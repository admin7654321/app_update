const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x592c4b,_0x1f65e0){if(!_0x592c4b)throw rt(_0x1f65e0);},rt=function(_0x1920e4){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x1920e4);},Vr=function(_0x15f399){const _0x335b6d=[];let _0x9f167f=0x0;for(let _0x539e86=0x0;_0x539e86<_0x15f399['length'];_0x539e86++){let _0x92031d=_0x15f399['charCodeAt'](_0x539e86);_0x92031d<0x80?_0x335b6d[_0x9f167f++]=_0x92031d:_0x92031d<0x800?(_0x335b6d[_0x9f167f++]=_0x92031d>>0x6|0xc0,_0x335b6d[_0x9f167f++]=_0x92031d&0x3f|0x80):(_0x92031d&0xfc00)===0xd800&&_0x539e86+0x1<_0x15f399['length']&&(_0x15f399['charCodeAt'](_0x539e86+0x1)&0xfc00)===0xdc00?(_0x92031d=0x10000+((_0x92031d&0x3ff)<<0xa)+(_0x15f399['charCodeAt'](++_0x539e86)&0x3ff),_0x335b6d[_0x9f167f++]=_0x92031d>>0x12|0xf0,_0x335b6d[_0x9f167f++]=_0x92031d>>0xc&0x3f|0x80,_0x335b6d[_0x9f167f++]=_0x92031d>>0x6&0x3f|0x80,_0x335b6d[_0x9f167f++]=_0x92031d&0x3f|0x80):(_0x335b6d[_0x9f167f++]=_0x92031d>>0xc|0xe0,_0x335b6d[_0x9f167f++]=_0x92031d>>0x6&0x3f|0x80,_0x335b6d[_0x9f167f++]=_0x92031d&0x3f|0x80);}return _0x335b6d;},ec=function(_0xab94b6){const _0x3276b5=[];let _0x557847=0x0,_0x33863e=0x0;for(;_0x557847<_0xab94b6['length'];){const _0x338f85=_0xab94b6[_0x557847++];if(_0x338f85<0x80)_0x3276b5[_0x33863e++]=String['fromCharCode'](_0x338f85);else{if(_0x338f85>0xbf&&_0x338f85<0xe0){const _0x3e263c=_0xab94b6[_0x557847++];_0x3276b5[_0x33863e++]=String['fromCharCode']((_0x338f85&0x1f)<<0x6|_0x3e263c&0x3f);}else{if(_0x338f85>0xef&&_0x338f85<0x16d){const _0x41cc9f=_0xab94b6[_0x557847++],_0x301675=_0xab94b6[_0x557847++],_0x410e77=_0xab94b6[_0x557847++],_0x177c49=((_0x338f85&0x7)<<0x12|(_0x41cc9f&0x3f)<<0xc|(_0x301675&0x3f)<<0x6|_0x410e77&0x3f)-0x10000;_0x3276b5[_0x33863e++]=String['fromCharCode'](0xd800+(_0x177c49>>0xa)),_0x3276b5[_0x33863e++]=String['fromCharCode'](0xdc00+(_0x177c49&0x3ff));}else{const _0x4789f6=_0xab94b6[_0x557847++],_0x5c15a7=_0xab94b6[_0x557847++];_0x3276b5[_0x33863e++]=String['fromCharCode']((_0x338f85&0xf)<<0xc|(_0x4789f6&0x3f)<<0x6|_0x5c15a7&0x3f);}}}}return _0x3276b5['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x22540b,_0x1914b6){if(!Array['isArray'](_0x22540b))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0xe7f8c2=_0x1914b6?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x31ca5b=[];for(let _0x46ff5f=0x0;_0x46ff5f<_0x22540b['length'];_0x46ff5f+=0x3){const _0x344466=_0x22540b[_0x46ff5f],_0x404773=_0x46ff5f+0x1<_0x22540b['length'],_0x54849a=_0x404773?_0x22540b[_0x46ff5f+0x1]:0x0,_0x377113=_0x46ff5f+0x2<_0x22540b['length'],_0x36e784=_0x377113?_0x22540b[_0x46ff5f+0x2]:0x0,_0x389c84=_0x344466>>0x2,_0x36539f=(_0x344466&0x3)<<0x4|_0x54849a>>0x4;let _0x52ba0e=(_0x54849a&0xf)<<0x2|_0x36e784>>0x6,_0xc1f7ed=_0x36e784&0x3f;_0x377113||(_0xc1f7ed=0x40,_0x404773||(_0x52ba0e=0x40)),_0x31ca5b['push'](_0xe7f8c2[_0x389c84],_0xe7f8c2[_0x36539f],_0xe7f8c2[_0x52ba0e],_0xe7f8c2[_0xc1f7ed]);}return _0x31ca5b['join']('');},'encodeString'(_0x3f3c33,_0x5089a9){return this['HAS_NATIVE_SUPPORT']&&!_0x5089a9?btoa(_0x3f3c33):this['encodeByteArray'](Vr(_0x3f3c33),_0x5089a9);},'decodeString'(_0x17510d,_0x54fc72){return this['HAS_NATIVE_SUPPORT']&&!_0x54fc72?atob(_0x17510d):ec(this['decodeStringToByteArray'](_0x17510d,_0x54fc72));},'decodeStringToByteArray'(_0xbeb110,_0x3d077e){this['init_']();const _0x34fcb5=_0x3d077e?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x236002=[];for(let _0x41a067=0x0;_0x41a067<_0xbeb110['length'];){const _0x3b2c1b=_0x34fcb5[_0xbeb110['charAt'](_0x41a067++)],_0x49cc7e=_0x41a067<_0xbeb110['length']?_0x34fcb5[_0xbeb110['charAt'](_0x41a067)]:0x0;++_0x41a067;const _0x3f6145=_0x41a067<_0xbeb110['length']?_0x34fcb5[_0xbeb110['charAt'](_0x41a067)]:0x40;++_0x41a067;const _0x57fe9e=_0x41a067<_0xbeb110['length']?_0x34fcb5[_0xbeb110['charAt'](_0x41a067)]:0x40;if(++_0x41a067,_0x3b2c1b==null||_0x49cc7e==null||_0x3f6145==null||_0x57fe9e==null)throw new tc();const _0x26dae6=_0x3b2c1b<<0x2|_0x49cc7e>>0x4;if(_0x236002['push'](_0x26dae6),_0x3f6145!==0x40){const _0x1ef5ec=_0x49cc7e<<0x4&0xf0|_0x3f6145>>0x2;if(_0x236002['push'](_0x1ef5ec),_0x57fe9e!==0x40){const _0x3185b5=_0x3f6145<<0x6&0xc0|_0x57fe9e;_0x236002['push'](_0x3185b5);}}}return _0x236002;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x46fcf0=0x0;_0x46fcf0<this['ENCODED_VALS']['length'];_0x46fcf0++)this['byteToCharMap_'][_0x46fcf0]=this['ENCODED_VALS']['charAt'](_0x46fcf0),this['charToByteMap_'][this['byteToCharMap_'][_0x46fcf0]]=_0x46fcf0,this['byteToCharMapWebSafe_'][_0x46fcf0]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x46fcf0),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x46fcf0]]=_0x46fcf0,_0x46fcf0>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x46fcf0)]=_0x46fcf0,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x46fcf0)]=_0x46fcf0);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x5dc599){const _0x114ebd=Vr(_0x5dc599);return Li['encodeByteArray'](_0x114ebd,!0x0);},cn=function(_0x48f8e8){return Hr(_0x48f8e8)['replace'](/\./g,'');},ln=function(_0x1b9658){try{return Li['decodeString'](_0x1b9658,!0x0);}catch(_0x4c245d){console['error']('base64Decode\x20failed:\x20',_0x4c245d);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x876b71){return $r(void 0x0,_0x876b71);}function $r(_0x526143,_0x1abe62){if(!(_0x1abe62 instanceof Object))return _0x1abe62;switch(_0x1abe62['constructor']){case Date:const _0x17d5e9=_0x1abe62;return new Date(_0x17d5e9['getTime']());case Object:_0x526143===void 0x0&&(_0x526143={});break;case Array:_0x526143=[];break;default:return _0x1abe62;}for(const _0x5ed059 in _0x1abe62)!_0x1abe62['hasOwnProperty'](_0x5ed059)||!ic(_0x5ed059)||(_0x526143[_0x5ed059]=$r(_0x526143[_0x5ed059],_0x1abe62[_0x5ed059]));return _0x526143;}function ic(_0x1b18e0){return _0x1b18e0!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x3c932e=Ns['__FIREBASE_DEFAULTS__'];if(_0x3c932e)return JSON['parse'](_0x3c932e);},ac=()=>{if(typeof document>'u')return;let _0x22af93;try{_0x22af93=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x4aa6ec=_0x22af93&&ln(_0x22af93[0x1]);return _0x4aa6ec&&JSON['parse'](_0x4aa6ec);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0xca6286){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0xca6286);return;}},Gr=_0x39585e=>{var _0x54db11,_0x11d5d1;return(_0x11d5d1=(_0x54db11=xi())==null?void 0x0:_0x54db11['emulatorHosts'])==null?void 0x0:_0x11d5d1[_0x39585e];},cc=_0x14008e=>{const _0x3e1dca=Gr(_0x14008e);if(!_0x3e1dca)return;const _0x5f2e14=_0x3e1dca['lastIndexOf'](':');if(_0x5f2e14<=0x0||_0x5f2e14+0x1===_0x3e1dca['length'])throw new Error('Invalid\x20host\x20'+_0x3e1dca+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x1ddd9=parseInt(_0x3e1dca['substring'](_0x5f2e14+0x1),0xa);return _0x3e1dca[0x0]==='['?[_0x3e1dca['substring'](0x1,_0x5f2e14-0x1),_0x1ddd9]:[_0x3e1dca['substring'](0x0,_0x5f2e14),_0x1ddd9];},qr=()=>{var _0x5573f7;return(_0x5573f7=xi())==null?void 0x0:_0x5573f7['config'];},zr=_0x9fae30=>{var _0x4101ea;return(_0x4101ea=xi())==null?void 0x0:_0x4101ea['_'+_0x9fae30];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x1a0d3e,_0x515df4)=>{this['resolve']=_0x1a0d3e,this['reject']=_0x515df4;});}['wrapCallback'](_0x4b13af){return(_0x3ec6a4,_0x1df732)=>{_0x3ec6a4?this['reject'](_0x3ec6a4):this['resolve'](_0x1df732),typeof _0x4b13af=='function'&&(this['promise']['catch'](()=>{}),_0x4b13af['length']===0x1?_0x4b13af(_0x3ec6a4):_0x4b13af(_0x3ec6a4,_0x1df732));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x78275a){try{return(_0x78275a['startsWith']('http://')||_0x78275a['startsWith']('https://')?new URL(_0x78275a)['hostname']:_0x78275a)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x7e5b52){return(await fetch(_0x7e5b52,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x5005cc,_0x39e38d){if(_0x5005cc['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x4cfbb3={'alg':'none','type':'JWT'},_0x3a4890=_0x39e38d||'demo-project',_0x48fced=_0x5005cc['iat']||0x0,_0x2e5a45=_0x5005cc['sub']||_0x5005cc['user_id'];if(!_0x2e5a45)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0xec08a2={'iss':'https://securetoken.google.com/'+_0x3a4890,'aud':_0x3a4890,'iat':_0x48fced,'exp':_0x48fced+0xe10,'auth_time':_0x48fced,'sub':_0x2e5a45,'user_id':_0x2e5a45,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x5005cc};return[cn(JSON['stringify'](_0x4cfbb3)),cn(JSON['stringify'](_0xec08a2)),'']['join']('.');}const It={};function hc(){const _0x2267c4={'prod':[],'emulator':[]};for(const _0x43bdb4 of Object['keys'](It))It[_0x43bdb4]?_0x2267c4['emulator']['push'](_0x43bdb4):_0x2267c4['prod']['push'](_0x43bdb4);return _0x2267c4;}function uc(_0x5430a4){let _0x499e0f=document['getElementById'](_0x5430a4),_0x5975e0=!0x1;return _0x499e0f||(_0x499e0f=document['createElement']('div'),_0x499e0f['setAttribute']('id',_0x5430a4),_0x5975e0=!0x0),{'created':_0x5975e0,'element':_0x499e0f};}let Ps=!0x1;function Kr(_0x198c41,_0x179206){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x198c41]===_0x179206||It[_0x198c41]||Ps)return;It[_0x198c41]=_0x179206;function _0x3cc43d(_0x46dc37){return'__firebase__banner__'+_0x46dc37;}const _0x217254='__firebase__banner',_0x5187cd=hc()['prod']['length']>0x0;function _0x28246a(){const _0x4cfdbf=document['getElementById'](_0x217254);_0x4cfdbf&&_0x4cfdbf['remove']();}function _0x1ab408(_0x168d8e){_0x168d8e['style']['display']='flex',_0x168d8e['style']['background']='#7faaf0',_0x168d8e['style']['position']='fixed',_0x168d8e['style']['bottom']='5px',_0x168d8e['style']['left']='5px',_0x168d8e['style']['padding']='.5em',_0x168d8e['style']['borderRadius']='5px',_0x168d8e['style']['alignItems']='center';}function _0xacd816(_0x26cfb4,_0x5eef0e){_0x26cfb4['setAttribute']('width','24'),_0x26cfb4['setAttribute']('id',_0x5eef0e),_0x26cfb4['setAttribute']('height','24'),_0x26cfb4['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x26cfb4['setAttribute']('fill','none'),_0x26cfb4['style']['marginLeft']='-6px';}function _0x2a4d9a(){const _0xb8968a=document['createElement']('span');return _0xb8968a['style']['cursor']='pointer',_0xb8968a['style']['marginLeft']='16px',_0xb8968a['style']['fontSize']='24px',_0xb8968a['innerHTML']='\x20&times;',_0xb8968a['onclick']=()=>{Ps=!0x0,_0x28246a();},_0xb8968a;}function _0x5cb83c(_0x5bdc5b,_0x4979a4){_0x5bdc5b['setAttribute']('id',_0x4979a4),_0x5bdc5b['innerText']='Learn\x20more',_0x5bdc5b['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x5bdc5b['setAttribute']('target','__blank'),_0x5bdc5b['style']['paddingLeft']='5px',_0x5bdc5b['style']['textDecoration']='underline';}function _0x1dba0a(){const _0x7d0436=uc(_0x217254),_0x3db0a6=_0x3cc43d('text'),_0x373e69=document['getElementById'](_0x3db0a6)||document['createElement']('span'),_0x11506f=_0x3cc43d('learnmore'),_0x97a3cd=document['getElementById'](_0x11506f)||document['createElement']('a'),_0x4c280d=_0x3cc43d('preprendIcon'),_0x3ef506=document['getElementById'](_0x4c280d)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x7d0436['created']){const _0x208089=_0x7d0436['element'];_0x1ab408(_0x208089),_0x5cb83c(_0x97a3cd,_0x11506f);const _0x491e58=_0x2a4d9a();_0xacd816(_0x3ef506,_0x4c280d),_0x208089['append'](_0x3ef506,_0x373e69,_0x97a3cd,_0x491e58),document['body']['appendChild'](_0x208089);}_0x5187cd?(_0x373e69['innerText']='Preview\x20backend\x20disconnected.',_0x3ef506['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x3ef506['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x373e69['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x373e69['setAttribute']('id',_0x3db0a6);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1dba0a):_0x1dba0a();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x12ffdc=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x12ffdc=='object'&&_0x12ffdc['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x9fb3e0=W();return _0x9fb3e0['indexOf']('MSIE\x20')>=0x0||_0x9fb3e0['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x5d660a,_0x37c4df)=>{try{let _0x113b34=!0x0;const _0x4bf526='validate-browser-context-for-indexeddb-analytics-module',_0x498862=self['indexedDB']['open'](_0x4bf526);_0x498862['onsuccess']=()=>{_0x498862['result']['close'](),_0x113b34||self['indexedDB']['deleteDatabase'](_0x4bf526),_0x5d660a(!0x0);},_0x498862['onupgradeneeded']=()=>{_0x113b34=!0x1;},_0x498862['onerror']=()=>{var _0x5af7bd;_0x37c4df(((_0x5af7bd=_0x498862['error'])==null?void 0x0:_0x5af7bd['message'])||'');};}catch(_0x64f985){_0x37c4df(_0x64f985);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x47dd5e,_0x527de1,_0x5d1e38){super(_0x527de1),this['code']=_0x47dd5e,this['customData']=_0x5d1e38,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x47aa28,_0x46aff6,_0x1f6f6e){this['service']=_0x47aa28,this['serviceName']=_0x46aff6,this['errors']=_0x1f6f6e;}['create'](_0x50b6e6,..._0x111bb6){const _0x335cda=_0x111bb6[0x0]||{},_0x1b72dc=this['service']+'/'+_0x50b6e6,_0x33fb35=this['errors'][_0x50b6e6],_0x2435c1=_0x33fb35?vc(_0x33fb35,_0x335cda):'Error',_0x4667f6=this['serviceName']+':\x20'+_0x2435c1+'\x20('+_0x1b72dc+').';return new Se(_0x1b72dc,_0x4667f6,_0x335cda);}}function vc(_0x4c2a7a,_0x2c52a9){return _0x4c2a7a['replace'](Ec,(_0xfc1724,_0x51bedf)=>{const _0xb7c3e7=_0x2c52a9[_0x51bedf];return _0xb7c3e7!=null?String(_0xb7c3e7):'<'+_0x51bedf+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x41740a){return JSON['parse'](_0x41740a);}function O(_0x9485f){return JSON['stringify'](_0x9485f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x18fb5b){let _0x498b79={},_0x3fd450={},_0x37d0a1={},_0x45620a='';try{const _0x20b164=_0x18fb5b['split']('.');_0x498b79=At(ln(_0x20b164[0x0])||''),_0x3fd450=At(ln(_0x20b164[0x1])||''),_0x45620a=_0x20b164[0x2],_0x37d0a1=_0x3fd450['d']||{},delete _0x3fd450['d'];}catch{}return{'header':_0x498b79,'claims':_0x3fd450,'data':_0x37d0a1,'signature':_0x45620a};},Ic=function(_0x41adf7){const _0x3b441a=Qr(_0x41adf7),_0x1f6dfd=_0x3b441a['claims'];return!!_0x1f6dfd&&typeof _0x1f6dfd=='object'&&_0x1f6dfd['hasOwnProperty']('iat');},wc=function(_0x374dd0){const _0x3e3251=Qr(_0x374dd0)['claims'];return typeof _0x3e3251=='object'&&_0x3e3251['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x37141d,_0x45eac5){return Object['prototype']['hasOwnProperty']['call'](_0x37141d,_0x45eac5);}function De(_0x362a82,_0x589655){if(Object['prototype']['hasOwnProperty']['call'](_0x362a82,_0x589655))return _0x362a82[_0x589655];}function ui(_0x5f4b06){for(const _0x408a7f in _0x5f4b06)if(Object['prototype']['hasOwnProperty']['call'](_0x5f4b06,_0x408a7f))return!0x1;return!0x0;}function hn(_0x2c59f7,_0x5df407,_0x24a200){const _0x2c71fb={};for(const _0x3396e2 in _0x2c59f7)Object['prototype']['hasOwnProperty']['call'](_0x2c59f7,_0x3396e2)&&(_0x2c71fb[_0x3396e2]=_0x5df407['call'](_0x24a200,_0x2c59f7[_0x3396e2],_0x3396e2,_0x2c59f7));return _0x2c71fb;}function Me(_0x18d094,_0x3863a7){if(_0x18d094===_0x3863a7)return!0x0;const _0x1ff307=Object['keys'](_0x18d094),_0x380049=Object['keys'](_0x3863a7);for(const _0x570fe0 of _0x1ff307){if(!_0x380049['includes'](_0x570fe0))return!0x1;const _0x182aa5=_0x18d094[_0x570fe0],_0x3f9cc7=_0x3863a7[_0x570fe0];if(Os(_0x182aa5)&&Os(_0x3f9cc7)){if(!Me(_0x182aa5,_0x3f9cc7))return!0x1;}else{if(_0x182aa5!==_0x3f9cc7)return!0x1;}}for(const _0x3e466f of _0x380049)if(!_0x1ff307['includes'](_0x3e466f))return!0x1;return!0x0;}function Os(_0x15562a){return _0x15562a!==null&&typeof _0x15562a=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x125550){const _0x427c1b=[];for(const [_0x402faf,_0x68d32d]of Object['entries'](_0x125550))Array['isArray'](_0x68d32d)?_0x68d32d['forEach'](_0x549b9e=>{_0x427c1b['push'](encodeURIComponent(_0x402faf)+'='+encodeURIComponent(_0x549b9e));}):_0x427c1b['push'](encodeURIComponent(_0x402faf)+'='+encodeURIComponent(_0x68d32d));return _0x427c1b['length']?'&'+_0x427c1b['join']('&'):'';}function vt(_0x7c8953){const _0x4f4ee6={};return _0x7c8953['replace'](/^\?/,'')['split']('&')['forEach'](_0x51f380=>{if(_0x51f380){const [_0x3169b7,_0x1b5eb5]=_0x51f380['split']('=');_0x4f4ee6[decodeURIComponent(_0x3169b7)]=decodeURIComponent(_0x1b5eb5);}}),_0x4f4ee6;}function Et(_0x36d76d){const _0x5cbde6=_0x36d76d['indexOf']('?');if(!_0x5cbde6)return'';const _0x23d247=_0x36d76d['indexOf']('#',_0x5cbde6);return _0x36d76d['substring'](_0x5cbde6,_0x23d247>0x0?_0x23d247:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x361c02=0x1;_0x361c02<this['blockSize'];++_0x361c02)this['pad_'][_0x361c02]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x48a702,_0x3d7d42){_0x3d7d42||(_0x3d7d42=0x0);const _0x225699=this['W_'];if(typeof _0x48a702=='string'){for(let _0xe948d9=0x0;_0xe948d9<0x10;_0xe948d9++)_0x225699[_0xe948d9]=_0x48a702['charCodeAt'](_0x3d7d42)<<0x18|_0x48a702['charCodeAt'](_0x3d7d42+0x1)<<0x10|_0x48a702['charCodeAt'](_0x3d7d42+0x2)<<0x8|_0x48a702['charCodeAt'](_0x3d7d42+0x3),_0x3d7d42+=0x4;}else{for(let _0x368742=0x0;_0x368742<0x10;_0x368742++)_0x225699[_0x368742]=_0x48a702[_0x3d7d42]<<0x18|_0x48a702[_0x3d7d42+0x1]<<0x10|_0x48a702[_0x3d7d42+0x2]<<0x8|_0x48a702[_0x3d7d42+0x3],_0x3d7d42+=0x4;}for(let _0xc1275=0x10;_0xc1275<0x50;_0xc1275++){const _0x584ac9=_0x225699[_0xc1275-0x3]^_0x225699[_0xc1275-0x8]^_0x225699[_0xc1275-0xe]^_0x225699[_0xc1275-0x10];_0x225699[_0xc1275]=(_0x584ac9<<0x1|_0x584ac9>>>0x1f)&0xffffffff;}let _0x425a9b=this['chain_'][0x0],_0x227586=this['chain_'][0x1],_0xaf2009=this['chain_'][0x2],_0x1772f1=this['chain_'][0x3],_0x1a545d=this['chain_'][0x4],_0x5a563a,_0x38a46e;for(let _0x4313dd=0x0;_0x4313dd<0x50;_0x4313dd++){_0x4313dd<0x28?_0x4313dd<0x14?(_0x5a563a=_0x1772f1^_0x227586&(_0xaf2009^_0x1772f1),_0x38a46e=0x5a827999):(_0x5a563a=_0x227586^_0xaf2009^_0x1772f1,_0x38a46e=0x6ed9eba1):_0x4313dd<0x3c?(_0x5a563a=_0x227586&_0xaf2009|_0x1772f1&(_0x227586|_0xaf2009),_0x38a46e=0x8f1bbcdc):(_0x5a563a=_0x227586^_0xaf2009^_0x1772f1,_0x38a46e=0xca62c1d6);const _0x2dad9f=(_0x425a9b<<0x5|_0x425a9b>>>0x1b)+_0x5a563a+_0x1a545d+_0x38a46e+_0x225699[_0x4313dd]&0xffffffff;_0x1a545d=_0x1772f1,_0x1772f1=_0xaf2009,_0xaf2009=(_0x227586<<0x1e|_0x227586>>>0x2)&0xffffffff,_0x227586=_0x425a9b,_0x425a9b=_0x2dad9f;}this['chain_'][0x0]=this['chain_'][0x0]+_0x425a9b&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x227586&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0xaf2009&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x1772f1&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x1a545d&0xffffffff;}['update'](_0x288cf1,_0x40245f){if(_0x288cf1==null)return;_0x40245f===void 0x0&&(_0x40245f=_0x288cf1['length']);const _0x59bbb8=_0x40245f-this['blockSize'];let _0x3a6799=0x0;const _0x132fea=this['buf_'];let _0x22b3ed=this['inbuf_'];for(;_0x3a6799<_0x40245f;){if(_0x22b3ed===0x0){for(;_0x3a6799<=_0x59bbb8;)this['compress_'](_0x288cf1,_0x3a6799),_0x3a6799+=this['blockSize'];}if(typeof _0x288cf1=='string'){for(;_0x3a6799<_0x40245f;)if(_0x132fea[_0x22b3ed]=_0x288cf1['charCodeAt'](_0x3a6799),++_0x22b3ed,++_0x3a6799,_0x22b3ed===this['blockSize']){this['compress_'](_0x132fea),_0x22b3ed=0x0;break;}}else{for(;_0x3a6799<_0x40245f;)if(_0x132fea[_0x22b3ed]=_0x288cf1[_0x3a6799],++_0x22b3ed,++_0x3a6799,_0x22b3ed===this['blockSize']){this['compress_'](_0x132fea),_0x22b3ed=0x0;break;}}}this['inbuf_']=_0x22b3ed,this['total_']+=_0x40245f;}['digest'](){const _0x2d26ce=[];let _0x330633=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x15e666=this['blockSize']-0x1;_0x15e666>=0x38;_0x15e666--)this['buf_'][_0x15e666]=_0x330633&0xff,_0x330633/=0x100;this['compress_'](this['buf_']);let _0x11b86b=0x0;for(let _0x3a8fac=0x0;_0x3a8fac<0x5;_0x3a8fac++)for(let _0x447f75=0x18;_0x447f75>=0x0;_0x447f75-=0x8)_0x2d26ce[_0x11b86b]=this['chain_'][_0x3a8fac]>>_0x447f75&0xff,++_0x11b86b;return _0x2d26ce;}}function Tc(_0x580c76,_0x2a2b40){const _0x2ee635=new Sc(_0x580c76,_0x2a2b40);return _0x2ee635['subscribe']['bind'](_0x2ee635);}class Sc{constructor(_0x2feca8,_0x3045cf){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x3045cf,this['task']['then'](()=>{_0x2feca8(this);})['catch'](_0x49ff7e=>{this['error'](_0x49ff7e);});}['next'](_0x22c7a4){this['forEachObserver'](_0x3b0b04=>{_0x3b0b04['next'](_0x22c7a4);});}['error'](_0x59b50d){this['forEachObserver'](_0x266071=>{_0x266071['error'](_0x59b50d);}),this['close'](_0x59b50d);}['complete'](){this['forEachObserver'](_0x59b483=>{_0x59b483['complete']();}),this['close']();}['subscribe'](_0x4ac108,_0x1e0c3b,_0x5e3ddf){let _0x459da2;if(_0x4ac108===void 0x0&&_0x1e0c3b===void 0x0&&_0x5e3ddf===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x4ac108,['next','error','complete'])?_0x459da2=_0x4ac108:_0x459da2={'next':_0x4ac108,'error':_0x1e0c3b,'complete':_0x5e3ddf},_0x459da2['next']===void 0x0&&(_0x459da2['next']=Jn),_0x459da2['error']===void 0x0&&(_0x459da2['error']=Jn),_0x459da2['complete']===void 0x0&&(_0x459da2['complete']=Jn);const _0x1d1a34=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x459da2['error'](this['finalError']):_0x459da2['complete']();}catch{}}),this['observers']['push'](_0x459da2),_0x1d1a34;}['unsubscribeOne'](_0x4e7c77){this['observers']===void 0x0||this['observers'][_0x4e7c77]===void 0x0||(delete this['observers'][_0x4e7c77],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x52b6dc){if(!this['finalized']){for(let _0x330878=0x0;_0x330878<this['observers']['length'];_0x330878++)this['sendOne'](_0x330878,_0x52b6dc);}}['sendOne'](_0x3b95b3,_0x1aad20){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x3b95b3]!==void 0x0)try{_0x1aad20(this['observers'][_0x3b95b3]);}catch(_0x38c393){typeof console<'u'&&console['error']&&console['error'](_0x38c393);}});}['close'](_0x9d4f11){this['finalized']||(this['finalized']=!0x0,_0x9d4f11!==void 0x0&&(this['finalError']=_0x9d4f11),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x36dab6,_0x222aab){if(typeof _0x36dab6!='object'||_0x36dab6===null)return!0x1;for(const _0xb652c8 of _0x222aab)if(_0xb652c8 in _0x36dab6&&typeof _0x36dab6[_0xb652c8]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x59908f,_0x397601){return _0x59908f+'\x20failed:\x20'+_0x397601+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x713381){const _0x4f4fde=[];let _0x2b01e5=0x0;for(let _0x2f8133=0x0;_0x2f8133<_0x713381['length'];_0x2f8133++){let _0x325c5e=_0x713381['charCodeAt'](_0x2f8133);if(_0x325c5e>=0xd800&&_0x325c5e<=0xdbff){const _0x3371ae=_0x325c5e-0xd800;_0x2f8133++,f(_0x2f8133<_0x713381['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x1abde2=_0x713381['charCodeAt'](_0x2f8133)-0xdc00;_0x325c5e=0x10000+(_0x3371ae<<0xa)+_0x1abde2;}_0x325c5e<0x80?_0x4f4fde[_0x2b01e5++]=_0x325c5e:_0x325c5e<0x800?(_0x4f4fde[_0x2b01e5++]=_0x325c5e>>0x6|0xc0,_0x4f4fde[_0x2b01e5++]=_0x325c5e&0x3f|0x80):_0x325c5e<0x10000?(_0x4f4fde[_0x2b01e5++]=_0x325c5e>>0xc|0xe0,_0x4f4fde[_0x2b01e5++]=_0x325c5e>>0x6&0x3f|0x80,_0x4f4fde[_0x2b01e5++]=_0x325c5e&0x3f|0x80):(_0x4f4fde[_0x2b01e5++]=_0x325c5e>>0x12|0xf0,_0x4f4fde[_0x2b01e5++]=_0x325c5e>>0xc&0x3f|0x80,_0x4f4fde[_0x2b01e5++]=_0x325c5e>>0x6&0x3f|0x80,_0x4f4fde[_0x2b01e5++]=_0x325c5e&0x3f|0x80);}return _0x4f4fde;},On=function(_0x53efa2){let _0x17c826=0x0;for(let _0x14545f=0x0;_0x14545f<_0x53efa2['length'];_0x14545f++){const _0x432af2=_0x53efa2['charCodeAt'](_0x14545f);_0x432af2<0x80?_0x17c826++:_0x432af2<0x800?_0x17c826+=0x2:_0x432af2>=0xd800&&_0x432af2<=0xdbff?(_0x17c826+=0x4,_0x14545f++):_0x17c826+=0x3;}return _0x17c826;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x3a3266){return _0x3a3266&&_0x3a3266['_delegate']?_0x3a3266['_delegate']:_0x3a3266;}class Le{constructor(_0x18112c,_0x14b1fd,_0x4ad47a){this['name']=_0x18112c,this['instanceFactory']=_0x14b1fd,this['type']=_0x4ad47a,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x126d9d){return this['instantiationMode']=_0x126d9d,this;}['setMultipleInstances'](_0x3693a5){return this['multipleInstances']=_0x3693a5,this;}['setServiceProps'](_0x4094b3){return this['serviceProps']=_0x4094b3,this;}['setInstanceCreatedCallback'](_0x24a35a){return this['onInstanceCreated']=_0x24a35a,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x2f2ba6,_0x41ee87){this['name']=_0x2f2ba6,this['container']=_0x41ee87,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x5afdb9){const _0x55e9ae=this['normalizeInstanceIdentifier'](_0x5afdb9);if(!this['instancesDeferred']['has'](_0x55e9ae)){const _0x1f452a=new ot();if(this['instancesDeferred']['set'](_0x55e9ae,_0x1f452a),this['isInitialized'](_0x55e9ae)||this['shouldAutoInitialize']())try{const _0x592442=this['getOrInitializeService']({'instanceIdentifier':_0x55e9ae});_0x592442&&_0x1f452a['resolve'](_0x592442);}catch{}}return this['instancesDeferred']['get'](_0x55e9ae)['promise'];}['getImmediate'](_0x59ad32){const _0x147b2a=this['normalizeInstanceIdentifier'](_0x59ad32==null?void 0x0:_0x59ad32['identifier']),_0x383b38=(_0x59ad32==null?void 0x0:_0x59ad32['optional'])??!0x1;if(this['isInitialized'](_0x147b2a)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x147b2a});}catch(_0x414f37){if(_0x383b38)return null;throw _0x414f37;}else{if(_0x383b38)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x22ab6f){if(_0x22ab6f['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x22ab6f['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x22ab6f,!!this['shouldAutoInitialize']()){if(Nc(_0x22ab6f))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x49c56a,_0x4b84d9]of this['instancesDeferred']['entries']()){const _0x2f465e=this['normalizeInstanceIdentifier'](_0x49c56a);try{const _0x11c4f7=this['getOrInitializeService']({'instanceIdentifier':_0x2f465e});_0x4b84d9['resolve'](_0x11c4f7);}catch{}}}}['clearInstance'](_0x22d919=Ne){this['instancesDeferred']['delete'](_0x22d919),this['instancesOptions']['delete'](_0x22d919),this['instances']['delete'](_0x22d919);}async['delete'](){const _0xfd68f8=Array['from'](this['instances']['values']());await Promise['all']([..._0xfd68f8['filter'](_0x3dbdcf=>'INTERNAL'in _0x3dbdcf)['map'](_0x327c81=>_0x327c81['INTERNAL']['delete']()),..._0xfd68f8['filter'](_0x1f0e51=>'_delete'in _0x1f0e51)['map'](_0x59b1ca=>_0x59b1ca['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x43ec4f=Ne){return this['instances']['has'](_0x43ec4f);}['getOptions'](_0x5cc502=Ne){return this['instancesOptions']['get'](_0x5cc502)||{};}['initialize'](_0xd96a18={}){const {options:_0x5de0f6={}}=_0xd96a18,_0x1ef459=this['normalizeInstanceIdentifier'](_0xd96a18['instanceIdentifier']);if(this['isInitialized'](_0x1ef459))throw Error(this['name']+'('+_0x1ef459+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x45a473=this['getOrInitializeService']({'instanceIdentifier':_0x1ef459,'options':_0x5de0f6});for(const [_0x44995b,_0x19ddcc]of this['instancesDeferred']['entries']()){const _0x3a355d=this['normalizeInstanceIdentifier'](_0x44995b);_0x1ef459===_0x3a355d&&_0x19ddcc['resolve'](_0x45a473);}return _0x45a473;}['onInit'](_0x1a84ab,_0x1a2c64){const _0x130063=this['normalizeInstanceIdentifier'](_0x1a2c64),_0x5077cd=this['onInitCallbacks']['get'](_0x130063)??new Set();_0x5077cd['add'](_0x1a84ab),this['onInitCallbacks']['set'](_0x130063,_0x5077cd);const _0x2b356a=this['instances']['get'](_0x130063);return _0x2b356a&&_0x1a84ab(_0x2b356a,_0x130063),()=>{_0x5077cd['delete'](_0x1a84ab);};}['invokeOnInitCallbacks'](_0x3e24f2,_0x5e2221){const _0x3ee46a=this['onInitCallbacks']['get'](_0x5e2221);if(_0x3ee46a){for(const _0x2d879e of _0x3ee46a)try{_0x2d879e(_0x3e24f2,_0x5e2221);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x1595e3,options:_0x2fd1c5={}}){let _0x54d054=this['instances']['get'](_0x1595e3);if(!_0x54d054&&this['component']&&(_0x54d054=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x1595e3),'options':_0x2fd1c5}),this['instances']['set'](_0x1595e3,_0x54d054),this['instancesOptions']['set'](_0x1595e3,_0x2fd1c5),this['invokeOnInitCallbacks'](_0x54d054,_0x1595e3),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x1595e3,_0x54d054);}catch{}return _0x54d054||null;}['normalizeInstanceIdentifier'](_0x3a1703=Ne){return this['component']?this['component']['multipleInstances']?_0x3a1703:Ne:_0x3a1703;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x5ad53a){return _0x5ad53a===Ne?void 0x0:_0x5ad53a;}function Nc(_0x5b102e){return _0x5b102e['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x13948e){this['name']=_0x13948e,this['providers']=new Map();}['addComponent'](_0x4f2d89){const _0x294354=this['getProvider'](_0x4f2d89['name']);if(_0x294354['isComponentSet']())throw new Error('Component\x20'+_0x4f2d89['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x294354['setComponent'](_0x4f2d89);}['addOrOverwriteComponent'](_0x421ab0){this['getProvider'](_0x421ab0['name'])['isComponentSet']()&&this['providers']['delete'](_0x421ab0['name']),this['addComponent'](_0x421ab0);}['getProvider'](_0x140f8a){if(this['providers']['has'](_0x140f8a))return this['providers']['get'](_0x140f8a);const _0x2e1f9d=new Ac(_0x140f8a,this);return this['providers']['set'](_0x140f8a,_0x2e1f9d),_0x2e1f9d;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x474c38){_0x474c38[_0x474c38['DEBUG']=0x0]='DEBUG',_0x474c38[_0x474c38['VERBOSE']=0x1]='VERBOSE',_0x474c38[_0x474c38['INFO']=0x2]='INFO',_0x474c38[_0x474c38['WARN']=0x3]='WARN',_0x474c38[_0x474c38['ERROR']=0x4]='ERROR',_0x474c38[_0x474c38['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x4c8a31,_0x153743,..._0x21ccd1)=>{if(_0x153743<_0x4c8a31['logLevel'])return;const _0x15c75e=new Date()['toISOString'](),_0xea48b6=Mc[_0x153743];if(_0xea48b6)console[_0xea48b6]('['+_0x15c75e+']\x20\x20'+_0x4c8a31['name']+':',..._0x21ccd1);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x153743+')');};class Ui{constructor(_0x520e5c){this['name']=_0x520e5c,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x10d7ca){if(!(_0x10d7ca in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x10d7ca+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x10d7ca;}['setLogLevel'](_0x422767){this['_logLevel']=typeof _0x422767=='string'?Oc[_0x422767]:_0x422767;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x3b39ba){if(typeof _0x3b39ba!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x3b39ba;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x37b3df){this['_userLogHandler']=_0x37b3df;}['debug'](..._0x198c81){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x198c81),this['_logHandler'](this,T['DEBUG'],..._0x198c81);}['log'](..._0x1af3df){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x1af3df),this['_logHandler'](this,T['VERBOSE'],..._0x1af3df);}['info'](..._0x2434cb){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x2434cb),this['_logHandler'](this,T['INFO'],..._0x2434cb);}['warn'](..._0x3f4449){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x3f4449),this['_logHandler'](this,T['WARN'],..._0x3f4449);}['error'](..._0x1b3b3a){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x1b3b3a),this['_logHandler'](this,T['ERROR'],..._0x1b3b3a);}}const xc=(_0x17a3dd,_0x56f72e)=>_0x56f72e['some'](_0x3ef15c=>_0x17a3dd instanceof _0x3ef15c);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x55df8e){const _0x2b208b=new Promise((_0x530348,_0x4d601e)=>{const _0x57ec89=()=>{_0x55df8e['removeEventListener']('success',_0x1dd63f),_0x55df8e['removeEventListener']('error',_0x517e93);},_0x1dd63f=()=>{_0x530348(_e(_0x55df8e['result'])),_0x57ec89();},_0x517e93=()=>{_0x4d601e(_0x55df8e['error']),_0x57ec89();};_0x55df8e['addEventListener']('success',_0x1dd63f),_0x55df8e['addEventListener']('error',_0x517e93);});return _0x2b208b['then'](_0x35a523=>{_0x35a523 instanceof IDBCursor&&Jr['set'](_0x35a523,_0x55df8e);})['catch'](()=>{}),Wi['set'](_0x2b208b,_0x55df8e),_0x2b208b;}function Bc(_0x131a18){if(di['has'](_0x131a18))return;const _0x38f10a=new Promise((_0x1eb615,_0x48411a)=>{const _0x4b1258=()=>{_0x131a18['removeEventListener']('complete',_0xf6c9c6),_0x131a18['removeEventListener']('error',_0x2994fc),_0x131a18['removeEventListener']('abort',_0x2994fc);},_0xf6c9c6=()=>{_0x1eb615(),_0x4b1258();},_0x2994fc=()=>{_0x48411a(_0x131a18['error']||new DOMException('AbortError','AbortError')),_0x4b1258();};_0x131a18['addEventListener']('complete',_0xf6c9c6),_0x131a18['addEventListener']('error',_0x2994fc),_0x131a18['addEventListener']('abort',_0x2994fc);});di['set'](_0x131a18,_0x38f10a);}let fi={'get'(_0x3d8cde,_0x22dc82,_0x3451bd){if(_0x3d8cde instanceof IDBTransaction){if(_0x22dc82==='done')return di['get'](_0x3d8cde);if(_0x22dc82==='objectStoreNames')return _0x3d8cde['objectStoreNames']||Xr['get'](_0x3d8cde);if(_0x22dc82==='store')return _0x3451bd['objectStoreNames'][0x1]?void 0x0:_0x3451bd['objectStore'](_0x3451bd['objectStoreNames'][0x0]);}return _e(_0x3d8cde[_0x22dc82]);},'set'(_0x1ea609,_0x244ca8,_0x19d5f3){return _0x1ea609[_0x244ca8]=_0x19d5f3,!0x0;},'has'(_0x3de8a8,_0x5c07ff){return _0x3de8a8 instanceof IDBTransaction&&(_0x5c07ff==='done'||_0x5c07ff==='store')?!0x0:_0x5c07ff in _0x3de8a8;}};function Vc(_0x576b23){fi=_0x576b23(fi);}function Hc(_0x37dcfb){return _0x37dcfb===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x31aaa0,..._0x24d7a7){const _0x902a4f=_0x37dcfb['call'](Zn(this),_0x31aaa0,..._0x24d7a7);return Xr['set'](_0x902a4f,_0x31aaa0['sort']?_0x31aaa0['sort']():[_0x31aaa0]),_e(_0x902a4f);}:Uc()['includes'](_0x37dcfb)?function(..._0x574475){return _0x37dcfb['apply'](Zn(this),_0x574475),_e(Jr['get'](this));}:function(..._0x3f8e1f){return _e(_0x37dcfb['apply'](Zn(this),_0x3f8e1f));};}function $c(_0x12eabe){return typeof _0x12eabe=='function'?Hc(_0x12eabe):(_0x12eabe instanceof IDBTransaction&&Bc(_0x12eabe),xc(_0x12eabe,Fc())?new Proxy(_0x12eabe,fi):_0x12eabe);}function _e(_0x1ba06d){if(_0x1ba06d instanceof IDBRequest)return Wc(_0x1ba06d);if(Xn['has'](_0x1ba06d))return Xn['get'](_0x1ba06d);const _0x14e6a3=$c(_0x1ba06d);return _0x14e6a3!==_0x1ba06d&&(Xn['set'](_0x1ba06d,_0x14e6a3),Wi['set'](_0x14e6a3,_0x1ba06d)),_0x14e6a3;}const Zn=_0x4cfc7e=>Wi['get'](_0x4cfc7e);function Gc(_0x4a5d9f,_0x293ef1,{blocked:_0x12d26b,upgrade:_0x1cfe31,blocking:_0x34040f,terminated:_0x3a4de1}={}){const _0x320271=indexedDB['open'](_0x4a5d9f,_0x293ef1),_0x1d1b49=_e(_0x320271);return _0x1cfe31&&_0x320271['addEventListener']('upgradeneeded',_0x386ab9=>{_0x1cfe31(_e(_0x320271['result']),_0x386ab9['oldVersion'],_0x386ab9['newVersion'],_e(_0x320271['transaction']),_0x386ab9);}),_0x12d26b&&_0x320271['addEventListener']('blocked',_0x5d8c48=>_0x12d26b(_0x5d8c48['oldVersion'],_0x5d8c48['newVersion'],_0x5d8c48)),_0x1d1b49['then'](_0x4140ca=>{_0x3a4de1&&_0x4140ca['addEventListener']('close',()=>_0x3a4de1()),_0x34040f&&_0x4140ca['addEventListener']('versionchange',_0x353196=>_0x34040f(_0x353196['oldVersion'],_0x353196['newVersion'],_0x353196));})['catch'](()=>{}),_0x1d1b49;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x309831,_0xa86c28){if(!(_0x309831 instanceof IDBDatabase&&!(_0xa86c28 in _0x309831)&&typeof _0xa86c28=='string'))return;if(ei['get'](_0xa86c28))return ei['get'](_0xa86c28);const _0x4df12f=_0xa86c28['replace'](/FromIndex$/,''),_0xf09a8b=_0xa86c28!==_0x4df12f,_0x1d2834=zc['includes'](_0x4df12f);if(!(_0x4df12f in(_0xf09a8b?IDBIndex:IDBObjectStore)['prototype'])||!(_0x1d2834||qc['includes'](_0x4df12f)))return;const _0x13a41e=async function(_0x59fd58,..._0x5235fa){const _0x35a8e7=this['transaction'](_0x59fd58,_0x1d2834?'readwrite':'readonly');let _0x1b7c28=_0x35a8e7['store'];return _0xf09a8b&&(_0x1b7c28=_0x1b7c28['index'](_0x5235fa['shift']())),(await Promise['all']([_0x1b7c28[_0x4df12f](..._0x5235fa),_0x1d2834&&_0x35a8e7['done']]))[0x0];};return ei['set'](_0xa86c28,_0x13a41e),_0x13a41e;}Vc(_0xb2fa3=>({..._0xb2fa3,'get':(_0x3bec55,_0x1b653d,_0x5b2f36)=>Ls(_0x3bec55,_0x1b653d)||_0xb2fa3['get'](_0x3bec55,_0x1b653d,_0x5b2f36),'has':(_0x197141,_0xd302e9)=>!!Ls(_0x197141,_0xd302e9)||_0xb2fa3['has'](_0x197141,_0xd302e9)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x21ab7c){this['container']=_0x21ab7c;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0xe93937=>{if(Kc(_0xe93937)){const _0x190c48=_0xe93937['getImmediate']();return _0x190c48['library']+'/'+_0x190c48['version'];}else return null;})['filter'](_0x1a98a7=>_0x1a98a7)['join']('\x20');}}function Kc(_0xc566e0){const _0x3e18c3=_0xc566e0['getComponent']();return(_0x3e18c3==null?void 0x0:_0x3e18c3['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x5c24cb,_0x156f7b){try{_0x5c24cb['container']['addComponent'](_0x156f7b);}catch(_0x3e4c50){oe['debug']('Component\x20'+_0x156f7b['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x5c24cb['name'],_0x3e4c50);}}function Ze(_0x118111){const _0x4cfea5=_0x118111['name'];if(mi['has'](_0x4cfea5))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x4cfea5+'.'),!0x1;mi['set'](_0x4cfea5,_0x118111);for(const _0x3a6285 of xe['values']())Fs(_0x3a6285,_0x118111);for(const _0x4a4b86 of gi['values']())Fs(_0x4a4b86,_0x118111);return!0x0;}function Bi(_0x4525a3,_0x767d8a){const _0x5ca5ba=_0x4525a3['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x5ca5ba&&_0x5ca5ba['triggerHeartbeat'](),_0x4525a3['container']['getProvider'](_0x767d8a);}function $(_0x37d4ea){return _0x37d4ea==null?!0x1:_0x37d4ea['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x423ff5,_0x43d79b,_0x592e2a){this['_isDeleted']=!0x1,this['_options']={..._0x423ff5},this['_config']={..._0x43d79b},this['_name']=_0x43d79b['name'],this['_automaticDataCollectionEnabled']=_0x43d79b['automaticDataCollectionEnabled'],this['_container']=_0x592e2a,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x59ff7c){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x59ff7c;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x5c6251){this['_isDeleted']=_0x5c6251;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x53e2b5,_0x46855b={}){let _0x2a94f1=_0x53e2b5;typeof _0x46855b!='object'&&(_0x46855b={'name':_0x46855b});const _0x47ea41={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x46855b},_0x1f0e57=_0x47ea41['name'];if(typeof _0x1f0e57!='string'||!_0x1f0e57)throw ge['create']('bad-app-name',{'appName':String(_0x1f0e57)});if(_0x2a94f1||(_0x2a94f1=qr()),!_0x2a94f1)throw ge['create']('no-options');const _0x3daa1e=xe['get'](_0x1f0e57);if(_0x3daa1e){if(Me(_0x2a94f1,_0x3daa1e['options'])&&Me(_0x47ea41,_0x3daa1e['config']))return _0x3daa1e;throw ge['create']('duplicate-app',{'appName':_0x1f0e57});}const _0x488db9=new Pc(_0x1f0e57);for(const _0x2b362c of mi['values']())_0x488db9['addComponent'](_0x2b362c);const _0x3d7e90=new Tl(_0x2a94f1,_0x47ea41,_0x488db9);return xe['set'](_0x1f0e57,_0x3d7e90),_0x3d7e90;}function Zr(_0x41d09f=_i){const _0x566110=xe['get'](_0x41d09f);if(!_0x566110&&_0x41d09f===_i&&qr())return Sl();if(!_0x566110)throw ge['create']('no-app',{'appName':_0x41d09f});return _0x566110;}function f_(){return Array['from'](xe['values']());}async function p_(_0x224415){let _0x48c499=!0x1;const _0x3fbf95=_0x224415['name'];xe['has'](_0x3fbf95)?(_0x48c499=!0x0,xe['delete'](_0x3fbf95)):gi['has'](_0x3fbf95)&&_0x224415['decRefCount']()<=0x0&&(gi['delete'](_0x3fbf95),_0x48c499=!0x0),_0x48c499&&(await Promise['all'](_0x224415['container']['getProviders']()['map'](_0x4a8889=>_0x4a8889['delete']())),_0x224415['isDeleted']=!0x0);}function me(_0x48d09c,_0x3f2ab4,_0x34a30c){let _0x205b34=wl[_0x48d09c]??_0x48d09c;_0x34a30c&&(_0x205b34+='-'+_0x34a30c);const _0x415593=_0x205b34['match'](/\s|\//),_0x8d6e2b=_0x3f2ab4['match'](/\s|\//);if(_0x415593||_0x8d6e2b){const _0xd854b3=['Unable\x20to\x20register\x20library\x20\x22'+_0x205b34+'\x22\x20with\x20version\x20\x22'+_0x3f2ab4+'\x22:'];_0x415593&&_0xd854b3['push']('library\x20name\x20\x22'+_0x205b34+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x415593&&_0x8d6e2b&&_0xd854b3['push']('and'),_0x8d6e2b&&_0xd854b3['push']('version\x20name\x20\x22'+_0x3f2ab4+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0xd854b3['join']('\x20'));return;}Ze(new Le(_0x205b34+'-version',()=>({'library':_0x205b34,'version':_0x3f2ab4}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x1e542b,_0x38e6f1)=>{switch(_0x38e6f1){case 0x0:try{_0x1e542b['createObjectStore'](kt);}catch(_0x232641){console['warn'](_0x232641);}}}})['catch'](_0x2767af=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x2767af['message']});})),ti;}async function Al(_0x473e01){try{const _0x1e12cc=(await eo())['transaction'](kt),_0x5695c6=await _0x1e12cc['objectStore'](kt)['get'](to(_0x473e01));return await _0x1e12cc['done'],_0x5695c6;}catch(_0xe4444d){if(_0xe4444d instanceof Se)oe['warn'](_0xe4444d['message']);else{const _0x5a97c9=ge['create']('idb-get',{'originalErrorMessage':_0xe4444d==null?void 0x0:_0xe4444d['message']});oe['warn'](_0x5a97c9['message']);}}}async function Us(_0xccf897,_0x4b6f46){try{const _0x19cd81=(await eo())['transaction'](kt,'readwrite');await _0x19cd81['objectStore'](kt)['put'](_0x4b6f46,to(_0xccf897)),await _0x19cd81['done'];}catch(_0x4ef003){if(_0x4ef003 instanceof Se)oe['warn'](_0x4ef003['message']);else{const _0x462544=ge['create']('idb-set',{'originalErrorMessage':_0x4ef003==null?void 0x0:_0x4ef003['message']});oe['warn'](_0x462544['message']);}}}function to(_0x592341){return _0x592341['name']+'!'+_0x592341['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x56214a){this['container']=_0x56214a,this['_heartbeatsCache']=null;const _0x345f47=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x345f47),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x25682a=>(this['_heartbeatsCache']=_0x25682a,_0x25682a));}async['triggerHeartbeat'](){var _0x19e094,_0x26bef1;try{const _0x422e13=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x1dce7d=Ws();if(((_0x19e094=this['_heartbeatsCache'])==null?void 0x0:_0x19e094['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x26bef1=this['_heartbeatsCache'])==null?void 0x0:_0x26bef1['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x1dce7d||this['_heartbeatsCache']['heartbeats']['some'](_0x293a76=>_0x293a76['date']===_0x1dce7d))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x1dce7d,'agent':_0x422e13}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x5605d3=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x5605d3,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x3565dc){oe['warn'](_0x3565dc);}}async['getHeartbeatsHeader'](){var _0xf661aa;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0xf661aa=this['_heartbeatsCache'])==null?void 0x0:_0xf661aa['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x3da131=Ws(),{heartbeatsToSend:_0x401194,unsentEntries:_0x27c136}=Ol(this['_heartbeatsCache']['heartbeats']),_0x242284=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x401194}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x3da131,_0x27c136['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x27c136,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x242284;}catch(_0x35f005){return oe['warn'](_0x35f005),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x122868,_0x2055b2=kl){const _0x591047=[];let _0x2d295b=_0x122868['slice']();for(const _0x58325c of _0x122868){const _0x40ef24=_0x591047['find'](_0x3c42f0=>_0x3c42f0['agent']===_0x58325c['agent']);if(_0x40ef24){if(_0x40ef24['dates']['push'](_0x58325c['date']),Bs(_0x591047)>_0x2055b2){_0x40ef24['dates']['pop']();break;}}else{if(_0x591047['push']({'agent':_0x58325c['agent'],'dates':[_0x58325c['date']]}),Bs(_0x591047)>_0x2055b2){_0x591047['pop']();break;}}_0x2d295b=_0x2d295b['slice'](0x1);}return{'heartbeatsToSend':_0x591047,'unsentEntries':_0x2d295b};}class Dl{constructor(_0x35457b){this['app']=_0x35457b,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x19b21d=await Al(this['app']);return _0x19b21d!=null&&_0x19b21d['heartbeats']?_0x19b21d:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x2263aa){if(await this['_canUseIndexedDBPromise']){const _0x31f0b6=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x2263aa['lastSentHeartbeatDate']??_0x31f0b6['lastSentHeartbeatDate'],'heartbeats':_0x2263aa['heartbeats']});}else return;}async['add'](_0x51e29a){if(await this['_canUseIndexedDBPromise']){const _0x53614d=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x51e29a['lastSentHeartbeatDate']??_0x53614d['lastSentHeartbeatDate'],'heartbeats':[..._0x53614d['heartbeats'],..._0x51e29a['heartbeats']]});}else return;}}function Bs(_0x46fb55){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x46fb55}))['length'];}function Ml(_0x48951a){if(_0x48951a['length']===0x0)return-0x1;let _0x5d9a6=0x0,_0x316603=_0x48951a[0x0]['date'];for(let _0x1485c0=0x1;_0x1485c0<_0x48951a['length'];_0x1485c0++)_0x48951a[_0x1485c0]['date']<_0x316603&&(_0x316603=_0x48951a[_0x1485c0]['date'],_0x5d9a6=_0x1485c0);return _0x5d9a6;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x421a08){Ze(new Le('platform-logger',_0x358c33=>new jc(_0x358c33),'PRIVATE')),Ze(new Le('heartbeat',_0x454599=>new Pl(_0x454599),'PRIVATE')),me(pi,xs,_0x421a08),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x3a734b){no=_0x3a734b;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x4be442){this['domStorage_']=_0x4be442,this['prefix_']='firebase:';}['set'](_0x41b3e0,_0x1c35df){_0x1c35df==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x41b3e0)):this['domStorage_']['setItem'](this['prefixedName_'](_0x41b3e0),O(_0x1c35df));}['get'](_0x133b41){const _0x593314=this['domStorage_']['getItem'](this['prefixedName_'](_0x133b41));return _0x593314==null?null:At(_0x593314);}['remove'](_0x118046){this['domStorage_']['removeItem'](this['prefixedName_'](_0x118046));}['prefixedName_'](_0x57f441){return this['prefix_']+_0x57f441;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x29febe,_0x2e9bf0){_0x2e9bf0==null?delete this['cache_'][_0x29febe]:this['cache_'][_0x29febe]=_0x2e9bf0;}['get'](_0x3dbfd9){return J(this['cache_'],_0x3dbfd9)?this['cache_'][_0x3dbfd9]:null;}['remove'](_0x256b12){delete this['cache_'][_0x256b12];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x326cae){try{if(typeof window<'u'&&typeof window[_0x326cae]<'u'){const _0x4336db=window[_0x326cae];return _0x4336db['setItem']('firebase:sentinel','cache'),_0x4336db['removeItem']('firebase:sentinel'),new Wl(_0x4336db);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x4488b5=0x1;return function(){return _0x4488b5++;};}()),ro=function(_0x22e291){const _0x4f7e15=Rc(_0x22e291),_0xa5135d=new Cc();_0xa5135d['update'](_0x4f7e15);const _0x31023d=_0xa5135d['digest']();return Li['encodeByteArray'](_0x31023d);},Vt=function(..._0x374a6b){let _0x5431ac='';for(let _0x457bd8=0x0;_0x457bd8<_0x374a6b['length'];_0x457bd8++){const _0x416f18=_0x374a6b[_0x457bd8];Array['isArray'](_0x416f18)||_0x416f18&&typeof _0x416f18=='object'&&typeof _0x416f18['length']=='number'?_0x5431ac+=Vt['apply'](null,_0x416f18):typeof _0x416f18=='object'?_0x5431ac+=O(_0x416f18):_0x5431ac+=_0x416f18,_0x5431ac+='\x20';}return _0x5431ac;};let wt=null,Gs=!0x0;const Hl=function(_0x4430a0,_0x437972){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x4585d2){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x2b06f2=Vt['apply'](null,_0x4585d2);wt(_0x2b06f2);}},Ht=function(_0x38aa20){return function(..._0x4efe38){L(_0x38aa20,..._0x4efe38);};},yi=function(..._0x3a3e51){const _0x1ee0c4='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x3a3e51);Ye['error'](_0x1ee0c4);},ae=function(..._0x69d4cd){const _0x5a27b3='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x69d4cd);throw Ye['error'](_0x5a27b3),new Error(_0x5a27b3);},U=function(..._0x43ac94){const _0x1c597d='FIREBASE\x20WARNING:\x20'+Vt(..._0x43ac94);Ye['warn'](_0x1c597d);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x46e22c){return typeof _0x46e22c=='number'&&(_0x46e22c!==_0x46e22c||_0x46e22c===Number['POSITIVE_INFINITY']||_0x46e22c===Number['NEGATIVE_INFINITY']);},Gl=function(_0x3a2368){if(document['readyState']==='complete')_0x3a2368();else{let _0x490170=!0x1;const _0xcef221=function(){if(!document['body']){setTimeout(_0xcef221,Math['floor'](0xa));return;}_0x490170||(_0x490170=!0x0,_0x3a2368());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0xcef221,!0x1),window['addEventListener']('load',_0xcef221,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0xcef221();}),window['attachEvent']('onload',_0xcef221));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x1ed805,_0x174052){if(_0x1ed805===_0x174052)return 0x0;if(_0x1ed805===Fe||_0x174052===Ie)return-0x1;if(_0x174052===Fe||_0x1ed805===Ie)return 0x1;{const _0x5897ce=qs(_0x1ed805),_0x5db698=qs(_0x174052);return _0x5897ce!==null?_0x5db698!==null?_0x5897ce-_0x5db698===0x0?_0x1ed805['length']-_0x174052['length']:_0x5897ce-_0x5db698:-0x1:_0x5db698!==null?0x1:_0x1ed805<_0x174052?-0x1:0x1;}},ql=function(_0x7170a8,_0x54e929){return _0x7170a8===_0x54e929?0x0:_0x7170a8<_0x54e929?-0x1:0x1;},_t=function(_0x2084e4,_0x1f05ec){if(_0x1f05ec&&_0x2084e4 in _0x1f05ec)return _0x1f05ec[_0x2084e4];throw new Error('Missing\x20required\x20key\x20('+_0x2084e4+')\x20in\x20object:\x20'+O(_0x1f05ec));},Hi=function(_0x970399){if(typeof _0x970399!='object'||_0x970399===null)return O(_0x970399);const _0x3a77c6=[];for(const _0x3395e9 in _0x970399)_0x3a77c6['push'](_0x3395e9);_0x3a77c6['sort']();let _0x4e2d22='{';for(let _0x55a3e8=0x0;_0x55a3e8<_0x3a77c6['length'];_0x55a3e8++)_0x55a3e8!==0x0&&(_0x4e2d22+=','),_0x4e2d22+=O(_0x3a77c6[_0x55a3e8]),_0x4e2d22+=':',_0x4e2d22+=Hi(_0x970399[_0x3a77c6[_0x55a3e8]]);return _0x4e2d22+='}',_0x4e2d22;},oo=function(_0x4bb5dc,_0x900608){const _0x1851f4=_0x4bb5dc['length'];if(_0x1851f4<=_0x900608)return[_0x4bb5dc];const _0x19f7fe=[];for(let _0x4c770b=0x0;_0x4c770b<_0x1851f4;_0x4c770b+=_0x900608)_0x4c770b+_0x900608>_0x1851f4?_0x19f7fe['push'](_0x4bb5dc['substring'](_0x4c770b,_0x1851f4)):_0x19f7fe['push'](_0x4bb5dc['substring'](_0x4c770b,_0x4c770b+_0x900608));return _0x19f7fe;};function x(_0x260dc2,_0x12c8ab){for(const _0x271a24 in _0x260dc2)_0x260dc2['hasOwnProperty'](_0x271a24)&&_0x12c8ab(_0x271a24,_0x260dc2[_0x271a24]);}const ao=function(_0xfa2c72){f(!Vi(_0xfa2c72),'Invalid\x20JSON\x20number');const _0x1658d6=0xb,_0x4103d1=0x34,_0x3316ef=(0x1<<_0x1658d6-0x1)-0x1;let _0x22c918,_0x51a2e6,_0x4e13d3,_0x3d58ec,_0x1ba488;_0xfa2c72===0x0?(_0x51a2e6=0x0,_0x4e13d3=0x0,_0x22c918=0x1/_0xfa2c72===-0x1/0x0?0x1:0x0):(_0x22c918=_0xfa2c72<0x0,_0xfa2c72=Math['abs'](_0xfa2c72),_0xfa2c72>=Math['pow'](0x2,0x1-_0x3316ef)?(_0x3d58ec=Math['min'](Math['floor'](Math['log'](_0xfa2c72)/Math['LN2']),_0x3316ef),_0x51a2e6=_0x3d58ec+_0x3316ef,_0x4e13d3=Math['round'](_0xfa2c72*Math['pow'](0x2,_0x4103d1-_0x3d58ec)-Math['pow'](0x2,_0x4103d1))):(_0x51a2e6=0x0,_0x4e13d3=Math['round'](_0xfa2c72/Math['pow'](0x2,0x1-_0x3316ef-_0x4103d1))));const _0x327d81=[];for(_0x1ba488=_0x4103d1;_0x1ba488;_0x1ba488-=0x1)_0x327d81['push'](_0x4e13d3%0x2?0x1:0x0),_0x4e13d3=Math['floor'](_0x4e13d3/0x2);for(_0x1ba488=_0x1658d6;_0x1ba488;_0x1ba488-=0x1)_0x327d81['push'](_0x51a2e6%0x2?0x1:0x0),_0x51a2e6=Math['floor'](_0x51a2e6/0x2);_0x327d81['push'](_0x22c918?0x1:0x0),_0x327d81['reverse']();const _0x456727=_0x327d81['join']('');let _0x4cba23='';for(_0x1ba488=0x0;_0x1ba488<0x40;_0x1ba488+=0x8){let _0x5050f3=parseInt(_0x456727['substr'](_0x1ba488,0x8),0x2)['toString'](0x10);_0x5050f3['length']===0x1&&(_0x5050f3='0'+_0x5050f3),_0x4cba23=_0x4cba23+_0x5050f3;}return _0x4cba23['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x59d862,_0x354552){let _0x5bba24='Unknown\x20Error';_0x59d862==='too_big'?_0x5bba24='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x59d862==='permission_denied'?_0x5bba24='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x59d862==='unavailable'&&(_0x5bba24='The\x20service\x20is\x20unavailable');const _0x296e3d=new Error(_0x59d862+'\x20at\x20'+_0x354552['_path']['toString']()+':\x20'+_0x5bba24);return _0x296e3d['code']=_0x59d862['toUpperCase'](),_0x296e3d;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x195894){if(Yl['test'](_0x195894)){const _0x23b6ba=Number(_0x195894);if(_0x23b6ba>=Ql&&_0x23b6ba<=Jl)return _0x23b6ba;}return null;},ht=function(_0x366c66){try{_0x366c66();}catch(_0x4fb062){setTimeout(()=>{const _0x1911b1=_0x4fb062['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x1911b1),_0x4fb062;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x5a9159,_0x242d30){const _0x426042=setTimeout(_0x5a9159,_0x242d30);return typeof _0x426042=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x426042):typeof _0x426042=='object'&&_0x426042['unref']&&_0x426042['unref'](),_0x426042;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x20a30d,_0x2d2df9){this['appCheckProvider']=_0x2d2df9,this['appName']=_0x20a30d['name'],$(_0x20a30d)&&_0x20a30d['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x20a30d['settings']['appCheckToken']),this['appCheck']=_0x2d2df9==null?void 0x0:_0x2d2df9['getImmediate']({'optional':!0x0}),this['appCheck']||_0x2d2df9==null||_0x2d2df9['get']()['then'](_0x6fbaed=>this['appCheck']=_0x6fbaed);}['getToken'](_0x345e37){if(this['serverAppAppCheckToken']){if(_0x345e37)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x345e37):new Promise((_0x5cc052,_0x456406)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x345e37)['then'](_0x5cc052,_0x456406):_0x5cc052(null);},0x0);});}['addTokenChangeListener'](_0x2aa45f){var _0x4448d5;(_0x4448d5=this['appCheckProvider'])==null||_0x4448d5['get']()['then'](_0x4d8c91=>_0x4d8c91['addTokenListener'](_0x2aa45f));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x3ea06c,_0x327d54,_0x28114c){this['appName_']=_0x3ea06c,this['firebaseOptions_']=_0x327d54,this['authProvider_']=_0x28114c,this['auth_']=null,this['auth_']=_0x28114c['getImmediate']({'optional':!0x0}),this['auth_']||_0x28114c['onInit'](_0x4b01f3=>this['auth_']=_0x4b01f3);}['getToken'](_0x152622){return this['auth_']?this['auth_']['getToken'](_0x152622)['catch'](_0x1a92e1=>_0x1a92e1&&_0x1a92e1['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x1a92e1)):new Promise((_0x54c432,_0x52b5ec)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x152622)['then'](_0x54c432,_0x52b5ec):_0x54c432(null);},0x0);});}['addTokenChangeListener'](_0xc1cae){this['auth_']?this['auth_']['addAuthTokenListener'](_0xc1cae):this['authProvider_']['get']()['then'](_0xc15436=>_0xc15436['addAuthTokenListener'](_0xc1cae));}['removeTokenChangeListener'](_0x1d7b5c){this['authProvider_']['get']()['then'](_0x3173d7=>_0x3173d7['removeAuthTokenListener'](_0x1d7b5c));}['notifyForInvalidToken'](){let _0x7d94c9='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x7d94c9+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x7d94c9+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x7d94c9+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x7d94c9);}}class nn{constructor(_0x27ec46){this['accessToken']=_0x27ec46;}['getToken'](_0x54062b){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x57dac2){_0x57dac2(this['accessToken']);}['removeTokenChangeListener'](_0x5663b9){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x1407a4,_0x3ac884,_0x59953a,_0x44f3c1,_0x1d37dd=!0x1,_0x291f6e='',_0x3dbd3d=!0x1,_0x25c5cb=!0x1,_0x4587dc=null){this['secure']=_0x3ac884,this['namespace']=_0x59953a,this['webSocketOnly']=_0x44f3c1,this['nodeAdmin']=_0x1d37dd,this['persistenceKey']=_0x291f6e,this['includeNamespaceInQueryParams']=_0x3dbd3d,this['isUsingEmulator']=_0x25c5cb,this['emulatorOptions']=_0x4587dc,this['_host']=_0x1407a4['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x1407a4)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x37f38b){_0x37f38b!==this['internalHost']&&(this['internalHost']=_0x37f38b,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x210a8c=this['toURLString']();return this['persistenceKey']&&(_0x210a8c+='<'+this['persistenceKey']+'>'),_0x210a8c;}['toURLString'](){const _0x89a079=this['secure']?'https://':'http://',_0x53d702=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x89a079+this['host']+'/'+_0x53d702;}}function th(_0x46e0ce){return _0x46e0ce['host']!==_0x46e0ce['internalHost']||_0x46e0ce['isCustomHost']()||_0x46e0ce['includeNamespaceInQueryParams'];}function vo(_0x470ed6,_0x46cf00,_0x2a7970){f(typeof _0x46cf00=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x2a7970=='object','typeof\x20params\x20must\x20==\x20object');let _0x4dbafb;if(_0x46cf00===go)_0x4dbafb=(_0x470ed6['secure']?'wss://':'ws://')+_0x470ed6['internalHost']+'/.ws?';else{if(_0x46cf00===mo)_0x4dbafb=(_0x470ed6['secure']?'https://':'http://')+_0x470ed6['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x46cf00);}th(_0x470ed6)&&(_0x2a7970['ns']=_0x470ed6['namespace']);const _0xd1a72f=[];return x(_0x2a7970,(_0x3a891c,_0x175825)=>{_0xd1a72f['push'](_0x3a891c+'='+_0x175825);}),_0x4dbafb+_0xd1a72f['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0xcd88b2,_0x52207a=0x1){J(this['counters_'],_0xcd88b2)||(this['counters_'][_0xcd88b2]=0x0),this['counters_'][_0xcd88b2]+=_0x52207a;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0xa266c4){const _0x599ae5=_0xa266c4['toString']();return ni[_0x599ae5]||(ni[_0x599ae5]=new nh()),ni[_0x599ae5];}function ih(_0x18e02e,_0x20ab8a){const _0x449651=_0x18e02e['toString']();return ii[_0x449651]||(ii[_0x449651]=_0x20ab8a()),ii[_0x449651];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x3beed3){this['onMessage_']=_0x3beed3,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x56a335,_0x5b8075){this['closeAfterResponse']=_0x56a335,this['onClose']=_0x5b8075,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0xb5fcc6,_0x5a73f9){for(this['pendingResponses'][_0xb5fcc6]=_0x5a73f9;this['pendingResponses'][this['currentResponseNum']];){const _0x440c5f=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x5f15e1=0x0;_0x5f15e1<_0x440c5f['length'];++_0x5f15e1)_0x440c5f[_0x5f15e1]&&ht(()=>{this['onMessage_'](_0x440c5f[_0x5f15e1]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x398330,_0x1b4019,_0x59c483,_0x43d2f2,_0x2fcb55,_0x524a72,_0x38dd50){this['connId']=_0x398330,this['repoInfo']=_0x1b4019,this['applicationId']=_0x59c483,this['appCheckToken']=_0x43d2f2,this['authToken']=_0x2fcb55,this['transportSessionId']=_0x524a72,this['lastSessionId']=_0x38dd50,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x398330),this['stats_']=Gi(_0x1b4019),this['urlFn']=_0x52fb51=>(this['appCheckToken']&&(_0x52fb51[vi]=this['appCheckToken']),vo(_0x1b4019,mo,_0x52fb51));}['open'](_0x1b4189,_0x386d19){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x386d19,this['myPacketOrderer']=new sh(_0x1b4189),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x288c7e)=>{const [_0x814cbe,_0xc41fe6,_0x503656,_0x382b26,_0x3dd822]=_0x288c7e;if(this['incrementIncomingBytes_'](_0x288c7e),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x814cbe===zs)this['id']=_0xc41fe6,this['password']=_0x503656;else{if(_0x814cbe===rh)_0xc41fe6?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0xc41fe6,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x814cbe);}}},(..._0x41a2dc)=>{const [_0x2eed5f,_0x1240ae]=_0x41a2dc;this['incrementIncomingBytes_'](_0x41a2dc),this['myPacketOrderer']['handleResponse'](_0x2eed5f,_0x1240ae);},()=>{this['onClosed_']();},this['urlFn']);const _0x2af52a={};_0x2af52a[zs]='t',_0x2af52a[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x2af52a[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x2af52a[co]=$i,this['transportSessionId']&&(_0x2af52a[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x2af52a[po]=this['lastSessionId']),this['applicationId']&&(_0x2af52a[_o]=this['applicationId']),this['appCheckToken']&&(_0x2af52a[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x2af52a[ho]=uo);const _0x4d8c17=this['urlFn'](_0x2af52a);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4d8c17),this['scriptTagHolder']['addTag'](_0x4d8c17,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x4d7f9a){const _0x19ad31=O(_0x4d7f9a);this['bytesSent']+=_0x19ad31['length'],this['stats_']['incrementCounter']('bytes_sent',_0x19ad31['length']);const _0x8015a5=Hr(_0x19ad31),_0x5ea8d1=oo(_0x8015a5,fh);for(let _0x8d9c97=0x0;_0x8d9c97<_0x5ea8d1['length'];_0x8d9c97++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x5ea8d1['length'],_0x5ea8d1[_0x8d9c97]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x43eb17,_0x248235){this['myDisconnFrame']=document['createElement']('iframe');const _0x5a4c19={};_0x5a4c19[dh]='t',_0x5a4c19[Eo]=_0x43eb17,_0x5a4c19[Io]=_0x248235,this['myDisconnFrame']['src']=this['urlFn'](_0x5a4c19),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x5dcfb0){const _0x2712a8=O(_0x5dcfb0)['length'];this['bytesReceived']+=_0x2712a8,this['stats_']['incrementCounter']('bytes_received',_0x2712a8);}}class qi{constructor(_0x432a5c,_0x11a438,_0xd2b58b,_0x175d42){this['onDisconnect']=_0xd2b58b,this['urlFn']=_0x175d42,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x432a5c,window[ah+this['uniqueCallbackIdentifier']]=_0x11a438,this['myIFrame']=qi['createIFrame_']();let _0x4801ae='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x4801ae='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0xed48a2='<html><body>'+_0x4801ae+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0xed48a2),this['myIFrame']['doc']['close']();}catch(_0x4a0590){L('frame\x20writing\x20exception'),_0x4a0590['stack']&&L(_0x4a0590['stack']),L(_0x4a0590);}}}static['createIFrame_'](){const _0x4bc96a=document['createElement']('iframe');if(_0x4bc96a['style']['display']='none',document['body']){document['body']['appendChild'](_0x4bc96a);try{_0x4bc96a['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x4d3558=document['domain'];_0x4bc96a['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x4d3558+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x4bc96a['contentDocument']?_0x4bc96a['doc']=_0x4bc96a['contentDocument']:_0x4bc96a['contentWindow']?_0x4bc96a['doc']=_0x4bc96a['contentWindow']['document']:_0x4bc96a['document']&&(_0x4bc96a['doc']=_0x4bc96a['document']),_0x4bc96a;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x1052ca=this['onDisconnect'];_0x1052ca&&(this['onDisconnect']=null,_0x1052ca());}['startLongPoll'](_0x625ef,_0x1536cd){for(this['myID']=_0x625ef,this['myPW']=_0x1536cd,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x3cd45a={};_0x3cd45a[Eo]=this['myID'],_0x3cd45a[Io]=this['myPW'],_0x3cd45a[wo]=this['currentSerial'];let _0x12ab2f=this['urlFn'](_0x3cd45a),_0x591990='',_0x1fae79=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x591990['length']<=Co;){const _0x220484=this['pendingSegs']['shift']();_0x591990=_0x591990+'&'+lh+_0x1fae79+'='+_0x220484['seg']+'&'+hh+_0x1fae79+'='+_0x220484['ts']+'&'+uh+_0x1fae79+'='+_0x220484['d'],_0x1fae79++;}return _0x12ab2f=_0x12ab2f+_0x591990,this['addLongPollTag_'](_0x12ab2f,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x31fd2f,_0x4f45f4,_0x30bebc){this['pendingSegs']['push']({'seg':_0x31fd2f,'ts':_0x4f45f4,'d':_0x30bebc}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0xd5992,_0x276d67){this['outstandingRequests']['add'](_0x276d67);const _0x34be19=()=>{this['outstandingRequests']['delete'](_0x276d67),this['newRequest_']();},_0x3cce08=setTimeout(_0x34be19,Math['floor'](ph)),_0x1b4a97=()=>{clearTimeout(_0x3cce08),_0x34be19();};this['addTag'](_0xd5992,_0x1b4a97);}['addTag'](_0x53e7d1,_0x451673){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x314805=this['myIFrame']['doc']['createElement']('script');_0x314805['type']='text/javascript',_0x314805['async']=!0x0,_0x314805['src']=_0x53e7d1,_0x314805['onload']=_0x314805['onreadystatechange']=function(){const _0x379dda=_0x314805['readyState'];(!_0x379dda||_0x379dda==='loaded'||_0x379dda==='complete')&&(_0x314805['onload']=_0x314805['onreadystatechange']=null,_0x314805['parentNode']&&_0x314805['parentNode']['removeChild'](_0x314805),_0x451673());},_0x314805['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x53e7d1),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x314805);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x1188a6,_0xf785f1,_0x3d7b9b,_0x486a5c,_0x4e9700,_0x531e44,_0x4aa729){this['connId']=_0x1188a6,this['applicationId']=_0x3d7b9b,this['appCheckToken']=_0x486a5c,this['authToken']=_0x4e9700,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0xf785f1),this['connURL']=z['connectionURL_'](_0xf785f1,_0x531e44,_0x4aa729,_0x486a5c,_0x3d7b9b),this['nodeAdmin']=_0xf785f1['nodeAdmin'];}static['connectionURL_'](_0x9572fa,_0x142013,_0x564d8b,_0x25c797,_0x4b2645){const _0x4745d2={};return _0x4745d2[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x4745d2[ho]=uo),_0x142013&&(_0x4745d2[lo]=_0x142013),_0x564d8b&&(_0x4745d2[po]=_0x564d8b),_0x25c797&&(_0x4745d2[vi]=_0x25c797),_0x4b2645&&(_0x4745d2[_o]=_0x4b2645),vo(_0x9572fa,go,_0x4745d2);}['open'](_0x5dc38b,_0x89263){this['onDisconnect']=_0x89263,this['onMessage']=_0x5dc38b,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x5ac20a;_c(),this['mySock']=new un(this['connURL'],[],_0x5ac20a);}catch(_0x2a13c4){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x1cb31a=_0x2a13c4['message']||_0x2a13c4['data'];_0x1cb31a&&this['log_'](_0x1cb31a),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x54ac7c=>{this['handleIncomingFrame'](_0x54ac7c);},this['mySock']['onerror']=_0x487b2=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x9e4d7f=_0x487b2['message']||_0x487b2['data'];_0x9e4d7f&&this['log_'](_0x9e4d7f),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x18e9bd=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x17bf46=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x3734ca=navigator['userAgent']['match'](_0x17bf46);_0x3734ca&&_0x3734ca['length']>0x1&&parseFloat(_0x3734ca[0x1])<4.4&&(_0x18e9bd=!0x0);}return!_0x18e9bd&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x281ec4){if(this['frames']['push'](_0x281ec4),this['frames']['length']===this['totalFrames']){const _0xae20a3=this['frames']['join']('');this['frames']=null;const _0x66204f=At(_0xae20a3);this['onMessage'](_0x66204f);}}['handleNewFrameCount_'](_0x5cb155){this['totalFrames']=_0x5cb155,this['frames']=[];}['extractFrameCount_'](_0x11e8aa){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x11e8aa['length']<=0x6){const _0x2601c6=Number(_0x11e8aa);if(!isNaN(_0x2601c6))return this['handleNewFrameCount_'](_0x2601c6),null;}return this['handleNewFrameCount_'](0x1),_0x11e8aa;}['handleIncomingFrame'](_0x5c47ed){if(this['mySock']===null)return;const _0x7f097=_0x5c47ed['data'];if(this['bytesReceived']+=_0x7f097['length'],this['stats_']['incrementCounter']('bytes_received',_0x7f097['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x7f097);else{const _0x401745=this['extractFrameCount_'](_0x7f097);_0x401745!==null&&this['appendFrame_'](_0x401745);}}['send'](_0x5cdca7){this['resetKeepAlive']();const _0x178004=O(_0x5cdca7);this['bytesSent']+=_0x178004['length'],this['stats_']['incrementCounter']('bytes_sent',_0x178004['length']);const _0x1eb118=oo(_0x178004,gh);_0x1eb118['length']>0x1&&this['sendString_'](String(_0x1eb118['length']));for(let _0x2acd5a=0x0;_0x2acd5a<_0x1eb118['length'];_0x2acd5a++)this['sendString_'](_0x1eb118[_0x2acd5a]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x596352){try{this['mySock']['send'](_0x596352);}catch(_0x22a2e3){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x22a2e3['message']||_0x22a2e3['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x59aeb5){this['initTransports_'](_0x59aeb5);}['initTransports_'](_0x5b950e){const _0x23d6d8=z&&z['isAvailable']();let _0x2c0e45=_0x23d6d8&&!z['previouslyFailed']();if(_0x5b950e['webSocketOnly']&&(_0x23d6d8||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x2c0e45=!0x0),_0x2c0e45)this['transports_']=[z];else{const _0x482726=this['transports_']=[];for(const _0x226339 of Nt['ALL_TRANSPORTS'])_0x226339&&_0x226339['isAvailable']()&&_0x482726['push'](_0x226339);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x932040,_0x6b710d,_0x732b5c,_0x49321f,_0x1d7e3a,_0x1bcda8,_0x2a9140,_0x40e738,_0x3297e8,_0x2fe32d){this['id']=_0x932040,this['repoInfo_']=_0x6b710d,this['applicationId_']=_0x732b5c,this['appCheckToken_']=_0x49321f,this['authToken_']=_0x1d7e3a,this['onMessage_']=_0x1bcda8,this['onReady_']=_0x2a9140,this['onDisconnect_']=_0x40e738,this['onKill_']=_0x3297e8,this['lastSessionId']=_0x2fe32d,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x6b710d),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x53876a=this['transportManager_']['initialTransport']();this['conn_']=new _0x53876a(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x53876a['responsesRequiredToBeHealthy']||0x0;const _0x34bd4e=this['connReceiver_'](this['conn_']),_0x465616=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x34bd4e,_0x465616);},Math['floor'](0x0));const _0x3f1d23=_0x53876a['healthyTimeout']||0x0;_0x3f1d23>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x3f1d23)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x56e336){return _0x4de7cc=>{_0x56e336===this['conn_']?this['onConnectionLost_'](_0x4de7cc):_0x56e336===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x4e3a5d){return _0xad97ef=>{this['state_']!==0x2&&(_0x4e3a5d===this['rx_']?this['onPrimaryMessageReceived_'](_0xad97ef):_0x4e3a5d===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0xad97ef):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x1d099a){const _0x3b5efa={'t':'d','d':_0x1d099a};this['sendData_'](_0x3b5efa);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x3e1485){if(si in _0x3e1485){const _0x58fd43=_0x3e1485[si];_0x58fd43===Qs?this['upgradeIfSecondaryHealthy_']():_0x58fd43===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x58fd43===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x49fe36){const _0x5da85a=_t('t',_0x49fe36),_0x464437=_t('d',_0x49fe36);if(_0x5da85a==='c')this['onSecondaryControl_'](_0x464437);else{if(_0x5da85a==='d')this['pendingDataMessages']['push'](_0x464437);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x5da85a);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0xc45787){const _0x198de5=_t('t',_0xc45787),_0xd816df=_t('d',_0xc45787);_0x198de5==='c'?this['onControl_'](_0xd816df):_0x198de5==='d'&&this['onDataMessage_'](_0xd816df);}['onDataMessage_'](_0x31cd1e){this['onPrimaryResponse_'](),this['onMessage_'](_0x31cd1e);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x2a3f17){const _0x14599d=_t(si,_0x2a3f17);if(js in _0x2a3f17){const _0x28b788=_0x2a3f17[js];if(_0x14599d===Th){const _0x421839={..._0x28b788};this['repoInfo_']['isUsingEmulator']&&(_0x421839['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x421839);}else{if(_0x14599d===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x202a1e=0x0;_0x202a1e<this['pendingDataMessages']['length'];++_0x202a1e)this['onDataMessage_'](this['pendingDataMessages'][_0x202a1e]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x14599d===wh?this['onConnectionShutdown_'](_0x28b788):_0x14599d===Ks?this['onReset_'](_0x28b788):_0x14599d===Ch?yi('Server\x20Error:\x20'+_0x28b788):_0x14599d===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x14599d);}}}['onHandshake_'](_0xaf08b9){const _0x153e77=_0xaf08b9['ts'],_0x277f30=_0xaf08b9['v'],_0x1d239f=_0xaf08b9['h'];this['sessionId']=_0xaf08b9['s'],this['repoInfo_']['host']=_0x1d239f,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x153e77),$i!==_0x277f30&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x958aa0=this['transportManager_']['upgradeTransport']();_0x958aa0&&this['startUpgrade_'](_0x958aa0);}['startUpgrade_'](_0x598b9b){this['secondaryConn_']=new _0x598b9b(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x598b9b['responsesRequiredToBeHealthy']||0x0;const _0x4b60a5=this['connReceiver_'](this['secondaryConn_']),_0x3436d8=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x4b60a5,_0x3436d8),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x5b4df1){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x5b4df1),this['repoInfo_']['host']=_0x5b4df1,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x4c141f,_0x346d27){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x4c141f,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x346d27,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x5be6a3=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x5be6a3||this['rx_']===_0x5be6a3)&&this['close']();}['onConnectionLost_'](_0x3d29be){this['conn_']=null,!_0x3d29be&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x3d6c1a){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x3d6c1a),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x4bcdc2){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x4bcdc2);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x2ff1e7,_0x565a3c,_0x271d4c,_0x30dc2f){}['merge'](_0x4d5caf,_0x2474c0,_0x558413,_0x5841b5){}['refreshAuthToken'](_0x208afe){}['refreshAppCheckToken'](_0x3ba79a){}['onDisconnectPut'](_0x11e3a5,_0x20866e,_0x4fe332){}['onDisconnectMerge'](_0x4395c5,_0x383e34,_0x3c242d){}['onDisconnectCancel'](_0xf3d227,_0x55b57e){}['reportStats'](_0x2c1029){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x3a6e53){this['allowedEvents_']=_0x3a6e53,this['listeners_']={},f(Array['isArray'](_0x3a6e53)&&_0x3a6e53['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x19cae1,..._0x4c9a81){if(Array['isArray'](this['listeners_'][_0x19cae1])){const _0x344ec0=[...this['listeners_'][_0x19cae1]];for(let _0x571247=0x0;_0x571247<_0x344ec0['length'];_0x571247++)_0x344ec0[_0x571247]['callback']['apply'](_0x344ec0[_0x571247]['context'],_0x4c9a81);}}['on'](_0x1dd7c7,_0x38c575,_0x7b590e){this['validateEventType_'](_0x1dd7c7),this['listeners_'][_0x1dd7c7]=this['listeners_'][_0x1dd7c7]||[],this['listeners_'][_0x1dd7c7]['push']({'callback':_0x38c575,'context':_0x7b590e});const _0x58f798=this['getInitialEvent'](_0x1dd7c7);_0x58f798&&_0x38c575['apply'](_0x7b590e,_0x58f798);}['off'](_0x225dae,_0x25ee8d,_0x23f61d){this['validateEventType_'](_0x225dae);const _0x4a18d8=this['listeners_'][_0x225dae]||[];for(let _0x356889=0x0;_0x356889<_0x4a18d8['length'];_0x356889++)if(_0x4a18d8[_0x356889]['callback']===_0x25ee8d&&(!_0x23f61d||_0x23f61d===_0x4a18d8[_0x356889]['context'])){_0x4a18d8['splice'](_0x356889,0x1);return;}}['validateEventType_'](_0x2282b5){f(this['allowedEvents_']['find'](_0x23c014=>_0x23c014===_0x2282b5),'Unknown\x20event:\x20'+_0x2282b5);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x201d8f){return f(_0x201d8f==='online','Unknown\x20event\x20type:\x20'+_0x201d8f),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x326c68,_0x457760){if(_0x457760===void 0x0){this['pieces_']=_0x326c68['split']('/');let _0x5e4aff=0x0;for(let _0x54969a=0x0;_0x54969a<this['pieces_']['length'];_0x54969a++)this['pieces_'][_0x54969a]['length']>0x0&&(this['pieces_'][_0x5e4aff]=this['pieces_'][_0x54969a],_0x5e4aff++);this['pieces_']['length']=_0x5e4aff,this['pieceNum_']=0x0;}else this['pieces_']=_0x326c68,this['pieceNum_']=_0x457760;}['toString'](){let _0x4f0a82='';for(let _0x3ef26e=this['pieceNum_'];_0x3ef26e<this['pieces_']['length'];_0x3ef26e++)this['pieces_'][_0x3ef26e]!==''&&(_0x4f0a82+='/'+this['pieces_'][_0x3ef26e]);return _0x4f0a82||'/';}}function w(){return new C('');}function y(_0x5ead68){return _0x5ead68['pieceNum_']>=_0x5ead68['pieces_']['length']?null:_0x5ead68['pieces_'][_0x5ead68['pieceNum_']];}function we(_0x5e0b97){return _0x5e0b97['pieces_']['length']-_0x5e0b97['pieceNum_'];}function b(_0x117c88){let _0x344e2b=_0x117c88['pieceNum_'];return _0x344e2b<_0x117c88['pieces_']['length']&&_0x344e2b++,new C(_0x117c88['pieces_'],_0x344e2b);}function zi(_0x284eba){return _0x284eba['pieceNum_']<_0x284eba['pieces_']['length']?_0x284eba['pieces_'][_0x284eba['pieces_']['length']-0x1]:null;}function bh(_0x29c1ee){let _0x214bf9='';for(let _0x5885d4=_0x29c1ee['pieceNum_'];_0x5885d4<_0x29c1ee['pieces_']['length'];_0x5885d4++)_0x29c1ee['pieces_'][_0x5885d4]!==''&&(_0x214bf9+='/'+encodeURIComponent(String(_0x29c1ee['pieces_'][_0x5885d4])));return _0x214bf9||'/';}function Pt(_0x11cc2f,_0x3d31b3=0x0){return _0x11cc2f['pieces_']['slice'](_0x11cc2f['pieceNum_']+_0x3d31b3);}function Ro(_0xa190c9){if(_0xa190c9['pieceNum_']>=_0xa190c9['pieces_']['length'])return null;const _0x3127af=[];for(let _0xf15933=_0xa190c9['pieceNum_'];_0xf15933<_0xa190c9['pieces_']['length']-0x1;_0xf15933++)_0x3127af['push'](_0xa190c9['pieces_'][_0xf15933]);return new C(_0x3127af,0x0);}function k(_0x50b533,_0x31e70a){const _0x3a0e79=[];for(let _0x3f3f58=_0x50b533['pieceNum_'];_0x3f3f58<_0x50b533['pieces_']['length'];_0x3f3f58++)_0x3a0e79['push'](_0x50b533['pieces_'][_0x3f3f58]);if(_0x31e70a instanceof C){for(let _0x19a96d=_0x31e70a['pieceNum_'];_0x19a96d<_0x31e70a['pieces_']['length'];_0x19a96d++)_0x3a0e79['push'](_0x31e70a['pieces_'][_0x19a96d]);}else{const _0x1cce29=_0x31e70a['split']('/');for(let _0x2f0c5a=0x0;_0x2f0c5a<_0x1cce29['length'];_0x2f0c5a++)_0x1cce29[_0x2f0c5a]['length']>0x0&&_0x3a0e79['push'](_0x1cce29[_0x2f0c5a]);}return new C(_0x3a0e79,0x0);}function v(_0x3a6344){return _0x3a6344['pieceNum_']>=_0x3a6344['pieces_']['length'];}function F(_0xacd4d,_0x295b18){const _0x3dcfd4=y(_0xacd4d),_0x2bd8da=y(_0x295b18);if(_0x3dcfd4===null)return _0x295b18;if(_0x3dcfd4===_0x2bd8da)return F(b(_0xacd4d),b(_0x295b18));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x295b18+')\x20is\x20not\x20within\x20outerPath\x20('+_0xacd4d+')');}function Rh(_0x3cebea,_0x17cab0){const _0x36427b=Pt(_0x3cebea,0x0),_0x21d7c6=Pt(_0x17cab0,0x0);for(let _0x119d26=0x0;_0x119d26<_0x36427b['length']&&_0x119d26<_0x21d7c6['length'];_0x119d26++){const _0x516deb=He(_0x36427b[_0x119d26],_0x21d7c6[_0x119d26]);if(_0x516deb!==0x0)return _0x516deb;}return _0x36427b['length']===_0x21d7c6['length']?0x0:_0x36427b['length']<_0x21d7c6['length']?-0x1:0x1;}function ji(_0x7d7e80,_0x1782d9){if(we(_0x7d7e80)!==we(_0x1782d9))return!0x1;for(let _0x2609d0=_0x7d7e80['pieceNum_'],_0x159059=_0x1782d9['pieceNum_'];_0x2609d0<=_0x7d7e80['pieces_']['length'];_0x2609d0++,_0x159059++)if(_0x7d7e80['pieces_'][_0x2609d0]!==_0x1782d9['pieces_'][_0x159059])return!0x1;return!0x0;}function G(_0x130a02,_0x5223df){let _0xd08b48=_0x130a02['pieceNum_'],_0x1a0595=_0x5223df['pieceNum_'];if(we(_0x130a02)>we(_0x5223df))return!0x1;for(;_0xd08b48<_0x130a02['pieces_']['length'];){if(_0x130a02['pieces_'][_0xd08b48]!==_0x5223df['pieces_'][_0x1a0595])return!0x1;++_0xd08b48,++_0x1a0595;}return!0x0;}class Ah{constructor(_0x2367b1,_0x5d7929){this['errorPrefix_']=_0x5d7929,this['parts_']=Pt(_0x2367b1,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x719be2=0x0;_0x719be2<this['parts_']['length'];_0x719be2++)this['byteLength_']+=On(this['parts_'][_0x719be2]);Ao(this);}}function kh(_0x225c80,_0x5aaf8b){_0x225c80['parts_']['length']>0x0&&(_0x225c80['byteLength_']+=0x1),_0x225c80['parts_']['push'](_0x5aaf8b),_0x225c80['byteLength_']+=On(_0x5aaf8b),Ao(_0x225c80);}function Nh(_0x3ddf90){const _0x1ac43e=_0x3ddf90['parts_']['pop']();_0x3ddf90['byteLength_']-=On(_0x1ac43e),_0x3ddf90['parts_']['length']>0x0&&(_0x3ddf90['byteLength_']-=0x1);}function Ao(_0x3849ac){if(_0x3849ac['byteLength_']>er)throw new Error(_0x3849ac['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x3849ac['byteLength_']+').');if(_0x3849ac['parts_']['length']>Zs)throw new Error(_0x3849ac['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x3849ac));}function Pe(_0x4c0ed8){return _0x4c0ed8['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x4c0ed8['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x13a696,_0x227f96;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x227f96='visibilitychange',_0x13a696='hidden'):typeof document['mozHidden']<'u'?(_0x227f96='mozvisibilitychange',_0x13a696='mozHidden'):typeof document['msHidden']<'u'?(_0x227f96='msvisibilitychange',_0x13a696='msHidden'):typeof document['webkitHidden']<'u'&&(_0x227f96='webkitvisibilitychange',_0x13a696='webkitHidden')),this['visible_']=!0x0,_0x227f96&&document['addEventListener'](_0x227f96,()=>{const _0x4a871d=!document[_0x13a696];_0x4a871d!==this['visible_']&&(this['visible_']=_0x4a871d,this['trigger']('visible',_0x4a871d));},!0x1);}['getInitialEvent'](_0x3af19d){return f(_0x3af19d==='visible','Unknown\x20event\x20type:\x20'+_0x3af19d),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x5d6167,_0x49167b,_0x800ef1,_0x9cadbd,_0x41d0fc,_0x56d919,_0x59d8b8,_0x2e2a2f){if(super(),this['repoInfo_']=_0x5d6167,this['applicationId_']=_0x49167b,this['onDataUpdate_']=_0x800ef1,this['onConnectStatus_']=_0x9cadbd,this['onServerInfoUpdate_']=_0x41d0fc,this['authTokenProvider_']=_0x56d919,this['appCheckTokenProvider_']=_0x59d8b8,this['authOverride_']=_0x2e2a2f,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x2e2a2f)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x5d6167['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x2ae578,_0x1f5ff1,_0x332c9b){const _0x369b50=++this['requestNumber_'],_0x4a0a45={'r':_0x369b50,'a':_0x2ae578,'b':_0x1f5ff1};this['log_'](O(_0x4a0a45)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x4a0a45),_0x332c9b&&(this['requestCBHash_'][_0x369b50]=_0x332c9b);}['get'](_0x4a3cef){this['initConnection_']();const _0x51ecb7=new ot(),_0x5cd081={'action':'g','request':{'p':_0x4a3cef['_path']['toString'](),'q':_0x4a3cef['_queryObject']},'onComplete':_0x1bf923=>{const _0x567820=_0x1bf923['d'];_0x1bf923['s']==='ok'?_0x51ecb7['resolve'](_0x567820):_0x51ecb7['reject'](_0x567820);}};this['outstandingGets_']['push'](_0x5cd081),this['outstandingGetCount_']++;const _0x394314=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x394314),_0x51ecb7['promise'];}['listen'](_0x14011d,_0x3b910d,_0x2f25fe,_0x39fb02){this['initConnection_']();const _0x3b599c=_0x14011d['_queryIdentifier'],_0x1512ed=_0x14011d['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1512ed+'\x20'+_0x3b599c),this['listens']['has'](_0x1512ed)||this['listens']['set'](_0x1512ed,new Map()),f(_0x14011d['_queryParams']['isDefault']()||!_0x14011d['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x1512ed)['has'](_0x3b599c),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x2ce627={'onComplete':_0x39fb02,'hashFn':_0x3b910d,'query':_0x14011d,'tag':_0x2f25fe};this['listens']['get'](_0x1512ed)['set'](_0x3b599c,_0x2ce627),this['connected_']&&this['sendListen_'](_0x2ce627);}['sendGet_'](_0x201d9f){const _0x243c81=this['outstandingGets_'][_0x201d9f];this['sendRequest']('g',_0x243c81['request'],_0x247d55=>{delete this['outstandingGets_'][_0x201d9f],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x243c81['onComplete']&&_0x243c81['onComplete'](_0x247d55);});}['sendListen_'](_0x800182){const _0x871a21=_0x800182['query'],_0x706b4b=_0x871a21['_path']['toString'](),_0x6c3fb5=_0x871a21['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x706b4b+'\x20for\x20'+_0x6c3fb5);const _0x414001={'p':_0x706b4b},_0x158226='q';_0x800182['tag']&&(_0x414001['q']=_0x871a21['_queryObject'],_0x414001['t']=_0x800182['tag']),_0x414001['h']=_0x800182['hashFn'](),this['sendRequest'](_0x158226,_0x414001,_0x4dc412=>{const _0x31ba4c=_0x4dc412['d'],_0x38cac7=_0x4dc412['s'];se['warnOnListenWarnings_'](_0x31ba4c,_0x871a21),(this['listens']['get'](_0x706b4b)&&this['listens']['get'](_0x706b4b)['get'](_0x6c3fb5))===_0x800182&&(this['log_']('listen\x20response',_0x4dc412),_0x38cac7!=='ok'&&this['removeListen_'](_0x706b4b,_0x6c3fb5),_0x800182['onComplete']&&_0x800182['onComplete'](_0x38cac7,_0x31ba4c));});}static['warnOnListenWarnings_'](_0x405237,_0x342435){if(_0x405237&&typeof _0x405237=='object'&&J(_0x405237,'w')){const _0x11a7e0=De(_0x405237,'w');if(Array['isArray'](_0x11a7e0)&&~_0x11a7e0['indexOf']('no_index')){const _0x4b9f1a='\x22.indexOn\x22:\x20\x22'+_0x342435['_queryParams']['getIndex']()['toString']()+'\x22',_0x27f7c6=_0x342435['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x4b9f1a+'\x20at\x20'+_0x27f7c6+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x59c573){this['authToken_']=_0x59c573,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x59c573);}['reduceReconnectDelayIfAdminCredential_'](_0x3a7785){(_0x3a7785&&_0x3a7785['length']===0x28||wc(_0x3a7785))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x434822){this['appCheckToken_']=_0x434822,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x168c9d=this['authToken_'],_0x130db8=Ic(_0x168c9d)?'auth':'gauth',_0x22fbd6={'cred':_0x168c9d};this['authOverride_']===null?_0x22fbd6['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x22fbd6['authvar']=this['authOverride_']),this['sendRequest'](_0x130db8,_0x22fbd6,_0x436081=>{const _0x3ea247=_0x436081['s'],_0x154c87=_0x436081['d']||'error';this['authToken_']===_0x168c9d&&(_0x3ea247==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x3ea247,_0x154c87));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x6d7744=>{const _0x4d0a7e=_0x6d7744['s'],_0x586939=_0x6d7744['d']||'error';_0x4d0a7e==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x4d0a7e,_0x586939);});}['unlisten'](_0x5c31e5,_0x23c08f){const _0x344068=_0x5c31e5['_path']['toString'](),_0x2f8b2f=_0x5c31e5['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x344068+'\x20'+_0x2f8b2f),f(_0x5c31e5['_queryParams']['isDefault']()||!_0x5c31e5['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x344068,_0x2f8b2f)&&this['connected_']&&this['sendUnlisten_'](_0x344068,_0x2f8b2f,_0x5c31e5['_queryObject'],_0x23c08f);}['sendUnlisten_'](_0x4fe9be,_0x3f8bd9,_0x2f5c5a,_0x57d235){this['log_']('Unlisten\x20on\x20'+_0x4fe9be+'\x20for\x20'+_0x3f8bd9);const _0xc0fedd={'p':_0x4fe9be},_0x7bd637='n';_0x57d235&&(_0xc0fedd['q']=_0x2f5c5a,_0xc0fedd['t']=_0x57d235),this['sendRequest'](_0x7bd637,_0xc0fedd);}['onDisconnectPut'](_0x4f8bff,_0x2e45eb,_0x2639d6){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x4f8bff,_0x2e45eb,_0x2639d6):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4f8bff,'action':'o','data':_0x2e45eb,'onComplete':_0x2639d6});}['onDisconnectMerge'](_0x40a1c9,_0x190fb2,_0x3f066b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x40a1c9,_0x190fb2,_0x3f066b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x40a1c9,'action':'om','data':_0x190fb2,'onComplete':_0x3f066b});}['onDisconnectCancel'](_0x366b1d,_0x1b403d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x366b1d,null,_0x1b403d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x366b1d,'action':'oc','data':null,'onComplete':_0x1b403d});}['sendOnDisconnect_'](_0x41f241,_0x23dc22,_0x9b7836,_0x2efe55){const _0x336e61={'p':_0x23dc22,'d':_0x9b7836};this['log_']('onDisconnect\x20'+_0x41f241,_0x336e61),this['sendRequest'](_0x41f241,_0x336e61,_0x2804e0=>{_0x2efe55&&setTimeout(()=>{_0x2efe55(_0x2804e0['s'],_0x2804e0['d']);},Math['floor'](0x0));});}['put'](_0x355883,_0x592dfd,_0x4284e4,_0x142cb5){this['putInternal']('p',_0x355883,_0x592dfd,_0x4284e4,_0x142cb5);}['merge'](_0x5eb38f,_0x452f78,_0x295d62,_0x37feda){this['putInternal']('m',_0x5eb38f,_0x452f78,_0x295d62,_0x37feda);}['putInternal'](_0x575331,_0x2671f4,_0x42f6a3,_0x3ddb7d,_0x391ce3){this['initConnection_']();const _0x9a4434={'p':_0x2671f4,'d':_0x42f6a3};_0x391ce3!==void 0x0&&(_0x9a4434['h']=_0x391ce3),this['outstandingPuts_']['push']({'action':_0x575331,'request':_0x9a4434,'onComplete':_0x3ddb7d}),this['outstandingPutCount_']++;const _0x3209c0=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x3209c0):this['log_']('Buffering\x20put:\x20'+_0x2671f4);}['sendPut_'](_0x116280){const _0x18268d=this['outstandingPuts_'][_0x116280]['action'],_0x2a147d=this['outstandingPuts_'][_0x116280]['request'],_0xc8f748=this['outstandingPuts_'][_0x116280]['onComplete'];this['outstandingPuts_'][_0x116280]['queued']=this['connected_'],this['sendRequest'](_0x18268d,_0x2a147d,_0x26ccab=>{this['log_'](_0x18268d+'\x20response',_0x26ccab),delete this['outstandingPuts_'][_0x116280],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0xc8f748&&_0xc8f748(_0x26ccab['s'],_0x26ccab['d']);});}['reportStats'](_0x56cdd6){if(this['connected_']){const _0x44ae37={'c':_0x56cdd6};this['log_']('reportStats',_0x44ae37),this['sendRequest']('s',_0x44ae37,_0x102aa0=>{if(_0x102aa0['s']!=='ok'){const _0x388ab5=_0x102aa0['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x388ab5);}});}}['onDataMessage_'](_0x40f284){if('r'in _0x40f284){this['log_']('from\x20server:\x20'+O(_0x40f284));const _0x21385b=_0x40f284['r'],_0x287019=this['requestCBHash_'][_0x21385b];_0x287019&&(delete this['requestCBHash_'][_0x21385b],_0x287019(_0x40f284['b']));}else{if('error'in _0x40f284)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x40f284['error'];'a'in _0x40f284&&this['onDataPush_'](_0x40f284['a'],_0x40f284['b']);}}['onDataPush_'](_0x5b0ad6,_0x1aaaad){this['log_']('handleServerMessage',_0x5b0ad6,_0x1aaaad),_0x5b0ad6==='d'?this['onDataUpdate_'](_0x1aaaad['p'],_0x1aaaad['d'],!0x1,_0x1aaaad['t']):_0x5b0ad6==='m'?this['onDataUpdate_'](_0x1aaaad['p'],_0x1aaaad['d'],!0x0,_0x1aaaad['t']):_0x5b0ad6==='c'?this['onListenRevoked_'](_0x1aaaad['p'],_0x1aaaad['q']):_0x5b0ad6==='ac'?this['onAuthRevoked_'](_0x1aaaad['s'],_0x1aaaad['d']):_0x5b0ad6==='apc'?this['onAppCheckRevoked_'](_0x1aaaad['s'],_0x1aaaad['d']):_0x5b0ad6==='sd'?this['onSecurityDebugPacket_'](_0x1aaaad):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x5b0ad6)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x57aaa6,_0x22f818){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x57aaa6),this['lastSessionId']=_0x22f818,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x3a0f94){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x3a0f94));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x3c1cc4){_0x3c1cc4&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x3c1cc4;}['onOnline_'](_0x56f98c){_0x56f98c?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x2ada51=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x546039=Math['max'](0x0,this['reconnectDelay_']-_0x2ada51);_0x546039=Math['random']()*_0x546039,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x546039+'ms'),this['scheduleConnect_'](_0x546039),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0xdcb2fe=this['onDataMessage_']['bind'](this),_0x5e11d8=this['onReady_']['bind'](this),_0x1076b6=this['onRealtimeDisconnect_']['bind'](this),_0x5321a1=this['id']+':'+se['nextConnectionId_']++,_0x402440=this['lastSessionId'];let _0x48ffaf=!0x1,_0x51f64b=null;const _0x36d290=function(){_0x51f64b?_0x51f64b['close']():(_0x48ffaf=!0x0,_0x1076b6());},_0x21f100=function(_0x4deb8e){f(_0x51f64b,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x51f64b['sendRequest'](_0x4deb8e);};this['realtime_']={'close':_0x36d290,'sendRequest':_0x21f100};const _0x37122e=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x6c2613,_0x516959]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x37122e),this['appCheckTokenProvider_']['getToken'](_0x37122e)]);_0x48ffaf?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x6c2613&&_0x6c2613['accessToken'],this['appCheckToken_']=_0x516959&&_0x516959['token'],_0x51f64b=new Sh(_0x5321a1,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0xdcb2fe,_0x5e11d8,_0x1076b6,_0x5c11f5=>{U(_0x5c11f5+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x402440));}catch(_0x3f21a5){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x3f21a5),_0x48ffaf||(this['repoInfo_']['nodeAdmin']&&U(_0x3f21a5),_0x36d290());}}}['interrupt'](_0x175517){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x175517),this['interruptReasons_'][_0x175517]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x34e12e){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x34e12e),delete this['interruptReasons_'][_0x34e12e],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x2b42b7){const _0xcf516c=_0x2b42b7-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0xcf516c});}['cancelSentTransactions_'](){for(let _0x5e9185=0x0;_0x5e9185<this['outstandingPuts_']['length'];_0x5e9185++){const _0x3f1c59=this['outstandingPuts_'][_0x5e9185];_0x3f1c59&&'h'in _0x3f1c59['request']&&_0x3f1c59['queued']&&(_0x3f1c59['onComplete']&&_0x3f1c59['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x5e9185],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x1ec8c1,_0x3766f1){let _0x461a4c;_0x3766f1?_0x461a4c=_0x3766f1['map'](_0x547cff=>Hi(_0x547cff))['join']('$'):_0x461a4c='default';const _0x579242=this['removeListen_'](_0x1ec8c1,_0x461a4c);_0x579242&&_0x579242['onComplete']&&_0x579242['onComplete']('permission_denied');}['removeListen_'](_0x4b3917,_0x355559){const _0x23ba08=new C(_0x4b3917)['toString']();let _0x41716e;if(this['listens']['has'](_0x23ba08)){const _0x271d7e=this['listens']['get'](_0x23ba08);_0x41716e=_0x271d7e['get'](_0x355559),_0x271d7e['delete'](_0x355559),_0x271d7e['size']===0x0&&this['listens']['delete'](_0x23ba08);}else _0x41716e=void 0x0;return _0x41716e;}['onAuthRevoked_'](_0x4c19cb,_0xfcd395){L('Auth\x20token\x20revoked:\x20'+_0x4c19cb+'/'+_0xfcd395),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x4c19cb==='invalid_token'||_0x4c19cb==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x301aa3,_0x2ae115){L('App\x20check\x20token\x20revoked:\x20'+_0x301aa3+'/'+_0x2ae115),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x301aa3==='invalid_token'||_0x301aa3==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x55bd93){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x55bd93):'msg'in _0x55bd93&&console['log']('FIREBASE:\x20'+_0x55bd93['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x44d0e8 of this['listens']['values']())for(const _0x6f8fa9 of _0x44d0e8['values']())this['sendListen_'](_0x6f8fa9);for(let _0x2b9b5e=0x0;_0x2b9b5e<this['outstandingPuts_']['length'];_0x2b9b5e++)this['outstandingPuts_'][_0x2b9b5e]&&this['sendPut_'](_0x2b9b5e);for(;this['onDisconnectRequestQueue_']['length'];){const _0x208d90=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x208d90['action'],_0x208d90['pathString'],_0x208d90['data'],_0x208d90['onComplete']);}for(let _0x5e9d64=0x0;_0x5e9d64<this['outstandingGets_']['length'];_0x5e9d64++)this['outstandingGets_'][_0x5e9d64]&&this['sendGet_'](_0x5e9d64);}['sendConnectStats_'](){const _0xf9341e={};let _0x439b9d='js';_0xf9341e['sdk.'+_0x439b9d+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0xf9341e['framework.cordova']=0x1:Yr()&&(_0xf9341e['framework.reactnative']=0x1),this['reportStats'](_0xf9341e);}['shouldReconnect_'](){const _0x1ed8d2=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x1ed8d2;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x4a6437,_0x2ed3db){this['name']=_0x4a6437,this['node']=_0x2ed3db;}static['Wrap'](_0x1bb22e,_0x5e1908){return new E(_0x1bb22e,_0x5e1908);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x1bb2b0,_0x4eaa99){const _0x41cbe8=new E(Fe,_0x1bb2b0),_0x2b5eda=new E(Fe,_0x4eaa99);return this['compare'](_0x41cbe8,_0x2b5eda)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0xbb0a4){Zt=_0xbb0a4;}['compare'](_0x1af9e6,_0x218f15){return He(_0x1af9e6['name'],_0x218f15['name']);}['isDefinedOn'](_0x148c14){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x3b437e,_0x2ef8a5){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x105f81,_0x2378bb){return f(typeof _0x105f81=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x105f81,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x33beb1,_0x157ca5,_0x2c8c85,_0x5702cc,_0x5e7349=null){this['isReverse_']=_0x5702cc,this['resultGenerator_']=_0x5e7349,this['nodeStack_']=[];let _0x2f865e=0x1;for(;!_0x33beb1['isEmpty']();)if(_0x33beb1=_0x33beb1,_0x2f865e=_0x157ca5?_0x2c8c85(_0x33beb1['key'],_0x157ca5):0x1,_0x5702cc&&(_0x2f865e*=-0x1),_0x2f865e<0x0)this['isReverse_']?_0x33beb1=_0x33beb1['left']:_0x33beb1=_0x33beb1['right'];else{if(_0x2f865e===0x0){this['nodeStack_']['push'](_0x33beb1);break;}else this['nodeStack_']['push'](_0x33beb1),this['isReverse_']?_0x33beb1=_0x33beb1['right']:_0x33beb1=_0x33beb1['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x1ef1f0=this['nodeStack_']['pop'](),_0xd8d86;if(this['resultGenerator_']?_0xd8d86=this['resultGenerator_'](_0x1ef1f0['key'],_0x1ef1f0['value']):_0xd8d86={'key':_0x1ef1f0['key'],'value':_0x1ef1f0['value']},this['isReverse_']){for(_0x1ef1f0=_0x1ef1f0['left'];!_0x1ef1f0['isEmpty']();)this['nodeStack_']['push'](_0x1ef1f0),_0x1ef1f0=_0x1ef1f0['right'];}else{for(_0x1ef1f0=_0x1ef1f0['right'];!_0x1ef1f0['isEmpty']();)this['nodeStack_']['push'](_0x1ef1f0),_0x1ef1f0=_0x1ef1f0['left'];}return _0xd8d86;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x22bcef=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x22bcef['key'],_0x22bcef['value']):{'key':_0x22bcef['key'],'value':_0x22bcef['value']};}}class M{constructor(_0x361d35,_0x57dbe6,_0x179b13,_0x185f19,_0x9fc93c){this['key']=_0x361d35,this['value']=_0x57dbe6,this['color']=_0x179b13??M['RED'],this['left']=_0x185f19??B['EMPTY_NODE'],this['right']=_0x9fc93c??B['EMPTY_NODE'];}['copy'](_0x187e2a,_0x3f6463,_0x3a9d9c,_0x9f827d,_0x3d02ef){return new M(_0x187e2a??this['key'],_0x3f6463??this['value'],_0x3a9d9c??this['color'],_0x9f827d??this['left'],_0x3d02ef??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0xe1217b){return this['left']['inorderTraversal'](_0xe1217b)||!!_0xe1217b(this['key'],this['value'])||this['right']['inorderTraversal'](_0xe1217b);}['reverseTraversal'](_0x43dd2e){return this['right']['reverseTraversal'](_0x43dd2e)||_0x43dd2e(this['key'],this['value'])||this['left']['reverseTraversal'](_0x43dd2e);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x1b2f28,_0x2a00ef,_0x117093){let _0x172a5d=this;const _0x538334=_0x117093(_0x1b2f28,_0x172a5d['key']);return _0x538334<0x0?_0x172a5d=_0x172a5d['copy'](null,null,null,_0x172a5d['left']['insert'](_0x1b2f28,_0x2a00ef,_0x117093),null):_0x538334===0x0?_0x172a5d=_0x172a5d['copy'](null,_0x2a00ef,null,null,null):_0x172a5d=_0x172a5d['copy'](null,null,null,null,_0x172a5d['right']['insert'](_0x1b2f28,_0x2a00ef,_0x117093)),_0x172a5d['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0xa98ef1=this;return!_0xa98ef1['left']['isRed_']()&&!_0xa98ef1['left']['left']['isRed_']()&&(_0xa98ef1=_0xa98ef1['moveRedLeft_']()),_0xa98ef1=_0xa98ef1['copy'](null,null,null,_0xa98ef1['left']['removeMin_'](),null),_0xa98ef1['fixUp_']();}['remove'](_0x62023e,_0x45ca4d){let _0x3cac6f,_0x1f47e4;if(_0x3cac6f=this,_0x45ca4d(_0x62023e,_0x3cac6f['key'])<0x0)!_0x3cac6f['left']['isEmpty']()&&!_0x3cac6f['left']['isRed_']()&&!_0x3cac6f['left']['left']['isRed_']()&&(_0x3cac6f=_0x3cac6f['moveRedLeft_']()),_0x3cac6f=_0x3cac6f['copy'](null,null,null,_0x3cac6f['left']['remove'](_0x62023e,_0x45ca4d),null);else{if(_0x3cac6f['left']['isRed_']()&&(_0x3cac6f=_0x3cac6f['rotateRight_']()),!_0x3cac6f['right']['isEmpty']()&&!_0x3cac6f['right']['isRed_']()&&!_0x3cac6f['right']['left']['isRed_']()&&(_0x3cac6f=_0x3cac6f['moveRedRight_']()),_0x45ca4d(_0x62023e,_0x3cac6f['key'])===0x0){if(_0x3cac6f['right']['isEmpty']())return B['EMPTY_NODE'];_0x1f47e4=_0x3cac6f['right']['min_'](),_0x3cac6f=_0x3cac6f['copy'](_0x1f47e4['key'],_0x1f47e4['value'],null,null,_0x3cac6f['right']['removeMin_']());}_0x3cac6f=_0x3cac6f['copy'](null,null,null,null,_0x3cac6f['right']['remove'](_0x62023e,_0x45ca4d));}return _0x3cac6f['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x30e7f0=this;return _0x30e7f0['right']['isRed_']()&&!_0x30e7f0['left']['isRed_']()&&(_0x30e7f0=_0x30e7f0['rotateLeft_']()),_0x30e7f0['left']['isRed_']()&&_0x30e7f0['left']['left']['isRed_']()&&(_0x30e7f0=_0x30e7f0['rotateRight_']()),_0x30e7f0['left']['isRed_']()&&_0x30e7f0['right']['isRed_']()&&(_0x30e7f0=_0x30e7f0['colorFlip_']()),_0x30e7f0;}['moveRedLeft_'](){let _0x554cb0=this['colorFlip_']();return _0x554cb0['right']['left']['isRed_']()&&(_0x554cb0=_0x554cb0['copy'](null,null,null,null,_0x554cb0['right']['rotateRight_']()),_0x554cb0=_0x554cb0['rotateLeft_'](),_0x554cb0=_0x554cb0['colorFlip_']()),_0x554cb0;}['moveRedRight_'](){let _0xe8d523=this['colorFlip_']();return _0xe8d523['left']['left']['isRed_']()&&(_0xe8d523=_0xe8d523['rotateRight_'](),_0xe8d523=_0xe8d523['colorFlip_']()),_0xe8d523;}['rotateLeft_'](){const _0x82f129=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x82f129,null);}['rotateRight_'](){const _0x877cf3=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x877cf3);}['colorFlip_'](){const _0x16e3da=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x1b116b=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x16e3da,_0x1b116b);}['checkMaxDepth_'](){const _0x27a31d=this['check_']();return Math['pow'](0x2,_0x27a31d)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x60103d=this['left']['check_']();if(_0x60103d!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x60103d+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x42bb5e,_0x108b61,_0x38dec3,_0x92894f,_0x54a4b9){return this;}['insert'](_0x1eaff2,_0x54d69a,_0x3c74bc){return new M(_0x1eaff2,_0x54d69a,null);}['remove'](_0x502465,_0x33b389){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x1fc33c){return!0x1;}['reverseTraversal'](_0x19602a){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x27cee1,_0x59ee3d=B['EMPTY_NODE']){this['comparator_']=_0x27cee1,this['root_']=_0x59ee3d;}['insert'](_0x4e35b5,_0xbd537a){return new B(this['comparator_'],this['root_']['insert'](_0x4e35b5,_0xbd537a,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x3a3a60){return new B(this['comparator_'],this['root_']['remove'](_0x3a3a60,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x16f7b4){let _0x1bb21e,_0x4cae76=this['root_'];for(;!_0x4cae76['isEmpty']();){if(_0x1bb21e=this['comparator_'](_0x16f7b4,_0x4cae76['key']),_0x1bb21e===0x0)return _0x4cae76['value'];_0x1bb21e<0x0?_0x4cae76=_0x4cae76['left']:_0x1bb21e>0x0&&(_0x4cae76=_0x4cae76['right']);}return null;}['getPredecessorKey'](_0x428721){let _0x4beedb,_0xccafa1=this['root_'],_0x4dbbbf=null;for(;!_0xccafa1['isEmpty']();)if(_0x4beedb=this['comparator_'](_0x428721,_0xccafa1['key']),_0x4beedb===0x0){if(_0xccafa1['left']['isEmpty']())return _0x4dbbbf?_0x4dbbbf['key']:null;for(_0xccafa1=_0xccafa1['left'];!_0xccafa1['right']['isEmpty']();)_0xccafa1=_0xccafa1['right'];return _0xccafa1['key'];}else _0x4beedb<0x0?_0xccafa1=_0xccafa1['left']:_0x4beedb>0x0&&(_0x4dbbbf=_0xccafa1,_0xccafa1=_0xccafa1['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x3b2393){return this['root_']['inorderTraversal'](_0x3b2393);}['reverseTraversal'](_0x317458){return this['root_']['reverseTraversal'](_0x317458);}['getIterator'](_0x4ed7a8){return new en(this['root_'],null,this['comparator_'],!0x1,_0x4ed7a8);}['getIteratorFrom'](_0xc7ad82,_0x5d7e44){return new en(this['root_'],_0xc7ad82,this['comparator_'],!0x1,_0x5d7e44);}['getReverseIteratorFrom'](_0x41a449,_0x15ab35){return new en(this['root_'],_0x41a449,this['comparator_'],!0x0,_0x15ab35);}['getReverseIterator'](_0x28f28c){return new en(this['root_'],null,this['comparator_'],!0x0,_0x28f28c);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x41d996,_0x291458){return He(_0x41d996['name'],_0x291458['name']);}function Yi(_0x4851be,_0x1dea79){return He(_0x4851be,_0x1dea79);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0xc8880d){Ei=_0xc8880d;}const No=function(_0x52a025){return typeof _0x52a025=='number'?'number:'+ao(_0x52a025):'string:'+_0x52a025;},Po=function(_0x6579ff){if(_0x6579ff['isLeafNode']()){const _0x22843f=_0x6579ff['val']();f(typeof _0x22843f=='string'||typeof _0x22843f=='number'||typeof _0x22843f=='object'&&J(_0x22843f,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x6579ff===Ei||_0x6579ff['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x6579ff===Ei||_0x6579ff['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x2fc596){ir=_0x2fc596;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x354167,_0x1ebcdd=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x354167,this['priorityNode_']=_0x1ebcdd,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1501e1){return new D(this['value_'],_0x1501e1);}['getImmediateChild'](_0x2c3565){return _0x2c3565==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x606310){return v(_0x606310)?this:y(_0x606310)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x4c3ae2,_0x55855f){return null;}['updateImmediateChild'](_0x1eac88,_0x32fb6f){return _0x1eac88==='.priority'?this['updatePriority'](_0x32fb6f):_0x32fb6f['isEmpty']()&&_0x1eac88!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x1eac88,_0x32fb6f)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x2f15c7,_0x5cba2f){const _0x1264fb=y(_0x2f15c7);return _0x1264fb===null?_0x5cba2f:_0x5cba2f['isEmpty']()&&_0x1264fb!=='.priority'?this:(f(_0x1264fb!=='.priority'||we(_0x2f15c7)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x1264fb,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x2f15c7),_0x5cba2f)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x5429a4,_0x14239f){return!0x1;}['val'](_0x5136bf){return _0x5136bf&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x52a768='';this['priorityNode_']['isEmpty']()||(_0x52a768+='priority:'+No(this['priorityNode_']['val']())+':');const _0x242b55=typeof this['value_'];_0x52a768+=_0x242b55+':',_0x242b55==='number'?_0x52a768+=ao(this['value_']):_0x52a768+=this['value_'],this['lazyHash_']=ro(_0x52a768);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x26e6cb){return _0x26e6cb===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x26e6cb instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x26e6cb['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x26e6cb));}['compareToLeafNode_'](_0x5f43f7){const _0x24a779=typeof _0x5f43f7['value_'],_0x1462b4=typeof this['value_'],_0x3242f2=D['VALUE_TYPE_ORDER']['indexOf'](_0x24a779),_0xebc4f0=D['VALUE_TYPE_ORDER']['indexOf'](_0x1462b4);return f(_0x3242f2>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x24a779),f(_0xebc4f0>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1462b4),_0x3242f2===_0xebc4f0?_0x1462b4==='object'?0x0:this['value_']<_0x5f43f7['value_']?-0x1:this['value_']===_0x5f43f7['value_']?0x0:0x1:_0xebc4f0-_0x3242f2;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x3c0f03){if(_0x3c0f03===this)return!0x0;if(_0x3c0f03['isLeafNode']()){const _0x49e3d4=_0x3c0f03;return this['value_']===_0x49e3d4['value_']&&this['priorityNode_']['equals'](_0x49e3d4['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x320097){Oo=_0x320097;}function Wh(_0x20ec68){Do=_0x20ec68;}class Bh extends Dn{['compare'](_0xff2df8,_0x1da62e){const _0x1a4e94=_0xff2df8['node']['getPriority'](),_0x59c2a1=_0x1da62e['node']['getPriority'](),_0x361f16=_0x1a4e94['compareTo'](_0x59c2a1);return _0x361f16===0x0?He(_0xff2df8['name'],_0x1da62e['name']):_0x361f16;}['isDefinedOn'](_0x3c7e48){return!_0x3c7e48['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x41531b,_0x45c151){return!_0x41531b['getPriority']()['equals'](_0x45c151['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x28941b,_0x54934a){const _0x1e5998=Oo(_0x28941b);return new E(_0x54934a,new D('[PRIORITY-POST]',_0x1e5998));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0xab3269){const _0x376f64=_0x2d1583=>parseInt(Math['log'](_0x2d1583)/Vh,0xa),_0x704a09=_0x1bf8bf=>parseInt(Array(_0x1bf8bf+0x1)['join']('1'),0x2);this['count']=_0x376f64(_0xab3269+0x1),this['current_']=this['count']-0x1;const _0x2f2e76=_0x704a09(this['count']);this['bits_']=_0xab3269+0x1&_0x2f2e76;}['nextBitIsOne'](){const _0x13b2a0=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x13b2a0;}}const fn=function(_0xe11b99,_0x395547,_0x3a8905,_0x50c4f9){_0xe11b99['sort'](_0x395547);const _0x3d6585=function(_0x3cb1cd,_0x245d14){const _0x93fd54=_0x245d14-_0x3cb1cd;let _0x39fb8b,_0x44fe04;if(_0x93fd54===0x0)return null;if(_0x93fd54===0x1)return _0x39fb8b=_0xe11b99[_0x3cb1cd],_0x44fe04=_0x3a8905?_0x3a8905(_0x39fb8b):_0x39fb8b,new M(_0x44fe04,_0x39fb8b['node'],M['BLACK'],null,null);{const _0x91e57d=parseInt(_0x93fd54/0x2,0xa)+_0x3cb1cd,_0x2288fc=_0x3d6585(_0x3cb1cd,_0x91e57d),_0x148eb2=_0x3d6585(_0x91e57d+0x1,_0x245d14);return _0x39fb8b=_0xe11b99[_0x91e57d],_0x44fe04=_0x3a8905?_0x3a8905(_0x39fb8b):_0x39fb8b,new M(_0x44fe04,_0x39fb8b['node'],M['BLACK'],_0x2288fc,_0x148eb2);}},_0x32f335=function(_0x1d8ca4){let _0x5299ed=null,_0x3b669a=null,_0xd8e333=_0xe11b99['length'];const _0x45560b=function(_0x276523,_0x32bf55){const _0x26767f=_0xd8e333-_0x276523,_0x3f19d4=_0xd8e333;_0xd8e333-=_0x276523;const _0x3d3ab=_0x3d6585(_0x26767f+0x1,_0x3f19d4),_0x189d30=_0xe11b99[_0x26767f],_0x13974a=_0x3a8905?_0x3a8905(_0x189d30):_0x189d30;_0x1a188c(new M(_0x13974a,_0x189d30['node'],_0x32bf55,null,_0x3d3ab));},_0x1a188c=function(_0x3e476b){_0x5299ed?(_0x5299ed['left']=_0x3e476b,_0x5299ed=_0x3e476b):(_0x3b669a=_0x3e476b,_0x5299ed=_0x3e476b);};for(let _0x270805=0x0;_0x270805<_0x1d8ca4['count'];++_0x270805){const _0x5d44cf=_0x1d8ca4['nextBitIsOne'](),_0x40d79c=Math['pow'](0x2,_0x1d8ca4['count']-(_0x270805+0x1));_0x5d44cf?_0x45560b(_0x40d79c,M['BLACK']):(_0x45560b(_0x40d79c,M['BLACK']),_0x45560b(_0x40d79c,M['RED']));}return _0x3b669a;},_0x500f6f=new Hh(_0xe11b99['length']),_0x2051d7=_0x32f335(_0x500f6f);return new B(_0x50c4f9||_0x395547,_0x2051d7);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x58ac5d,_0x471cb1){this['indexes_']=_0x58ac5d,this['indexSet_']=_0x471cb1;}['get'](_0x47f636){const _0x3dd9fe=De(this['indexes_'],_0x47f636);if(!_0x3dd9fe)throw new Error('No\x20index\x20defined\x20for\x20'+_0x47f636);return _0x3dd9fe instanceof B?_0x3dd9fe:null;}['hasIndex'](_0x529383){return J(this['indexSet_'],_0x529383['toString']());}['addIndex'](_0x323d2f,_0x17e4ff){f(_0x323d2f!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x41152f=[];let _0x1a58ce=!0x1;const _0x1801ef=_0x17e4ff['getIterator'](E['Wrap']);let _0x2489be=_0x1801ef['getNext']();for(;_0x2489be;)_0x1a58ce=_0x1a58ce||_0x323d2f['isDefinedOn'](_0x2489be['node']),_0x41152f['push'](_0x2489be),_0x2489be=_0x1801ef['getNext']();let _0x356dfb;_0x1a58ce?_0x356dfb=fn(_0x41152f,_0x323d2f['getCompare']()):_0x356dfb=ze;const _0x341ab6=_0x323d2f['toString'](),_0x1c5210={...this['indexSet_']};_0x1c5210[_0x341ab6]=_0x323d2f;const _0x5449ce={...this['indexes_']};return _0x5449ce[_0x341ab6]=_0x356dfb,new te(_0x5449ce,_0x1c5210);}['addToIndexes'](_0x72f355,_0x1950f5){const _0x2a37ce=hn(this['indexes_'],(_0x5bfad7,_0x41b1e5)=>{const _0x373bba=De(this['indexSet_'],_0x41b1e5);if(f(_0x373bba,'Missing\x20index\x20implementation\x20for\x20'+_0x41b1e5),_0x5bfad7===ze){if(_0x373bba['isDefinedOn'](_0x72f355['node'])){const _0x295219=[],_0x1c81f8=_0x1950f5['getIterator'](E['Wrap']);let _0x26b555=_0x1c81f8['getNext']();for(;_0x26b555;)_0x26b555['name']!==_0x72f355['name']&&_0x295219['push'](_0x26b555),_0x26b555=_0x1c81f8['getNext']();return _0x295219['push'](_0x72f355),fn(_0x295219,_0x373bba['getCompare']());}else return ze;}else{const _0xfbe416=_0x1950f5['get'](_0x72f355['name']);let _0x42eb1d=_0x5bfad7;return _0xfbe416&&(_0x42eb1d=_0x42eb1d['remove'](new E(_0x72f355['name'],_0xfbe416))),_0x42eb1d['insert'](_0x72f355,_0x72f355['node']);}});return new te(_0x2a37ce,this['indexSet_']);}['removeFromIndexes'](_0x272117,_0x5eda99){const _0x14c281=hn(this['indexes_'],_0x53130a=>{if(_0x53130a===ze)return _0x53130a;{const _0x5451ee=_0x5eda99['get'](_0x272117['name']);return _0x5451ee?_0x53130a['remove'](new E(_0x272117['name'],_0x5451ee)):_0x53130a;}});return new te(_0x14c281,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x5c066d,_0x245c60,_0x540106){this['children_']=_0x5c066d,this['priorityNode_']=_0x245c60,this['indexMap_']=_0x540106,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x59d499){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x59d499,this['indexMap_']);}['getImmediateChild'](_0x26f213){if(_0x26f213==='.priority')return this['getPriority']();{const _0x5d6586=this['children_']['get'](_0x26f213);return _0x5d6586===null?mt:_0x5d6586;}}['getChild'](_0x4b5e33){const _0x20b0fa=y(_0x4b5e33);return _0x20b0fa===null?this:this['getImmediateChild'](_0x20b0fa)['getChild'](b(_0x4b5e33));}['hasChild'](_0x47a24c){return this['children_']['get'](_0x47a24c)!==null;}['updateImmediateChild'](_0x2340ee,_0x4d7bdc){if(f(_0x4d7bdc,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x2340ee==='.priority')return this['updatePriority'](_0x4d7bdc);{const _0x2acde6=new E(_0x2340ee,_0x4d7bdc);let _0x4596b4,_0x15673e;_0x4d7bdc['isEmpty']()?(_0x4596b4=this['children_']['remove'](_0x2340ee),_0x15673e=this['indexMap_']['removeFromIndexes'](_0x2acde6,this['children_'])):(_0x4596b4=this['children_']['insert'](_0x2340ee,_0x4d7bdc),_0x15673e=this['indexMap_']['addToIndexes'](_0x2acde6,this['children_']));const _0x1b3790=_0x4596b4['isEmpty']()?mt:this['priorityNode_'];return new g(_0x4596b4,_0x1b3790,_0x15673e);}}['updateChild'](_0x4a4507,_0x16392c){const _0x37dfbb=y(_0x4a4507);if(_0x37dfbb===null)return _0x16392c;{f(y(_0x4a4507)!=='.priority'||we(_0x4a4507)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x153cf0=this['getImmediateChild'](_0x37dfbb)['updateChild'](b(_0x4a4507),_0x16392c);return this['updateImmediateChild'](_0x37dfbb,_0x153cf0);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x61810f){if(this['isEmpty']())return null;const _0x13d8af={};let _0x289e5b=0x0,_0xa0181d=0x0,_0x4a7546=!0x0;if(this['forEachChild'](R,(_0x196e5d,_0x57f3cb)=>{_0x13d8af[_0x196e5d]=_0x57f3cb['val'](_0x61810f),_0x289e5b++,_0x4a7546&&g['INTEGER_REGEXP_']['test'](_0x196e5d)?_0xa0181d=Math['max'](_0xa0181d,Number(_0x196e5d)):_0x4a7546=!0x1;}),!_0x61810f&&_0x4a7546&&_0xa0181d<0x2*_0x289e5b){const _0x52eceb=[];for(const _0x44eb83 in _0x13d8af)_0x52eceb[_0x44eb83]=_0x13d8af[_0x44eb83];return _0x52eceb;}else return _0x61810f&&!this['getPriority']()['isEmpty']()&&(_0x13d8af['.priority']=this['getPriority']()['val']()),_0x13d8af;}['hash'](){if(this['lazyHash_']===null){let _0x5729db='';this['getPriority']()['isEmpty']()||(_0x5729db+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x2dbeb2,_0x3b113c)=>{const _0xe5983c=_0x3b113c['hash']();_0xe5983c!==''&&(_0x5729db+=':'+_0x2dbeb2+':'+_0xe5983c);}),this['lazyHash_']=_0x5729db===''?'':ro(_0x5729db);}return this['lazyHash_'];}['getPredecessorChildName'](_0x175bfd,_0x5c07e7,_0x2e865a){const _0x486f5b=this['resolveIndex_'](_0x2e865a);if(_0x486f5b){const _0x386836=_0x486f5b['getPredecessorKey'](new E(_0x175bfd,_0x5c07e7));return _0x386836?_0x386836['name']:null;}else return this['children_']['getPredecessorKey'](_0x175bfd);}['getFirstChildName'](_0x568124){const _0x258179=this['resolveIndex_'](_0x568124);if(_0x258179){const _0x1d192d=_0x258179['minKey']();return _0x1d192d&&_0x1d192d['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x142840){const _0x5ee8b9=this['getFirstChildName'](_0x142840);return _0x5ee8b9?new E(_0x5ee8b9,this['children_']['get'](_0x5ee8b9)):null;}['getLastChildName'](_0x4ff472){const _0x1b4708=this['resolveIndex_'](_0x4ff472);if(_0x1b4708){const _0x3c2df8=_0x1b4708['maxKey']();return _0x3c2df8&&_0x3c2df8['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x2fa798){const _0x138d18=this['getLastChildName'](_0x2fa798);return _0x138d18?new E(_0x138d18,this['children_']['get'](_0x138d18)):null;}['forEachChild'](_0x3c9479,_0x115fe5){const _0x34bd42=this['resolveIndex_'](_0x3c9479);return _0x34bd42?_0x34bd42['inorderTraversal'](_0x1097e2=>_0x115fe5(_0x1097e2['name'],_0x1097e2['node'])):this['children_']['inorderTraversal'](_0x115fe5);}['getIterator'](_0x410f91){return this['getIteratorFrom'](_0x410f91['minPost'](),_0x410f91);}['getIteratorFrom'](_0x50e8c1,_0x42a9c8){const _0xf5a979=this['resolveIndex_'](_0x42a9c8);if(_0xf5a979)return _0xf5a979['getIteratorFrom'](_0x50e8c1,_0x53b259=>_0x53b259);{const _0x56d43c=this['children_']['getIteratorFrom'](_0x50e8c1['name'],E['Wrap']);let _0x21525b=_0x56d43c['peek']();for(;_0x21525b!=null&&_0x42a9c8['compare'](_0x21525b,_0x50e8c1)<0x0;)_0x56d43c['getNext'](),_0x21525b=_0x56d43c['peek']();return _0x56d43c;}}['getReverseIterator'](_0x336358){return this['getReverseIteratorFrom'](_0x336358['maxPost'](),_0x336358);}['getReverseIteratorFrom'](_0x431cf0,_0xd732cd){const _0x18a856=this['resolveIndex_'](_0xd732cd);if(_0x18a856)return _0x18a856['getReverseIteratorFrom'](_0x431cf0,_0x417c58=>_0x417c58);{const _0x4eaa1c=this['children_']['getReverseIteratorFrom'](_0x431cf0['name'],E['Wrap']);let _0x10108e=_0x4eaa1c['peek']();for(;_0x10108e!=null&&_0xd732cd['compare'](_0x10108e,_0x431cf0)>0x0;)_0x4eaa1c['getNext'](),_0x10108e=_0x4eaa1c['peek']();return _0x4eaa1c;}}['compareTo'](_0x2606cf){return this['isEmpty']()?_0x2606cf['isEmpty']()?0x0:-0x1:_0x2606cf['isLeafNode']()||_0x2606cf['isEmpty']()?0x1:_0x2606cf===$t?-0x1:0x0;}['withIndex'](_0x2455b9){if(_0x2455b9===ye||this['indexMap_']['hasIndex'](_0x2455b9))return this;{const _0x453ad0=this['indexMap_']['addIndex'](_0x2455b9,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x453ad0);}}['isIndexed'](_0x11e32f){return _0x11e32f===ye||this['indexMap_']['hasIndex'](_0x11e32f);}['equals'](_0x3208ef){if(_0x3208ef===this)return!0x0;if(_0x3208ef['isLeafNode']())return!0x1;{const _0x53c070=_0x3208ef;if(this['getPriority']()['equals'](_0x53c070['getPriority']())){if(this['children_']['count']()===_0x53c070['children_']['count']()){const _0x3f9852=this['getIterator'](R),_0x3b0548=_0x53c070['getIterator'](R);let _0x4183e6=_0x3f9852['getNext'](),_0xd20faa=_0x3b0548['getNext']();for(;_0x4183e6&&_0xd20faa;){if(_0x4183e6['name']!==_0xd20faa['name']||!_0x4183e6['node']['equals'](_0xd20faa['node']))return!0x1;_0x4183e6=_0x3f9852['getNext'](),_0xd20faa=_0x3b0548['getNext']();}return _0x4183e6===null&&_0xd20faa===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0xe9ac9d){return _0xe9ac9d===ye?null:this['indexMap_']['get'](_0xe9ac9d['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0xa76be8){return _0xa76be8===this?0x0:0x1;}['equals'](_0x1c0e61){return _0x1c0e61===this;}['getPriority'](){return this;}['getImmediateChild'](_0x45ad93){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x5c967e,_0x1b22a6=null){if(_0x5c967e===null)return g['EMPTY_NODE'];if(typeof _0x5c967e=='object'&&'.priority'in _0x5c967e&&(_0x1b22a6=_0x5c967e['.priority']),f(_0x1b22a6===null||typeof _0x1b22a6=='string'||typeof _0x1b22a6=='number'||typeof _0x1b22a6=='object'&&'.sv'in _0x1b22a6,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x1b22a6),typeof _0x5c967e=='object'&&'.value'in _0x5c967e&&_0x5c967e['.value']!==null&&(_0x5c967e=_0x5c967e['.value']),typeof _0x5c967e!='object'||'.sv'in _0x5c967e){const _0x1c358b=_0x5c967e;return new D(_0x1c358b,P(_0x1b22a6));}if(!(_0x5c967e instanceof Array)&&Gh){const _0x116351=[];let _0x546a0a=!0x1;if(x(_0x5c967e,(_0x5e8d1e,_0x532a1b)=>{if(_0x5e8d1e['substring'](0x0,0x1)!=='.'){const _0xf0c627=P(_0x532a1b);_0xf0c627['isEmpty']()||(_0x546a0a=_0x546a0a||!_0xf0c627['getPriority']()['isEmpty'](),_0x116351['push'](new E(_0x5e8d1e,_0xf0c627)));}}),_0x116351['length']===0x0)return g['EMPTY_NODE'];const _0x58ec9b=fn(_0x116351,xh,_0x57aa91=>_0x57aa91['name'],Yi);if(_0x546a0a){const _0x58595f=fn(_0x116351,R['getCompare']());return new g(_0x58ec9b,P(_0x1b22a6),new te({'.priority':_0x58595f},{'.priority':R}));}else return new g(_0x58ec9b,P(_0x1b22a6),te['Default']);}else{let _0x2d6377=g['EMPTY_NODE'];return x(_0x5c967e,(_0x1d86b9,_0x3ba1b6)=>{if(J(_0x5c967e,_0x1d86b9)&&_0x1d86b9['substring'](0x0,0x1)!=='.'){const _0x5f3ca9=P(_0x3ba1b6);(_0x5f3ca9['isLeafNode']()||!_0x5f3ca9['isEmpty']())&&(_0x2d6377=_0x2d6377['updateImmediateChild'](_0x1d86b9,_0x5f3ca9));}}),_0x2d6377['updatePriority'](P(_0x1b22a6));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x5e5cdd){super(),this['indexPath_']=_0x5e5cdd,f(!v(_0x5e5cdd)&&y(_0x5e5cdd)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x5de34c){return _0x5de34c['getChild'](this['indexPath_']);}['isDefinedOn'](_0x123c69){return!_0x123c69['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x1a5ea1,_0x2b41cf){const _0x36d88f=this['extractChild'](_0x1a5ea1['node']),_0x28f134=this['extractChild'](_0x2b41cf['node']),_0x5285fa=_0x36d88f['compareTo'](_0x28f134);return _0x5285fa===0x0?He(_0x1a5ea1['name'],_0x2b41cf['name']):_0x5285fa;}['makePost'](_0x20c565,_0x4cdae3){const _0x53110e=P(_0x20c565),_0x2b840c=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x53110e);return new E(_0x4cdae3,_0x2b840c);}['maxPost'](){const _0x39de60=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x39de60);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x34de1f,_0x52010d){const _0x39023b=_0x34de1f['node']['compareTo'](_0x52010d['node']);return _0x39023b===0x0?He(_0x34de1f['name'],_0x52010d['name']):_0x39023b;}['isDefinedOn'](_0x29c89c){return!0x0;}['indexedValueChanged'](_0x5d8ddc,_0x136f07){return!_0x5d8ddc['equals'](_0x136f07);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x40f714,_0x583b09){const _0x15714a=P(_0x40f714);return new E(_0x583b09,_0x15714a);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x29ebc4){return{'type':'value','snapshotNode':_0x29ebc4};}function et(_0x32d166,_0x5d3d23){return{'type':'child_added','snapshotNode':_0x5d3d23,'childName':_0x32d166};}function Ot(_0x4e1a51,_0x9183bc){return{'type':'child_removed','snapshotNode':_0x9183bc,'childName':_0x4e1a51};}function Dt(_0x1262e1,_0x1e683c,_0xd7de95){return{'type':'child_changed','snapshotNode':_0x1e683c,'childName':_0x1262e1,'oldSnap':_0xd7de95};}function zh(_0x1f3c68,_0x383d6b){return{'type':'child_moved','snapshotNode':_0x383d6b,'childName':_0x1f3c68};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x3cc307){this['index_']=_0x3cc307;}['updateChild'](_0x4b2e87,_0x437f6a,_0x312795,_0x28db4c,_0x436f4c,_0x510c69){f(_0x4b2e87['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x1b812d=_0x4b2e87['getImmediateChild'](_0x437f6a);return _0x1b812d['getChild'](_0x28db4c)['equals'](_0x312795['getChild'](_0x28db4c))&&_0x1b812d['isEmpty']()===_0x312795['isEmpty']()||(_0x510c69!=null&&(_0x312795['isEmpty']()?_0x4b2e87['hasChild'](_0x437f6a)?_0x510c69['trackChildChange'](Ot(_0x437f6a,_0x1b812d)):f(_0x4b2e87['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x1b812d['isEmpty']()?_0x510c69['trackChildChange'](et(_0x437f6a,_0x312795)):_0x510c69['trackChildChange'](Dt(_0x437f6a,_0x312795,_0x1b812d))),_0x4b2e87['isLeafNode']()&&_0x312795['isEmpty']())?_0x4b2e87:_0x4b2e87['updateImmediateChild'](_0x437f6a,_0x312795)['withIndex'](this['index_']);}['updateFullNode'](_0x561bcb,_0x31449a,_0x52f78c){return _0x52f78c!=null&&(_0x561bcb['isLeafNode']()||_0x561bcb['forEachChild'](R,(_0xbd3b69,_0x333d4c)=>{_0x31449a['hasChild'](_0xbd3b69)||_0x52f78c['trackChildChange'](Ot(_0xbd3b69,_0x333d4c));}),_0x31449a['isLeafNode']()||_0x31449a['forEachChild'](R,(_0x40fd37,_0x224160)=>{if(_0x561bcb['hasChild'](_0x40fd37)){const _0x3f5072=_0x561bcb['getImmediateChild'](_0x40fd37);_0x3f5072['equals'](_0x224160)||_0x52f78c['trackChildChange'](Dt(_0x40fd37,_0x224160,_0x3f5072));}else _0x52f78c['trackChildChange'](et(_0x40fd37,_0x224160));})),_0x31449a['withIndex'](this['index_']);}['updatePriority'](_0x16d8be,_0x4cb729){return _0x16d8be['isEmpty']()?g['EMPTY_NODE']:_0x16d8be['updatePriority'](_0x4cb729);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x37bd85){this['indexedFilter_']=new Ji(_0x37bd85['getIndex']()),this['index_']=_0x37bd85['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x37bd85),this['endPost_']=Mt['getEndPost_'](_0x37bd85),this['startIsInclusive_']=!_0x37bd85['startAfterSet_'],this['endIsInclusive_']=!_0x37bd85['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x35f557){const _0x207e61=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x35f557)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x35f557)<0x0,_0x266e64=this['endIsInclusive_']?this['index_']['compare'](_0x35f557,this['getEndPost']())<=0x0:this['index_']['compare'](_0x35f557,this['getEndPost']())<0x0;return _0x207e61&&_0x266e64;}['updateChild'](_0x426f66,_0x3b3bc0,_0x1e79a1,_0x23cf01,_0x4a28ee,_0x39b663){return this['matches'](new E(_0x3b3bc0,_0x1e79a1))||(_0x1e79a1=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x426f66,_0x3b3bc0,_0x1e79a1,_0x23cf01,_0x4a28ee,_0x39b663);}['updateFullNode'](_0x1969c8,_0x38a403,_0x186fa8){_0x38a403['isLeafNode']()&&(_0x38a403=g['EMPTY_NODE']);let _0x2d997b=_0x38a403['withIndex'](this['index_']);_0x2d997b=_0x2d997b['updatePriority'](g['EMPTY_NODE']);const _0x57851d=this;return _0x38a403['forEachChild'](R,(_0x1220fc,_0x4ffb17)=>{_0x57851d['matches'](new E(_0x1220fc,_0x4ffb17))||(_0x2d997b=_0x2d997b['updateImmediateChild'](_0x1220fc,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1969c8,_0x2d997b,_0x186fa8);}['updatePriority'](_0x4242b8,_0x36c8e5){return _0x4242b8;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x1b04a1){if(_0x1b04a1['hasStart']()){const _0x2198f9=_0x1b04a1['getIndexStartName']();return _0x1b04a1['getIndex']()['makePost'](_0x1b04a1['getIndexStartValue'](),_0x2198f9);}else return _0x1b04a1['getIndex']()['minPost']();}static['getEndPost_'](_0x2b5020){if(_0x2b5020['hasEnd']()){const _0x2530d6=_0x2b5020['getIndexEndName']();return _0x2b5020['getIndex']()['makePost'](_0x2b5020['getIndexEndValue'](),_0x2530d6);}else return _0x2b5020['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x4bedf9){this['withinDirectionalStart']=_0x567aaf=>this['reverse_']?this['withinEndPost'](_0x567aaf):this['withinStartPost'](_0x567aaf),this['withinDirectionalEnd']=_0x4823a5=>this['reverse_']?this['withinStartPost'](_0x4823a5):this['withinEndPost'](_0x4823a5),this['withinStartPost']=_0x4017bf=>{const _0x9ceacc=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x4017bf);return this['startIsInclusive_']?_0x9ceacc<=0x0:_0x9ceacc<0x0;},this['withinEndPost']=_0x5ef38f=>{const _0x31a949=this['index_']['compare'](_0x5ef38f,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x31a949<=0x0:_0x31a949<0x0;},this['rangedFilter_']=new Mt(_0x4bedf9),this['index_']=_0x4bedf9['getIndex'](),this['limit_']=_0x4bedf9['getLimit'](),this['reverse_']=!_0x4bedf9['isViewFromLeft'](),this['startIsInclusive_']=!_0x4bedf9['startAfterSet_'],this['endIsInclusive_']=!_0x4bedf9['endBeforeSet_'];}['updateChild'](_0x574f95,_0x5733bb,_0x5a1aee,_0x3a5752,_0x3da114,_0x14a38d){return this['rangedFilter_']['matches'](new E(_0x5733bb,_0x5a1aee))||(_0x5a1aee=g['EMPTY_NODE']),_0x574f95['getImmediateChild'](_0x5733bb)['equals'](_0x5a1aee)?_0x574f95:_0x574f95['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x574f95,_0x5733bb,_0x5a1aee,_0x3a5752,_0x3da114,_0x14a38d):this['fullLimitUpdateChild_'](_0x574f95,_0x5733bb,_0x5a1aee,_0x3da114,_0x14a38d);}['updateFullNode'](_0x590c70,_0x51aff8,_0x33673f){let _0x1762df;if(_0x51aff8['isLeafNode']()||_0x51aff8['isEmpty']())_0x1762df=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x51aff8['numChildren']()&&_0x51aff8['isIndexed'](this['index_'])){_0x1762df=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x507cb4;this['reverse_']?_0x507cb4=_0x51aff8['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x507cb4=_0x51aff8['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x151831=0x0;for(;_0x507cb4['hasNext']()&&_0x151831<this['limit_'];){const _0x1949bf=_0x507cb4['getNext']();if(this['withinDirectionalStart'](_0x1949bf)){if(this['withinDirectionalEnd'](_0x1949bf))_0x1762df=_0x1762df['updateImmediateChild'](_0x1949bf['name'],_0x1949bf['node']),_0x151831++;else break;}else continue;}}else{_0x1762df=_0x51aff8['withIndex'](this['index_']),_0x1762df=_0x1762df['updatePriority'](g['EMPTY_NODE']);let _0x5a08a1;this['reverse_']?_0x5a08a1=_0x1762df['getReverseIterator'](this['index_']):_0x5a08a1=_0x1762df['getIterator'](this['index_']);let _0x177fa5=0x0;for(;_0x5a08a1['hasNext']();){const _0x4ab94b=_0x5a08a1['getNext']();_0x177fa5<this['limit_']&&this['withinDirectionalStart'](_0x4ab94b)&&this['withinDirectionalEnd'](_0x4ab94b)?_0x177fa5++:_0x1762df=_0x1762df['updateImmediateChild'](_0x4ab94b['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x590c70,_0x1762df,_0x33673f);}['updatePriority'](_0x52db3e,_0x19b830){return _0x52db3e;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x232d2e,_0x48d171,_0x331e1e,_0x336450,_0x3fb54e){let _0x21ec51;if(this['reverse_']){const _0x251bf7=this['index_']['getCompare']();_0x21ec51=(_0x4fa0b7,_0x11628f)=>_0x251bf7(_0x11628f,_0x4fa0b7);}else _0x21ec51=this['index_']['getCompare']();const _0x59b931=_0x232d2e;f(_0x59b931['numChildren']()===this['limit_'],'');const _0xb9b468=new E(_0x48d171,_0x331e1e),_0x84474c=this['reverse_']?_0x59b931['getFirstChild'](this['index_']):_0x59b931['getLastChild'](this['index_']),_0x31dc5e=this['rangedFilter_']['matches'](_0xb9b468);if(_0x59b931['hasChild'](_0x48d171)){const _0x16bd38=_0x59b931['getImmediateChild'](_0x48d171);let _0xc8deac=_0x336450['getChildAfterChild'](this['index_'],_0x84474c,this['reverse_']);for(;_0xc8deac!=null&&(_0xc8deac['name']===_0x48d171||_0x59b931['hasChild'](_0xc8deac['name']));)_0xc8deac=_0x336450['getChildAfterChild'](this['index_'],_0xc8deac,this['reverse_']);const _0x37f682=_0xc8deac==null?0x1:_0x21ec51(_0xc8deac,_0xb9b468);if(_0x31dc5e&&!_0x331e1e['isEmpty']()&&_0x37f682>=0x0)return _0x3fb54e!=null&&_0x3fb54e['trackChildChange'](Dt(_0x48d171,_0x331e1e,_0x16bd38)),_0x59b931['updateImmediateChild'](_0x48d171,_0x331e1e);{_0x3fb54e!=null&&_0x3fb54e['trackChildChange'](Ot(_0x48d171,_0x16bd38));const _0x2e6aa3=_0x59b931['updateImmediateChild'](_0x48d171,g['EMPTY_NODE']);return _0xc8deac!=null&&this['rangedFilter_']['matches'](_0xc8deac)?(_0x3fb54e!=null&&_0x3fb54e['trackChildChange'](et(_0xc8deac['name'],_0xc8deac['node'])),_0x2e6aa3['updateImmediateChild'](_0xc8deac['name'],_0xc8deac['node'])):_0x2e6aa3;}}else return _0x331e1e['isEmpty']()?_0x232d2e:_0x31dc5e&&_0x21ec51(_0x84474c,_0xb9b468)>=0x0?(_0x3fb54e!=null&&(_0x3fb54e['trackChildChange'](Ot(_0x84474c['name'],_0x84474c['node'])),_0x3fb54e['trackChildChange'](et(_0x48d171,_0x331e1e))),_0x59b931['updateImmediateChild'](_0x48d171,_0x331e1e)['updateImmediateChild'](_0x84474c['name'],g['EMPTY_NODE'])):_0x232d2e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x35cf2f=new Xi();return _0x35cf2f['limitSet_']=this['limitSet_'],_0x35cf2f['limit_']=this['limit_'],_0x35cf2f['startSet_']=this['startSet_'],_0x35cf2f['startAfterSet_']=this['startAfterSet_'],_0x35cf2f['indexStartValue_']=this['indexStartValue_'],_0x35cf2f['startNameSet_']=this['startNameSet_'],_0x35cf2f['indexStartName_']=this['indexStartName_'],_0x35cf2f['endSet_']=this['endSet_'],_0x35cf2f['endBeforeSet_']=this['endBeforeSet_'],_0x35cf2f['indexEndValue_']=this['indexEndValue_'],_0x35cf2f['endNameSet_']=this['endNameSet_'],_0x35cf2f['indexEndName_']=this['indexEndName_'],_0x35cf2f['index_']=this['index_'],_0x35cf2f['viewFrom_']=this['viewFrom_'],_0x35cf2f;}}function Kh(_0xe7af83){return _0xe7af83['loadsAllData']()?new Ji(_0xe7af83['getIndex']()):_0xe7af83['hasLimit']()?new jh(_0xe7af83):new Mt(_0xe7af83);}function Yh(_0x2cb7ce,_0x556195){const _0x1247db=_0x2cb7ce['copy']();return _0x1247db['limitSet_']=!0x0,_0x1247db['limit_']=_0x556195,_0x1247db['viewFrom_']='l',_0x1247db;}function Qh(_0x28e979,_0x287b0a,_0x3824c8){const _0x110c1f=_0x28e979['copy']();return _0x110c1f['startSet_']=!0x0,_0x287b0a===void 0x0&&(_0x287b0a=null),_0x110c1f['indexStartValue_']=_0x287b0a,_0x3824c8!=null?(_0x110c1f['startNameSet_']=!0x0,_0x110c1f['indexStartName_']=_0x3824c8):(_0x110c1f['startNameSet_']=!0x1,_0x110c1f['indexStartName_']=''),_0x110c1f;}function Jh(_0x4ddf3b,_0x4bfb15,_0x4ed7de){const _0x5297fd=_0x4ddf3b['copy']();return _0x5297fd['endSet_']=!0x0,_0x4bfb15===void 0x0&&(_0x4bfb15=null),_0x5297fd['indexEndValue_']=_0x4bfb15,_0x4ed7de!==void 0x0?(_0x5297fd['endNameSet_']=!0x0,_0x5297fd['indexEndName_']=_0x4ed7de):(_0x5297fd['endNameSet_']=!0x1,_0x5297fd['indexEndName_']=''),_0x5297fd;}function xo(_0x4fa980,_0x574fa8){const _0x341ed8=_0x4fa980['copy']();return _0x341ed8['index_']=_0x574fa8,_0x341ed8;}function sr(_0x30e7fb){const _0x30ef40={};if(_0x30e7fb['isDefault']())return _0x30ef40;let _0x20151f;if(_0x30e7fb['index_']===R?_0x20151f='$priority':_0x30e7fb['index_']===Mo?_0x20151f='$value':_0x30e7fb['index_']===ye?_0x20151f='$key':(f(_0x30e7fb['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x20151f=_0x30e7fb['index_']['toString']()),_0x30ef40['orderBy']=O(_0x20151f),_0x30e7fb['startSet_']){const _0x1a3b68=_0x30e7fb['startAfterSet_']?'startAfter':'startAt';_0x30ef40[_0x1a3b68]=O(_0x30e7fb['indexStartValue_']),_0x30e7fb['startNameSet_']&&(_0x30ef40[_0x1a3b68]+=','+O(_0x30e7fb['indexStartName_']));}if(_0x30e7fb['endSet_']){const _0x34f995=_0x30e7fb['endBeforeSet_']?'endBefore':'endAt';_0x30ef40[_0x34f995]=O(_0x30e7fb['indexEndValue_']),_0x30e7fb['endNameSet_']&&(_0x30ef40[_0x34f995]+=','+O(_0x30e7fb['indexEndName_']));}return _0x30e7fb['limitSet_']&&(_0x30e7fb['isViewFromLeft']()?_0x30ef40['limitToFirst']=_0x30e7fb['limit_']:_0x30ef40['limitToLast']=_0x30e7fb['limit_']),_0x30ef40;}function rr(_0x2651aa){const _0x39b48c={};if(_0x2651aa['startSet_']&&(_0x39b48c['sp']=_0x2651aa['indexStartValue_'],_0x2651aa['startNameSet_']&&(_0x39b48c['sn']=_0x2651aa['indexStartName_']),_0x39b48c['sin']=!_0x2651aa['startAfterSet_']),_0x2651aa['endSet_']&&(_0x39b48c['ep']=_0x2651aa['indexEndValue_'],_0x2651aa['endNameSet_']&&(_0x39b48c['en']=_0x2651aa['indexEndName_']),_0x39b48c['ein']=!_0x2651aa['endBeforeSet_']),_0x2651aa['limitSet_']){_0x39b48c['l']=_0x2651aa['limit_'];let _0x1f3b04=_0x2651aa['viewFrom_'];_0x1f3b04===''&&(_0x2651aa['isViewFromLeft']()?_0x1f3b04='l':_0x1f3b04='r'),_0x39b48c['vf']=_0x1f3b04;}return _0x2651aa['index_']!==R&&(_0x39b48c['i']=_0x2651aa['index_']['toString']()),_0x39b48c;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x3284c1){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x388d93,_0x4999fb){return _0x4999fb!==void 0x0?'tag$'+_0x4999fb:(f(_0x388d93['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x388d93['_path']['toString']());}constructor(_0x336ced,_0x367765,_0x29a1d0,_0x39d17a){super(),this['repoInfo_']=_0x336ced,this['onDataUpdate_']=_0x367765,this['authTokenProvider_']=_0x29a1d0,this['appCheckTokenProvider_']=_0x39d17a,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x88d365,_0x1c0b1c,_0xfe6a09,_0x4df4a2){const _0x1907ed=_0x88d365['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1907ed+'\x20'+_0x88d365['_queryIdentifier']);const _0x5f3c7a=pn['getListenId_'](_0x88d365,_0xfe6a09),_0x2bbac4={};this['listens_'][_0x5f3c7a]=_0x2bbac4;const _0x42ad27=sr(_0x88d365['_queryParams']);this['restRequest_'](_0x1907ed+'.json',_0x42ad27,(_0x403b85,_0x273ca2)=>{let _0x5d851f=_0x273ca2;if(_0x403b85===0x194&&(_0x5d851f=null,_0x403b85=null),_0x403b85===null&&this['onDataUpdate_'](_0x1907ed,_0x5d851f,!0x1,_0xfe6a09),De(this['listens_'],_0x5f3c7a)===_0x2bbac4){let _0x5af5f6;_0x403b85?_0x403b85===0x191?_0x5af5f6='permission_denied':_0x5af5f6='rest_error:'+_0x403b85:_0x5af5f6='ok',_0x4df4a2(_0x5af5f6,null);}});}['unlisten'](_0x3a05d0,_0x3adffd){const _0x467af5=pn['getListenId_'](_0x3a05d0,_0x3adffd);delete this['listens_'][_0x467af5];}['get'](_0x6fdd03){const _0x2d7b47=sr(_0x6fdd03['_queryParams']),_0x36d10d=_0x6fdd03['_path']['toString'](),_0x16e1df=new ot();return this['restRequest_'](_0x36d10d+'.json',_0x2d7b47,(_0x3b3510,_0x344045)=>{let _0x310763=_0x344045;_0x3b3510===0x194&&(_0x310763=null,_0x3b3510=null),_0x3b3510===null?(this['onDataUpdate_'](_0x36d10d,_0x310763,!0x1,null),_0x16e1df['resolve'](_0x310763)):_0x16e1df['reject'](new Error(_0x310763));}),_0x16e1df['promise'];}['refreshAuthToken'](_0x291e62){}['restRequest_'](_0x502474,_0x2da24a={},_0x79ab7e){return _0x2da24a['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x7a552c,_0x2f927b])=>{_0x7a552c&&_0x7a552c['accessToken']&&(_0x2da24a['auth']=_0x7a552c['accessToken']),_0x2f927b&&_0x2f927b['token']&&(_0x2da24a['ac']=_0x2f927b['token']);const _0x43afd2=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x502474+'?ns='+this['repoInfo_']['namespace']+ct(_0x2da24a);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x43afd2);const _0x12cd0b=new XMLHttpRequest();_0x12cd0b['onreadystatechange']=()=>{if(_0x79ab7e&&_0x12cd0b['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x43afd2+'\x20received.\x20status:',_0x12cd0b['status'],'response:',_0x12cd0b['responseText']);let _0x12f8e6=null;if(_0x12cd0b['status']>=0xc8&&_0x12cd0b['status']<0x12c){try{_0x12f8e6=At(_0x12cd0b['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x43afd2+':\x20'+_0x12cd0b['responseText']);}_0x79ab7e(null,_0x12f8e6);}else _0x12cd0b['status']!==0x191&&_0x12cd0b['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x43afd2+'\x20Status:\x20'+_0x12cd0b['status']),_0x79ab7e(_0x12cd0b['status']);_0x79ab7e=null;}},_0x12cd0b['open']('GET',_0x43afd2,!0x0),_0x12cd0b['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x8cac34){return this['rootNode_']['getChild'](_0x8cac34);}['updateSnapshot'](_0x56b71c,_0x171f98){this['rootNode_']=this['rootNode_']['updateChild'](_0x56b71c,_0x171f98);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x3365e6,_0x29762c,_0x3ad304){if(v(_0x29762c))_0x3365e6['value']=_0x3ad304,_0x3365e6['children']['clear']();else{if(_0x3365e6['value']!==null)_0x3365e6['value']=_0x3365e6['value']['updateChild'](_0x29762c,_0x3ad304);else{const _0xb3ec40=y(_0x29762c);_0x3365e6['children']['has'](_0xb3ec40)||_0x3365e6['children']['set'](_0xb3ec40,_n());const _0x41f05b=_0x3365e6['children']['get'](_0xb3ec40);_0x29762c=b(_0x29762c),Fo(_0x41f05b,_0x29762c,_0x3ad304);}}}function Ii(_0xc39085,_0x8ef9e8,_0x323396){_0xc39085['value']!==null?_0x323396(_0x8ef9e8,_0xc39085['value']):Zh(_0xc39085,(_0x3603ed,_0x1f1443)=>{const _0x48b3bf=new C(_0x8ef9e8['toString']()+'/'+_0x3603ed);Ii(_0x1f1443,_0x48b3bf,_0x323396);});}function Zh(_0x1b5cb1,_0x1efb0e){_0x1b5cb1['children']['forEach']((_0x8c33a2,_0x302cff)=>{_0x1efb0e(_0x302cff,_0x8c33a2);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x593861){this['collection_']=_0x593861,this['last_']=null;}['get'](){const _0x5e34ec=this['collection_']['get'](),_0x5ce043={..._0x5e34ec};return this['last_']&&x(this['last_'],(_0x170a70,_0x2ac4f4)=>{_0x5ce043[_0x170a70]=_0x5ce043[_0x170a70]-_0x2ac4f4;}),this['last_']=_0x5e34ec,_0x5ce043;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x2c8ee5,_0xeaffe){this['server_']=_0xeaffe,this['statsToReport_']={},this['statsListener_']=new eu(_0x2c8ee5);const _0x443a48=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x443a48));}['reportStats_'](){const _0x113dda=this['statsListener_']['get'](),_0x127433={};let _0x1981e8=!0x1;x(_0x113dda,(_0x3e5881,_0x1684dc)=>{_0x1684dc>0x0&&J(this['statsToReport_'],_0x3e5881)&&(_0x127433[_0x3e5881]=_0x1684dc,_0x1981e8=!0x0);}),_0x1981e8&&this['server_']['reportStats'](_0x127433),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x5765af){_0x5765af[_0x5765af['OVERWRITE']=0x0]='OVERWRITE',_0x5765af[_0x5765af['MERGE']=0x1]='MERGE',_0x5765af[_0x5765af['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x5765af[_0x5765af['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x4d60cb){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x4d60cb,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x1b23af,_0x10adf9,_0x42516f){this['path']=_0x1b23af,this['affectedTree']=_0x10adf9,this['revert']=_0x42516f,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x3c2cf3){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x2631fa=this['affectedTree']['subtree'](new C(_0x3c2cf3));return new gn(w(),_0x2631fa,this['revert']);}}else return f(y(this['path'])===_0x3c2cf3,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x643302,_0x23f17b){this['source']=_0x643302,this['path']=_0x23f17b,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x24c088){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x3bed42,_0x529f2f,_0x1f8a86){this['source']=_0x3bed42,this['path']=_0x529f2f,this['snap']=_0x1f8a86,this['type']=j['OVERWRITE'];}['operationForChild'](_0x295819){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x295819)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0xaf99c1,_0x350da8,_0x4a7965){this['source']=_0xaf99c1,this['path']=_0x350da8,this['children']=_0x4a7965,this['type']=j['MERGE'];}['operationForChild'](_0x33a0e1){if(v(this['path'])){const _0x595c8d=this['children']['subtree'](new C(_0x33a0e1));return _0x595c8d['isEmpty']()?null:_0x595c8d['value']?new Ue(this['source'],w(),_0x595c8d['value']):new tt(this['source'],w(),_0x595c8d);}else return f(y(this['path'])===_0x33a0e1,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x1b8a80,_0x146d3e,_0x30c963){this['node_']=_0x1b8a80,this['fullyInitialized_']=_0x146d3e,this['filtered_']=_0x30c963;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x56c75f){if(v(_0x56c75f))return this['isFullyInitialized']()&&!this['filtered_'];const _0x3ec424=y(_0x56c75f);return this['isCompleteForChild'](_0x3ec424);}['isCompleteForChild'](_0x42535c){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x42535c);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x5e449c){this['query_']=_0x5e449c,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x14260a,_0x2eaf6d,_0x3249e1,_0x4cbe48){const _0x1247fe=[],_0x4c13b2=[];return _0x2eaf6d['forEach'](_0x5ca226=>{_0x5ca226['type']==='child_changed'&&_0x14260a['index_']['indexedValueChanged'](_0x5ca226['oldSnap'],_0x5ca226['snapshotNode'])&&_0x4c13b2['push'](zh(_0x5ca226['childName'],_0x5ca226['snapshotNode']));}),yt(_0x14260a,_0x1247fe,'child_removed',_0x2eaf6d,_0x4cbe48,_0x3249e1),yt(_0x14260a,_0x1247fe,'child_added',_0x2eaf6d,_0x4cbe48,_0x3249e1),yt(_0x14260a,_0x1247fe,'child_moved',_0x4c13b2,_0x4cbe48,_0x3249e1),yt(_0x14260a,_0x1247fe,'child_changed',_0x2eaf6d,_0x4cbe48,_0x3249e1),yt(_0x14260a,_0x1247fe,'value',_0x2eaf6d,_0x4cbe48,_0x3249e1),_0x1247fe;}function yt(_0x142769,_0x3a9bd7,_0x19281b,_0x30903b,_0x4ec282,_0x86d80c){const _0x283e54=_0x30903b['filter'](_0x55b96a=>_0x55b96a['type']===_0x19281b);_0x283e54['sort']((_0x1fbb7f,_0x10d955)=>au(_0x142769,_0x1fbb7f,_0x10d955)),_0x283e54['forEach'](_0x473061=>{const _0x1ad7c6=ou(_0x142769,_0x473061,_0x86d80c);_0x4ec282['forEach'](_0x46e871=>{_0x46e871['respondsTo'](_0x473061['type'])&&_0x3a9bd7['push'](_0x46e871['createEvent'](_0x1ad7c6,_0x142769['query_']));});});}function ou(_0x20a54a,_0x3dc3de,_0x165398){return _0x3dc3de['type']==='value'||_0x3dc3de['type']==='child_removed'||(_0x3dc3de['prevName']=_0x165398['getPredecessorChildName'](_0x3dc3de['childName'],_0x3dc3de['snapshotNode'],_0x20a54a['index_'])),_0x3dc3de;}function au(_0x3e2229,_0x129d6d,_0x21fbaf){if(_0x129d6d['childName']==null||_0x21fbaf['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x5c0c97=new E(_0x129d6d['childName'],_0x129d6d['snapshotNode']),_0x49b3ed=new E(_0x21fbaf['childName'],_0x21fbaf['snapshotNode']);return _0x3e2229['index_']['compare'](_0x5c0c97,_0x49b3ed);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x4fb542,_0x19603c){return{'eventCache':_0x4fb542,'serverCache':_0x19603c};}function Tt(_0x51529e,_0x5aec2c,_0x753e38,_0x5f1ce4){return Mn(new Ce(_0x5aec2c,_0x753e38,_0x5f1ce4),_0x51529e['serverCache']);}function Uo(_0x592ead,_0x5428ba,_0x2a9fc3,_0x49f762){return Mn(_0x592ead['eventCache'],new Ce(_0x5428ba,_0x2a9fc3,_0x49f762));}function mn(_0x160579){return _0x160579['eventCache']['isFullyInitialized']()?_0x160579['eventCache']['getNode']():null;}function We(_0x599ae8){return _0x599ae8['serverCache']['isFullyInitialized']()?_0x599ae8['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x447ff5){let _0x2cf13a=new S(null);return x(_0x447ff5,(_0xb03e61,_0x27717c)=>{_0x2cf13a=_0x2cf13a['set'](new C(_0xb03e61),_0x27717c);}),_0x2cf13a;}constructor(_0x1c8bf4,_0x151dbc=cu()){this['value']=_0x1c8bf4,this['children']=_0x151dbc;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x5ee9df,_0x47a978){if(this['value']!=null&&_0x47a978(this['value']))return{'path':w(),'value':this['value']};if(v(_0x5ee9df))return null;{const _0x299f63=y(_0x5ee9df),_0xf4746=this['children']['get'](_0x299f63);if(_0xf4746!==null){const _0x4b95ef=_0xf4746['findRootMostMatchingPathAndValue'](b(_0x5ee9df),_0x47a978);return _0x4b95ef!=null?{'path':k(new C(_0x299f63),_0x4b95ef['path']),'value':_0x4b95ef['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x1be35c){return this['findRootMostMatchingPathAndValue'](_0x1be35c,()=>!0x0);}['subtree'](_0x3d617c){if(v(_0x3d617c))return this;{const _0x29ab17=y(_0x3d617c),_0x4f1a70=this['children']['get'](_0x29ab17);return _0x4f1a70!==null?_0x4f1a70['subtree'](b(_0x3d617c)):new S(null);}}['set'](_0x5929c4,_0x587370){if(v(_0x5929c4))return new S(_0x587370,this['children']);{const _0x1f6cac=y(_0x5929c4),_0x5d7dcb=(this['children']['get'](_0x1f6cac)||new S(null))['set'](b(_0x5929c4),_0x587370),_0x59060a=this['children']['insert'](_0x1f6cac,_0x5d7dcb);return new S(this['value'],_0x59060a);}}['remove'](_0x35e8fd){if(v(_0x35e8fd))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x565080=y(_0x35e8fd),_0x554710=this['children']['get'](_0x565080);if(_0x554710){const _0x2cd2fe=_0x554710['remove'](b(_0x35e8fd));let _0x23894d;return _0x2cd2fe['isEmpty']()?_0x23894d=this['children']['remove'](_0x565080):_0x23894d=this['children']['insert'](_0x565080,_0x2cd2fe),this['value']===null&&_0x23894d['isEmpty']()?new S(null):new S(this['value'],_0x23894d);}else return this;}}['get'](_0x46d892){if(v(_0x46d892))return this['value'];{const _0x48d38d=y(_0x46d892),_0x34f019=this['children']['get'](_0x48d38d);return _0x34f019?_0x34f019['get'](b(_0x46d892)):null;}}['setTree'](_0x511f73,_0x390ab5){if(v(_0x511f73))return _0x390ab5;{const _0x5d6148=y(_0x511f73),_0x47a43b=(this['children']['get'](_0x5d6148)||new S(null))['setTree'](b(_0x511f73),_0x390ab5);let _0x5adb9e;return _0x47a43b['isEmpty']()?_0x5adb9e=this['children']['remove'](_0x5d6148):_0x5adb9e=this['children']['insert'](_0x5d6148,_0x47a43b),new S(this['value'],_0x5adb9e);}}['fold'](_0x2f7683){return this['fold_'](w(),_0x2f7683);}['fold_'](_0x410a29,_0x41c493){const _0x5390ed={};return this['children']['inorderTraversal']((_0x2f132f,_0x16d176)=>{_0x5390ed[_0x2f132f]=_0x16d176['fold_'](k(_0x410a29,_0x2f132f),_0x41c493);}),_0x41c493(_0x410a29,this['value'],_0x5390ed);}['findOnPath'](_0x24cdec,_0x2f3d50){return this['findOnPath_'](_0x24cdec,w(),_0x2f3d50);}['findOnPath_'](_0x2f708b,_0x9b4981,_0x4ed460){const _0xa75b4b=this['value']?_0x4ed460(_0x9b4981,this['value']):!0x1;if(_0xa75b4b)return _0xa75b4b;if(v(_0x2f708b))return null;{const _0x203823=y(_0x2f708b),_0x98d0c8=this['children']['get'](_0x203823);return _0x98d0c8?_0x98d0c8['findOnPath_'](b(_0x2f708b),k(_0x9b4981,_0x203823),_0x4ed460):null;}}['foreachOnPath'](_0x10efc0,_0x3f6f22){return this['foreachOnPath_'](_0x10efc0,w(),_0x3f6f22);}['foreachOnPath_'](_0xfc8c06,_0x1da95f,_0xb129aa){if(v(_0xfc8c06))return this;{this['value']&&_0xb129aa(_0x1da95f,this['value']);const _0x22d810=y(_0xfc8c06),_0x25c386=this['children']['get'](_0x22d810);return _0x25c386?_0x25c386['foreachOnPath_'](b(_0xfc8c06),k(_0x1da95f,_0x22d810),_0xb129aa):new S(null);}}['foreach'](_0x515243){this['foreach_'](w(),_0x515243);}['foreach_'](_0x2734d1,_0x3ce47a){this['children']['inorderTraversal']((_0x270e89,_0x300e44)=>{_0x300e44['foreach_'](k(_0x2734d1,_0x270e89),_0x3ce47a);}),this['value']&&_0x3ce47a(_0x2734d1,this['value']);}['foreachChild'](_0x55c211){this['children']['inorderTraversal']((_0x46fca7,_0x5c0abe)=>{_0x5c0abe['value']&&_0x55c211(_0x46fca7,_0x5c0abe['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x25c862){this['writeTree_']=_0x25c862;}static['empty'](){return new Y(new S(null));}}function St(_0x5c7e17,_0x384881,_0x1d0376){if(v(_0x384881))return new Y(new S(_0x1d0376));{const _0x485545=_0x5c7e17['writeTree_']['findRootMostValueAndPath'](_0x384881);if(_0x485545!=null){const _0x1f5ca5=_0x485545['path'];let _0x3f6f7a=_0x485545['value'];const _0x21c1a6=F(_0x1f5ca5,_0x384881);return _0x3f6f7a=_0x3f6f7a['updateChild'](_0x21c1a6,_0x1d0376),new Y(_0x5c7e17['writeTree_']['set'](_0x1f5ca5,_0x3f6f7a));}else{const _0x188856=new S(_0x1d0376),_0x37b388=_0x5c7e17['writeTree_']['setTree'](_0x384881,_0x188856);return new Y(_0x37b388);}}}function wi(_0xf6395b,_0x421c52,_0x1582aa){let _0xa12217=_0xf6395b;return x(_0x1582aa,(_0x4d8d0f,_0x3af769)=>{_0xa12217=St(_0xa12217,k(_0x421c52,_0x4d8d0f),_0x3af769);}),_0xa12217;}function ar(_0x40dcf9,_0x576e58){if(v(_0x576e58))return Y['empty']();{const _0xf106db=_0x40dcf9['writeTree_']['setTree'](_0x576e58,new S(null));return new Y(_0xf106db);}}function Ci(_0x494f18,_0x453868){return $e(_0x494f18,_0x453868)!=null;}function $e(_0x4dc13a,_0x271f2a){const _0x1cc2bb=_0x4dc13a['writeTree_']['findRootMostValueAndPath'](_0x271f2a);return _0x1cc2bb!=null?_0x4dc13a['writeTree_']['get'](_0x1cc2bb['path'])['getChild'](F(_0x1cc2bb['path'],_0x271f2a)):null;}function cr(_0x513c65){const _0x4e03b5=[],_0x327a53=_0x513c65['writeTree_']['value'];return _0x327a53!=null?_0x327a53['isLeafNode']()||_0x327a53['forEachChild'](R,(_0xb88510,_0xd7d908)=>{_0x4e03b5['push'](new E(_0xb88510,_0xd7d908));}):_0x513c65['writeTree_']['children']['inorderTraversal']((_0x339862,_0x2f713d)=>{_0x2f713d['value']!=null&&_0x4e03b5['push'](new E(_0x339862,_0x2f713d['value']));}),_0x4e03b5;}function ve(_0x3fc799,_0x3991ec){if(v(_0x3991ec))return _0x3fc799;{const _0x498f15=$e(_0x3fc799,_0x3991ec);return _0x498f15!=null?new Y(new S(_0x498f15)):new Y(_0x3fc799['writeTree_']['subtree'](_0x3991ec));}}function Ti(_0x3e1269){return _0x3e1269['writeTree_']['isEmpty']();}function nt(_0x366e57,_0x3e156c){return Wo(w(),_0x366e57['writeTree_'],_0x3e156c);}function Wo(_0x392778,_0x57bf61,_0x13ade1){if(_0x57bf61['value']!=null)return _0x13ade1['updateChild'](_0x392778,_0x57bf61['value']);{let _0x3067c0=null;return _0x57bf61['children']['inorderTraversal']((_0x8642a3,_0x4e8962)=>{_0x8642a3==='.priority'?(f(_0x4e8962['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x3067c0=_0x4e8962['value']):_0x13ade1=Wo(k(_0x392778,_0x8642a3),_0x4e8962,_0x13ade1);}),!_0x13ade1['getChild'](_0x392778)['isEmpty']()&&_0x3067c0!==null&&(_0x13ade1=_0x13ade1['updateChild'](k(_0x392778,'.priority'),_0x3067c0)),_0x13ade1;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x2de186,_0x3be4a6){return $o(_0x3be4a6,_0x2de186);}function lu(_0xeea7af,_0x2ef88d,_0x2e86f4,_0x36b620,_0x38ad96){f(_0x36b620>_0xeea7af['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x38ad96===void 0x0&&(_0x38ad96=!0x0),_0xeea7af['allWrites']['push']({'path':_0x2ef88d,'snap':_0x2e86f4,'writeId':_0x36b620,'visible':_0x38ad96}),_0x38ad96&&(_0xeea7af['visibleWrites']=St(_0xeea7af['visibleWrites'],_0x2ef88d,_0x2e86f4)),_0xeea7af['lastWriteId']=_0x36b620;}function hu(_0x1227e9,_0x383642,_0x41ce79,_0x5c2939){f(_0x5c2939>_0x1227e9['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x1227e9['allWrites']['push']({'path':_0x383642,'children':_0x41ce79,'writeId':_0x5c2939,'visible':!0x0}),_0x1227e9['visibleWrites']=wi(_0x1227e9['visibleWrites'],_0x383642,_0x41ce79),_0x1227e9['lastWriteId']=_0x5c2939;}function uu(_0x1a3292,_0x30a4a8){for(let _0x16c164=0x0;_0x16c164<_0x1a3292['allWrites']['length'];_0x16c164++){const _0x2a5e5f=_0x1a3292['allWrites'][_0x16c164];if(_0x2a5e5f['writeId']===_0x30a4a8)return _0x2a5e5f;}return null;}function du(_0x13190a,_0x47ed6e){const _0x3906b3=_0x13190a['allWrites']['findIndex'](_0x2325c7=>_0x2325c7['writeId']===_0x47ed6e);f(_0x3906b3>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x5bcf49=_0x13190a['allWrites'][_0x3906b3];_0x13190a['allWrites']['splice'](_0x3906b3,0x1);let _0x2ef295=_0x5bcf49['visible'],_0x5657e6=!0x1,_0x2d675e=_0x13190a['allWrites']['length']-0x1;for(;_0x2ef295&&_0x2d675e>=0x0;){const _0x4c5a79=_0x13190a['allWrites'][_0x2d675e];_0x4c5a79['visible']&&(_0x2d675e>=_0x3906b3&&fu(_0x4c5a79,_0x5bcf49['path'])?_0x2ef295=!0x1:G(_0x5bcf49['path'],_0x4c5a79['path'])&&(_0x5657e6=!0x0)),_0x2d675e--;}if(_0x2ef295){if(_0x5657e6)return pu(_0x13190a),!0x0;if(_0x5bcf49['snap'])_0x13190a['visibleWrites']=ar(_0x13190a['visibleWrites'],_0x5bcf49['path']);else{const _0xcac23a=_0x5bcf49['children'];x(_0xcac23a,_0xf92cbc=>{_0x13190a['visibleWrites']=ar(_0x13190a['visibleWrites'],k(_0x5bcf49['path'],_0xf92cbc));});}return!0x0;}else return!0x1;}function fu(_0x56f166,_0x206b67){if(_0x56f166['snap'])return G(_0x56f166['path'],_0x206b67);for(const _0x382cbe in _0x56f166['children'])if(_0x56f166['children']['hasOwnProperty'](_0x382cbe)&&G(k(_0x56f166['path'],_0x382cbe),_0x206b67))return!0x0;return!0x1;}function pu(_0x10f029){_0x10f029['visibleWrites']=Bo(_0x10f029['allWrites'],_u,w()),_0x10f029['allWrites']['length']>0x0?_0x10f029['lastWriteId']=_0x10f029['allWrites'][_0x10f029['allWrites']['length']-0x1]['writeId']:_0x10f029['lastWriteId']=-0x1;}function _u(_0x4e4680){return _0x4e4680['visible'];}function Bo(_0x365faf,_0x26b135,_0x172c53){let _0x45f9ea=Y['empty']();for(let _0x46cfb4=0x0;_0x46cfb4<_0x365faf['length'];++_0x46cfb4){const _0x50e558=_0x365faf[_0x46cfb4];if(_0x26b135(_0x50e558)){const _0x3cda4c=_0x50e558['path'];let _0x224462;if(_0x50e558['snap'])G(_0x172c53,_0x3cda4c)?(_0x224462=F(_0x172c53,_0x3cda4c),_0x45f9ea=St(_0x45f9ea,_0x224462,_0x50e558['snap'])):G(_0x3cda4c,_0x172c53)&&(_0x224462=F(_0x3cda4c,_0x172c53),_0x45f9ea=St(_0x45f9ea,w(),_0x50e558['snap']['getChild'](_0x224462)));else{if(_0x50e558['children']){if(G(_0x172c53,_0x3cda4c))_0x224462=F(_0x172c53,_0x3cda4c),_0x45f9ea=wi(_0x45f9ea,_0x224462,_0x50e558['children']);else{if(G(_0x3cda4c,_0x172c53)){if(_0x224462=F(_0x3cda4c,_0x172c53),v(_0x224462))_0x45f9ea=wi(_0x45f9ea,w(),_0x50e558['children']);else{const _0x1cd35f=De(_0x50e558['children'],y(_0x224462));if(_0x1cd35f){const _0x4b66a6=_0x1cd35f['getChild'](b(_0x224462));_0x45f9ea=St(_0x45f9ea,w(),_0x4b66a6);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x45f9ea;}function Vo(_0x8b3036,_0x5960e7,_0x2558af,_0x4064d6,_0x34825e){if(!_0x4064d6&&!_0x34825e){const _0x27be4d=$e(_0x8b3036['visibleWrites'],_0x5960e7);if(_0x27be4d!=null)return _0x27be4d;{const _0x51a6aa=ve(_0x8b3036['visibleWrites'],_0x5960e7);if(Ti(_0x51a6aa))return _0x2558af;if(_0x2558af==null&&!Ci(_0x51a6aa,w()))return null;{const _0x54203a=_0x2558af||g['EMPTY_NODE'];return nt(_0x51a6aa,_0x54203a);}}}else{const _0x2e9547=ve(_0x8b3036['visibleWrites'],_0x5960e7);if(!_0x34825e&&Ti(_0x2e9547))return _0x2558af;if(!_0x34825e&&_0x2558af==null&&!Ci(_0x2e9547,w()))return null;{const _0x1b8da2=function(_0x592e09){return(_0x592e09['visible']||_0x34825e)&&(!_0x4064d6||!~_0x4064d6['indexOf'](_0x592e09['writeId']))&&(G(_0x592e09['path'],_0x5960e7)||G(_0x5960e7,_0x592e09['path']));},_0x2dec39=Bo(_0x8b3036['allWrites'],_0x1b8da2,_0x5960e7),_0x157298=_0x2558af||g['EMPTY_NODE'];return nt(_0x2dec39,_0x157298);}}}function gu(_0x2d76a7,_0xaabc4e,_0x40d7c9){let _0x34488c=g['EMPTY_NODE'];const _0x18ef82=$e(_0x2d76a7['visibleWrites'],_0xaabc4e);if(_0x18ef82)return _0x18ef82['isLeafNode']()||_0x18ef82['forEachChild'](R,(_0x18d274,_0x4df1ff)=>{_0x34488c=_0x34488c['updateImmediateChild'](_0x18d274,_0x4df1ff);}),_0x34488c;if(_0x40d7c9){const _0x41c637=ve(_0x2d76a7['visibleWrites'],_0xaabc4e);return _0x40d7c9['forEachChild'](R,(_0x6417b0,_0x4b7462)=>{const _0x35b9a5=nt(ve(_0x41c637,new C(_0x6417b0)),_0x4b7462);_0x34488c=_0x34488c['updateImmediateChild'](_0x6417b0,_0x35b9a5);}),cr(_0x41c637)['forEach'](_0x23717d=>{_0x34488c=_0x34488c['updateImmediateChild'](_0x23717d['name'],_0x23717d['node']);}),_0x34488c;}else{const _0x3b879b=ve(_0x2d76a7['visibleWrites'],_0xaabc4e);return cr(_0x3b879b)['forEach'](_0x20603f=>{_0x34488c=_0x34488c['updateImmediateChild'](_0x20603f['name'],_0x20603f['node']);}),_0x34488c;}}function mu(_0x133f28,_0x23ca0a,_0x33fe38,_0x49e171,_0x5d2d8b){f(_0x49e171||_0x5d2d8b,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x56445e=k(_0x23ca0a,_0x33fe38);if(Ci(_0x133f28['visibleWrites'],_0x56445e))return null;{const _0x15e318=ve(_0x133f28['visibleWrites'],_0x56445e);return Ti(_0x15e318)?_0x5d2d8b['getChild'](_0x33fe38):nt(_0x15e318,_0x5d2d8b['getChild'](_0x33fe38));}}function yu(_0x1d4a7e,_0x132631,_0x378690,_0x484830){const _0x137853=k(_0x132631,_0x378690),_0x34dc1d=$e(_0x1d4a7e['visibleWrites'],_0x137853);if(_0x34dc1d!=null)return _0x34dc1d;if(_0x484830['isCompleteForChild'](_0x378690)){const _0x358b21=ve(_0x1d4a7e['visibleWrites'],_0x137853);return nt(_0x358b21,_0x484830['getNode']()['getImmediateChild'](_0x378690));}else return null;}function vu(_0x53f379,_0x1976b0){return $e(_0x53f379['visibleWrites'],_0x1976b0);}function Eu(_0xba1ead,_0x2bcaf4,_0x163eb2,_0x5cb822,_0x1b4391,_0x5c01c4,_0x586078){let _0x423a2e;const _0x411e2a=ve(_0xba1ead['visibleWrites'],_0x2bcaf4),_0x32e4e4=$e(_0x411e2a,w());if(_0x32e4e4!=null)_0x423a2e=_0x32e4e4;else{if(_0x163eb2!=null)_0x423a2e=nt(_0x411e2a,_0x163eb2);else return[];}if(_0x423a2e=_0x423a2e['withIndex'](_0x586078),!_0x423a2e['isEmpty']()&&!_0x423a2e['isLeafNode']()){const _0xfb4bbf=[],_0x130f1a=_0x586078['getCompare'](),_0x39bc3b=_0x5c01c4?_0x423a2e['getReverseIteratorFrom'](_0x5cb822,_0x586078):_0x423a2e['getIteratorFrom'](_0x5cb822,_0x586078);let _0x926de6=_0x39bc3b['getNext']();for(;_0x926de6&&_0xfb4bbf['length']<_0x1b4391;)_0x130f1a(_0x926de6,_0x5cb822)!==0x0&&_0xfb4bbf['push'](_0x926de6),_0x926de6=_0x39bc3b['getNext']();return _0xfb4bbf;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x35a65b,_0x4018df,_0x231314,_0x55daf8){return Vo(_0x35a65b['writeTree'],_0x35a65b['treePath'],_0x4018df,_0x231314,_0x55daf8);}function ns(_0x8236ae,_0x2f9fe8){return gu(_0x8236ae['writeTree'],_0x8236ae['treePath'],_0x2f9fe8);}function lr(_0x2e3ab2,_0x2e18a5,_0xbfcfd7,_0x32a8e9){return mu(_0x2e3ab2['writeTree'],_0x2e3ab2['treePath'],_0x2e18a5,_0xbfcfd7,_0x32a8e9);}function vn(_0x65bf5c,_0x57c3f1){return vu(_0x65bf5c['writeTree'],k(_0x65bf5c['treePath'],_0x57c3f1));}function wu(_0x20b17c,_0x25ce89,_0x1f540e,_0x350b2d,_0x2e2751,_0x2731f0){return Eu(_0x20b17c['writeTree'],_0x20b17c['treePath'],_0x25ce89,_0x1f540e,_0x350b2d,_0x2e2751,_0x2731f0);}function is(_0x60ebce,_0x2fd029,_0x74678b){return yu(_0x60ebce['writeTree'],_0x60ebce['treePath'],_0x2fd029,_0x74678b);}function Ho(_0x4925d0,_0x2b5400){return $o(k(_0x4925d0['treePath'],_0x2b5400),_0x4925d0['writeTree']);}function $o(_0x52013b,_0x31b05b){return{'treePath':_0x52013b,'writeTree':_0x31b05b};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x162b47){const _0x597637=_0x162b47['type'],_0x301cfa=_0x162b47['childName'];f(_0x597637==='child_added'||_0x597637==='child_changed'||_0x597637==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x301cfa!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x46b239=this['changeMap']['get'](_0x301cfa);if(_0x46b239){const _0x112352=_0x46b239['type'];if(_0x597637==='child_added'&&_0x112352==='child_removed')this['changeMap']['set'](_0x301cfa,Dt(_0x301cfa,_0x162b47['snapshotNode'],_0x46b239['snapshotNode']));else{if(_0x597637==='child_removed'&&_0x112352==='child_added')this['changeMap']['delete'](_0x301cfa);else{if(_0x597637==='child_removed'&&_0x112352==='child_changed')this['changeMap']['set'](_0x301cfa,Ot(_0x301cfa,_0x46b239['oldSnap']));else{if(_0x597637==='child_changed'&&_0x112352==='child_added')this['changeMap']['set'](_0x301cfa,et(_0x301cfa,_0x162b47['snapshotNode']));else{if(_0x597637==='child_changed'&&_0x112352==='child_changed')this['changeMap']['set'](_0x301cfa,Dt(_0x301cfa,_0x162b47['snapshotNode'],_0x46b239['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x162b47+'\x20occurred\x20after\x20'+_0x46b239);}}}}}else this['changeMap']['set'](_0x301cfa,_0x162b47);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0xcda0b5){return null;}['getChildAfterChild'](_0x60534a,_0xb9c341,_0x51f856){return null;}}const Go=new Tu();class ss{constructor(_0x3d7977,_0x48ce1d,_0x184f2f=null){this['writes_']=_0x3d7977,this['viewCache_']=_0x48ce1d,this['optCompleteServerCache_']=_0x184f2f;}['getCompleteChild'](_0x41da56){const _0x55437e=this['viewCache_']['eventCache'];if(_0x55437e['isCompleteForChild'](_0x41da56))return _0x55437e['getNode']()['getImmediateChild'](_0x41da56);{const _0x45d6b2=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x41da56,_0x45d6b2);}}['getChildAfterChild'](_0xdd72f7,_0x23c568,_0x4f953f){const _0x5adca9=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x480a1d=wu(this['writes_'],_0x5adca9,_0x23c568,0x1,_0x4f953f,_0xdd72f7);return _0x480a1d['length']===0x0?null:_0x480a1d[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x3ad645){return{'filter':_0x3ad645};}function bu(_0x2b29cd,_0x2b6109){f(_0x2b6109['eventCache']['getNode']()['isIndexed'](_0x2b29cd['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x2b6109['serverCache']['getNode']()['isIndexed'](_0x2b29cd['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x382fd7,_0x43e2ac,_0x327d1f,_0x122438,_0x54040d){const _0x4f2c43=new Cu();let _0xcdea6d,_0x43a06c;if(_0x327d1f['type']===j['OVERWRITE']){const _0x5db3da=_0x327d1f;_0x5db3da['source']['fromUser']?_0xcdea6d=Si(_0x382fd7,_0x43e2ac,_0x5db3da['path'],_0x5db3da['snap'],_0x122438,_0x54040d,_0x4f2c43):(f(_0x5db3da['source']['fromServer'],'Unknown\x20source.'),_0x43a06c=_0x5db3da['source']['tagged']||_0x43e2ac['serverCache']['isFiltered']()&&!v(_0x5db3da['path']),_0xcdea6d=En(_0x382fd7,_0x43e2ac,_0x5db3da['path'],_0x5db3da['snap'],_0x122438,_0x54040d,_0x43a06c,_0x4f2c43));}else{if(_0x327d1f['type']===j['MERGE']){const _0xac0805=_0x327d1f;_0xac0805['source']['fromUser']?_0xcdea6d=ku(_0x382fd7,_0x43e2ac,_0xac0805['path'],_0xac0805['children'],_0x122438,_0x54040d,_0x4f2c43):(f(_0xac0805['source']['fromServer'],'Unknown\x20source.'),_0x43a06c=_0xac0805['source']['tagged']||_0x43e2ac['serverCache']['isFiltered'](),_0xcdea6d=bi(_0x382fd7,_0x43e2ac,_0xac0805['path'],_0xac0805['children'],_0x122438,_0x54040d,_0x43a06c,_0x4f2c43));}else{if(_0x327d1f['type']===j['ACK_USER_WRITE']){const _0x416191=_0x327d1f;_0x416191['revert']?_0xcdea6d=Ou(_0x382fd7,_0x43e2ac,_0x416191['path'],_0x122438,_0x54040d,_0x4f2c43):_0xcdea6d=Nu(_0x382fd7,_0x43e2ac,_0x416191['path'],_0x416191['affectedTree'],_0x122438,_0x54040d,_0x4f2c43);}else{if(_0x327d1f['type']===j['LISTEN_COMPLETE'])_0xcdea6d=Pu(_0x382fd7,_0x43e2ac,_0x327d1f['path'],_0x122438,_0x4f2c43);else throw rt('Unknown\x20operation\x20type:\x20'+_0x327d1f['type']);}}}const _0x53ac73=_0x4f2c43['getChanges']();return Au(_0x43e2ac,_0xcdea6d,_0x53ac73),{'viewCache':_0xcdea6d,'changes':_0x53ac73};}function Au(_0x5cd251,_0x761c9,_0x1a32d0){const _0x1a1e30=_0x761c9['eventCache'];if(_0x1a1e30['isFullyInitialized']()){const _0x54f0b1=_0x1a1e30['getNode']()['isLeafNode']()||_0x1a1e30['getNode']()['isEmpty'](),_0x15adc3=mn(_0x5cd251);(_0x1a32d0['length']>0x0||!_0x5cd251['eventCache']['isFullyInitialized']()||_0x54f0b1&&!_0x1a1e30['getNode']()['equals'](_0x15adc3)||!_0x1a1e30['getNode']()['getPriority']()['equals'](_0x15adc3['getPriority']()))&&_0x1a32d0['push'](Lo(mn(_0x761c9)));}}function qo(_0x3015d5,_0x183cb6,_0x34d60c,_0x4e137b,_0x85d510,_0x414e3a){const _0x4eec05=_0x183cb6['eventCache'];if(vn(_0x4e137b,_0x34d60c)!=null)return _0x183cb6;{let _0x363105,_0x54d1f0;if(v(_0x34d60c)){if(f(_0x183cb6['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x183cb6['serverCache']['isFiltered']()){const _0xa22931=We(_0x183cb6),_0x1e7780=_0xa22931 instanceof g?_0xa22931:g['EMPTY_NODE'],_0x374ce5=ns(_0x4e137b,_0x1e7780);_0x363105=_0x3015d5['filter']['updateFullNode'](_0x183cb6['eventCache']['getNode'](),_0x374ce5,_0x414e3a);}else{const _0x702560=yn(_0x4e137b,We(_0x183cb6));_0x363105=_0x3015d5['filter']['updateFullNode'](_0x183cb6['eventCache']['getNode'](),_0x702560,_0x414e3a);}}else{const _0x429d0d=y(_0x34d60c);if(_0x429d0d==='.priority'){f(we(_0x34d60c)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0xd06cec=_0x4eec05['getNode']();_0x54d1f0=_0x183cb6['serverCache']['getNode']();const _0x32140c=lr(_0x4e137b,_0x34d60c,_0xd06cec,_0x54d1f0);_0x32140c!=null?_0x363105=_0x3015d5['filter']['updatePriority'](_0xd06cec,_0x32140c):_0x363105=_0x4eec05['getNode']();}else{const _0x1a5cf1=b(_0x34d60c);let _0x51cdbe;if(_0x4eec05['isCompleteForChild'](_0x429d0d)){_0x54d1f0=_0x183cb6['serverCache']['getNode']();const _0x4ede36=lr(_0x4e137b,_0x34d60c,_0x4eec05['getNode'](),_0x54d1f0);_0x4ede36!=null?_0x51cdbe=_0x4eec05['getNode']()['getImmediateChild'](_0x429d0d)['updateChild'](_0x1a5cf1,_0x4ede36):_0x51cdbe=_0x4eec05['getNode']()['getImmediateChild'](_0x429d0d);}else _0x51cdbe=is(_0x4e137b,_0x429d0d,_0x183cb6['serverCache']);_0x51cdbe!=null?_0x363105=_0x3015d5['filter']['updateChild'](_0x4eec05['getNode'](),_0x429d0d,_0x51cdbe,_0x1a5cf1,_0x85d510,_0x414e3a):_0x363105=_0x4eec05['getNode']();}}return Tt(_0x183cb6,_0x363105,_0x4eec05['isFullyInitialized']()||v(_0x34d60c),_0x3015d5['filter']['filtersNodes']());}}function En(_0x584df0,_0x303724,_0x30bd5a,_0x52f725,_0x2bd037,_0x1387ff,_0xecf4e6,_0xffd371){const _0x50f87a=_0x303724['serverCache'];let _0x58bdc9;const _0x4b3e42=_0xecf4e6?_0x584df0['filter']:_0x584df0['filter']['getIndexedFilter']();if(v(_0x30bd5a))_0x58bdc9=_0x4b3e42['updateFullNode'](_0x50f87a['getNode'](),_0x52f725,null);else{if(_0x4b3e42['filtersNodes']()&&!_0x50f87a['isFiltered']()){const _0xbaed42=_0x50f87a['getNode']()['updateChild'](_0x30bd5a,_0x52f725);_0x58bdc9=_0x4b3e42['updateFullNode'](_0x50f87a['getNode'](),_0xbaed42,null);}else{const _0x42940f=y(_0x30bd5a);if(!_0x50f87a['isCompleteForPath'](_0x30bd5a)&&we(_0x30bd5a)>0x1)return _0x303724;const _0x5ce1be=b(_0x30bd5a),_0x4bf2c4=_0x50f87a['getNode']()['getImmediateChild'](_0x42940f)['updateChild'](_0x5ce1be,_0x52f725);_0x42940f==='.priority'?_0x58bdc9=_0x4b3e42['updatePriority'](_0x50f87a['getNode'](),_0x4bf2c4):_0x58bdc9=_0x4b3e42['updateChild'](_0x50f87a['getNode'](),_0x42940f,_0x4bf2c4,_0x5ce1be,Go,null);}}const _0x474508=Uo(_0x303724,_0x58bdc9,_0x50f87a['isFullyInitialized']()||v(_0x30bd5a),_0x4b3e42['filtersNodes']()),_0x3d3b80=new ss(_0x2bd037,_0x474508,_0x1387ff);return qo(_0x584df0,_0x474508,_0x30bd5a,_0x2bd037,_0x3d3b80,_0xffd371);}function Si(_0xb616c0,_0x33db98,_0xf61feb,_0x58f95a,_0x5c2431,_0x1c8639,_0x18686c){const _0x4a7046=_0x33db98['eventCache'];let _0x1b13ec,_0x373c07;const _0x54916c=new ss(_0x5c2431,_0x33db98,_0x1c8639);if(v(_0xf61feb))_0x373c07=_0xb616c0['filter']['updateFullNode'](_0x33db98['eventCache']['getNode'](),_0x58f95a,_0x18686c),_0x1b13ec=Tt(_0x33db98,_0x373c07,!0x0,_0xb616c0['filter']['filtersNodes']());else{const _0x55c37d=y(_0xf61feb);if(_0x55c37d==='.priority')_0x373c07=_0xb616c0['filter']['updatePriority'](_0x33db98['eventCache']['getNode'](),_0x58f95a),_0x1b13ec=Tt(_0x33db98,_0x373c07,_0x4a7046['isFullyInitialized'](),_0x4a7046['isFiltered']());else{const _0x492d41=b(_0xf61feb),_0x443654=_0x4a7046['getNode']()['getImmediateChild'](_0x55c37d);let _0x299fe1;if(v(_0x492d41))_0x299fe1=_0x58f95a;else{const _0x46ffb6=_0x54916c['getCompleteChild'](_0x55c37d);_0x46ffb6!=null?zi(_0x492d41)==='.priority'&&_0x46ffb6['getChild'](Ro(_0x492d41))['isEmpty']()?_0x299fe1=_0x46ffb6:_0x299fe1=_0x46ffb6['updateChild'](_0x492d41,_0x58f95a):_0x299fe1=g['EMPTY_NODE'];}if(_0x443654['equals'](_0x299fe1))_0x1b13ec=_0x33db98;else{const _0x346aa4=_0xb616c0['filter']['updateChild'](_0x4a7046['getNode'](),_0x55c37d,_0x299fe1,_0x492d41,_0x54916c,_0x18686c);_0x1b13ec=Tt(_0x33db98,_0x346aa4,_0x4a7046['isFullyInitialized'](),_0xb616c0['filter']['filtersNodes']());}}}return _0x1b13ec;}function hr(_0x44ff92,_0x42e6c3){return _0x44ff92['eventCache']['isCompleteForChild'](_0x42e6c3);}function ku(_0x577eda,_0x4a7159,_0x53c13d,_0x48c194,_0x344292,_0xcf4fac,_0x412d54){let _0x599237=_0x4a7159;return _0x48c194['foreach']((_0x1fef96,_0x120973)=>{const _0x2ed788=k(_0x53c13d,_0x1fef96);hr(_0x4a7159,y(_0x2ed788))&&(_0x599237=Si(_0x577eda,_0x599237,_0x2ed788,_0x120973,_0x344292,_0xcf4fac,_0x412d54));}),_0x48c194['foreach']((_0x87774,_0xd401e)=>{const _0x521022=k(_0x53c13d,_0x87774);hr(_0x4a7159,y(_0x521022))||(_0x599237=Si(_0x577eda,_0x599237,_0x521022,_0xd401e,_0x344292,_0xcf4fac,_0x412d54));}),_0x599237;}function ur(_0x14ebef,_0x5d2248,_0xc3f8f){return _0xc3f8f['foreach']((_0x3b4393,_0x1107b7)=>{_0x5d2248=_0x5d2248['updateChild'](_0x3b4393,_0x1107b7);}),_0x5d2248;}function bi(_0x2039c3,_0x8855a6,_0x350dfa,_0x456a5c,_0x200b8b,_0x1252e1,_0x4eb288,_0x5c9c40){if(_0x8855a6['serverCache']['getNode']()['isEmpty']()&&!_0x8855a6['serverCache']['isFullyInitialized']())return _0x8855a6;let _0x584839=_0x8855a6,_0x25bfc2;v(_0x350dfa)?_0x25bfc2=_0x456a5c:_0x25bfc2=new S(null)['setTree'](_0x350dfa,_0x456a5c);const _0x5b4110=_0x8855a6['serverCache']['getNode']();return _0x25bfc2['children']['inorderTraversal']((_0x431fe4,_0xde40eb)=>{if(_0x5b4110['hasChild'](_0x431fe4)){const _0x306621=_0x8855a6['serverCache']['getNode']()['getImmediateChild'](_0x431fe4),_0x3bcc7b=ur(_0x2039c3,_0x306621,_0xde40eb);_0x584839=En(_0x2039c3,_0x584839,new C(_0x431fe4),_0x3bcc7b,_0x200b8b,_0x1252e1,_0x4eb288,_0x5c9c40);}}),_0x25bfc2['children']['inorderTraversal']((_0x25c667,_0x16e5f1)=>{const _0x290338=!_0x8855a6['serverCache']['isCompleteForChild'](_0x25c667)&&_0x16e5f1['value']===null;if(!_0x5b4110['hasChild'](_0x25c667)&&!_0x290338){const _0x1b2698=_0x8855a6['serverCache']['getNode']()['getImmediateChild'](_0x25c667),_0x1a1b6c=ur(_0x2039c3,_0x1b2698,_0x16e5f1);_0x584839=En(_0x2039c3,_0x584839,new C(_0x25c667),_0x1a1b6c,_0x200b8b,_0x1252e1,_0x4eb288,_0x5c9c40);}}),_0x584839;}function Nu(_0x32c362,_0x43e7ec,_0x11ea53,_0x2332e3,_0x236dfe,_0x4db835,_0x346e86){if(vn(_0x236dfe,_0x11ea53)!=null)return _0x43e7ec;const _0x5eb20f=_0x43e7ec['serverCache']['isFiltered'](),_0x5b1e3a=_0x43e7ec['serverCache'];if(_0x2332e3['value']!=null){if(v(_0x11ea53)&&_0x5b1e3a['isFullyInitialized']()||_0x5b1e3a['isCompleteForPath'](_0x11ea53))return En(_0x32c362,_0x43e7ec,_0x11ea53,_0x5b1e3a['getNode']()['getChild'](_0x11ea53),_0x236dfe,_0x4db835,_0x5eb20f,_0x346e86);if(v(_0x11ea53)){let _0x3cf793=new S(null);return _0x5b1e3a['getNode']()['forEachChild'](ye,(_0x5c19a4,_0x3b6111)=>{_0x3cf793=_0x3cf793['set'](new C(_0x5c19a4),_0x3b6111);}),bi(_0x32c362,_0x43e7ec,_0x11ea53,_0x3cf793,_0x236dfe,_0x4db835,_0x5eb20f,_0x346e86);}else return _0x43e7ec;}else{let _0xe232ad=new S(null);return _0x2332e3['foreach']((_0x407b80,_0x594dc1)=>{const _0x27b422=k(_0x11ea53,_0x407b80);_0x5b1e3a['isCompleteForPath'](_0x27b422)&&(_0xe232ad=_0xe232ad['set'](_0x407b80,_0x5b1e3a['getNode']()['getChild'](_0x27b422)));}),bi(_0x32c362,_0x43e7ec,_0x11ea53,_0xe232ad,_0x236dfe,_0x4db835,_0x5eb20f,_0x346e86);}}function Pu(_0x4b9311,_0x3eb5e9,_0x3411f8,_0x479170,_0xf46927){const _0x336df3=_0x3eb5e9['serverCache'],_0x54efd4=Uo(_0x3eb5e9,_0x336df3['getNode'](),_0x336df3['isFullyInitialized']()||v(_0x3411f8),_0x336df3['isFiltered']());return qo(_0x4b9311,_0x54efd4,_0x3411f8,_0x479170,Go,_0xf46927);}function Ou(_0x44bd23,_0x23afe4,_0x5f32e5,_0x6382ef,_0x1810dc,_0x52deb0){let _0x2c86c4;if(vn(_0x6382ef,_0x5f32e5)!=null)return _0x23afe4;{const _0x3ba6b9=new ss(_0x6382ef,_0x23afe4,_0x1810dc),_0x455a1b=_0x23afe4['eventCache']['getNode']();let _0x21c9ed;if(v(_0x5f32e5)||y(_0x5f32e5)==='.priority'){let _0x408b1c;if(_0x23afe4['serverCache']['isFullyInitialized']())_0x408b1c=yn(_0x6382ef,We(_0x23afe4));else{const _0x1465cd=_0x23afe4['serverCache']['getNode']();f(_0x1465cd instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x408b1c=ns(_0x6382ef,_0x1465cd);}_0x408b1c=_0x408b1c,_0x21c9ed=_0x44bd23['filter']['updateFullNode'](_0x455a1b,_0x408b1c,_0x52deb0);}else{const _0x4ce543=y(_0x5f32e5);let _0x16daed=is(_0x6382ef,_0x4ce543,_0x23afe4['serverCache']);_0x16daed==null&&_0x23afe4['serverCache']['isCompleteForChild'](_0x4ce543)&&(_0x16daed=_0x455a1b['getImmediateChild'](_0x4ce543)),_0x16daed!=null?_0x21c9ed=_0x44bd23['filter']['updateChild'](_0x455a1b,_0x4ce543,_0x16daed,b(_0x5f32e5),_0x3ba6b9,_0x52deb0):_0x23afe4['eventCache']['getNode']()['hasChild'](_0x4ce543)?_0x21c9ed=_0x44bd23['filter']['updateChild'](_0x455a1b,_0x4ce543,g['EMPTY_NODE'],b(_0x5f32e5),_0x3ba6b9,_0x52deb0):_0x21c9ed=_0x455a1b,_0x21c9ed['isEmpty']()&&_0x23afe4['serverCache']['isFullyInitialized']()&&(_0x2c86c4=yn(_0x6382ef,We(_0x23afe4)),_0x2c86c4['isLeafNode']()&&(_0x21c9ed=_0x44bd23['filter']['updateFullNode'](_0x21c9ed,_0x2c86c4,_0x52deb0)));}return _0x2c86c4=_0x23afe4['serverCache']['isFullyInitialized']()||vn(_0x6382ef,w())!=null,Tt(_0x23afe4,_0x21c9ed,_0x2c86c4,_0x44bd23['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x4708c0,_0x466dbb){this['query_']=_0x4708c0,this['eventRegistrations_']=[];const _0x37c954=this['query_']['_queryParams'],_0x4c3e07=new Ji(_0x37c954['getIndex']()),_0x30b99d=Kh(_0x37c954);this['processor_']=Su(_0x30b99d);const _0x3d2222=_0x466dbb['serverCache'],_0x1d773e=_0x466dbb['eventCache'],_0x215ec7=_0x4c3e07['updateFullNode'](g['EMPTY_NODE'],_0x3d2222['getNode'](),null),_0x58ed00=_0x30b99d['updateFullNode'](g['EMPTY_NODE'],_0x1d773e['getNode'](),null),_0x14f4e6=new Ce(_0x215ec7,_0x3d2222['isFullyInitialized'](),_0x4c3e07['filtersNodes']()),_0xfbf117=new Ce(_0x58ed00,_0x1d773e['isFullyInitialized'](),_0x30b99d['filtersNodes']());this['viewCache_']=Mn(_0xfbf117,_0x14f4e6),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x1cdc1c){return _0x1cdc1c['viewCache_']['serverCache']['getNode']();}function Lu(_0x5ce866){return mn(_0x5ce866['viewCache_']);}function xu(_0x2bd9fe,_0x5279c7){const _0x837154=We(_0x2bd9fe['viewCache_']);return _0x837154&&(_0x2bd9fe['query']['_queryParams']['loadsAllData']()||!v(_0x5279c7)&&!_0x837154['getImmediateChild'](y(_0x5279c7))['isEmpty']())?_0x837154['getChild'](_0x5279c7):null;}function dr(_0x5bc0a6){return _0x5bc0a6['eventRegistrations_']['length']===0x0;}function Fu(_0x1aaa11,_0x451dd0){_0x1aaa11['eventRegistrations_']['push'](_0x451dd0);}function fr(_0x2be478,_0x5a18ed,_0x34f147){const _0x56048e=[];if(_0x34f147){f(_0x5a18ed==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x5b60ac=_0x2be478['query']['_path'];_0x2be478['eventRegistrations_']['forEach'](_0x14c9cd=>{const _0x3ebc5a=_0x14c9cd['createCancelEvent'](_0x34f147,_0x5b60ac);_0x3ebc5a&&_0x56048e['push'](_0x3ebc5a);});}if(_0x5a18ed){let _0x4800a5=[];for(let _0x3e5929=0x0;_0x3e5929<_0x2be478['eventRegistrations_']['length'];++_0x3e5929){const _0x27ac25=_0x2be478['eventRegistrations_'][_0x3e5929];if(!_0x27ac25['matches'](_0x5a18ed))_0x4800a5['push'](_0x27ac25);else{if(_0x5a18ed['hasAnyCallback']()){_0x4800a5=_0x4800a5['concat'](_0x2be478['eventRegistrations_']['slice'](_0x3e5929+0x1));break;}}}_0x2be478['eventRegistrations_']=_0x4800a5;}else _0x2be478['eventRegistrations_']=[];return _0x56048e;}function pr(_0x4cda0a,_0x464482,_0x41304e,_0x145423){_0x464482['type']===j['MERGE']&&_0x464482['source']['queryId']!==null&&(f(We(_0x4cda0a['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x4cda0a['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x50829e=_0x4cda0a['viewCache_'],_0x3126f7=Ru(_0x4cda0a['processor_'],_0x50829e,_0x464482,_0x41304e,_0x145423);return bu(_0x4cda0a['processor_'],_0x3126f7['viewCache']),f(_0x3126f7['viewCache']['serverCache']['isFullyInitialized']()||!_0x50829e['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x4cda0a['viewCache_']=_0x3126f7['viewCache'],zo(_0x4cda0a,_0x3126f7['changes'],_0x3126f7['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x5314fb,_0x3ff014){const _0x320a5d=_0x5314fb['viewCache_']['eventCache'],_0x326db0=[];return _0x320a5d['getNode']()['isLeafNode']()||_0x320a5d['getNode']()['forEachChild'](R,(_0x1c8093,_0x3e8a44)=>{_0x326db0['push'](et(_0x1c8093,_0x3e8a44));}),_0x320a5d['isFullyInitialized']()&&_0x326db0['push'](Lo(_0x320a5d['getNode']())),zo(_0x5314fb,_0x326db0,_0x320a5d['getNode'](),_0x3ff014);}function zo(_0xee9059,_0x54b817,_0x2f9ae2,_0x4c04b1){const _0x3d5884=_0x4c04b1?[_0x4c04b1]:_0xee9059['eventRegistrations_'];return ru(_0xee9059['eventGenerator_'],_0x54b817,_0x2f9ae2,_0x3d5884);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x579cf5){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x579cf5;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x1904a6){return _0x1904a6['views']['size']===0x0;}function rs(_0x520091,_0x242cc1,_0x1ce9bc,_0x2539ec){const _0x505ff3=_0x242cc1['source']['queryId'];if(_0x505ff3!==null){const _0x512c9b=_0x520091['views']['get'](_0x505ff3);return f(_0x512c9b!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x512c9b,_0x242cc1,_0x1ce9bc,_0x2539ec);}else{let _0x3f360f=[];for(const _0x5ad4a1 of _0x520091['views']['values']())_0x3f360f=_0x3f360f['concat'](pr(_0x5ad4a1,_0x242cc1,_0x1ce9bc,_0x2539ec));return _0x3f360f;}}function Ko(_0x5381c0,_0x1b5a00,_0x3238d3,_0xdfa63,_0x2f5a1e){const _0x1bcdb2=_0x1b5a00['_queryIdentifier'],_0x38519e=_0x5381c0['views']['get'](_0x1bcdb2);if(!_0x38519e){let _0x4d932b=yn(_0x3238d3,_0x2f5a1e?_0xdfa63:null),_0x3b0ec9=!0x1;_0x4d932b?_0x3b0ec9=!0x0:_0xdfa63 instanceof g?(_0x4d932b=ns(_0x3238d3,_0xdfa63),_0x3b0ec9=!0x1):(_0x4d932b=g['EMPTY_NODE'],_0x3b0ec9=!0x1);const _0x182bff=Mn(new Ce(_0x4d932b,_0x3b0ec9,!0x1),new Ce(_0xdfa63,_0x2f5a1e,!0x1));return new Du(_0x1b5a00,_0x182bff);}return _0x38519e;}function Hu(_0x3f32c1,_0x505173,_0x9b8547,_0x10b14f,_0x478916,_0x229fda){const _0x5ac6b3=Ko(_0x3f32c1,_0x505173,_0x10b14f,_0x478916,_0x229fda);return _0x3f32c1['views']['has'](_0x505173['_queryIdentifier'])||_0x3f32c1['views']['set'](_0x505173['_queryIdentifier'],_0x5ac6b3),Fu(_0x5ac6b3,_0x9b8547),Uu(_0x5ac6b3,_0x9b8547);}function $u(_0x207711,_0x2be646,_0x3e5a6f,_0x1f082d){const _0x1ee2b7=_0x2be646['_queryIdentifier'],_0x556b5e=[];let _0x3ea32f=[];const _0x5c55cd=Te(_0x207711);if(_0x1ee2b7==='default'){for(const [_0x1e8337,_0x28a93e]of _0x207711['views']['entries']())_0x3ea32f=_0x3ea32f['concat'](fr(_0x28a93e,_0x3e5a6f,_0x1f082d)),dr(_0x28a93e)&&(_0x207711['views']['delete'](_0x1e8337),_0x28a93e['query']['_queryParams']['loadsAllData']()||_0x556b5e['push'](_0x28a93e['query']));}else{const _0x15d217=_0x207711['views']['get'](_0x1ee2b7);_0x15d217&&(_0x3ea32f=_0x3ea32f['concat'](fr(_0x15d217,_0x3e5a6f,_0x1f082d)),dr(_0x15d217)&&(_0x207711['views']['delete'](_0x1ee2b7),_0x15d217['query']['_queryParams']['loadsAllData']()||_0x556b5e['push'](_0x15d217['query'])));}return _0x5c55cd&&!Te(_0x207711)&&_0x556b5e['push'](new(Bu())(_0x2be646['_repo'],_0x2be646['_path'])),{'removed':_0x556b5e,'events':_0x3ea32f};}function Yo(_0x4c70b6){const _0x20d69c=[];for(const _0x455038 of _0x4c70b6['views']['values']())_0x455038['query']['_queryParams']['loadsAllData']()||_0x20d69c['push'](_0x455038);return _0x20d69c;}function Ee(_0x2049b6,_0x5f58ae){let _0x56bf9d=null;for(const _0x311863 of _0x2049b6['views']['values']())_0x56bf9d=_0x56bf9d||xu(_0x311863,_0x5f58ae);return _0x56bf9d;}function Qo(_0x560f2f,_0x4d5421){if(_0x4d5421['_queryParams']['loadsAllData']())return xn(_0x560f2f);{const _0x1c62ef=_0x4d5421['_queryIdentifier'];return _0x560f2f['views']['get'](_0x1c62ef);}}function Jo(_0x200442,_0xffc0c6){return Qo(_0x200442,_0xffc0c6)!=null;}function Te(_0x373b75){return xn(_0x373b75)!=null;}function xn(_0x2a8dd7){for(const _0x47aeba of _0x2a8dd7['views']['values']())if(_0x47aeba['query']['_queryParams']['loadsAllData']())return _0x47aeba;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x2dc188){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x2dc188;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x17495d){this['listenProvider_']=_0x17495d,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x6d9308,_0x154cf2,_0x21fc73,_0x2e6379,_0x43851f){return lu(_0x6d9308['pendingWriteTree_'],_0x154cf2,_0x21fc73,_0x2e6379,_0x43851f),_0x43851f?ut(_0x6d9308,new Ue(Zi(),_0x154cf2,_0x21fc73)):[];}function ju(_0x417d5c,_0x38ba45,_0x3d2184,_0x5cdb0d){hu(_0x417d5c['pendingWriteTree_'],_0x38ba45,_0x3d2184,_0x5cdb0d);const _0x1bf335=S['fromObject'](_0x3d2184);return ut(_0x417d5c,new tt(Zi(),_0x38ba45,_0x1bf335));}function pe(_0x5611fa,_0x1b1f76,_0x4b263c=!0x1){const _0x449865=uu(_0x5611fa['pendingWriteTree_'],_0x1b1f76);if(du(_0x5611fa['pendingWriteTree_'],_0x1b1f76)){let _0x3640ae=new S(null);return _0x449865['snap']!=null?_0x3640ae=_0x3640ae['set'](w(),!0x0):x(_0x449865['children'],_0x2a2a71=>{_0x3640ae=_0x3640ae['set'](new C(_0x2a2a71),!0x0);}),ut(_0x5611fa,new gn(_0x449865['path'],_0x3640ae,_0x4b263c));}else return[];}function Gt(_0x1010a9,_0x290f69,_0x3d311e){return ut(_0x1010a9,new Ue(es(),_0x290f69,_0x3d311e));}function Ku(_0x592547,_0x5909c0,_0x41256d){const _0x59bdf3=S['fromObject'](_0x41256d);return ut(_0x592547,new tt(es(),_0x5909c0,_0x59bdf3));}function Yu(_0x566ee6,_0x4c81bd){return ut(_0x566ee6,new Lt(es(),_0x4c81bd));}function Qu(_0x500ca,_0x31ae01,_0x2bdda3){const _0x1d3640=as(_0x500ca,_0x2bdda3);if(_0x1d3640){const _0x164f12=cs(_0x1d3640),_0x1acc5e=_0x164f12['path'],_0x386e0e=_0x164f12['queryId'],_0x16a0a2=F(_0x1acc5e,_0x31ae01),_0x5129e5=new Lt(ts(_0x386e0e),_0x16a0a2);return ls(_0x500ca,_0x1acc5e,_0x5129e5);}else return[];}function Cn(_0x42ee98,_0x1a59b4,_0x16b9ed,_0x1935bc,_0xfb8d6f=!0x1){const _0x4cb541=_0x1a59b4['_path'],_0xd5038=_0x42ee98['syncPointTree_']['get'](_0x4cb541);let _0x1472f=[];if(_0xd5038&&(_0x1a59b4['_queryIdentifier']==='default'||Jo(_0xd5038,_0x1a59b4))){const _0x3d1f97=$u(_0xd5038,_0x1a59b4,_0x16b9ed,_0x1935bc);Vu(_0xd5038)&&(_0x42ee98['syncPointTree_']=_0x42ee98['syncPointTree_']['remove'](_0x4cb541));const _0x9b3f3d=_0x3d1f97['removed'];if(_0x1472f=_0x3d1f97['events'],!_0xfb8d6f){const _0x19aa9f=_0x9b3f3d['findIndex'](_0x48ba46=>_0x48ba46['_queryParams']['loadsAllData']())!==-0x1,_0xa449de=_0x42ee98['syncPointTree_']['findOnPath'](_0x4cb541,(_0x5e1cc9,_0x6bf577)=>Te(_0x6bf577));if(_0x19aa9f&&!_0xa449de){const _0x2e1296=_0x42ee98['syncPointTree_']['subtree'](_0x4cb541);if(!_0x2e1296['isEmpty']()){const _0xa3a0d2=Zu(_0x2e1296);for(let _0x3f4fa6=0x0;_0x3f4fa6<_0xa3a0d2['length'];++_0x3f4fa6){const _0x518631=_0xa3a0d2[_0x3f4fa6],_0x3d64b9=_0x518631['query'],_0x25b895=ta(_0x42ee98,_0x518631);_0x42ee98['listenProvider_']['startListening'](bt(_0x3d64b9),xt(_0x42ee98,_0x3d64b9),_0x25b895['hashFn'],_0x25b895['onComplete']);}}}!_0xa449de&&_0x9b3f3d['length']>0x0&&!_0x1935bc&&(_0x19aa9f?_0x42ee98['listenProvider_']['stopListening'](bt(_0x1a59b4),null):_0x9b3f3d['forEach'](_0x4a2b52=>{const _0x13c606=_0x42ee98['queryToTagMap']['get'](Un(_0x4a2b52));_0x42ee98['listenProvider_']['stopListening'](bt(_0x4a2b52),_0x13c606);}));}ed(_0x42ee98,_0x9b3f3d);}return _0x1472f;}function Xo(_0x8dc568,_0x3ab68f,_0x219a54,_0x4defea){const _0x8ba2c=as(_0x8dc568,_0x4defea);if(_0x8ba2c!=null){const _0x56a931=cs(_0x8ba2c),_0x4968b8=_0x56a931['path'],_0x408d86=_0x56a931['queryId'],_0x399ca9=F(_0x4968b8,_0x3ab68f),_0x1db77f=new Ue(ts(_0x408d86),_0x399ca9,_0x219a54);return ls(_0x8dc568,_0x4968b8,_0x1db77f);}else return[];}function Ju(_0x78645,_0x50c6e4,_0xabf8f0,_0x23633d){const _0x443eae=as(_0x78645,_0x23633d);if(_0x443eae){const _0x2f1cf4=cs(_0x443eae),_0x4a6213=_0x2f1cf4['path'],_0x4bca46=_0x2f1cf4['queryId'],_0x4d20f4=F(_0x4a6213,_0x50c6e4),_0x365453=S['fromObject'](_0xabf8f0),_0x28f596=new tt(ts(_0x4bca46),_0x4d20f4,_0x365453);return ls(_0x78645,_0x4a6213,_0x28f596);}else return[];}function Ri(_0x95e78d,_0x4c789c,_0x2d6cb9,_0x3a1d8f=!0x1){const _0x2454b9=_0x4c789c['_path'];let _0x14e37d=null,_0x5bf357=!0x1;_0x95e78d['syncPointTree_']['foreachOnPath'](_0x2454b9,(_0xd0cf70,_0x3de1fa)=>{const _0x343a5f=F(_0xd0cf70,_0x2454b9);_0x14e37d=_0x14e37d||Ee(_0x3de1fa,_0x343a5f),_0x5bf357=_0x5bf357||Te(_0x3de1fa);});let _0x245125=_0x95e78d['syncPointTree_']['get'](_0x2454b9);_0x245125?(_0x5bf357=_0x5bf357||Te(_0x245125),_0x14e37d=_0x14e37d||Ee(_0x245125,w())):(_0x245125=new jo(),_0x95e78d['syncPointTree_']=_0x95e78d['syncPointTree_']['set'](_0x2454b9,_0x245125));let _0xde1b61;_0x14e37d!=null?_0xde1b61=!0x0:(_0xde1b61=!0x1,_0x14e37d=g['EMPTY_NODE'],_0x95e78d['syncPointTree_']['subtree'](_0x2454b9)['foreachChild']((_0x1d34be,_0x352256)=>{const _0x1033b1=Ee(_0x352256,w());_0x1033b1&&(_0x14e37d=_0x14e37d['updateImmediateChild'](_0x1d34be,_0x1033b1));}));const _0x14380b=Jo(_0x245125,_0x4c789c);if(!_0x14380b&&!_0x4c789c['_queryParams']['loadsAllData']()){const _0x18de10=Un(_0x4c789c);f(!_0x95e78d['queryToTagMap']['has'](_0x18de10),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x11491a=td();_0x95e78d['queryToTagMap']['set'](_0x18de10,_0x11491a),_0x95e78d['tagToQueryMap']['set'](_0x11491a,_0x18de10);}const _0xe7675c=Ln(_0x95e78d['pendingWriteTree_'],_0x2454b9);let _0x2498cf=Hu(_0x245125,_0x4c789c,_0x2d6cb9,_0xe7675c,_0x14e37d,_0xde1b61);if(!_0x14380b&&!_0x5bf357&&!_0x3a1d8f){const _0x47ca6e=Qo(_0x245125,_0x4c789c);_0x2498cf=_0x2498cf['concat'](nd(_0x95e78d,_0x4c789c,_0x47ca6e));}return _0x2498cf;}function Fn(_0x2e312a,_0x1710e5,_0x43fc3e){const _0x2290c9=_0x2e312a['pendingWriteTree_'],_0x401149=_0x2e312a['syncPointTree_']['findOnPath'](_0x1710e5,(_0x42d9c9,_0x2501c6)=>{const _0x2e74d=F(_0x42d9c9,_0x1710e5),_0xa44d06=Ee(_0x2501c6,_0x2e74d);if(_0xa44d06)return _0xa44d06;});return Vo(_0x2290c9,_0x1710e5,_0x401149,_0x43fc3e,!0x0);}function Xu(_0x341f25,_0xc5a038){const _0x41e7d0=_0xc5a038['_path'];let _0x829dfe=null;_0x341f25['syncPointTree_']['foreachOnPath'](_0x41e7d0,(_0x1e52be,_0x416a27)=>{const _0x7dae6c=F(_0x1e52be,_0x41e7d0);_0x829dfe=_0x829dfe||Ee(_0x416a27,_0x7dae6c);});let _0xf6bb18=_0x341f25['syncPointTree_']['get'](_0x41e7d0);_0xf6bb18?_0x829dfe=_0x829dfe||Ee(_0xf6bb18,w()):(_0xf6bb18=new jo(),_0x341f25['syncPointTree_']=_0x341f25['syncPointTree_']['set'](_0x41e7d0,_0xf6bb18));const _0x44dd17=_0x829dfe!=null,_0x52c4d4=_0x44dd17?new Ce(_0x829dfe,!0x0,!0x1):null,_0x5be9bf=Ln(_0x341f25['pendingWriteTree_'],_0xc5a038['_path']),_0x53dfa1=Ko(_0xf6bb18,_0xc5a038,_0x5be9bf,_0x44dd17?_0x52c4d4['getNode']():g['EMPTY_NODE'],_0x44dd17);return Lu(_0x53dfa1);}function ut(_0x282b22,_0x3a74c7){return Zo(_0x3a74c7,_0x282b22['syncPointTree_'],null,Ln(_0x282b22['pendingWriteTree_'],w()));}function Zo(_0x537975,_0x273597,_0x423125,_0x50880f){if(v(_0x537975['path']))return ea(_0x537975,_0x273597,_0x423125,_0x50880f);{const _0x3188e4=_0x273597['get'](w());_0x423125==null&&_0x3188e4!=null&&(_0x423125=Ee(_0x3188e4,w()));let _0x5caedd=[];const _0x274028=y(_0x537975['path']),_0x43fe5c=_0x537975['operationForChild'](_0x274028),_0x689505=_0x273597['children']['get'](_0x274028);if(_0x689505&&_0x43fe5c){const _0x3a05b8=_0x423125?_0x423125['getImmediateChild'](_0x274028):null,_0x4a5651=Ho(_0x50880f,_0x274028);_0x5caedd=_0x5caedd['concat'](Zo(_0x43fe5c,_0x689505,_0x3a05b8,_0x4a5651));}return _0x3188e4&&(_0x5caedd=_0x5caedd['concat'](rs(_0x3188e4,_0x537975,_0x50880f,_0x423125))),_0x5caedd;}}function ea(_0x4f508d,_0x2ca2e4,_0x4396e6,_0x3fd41f){const _0x3c3561=_0x2ca2e4['get'](w());_0x4396e6==null&&_0x3c3561!=null&&(_0x4396e6=Ee(_0x3c3561,w()));let _0x226c32=[];return _0x2ca2e4['children']['inorderTraversal']((_0x37e5df,_0x3bd06d)=>{const _0x18d4f5=_0x4396e6?_0x4396e6['getImmediateChild'](_0x37e5df):null,_0x3a8e94=Ho(_0x3fd41f,_0x37e5df),_0x4ac48f=_0x4f508d['operationForChild'](_0x37e5df);_0x4ac48f&&(_0x226c32=_0x226c32['concat'](ea(_0x4ac48f,_0x3bd06d,_0x18d4f5,_0x3a8e94)));}),_0x3c3561&&(_0x226c32=_0x226c32['concat'](rs(_0x3c3561,_0x4f508d,_0x3fd41f,_0x4396e6))),_0x226c32;}function ta(_0x1ff358,_0x1e82a4){const _0x13385d=_0x1e82a4['query'],_0x52bd8c=xt(_0x1ff358,_0x13385d);return{'hashFn':()=>(Mu(_0x1e82a4)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x503e8f=>{if(_0x503e8f==='ok')return _0x52bd8c?Qu(_0x1ff358,_0x13385d['_path'],_0x52bd8c):Yu(_0x1ff358,_0x13385d['_path']);{const _0xa6e08a=Kl(_0x503e8f,_0x13385d);return Cn(_0x1ff358,_0x13385d,null,_0xa6e08a);}}};}function xt(_0x2c9ec0,_0x1c0edb){const _0x27d88a=Un(_0x1c0edb);return _0x2c9ec0['queryToTagMap']['get'](_0x27d88a);}function Un(_0x3f246b){return _0x3f246b['_path']['toString']()+'$'+_0x3f246b['_queryIdentifier'];}function as(_0x3cfee2,_0x5c64b9){return _0x3cfee2['tagToQueryMap']['get'](_0x5c64b9);}function cs(_0xcec395){const _0x420603=_0xcec395['indexOf']('$');return f(_0x420603!==-0x1&&_0x420603<_0xcec395['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0xcec395['substr'](_0x420603+0x1),'path':new C(_0xcec395['substr'](0x0,_0x420603))};}function ls(_0x556a75,_0x15ab4d,_0x18af60){const _0x495fba=_0x556a75['syncPointTree_']['get'](_0x15ab4d);f(_0x495fba,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x13ef35=Ln(_0x556a75['pendingWriteTree_'],_0x15ab4d);return rs(_0x495fba,_0x18af60,_0x13ef35,null);}function Zu(_0x368592){return _0x368592['fold']((_0x57c3f3,_0x2f1d07,_0x581fd4)=>{if(_0x2f1d07&&Te(_0x2f1d07))return[xn(_0x2f1d07)];{let _0x3c8bb0=[];return _0x2f1d07&&(_0x3c8bb0=Yo(_0x2f1d07)),x(_0x581fd4,(_0x3f6cf8,_0x53f554)=>{_0x3c8bb0=_0x3c8bb0['concat'](_0x53f554);}),_0x3c8bb0;}});}function bt(_0x316f8a){return _0x316f8a['_queryParams']['loadsAllData']()&&!_0x316f8a['_queryParams']['isDefault']()?new(qu())(_0x316f8a['_repo'],_0x316f8a['_path']):_0x316f8a;}function ed(_0x327338,_0x4bfacf){for(let _0x3dab68=0x0;_0x3dab68<_0x4bfacf['length'];++_0x3dab68){const _0x5112c4=_0x4bfacf[_0x3dab68];if(!_0x5112c4['_queryParams']['loadsAllData']()){const _0x55e2cc=Un(_0x5112c4),_0x1fbaee=_0x327338['queryToTagMap']['get'](_0x55e2cc);_0x327338['queryToTagMap']['delete'](_0x55e2cc),_0x327338['tagToQueryMap']['delete'](_0x1fbaee);}}}function td(){return zu++;}function nd(_0x3d2132,_0x3d3e5b,_0x6d68b3){const _0x57aaf2=_0x3d3e5b['_path'],_0x6e669b=xt(_0x3d2132,_0x3d3e5b),_0x523746=ta(_0x3d2132,_0x6d68b3),_0x536cf6=_0x3d2132['listenProvider_']['startListening'](bt(_0x3d3e5b),_0x6e669b,_0x523746['hashFn'],_0x523746['onComplete']),_0x1261d1=_0x3d2132['syncPointTree_']['subtree'](_0x57aaf2);if(_0x6e669b)f(!Te(_0x1261d1['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x5b0967=_0x1261d1['fold']((_0x37e5db,_0x2adb1e,_0x5939a9)=>{if(!v(_0x37e5db)&&_0x2adb1e&&Te(_0x2adb1e))return[xn(_0x2adb1e)['query']];{let _0x389eab=[];return _0x2adb1e&&(_0x389eab=_0x389eab['concat'](Yo(_0x2adb1e)['map'](_0x5e22a9=>_0x5e22a9['query']))),x(_0x5939a9,(_0x1f8e1e,_0x314f09)=>{_0x389eab=_0x389eab['concat'](_0x314f09);}),_0x389eab;}});for(let _0x31caae=0x0;_0x31caae<_0x5b0967['length'];++_0x31caae){const _0x5354e1=_0x5b0967[_0x31caae];_0x3d2132['listenProvider_']['stopListening'](bt(_0x5354e1),xt(_0x3d2132,_0x5354e1));}}return _0x536cf6;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x596b42){this['node_']=_0x596b42;}['getImmediateChild'](_0x18c778){const _0x575847=this['node_']['getImmediateChild'](_0x18c778);return new hs(_0x575847);}['node'](){return this['node_'];}}class us{constructor(_0x40ff20,_0x54826d){this['syncTree_']=_0x40ff20,this['path_']=_0x54826d;}['getImmediateChild'](_0x233a8e){const _0x2de6e3=k(this['path_'],_0x233a8e);return new us(this['syncTree_'],_0x2de6e3);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x8fa8fb){return _0x8fa8fb=_0x8fa8fb||{},_0x8fa8fb['timestamp']=_0x8fa8fb['timestamp']||new Date()['getTime'](),_0x8fa8fb;},gr=function(_0x4b116d,_0x2d94bc,_0x3db059){if(!_0x4b116d||typeof _0x4b116d!='object')return _0x4b116d;if(f('.sv'in _0x4b116d,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x4b116d['.sv']=='string')return sd(_0x4b116d['.sv'],_0x2d94bc,_0x3db059);if(typeof _0x4b116d['.sv']=='object')return rd(_0x4b116d['.sv'],_0x2d94bc);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4b116d,null,0x2));},sd=function(_0x4c76e2,_0x435bf1,_0x107caf){switch(_0x4c76e2){case'timestamp':return _0x107caf['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x4c76e2);}},rd=function(_0x5abe9d,_0x1ca7f4,_0x1d1ab2){_0x5abe9d['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5abe9d,null,0x2));const _0x5df904=_0x5abe9d['increment'];typeof _0x5df904!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x5df904);const _0x2aa97b=_0x1ca7f4['node']();if(f(_0x2aa97b!==null&&typeof _0x2aa97b<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x2aa97b['isLeafNode']())return _0x5df904;const _0x225826=_0x2aa97b['getValue']();return typeof _0x225826!='number'?_0x5df904:_0x225826+_0x5df904;},na=function(_0x24e5ee,_0x451fc0,_0x179953,_0x42c077){return fs(_0x451fc0,new us(_0x179953,_0x24e5ee),_0x42c077);},ds=function(_0x1d986a,_0x576d0d,_0x3f013d){return fs(_0x1d986a,new hs(_0x576d0d),_0x3f013d);};function fs(_0x4cf1f4,_0x3c8a1c,_0x54cdbe){const _0x1790dc=_0x4cf1f4['getPriority']()['val'](),_0x29f7ef=gr(_0x1790dc,_0x3c8a1c['getImmediateChild']('.priority'),_0x54cdbe);let _0x50a1b9;if(_0x4cf1f4['isLeafNode']()){const _0x2dbbc3=_0x4cf1f4,_0x32a189=gr(_0x2dbbc3['getValue'](),_0x3c8a1c,_0x54cdbe);return _0x32a189!==_0x2dbbc3['getValue']()||_0x29f7ef!==_0x2dbbc3['getPriority']()['val']()?new D(_0x32a189,P(_0x29f7ef)):_0x4cf1f4;}else{const _0x23acd1=_0x4cf1f4;return _0x50a1b9=_0x23acd1,_0x29f7ef!==_0x23acd1['getPriority']()['val']()&&(_0x50a1b9=_0x50a1b9['updatePriority'](new D(_0x29f7ef))),_0x23acd1['forEachChild'](R,(_0x428d39,_0x544b3f)=>{const _0x4db980=fs(_0x544b3f,_0x3c8a1c['getImmediateChild'](_0x428d39),_0x54cdbe);_0x4db980!==_0x544b3f&&(_0x50a1b9=_0x50a1b9['updateImmediateChild'](_0x428d39,_0x4db980));}),_0x50a1b9;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x27089e='',_0x3cc221=null,_0x539711={'children':{},'childCount':0x0}){this['name']=_0x27089e,this['parent']=_0x3cc221,this['node']=_0x539711;}}function Wn(_0x400f0e,_0x1fd670){let _0x288c9e=_0x1fd670 instanceof C?_0x1fd670:new C(_0x1fd670),_0xeab8f5=_0x400f0e,_0x58ccae=y(_0x288c9e);for(;_0x58ccae!==null;){const _0x1e71af=De(_0xeab8f5['node']['children'],_0x58ccae)||{'children':{},'childCount':0x0};_0xeab8f5=new ps(_0x58ccae,_0xeab8f5,_0x1e71af),_0x288c9e=b(_0x288c9e),_0x58ccae=y(_0x288c9e);}return _0xeab8f5;}function Ge(_0x274ec3){return _0x274ec3['node']['value'];}function _s(_0x1a96fe,_0x4bfbeb){_0x1a96fe['node']['value']=_0x4bfbeb,Ai(_0x1a96fe);}function ia(_0x53a41f){return _0x53a41f['node']['childCount']>0x0;}function od(_0x389287){return Ge(_0x389287)===void 0x0&&!ia(_0x389287);}function Bn(_0x3c93db,_0x3c8a7f){x(_0x3c93db['node']['children'],(_0x516423,_0x49a806)=>{_0x3c8a7f(new ps(_0x516423,_0x3c93db,_0x49a806));});}function sa(_0x4dfac5,_0xdf7101,_0x3650a0,_0x273810){_0x3650a0&&_0xdf7101(_0x4dfac5),Bn(_0x4dfac5,_0x3c28d2=>{sa(_0x3c28d2,_0xdf7101,!0x0);});}function ad(_0x812f70,_0x3c898d,_0x5274d6){let _0x5e5754=_0x812f70['parent'];for(;_0x5e5754!==null;){if(_0x3c898d(_0x5e5754))return!0x0;_0x5e5754=_0x5e5754['parent'];}return!0x1;}function qt(_0x2d6cc6){return new C(_0x2d6cc6['parent']===null?_0x2d6cc6['name']:qt(_0x2d6cc6['parent'])+'/'+_0x2d6cc6['name']);}function Ai(_0x5e5ebd){_0x5e5ebd['parent']!==null&&cd(_0x5e5ebd['parent'],_0x5e5ebd['name'],_0x5e5ebd);}function cd(_0x368dcd,_0x22c15b,_0x36e394){const _0x1cdf84=od(_0x36e394),_0x29e2fb=J(_0x368dcd['node']['children'],_0x22c15b);_0x1cdf84&&_0x29e2fb?(delete _0x368dcd['node']['children'][_0x22c15b],_0x368dcd['node']['childCount']--,Ai(_0x368dcd)):!_0x1cdf84&&!_0x29e2fb&&(_0x368dcd['node']['children'][_0x22c15b]=_0x36e394['node'],_0x368dcd['node']['childCount']++,Ai(_0x368dcd));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x32db1f){return typeof _0x32db1f=='string'&&_0x32db1f['length']!==0x0&&!ld['test'](_0x32db1f);},ra=function(_0x956ad8){return typeof _0x956ad8=='string'&&_0x956ad8['length']!==0x0&&!hd['test'](_0x956ad8);},ud=function(_0xd58fb1){return _0xd58fb1&&(_0xd58fb1=_0xd58fb1['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0xd58fb1);},Tn=function(_0x17f14c){return _0x17f14c===null||typeof _0x17f14c=='string'||typeof _0x17f14c=='number'&&!Vi(_0x17f14c)||_0x17f14c&&typeof _0x17f14c=='object'&&J(_0x17f14c,'.sv');},zt=function(_0x13e6d2,_0x34440b,_0x2703ba,_0x4c9b1e){_0x4c9b1e&&_0x34440b===void 0x0||jt(Pn(_0x13e6d2,'value'),_0x34440b,_0x2703ba);},jt=function(_0x536c14,_0x53610b,_0x319d6d){const _0x419914=_0x319d6d instanceof C?new Ah(_0x319d6d,_0x536c14):_0x319d6d;if(_0x53610b===void 0x0)throw new Error(_0x536c14+'contains\x20undefined\x20'+Pe(_0x419914));if(typeof _0x53610b=='function')throw new Error(_0x536c14+'contains\x20a\x20function\x20'+Pe(_0x419914)+'\x20with\x20contents\x20=\x20'+_0x53610b['toString']());if(Vi(_0x53610b))throw new Error(_0x536c14+'contains\x20'+_0x53610b['toString']()+'\x20'+Pe(_0x419914));if(typeof _0x53610b=='string'&&_0x53610b['length']>ai/0x3&&On(_0x53610b)>ai)throw new Error(_0x536c14+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x419914)+'\x20(\x27'+_0x53610b['substring'](0x0,0x32)+'...\x27)');if(_0x53610b&&typeof _0x53610b=='object'){let _0x41684b=!0x1,_0x33baf7=!0x1;if(x(_0x53610b,(_0x1e8782,_0x150d0e)=>{if(_0x1e8782==='.value')_0x41684b=!0x0;else{if(_0x1e8782!=='.priority'&&_0x1e8782!=='.sv'&&(_0x33baf7=!0x0,!gs(_0x1e8782)))throw new Error(_0x536c14+'\x20contains\x20an\x20invalid\x20key\x20('+_0x1e8782+')\x20'+Pe(_0x419914)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x419914,_0x1e8782),jt(_0x536c14,_0x150d0e,_0x419914),Nh(_0x419914);}),_0x41684b&&_0x33baf7)throw new Error(_0x536c14+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x419914)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x5adc8b,_0x25f7f9){let _0x6ab025,_0x3ebc80;for(_0x6ab025=0x0;_0x6ab025<_0x25f7f9['length'];_0x6ab025++){_0x3ebc80=_0x25f7f9[_0x6ab025];const _0x2c200c=Pt(_0x3ebc80);for(let _0xfe9c0d=0x0;_0xfe9c0d<_0x2c200c['length'];_0xfe9c0d++)if(!(_0x2c200c[_0xfe9c0d]==='.priority'&&_0xfe9c0d===_0x2c200c['length']-0x1)){if(!gs(_0x2c200c[_0xfe9c0d]))throw new Error(_0x5adc8b+'contains\x20an\x20invalid\x20key\x20('+_0x2c200c[_0xfe9c0d]+')\x20in\x20path\x20'+_0x3ebc80['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x25f7f9['sort'](Rh);let _0x2eb7a2=null;for(_0x6ab025=0x0;_0x6ab025<_0x25f7f9['length'];_0x6ab025++){if(_0x3ebc80=_0x25f7f9[_0x6ab025],_0x2eb7a2!==null&&G(_0x2eb7a2,_0x3ebc80))throw new Error(_0x5adc8b+'contains\x20a\x20path\x20'+_0x2eb7a2['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x3ebc80['toString']());_0x2eb7a2=_0x3ebc80;}},fd=function(_0x8f0b80,_0x532a23,_0x420282,_0x7a0056){const _0x162379=Pn(_0x8f0b80,'values');if(!(_0x532a23&&typeof _0x532a23=='object')||Array['isArray'](_0x532a23))throw new Error(_0x162379+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0xee3ac9=[];x(_0x532a23,(_0x40b73b,_0x22f96d)=>{const _0x13a84d=new C(_0x40b73b);if(jt(_0x162379,_0x22f96d,k(_0x420282,_0x13a84d)),zi(_0x13a84d)==='.priority'&&!Tn(_0x22f96d))throw new Error(_0x162379+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x13a84d['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0xee3ac9['push'](_0x13a84d);}),dd(_0x162379,_0xee3ac9);},ms=function(_0x2a2f27,_0xc52dfc,_0x2d23e3,_0x233807){if(!ra(_0x2d23e3))throw new Error(Pn(_0x2a2f27,_0xc52dfc)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x2d23e3+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x49eb74,_0x4b652f,_0x3117e4,_0x310203){_0x3117e4&&(_0x3117e4=_0x3117e4['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x49eb74,_0x4b652f,_0x3117e4);},ys=function(_0x6c1e84,_0x3994ea){if(y(_0x3994ea)==='.info')throw new Error(_0x6c1e84+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x458e7c,_0x5891f1){const _0x4188f0=_0x5891f1['path']['toString']();if(typeof _0x5891f1['repoInfo']['host']!='string'||_0x5891f1['repoInfo']['host']['length']===0x0||!gs(_0x5891f1['repoInfo']['namespace'])&&_0x5891f1['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x4188f0['length']!==0x0&&!ud(_0x4188f0))throw new Error(Pn(_0x458e7c,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x3c6e39,_0x135820){let _0xf12042=null;for(let _0x56f58=0x0;_0x56f58<_0x135820['length'];_0x56f58++){const _0x400b44=_0x135820[_0x56f58],_0x2ea434=_0x400b44['getPath']();_0xf12042!==null&&!ji(_0x2ea434,_0xf12042['path'])&&(_0x3c6e39['eventLists_']['push'](_0xf12042),_0xf12042=null),_0xf12042===null&&(_0xf12042={'events':[],'path':_0x2ea434}),_0xf12042['events']['push'](_0x400b44);}_0xf12042&&_0x3c6e39['eventLists_']['push'](_0xf12042);}function oa(_0x3f5513,_0x5c3722,_0x8c28a3){Vn(_0x3f5513,_0x8c28a3),aa(_0x3f5513,_0x4d0355=>ji(_0x4d0355,_0x5c3722));}function H(_0x265fc5,_0xc486c7,_0x5181bc){Vn(_0x265fc5,_0x5181bc),aa(_0x265fc5,_0x9040be=>G(_0x9040be,_0xc486c7)||G(_0xc486c7,_0x9040be));}function aa(_0x14ce71,_0x2cc0c3){_0x14ce71['recursionDepth_']++;let _0x45798c=!0x0;for(let _0x262947=0x0;_0x262947<_0x14ce71['eventLists_']['length'];_0x262947++){const _0x415983=_0x14ce71['eventLists_'][_0x262947];if(_0x415983){const _0x5ae245=_0x415983['path'];_0x2cc0c3(_0x5ae245)?(md(_0x14ce71['eventLists_'][_0x262947]),_0x14ce71['eventLists_'][_0x262947]=null):_0x45798c=!0x1;}}_0x45798c&&(_0x14ce71['eventLists_']=[]),_0x14ce71['recursionDepth_']--;}function md(_0x515f34){for(let _0x38cf41=0x0;_0x38cf41<_0x515f34['events']['length'];_0x38cf41++){const _0x4fbd7a=_0x515f34['events'][_0x38cf41];if(_0x4fbd7a!==null){_0x515f34['events'][_0x38cf41]=null;const _0x3a5978=_0x4fbd7a['getEventRunner']();wt&&L('event:\x20'+_0x4fbd7a['toString']()),ht(_0x3a5978);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0xc67ea5,_0x4acece,_0x55ff21,_0x4534f9){this['repoInfo_']=_0xc67ea5,this['forceRestClient_']=_0x4acece,this['authTokenProvider_']=_0x55ff21,this['appCheckProvider_']=_0x4534f9,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x4287f3,_0x9dccb8,_0x38a40c){if(_0x4287f3['stats_']=Gi(_0x4287f3['repoInfo_']),_0x4287f3['forceRestClient_']||Xl())_0x4287f3['server_']=new pn(_0x4287f3['repoInfo_'],(_0x2d1e1e,_0x3580ed,_0x375541,_0x2d0de8)=>{mr(_0x4287f3,_0x2d1e1e,_0x3580ed,_0x375541,_0x2d0de8);},_0x4287f3['authTokenProvider_'],_0x4287f3['appCheckProvider_']),setTimeout(()=>yr(_0x4287f3,!0x0),0x0);else{if(typeof _0x38a40c<'u'&&_0x38a40c!==null){if(typeof _0x38a40c!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x38a40c);}catch(_0x19d359){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x19d359);}}_0x4287f3['persistentConnection_']=new se(_0x4287f3['repoInfo_'],_0x9dccb8,(_0x5346cd,_0x372091,_0x194e19,_0x216c72)=>{mr(_0x4287f3,_0x5346cd,_0x372091,_0x194e19,_0x216c72);},_0x46e48b=>{yr(_0x4287f3,_0x46e48b);},_0x562374=>{Id(_0x4287f3,_0x562374);},_0x4287f3['authTokenProvider_'],_0x4287f3['appCheckProvider_'],_0x38a40c),_0x4287f3['server_']=_0x4287f3['persistentConnection_'];}_0x4287f3['authTokenProvider_']['addTokenChangeListener'](_0x335b84=>{_0x4287f3['server_']['refreshAuthToken'](_0x335b84);}),_0x4287f3['appCheckProvider_']['addTokenChangeListener'](_0x1af4f8=>{_0x4287f3['server_']['refreshAppCheckToken'](_0x1af4f8['token']);}),_0x4287f3['statsReporter_']=ih(_0x4287f3['repoInfo_'],()=>new iu(_0x4287f3['stats_'],_0x4287f3['server_'])),_0x4287f3['infoData_']=new Xh(),_0x4287f3['infoSyncTree_']=new _r({'startListening':(_0x704e6b,_0x2431a0,_0x27e5bb,_0x2d4236)=>{let _0x1001b9=[];const _0x48d3a9=_0x4287f3['infoData_']['getNode'](_0x704e6b['_path']);return _0x48d3a9['isEmpty']()||(_0x1001b9=Gt(_0x4287f3['infoSyncTree_'],_0x704e6b['_path'],_0x48d3a9),setTimeout(()=>{_0x2d4236('ok');},0x0)),_0x1001b9;},'stopListening':()=>{}}),vs(_0x4287f3,'connected',!0x1),_0x4287f3['serverSyncTree_']=new _r({'startListening':(_0x578f81,_0x24b7d0,_0x24518d,_0x1c68bc)=>(_0x4287f3['server_']['listen'](_0x578f81,_0x24518d,_0x24b7d0,(_0x1f1640,_0x3c93bc)=>{const _0x1614c9=_0x1c68bc(_0x1f1640,_0x3c93bc);H(_0x4287f3['eventQueue_'],_0x578f81['_path'],_0x1614c9);}),[]),'stopListening':(_0x37986d,_0xdea62e)=>{_0x4287f3['server_']['unlisten'](_0x37986d,_0xdea62e);}});}function la(_0x1f8991){const _0x4a38d6=_0x1f8991['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x4a38d6;}function Kt(_0xed2187){return id({'timestamp':la(_0xed2187)});}function mr(_0x244e4f,_0x28a139,_0x59d625,_0x1a8c14,_0x4c6692){_0x244e4f['dataUpdateCount']++;const _0x55b170=new C(_0x28a139);_0x59d625=_0x244e4f['interceptServerDataCallback_']?_0x244e4f['interceptServerDataCallback_'](_0x28a139,_0x59d625):_0x59d625;let _0x2aba12=[];if(_0x4c6692){if(_0x1a8c14){const _0x33d3ef=hn(_0x59d625,_0x48fc28=>P(_0x48fc28));_0x2aba12=Ju(_0x244e4f['serverSyncTree_'],_0x55b170,_0x33d3ef,_0x4c6692);}else{const _0x570770=P(_0x59d625);_0x2aba12=Xo(_0x244e4f['serverSyncTree_'],_0x55b170,_0x570770,_0x4c6692);}}else{if(_0x1a8c14){const _0x52df2a=hn(_0x59d625,_0x4b1964=>P(_0x4b1964));_0x2aba12=Ku(_0x244e4f['serverSyncTree_'],_0x55b170,_0x52df2a);}else{const _0x372c92=P(_0x59d625);_0x2aba12=Gt(_0x244e4f['serverSyncTree_'],_0x55b170,_0x372c92);}}let _0x2378ae=_0x55b170;_0x2aba12['length']>0x0&&(_0x2378ae=it(_0x244e4f,_0x55b170)),H(_0x244e4f['eventQueue_'],_0x2378ae,_0x2aba12);}function yr(_0x5d9723,_0x32aacc){vs(_0x5d9723,'connected',_0x32aacc),_0x32aacc===!0x1&&Sd(_0x5d9723);}function Id(_0x5bbd0d,_0x5b3a5c){x(_0x5b3a5c,(_0x1db948,_0xb3c3cd)=>{vs(_0x5bbd0d,_0x1db948,_0xb3c3cd);});}function vs(_0x2cb3a9,_0x3df4f1,_0x21169b){const _0x2035b0=new C('/.info/'+_0x3df4f1),_0x5678ac=P(_0x21169b);_0x2cb3a9['infoData_']['updateSnapshot'](_0x2035b0,_0x5678ac);const _0x1215b2=Gt(_0x2cb3a9['infoSyncTree_'],_0x2035b0,_0x5678ac);H(_0x2cb3a9['eventQueue_'],_0x2035b0,_0x1215b2);}function Hn(_0x453226){return _0x453226['nextWriteId_']++;}function wd(_0x4d97f0,_0x2bf58e,_0x33e71a){const _0x1ad014=Xu(_0x4d97f0['serverSyncTree_'],_0x2bf58e);return _0x1ad014!=null?Promise['resolve'](_0x1ad014):_0x4d97f0['server_']['get'](_0x2bf58e)['then'](_0x59e606=>{const _0x46fe52=P(_0x59e606)['withIndex'](_0x2bf58e['_queryParams']['getIndex']());Ri(_0x4d97f0['serverSyncTree_'],_0x2bf58e,_0x33e71a,!0x0);let _0x379514;if(_0x2bf58e['_queryParams']['loadsAllData']())_0x379514=Gt(_0x4d97f0['serverSyncTree_'],_0x2bf58e['_path'],_0x46fe52);else{const _0x159f4c=xt(_0x4d97f0['serverSyncTree_'],_0x2bf58e);_0x379514=Xo(_0x4d97f0['serverSyncTree_'],_0x2bf58e['_path'],_0x46fe52,_0x159f4c);}return H(_0x4d97f0['eventQueue_'],_0x2bf58e['_path'],_0x379514),Cn(_0x4d97f0['serverSyncTree_'],_0x2bf58e,_0x33e71a,null,!0x0),_0x46fe52;},_0x2d36b7=>(dt(_0x4d97f0,'get\x20for\x20query\x20'+O(_0x2bf58e)+'\x20failed:\x20'+_0x2d36b7),Promise['reject'](new Error(_0x2d36b7))));}function Cd(_0x4cfd2f,_0x3b6bf4,_0x1c3cdd,_0x159150,_0x5e7582){dt(_0x4cfd2f,'set',{'path':_0x3b6bf4['toString'](),'value':_0x1c3cdd,'priority':_0x159150});const _0x2f58e1=Kt(_0x4cfd2f),_0x2c72a1=P(_0x1c3cdd,_0x159150),_0x186584=Fn(_0x4cfd2f['serverSyncTree_'],_0x3b6bf4),_0x187c9e=ds(_0x2c72a1,_0x186584,_0x2f58e1),_0x1bcf5c=Hn(_0x4cfd2f),_0x5baa0c=os(_0x4cfd2f['serverSyncTree_'],_0x3b6bf4,_0x187c9e,_0x1bcf5c,!0x0);Vn(_0x4cfd2f['eventQueue_'],_0x5baa0c),_0x4cfd2f['server_']['put'](_0x3b6bf4['toString'](),_0x2c72a1['val'](!0x0),(_0x18b518,_0x16fb82)=>{const _0x4176de=_0x18b518==='ok';_0x4176de||U('set\x20at\x20'+_0x3b6bf4+'\x20failed:\x20'+_0x18b518);const _0x361592=pe(_0x4cfd2f['serverSyncTree_'],_0x1bcf5c,!_0x4176de);H(_0x4cfd2f['eventQueue_'],_0x3b6bf4,_0x361592),ki(_0x4cfd2f,_0x5e7582,_0x18b518,_0x16fb82);});const _0x26ce24=Is(_0x4cfd2f,_0x3b6bf4);it(_0x4cfd2f,_0x26ce24),H(_0x4cfd2f['eventQueue_'],_0x26ce24,[]);}function Td(_0x4c5da2,_0x3a9d76,_0x3a16a0,_0x3ff140){dt(_0x4c5da2,'update',{'path':_0x3a9d76['toString'](),'value':_0x3a16a0});let _0x1ef14d=!0x0;const _0x3cf5d2=Kt(_0x4c5da2),_0x4d3cf7={};if(x(_0x3a16a0,(_0x1793c5,_0x2d421a)=>{_0x1ef14d=!0x1,_0x4d3cf7[_0x1793c5]=na(k(_0x3a9d76,_0x1793c5),P(_0x2d421a),_0x4c5da2['serverSyncTree_'],_0x3cf5d2);}),_0x1ef14d)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x4c5da2,_0x3ff140,'ok',void 0x0);else{const _0x531ff1=Hn(_0x4c5da2),_0x33fc09=ju(_0x4c5da2['serverSyncTree_'],_0x3a9d76,_0x4d3cf7,_0x531ff1);Vn(_0x4c5da2['eventQueue_'],_0x33fc09),_0x4c5da2['server_']['merge'](_0x3a9d76['toString'](),_0x3a16a0,(_0x29ca4e,_0xd25b1)=>{const _0x3fc5b0=_0x29ca4e==='ok';_0x3fc5b0||U('update\x20at\x20'+_0x3a9d76+'\x20failed:\x20'+_0x29ca4e);const _0x1d87f4=pe(_0x4c5da2['serverSyncTree_'],_0x531ff1,!_0x3fc5b0),_0x2283dd=_0x1d87f4['length']>0x0?it(_0x4c5da2,_0x3a9d76):_0x3a9d76;H(_0x4c5da2['eventQueue_'],_0x2283dd,_0x1d87f4),ki(_0x4c5da2,_0x3ff140,_0x29ca4e,_0xd25b1);}),x(_0x3a16a0,_0x521012=>{const _0x140360=Is(_0x4c5da2,k(_0x3a9d76,_0x521012));it(_0x4c5da2,_0x140360);}),H(_0x4c5da2['eventQueue_'],_0x3a9d76,[]);}}function Sd(_0x11b723){dt(_0x11b723,'onDisconnectEvents');const _0x33b162=Kt(_0x11b723),_0x1ce0a7=_n();Ii(_0x11b723['onDisconnect_'],w(),(_0x1201dc,_0x150f20)=>{const _0x40734c=na(_0x1201dc,_0x150f20,_0x11b723['serverSyncTree_'],_0x33b162);Fo(_0x1ce0a7,_0x1201dc,_0x40734c);});let _0x128aab=[];Ii(_0x1ce0a7,w(),(_0x2be4a6,_0x5d4fd2)=>{_0x128aab=_0x128aab['concat'](Gt(_0x11b723['serverSyncTree_'],_0x2be4a6,_0x5d4fd2));const _0x2b7cca=Is(_0x11b723,_0x2be4a6);it(_0x11b723,_0x2b7cca);}),_0x11b723['onDisconnect_']=_n(),H(_0x11b723['eventQueue_'],w(),_0x128aab);}function bd(_0x674903,_0x327b5c,_0x8f0ebc){let _0x3447a2;y(_0x327b5c['_path'])==='.info'?_0x3447a2=Ri(_0x674903['infoSyncTree_'],_0x327b5c,_0x8f0ebc):_0x3447a2=Ri(_0x674903['serverSyncTree_'],_0x327b5c,_0x8f0ebc),oa(_0x674903['eventQueue_'],_0x327b5c['_path'],_0x3447a2);}function Rd(_0x1aff09,_0x56cb47,_0x4aa00a){let _0x389ba7;y(_0x56cb47['_path'])==='.info'?_0x389ba7=Cn(_0x1aff09['infoSyncTree_'],_0x56cb47,_0x4aa00a):_0x389ba7=Cn(_0x1aff09['serverSyncTree_'],_0x56cb47,_0x4aa00a),oa(_0x1aff09['eventQueue_'],_0x56cb47['_path'],_0x389ba7);}function ha(_0x5e2c4c){_0x5e2c4c['persistentConnection_']&&_0x5e2c4c['persistentConnection_']['interrupt'](ca);}function Ad(_0x3697b7){_0x3697b7['persistentConnection_']&&_0x3697b7['persistentConnection_']['resume'](ca);}function dt(_0x59cf7e,..._0x26a064){let _0x4aef20='';_0x59cf7e['persistentConnection_']&&(_0x4aef20=_0x59cf7e['persistentConnection_']['id']+':'),L(_0x4aef20,..._0x26a064);}function ki(_0x31f454,_0x5c0058,_0x55a977,_0x2d6de3){_0x5c0058&&ht(()=>{if(_0x55a977==='ok')_0x5c0058(null);else{const _0x2ef4dd=(_0x55a977||'error')['toUpperCase']();let _0x298d42=_0x2ef4dd;_0x2d6de3&&(_0x298d42+=':\x20'+_0x2d6de3);const _0x226a5b=new Error(_0x298d42);_0x226a5b['code']=_0x2ef4dd,_0x5c0058(_0x226a5b);}});}function kd(_0x2ffa3b,_0x3aa0ca,_0x2dbfbf,_0x13d305,_0x1443d6,_0x71d595){dt(_0x2ffa3b,'transaction\x20on\x20'+_0x3aa0ca);const _0x5bd806={'path':_0x3aa0ca,'update':_0x2dbfbf,'onComplete':_0x13d305,'status':null,'order':so(),'applyLocally':_0x71d595,'retryCount':0x0,'unwatcher':_0x1443d6,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x3cae66=Es(_0x2ffa3b,_0x3aa0ca,void 0x0);_0x5bd806['currentInputSnapshot']=_0x3cae66;const _0x33adff=_0x5bd806['update'](_0x3cae66['val']());if(_0x33adff===void 0x0)_0x5bd806['unwatcher'](),_0x5bd806['currentOutputSnapshotRaw']=null,_0x5bd806['currentOutputSnapshotResolved']=null,_0x5bd806['onComplete']&&_0x5bd806['onComplete'](null,!0x1,_0x5bd806['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x33adff,_0x5bd806['path']),_0x5bd806['status']=0x0;const _0x54a40d=Wn(_0x2ffa3b['transactionQueueTree_'],_0x3aa0ca),_0x3d7c58=Ge(_0x54a40d)||[];_0x3d7c58['push'](_0x5bd806),_s(_0x54a40d,_0x3d7c58);let _0x513920;typeof _0x33adff=='object'&&_0x33adff!==null&&J(_0x33adff,'.priority')?(_0x513920=De(_0x33adff,'.priority'),f(Tn(_0x513920),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x513920=(Fn(_0x2ffa3b['serverSyncTree_'],_0x3aa0ca)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x3222de=Kt(_0x2ffa3b),_0x2e9077=P(_0x33adff,_0x513920),_0x333a35=ds(_0x2e9077,_0x3cae66,_0x3222de);_0x5bd806['currentOutputSnapshotRaw']=_0x2e9077,_0x5bd806['currentOutputSnapshotResolved']=_0x333a35,_0x5bd806['currentWriteId']=Hn(_0x2ffa3b);const _0x2b398e=os(_0x2ffa3b['serverSyncTree_'],_0x3aa0ca,_0x333a35,_0x5bd806['currentWriteId'],_0x5bd806['applyLocally']);H(_0x2ffa3b['eventQueue_'],_0x3aa0ca,_0x2b398e),$n(_0x2ffa3b,_0x2ffa3b['transactionQueueTree_']);}}function Es(_0x135914,_0x173fce,_0x109a85){return Fn(_0x135914['serverSyncTree_'],_0x173fce,_0x109a85)||g['EMPTY_NODE'];}function $n(_0x12d269,_0x5dcaef=_0x12d269['transactionQueueTree_']){if(_0x5dcaef||Gn(_0x12d269,_0x5dcaef),Ge(_0x5dcaef)){const _0x1742b2=da(_0x12d269,_0x5dcaef);f(_0x1742b2['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x1742b2['every'](_0x501e7b=>_0x501e7b['status']===0x0)&&Nd(_0x12d269,qt(_0x5dcaef),_0x1742b2);}else ia(_0x5dcaef)&&Bn(_0x5dcaef,_0x5c66d1=>{$n(_0x12d269,_0x5c66d1);});}function Nd(_0x485f99,_0x2d99e1,_0x1288e4){const _0x546470=_0x1288e4['map'](_0x1d3895=>_0x1d3895['currentWriteId']),_0x136aa1=Es(_0x485f99,_0x2d99e1,_0x546470);let _0x4510fe=_0x136aa1;const _0x50a46e=_0x136aa1['hash']();for(let _0x520ca2=0x0;_0x520ca2<_0x1288e4['length'];_0x520ca2++){const _0x1194d3=_0x1288e4[_0x520ca2];f(_0x1194d3['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x1194d3['status']=0x1,_0x1194d3['retryCount']++;const _0x1bbca9=F(_0x2d99e1,_0x1194d3['path']);_0x4510fe=_0x4510fe['updateChild'](_0x1bbca9,_0x1194d3['currentOutputSnapshotRaw']);}const _0x15421a=_0x4510fe['val'](!0x0),_0x5f4617=_0x2d99e1;_0x485f99['server_']['put'](_0x5f4617['toString'](),_0x15421a,_0x1bc313=>{dt(_0x485f99,'transaction\x20put\x20response',{'path':_0x5f4617['toString'](),'status':_0x1bc313});let _0x5dc9ad=[];if(_0x1bc313==='ok'){const _0x366c49=[];for(let _0x3c5e77=0x0;_0x3c5e77<_0x1288e4['length'];_0x3c5e77++)_0x1288e4[_0x3c5e77]['status']=0x2,_0x5dc9ad=_0x5dc9ad['concat'](pe(_0x485f99['serverSyncTree_'],_0x1288e4[_0x3c5e77]['currentWriteId'])),_0x1288e4[_0x3c5e77]['onComplete']&&_0x366c49['push'](()=>_0x1288e4[_0x3c5e77]['onComplete'](null,!0x0,_0x1288e4[_0x3c5e77]['currentOutputSnapshotResolved'])),_0x1288e4[_0x3c5e77]['unwatcher']();Gn(_0x485f99,Wn(_0x485f99['transactionQueueTree_'],_0x2d99e1)),$n(_0x485f99,_0x485f99['transactionQueueTree_']),H(_0x485f99['eventQueue_'],_0x2d99e1,_0x5dc9ad);for(let _0x3e452a=0x0;_0x3e452a<_0x366c49['length'];_0x3e452a++)ht(_0x366c49[_0x3e452a]);}else{if(_0x1bc313==='datastale'){for(let _0x2741e4=0x0;_0x2741e4<_0x1288e4['length'];_0x2741e4++)_0x1288e4[_0x2741e4]['status']===0x3?_0x1288e4[_0x2741e4]['status']=0x4:_0x1288e4[_0x2741e4]['status']=0x0;}else{U('transaction\x20at\x20'+_0x5f4617['toString']()+'\x20failed:\x20'+_0x1bc313);for(let _0x5f5e56=0x0;_0x5f5e56<_0x1288e4['length'];_0x5f5e56++)_0x1288e4[_0x5f5e56]['status']=0x4,_0x1288e4[_0x5f5e56]['abortReason']=_0x1bc313;}it(_0x485f99,_0x2d99e1);}},_0x50a46e);}function it(_0x21b96e,_0x4afe7c){const _0x337067=ua(_0x21b96e,_0x4afe7c),_0x40e924=qt(_0x337067),_0x4b36b2=da(_0x21b96e,_0x337067);return Pd(_0x21b96e,_0x4b36b2,_0x40e924),_0x40e924;}function Pd(_0x2b99c7,_0x535779,_0x113012){if(_0x535779['length']===0x0)return;const _0x2519c3=[];let _0x2f32c9=[];const _0x384998=_0x535779['filter'](_0x3d0ac0=>_0x3d0ac0['status']===0x0)['map'](_0x2336f2=>_0x2336f2['currentWriteId']);for(let _0x382ff5=0x0;_0x382ff5<_0x535779['length'];_0x382ff5++){const _0x4ac647=_0x535779[_0x382ff5],_0x22f2c2=F(_0x113012,_0x4ac647['path']);let _0x48dcfe=!0x1,_0x340649;if(f(_0x22f2c2!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x4ac647['status']===0x4)_0x48dcfe=!0x0,_0x340649=_0x4ac647['abortReason'],_0x2f32c9=_0x2f32c9['concat'](pe(_0x2b99c7['serverSyncTree_'],_0x4ac647['currentWriteId'],!0x0));else{if(_0x4ac647['status']===0x0){if(_0x4ac647['retryCount']>=yd)_0x48dcfe=!0x0,_0x340649='maxretry',_0x2f32c9=_0x2f32c9['concat'](pe(_0x2b99c7['serverSyncTree_'],_0x4ac647['currentWriteId'],!0x0));else{const _0x2c1b11=Es(_0x2b99c7,_0x4ac647['path'],_0x384998);_0x4ac647['currentInputSnapshot']=_0x2c1b11;const _0x17ba8d=_0x535779[_0x382ff5]['update'](_0x2c1b11['val']());if(_0x17ba8d!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x17ba8d,_0x4ac647['path']);let _0x389cd8=P(_0x17ba8d);typeof _0x17ba8d=='object'&&_0x17ba8d!=null&&J(_0x17ba8d,'.priority')||(_0x389cd8=_0x389cd8['updatePriority'](_0x2c1b11['getPriority']()));const _0x358089=_0x4ac647['currentWriteId'],_0x2231ce=Kt(_0x2b99c7),_0x176af3=ds(_0x389cd8,_0x2c1b11,_0x2231ce);_0x4ac647['currentOutputSnapshotRaw']=_0x389cd8,_0x4ac647['currentOutputSnapshotResolved']=_0x176af3,_0x4ac647['currentWriteId']=Hn(_0x2b99c7),_0x384998['splice'](_0x384998['indexOf'](_0x358089),0x1),_0x2f32c9=_0x2f32c9['concat'](os(_0x2b99c7['serverSyncTree_'],_0x4ac647['path'],_0x176af3,_0x4ac647['currentWriteId'],_0x4ac647['applyLocally'])),_0x2f32c9=_0x2f32c9['concat'](pe(_0x2b99c7['serverSyncTree_'],_0x358089,!0x0));}else _0x48dcfe=!0x0,_0x340649='nodata',_0x2f32c9=_0x2f32c9['concat'](pe(_0x2b99c7['serverSyncTree_'],_0x4ac647['currentWriteId'],!0x0));}}}H(_0x2b99c7['eventQueue_'],_0x113012,_0x2f32c9),_0x2f32c9=[],_0x48dcfe&&(_0x535779[_0x382ff5]['status']=0x2,function(_0x204864){setTimeout(_0x204864,Math['floor'](0x0));}(_0x535779[_0x382ff5]['unwatcher']),_0x535779[_0x382ff5]['onComplete']&&(_0x340649==='nodata'?_0x2519c3['push'](()=>_0x535779[_0x382ff5]['onComplete'](null,!0x1,_0x535779[_0x382ff5]['currentInputSnapshot'])):_0x2519c3['push'](()=>_0x535779[_0x382ff5]['onComplete'](new Error(_0x340649),!0x1,null))));}Gn(_0x2b99c7,_0x2b99c7['transactionQueueTree_']);for(let _0x4e14c1=0x0;_0x4e14c1<_0x2519c3['length'];_0x4e14c1++)ht(_0x2519c3[_0x4e14c1]);$n(_0x2b99c7,_0x2b99c7['transactionQueueTree_']);}function ua(_0x501272,_0x3acf6c){let _0x580d51,_0x2066d1=_0x501272['transactionQueueTree_'];for(_0x580d51=y(_0x3acf6c);_0x580d51!==null&&Ge(_0x2066d1)===void 0x0;)_0x2066d1=Wn(_0x2066d1,_0x580d51),_0x3acf6c=b(_0x3acf6c),_0x580d51=y(_0x3acf6c);return _0x2066d1;}function da(_0x9d5bc0,_0x511d9c){const _0x2bd51e=[];return fa(_0x9d5bc0,_0x511d9c,_0x2bd51e),_0x2bd51e['sort']((_0x5e4335,_0x15e995)=>_0x5e4335['order']-_0x15e995['order']),_0x2bd51e;}function fa(_0x14c6a9,_0x3faf8e,_0x4e1344){const _0x13c9fc=Ge(_0x3faf8e);if(_0x13c9fc){for(let _0x1be78d=0x0;_0x1be78d<_0x13c9fc['length'];_0x1be78d++)_0x4e1344['push'](_0x13c9fc[_0x1be78d]);}Bn(_0x3faf8e,_0x2dda5e=>{fa(_0x14c6a9,_0x2dda5e,_0x4e1344);});}function Gn(_0xeeae5a,_0x17c00a){const _0x510e2e=Ge(_0x17c00a);if(_0x510e2e){let _0x568920=0x0;for(let _0x463c69=0x0;_0x463c69<_0x510e2e['length'];_0x463c69++)_0x510e2e[_0x463c69]['status']!==0x2&&(_0x510e2e[_0x568920]=_0x510e2e[_0x463c69],_0x568920++);_0x510e2e['length']=_0x568920,_s(_0x17c00a,_0x510e2e['length']>0x0?_0x510e2e:void 0x0);}Bn(_0x17c00a,_0x3cd1aa=>{Gn(_0xeeae5a,_0x3cd1aa);});}function Is(_0x212607,_0x18dc7e){const _0xac3f95=qt(ua(_0x212607,_0x18dc7e)),_0x34a96e=Wn(_0x212607['transactionQueueTree_'],_0x18dc7e);return ad(_0x34a96e,_0x56d7b2=>{ci(_0x212607,_0x56d7b2);}),ci(_0x212607,_0x34a96e),sa(_0x34a96e,_0x4f5aa6=>{ci(_0x212607,_0x4f5aa6);}),_0xac3f95;}function ci(_0x5f46f4,_0x27a692){const _0x1fde44=Ge(_0x27a692);if(_0x1fde44){const _0x13efef=[];let _0x3ba192=[],_0x57c6dd=-0x1;for(let _0x34d35e=0x0;_0x34d35e<_0x1fde44['length'];_0x34d35e++)_0x1fde44[_0x34d35e]['status']===0x3||(_0x1fde44[_0x34d35e]['status']===0x1?(f(_0x57c6dd===_0x34d35e-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x57c6dd=_0x34d35e,_0x1fde44[_0x34d35e]['status']=0x3,_0x1fde44[_0x34d35e]['abortReason']='set'):(f(_0x1fde44[_0x34d35e]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x1fde44[_0x34d35e]['unwatcher'](),_0x3ba192=_0x3ba192['concat'](pe(_0x5f46f4['serverSyncTree_'],_0x1fde44[_0x34d35e]['currentWriteId'],!0x0)),_0x1fde44[_0x34d35e]['onComplete']&&_0x13efef['push'](_0x1fde44[_0x34d35e]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x57c6dd===-0x1?_s(_0x27a692,void 0x0):_0x1fde44['length']=_0x57c6dd+0x1,H(_0x5f46f4['eventQueue_'],qt(_0x27a692),_0x3ba192);for(let _0x2e37c4=0x0;_0x2e37c4<_0x13efef['length'];_0x2e37c4++)ht(_0x13efef[_0x2e37c4]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x56fa1a){let _0x2f45c6='';const _0x2d8c45=_0x56fa1a['split']('/');for(let _0x2388ee=0x0;_0x2388ee<_0x2d8c45['length'];_0x2388ee++)if(_0x2d8c45[_0x2388ee]['length']>0x0){let _0x426e33=_0x2d8c45[_0x2388ee];try{_0x426e33=decodeURIComponent(_0x426e33['replace'](/\+/g,'\x20'));}catch{}_0x2f45c6+='/'+_0x426e33;}return _0x2f45c6;}function Dd(_0x2bbdaa){const _0x5bd0b9={};_0x2bbdaa['charAt'](0x0)==='?'&&(_0x2bbdaa=_0x2bbdaa['substring'](0x1));for(const _0x1455c9 of _0x2bbdaa['split']('&')){if(_0x1455c9['length']===0x0)continue;const _0x16d4c7=_0x1455c9['split']('=');_0x16d4c7['length']===0x2?_0x5bd0b9[decodeURIComponent(_0x16d4c7[0x0])]=decodeURIComponent(_0x16d4c7[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x1455c9+'\x27\x20in\x20query\x20\x27'+_0x2bbdaa+'\x27');}return _0x5bd0b9;}const vr=function(_0x3bf13d,_0x53019b){const _0x3fa481=Md(_0x3bf13d),_0x490801=_0x3fa481['namespace'];_0x3fa481['domain']==='firebase.com'&&ae(_0x3fa481['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x490801||_0x490801==='undefined')&&_0x3fa481['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x3fa481['secure']||$l();const _0xfe5f2e=_0x3fa481['scheme']==='ws'||_0x3fa481['scheme']==='wss';return{'repoInfo':new yo(_0x3fa481['host'],_0x3fa481['secure'],_0x490801,_0xfe5f2e,_0x53019b,'',_0x490801!==_0x3fa481['subdomain']),'path':new C(_0x3fa481['pathString'])};},Md=function(_0xf52f96){let _0x1458e6='',_0x428eac='',_0x590267='',_0x2eb17d='',_0x4da679='',_0x516c68=!0x0,_0x1c8d23='https',_0x266629=0x1bb;if(typeof _0xf52f96=='string'){let _0x21b83e=_0xf52f96['indexOf']('//');_0x21b83e>=0x0&&(_0x1c8d23=_0xf52f96['substring'](0x0,_0x21b83e-0x1),_0xf52f96=_0xf52f96['substring'](_0x21b83e+0x2));let _0x5a0c15=_0xf52f96['indexOf']('/');_0x5a0c15===-0x1&&(_0x5a0c15=_0xf52f96['length']);let _0x3e2c8c=_0xf52f96['indexOf']('?');_0x3e2c8c===-0x1&&(_0x3e2c8c=_0xf52f96['length']),_0x1458e6=_0xf52f96['substring'](0x0,Math['min'](_0x5a0c15,_0x3e2c8c)),_0x5a0c15<_0x3e2c8c&&(_0x2eb17d=Od(_0xf52f96['substring'](_0x5a0c15,_0x3e2c8c)));const _0x5481c4=Dd(_0xf52f96['substring'](Math['min'](_0xf52f96['length'],_0x3e2c8c)));_0x21b83e=_0x1458e6['indexOf'](':'),_0x21b83e>=0x0?(_0x516c68=_0x1c8d23==='https'||_0x1c8d23==='wss',_0x266629=parseInt(_0x1458e6['substring'](_0x21b83e+0x1),0xa)):_0x21b83e=_0x1458e6['length'];const _0x4bf15e=_0x1458e6['slice'](0x0,_0x21b83e);if(_0x4bf15e['toLowerCase']()==='localhost')_0x428eac='localhost';else{if(_0x4bf15e['split']('.')['length']<=0x2)_0x428eac=_0x4bf15e;else{const _0x5ce803=_0x1458e6['indexOf']('.');_0x590267=_0x1458e6['substring'](0x0,_0x5ce803)['toLowerCase'](),_0x428eac=_0x1458e6['substring'](_0x5ce803+0x1),_0x4da679=_0x590267;}}'ns'in _0x5481c4&&(_0x4da679=_0x5481c4['ns']);}return{'host':_0x1458e6,'port':_0x266629,'domain':_0x428eac,'subdomain':_0x590267,'secure':_0x516c68,'scheme':_0x1c8d23,'pathString':_0x2eb17d,'namespace':_0x4da679};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x54a632=0x0;const _0xb65aef=[];return function(_0x3b635b){const _0x235adc=_0x3b635b===_0x54a632;_0x54a632=_0x3b635b;let _0x46a866;const _0x53a2fb=new Array(0x8);for(_0x46a866=0x7;_0x46a866>=0x0;_0x46a866--)_0x53a2fb[_0x46a866]=Er['charAt'](_0x3b635b%0x40),_0x3b635b=Math['floor'](_0x3b635b/0x40);f(_0x3b635b===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x53518d=_0x53a2fb['join']('');if(_0x235adc){for(_0x46a866=0xb;_0x46a866>=0x0&&_0xb65aef[_0x46a866]===0x3f;_0x46a866--)_0xb65aef[_0x46a866]=0x0;_0xb65aef[_0x46a866]++;}else{for(_0x46a866=0x0;_0x46a866<0xc;_0x46a866++)_0xb65aef[_0x46a866]=Math['floor'](Math['random']()*0x40);}for(_0x46a866=0x0;_0x46a866<0xc;_0x46a866++)_0x53518d+=Er['charAt'](_0xb65aef[_0x46a866]);return f(_0x53518d['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x53518d;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0xcb4a87,_0x14d6c0,_0x5961ad,_0x5846dd){this['eventType']=_0xcb4a87,this['eventRegistration']=_0x14d6c0,this['snapshot']=_0x5961ad,this['prevName']=_0x5846dd;}['getPath'](){const _0x40a3b3=this['snapshot']['ref'];return this['eventType']==='value'?_0x40a3b3['_path']:_0x40a3b3['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x5db2f5,_0x37c529,_0x4db9e5){this['eventRegistration']=_0x5db2f5,this['error']=_0x37c529,this['path']=_0x4db9e5;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x47dbaa,_0x4a4e75){this['snapshotCallback']=_0x47dbaa,this['cancelCallback']=_0x4a4e75;}['onValue'](_0x315f03,_0x2c3a91){this['snapshotCallback']['call'](null,_0x315f03,_0x2c3a91);}['onCancel'](_0x490b2e){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x490b2e);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x161302){return this['snapshotCallback']===_0x161302['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x161302['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x161302['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x334a97,_0x357b66,_0x231e67,_0x28b5a3){this['_repo']=_0x334a97,this['_path']=_0x357b66,this['_queryParams']=_0x231e67,this['_orderByCalled']=_0x28b5a3;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x2969ed=rr(this['_queryParams']),_0xe26a19=Hi(_0x2969ed);return _0xe26a19==='{}'?'default':_0xe26a19;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x1db19b){if(_0x1db19b=N(_0x1db19b),!(_0x1db19b instanceof be))return!0x1;const _0x748978=this['_repo']===_0x1db19b['_repo'],_0x484aed=ji(this['_path'],_0x1db19b['_path']),_0x3b6d50=this['_queryIdentifier']===_0x1db19b['_queryIdentifier'];return _0x748978&&_0x484aed&&_0x3b6d50;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x2d5dbe,_0x427920){if(_0x2d5dbe['_orderByCalled']===!0x0)throw new Error(_0x427920+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x50e0df){let _0x59845c=null,_0x259dda=null;if(_0x50e0df['hasStart']()&&(_0x59845c=_0x50e0df['getIndexStartValue']()),_0x50e0df['hasEnd']()&&(_0x259dda=_0x50e0df['getIndexEndValue']()),_0x50e0df['getIndex']()===ye){const _0x47852d='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x3b3a3d='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x50e0df['hasStart']()){if(_0x50e0df['getIndexStartName']()!==Fe)throw new Error(_0x47852d);if(typeof _0x59845c!='string')throw new Error(_0x3b3a3d);}if(_0x50e0df['hasEnd']()){if(_0x50e0df['getIndexEndName']()!==Ie)throw new Error(_0x47852d);if(typeof _0x259dda!='string')throw new Error(_0x3b3a3d);}}else{if(_0x50e0df['getIndex']()===R){if(_0x59845c!=null&&!Tn(_0x59845c)||_0x259dda!=null&&!Tn(_0x259dda))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x50e0df['getIndex']()instanceof Qi||_0x50e0df['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x59845c!=null&&typeof _0x59845c=='object'||_0x259dda!=null&&typeof _0x259dda=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x282fbb){if(_0x282fbb['hasStart']()&&_0x282fbb['hasEnd']()&&_0x282fbb['hasLimit']()&&!_0x282fbb['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x4ffea1,_0x3ebe3c){super(_0x4ffea1,_0x3ebe3c,new Xi(),!0x1);}get['parent'](){const _0x2652bf=Ro(this['_path']);return _0x2652bf===null?null:new ee(this['_repo'],_0x2652bf);}get['root'](){let _0x2d4596=this;for(;_0x2d4596['parent']!==null;)_0x2d4596=_0x2d4596['parent'];return _0x2d4596;}}class st{constructor(_0x241b6f,_0x23da7b,_0x2740fc){this['_node']=_0x241b6f,this['ref']=_0x23da7b,this['_index']=_0x2740fc;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x47a5c3){const _0x257e37=new C(_0x47a5c3),_0x2d6d52=Ft(this['ref'],_0x47a5c3);return new st(this['_node']['getChild'](_0x257e37),_0x2d6d52,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x13c49f){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x3e71ae,_0x8f3ae7)=>_0x13c49f(new st(_0x8f3ae7,Ft(this['ref'],_0x3e71ae),R)));}['hasChild'](_0xbbc1c3){const _0x4e1a4a=new C(_0xbbc1c3);return!this['_node']['getChild'](_0x4e1a4a)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x33f96f,_0x58cf3b){return _0x33f96f=N(_0x33f96f),_0x33f96f['_checkNotDeleted']('ref'),_0x58cf3b!==void 0x0?Ft(_0x33f96f['_root'],_0x58cf3b):_0x33f96f['_root'];}function Ft(_0x55551a,_0x8b721){return _0x55551a=N(_0x55551a),y(_0x55551a['_path'])===null?pd('child','path',_0x8b721):ms('child','path',_0x8b721),new ee(_0x55551a['_repo'],k(_0x55551a['_path'],_0x8b721));}function g_(_0x23ddbc,_0xb5e145){_0x23ddbc=N(_0x23ddbc),ys('push',_0x23ddbc['_path']),zt('push',_0xb5e145,_0x23ddbc['_path'],!0x0);const _0x230aa1=la(_0x23ddbc['_repo']),_0x8d19ac=Ld(_0x230aa1),_0x5a37dd=Ft(_0x23ddbc,_0x8d19ac),_0x3fab4c=Ft(_0x23ddbc,_0x8d19ac);let _0x4dbfec;return _0xb5e145!=null?_0x4dbfec=Ud(_0x3fab4c,_0xb5e145)['then'](()=>_0x3fab4c):_0x4dbfec=Promise['resolve'](_0x3fab4c),_0x5a37dd['then']=_0x4dbfec['then']['bind'](_0x4dbfec),_0x5a37dd['catch']=_0x4dbfec['then']['bind'](_0x4dbfec,void 0x0),_0x5a37dd;}function Ud(_0x32b180,_0x5ead2b){_0x32b180=N(_0x32b180),ys('set',_0x32b180['_path']),zt('set',_0x5ead2b,_0x32b180['_path'],!0x1);const _0x429d72=new ot();return Cd(_0x32b180['_repo'],_0x32b180['_path'],_0x5ead2b,null,_0x429d72['wrapCallback'](()=>{})),_0x429d72['promise'];}function m_(_0x37a18d,_0x5ededa){fd('update',_0x5ededa,_0x37a18d['_path']);const _0x573448=new ot();return Td(_0x37a18d['_repo'],_0x37a18d['_path'],_0x5ededa,_0x573448['wrapCallback'](()=>{})),_0x573448['promise'];}function y_(_0xacc968){_0xacc968=N(_0xacc968);const _0x1e9807=new pa(()=>{}),_0x4a3c7f=new zn(_0x1e9807);return wd(_0xacc968['_repo'],_0xacc968,_0x4a3c7f)['then'](_0xf0e0d1=>new st(_0xf0e0d1,new ee(_0xacc968['_repo'],_0xacc968['_path']),_0xacc968['_queryParams']['getIndex']()));}class zn{constructor(_0x34f41e){this['callbackContext']=_0x34f41e;}['respondsTo'](_0xcf9c2){return _0xcf9c2==='value';}['createEvent'](_0x1c6ea5,_0x1f0099){const _0x4080de=_0x1f0099['_queryParams']['getIndex']();return new xd('value',this,new st(_0x1c6ea5['snapshotNode'],new ee(_0x1f0099['_repo'],_0x1f0099['_path']),_0x4080de));}['getEventRunner'](_0x4c309d){return _0x4c309d['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x4c309d['error']):()=>this['callbackContext']['onValue'](_0x4c309d['snapshot'],null);}['createCancelEvent'](_0x1ca34e,_0x44a5aa){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x1ca34e,_0x44a5aa):null;}['matches'](_0x1ebcd5){return _0x1ebcd5 instanceof zn?!_0x1ebcd5['callbackContext']||!this['callbackContext']?!0x0:_0x1ebcd5['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x1e7812,_0x2075ac,_0x558099,_0x29f019,_0x3ce3e9){const _0x546cfa=new pa(_0x558099,void 0x0),_0x339fd6=new zn(_0x546cfa);return bd(_0x1e7812['_repo'],_0x1e7812,_0x339fd6),()=>Rd(_0x1e7812['_repo'],_0x1e7812,_0x339fd6);}function Bd(_0x2ef2bf,_0x2e8d7a,_0x56e304,_0x4d9e2a){return Wd(_0x2ef2bf,'value',_0x2e8d7a);}class ft{}class ma extends ft{constructor(_0x10227c,_0x227df5){super(),this['_value']=_0x10227c,this['_key']=_0x227df5,this['type']='endAt';}['_apply'](_0x5c4746){zt('endAt',this['_value'],_0x5c4746['_path'],!0x0);const _0x10eb5a=Jh(_0x5c4746['_queryParams'],this['_value'],this['_key']);if(ga(_0x10eb5a),qn(_0x10eb5a),_0x5c4746['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x5c4746['_repo'],_0x5c4746['_path'],_0x10eb5a,_0x5c4746['_orderByCalled']);}}function v_(_0x3c3fa9,_0x26afa0){return new ma(_0x3c3fa9,_0x26afa0);}class ya extends ft{constructor(_0x2cd4d0,_0x1abc18){super(),this['_value']=_0x2cd4d0,this['_key']=_0x1abc18,this['type']='startAt';}['_apply'](_0x1c5769){zt('startAt',this['_value'],_0x1c5769['_path'],!0x0);const _0x4f7661=Qh(_0x1c5769['_queryParams'],this['_value'],this['_key']);if(ga(_0x4f7661),qn(_0x4f7661),_0x1c5769['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x1c5769['_repo'],_0x1c5769['_path'],_0x4f7661,_0x1c5769['_orderByCalled']);}}function E_(_0x556b32=null,_0x27f6ca){return new ya(_0x556b32,_0x27f6ca);}class Vd extends ft{constructor(_0x7177c7){super(),this['_limit']=_0x7177c7,this['type']='limitToFirst';}['_apply'](_0x387a24){if(_0x387a24['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x387a24['_repo'],_0x387a24['_path'],Yh(_0x387a24['_queryParams'],this['_limit']),_0x387a24['_orderByCalled']);}}function I_(_0x2bc7dc){if(Math['floor'](_0x2bc7dc)!==_0x2bc7dc||_0x2bc7dc<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x2bc7dc);}class Hd extends ft{constructor(_0x14e13b){super(),this['_path']=_0x14e13b,this['type']='orderByChild';}['_apply'](_0x2d9acd){_a(_0x2d9acd,'orderByChild');const _0x1cc9ae=new C(this['_path']);if(v(_0x1cc9ae))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x381014=new Qi(_0x1cc9ae),_0x272674=xo(_0x2d9acd['_queryParams'],_0x381014);return qn(_0x272674),new be(_0x2d9acd['_repo'],_0x2d9acd['_path'],_0x272674,!0x0);}}function w_(_0x2d1b10){if(_0x2d1b10==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x2d1b10==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x2d1b10==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x2d1b10),new Hd(_0x2d1b10);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x5201eb){_a(_0x5201eb,'orderByKey');const _0x2f42f=xo(_0x5201eb['_queryParams'],ye);return qn(_0x2f42f),new be(_0x5201eb['_repo'],_0x5201eb['_path'],_0x2f42f,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x39a5ce,_0xf410f7){super(),this['_value']=_0x39a5ce,this['_key']=_0xf410f7,this['type']='equalTo';}['_apply'](_0x3c35ac){if(zt('equalTo',this['_value'],_0x3c35ac['_path'],!0x1),_0x3c35ac['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x3c35ac['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x3c35ac));}}function T_(_0x371791,_0xb81b0e){return new Gd(_0x371791,_0xb81b0e);}function S_(_0x2b00d1,..._0x5d00ca){let _0x1c2a2c=N(_0x2b00d1);for(const _0x566218 of _0x5d00ca)_0x1c2a2c=_0x566218['_apply'](_0x1c2a2c);return _0x1c2a2c;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x3a7a8a,_0x4229f2,_0x39a961,_0x208366){const _0x4c530d=_0x4229f2['lastIndexOf'](':'),_0x177303=_0x4229f2['substring'](0x0,_0x4c530d),_0x598520=at(_0x177303);_0x3a7a8a['repoInfo_']=new yo(_0x4229f2,_0x598520,_0x3a7a8a['repoInfo_']['namespace'],_0x3a7a8a['repoInfo_']['webSocketOnly'],_0x3a7a8a['repoInfo_']['nodeAdmin'],_0x3a7a8a['repoInfo_']['persistenceKey'],_0x3a7a8a['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x39a961),_0x208366&&(_0x3a7a8a['authTokenProvider_']=_0x208366);}function Kd(_0x192d54,_0x5c4af3,_0x244c3f,_0x279ebe,_0xc606a5){let _0x14727f=_0x279ebe||_0x192d54['options']['databaseURL'];_0x14727f===void 0x0&&(_0x192d54['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x192d54['options']['projectId']),_0x14727f=_0x192d54['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x582384=vr(_0x14727f,_0xc606a5),_0x3c49f0=_0x582384['repoInfo'],_0x3899a6;typeof process<'u'&&Vs&&(_0x3899a6=Vs[qd]),_0x3899a6?(_0x14727f='http://'+_0x3899a6+'?ns='+_0x3c49f0['namespace'],_0x582384=vr(_0x14727f,_0xc606a5),_0x3c49f0=_0x582384['repoInfo']):_0x582384['repoInfo']['secure'];const _0x23bae1=new eh(_0x192d54['name'],_0x192d54['options'],_0x5c4af3);_d('Invalid\x20Firebase\x20Database\x20URL',_0x582384),v(_0x582384['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x58af88=Qd(_0x3c49f0,_0x192d54,_0x23bae1,new Zl(_0x192d54,_0x244c3f));return new Jd(_0x58af88,_0x192d54);}function Yd(_0x116406,_0x5a040a){const _0xa78e54=Ni[_0x5a040a];(!_0xa78e54||_0xa78e54[_0x116406['key']]!==_0x116406)&&ae('Database\x20'+_0x5a040a+'('+_0x116406['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x116406),delete _0xa78e54[_0x116406['key']];}function Qd(_0x50ef98,_0x2753ba,_0x208178,_0x19a84f){let _0x2e565e=Ni[_0x2753ba['name']];_0x2e565e||(_0x2e565e={},Ni[_0x2753ba['name']]=_0x2e565e);let _0x355930=_0x2e565e[_0x50ef98['toURLString']()];return _0x355930&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x355930=new vd(_0x50ef98,zd,_0x208178,_0x19a84f),_0x2e565e[_0x50ef98['toURLString']()]=_0x355930,_0x355930;}class Jd{constructor(_0x68da87,_0x510f62){this['_repoInternal']=_0x68da87,this['app']=_0x510f62,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x39c4f2){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x39c4f2+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x18c872=Zr(),_0x891e75){const _0xc5f02d=Bi(_0x18c872,'database')['getImmediate']({'identifier':_0x891e75});if(!_0xc5f02d['_instanceStarted']){const _0x106ef8=cc('database');_0x106ef8&&Xd(_0xc5f02d,..._0x106ef8);}return _0xc5f02d;}function Xd(_0x1efa26,_0x5b1346,_0x1fb913,_0x550b9a={}){_0x1efa26=N(_0x1efa26),_0x1efa26['_checkNotDeleted']('useEmulator');const _0x66dca0=_0x5b1346+':'+_0x1fb913,_0x7dff84=_0x1efa26['_repoInternal'];if(_0x1efa26['_instanceStarted']){if(_0x66dca0===_0x1efa26['_repoInternal']['repoInfo_']['host']&&Me(_0x550b9a,_0x7dff84['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x45732d;if(_0x7dff84['repoInfo_']['nodeAdmin'])_0x550b9a['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x45732d=new nn(nn['OWNER']);else{if(_0x550b9a['mockUserToken']){const _0x277b8e=typeof _0x550b9a['mockUserToken']=='string'?_0x550b9a['mockUserToken']:lc(_0x550b9a['mockUserToken'],_0x1efa26['app']['options']['projectId']);_0x45732d=new nn(_0x277b8e);}}at(_0x5b1346)&&(jr(_0x5b1346),Kr('Database',!0x0)),jd(_0x7dff84,_0x66dca0,_0x550b9a,_0x45732d);}function R_(_0x33d003){_0x33d003=N(_0x33d003),_0x33d003['_checkNotDeleted']('goOffline'),ha(_0x33d003['_repo']);}function A_(_0x292909){_0x292909=N(_0x292909),_0x292909['_checkNotDeleted']('goOnline'),Ad(_0x292909['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x2ba7dd){Ul(lt),Ze(new Le('database',(_0x47ba1f,{instanceIdentifier:_0x4fdc86})=>{const _0x93b61f=_0x47ba1f['getProvider']('app')['getImmediate'](),_0x116142=_0x47ba1f['getProvider']('auth-internal'),_0x4c8b6f=_0x47ba1f['getProvider']('app-check-internal');return Kd(_0x93b61f,_0x116142,_0x4c8b6f,_0x4fdc86);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x2ba7dd),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x18ba15,_0xc540d2){this['committed']=_0x18ba15,this['snapshot']=_0xc540d2;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x10c120,_0xe961cf,_0x2fb189){if(_0x10c120=N(_0x10c120),ys('Reference.transaction',_0x10c120['_path']),_0x10c120['key']==='.length'||_0x10c120['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x10c120['key']+'\x20is\x20a\x20read-only\x20object.';const _0x441f20=!0x0,_0x1439dd=new ot(),_0x3057a3=(_0x3892e4,_0x2250a0,_0x2e194d)=>{let _0xabfd77=null;_0x3892e4?_0x1439dd['reject'](_0x3892e4):(_0xabfd77=new st(_0x2e194d,new ee(_0x10c120['_repo'],_0x10c120['_path']),R),_0x1439dd['resolve'](new tf(_0x2250a0,_0xabfd77)));},_0x176fc6=Bd(_0x10c120,()=>{});return kd(_0x10c120['_repo'],_0x10c120['_path'],_0xe961cf,_0x3057a3,_0x176fc6,_0x441f20),_0x1439dd['promise'];}se['prototype']['simpleListen']=function(_0x45805b,_0x30e299){this['sendRequest']('q',{'p':_0x45805b},_0x30e299);},se['prototype']['echo']=function(_0x455e5d,_0x2fc966){this['sendRequest']('echo',{'d':_0x455e5d},_0x2fc966);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x131eea,..._0x4aa8a3){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x131eea,..._0x4aa8a3);}function sn(_0x44d7f5,..._0x4f4cb2){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x44d7f5,..._0x4f4cb2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x17b3d3,..._0x5b1494){throw ws(_0x17b3d3,..._0x5b1494);}function X(_0x2665fe,..._0x1bd832){return ws(_0x2665fe,..._0x1bd832);}function Ia(_0x20460d,_0x43f7fd,_0x3cbcc2){const _0x42d8c8={...nf(),[_0x43f7fd]:_0x3cbcc2};return new Bt('auth','Firebase',_0x42d8c8)['create'](_0x43f7fd,{'appName':_0x20460d['name']});}function re(_0x2c1cef){return Ia(_0x2c1cef,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x393746,..._0x591c2f){if(typeof _0x393746!='string'){const _0x435559=_0x591c2f[0x0],_0x66c91d=[..._0x591c2f['slice'](0x1)];return _0x66c91d[0x0]&&(_0x66c91d[0x0]['appName']=_0x393746['name']),_0x393746['_errorFactory']['create'](_0x435559,..._0x66c91d);}return Ea['create'](_0x393746,..._0x591c2f);}function m(_0x408a03,_0x4c8193,..._0x18d55e){if(!_0x408a03)throw ws(_0x4c8193,..._0x18d55e);}function ne(_0xe15261){const _0x13f4ca='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0xe15261;throw sn(_0x13f4ca),new Error(_0x13f4ca);}function ce(_0x4e45cc,_0x579b50){_0x4e45cc||ne(_0x579b50);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x4046df;return typeof self<'u'&&((_0x4046df=self['location'])==null?void 0x0:_0x4046df['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x2510c0;return typeof self<'u'&&((_0x2510c0=self['location'])==null?void 0x0:_0x2510c0['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x566a01=navigator;return _0x566a01['languages']&&_0x566a01['languages'][0x0]||_0x566a01['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x242ce2,_0x3d2819){this['shortDelay']=_0x242ce2,this['longDelay']=_0x3d2819,ce(_0x3d2819>_0x242ce2,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x211e84,_0x19a189){ce(_0x211e84['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0xb408dd}=_0x211e84['emulator'];return _0x19a189?''+_0xb408dd+(_0x19a189['startsWith']('/')?_0x19a189['slice'](0x1):_0x19a189):_0xb408dd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x2483aa,_0x20e580,_0x1f0086){this['fetchImpl']=_0x2483aa,_0x20e580&&(this['headersImpl']=_0x20e580),_0x1f0086&&(this['responseImpl']=_0x1f0086);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x235504,_0x507ef9){return _0x235504['tenantId']&&!_0x507ef9['tenantId']?{..._0x507ef9,'tenantId':_0x235504['tenantId']}:_0x507ef9;}async function Ae(_0x8d83a3,_0x3a561c,_0x9589f2,_0x4aeb83,_0x4f34cd={}){return Ca(_0x8d83a3,_0x4f34cd,async()=>{let _0x34cf7c={},_0x1643a7={};_0x4aeb83&&(_0x3a561c==='GET'?_0x1643a7=_0x4aeb83:_0x34cf7c={'body':JSON['stringify'](_0x4aeb83)});const _0x569f01=ct({'key':_0x8d83a3['config']['apiKey'],..._0x1643a7})['slice'](0x1),_0x2a0057=await _0x8d83a3['_getAdditionalHeaders']();_0x2a0057['Content-Type']='application/json',_0x8d83a3['languageCode']&&(_0x2a0057['X-Firebase-Locale']=_0x8d83a3['languageCode']);const _0x5cf9ca={'method':_0x3a561c,'headers':_0x2a0057,..._0x34cf7c};return dc()||(_0x5cf9ca['referrerPolicy']='no-referrer'),_0x8d83a3['emulatorConfig']&&at(_0x8d83a3['emulatorConfig']['host'])&&(_0x5cf9ca['credentials']='include'),wa['fetch']()(await Ta(_0x8d83a3,_0x8d83a3['config']['apiHost'],_0x9589f2,_0x569f01),_0x5cf9ca);});}async function Ca(_0x354047,_0x528084,_0x59886b){_0x354047['_canInitEmulator']=!0x1;const _0x4c702f={...cf,..._0x528084};try{const _0x2d7120=new df(_0x354047),_0x164f9f=await Promise['race']([_0x59886b(),_0x2d7120['promise']]);_0x2d7120['clearNetworkTimeout']();const _0x36f0fe=await _0x164f9f['json']();if('needConfirmation'in _0x36f0fe)throw tn(_0x354047,'account-exists-with-different-credential',_0x36f0fe);if(_0x164f9f['ok']&&!('errorMessage'in _0x36f0fe))return _0x36f0fe;{const _0x24970b=_0x164f9f['ok']?_0x36f0fe['errorMessage']:_0x36f0fe['error']['message'],[_0x34bee1,_0x54ee35]=_0x24970b['split']('\x20:\x20');if(_0x34bee1==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x354047,'credential-already-in-use',_0x36f0fe);if(_0x34bee1==='EMAIL_EXISTS')throw tn(_0x354047,'email-already-in-use',_0x36f0fe);if(_0x34bee1==='USER_DISABLED')throw tn(_0x354047,'user-disabled',_0x36f0fe);const _0x17075d=_0x4c702f[_0x34bee1]||_0x34bee1['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x54ee35)throw Ia(_0x354047,_0x17075d,_0x54ee35);Q(_0x354047,_0x17075d);}}catch(_0xe69d94){if(_0xe69d94 instanceof Se)throw _0xe69d94;Q(_0x354047,'network-request-failed',{'message':String(_0xe69d94)});}}async function Qt(_0x4d63b7,_0x5007aa,_0x248b61,_0x21525a,_0x2c26b8={}){const _0xaa6a94=await Ae(_0x4d63b7,_0x5007aa,_0x248b61,_0x21525a,_0x2c26b8);return'mfaPendingCredential'in _0xaa6a94&&Q(_0x4d63b7,'multi-factor-auth-required',{'_serverResponse':_0xaa6a94}),_0xaa6a94;}async function Ta(_0x1341a4,_0x5a1344,_0x327a67,_0x62c01){const _0x9d80b0=''+_0x5a1344+_0x327a67+'?'+_0x62c01,_0x1c28a9=_0x1341a4,_0x1c9ff7=_0x1c28a9['config']['emulator']?Cs(_0x1341a4['config'],_0x9d80b0):_0x1341a4['config']['apiScheme']+'://'+_0x9d80b0;return lf['includes'](_0x327a67)&&(await _0x1c28a9['_persistenceManagerAvailable'],_0x1c28a9['_getPersistenceType']()==='COOKIE')?_0x1c28a9['_getPersistence']()['_getFinalTarget'](_0x1c9ff7)['toString']():_0x1c9ff7;}function uf(_0x283d29){switch(_0x283d29){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x4a29fe){this['auth']=_0x4a29fe,this['timer']=null,this['promise']=new Promise((_0x3643d9,_0x165a03)=>{this['timer']=setTimeout(()=>_0x165a03(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x1421ba,_0x118eb4,_0x4b134e){const _0x5ba231={'appName':_0x1421ba['name']};_0x4b134e['email']&&(_0x5ba231['email']=_0x4b134e['email']),_0x4b134e['phoneNumber']&&(_0x5ba231['phoneNumber']=_0x4b134e['phoneNumber']);const _0x21b5ae=X(_0x1421ba,_0x118eb4,_0x5ba231);return _0x21b5ae['customData']['_tokenResponse']=_0x4b134e,_0x21b5ae;}function wr(_0x56035f){return _0x56035f!==void 0x0&&_0x56035f['enterprise']!==void 0x0;}class ff{constructor(_0x32b2e7){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x32b2e7['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x32b2e7['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x32b2e7['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x4a5c7d){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x5dd138 of this['recaptchaEnforcementState'])if(_0x5dd138['provider']&&_0x5dd138['provider']===_0x4a5c7d)return uf(_0x5dd138['enforcementState']);return null;}['isProviderEnabled'](_0x1aeee1){return this['getProviderEnforcementState'](_0x1aeee1)==='ENFORCE'||this['getProviderEnforcementState'](_0x1aeee1)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x5cd4ba,_0x22c01a){return Ae(_0x5cd4ba,'GET','/v2/recaptchaConfig',Re(_0x5cd4ba,_0x22c01a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x3e887d,_0x177fb4){return Ae(_0x3e887d,'POST','/v1/accounts:delete',_0x177fb4);}async function bn(_0x4a4644,_0x5b299b){return Ae(_0x4a4644,'POST','/v1/accounts:lookup',_0x5b299b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x147f2c){if(_0x147f2c)try{const _0x214180=new Date(Number(_0x147f2c));if(!isNaN(_0x214180['getTime']()))return _0x214180['toUTCString']();}catch{}}async function gf(_0x32a92c,_0x165865=!0x1){const _0x22e6c3=N(_0x32a92c),_0x1a15d5=await _0x22e6c3['getIdToken'](_0x165865),_0x2152f3=Ts(_0x1a15d5);m(_0x2152f3&&_0x2152f3['exp']&&_0x2152f3['auth_time']&&_0x2152f3['iat'],_0x22e6c3['auth'],'internal-error');const _0x3fb9fd=typeof _0x2152f3['firebase']=='object'?_0x2152f3['firebase']:void 0x0,_0x37d9cb=_0x3fb9fd==null?void 0x0:_0x3fb9fd['sign_in_provider'];return{'claims':_0x2152f3,'token':_0x1a15d5,'authTime':Rt(li(_0x2152f3['auth_time'])),'issuedAtTime':Rt(li(_0x2152f3['iat'])),'expirationTime':Rt(li(_0x2152f3['exp'])),'signInProvider':_0x37d9cb||null,'signInSecondFactor':(_0x3fb9fd==null?void 0x0:_0x3fb9fd['sign_in_second_factor'])||null};}function li(_0x2072e5){return Number(_0x2072e5)*0x3e8;}function Ts(_0x4c2718){const [_0x305a07,_0x2be69e,_0x10bc22]=_0x4c2718['split']('.');if(_0x305a07===void 0x0||_0x2be69e===void 0x0||_0x10bc22===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x5d0543=ln(_0x2be69e);return _0x5d0543?JSON['parse'](_0x5d0543):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x445f00){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x445f00==null?void 0x0:_0x445f00['toString']()),null;}}function Cr(_0x338570){const _0x4307bb=Ts(_0x338570);return m(_0x4307bb,'internal-error'),m(typeof _0x4307bb['exp']<'u','internal-error'),m(typeof _0x4307bb['iat']<'u','internal-error'),Number(_0x4307bb['exp'])-Number(_0x4307bb['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x695f52,_0x2d9675,_0x372500=!0x1){if(_0x372500)return _0x2d9675;try{return await _0x2d9675;}catch(_0x569f7f){throw _0x569f7f instanceof Se&&mf(_0x569f7f)&&_0x695f52['auth']['currentUser']===_0x695f52&&await _0x695f52['auth']['signOut'](),_0x569f7f;}}function mf({code:_0x5c1c20}){return _0x5c1c20==='auth/user-disabled'||_0x5c1c20==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0xcd06e){this['user']=_0xcd06e,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0xf01bcc){if(_0xf01bcc){const _0x5a431b=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x5a431b;}else{this['errorBackoff']=0x7530;const _0x263419=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x263419);}}['schedule'](_0x9b8d5d=!0x1){if(!this['isRunning'])return;const _0x4c7de6=this['getInterval'](_0x9b8d5d);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x4c7de6);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x2f3d3c){(_0x2f3d3c==null?void 0x0:_0x2f3d3c['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x4d9595,_0x3c9f78){this['createdAt']=_0x4d9595,this['lastLoginAt']=_0x3c9f78,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x5f0d3e){this['createdAt']=_0x5f0d3e['createdAt'],this['lastLoginAt']=_0x5f0d3e['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x1fcd79){var _0x4f7232;const _0x54c16c=_0x1fcd79['auth'],_0x3f86c9=await _0x1fcd79['getIdToken'](),_0x3d8232=await Ut(_0x1fcd79,bn(_0x54c16c,{'idToken':_0x3f86c9}));m(_0x3d8232==null?void 0x0:_0x3d8232['users']['length'],_0x54c16c,'internal-error');const _0x4d3fec=_0x3d8232['users'][0x0];_0x1fcd79['_notifyReloadListener'](_0x4d3fec);const _0x4afec4=(_0x4f7232=_0x4d3fec['providerUserInfo'])!=null&&_0x4f7232['length']?Sa(_0x4d3fec['providerUserInfo']):[],_0x3356e8=Ef(_0x1fcd79['providerData'],_0x4afec4),_0x2e3cca=_0x1fcd79['isAnonymous'],_0x28014c=!(_0x1fcd79['email']&&_0x4d3fec['passwordHash'])&&!(_0x3356e8!=null&&_0x3356e8['length']),_0x327919=_0x2e3cca?_0x28014c:!0x1,_0x35d929={'uid':_0x4d3fec['localId'],'displayName':_0x4d3fec['displayName']||null,'photoURL':_0x4d3fec['photoUrl']||null,'email':_0x4d3fec['email']||null,'emailVerified':_0x4d3fec['emailVerified']||!0x1,'phoneNumber':_0x4d3fec['phoneNumber']||null,'tenantId':_0x4d3fec['tenantId']||null,'providerData':_0x3356e8,'metadata':new Oi(_0x4d3fec['createdAt'],_0x4d3fec['lastLoginAt']),'isAnonymous':_0x327919};Object['assign'](_0x1fcd79,_0x35d929);}async function vf(_0x474677){const _0x249e53=N(_0x474677);await Rn(_0x249e53),await _0x249e53['auth']['_persistUserIfCurrent'](_0x249e53),_0x249e53['auth']['_notifyListenersIfCurrent'](_0x249e53);}function Ef(_0x5d72f0,_0xcbcdf9){return[..._0x5d72f0['filter'](_0x3f85a5=>!_0xcbcdf9['some'](_0x12b602=>_0x12b602['providerId']===_0x3f85a5['providerId'])),..._0xcbcdf9];}function Sa(_0x58f886){return _0x58f886['map'](({providerId:_0x42ce1c,..._0x4d9f0c})=>({'providerId':_0x42ce1c,'uid':_0x4d9f0c['rawId']||'','displayName':_0x4d9f0c['displayName']||null,'email':_0x4d9f0c['email']||null,'phoneNumber':_0x4d9f0c['phoneNumber']||null,'photoURL':_0x4d9f0c['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x4f065b,_0x484d68){const _0x2d91e7=await Ca(_0x4f065b,{},async()=>{const _0x4f00aa=ct({'grant_type':'refresh_token','refresh_token':_0x484d68})['slice'](0x1),{tokenApiHost:_0x22c9d7,apiKey:_0x54f528}=_0x4f065b['config'],_0x443c45=await Ta(_0x4f065b,_0x22c9d7,'/v1/token','key='+_0x54f528),_0x32a6cd=await _0x4f065b['_getAdditionalHeaders']();_0x32a6cd['Content-Type']='application/x-www-form-urlencoded';const _0x250ba4={'method':'POST','headers':_0x32a6cd,'body':_0x4f00aa};return _0x4f065b['emulatorConfig']&&at(_0x4f065b['emulatorConfig']['host'])&&(_0x250ba4['credentials']='include'),wa['fetch']()(_0x443c45,_0x250ba4);});return{'accessToken':_0x2d91e7['access_token'],'expiresIn':_0x2d91e7['expires_in'],'refreshToken':_0x2d91e7['refresh_token']};}async function wf(_0x850c09,_0x84e0ca){return Ae(_0x850c09,'POST','/v2/accounts:revokeToken',Re(_0x850c09,_0x84e0ca));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x265855){m(_0x265855['idToken'],'internal-error'),m(typeof _0x265855['idToken']<'u','internal-error'),m(typeof _0x265855['refreshToken']<'u','internal-error');const _0x43e496='expiresIn'in _0x265855&&typeof _0x265855['expiresIn']<'u'?Number(_0x265855['expiresIn']):Cr(_0x265855['idToken']);this['updateTokensAndExpiration'](_0x265855['idToken'],_0x265855['refreshToken'],_0x43e496);}['updateFromIdToken'](_0x9eef0f){m(_0x9eef0f['length']!==0x0,'internal-error');const _0x43e57a=Cr(_0x9eef0f);this['updateTokensAndExpiration'](_0x9eef0f,null,_0x43e57a);}async['getToken'](_0xd712cf,_0x4a1df2=!0x1){return!_0x4a1df2&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0xd712cf,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0xd712cf,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x338247,_0x46e114){const {accessToken:_0x7b92ce,refreshToken:_0x180913,expiresIn:_0x264082}=await If(_0x338247,_0x46e114);this['updateTokensAndExpiration'](_0x7b92ce,_0x180913,Number(_0x264082));}['updateTokensAndExpiration'](_0x4829f8,_0x16d165,_0xc77543){this['refreshToken']=_0x16d165||null,this['accessToken']=_0x4829f8||null,this['expirationTime']=Date['now']()+_0xc77543*0x3e8;}static['fromJSON'](_0x55ad42,_0x515f11){const {refreshToken:_0x46ac4f,accessToken:_0x1dc19c,expirationTime:_0x3005ac}=_0x515f11,_0x244bd2=new Qe();return _0x46ac4f&&(m(typeof _0x46ac4f=='string','internal-error',{'appName':_0x55ad42}),_0x244bd2['refreshToken']=_0x46ac4f),_0x1dc19c&&(m(typeof _0x1dc19c=='string','internal-error',{'appName':_0x55ad42}),_0x244bd2['accessToken']=_0x1dc19c),_0x3005ac&&(m(typeof _0x3005ac=='number','internal-error',{'appName':_0x55ad42}),_0x244bd2['expirationTime']=_0x3005ac),_0x244bd2;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x533f4e){this['accessToken']=_0x533f4e['accessToken'],this['refreshToken']=_0x533f4e['refreshToken'],this['expirationTime']=_0x533f4e['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0xbdae97,_0x253f57){m(typeof _0xbdae97=='string'||typeof _0xbdae97>'u','internal-error',{'appName':_0x253f57});}class K{constructor({uid:_0x23f3f0,auth:_0x47f37b,stsTokenManager:_0x119a2a,..._0x5d7735}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x23f3f0,this['auth']=_0x47f37b,this['stsTokenManager']=_0x119a2a,this['accessToken']=_0x119a2a['accessToken'],this['displayName']=_0x5d7735['displayName']||null,this['email']=_0x5d7735['email']||null,this['emailVerified']=_0x5d7735['emailVerified']||!0x1,this['phoneNumber']=_0x5d7735['phoneNumber']||null,this['photoURL']=_0x5d7735['photoURL']||null,this['isAnonymous']=_0x5d7735['isAnonymous']||!0x1,this['tenantId']=_0x5d7735['tenantId']||null,this['providerData']=_0x5d7735['providerData']?[..._0x5d7735['providerData']]:[],this['metadata']=new Oi(_0x5d7735['createdAt']||void 0x0,_0x5d7735['lastLoginAt']||void 0x0);}async['getIdToken'](_0x423245){const _0x161655=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x423245));return m(_0x161655,this['auth'],'internal-error'),this['accessToken']!==_0x161655&&(this['accessToken']=_0x161655,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x161655;}['getIdTokenResult'](_0x1e1113){return gf(this,_0x1e1113);}['reload'](){return vf(this);}['_assign'](_0x47b84b){this!==_0x47b84b&&(m(this['uid']===_0x47b84b['uid'],this['auth'],'internal-error'),this['displayName']=_0x47b84b['displayName'],this['photoURL']=_0x47b84b['photoURL'],this['email']=_0x47b84b['email'],this['emailVerified']=_0x47b84b['emailVerified'],this['phoneNumber']=_0x47b84b['phoneNumber'],this['isAnonymous']=_0x47b84b['isAnonymous'],this['tenantId']=_0x47b84b['tenantId'],this['providerData']=_0x47b84b['providerData']['map'](_0x40a64d=>({..._0x40a64d})),this['metadata']['_copy'](_0x47b84b['metadata']),this['stsTokenManager']['_assign'](_0x47b84b['stsTokenManager']));}['_clone'](_0x2d703d){const _0x46e574=new K({...this,'auth':_0x2d703d,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x46e574['metadata']['_copy'](this['metadata']),_0x46e574;}['_onReload'](_0x2aaf4d){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x2aaf4d,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x52d11c){this['reloadListener']?this['reloadListener'](_0x52d11c):this['reloadUserInfo']=_0x52d11c;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x40054e,_0x373858=!0x1){let _0x51c568=!0x1;_0x40054e['idToken']&&_0x40054e['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x40054e),_0x51c568=!0x0),_0x373858&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x51c568&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x49d08b=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x49d08b})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0xa2ec10=>({..._0xa2ec10})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x6637a6,_0x2e6993){const _0x2337ef=_0x2e6993['displayName']??void 0x0,_0x424628=_0x2e6993['email']??void 0x0,_0x2dc61a=_0x2e6993['phoneNumber']??void 0x0,_0x140bde=_0x2e6993['photoURL']??void 0x0,_0x942a54=_0x2e6993['tenantId']??void 0x0,_0x12e2b3=_0x2e6993['_redirectEventId']??void 0x0,_0x181218=_0x2e6993['createdAt']??void 0x0,_0x390a27=_0x2e6993['lastLoginAt']??void 0x0,{uid:_0x39a258,emailVerified:_0x4aff75,isAnonymous:_0x530829,providerData:_0x1b77c8,stsTokenManager:_0x2f9481}=_0x2e6993;m(_0x39a258&&_0x2f9481,_0x6637a6,'internal-error');const _0x4141ce=Qe['fromJSON'](this['name'],_0x2f9481);m(typeof _0x39a258=='string',_0x6637a6,'internal-error'),le(_0x2337ef,_0x6637a6['name']),le(_0x424628,_0x6637a6['name']),m(typeof _0x4aff75=='boolean',_0x6637a6,'internal-error'),m(typeof _0x530829=='boolean',_0x6637a6,'internal-error'),le(_0x2dc61a,_0x6637a6['name']),le(_0x140bde,_0x6637a6['name']),le(_0x942a54,_0x6637a6['name']),le(_0x12e2b3,_0x6637a6['name']),le(_0x181218,_0x6637a6['name']),le(_0x390a27,_0x6637a6['name']);const _0x134e77=new K({'uid':_0x39a258,'auth':_0x6637a6,'email':_0x424628,'emailVerified':_0x4aff75,'displayName':_0x2337ef,'isAnonymous':_0x530829,'photoURL':_0x140bde,'phoneNumber':_0x2dc61a,'tenantId':_0x942a54,'stsTokenManager':_0x4141ce,'createdAt':_0x181218,'lastLoginAt':_0x390a27});return _0x1b77c8&&Array['isArray'](_0x1b77c8)&&(_0x134e77['providerData']=_0x1b77c8['map'](_0x200b7d=>({..._0x200b7d}))),_0x12e2b3&&(_0x134e77['_redirectEventId']=_0x12e2b3),_0x134e77;}static async['_fromIdTokenResponse'](_0x26aa53,_0xc4d9e6,_0x1d2e12=!0x1){const _0x5675af=new Qe();_0x5675af['updateFromServerResponse'](_0xc4d9e6);const _0x441a14=new K({'uid':_0xc4d9e6['localId'],'auth':_0x26aa53,'stsTokenManager':_0x5675af,'isAnonymous':_0x1d2e12});return await Rn(_0x441a14),_0x441a14;}static async['_fromGetAccountInfoResponse'](_0x6d2ac9,_0x1cb9ca,_0x4e481c){const _0x5b5491=_0x1cb9ca['users'][0x0];m(_0x5b5491['localId']!==void 0x0,'internal-error');const _0x157eb4=_0x5b5491['providerUserInfo']!==void 0x0?Sa(_0x5b5491['providerUserInfo']):[],_0x220945=!(_0x5b5491['email']&&_0x5b5491['passwordHash'])&&!(_0x157eb4!=null&&_0x157eb4['length']),_0x376f6d=new Qe();_0x376f6d['updateFromIdToken'](_0x4e481c);const _0x38b32f=new K({'uid':_0x5b5491['localId'],'auth':_0x6d2ac9,'stsTokenManager':_0x376f6d,'isAnonymous':_0x220945}),_0x43b23f={'uid':_0x5b5491['localId'],'displayName':_0x5b5491['displayName']||null,'photoURL':_0x5b5491['photoUrl']||null,'email':_0x5b5491['email']||null,'emailVerified':_0x5b5491['emailVerified']||!0x1,'phoneNumber':_0x5b5491['phoneNumber']||null,'tenantId':_0x5b5491['tenantId']||null,'providerData':_0x157eb4,'metadata':new Oi(_0x5b5491['createdAt'],_0x5b5491['lastLoginAt']),'isAnonymous':!(_0x5b5491['email']&&_0x5b5491['passwordHash'])&&!(_0x157eb4!=null&&_0x157eb4['length'])};return Object['assign'](_0x38b32f,_0x43b23f),_0x38b32f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x3a3655){ce(_0x3a3655 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x1d8cc6=Tr['get'](_0x3a3655);return _0x1d8cc6?(ce(_0x1d8cc6 instanceof _0x3a3655,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x1d8cc6):(_0x1d8cc6=new _0x3a3655(),Tr['set'](_0x3a3655,_0x1d8cc6),_0x1d8cc6);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0xf276d,_0x1edc31){this['storage'][_0xf276d]=_0x1edc31;}async['_get'](_0x5c2a66){const _0x57fa02=this['storage'][_0x5c2a66];return _0x57fa02===void 0x0?null:_0x57fa02;}async['_remove'](_0x324655){delete this['storage'][_0x324655];}['_addListener'](_0x187793,_0x477f16){}['_removeListener'](_0x421b96,_0x3e615c){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0xf004b3,_0x107b0e,_0x1388a8){return'firebase:'+_0xf004b3+':'+_0x107b0e+':'+_0x1388a8;}class Je{constructor(_0x51d837,_0x3db193,_0x33bae2){this['persistence']=_0x51d837,this['auth']=_0x3db193,this['userKey']=_0x33bae2;const {config:_0x6db8ef,name:_0x42eac9}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x6db8ef['apiKey'],_0x42eac9),this['fullPersistenceKey']=rn('persistence',_0x6db8ef['apiKey'],_0x42eac9),this['boundEventHandler']=_0x3db193['_onStorageEvent']['bind'](_0x3db193),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x5dc250){return this['persistence']['_set'](this['fullUserKey'],_0x5dc250['toJSON']());}async['getCurrentUser'](){const _0xd3d4f9=await this['persistence']['_get'](this['fullUserKey']);if(!_0xd3d4f9)return null;if(typeof _0xd3d4f9=='string'){const _0x39e0e7=await bn(this['auth'],{'idToken':_0xd3d4f9})['catch'](()=>{});return _0x39e0e7?K['_fromGetAccountInfoResponse'](this['auth'],_0x39e0e7,_0xd3d4f9):null;}return K['_fromJSON'](this['auth'],_0xd3d4f9);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x3d91be){if(this['persistence']===_0x3d91be)return;const _0x1cb9f2=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x3d91be,_0x1cb9f2)return this['setCurrentUser'](_0x1cb9f2);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x2fa6d6,_0x7de9ca,_0x20106b='authUser'){if(!_0x7de9ca['length'])return new Je(ie(Sr),_0x2fa6d6,_0x20106b);const _0x2c9712=(await Promise['all'](_0x7de9ca['map'](async _0x46c1b6=>{if(await _0x46c1b6['_isAvailable']())return _0x46c1b6;})))['filter'](_0x324449=>_0x324449);let _0x47adb9=_0x2c9712[0x0]||ie(Sr);const _0x1c7e7d=rn(_0x20106b,_0x2fa6d6['config']['apiKey'],_0x2fa6d6['name']);let _0x3f6204=null;for(const _0x5e3798 of _0x7de9ca)try{const _0x357bec=await _0x5e3798['_get'](_0x1c7e7d);if(_0x357bec){let _0x8274f1;if(typeof _0x357bec=='string'){const _0x2ad006=await bn(_0x2fa6d6,{'idToken':_0x357bec})['catch'](()=>{});if(!_0x2ad006)break;_0x8274f1=await K['_fromGetAccountInfoResponse'](_0x2fa6d6,_0x2ad006,_0x357bec);}else _0x8274f1=K['_fromJSON'](_0x2fa6d6,_0x357bec);_0x5e3798!==_0x47adb9&&(_0x3f6204=_0x8274f1),_0x47adb9=_0x5e3798;break;}}catch{}const _0x50c1f2=_0x2c9712['filter'](_0x7a1ef7=>_0x7a1ef7['_shouldAllowMigration']);return!_0x47adb9['_shouldAllowMigration']||!_0x50c1f2['length']?new Je(_0x47adb9,_0x2fa6d6,_0x20106b):(_0x47adb9=_0x50c1f2[0x0],_0x3f6204&&await _0x47adb9['_set'](_0x1c7e7d,_0x3f6204['toJSON']()),await Promise['all'](_0x7de9ca['map'](async _0x5eec88=>{if(_0x5eec88!==_0x47adb9)try{await _0x5eec88['_remove'](_0x1c7e7d);}catch{}})),new Je(_0x47adb9,_0x2fa6d6,_0x20106b));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x1a54c8){const _0x755610=_0x1a54c8['toLowerCase']();if(_0x755610['includes']('opera/')||_0x755610['includes']('opr/')||_0x755610['includes']('opios/'))return'Opera';if(Na(_0x755610))return'IEMobile';if(_0x755610['includes']('msie')||_0x755610['includes']('trident/'))return'IE';if(_0x755610['includes']('edge/'))return'Edge';if(Ra(_0x755610))return'Firefox';if(_0x755610['includes']('silk/'))return'Silk';if(Oa(_0x755610))return'Blackberry';if(Da(_0x755610))return'Webos';if(Aa(_0x755610))return'Safari';if((_0x755610['includes']('chrome/')||ka(_0x755610))&&!_0x755610['includes']('edge/'))return'Chrome';if(Pa(_0x755610))return'Android';{const _0x24662d=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0xc39689=_0x1a54c8['match'](_0x24662d);if((_0xc39689==null?void 0x0:_0xc39689['length'])===0x2)return _0xc39689[0x1];}return'Other';}function Ra(_0x1ac788=W()){return/firefox\//i['test'](_0x1ac788);}function Aa(_0x191740=W()){const _0x190150=_0x191740['toLowerCase']();return _0x190150['includes']('safari/')&&!_0x190150['includes']('chrome/')&&!_0x190150['includes']('crios/')&&!_0x190150['includes']('android');}function ka(_0x49d888=W()){return/crios\//i['test'](_0x49d888);}function Na(_0xf72273=W()){return/iemobile/i['test'](_0xf72273);}function Pa(_0x17f317=W()){return/android/i['test'](_0x17f317);}function Oa(_0x987ce1=W()){return/blackberry/i['test'](_0x987ce1);}function Da(_0x3121aa=W()){return/webos/i['test'](_0x3121aa);}function Ss(_0x2726d5=W()){return/iphone|ipad|ipod/i['test'](_0x2726d5)||/macintosh/i['test'](_0x2726d5)&&/mobile/i['test'](_0x2726d5);}function Cf(_0x4d3903=W()){var _0x20fb5c;return Ss(_0x4d3903)&&!!((_0x20fb5c=window['navigator'])!=null&&_0x20fb5c['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x44bf3e=W()){return Ss(_0x44bf3e)||Pa(_0x44bf3e)||Da(_0x44bf3e)||Oa(_0x44bf3e)||/windows phone/i['test'](_0x44bf3e)||Na(_0x44bf3e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x5ebce1,_0x2f1105=[]){let _0xb23ad2;switch(_0x5ebce1){case'Browser':_0xb23ad2=br(W());break;case'Worker':_0xb23ad2=br(W())+'-'+_0x5ebce1;break;default:_0xb23ad2=_0x5ebce1;}const _0x2b731d=_0x2f1105['length']?_0x2f1105['join'](','):'FirebaseCore-web';return _0xb23ad2+'/JsCore/'+lt+'/'+_0x2b731d;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x1bbe12){this['auth']=_0x1bbe12,this['queue']=[];}['pushCallback'](_0x1411d5,_0x300ecf){const _0x3b3617=_0x526cb5=>new Promise((_0x3c326c,_0x15a1f3)=>{try{const _0x2619d1=_0x1411d5(_0x526cb5);_0x3c326c(_0x2619d1);}catch(_0x2daa7c){_0x15a1f3(_0x2daa7c);}});_0x3b3617['onAbort']=_0x300ecf,this['queue']['push'](_0x3b3617);const _0x463c49=this['queue']['length']-0x1;return()=>{this['queue'][_0x463c49]=()=>Promise['resolve']();};}async['runMiddleware'](_0x11227a){if(this['auth']['currentUser']===_0x11227a)return;const _0x41d684=[];try{for(const _0x1b3b11 of this['queue'])await _0x1b3b11(_0x11227a),_0x1b3b11['onAbort']&&_0x41d684['push'](_0x1b3b11['onAbort']);}catch(_0x18de85){_0x41d684['reverse']();for(const _0x3c496d of _0x41d684)try{_0x3c496d();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x18de85==null?void 0x0:_0x18de85['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x5170ed,_0x1f2a2e={}){return Ae(_0x5170ed,'GET','/v2/passwordPolicy',Re(_0x5170ed,_0x1f2a2e));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0xa2938f){var _0x1add5f;const _0x493c1d=_0xa2938f['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x493c1d['minPasswordLength']??Rf,_0x493c1d['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x493c1d['maxPasswordLength']),_0x493c1d['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x493c1d['containsLowercaseCharacter']),_0x493c1d['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x493c1d['containsUppercaseCharacter']),_0x493c1d['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x493c1d['containsNumericCharacter']),_0x493c1d['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x493c1d['containsNonAlphanumericCharacter']),this['enforcementState']=_0xa2938f['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x1add5f=_0xa2938f['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x1add5f['join'](''))??'',this['forceUpgradeOnSignin']=_0xa2938f['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0xa2938f['schemaVersion'];}['validatePassword'](_0x5bcac5){const _0x669bf6={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x5bcac5,_0x669bf6),this['validatePasswordCharacterOptions'](_0x5bcac5,_0x669bf6),_0x669bf6['isValid']&&(_0x669bf6['isValid']=_0x669bf6['meetsMinPasswordLength']??!0x0),_0x669bf6['isValid']&&(_0x669bf6['isValid']=_0x669bf6['meetsMaxPasswordLength']??!0x0),_0x669bf6['isValid']&&(_0x669bf6['isValid']=_0x669bf6['containsLowercaseLetter']??!0x0),_0x669bf6['isValid']&&(_0x669bf6['isValid']=_0x669bf6['containsUppercaseLetter']??!0x0),_0x669bf6['isValid']&&(_0x669bf6['isValid']=_0x669bf6['containsNumericCharacter']??!0x0),_0x669bf6['isValid']&&(_0x669bf6['isValid']=_0x669bf6['containsNonAlphanumericCharacter']??!0x0),_0x669bf6;}['validatePasswordLengthOptions'](_0x4f4637,_0x173087){const _0xb4880e=this['customStrengthOptions']['minPasswordLength'],_0xe66a9f=this['customStrengthOptions']['maxPasswordLength'];_0xb4880e&&(_0x173087['meetsMinPasswordLength']=_0x4f4637['length']>=_0xb4880e),_0xe66a9f&&(_0x173087['meetsMaxPasswordLength']=_0x4f4637['length']<=_0xe66a9f);}['validatePasswordCharacterOptions'](_0x541596,_0xc1c1fd){this['updatePasswordCharacterOptionsStatuses'](_0xc1c1fd,!0x1,!0x1,!0x1,!0x1);let _0x317caa;for(let _0x4e472f=0x0;_0x4e472f<_0x541596['length'];_0x4e472f++)_0x317caa=_0x541596['charAt'](_0x4e472f),this['updatePasswordCharacterOptionsStatuses'](_0xc1c1fd,_0x317caa>='a'&&_0x317caa<='z',_0x317caa>='A'&&_0x317caa<='Z',_0x317caa>='0'&&_0x317caa<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x317caa));}['updatePasswordCharacterOptionsStatuses'](_0x5bde1,_0x2d0892,_0x366b9e,_0x43d14e,_0x3b1eb6){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5bde1['containsLowercaseLetter']||(_0x5bde1['containsLowercaseLetter']=_0x2d0892)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5bde1['containsUppercaseLetter']||(_0x5bde1['containsUppercaseLetter']=_0x366b9e)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5bde1['containsNumericCharacter']||(_0x5bde1['containsNumericCharacter']=_0x43d14e)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5bde1['containsNonAlphanumericCharacter']||(_0x5bde1['containsNonAlphanumericCharacter']=_0x3b1eb6));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x4787ba,_0x1dbc28,_0x1a5be3,_0x48aed7){this['app']=_0x4787ba,this['heartbeatServiceProvider']=_0x1dbc28,this['appCheckServiceProvider']=_0x1a5be3,this['config']=_0x48aed7,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x4787ba['name'],this['clientVersion']=_0x48aed7['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x1f3772=>this['_resolvePersistenceManagerAvailable']=_0x1f3772);}['_initializeWithPersistence'](_0x4f68b9,_0x141e02){return _0x141e02&&(this['_popupRedirectResolver']=ie(_0x141e02)),this['_initializationPromise']=this['queue'](async()=>{var _0x21c5c2,_0x157fea,_0x1bd8b1;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x4f68b9),(_0x21c5c2=this['_resolvePersistenceManagerAvailable'])==null||_0x21c5c2['call'](this),!this['_deleted'])){if((_0x157fea=this['_popupRedirectResolver'])!=null&&_0x157fea['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x141e02),this['lastNotifiedUid']=((_0x1bd8b1=this['currentUser'])==null?void 0x0:_0x1bd8b1['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x3bff83=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x3bff83)){if(this['currentUser']&&_0x3bff83&&this['currentUser']['uid']===_0x3bff83['uid']){this['_currentUser']['_assign'](_0x3bff83),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x3bff83,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x4922c4){try{const _0x209bff=await bn(this,{'idToken':_0x4922c4}),_0x35f818=await K['_fromGetAccountInfoResponse'](this,_0x209bff,_0x4922c4);await this['directlySetCurrentUser'](_0x35f818);}catch(_0x355e67){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x355e67),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x50a09a){var _0x3823de;if($(this['app'])){const _0x3a670d=this['app']['settings']['authIdToken'];return _0x3a670d?new Promise(_0x4a7803=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x3a670d)['then'](_0x4a7803,_0x4a7803));}):this['directlySetCurrentUser'](null);}const _0x3dc774=await this['assertedPersistence']['getCurrentUser']();let _0x3836f1=_0x3dc774,_0x351065=!0x1;if(_0x50a09a&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x434740=(_0x3823de=this['redirectUser'])==null?void 0x0:_0x3823de['_redirectEventId'],_0xc0c9bd=_0x3836f1==null?void 0x0:_0x3836f1['_redirectEventId'],_0x3451c1=await this['tryRedirectSignIn'](_0x50a09a);(!_0x434740||_0x434740===_0xc0c9bd)&&(_0x3451c1!=null&&_0x3451c1['user'])&&(_0x3836f1=_0x3451c1['user'],_0x351065=!0x0);}if(!_0x3836f1)return this['directlySetCurrentUser'](null);if(!_0x3836f1['_redirectEventId']){if(_0x351065)try{await this['beforeStateQueue']['runMiddleware'](_0x3836f1);}catch(_0x478483){_0x3836f1=_0x3dc774,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x478483));}return _0x3836f1?this['reloadAndSetCurrentUserOrClear'](_0x3836f1):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x3836f1['_redirectEventId']?this['directlySetCurrentUser'](_0x3836f1):this['reloadAndSetCurrentUserOrClear'](_0x3836f1);}async['tryRedirectSignIn'](_0x159be5){let _0x2d6c05=null;try{_0x2d6c05=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x159be5,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x2d6c05;}async['reloadAndSetCurrentUserOrClear'](_0x4f0bbd){try{await Rn(_0x4f0bbd);}catch(_0x3d4ef3){if((_0x3d4ef3==null?void 0x0:_0x3d4ef3['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x4f0bbd);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x3b6b86){if($(this['app']))return Promise['reject'](re(this));const _0x1021b1=_0x3b6b86?N(_0x3b6b86):null;return _0x1021b1&&m(_0x1021b1['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x1021b1&&_0x1021b1['_clone'](this));}async['_updateCurrentUser'](_0xaea03a,_0x3bf889=!0x1){if(!this['_deleted'])return _0xaea03a&&m(this['tenantId']===_0xaea03a['tenantId'],this,'tenant-id-mismatch'),_0x3bf889||await this['beforeStateQueue']['runMiddleware'](_0xaea03a),this['queue'](async()=>{await this['directlySetCurrentUser'](_0xaea03a),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x11f18c){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x11f18c));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x17ef9f){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x389ee4=this['_getPasswordPolicyInternal']();return _0x389ee4['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x389ee4['validatePassword'](_0x17ef9f);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0xb36ff1=await bf(this),_0x30fa6c=new Af(_0xb36ff1);this['tenantId']===null?this['_projectPasswordPolicy']=_0x30fa6c:this['_tenantPasswordPolicies'][this['tenantId']]=_0x30fa6c;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x587f6e){this['_errorFactory']=new Bt('auth','Firebase',_0x587f6e());}['onAuthStateChanged'](_0x20ebf7,_0x24c149,_0x3896b9){return this['registerStateListener'](this['authStateSubscription'],_0x20ebf7,_0x24c149,_0x3896b9);}['beforeAuthStateChanged'](_0x1835b2,_0x152668){return this['beforeStateQueue']['pushCallback'](_0x1835b2,_0x152668);}['onIdTokenChanged'](_0x247bce,_0x3809f9,_0x398ee9){return this['registerStateListener'](this['idTokenSubscription'],_0x247bce,_0x3809f9,_0x398ee9);}['authStateReady'](){return new Promise((_0x3f002c,_0xed57c7)=>{if(this['currentUser'])_0x3f002c();else{const _0x45595e=this['onAuthStateChanged'](()=>{_0x45595e(),_0x3f002c();},_0xed57c7);}});}async['revokeAccessToken'](_0x368bea){if(this['currentUser']){const _0x1577ee=await this['currentUser']['getIdToken'](),_0x10c73d={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x368bea,'idToken':_0x1577ee};this['tenantId']!=null&&(_0x10c73d['tenantId']=this['tenantId']),await wf(this,_0x10c73d);}}['toJSON'](){var _0x473949;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x473949=this['_currentUser'])==null?void 0x0:_0x473949['toJSON']()};}async['_setRedirectUser'](_0x66b727,_0x3ca97e){const _0x36ce02=await this['getOrInitRedirectPersistenceManager'](_0x3ca97e);return _0x66b727===null?_0x36ce02['removeCurrentUser']():_0x36ce02['setCurrentUser'](_0x66b727);}async['getOrInitRedirectPersistenceManager'](_0x104a2f){if(!this['redirectPersistenceManager']){const _0x55b203=_0x104a2f&&ie(_0x104a2f)||this['_popupRedirectResolver'];m(_0x55b203,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x55b203['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x3864bd){var _0x430951,_0x34f3aa;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x430951=this['_currentUser'])==null?void 0x0:_0x430951['_redirectEventId'])===_0x3864bd?this['_currentUser']:((_0x34f3aa=this['redirectUser'])==null?void 0x0:_0x34f3aa['_redirectEventId'])===_0x3864bd?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x1c3755){if(_0x1c3755===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x1c3755));}['_notifyListenersIfCurrent'](_0x861420){_0x861420===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x18e70e;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x3b3b8d=((_0x18e70e=this['currentUser'])==null?void 0x0:_0x18e70e['uid'])??null;this['lastNotifiedUid']!==_0x3b3b8d&&(this['lastNotifiedUid']=_0x3b3b8d,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x464ccc,_0xc6b78b,_0xb44405,_0x1ee7b2){if(this['_deleted'])return()=>{};const _0x30aa01=typeof _0xc6b78b=='function'?_0xc6b78b:_0xc6b78b['next']['bind'](_0xc6b78b);let _0x9e2b43=!0x1;const _0x410fcf=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x410fcf,this,'internal-error'),_0x410fcf['then'](()=>{_0x9e2b43||_0x30aa01(this['currentUser']);}),typeof _0xc6b78b=='function'){const _0xbfab77=_0x464ccc['addObserver'](_0xc6b78b,_0xb44405,_0x1ee7b2);return()=>{_0x9e2b43=!0x0,_0xbfab77();};}else{const _0x298c9b=_0x464ccc['addObserver'](_0xc6b78b);return()=>{_0x9e2b43=!0x0,_0x298c9b();};}}async['directlySetCurrentUser'](_0x3bdbf7){this['currentUser']&&this['currentUser']!==_0x3bdbf7&&this['_currentUser']['_stopProactiveRefresh'](),_0x3bdbf7&&this['isProactiveRefreshEnabled']&&_0x3bdbf7['_startProactiveRefresh'](),this['currentUser']=_0x3bdbf7,_0x3bdbf7?await this['assertedPersistence']['setCurrentUser'](_0x3bdbf7):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x15fe8c){return this['operations']=this['operations']['then'](_0x15fe8c,_0x15fe8c),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0xdf70ae){!_0xdf70ae||this['frameworks']['includes'](_0xdf70ae)||(this['frameworks']['push'](_0xdf70ae),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x302564;const _0x44180c={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x44180c['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x5d266c=await((_0x302564=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x302564['getHeartbeatsHeader']());_0x5d266c&&(_0x44180c['X-Firebase-Client']=_0x5d266c);const _0x6f02c4=await this['_getAppCheckToken']();return _0x6f02c4&&(_0x44180c['X-Firebase-AppCheck']=_0x6f02c4),_0x44180c;}async['_getAppCheckToken'](){var _0x36285e;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x15857e=await((_0x36285e=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x36285e['getToken']());return _0x15857e!=null&&_0x15857e['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x15857e['error']),_0x15857e==null?void 0x0:_0x15857e['token'];}}function qe(_0x2ffec9){return N(_0x2ffec9);}class Rr{constructor(_0x577b39){this['auth']=_0x577b39,this['observer']=null,this['addObserver']=Tc(_0x53956e=>this['observer']=_0x53956e);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x9f1278){jn=_0x9f1278;}function xa(_0x3b33f6){return jn['loadJS'](_0x3b33f6);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x1bdac7){return'__'+_0x1bdac7+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x1f9887){_0x1f9887();}['execute'](_0x11eb12,_0x20ee06){return Promise['resolve']('token');}['render'](_0x26b17c,_0x10b388){return'';}}class Lf{['ready'](_0x80f23d){_0x80f23d();}['execute'](_0x2cf5e8,_0x89e884){return Promise['resolve']('token');}['render'](_0x532384,_0x54b0df){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x367435){this['type']=xf,this['auth']=qe(_0x367435);}async['verify'](_0x3be644='verify',_0x1f6eb0=!0x1){async function _0x46ee1f(_0x14277f){if(!_0x1f6eb0){if(_0x14277f['tenantId']==null&&_0x14277f['_agentRecaptchaConfig']!=null)return _0x14277f['_agentRecaptchaConfig']['siteKey'];if(_0x14277f['tenantId']!=null&&_0x14277f['_tenantRecaptchaConfigs'][_0x14277f['tenantId']]!==void 0x0)return _0x14277f['_tenantRecaptchaConfigs'][_0x14277f['tenantId']]['siteKey'];}return new Promise(async(_0x39b88c,_0x39f066)=>{pf(_0x14277f,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x14b617=>{if(_0x14b617['recaptchaKey']===void 0x0)_0x39f066(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x29ffc9=new ff(_0x14b617);return _0x14277f['tenantId']==null?_0x14277f['_agentRecaptchaConfig']=_0x29ffc9:_0x14277f['_tenantRecaptchaConfigs'][_0x14277f['tenantId']]=_0x29ffc9,_0x39b88c(_0x29ffc9['siteKey']);}})['catch'](_0x2a14e8=>{_0x39f066(_0x2a14e8);});});}function _0x28a2b6(_0x49e0b4,_0x2e6c28,_0x163e10){const _0x162da7=window['grecaptcha'];wr(_0x162da7)?_0x162da7['enterprise']['ready'](()=>{_0x162da7['enterprise']['execute'](_0x49e0b4,{'action':_0x3be644})['then'](_0x21f4f6=>{_0x2e6c28(_0x21f4f6);})['catch'](()=>{_0x2e6c28(Fa);});}):_0x163e10(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x887743,_0x5990d7)=>{_0x46ee1f(this['auth'])['then'](_0x142c6c=>{if(!_0x1f6eb0&&wr(window['grecaptcha']))_0x28a2b6(_0x142c6c,_0x887743,_0x5990d7);else{if(typeof window>'u'){_0x5990d7(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x71caf4=Pf();_0x71caf4['length']!==0x0&&(_0x71caf4+=_0x142c6c),xa(_0x71caf4)['then'](()=>{_0x28a2b6(_0x142c6c,_0x887743,_0x5990d7);})['catch'](_0x350d1e=>{_0x5990d7(_0x350d1e);});}})['catch'](_0x4d8103=>{_0x5990d7(_0x4d8103);});});}}async function Ar(_0x318b0c,_0x4ccade,_0x3ef92e,_0x53c087=!0x1,_0x22c514=!0x1){const _0x131dd5=new Ff(_0x318b0c);let _0x2132ea;if(_0x22c514)_0x2132ea=Fa;else try{_0x2132ea=await _0x131dd5['verify'](_0x3ef92e);}catch{_0x2132ea=await _0x131dd5['verify'](_0x3ef92e,!0x0);}const _0x32177b={..._0x4ccade};if(_0x3ef92e==='mfaSmsEnrollment'||_0x3ef92e==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x32177b){const _0x200ffa=_0x32177b['phoneEnrollmentInfo']['phoneNumber'],_0x1fccef=_0x32177b['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x32177b,{'phoneEnrollmentInfo':{'phoneNumber':_0x200ffa,'recaptchaToken':_0x1fccef,'captchaResponse':_0x2132ea,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x32177b){const _0x1500b6=_0x32177b['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x32177b,{'phoneSignInInfo':{'recaptchaToken':_0x1500b6,'captchaResponse':_0x2132ea,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x32177b;}return _0x53c087?Object['assign'](_0x32177b,{'captchaResp':_0x2132ea}):Object['assign'](_0x32177b,{'captchaResponse':_0x2132ea}),Object['assign'](_0x32177b,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x32177b,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x32177b;}async function Di(_0x4f6237,_0x1b8a4a,_0x227faa,_0x135d16,_0xbe6000){var _0x119ed7;if((_0x119ed7=_0x4f6237['_getRecaptchaConfig']())!=null&&_0x119ed7['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0xdd899d=await Ar(_0x4f6237,_0x1b8a4a,_0x227faa,_0x227faa==='getOobCode');return _0x135d16(_0x4f6237,_0xdd899d);}else return _0x135d16(_0x4f6237,_0x1b8a4a)['catch'](async _0x3e9fe7=>{if(_0x3e9fe7['code']==='auth/missing-recaptcha-token'){console['log'](_0x227faa+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x87e309=await Ar(_0x4f6237,_0x1b8a4a,_0x227faa,_0x227faa==='getOobCode');return _0x135d16(_0x4f6237,_0x87e309);}else return Promise['reject'](_0x3e9fe7);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x1765dc,_0x281129){const _0x5798d5=Bi(_0x1765dc,'auth');if(_0x5798d5['isInitialized']()){const _0x3dad2f=_0x5798d5['getImmediate'](),_0x349d84=_0x5798d5['getOptions']();if(Me(_0x349d84,_0x281129??{}))return _0x3dad2f;Q(_0x3dad2f,'already-initialized');}return _0x5798d5['initialize']({'options':_0x281129});}function Wf(_0x336f5a,_0x30412c){const _0x43c31e=(_0x30412c==null?void 0x0:_0x30412c['persistence'])||[],_0x42d22b=(Array['isArray'](_0x43c31e)?_0x43c31e:[_0x43c31e])['map'](ie);_0x30412c!=null&&_0x30412c['errorMap']&&_0x336f5a['_updateErrorMap'](_0x30412c['errorMap']),_0x336f5a['_initializeWithPersistence'](_0x42d22b,_0x30412c==null?void 0x0:_0x30412c['popupRedirectResolver']);}function Bf(_0x3ae891,_0x3979d1,_0x2e1a83){const _0x6d87a5=qe(_0x3ae891);m(/^https?:\/\//['test'](_0x3979d1),_0x6d87a5,'invalid-emulator-scheme');const _0x97ed81=!0x1,_0x55c338=Ua(_0x3979d1),{host:_0x25d782,port:_0x282669}=Vf(_0x3979d1),_0x1358be=_0x282669===null?'':':'+_0x282669,_0x50cf6e={'url':_0x55c338+'//'+_0x25d782+_0x1358be+'/'},_0x1b7ff1=Object['freeze']({'host':_0x25d782,'port':_0x282669,'protocol':_0x55c338['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x97ed81})});if(!_0x6d87a5['_canInitEmulator']){m(_0x6d87a5['config']['emulator']&&_0x6d87a5['emulatorConfig'],_0x6d87a5,'emulator-config-failed'),m(Me(_0x50cf6e,_0x6d87a5['config']['emulator'])&&Me(_0x1b7ff1,_0x6d87a5['emulatorConfig']),_0x6d87a5,'emulator-config-failed');return;}_0x6d87a5['config']['emulator']=_0x50cf6e,_0x6d87a5['emulatorConfig']=_0x1b7ff1,_0x6d87a5['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x25d782)?(jr(_0x55c338+'//'+_0x25d782+_0x1358be),Kr('Auth',!0x0)):Hf();}function Ua(_0x3a4315){const _0x2a4f23=_0x3a4315['indexOf'](':');return _0x2a4f23<0x0?'':_0x3a4315['substr'](0x0,_0x2a4f23+0x1);}function Vf(_0x4eb36e){const _0x47267f=Ua(_0x4eb36e),_0xa482a=/(\/\/)?([^?#/]+)/['exec'](_0x4eb36e['substr'](_0x47267f['length']));if(!_0xa482a)return{'host':'','port':null};const _0x516cba=_0xa482a[0x2]['split']('@')['pop']()||'',_0x51012f=/^(\[[^\]]+\])(:|$)/['exec'](_0x516cba);if(_0x51012f){const _0x9bad41=_0x51012f[0x1];return{'host':_0x9bad41,'port':kr(_0x516cba['substr'](_0x9bad41['length']+0x1))};}else{const [_0x3a412c,_0x541237]=_0x516cba['split'](':');return{'host':_0x3a412c,'port':kr(_0x541237)};}}function kr(_0x3fdd8c){if(!_0x3fdd8c)return null;const _0xdc3463=Number(_0x3fdd8c);return isNaN(_0xdc3463)?null:_0xdc3463;}function Hf(){function _0x593e37(){const _0x5c08dc=document['createElement']('p'),_0x3ee79f=_0x5c08dc['style'];_0x5c08dc['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x3ee79f['position']='fixed',_0x3ee79f['width']='100%',_0x3ee79f['backgroundColor']='#ffffff',_0x3ee79f['border']='.1em\x20solid\x20#000000',_0x3ee79f['color']='#b50000',_0x3ee79f['bottom']='0px',_0x3ee79f['left']='0px',_0x3ee79f['margin']='0px',_0x3ee79f['zIndex']='10000',_0x3ee79f['textAlign']='center',_0x5c08dc['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x5c08dc);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x593e37):_0x593e37());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0xec8f36,_0x3df087){this['providerId']=_0xec8f36,this['signInMethod']=_0x3df087;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x46828a){return ne('not\x20implemented');}['_linkToIdToken'](_0x538729,_0x269622){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x57372c){return ne('not\x20implemented');}}async function $f(_0xd5aa46,_0x208de1){return Ae(_0xd5aa46,'POST','/v1/accounts:signUp',_0x208de1);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0xbf16f9,_0x4a67c9){return Qt(_0xbf16f9,'POST','/v1/accounts:signInWithPassword',Re(_0xbf16f9,_0x4a67c9));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x5b548c,_0x751601){return Qt(_0x5b548c,'POST','/v1/accounts:signInWithEmailLink',Re(_0x5b548c,_0x751601));}async function zf(_0x5f5365,_0x1d336c){return Qt(_0x5f5365,'POST','/v1/accounts:signInWithEmailLink',Re(_0x5f5365,_0x1d336c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x50c788,_0x42dd72,_0x34f792,_0x987c0b=null){super('password',_0x34f792),this['_email']=_0x50c788,this['_password']=_0x42dd72,this['_tenantId']=_0x987c0b;}static['_fromEmailAndPassword'](_0x252893,_0x377480){return new Wt(_0x252893,_0x377480,'password');}static['_fromEmailAndCode'](_0x53090c,_0x378c21,_0x22b9b0=null){return new Wt(_0x53090c,_0x378c21,'emailLink',_0x22b9b0);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x786ce2){const _0xa5cf26=typeof _0x786ce2=='string'?JSON['parse'](_0x786ce2):_0x786ce2;if(_0xa5cf26!=null&&_0xa5cf26['email']&&(_0xa5cf26!=null&&_0xa5cf26['password'])){if(_0xa5cf26['signInMethod']==='password')return this['_fromEmailAndPassword'](_0xa5cf26['email'],_0xa5cf26['password']);if(_0xa5cf26['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0xa5cf26['email'],_0xa5cf26['password'],_0xa5cf26['tenantId']);}return null;}async['_getIdTokenResponse'](_0x3b3c5b){switch(this['signInMethod']){case'password':const _0x48a179={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x3b3c5b,_0x48a179,'signInWithPassword',Gf);case'emailLink':return qf(_0x3b3c5b,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x3b3c5b,'internal-error');}}async['_linkToIdToken'](_0x52a16c,_0x26d578){switch(this['signInMethod']){case'password':const _0x36214b={'idToken':_0x26d578,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x52a16c,_0x36214b,'signUpPassword',$f);case'emailLink':return zf(_0x52a16c,{'idToken':_0x26d578,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x52a16c,'internal-error');}}['_getReauthenticationResolver'](_0x64f420){return this['_getIdTokenResponse'](_0x64f420);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x3b9ae5,_0x2fe267){return Qt(_0x3b9ae5,'POST','/v1/accounts:signInWithIdp',Re(_0x3b9ae5,_0x2fe267));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x249db3){const _0x703bae=new Be(_0x249db3['providerId'],_0x249db3['signInMethod']);return _0x249db3['idToken']||_0x249db3['accessToken']?(_0x249db3['idToken']&&(_0x703bae['idToken']=_0x249db3['idToken']),_0x249db3['accessToken']&&(_0x703bae['accessToken']=_0x249db3['accessToken']),_0x249db3['nonce']&&!_0x249db3['pendingToken']&&(_0x703bae['nonce']=_0x249db3['nonce']),_0x249db3['pendingToken']&&(_0x703bae['pendingToken']=_0x249db3['pendingToken'])):_0x249db3['oauthToken']&&_0x249db3['oauthTokenSecret']?(_0x703bae['accessToken']=_0x249db3['oauthToken'],_0x703bae['secret']=_0x249db3['oauthTokenSecret']):Q('argument-error'),_0x703bae;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x58d755){const _0x4e04b5=typeof _0x58d755=='string'?JSON['parse'](_0x58d755):_0x58d755,{providerId:_0x5e014c,signInMethod:_0x132057,..._0x395539}=_0x4e04b5;if(!_0x5e014c||!_0x132057)return null;const _0x314e60=new Be(_0x5e014c,_0x132057);return _0x314e60['idToken']=_0x395539['idToken']||void 0x0,_0x314e60['accessToken']=_0x395539['accessToken']||void 0x0,_0x314e60['secret']=_0x395539['secret'],_0x314e60['nonce']=_0x395539['nonce'],_0x314e60['pendingToken']=_0x395539['pendingToken']||null,_0x314e60;}['_getIdTokenResponse'](_0x48e443){const _0x38af44=this['buildRequest']();return Xe(_0x48e443,_0x38af44);}['_linkToIdToken'](_0x820e35,_0x5b44aa){const _0x59caf8=this['buildRequest']();return _0x59caf8['idToken']=_0x5b44aa,Xe(_0x820e35,_0x59caf8);}['_getReauthenticationResolver'](_0x49a861){const _0x24c5f9=this['buildRequest']();return _0x24c5f9['autoCreate']=!0x1,Xe(_0x49a861,_0x24c5f9);}['buildRequest'](){const _0x49e078={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x49e078['pendingToken']=this['pendingToken'];else{const _0x2f6d97={};this['idToken']&&(_0x2f6d97['id_token']=this['idToken']),this['accessToken']&&(_0x2f6d97['access_token']=this['accessToken']),this['secret']&&(_0x2f6d97['oauth_token_secret']=this['secret']),_0x2f6d97['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x2f6d97['nonce']=this['nonce']),_0x49e078['postBody']=ct(_0x2f6d97);}return _0x49e078;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x262ba9){switch(_0x262ba9){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x4b282f){const _0x3be300=vt(Et(_0x4b282f))['link'],_0x399c6b=_0x3be300?vt(Et(_0x3be300))['deep_link_id']:null,_0x3eaa35=vt(Et(_0x4b282f))['deep_link_id'];return(_0x3eaa35?vt(Et(_0x3eaa35))['link']:null)||_0x3eaa35||_0x399c6b||_0x3be300||_0x4b282f;}class Rs{constructor(_0x28964b){const _0x457087=vt(Et(_0x28964b)),_0x95aac9=_0x457087['apiKey']??null,_0x34840d=_0x457087['oobCode']??null,_0x33c36b=Kf(_0x457087['mode']??null);m(_0x95aac9&&_0x34840d&&_0x33c36b,'argument-error'),this['apiKey']=_0x95aac9,this['operation']=_0x33c36b,this['code']=_0x34840d,this['continueUrl']=_0x457087['continueUrl']??null,this['languageCode']=_0x457087['lang']??null,this['tenantId']=_0x457087['tenantId']??null;}static['parseLink'](_0x4b2ce0){const _0x31951e=Yf(_0x4b2ce0);try{return new Rs(_0x31951e);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x5183ee,_0x45a2d3){return Wt['_fromEmailAndPassword'](_0x5183ee,_0x45a2d3);}static['credentialWithLink'](_0x2ec8eb,_0x4244ad){const _0x57ce87=Rs['parseLink'](_0x4244ad);return m(_0x57ce87,'argument-error'),Wt['_fromEmailAndCode'](_0x2ec8eb,_0x57ce87['code'],_0x57ce87['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x1dbb11){this['providerId']=_0x1dbb11,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x2ffd8f){this['defaultLanguageCode']=_0x2ffd8f;}['setCustomParameters'](_0x29b6d4){return this['customParameters']=_0x29b6d4,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x4c66a8){return this['scopes']['includes'](_0x4c66a8)||this['scopes']['push'](_0x4c66a8),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0xe3ebff){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0xe3ebff});}static['credentialFromResult'](_0x147228){return he['credentialFromTaggedObject'](_0x147228);}static['credentialFromError'](_0x5398ed){return he['credentialFromTaggedObject'](_0x5398ed['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x13ab7b}){if(!_0x13ab7b||!('oauthAccessToken'in _0x13ab7b)||!_0x13ab7b['oauthAccessToken'])return null;try{return he['credential'](_0x13ab7b['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x5f58d6,_0x72765e){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x5f58d6,'accessToken':_0x72765e});}static['credentialFromResult'](_0x507057){return ue['credentialFromTaggedObject'](_0x507057);}static['credentialFromError'](_0x3e3896){return ue['credentialFromTaggedObject'](_0x3e3896['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5278ec}){if(!_0x5278ec)return null;const {oauthIdToken:_0x16a6b9,oauthAccessToken:_0x53b0e2}=_0x5278ec;if(!_0x16a6b9&&!_0x53b0e2)return null;try{return ue['credential'](_0x16a6b9,_0x53b0e2);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x4b7d06){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x4b7d06});}static['credentialFromResult'](_0x7dc706){return de['credentialFromTaggedObject'](_0x7dc706);}static['credentialFromError'](_0x4c34f0){return de['credentialFromTaggedObject'](_0x4c34f0['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3cd2e2}){if(!_0x3cd2e2||!('oauthAccessToken'in _0x3cd2e2)||!_0x3cd2e2['oauthAccessToken'])return null;try{return de['credential'](_0x3cd2e2['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x333f24,_0x4ef278){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x333f24,'oauthTokenSecret':_0x4ef278});}static['credentialFromResult'](_0x3692b5){return fe['credentialFromTaggedObject'](_0x3692b5);}static['credentialFromError'](_0x3f01b5){return fe['credentialFromTaggedObject'](_0x3f01b5['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3ff042}){if(!_0x3ff042)return null;const {oauthAccessToken:_0x22401e,oauthTokenSecret:_0x538fc3}=_0x3ff042;if(!_0x22401e||!_0x538fc3)return null;try{return fe['credential'](_0x22401e,_0x538fc3);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x3f7847,_0x373361){return Qt(_0x3f7847,'POST','/v1/accounts:signUp',Re(_0x3f7847,_0x373361));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x352ae3){this['user']=_0x352ae3['user'],this['providerId']=_0x352ae3['providerId'],this['_tokenResponse']=_0x352ae3['_tokenResponse'],this['operationType']=_0x352ae3['operationType'];}static async['_fromIdTokenResponse'](_0x282e43,_0x398645,_0x2d32d1,_0x2bd38e=!0x1){const _0xb19b2d=await K['_fromIdTokenResponse'](_0x282e43,_0x2d32d1,_0x2bd38e),_0x1f6320=Nr(_0x2d32d1);return new Ve({'user':_0xb19b2d,'providerId':_0x1f6320,'_tokenResponse':_0x2d32d1,'operationType':_0x398645});}static async['_forOperation'](_0x13f4b1,_0x28ff76,_0x368124){await _0x13f4b1['_updateTokensIfNecessary'](_0x368124,!0x0);const _0x319809=Nr(_0x368124);return new Ve({'user':_0x13f4b1,'providerId':_0x319809,'_tokenResponse':_0x368124,'operationType':_0x28ff76});}}function Nr(_0x2d77c5){return _0x2d77c5['providerId']?_0x2d77c5['providerId']:'phoneNumber'in _0x2d77c5?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x477787,_0x5b1fb3,_0x600ac5,_0x169b0b){super(_0x5b1fb3['code'],_0x5b1fb3['message']),this['operationType']=_0x600ac5,this['user']=_0x169b0b,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x477787['name'],'tenantId':_0x477787['tenantId']??void 0x0,'_serverResponse':_0x5b1fb3['customData']['_serverResponse'],'operationType':_0x600ac5};}static['_fromErrorAndOperation'](_0x5bb2c3,_0x433c2e,_0x54d331,_0x1c055a){return new An(_0x5bb2c3,_0x433c2e,_0x54d331,_0x1c055a);}}function Ba(_0x35572a,_0x4277de,_0x4a86f0,_0x19bba7){return(_0x4277de==='reauthenticate'?_0x4a86f0['_getReauthenticationResolver'](_0x35572a):_0x4a86f0['_getIdTokenResponse'](_0x35572a))['catch'](_0x2512f9=>{throw _0x2512f9['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x35572a,_0x2512f9,_0x4277de,_0x19bba7):_0x2512f9;});}async function Jf(_0xbfdc16,_0x9c103b,_0x2e6452=!0x1){const _0x5b253b=await Ut(_0xbfdc16,_0x9c103b['_linkToIdToken'](_0xbfdc16['auth'],await _0xbfdc16['getIdToken']()),_0x2e6452);return Ve['_forOperation'](_0xbfdc16,'link',_0x5b253b);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x114be9,_0x23c934,_0x443754=!0x1){const {auth:_0x19c73f}=_0x114be9;if($(_0x19c73f['app']))return Promise['reject'](re(_0x19c73f));const _0x2c4335='reauthenticate';try{const _0x35a253=await Ut(_0x114be9,Ba(_0x19c73f,_0x2c4335,_0x23c934,_0x114be9),_0x443754);m(_0x35a253['idToken'],_0x19c73f,'internal-error');const _0x334706=Ts(_0x35a253['idToken']);m(_0x334706,_0x19c73f,'internal-error');const {sub:_0x6d7a80}=_0x334706;return m(_0x114be9['uid']===_0x6d7a80,_0x19c73f,'user-mismatch'),Ve['_forOperation'](_0x114be9,_0x2c4335,_0x35a253);}catch(_0x50f9b1){throw(_0x50f9b1==null?void 0x0:_0x50f9b1['code'])==='auth/user-not-found'&&Q(_0x19c73f,'user-mismatch'),_0x50f9b1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x31ef6d,_0x57ef3c,_0x1e27b1=!0x1){if($(_0x31ef6d['app']))return Promise['reject'](re(_0x31ef6d));const _0x36d2db='signIn',_0x325c71=await Ba(_0x31ef6d,_0x36d2db,_0x57ef3c),_0x2fd332=await Ve['_fromIdTokenResponse'](_0x31ef6d,_0x36d2db,_0x325c71);return _0x1e27b1||await _0x31ef6d['_updateCurrentUser'](_0x2fd332['user']),_0x2fd332;}async function Zf(_0x100a1f,_0x148882){return Va(qe(_0x100a1f),_0x148882);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x429887){const _0x1ab7ec=qe(_0x429887);_0x1ab7ec['_getPasswordPolicyInternal']()&&await _0x1ab7ec['_updatePasswordPolicy']();}async function P_(_0x4dd1a0,_0x1044c7,_0x985782){if($(_0x4dd1a0['app']))return Promise['reject'](re(_0x4dd1a0));const _0x5c61a9=qe(_0x4dd1a0),_0x2f76a7=await Di(_0x5c61a9,{'returnSecureToken':!0x0,'email':_0x1044c7,'password':_0x985782,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x30389e=>{throw _0x30389e['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x4dd1a0),_0x30389e;}),_0x14bbe9=await Ve['_fromIdTokenResponse'](_0x5c61a9,'signIn',_0x2f76a7);return await _0x5c61a9['_updateCurrentUser'](_0x14bbe9['user']),_0x14bbe9;}function O_(_0xf52f74,_0x270e2b,_0x5888c0){return $(_0xf52f74['app'])?Promise['reject'](re(_0xf52f74)):Zf(N(_0xf52f74),pt['credential'](_0x270e2b,_0x5888c0))['catch'](async _0xa3105e=>{throw _0xa3105e['code']==='auth/password-does-not-meet-requirements'&&Ha(_0xf52f74),_0xa3105e;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x5750ae,_0xae8b51){return N(_0x5750ae)['setPersistence'](_0xae8b51);}function ep(_0x14b467,_0x2a03af,_0x440181,_0xc2699a){return N(_0x14b467)['onIdTokenChanged'](_0x2a03af,_0x440181,_0xc2699a);}function tp(_0x41603d,_0x5dd853,_0x41fb9f){return N(_0x41603d)['beforeAuthStateChanged'](_0x5dd853,_0x41fb9f);}function M_(_0xbbc65d,_0x47d084,_0x7d419b,_0x1035c5){return N(_0xbbc65d)['onAuthStateChanged'](_0x47d084,_0x7d419b,_0x1035c5);}function L_(_0x4c1a1f){return N(_0x4c1a1f)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x472370,_0x3585e1){this['storageRetriever']=_0x472370,this['type']=_0x3585e1;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x3cf361,_0x2d229b){return this['storage']['setItem'](_0x3cf361,JSON['stringify'](_0x2d229b)),Promise['resolve']();}['_get'](_0x51c56e){const _0x5ba784=this['storage']['getItem'](_0x51c56e);return Promise['resolve'](_0x5ba784?JSON['parse'](_0x5ba784):null);}['_remove'](_0x2d6ac4){return this['storage']['removeItem'](_0x2d6ac4),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x4ae347,_0x2aadcc)=>this['onStorageEvent'](_0x4ae347,_0x2aadcc),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x5c147f){for(const _0x311ea3 of Object['keys'](this['listeners'])){const _0x49caab=this['storage']['getItem'](_0x311ea3),_0x5026f9=this['localCache'][_0x311ea3];_0x49caab!==_0x5026f9&&_0x5c147f(_0x311ea3,_0x5026f9,_0x49caab);}}['onStorageEvent'](_0x3c0750,_0x1fd096=!0x1){if(!_0x3c0750['key']){this['forAllChangedKeys']((_0x3fcd31,_0x52cb11,_0x5de5bb)=>{this['notifyListeners'](_0x3fcd31,_0x5de5bb);});return;}const _0x98cc3b=_0x3c0750['key'];_0x1fd096?this['detachListener']():this['stopPolling']();const _0x4e2e47=()=>{const _0x46fc8f=this['storage']['getItem'](_0x98cc3b);!_0x1fd096&&this['localCache'][_0x98cc3b]===_0x46fc8f||this['notifyListeners'](_0x98cc3b,_0x46fc8f);},_0x5896ce=this['storage']['getItem'](_0x98cc3b);Tf()&&_0x5896ce!==_0x3c0750['newValue']&&_0x3c0750['newValue']!==_0x3c0750['oldValue']?setTimeout(_0x4e2e47,ip):_0x4e2e47();}['notifyListeners'](_0x37b86a,_0x445961){this['localCache'][_0x37b86a]=_0x445961;const _0x39fe88=this['listeners'][_0x37b86a];if(_0x39fe88){for(const _0x560f8a of Array['from'](_0x39fe88))_0x560f8a(_0x445961&&JSON['parse'](_0x445961));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x4d3c38,_0x579cc6,_0x3e66e0)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x4d3c38,'oldValue':_0x579cc6,'newValue':_0x3e66e0}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x6cb8f4,_0x9ae6e3){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x6cb8f4]||(this['listeners'][_0x6cb8f4]=new Set(),this['localCache'][_0x6cb8f4]=this['storage']['getItem'](_0x6cb8f4)),this['listeners'][_0x6cb8f4]['add'](_0x9ae6e3);}['_removeListener'](_0x5e4970,_0x1d9f14){this['listeners'][_0x5e4970]&&(this['listeners'][_0x5e4970]['delete'](_0x1d9f14),this['listeners'][_0x5e4970]['size']===0x0&&delete this['listeners'][_0x5e4970]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x4cdba4,_0x2e166a){await super['_set'](_0x4cdba4,_0x2e166a),this['localCache'][_0x4cdba4]=JSON['stringify'](_0x2e166a);}async['_get'](_0x14a008){const _0x4cf6a4=await super['_get'](_0x14a008);return this['localCache'][_0x14a008]=JSON['stringify'](_0x4cf6a4),_0x4cf6a4;}async['_remove'](_0x846847){await super['_remove'](_0x846847),delete this['localCache'][_0x846847];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x1e5308,_0x2f9333){}['_removeListener'](_0x15ddd8,_0x14b765){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x1059dc){return Promise['all'](_0x1059dc['map'](async _0x175e55=>{try{return{'fulfilled':!0x0,'value':await _0x175e55};}catch(_0x563894){return{'fulfilled':!0x1,'reason':_0x563894};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x203043){this['eventTarget']=_0x203043,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x2086d9){const _0x45c2d8=this['receivers']['find'](_0x5d2e81=>_0x5d2e81['isListeningto'](_0x2086d9));if(_0x45c2d8)return _0x45c2d8;const _0x41ca98=new Kn(_0x2086d9);return this['receivers']['push'](_0x41ca98),_0x41ca98;}['isListeningto'](_0x3ed70f){return this['eventTarget']===_0x3ed70f;}async['handleEvent'](_0x38a794){const _0x26da5f=_0x38a794,{eventId:_0x437fbb,eventType:_0x194d6d,data:_0x187508}=_0x26da5f['data'],_0x379256=this['handlersMap'][_0x194d6d];if(!(_0x379256!=null&&_0x379256['size']))return;_0x26da5f['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x437fbb,'eventType':_0x194d6d});const _0x40d702=Array['from'](_0x379256)['map'](async _0x2c4de6=>_0x2c4de6(_0x26da5f['origin'],_0x187508)),_0x1ce06c=await rp(_0x40d702);_0x26da5f['ports'][0x0]['postMessage']({'status':'done','eventId':_0x437fbb,'eventType':_0x194d6d,'response':_0x1ce06c});}['_subscribe'](_0x2462c5,_0x11d883){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x2462c5]||(this['handlersMap'][_0x2462c5]=new Set()),this['handlersMap'][_0x2462c5]['add'](_0x11d883);}['_unsubscribe'](_0xbc228c,_0x359ff7){this['handlersMap'][_0xbc228c]&&_0x359ff7&&this['handlersMap'][_0xbc228c]['delete'](_0x359ff7),(!_0x359ff7||this['handlersMap'][_0xbc228c]['size']===0x0)&&delete this['handlersMap'][_0xbc228c],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x2eb395='',_0x10a18d=0xa){let _0xb5c206='';for(let _0x52ea02=0x0;_0x52ea02<_0x10a18d;_0x52ea02++)_0xb5c206+=Math['floor'](Math['random']()*0xa);return _0x2eb395+_0xb5c206;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x4bce9){this['target']=_0x4bce9,this['handlers']=new Set();}['removeMessageHandler'](_0x3582b3){_0x3582b3['messageChannel']&&(_0x3582b3['messageChannel']['port1']['removeEventListener']('message',_0x3582b3['onMessage']),_0x3582b3['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x3582b3);}async['_send'](_0x2b3f0d,_0x560e29,_0x1a0f11=0x32){const _0x31cf43=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x31cf43)throw new Error('connection_unavailable');let _0x373b27,_0x4fe6d0;return new Promise((_0x566e83,_0x1808f2)=>{const _0x33b604=As('',0x14);_0x31cf43['port1']['start']();const _0x297cb8=setTimeout(()=>{_0x1808f2(new Error('unsupported_event'));},_0x1a0f11);_0x4fe6d0={'messageChannel':_0x31cf43,'onMessage'(_0x37f602){const _0x4a59f5=_0x37f602;if(_0x4a59f5['data']['eventId']===_0x33b604)switch(_0x4a59f5['data']['status']){case'ack':clearTimeout(_0x297cb8),_0x373b27=setTimeout(()=>{_0x1808f2(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x373b27),_0x566e83(_0x4a59f5['data']['response']);break;default:clearTimeout(_0x297cb8),clearTimeout(_0x373b27),_0x1808f2(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x4fe6d0),_0x31cf43['port1']['addEventListener']('message',_0x4fe6d0['onMessage']),this['target']['postMessage']({'eventType':_0x2b3f0d,'eventId':_0x33b604,'data':_0x560e29},[_0x31cf43['port2']]);})['finally'](()=>{_0x4fe6d0&&this['removeMessageHandler'](_0x4fe6d0);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x5d6e51){Z()['location']['href']=_0x5d6e51;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x112752;return((_0x112752=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x112752['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x49c152){this['request']=_0x49c152;}['toPromise'](){return new Promise((_0x1a142e,_0x110023)=>{this['request']['addEventListener']('success',()=>{_0x1a142e(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x110023(this['request']['error']);});});}}function Yn(_0x1bbc87,_0x44b352){return _0x1bbc87['transaction']([Nn],_0x44b352?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x1383ba=indexedDB['deleteDatabase'](Ka);return new Xt(_0x1383ba)['toPromise']();}function Mi(){const _0x44f3e0=indexedDB['open'](Ka,up);return new Promise((_0x2e4ebe,_0xfcb28)=>{_0x44f3e0['addEventListener']('error',()=>{_0xfcb28(_0x44f3e0['error']);}),_0x44f3e0['addEventListener']('upgradeneeded',()=>{const _0x47bbf1=_0x44f3e0['result'];try{_0x47bbf1['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x13ea0e){_0xfcb28(_0x13ea0e);}}),_0x44f3e0['addEventListener']('success',async()=>{const _0x46c303=_0x44f3e0['result'];_0x46c303['objectStoreNames']['contains'](Nn)?_0x2e4ebe(_0x46c303):(_0x46c303['close'](),await dp(),_0x2e4ebe(await Mi()));});});}async function Pr(_0x566200,_0x1f4a63,_0x1cecf9){const _0x125346=Yn(_0x566200,!0x0)['put']({[Ya]:_0x1f4a63,'value':_0x1cecf9});return new Xt(_0x125346)['toPromise']();}async function fp(_0x8b0575,_0x397605){const _0x442159=Yn(_0x8b0575,!0x1)['get'](_0x397605),_0x15e1e5=await new Xt(_0x442159)['toPromise']();return _0x15e1e5===void 0x0?null:_0x15e1e5['value'];}function Or(_0x2e5620,_0x35dd87){const _0x4c15ca=Yn(_0x2e5620,!0x0)['delete'](_0x35dd87);return new Xt(_0x4c15ca)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x31b2c4){let _0x24d578=0x0;for(;;)try{const _0x126d27=await this['_openDb']();return await _0x31b2c4(_0x126d27);}catch(_0xd6dcab){if(_0x24d578++>_p)throw _0xd6dcab;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x12826d,_0x19c0e3)=>({'keyProcessed':(await this['_poll']())['includes'](_0x19c0e3['key'])})),this['receiver']['_subscribe']('ping',async(_0x176ff5,_0x2c0e60)=>['keyChanged']);}async['initializeSender'](){var _0x2f97f5,_0x51fda2;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x7d94eb=await this['sender']['_send']('ping',{},0x320);_0x7d94eb&&(_0x2f97f5=_0x7d94eb[0x0])!=null&&_0x2f97f5['fulfilled']&&(_0x51fda2=_0x7d94eb[0x0])!=null&&_0x51fda2['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x4a081f){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x4a081f},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0xb9b18d=await Mi();return await Pr(_0xb9b18d,kn,'1'),await Or(_0xb9b18d,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x47223b){this['pendingWrites']++;try{await _0x47223b();}finally{this['pendingWrites']--;}}async['_set'](_0x47e3b3,_0x87585e){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x11acc8=>Pr(_0x11acc8,_0x47e3b3,_0x87585e)),this['localCache'][_0x47e3b3]=_0x87585e,this['notifyServiceWorker'](_0x47e3b3)));}async['_get'](_0x54ff7c){const _0x13cb81=await this['_withRetries'](_0x5cc1a3=>fp(_0x5cc1a3,_0x54ff7c));return this['localCache'][_0x54ff7c]=_0x13cb81,_0x13cb81;}async['_remove'](_0x265a84){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2ec5b3=>Or(_0x2ec5b3,_0x265a84)),delete this['localCache'][_0x265a84],this['notifyServiceWorker'](_0x265a84)));}async['_poll'](){const _0x45a1b0=await this['_withRetries'](_0xa80317=>{const _0x3122ba=Yn(_0xa80317,!0x1)['getAll']();return new Xt(_0x3122ba)['toPromise']();});if(!_0x45a1b0)return[];if(this['pendingWrites']!==0x0)return[];const _0x358a97=[],_0xb67af1=new Set();if(_0x45a1b0['length']!==0x0){for(const {fbase_key:_0xe28d07,value:_0x2eb372}of _0x45a1b0)_0xb67af1['add'](_0xe28d07),JSON['stringify'](this['localCache'][_0xe28d07])!==JSON['stringify'](_0x2eb372)&&(this['notifyListeners'](_0xe28d07,_0x2eb372),_0x358a97['push'](_0xe28d07));}for(const _0x4d73f0 of Object['keys'](this['localCache']))this['localCache'][_0x4d73f0]&&!_0xb67af1['has'](_0x4d73f0)&&(this['notifyListeners'](_0x4d73f0,null),_0x358a97['push'](_0x4d73f0));return _0x358a97;}['notifyListeners'](_0x53244d,_0x284373){this['localCache'][_0x53244d]=_0x284373;const _0x51759a=this['listeners'][_0x53244d];if(_0x51759a){for(const _0x12268d of Array['from'](_0x51759a))_0x12268d(_0x284373);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x186fc5,_0x226cf6){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x186fc5]||(this['listeners'][_0x186fc5]=new Set(),this['_get'](_0x186fc5)),this['listeners'][_0x186fc5]['add'](_0x226cf6);}['_removeListener'](_0x23cd44,_0x3e56c2){this['listeners'][_0x23cd44]&&(this['listeners'][_0x23cd44]['delete'](_0x3e56c2),this['listeners'][_0x23cd44]['size']===0x0&&delete this['listeners'][_0x23cd44]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x5b6f50,_0x384337){return _0x384337?ie(_0x384337):(m(_0x5b6f50['_popupRedirectResolver'],_0x5b6f50,'argument-error'),_0x5b6f50['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x1f71d1){super('custom','custom'),this['params']=_0x1f71d1;}['_getIdTokenResponse'](_0x434961){return Xe(_0x434961,this['_buildIdpRequest']());}['_linkToIdToken'](_0x149ca7,_0x4f9945){return Xe(_0x149ca7,this['_buildIdpRequest'](_0x4f9945));}['_getReauthenticationResolver'](_0x3dcfe0){return Xe(_0x3dcfe0,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x36a536){const _0x2bb39e={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x36a536&&(_0x2bb39e['idToken']=_0x36a536),_0x2bb39e;}}function yp(_0x2d1086){return Va(_0x2d1086['auth'],new ks(_0x2d1086),_0x2d1086['bypassAuthState']);}function vp(_0x20d1fc){const {auth:_0x45eb1d,user:_0x40de42}=_0x20d1fc;return m(_0x40de42,_0x45eb1d,'internal-error'),Xf(_0x40de42,new ks(_0x20d1fc),_0x20d1fc['bypassAuthState']);}async function Ep(_0x4d1703){const {auth:_0x5ec2b8,user:_0x5ce9a8}=_0x4d1703;return m(_0x5ce9a8,_0x5ec2b8,'internal-error'),Jf(_0x5ce9a8,new ks(_0x4d1703),_0x4d1703['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0xa111b8,_0x5de99d,_0x10915b,_0x2ad739,_0x3c7897=!0x1){this['auth']=_0xa111b8,this['resolver']=_0x10915b,this['user']=_0x2ad739,this['bypassAuthState']=_0x3c7897,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x5de99d)?_0x5de99d:[_0x5de99d];}['execute'](){return new Promise(async(_0x411aaf,_0x3d2aaa)=>{this['pendingPromise']={'resolve':_0x411aaf,'reject':_0x3d2aaa};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x370797){this['reject'](_0x370797);}});}async['onAuthEvent'](_0x194a77){const {urlResponse:_0x488f19,sessionId:_0x467b18,postBody:_0x4e4c4c,tenantId:_0x435369,error:_0x5afc4e,type:_0x44ae40}=_0x194a77;if(_0x5afc4e){this['reject'](_0x5afc4e);return;}const _0x1922cb={'auth':this['auth'],'requestUri':_0x488f19,'sessionId':_0x467b18,'tenantId':_0x435369||void 0x0,'postBody':_0x4e4c4c||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x44ae40)(_0x1922cb));}catch(_0x1b6834){this['reject'](_0x1b6834);}}['onError'](_0x2cf8f3){this['reject'](_0x2cf8f3);}['getIdpTask'](_0x42f23c){switch(_0x42f23c){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x2fb309){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x2fb309),this['unregisterAndCleanUp']();}['reject'](_0x5554a2){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x5554a2),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x2ba7f4,_0x59d398,_0x4a5559,_0x130ab8,_0x2971fa){super(_0x2ba7f4,_0x59d398,_0x130ab8,_0x2971fa),this['provider']=_0x4a5559,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0xa834f8=await this['execute']();return m(_0xa834f8,this['auth'],'internal-error'),_0xa834f8;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x46e3c4=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x46e3c4),this['authWindow']['associatedEvent']=_0x46e3c4,this['resolver']['_originValidation'](this['auth'])['catch'](_0x854369=>{this['reject'](_0x854369);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x3623d8=>{_0x3623d8||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x482c94;return((_0x482c94=this['authWindow'])==null?void 0x0:_0x482c94['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x48f943=()=>{var _0x358af8,_0x2ceb1e;if((_0x2ceb1e=(_0x358af8=this['authWindow'])==null?void 0x0:_0x358af8['window'])!=null&&_0x2ceb1e['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x48f943,Ip['get']());};_0x48f943();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x4e1ca4,_0x384758,_0x5dd7d=!0x1){super(_0x4e1ca4,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x384758,void 0x0,_0x5dd7d),this['eventId']=null;}async['execute'](){let _0x3f1ef9=on['get'](this['auth']['_key']());if(!_0x3f1ef9){try{const _0x14252f=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x3f1ef9=()=>Promise['resolve'](_0x14252f);}catch(_0x29cd54){_0x3f1ef9=()=>Promise['reject'](_0x29cd54);}on['set'](this['auth']['_key'](),_0x3f1ef9);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x3f1ef9();}async['onAuthEvent'](_0x4e0e97){if(_0x4e0e97['type']==='signInViaRedirect')return super['onAuthEvent'](_0x4e0e97);if(_0x4e0e97['type']==='unknown'){this['resolve'](null);return;}if(_0x4e0e97['eventId']){const _0x166be7=await this['auth']['_redirectUserForId'](_0x4e0e97['eventId']);if(_0x166be7)return this['user']=_0x166be7,super['onAuthEvent'](_0x4e0e97);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x18a58c,_0x157b8d){const _0x582f77=Rp(_0x157b8d),_0x562b53=bp(_0x18a58c);if(!await _0x562b53['_isAvailable']())return!0x1;const _0x39a9c5=await _0x562b53['_get'](_0x582f77)==='true';return await _0x562b53['_remove'](_0x582f77),_0x39a9c5;}function Sp(_0x14dc64,_0x416df1){on['set'](_0x14dc64['_key'](),_0x416df1);}function bp(_0x57fddf){return ie(_0x57fddf['_redirectPersistence']);}function Rp(_0x17bfec){return rn(wp,_0x17bfec['config']['apiKey'],_0x17bfec['name']);}async function Ap(_0x507d06,_0x100d63,_0x3108da=!0x1){if($(_0x507d06['app']))return Promise['reject'](re(_0x507d06));const _0x454885=qe(_0x507d06),_0x64235e=mp(_0x454885,_0x100d63),_0x7a2b0f=await new Cp(_0x454885,_0x64235e,_0x3108da)['execute']();return _0x7a2b0f&&!_0x3108da&&(delete _0x7a2b0f['user']['_redirectEventId'],await _0x454885['_persistUserIfCurrent'](_0x7a2b0f['user']),await _0x454885['_setRedirectUser'](null,_0x100d63)),_0x7a2b0f;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x15670a){this['auth']=_0x15670a,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x25fa03){this['consumers']['add'](_0x25fa03),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x25fa03)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x25fa03),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x416fcb){this['consumers']['delete'](_0x416fcb);}['onEvent'](_0x1532fa){if(this['hasEventBeenHandled'](_0x1532fa))return!0x1;let _0x3a875a=!0x1;return this['consumers']['forEach'](_0x418096=>{this['isEventForConsumer'](_0x1532fa,_0x418096)&&(_0x3a875a=!0x0,this['sendToConsumer'](_0x1532fa,_0x418096),this['saveEventToCache'](_0x1532fa));}),this['hasHandledPotentialRedirect']||!Pp(_0x1532fa)||(this['hasHandledPotentialRedirect']=!0x0,_0x3a875a||(this['queuedRedirectEvent']=_0x1532fa,_0x3a875a=!0x0)),_0x3a875a;}['sendToConsumer'](_0xf5710f,_0x73d320){var _0x2f73e4;if(_0xf5710f['error']&&!Xa(_0xf5710f)){const _0x1d62cc=((_0x2f73e4=_0xf5710f['error']['code'])==null?void 0x0:_0x2f73e4['split']('auth/')[0x1])||'internal-error';_0x73d320['onError'](X(this['auth'],_0x1d62cc));}else _0x73d320['onAuthEvent'](_0xf5710f);}['isEventForConsumer'](_0x383e79,_0x477b81){const _0x45bd52=_0x477b81['eventId']===null||!!_0x383e79['eventId']&&_0x383e79['eventId']===_0x477b81['eventId'];return _0x477b81['filter']['includes'](_0x383e79['type'])&&_0x45bd52;}['hasEventBeenHandled'](_0x1ce28){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x1ce28));}['saveEventToCache'](_0x5b364f){this['cachedEventUids']['add'](Dr(_0x5b364f)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x162266){return[_0x162266['type'],_0x162266['eventId'],_0x162266['sessionId'],_0x162266['tenantId']]['filter'](_0x276176=>_0x276176)['join']('-');}function Xa({type:_0x4d534e,error:_0xf31d1b}){return _0x4d534e==='unknown'&&(_0xf31d1b==null?void 0x0:_0xf31d1b['code'])==='auth/no-auth-event';}function Pp(_0x4e6b14){switch(_0x4e6b14['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x4e6b14);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x8d54d0,_0x126af0={}){return Ae(_0x8d54d0,'GET','/v1/projects',_0x126af0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x4ae78d){if(_0x4ae78d['config']['emulator'])return;const {authorizedDomains:_0x352559}=await Op(_0x4ae78d);for(const _0x28c356 of _0x352559)try{if(xp(_0x28c356))return;}catch{}Q(_0x4ae78d,'unauthorized-domain');}function xp(_0x42e40c){const _0x4588a8=Pi(),{protocol:_0x1652c8,hostname:_0x3deade}=new URL(_0x4588a8);if(_0x42e40c['startsWith']('chrome-extension://')){const _0x48926f=new URL(_0x42e40c);return _0x48926f['hostname']===''&&_0x3deade===''?_0x1652c8==='chrome-extension:'&&_0x42e40c['replace']('chrome-extension://','')===_0x4588a8['replace']('chrome-extension://',''):_0x1652c8==='chrome-extension:'&&_0x48926f['hostname']===_0x3deade;}if(!Mp['test'](_0x1652c8))return!0x1;if(Dp['test'](_0x42e40c))return _0x3deade===_0x42e40c;const _0x52270c=_0x42e40c['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x52270c+'|'+_0x52270c+')$','i')['test'](_0x3deade);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x35c7dc=Z()['___jsl'];if(_0x35c7dc!=null&&_0x35c7dc['H']){for(const _0x243d17 of Object['keys'](_0x35c7dc['H']))if(_0x35c7dc['H'][_0x243d17]['r']=_0x35c7dc['H'][_0x243d17]['r']||[],_0x35c7dc['H'][_0x243d17]['L']=_0x35c7dc['H'][_0x243d17]['L']||[],_0x35c7dc['H'][_0x243d17]['r']=[..._0x35c7dc['H'][_0x243d17]['L']],_0x35c7dc['CP']){for(let _0xba53de=0x0;_0xba53de<_0x35c7dc['CP']['length'];_0xba53de++)_0x35c7dc['CP'][_0xba53de]=null;}}}function Up(_0x4ac4f2){return new Promise((_0x503c99,_0x59ec75)=>{var _0xbcfb23,_0x38686c,_0x41e6db;function _0xce13ce(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x503c99(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x59ec75(X(_0x4ac4f2,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x38686c=(_0xbcfb23=Z()['gapi'])==null?void 0x0:_0xbcfb23['iframes'])!=null&&_0x38686c['Iframe'])_0x503c99(gapi['iframes']['getContext']());else{if((_0x41e6db=Z()['gapi'])!=null&&_0x41e6db['load'])_0xce13ce();else{const _0x40a95f=Df('iframefcb');return Z()[_0x40a95f]=()=>{gapi['load']?_0xce13ce():_0x59ec75(X(_0x4ac4f2,'network-request-failed'));},xa(Of()+'?onload='+_0x40a95f)['catch'](_0x3f6aa3=>_0x59ec75(_0x3f6aa3));}}})['catch'](_0xd43a6e=>{throw an=null,_0xd43a6e;});}let an=null;function Wp(_0x5699b2){return an=an||Up(_0x5699b2),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x30acf5){const _0x2dcb07=_0x30acf5['config'];m(_0x2dcb07['authDomain'],_0x30acf5,'auth-domain-config-required');const _0x18f923=_0x2dcb07['emulator']?Cs(_0x2dcb07,Hp):'https://'+_0x30acf5['config']['authDomain']+'/'+Vp,_0x4f42a4={'apiKey':_0x2dcb07['apiKey'],'appName':_0x30acf5['name'],'v':lt},_0x214a70=Gp['get'](_0x30acf5['config']['apiHost']);_0x214a70&&(_0x4f42a4['eid']=_0x214a70);const _0x2c366f=_0x30acf5['_getFrameworks']();return _0x2c366f['length']&&(_0x4f42a4['fw']=_0x2c366f['join'](',')),_0x18f923+'?'+ct(_0x4f42a4)['slice'](0x1);}async function zp(_0x53423a){const _0x2c50b9=await Wp(_0x53423a),_0x36cffd=Z()['gapi'];return m(_0x36cffd,_0x53423a,'internal-error'),_0x2c50b9['open']({'where':document['body'],'url':qp(_0x53423a),'messageHandlersFilter':_0x36cffd['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x402e27=>new Promise(async(_0x30b1b1,_0x1f56f3)=>{await _0x402e27['restyle']({'setHideOnLeave':!0x1});const _0x423902=X(_0x53423a,'network-request-failed'),_0x19413a=Z()['setTimeout'](()=>{_0x1f56f3(_0x423902);},Bp['get']());function _0x5e952d(){Z()['clearTimeout'](_0x19413a),_0x30b1b1(_0x402e27);}_0x402e27['ping'](_0x5e952d)['then'](_0x5e952d,()=>{_0x1f56f3(_0x423902);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x386bb9){this['window']=_0x386bb9,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x3f75e2,_0x22895a,_0x59d73f,_0x277b85=Kp,_0x20ee91=Yp){const _0x903443=Math['max']((window['screen']['availHeight']-_0x20ee91)/0x2,0x0)['toString'](),_0x26641c=Math['max']((window['screen']['availWidth']-_0x277b85)/0x2,0x0)['toString']();let _0x3d4625='';const _0x96da8b={...jp,'width':_0x277b85['toString'](),'height':_0x20ee91['toString'](),'top':_0x903443,'left':_0x26641c},_0x3b7770=W()['toLowerCase']();_0x59d73f&&(_0x3d4625=ka(_0x3b7770)?Qp:_0x59d73f),Ra(_0x3b7770)&&(_0x22895a=_0x22895a||Jp,_0x96da8b['scrollbars']='yes');const _0x3090b8=Object['entries'](_0x96da8b)['reduce']((_0x236fe9,[_0x44d7df,_0x3e092a])=>''+_0x236fe9+_0x44d7df+'='+_0x3e092a+',','');if(Cf(_0x3b7770)&&_0x3d4625!=='_self')return Zp(_0x22895a||'',_0x3d4625),new Lr(null);const _0x4c90a7=window['open'](_0x22895a||'',_0x3d4625,_0x3090b8);m(_0x4c90a7,_0x3f75e2,'popup-blocked');try{_0x4c90a7['focus']();}catch{}return new Lr(_0x4c90a7);}function Zp(_0x4041fe,_0x31565a){const _0x725444=document['createElement']('a');_0x725444['href']=_0x4041fe,_0x725444['target']=_0x31565a;const _0x408724=document['createEvent']('MouseEvent');_0x408724['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x725444['dispatchEvent'](_0x408724);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x26362c,_0x23be0c,_0x327e84,_0xb1da52,_0x5d3988,_0x245f40){m(_0x26362c['config']['authDomain'],_0x26362c,'auth-domain-config-required'),m(_0x26362c['config']['apiKey'],_0x26362c,'invalid-api-key');const _0x1c1a56={'apiKey':_0x26362c['config']['apiKey'],'appName':_0x26362c['name'],'authType':_0x327e84,'redirectUrl':_0xb1da52,'v':lt,'eventId':_0x5d3988};if(_0x23be0c instanceof Wa){_0x23be0c['setDefaultLanguage'](_0x26362c['languageCode']),_0x1c1a56['providerId']=_0x23be0c['providerId']||'',ui(_0x23be0c['getCustomParameters']())||(_0x1c1a56['customParameters']=JSON['stringify'](_0x23be0c['getCustomParameters']()));for(const [_0x39c213,_0x530ca9]of Object['entries']({}))_0x1c1a56[_0x39c213]=_0x530ca9;}if(_0x23be0c instanceof Jt){const _0x280700=_0x23be0c['getScopes']()['filter'](_0x50fb12=>_0x50fb12!=='');_0x280700['length']>0x0&&(_0x1c1a56['scopes']=_0x280700['join'](','));}_0x26362c['tenantId']&&(_0x1c1a56['tid']=_0x26362c['tenantId']);const _0x5596ba=_0x1c1a56;for(const _0x4ace29 of Object['keys'](_0x5596ba))_0x5596ba[_0x4ace29]===void 0x0&&delete _0x5596ba[_0x4ace29];const _0x138cab=await _0x26362c['_getAppCheckToken'](),_0x533004=_0x138cab?'#'+n_+'='+encodeURIComponent(_0x138cab):'';return i_(_0x26362c)+'?'+ct(_0x5596ba)['slice'](0x1)+_0x533004;}function i_({config:_0x428694}){return _0x428694['emulator']?Cs(_0x428694,t_):'https://'+_0x428694['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x123894,_0x4b10e7,_0xf1634e,_0x18c852){var _0xc909e9;ce((_0xc909e9=this['eventManagers'][_0x123894['_key']()])==null?void 0x0:_0xc909e9['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x2c2a42=await xr(_0x123894,_0x4b10e7,_0xf1634e,Pi(),_0x18c852);return Xp(_0x123894,_0x2c2a42,As());}async['_openRedirect'](_0x1e55a0,_0x43e713,_0x5a77a0,_0x2cbac8){await this['_originValidation'](_0x1e55a0);const _0x4deeca=await xr(_0x1e55a0,_0x43e713,_0x5a77a0,Pi(),_0x2cbac8);return ap(_0x4deeca),new Promise(()=>{});}['_initialize'](_0x1cadfe){const _0x583b46=_0x1cadfe['_key']();if(this['eventManagers'][_0x583b46]){const {manager:_0x288aa0,promise:_0x86954b}=this['eventManagers'][_0x583b46];return _0x288aa0?Promise['resolve'](_0x288aa0):(ce(_0x86954b,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x86954b);}const _0x15eec1=this['initAndGetManager'](_0x1cadfe);return this['eventManagers'][_0x583b46]={'promise':_0x15eec1},_0x15eec1['catch'](()=>{delete this['eventManagers'][_0x583b46];}),_0x15eec1;}async['initAndGetManager'](_0x23573c){const _0x5c8cce=await zp(_0x23573c),_0x26656d=new Np(_0x23573c);return _0x5c8cce['register']('authEvent',_0x1feeb2=>(m(_0x1feeb2==null?void 0x0:_0x1feeb2['authEvent'],_0x23573c,'invalid-auth-event'),{'status':_0x26656d['onEvent'](_0x1feeb2['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x23573c['_key']()]={'manager':_0x26656d},this['iframes'][_0x23573c['_key']()]=_0x5c8cce,_0x26656d;}['_isIframeWebStorageSupported'](_0x265c8c,_0x38418e){this['iframes'][_0x265c8c['_key']()]['send'](hi,{'type':hi},_0x520ba5=>{var _0x1695fb;const _0x33f0e2=(_0x1695fb=_0x520ba5==null?void 0x0:_0x520ba5[0x0])==null?void 0x0:_0x1695fb[hi];_0x33f0e2!==void 0x0&&_0x38418e(!!_0x33f0e2),Q(_0x265c8c,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x1c1862){const _0x3d6399=_0x1c1862['_key']();return this['originValidationPromises'][_0x3d6399]||(this['originValidationPromises'][_0x3d6399]=Lp(_0x1c1862)),this['originValidationPromises'][_0x3d6399];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0xbe804a){this['auth']=_0xbe804a,this['internalListeners']=new Map();}['getUid'](){var _0x34705e;return this['assertAuthConfigured'](),((_0x34705e=this['auth']['currentUser'])==null?void 0x0:_0x34705e['uid'])||null;}async['getToken'](_0x3cf300){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x3cf300)}:null;}['addAuthTokenListener'](_0x51c8e3){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x51c8e3))return;const _0x39edf7=this['auth']['onIdTokenChanged'](_0x16061f=>{_0x51c8e3((_0x16061f==null?void 0x0:_0x16061f['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x51c8e3,_0x39edf7),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x473e46){this['assertAuthConfigured']();const _0x4cdd9b=this['internalListeners']['get'](_0x473e46);_0x4cdd9b&&(this['internalListeners']['delete'](_0x473e46),_0x4cdd9b(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x44e272){switch(_0x44e272){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x3eb1aa){Ze(new Le('auth',(_0x164917,{options:_0x1e9fc2})=>{const _0xb3655e=_0x164917['getProvider']('app')['getImmediate'](),_0x4e7c0c=_0x164917['getProvider']('heartbeat'),_0x3c6f66=_0x164917['getProvider']('app-check-internal'),{apiKey:_0x3d1724,authDomain:_0x57d2d2}=_0xb3655e['options'];m(_0x3d1724&&!_0x3d1724['includes'](':'),'invalid-api-key',{'appName':_0xb3655e['name']});const _0xff590a={'apiKey':_0x3d1724,'authDomain':_0x57d2d2,'clientPlatform':_0x3eb1aa,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x3eb1aa)},_0x318d84=new kf(_0xb3655e,_0x4e7c0c,_0x3c6f66,_0xff590a);return Wf(_0x318d84,_0x1e9fc2),_0x318d84;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x1708bb,_0x1bbd5a,_0x11f680)=>{_0x1708bb['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x3b82f3=>{const _0x295f68=qe(_0x3b82f3['getProvider']('auth')['getImmediate']());return(_0x15c00d=>new o_(_0x15c00d))(_0x295f68);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x3eb1aa)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x43574c=>async _0xb64ad8=>{const _0xe73c72=_0xb64ad8&&await _0xb64ad8['getIdTokenResult'](),_0x107d1b=_0xe73c72&&(new Date()['getTime']()-Date['parse'](_0xe73c72['issuedAtTime']))/0x3e8;if(_0x107d1b&&_0x107d1b>h_)return;const _0x1d0966=_0xe73c72==null?void 0x0:_0xe73c72['token'];Wr!==_0x1d0966&&(Wr=_0x1d0966,await fetch(_0x43574c,{'method':_0x1d0966?'POST':'DELETE','headers':_0x1d0966?{'Authorization':'Bearer\x20'+_0x1d0966}:{}}));};function x_(_0x3ab3be=Zr()){const _0x5b42b8=Bi(_0x3ab3be,'auth');if(_0x5b42b8['isInitialized']())return _0x5b42b8['getImmediate']();const _0x9d70f1=Uf(_0x3ab3be,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x51b15b=zr('authTokenSyncURL');if(_0x51b15b&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x1fbce0=new URL(_0x51b15b,location['origin']);if(location['origin']===_0x1fbce0['origin']){const _0x1becdc=u_(_0x1fbce0['toString']());tp(_0x9d70f1,_0x1becdc,()=>_0x1becdc(_0x9d70f1['currentUser'])),ep(_0x9d70f1,_0x351e0b=>_0x1becdc(_0x351e0b));}}const _0x3c8693=Gr('auth');return _0x3c8693&&Bf(_0x9d70f1,'http://'+_0x3c8693),_0x9d70f1;}function d_(){var _0x24ed36;return((_0x24ed36=document['getElementsByTagName']('head'))==null?void 0x0:_0x24ed36[0x0])??document;}Nf({'loadJS'(_0xb1cfb6){return new Promise((_0x34a7dd,_0x4f5c55)=>{const _0x5d49d7=document['createElement']('script');_0x5d49d7['setAttribute']('src',_0xb1cfb6),_0x5d49d7['onload']=_0x34a7dd,_0x5d49d7['onerror']=_0x302624=>{const _0x27b16f=X('internal-error');_0x27b16f['customData']=_0x302624,_0x4f5c55(_0x27b16f);},_0x5d49d7['type']='text/javascript',_0x5d49d7['charset']='UTF-8',d_()['appendChild'](_0x5d49d7);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};