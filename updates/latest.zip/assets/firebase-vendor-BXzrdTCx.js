const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x4d2aad,_0x4702a8){if(!_0x4d2aad)throw rt(_0x4702a8);},rt=function(_0x957bcf){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x957bcf);},Vr=function(_0xe06b58){const _0x98cc95=[];let _0x11e563=0x0;for(let _0x415e03=0x0;_0x415e03<_0xe06b58['length'];_0x415e03++){let _0x54fa0a=_0xe06b58['charCodeAt'](_0x415e03);_0x54fa0a<0x80?_0x98cc95[_0x11e563++]=_0x54fa0a:_0x54fa0a<0x800?(_0x98cc95[_0x11e563++]=_0x54fa0a>>0x6|0xc0,_0x98cc95[_0x11e563++]=_0x54fa0a&0x3f|0x80):(_0x54fa0a&0xfc00)===0xd800&&_0x415e03+0x1<_0xe06b58['length']&&(_0xe06b58['charCodeAt'](_0x415e03+0x1)&0xfc00)===0xdc00?(_0x54fa0a=0x10000+((_0x54fa0a&0x3ff)<<0xa)+(_0xe06b58['charCodeAt'](++_0x415e03)&0x3ff),_0x98cc95[_0x11e563++]=_0x54fa0a>>0x12|0xf0,_0x98cc95[_0x11e563++]=_0x54fa0a>>0xc&0x3f|0x80,_0x98cc95[_0x11e563++]=_0x54fa0a>>0x6&0x3f|0x80,_0x98cc95[_0x11e563++]=_0x54fa0a&0x3f|0x80):(_0x98cc95[_0x11e563++]=_0x54fa0a>>0xc|0xe0,_0x98cc95[_0x11e563++]=_0x54fa0a>>0x6&0x3f|0x80,_0x98cc95[_0x11e563++]=_0x54fa0a&0x3f|0x80);}return _0x98cc95;},ec=function(_0x2c9ca9){const _0x170015=[];let _0x1c5515=0x0,_0x52f478=0x0;for(;_0x1c5515<_0x2c9ca9['length'];){const _0x25b970=_0x2c9ca9[_0x1c5515++];if(_0x25b970<0x80)_0x170015[_0x52f478++]=String['fromCharCode'](_0x25b970);else{if(_0x25b970>0xbf&&_0x25b970<0xe0){const _0x282f5a=_0x2c9ca9[_0x1c5515++];_0x170015[_0x52f478++]=String['fromCharCode']((_0x25b970&0x1f)<<0x6|_0x282f5a&0x3f);}else{if(_0x25b970>0xef&&_0x25b970<0x16d){const _0x3d9ca3=_0x2c9ca9[_0x1c5515++],_0x2d307d=_0x2c9ca9[_0x1c5515++],_0xaec310=_0x2c9ca9[_0x1c5515++],_0x1b87d6=((_0x25b970&0x7)<<0x12|(_0x3d9ca3&0x3f)<<0xc|(_0x2d307d&0x3f)<<0x6|_0xaec310&0x3f)-0x10000;_0x170015[_0x52f478++]=String['fromCharCode'](0xd800+(_0x1b87d6>>0xa)),_0x170015[_0x52f478++]=String['fromCharCode'](0xdc00+(_0x1b87d6&0x3ff));}else{const _0x3baf63=_0x2c9ca9[_0x1c5515++],_0x1c5c57=_0x2c9ca9[_0x1c5515++];_0x170015[_0x52f478++]=String['fromCharCode']((_0x25b970&0xf)<<0xc|(_0x3baf63&0x3f)<<0x6|_0x1c5c57&0x3f);}}}}return _0x170015['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x55119d,_0x44a6f8){if(!Array['isArray'](_0x55119d))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x189303=_0x44a6f8?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x42978d=[];for(let _0x3d8923=0x0;_0x3d8923<_0x55119d['length'];_0x3d8923+=0x3){const _0x3c7e55=_0x55119d[_0x3d8923],_0x5868ec=_0x3d8923+0x1<_0x55119d['length'],_0x3fcf10=_0x5868ec?_0x55119d[_0x3d8923+0x1]:0x0,_0x5d0953=_0x3d8923+0x2<_0x55119d['length'],_0x2360d0=_0x5d0953?_0x55119d[_0x3d8923+0x2]:0x0,_0x564220=_0x3c7e55>>0x2,_0x11b980=(_0x3c7e55&0x3)<<0x4|_0x3fcf10>>0x4;let _0x3ca2b2=(_0x3fcf10&0xf)<<0x2|_0x2360d0>>0x6,_0x494e23=_0x2360d0&0x3f;_0x5d0953||(_0x494e23=0x40,_0x5868ec||(_0x3ca2b2=0x40)),_0x42978d['push'](_0x189303[_0x564220],_0x189303[_0x11b980],_0x189303[_0x3ca2b2],_0x189303[_0x494e23]);}return _0x42978d['join']('');},'encodeString'(_0x59663c,_0x5a716c){return this['HAS_NATIVE_SUPPORT']&&!_0x5a716c?btoa(_0x59663c):this['encodeByteArray'](Vr(_0x59663c),_0x5a716c);},'decodeString'(_0x16675b,_0x4c5ad6){return this['HAS_NATIVE_SUPPORT']&&!_0x4c5ad6?atob(_0x16675b):ec(this['decodeStringToByteArray'](_0x16675b,_0x4c5ad6));},'decodeStringToByteArray'(_0x196d40,_0x413af7){this['init_']();const _0x3be24b=_0x413af7?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x301347=[];for(let _0x3379e6=0x0;_0x3379e6<_0x196d40['length'];){const _0x499e02=_0x3be24b[_0x196d40['charAt'](_0x3379e6++)],_0x1c33a5=_0x3379e6<_0x196d40['length']?_0x3be24b[_0x196d40['charAt'](_0x3379e6)]:0x0;++_0x3379e6;const _0x621f8=_0x3379e6<_0x196d40['length']?_0x3be24b[_0x196d40['charAt'](_0x3379e6)]:0x40;++_0x3379e6;const _0x5d0734=_0x3379e6<_0x196d40['length']?_0x3be24b[_0x196d40['charAt'](_0x3379e6)]:0x40;if(++_0x3379e6,_0x499e02==null||_0x1c33a5==null||_0x621f8==null||_0x5d0734==null)throw new tc();const _0x2c616c=_0x499e02<<0x2|_0x1c33a5>>0x4;if(_0x301347['push'](_0x2c616c),_0x621f8!==0x40){const _0x408e9a=_0x1c33a5<<0x4&0xf0|_0x621f8>>0x2;if(_0x301347['push'](_0x408e9a),_0x5d0734!==0x40){const _0x4ec74a=_0x621f8<<0x6&0xc0|_0x5d0734;_0x301347['push'](_0x4ec74a);}}}return _0x301347;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0xfdc6ec=0x0;_0xfdc6ec<this['ENCODED_VALS']['length'];_0xfdc6ec++)this['byteToCharMap_'][_0xfdc6ec]=this['ENCODED_VALS']['charAt'](_0xfdc6ec),this['charToByteMap_'][this['byteToCharMap_'][_0xfdc6ec]]=_0xfdc6ec,this['byteToCharMapWebSafe_'][_0xfdc6ec]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0xfdc6ec),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0xfdc6ec]]=_0xfdc6ec,_0xfdc6ec>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0xfdc6ec)]=_0xfdc6ec,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0xfdc6ec)]=_0xfdc6ec);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x4fcda7){const _0x163773=Vr(_0x4fcda7);return Li['encodeByteArray'](_0x163773,!0x0);},cn=function(_0x53fbf6){return Hr(_0x53fbf6)['replace'](/\./g,'');},ln=function(_0x3eaf49){try{return Li['decodeString'](_0x3eaf49,!0x0);}catch(_0x3d0bee){console['error']('base64Decode\x20failed:\x20',_0x3d0bee);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x2fc875){return $r(void 0x0,_0x2fc875);}function $r(_0x33598c,_0x44495a){if(!(_0x44495a instanceof Object))return _0x44495a;switch(_0x44495a['constructor']){case Date:const _0x1ee19f=_0x44495a;return new Date(_0x1ee19f['getTime']());case Object:_0x33598c===void 0x0&&(_0x33598c={});break;case Array:_0x33598c=[];break;default:return _0x44495a;}for(const _0x7b7426 in _0x44495a)!_0x44495a['hasOwnProperty'](_0x7b7426)||!ic(_0x7b7426)||(_0x33598c[_0x7b7426]=$r(_0x33598c[_0x7b7426],_0x44495a[_0x7b7426]));return _0x33598c;}function ic(_0x447d08){return _0x447d08!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x23d5ef=Ns['__FIREBASE_DEFAULTS__'];if(_0x23d5ef)return JSON['parse'](_0x23d5ef);},ac=()=>{if(typeof document>'u')return;let _0x4aa74b;try{_0x4aa74b=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x290dd3=_0x4aa74b&&ln(_0x4aa74b[0x1]);return _0x290dd3&&JSON['parse'](_0x290dd3);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x4cc0b9){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4cc0b9);return;}},Gr=_0x220d5b=>{var _0x5dd403,_0x6ab438;return(_0x6ab438=(_0x5dd403=xi())==null?void 0x0:_0x5dd403['emulatorHosts'])==null?void 0x0:_0x6ab438[_0x220d5b];},cc=_0x3fe8f0=>{const _0x20e657=Gr(_0x3fe8f0);if(!_0x20e657)return;const _0x412d81=_0x20e657['lastIndexOf'](':');if(_0x412d81<=0x0||_0x412d81+0x1===_0x20e657['length'])throw new Error('Invalid\x20host\x20'+_0x20e657+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x5956cf=parseInt(_0x20e657['substring'](_0x412d81+0x1),0xa);return _0x20e657[0x0]==='['?[_0x20e657['substring'](0x1,_0x412d81-0x1),_0x5956cf]:[_0x20e657['substring'](0x0,_0x412d81),_0x5956cf];},qr=()=>{var _0xb0d2ef;return(_0xb0d2ef=xi())==null?void 0x0:_0xb0d2ef['config'];},zr=_0x12b115=>{var _0x57bf0f;return(_0x57bf0f=xi())==null?void 0x0:_0x57bf0f['_'+_0x12b115];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x350e18,_0x3c0162)=>{this['resolve']=_0x350e18,this['reject']=_0x3c0162;});}['wrapCallback'](_0x144e0a){return(_0x11b0d7,_0x44becd)=>{_0x11b0d7?this['reject'](_0x11b0d7):this['resolve'](_0x44becd),typeof _0x144e0a=='function'&&(this['promise']['catch'](()=>{}),_0x144e0a['length']===0x1?_0x144e0a(_0x11b0d7):_0x144e0a(_0x11b0d7,_0x44becd));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x1f2eec){try{return(_0x1f2eec['startsWith']('http://')||_0x1f2eec['startsWith']('https://')?new URL(_0x1f2eec)['hostname']:_0x1f2eec)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x3704d4){return(await fetch(_0x3704d4,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x31aaa3,_0x4ce7af){if(_0x31aaa3['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x337f2e={'alg':'none','type':'JWT'},_0x1507b0=_0x4ce7af||'demo-project',_0xf8f501=_0x31aaa3['iat']||0x0,_0x2e1c13=_0x31aaa3['sub']||_0x31aaa3['user_id'];if(!_0x2e1c13)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x166ba8={'iss':'https://securetoken.google.com/'+_0x1507b0,'aud':_0x1507b0,'iat':_0xf8f501,'exp':_0xf8f501+0xe10,'auth_time':_0xf8f501,'sub':_0x2e1c13,'user_id':_0x2e1c13,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x31aaa3};return[cn(JSON['stringify'](_0x337f2e)),cn(JSON['stringify'](_0x166ba8)),'']['join']('.');}const It={};function hc(){const _0x4ccef9={'prod':[],'emulator':[]};for(const _0x5dcabe of Object['keys'](It))It[_0x5dcabe]?_0x4ccef9['emulator']['push'](_0x5dcabe):_0x4ccef9['prod']['push'](_0x5dcabe);return _0x4ccef9;}function uc(_0x3b1574){let _0x55b1de=document['getElementById'](_0x3b1574),_0x3489d9=!0x1;return _0x55b1de||(_0x55b1de=document['createElement']('div'),_0x55b1de['setAttribute']('id',_0x3b1574),_0x3489d9=!0x0),{'created':_0x3489d9,'element':_0x55b1de};}let Ps=!0x1;function Kr(_0x3aabf5,_0x5319c3){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x3aabf5]===_0x5319c3||It[_0x3aabf5]||Ps)return;It[_0x3aabf5]=_0x5319c3;function _0x6e0d69(_0x97d8c8){return'__firebase__banner__'+_0x97d8c8;}const _0x344f4c='__firebase__banner',_0x9dc8ae=hc()['prod']['length']>0x0;function _0xc5b0a2(){const _0x4fa638=document['getElementById'](_0x344f4c);_0x4fa638&&_0x4fa638['remove']();}function _0x27a03f(_0x5a5d6d){_0x5a5d6d['style']['display']='flex',_0x5a5d6d['style']['background']='#7faaf0',_0x5a5d6d['style']['position']='fixed',_0x5a5d6d['style']['bottom']='5px',_0x5a5d6d['style']['left']='5px',_0x5a5d6d['style']['padding']='.5em',_0x5a5d6d['style']['borderRadius']='5px',_0x5a5d6d['style']['alignItems']='center';}function _0x4d1cae(_0x2b96d3,_0x47e905){_0x2b96d3['setAttribute']('width','24'),_0x2b96d3['setAttribute']('id',_0x47e905),_0x2b96d3['setAttribute']('height','24'),_0x2b96d3['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x2b96d3['setAttribute']('fill','none'),_0x2b96d3['style']['marginLeft']='-6px';}function _0x29972e(){const _0x2dc7c2=document['createElement']('span');return _0x2dc7c2['style']['cursor']='pointer',_0x2dc7c2['style']['marginLeft']='16px',_0x2dc7c2['style']['fontSize']='24px',_0x2dc7c2['innerHTML']='\x20&times;',_0x2dc7c2['onclick']=()=>{Ps=!0x0,_0xc5b0a2();},_0x2dc7c2;}function _0x1c9034(_0x3cb3d4,_0x1d15ba){_0x3cb3d4['setAttribute']('id',_0x1d15ba),_0x3cb3d4['innerText']='Learn\x20more',_0x3cb3d4['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x3cb3d4['setAttribute']('target','__blank'),_0x3cb3d4['style']['paddingLeft']='5px',_0x3cb3d4['style']['textDecoration']='underline';}function _0x5c1592(){const _0x120dea=uc(_0x344f4c),_0x48b810=_0x6e0d69('text'),_0x7d74d9=document['getElementById'](_0x48b810)||document['createElement']('span'),_0x42eacb=_0x6e0d69('learnmore'),_0x2b15bb=document['getElementById'](_0x42eacb)||document['createElement']('a'),_0x21dacf=_0x6e0d69('preprendIcon'),_0x1aa050=document['getElementById'](_0x21dacf)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x120dea['created']){const _0x379700=_0x120dea['element'];_0x27a03f(_0x379700),_0x1c9034(_0x2b15bb,_0x42eacb);const _0x3e275a=_0x29972e();_0x4d1cae(_0x1aa050,_0x21dacf),_0x379700['append'](_0x1aa050,_0x7d74d9,_0x2b15bb,_0x3e275a),document['body']['appendChild'](_0x379700);}_0x9dc8ae?(_0x7d74d9['innerText']='Preview\x20backend\x20disconnected.',_0x1aa050['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x1aa050['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x7d74d9['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x7d74d9['setAttribute']('id',_0x48b810);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x5c1592):_0x5c1592();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x502b3f=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x502b3f=='object'&&_0x502b3f['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x3f23ba=W();return _0x3f23ba['indexOf']('MSIE\x20')>=0x0||_0x3f23ba['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x3bf5fe,_0x292bd8)=>{try{let _0x305dd2=!0x0;const _0x38662f='validate-browser-context-for-indexeddb-analytics-module',_0x710164=self['indexedDB']['open'](_0x38662f);_0x710164['onsuccess']=()=>{_0x710164['result']['close'](),_0x305dd2||self['indexedDB']['deleteDatabase'](_0x38662f),_0x3bf5fe(!0x0);},_0x710164['onupgradeneeded']=()=>{_0x305dd2=!0x1;},_0x710164['onerror']=()=>{var _0x3247fe;_0x292bd8(((_0x3247fe=_0x710164['error'])==null?void 0x0:_0x3247fe['message'])||'');};}catch(_0x1a1ccd){_0x292bd8(_0x1a1ccd);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x16cd51,_0x57a6a5,_0x22d0f0){super(_0x57a6a5),this['code']=_0x16cd51,this['customData']=_0x22d0f0,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x4f6a04,_0x4ddece,_0x367bcf){this['service']=_0x4f6a04,this['serviceName']=_0x4ddece,this['errors']=_0x367bcf;}['create'](_0x83536e,..._0x2d0f37){const _0x158b63=_0x2d0f37[0x0]||{},_0x36e91b=this['service']+'/'+_0x83536e,_0x45587e=this['errors'][_0x83536e],_0x3364b3=_0x45587e?vc(_0x45587e,_0x158b63):'Error',_0x137e37=this['serviceName']+':\x20'+_0x3364b3+'\x20('+_0x36e91b+').';return new Se(_0x36e91b,_0x137e37,_0x158b63);}}function vc(_0x3e2b12,_0x2bcc9c){return _0x3e2b12['replace'](Ec,(_0x35004b,_0x4ca6a8)=>{const _0x3c4d07=_0x2bcc9c[_0x4ca6a8];return _0x3c4d07!=null?String(_0x3c4d07):'<'+_0x4ca6a8+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x369625){return JSON['parse'](_0x369625);}function O(_0x14dbef){return JSON['stringify'](_0x14dbef);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x1a257c){let _0x257a01={},_0x1eb017={},_0x5482f9={},_0x3b98f1='';try{const _0x3b71ae=_0x1a257c['split']('.');_0x257a01=At(ln(_0x3b71ae[0x0])||''),_0x1eb017=At(ln(_0x3b71ae[0x1])||''),_0x3b98f1=_0x3b71ae[0x2],_0x5482f9=_0x1eb017['d']||{},delete _0x1eb017['d'];}catch{}return{'header':_0x257a01,'claims':_0x1eb017,'data':_0x5482f9,'signature':_0x3b98f1};},Ic=function(_0x5ce926){const _0x3418d1=Qr(_0x5ce926),_0x4a2256=_0x3418d1['claims'];return!!_0x4a2256&&typeof _0x4a2256=='object'&&_0x4a2256['hasOwnProperty']('iat');},wc=function(_0x29db85){const _0x5bb77c=Qr(_0x29db85)['claims'];return typeof _0x5bb77c=='object'&&_0x5bb77c['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x44e2b9,_0x46349d){return Object['prototype']['hasOwnProperty']['call'](_0x44e2b9,_0x46349d);}function De(_0x3a9f1d,_0x4883c5){if(Object['prototype']['hasOwnProperty']['call'](_0x3a9f1d,_0x4883c5))return _0x3a9f1d[_0x4883c5];}function ui(_0x2078b1){for(const _0x916eb4 in _0x2078b1)if(Object['prototype']['hasOwnProperty']['call'](_0x2078b1,_0x916eb4))return!0x1;return!0x0;}function hn(_0x26f440,_0x3c6956,_0x3e8711){const _0x3b7ec1={};for(const _0x5ea7e5 in _0x26f440)Object['prototype']['hasOwnProperty']['call'](_0x26f440,_0x5ea7e5)&&(_0x3b7ec1[_0x5ea7e5]=_0x3c6956['call'](_0x3e8711,_0x26f440[_0x5ea7e5],_0x5ea7e5,_0x26f440));return _0x3b7ec1;}function Me(_0x269e8e,_0x1a5b5f){if(_0x269e8e===_0x1a5b5f)return!0x0;const _0x53c273=Object['keys'](_0x269e8e),_0xbe9d5e=Object['keys'](_0x1a5b5f);for(const _0x4c76c0 of _0x53c273){if(!_0xbe9d5e['includes'](_0x4c76c0))return!0x1;const _0x457055=_0x269e8e[_0x4c76c0],_0xa1bcc3=_0x1a5b5f[_0x4c76c0];if(Os(_0x457055)&&Os(_0xa1bcc3)){if(!Me(_0x457055,_0xa1bcc3))return!0x1;}else{if(_0x457055!==_0xa1bcc3)return!0x1;}}for(const _0x8a02a0 of _0xbe9d5e)if(!_0x53c273['includes'](_0x8a02a0))return!0x1;return!0x0;}function Os(_0x284690){return _0x284690!==null&&typeof _0x284690=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x3a6cfb){const _0x1dbede=[];for(const [_0x223956,_0x1022c0]of Object['entries'](_0x3a6cfb))Array['isArray'](_0x1022c0)?_0x1022c0['forEach'](_0x598276=>{_0x1dbede['push'](encodeURIComponent(_0x223956)+'='+encodeURIComponent(_0x598276));}):_0x1dbede['push'](encodeURIComponent(_0x223956)+'='+encodeURIComponent(_0x1022c0));return _0x1dbede['length']?'&'+_0x1dbede['join']('&'):'';}function vt(_0x5f3fbc){const _0xf0db93={};return _0x5f3fbc['replace'](/^\?/,'')['split']('&')['forEach'](_0x5c831c=>{if(_0x5c831c){const [_0xf14a2c,_0x1b9851]=_0x5c831c['split']('=');_0xf0db93[decodeURIComponent(_0xf14a2c)]=decodeURIComponent(_0x1b9851);}}),_0xf0db93;}function Et(_0x88086){const _0x23a2e0=_0x88086['indexOf']('?');if(!_0x23a2e0)return'';const _0x54de1c=_0x88086['indexOf']('#',_0x23a2e0);return _0x88086['substring'](_0x23a2e0,_0x54de1c>0x0?_0x54de1c:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x156b4b=0x1;_0x156b4b<this['blockSize'];++_0x156b4b)this['pad_'][_0x156b4b]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x3a3cfd,_0x4e755f){_0x4e755f||(_0x4e755f=0x0);const _0x3f75b9=this['W_'];if(typeof _0x3a3cfd=='string'){for(let _0x61abb9=0x0;_0x61abb9<0x10;_0x61abb9++)_0x3f75b9[_0x61abb9]=_0x3a3cfd['charCodeAt'](_0x4e755f)<<0x18|_0x3a3cfd['charCodeAt'](_0x4e755f+0x1)<<0x10|_0x3a3cfd['charCodeAt'](_0x4e755f+0x2)<<0x8|_0x3a3cfd['charCodeAt'](_0x4e755f+0x3),_0x4e755f+=0x4;}else{for(let _0x3e57bb=0x0;_0x3e57bb<0x10;_0x3e57bb++)_0x3f75b9[_0x3e57bb]=_0x3a3cfd[_0x4e755f]<<0x18|_0x3a3cfd[_0x4e755f+0x1]<<0x10|_0x3a3cfd[_0x4e755f+0x2]<<0x8|_0x3a3cfd[_0x4e755f+0x3],_0x4e755f+=0x4;}for(let _0x490ace=0x10;_0x490ace<0x50;_0x490ace++){const _0x121e4c=_0x3f75b9[_0x490ace-0x3]^_0x3f75b9[_0x490ace-0x8]^_0x3f75b9[_0x490ace-0xe]^_0x3f75b9[_0x490ace-0x10];_0x3f75b9[_0x490ace]=(_0x121e4c<<0x1|_0x121e4c>>>0x1f)&0xffffffff;}let _0x1eb4e8=this['chain_'][0x0],_0x51599a=this['chain_'][0x1],_0x109b3e=this['chain_'][0x2],_0x472b6e=this['chain_'][0x3],_0x1dd9bc=this['chain_'][0x4],_0x2004a8,_0x195ab7;for(let _0x3144bf=0x0;_0x3144bf<0x50;_0x3144bf++){_0x3144bf<0x28?_0x3144bf<0x14?(_0x2004a8=_0x472b6e^_0x51599a&(_0x109b3e^_0x472b6e),_0x195ab7=0x5a827999):(_0x2004a8=_0x51599a^_0x109b3e^_0x472b6e,_0x195ab7=0x6ed9eba1):_0x3144bf<0x3c?(_0x2004a8=_0x51599a&_0x109b3e|_0x472b6e&(_0x51599a|_0x109b3e),_0x195ab7=0x8f1bbcdc):(_0x2004a8=_0x51599a^_0x109b3e^_0x472b6e,_0x195ab7=0xca62c1d6);const _0x235a5b=(_0x1eb4e8<<0x5|_0x1eb4e8>>>0x1b)+_0x2004a8+_0x1dd9bc+_0x195ab7+_0x3f75b9[_0x3144bf]&0xffffffff;_0x1dd9bc=_0x472b6e,_0x472b6e=_0x109b3e,_0x109b3e=(_0x51599a<<0x1e|_0x51599a>>>0x2)&0xffffffff,_0x51599a=_0x1eb4e8,_0x1eb4e8=_0x235a5b;}this['chain_'][0x0]=this['chain_'][0x0]+_0x1eb4e8&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x51599a&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x109b3e&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x472b6e&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x1dd9bc&0xffffffff;}['update'](_0x399a1b,_0x3cf846){if(_0x399a1b==null)return;_0x3cf846===void 0x0&&(_0x3cf846=_0x399a1b['length']);const _0xfe82b3=_0x3cf846-this['blockSize'];let _0x5027d1=0x0;const _0x1fcc70=this['buf_'];let _0xc53722=this['inbuf_'];for(;_0x5027d1<_0x3cf846;){if(_0xc53722===0x0){for(;_0x5027d1<=_0xfe82b3;)this['compress_'](_0x399a1b,_0x5027d1),_0x5027d1+=this['blockSize'];}if(typeof _0x399a1b=='string'){for(;_0x5027d1<_0x3cf846;)if(_0x1fcc70[_0xc53722]=_0x399a1b['charCodeAt'](_0x5027d1),++_0xc53722,++_0x5027d1,_0xc53722===this['blockSize']){this['compress_'](_0x1fcc70),_0xc53722=0x0;break;}}else{for(;_0x5027d1<_0x3cf846;)if(_0x1fcc70[_0xc53722]=_0x399a1b[_0x5027d1],++_0xc53722,++_0x5027d1,_0xc53722===this['blockSize']){this['compress_'](_0x1fcc70),_0xc53722=0x0;break;}}}this['inbuf_']=_0xc53722,this['total_']+=_0x3cf846;}['digest'](){const _0x5560c4=[];let _0x339cd3=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x2c6b50=this['blockSize']-0x1;_0x2c6b50>=0x38;_0x2c6b50--)this['buf_'][_0x2c6b50]=_0x339cd3&0xff,_0x339cd3/=0x100;this['compress_'](this['buf_']);let _0x3a0f69=0x0;for(let _0x579f3b=0x0;_0x579f3b<0x5;_0x579f3b++)for(let _0x46a847=0x18;_0x46a847>=0x0;_0x46a847-=0x8)_0x5560c4[_0x3a0f69]=this['chain_'][_0x579f3b]>>_0x46a847&0xff,++_0x3a0f69;return _0x5560c4;}}function Tc(_0x150d15,_0x429d5c){const _0x403dff=new Sc(_0x150d15,_0x429d5c);return _0x403dff['subscribe']['bind'](_0x403dff);}class Sc{constructor(_0x22fe4f,_0xcb0280){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0xcb0280,this['task']['then'](()=>{_0x22fe4f(this);})['catch'](_0x3cba48=>{this['error'](_0x3cba48);});}['next'](_0xb819c){this['forEachObserver'](_0x1e62aa=>{_0x1e62aa['next'](_0xb819c);});}['error'](_0x4058b3){this['forEachObserver'](_0x295294=>{_0x295294['error'](_0x4058b3);}),this['close'](_0x4058b3);}['complete'](){this['forEachObserver'](_0x4e596d=>{_0x4e596d['complete']();}),this['close']();}['subscribe'](_0x2939d2,_0x3c32bb,_0x12a7d1){let _0x4d5dc4;if(_0x2939d2===void 0x0&&_0x3c32bb===void 0x0&&_0x12a7d1===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x2939d2,['next','error','complete'])?_0x4d5dc4=_0x2939d2:_0x4d5dc4={'next':_0x2939d2,'error':_0x3c32bb,'complete':_0x12a7d1},_0x4d5dc4['next']===void 0x0&&(_0x4d5dc4['next']=Jn),_0x4d5dc4['error']===void 0x0&&(_0x4d5dc4['error']=Jn),_0x4d5dc4['complete']===void 0x0&&(_0x4d5dc4['complete']=Jn);const _0x59db0e=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x4d5dc4['error'](this['finalError']):_0x4d5dc4['complete']();}catch{}}),this['observers']['push'](_0x4d5dc4),_0x59db0e;}['unsubscribeOne'](_0x5c99c1){this['observers']===void 0x0||this['observers'][_0x5c99c1]===void 0x0||(delete this['observers'][_0x5c99c1],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x530aa4){if(!this['finalized']){for(let _0x45b70a=0x0;_0x45b70a<this['observers']['length'];_0x45b70a++)this['sendOne'](_0x45b70a,_0x530aa4);}}['sendOne'](_0x59bc51,_0x36b800){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x59bc51]!==void 0x0)try{_0x36b800(this['observers'][_0x59bc51]);}catch(_0x542c2c){typeof console<'u'&&console['error']&&console['error'](_0x542c2c);}});}['close'](_0x48344f){this['finalized']||(this['finalized']=!0x0,_0x48344f!==void 0x0&&(this['finalError']=_0x48344f),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x169be6,_0x6263a1){if(typeof _0x169be6!='object'||_0x169be6===null)return!0x1;for(const _0x30f27e of _0x6263a1)if(_0x30f27e in _0x169be6&&typeof _0x169be6[_0x30f27e]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x949230,_0xac8bd2){return _0x949230+'\x20failed:\x20'+_0xac8bd2+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x40c82a){const _0x5816cc=[];let _0x39e561=0x0;for(let _0x151527=0x0;_0x151527<_0x40c82a['length'];_0x151527++){let _0x1da3ec=_0x40c82a['charCodeAt'](_0x151527);if(_0x1da3ec>=0xd800&&_0x1da3ec<=0xdbff){const _0x16ba09=_0x1da3ec-0xd800;_0x151527++,f(_0x151527<_0x40c82a['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x2a4c5e=_0x40c82a['charCodeAt'](_0x151527)-0xdc00;_0x1da3ec=0x10000+(_0x16ba09<<0xa)+_0x2a4c5e;}_0x1da3ec<0x80?_0x5816cc[_0x39e561++]=_0x1da3ec:_0x1da3ec<0x800?(_0x5816cc[_0x39e561++]=_0x1da3ec>>0x6|0xc0,_0x5816cc[_0x39e561++]=_0x1da3ec&0x3f|0x80):_0x1da3ec<0x10000?(_0x5816cc[_0x39e561++]=_0x1da3ec>>0xc|0xe0,_0x5816cc[_0x39e561++]=_0x1da3ec>>0x6&0x3f|0x80,_0x5816cc[_0x39e561++]=_0x1da3ec&0x3f|0x80):(_0x5816cc[_0x39e561++]=_0x1da3ec>>0x12|0xf0,_0x5816cc[_0x39e561++]=_0x1da3ec>>0xc&0x3f|0x80,_0x5816cc[_0x39e561++]=_0x1da3ec>>0x6&0x3f|0x80,_0x5816cc[_0x39e561++]=_0x1da3ec&0x3f|0x80);}return _0x5816cc;},On=function(_0x5838f4){let _0x1cd4d2=0x0;for(let _0x13b815=0x0;_0x13b815<_0x5838f4['length'];_0x13b815++){const _0x2ba63a=_0x5838f4['charCodeAt'](_0x13b815);_0x2ba63a<0x80?_0x1cd4d2++:_0x2ba63a<0x800?_0x1cd4d2+=0x2:_0x2ba63a>=0xd800&&_0x2ba63a<=0xdbff?(_0x1cd4d2+=0x4,_0x13b815++):_0x1cd4d2+=0x3;}return _0x1cd4d2;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x2bdd12){return _0x2bdd12&&_0x2bdd12['_delegate']?_0x2bdd12['_delegate']:_0x2bdd12;}class Le{constructor(_0x90b08b,_0x1ebce3,_0x14db39){this['name']=_0x90b08b,this['instanceFactory']=_0x1ebce3,this['type']=_0x14db39,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x1c3e81){return this['instantiationMode']=_0x1c3e81,this;}['setMultipleInstances'](_0x377d0d){return this['multipleInstances']=_0x377d0d,this;}['setServiceProps'](_0x1686d6){return this['serviceProps']=_0x1686d6,this;}['setInstanceCreatedCallback'](_0xb91d88){return this['onInstanceCreated']=_0xb91d88,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x38591e,_0x476d79){this['name']=_0x38591e,this['container']=_0x476d79,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x50c5f9){const _0x20e3d0=this['normalizeInstanceIdentifier'](_0x50c5f9);if(!this['instancesDeferred']['has'](_0x20e3d0)){const _0x1d01b9=new ot();if(this['instancesDeferred']['set'](_0x20e3d0,_0x1d01b9),this['isInitialized'](_0x20e3d0)||this['shouldAutoInitialize']())try{const _0x1e0931=this['getOrInitializeService']({'instanceIdentifier':_0x20e3d0});_0x1e0931&&_0x1d01b9['resolve'](_0x1e0931);}catch{}}return this['instancesDeferred']['get'](_0x20e3d0)['promise'];}['getImmediate'](_0x1e378a){const _0x4edc27=this['normalizeInstanceIdentifier'](_0x1e378a==null?void 0x0:_0x1e378a['identifier']),_0x39e7d9=(_0x1e378a==null?void 0x0:_0x1e378a['optional'])??!0x1;if(this['isInitialized'](_0x4edc27)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4edc27});}catch(_0x331d3f){if(_0x39e7d9)return null;throw _0x331d3f;}else{if(_0x39e7d9)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x3addc6){if(_0x3addc6['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x3addc6['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x3addc6,!!this['shouldAutoInitialize']()){if(Nc(_0x3addc6))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x370c50,_0x13133d]of this['instancesDeferred']['entries']()){const _0x349d7c=this['normalizeInstanceIdentifier'](_0x370c50);try{const _0x42f9a6=this['getOrInitializeService']({'instanceIdentifier':_0x349d7c});_0x13133d['resolve'](_0x42f9a6);}catch{}}}}['clearInstance'](_0x24740e=Ne){this['instancesDeferred']['delete'](_0x24740e),this['instancesOptions']['delete'](_0x24740e),this['instances']['delete'](_0x24740e);}async['delete'](){const _0x196689=Array['from'](this['instances']['values']());await Promise['all']([..._0x196689['filter'](_0x5789a8=>'INTERNAL'in _0x5789a8)['map'](_0x2f7639=>_0x2f7639['INTERNAL']['delete']()),..._0x196689['filter'](_0x201fc9=>'_delete'in _0x201fc9)['map'](_0x31bc07=>_0x31bc07['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x358e37=Ne){return this['instances']['has'](_0x358e37);}['getOptions'](_0x2df658=Ne){return this['instancesOptions']['get'](_0x2df658)||{};}['initialize'](_0x9a2d52={}){const {options:_0x3aff3c={}}=_0x9a2d52,_0x5d46d9=this['normalizeInstanceIdentifier'](_0x9a2d52['instanceIdentifier']);if(this['isInitialized'](_0x5d46d9))throw Error(this['name']+'('+_0x5d46d9+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x364265=this['getOrInitializeService']({'instanceIdentifier':_0x5d46d9,'options':_0x3aff3c});for(const [_0x4c0eda,_0x327a63]of this['instancesDeferred']['entries']()){const _0x28e247=this['normalizeInstanceIdentifier'](_0x4c0eda);_0x5d46d9===_0x28e247&&_0x327a63['resolve'](_0x364265);}return _0x364265;}['onInit'](_0x4a299d,_0x3871ea){const _0xf7a047=this['normalizeInstanceIdentifier'](_0x3871ea),_0x504dee=this['onInitCallbacks']['get'](_0xf7a047)??new Set();_0x504dee['add'](_0x4a299d),this['onInitCallbacks']['set'](_0xf7a047,_0x504dee);const _0x261eca=this['instances']['get'](_0xf7a047);return _0x261eca&&_0x4a299d(_0x261eca,_0xf7a047),()=>{_0x504dee['delete'](_0x4a299d);};}['invokeOnInitCallbacks'](_0x1063eb,_0x180a2e){const _0x2a9918=this['onInitCallbacks']['get'](_0x180a2e);if(_0x2a9918){for(const _0x52d3bc of _0x2a9918)try{_0x52d3bc(_0x1063eb,_0x180a2e);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x3f5eef,options:_0x4794a1={}}){let _0x3c213e=this['instances']['get'](_0x3f5eef);if(!_0x3c213e&&this['component']&&(_0x3c213e=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x3f5eef),'options':_0x4794a1}),this['instances']['set'](_0x3f5eef,_0x3c213e),this['instancesOptions']['set'](_0x3f5eef,_0x4794a1),this['invokeOnInitCallbacks'](_0x3c213e,_0x3f5eef),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x3f5eef,_0x3c213e);}catch{}return _0x3c213e||null;}['normalizeInstanceIdentifier'](_0x4066b6=Ne){return this['component']?this['component']['multipleInstances']?_0x4066b6:Ne:_0x4066b6;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x310c3){return _0x310c3===Ne?void 0x0:_0x310c3;}function Nc(_0x3db553){return _0x3db553['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x53c804){this['name']=_0x53c804,this['providers']=new Map();}['addComponent'](_0x112549){const _0x442238=this['getProvider'](_0x112549['name']);if(_0x442238['isComponentSet']())throw new Error('Component\x20'+_0x112549['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x442238['setComponent'](_0x112549);}['addOrOverwriteComponent'](_0x4248d0){this['getProvider'](_0x4248d0['name'])['isComponentSet']()&&this['providers']['delete'](_0x4248d0['name']),this['addComponent'](_0x4248d0);}['getProvider'](_0x4a1eb4){if(this['providers']['has'](_0x4a1eb4))return this['providers']['get'](_0x4a1eb4);const _0x14be5a=new Ac(_0x4a1eb4,this);return this['providers']['set'](_0x4a1eb4,_0x14be5a),_0x14be5a;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x3318cb){_0x3318cb[_0x3318cb['DEBUG']=0x0]='DEBUG',_0x3318cb[_0x3318cb['VERBOSE']=0x1]='VERBOSE',_0x3318cb[_0x3318cb['INFO']=0x2]='INFO',_0x3318cb[_0x3318cb['WARN']=0x3]='WARN',_0x3318cb[_0x3318cb['ERROR']=0x4]='ERROR',_0x3318cb[_0x3318cb['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x2c0450,_0x3fe82e,..._0x54540f)=>{if(_0x3fe82e<_0x2c0450['logLevel'])return;const _0x472082=new Date()['toISOString'](),_0x134f5b=Mc[_0x3fe82e];if(_0x134f5b)console[_0x134f5b]('['+_0x472082+']\x20\x20'+_0x2c0450['name']+':',..._0x54540f);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x3fe82e+')');};class Ui{constructor(_0x346f2d){this['name']=_0x346f2d,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x47afde){if(!(_0x47afde in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x47afde+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x47afde;}['setLogLevel'](_0x477026){this['_logLevel']=typeof _0x477026=='string'?Oc[_0x477026]:_0x477026;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0xeffe4f){if(typeof _0xeffe4f!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0xeffe4f;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x488c4b){this['_userLogHandler']=_0x488c4b;}['debug'](..._0x4fdbca){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x4fdbca),this['_logHandler'](this,T['DEBUG'],..._0x4fdbca);}['log'](..._0x58783b){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x58783b),this['_logHandler'](this,T['VERBOSE'],..._0x58783b);}['info'](..._0x4702cd){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x4702cd),this['_logHandler'](this,T['INFO'],..._0x4702cd);}['warn'](..._0x559c32){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x559c32),this['_logHandler'](this,T['WARN'],..._0x559c32);}['error'](..._0x280114){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x280114),this['_logHandler'](this,T['ERROR'],..._0x280114);}}const xc=(_0x2bb341,_0x48c250)=>_0x48c250['some'](_0x52c660=>_0x2bb341 instanceof _0x52c660);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x399b92){const _0x212905=new Promise((_0x493544,_0x5e6600)=>{const _0x4a6540=()=>{_0x399b92['removeEventListener']('success',_0x5824f6),_0x399b92['removeEventListener']('error',_0x3a5d83);},_0x5824f6=()=>{_0x493544(_e(_0x399b92['result'])),_0x4a6540();},_0x3a5d83=()=>{_0x5e6600(_0x399b92['error']),_0x4a6540();};_0x399b92['addEventListener']('success',_0x5824f6),_0x399b92['addEventListener']('error',_0x3a5d83);});return _0x212905['then'](_0x10bae8=>{_0x10bae8 instanceof IDBCursor&&Jr['set'](_0x10bae8,_0x399b92);})['catch'](()=>{}),Wi['set'](_0x212905,_0x399b92),_0x212905;}function Bc(_0x557cae){if(di['has'](_0x557cae))return;const _0x20178d=new Promise((_0xfdca68,_0x569976)=>{const _0x480e9f=()=>{_0x557cae['removeEventListener']('complete',_0x5417ec),_0x557cae['removeEventListener']('error',_0x23bc71),_0x557cae['removeEventListener']('abort',_0x23bc71);},_0x5417ec=()=>{_0xfdca68(),_0x480e9f();},_0x23bc71=()=>{_0x569976(_0x557cae['error']||new DOMException('AbortError','AbortError')),_0x480e9f();};_0x557cae['addEventListener']('complete',_0x5417ec),_0x557cae['addEventListener']('error',_0x23bc71),_0x557cae['addEventListener']('abort',_0x23bc71);});di['set'](_0x557cae,_0x20178d);}let fi={'get'(_0xb7fffe,_0x24271a,_0xb2d0b0){if(_0xb7fffe instanceof IDBTransaction){if(_0x24271a==='done')return di['get'](_0xb7fffe);if(_0x24271a==='objectStoreNames')return _0xb7fffe['objectStoreNames']||Xr['get'](_0xb7fffe);if(_0x24271a==='store')return _0xb2d0b0['objectStoreNames'][0x1]?void 0x0:_0xb2d0b0['objectStore'](_0xb2d0b0['objectStoreNames'][0x0]);}return _e(_0xb7fffe[_0x24271a]);},'set'(_0x1c1868,_0x23b8e3,_0x44f824){return _0x1c1868[_0x23b8e3]=_0x44f824,!0x0;},'has'(_0x4a4985,_0x5bc573){return _0x4a4985 instanceof IDBTransaction&&(_0x5bc573==='done'||_0x5bc573==='store')?!0x0:_0x5bc573 in _0x4a4985;}};function Vc(_0xcee6a8){fi=_0xcee6a8(fi);}function Hc(_0x511044){return _0x511044===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x42bec0,..._0xbce3eb){const _0x1301ce=_0x511044['call'](Zn(this),_0x42bec0,..._0xbce3eb);return Xr['set'](_0x1301ce,_0x42bec0['sort']?_0x42bec0['sort']():[_0x42bec0]),_e(_0x1301ce);}:Uc()['includes'](_0x511044)?function(..._0x2d790c){return _0x511044['apply'](Zn(this),_0x2d790c),_e(Jr['get'](this));}:function(..._0x2b4380){return _e(_0x511044['apply'](Zn(this),_0x2b4380));};}function $c(_0x1b64d6){return typeof _0x1b64d6=='function'?Hc(_0x1b64d6):(_0x1b64d6 instanceof IDBTransaction&&Bc(_0x1b64d6),xc(_0x1b64d6,Fc())?new Proxy(_0x1b64d6,fi):_0x1b64d6);}function _e(_0x2aa4f7){if(_0x2aa4f7 instanceof IDBRequest)return Wc(_0x2aa4f7);if(Xn['has'](_0x2aa4f7))return Xn['get'](_0x2aa4f7);const _0x37cffd=$c(_0x2aa4f7);return _0x37cffd!==_0x2aa4f7&&(Xn['set'](_0x2aa4f7,_0x37cffd),Wi['set'](_0x37cffd,_0x2aa4f7)),_0x37cffd;}const Zn=_0x2a4175=>Wi['get'](_0x2a4175);function Gc(_0x43466a,_0x627b3c,{blocked:_0x4d32ad,upgrade:_0x283b36,blocking:_0x29dbd1,terminated:_0x248edf}={}){const _0x3e92c5=indexedDB['open'](_0x43466a,_0x627b3c),_0xd5b65e=_e(_0x3e92c5);return _0x283b36&&_0x3e92c5['addEventListener']('upgradeneeded',_0x3a1a38=>{_0x283b36(_e(_0x3e92c5['result']),_0x3a1a38['oldVersion'],_0x3a1a38['newVersion'],_e(_0x3e92c5['transaction']),_0x3a1a38);}),_0x4d32ad&&_0x3e92c5['addEventListener']('blocked',_0x434e95=>_0x4d32ad(_0x434e95['oldVersion'],_0x434e95['newVersion'],_0x434e95)),_0xd5b65e['then'](_0x1743c1=>{_0x248edf&&_0x1743c1['addEventListener']('close',()=>_0x248edf()),_0x29dbd1&&_0x1743c1['addEventListener']('versionchange',_0xf24fe3=>_0x29dbd1(_0xf24fe3['oldVersion'],_0xf24fe3['newVersion'],_0xf24fe3));})['catch'](()=>{}),_0xd5b65e;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x31abef,_0x25c061){if(!(_0x31abef instanceof IDBDatabase&&!(_0x25c061 in _0x31abef)&&typeof _0x25c061=='string'))return;if(ei['get'](_0x25c061))return ei['get'](_0x25c061);const _0x5c4d19=_0x25c061['replace'](/FromIndex$/,''),_0xcfa6e4=_0x25c061!==_0x5c4d19,_0xc0b3af=zc['includes'](_0x5c4d19);if(!(_0x5c4d19 in(_0xcfa6e4?IDBIndex:IDBObjectStore)['prototype'])||!(_0xc0b3af||qc['includes'](_0x5c4d19)))return;const _0x43d273=async function(_0x134358,..._0x3f2dcc){const _0x30af71=this['transaction'](_0x134358,_0xc0b3af?'readwrite':'readonly');let _0x21699f=_0x30af71['store'];return _0xcfa6e4&&(_0x21699f=_0x21699f['index'](_0x3f2dcc['shift']())),(await Promise['all']([_0x21699f[_0x5c4d19](..._0x3f2dcc),_0xc0b3af&&_0x30af71['done']]))[0x0];};return ei['set'](_0x25c061,_0x43d273),_0x43d273;}Vc(_0x11804f=>({..._0x11804f,'get':(_0xa6955a,_0x30e60f,_0x5b49f6)=>Ls(_0xa6955a,_0x30e60f)||_0x11804f['get'](_0xa6955a,_0x30e60f,_0x5b49f6),'has':(_0x3a1ed5,_0x5e3fea)=>!!Ls(_0x3a1ed5,_0x5e3fea)||_0x11804f['has'](_0x3a1ed5,_0x5e3fea)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x19b55e){this['container']=_0x19b55e;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x1d6a64=>{if(Kc(_0x1d6a64)){const _0x55fa8b=_0x1d6a64['getImmediate']();return _0x55fa8b['library']+'/'+_0x55fa8b['version'];}else return null;})['filter'](_0x47b2ac=>_0x47b2ac)['join']('\x20');}}function Kc(_0x5dc221){const _0x3d38ec=_0x5dc221['getComponent']();return(_0x3d38ec==null?void 0x0:_0x3d38ec['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x44703d,_0xcdb8c2){try{_0x44703d['container']['addComponent'](_0xcdb8c2);}catch(_0x480ab7){oe['debug']('Component\x20'+_0xcdb8c2['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x44703d['name'],_0x480ab7);}}function Ze(_0x3dfac4){const _0xf2d65a=_0x3dfac4['name'];if(mi['has'](_0xf2d65a))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0xf2d65a+'.'),!0x1;mi['set'](_0xf2d65a,_0x3dfac4);for(const _0x522e41 of xe['values']())Fs(_0x522e41,_0x3dfac4);for(const _0x20e516 of gi['values']())Fs(_0x20e516,_0x3dfac4);return!0x0;}function Bi(_0x23003c,_0x2e1301){const _0x4f875f=_0x23003c['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x4f875f&&_0x4f875f['triggerHeartbeat'](),_0x23003c['container']['getProvider'](_0x2e1301);}function $(_0x3b7b91){return _0x3b7b91==null?!0x1:_0x3b7b91['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x490421,_0x1b3844,_0x5a40c7){this['_isDeleted']=!0x1,this['_options']={..._0x490421},this['_config']={..._0x1b3844},this['_name']=_0x1b3844['name'],this['_automaticDataCollectionEnabled']=_0x1b3844['automaticDataCollectionEnabled'],this['_container']=_0x5a40c7,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x488fb6){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x488fb6;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x4c2f3a){this['_isDeleted']=_0x4c2f3a;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x123391,_0x42f823={}){let _0x4e1590=_0x123391;typeof _0x42f823!='object'&&(_0x42f823={'name':_0x42f823});const _0x164ac6={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x42f823},_0x489aaa=_0x164ac6['name'];if(typeof _0x489aaa!='string'||!_0x489aaa)throw ge['create']('bad-app-name',{'appName':String(_0x489aaa)});if(_0x4e1590||(_0x4e1590=qr()),!_0x4e1590)throw ge['create']('no-options');const _0x28ae90=xe['get'](_0x489aaa);if(_0x28ae90){if(Me(_0x4e1590,_0x28ae90['options'])&&Me(_0x164ac6,_0x28ae90['config']))return _0x28ae90;throw ge['create']('duplicate-app',{'appName':_0x489aaa});}const _0x160671=new Pc(_0x489aaa);for(const _0x35d60c of mi['values']())_0x160671['addComponent'](_0x35d60c);const _0x15720b=new Tl(_0x4e1590,_0x164ac6,_0x160671);return xe['set'](_0x489aaa,_0x15720b),_0x15720b;}function Zr(_0x50e5ae=_i){const _0x35907a=xe['get'](_0x50e5ae);if(!_0x35907a&&_0x50e5ae===_i&&qr())return Sl();if(!_0x35907a)throw ge['create']('no-app',{'appName':_0x50e5ae});return _0x35907a;}function f_(){return Array['from'](xe['values']());}async function p_(_0x1595af){let _0x5810d5=!0x1;const _0x2970f6=_0x1595af['name'];xe['has'](_0x2970f6)?(_0x5810d5=!0x0,xe['delete'](_0x2970f6)):gi['has'](_0x2970f6)&&_0x1595af['decRefCount']()<=0x0&&(gi['delete'](_0x2970f6),_0x5810d5=!0x0),_0x5810d5&&(await Promise['all'](_0x1595af['container']['getProviders']()['map'](_0x62580a=>_0x62580a['delete']())),_0x1595af['isDeleted']=!0x0);}function me(_0x4ea4ce,_0x3346b1,_0x5f4d6e){let _0x439bc8=wl[_0x4ea4ce]??_0x4ea4ce;_0x5f4d6e&&(_0x439bc8+='-'+_0x5f4d6e);const _0x2afa01=_0x439bc8['match'](/\s|\//),_0x349a1a=_0x3346b1['match'](/\s|\//);if(_0x2afa01||_0x349a1a){const _0x41945e=['Unable\x20to\x20register\x20library\x20\x22'+_0x439bc8+'\x22\x20with\x20version\x20\x22'+_0x3346b1+'\x22:'];_0x2afa01&&_0x41945e['push']('library\x20name\x20\x22'+_0x439bc8+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x2afa01&&_0x349a1a&&_0x41945e['push']('and'),_0x349a1a&&_0x41945e['push']('version\x20name\x20\x22'+_0x3346b1+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x41945e['join']('\x20'));return;}Ze(new Le(_0x439bc8+'-version',()=>({'library':_0x439bc8,'version':_0x3346b1}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0xef93cf,_0x35e274)=>{switch(_0x35e274){case 0x0:try{_0xef93cf['createObjectStore'](kt);}catch(_0x91a408){console['warn'](_0x91a408);}}}})['catch'](_0x19cf82=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x19cf82['message']});})),ti;}async function Al(_0x15e1a4){try{const _0x388891=(await eo())['transaction'](kt),_0x41465c=await _0x388891['objectStore'](kt)['get'](to(_0x15e1a4));return await _0x388891['done'],_0x41465c;}catch(_0x4d2beb){if(_0x4d2beb instanceof Se)oe['warn'](_0x4d2beb['message']);else{const _0x1b0ecd=ge['create']('idb-get',{'originalErrorMessage':_0x4d2beb==null?void 0x0:_0x4d2beb['message']});oe['warn'](_0x1b0ecd['message']);}}}async function Us(_0x21076e,_0x34c476){try{const _0x340b8d=(await eo())['transaction'](kt,'readwrite');await _0x340b8d['objectStore'](kt)['put'](_0x34c476,to(_0x21076e)),await _0x340b8d['done'];}catch(_0x351a21){if(_0x351a21 instanceof Se)oe['warn'](_0x351a21['message']);else{const _0x869581=ge['create']('idb-set',{'originalErrorMessage':_0x351a21==null?void 0x0:_0x351a21['message']});oe['warn'](_0x869581['message']);}}}function to(_0x139570){return _0x139570['name']+'!'+_0x139570['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0xc9e836){this['container']=_0xc9e836,this['_heartbeatsCache']=null;const _0x4b8e99=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x4b8e99),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x3cf9fb=>(this['_heartbeatsCache']=_0x3cf9fb,_0x3cf9fb));}async['triggerHeartbeat'](){var _0x36e991,_0x250c24;try{const _0x116e01=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3224a4=Ws();if(((_0x36e991=this['_heartbeatsCache'])==null?void 0x0:_0x36e991['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x250c24=this['_heartbeatsCache'])==null?void 0x0:_0x250c24['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3224a4||this['_heartbeatsCache']['heartbeats']['some'](_0x365523=>_0x365523['date']===_0x3224a4))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3224a4,'agent':_0x116e01}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x1e2fad=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x1e2fad,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x331923){oe['warn'](_0x331923);}}async['getHeartbeatsHeader'](){var _0x251252;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x251252=this['_heartbeatsCache'])==null?void 0x0:_0x251252['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x18f3e2=Ws(),{heartbeatsToSend:_0x147f1d,unsentEntries:_0xadce37}=Ol(this['_heartbeatsCache']['heartbeats']),_0x54dfc4=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x147f1d}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x18f3e2,_0xadce37['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0xadce37,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x54dfc4;}catch(_0x5a3fdd){return oe['warn'](_0x5a3fdd),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x59c2a3,_0x69116b=kl){const _0x4af479=[];let _0x1bf358=_0x59c2a3['slice']();for(const _0x30c85f of _0x59c2a3){const _0x1d943f=_0x4af479['find'](_0x2ed056=>_0x2ed056['agent']===_0x30c85f['agent']);if(_0x1d943f){if(_0x1d943f['dates']['push'](_0x30c85f['date']),Bs(_0x4af479)>_0x69116b){_0x1d943f['dates']['pop']();break;}}else{if(_0x4af479['push']({'agent':_0x30c85f['agent'],'dates':[_0x30c85f['date']]}),Bs(_0x4af479)>_0x69116b){_0x4af479['pop']();break;}}_0x1bf358=_0x1bf358['slice'](0x1);}return{'heartbeatsToSend':_0x4af479,'unsentEntries':_0x1bf358};}class Dl{constructor(_0x489ae9){this['app']=_0x489ae9,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x56f1f5=await Al(this['app']);return _0x56f1f5!=null&&_0x56f1f5['heartbeats']?_0x56f1f5:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x137e02){if(await this['_canUseIndexedDBPromise']){const _0x46a56e=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x137e02['lastSentHeartbeatDate']??_0x46a56e['lastSentHeartbeatDate'],'heartbeats':_0x137e02['heartbeats']});}else return;}async['add'](_0x5d2220){if(await this['_canUseIndexedDBPromise']){const _0x3fa822=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x5d2220['lastSentHeartbeatDate']??_0x3fa822['lastSentHeartbeatDate'],'heartbeats':[..._0x3fa822['heartbeats'],..._0x5d2220['heartbeats']]});}else return;}}function Bs(_0x5e5d2d){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x5e5d2d}))['length'];}function Ml(_0x3d76b1){if(_0x3d76b1['length']===0x0)return-0x1;let _0x2c1a56=0x0,_0x416b80=_0x3d76b1[0x0]['date'];for(let _0xa2baaf=0x1;_0xa2baaf<_0x3d76b1['length'];_0xa2baaf++)_0x3d76b1[_0xa2baaf]['date']<_0x416b80&&(_0x416b80=_0x3d76b1[_0xa2baaf]['date'],_0x2c1a56=_0xa2baaf);return _0x2c1a56;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x2a152d){Ze(new Le('platform-logger',_0x24831c=>new jc(_0x24831c),'PRIVATE')),Ze(new Le('heartbeat',_0x3618e1=>new Pl(_0x3618e1),'PRIVATE')),me(pi,xs,_0x2a152d),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x25784f){no=_0x25784f;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x5c86d7){this['domStorage_']=_0x5c86d7,this['prefix_']='firebase:';}['set'](_0x4bb846,_0x53c902){_0x53c902==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x4bb846)):this['domStorage_']['setItem'](this['prefixedName_'](_0x4bb846),O(_0x53c902));}['get'](_0x271d98){const _0x9957cf=this['domStorage_']['getItem'](this['prefixedName_'](_0x271d98));return _0x9957cf==null?null:At(_0x9957cf);}['remove'](_0x5b4ca7){this['domStorage_']['removeItem'](this['prefixedName_'](_0x5b4ca7));}['prefixedName_'](_0x363855){return this['prefix_']+_0x363855;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x10bd76,_0x4935de){_0x4935de==null?delete this['cache_'][_0x10bd76]:this['cache_'][_0x10bd76]=_0x4935de;}['get'](_0x4f3ff2){return J(this['cache_'],_0x4f3ff2)?this['cache_'][_0x4f3ff2]:null;}['remove'](_0x556302){delete this['cache_'][_0x556302];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x581495){try{if(typeof window<'u'&&typeof window[_0x581495]<'u'){const _0x1c337f=window[_0x581495];return _0x1c337f['setItem']('firebase:sentinel','cache'),_0x1c337f['removeItem']('firebase:sentinel'),new Wl(_0x1c337f);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x490eea=0x1;return function(){return _0x490eea++;};}()),ro=function(_0x4f7047){const _0x3693de=Rc(_0x4f7047),_0x211f06=new Cc();_0x211f06['update'](_0x3693de);const _0x3a0a61=_0x211f06['digest']();return Li['encodeByteArray'](_0x3a0a61);},Vt=function(..._0x518f37){let _0x1b9fe9='';for(let _0x476b75=0x0;_0x476b75<_0x518f37['length'];_0x476b75++){const _0x3ea163=_0x518f37[_0x476b75];Array['isArray'](_0x3ea163)||_0x3ea163&&typeof _0x3ea163=='object'&&typeof _0x3ea163['length']=='number'?_0x1b9fe9+=Vt['apply'](null,_0x3ea163):typeof _0x3ea163=='object'?_0x1b9fe9+=O(_0x3ea163):_0x1b9fe9+=_0x3ea163,_0x1b9fe9+='\x20';}return _0x1b9fe9;};let wt=null,Gs=!0x0;const Hl=function(_0x11226b,_0x589456){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x342500){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x4a7fa9=Vt['apply'](null,_0x342500);wt(_0x4a7fa9);}},Ht=function(_0x2ef374){return function(..._0x2d66a6){L(_0x2ef374,..._0x2d66a6);};},yi=function(..._0x45b4bf){const _0xd602e7='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x45b4bf);Ye['error'](_0xd602e7);},ae=function(..._0x32b446){const _0x5c38cd='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x32b446);throw Ye['error'](_0x5c38cd),new Error(_0x5c38cd);},U=function(..._0x50ae31){const _0x429171='FIREBASE\x20WARNING:\x20'+Vt(..._0x50ae31);Ye['warn'](_0x429171);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x1f562c){return typeof _0x1f562c=='number'&&(_0x1f562c!==_0x1f562c||_0x1f562c===Number['POSITIVE_INFINITY']||_0x1f562c===Number['NEGATIVE_INFINITY']);},Gl=function(_0x46b740){if(document['readyState']==='complete')_0x46b740();else{let _0x2e4f3f=!0x1;const _0x238d14=function(){if(!document['body']){setTimeout(_0x238d14,Math['floor'](0xa));return;}_0x2e4f3f||(_0x2e4f3f=!0x0,_0x46b740());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x238d14,!0x1),window['addEventListener']('load',_0x238d14,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x238d14();}),window['attachEvent']('onload',_0x238d14));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x57ff95,_0x4bd863){if(_0x57ff95===_0x4bd863)return 0x0;if(_0x57ff95===Fe||_0x4bd863===Ie)return-0x1;if(_0x4bd863===Fe||_0x57ff95===Ie)return 0x1;{const _0x4a1f9f=qs(_0x57ff95),_0x17e120=qs(_0x4bd863);return _0x4a1f9f!==null?_0x17e120!==null?_0x4a1f9f-_0x17e120===0x0?_0x57ff95['length']-_0x4bd863['length']:_0x4a1f9f-_0x17e120:-0x1:_0x17e120!==null?0x1:_0x57ff95<_0x4bd863?-0x1:0x1;}},ql=function(_0x12596d,_0x463029){return _0x12596d===_0x463029?0x0:_0x12596d<_0x463029?-0x1:0x1;},_t=function(_0x5efa6b,_0x2ce0f5){if(_0x2ce0f5&&_0x5efa6b in _0x2ce0f5)return _0x2ce0f5[_0x5efa6b];throw new Error('Missing\x20required\x20key\x20('+_0x5efa6b+')\x20in\x20object:\x20'+O(_0x2ce0f5));},Hi=function(_0x3d15a3){if(typeof _0x3d15a3!='object'||_0x3d15a3===null)return O(_0x3d15a3);const _0x53e0aa=[];for(const _0x4371d6 in _0x3d15a3)_0x53e0aa['push'](_0x4371d6);_0x53e0aa['sort']();let _0x47e6ad='{';for(let _0x4c4bf2=0x0;_0x4c4bf2<_0x53e0aa['length'];_0x4c4bf2++)_0x4c4bf2!==0x0&&(_0x47e6ad+=','),_0x47e6ad+=O(_0x53e0aa[_0x4c4bf2]),_0x47e6ad+=':',_0x47e6ad+=Hi(_0x3d15a3[_0x53e0aa[_0x4c4bf2]]);return _0x47e6ad+='}',_0x47e6ad;},oo=function(_0x1453d5,_0x3fa4b3){const _0x4db0e8=_0x1453d5['length'];if(_0x4db0e8<=_0x3fa4b3)return[_0x1453d5];const _0x707fcc=[];for(let _0x2f829d=0x0;_0x2f829d<_0x4db0e8;_0x2f829d+=_0x3fa4b3)_0x2f829d+_0x3fa4b3>_0x4db0e8?_0x707fcc['push'](_0x1453d5['substring'](_0x2f829d,_0x4db0e8)):_0x707fcc['push'](_0x1453d5['substring'](_0x2f829d,_0x2f829d+_0x3fa4b3));return _0x707fcc;};function x(_0x1fbfe2,_0x5eae89){for(const _0x366f9a in _0x1fbfe2)_0x1fbfe2['hasOwnProperty'](_0x366f9a)&&_0x5eae89(_0x366f9a,_0x1fbfe2[_0x366f9a]);}const ao=function(_0x516b35){f(!Vi(_0x516b35),'Invalid\x20JSON\x20number');const _0x4ab82e=0xb,_0x47e5ee=0x34,_0x163807=(0x1<<_0x4ab82e-0x1)-0x1;let _0x1ce61c,_0x19e647,_0x476062,_0x4684f6,_0xa519be;_0x516b35===0x0?(_0x19e647=0x0,_0x476062=0x0,_0x1ce61c=0x1/_0x516b35===-0x1/0x0?0x1:0x0):(_0x1ce61c=_0x516b35<0x0,_0x516b35=Math['abs'](_0x516b35),_0x516b35>=Math['pow'](0x2,0x1-_0x163807)?(_0x4684f6=Math['min'](Math['floor'](Math['log'](_0x516b35)/Math['LN2']),_0x163807),_0x19e647=_0x4684f6+_0x163807,_0x476062=Math['round'](_0x516b35*Math['pow'](0x2,_0x47e5ee-_0x4684f6)-Math['pow'](0x2,_0x47e5ee))):(_0x19e647=0x0,_0x476062=Math['round'](_0x516b35/Math['pow'](0x2,0x1-_0x163807-_0x47e5ee))));const _0x3cdb68=[];for(_0xa519be=_0x47e5ee;_0xa519be;_0xa519be-=0x1)_0x3cdb68['push'](_0x476062%0x2?0x1:0x0),_0x476062=Math['floor'](_0x476062/0x2);for(_0xa519be=_0x4ab82e;_0xa519be;_0xa519be-=0x1)_0x3cdb68['push'](_0x19e647%0x2?0x1:0x0),_0x19e647=Math['floor'](_0x19e647/0x2);_0x3cdb68['push'](_0x1ce61c?0x1:0x0),_0x3cdb68['reverse']();const _0x3af163=_0x3cdb68['join']('');let _0x4e6223='';for(_0xa519be=0x0;_0xa519be<0x40;_0xa519be+=0x8){let _0x32b389=parseInt(_0x3af163['substr'](_0xa519be,0x8),0x2)['toString'](0x10);_0x32b389['length']===0x1&&(_0x32b389='0'+_0x32b389),_0x4e6223=_0x4e6223+_0x32b389;}return _0x4e6223['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x167263,_0x47fdaa){let _0x37d934='Unknown\x20Error';_0x167263==='too_big'?_0x37d934='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x167263==='permission_denied'?_0x37d934='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x167263==='unavailable'&&(_0x37d934='The\x20service\x20is\x20unavailable');const _0x574935=new Error(_0x167263+'\x20at\x20'+_0x47fdaa['_path']['toString']()+':\x20'+_0x37d934);return _0x574935['code']=_0x167263['toUpperCase'](),_0x574935;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x523cb1){if(Yl['test'](_0x523cb1)){const _0x2f38ff=Number(_0x523cb1);if(_0x2f38ff>=Ql&&_0x2f38ff<=Jl)return _0x2f38ff;}return null;},ht=function(_0x5a748e){try{_0x5a748e();}catch(_0x422dfd){setTimeout(()=>{const _0x306ed4=_0x422dfd['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x306ed4),_0x422dfd;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x45c658,_0x3c6a66){const _0x548dbe=setTimeout(_0x45c658,_0x3c6a66);return typeof _0x548dbe=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x548dbe):typeof _0x548dbe=='object'&&_0x548dbe['unref']&&_0x548dbe['unref'](),_0x548dbe;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x1eb5bc,_0xbf5ac1){this['appCheckProvider']=_0xbf5ac1,this['appName']=_0x1eb5bc['name'],$(_0x1eb5bc)&&_0x1eb5bc['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x1eb5bc['settings']['appCheckToken']),this['appCheck']=_0xbf5ac1==null?void 0x0:_0xbf5ac1['getImmediate']({'optional':!0x0}),this['appCheck']||_0xbf5ac1==null||_0xbf5ac1['get']()['then'](_0x3116d3=>this['appCheck']=_0x3116d3);}['getToken'](_0x22cd44){if(this['serverAppAppCheckToken']){if(_0x22cd44)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x22cd44):new Promise((_0x7f9925,_0x56c6b1)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x22cd44)['then'](_0x7f9925,_0x56c6b1):_0x7f9925(null);},0x0);});}['addTokenChangeListener'](_0xf831c){var _0x2a836b;(_0x2a836b=this['appCheckProvider'])==null||_0x2a836b['get']()['then'](_0x52be9d=>_0x52be9d['addTokenListener'](_0xf831c));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x114a77,_0x3facb7,_0xf8d1bb){this['appName_']=_0x114a77,this['firebaseOptions_']=_0x3facb7,this['authProvider_']=_0xf8d1bb,this['auth_']=null,this['auth_']=_0xf8d1bb['getImmediate']({'optional':!0x0}),this['auth_']||_0xf8d1bb['onInit'](_0xeaf3d1=>this['auth_']=_0xeaf3d1);}['getToken'](_0x476a24){return this['auth_']?this['auth_']['getToken'](_0x476a24)['catch'](_0x375a16=>_0x375a16&&_0x375a16['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x375a16)):new Promise((_0x5b385a,_0x3b352a)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x476a24)['then'](_0x5b385a,_0x3b352a):_0x5b385a(null);},0x0);});}['addTokenChangeListener'](_0x2f2d73){this['auth_']?this['auth_']['addAuthTokenListener'](_0x2f2d73):this['authProvider_']['get']()['then'](_0x479098=>_0x479098['addAuthTokenListener'](_0x2f2d73));}['removeTokenChangeListener'](_0x457816){this['authProvider_']['get']()['then'](_0x5e6c66=>_0x5e6c66['removeAuthTokenListener'](_0x457816));}['notifyForInvalidToken'](){let _0x5d13d4='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x5d13d4+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x5d13d4+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x5d13d4+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x5d13d4);}}class nn{constructor(_0x2ea554){this['accessToken']=_0x2ea554;}['getToken'](_0x50893e){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x2edbd2){_0x2edbd2(this['accessToken']);}['removeTokenChangeListener'](_0x145583){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x3e34c4,_0x2c1ab0,_0x183e3f,_0x5d1a31,_0x265ea7=!0x1,_0x5c61be='',_0x55b01b=!0x1,_0x3abc60=!0x1,_0x17c632=null){this['secure']=_0x2c1ab0,this['namespace']=_0x183e3f,this['webSocketOnly']=_0x5d1a31,this['nodeAdmin']=_0x265ea7,this['persistenceKey']=_0x5c61be,this['includeNamespaceInQueryParams']=_0x55b01b,this['isUsingEmulator']=_0x3abc60,this['emulatorOptions']=_0x17c632,this['_host']=_0x3e34c4['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x3e34c4)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x47db7a){_0x47db7a!==this['internalHost']&&(this['internalHost']=_0x47db7a,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x33bf1f=this['toURLString']();return this['persistenceKey']&&(_0x33bf1f+='<'+this['persistenceKey']+'>'),_0x33bf1f;}['toURLString'](){const _0x3f30b0=this['secure']?'https://':'http://',_0x4ffef7=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x3f30b0+this['host']+'/'+_0x4ffef7;}}function th(_0x32fe73){return _0x32fe73['host']!==_0x32fe73['internalHost']||_0x32fe73['isCustomHost']()||_0x32fe73['includeNamespaceInQueryParams'];}function vo(_0x5bff7e,_0x2fd7d4,_0x5d8fdd){f(typeof _0x2fd7d4=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x5d8fdd=='object','typeof\x20params\x20must\x20==\x20object');let _0x3d02cf;if(_0x2fd7d4===go)_0x3d02cf=(_0x5bff7e['secure']?'wss://':'ws://')+_0x5bff7e['internalHost']+'/.ws?';else{if(_0x2fd7d4===mo)_0x3d02cf=(_0x5bff7e['secure']?'https://':'http://')+_0x5bff7e['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x2fd7d4);}th(_0x5bff7e)&&(_0x5d8fdd['ns']=_0x5bff7e['namespace']);const _0x44f171=[];return x(_0x5d8fdd,(_0x2c140a,_0x1b7fe1)=>{_0x44f171['push'](_0x2c140a+'='+_0x1b7fe1);}),_0x3d02cf+_0x44f171['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x1c83ab,_0x2c552d=0x1){J(this['counters_'],_0x1c83ab)||(this['counters_'][_0x1c83ab]=0x0),this['counters_'][_0x1c83ab]+=_0x2c552d;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x1e0ce3){const _0x3e64d6=_0x1e0ce3['toString']();return ni[_0x3e64d6]||(ni[_0x3e64d6]=new nh()),ni[_0x3e64d6];}function ih(_0x420dbc,_0x30fc9f){const _0x3887bb=_0x420dbc['toString']();return ii[_0x3887bb]||(ii[_0x3887bb]=_0x30fc9f()),ii[_0x3887bb];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x5ad28a){this['onMessage_']=_0x5ad28a,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x2e6782,_0x45cd3f){this['closeAfterResponse']=_0x2e6782,this['onClose']=_0x45cd3f,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x505068,_0x327cbe){for(this['pendingResponses'][_0x505068]=_0x327cbe;this['pendingResponses'][this['currentResponseNum']];){const _0xaba578=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x49c030=0x0;_0x49c030<_0xaba578['length'];++_0x49c030)_0xaba578[_0x49c030]&&ht(()=>{this['onMessage_'](_0xaba578[_0x49c030]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0xe3dfa0,_0x575eb2,_0xc65210,_0x392b55,_0x5e0bff,_0x161696,_0x4c26ed){this['connId']=_0xe3dfa0,this['repoInfo']=_0x575eb2,this['applicationId']=_0xc65210,this['appCheckToken']=_0x392b55,this['authToken']=_0x5e0bff,this['transportSessionId']=_0x161696,this['lastSessionId']=_0x4c26ed,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0xe3dfa0),this['stats_']=Gi(_0x575eb2),this['urlFn']=_0x44004d=>(this['appCheckToken']&&(_0x44004d[vi]=this['appCheckToken']),vo(_0x575eb2,mo,_0x44004d));}['open'](_0x2c1892,_0x20f2e7){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x20f2e7,this['myPacketOrderer']=new sh(_0x2c1892),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x1c6e4f)=>{const [_0x5009c4,_0x587426,_0x4647a2,_0x250976,_0x292fe4]=_0x1c6e4f;if(this['incrementIncomingBytes_'](_0x1c6e4f),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x5009c4===zs)this['id']=_0x587426,this['password']=_0x4647a2;else{if(_0x5009c4===rh)_0x587426?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x587426,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x5009c4);}}},(..._0x5ab889)=>{const [_0x106f0b,_0x405c27]=_0x5ab889;this['incrementIncomingBytes_'](_0x5ab889),this['myPacketOrderer']['handleResponse'](_0x106f0b,_0x405c27);},()=>{this['onClosed_']();},this['urlFn']);const _0x1eb05c={};_0x1eb05c[zs]='t',_0x1eb05c[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x1eb05c[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x1eb05c[co]=$i,this['transportSessionId']&&(_0x1eb05c[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x1eb05c[po]=this['lastSessionId']),this['applicationId']&&(_0x1eb05c[_o]=this['applicationId']),this['appCheckToken']&&(_0x1eb05c[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x1eb05c[ho]=uo);const _0x1a1091=this['urlFn'](_0x1eb05c);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x1a1091),this['scriptTagHolder']['addTag'](_0x1a1091,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x2bd556){const _0xabdfc1=O(_0x2bd556);this['bytesSent']+=_0xabdfc1['length'],this['stats_']['incrementCounter']('bytes_sent',_0xabdfc1['length']);const _0x4f4ead=Hr(_0xabdfc1),_0x4dc9b5=oo(_0x4f4ead,fh);for(let _0xd8e74f=0x0;_0xd8e74f<_0x4dc9b5['length'];_0xd8e74f++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x4dc9b5['length'],_0x4dc9b5[_0xd8e74f]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x303c05,_0x3742d6){this['myDisconnFrame']=document['createElement']('iframe');const _0x499d76={};_0x499d76[dh]='t',_0x499d76[Eo]=_0x303c05,_0x499d76[Io]=_0x3742d6,this['myDisconnFrame']['src']=this['urlFn'](_0x499d76),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x5daa47){const _0x4200e2=O(_0x5daa47)['length'];this['bytesReceived']+=_0x4200e2,this['stats_']['incrementCounter']('bytes_received',_0x4200e2);}}class qi{constructor(_0x3e675a,_0x4a93e1,_0x3e0150,_0x70a5e){this['onDisconnect']=_0x3e0150,this['urlFn']=_0x70a5e,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x3e675a,window[ah+this['uniqueCallbackIdentifier']]=_0x4a93e1,this['myIFrame']=qi['createIFrame_']();let _0x4eecf6='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x4eecf6='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x1d26d5='<html><body>'+_0x4eecf6+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x1d26d5),this['myIFrame']['doc']['close']();}catch(_0x4ac82c){L('frame\x20writing\x20exception'),_0x4ac82c['stack']&&L(_0x4ac82c['stack']),L(_0x4ac82c);}}}static['createIFrame_'](){const _0x5b3748=document['createElement']('iframe');if(_0x5b3748['style']['display']='none',document['body']){document['body']['appendChild'](_0x5b3748);try{_0x5b3748['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x3b6138=document['domain'];_0x5b3748['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x3b6138+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x5b3748['contentDocument']?_0x5b3748['doc']=_0x5b3748['contentDocument']:_0x5b3748['contentWindow']?_0x5b3748['doc']=_0x5b3748['contentWindow']['document']:_0x5b3748['document']&&(_0x5b3748['doc']=_0x5b3748['document']),_0x5b3748;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x169672=this['onDisconnect'];_0x169672&&(this['onDisconnect']=null,_0x169672());}['startLongPoll'](_0x1eab60,_0x1d7f7d){for(this['myID']=_0x1eab60,this['myPW']=_0x1d7f7d,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x401fd3={};_0x401fd3[Eo]=this['myID'],_0x401fd3[Io]=this['myPW'],_0x401fd3[wo]=this['currentSerial'];let _0x54b3a6=this['urlFn'](_0x401fd3),_0x1965e3='',_0x36c713=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x1965e3['length']<=Co;){const _0xba771c=this['pendingSegs']['shift']();_0x1965e3=_0x1965e3+'&'+lh+_0x36c713+'='+_0xba771c['seg']+'&'+hh+_0x36c713+'='+_0xba771c['ts']+'&'+uh+_0x36c713+'='+_0xba771c['d'],_0x36c713++;}return _0x54b3a6=_0x54b3a6+_0x1965e3,this['addLongPollTag_'](_0x54b3a6,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x54f3a1,_0x9a12c5,_0x44f5a6){this['pendingSegs']['push']({'seg':_0x54f3a1,'ts':_0x9a12c5,'d':_0x44f5a6}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x47b6c9,_0x3341c8){this['outstandingRequests']['add'](_0x3341c8);const _0x4ba9e1=()=>{this['outstandingRequests']['delete'](_0x3341c8),this['newRequest_']();},_0x12e38d=setTimeout(_0x4ba9e1,Math['floor'](ph)),_0x3c112e=()=>{clearTimeout(_0x12e38d),_0x4ba9e1();};this['addTag'](_0x47b6c9,_0x3c112e);}['addTag'](_0x45451a,_0x55f984){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x21de8e=this['myIFrame']['doc']['createElement']('script');_0x21de8e['type']='text/javascript',_0x21de8e['async']=!0x0,_0x21de8e['src']=_0x45451a,_0x21de8e['onload']=_0x21de8e['onreadystatechange']=function(){const _0x2e42d1=_0x21de8e['readyState'];(!_0x2e42d1||_0x2e42d1==='loaded'||_0x2e42d1==='complete')&&(_0x21de8e['onload']=_0x21de8e['onreadystatechange']=null,_0x21de8e['parentNode']&&_0x21de8e['parentNode']['removeChild'](_0x21de8e),_0x55f984());},_0x21de8e['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x45451a),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x21de8e);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x3f0015,_0x4a840a,_0x5280d4,_0x24f128,_0x531b78,_0x4b25c7,_0x4bbffe){this['connId']=_0x3f0015,this['applicationId']=_0x5280d4,this['appCheckToken']=_0x24f128,this['authToken']=_0x531b78,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x4a840a),this['connURL']=z['connectionURL_'](_0x4a840a,_0x4b25c7,_0x4bbffe,_0x24f128,_0x5280d4),this['nodeAdmin']=_0x4a840a['nodeAdmin'];}static['connectionURL_'](_0x1d7561,_0x26ead2,_0x4dbe1d,_0x499134,_0x3817ef){const _0x56459a={};return _0x56459a[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x56459a[ho]=uo),_0x26ead2&&(_0x56459a[lo]=_0x26ead2),_0x4dbe1d&&(_0x56459a[po]=_0x4dbe1d),_0x499134&&(_0x56459a[vi]=_0x499134),_0x3817ef&&(_0x56459a[_o]=_0x3817ef),vo(_0x1d7561,go,_0x56459a);}['open'](_0x1674eb,_0x4c845a){this['onDisconnect']=_0x4c845a,this['onMessage']=_0x1674eb,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0xce068c;_c(),this['mySock']=new un(this['connURL'],[],_0xce068c);}catch(_0x328ae7){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x1cd9ba=_0x328ae7['message']||_0x328ae7['data'];_0x1cd9ba&&this['log_'](_0x1cd9ba),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x45c506=>{this['handleIncomingFrame'](_0x45c506);},this['mySock']['onerror']=_0x5e3968=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x31b6da=_0x5e3968['message']||_0x5e3968['data'];_0x31b6da&&this['log_'](_0x31b6da),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x20a1dd=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x584e7c=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x46b568=navigator['userAgent']['match'](_0x584e7c);_0x46b568&&_0x46b568['length']>0x1&&parseFloat(_0x46b568[0x1])<4.4&&(_0x20a1dd=!0x0);}return!_0x20a1dd&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x40cd5e){if(this['frames']['push'](_0x40cd5e),this['frames']['length']===this['totalFrames']){const _0x7ef327=this['frames']['join']('');this['frames']=null;const _0x11dc1a=At(_0x7ef327);this['onMessage'](_0x11dc1a);}}['handleNewFrameCount_'](_0x4f0957){this['totalFrames']=_0x4f0957,this['frames']=[];}['extractFrameCount_'](_0x126a39){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x126a39['length']<=0x6){const _0x471cba=Number(_0x126a39);if(!isNaN(_0x471cba))return this['handleNewFrameCount_'](_0x471cba),null;}return this['handleNewFrameCount_'](0x1),_0x126a39;}['handleIncomingFrame'](_0x57e48d){if(this['mySock']===null)return;const _0x1ac61f=_0x57e48d['data'];if(this['bytesReceived']+=_0x1ac61f['length'],this['stats_']['incrementCounter']('bytes_received',_0x1ac61f['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x1ac61f);else{const _0x4aeb5f=this['extractFrameCount_'](_0x1ac61f);_0x4aeb5f!==null&&this['appendFrame_'](_0x4aeb5f);}}['send'](_0x53b02e){this['resetKeepAlive']();const _0x4a25e=O(_0x53b02e);this['bytesSent']+=_0x4a25e['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4a25e['length']);const _0x5944d9=oo(_0x4a25e,gh);_0x5944d9['length']>0x1&&this['sendString_'](String(_0x5944d9['length']));for(let _0x133f66=0x0;_0x133f66<_0x5944d9['length'];_0x133f66++)this['sendString_'](_0x5944d9[_0x133f66]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x2edb19){try{this['mySock']['send'](_0x2edb19);}catch(_0x3f126f){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x3f126f['message']||_0x3f126f['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x328bd6){this['initTransports_'](_0x328bd6);}['initTransports_'](_0x22e0a4){const _0x535e94=z&&z['isAvailable']();let _0x14b6a7=_0x535e94&&!z['previouslyFailed']();if(_0x22e0a4['webSocketOnly']&&(_0x535e94||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x14b6a7=!0x0),_0x14b6a7)this['transports_']=[z];else{const _0x269a9c=this['transports_']=[];for(const _0xfcb91 of Nt['ALL_TRANSPORTS'])_0xfcb91&&_0xfcb91['isAvailable']()&&_0x269a9c['push'](_0xfcb91);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x5d986f,_0x627d33,_0x194bb2,_0x230186,_0x1a21a8,_0x530a8d,_0x10653c,_0x358981,_0x4f10a5,_0x556cb4){this['id']=_0x5d986f,this['repoInfo_']=_0x627d33,this['applicationId_']=_0x194bb2,this['appCheckToken_']=_0x230186,this['authToken_']=_0x1a21a8,this['onMessage_']=_0x530a8d,this['onReady_']=_0x10653c,this['onDisconnect_']=_0x358981,this['onKill_']=_0x4f10a5,this['lastSessionId']=_0x556cb4,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x627d33),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x587cea=this['transportManager_']['initialTransport']();this['conn_']=new _0x587cea(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x587cea['responsesRequiredToBeHealthy']||0x0;const _0x1e024a=this['connReceiver_'](this['conn_']),_0x58e7f5=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x1e024a,_0x58e7f5);},Math['floor'](0x0));const _0x18d3b4=_0x587cea['healthyTimeout']||0x0;_0x18d3b4>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x18d3b4)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x51ecef){return _0x53a37d=>{_0x51ecef===this['conn_']?this['onConnectionLost_'](_0x53a37d):_0x51ecef===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x2904e1){return _0x15e195=>{this['state_']!==0x2&&(_0x2904e1===this['rx_']?this['onPrimaryMessageReceived_'](_0x15e195):_0x2904e1===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x15e195):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0xc59a84){const _0xb4ca62={'t':'d','d':_0xc59a84};this['sendData_'](_0xb4ca62);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x57231a){if(si in _0x57231a){const _0x1f4dad=_0x57231a[si];_0x1f4dad===Qs?this['upgradeIfSecondaryHealthy_']():_0x1f4dad===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x1f4dad===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x2210e2){const _0x145606=_t('t',_0x2210e2),_0x223879=_t('d',_0x2210e2);if(_0x145606==='c')this['onSecondaryControl_'](_0x223879);else{if(_0x145606==='d')this['pendingDataMessages']['push'](_0x223879);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x145606);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0xf4c6b0){const _0x46056d=_t('t',_0xf4c6b0),_0x2e3320=_t('d',_0xf4c6b0);_0x46056d==='c'?this['onControl_'](_0x2e3320):_0x46056d==='d'&&this['onDataMessage_'](_0x2e3320);}['onDataMessage_'](_0x188dbb){this['onPrimaryResponse_'](),this['onMessage_'](_0x188dbb);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x20e5fe){const _0x28b731=_t(si,_0x20e5fe);if(js in _0x20e5fe){const _0x2df6f0=_0x20e5fe[js];if(_0x28b731===Th){const _0x1881da={..._0x2df6f0};this['repoInfo_']['isUsingEmulator']&&(_0x1881da['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x1881da);}else{if(_0x28b731===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x7a0bbf=0x0;_0x7a0bbf<this['pendingDataMessages']['length'];++_0x7a0bbf)this['onDataMessage_'](this['pendingDataMessages'][_0x7a0bbf]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x28b731===wh?this['onConnectionShutdown_'](_0x2df6f0):_0x28b731===Ks?this['onReset_'](_0x2df6f0):_0x28b731===Ch?yi('Server\x20Error:\x20'+_0x2df6f0):_0x28b731===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x28b731);}}}['onHandshake_'](_0x1c62f9){const _0x1e43c5=_0x1c62f9['ts'],_0x25a0c7=_0x1c62f9['v'],_0x4fe47c=_0x1c62f9['h'];this['sessionId']=_0x1c62f9['s'],this['repoInfo_']['host']=_0x4fe47c,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x1e43c5),$i!==_0x25a0c7&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x31c5ec=this['transportManager_']['upgradeTransport']();_0x31c5ec&&this['startUpgrade_'](_0x31c5ec);}['startUpgrade_'](_0x5aef28){this['secondaryConn_']=new _0x5aef28(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x5aef28['responsesRequiredToBeHealthy']||0x0;const _0x36f868=this['connReceiver_'](this['secondaryConn_']),_0x100b55=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x36f868,_0x100b55),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x535456){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x535456),this['repoInfo_']['host']=_0x535456,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x3705fe,_0x6cad28){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x3705fe,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x6cad28,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0xd66481=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0xd66481||this['rx_']===_0xd66481)&&this['close']();}['onConnectionLost_'](_0x465e3c){this['conn_']=null,!_0x465e3c&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x340814){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x340814),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x20870d){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x20870d);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x333c41,_0x1c1c5e,_0x42c2dd,_0x4daf23){}['merge'](_0x32265e,_0x466cac,_0x10e420,_0x28c708){}['refreshAuthToken'](_0x1e37e7){}['refreshAppCheckToken'](_0x5d93af){}['onDisconnectPut'](_0x3f7aec,_0x43d3fb,_0x2939f1){}['onDisconnectMerge'](_0x4ecfac,_0x88363d,_0x367143){}['onDisconnectCancel'](_0x1e8fbd,_0x19cc75){}['reportStats'](_0x4d92ce){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x50f22d){this['allowedEvents_']=_0x50f22d,this['listeners_']={},f(Array['isArray'](_0x50f22d)&&_0x50f22d['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x55ff65,..._0x37d5f4){if(Array['isArray'](this['listeners_'][_0x55ff65])){const _0x49c8b1=[...this['listeners_'][_0x55ff65]];for(let _0x19b359=0x0;_0x19b359<_0x49c8b1['length'];_0x19b359++)_0x49c8b1[_0x19b359]['callback']['apply'](_0x49c8b1[_0x19b359]['context'],_0x37d5f4);}}['on'](_0x53985c,_0xdcf298,_0x436d75){this['validateEventType_'](_0x53985c),this['listeners_'][_0x53985c]=this['listeners_'][_0x53985c]||[],this['listeners_'][_0x53985c]['push']({'callback':_0xdcf298,'context':_0x436d75});const _0x58d4de=this['getInitialEvent'](_0x53985c);_0x58d4de&&_0xdcf298['apply'](_0x436d75,_0x58d4de);}['off'](_0x362de9,_0xb30db1,_0x5225d1){this['validateEventType_'](_0x362de9);const _0x189235=this['listeners_'][_0x362de9]||[];for(let _0x4123bc=0x0;_0x4123bc<_0x189235['length'];_0x4123bc++)if(_0x189235[_0x4123bc]['callback']===_0xb30db1&&(!_0x5225d1||_0x5225d1===_0x189235[_0x4123bc]['context'])){_0x189235['splice'](_0x4123bc,0x1);return;}}['validateEventType_'](_0x559980){f(this['allowedEvents_']['find'](_0x46fcab=>_0x46fcab===_0x559980),'Unknown\x20event:\x20'+_0x559980);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x1a8c08){return f(_0x1a8c08==='online','Unknown\x20event\x20type:\x20'+_0x1a8c08),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x2f1f36,_0x5290da){if(_0x5290da===void 0x0){this['pieces_']=_0x2f1f36['split']('/');let _0x414f40=0x0;for(let _0x55ce5f=0x0;_0x55ce5f<this['pieces_']['length'];_0x55ce5f++)this['pieces_'][_0x55ce5f]['length']>0x0&&(this['pieces_'][_0x414f40]=this['pieces_'][_0x55ce5f],_0x414f40++);this['pieces_']['length']=_0x414f40,this['pieceNum_']=0x0;}else this['pieces_']=_0x2f1f36,this['pieceNum_']=_0x5290da;}['toString'](){let _0x12467b='';for(let _0x53613f=this['pieceNum_'];_0x53613f<this['pieces_']['length'];_0x53613f++)this['pieces_'][_0x53613f]!==''&&(_0x12467b+='/'+this['pieces_'][_0x53613f]);return _0x12467b||'/';}}function w(){return new C('');}function y(_0x4421ec){return _0x4421ec['pieceNum_']>=_0x4421ec['pieces_']['length']?null:_0x4421ec['pieces_'][_0x4421ec['pieceNum_']];}function we(_0x31ba58){return _0x31ba58['pieces_']['length']-_0x31ba58['pieceNum_'];}function b(_0x3a23fd){let _0x313dee=_0x3a23fd['pieceNum_'];return _0x313dee<_0x3a23fd['pieces_']['length']&&_0x313dee++,new C(_0x3a23fd['pieces_'],_0x313dee);}function zi(_0x329f57){return _0x329f57['pieceNum_']<_0x329f57['pieces_']['length']?_0x329f57['pieces_'][_0x329f57['pieces_']['length']-0x1]:null;}function bh(_0x2fc0e9){let _0x133e20='';for(let _0xf42785=_0x2fc0e9['pieceNum_'];_0xf42785<_0x2fc0e9['pieces_']['length'];_0xf42785++)_0x2fc0e9['pieces_'][_0xf42785]!==''&&(_0x133e20+='/'+encodeURIComponent(String(_0x2fc0e9['pieces_'][_0xf42785])));return _0x133e20||'/';}function Pt(_0x439aa9,_0x3340f6=0x0){return _0x439aa9['pieces_']['slice'](_0x439aa9['pieceNum_']+_0x3340f6);}function Ro(_0xead96e){if(_0xead96e['pieceNum_']>=_0xead96e['pieces_']['length'])return null;const _0xecd65c=[];for(let _0xc836aa=_0xead96e['pieceNum_'];_0xc836aa<_0xead96e['pieces_']['length']-0x1;_0xc836aa++)_0xecd65c['push'](_0xead96e['pieces_'][_0xc836aa]);return new C(_0xecd65c,0x0);}function k(_0x47e65b,_0x4a56e8){const _0x67ee3e=[];for(let _0xd42a7=_0x47e65b['pieceNum_'];_0xd42a7<_0x47e65b['pieces_']['length'];_0xd42a7++)_0x67ee3e['push'](_0x47e65b['pieces_'][_0xd42a7]);if(_0x4a56e8 instanceof C){for(let _0x576c39=_0x4a56e8['pieceNum_'];_0x576c39<_0x4a56e8['pieces_']['length'];_0x576c39++)_0x67ee3e['push'](_0x4a56e8['pieces_'][_0x576c39]);}else{const _0x4e4f19=_0x4a56e8['split']('/');for(let _0x5764dc=0x0;_0x5764dc<_0x4e4f19['length'];_0x5764dc++)_0x4e4f19[_0x5764dc]['length']>0x0&&_0x67ee3e['push'](_0x4e4f19[_0x5764dc]);}return new C(_0x67ee3e,0x0);}function v(_0x397b0a){return _0x397b0a['pieceNum_']>=_0x397b0a['pieces_']['length'];}function F(_0x1371de,_0x2ff593){const _0x444608=y(_0x1371de),_0x23cdc9=y(_0x2ff593);if(_0x444608===null)return _0x2ff593;if(_0x444608===_0x23cdc9)return F(b(_0x1371de),b(_0x2ff593));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x2ff593+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1371de+')');}function Rh(_0x3e4f0d,_0x3c7e85){const _0x54b896=Pt(_0x3e4f0d,0x0),_0x17fbd4=Pt(_0x3c7e85,0x0);for(let _0x51624f=0x0;_0x51624f<_0x54b896['length']&&_0x51624f<_0x17fbd4['length'];_0x51624f++){const _0x29f1e0=He(_0x54b896[_0x51624f],_0x17fbd4[_0x51624f]);if(_0x29f1e0!==0x0)return _0x29f1e0;}return _0x54b896['length']===_0x17fbd4['length']?0x0:_0x54b896['length']<_0x17fbd4['length']?-0x1:0x1;}function ji(_0x5b324e,_0x2b5890){if(we(_0x5b324e)!==we(_0x2b5890))return!0x1;for(let _0x54334f=_0x5b324e['pieceNum_'],_0x586a76=_0x2b5890['pieceNum_'];_0x54334f<=_0x5b324e['pieces_']['length'];_0x54334f++,_0x586a76++)if(_0x5b324e['pieces_'][_0x54334f]!==_0x2b5890['pieces_'][_0x586a76])return!0x1;return!0x0;}function G(_0x77d4b3,_0x3ab3ea){let _0x16a77d=_0x77d4b3['pieceNum_'],_0x7bb133=_0x3ab3ea['pieceNum_'];if(we(_0x77d4b3)>we(_0x3ab3ea))return!0x1;for(;_0x16a77d<_0x77d4b3['pieces_']['length'];){if(_0x77d4b3['pieces_'][_0x16a77d]!==_0x3ab3ea['pieces_'][_0x7bb133])return!0x1;++_0x16a77d,++_0x7bb133;}return!0x0;}class Ah{constructor(_0x442c84,_0x385680){this['errorPrefix_']=_0x385680,this['parts_']=Pt(_0x442c84,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x2cf4e8=0x0;_0x2cf4e8<this['parts_']['length'];_0x2cf4e8++)this['byteLength_']+=On(this['parts_'][_0x2cf4e8]);Ao(this);}}function kh(_0x5a43b1,_0x1b7550){_0x5a43b1['parts_']['length']>0x0&&(_0x5a43b1['byteLength_']+=0x1),_0x5a43b1['parts_']['push'](_0x1b7550),_0x5a43b1['byteLength_']+=On(_0x1b7550),Ao(_0x5a43b1);}function Nh(_0x46fdb7){const _0x26340e=_0x46fdb7['parts_']['pop']();_0x46fdb7['byteLength_']-=On(_0x26340e),_0x46fdb7['parts_']['length']>0x0&&(_0x46fdb7['byteLength_']-=0x1);}function Ao(_0x3f35b0){if(_0x3f35b0['byteLength_']>er)throw new Error(_0x3f35b0['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x3f35b0['byteLength_']+').');if(_0x3f35b0['parts_']['length']>Zs)throw new Error(_0x3f35b0['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x3f35b0));}function Pe(_0x4b7820){return _0x4b7820['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x4b7820['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x59d990,_0x5df31d;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x5df31d='visibilitychange',_0x59d990='hidden'):typeof document['mozHidden']<'u'?(_0x5df31d='mozvisibilitychange',_0x59d990='mozHidden'):typeof document['msHidden']<'u'?(_0x5df31d='msvisibilitychange',_0x59d990='msHidden'):typeof document['webkitHidden']<'u'&&(_0x5df31d='webkitvisibilitychange',_0x59d990='webkitHidden')),this['visible_']=!0x0,_0x5df31d&&document['addEventListener'](_0x5df31d,()=>{const _0x190525=!document[_0x59d990];_0x190525!==this['visible_']&&(this['visible_']=_0x190525,this['trigger']('visible',_0x190525));},!0x1);}['getInitialEvent'](_0x20280d){return f(_0x20280d==='visible','Unknown\x20event\x20type:\x20'+_0x20280d),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x5c3e7e,_0x23da25,_0x2bbeca,_0x2f76c0,_0x2046fb,_0x4251fd,_0x5bef25,_0x34cfb3){if(super(),this['repoInfo_']=_0x5c3e7e,this['applicationId_']=_0x23da25,this['onDataUpdate_']=_0x2bbeca,this['onConnectStatus_']=_0x2f76c0,this['onServerInfoUpdate_']=_0x2046fb,this['authTokenProvider_']=_0x4251fd,this['appCheckTokenProvider_']=_0x5bef25,this['authOverride_']=_0x34cfb3,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x34cfb3)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x5c3e7e['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x3c5314,_0x1e2d88,_0x16f4a4){const _0x515d60=++this['requestNumber_'],_0x2ce4c5={'r':_0x515d60,'a':_0x3c5314,'b':_0x1e2d88};this['log_'](O(_0x2ce4c5)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x2ce4c5),_0x16f4a4&&(this['requestCBHash_'][_0x515d60]=_0x16f4a4);}['get'](_0x5b1c60){this['initConnection_']();const _0x23261b=new ot(),_0x490a1f={'action':'g','request':{'p':_0x5b1c60['_path']['toString'](),'q':_0x5b1c60['_queryObject']},'onComplete':_0x1d8c5b=>{const _0x555862=_0x1d8c5b['d'];_0x1d8c5b['s']==='ok'?_0x23261b['resolve'](_0x555862):_0x23261b['reject'](_0x555862);}};this['outstandingGets_']['push'](_0x490a1f),this['outstandingGetCount_']++;const _0x29b506=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x29b506),_0x23261b['promise'];}['listen'](_0xf4f4f1,_0x24ee2e,_0x30a13e,_0x5d3a42){this['initConnection_']();const _0x3d0c7b=_0xf4f4f1['_queryIdentifier'],_0x2b8ba5=_0xf4f4f1['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2b8ba5+'\x20'+_0x3d0c7b),this['listens']['has'](_0x2b8ba5)||this['listens']['set'](_0x2b8ba5,new Map()),f(_0xf4f4f1['_queryParams']['isDefault']()||!_0xf4f4f1['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x2b8ba5)['has'](_0x3d0c7b),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x4d8cb4={'onComplete':_0x5d3a42,'hashFn':_0x24ee2e,'query':_0xf4f4f1,'tag':_0x30a13e};this['listens']['get'](_0x2b8ba5)['set'](_0x3d0c7b,_0x4d8cb4),this['connected_']&&this['sendListen_'](_0x4d8cb4);}['sendGet_'](_0x20c8d3){const _0x86d2b9=this['outstandingGets_'][_0x20c8d3];this['sendRequest']('g',_0x86d2b9['request'],_0x2a1b3c=>{delete this['outstandingGets_'][_0x20c8d3],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x86d2b9['onComplete']&&_0x86d2b9['onComplete'](_0x2a1b3c);});}['sendListen_'](_0x2a6659){const _0x29a594=_0x2a6659['query'],_0x24650e=_0x29a594['_path']['toString'](),_0xbaf074=_0x29a594['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x24650e+'\x20for\x20'+_0xbaf074);const _0x596e93={'p':_0x24650e},_0x8c53d4='q';_0x2a6659['tag']&&(_0x596e93['q']=_0x29a594['_queryObject'],_0x596e93['t']=_0x2a6659['tag']),_0x596e93['h']=_0x2a6659['hashFn'](),this['sendRequest'](_0x8c53d4,_0x596e93,_0xe44cf7=>{const _0xcdb4d5=_0xe44cf7['d'],_0x4c08e5=_0xe44cf7['s'];se['warnOnListenWarnings_'](_0xcdb4d5,_0x29a594),(this['listens']['get'](_0x24650e)&&this['listens']['get'](_0x24650e)['get'](_0xbaf074))===_0x2a6659&&(this['log_']('listen\x20response',_0xe44cf7),_0x4c08e5!=='ok'&&this['removeListen_'](_0x24650e,_0xbaf074),_0x2a6659['onComplete']&&_0x2a6659['onComplete'](_0x4c08e5,_0xcdb4d5));});}static['warnOnListenWarnings_'](_0x24c3e5,_0x52a813){if(_0x24c3e5&&typeof _0x24c3e5=='object'&&J(_0x24c3e5,'w')){const _0x466587=De(_0x24c3e5,'w');if(Array['isArray'](_0x466587)&&~_0x466587['indexOf']('no_index')){const _0x9a0438='\x22.indexOn\x22:\x20\x22'+_0x52a813['_queryParams']['getIndex']()['toString']()+'\x22',_0x12fd79=_0x52a813['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x9a0438+'\x20at\x20'+_0x12fd79+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x3e8239){this['authToken_']=_0x3e8239,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x3e8239);}['reduceReconnectDelayIfAdminCredential_'](_0x2d9a10){(_0x2d9a10&&_0x2d9a10['length']===0x28||wc(_0x2d9a10))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x3406e1){this['appCheckToken_']=_0x3406e1,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x25d1fe=this['authToken_'],_0x12c9a1=Ic(_0x25d1fe)?'auth':'gauth',_0x38fc28={'cred':_0x25d1fe};this['authOverride_']===null?_0x38fc28['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x38fc28['authvar']=this['authOverride_']),this['sendRequest'](_0x12c9a1,_0x38fc28,_0x291351=>{const _0x219140=_0x291351['s'],_0x4050eb=_0x291351['d']||'error';this['authToken_']===_0x25d1fe&&(_0x219140==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x219140,_0x4050eb));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x4f310c=>{const _0x4974ab=_0x4f310c['s'],_0x3104cd=_0x4f310c['d']||'error';_0x4974ab==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x4974ab,_0x3104cd);});}['unlisten'](_0x5db874,_0x419b8b){const _0x120c43=_0x5db874['_path']['toString'](),_0xc89cfb=_0x5db874['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x120c43+'\x20'+_0xc89cfb),f(_0x5db874['_queryParams']['isDefault']()||!_0x5db874['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x120c43,_0xc89cfb)&&this['connected_']&&this['sendUnlisten_'](_0x120c43,_0xc89cfb,_0x5db874['_queryObject'],_0x419b8b);}['sendUnlisten_'](_0x5ad62e,_0x5117b4,_0x272ae3,_0x41b930){this['log_']('Unlisten\x20on\x20'+_0x5ad62e+'\x20for\x20'+_0x5117b4);const _0xc60f49={'p':_0x5ad62e},_0x470d7e='n';_0x41b930&&(_0xc60f49['q']=_0x272ae3,_0xc60f49['t']=_0x41b930),this['sendRequest'](_0x470d7e,_0xc60f49);}['onDisconnectPut'](_0x22cb68,_0x1521e7,_0xe5f91f){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x22cb68,_0x1521e7,_0xe5f91f):this['onDisconnectRequestQueue_']['push']({'pathString':_0x22cb68,'action':'o','data':_0x1521e7,'onComplete':_0xe5f91f});}['onDisconnectMerge'](_0x468e09,_0x38101c,_0x57728d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x468e09,_0x38101c,_0x57728d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x468e09,'action':'om','data':_0x38101c,'onComplete':_0x57728d});}['onDisconnectCancel'](_0x1fc0d9,_0x5d6fd4){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x1fc0d9,null,_0x5d6fd4):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1fc0d9,'action':'oc','data':null,'onComplete':_0x5d6fd4});}['sendOnDisconnect_'](_0x9acfb,_0x1dbd10,_0x44cca1,_0x3129d1){const _0xc4f375={'p':_0x1dbd10,'d':_0x44cca1};this['log_']('onDisconnect\x20'+_0x9acfb,_0xc4f375),this['sendRequest'](_0x9acfb,_0xc4f375,_0x2a117f=>{_0x3129d1&&setTimeout(()=>{_0x3129d1(_0x2a117f['s'],_0x2a117f['d']);},Math['floor'](0x0));});}['put'](_0xa75a72,_0x5aab60,_0x2dfeca,_0x4ceea0){this['putInternal']('p',_0xa75a72,_0x5aab60,_0x2dfeca,_0x4ceea0);}['merge'](_0x1c3162,_0x530f4b,_0x36b48e,_0x457aad){this['putInternal']('m',_0x1c3162,_0x530f4b,_0x36b48e,_0x457aad);}['putInternal'](_0x5ed203,_0x4d00e6,_0x324e84,_0x103d74,_0xab79e){this['initConnection_']();const _0x53d398={'p':_0x4d00e6,'d':_0x324e84};_0xab79e!==void 0x0&&(_0x53d398['h']=_0xab79e),this['outstandingPuts_']['push']({'action':_0x5ed203,'request':_0x53d398,'onComplete':_0x103d74}),this['outstandingPutCount_']++;const _0x3266ec=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x3266ec):this['log_']('Buffering\x20put:\x20'+_0x4d00e6);}['sendPut_'](_0x1e4fbc){const _0x12b91e=this['outstandingPuts_'][_0x1e4fbc]['action'],_0x72363c=this['outstandingPuts_'][_0x1e4fbc]['request'],_0xb3f95f=this['outstandingPuts_'][_0x1e4fbc]['onComplete'];this['outstandingPuts_'][_0x1e4fbc]['queued']=this['connected_'],this['sendRequest'](_0x12b91e,_0x72363c,_0x2e5e97=>{this['log_'](_0x12b91e+'\x20response',_0x2e5e97),delete this['outstandingPuts_'][_0x1e4fbc],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0xb3f95f&&_0xb3f95f(_0x2e5e97['s'],_0x2e5e97['d']);});}['reportStats'](_0x23fa5a){if(this['connected_']){const _0x2a4a7c={'c':_0x23fa5a};this['log_']('reportStats',_0x2a4a7c),this['sendRequest']('s',_0x2a4a7c,_0x4fb99e=>{if(_0x4fb99e['s']!=='ok'){const _0x113469=_0x4fb99e['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x113469);}});}}['onDataMessage_'](_0x261a93){if('r'in _0x261a93){this['log_']('from\x20server:\x20'+O(_0x261a93));const _0x3ba999=_0x261a93['r'],_0x5c9a06=this['requestCBHash_'][_0x3ba999];_0x5c9a06&&(delete this['requestCBHash_'][_0x3ba999],_0x5c9a06(_0x261a93['b']));}else{if('error'in _0x261a93)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x261a93['error'];'a'in _0x261a93&&this['onDataPush_'](_0x261a93['a'],_0x261a93['b']);}}['onDataPush_'](_0x54531e,_0x250c1e){this['log_']('handleServerMessage',_0x54531e,_0x250c1e),_0x54531e==='d'?this['onDataUpdate_'](_0x250c1e['p'],_0x250c1e['d'],!0x1,_0x250c1e['t']):_0x54531e==='m'?this['onDataUpdate_'](_0x250c1e['p'],_0x250c1e['d'],!0x0,_0x250c1e['t']):_0x54531e==='c'?this['onListenRevoked_'](_0x250c1e['p'],_0x250c1e['q']):_0x54531e==='ac'?this['onAuthRevoked_'](_0x250c1e['s'],_0x250c1e['d']):_0x54531e==='apc'?this['onAppCheckRevoked_'](_0x250c1e['s'],_0x250c1e['d']):_0x54531e==='sd'?this['onSecurityDebugPacket_'](_0x250c1e):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x54531e)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x1b8533,_0x106149){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x1b8533),this['lastSessionId']=_0x106149,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x295a9c){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x295a9c));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0xe1a6c6){_0xe1a6c6&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0xe1a6c6;}['onOnline_'](_0x2356a9){_0x2356a9?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x483d88=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x209bcd=Math['max'](0x0,this['reconnectDelay_']-_0x483d88);_0x209bcd=Math['random']()*_0x209bcd,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x209bcd+'ms'),this['scheduleConnect_'](_0x209bcd),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x26bef1=this['onDataMessage_']['bind'](this),_0x5656b8=this['onReady_']['bind'](this),_0x35d0ae=this['onRealtimeDisconnect_']['bind'](this),_0x5527b6=this['id']+':'+se['nextConnectionId_']++,_0x114dbb=this['lastSessionId'];let _0x19a90b=!0x1,_0x3b13=null;const _0xe2f899=function(){_0x3b13?_0x3b13['close']():(_0x19a90b=!0x0,_0x35d0ae());},_0x4f693d=function(_0x4a436f){f(_0x3b13,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x3b13['sendRequest'](_0x4a436f);};this['realtime_']={'close':_0xe2f899,'sendRequest':_0x4f693d};const _0x46c6c3=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x35eba6,_0xf20318]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x46c6c3),this['appCheckTokenProvider_']['getToken'](_0x46c6c3)]);_0x19a90b?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x35eba6&&_0x35eba6['accessToken'],this['appCheckToken_']=_0xf20318&&_0xf20318['token'],_0x3b13=new Sh(_0x5527b6,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x26bef1,_0x5656b8,_0x35d0ae,_0x595b85=>{U(_0x595b85+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x114dbb));}catch(_0x4ff6c6){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x4ff6c6),_0x19a90b||(this['repoInfo_']['nodeAdmin']&&U(_0x4ff6c6),_0xe2f899());}}}['interrupt'](_0x42f1f4){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x42f1f4),this['interruptReasons_'][_0x42f1f4]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x422fdf){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x422fdf),delete this['interruptReasons_'][_0x422fdf],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x7d4927){const _0x3ce42d=_0x7d4927-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x3ce42d});}['cancelSentTransactions_'](){for(let _0x4ed37f=0x0;_0x4ed37f<this['outstandingPuts_']['length'];_0x4ed37f++){const _0xf1071f=this['outstandingPuts_'][_0x4ed37f];_0xf1071f&&'h'in _0xf1071f['request']&&_0xf1071f['queued']&&(_0xf1071f['onComplete']&&_0xf1071f['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x4ed37f],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x522142,_0x4944fc){let _0x2011b6;_0x4944fc?_0x2011b6=_0x4944fc['map'](_0x4107ca=>Hi(_0x4107ca))['join']('$'):_0x2011b6='default';const _0x85203b=this['removeListen_'](_0x522142,_0x2011b6);_0x85203b&&_0x85203b['onComplete']&&_0x85203b['onComplete']('permission_denied');}['removeListen_'](_0x66a9ce,_0x6dd365){const _0x22696f=new C(_0x66a9ce)['toString']();let _0x4742ae;if(this['listens']['has'](_0x22696f)){const _0x5065bb=this['listens']['get'](_0x22696f);_0x4742ae=_0x5065bb['get'](_0x6dd365),_0x5065bb['delete'](_0x6dd365),_0x5065bb['size']===0x0&&this['listens']['delete'](_0x22696f);}else _0x4742ae=void 0x0;return _0x4742ae;}['onAuthRevoked_'](_0x4595ec,_0x32502a){L('Auth\x20token\x20revoked:\x20'+_0x4595ec+'/'+_0x32502a),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x4595ec==='invalid_token'||_0x4595ec==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x4fa01a,_0x2fe403){L('App\x20check\x20token\x20revoked:\x20'+_0x4fa01a+'/'+_0x2fe403),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x4fa01a==='invalid_token'||_0x4fa01a==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x426cab){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x426cab):'msg'in _0x426cab&&console['log']('FIREBASE:\x20'+_0x426cab['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x111ced of this['listens']['values']())for(const _0x27999d of _0x111ced['values']())this['sendListen_'](_0x27999d);for(let _0x164a73=0x0;_0x164a73<this['outstandingPuts_']['length'];_0x164a73++)this['outstandingPuts_'][_0x164a73]&&this['sendPut_'](_0x164a73);for(;this['onDisconnectRequestQueue_']['length'];){const _0x2e8b97=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x2e8b97['action'],_0x2e8b97['pathString'],_0x2e8b97['data'],_0x2e8b97['onComplete']);}for(let _0x5b837c=0x0;_0x5b837c<this['outstandingGets_']['length'];_0x5b837c++)this['outstandingGets_'][_0x5b837c]&&this['sendGet_'](_0x5b837c);}['sendConnectStats_'](){const _0x1cc71f={};let _0x25e83='js';_0x1cc71f['sdk.'+_0x25e83+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x1cc71f['framework.cordova']=0x1:Yr()&&(_0x1cc71f['framework.reactnative']=0x1),this['reportStats'](_0x1cc71f);}['shouldReconnect_'](){const _0x509c47=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x509c47;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x5b4e2d,_0x338c64){this['name']=_0x5b4e2d,this['node']=_0x338c64;}static['Wrap'](_0x5202db,_0x50bb5d){return new E(_0x5202db,_0x50bb5d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x8c9b3e,_0x414d05){const _0x20f543=new E(Fe,_0x8c9b3e),_0x17f59a=new E(Fe,_0x414d05);return this['compare'](_0x20f543,_0x17f59a)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x3a669b){Zt=_0x3a669b;}['compare'](_0xee406,_0x5c000a){return He(_0xee406['name'],_0x5c000a['name']);}['isDefinedOn'](_0x1290ce){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x4593fa,_0x3e918c){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x214365,_0x32fb88){return f(typeof _0x214365=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x214365,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x57e943,_0x3418ac,_0x24cae2,_0x19ef06,_0x39da3f=null){this['isReverse_']=_0x19ef06,this['resultGenerator_']=_0x39da3f,this['nodeStack_']=[];let _0x3c5d0e=0x1;for(;!_0x57e943['isEmpty']();)if(_0x57e943=_0x57e943,_0x3c5d0e=_0x3418ac?_0x24cae2(_0x57e943['key'],_0x3418ac):0x1,_0x19ef06&&(_0x3c5d0e*=-0x1),_0x3c5d0e<0x0)this['isReverse_']?_0x57e943=_0x57e943['left']:_0x57e943=_0x57e943['right'];else{if(_0x3c5d0e===0x0){this['nodeStack_']['push'](_0x57e943);break;}else this['nodeStack_']['push'](_0x57e943),this['isReverse_']?_0x57e943=_0x57e943['right']:_0x57e943=_0x57e943['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x3a5638=this['nodeStack_']['pop'](),_0xd69bd6;if(this['resultGenerator_']?_0xd69bd6=this['resultGenerator_'](_0x3a5638['key'],_0x3a5638['value']):_0xd69bd6={'key':_0x3a5638['key'],'value':_0x3a5638['value']},this['isReverse_']){for(_0x3a5638=_0x3a5638['left'];!_0x3a5638['isEmpty']();)this['nodeStack_']['push'](_0x3a5638),_0x3a5638=_0x3a5638['right'];}else{for(_0x3a5638=_0x3a5638['right'];!_0x3a5638['isEmpty']();)this['nodeStack_']['push'](_0x3a5638),_0x3a5638=_0x3a5638['left'];}return _0xd69bd6;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x197269=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x197269['key'],_0x197269['value']):{'key':_0x197269['key'],'value':_0x197269['value']};}}class M{constructor(_0xa7ee96,_0x566750,_0x5d4bfc,_0x2f98da,_0x2117fd){this['key']=_0xa7ee96,this['value']=_0x566750,this['color']=_0x5d4bfc??M['RED'],this['left']=_0x2f98da??B['EMPTY_NODE'],this['right']=_0x2117fd??B['EMPTY_NODE'];}['copy'](_0x1ad0de,_0x3e8e4d,_0xc752db,_0x4f9704,_0x3b914e){return new M(_0x1ad0de??this['key'],_0x3e8e4d??this['value'],_0xc752db??this['color'],_0x4f9704??this['left'],_0x3b914e??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x490ceb){return this['left']['inorderTraversal'](_0x490ceb)||!!_0x490ceb(this['key'],this['value'])||this['right']['inorderTraversal'](_0x490ceb);}['reverseTraversal'](_0x13fd6c){return this['right']['reverseTraversal'](_0x13fd6c)||_0x13fd6c(this['key'],this['value'])||this['left']['reverseTraversal'](_0x13fd6c);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x20ed7a,_0x3be513,_0x592163){let _0x12b8be=this;const _0x20240c=_0x592163(_0x20ed7a,_0x12b8be['key']);return _0x20240c<0x0?_0x12b8be=_0x12b8be['copy'](null,null,null,_0x12b8be['left']['insert'](_0x20ed7a,_0x3be513,_0x592163),null):_0x20240c===0x0?_0x12b8be=_0x12b8be['copy'](null,_0x3be513,null,null,null):_0x12b8be=_0x12b8be['copy'](null,null,null,null,_0x12b8be['right']['insert'](_0x20ed7a,_0x3be513,_0x592163)),_0x12b8be['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x3423ec=this;return!_0x3423ec['left']['isRed_']()&&!_0x3423ec['left']['left']['isRed_']()&&(_0x3423ec=_0x3423ec['moveRedLeft_']()),_0x3423ec=_0x3423ec['copy'](null,null,null,_0x3423ec['left']['removeMin_'](),null),_0x3423ec['fixUp_']();}['remove'](_0x565c95,_0x18fdc9){let _0x1e0416,_0x4981ac;if(_0x1e0416=this,_0x18fdc9(_0x565c95,_0x1e0416['key'])<0x0)!_0x1e0416['left']['isEmpty']()&&!_0x1e0416['left']['isRed_']()&&!_0x1e0416['left']['left']['isRed_']()&&(_0x1e0416=_0x1e0416['moveRedLeft_']()),_0x1e0416=_0x1e0416['copy'](null,null,null,_0x1e0416['left']['remove'](_0x565c95,_0x18fdc9),null);else{if(_0x1e0416['left']['isRed_']()&&(_0x1e0416=_0x1e0416['rotateRight_']()),!_0x1e0416['right']['isEmpty']()&&!_0x1e0416['right']['isRed_']()&&!_0x1e0416['right']['left']['isRed_']()&&(_0x1e0416=_0x1e0416['moveRedRight_']()),_0x18fdc9(_0x565c95,_0x1e0416['key'])===0x0){if(_0x1e0416['right']['isEmpty']())return B['EMPTY_NODE'];_0x4981ac=_0x1e0416['right']['min_'](),_0x1e0416=_0x1e0416['copy'](_0x4981ac['key'],_0x4981ac['value'],null,null,_0x1e0416['right']['removeMin_']());}_0x1e0416=_0x1e0416['copy'](null,null,null,null,_0x1e0416['right']['remove'](_0x565c95,_0x18fdc9));}return _0x1e0416['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x2d1494=this;return _0x2d1494['right']['isRed_']()&&!_0x2d1494['left']['isRed_']()&&(_0x2d1494=_0x2d1494['rotateLeft_']()),_0x2d1494['left']['isRed_']()&&_0x2d1494['left']['left']['isRed_']()&&(_0x2d1494=_0x2d1494['rotateRight_']()),_0x2d1494['left']['isRed_']()&&_0x2d1494['right']['isRed_']()&&(_0x2d1494=_0x2d1494['colorFlip_']()),_0x2d1494;}['moveRedLeft_'](){let _0x324437=this['colorFlip_']();return _0x324437['right']['left']['isRed_']()&&(_0x324437=_0x324437['copy'](null,null,null,null,_0x324437['right']['rotateRight_']()),_0x324437=_0x324437['rotateLeft_'](),_0x324437=_0x324437['colorFlip_']()),_0x324437;}['moveRedRight_'](){let _0x323edb=this['colorFlip_']();return _0x323edb['left']['left']['isRed_']()&&(_0x323edb=_0x323edb['rotateRight_'](),_0x323edb=_0x323edb['colorFlip_']()),_0x323edb;}['rotateLeft_'](){const _0x344cce=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x344cce,null);}['rotateRight_'](){const _0x12d955=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x12d955);}['colorFlip_'](){const _0x2c0c15=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x350cf7=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x2c0c15,_0x350cf7);}['checkMaxDepth_'](){const _0xf7536e=this['check_']();return Math['pow'](0x2,_0xf7536e)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x500b2a=this['left']['check_']();if(_0x500b2a!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x500b2a+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x71314c,_0x270b53,_0x14c439,_0x4ef586,_0x254dae){return this;}['insert'](_0x16ccda,_0xe07e28,_0x458173){return new M(_0x16ccda,_0xe07e28,null);}['remove'](_0x55c631,_0x5e480c){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x37d2d5){return!0x1;}['reverseTraversal'](_0x38b806){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x53be64,_0x4ff690=B['EMPTY_NODE']){this['comparator_']=_0x53be64,this['root_']=_0x4ff690;}['insert'](_0x29dd81,_0x1f8842){return new B(this['comparator_'],this['root_']['insert'](_0x29dd81,_0x1f8842,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x2a446e){return new B(this['comparator_'],this['root_']['remove'](_0x2a446e,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x2c9228){let _0x437051,_0x219cfe=this['root_'];for(;!_0x219cfe['isEmpty']();){if(_0x437051=this['comparator_'](_0x2c9228,_0x219cfe['key']),_0x437051===0x0)return _0x219cfe['value'];_0x437051<0x0?_0x219cfe=_0x219cfe['left']:_0x437051>0x0&&(_0x219cfe=_0x219cfe['right']);}return null;}['getPredecessorKey'](_0x4ec64f){let _0x1d6b6c,_0x4cab7c=this['root_'],_0x4d4338=null;for(;!_0x4cab7c['isEmpty']();)if(_0x1d6b6c=this['comparator_'](_0x4ec64f,_0x4cab7c['key']),_0x1d6b6c===0x0){if(_0x4cab7c['left']['isEmpty']())return _0x4d4338?_0x4d4338['key']:null;for(_0x4cab7c=_0x4cab7c['left'];!_0x4cab7c['right']['isEmpty']();)_0x4cab7c=_0x4cab7c['right'];return _0x4cab7c['key'];}else _0x1d6b6c<0x0?_0x4cab7c=_0x4cab7c['left']:_0x1d6b6c>0x0&&(_0x4d4338=_0x4cab7c,_0x4cab7c=_0x4cab7c['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x7805b1){return this['root_']['inorderTraversal'](_0x7805b1);}['reverseTraversal'](_0x48f29f){return this['root_']['reverseTraversal'](_0x48f29f);}['getIterator'](_0x563aa5){return new en(this['root_'],null,this['comparator_'],!0x1,_0x563aa5);}['getIteratorFrom'](_0x5a7a7c,_0x2c2848){return new en(this['root_'],_0x5a7a7c,this['comparator_'],!0x1,_0x2c2848);}['getReverseIteratorFrom'](_0x4a2a43,_0x43a99d){return new en(this['root_'],_0x4a2a43,this['comparator_'],!0x0,_0x43a99d);}['getReverseIterator'](_0x44f556){return new en(this['root_'],null,this['comparator_'],!0x0,_0x44f556);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x3c4cdd,_0x4ebdde){return He(_0x3c4cdd['name'],_0x4ebdde['name']);}function Yi(_0x49e4b1,_0x3dd245){return He(_0x49e4b1,_0x3dd245);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x3b892d){Ei=_0x3b892d;}const No=function(_0x47289e){return typeof _0x47289e=='number'?'number:'+ao(_0x47289e):'string:'+_0x47289e;},Po=function(_0x4e5105){if(_0x4e5105['isLeafNode']()){const _0x5c6d5b=_0x4e5105['val']();f(typeof _0x5c6d5b=='string'||typeof _0x5c6d5b=='number'||typeof _0x5c6d5b=='object'&&J(_0x5c6d5b,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x4e5105===Ei||_0x4e5105['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x4e5105===Ei||_0x4e5105['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x2b1eb1){ir=_0x2b1eb1;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x581c48,_0xe85197=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x581c48,this['priorityNode_']=_0xe85197,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x573e32){return new D(this['value_'],_0x573e32);}['getImmediateChild'](_0x927077){return _0x927077==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x2cc720){return v(_0x2cc720)?this:y(_0x2cc720)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x3859f9,_0x243f2c){return null;}['updateImmediateChild'](_0xfa2fe6,_0xc8e1d3){return _0xfa2fe6==='.priority'?this['updatePriority'](_0xc8e1d3):_0xc8e1d3['isEmpty']()&&_0xfa2fe6!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0xfa2fe6,_0xc8e1d3)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x1b94ea,_0x120285){const _0x393a69=y(_0x1b94ea);return _0x393a69===null?_0x120285:_0x120285['isEmpty']()&&_0x393a69!=='.priority'?this:(f(_0x393a69!=='.priority'||we(_0x1b94ea)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x393a69,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x1b94ea),_0x120285)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x30bebf,_0x3c0d48){return!0x1;}['val'](_0x2cecac){return _0x2cecac&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x4525e6='';this['priorityNode_']['isEmpty']()||(_0x4525e6+='priority:'+No(this['priorityNode_']['val']())+':');const _0x58614f=typeof this['value_'];_0x4525e6+=_0x58614f+':',_0x58614f==='number'?_0x4525e6+=ao(this['value_']):_0x4525e6+=this['value_'],this['lazyHash_']=ro(_0x4525e6);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x3bfb1a){return _0x3bfb1a===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x3bfb1a instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x3bfb1a['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x3bfb1a));}['compareToLeafNode_'](_0x16f29d){const _0x4ed4b7=typeof _0x16f29d['value_'],_0xcbf093=typeof this['value_'],_0x32217e=D['VALUE_TYPE_ORDER']['indexOf'](_0x4ed4b7),_0xf6521d=D['VALUE_TYPE_ORDER']['indexOf'](_0xcbf093);return f(_0x32217e>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4ed4b7),f(_0xf6521d>=0x0,'Unknown\x20leaf\x20type:\x20'+_0xcbf093),_0x32217e===_0xf6521d?_0xcbf093==='object'?0x0:this['value_']<_0x16f29d['value_']?-0x1:this['value_']===_0x16f29d['value_']?0x0:0x1:_0xf6521d-_0x32217e;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x3fe864){if(_0x3fe864===this)return!0x0;if(_0x3fe864['isLeafNode']()){const _0x413880=_0x3fe864;return this['value_']===_0x413880['value_']&&this['priorityNode_']['equals'](_0x413880['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x514f85){Oo=_0x514f85;}function Wh(_0x142b5d){Do=_0x142b5d;}class Bh extends Dn{['compare'](_0x244a86,_0x4b079d){const _0x5e847c=_0x244a86['node']['getPriority'](),_0x5a0eea=_0x4b079d['node']['getPriority'](),_0x9071b2=_0x5e847c['compareTo'](_0x5a0eea);return _0x9071b2===0x0?He(_0x244a86['name'],_0x4b079d['name']):_0x9071b2;}['isDefinedOn'](_0x461219){return!_0x461219['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x77cd1a,_0x24c07d){return!_0x77cd1a['getPriority']()['equals'](_0x24c07d['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0xefc8c6,_0x594755){const _0x272575=Oo(_0xefc8c6);return new E(_0x594755,new D('[PRIORITY-POST]',_0x272575));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x3d5c22){const _0x5ae9d5=_0xb811dc=>parseInt(Math['log'](_0xb811dc)/Vh,0xa),_0x5bead6=_0x3ecc8b=>parseInt(Array(_0x3ecc8b+0x1)['join']('1'),0x2);this['count']=_0x5ae9d5(_0x3d5c22+0x1),this['current_']=this['count']-0x1;const _0x51a04a=_0x5bead6(this['count']);this['bits_']=_0x3d5c22+0x1&_0x51a04a;}['nextBitIsOne'](){const _0x46a690=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x46a690;}}const fn=function(_0x2300a4,_0x34b6fb,_0x399ae6,_0x4837c6){_0x2300a4['sort'](_0x34b6fb);const _0x188ea5=function(_0x1e17f9,_0x3ee0b1){const _0x62d0f8=_0x3ee0b1-_0x1e17f9;let _0xe2a837,_0x3e4be5;if(_0x62d0f8===0x0)return null;if(_0x62d0f8===0x1)return _0xe2a837=_0x2300a4[_0x1e17f9],_0x3e4be5=_0x399ae6?_0x399ae6(_0xe2a837):_0xe2a837,new M(_0x3e4be5,_0xe2a837['node'],M['BLACK'],null,null);{const _0x3e1103=parseInt(_0x62d0f8/0x2,0xa)+_0x1e17f9,_0x54d312=_0x188ea5(_0x1e17f9,_0x3e1103),_0x3ccc84=_0x188ea5(_0x3e1103+0x1,_0x3ee0b1);return _0xe2a837=_0x2300a4[_0x3e1103],_0x3e4be5=_0x399ae6?_0x399ae6(_0xe2a837):_0xe2a837,new M(_0x3e4be5,_0xe2a837['node'],M['BLACK'],_0x54d312,_0x3ccc84);}},_0x1e80eb=function(_0x3aac08){let _0x277e6a=null,_0x3f4e60=null,_0x25f23a=_0x2300a4['length'];const _0x3891a4=function(_0x58ce3c,_0x409c95){const _0x5cf6c3=_0x25f23a-_0x58ce3c,_0xef4514=_0x25f23a;_0x25f23a-=_0x58ce3c;const _0x3216c1=_0x188ea5(_0x5cf6c3+0x1,_0xef4514),_0x7e45aa=_0x2300a4[_0x5cf6c3],_0x37fb90=_0x399ae6?_0x399ae6(_0x7e45aa):_0x7e45aa;_0x4c333f(new M(_0x37fb90,_0x7e45aa['node'],_0x409c95,null,_0x3216c1));},_0x4c333f=function(_0x3fe07d){_0x277e6a?(_0x277e6a['left']=_0x3fe07d,_0x277e6a=_0x3fe07d):(_0x3f4e60=_0x3fe07d,_0x277e6a=_0x3fe07d);};for(let _0x266361=0x0;_0x266361<_0x3aac08['count'];++_0x266361){const _0x5a1af2=_0x3aac08['nextBitIsOne'](),_0x2263cc=Math['pow'](0x2,_0x3aac08['count']-(_0x266361+0x1));_0x5a1af2?_0x3891a4(_0x2263cc,M['BLACK']):(_0x3891a4(_0x2263cc,M['BLACK']),_0x3891a4(_0x2263cc,M['RED']));}return _0x3f4e60;},_0x6db851=new Hh(_0x2300a4['length']),_0x33a4a0=_0x1e80eb(_0x6db851);return new B(_0x4837c6||_0x34b6fb,_0x33a4a0);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x145269,_0x3fd717){this['indexes_']=_0x145269,this['indexSet_']=_0x3fd717;}['get'](_0x40b8a5){const _0x4a63be=De(this['indexes_'],_0x40b8a5);if(!_0x4a63be)throw new Error('No\x20index\x20defined\x20for\x20'+_0x40b8a5);return _0x4a63be instanceof B?_0x4a63be:null;}['hasIndex'](_0x5ad749){return J(this['indexSet_'],_0x5ad749['toString']());}['addIndex'](_0x174d5c,_0x38f2e9){f(_0x174d5c!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0xf4492e=[];let _0x2170f9=!0x1;const _0x4b0638=_0x38f2e9['getIterator'](E['Wrap']);let _0x13e25b=_0x4b0638['getNext']();for(;_0x13e25b;)_0x2170f9=_0x2170f9||_0x174d5c['isDefinedOn'](_0x13e25b['node']),_0xf4492e['push'](_0x13e25b),_0x13e25b=_0x4b0638['getNext']();let _0x3ac2e1;_0x2170f9?_0x3ac2e1=fn(_0xf4492e,_0x174d5c['getCompare']()):_0x3ac2e1=ze;const _0x492796=_0x174d5c['toString'](),_0x2ad83a={...this['indexSet_']};_0x2ad83a[_0x492796]=_0x174d5c;const _0x3af9e1={...this['indexes_']};return _0x3af9e1[_0x492796]=_0x3ac2e1,new te(_0x3af9e1,_0x2ad83a);}['addToIndexes'](_0x30c2b0,_0x353671){const _0x8b4ecd=hn(this['indexes_'],(_0x8b63ed,_0x11d4c3)=>{const _0x4f3e05=De(this['indexSet_'],_0x11d4c3);if(f(_0x4f3e05,'Missing\x20index\x20implementation\x20for\x20'+_0x11d4c3),_0x8b63ed===ze){if(_0x4f3e05['isDefinedOn'](_0x30c2b0['node'])){const _0x59c169=[],_0x597a96=_0x353671['getIterator'](E['Wrap']);let _0x5cc1ba=_0x597a96['getNext']();for(;_0x5cc1ba;)_0x5cc1ba['name']!==_0x30c2b0['name']&&_0x59c169['push'](_0x5cc1ba),_0x5cc1ba=_0x597a96['getNext']();return _0x59c169['push'](_0x30c2b0),fn(_0x59c169,_0x4f3e05['getCompare']());}else return ze;}else{const _0x3c2358=_0x353671['get'](_0x30c2b0['name']);let _0x42f23c=_0x8b63ed;return _0x3c2358&&(_0x42f23c=_0x42f23c['remove'](new E(_0x30c2b0['name'],_0x3c2358))),_0x42f23c['insert'](_0x30c2b0,_0x30c2b0['node']);}});return new te(_0x8b4ecd,this['indexSet_']);}['removeFromIndexes'](_0x50280c,_0x2c449e){const _0x3deeff=hn(this['indexes_'],_0x13a248=>{if(_0x13a248===ze)return _0x13a248;{const _0x118359=_0x2c449e['get'](_0x50280c['name']);return _0x118359?_0x13a248['remove'](new E(_0x50280c['name'],_0x118359)):_0x13a248;}});return new te(_0x3deeff,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x5163f8,_0x4cf3b5,_0x151c26){this['children_']=_0x5163f8,this['priorityNode_']=_0x4cf3b5,this['indexMap_']=_0x151c26,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x290859){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x290859,this['indexMap_']);}['getImmediateChild'](_0x3d10f0){if(_0x3d10f0==='.priority')return this['getPriority']();{const _0x2f645f=this['children_']['get'](_0x3d10f0);return _0x2f645f===null?mt:_0x2f645f;}}['getChild'](_0x582d2c){const _0xdb57c9=y(_0x582d2c);return _0xdb57c9===null?this:this['getImmediateChild'](_0xdb57c9)['getChild'](b(_0x582d2c));}['hasChild'](_0x1f7fb2){return this['children_']['get'](_0x1f7fb2)!==null;}['updateImmediateChild'](_0x356f5c,_0x1f6e31){if(f(_0x1f6e31,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x356f5c==='.priority')return this['updatePriority'](_0x1f6e31);{const _0x32dc6d=new E(_0x356f5c,_0x1f6e31);let _0x5ea913,_0x4dae0e;_0x1f6e31['isEmpty']()?(_0x5ea913=this['children_']['remove'](_0x356f5c),_0x4dae0e=this['indexMap_']['removeFromIndexes'](_0x32dc6d,this['children_'])):(_0x5ea913=this['children_']['insert'](_0x356f5c,_0x1f6e31),_0x4dae0e=this['indexMap_']['addToIndexes'](_0x32dc6d,this['children_']));const _0x52a6b0=_0x5ea913['isEmpty']()?mt:this['priorityNode_'];return new g(_0x5ea913,_0x52a6b0,_0x4dae0e);}}['updateChild'](_0x370c28,_0x34f459){const _0x451430=y(_0x370c28);if(_0x451430===null)return _0x34f459;{f(y(_0x370c28)!=='.priority'||we(_0x370c28)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x583d2c=this['getImmediateChild'](_0x451430)['updateChild'](b(_0x370c28),_0x34f459);return this['updateImmediateChild'](_0x451430,_0x583d2c);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x6a86ce){if(this['isEmpty']())return null;const _0x5b90bb={};let _0x2ad0b3=0x0,_0x48ff27=0x0,_0x462f86=!0x0;if(this['forEachChild'](R,(_0x6cd246,_0x54ae98)=>{_0x5b90bb[_0x6cd246]=_0x54ae98['val'](_0x6a86ce),_0x2ad0b3++,_0x462f86&&g['INTEGER_REGEXP_']['test'](_0x6cd246)?_0x48ff27=Math['max'](_0x48ff27,Number(_0x6cd246)):_0x462f86=!0x1;}),!_0x6a86ce&&_0x462f86&&_0x48ff27<0x2*_0x2ad0b3){const _0x47c32b=[];for(const _0x283118 in _0x5b90bb)_0x47c32b[_0x283118]=_0x5b90bb[_0x283118];return _0x47c32b;}else return _0x6a86ce&&!this['getPriority']()['isEmpty']()&&(_0x5b90bb['.priority']=this['getPriority']()['val']()),_0x5b90bb;}['hash'](){if(this['lazyHash_']===null){let _0x533e06='';this['getPriority']()['isEmpty']()||(_0x533e06+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x3b7c4c,_0x2a224c)=>{const _0x286b0f=_0x2a224c['hash']();_0x286b0f!==''&&(_0x533e06+=':'+_0x3b7c4c+':'+_0x286b0f);}),this['lazyHash_']=_0x533e06===''?'':ro(_0x533e06);}return this['lazyHash_'];}['getPredecessorChildName'](_0xc0aa5,_0x48f995,_0xa333f5){const _0x3cb80a=this['resolveIndex_'](_0xa333f5);if(_0x3cb80a){const _0x4e3dc1=_0x3cb80a['getPredecessorKey'](new E(_0xc0aa5,_0x48f995));return _0x4e3dc1?_0x4e3dc1['name']:null;}else return this['children_']['getPredecessorKey'](_0xc0aa5);}['getFirstChildName'](_0x120407){const _0x42eae6=this['resolveIndex_'](_0x120407);if(_0x42eae6){const _0x3c23c7=_0x42eae6['minKey']();return _0x3c23c7&&_0x3c23c7['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x1a594e){const _0x29a2e7=this['getFirstChildName'](_0x1a594e);return _0x29a2e7?new E(_0x29a2e7,this['children_']['get'](_0x29a2e7)):null;}['getLastChildName'](_0x4772f5){const _0x30203f=this['resolveIndex_'](_0x4772f5);if(_0x30203f){const _0x55cbc5=_0x30203f['maxKey']();return _0x55cbc5&&_0x55cbc5['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x21ef6b){const _0x48b631=this['getLastChildName'](_0x21ef6b);return _0x48b631?new E(_0x48b631,this['children_']['get'](_0x48b631)):null;}['forEachChild'](_0x3e0a87,_0x25a216){const _0x2c0768=this['resolveIndex_'](_0x3e0a87);return _0x2c0768?_0x2c0768['inorderTraversal'](_0x17b5bc=>_0x25a216(_0x17b5bc['name'],_0x17b5bc['node'])):this['children_']['inorderTraversal'](_0x25a216);}['getIterator'](_0x17a040){return this['getIteratorFrom'](_0x17a040['minPost'](),_0x17a040);}['getIteratorFrom'](_0x3a9d10,_0x9b51ea){const _0x210f6d=this['resolveIndex_'](_0x9b51ea);if(_0x210f6d)return _0x210f6d['getIteratorFrom'](_0x3a9d10,_0x25c0ce=>_0x25c0ce);{const _0x56b9ea=this['children_']['getIteratorFrom'](_0x3a9d10['name'],E['Wrap']);let _0x37807c=_0x56b9ea['peek']();for(;_0x37807c!=null&&_0x9b51ea['compare'](_0x37807c,_0x3a9d10)<0x0;)_0x56b9ea['getNext'](),_0x37807c=_0x56b9ea['peek']();return _0x56b9ea;}}['getReverseIterator'](_0x4c2509){return this['getReverseIteratorFrom'](_0x4c2509['maxPost'](),_0x4c2509);}['getReverseIteratorFrom'](_0x461e7d,_0x4b1947){const _0x466362=this['resolveIndex_'](_0x4b1947);if(_0x466362)return _0x466362['getReverseIteratorFrom'](_0x461e7d,_0x1f2e92=>_0x1f2e92);{const _0x1342b2=this['children_']['getReverseIteratorFrom'](_0x461e7d['name'],E['Wrap']);let _0x18c2b6=_0x1342b2['peek']();for(;_0x18c2b6!=null&&_0x4b1947['compare'](_0x18c2b6,_0x461e7d)>0x0;)_0x1342b2['getNext'](),_0x18c2b6=_0x1342b2['peek']();return _0x1342b2;}}['compareTo'](_0x4f6818){return this['isEmpty']()?_0x4f6818['isEmpty']()?0x0:-0x1:_0x4f6818['isLeafNode']()||_0x4f6818['isEmpty']()?0x1:_0x4f6818===$t?-0x1:0x0;}['withIndex'](_0x7c4304){if(_0x7c4304===ye||this['indexMap_']['hasIndex'](_0x7c4304))return this;{const _0x5e8f8e=this['indexMap_']['addIndex'](_0x7c4304,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x5e8f8e);}}['isIndexed'](_0x145fe8){return _0x145fe8===ye||this['indexMap_']['hasIndex'](_0x145fe8);}['equals'](_0x1e76ce){if(_0x1e76ce===this)return!0x0;if(_0x1e76ce['isLeafNode']())return!0x1;{const _0x2f3777=_0x1e76ce;if(this['getPriority']()['equals'](_0x2f3777['getPriority']())){if(this['children_']['count']()===_0x2f3777['children_']['count']()){const _0x13936f=this['getIterator'](R),_0x5996ea=_0x2f3777['getIterator'](R);let _0xd50c27=_0x13936f['getNext'](),_0x48dbf4=_0x5996ea['getNext']();for(;_0xd50c27&&_0x48dbf4;){if(_0xd50c27['name']!==_0x48dbf4['name']||!_0xd50c27['node']['equals'](_0x48dbf4['node']))return!0x1;_0xd50c27=_0x13936f['getNext'](),_0x48dbf4=_0x5996ea['getNext']();}return _0xd50c27===null&&_0x48dbf4===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x3cf563){return _0x3cf563===ye?null:this['indexMap_']['get'](_0x3cf563['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x18521a){return _0x18521a===this?0x0:0x1;}['equals'](_0x389c86){return _0x389c86===this;}['getPriority'](){return this;}['getImmediateChild'](_0x1ca0b6){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x5100d9,_0x3da322=null){if(_0x5100d9===null)return g['EMPTY_NODE'];if(typeof _0x5100d9=='object'&&'.priority'in _0x5100d9&&(_0x3da322=_0x5100d9['.priority']),f(_0x3da322===null||typeof _0x3da322=='string'||typeof _0x3da322=='number'||typeof _0x3da322=='object'&&'.sv'in _0x3da322,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x3da322),typeof _0x5100d9=='object'&&'.value'in _0x5100d9&&_0x5100d9['.value']!==null&&(_0x5100d9=_0x5100d9['.value']),typeof _0x5100d9!='object'||'.sv'in _0x5100d9){const _0x27687a=_0x5100d9;return new D(_0x27687a,P(_0x3da322));}if(!(_0x5100d9 instanceof Array)&&Gh){const _0x205588=[];let _0x4a6566=!0x1;if(x(_0x5100d9,(_0x935b73,_0x143a2d)=>{if(_0x935b73['substring'](0x0,0x1)!=='.'){const _0x2736ff=P(_0x143a2d);_0x2736ff['isEmpty']()||(_0x4a6566=_0x4a6566||!_0x2736ff['getPriority']()['isEmpty'](),_0x205588['push'](new E(_0x935b73,_0x2736ff)));}}),_0x205588['length']===0x0)return g['EMPTY_NODE'];const _0x5e5e8f=fn(_0x205588,xh,_0x59294a=>_0x59294a['name'],Yi);if(_0x4a6566){const _0x5f0bc5=fn(_0x205588,R['getCompare']());return new g(_0x5e5e8f,P(_0x3da322),new te({'.priority':_0x5f0bc5},{'.priority':R}));}else return new g(_0x5e5e8f,P(_0x3da322),te['Default']);}else{let _0x3bdf0b=g['EMPTY_NODE'];return x(_0x5100d9,(_0x5a8d8f,_0x2909b9)=>{if(J(_0x5100d9,_0x5a8d8f)&&_0x5a8d8f['substring'](0x0,0x1)!=='.'){const _0x3c98cb=P(_0x2909b9);(_0x3c98cb['isLeafNode']()||!_0x3c98cb['isEmpty']())&&(_0x3bdf0b=_0x3bdf0b['updateImmediateChild'](_0x5a8d8f,_0x3c98cb));}}),_0x3bdf0b['updatePriority'](P(_0x3da322));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x34e4cc){super(),this['indexPath_']=_0x34e4cc,f(!v(_0x34e4cc)&&y(_0x34e4cc)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0xab9fd0){return _0xab9fd0['getChild'](this['indexPath_']);}['isDefinedOn'](_0x3ce6e4){return!_0x3ce6e4['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x39a21e,_0x265739){const _0x3911ae=this['extractChild'](_0x39a21e['node']),_0x5c8b8d=this['extractChild'](_0x265739['node']),_0x111a1a=_0x3911ae['compareTo'](_0x5c8b8d);return _0x111a1a===0x0?He(_0x39a21e['name'],_0x265739['name']):_0x111a1a;}['makePost'](_0x34d296,_0x2815fb){const _0x32ddb8=P(_0x34d296),_0x1fce47=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x32ddb8);return new E(_0x2815fb,_0x1fce47);}['maxPost'](){const _0x5e36a6=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x5e36a6);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x390460,_0xd05046){const _0x4ba728=_0x390460['node']['compareTo'](_0xd05046['node']);return _0x4ba728===0x0?He(_0x390460['name'],_0xd05046['name']):_0x4ba728;}['isDefinedOn'](_0xfec9e8){return!0x0;}['indexedValueChanged'](_0x10d0f1,_0x283f93){return!_0x10d0f1['equals'](_0x283f93);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x157eda,_0xc4ee1b){const _0x4c10df=P(_0x157eda);return new E(_0xc4ee1b,_0x4c10df);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x22f1f5){return{'type':'value','snapshotNode':_0x22f1f5};}function et(_0x255ff1,_0x31a003){return{'type':'child_added','snapshotNode':_0x31a003,'childName':_0x255ff1};}function Ot(_0x472736,_0x597f3a){return{'type':'child_removed','snapshotNode':_0x597f3a,'childName':_0x472736};}function Dt(_0x37a034,_0x56beeb,_0xe2e65f){return{'type':'child_changed','snapshotNode':_0x56beeb,'childName':_0x37a034,'oldSnap':_0xe2e65f};}function zh(_0x412c88,_0x3a1569){return{'type':'child_moved','snapshotNode':_0x3a1569,'childName':_0x412c88};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x2f317f){this['index_']=_0x2f317f;}['updateChild'](_0x5cdaf1,_0x7b8153,_0x251800,_0xfbc2cf,_0x1fb0b1,_0x54bda2){f(_0x5cdaf1['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x2e3239=_0x5cdaf1['getImmediateChild'](_0x7b8153);return _0x2e3239['getChild'](_0xfbc2cf)['equals'](_0x251800['getChild'](_0xfbc2cf))&&_0x2e3239['isEmpty']()===_0x251800['isEmpty']()||(_0x54bda2!=null&&(_0x251800['isEmpty']()?_0x5cdaf1['hasChild'](_0x7b8153)?_0x54bda2['trackChildChange'](Ot(_0x7b8153,_0x2e3239)):f(_0x5cdaf1['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x2e3239['isEmpty']()?_0x54bda2['trackChildChange'](et(_0x7b8153,_0x251800)):_0x54bda2['trackChildChange'](Dt(_0x7b8153,_0x251800,_0x2e3239))),_0x5cdaf1['isLeafNode']()&&_0x251800['isEmpty']())?_0x5cdaf1:_0x5cdaf1['updateImmediateChild'](_0x7b8153,_0x251800)['withIndex'](this['index_']);}['updateFullNode'](_0x47e094,_0x2f1b1d,_0x41ec41){return _0x41ec41!=null&&(_0x47e094['isLeafNode']()||_0x47e094['forEachChild'](R,(_0x23725c,_0x2b1b4f)=>{_0x2f1b1d['hasChild'](_0x23725c)||_0x41ec41['trackChildChange'](Ot(_0x23725c,_0x2b1b4f));}),_0x2f1b1d['isLeafNode']()||_0x2f1b1d['forEachChild'](R,(_0x5dcfc7,_0xe20920)=>{if(_0x47e094['hasChild'](_0x5dcfc7)){const _0x410fe7=_0x47e094['getImmediateChild'](_0x5dcfc7);_0x410fe7['equals'](_0xe20920)||_0x41ec41['trackChildChange'](Dt(_0x5dcfc7,_0xe20920,_0x410fe7));}else _0x41ec41['trackChildChange'](et(_0x5dcfc7,_0xe20920));})),_0x2f1b1d['withIndex'](this['index_']);}['updatePriority'](_0x1c2027,_0xa738b6){return _0x1c2027['isEmpty']()?g['EMPTY_NODE']:_0x1c2027['updatePriority'](_0xa738b6);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x3ec4e9){this['indexedFilter_']=new Ji(_0x3ec4e9['getIndex']()),this['index_']=_0x3ec4e9['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x3ec4e9),this['endPost_']=Mt['getEndPost_'](_0x3ec4e9),this['startIsInclusive_']=!_0x3ec4e9['startAfterSet_'],this['endIsInclusive_']=!_0x3ec4e9['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x1acc89){const _0x56d332=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x1acc89)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x1acc89)<0x0,_0x40a0b3=this['endIsInclusive_']?this['index_']['compare'](_0x1acc89,this['getEndPost']())<=0x0:this['index_']['compare'](_0x1acc89,this['getEndPost']())<0x0;return _0x56d332&&_0x40a0b3;}['updateChild'](_0x2f7f70,_0x509f08,_0x17ba3e,_0x80015b,_0x35af18,_0x4af621){return this['matches'](new E(_0x509f08,_0x17ba3e))||(_0x17ba3e=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x2f7f70,_0x509f08,_0x17ba3e,_0x80015b,_0x35af18,_0x4af621);}['updateFullNode'](_0x748ac,_0x47c634,_0x2d018c){_0x47c634['isLeafNode']()&&(_0x47c634=g['EMPTY_NODE']);let _0x2aa96b=_0x47c634['withIndex'](this['index_']);_0x2aa96b=_0x2aa96b['updatePriority'](g['EMPTY_NODE']);const _0x55a8c1=this;return _0x47c634['forEachChild'](R,(_0x1e7910,_0x481fac)=>{_0x55a8c1['matches'](new E(_0x1e7910,_0x481fac))||(_0x2aa96b=_0x2aa96b['updateImmediateChild'](_0x1e7910,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x748ac,_0x2aa96b,_0x2d018c);}['updatePriority'](_0x546be0,_0x412c07){return _0x546be0;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x3b5de1){if(_0x3b5de1['hasStart']()){const _0x6613d7=_0x3b5de1['getIndexStartName']();return _0x3b5de1['getIndex']()['makePost'](_0x3b5de1['getIndexStartValue'](),_0x6613d7);}else return _0x3b5de1['getIndex']()['minPost']();}static['getEndPost_'](_0x57bde4){if(_0x57bde4['hasEnd']()){const _0x4f850c=_0x57bde4['getIndexEndName']();return _0x57bde4['getIndex']()['makePost'](_0x57bde4['getIndexEndValue'](),_0x4f850c);}else return _0x57bde4['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x168722){this['withinDirectionalStart']=_0x1a7128=>this['reverse_']?this['withinEndPost'](_0x1a7128):this['withinStartPost'](_0x1a7128),this['withinDirectionalEnd']=_0xcda8a0=>this['reverse_']?this['withinStartPost'](_0xcda8a0):this['withinEndPost'](_0xcda8a0),this['withinStartPost']=_0x48e606=>{const _0x3091c4=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x48e606);return this['startIsInclusive_']?_0x3091c4<=0x0:_0x3091c4<0x0;},this['withinEndPost']=_0x3957a9=>{const _0x5dc13f=this['index_']['compare'](_0x3957a9,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x5dc13f<=0x0:_0x5dc13f<0x0;},this['rangedFilter_']=new Mt(_0x168722),this['index_']=_0x168722['getIndex'](),this['limit_']=_0x168722['getLimit'](),this['reverse_']=!_0x168722['isViewFromLeft'](),this['startIsInclusive_']=!_0x168722['startAfterSet_'],this['endIsInclusive_']=!_0x168722['endBeforeSet_'];}['updateChild'](_0x36427e,_0x339f1f,_0x45cc61,_0x4952ec,_0x4b8737,_0x46ab34){return this['rangedFilter_']['matches'](new E(_0x339f1f,_0x45cc61))||(_0x45cc61=g['EMPTY_NODE']),_0x36427e['getImmediateChild'](_0x339f1f)['equals'](_0x45cc61)?_0x36427e:_0x36427e['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x36427e,_0x339f1f,_0x45cc61,_0x4952ec,_0x4b8737,_0x46ab34):this['fullLimitUpdateChild_'](_0x36427e,_0x339f1f,_0x45cc61,_0x4b8737,_0x46ab34);}['updateFullNode'](_0x1d2ec5,_0x2080a7,_0x5d4984){let _0x5cb68c;if(_0x2080a7['isLeafNode']()||_0x2080a7['isEmpty']())_0x5cb68c=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x2080a7['numChildren']()&&_0x2080a7['isIndexed'](this['index_'])){_0x5cb68c=g['EMPTY_NODE']['withIndex'](this['index_']);let _0xf94edf;this['reverse_']?_0xf94edf=_0x2080a7['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0xf94edf=_0x2080a7['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x18f0b9=0x0;for(;_0xf94edf['hasNext']()&&_0x18f0b9<this['limit_'];){const _0x2bd6f0=_0xf94edf['getNext']();if(this['withinDirectionalStart'](_0x2bd6f0)){if(this['withinDirectionalEnd'](_0x2bd6f0))_0x5cb68c=_0x5cb68c['updateImmediateChild'](_0x2bd6f0['name'],_0x2bd6f0['node']),_0x18f0b9++;else break;}else continue;}}else{_0x5cb68c=_0x2080a7['withIndex'](this['index_']),_0x5cb68c=_0x5cb68c['updatePriority'](g['EMPTY_NODE']);let _0x20701c;this['reverse_']?_0x20701c=_0x5cb68c['getReverseIterator'](this['index_']):_0x20701c=_0x5cb68c['getIterator'](this['index_']);let _0x59d6ec=0x0;for(;_0x20701c['hasNext']();){const _0x2e739d=_0x20701c['getNext']();_0x59d6ec<this['limit_']&&this['withinDirectionalStart'](_0x2e739d)&&this['withinDirectionalEnd'](_0x2e739d)?_0x59d6ec++:_0x5cb68c=_0x5cb68c['updateImmediateChild'](_0x2e739d['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x1d2ec5,_0x5cb68c,_0x5d4984);}['updatePriority'](_0x3f26e3,_0x3324a3){return _0x3f26e3;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x44c712,_0x301e48,_0x47a781,_0x8abb93,_0x1f99f0){let _0x19284e;if(this['reverse_']){const _0x5d778a=this['index_']['getCompare']();_0x19284e=(_0x137e10,_0x59e73c)=>_0x5d778a(_0x59e73c,_0x137e10);}else _0x19284e=this['index_']['getCompare']();const _0x43d2a1=_0x44c712;f(_0x43d2a1['numChildren']()===this['limit_'],'');const _0x17d915=new E(_0x301e48,_0x47a781),_0x34bb44=this['reverse_']?_0x43d2a1['getFirstChild'](this['index_']):_0x43d2a1['getLastChild'](this['index_']),_0x1a44c6=this['rangedFilter_']['matches'](_0x17d915);if(_0x43d2a1['hasChild'](_0x301e48)){const _0x123e4c=_0x43d2a1['getImmediateChild'](_0x301e48);let _0x5d4c99=_0x8abb93['getChildAfterChild'](this['index_'],_0x34bb44,this['reverse_']);for(;_0x5d4c99!=null&&(_0x5d4c99['name']===_0x301e48||_0x43d2a1['hasChild'](_0x5d4c99['name']));)_0x5d4c99=_0x8abb93['getChildAfterChild'](this['index_'],_0x5d4c99,this['reverse_']);const _0x138204=_0x5d4c99==null?0x1:_0x19284e(_0x5d4c99,_0x17d915);if(_0x1a44c6&&!_0x47a781['isEmpty']()&&_0x138204>=0x0)return _0x1f99f0!=null&&_0x1f99f0['trackChildChange'](Dt(_0x301e48,_0x47a781,_0x123e4c)),_0x43d2a1['updateImmediateChild'](_0x301e48,_0x47a781);{_0x1f99f0!=null&&_0x1f99f0['trackChildChange'](Ot(_0x301e48,_0x123e4c));const _0x3d5ac8=_0x43d2a1['updateImmediateChild'](_0x301e48,g['EMPTY_NODE']);return _0x5d4c99!=null&&this['rangedFilter_']['matches'](_0x5d4c99)?(_0x1f99f0!=null&&_0x1f99f0['trackChildChange'](et(_0x5d4c99['name'],_0x5d4c99['node'])),_0x3d5ac8['updateImmediateChild'](_0x5d4c99['name'],_0x5d4c99['node'])):_0x3d5ac8;}}else return _0x47a781['isEmpty']()?_0x44c712:_0x1a44c6&&_0x19284e(_0x34bb44,_0x17d915)>=0x0?(_0x1f99f0!=null&&(_0x1f99f0['trackChildChange'](Ot(_0x34bb44['name'],_0x34bb44['node'])),_0x1f99f0['trackChildChange'](et(_0x301e48,_0x47a781))),_0x43d2a1['updateImmediateChild'](_0x301e48,_0x47a781)['updateImmediateChild'](_0x34bb44['name'],g['EMPTY_NODE'])):_0x44c712;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x27d134=new Xi();return _0x27d134['limitSet_']=this['limitSet_'],_0x27d134['limit_']=this['limit_'],_0x27d134['startSet_']=this['startSet_'],_0x27d134['startAfterSet_']=this['startAfterSet_'],_0x27d134['indexStartValue_']=this['indexStartValue_'],_0x27d134['startNameSet_']=this['startNameSet_'],_0x27d134['indexStartName_']=this['indexStartName_'],_0x27d134['endSet_']=this['endSet_'],_0x27d134['endBeforeSet_']=this['endBeforeSet_'],_0x27d134['indexEndValue_']=this['indexEndValue_'],_0x27d134['endNameSet_']=this['endNameSet_'],_0x27d134['indexEndName_']=this['indexEndName_'],_0x27d134['index_']=this['index_'],_0x27d134['viewFrom_']=this['viewFrom_'],_0x27d134;}}function Kh(_0x1949a4){return _0x1949a4['loadsAllData']()?new Ji(_0x1949a4['getIndex']()):_0x1949a4['hasLimit']()?new jh(_0x1949a4):new Mt(_0x1949a4);}function Yh(_0x161a25,_0x3885aa){const _0x4ba31f=_0x161a25['copy']();return _0x4ba31f['limitSet_']=!0x0,_0x4ba31f['limit_']=_0x3885aa,_0x4ba31f['viewFrom_']='l',_0x4ba31f;}function Qh(_0x56f68e,_0x2a7375,_0x383e10){const _0x43d673=_0x56f68e['copy']();return _0x43d673['startSet_']=!0x0,_0x2a7375===void 0x0&&(_0x2a7375=null),_0x43d673['indexStartValue_']=_0x2a7375,_0x383e10!=null?(_0x43d673['startNameSet_']=!0x0,_0x43d673['indexStartName_']=_0x383e10):(_0x43d673['startNameSet_']=!0x1,_0x43d673['indexStartName_']=''),_0x43d673;}function Jh(_0x54ba07,_0x59740c,_0x4ef9fc){const _0x4de154=_0x54ba07['copy']();return _0x4de154['endSet_']=!0x0,_0x59740c===void 0x0&&(_0x59740c=null),_0x4de154['indexEndValue_']=_0x59740c,_0x4ef9fc!==void 0x0?(_0x4de154['endNameSet_']=!0x0,_0x4de154['indexEndName_']=_0x4ef9fc):(_0x4de154['endNameSet_']=!0x1,_0x4de154['indexEndName_']=''),_0x4de154;}function xo(_0x2cb7c9,_0xbb8825){const _0x3df09c=_0x2cb7c9['copy']();return _0x3df09c['index_']=_0xbb8825,_0x3df09c;}function sr(_0xe04a6){const _0x537474={};if(_0xe04a6['isDefault']())return _0x537474;let _0x347615;if(_0xe04a6['index_']===R?_0x347615='$priority':_0xe04a6['index_']===Mo?_0x347615='$value':_0xe04a6['index_']===ye?_0x347615='$key':(f(_0xe04a6['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x347615=_0xe04a6['index_']['toString']()),_0x537474['orderBy']=O(_0x347615),_0xe04a6['startSet_']){const _0x102378=_0xe04a6['startAfterSet_']?'startAfter':'startAt';_0x537474[_0x102378]=O(_0xe04a6['indexStartValue_']),_0xe04a6['startNameSet_']&&(_0x537474[_0x102378]+=','+O(_0xe04a6['indexStartName_']));}if(_0xe04a6['endSet_']){const _0x8ee592=_0xe04a6['endBeforeSet_']?'endBefore':'endAt';_0x537474[_0x8ee592]=O(_0xe04a6['indexEndValue_']),_0xe04a6['endNameSet_']&&(_0x537474[_0x8ee592]+=','+O(_0xe04a6['indexEndName_']));}return _0xe04a6['limitSet_']&&(_0xe04a6['isViewFromLeft']()?_0x537474['limitToFirst']=_0xe04a6['limit_']:_0x537474['limitToLast']=_0xe04a6['limit_']),_0x537474;}function rr(_0x800001){const _0x39ee9c={};if(_0x800001['startSet_']&&(_0x39ee9c['sp']=_0x800001['indexStartValue_'],_0x800001['startNameSet_']&&(_0x39ee9c['sn']=_0x800001['indexStartName_']),_0x39ee9c['sin']=!_0x800001['startAfterSet_']),_0x800001['endSet_']&&(_0x39ee9c['ep']=_0x800001['indexEndValue_'],_0x800001['endNameSet_']&&(_0x39ee9c['en']=_0x800001['indexEndName_']),_0x39ee9c['ein']=!_0x800001['endBeforeSet_']),_0x800001['limitSet_']){_0x39ee9c['l']=_0x800001['limit_'];let _0x11e57c=_0x800001['viewFrom_'];_0x11e57c===''&&(_0x800001['isViewFromLeft']()?_0x11e57c='l':_0x11e57c='r'),_0x39ee9c['vf']=_0x11e57c;}return _0x800001['index_']!==R&&(_0x39ee9c['i']=_0x800001['index_']['toString']()),_0x39ee9c;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x2cbe55){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x5e2e24,_0x1f4d2f){return _0x1f4d2f!==void 0x0?'tag$'+_0x1f4d2f:(f(_0x5e2e24['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x5e2e24['_path']['toString']());}constructor(_0x2b50f3,_0xe6564c,_0x1c4bcb,_0x216cbf){super(),this['repoInfo_']=_0x2b50f3,this['onDataUpdate_']=_0xe6564c,this['authTokenProvider_']=_0x1c4bcb,this['appCheckTokenProvider_']=_0x216cbf,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0xf68c1e,_0x4a4924,_0x60a80,_0x1fdc41){const _0x27fcb0=_0xf68c1e['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x27fcb0+'\x20'+_0xf68c1e['_queryIdentifier']);const _0x4d9e04=pn['getListenId_'](_0xf68c1e,_0x60a80),_0xb573d={};this['listens_'][_0x4d9e04]=_0xb573d;const _0x2b8c9e=sr(_0xf68c1e['_queryParams']);this['restRequest_'](_0x27fcb0+'.json',_0x2b8c9e,(_0x2a6b72,_0x58640b)=>{let _0x33dccd=_0x58640b;if(_0x2a6b72===0x194&&(_0x33dccd=null,_0x2a6b72=null),_0x2a6b72===null&&this['onDataUpdate_'](_0x27fcb0,_0x33dccd,!0x1,_0x60a80),De(this['listens_'],_0x4d9e04)===_0xb573d){let _0x218a91;_0x2a6b72?_0x2a6b72===0x191?_0x218a91='permission_denied':_0x218a91='rest_error:'+_0x2a6b72:_0x218a91='ok',_0x1fdc41(_0x218a91,null);}});}['unlisten'](_0x58f569,_0x3f87b2){const _0xd8122e=pn['getListenId_'](_0x58f569,_0x3f87b2);delete this['listens_'][_0xd8122e];}['get'](_0x16aa69){const _0xbf83bf=sr(_0x16aa69['_queryParams']),_0x9dd568=_0x16aa69['_path']['toString'](),_0x374daa=new ot();return this['restRequest_'](_0x9dd568+'.json',_0xbf83bf,(_0x25c00a,_0x233cc4)=>{let _0x21b174=_0x233cc4;_0x25c00a===0x194&&(_0x21b174=null,_0x25c00a=null),_0x25c00a===null?(this['onDataUpdate_'](_0x9dd568,_0x21b174,!0x1,null),_0x374daa['resolve'](_0x21b174)):_0x374daa['reject'](new Error(_0x21b174));}),_0x374daa['promise'];}['refreshAuthToken'](_0x14ed62){}['restRequest_'](_0x6dae0e,_0x387f96={},_0x520a35){return _0x387f96['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x3e5a38,_0x59e9c2])=>{_0x3e5a38&&_0x3e5a38['accessToken']&&(_0x387f96['auth']=_0x3e5a38['accessToken']),_0x59e9c2&&_0x59e9c2['token']&&(_0x387f96['ac']=_0x59e9c2['token']);const _0x1fe9d5=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x6dae0e+'?ns='+this['repoInfo_']['namespace']+ct(_0x387f96);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x1fe9d5);const _0x58df74=new XMLHttpRequest();_0x58df74['onreadystatechange']=()=>{if(_0x520a35&&_0x58df74['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x1fe9d5+'\x20received.\x20status:',_0x58df74['status'],'response:',_0x58df74['responseText']);let _0x15bf54=null;if(_0x58df74['status']>=0xc8&&_0x58df74['status']<0x12c){try{_0x15bf54=At(_0x58df74['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x1fe9d5+':\x20'+_0x58df74['responseText']);}_0x520a35(null,_0x15bf54);}else _0x58df74['status']!==0x191&&_0x58df74['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x1fe9d5+'\x20Status:\x20'+_0x58df74['status']),_0x520a35(_0x58df74['status']);_0x520a35=null;}},_0x58df74['open']('GET',_0x1fe9d5,!0x0),_0x58df74['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x3ce15b){return this['rootNode_']['getChild'](_0x3ce15b);}['updateSnapshot'](_0x3dff69,_0x5a4d34){this['rootNode_']=this['rootNode_']['updateChild'](_0x3dff69,_0x5a4d34);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x1bde9b,_0x43c703,_0x2c2006){if(v(_0x43c703))_0x1bde9b['value']=_0x2c2006,_0x1bde9b['children']['clear']();else{if(_0x1bde9b['value']!==null)_0x1bde9b['value']=_0x1bde9b['value']['updateChild'](_0x43c703,_0x2c2006);else{const _0x1ae02a=y(_0x43c703);_0x1bde9b['children']['has'](_0x1ae02a)||_0x1bde9b['children']['set'](_0x1ae02a,_n());const _0x3d2267=_0x1bde9b['children']['get'](_0x1ae02a);_0x43c703=b(_0x43c703),Fo(_0x3d2267,_0x43c703,_0x2c2006);}}}function Ii(_0x508f6f,_0x1aa74f,_0x5bc60b){_0x508f6f['value']!==null?_0x5bc60b(_0x1aa74f,_0x508f6f['value']):Zh(_0x508f6f,(_0x2b1330,_0xd8169b)=>{const _0x380e23=new C(_0x1aa74f['toString']()+'/'+_0x2b1330);Ii(_0xd8169b,_0x380e23,_0x5bc60b);});}function Zh(_0x4332fc,_0x24d845){_0x4332fc['children']['forEach']((_0xeeadc2,_0x489c6c)=>{_0x24d845(_0x489c6c,_0xeeadc2);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x4d2764){this['collection_']=_0x4d2764,this['last_']=null;}['get'](){const _0x1a6252=this['collection_']['get'](),_0x4c205a={..._0x1a6252};return this['last_']&&x(this['last_'],(_0x44a6a8,_0x56099b)=>{_0x4c205a[_0x44a6a8]=_0x4c205a[_0x44a6a8]-_0x56099b;}),this['last_']=_0x1a6252,_0x4c205a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x45737b,_0x554fed){this['server_']=_0x554fed,this['statsToReport_']={},this['statsListener_']=new eu(_0x45737b);const _0x536a99=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x536a99));}['reportStats_'](){const _0x119328=this['statsListener_']['get'](),_0x696b39={};let _0x356b3f=!0x1;x(_0x119328,(_0x1b3309,_0x3e772d)=>{_0x3e772d>0x0&&J(this['statsToReport_'],_0x1b3309)&&(_0x696b39[_0x1b3309]=_0x3e772d,_0x356b3f=!0x0);}),_0x356b3f&&this['server_']['reportStats'](_0x696b39),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x2b8d17){_0x2b8d17[_0x2b8d17['OVERWRITE']=0x0]='OVERWRITE',_0x2b8d17[_0x2b8d17['MERGE']=0x1]='MERGE',_0x2b8d17[_0x2b8d17['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x2b8d17[_0x2b8d17['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x387710){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x387710,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x379c89,_0x48ce4f,_0x133fd9){this['path']=_0x379c89,this['affectedTree']=_0x48ce4f,this['revert']=_0x133fd9,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x2baff3){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x44b478=this['affectedTree']['subtree'](new C(_0x2baff3));return new gn(w(),_0x44b478,this['revert']);}}else return f(y(this['path'])===_0x2baff3,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x52f8de,_0x12fae6){this['source']=_0x52f8de,this['path']=_0x12fae6,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x66a825){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x5c1373,_0x200826,_0x429c79){this['source']=_0x5c1373,this['path']=_0x200826,this['snap']=_0x429c79,this['type']=j['OVERWRITE'];}['operationForChild'](_0x259523){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x259523)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x20b7ec,_0x219276,_0x250846){this['source']=_0x20b7ec,this['path']=_0x219276,this['children']=_0x250846,this['type']=j['MERGE'];}['operationForChild'](_0x12b9cc){if(v(this['path'])){const _0xa2a3c2=this['children']['subtree'](new C(_0x12b9cc));return _0xa2a3c2['isEmpty']()?null:_0xa2a3c2['value']?new Ue(this['source'],w(),_0xa2a3c2['value']):new tt(this['source'],w(),_0xa2a3c2);}else return f(y(this['path'])===_0x12b9cc,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x18311f,_0x60a85b,_0x318c1e){this['node_']=_0x18311f,this['fullyInitialized_']=_0x60a85b,this['filtered_']=_0x318c1e;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x5451b2){if(v(_0x5451b2))return this['isFullyInitialized']()&&!this['filtered_'];const _0x2fdf45=y(_0x5451b2);return this['isCompleteForChild'](_0x2fdf45);}['isCompleteForChild'](_0x40048d){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x40048d);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x422040){this['query_']=_0x422040,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x35264c,_0x8743e5,_0x57a68e,_0x4228dc){const _0x174a5e=[],_0x5bae8f=[];return _0x8743e5['forEach'](_0x1a4a61=>{_0x1a4a61['type']==='child_changed'&&_0x35264c['index_']['indexedValueChanged'](_0x1a4a61['oldSnap'],_0x1a4a61['snapshotNode'])&&_0x5bae8f['push'](zh(_0x1a4a61['childName'],_0x1a4a61['snapshotNode']));}),yt(_0x35264c,_0x174a5e,'child_removed',_0x8743e5,_0x4228dc,_0x57a68e),yt(_0x35264c,_0x174a5e,'child_added',_0x8743e5,_0x4228dc,_0x57a68e),yt(_0x35264c,_0x174a5e,'child_moved',_0x5bae8f,_0x4228dc,_0x57a68e),yt(_0x35264c,_0x174a5e,'child_changed',_0x8743e5,_0x4228dc,_0x57a68e),yt(_0x35264c,_0x174a5e,'value',_0x8743e5,_0x4228dc,_0x57a68e),_0x174a5e;}function yt(_0x8aeb44,_0x304ce4,_0x2f2aaf,_0x4f9cf7,_0x222611,_0x1c7013){const _0x4bb928=_0x4f9cf7['filter'](_0x57cfb5=>_0x57cfb5['type']===_0x2f2aaf);_0x4bb928['sort']((_0x316ccb,_0x554c80)=>au(_0x8aeb44,_0x316ccb,_0x554c80)),_0x4bb928['forEach'](_0x552fe6=>{const _0x4655bb=ou(_0x8aeb44,_0x552fe6,_0x1c7013);_0x222611['forEach'](_0x3feca3=>{_0x3feca3['respondsTo'](_0x552fe6['type'])&&_0x304ce4['push'](_0x3feca3['createEvent'](_0x4655bb,_0x8aeb44['query_']));});});}function ou(_0x366e27,_0x274101,_0xb4f434){return _0x274101['type']==='value'||_0x274101['type']==='child_removed'||(_0x274101['prevName']=_0xb4f434['getPredecessorChildName'](_0x274101['childName'],_0x274101['snapshotNode'],_0x366e27['index_'])),_0x274101;}function au(_0x2ccfa4,_0x2a1868,_0x4b3c60){if(_0x2a1868['childName']==null||_0x4b3c60['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x1d6d29=new E(_0x2a1868['childName'],_0x2a1868['snapshotNode']),_0x384c33=new E(_0x4b3c60['childName'],_0x4b3c60['snapshotNode']);return _0x2ccfa4['index_']['compare'](_0x1d6d29,_0x384c33);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x17702d,_0x4062ab){return{'eventCache':_0x17702d,'serverCache':_0x4062ab};}function Tt(_0x4c953d,_0x112056,_0x36cadd,_0x513e9d){return Mn(new Ce(_0x112056,_0x36cadd,_0x513e9d),_0x4c953d['serverCache']);}function Uo(_0x919e99,_0x129b03,_0x188a7b,_0x36cb76){return Mn(_0x919e99['eventCache'],new Ce(_0x129b03,_0x188a7b,_0x36cb76));}function mn(_0x1d0f65){return _0x1d0f65['eventCache']['isFullyInitialized']()?_0x1d0f65['eventCache']['getNode']():null;}function We(_0x3d4df7){return _0x3d4df7['serverCache']['isFullyInitialized']()?_0x3d4df7['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x53628e){let _0x371341=new S(null);return x(_0x53628e,(_0x338698,_0x1c5633)=>{_0x371341=_0x371341['set'](new C(_0x338698),_0x1c5633);}),_0x371341;}constructor(_0x4c8fd8,_0x5b8645=cu()){this['value']=_0x4c8fd8,this['children']=_0x5b8645;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x4349bc,_0x1f624a){if(this['value']!=null&&_0x1f624a(this['value']))return{'path':w(),'value':this['value']};if(v(_0x4349bc))return null;{const _0x9605d9=y(_0x4349bc),_0x2e8c04=this['children']['get'](_0x9605d9);if(_0x2e8c04!==null){const _0x2a06ea=_0x2e8c04['findRootMostMatchingPathAndValue'](b(_0x4349bc),_0x1f624a);return _0x2a06ea!=null?{'path':k(new C(_0x9605d9),_0x2a06ea['path']),'value':_0x2a06ea['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x2b9429){return this['findRootMostMatchingPathAndValue'](_0x2b9429,()=>!0x0);}['subtree'](_0x5565c1){if(v(_0x5565c1))return this;{const _0x194b8a=y(_0x5565c1),_0x1de600=this['children']['get'](_0x194b8a);return _0x1de600!==null?_0x1de600['subtree'](b(_0x5565c1)):new S(null);}}['set'](_0x48080d,_0x4d7faf){if(v(_0x48080d))return new S(_0x4d7faf,this['children']);{const _0x2c118c=y(_0x48080d),_0x4c4e93=(this['children']['get'](_0x2c118c)||new S(null))['set'](b(_0x48080d),_0x4d7faf),_0x3f74d0=this['children']['insert'](_0x2c118c,_0x4c4e93);return new S(this['value'],_0x3f74d0);}}['remove'](_0x4037f2){if(v(_0x4037f2))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x4c2700=y(_0x4037f2),_0x1022fc=this['children']['get'](_0x4c2700);if(_0x1022fc){const _0x5eb15f=_0x1022fc['remove'](b(_0x4037f2));let _0x391883;return _0x5eb15f['isEmpty']()?_0x391883=this['children']['remove'](_0x4c2700):_0x391883=this['children']['insert'](_0x4c2700,_0x5eb15f),this['value']===null&&_0x391883['isEmpty']()?new S(null):new S(this['value'],_0x391883);}else return this;}}['get'](_0x585f17){if(v(_0x585f17))return this['value'];{const _0x3d0423=y(_0x585f17),_0x453c9a=this['children']['get'](_0x3d0423);return _0x453c9a?_0x453c9a['get'](b(_0x585f17)):null;}}['setTree'](_0x2b0402,_0x1c5328){if(v(_0x2b0402))return _0x1c5328;{const _0x4aca62=y(_0x2b0402),_0x58ddd2=(this['children']['get'](_0x4aca62)||new S(null))['setTree'](b(_0x2b0402),_0x1c5328);let _0x8e266a;return _0x58ddd2['isEmpty']()?_0x8e266a=this['children']['remove'](_0x4aca62):_0x8e266a=this['children']['insert'](_0x4aca62,_0x58ddd2),new S(this['value'],_0x8e266a);}}['fold'](_0x507b18){return this['fold_'](w(),_0x507b18);}['fold_'](_0x50903,_0xa5e4a1){const _0x550cc4={};return this['children']['inorderTraversal']((_0x594c19,_0x5bd780)=>{_0x550cc4[_0x594c19]=_0x5bd780['fold_'](k(_0x50903,_0x594c19),_0xa5e4a1);}),_0xa5e4a1(_0x50903,this['value'],_0x550cc4);}['findOnPath'](_0x177ad2,_0xcdc3e){return this['findOnPath_'](_0x177ad2,w(),_0xcdc3e);}['findOnPath_'](_0x121eb3,_0x1280d2,_0x2bdcc7){const _0x39c442=this['value']?_0x2bdcc7(_0x1280d2,this['value']):!0x1;if(_0x39c442)return _0x39c442;if(v(_0x121eb3))return null;{const _0x2c968a=y(_0x121eb3),_0x5a97ad=this['children']['get'](_0x2c968a);return _0x5a97ad?_0x5a97ad['findOnPath_'](b(_0x121eb3),k(_0x1280d2,_0x2c968a),_0x2bdcc7):null;}}['foreachOnPath'](_0x282d9f,_0x13f43f){return this['foreachOnPath_'](_0x282d9f,w(),_0x13f43f);}['foreachOnPath_'](_0x291ee8,_0x2bd1a2,_0x3144ca){if(v(_0x291ee8))return this;{this['value']&&_0x3144ca(_0x2bd1a2,this['value']);const _0x1bd1ff=y(_0x291ee8),_0x531926=this['children']['get'](_0x1bd1ff);return _0x531926?_0x531926['foreachOnPath_'](b(_0x291ee8),k(_0x2bd1a2,_0x1bd1ff),_0x3144ca):new S(null);}}['foreach'](_0x40516c){this['foreach_'](w(),_0x40516c);}['foreach_'](_0x4b60bd,_0x3b35b4){this['children']['inorderTraversal']((_0x59b8fa,_0x5e5bb0)=>{_0x5e5bb0['foreach_'](k(_0x4b60bd,_0x59b8fa),_0x3b35b4);}),this['value']&&_0x3b35b4(_0x4b60bd,this['value']);}['foreachChild'](_0x5650e0){this['children']['inorderTraversal']((_0x519813,_0x2e2ef0)=>{_0x2e2ef0['value']&&_0x5650e0(_0x519813,_0x2e2ef0['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x425a0a){this['writeTree_']=_0x425a0a;}static['empty'](){return new Y(new S(null));}}function St(_0x49e807,_0x5220ad,_0x24a50c){if(v(_0x5220ad))return new Y(new S(_0x24a50c));{const _0x257acf=_0x49e807['writeTree_']['findRootMostValueAndPath'](_0x5220ad);if(_0x257acf!=null){const _0x250912=_0x257acf['path'];let _0x1d43f8=_0x257acf['value'];const _0x243630=F(_0x250912,_0x5220ad);return _0x1d43f8=_0x1d43f8['updateChild'](_0x243630,_0x24a50c),new Y(_0x49e807['writeTree_']['set'](_0x250912,_0x1d43f8));}else{const _0x5c774c=new S(_0x24a50c),_0xa61613=_0x49e807['writeTree_']['setTree'](_0x5220ad,_0x5c774c);return new Y(_0xa61613);}}}function wi(_0x979dd0,_0x392a8d,_0x5ac249){let _0x35af25=_0x979dd0;return x(_0x5ac249,(_0x1cd375,_0x49b2a6)=>{_0x35af25=St(_0x35af25,k(_0x392a8d,_0x1cd375),_0x49b2a6);}),_0x35af25;}function ar(_0x475ea7,_0x1aaa79){if(v(_0x1aaa79))return Y['empty']();{const _0x272b86=_0x475ea7['writeTree_']['setTree'](_0x1aaa79,new S(null));return new Y(_0x272b86);}}function Ci(_0x4a69dd,_0x26194a){return $e(_0x4a69dd,_0x26194a)!=null;}function $e(_0x3f261c,_0x4a1e29){const _0x2b3982=_0x3f261c['writeTree_']['findRootMostValueAndPath'](_0x4a1e29);return _0x2b3982!=null?_0x3f261c['writeTree_']['get'](_0x2b3982['path'])['getChild'](F(_0x2b3982['path'],_0x4a1e29)):null;}function cr(_0x10d1ba){const _0xf794d2=[],_0x157094=_0x10d1ba['writeTree_']['value'];return _0x157094!=null?_0x157094['isLeafNode']()||_0x157094['forEachChild'](R,(_0x4391ed,_0x445fee)=>{_0xf794d2['push'](new E(_0x4391ed,_0x445fee));}):_0x10d1ba['writeTree_']['children']['inorderTraversal']((_0x1ab612,_0x4dfb54)=>{_0x4dfb54['value']!=null&&_0xf794d2['push'](new E(_0x1ab612,_0x4dfb54['value']));}),_0xf794d2;}function ve(_0x39c690,_0x2b9ede){if(v(_0x2b9ede))return _0x39c690;{const _0x88f515=$e(_0x39c690,_0x2b9ede);return _0x88f515!=null?new Y(new S(_0x88f515)):new Y(_0x39c690['writeTree_']['subtree'](_0x2b9ede));}}function Ti(_0x26c7d3){return _0x26c7d3['writeTree_']['isEmpty']();}function nt(_0x19e9ff,_0x577259){return Wo(w(),_0x19e9ff['writeTree_'],_0x577259);}function Wo(_0x3e082d,_0x15097c,_0x39f976){if(_0x15097c['value']!=null)return _0x39f976['updateChild'](_0x3e082d,_0x15097c['value']);{let _0xd8a185=null;return _0x15097c['children']['inorderTraversal']((_0x17428d,_0x1b7422)=>{_0x17428d==='.priority'?(f(_0x1b7422['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0xd8a185=_0x1b7422['value']):_0x39f976=Wo(k(_0x3e082d,_0x17428d),_0x1b7422,_0x39f976);}),!_0x39f976['getChild'](_0x3e082d)['isEmpty']()&&_0xd8a185!==null&&(_0x39f976=_0x39f976['updateChild'](k(_0x3e082d,'.priority'),_0xd8a185)),_0x39f976;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x3bd506,_0x4becf3){return $o(_0x4becf3,_0x3bd506);}function lu(_0x558955,_0x6d0b78,_0x5210e1,_0x55af79,_0x2c1af3){f(_0x55af79>_0x558955['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x2c1af3===void 0x0&&(_0x2c1af3=!0x0),_0x558955['allWrites']['push']({'path':_0x6d0b78,'snap':_0x5210e1,'writeId':_0x55af79,'visible':_0x2c1af3}),_0x2c1af3&&(_0x558955['visibleWrites']=St(_0x558955['visibleWrites'],_0x6d0b78,_0x5210e1)),_0x558955['lastWriteId']=_0x55af79;}function hu(_0x4b5430,_0xa0be04,_0x339cc7,_0x30329e){f(_0x30329e>_0x4b5430['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x4b5430['allWrites']['push']({'path':_0xa0be04,'children':_0x339cc7,'writeId':_0x30329e,'visible':!0x0}),_0x4b5430['visibleWrites']=wi(_0x4b5430['visibleWrites'],_0xa0be04,_0x339cc7),_0x4b5430['lastWriteId']=_0x30329e;}function uu(_0x34b421,_0x113567){for(let _0x26c0f4=0x0;_0x26c0f4<_0x34b421['allWrites']['length'];_0x26c0f4++){const _0x4edcab=_0x34b421['allWrites'][_0x26c0f4];if(_0x4edcab['writeId']===_0x113567)return _0x4edcab;}return null;}function du(_0x7994c,_0x2d0eb6){const _0x23b902=_0x7994c['allWrites']['findIndex'](_0x4d7e2a=>_0x4d7e2a['writeId']===_0x2d0eb6);f(_0x23b902>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x523001=_0x7994c['allWrites'][_0x23b902];_0x7994c['allWrites']['splice'](_0x23b902,0x1);let _0x41bf7f=_0x523001['visible'],_0x46d7be=!0x1,_0x496ac5=_0x7994c['allWrites']['length']-0x1;for(;_0x41bf7f&&_0x496ac5>=0x0;){const _0x59ff84=_0x7994c['allWrites'][_0x496ac5];_0x59ff84['visible']&&(_0x496ac5>=_0x23b902&&fu(_0x59ff84,_0x523001['path'])?_0x41bf7f=!0x1:G(_0x523001['path'],_0x59ff84['path'])&&(_0x46d7be=!0x0)),_0x496ac5--;}if(_0x41bf7f){if(_0x46d7be)return pu(_0x7994c),!0x0;if(_0x523001['snap'])_0x7994c['visibleWrites']=ar(_0x7994c['visibleWrites'],_0x523001['path']);else{const _0x5656e1=_0x523001['children'];x(_0x5656e1,_0x32af87=>{_0x7994c['visibleWrites']=ar(_0x7994c['visibleWrites'],k(_0x523001['path'],_0x32af87));});}return!0x0;}else return!0x1;}function fu(_0x4768aa,_0x4f0a5d){if(_0x4768aa['snap'])return G(_0x4768aa['path'],_0x4f0a5d);for(const _0x183990 in _0x4768aa['children'])if(_0x4768aa['children']['hasOwnProperty'](_0x183990)&&G(k(_0x4768aa['path'],_0x183990),_0x4f0a5d))return!0x0;return!0x1;}function pu(_0x4e31da){_0x4e31da['visibleWrites']=Bo(_0x4e31da['allWrites'],_u,w()),_0x4e31da['allWrites']['length']>0x0?_0x4e31da['lastWriteId']=_0x4e31da['allWrites'][_0x4e31da['allWrites']['length']-0x1]['writeId']:_0x4e31da['lastWriteId']=-0x1;}function _u(_0x12cb82){return _0x12cb82['visible'];}function Bo(_0x7459ac,_0x3a0968,_0x3c3b11){let _0x2fb82c=Y['empty']();for(let _0x470874=0x0;_0x470874<_0x7459ac['length'];++_0x470874){const _0x4bf1b9=_0x7459ac[_0x470874];if(_0x3a0968(_0x4bf1b9)){const _0x3e1490=_0x4bf1b9['path'];let _0x1a22bb;if(_0x4bf1b9['snap'])G(_0x3c3b11,_0x3e1490)?(_0x1a22bb=F(_0x3c3b11,_0x3e1490),_0x2fb82c=St(_0x2fb82c,_0x1a22bb,_0x4bf1b9['snap'])):G(_0x3e1490,_0x3c3b11)&&(_0x1a22bb=F(_0x3e1490,_0x3c3b11),_0x2fb82c=St(_0x2fb82c,w(),_0x4bf1b9['snap']['getChild'](_0x1a22bb)));else{if(_0x4bf1b9['children']){if(G(_0x3c3b11,_0x3e1490))_0x1a22bb=F(_0x3c3b11,_0x3e1490),_0x2fb82c=wi(_0x2fb82c,_0x1a22bb,_0x4bf1b9['children']);else{if(G(_0x3e1490,_0x3c3b11)){if(_0x1a22bb=F(_0x3e1490,_0x3c3b11),v(_0x1a22bb))_0x2fb82c=wi(_0x2fb82c,w(),_0x4bf1b9['children']);else{const _0x50cd93=De(_0x4bf1b9['children'],y(_0x1a22bb));if(_0x50cd93){const _0x16331e=_0x50cd93['getChild'](b(_0x1a22bb));_0x2fb82c=St(_0x2fb82c,w(),_0x16331e);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x2fb82c;}function Vo(_0x24c642,_0x4d3961,_0x1f3f4a,_0x3bed12,_0x107581){if(!_0x3bed12&&!_0x107581){const _0x5c8731=$e(_0x24c642['visibleWrites'],_0x4d3961);if(_0x5c8731!=null)return _0x5c8731;{const _0x539fa7=ve(_0x24c642['visibleWrites'],_0x4d3961);if(Ti(_0x539fa7))return _0x1f3f4a;if(_0x1f3f4a==null&&!Ci(_0x539fa7,w()))return null;{const _0x25f37f=_0x1f3f4a||g['EMPTY_NODE'];return nt(_0x539fa7,_0x25f37f);}}}else{const _0x25ee9c=ve(_0x24c642['visibleWrites'],_0x4d3961);if(!_0x107581&&Ti(_0x25ee9c))return _0x1f3f4a;if(!_0x107581&&_0x1f3f4a==null&&!Ci(_0x25ee9c,w()))return null;{const _0x14f492=function(_0x136f08){return(_0x136f08['visible']||_0x107581)&&(!_0x3bed12||!~_0x3bed12['indexOf'](_0x136f08['writeId']))&&(G(_0x136f08['path'],_0x4d3961)||G(_0x4d3961,_0x136f08['path']));},_0x320224=Bo(_0x24c642['allWrites'],_0x14f492,_0x4d3961),_0x27cc55=_0x1f3f4a||g['EMPTY_NODE'];return nt(_0x320224,_0x27cc55);}}}function gu(_0x55cf59,_0x32a6d9,_0x5f4f9a){let _0x5f2702=g['EMPTY_NODE'];const _0x3a13ec=$e(_0x55cf59['visibleWrites'],_0x32a6d9);if(_0x3a13ec)return _0x3a13ec['isLeafNode']()||_0x3a13ec['forEachChild'](R,(_0x6ed49e,_0x523fbb)=>{_0x5f2702=_0x5f2702['updateImmediateChild'](_0x6ed49e,_0x523fbb);}),_0x5f2702;if(_0x5f4f9a){const _0x2250ad=ve(_0x55cf59['visibleWrites'],_0x32a6d9);return _0x5f4f9a['forEachChild'](R,(_0x32fe80,_0x6fec5)=>{const _0x34e319=nt(ve(_0x2250ad,new C(_0x32fe80)),_0x6fec5);_0x5f2702=_0x5f2702['updateImmediateChild'](_0x32fe80,_0x34e319);}),cr(_0x2250ad)['forEach'](_0xf234c5=>{_0x5f2702=_0x5f2702['updateImmediateChild'](_0xf234c5['name'],_0xf234c5['node']);}),_0x5f2702;}else{const _0x5a9a0f=ve(_0x55cf59['visibleWrites'],_0x32a6d9);return cr(_0x5a9a0f)['forEach'](_0x9b7803=>{_0x5f2702=_0x5f2702['updateImmediateChild'](_0x9b7803['name'],_0x9b7803['node']);}),_0x5f2702;}}function mu(_0x268e63,_0x116a15,_0x4bd7fd,_0x3111cf,_0x812345){f(_0x3111cf||_0x812345,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x276a2d=k(_0x116a15,_0x4bd7fd);if(Ci(_0x268e63['visibleWrites'],_0x276a2d))return null;{const _0x415dac=ve(_0x268e63['visibleWrites'],_0x276a2d);return Ti(_0x415dac)?_0x812345['getChild'](_0x4bd7fd):nt(_0x415dac,_0x812345['getChild'](_0x4bd7fd));}}function yu(_0x12a571,_0x432cdd,_0x4b4232,_0x2b1a1f){const _0x574a56=k(_0x432cdd,_0x4b4232),_0x1220c4=$e(_0x12a571['visibleWrites'],_0x574a56);if(_0x1220c4!=null)return _0x1220c4;if(_0x2b1a1f['isCompleteForChild'](_0x4b4232)){const _0x1058b1=ve(_0x12a571['visibleWrites'],_0x574a56);return nt(_0x1058b1,_0x2b1a1f['getNode']()['getImmediateChild'](_0x4b4232));}else return null;}function vu(_0x42f6ec,_0x2dc75c){return $e(_0x42f6ec['visibleWrites'],_0x2dc75c);}function Eu(_0x9116c2,_0x3b485c,_0x13b13f,_0x28d3b7,_0xa66724,_0x54b5cf,_0x2cb029){let _0x2ceb6d;const _0x3861b6=ve(_0x9116c2['visibleWrites'],_0x3b485c),_0x315639=$e(_0x3861b6,w());if(_0x315639!=null)_0x2ceb6d=_0x315639;else{if(_0x13b13f!=null)_0x2ceb6d=nt(_0x3861b6,_0x13b13f);else return[];}if(_0x2ceb6d=_0x2ceb6d['withIndex'](_0x2cb029),!_0x2ceb6d['isEmpty']()&&!_0x2ceb6d['isLeafNode']()){const _0x807fe6=[],_0x8a0eab=_0x2cb029['getCompare'](),_0x297c8e=_0x54b5cf?_0x2ceb6d['getReverseIteratorFrom'](_0x28d3b7,_0x2cb029):_0x2ceb6d['getIteratorFrom'](_0x28d3b7,_0x2cb029);let _0x54cda8=_0x297c8e['getNext']();for(;_0x54cda8&&_0x807fe6['length']<_0xa66724;)_0x8a0eab(_0x54cda8,_0x28d3b7)!==0x0&&_0x807fe6['push'](_0x54cda8),_0x54cda8=_0x297c8e['getNext']();return _0x807fe6;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x5dca41,_0x100009,_0x48e849,_0x49760c){return Vo(_0x5dca41['writeTree'],_0x5dca41['treePath'],_0x100009,_0x48e849,_0x49760c);}function ns(_0x3b8025,_0x29fddd){return gu(_0x3b8025['writeTree'],_0x3b8025['treePath'],_0x29fddd);}function lr(_0x5b1ea1,_0x4358a5,_0x58dd95,_0x17945f){return mu(_0x5b1ea1['writeTree'],_0x5b1ea1['treePath'],_0x4358a5,_0x58dd95,_0x17945f);}function vn(_0x2fbdc5,_0x27366a){return vu(_0x2fbdc5['writeTree'],k(_0x2fbdc5['treePath'],_0x27366a));}function wu(_0x56e088,_0x55a101,_0xd71bfd,_0x3772af,_0x172929,_0x20fe8f){return Eu(_0x56e088['writeTree'],_0x56e088['treePath'],_0x55a101,_0xd71bfd,_0x3772af,_0x172929,_0x20fe8f);}function is(_0x636747,_0x509055,_0x969aad){return yu(_0x636747['writeTree'],_0x636747['treePath'],_0x509055,_0x969aad);}function Ho(_0x5caa25,_0x280b3b){return $o(k(_0x5caa25['treePath'],_0x280b3b),_0x5caa25['writeTree']);}function $o(_0x4ac01e,_0x336eb5){return{'treePath':_0x4ac01e,'writeTree':_0x336eb5};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x158948){const _0x3927f2=_0x158948['type'],_0x52aa16=_0x158948['childName'];f(_0x3927f2==='child_added'||_0x3927f2==='child_changed'||_0x3927f2==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x52aa16!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x4f28c7=this['changeMap']['get'](_0x52aa16);if(_0x4f28c7){const _0x28eb10=_0x4f28c7['type'];if(_0x3927f2==='child_added'&&_0x28eb10==='child_removed')this['changeMap']['set'](_0x52aa16,Dt(_0x52aa16,_0x158948['snapshotNode'],_0x4f28c7['snapshotNode']));else{if(_0x3927f2==='child_removed'&&_0x28eb10==='child_added')this['changeMap']['delete'](_0x52aa16);else{if(_0x3927f2==='child_removed'&&_0x28eb10==='child_changed')this['changeMap']['set'](_0x52aa16,Ot(_0x52aa16,_0x4f28c7['oldSnap']));else{if(_0x3927f2==='child_changed'&&_0x28eb10==='child_added')this['changeMap']['set'](_0x52aa16,et(_0x52aa16,_0x158948['snapshotNode']));else{if(_0x3927f2==='child_changed'&&_0x28eb10==='child_changed')this['changeMap']['set'](_0x52aa16,Dt(_0x52aa16,_0x158948['snapshotNode'],_0x4f28c7['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x158948+'\x20occurred\x20after\x20'+_0x4f28c7);}}}}}else this['changeMap']['set'](_0x52aa16,_0x158948);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x181ce4){return null;}['getChildAfterChild'](_0x51db49,_0x2815a0,_0x24b388){return null;}}const Go=new Tu();class ss{constructor(_0x2a4445,_0x48fa30,_0x2fe2d0=null){this['writes_']=_0x2a4445,this['viewCache_']=_0x48fa30,this['optCompleteServerCache_']=_0x2fe2d0;}['getCompleteChild'](_0x396547){const _0x306971=this['viewCache_']['eventCache'];if(_0x306971['isCompleteForChild'](_0x396547))return _0x306971['getNode']()['getImmediateChild'](_0x396547);{const _0x3081f0=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x396547,_0x3081f0);}}['getChildAfterChild'](_0xf76743,_0x1661ba,_0x367d2d){const _0xe9d626=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x7e15c8=wu(this['writes_'],_0xe9d626,_0x1661ba,0x1,_0x367d2d,_0xf76743);return _0x7e15c8['length']===0x0?null:_0x7e15c8[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0xf371bb){return{'filter':_0xf371bb};}function bu(_0x351865,_0x23d6d9){f(_0x23d6d9['eventCache']['getNode']()['isIndexed'](_0x351865['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x23d6d9['serverCache']['getNode']()['isIndexed'](_0x351865['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x24fa46,_0x583ae6,_0x3271eb,_0x3a7034,_0x125fcc){const _0x5ecd53=new Cu();let _0x2a161e,_0x1722ea;if(_0x3271eb['type']===j['OVERWRITE']){const _0x39c9ea=_0x3271eb;_0x39c9ea['source']['fromUser']?_0x2a161e=Si(_0x24fa46,_0x583ae6,_0x39c9ea['path'],_0x39c9ea['snap'],_0x3a7034,_0x125fcc,_0x5ecd53):(f(_0x39c9ea['source']['fromServer'],'Unknown\x20source.'),_0x1722ea=_0x39c9ea['source']['tagged']||_0x583ae6['serverCache']['isFiltered']()&&!v(_0x39c9ea['path']),_0x2a161e=En(_0x24fa46,_0x583ae6,_0x39c9ea['path'],_0x39c9ea['snap'],_0x3a7034,_0x125fcc,_0x1722ea,_0x5ecd53));}else{if(_0x3271eb['type']===j['MERGE']){const _0x3c0391=_0x3271eb;_0x3c0391['source']['fromUser']?_0x2a161e=ku(_0x24fa46,_0x583ae6,_0x3c0391['path'],_0x3c0391['children'],_0x3a7034,_0x125fcc,_0x5ecd53):(f(_0x3c0391['source']['fromServer'],'Unknown\x20source.'),_0x1722ea=_0x3c0391['source']['tagged']||_0x583ae6['serverCache']['isFiltered'](),_0x2a161e=bi(_0x24fa46,_0x583ae6,_0x3c0391['path'],_0x3c0391['children'],_0x3a7034,_0x125fcc,_0x1722ea,_0x5ecd53));}else{if(_0x3271eb['type']===j['ACK_USER_WRITE']){const _0x461bf5=_0x3271eb;_0x461bf5['revert']?_0x2a161e=Ou(_0x24fa46,_0x583ae6,_0x461bf5['path'],_0x3a7034,_0x125fcc,_0x5ecd53):_0x2a161e=Nu(_0x24fa46,_0x583ae6,_0x461bf5['path'],_0x461bf5['affectedTree'],_0x3a7034,_0x125fcc,_0x5ecd53);}else{if(_0x3271eb['type']===j['LISTEN_COMPLETE'])_0x2a161e=Pu(_0x24fa46,_0x583ae6,_0x3271eb['path'],_0x3a7034,_0x5ecd53);else throw rt('Unknown\x20operation\x20type:\x20'+_0x3271eb['type']);}}}const _0x2597ae=_0x5ecd53['getChanges']();return Au(_0x583ae6,_0x2a161e,_0x2597ae),{'viewCache':_0x2a161e,'changes':_0x2597ae};}function Au(_0x2e93b8,_0x350389,_0x3f12db){const _0x3305f2=_0x350389['eventCache'];if(_0x3305f2['isFullyInitialized']()){const _0x2cf2c7=_0x3305f2['getNode']()['isLeafNode']()||_0x3305f2['getNode']()['isEmpty'](),_0x482ccd=mn(_0x2e93b8);(_0x3f12db['length']>0x0||!_0x2e93b8['eventCache']['isFullyInitialized']()||_0x2cf2c7&&!_0x3305f2['getNode']()['equals'](_0x482ccd)||!_0x3305f2['getNode']()['getPriority']()['equals'](_0x482ccd['getPriority']()))&&_0x3f12db['push'](Lo(mn(_0x350389)));}}function qo(_0x1bc2f6,_0xe4ec2e,_0x52900e,_0x5e5800,_0x15f38d,_0x21fba0){const _0x119062=_0xe4ec2e['eventCache'];if(vn(_0x5e5800,_0x52900e)!=null)return _0xe4ec2e;{let _0x235059,_0x2b4f98;if(v(_0x52900e)){if(f(_0xe4ec2e['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0xe4ec2e['serverCache']['isFiltered']()){const _0x37b51f=We(_0xe4ec2e),_0x1cfb22=_0x37b51f instanceof g?_0x37b51f:g['EMPTY_NODE'],_0x59fbc3=ns(_0x5e5800,_0x1cfb22);_0x235059=_0x1bc2f6['filter']['updateFullNode'](_0xe4ec2e['eventCache']['getNode'](),_0x59fbc3,_0x21fba0);}else{const _0x29b2c8=yn(_0x5e5800,We(_0xe4ec2e));_0x235059=_0x1bc2f6['filter']['updateFullNode'](_0xe4ec2e['eventCache']['getNode'](),_0x29b2c8,_0x21fba0);}}else{const _0xd53294=y(_0x52900e);if(_0xd53294==='.priority'){f(we(_0x52900e)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x287f06=_0x119062['getNode']();_0x2b4f98=_0xe4ec2e['serverCache']['getNode']();const _0x3b1d66=lr(_0x5e5800,_0x52900e,_0x287f06,_0x2b4f98);_0x3b1d66!=null?_0x235059=_0x1bc2f6['filter']['updatePriority'](_0x287f06,_0x3b1d66):_0x235059=_0x119062['getNode']();}else{const _0x53151e=b(_0x52900e);let _0x450b3f;if(_0x119062['isCompleteForChild'](_0xd53294)){_0x2b4f98=_0xe4ec2e['serverCache']['getNode']();const _0x599332=lr(_0x5e5800,_0x52900e,_0x119062['getNode'](),_0x2b4f98);_0x599332!=null?_0x450b3f=_0x119062['getNode']()['getImmediateChild'](_0xd53294)['updateChild'](_0x53151e,_0x599332):_0x450b3f=_0x119062['getNode']()['getImmediateChild'](_0xd53294);}else _0x450b3f=is(_0x5e5800,_0xd53294,_0xe4ec2e['serverCache']);_0x450b3f!=null?_0x235059=_0x1bc2f6['filter']['updateChild'](_0x119062['getNode'](),_0xd53294,_0x450b3f,_0x53151e,_0x15f38d,_0x21fba0):_0x235059=_0x119062['getNode']();}}return Tt(_0xe4ec2e,_0x235059,_0x119062['isFullyInitialized']()||v(_0x52900e),_0x1bc2f6['filter']['filtersNodes']());}}function En(_0x510b84,_0xae2240,_0xfd22d,_0x3c6364,_0x2f2028,_0x1ed1a8,_0x1853d0,_0x3f95c9){const _0x3fb2e0=_0xae2240['serverCache'];let _0x1c9a37;const _0x3efcd5=_0x1853d0?_0x510b84['filter']:_0x510b84['filter']['getIndexedFilter']();if(v(_0xfd22d))_0x1c9a37=_0x3efcd5['updateFullNode'](_0x3fb2e0['getNode'](),_0x3c6364,null);else{if(_0x3efcd5['filtersNodes']()&&!_0x3fb2e0['isFiltered']()){const _0x5e97d7=_0x3fb2e0['getNode']()['updateChild'](_0xfd22d,_0x3c6364);_0x1c9a37=_0x3efcd5['updateFullNode'](_0x3fb2e0['getNode'](),_0x5e97d7,null);}else{const _0x3739fd=y(_0xfd22d);if(!_0x3fb2e0['isCompleteForPath'](_0xfd22d)&&we(_0xfd22d)>0x1)return _0xae2240;const _0x288d30=b(_0xfd22d),_0x3b6a1b=_0x3fb2e0['getNode']()['getImmediateChild'](_0x3739fd)['updateChild'](_0x288d30,_0x3c6364);_0x3739fd==='.priority'?_0x1c9a37=_0x3efcd5['updatePriority'](_0x3fb2e0['getNode'](),_0x3b6a1b):_0x1c9a37=_0x3efcd5['updateChild'](_0x3fb2e0['getNode'](),_0x3739fd,_0x3b6a1b,_0x288d30,Go,null);}}const _0x13bd4b=Uo(_0xae2240,_0x1c9a37,_0x3fb2e0['isFullyInitialized']()||v(_0xfd22d),_0x3efcd5['filtersNodes']()),_0x374a2c=new ss(_0x2f2028,_0x13bd4b,_0x1ed1a8);return qo(_0x510b84,_0x13bd4b,_0xfd22d,_0x2f2028,_0x374a2c,_0x3f95c9);}function Si(_0x5b3bcd,_0xfac89,_0x198782,_0x3ba111,_0x213a44,_0x1cb706,_0x389eb2){const _0x42462f=_0xfac89['eventCache'];let _0x4f02d4,_0xc6f123;const _0xd28909=new ss(_0x213a44,_0xfac89,_0x1cb706);if(v(_0x198782))_0xc6f123=_0x5b3bcd['filter']['updateFullNode'](_0xfac89['eventCache']['getNode'](),_0x3ba111,_0x389eb2),_0x4f02d4=Tt(_0xfac89,_0xc6f123,!0x0,_0x5b3bcd['filter']['filtersNodes']());else{const _0x29810a=y(_0x198782);if(_0x29810a==='.priority')_0xc6f123=_0x5b3bcd['filter']['updatePriority'](_0xfac89['eventCache']['getNode'](),_0x3ba111),_0x4f02d4=Tt(_0xfac89,_0xc6f123,_0x42462f['isFullyInitialized'](),_0x42462f['isFiltered']());else{const _0x18ac0e=b(_0x198782),_0x54f049=_0x42462f['getNode']()['getImmediateChild'](_0x29810a);let _0x3ccd1b;if(v(_0x18ac0e))_0x3ccd1b=_0x3ba111;else{const _0x46f03c=_0xd28909['getCompleteChild'](_0x29810a);_0x46f03c!=null?zi(_0x18ac0e)==='.priority'&&_0x46f03c['getChild'](Ro(_0x18ac0e))['isEmpty']()?_0x3ccd1b=_0x46f03c:_0x3ccd1b=_0x46f03c['updateChild'](_0x18ac0e,_0x3ba111):_0x3ccd1b=g['EMPTY_NODE'];}if(_0x54f049['equals'](_0x3ccd1b))_0x4f02d4=_0xfac89;else{const _0x50fe30=_0x5b3bcd['filter']['updateChild'](_0x42462f['getNode'](),_0x29810a,_0x3ccd1b,_0x18ac0e,_0xd28909,_0x389eb2);_0x4f02d4=Tt(_0xfac89,_0x50fe30,_0x42462f['isFullyInitialized'](),_0x5b3bcd['filter']['filtersNodes']());}}}return _0x4f02d4;}function hr(_0x329f60,_0x3e27b1){return _0x329f60['eventCache']['isCompleteForChild'](_0x3e27b1);}function ku(_0x1bad54,_0x772139,_0x30c4ed,_0x21316c,_0x24cf01,_0x5713a1,_0x3f5071){let _0x1e9561=_0x772139;return _0x21316c['foreach']((_0x5663d6,_0x5db5ea)=>{const _0x5b1e86=k(_0x30c4ed,_0x5663d6);hr(_0x772139,y(_0x5b1e86))&&(_0x1e9561=Si(_0x1bad54,_0x1e9561,_0x5b1e86,_0x5db5ea,_0x24cf01,_0x5713a1,_0x3f5071));}),_0x21316c['foreach']((_0x372180,_0xf0aa8c)=>{const _0x5db074=k(_0x30c4ed,_0x372180);hr(_0x772139,y(_0x5db074))||(_0x1e9561=Si(_0x1bad54,_0x1e9561,_0x5db074,_0xf0aa8c,_0x24cf01,_0x5713a1,_0x3f5071));}),_0x1e9561;}function ur(_0x67ca,_0x1e5905,_0x36b04b){return _0x36b04b['foreach']((_0x173d37,_0x20c789)=>{_0x1e5905=_0x1e5905['updateChild'](_0x173d37,_0x20c789);}),_0x1e5905;}function bi(_0x4ccbc6,_0x324476,_0x2d0d2f,_0x55c9bd,_0x11d4a0,_0x45e22c,_0x36cf37,_0x4cc6ca){if(_0x324476['serverCache']['getNode']()['isEmpty']()&&!_0x324476['serverCache']['isFullyInitialized']())return _0x324476;let _0x51d74a=_0x324476,_0x43fa44;v(_0x2d0d2f)?_0x43fa44=_0x55c9bd:_0x43fa44=new S(null)['setTree'](_0x2d0d2f,_0x55c9bd);const _0x10e956=_0x324476['serverCache']['getNode']();return _0x43fa44['children']['inorderTraversal']((_0x12df5d,_0x48ebf8)=>{if(_0x10e956['hasChild'](_0x12df5d)){const _0x48d96b=_0x324476['serverCache']['getNode']()['getImmediateChild'](_0x12df5d),_0xb07a32=ur(_0x4ccbc6,_0x48d96b,_0x48ebf8);_0x51d74a=En(_0x4ccbc6,_0x51d74a,new C(_0x12df5d),_0xb07a32,_0x11d4a0,_0x45e22c,_0x36cf37,_0x4cc6ca);}}),_0x43fa44['children']['inorderTraversal']((_0xe35cce,_0x59c018)=>{const _0x1ac854=!_0x324476['serverCache']['isCompleteForChild'](_0xe35cce)&&_0x59c018['value']===null;if(!_0x10e956['hasChild'](_0xe35cce)&&!_0x1ac854){const _0x4ea3cf=_0x324476['serverCache']['getNode']()['getImmediateChild'](_0xe35cce),_0x597d37=ur(_0x4ccbc6,_0x4ea3cf,_0x59c018);_0x51d74a=En(_0x4ccbc6,_0x51d74a,new C(_0xe35cce),_0x597d37,_0x11d4a0,_0x45e22c,_0x36cf37,_0x4cc6ca);}}),_0x51d74a;}function Nu(_0x346e9d,_0x537a84,_0x475547,_0x25824b,_0x43dd21,_0x48cb86,_0x234222){if(vn(_0x43dd21,_0x475547)!=null)return _0x537a84;const _0x23defb=_0x537a84['serverCache']['isFiltered'](),_0x3b6b35=_0x537a84['serverCache'];if(_0x25824b['value']!=null){if(v(_0x475547)&&_0x3b6b35['isFullyInitialized']()||_0x3b6b35['isCompleteForPath'](_0x475547))return En(_0x346e9d,_0x537a84,_0x475547,_0x3b6b35['getNode']()['getChild'](_0x475547),_0x43dd21,_0x48cb86,_0x23defb,_0x234222);if(v(_0x475547)){let _0x4f23ef=new S(null);return _0x3b6b35['getNode']()['forEachChild'](ye,(_0x4a9b3c,_0x39e272)=>{_0x4f23ef=_0x4f23ef['set'](new C(_0x4a9b3c),_0x39e272);}),bi(_0x346e9d,_0x537a84,_0x475547,_0x4f23ef,_0x43dd21,_0x48cb86,_0x23defb,_0x234222);}else return _0x537a84;}else{let _0x2fcafe=new S(null);return _0x25824b['foreach']((_0x5d2450,_0x14bc22)=>{const _0x24af0a=k(_0x475547,_0x5d2450);_0x3b6b35['isCompleteForPath'](_0x24af0a)&&(_0x2fcafe=_0x2fcafe['set'](_0x5d2450,_0x3b6b35['getNode']()['getChild'](_0x24af0a)));}),bi(_0x346e9d,_0x537a84,_0x475547,_0x2fcafe,_0x43dd21,_0x48cb86,_0x23defb,_0x234222);}}function Pu(_0x7c1d90,_0x111f1c,_0x208eca,_0x244a8d,_0x509f37){const _0x3f16be=_0x111f1c['serverCache'],_0x12809a=Uo(_0x111f1c,_0x3f16be['getNode'](),_0x3f16be['isFullyInitialized']()||v(_0x208eca),_0x3f16be['isFiltered']());return qo(_0x7c1d90,_0x12809a,_0x208eca,_0x244a8d,Go,_0x509f37);}function Ou(_0x512e3b,_0x5b29b3,_0x196108,_0x199a6a,_0x2d9bf5,_0xa264db){let _0x2d87bb;if(vn(_0x199a6a,_0x196108)!=null)return _0x5b29b3;{const _0x93b858=new ss(_0x199a6a,_0x5b29b3,_0x2d9bf5),_0x59b305=_0x5b29b3['eventCache']['getNode']();let _0x4378f2;if(v(_0x196108)||y(_0x196108)==='.priority'){let _0xae1725;if(_0x5b29b3['serverCache']['isFullyInitialized']())_0xae1725=yn(_0x199a6a,We(_0x5b29b3));else{const _0x5d66d2=_0x5b29b3['serverCache']['getNode']();f(_0x5d66d2 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0xae1725=ns(_0x199a6a,_0x5d66d2);}_0xae1725=_0xae1725,_0x4378f2=_0x512e3b['filter']['updateFullNode'](_0x59b305,_0xae1725,_0xa264db);}else{const _0x49e756=y(_0x196108);let _0x1f90fe=is(_0x199a6a,_0x49e756,_0x5b29b3['serverCache']);_0x1f90fe==null&&_0x5b29b3['serverCache']['isCompleteForChild'](_0x49e756)&&(_0x1f90fe=_0x59b305['getImmediateChild'](_0x49e756)),_0x1f90fe!=null?_0x4378f2=_0x512e3b['filter']['updateChild'](_0x59b305,_0x49e756,_0x1f90fe,b(_0x196108),_0x93b858,_0xa264db):_0x5b29b3['eventCache']['getNode']()['hasChild'](_0x49e756)?_0x4378f2=_0x512e3b['filter']['updateChild'](_0x59b305,_0x49e756,g['EMPTY_NODE'],b(_0x196108),_0x93b858,_0xa264db):_0x4378f2=_0x59b305,_0x4378f2['isEmpty']()&&_0x5b29b3['serverCache']['isFullyInitialized']()&&(_0x2d87bb=yn(_0x199a6a,We(_0x5b29b3)),_0x2d87bb['isLeafNode']()&&(_0x4378f2=_0x512e3b['filter']['updateFullNode'](_0x4378f2,_0x2d87bb,_0xa264db)));}return _0x2d87bb=_0x5b29b3['serverCache']['isFullyInitialized']()||vn(_0x199a6a,w())!=null,Tt(_0x5b29b3,_0x4378f2,_0x2d87bb,_0x512e3b['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x455948,_0x598d65){this['query_']=_0x455948,this['eventRegistrations_']=[];const _0xaaac0e=this['query_']['_queryParams'],_0x5dacfc=new Ji(_0xaaac0e['getIndex']()),_0x569108=Kh(_0xaaac0e);this['processor_']=Su(_0x569108);const _0x2150c2=_0x598d65['serverCache'],_0x1d9dba=_0x598d65['eventCache'],_0x148c43=_0x5dacfc['updateFullNode'](g['EMPTY_NODE'],_0x2150c2['getNode'](),null),_0x5ec735=_0x569108['updateFullNode'](g['EMPTY_NODE'],_0x1d9dba['getNode'](),null),_0x59ca85=new Ce(_0x148c43,_0x2150c2['isFullyInitialized'](),_0x5dacfc['filtersNodes']()),_0x3d920d=new Ce(_0x5ec735,_0x1d9dba['isFullyInitialized'](),_0x569108['filtersNodes']());this['viewCache_']=Mn(_0x3d920d,_0x59ca85),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x1ee529){return _0x1ee529['viewCache_']['serverCache']['getNode']();}function Lu(_0x4d6d24){return mn(_0x4d6d24['viewCache_']);}function xu(_0x445a00,_0xa15d4e){const _0x2e7f5f=We(_0x445a00['viewCache_']);return _0x2e7f5f&&(_0x445a00['query']['_queryParams']['loadsAllData']()||!v(_0xa15d4e)&&!_0x2e7f5f['getImmediateChild'](y(_0xa15d4e))['isEmpty']())?_0x2e7f5f['getChild'](_0xa15d4e):null;}function dr(_0xeca6b1){return _0xeca6b1['eventRegistrations_']['length']===0x0;}function Fu(_0x27d280,_0x287c99){_0x27d280['eventRegistrations_']['push'](_0x287c99);}function fr(_0x546a7f,_0x5ad0cd,_0xd733e){const _0x2959f7=[];if(_0xd733e){f(_0x5ad0cd==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x56bccb=_0x546a7f['query']['_path'];_0x546a7f['eventRegistrations_']['forEach'](_0x26a1ac=>{const _0x18309f=_0x26a1ac['createCancelEvent'](_0xd733e,_0x56bccb);_0x18309f&&_0x2959f7['push'](_0x18309f);});}if(_0x5ad0cd){let _0x4f4092=[];for(let _0x5d9064=0x0;_0x5d9064<_0x546a7f['eventRegistrations_']['length'];++_0x5d9064){const _0x40433e=_0x546a7f['eventRegistrations_'][_0x5d9064];if(!_0x40433e['matches'](_0x5ad0cd))_0x4f4092['push'](_0x40433e);else{if(_0x5ad0cd['hasAnyCallback']()){_0x4f4092=_0x4f4092['concat'](_0x546a7f['eventRegistrations_']['slice'](_0x5d9064+0x1));break;}}}_0x546a7f['eventRegistrations_']=_0x4f4092;}else _0x546a7f['eventRegistrations_']=[];return _0x2959f7;}function pr(_0x5d1aea,_0x57bc45,_0x2ea3a6,_0x3a2e71){_0x57bc45['type']===j['MERGE']&&_0x57bc45['source']['queryId']!==null&&(f(We(_0x5d1aea['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x5d1aea['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x52a369=_0x5d1aea['viewCache_'],_0x2be898=Ru(_0x5d1aea['processor_'],_0x52a369,_0x57bc45,_0x2ea3a6,_0x3a2e71);return bu(_0x5d1aea['processor_'],_0x2be898['viewCache']),f(_0x2be898['viewCache']['serverCache']['isFullyInitialized']()||!_0x52a369['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x5d1aea['viewCache_']=_0x2be898['viewCache'],zo(_0x5d1aea,_0x2be898['changes'],_0x2be898['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x3cf75b,_0x3e5295){const _0x11a885=_0x3cf75b['viewCache_']['eventCache'],_0x1289a2=[];return _0x11a885['getNode']()['isLeafNode']()||_0x11a885['getNode']()['forEachChild'](R,(_0x1511ae,_0xd11276)=>{_0x1289a2['push'](et(_0x1511ae,_0xd11276));}),_0x11a885['isFullyInitialized']()&&_0x1289a2['push'](Lo(_0x11a885['getNode']())),zo(_0x3cf75b,_0x1289a2,_0x11a885['getNode'](),_0x3e5295);}function zo(_0x4e5047,_0x374477,_0x40a584,_0xfcd5a1){const _0x30f0f5=_0xfcd5a1?[_0xfcd5a1]:_0x4e5047['eventRegistrations_'];return ru(_0x4e5047['eventGenerator_'],_0x374477,_0x40a584,_0x30f0f5);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x316b73){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x316b73;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x14fc62){return _0x14fc62['views']['size']===0x0;}function rs(_0x5ed2be,_0x7a84f3,_0xaa2626,_0x4306b6){const _0x363b21=_0x7a84f3['source']['queryId'];if(_0x363b21!==null){const _0x469129=_0x5ed2be['views']['get'](_0x363b21);return f(_0x469129!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x469129,_0x7a84f3,_0xaa2626,_0x4306b6);}else{let _0x5e8e06=[];for(const _0x39209b of _0x5ed2be['views']['values']())_0x5e8e06=_0x5e8e06['concat'](pr(_0x39209b,_0x7a84f3,_0xaa2626,_0x4306b6));return _0x5e8e06;}}function Ko(_0xe34d37,_0x5b314e,_0x24ac2a,_0x3f4a5b,_0x5cc450){const _0x5b90f7=_0x5b314e['_queryIdentifier'],_0x47fa8b=_0xe34d37['views']['get'](_0x5b90f7);if(!_0x47fa8b){let _0x3e7dee=yn(_0x24ac2a,_0x5cc450?_0x3f4a5b:null),_0x2790b4=!0x1;_0x3e7dee?_0x2790b4=!0x0:_0x3f4a5b instanceof g?(_0x3e7dee=ns(_0x24ac2a,_0x3f4a5b),_0x2790b4=!0x1):(_0x3e7dee=g['EMPTY_NODE'],_0x2790b4=!0x1);const _0x3b865d=Mn(new Ce(_0x3e7dee,_0x2790b4,!0x1),new Ce(_0x3f4a5b,_0x5cc450,!0x1));return new Du(_0x5b314e,_0x3b865d);}return _0x47fa8b;}function Hu(_0x13de82,_0x472926,_0x4d0e2c,_0x1eef73,_0x550a50,_0x686eb1){const _0x5858ff=Ko(_0x13de82,_0x472926,_0x1eef73,_0x550a50,_0x686eb1);return _0x13de82['views']['has'](_0x472926['_queryIdentifier'])||_0x13de82['views']['set'](_0x472926['_queryIdentifier'],_0x5858ff),Fu(_0x5858ff,_0x4d0e2c),Uu(_0x5858ff,_0x4d0e2c);}function $u(_0xbc331c,_0x29a300,_0xf36110,_0x5b4bdf){const _0x51858f=_0x29a300['_queryIdentifier'],_0x270717=[];let _0x38d9eb=[];const _0x28c115=Te(_0xbc331c);if(_0x51858f==='default'){for(const [_0xb722c8,_0xed1964]of _0xbc331c['views']['entries']())_0x38d9eb=_0x38d9eb['concat'](fr(_0xed1964,_0xf36110,_0x5b4bdf)),dr(_0xed1964)&&(_0xbc331c['views']['delete'](_0xb722c8),_0xed1964['query']['_queryParams']['loadsAllData']()||_0x270717['push'](_0xed1964['query']));}else{const _0x4d361c=_0xbc331c['views']['get'](_0x51858f);_0x4d361c&&(_0x38d9eb=_0x38d9eb['concat'](fr(_0x4d361c,_0xf36110,_0x5b4bdf)),dr(_0x4d361c)&&(_0xbc331c['views']['delete'](_0x51858f),_0x4d361c['query']['_queryParams']['loadsAllData']()||_0x270717['push'](_0x4d361c['query'])));}return _0x28c115&&!Te(_0xbc331c)&&_0x270717['push'](new(Bu())(_0x29a300['_repo'],_0x29a300['_path'])),{'removed':_0x270717,'events':_0x38d9eb};}function Yo(_0x337060){const _0x59fd1c=[];for(const _0x109243 of _0x337060['views']['values']())_0x109243['query']['_queryParams']['loadsAllData']()||_0x59fd1c['push'](_0x109243);return _0x59fd1c;}function Ee(_0x3980e8,_0x177eaf){let _0xddde6d=null;for(const _0x44945d of _0x3980e8['views']['values']())_0xddde6d=_0xddde6d||xu(_0x44945d,_0x177eaf);return _0xddde6d;}function Qo(_0x29f173,_0x3415b0){if(_0x3415b0['_queryParams']['loadsAllData']())return xn(_0x29f173);{const _0x33d443=_0x3415b0['_queryIdentifier'];return _0x29f173['views']['get'](_0x33d443);}}function Jo(_0xd2f01b,_0x469ecc){return Qo(_0xd2f01b,_0x469ecc)!=null;}function Te(_0x380a35){return xn(_0x380a35)!=null;}function xn(_0xa4d16e){for(const _0x424cb2 of _0xa4d16e['views']['values']())if(_0x424cb2['query']['_queryParams']['loadsAllData']())return _0x424cb2;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x459ca7){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x459ca7;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x2f312c){this['listenProvider_']=_0x2f312c,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x4bc216,_0x4dceea,_0x389c8a,_0x259ca2,_0x1b792f){return lu(_0x4bc216['pendingWriteTree_'],_0x4dceea,_0x389c8a,_0x259ca2,_0x1b792f),_0x1b792f?ut(_0x4bc216,new Ue(Zi(),_0x4dceea,_0x389c8a)):[];}function ju(_0x3c2e59,_0x776e63,_0x2d1a97,_0x2105ba){hu(_0x3c2e59['pendingWriteTree_'],_0x776e63,_0x2d1a97,_0x2105ba);const _0x1debb1=S['fromObject'](_0x2d1a97);return ut(_0x3c2e59,new tt(Zi(),_0x776e63,_0x1debb1));}function pe(_0x27b1c6,_0x2e1295,_0x2f3da4=!0x1){const _0x3cdf0a=uu(_0x27b1c6['pendingWriteTree_'],_0x2e1295);if(du(_0x27b1c6['pendingWriteTree_'],_0x2e1295)){let _0x13c82=new S(null);return _0x3cdf0a['snap']!=null?_0x13c82=_0x13c82['set'](w(),!0x0):x(_0x3cdf0a['children'],_0x30ba42=>{_0x13c82=_0x13c82['set'](new C(_0x30ba42),!0x0);}),ut(_0x27b1c6,new gn(_0x3cdf0a['path'],_0x13c82,_0x2f3da4));}else return[];}function Gt(_0x671138,_0x25b86e,_0x568400){return ut(_0x671138,new Ue(es(),_0x25b86e,_0x568400));}function Ku(_0x2ab41a,_0x15137c,_0x12f43d){const _0x38cf68=S['fromObject'](_0x12f43d);return ut(_0x2ab41a,new tt(es(),_0x15137c,_0x38cf68));}function Yu(_0x3461d4,_0x31a2e2){return ut(_0x3461d4,new Lt(es(),_0x31a2e2));}function Qu(_0x2d57fd,_0x1695ca,_0x418c4c){const _0x3f30c8=as(_0x2d57fd,_0x418c4c);if(_0x3f30c8){const _0x5efb60=cs(_0x3f30c8),_0x25f64a=_0x5efb60['path'],_0x4ebc3c=_0x5efb60['queryId'],_0x3069b0=F(_0x25f64a,_0x1695ca),_0x565e66=new Lt(ts(_0x4ebc3c),_0x3069b0);return ls(_0x2d57fd,_0x25f64a,_0x565e66);}else return[];}function Cn(_0x44d02c,_0x2d04f8,_0x4a56c5,_0x59b5f4,_0x15fba0=!0x1){const _0x1b1155=_0x2d04f8['_path'],_0x34bf87=_0x44d02c['syncPointTree_']['get'](_0x1b1155);let _0xcf0f79=[];if(_0x34bf87&&(_0x2d04f8['_queryIdentifier']==='default'||Jo(_0x34bf87,_0x2d04f8))){const _0x189a82=$u(_0x34bf87,_0x2d04f8,_0x4a56c5,_0x59b5f4);Vu(_0x34bf87)&&(_0x44d02c['syncPointTree_']=_0x44d02c['syncPointTree_']['remove'](_0x1b1155));const _0x1f24bd=_0x189a82['removed'];if(_0xcf0f79=_0x189a82['events'],!_0x15fba0){const _0x2596b3=_0x1f24bd['findIndex'](_0x50a195=>_0x50a195['_queryParams']['loadsAllData']())!==-0x1,_0x4bfb78=_0x44d02c['syncPointTree_']['findOnPath'](_0x1b1155,(_0x146cf1,_0x2f8822)=>Te(_0x2f8822));if(_0x2596b3&&!_0x4bfb78){const _0x2a664f=_0x44d02c['syncPointTree_']['subtree'](_0x1b1155);if(!_0x2a664f['isEmpty']()){const _0x2d31c1=Zu(_0x2a664f);for(let _0x3e319f=0x0;_0x3e319f<_0x2d31c1['length'];++_0x3e319f){const _0x1c5627=_0x2d31c1[_0x3e319f],_0x5c5096=_0x1c5627['query'],_0x4c34d6=ta(_0x44d02c,_0x1c5627);_0x44d02c['listenProvider_']['startListening'](bt(_0x5c5096),xt(_0x44d02c,_0x5c5096),_0x4c34d6['hashFn'],_0x4c34d6['onComplete']);}}}!_0x4bfb78&&_0x1f24bd['length']>0x0&&!_0x59b5f4&&(_0x2596b3?_0x44d02c['listenProvider_']['stopListening'](bt(_0x2d04f8),null):_0x1f24bd['forEach'](_0x1f7049=>{const _0x4b3fc6=_0x44d02c['queryToTagMap']['get'](Un(_0x1f7049));_0x44d02c['listenProvider_']['stopListening'](bt(_0x1f7049),_0x4b3fc6);}));}ed(_0x44d02c,_0x1f24bd);}return _0xcf0f79;}function Xo(_0x5112b7,_0x1cd7aa,_0x539bc9,_0x3e6183){const _0x3090ea=as(_0x5112b7,_0x3e6183);if(_0x3090ea!=null){const _0x552e3c=cs(_0x3090ea),_0x247f97=_0x552e3c['path'],_0x18e2c8=_0x552e3c['queryId'],_0x3b0951=F(_0x247f97,_0x1cd7aa),_0x1b19d2=new Ue(ts(_0x18e2c8),_0x3b0951,_0x539bc9);return ls(_0x5112b7,_0x247f97,_0x1b19d2);}else return[];}function Ju(_0x1f8a34,_0x35a41d,_0x1d2dc8,_0x171a21){const _0x3a1bb2=as(_0x1f8a34,_0x171a21);if(_0x3a1bb2){const _0xec14ad=cs(_0x3a1bb2),_0x2791fc=_0xec14ad['path'],_0x409ec3=_0xec14ad['queryId'],_0x5d071e=F(_0x2791fc,_0x35a41d),_0x5499b6=S['fromObject'](_0x1d2dc8),_0x927951=new tt(ts(_0x409ec3),_0x5d071e,_0x5499b6);return ls(_0x1f8a34,_0x2791fc,_0x927951);}else return[];}function Ri(_0x2ee3e1,_0x479607,_0x208c37,_0x16dfab=!0x1){const _0x27b097=_0x479607['_path'];let _0x4fcc09=null,_0x3ece51=!0x1;_0x2ee3e1['syncPointTree_']['foreachOnPath'](_0x27b097,(_0x1a0db7,_0x318483)=>{const _0x64f695=F(_0x1a0db7,_0x27b097);_0x4fcc09=_0x4fcc09||Ee(_0x318483,_0x64f695),_0x3ece51=_0x3ece51||Te(_0x318483);});let _0x16c2de=_0x2ee3e1['syncPointTree_']['get'](_0x27b097);_0x16c2de?(_0x3ece51=_0x3ece51||Te(_0x16c2de),_0x4fcc09=_0x4fcc09||Ee(_0x16c2de,w())):(_0x16c2de=new jo(),_0x2ee3e1['syncPointTree_']=_0x2ee3e1['syncPointTree_']['set'](_0x27b097,_0x16c2de));let _0x40f24f;_0x4fcc09!=null?_0x40f24f=!0x0:(_0x40f24f=!0x1,_0x4fcc09=g['EMPTY_NODE'],_0x2ee3e1['syncPointTree_']['subtree'](_0x27b097)['foreachChild']((_0x2de91a,_0x352d40)=>{const _0x14bbc9=Ee(_0x352d40,w());_0x14bbc9&&(_0x4fcc09=_0x4fcc09['updateImmediateChild'](_0x2de91a,_0x14bbc9));}));const _0x13c707=Jo(_0x16c2de,_0x479607);if(!_0x13c707&&!_0x479607['_queryParams']['loadsAllData']()){const _0x4c4a4e=Un(_0x479607);f(!_0x2ee3e1['queryToTagMap']['has'](_0x4c4a4e),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x2ee71f=td();_0x2ee3e1['queryToTagMap']['set'](_0x4c4a4e,_0x2ee71f),_0x2ee3e1['tagToQueryMap']['set'](_0x2ee71f,_0x4c4a4e);}const _0x22bd6d=Ln(_0x2ee3e1['pendingWriteTree_'],_0x27b097);let _0x5488b0=Hu(_0x16c2de,_0x479607,_0x208c37,_0x22bd6d,_0x4fcc09,_0x40f24f);if(!_0x13c707&&!_0x3ece51&&!_0x16dfab){const _0x2649a6=Qo(_0x16c2de,_0x479607);_0x5488b0=_0x5488b0['concat'](nd(_0x2ee3e1,_0x479607,_0x2649a6));}return _0x5488b0;}function Fn(_0x521c66,_0x4d1222,_0x3b5110){const _0x141329=_0x521c66['pendingWriteTree_'],_0x439284=_0x521c66['syncPointTree_']['findOnPath'](_0x4d1222,(_0x33edff,_0x1a8bea)=>{const _0x51c89e=F(_0x33edff,_0x4d1222),_0x3776e9=Ee(_0x1a8bea,_0x51c89e);if(_0x3776e9)return _0x3776e9;});return Vo(_0x141329,_0x4d1222,_0x439284,_0x3b5110,!0x0);}function Xu(_0x311490,_0xdad6ce){const _0x20ce45=_0xdad6ce['_path'];let _0x594122=null;_0x311490['syncPointTree_']['foreachOnPath'](_0x20ce45,(_0xefb6e7,_0x53f001)=>{const _0x3bb589=F(_0xefb6e7,_0x20ce45);_0x594122=_0x594122||Ee(_0x53f001,_0x3bb589);});let _0x4f41d4=_0x311490['syncPointTree_']['get'](_0x20ce45);_0x4f41d4?_0x594122=_0x594122||Ee(_0x4f41d4,w()):(_0x4f41d4=new jo(),_0x311490['syncPointTree_']=_0x311490['syncPointTree_']['set'](_0x20ce45,_0x4f41d4));const _0xdbe8bb=_0x594122!=null,_0x16938f=_0xdbe8bb?new Ce(_0x594122,!0x0,!0x1):null,_0x152383=Ln(_0x311490['pendingWriteTree_'],_0xdad6ce['_path']),_0x23fc24=Ko(_0x4f41d4,_0xdad6ce,_0x152383,_0xdbe8bb?_0x16938f['getNode']():g['EMPTY_NODE'],_0xdbe8bb);return Lu(_0x23fc24);}function ut(_0x14b8ae,_0x5adec0){return Zo(_0x5adec0,_0x14b8ae['syncPointTree_'],null,Ln(_0x14b8ae['pendingWriteTree_'],w()));}function Zo(_0x573d84,_0x16b4ed,_0x2cf50a,_0x4cce62){if(v(_0x573d84['path']))return ea(_0x573d84,_0x16b4ed,_0x2cf50a,_0x4cce62);{const _0x20af5c=_0x16b4ed['get'](w());_0x2cf50a==null&&_0x20af5c!=null&&(_0x2cf50a=Ee(_0x20af5c,w()));let _0x5c3d16=[];const _0x5c957f=y(_0x573d84['path']),_0x578fa5=_0x573d84['operationForChild'](_0x5c957f),_0x4970d7=_0x16b4ed['children']['get'](_0x5c957f);if(_0x4970d7&&_0x578fa5){const _0x10851d=_0x2cf50a?_0x2cf50a['getImmediateChild'](_0x5c957f):null,_0x4df544=Ho(_0x4cce62,_0x5c957f);_0x5c3d16=_0x5c3d16['concat'](Zo(_0x578fa5,_0x4970d7,_0x10851d,_0x4df544));}return _0x20af5c&&(_0x5c3d16=_0x5c3d16['concat'](rs(_0x20af5c,_0x573d84,_0x4cce62,_0x2cf50a))),_0x5c3d16;}}function ea(_0x552c8e,_0x2c2f02,_0x206739,_0x377c05){const _0x32e159=_0x2c2f02['get'](w());_0x206739==null&&_0x32e159!=null&&(_0x206739=Ee(_0x32e159,w()));let _0x4e8220=[];return _0x2c2f02['children']['inorderTraversal']((_0x4659da,_0x55b41a)=>{const _0xbe61b=_0x206739?_0x206739['getImmediateChild'](_0x4659da):null,_0x4c94f5=Ho(_0x377c05,_0x4659da),_0x233a97=_0x552c8e['operationForChild'](_0x4659da);_0x233a97&&(_0x4e8220=_0x4e8220['concat'](ea(_0x233a97,_0x55b41a,_0xbe61b,_0x4c94f5)));}),_0x32e159&&(_0x4e8220=_0x4e8220['concat'](rs(_0x32e159,_0x552c8e,_0x377c05,_0x206739))),_0x4e8220;}function ta(_0x47e25e,_0x1d4dce){const _0x4f30bc=_0x1d4dce['query'],_0x42da2a=xt(_0x47e25e,_0x4f30bc);return{'hashFn':()=>(Mu(_0x1d4dce)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x36e8f1=>{if(_0x36e8f1==='ok')return _0x42da2a?Qu(_0x47e25e,_0x4f30bc['_path'],_0x42da2a):Yu(_0x47e25e,_0x4f30bc['_path']);{const _0x44c6bd=Kl(_0x36e8f1,_0x4f30bc);return Cn(_0x47e25e,_0x4f30bc,null,_0x44c6bd);}}};}function xt(_0x2b6c34,_0x36039e){const _0x4a91f3=Un(_0x36039e);return _0x2b6c34['queryToTagMap']['get'](_0x4a91f3);}function Un(_0x239153){return _0x239153['_path']['toString']()+'$'+_0x239153['_queryIdentifier'];}function as(_0x4dbcbe,_0x195836){return _0x4dbcbe['tagToQueryMap']['get'](_0x195836);}function cs(_0x193a57){const _0x5e6117=_0x193a57['indexOf']('$');return f(_0x5e6117!==-0x1&&_0x5e6117<_0x193a57['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x193a57['substr'](_0x5e6117+0x1),'path':new C(_0x193a57['substr'](0x0,_0x5e6117))};}function ls(_0x1317f9,_0x456022,_0x5e9684){const _0x2f291b=_0x1317f9['syncPointTree_']['get'](_0x456022);f(_0x2f291b,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x11c578=Ln(_0x1317f9['pendingWriteTree_'],_0x456022);return rs(_0x2f291b,_0x5e9684,_0x11c578,null);}function Zu(_0x1b5420){return _0x1b5420['fold']((_0x449c84,_0x4a92a3,_0x80ceef)=>{if(_0x4a92a3&&Te(_0x4a92a3))return[xn(_0x4a92a3)];{let _0x341a31=[];return _0x4a92a3&&(_0x341a31=Yo(_0x4a92a3)),x(_0x80ceef,(_0x37e197,_0x3b4d34)=>{_0x341a31=_0x341a31['concat'](_0x3b4d34);}),_0x341a31;}});}function bt(_0x1a0f0b){return _0x1a0f0b['_queryParams']['loadsAllData']()&&!_0x1a0f0b['_queryParams']['isDefault']()?new(qu())(_0x1a0f0b['_repo'],_0x1a0f0b['_path']):_0x1a0f0b;}function ed(_0xd42c74,_0x37d520){for(let _0x1302ab=0x0;_0x1302ab<_0x37d520['length'];++_0x1302ab){const _0x31addc=_0x37d520[_0x1302ab];if(!_0x31addc['_queryParams']['loadsAllData']()){const _0x794207=Un(_0x31addc),_0x4032ca=_0xd42c74['queryToTagMap']['get'](_0x794207);_0xd42c74['queryToTagMap']['delete'](_0x794207),_0xd42c74['tagToQueryMap']['delete'](_0x4032ca);}}}function td(){return zu++;}function nd(_0x43f417,_0x5cd163,_0x5994e3){const _0x261d1e=_0x5cd163['_path'],_0x28f290=xt(_0x43f417,_0x5cd163),_0x357505=ta(_0x43f417,_0x5994e3),_0x5bef7d=_0x43f417['listenProvider_']['startListening'](bt(_0x5cd163),_0x28f290,_0x357505['hashFn'],_0x357505['onComplete']),_0x5a56cc=_0x43f417['syncPointTree_']['subtree'](_0x261d1e);if(_0x28f290)f(!Te(_0x5a56cc['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x450416=_0x5a56cc['fold']((_0xf00f7f,_0x15a5f8,_0x53b83b)=>{if(!v(_0xf00f7f)&&_0x15a5f8&&Te(_0x15a5f8))return[xn(_0x15a5f8)['query']];{let _0x3bd33e=[];return _0x15a5f8&&(_0x3bd33e=_0x3bd33e['concat'](Yo(_0x15a5f8)['map'](_0x453159=>_0x453159['query']))),x(_0x53b83b,(_0x5167b0,_0x2aec26)=>{_0x3bd33e=_0x3bd33e['concat'](_0x2aec26);}),_0x3bd33e;}});for(let _0x41667e=0x0;_0x41667e<_0x450416['length'];++_0x41667e){const _0x44e233=_0x450416[_0x41667e];_0x43f417['listenProvider_']['stopListening'](bt(_0x44e233),xt(_0x43f417,_0x44e233));}}return _0x5bef7d;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x574f41){this['node_']=_0x574f41;}['getImmediateChild'](_0x48c92b){const _0x425739=this['node_']['getImmediateChild'](_0x48c92b);return new hs(_0x425739);}['node'](){return this['node_'];}}class us{constructor(_0x164116,_0x2bf887){this['syncTree_']=_0x164116,this['path_']=_0x2bf887;}['getImmediateChild'](_0x3f0a48){const _0x5e6eee=k(this['path_'],_0x3f0a48);return new us(this['syncTree_'],_0x5e6eee);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x541014){return _0x541014=_0x541014||{},_0x541014['timestamp']=_0x541014['timestamp']||new Date()['getTime'](),_0x541014;},gr=function(_0x3a240c,_0x3d9e68,_0x3265ea){if(!_0x3a240c||typeof _0x3a240c!='object')return _0x3a240c;if(f('.sv'in _0x3a240c,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x3a240c['.sv']=='string')return sd(_0x3a240c['.sv'],_0x3d9e68,_0x3265ea);if(typeof _0x3a240c['.sv']=='object')return rd(_0x3a240c['.sv'],_0x3d9e68);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3a240c,null,0x2));},sd=function(_0x26672b,_0x2c2049,_0x58c5f7){switch(_0x26672b){case'timestamp':return _0x58c5f7['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x26672b);}},rd=function(_0x8206e0,_0x1ae2e3,_0xd316fb){_0x8206e0['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x8206e0,null,0x2));const _0x1b7fde=_0x8206e0['increment'];typeof _0x1b7fde!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x1b7fde);const _0x843422=_0x1ae2e3['node']();if(f(_0x843422!==null&&typeof _0x843422<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x843422['isLeafNode']())return _0x1b7fde;const _0x1e482d=_0x843422['getValue']();return typeof _0x1e482d!='number'?_0x1b7fde:_0x1e482d+_0x1b7fde;},na=function(_0x5c304d,_0x53fdd4,_0x4adfd3,_0xceb61e){return fs(_0x53fdd4,new us(_0x4adfd3,_0x5c304d),_0xceb61e);},ds=function(_0x3378fc,_0x504fc6,_0x4edb1b){return fs(_0x3378fc,new hs(_0x504fc6),_0x4edb1b);};function fs(_0xc304fc,_0x17f28b,_0x32ecd9){const _0x3496e9=_0xc304fc['getPriority']()['val'](),_0x5101b9=gr(_0x3496e9,_0x17f28b['getImmediateChild']('.priority'),_0x32ecd9);let _0x218388;if(_0xc304fc['isLeafNode']()){const _0x1c9fd0=_0xc304fc,_0x1d3774=gr(_0x1c9fd0['getValue'](),_0x17f28b,_0x32ecd9);return _0x1d3774!==_0x1c9fd0['getValue']()||_0x5101b9!==_0x1c9fd0['getPriority']()['val']()?new D(_0x1d3774,P(_0x5101b9)):_0xc304fc;}else{const _0x157e46=_0xc304fc;return _0x218388=_0x157e46,_0x5101b9!==_0x157e46['getPriority']()['val']()&&(_0x218388=_0x218388['updatePriority'](new D(_0x5101b9))),_0x157e46['forEachChild'](R,(_0x308c72,_0xb84ee3)=>{const _0x5b85ab=fs(_0xb84ee3,_0x17f28b['getImmediateChild'](_0x308c72),_0x32ecd9);_0x5b85ab!==_0xb84ee3&&(_0x218388=_0x218388['updateImmediateChild'](_0x308c72,_0x5b85ab));}),_0x218388;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0xbe86b0='',_0x2edae9=null,_0x495f67={'children':{},'childCount':0x0}){this['name']=_0xbe86b0,this['parent']=_0x2edae9,this['node']=_0x495f67;}}function Wn(_0x4f4ae1,_0x5db5be){let _0x2f997d=_0x5db5be instanceof C?_0x5db5be:new C(_0x5db5be),_0x166725=_0x4f4ae1,_0x402a64=y(_0x2f997d);for(;_0x402a64!==null;){const _0x3e7119=De(_0x166725['node']['children'],_0x402a64)||{'children':{},'childCount':0x0};_0x166725=new ps(_0x402a64,_0x166725,_0x3e7119),_0x2f997d=b(_0x2f997d),_0x402a64=y(_0x2f997d);}return _0x166725;}function Ge(_0x5f5bdf){return _0x5f5bdf['node']['value'];}function _s(_0x73797e,_0x13baeb){_0x73797e['node']['value']=_0x13baeb,Ai(_0x73797e);}function ia(_0x4915cf){return _0x4915cf['node']['childCount']>0x0;}function od(_0x341649){return Ge(_0x341649)===void 0x0&&!ia(_0x341649);}function Bn(_0x1ff70e,_0x515110){x(_0x1ff70e['node']['children'],(_0x44f748,_0x3c024c)=>{_0x515110(new ps(_0x44f748,_0x1ff70e,_0x3c024c));});}function sa(_0x5bebd0,_0x301c8b,_0x394f8d,_0x821c9d){_0x394f8d&&_0x301c8b(_0x5bebd0),Bn(_0x5bebd0,_0x2e29be=>{sa(_0x2e29be,_0x301c8b,!0x0);});}function ad(_0x48722b,_0x49433d,_0x4a25a8){let _0x35d76d=_0x48722b['parent'];for(;_0x35d76d!==null;){if(_0x49433d(_0x35d76d))return!0x0;_0x35d76d=_0x35d76d['parent'];}return!0x1;}function qt(_0x3e3250){return new C(_0x3e3250['parent']===null?_0x3e3250['name']:qt(_0x3e3250['parent'])+'/'+_0x3e3250['name']);}function Ai(_0x33bb6a){_0x33bb6a['parent']!==null&&cd(_0x33bb6a['parent'],_0x33bb6a['name'],_0x33bb6a);}function cd(_0x4adf7f,_0x59d4e3,_0x425c73){const _0x18e232=od(_0x425c73),_0x2d5cf7=J(_0x4adf7f['node']['children'],_0x59d4e3);_0x18e232&&_0x2d5cf7?(delete _0x4adf7f['node']['children'][_0x59d4e3],_0x4adf7f['node']['childCount']--,Ai(_0x4adf7f)):!_0x18e232&&!_0x2d5cf7&&(_0x4adf7f['node']['children'][_0x59d4e3]=_0x425c73['node'],_0x4adf7f['node']['childCount']++,Ai(_0x4adf7f));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x4e8385){return typeof _0x4e8385=='string'&&_0x4e8385['length']!==0x0&&!ld['test'](_0x4e8385);},ra=function(_0x19b88c){return typeof _0x19b88c=='string'&&_0x19b88c['length']!==0x0&&!hd['test'](_0x19b88c);},ud=function(_0x59a704){return _0x59a704&&(_0x59a704=_0x59a704['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x59a704);},Tn=function(_0x264a99){return _0x264a99===null||typeof _0x264a99=='string'||typeof _0x264a99=='number'&&!Vi(_0x264a99)||_0x264a99&&typeof _0x264a99=='object'&&J(_0x264a99,'.sv');},zt=function(_0x21b8a1,_0x1ca184,_0x518f51,_0x40ff3d){_0x40ff3d&&_0x1ca184===void 0x0||jt(Pn(_0x21b8a1,'value'),_0x1ca184,_0x518f51);},jt=function(_0x1c90a7,_0x183c13,_0xa1a91){const _0x291eed=_0xa1a91 instanceof C?new Ah(_0xa1a91,_0x1c90a7):_0xa1a91;if(_0x183c13===void 0x0)throw new Error(_0x1c90a7+'contains\x20undefined\x20'+Pe(_0x291eed));if(typeof _0x183c13=='function')throw new Error(_0x1c90a7+'contains\x20a\x20function\x20'+Pe(_0x291eed)+'\x20with\x20contents\x20=\x20'+_0x183c13['toString']());if(Vi(_0x183c13))throw new Error(_0x1c90a7+'contains\x20'+_0x183c13['toString']()+'\x20'+Pe(_0x291eed));if(typeof _0x183c13=='string'&&_0x183c13['length']>ai/0x3&&On(_0x183c13)>ai)throw new Error(_0x1c90a7+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x291eed)+'\x20(\x27'+_0x183c13['substring'](0x0,0x32)+'...\x27)');if(_0x183c13&&typeof _0x183c13=='object'){let _0x584168=!0x1,_0x2452c=!0x1;if(x(_0x183c13,(_0x1b4c0d,_0x517921)=>{if(_0x1b4c0d==='.value')_0x584168=!0x0;else{if(_0x1b4c0d!=='.priority'&&_0x1b4c0d!=='.sv'&&(_0x2452c=!0x0,!gs(_0x1b4c0d)))throw new Error(_0x1c90a7+'\x20contains\x20an\x20invalid\x20key\x20('+_0x1b4c0d+')\x20'+Pe(_0x291eed)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x291eed,_0x1b4c0d),jt(_0x1c90a7,_0x517921,_0x291eed),Nh(_0x291eed);}),_0x584168&&_0x2452c)throw new Error(_0x1c90a7+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x291eed)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x5e64f4,_0x3f52ef){let _0x23b2bb,_0x112009;for(_0x23b2bb=0x0;_0x23b2bb<_0x3f52ef['length'];_0x23b2bb++){_0x112009=_0x3f52ef[_0x23b2bb];const _0x1ce466=Pt(_0x112009);for(let _0x1f25f2=0x0;_0x1f25f2<_0x1ce466['length'];_0x1f25f2++)if(!(_0x1ce466[_0x1f25f2]==='.priority'&&_0x1f25f2===_0x1ce466['length']-0x1)){if(!gs(_0x1ce466[_0x1f25f2]))throw new Error(_0x5e64f4+'contains\x20an\x20invalid\x20key\x20('+_0x1ce466[_0x1f25f2]+')\x20in\x20path\x20'+_0x112009['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x3f52ef['sort'](Rh);let _0x33f5a5=null;for(_0x23b2bb=0x0;_0x23b2bb<_0x3f52ef['length'];_0x23b2bb++){if(_0x112009=_0x3f52ef[_0x23b2bb],_0x33f5a5!==null&&G(_0x33f5a5,_0x112009))throw new Error(_0x5e64f4+'contains\x20a\x20path\x20'+_0x33f5a5['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x112009['toString']());_0x33f5a5=_0x112009;}},fd=function(_0x51f06b,_0x194f6d,_0x18c767,_0x292808){const _0x5cf308=Pn(_0x51f06b,'values');if(!(_0x194f6d&&typeof _0x194f6d=='object')||Array['isArray'](_0x194f6d))throw new Error(_0x5cf308+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x3a9758=[];x(_0x194f6d,(_0x3b2b9c,_0x19a19f)=>{const _0x357bb3=new C(_0x3b2b9c);if(jt(_0x5cf308,_0x19a19f,k(_0x18c767,_0x357bb3)),zi(_0x357bb3)==='.priority'&&!Tn(_0x19a19f))throw new Error(_0x5cf308+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x357bb3['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x3a9758['push'](_0x357bb3);}),dd(_0x5cf308,_0x3a9758);},ms=function(_0x299158,_0x46cc04,_0x50a8cd,_0x3e8051){if(!ra(_0x50a8cd))throw new Error(Pn(_0x299158,_0x46cc04)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x50a8cd+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x24b73c,_0x22a518,_0x174d30,_0x16a12f){_0x174d30&&(_0x174d30=_0x174d30['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x24b73c,_0x22a518,_0x174d30);},ys=function(_0x2d350b,_0x5ca925){if(y(_0x5ca925)==='.info')throw new Error(_0x2d350b+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x6fff54,_0x4e4464){const _0x217c02=_0x4e4464['path']['toString']();if(typeof _0x4e4464['repoInfo']['host']!='string'||_0x4e4464['repoInfo']['host']['length']===0x0||!gs(_0x4e4464['repoInfo']['namespace'])&&_0x4e4464['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x217c02['length']!==0x0&&!ud(_0x217c02))throw new Error(Pn(_0x6fff54,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x4cd983,_0x5696b1){let _0x5612c7=null;for(let _0x54d552=0x0;_0x54d552<_0x5696b1['length'];_0x54d552++){const _0x166550=_0x5696b1[_0x54d552],_0x343db5=_0x166550['getPath']();_0x5612c7!==null&&!ji(_0x343db5,_0x5612c7['path'])&&(_0x4cd983['eventLists_']['push'](_0x5612c7),_0x5612c7=null),_0x5612c7===null&&(_0x5612c7={'events':[],'path':_0x343db5}),_0x5612c7['events']['push'](_0x166550);}_0x5612c7&&_0x4cd983['eventLists_']['push'](_0x5612c7);}function oa(_0x3fcbf9,_0x11d610,_0x15a496){Vn(_0x3fcbf9,_0x15a496),aa(_0x3fcbf9,_0x2b6c12=>ji(_0x2b6c12,_0x11d610));}function H(_0xac649b,_0x4347a5,_0x1f3599){Vn(_0xac649b,_0x1f3599),aa(_0xac649b,_0x472491=>G(_0x472491,_0x4347a5)||G(_0x4347a5,_0x472491));}function aa(_0x213917,_0x1d71d5){_0x213917['recursionDepth_']++;let _0x4564f4=!0x0;for(let _0x33c2b3=0x0;_0x33c2b3<_0x213917['eventLists_']['length'];_0x33c2b3++){const _0x58da43=_0x213917['eventLists_'][_0x33c2b3];if(_0x58da43){const _0x5aaabb=_0x58da43['path'];_0x1d71d5(_0x5aaabb)?(md(_0x213917['eventLists_'][_0x33c2b3]),_0x213917['eventLists_'][_0x33c2b3]=null):_0x4564f4=!0x1;}}_0x4564f4&&(_0x213917['eventLists_']=[]),_0x213917['recursionDepth_']--;}function md(_0x5d1def){for(let _0x1e68f1=0x0;_0x1e68f1<_0x5d1def['events']['length'];_0x1e68f1++){const _0x51365b=_0x5d1def['events'][_0x1e68f1];if(_0x51365b!==null){_0x5d1def['events'][_0x1e68f1]=null;const _0x319a9e=_0x51365b['getEventRunner']();wt&&L('event:\x20'+_0x51365b['toString']()),ht(_0x319a9e);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x32ab9e,_0x1a5add,_0xd209f7,_0x3e042c){this['repoInfo_']=_0x32ab9e,this['forceRestClient_']=_0x1a5add,this['authTokenProvider_']=_0xd209f7,this['appCheckProvider_']=_0x3e042c,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x222800,_0x2c9e13,_0x29b2d4){if(_0x222800['stats_']=Gi(_0x222800['repoInfo_']),_0x222800['forceRestClient_']||Xl())_0x222800['server_']=new pn(_0x222800['repoInfo_'],(_0x53ef6f,_0x3d2a62,_0x331eaf,_0x59f9a2)=>{mr(_0x222800,_0x53ef6f,_0x3d2a62,_0x331eaf,_0x59f9a2);},_0x222800['authTokenProvider_'],_0x222800['appCheckProvider_']),setTimeout(()=>yr(_0x222800,!0x0),0x0);else{if(typeof _0x29b2d4<'u'&&_0x29b2d4!==null){if(typeof _0x29b2d4!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x29b2d4);}catch(_0x1fa81b){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x1fa81b);}}_0x222800['persistentConnection_']=new se(_0x222800['repoInfo_'],_0x2c9e13,(_0x1ac09b,_0x1b6831,_0xeda29d,_0x3fd3d9)=>{mr(_0x222800,_0x1ac09b,_0x1b6831,_0xeda29d,_0x3fd3d9);},_0x55a345=>{yr(_0x222800,_0x55a345);},_0x396a3c=>{Id(_0x222800,_0x396a3c);},_0x222800['authTokenProvider_'],_0x222800['appCheckProvider_'],_0x29b2d4),_0x222800['server_']=_0x222800['persistentConnection_'];}_0x222800['authTokenProvider_']['addTokenChangeListener'](_0x245bd1=>{_0x222800['server_']['refreshAuthToken'](_0x245bd1);}),_0x222800['appCheckProvider_']['addTokenChangeListener'](_0x3dfeaf=>{_0x222800['server_']['refreshAppCheckToken'](_0x3dfeaf['token']);}),_0x222800['statsReporter_']=ih(_0x222800['repoInfo_'],()=>new iu(_0x222800['stats_'],_0x222800['server_'])),_0x222800['infoData_']=new Xh(),_0x222800['infoSyncTree_']=new _r({'startListening':(_0x1f63d1,_0x5d0cef,_0x3121e2,_0x55320b)=>{let _0x33724f=[];const _0x2e46a0=_0x222800['infoData_']['getNode'](_0x1f63d1['_path']);return _0x2e46a0['isEmpty']()||(_0x33724f=Gt(_0x222800['infoSyncTree_'],_0x1f63d1['_path'],_0x2e46a0),setTimeout(()=>{_0x55320b('ok');},0x0)),_0x33724f;},'stopListening':()=>{}}),vs(_0x222800,'connected',!0x1),_0x222800['serverSyncTree_']=new _r({'startListening':(_0x40222f,_0x20210a,_0x266c2f,_0x454735)=>(_0x222800['server_']['listen'](_0x40222f,_0x266c2f,_0x20210a,(_0x3c67d6,_0xf3e055)=>{const _0x3d7c4a=_0x454735(_0x3c67d6,_0xf3e055);H(_0x222800['eventQueue_'],_0x40222f['_path'],_0x3d7c4a);}),[]),'stopListening':(_0x1ea84b,_0x5b524d)=>{_0x222800['server_']['unlisten'](_0x1ea84b,_0x5b524d);}});}function la(_0x59d16e){const _0x241a75=_0x59d16e['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x241a75;}function Kt(_0x44d0d7){return id({'timestamp':la(_0x44d0d7)});}function mr(_0x212177,_0x45992c,_0x266d3f,_0x1d90a0,_0x5e24c1){_0x212177['dataUpdateCount']++;const _0x449eae=new C(_0x45992c);_0x266d3f=_0x212177['interceptServerDataCallback_']?_0x212177['interceptServerDataCallback_'](_0x45992c,_0x266d3f):_0x266d3f;let _0x5cb698=[];if(_0x5e24c1){if(_0x1d90a0){const _0x2e74a0=hn(_0x266d3f,_0x2169a6=>P(_0x2169a6));_0x5cb698=Ju(_0x212177['serverSyncTree_'],_0x449eae,_0x2e74a0,_0x5e24c1);}else{const _0x3e243b=P(_0x266d3f);_0x5cb698=Xo(_0x212177['serverSyncTree_'],_0x449eae,_0x3e243b,_0x5e24c1);}}else{if(_0x1d90a0){const _0x56ac30=hn(_0x266d3f,_0x3e8c28=>P(_0x3e8c28));_0x5cb698=Ku(_0x212177['serverSyncTree_'],_0x449eae,_0x56ac30);}else{const _0x198daa=P(_0x266d3f);_0x5cb698=Gt(_0x212177['serverSyncTree_'],_0x449eae,_0x198daa);}}let _0x4f75e1=_0x449eae;_0x5cb698['length']>0x0&&(_0x4f75e1=it(_0x212177,_0x449eae)),H(_0x212177['eventQueue_'],_0x4f75e1,_0x5cb698);}function yr(_0x3e5695,_0x4cd9e4){vs(_0x3e5695,'connected',_0x4cd9e4),_0x4cd9e4===!0x1&&Sd(_0x3e5695);}function Id(_0x5b0655,_0x23ea3a){x(_0x23ea3a,(_0x2c3648,_0x46d386)=>{vs(_0x5b0655,_0x2c3648,_0x46d386);});}function vs(_0x487513,_0x329d3c,_0x367590){const _0x2fb5ad=new C('/.info/'+_0x329d3c),_0x1a6926=P(_0x367590);_0x487513['infoData_']['updateSnapshot'](_0x2fb5ad,_0x1a6926);const _0xe3c756=Gt(_0x487513['infoSyncTree_'],_0x2fb5ad,_0x1a6926);H(_0x487513['eventQueue_'],_0x2fb5ad,_0xe3c756);}function Hn(_0x4d67ab){return _0x4d67ab['nextWriteId_']++;}function wd(_0x27761d,_0x1d5e27,_0x520dc3){const _0x2b6f7f=Xu(_0x27761d['serverSyncTree_'],_0x1d5e27);return _0x2b6f7f!=null?Promise['resolve'](_0x2b6f7f):_0x27761d['server_']['get'](_0x1d5e27)['then'](_0x19a44f=>{const _0xca29d=P(_0x19a44f)['withIndex'](_0x1d5e27['_queryParams']['getIndex']());Ri(_0x27761d['serverSyncTree_'],_0x1d5e27,_0x520dc3,!0x0);let _0x59a0bd;if(_0x1d5e27['_queryParams']['loadsAllData']())_0x59a0bd=Gt(_0x27761d['serverSyncTree_'],_0x1d5e27['_path'],_0xca29d);else{const _0x1aa36b=xt(_0x27761d['serverSyncTree_'],_0x1d5e27);_0x59a0bd=Xo(_0x27761d['serverSyncTree_'],_0x1d5e27['_path'],_0xca29d,_0x1aa36b);}return H(_0x27761d['eventQueue_'],_0x1d5e27['_path'],_0x59a0bd),Cn(_0x27761d['serverSyncTree_'],_0x1d5e27,_0x520dc3,null,!0x0),_0xca29d;},_0x30f7ee=>(dt(_0x27761d,'get\x20for\x20query\x20'+O(_0x1d5e27)+'\x20failed:\x20'+_0x30f7ee),Promise['reject'](new Error(_0x30f7ee))));}function Cd(_0x32effe,_0xe6ba7f,_0x523473,_0x484b1c,_0x52ae55){dt(_0x32effe,'set',{'path':_0xe6ba7f['toString'](),'value':_0x523473,'priority':_0x484b1c});const _0x2b8253=Kt(_0x32effe),_0x38f22b=P(_0x523473,_0x484b1c),_0x2ffa94=Fn(_0x32effe['serverSyncTree_'],_0xe6ba7f),_0x5c1918=ds(_0x38f22b,_0x2ffa94,_0x2b8253),_0x5368e2=Hn(_0x32effe),_0x3608d7=os(_0x32effe['serverSyncTree_'],_0xe6ba7f,_0x5c1918,_0x5368e2,!0x0);Vn(_0x32effe['eventQueue_'],_0x3608d7),_0x32effe['server_']['put'](_0xe6ba7f['toString'](),_0x38f22b['val'](!0x0),(_0x47a07f,_0x1bc9ea)=>{const _0x3f2063=_0x47a07f==='ok';_0x3f2063||U('set\x20at\x20'+_0xe6ba7f+'\x20failed:\x20'+_0x47a07f);const _0x274abb=pe(_0x32effe['serverSyncTree_'],_0x5368e2,!_0x3f2063);H(_0x32effe['eventQueue_'],_0xe6ba7f,_0x274abb),ki(_0x32effe,_0x52ae55,_0x47a07f,_0x1bc9ea);});const _0x503626=Is(_0x32effe,_0xe6ba7f);it(_0x32effe,_0x503626),H(_0x32effe['eventQueue_'],_0x503626,[]);}function Td(_0xb50644,_0x30b70a,_0x378419,_0x38e270){dt(_0xb50644,'update',{'path':_0x30b70a['toString'](),'value':_0x378419});let _0x1e40db=!0x0;const _0x483b4f=Kt(_0xb50644),_0x286a4f={};if(x(_0x378419,(_0x1882c9,_0x3da0d9)=>{_0x1e40db=!0x1,_0x286a4f[_0x1882c9]=na(k(_0x30b70a,_0x1882c9),P(_0x3da0d9),_0xb50644['serverSyncTree_'],_0x483b4f);}),_0x1e40db)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0xb50644,_0x38e270,'ok',void 0x0);else{const _0x11a30d=Hn(_0xb50644),_0x38b278=ju(_0xb50644['serverSyncTree_'],_0x30b70a,_0x286a4f,_0x11a30d);Vn(_0xb50644['eventQueue_'],_0x38b278),_0xb50644['server_']['merge'](_0x30b70a['toString'](),_0x378419,(_0x6df4bc,_0x4c4aac)=>{const _0x1fb5d4=_0x6df4bc==='ok';_0x1fb5d4||U('update\x20at\x20'+_0x30b70a+'\x20failed:\x20'+_0x6df4bc);const _0x3a1390=pe(_0xb50644['serverSyncTree_'],_0x11a30d,!_0x1fb5d4),_0x15a5be=_0x3a1390['length']>0x0?it(_0xb50644,_0x30b70a):_0x30b70a;H(_0xb50644['eventQueue_'],_0x15a5be,_0x3a1390),ki(_0xb50644,_0x38e270,_0x6df4bc,_0x4c4aac);}),x(_0x378419,_0x21e77c=>{const _0x511e0c=Is(_0xb50644,k(_0x30b70a,_0x21e77c));it(_0xb50644,_0x511e0c);}),H(_0xb50644['eventQueue_'],_0x30b70a,[]);}}function Sd(_0x364107){dt(_0x364107,'onDisconnectEvents');const _0x40b72e=Kt(_0x364107),_0x502419=_n();Ii(_0x364107['onDisconnect_'],w(),(_0x130986,_0x44cc5f)=>{const _0x3a5f73=na(_0x130986,_0x44cc5f,_0x364107['serverSyncTree_'],_0x40b72e);Fo(_0x502419,_0x130986,_0x3a5f73);});let _0x23e6ab=[];Ii(_0x502419,w(),(_0x144db2,_0x3dc0ad)=>{_0x23e6ab=_0x23e6ab['concat'](Gt(_0x364107['serverSyncTree_'],_0x144db2,_0x3dc0ad));const _0x42083e=Is(_0x364107,_0x144db2);it(_0x364107,_0x42083e);}),_0x364107['onDisconnect_']=_n(),H(_0x364107['eventQueue_'],w(),_0x23e6ab);}function bd(_0x1559ea,_0x4e8f0f,_0x4b4f49){let _0x1b924a;y(_0x4e8f0f['_path'])==='.info'?_0x1b924a=Ri(_0x1559ea['infoSyncTree_'],_0x4e8f0f,_0x4b4f49):_0x1b924a=Ri(_0x1559ea['serverSyncTree_'],_0x4e8f0f,_0x4b4f49),oa(_0x1559ea['eventQueue_'],_0x4e8f0f['_path'],_0x1b924a);}function Rd(_0x19b82d,_0x419059,_0x433d92){let _0x37500e;y(_0x419059['_path'])==='.info'?_0x37500e=Cn(_0x19b82d['infoSyncTree_'],_0x419059,_0x433d92):_0x37500e=Cn(_0x19b82d['serverSyncTree_'],_0x419059,_0x433d92),oa(_0x19b82d['eventQueue_'],_0x419059['_path'],_0x37500e);}function ha(_0x44552f){_0x44552f['persistentConnection_']&&_0x44552f['persistentConnection_']['interrupt'](ca);}function Ad(_0x577d17){_0x577d17['persistentConnection_']&&_0x577d17['persistentConnection_']['resume'](ca);}function dt(_0x345b75,..._0x329bbc){let _0x3a37a8='';_0x345b75['persistentConnection_']&&(_0x3a37a8=_0x345b75['persistentConnection_']['id']+':'),L(_0x3a37a8,..._0x329bbc);}function ki(_0x39e64b,_0x5b6446,_0x32327f,_0x3d28be){_0x5b6446&&ht(()=>{if(_0x32327f==='ok')_0x5b6446(null);else{const _0x2c5df5=(_0x32327f||'error')['toUpperCase']();let _0x53e793=_0x2c5df5;_0x3d28be&&(_0x53e793+=':\x20'+_0x3d28be);const _0x5da2ab=new Error(_0x53e793);_0x5da2ab['code']=_0x2c5df5,_0x5b6446(_0x5da2ab);}});}function kd(_0x27e907,_0x319793,_0x156663,_0x1be355,_0xb63d56,_0x1ff8ad){dt(_0x27e907,'transaction\x20on\x20'+_0x319793);const _0x30f5ef={'path':_0x319793,'update':_0x156663,'onComplete':_0x1be355,'status':null,'order':so(),'applyLocally':_0x1ff8ad,'retryCount':0x0,'unwatcher':_0xb63d56,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x2a47b5=Es(_0x27e907,_0x319793,void 0x0);_0x30f5ef['currentInputSnapshot']=_0x2a47b5;const _0x469fbf=_0x30f5ef['update'](_0x2a47b5['val']());if(_0x469fbf===void 0x0)_0x30f5ef['unwatcher'](),_0x30f5ef['currentOutputSnapshotRaw']=null,_0x30f5ef['currentOutputSnapshotResolved']=null,_0x30f5ef['onComplete']&&_0x30f5ef['onComplete'](null,!0x1,_0x30f5ef['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x469fbf,_0x30f5ef['path']),_0x30f5ef['status']=0x0;const _0x39668d=Wn(_0x27e907['transactionQueueTree_'],_0x319793),_0x5295b1=Ge(_0x39668d)||[];_0x5295b1['push'](_0x30f5ef),_s(_0x39668d,_0x5295b1);let _0x53f5e5;typeof _0x469fbf=='object'&&_0x469fbf!==null&&J(_0x469fbf,'.priority')?(_0x53f5e5=De(_0x469fbf,'.priority'),f(Tn(_0x53f5e5),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x53f5e5=(Fn(_0x27e907['serverSyncTree_'],_0x319793)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x23ae0a=Kt(_0x27e907),_0x103068=P(_0x469fbf,_0x53f5e5),_0x4a369c=ds(_0x103068,_0x2a47b5,_0x23ae0a);_0x30f5ef['currentOutputSnapshotRaw']=_0x103068,_0x30f5ef['currentOutputSnapshotResolved']=_0x4a369c,_0x30f5ef['currentWriteId']=Hn(_0x27e907);const _0x29741d=os(_0x27e907['serverSyncTree_'],_0x319793,_0x4a369c,_0x30f5ef['currentWriteId'],_0x30f5ef['applyLocally']);H(_0x27e907['eventQueue_'],_0x319793,_0x29741d),$n(_0x27e907,_0x27e907['transactionQueueTree_']);}}function Es(_0x123a14,_0x38a614,_0x47fae4){return Fn(_0x123a14['serverSyncTree_'],_0x38a614,_0x47fae4)||g['EMPTY_NODE'];}function $n(_0x4243c7,_0x28031a=_0x4243c7['transactionQueueTree_']){if(_0x28031a||Gn(_0x4243c7,_0x28031a),Ge(_0x28031a)){const _0x56bde5=da(_0x4243c7,_0x28031a);f(_0x56bde5['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x56bde5['every'](_0x68b984=>_0x68b984['status']===0x0)&&Nd(_0x4243c7,qt(_0x28031a),_0x56bde5);}else ia(_0x28031a)&&Bn(_0x28031a,_0x1d6b50=>{$n(_0x4243c7,_0x1d6b50);});}function Nd(_0xd5c420,_0x3a45f4,_0x4f07ff){const _0x121d74=_0x4f07ff['map'](_0x56243a=>_0x56243a['currentWriteId']),_0x44960d=Es(_0xd5c420,_0x3a45f4,_0x121d74);let _0x2d5c52=_0x44960d;const _0x447aa0=_0x44960d['hash']();for(let _0x375e5a=0x0;_0x375e5a<_0x4f07ff['length'];_0x375e5a++){const _0x110e9d=_0x4f07ff[_0x375e5a];f(_0x110e9d['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x110e9d['status']=0x1,_0x110e9d['retryCount']++;const _0x1bb46c=F(_0x3a45f4,_0x110e9d['path']);_0x2d5c52=_0x2d5c52['updateChild'](_0x1bb46c,_0x110e9d['currentOutputSnapshotRaw']);}const _0x268ae0=_0x2d5c52['val'](!0x0),_0x737b07=_0x3a45f4;_0xd5c420['server_']['put'](_0x737b07['toString'](),_0x268ae0,_0x4b6761=>{dt(_0xd5c420,'transaction\x20put\x20response',{'path':_0x737b07['toString'](),'status':_0x4b6761});let _0x27bf92=[];if(_0x4b6761==='ok'){const _0x4ac953=[];for(let _0x352861=0x0;_0x352861<_0x4f07ff['length'];_0x352861++)_0x4f07ff[_0x352861]['status']=0x2,_0x27bf92=_0x27bf92['concat'](pe(_0xd5c420['serverSyncTree_'],_0x4f07ff[_0x352861]['currentWriteId'])),_0x4f07ff[_0x352861]['onComplete']&&_0x4ac953['push'](()=>_0x4f07ff[_0x352861]['onComplete'](null,!0x0,_0x4f07ff[_0x352861]['currentOutputSnapshotResolved'])),_0x4f07ff[_0x352861]['unwatcher']();Gn(_0xd5c420,Wn(_0xd5c420['transactionQueueTree_'],_0x3a45f4)),$n(_0xd5c420,_0xd5c420['transactionQueueTree_']),H(_0xd5c420['eventQueue_'],_0x3a45f4,_0x27bf92);for(let _0x45b648=0x0;_0x45b648<_0x4ac953['length'];_0x45b648++)ht(_0x4ac953[_0x45b648]);}else{if(_0x4b6761==='datastale'){for(let _0x234a91=0x0;_0x234a91<_0x4f07ff['length'];_0x234a91++)_0x4f07ff[_0x234a91]['status']===0x3?_0x4f07ff[_0x234a91]['status']=0x4:_0x4f07ff[_0x234a91]['status']=0x0;}else{U('transaction\x20at\x20'+_0x737b07['toString']()+'\x20failed:\x20'+_0x4b6761);for(let _0x271bd0=0x0;_0x271bd0<_0x4f07ff['length'];_0x271bd0++)_0x4f07ff[_0x271bd0]['status']=0x4,_0x4f07ff[_0x271bd0]['abortReason']=_0x4b6761;}it(_0xd5c420,_0x3a45f4);}},_0x447aa0);}function it(_0x531ce0,_0xa2071b){const _0x3afdea=ua(_0x531ce0,_0xa2071b),_0x3a2835=qt(_0x3afdea),_0x16ed80=da(_0x531ce0,_0x3afdea);return Pd(_0x531ce0,_0x16ed80,_0x3a2835),_0x3a2835;}function Pd(_0x2f91bd,_0x862ec3,_0x35d12e){if(_0x862ec3['length']===0x0)return;const _0x5d5ae5=[];let _0x88b7a3=[];const _0x74cf45=_0x862ec3['filter'](_0x200751=>_0x200751['status']===0x0)['map'](_0x293e7c=>_0x293e7c['currentWriteId']);for(let _0x14d0ee=0x0;_0x14d0ee<_0x862ec3['length'];_0x14d0ee++){const _0x36f88c=_0x862ec3[_0x14d0ee],_0x49af57=F(_0x35d12e,_0x36f88c['path']);let _0x190e8b=!0x1,_0x54c8ac;if(f(_0x49af57!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x36f88c['status']===0x4)_0x190e8b=!0x0,_0x54c8ac=_0x36f88c['abortReason'],_0x88b7a3=_0x88b7a3['concat'](pe(_0x2f91bd['serverSyncTree_'],_0x36f88c['currentWriteId'],!0x0));else{if(_0x36f88c['status']===0x0){if(_0x36f88c['retryCount']>=yd)_0x190e8b=!0x0,_0x54c8ac='maxretry',_0x88b7a3=_0x88b7a3['concat'](pe(_0x2f91bd['serverSyncTree_'],_0x36f88c['currentWriteId'],!0x0));else{const _0x539584=Es(_0x2f91bd,_0x36f88c['path'],_0x74cf45);_0x36f88c['currentInputSnapshot']=_0x539584;const _0x59f374=_0x862ec3[_0x14d0ee]['update'](_0x539584['val']());if(_0x59f374!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x59f374,_0x36f88c['path']);let _0x16debe=P(_0x59f374);typeof _0x59f374=='object'&&_0x59f374!=null&&J(_0x59f374,'.priority')||(_0x16debe=_0x16debe['updatePriority'](_0x539584['getPriority']()));const _0x2b0f19=_0x36f88c['currentWriteId'],_0x5f55b9=Kt(_0x2f91bd),_0x555b82=ds(_0x16debe,_0x539584,_0x5f55b9);_0x36f88c['currentOutputSnapshotRaw']=_0x16debe,_0x36f88c['currentOutputSnapshotResolved']=_0x555b82,_0x36f88c['currentWriteId']=Hn(_0x2f91bd),_0x74cf45['splice'](_0x74cf45['indexOf'](_0x2b0f19),0x1),_0x88b7a3=_0x88b7a3['concat'](os(_0x2f91bd['serverSyncTree_'],_0x36f88c['path'],_0x555b82,_0x36f88c['currentWriteId'],_0x36f88c['applyLocally'])),_0x88b7a3=_0x88b7a3['concat'](pe(_0x2f91bd['serverSyncTree_'],_0x2b0f19,!0x0));}else _0x190e8b=!0x0,_0x54c8ac='nodata',_0x88b7a3=_0x88b7a3['concat'](pe(_0x2f91bd['serverSyncTree_'],_0x36f88c['currentWriteId'],!0x0));}}}H(_0x2f91bd['eventQueue_'],_0x35d12e,_0x88b7a3),_0x88b7a3=[],_0x190e8b&&(_0x862ec3[_0x14d0ee]['status']=0x2,function(_0x177481){setTimeout(_0x177481,Math['floor'](0x0));}(_0x862ec3[_0x14d0ee]['unwatcher']),_0x862ec3[_0x14d0ee]['onComplete']&&(_0x54c8ac==='nodata'?_0x5d5ae5['push'](()=>_0x862ec3[_0x14d0ee]['onComplete'](null,!0x1,_0x862ec3[_0x14d0ee]['currentInputSnapshot'])):_0x5d5ae5['push'](()=>_0x862ec3[_0x14d0ee]['onComplete'](new Error(_0x54c8ac),!0x1,null))));}Gn(_0x2f91bd,_0x2f91bd['transactionQueueTree_']);for(let _0x1d93e7=0x0;_0x1d93e7<_0x5d5ae5['length'];_0x1d93e7++)ht(_0x5d5ae5[_0x1d93e7]);$n(_0x2f91bd,_0x2f91bd['transactionQueueTree_']);}function ua(_0x42f5d1,_0x38a976){let _0x1d9100,_0x45d2f9=_0x42f5d1['transactionQueueTree_'];for(_0x1d9100=y(_0x38a976);_0x1d9100!==null&&Ge(_0x45d2f9)===void 0x0;)_0x45d2f9=Wn(_0x45d2f9,_0x1d9100),_0x38a976=b(_0x38a976),_0x1d9100=y(_0x38a976);return _0x45d2f9;}function da(_0x375189,_0x1f31bb){const _0xc05684=[];return fa(_0x375189,_0x1f31bb,_0xc05684),_0xc05684['sort']((_0x51edeb,_0x58b759)=>_0x51edeb['order']-_0x58b759['order']),_0xc05684;}function fa(_0x44fcfa,_0x5221ec,_0x1ec565){const _0x131f44=Ge(_0x5221ec);if(_0x131f44){for(let _0x8c94db=0x0;_0x8c94db<_0x131f44['length'];_0x8c94db++)_0x1ec565['push'](_0x131f44[_0x8c94db]);}Bn(_0x5221ec,_0x3c2f5a=>{fa(_0x44fcfa,_0x3c2f5a,_0x1ec565);});}function Gn(_0x119824,_0x5c339c){const _0x1306a5=Ge(_0x5c339c);if(_0x1306a5){let _0x2fa486=0x0;for(let _0x48821d=0x0;_0x48821d<_0x1306a5['length'];_0x48821d++)_0x1306a5[_0x48821d]['status']!==0x2&&(_0x1306a5[_0x2fa486]=_0x1306a5[_0x48821d],_0x2fa486++);_0x1306a5['length']=_0x2fa486,_s(_0x5c339c,_0x1306a5['length']>0x0?_0x1306a5:void 0x0);}Bn(_0x5c339c,_0x2eff55=>{Gn(_0x119824,_0x2eff55);});}function Is(_0xc46967,_0x48595a){const _0x1a436a=qt(ua(_0xc46967,_0x48595a)),_0x3a1b91=Wn(_0xc46967['transactionQueueTree_'],_0x48595a);return ad(_0x3a1b91,_0x23123e=>{ci(_0xc46967,_0x23123e);}),ci(_0xc46967,_0x3a1b91),sa(_0x3a1b91,_0x48ca72=>{ci(_0xc46967,_0x48ca72);}),_0x1a436a;}function ci(_0x5cf2e9,_0x3a1bc9){const _0x49dfff=Ge(_0x3a1bc9);if(_0x49dfff){const _0x1f8678=[];let _0x10396b=[],_0x4cb428=-0x1;for(let _0x2568be=0x0;_0x2568be<_0x49dfff['length'];_0x2568be++)_0x49dfff[_0x2568be]['status']===0x3||(_0x49dfff[_0x2568be]['status']===0x1?(f(_0x4cb428===_0x2568be-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x4cb428=_0x2568be,_0x49dfff[_0x2568be]['status']=0x3,_0x49dfff[_0x2568be]['abortReason']='set'):(f(_0x49dfff[_0x2568be]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x49dfff[_0x2568be]['unwatcher'](),_0x10396b=_0x10396b['concat'](pe(_0x5cf2e9['serverSyncTree_'],_0x49dfff[_0x2568be]['currentWriteId'],!0x0)),_0x49dfff[_0x2568be]['onComplete']&&_0x1f8678['push'](_0x49dfff[_0x2568be]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x4cb428===-0x1?_s(_0x3a1bc9,void 0x0):_0x49dfff['length']=_0x4cb428+0x1,H(_0x5cf2e9['eventQueue_'],qt(_0x3a1bc9),_0x10396b);for(let _0x3778b1=0x0;_0x3778b1<_0x1f8678['length'];_0x3778b1++)ht(_0x1f8678[_0x3778b1]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x1a78c7){let _0x41916a='';const _0x3be6eb=_0x1a78c7['split']('/');for(let _0x36e834=0x0;_0x36e834<_0x3be6eb['length'];_0x36e834++)if(_0x3be6eb[_0x36e834]['length']>0x0){let _0x5ad44b=_0x3be6eb[_0x36e834];try{_0x5ad44b=decodeURIComponent(_0x5ad44b['replace'](/\+/g,'\x20'));}catch{}_0x41916a+='/'+_0x5ad44b;}return _0x41916a;}function Dd(_0x220128){const _0x22520b={};_0x220128['charAt'](0x0)==='?'&&(_0x220128=_0x220128['substring'](0x1));for(const _0x137784 of _0x220128['split']('&')){if(_0x137784['length']===0x0)continue;const _0x4d140b=_0x137784['split']('=');_0x4d140b['length']===0x2?_0x22520b[decodeURIComponent(_0x4d140b[0x0])]=decodeURIComponent(_0x4d140b[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x137784+'\x27\x20in\x20query\x20\x27'+_0x220128+'\x27');}return _0x22520b;}const vr=function(_0x3c45fe,_0x496f15){const _0x137dd4=Md(_0x3c45fe),_0x57cad6=_0x137dd4['namespace'];_0x137dd4['domain']==='firebase.com'&&ae(_0x137dd4['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x57cad6||_0x57cad6==='undefined')&&_0x137dd4['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x137dd4['secure']||$l();const _0xa8bd8b=_0x137dd4['scheme']==='ws'||_0x137dd4['scheme']==='wss';return{'repoInfo':new yo(_0x137dd4['host'],_0x137dd4['secure'],_0x57cad6,_0xa8bd8b,_0x496f15,'',_0x57cad6!==_0x137dd4['subdomain']),'path':new C(_0x137dd4['pathString'])};},Md=function(_0x161821){let _0x428239='',_0x3b8113='',_0x588916='',_0x409d76='',_0x357b90='',_0x1685fb=!0x0,_0x37207c='https',_0x1295f5=0x1bb;if(typeof _0x161821=='string'){let _0x4f6d89=_0x161821['indexOf']('//');_0x4f6d89>=0x0&&(_0x37207c=_0x161821['substring'](0x0,_0x4f6d89-0x1),_0x161821=_0x161821['substring'](_0x4f6d89+0x2));let _0x2a4618=_0x161821['indexOf']('/');_0x2a4618===-0x1&&(_0x2a4618=_0x161821['length']);let _0x419abd=_0x161821['indexOf']('?');_0x419abd===-0x1&&(_0x419abd=_0x161821['length']),_0x428239=_0x161821['substring'](0x0,Math['min'](_0x2a4618,_0x419abd)),_0x2a4618<_0x419abd&&(_0x409d76=Od(_0x161821['substring'](_0x2a4618,_0x419abd)));const _0x2e8a18=Dd(_0x161821['substring'](Math['min'](_0x161821['length'],_0x419abd)));_0x4f6d89=_0x428239['indexOf'](':'),_0x4f6d89>=0x0?(_0x1685fb=_0x37207c==='https'||_0x37207c==='wss',_0x1295f5=parseInt(_0x428239['substring'](_0x4f6d89+0x1),0xa)):_0x4f6d89=_0x428239['length'];const _0x277112=_0x428239['slice'](0x0,_0x4f6d89);if(_0x277112['toLowerCase']()==='localhost')_0x3b8113='localhost';else{if(_0x277112['split']('.')['length']<=0x2)_0x3b8113=_0x277112;else{const _0x493f3b=_0x428239['indexOf']('.');_0x588916=_0x428239['substring'](0x0,_0x493f3b)['toLowerCase'](),_0x3b8113=_0x428239['substring'](_0x493f3b+0x1),_0x357b90=_0x588916;}}'ns'in _0x2e8a18&&(_0x357b90=_0x2e8a18['ns']);}return{'host':_0x428239,'port':_0x1295f5,'domain':_0x3b8113,'subdomain':_0x588916,'secure':_0x1685fb,'scheme':_0x37207c,'pathString':_0x409d76,'namespace':_0x357b90};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x34c8b1=0x0;const _0x15f841=[];return function(_0xc234a3){const _0x1e01bc=_0xc234a3===_0x34c8b1;_0x34c8b1=_0xc234a3;let _0x5f1087;const _0x199927=new Array(0x8);for(_0x5f1087=0x7;_0x5f1087>=0x0;_0x5f1087--)_0x199927[_0x5f1087]=Er['charAt'](_0xc234a3%0x40),_0xc234a3=Math['floor'](_0xc234a3/0x40);f(_0xc234a3===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x463703=_0x199927['join']('');if(_0x1e01bc){for(_0x5f1087=0xb;_0x5f1087>=0x0&&_0x15f841[_0x5f1087]===0x3f;_0x5f1087--)_0x15f841[_0x5f1087]=0x0;_0x15f841[_0x5f1087]++;}else{for(_0x5f1087=0x0;_0x5f1087<0xc;_0x5f1087++)_0x15f841[_0x5f1087]=Math['floor'](Math['random']()*0x40);}for(_0x5f1087=0x0;_0x5f1087<0xc;_0x5f1087++)_0x463703+=Er['charAt'](_0x15f841[_0x5f1087]);return f(_0x463703['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x463703;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x11a57b,_0x1bb605,_0x42dd7b,_0x58575f){this['eventType']=_0x11a57b,this['eventRegistration']=_0x1bb605,this['snapshot']=_0x42dd7b,this['prevName']=_0x58575f;}['getPath'](){const _0x3975dc=this['snapshot']['ref'];return this['eventType']==='value'?_0x3975dc['_path']:_0x3975dc['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x1d83e1,_0x4923af,_0x23aa20){this['eventRegistration']=_0x1d83e1,this['error']=_0x4923af,this['path']=_0x23aa20;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x29e76e,_0x1b6b58){this['snapshotCallback']=_0x29e76e,this['cancelCallback']=_0x1b6b58;}['onValue'](_0x3f6e0b,_0x25839c){this['snapshotCallback']['call'](null,_0x3f6e0b,_0x25839c);}['onCancel'](_0x4df91f){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x4df91f);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x52a268){return this['snapshotCallback']===_0x52a268['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x52a268['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x52a268['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x23753f,_0x27a729,_0x3cde59,_0x156478){this['_repo']=_0x23753f,this['_path']=_0x27a729,this['_queryParams']=_0x3cde59,this['_orderByCalled']=_0x156478;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x4eb646=rr(this['_queryParams']),_0x1dcd6e=Hi(_0x4eb646);return _0x1dcd6e==='{}'?'default':_0x1dcd6e;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x1d3c9f){if(_0x1d3c9f=N(_0x1d3c9f),!(_0x1d3c9f instanceof be))return!0x1;const _0x29619e=this['_repo']===_0x1d3c9f['_repo'],_0xb78997=ji(this['_path'],_0x1d3c9f['_path']),_0x34596e=this['_queryIdentifier']===_0x1d3c9f['_queryIdentifier'];return _0x29619e&&_0xb78997&&_0x34596e;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x165403,_0x2ceeca){if(_0x165403['_orderByCalled']===!0x0)throw new Error(_0x2ceeca+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x48fd5a){let _0x50c7a5=null,_0x3fd80a=null;if(_0x48fd5a['hasStart']()&&(_0x50c7a5=_0x48fd5a['getIndexStartValue']()),_0x48fd5a['hasEnd']()&&(_0x3fd80a=_0x48fd5a['getIndexEndValue']()),_0x48fd5a['getIndex']()===ye){const _0x246d40='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x3761d9='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x48fd5a['hasStart']()){if(_0x48fd5a['getIndexStartName']()!==Fe)throw new Error(_0x246d40);if(typeof _0x50c7a5!='string')throw new Error(_0x3761d9);}if(_0x48fd5a['hasEnd']()){if(_0x48fd5a['getIndexEndName']()!==Ie)throw new Error(_0x246d40);if(typeof _0x3fd80a!='string')throw new Error(_0x3761d9);}}else{if(_0x48fd5a['getIndex']()===R){if(_0x50c7a5!=null&&!Tn(_0x50c7a5)||_0x3fd80a!=null&&!Tn(_0x3fd80a))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x48fd5a['getIndex']()instanceof Qi||_0x48fd5a['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x50c7a5!=null&&typeof _0x50c7a5=='object'||_0x3fd80a!=null&&typeof _0x3fd80a=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x5e65d4){if(_0x5e65d4['hasStart']()&&_0x5e65d4['hasEnd']()&&_0x5e65d4['hasLimit']()&&!_0x5e65d4['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x3815e5,_0x84681d){super(_0x3815e5,_0x84681d,new Xi(),!0x1);}get['parent'](){const _0x32d95b=Ro(this['_path']);return _0x32d95b===null?null:new ee(this['_repo'],_0x32d95b);}get['root'](){let _0x266a08=this;for(;_0x266a08['parent']!==null;)_0x266a08=_0x266a08['parent'];return _0x266a08;}}class st{constructor(_0x26b326,_0xaf1869,_0x27772f){this['_node']=_0x26b326,this['ref']=_0xaf1869,this['_index']=_0x27772f;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x519d0d){const _0x3ee8d2=new C(_0x519d0d),_0x27b63c=Ft(this['ref'],_0x519d0d);return new st(this['_node']['getChild'](_0x3ee8d2),_0x27b63c,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x21d10e){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x2234ad,_0x51d395)=>_0x21d10e(new st(_0x51d395,Ft(this['ref'],_0x2234ad),R)));}['hasChild'](_0x245213){const _0x5d5c62=new C(_0x245213);return!this['_node']['getChild'](_0x5d5c62)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0xde0464,_0x476f5a){return _0xde0464=N(_0xde0464),_0xde0464['_checkNotDeleted']('ref'),_0x476f5a!==void 0x0?Ft(_0xde0464['_root'],_0x476f5a):_0xde0464['_root'];}function Ft(_0x45e17c,_0x4be7c8){return _0x45e17c=N(_0x45e17c),y(_0x45e17c['_path'])===null?pd('child','path',_0x4be7c8):ms('child','path',_0x4be7c8),new ee(_0x45e17c['_repo'],k(_0x45e17c['_path'],_0x4be7c8));}function g_(_0x1cc794,_0x32aa62){_0x1cc794=N(_0x1cc794),ys('push',_0x1cc794['_path']),zt('push',_0x32aa62,_0x1cc794['_path'],!0x0);const _0x4468b1=la(_0x1cc794['_repo']),_0x129016=Ld(_0x4468b1),_0x4d45f5=Ft(_0x1cc794,_0x129016),_0x3bcfee=Ft(_0x1cc794,_0x129016);let _0x36a0f2;return _0x32aa62!=null?_0x36a0f2=Ud(_0x3bcfee,_0x32aa62)['then'](()=>_0x3bcfee):_0x36a0f2=Promise['resolve'](_0x3bcfee),_0x4d45f5['then']=_0x36a0f2['then']['bind'](_0x36a0f2),_0x4d45f5['catch']=_0x36a0f2['then']['bind'](_0x36a0f2,void 0x0),_0x4d45f5;}function Ud(_0x1eaf93,_0x1362be){_0x1eaf93=N(_0x1eaf93),ys('set',_0x1eaf93['_path']),zt('set',_0x1362be,_0x1eaf93['_path'],!0x1);const _0x4e5bc5=new ot();return Cd(_0x1eaf93['_repo'],_0x1eaf93['_path'],_0x1362be,null,_0x4e5bc5['wrapCallback'](()=>{})),_0x4e5bc5['promise'];}function m_(_0x319f2a,_0x2cb64a){fd('update',_0x2cb64a,_0x319f2a['_path']);const _0x24b2a3=new ot();return Td(_0x319f2a['_repo'],_0x319f2a['_path'],_0x2cb64a,_0x24b2a3['wrapCallback'](()=>{})),_0x24b2a3['promise'];}function y_(_0x147826){_0x147826=N(_0x147826);const _0x5d451a=new pa(()=>{}),_0x2b6400=new zn(_0x5d451a);return wd(_0x147826['_repo'],_0x147826,_0x2b6400)['then'](_0x5dcf9b=>new st(_0x5dcf9b,new ee(_0x147826['_repo'],_0x147826['_path']),_0x147826['_queryParams']['getIndex']()));}class zn{constructor(_0xed3fdb){this['callbackContext']=_0xed3fdb;}['respondsTo'](_0x164cdb){return _0x164cdb==='value';}['createEvent'](_0x33f611,_0x279436){const _0x370a75=_0x279436['_queryParams']['getIndex']();return new xd('value',this,new st(_0x33f611['snapshotNode'],new ee(_0x279436['_repo'],_0x279436['_path']),_0x370a75));}['getEventRunner'](_0x5d39c4){return _0x5d39c4['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x5d39c4['error']):()=>this['callbackContext']['onValue'](_0x5d39c4['snapshot'],null);}['createCancelEvent'](_0x55534b,_0x4db116){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x55534b,_0x4db116):null;}['matches'](_0x329994){return _0x329994 instanceof zn?!_0x329994['callbackContext']||!this['callbackContext']?!0x0:_0x329994['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x19e78b,_0x105f73,_0x3f4c25,_0x57786f,_0x104a13){const _0x44b5d6=new pa(_0x3f4c25,void 0x0),_0x501276=new zn(_0x44b5d6);return bd(_0x19e78b['_repo'],_0x19e78b,_0x501276),()=>Rd(_0x19e78b['_repo'],_0x19e78b,_0x501276);}function Bd(_0x719cd5,_0x268b2a,_0x391ca4,_0x41919c){return Wd(_0x719cd5,'value',_0x268b2a);}class ft{}class ma extends ft{constructor(_0x5f1418,_0x2da897){super(),this['_value']=_0x5f1418,this['_key']=_0x2da897,this['type']='endAt';}['_apply'](_0x53ece9){zt('endAt',this['_value'],_0x53ece9['_path'],!0x0);const _0x513740=Jh(_0x53ece9['_queryParams'],this['_value'],this['_key']);if(ga(_0x513740),qn(_0x513740),_0x53ece9['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x53ece9['_repo'],_0x53ece9['_path'],_0x513740,_0x53ece9['_orderByCalled']);}}function v_(_0x35869a,_0x2421df){return new ma(_0x35869a,_0x2421df);}class ya extends ft{constructor(_0x309dc5,_0x301610){super(),this['_value']=_0x309dc5,this['_key']=_0x301610,this['type']='startAt';}['_apply'](_0x280d00){zt('startAt',this['_value'],_0x280d00['_path'],!0x0);const _0x53c330=Qh(_0x280d00['_queryParams'],this['_value'],this['_key']);if(ga(_0x53c330),qn(_0x53c330),_0x280d00['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x280d00['_repo'],_0x280d00['_path'],_0x53c330,_0x280d00['_orderByCalled']);}}function E_(_0x5dadd7=null,_0x402d61){return new ya(_0x5dadd7,_0x402d61);}class Vd extends ft{constructor(_0x3a491a){super(),this['_limit']=_0x3a491a,this['type']='limitToFirst';}['_apply'](_0x638578){if(_0x638578['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x638578['_repo'],_0x638578['_path'],Yh(_0x638578['_queryParams'],this['_limit']),_0x638578['_orderByCalled']);}}function I_(_0x27163a){if(Math['floor'](_0x27163a)!==_0x27163a||_0x27163a<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x27163a);}class Hd extends ft{constructor(_0x2448cd){super(),this['_path']=_0x2448cd,this['type']='orderByChild';}['_apply'](_0xd3ea5){_a(_0xd3ea5,'orderByChild');const _0x140a08=new C(this['_path']);if(v(_0x140a08))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x179f1f=new Qi(_0x140a08),_0x53cc09=xo(_0xd3ea5['_queryParams'],_0x179f1f);return qn(_0x53cc09),new be(_0xd3ea5['_repo'],_0xd3ea5['_path'],_0x53cc09,!0x0);}}function w_(_0x37d8d9){if(_0x37d8d9==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x37d8d9==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x37d8d9==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x37d8d9),new Hd(_0x37d8d9);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x30bd94){_a(_0x30bd94,'orderByKey');const _0x1f9b05=xo(_0x30bd94['_queryParams'],ye);return qn(_0x1f9b05),new be(_0x30bd94['_repo'],_0x30bd94['_path'],_0x1f9b05,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x1fdb22,_0x2d7b27){super(),this['_value']=_0x1fdb22,this['_key']=_0x2d7b27,this['type']='equalTo';}['_apply'](_0x85adb8){if(zt('equalTo',this['_value'],_0x85adb8['_path'],!0x1),_0x85adb8['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x85adb8['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x85adb8));}}function T_(_0x39562a,_0xb1f623){return new Gd(_0x39562a,_0xb1f623);}function S_(_0x3b0410,..._0x1fa6de){let _0xc0edd0=N(_0x3b0410);for(const _0x2bbcaa of _0x1fa6de)_0xc0edd0=_0x2bbcaa['_apply'](_0xc0edd0);return _0xc0edd0;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x3765c2,_0x5b02e4,_0x1bd051,_0x3887f8){const _0x340a5d=_0x5b02e4['lastIndexOf'](':'),_0x1cc47a=_0x5b02e4['substring'](0x0,_0x340a5d),_0x49b901=at(_0x1cc47a);_0x3765c2['repoInfo_']=new yo(_0x5b02e4,_0x49b901,_0x3765c2['repoInfo_']['namespace'],_0x3765c2['repoInfo_']['webSocketOnly'],_0x3765c2['repoInfo_']['nodeAdmin'],_0x3765c2['repoInfo_']['persistenceKey'],_0x3765c2['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x1bd051),_0x3887f8&&(_0x3765c2['authTokenProvider_']=_0x3887f8);}function Kd(_0x24b5ce,_0x4f54bb,_0x3f24e1,_0x4784e9,_0x4deec2){let _0x525001=_0x4784e9||_0x24b5ce['options']['databaseURL'];_0x525001===void 0x0&&(_0x24b5ce['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x24b5ce['options']['projectId']),_0x525001=_0x24b5ce['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x48b606=vr(_0x525001,_0x4deec2),_0xf4775=_0x48b606['repoInfo'],_0x59bca3;typeof process<'u'&&Vs&&(_0x59bca3=Vs[qd]),_0x59bca3?(_0x525001='http://'+_0x59bca3+'?ns='+_0xf4775['namespace'],_0x48b606=vr(_0x525001,_0x4deec2),_0xf4775=_0x48b606['repoInfo']):_0x48b606['repoInfo']['secure'];const _0x37c066=new eh(_0x24b5ce['name'],_0x24b5ce['options'],_0x4f54bb);_d('Invalid\x20Firebase\x20Database\x20URL',_0x48b606),v(_0x48b606['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x53708f=Qd(_0xf4775,_0x24b5ce,_0x37c066,new Zl(_0x24b5ce,_0x3f24e1));return new Jd(_0x53708f,_0x24b5ce);}function Yd(_0x59a319,_0x5d3a15){const _0x2ab614=Ni[_0x5d3a15];(!_0x2ab614||_0x2ab614[_0x59a319['key']]!==_0x59a319)&&ae('Database\x20'+_0x5d3a15+'('+_0x59a319['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x59a319),delete _0x2ab614[_0x59a319['key']];}function Qd(_0x5ae8d7,_0x21b313,_0x495027,_0x89a337){let _0x595d12=Ni[_0x21b313['name']];_0x595d12||(_0x595d12={},Ni[_0x21b313['name']]=_0x595d12);let _0x428f6b=_0x595d12[_0x5ae8d7['toURLString']()];return _0x428f6b&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x428f6b=new vd(_0x5ae8d7,zd,_0x495027,_0x89a337),_0x595d12[_0x5ae8d7['toURLString']()]=_0x428f6b,_0x428f6b;}class Jd{constructor(_0x5e0657,_0x117b46){this['_repoInternal']=_0x5e0657,this['app']=_0x117b46,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x3de24d){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x3de24d+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x275131=Zr(),_0x5b97f0){const _0x49ef67=Bi(_0x275131,'database')['getImmediate']({'identifier':_0x5b97f0});if(!_0x49ef67['_instanceStarted']){const _0x139ab4=cc('database');_0x139ab4&&Xd(_0x49ef67,..._0x139ab4);}return _0x49ef67;}function Xd(_0x4aae4e,_0x1a5796,_0x4cb385,_0x33dc5e={}){_0x4aae4e=N(_0x4aae4e),_0x4aae4e['_checkNotDeleted']('useEmulator');const _0x440258=_0x1a5796+':'+_0x4cb385,_0x1ff1d0=_0x4aae4e['_repoInternal'];if(_0x4aae4e['_instanceStarted']){if(_0x440258===_0x4aae4e['_repoInternal']['repoInfo_']['host']&&Me(_0x33dc5e,_0x1ff1d0['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x515908;if(_0x1ff1d0['repoInfo_']['nodeAdmin'])_0x33dc5e['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x515908=new nn(nn['OWNER']);else{if(_0x33dc5e['mockUserToken']){const _0x2c542b=typeof _0x33dc5e['mockUserToken']=='string'?_0x33dc5e['mockUserToken']:lc(_0x33dc5e['mockUserToken'],_0x4aae4e['app']['options']['projectId']);_0x515908=new nn(_0x2c542b);}}at(_0x1a5796)&&(jr(_0x1a5796),Kr('Database',!0x0)),jd(_0x1ff1d0,_0x440258,_0x33dc5e,_0x515908);}function R_(_0x19f85b){_0x19f85b=N(_0x19f85b),_0x19f85b['_checkNotDeleted']('goOffline'),ha(_0x19f85b['_repo']);}function A_(_0x162c2e){_0x162c2e=N(_0x162c2e),_0x162c2e['_checkNotDeleted']('goOnline'),Ad(_0x162c2e['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x4105b1){Ul(lt),Ze(new Le('database',(_0xe71e40,{instanceIdentifier:_0x45a47f})=>{const _0x29d27f=_0xe71e40['getProvider']('app')['getImmediate'](),_0xd2b192=_0xe71e40['getProvider']('auth-internal'),_0x343ffb=_0xe71e40['getProvider']('app-check-internal');return Kd(_0x29d27f,_0xd2b192,_0x343ffb,_0x45a47f);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x4105b1),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x4a68ff,_0x473478){this['committed']=_0x4a68ff,this['snapshot']=_0x473478;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x4ccd0a,_0x5c51ab,_0x4e311c){if(_0x4ccd0a=N(_0x4ccd0a),ys('Reference.transaction',_0x4ccd0a['_path']),_0x4ccd0a['key']==='.length'||_0x4ccd0a['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x4ccd0a['key']+'\x20is\x20a\x20read-only\x20object.';const _0x88c346=!0x0,_0x41de65=new ot(),_0x2d1b59=(_0x383409,_0x574231,_0x53502c)=>{let _0x3f061b=null;_0x383409?_0x41de65['reject'](_0x383409):(_0x3f061b=new st(_0x53502c,new ee(_0x4ccd0a['_repo'],_0x4ccd0a['_path']),R),_0x41de65['resolve'](new tf(_0x574231,_0x3f061b)));},_0x209c48=Bd(_0x4ccd0a,()=>{});return kd(_0x4ccd0a['_repo'],_0x4ccd0a['_path'],_0x5c51ab,_0x2d1b59,_0x209c48,_0x88c346),_0x41de65['promise'];}se['prototype']['simpleListen']=function(_0x5e24d3,_0x237afc){this['sendRequest']('q',{'p':_0x5e24d3},_0x237afc);},se['prototype']['echo']=function(_0x1249a5,_0x44f1b6){this['sendRequest']('echo',{'d':_0x1249a5},_0x44f1b6);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x372fc0,..._0x1cc1de){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x372fc0,..._0x1cc1de);}function sn(_0xc8d219,..._0x341426){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0xc8d219,..._0x341426);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x47d1c6,..._0x3dff5f){throw ws(_0x47d1c6,..._0x3dff5f);}function X(_0x5b0a4f,..._0x3332dc){return ws(_0x5b0a4f,..._0x3332dc);}function Ia(_0x476341,_0x517eeb,_0x15c596){const _0x28339b={...nf(),[_0x517eeb]:_0x15c596};return new Bt('auth','Firebase',_0x28339b)['create'](_0x517eeb,{'appName':_0x476341['name']});}function re(_0x65952d){return Ia(_0x65952d,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x2ffc1a,..._0x377a13){if(typeof _0x2ffc1a!='string'){const _0x7d6697=_0x377a13[0x0],_0x2d5e25=[..._0x377a13['slice'](0x1)];return _0x2d5e25[0x0]&&(_0x2d5e25[0x0]['appName']=_0x2ffc1a['name']),_0x2ffc1a['_errorFactory']['create'](_0x7d6697,..._0x2d5e25);}return Ea['create'](_0x2ffc1a,..._0x377a13);}function m(_0x14e69e,_0x386a46,..._0x2f333e){if(!_0x14e69e)throw ws(_0x386a46,..._0x2f333e);}function ne(_0x1c0694){const _0x25192d='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1c0694;throw sn(_0x25192d),new Error(_0x25192d);}function ce(_0x475d52,_0x43d12f){_0x475d52||ne(_0x43d12f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x5289ec;return typeof self<'u'&&((_0x5289ec=self['location'])==null?void 0x0:_0x5289ec['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x207486;return typeof self<'u'&&((_0x207486=self['location'])==null?void 0x0:_0x207486['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x310cd4=navigator;return _0x310cd4['languages']&&_0x310cd4['languages'][0x0]||_0x310cd4['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x181004,_0x464630){this['shortDelay']=_0x181004,this['longDelay']=_0x464630,ce(_0x464630>_0x181004,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x29e713,_0x262aff){ce(_0x29e713['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x26da7c}=_0x29e713['emulator'];return _0x262aff?''+_0x26da7c+(_0x262aff['startsWith']('/')?_0x262aff['slice'](0x1):_0x262aff):_0x26da7c;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x5e6d84,_0x29c6d9,_0x56b1b9){this['fetchImpl']=_0x5e6d84,_0x29c6d9&&(this['headersImpl']=_0x29c6d9),_0x56b1b9&&(this['responseImpl']=_0x56b1b9);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x409d29,_0x427791){return _0x409d29['tenantId']&&!_0x427791['tenantId']?{..._0x427791,'tenantId':_0x409d29['tenantId']}:_0x427791;}async function Ae(_0x4d2fae,_0x21b4ee,_0x440f9f,_0x8b9762,_0xe96a36={}){return Ca(_0x4d2fae,_0xe96a36,async()=>{let _0x303992={},_0x35b093={};_0x8b9762&&(_0x21b4ee==='GET'?_0x35b093=_0x8b9762:_0x303992={'body':JSON['stringify'](_0x8b9762)});const _0x7a192d=ct({'key':_0x4d2fae['config']['apiKey'],..._0x35b093})['slice'](0x1),_0x3e83aa=await _0x4d2fae['_getAdditionalHeaders']();_0x3e83aa['Content-Type']='application/json',_0x4d2fae['languageCode']&&(_0x3e83aa['X-Firebase-Locale']=_0x4d2fae['languageCode']);const _0x18d37c={'method':_0x21b4ee,'headers':_0x3e83aa,..._0x303992};return dc()||(_0x18d37c['referrerPolicy']='no-referrer'),_0x4d2fae['emulatorConfig']&&at(_0x4d2fae['emulatorConfig']['host'])&&(_0x18d37c['credentials']='include'),wa['fetch']()(await Ta(_0x4d2fae,_0x4d2fae['config']['apiHost'],_0x440f9f,_0x7a192d),_0x18d37c);});}async function Ca(_0x2a8b07,_0x5e746a,_0x3d4c1b){_0x2a8b07['_canInitEmulator']=!0x1;const _0x49a181={...cf,..._0x5e746a};try{const _0x20257c=new df(_0x2a8b07),_0x318d0d=await Promise['race']([_0x3d4c1b(),_0x20257c['promise']]);_0x20257c['clearNetworkTimeout']();const _0x1c3f24=await _0x318d0d['json']();if('needConfirmation'in _0x1c3f24)throw tn(_0x2a8b07,'account-exists-with-different-credential',_0x1c3f24);if(_0x318d0d['ok']&&!('errorMessage'in _0x1c3f24))return _0x1c3f24;{const _0x4846b7=_0x318d0d['ok']?_0x1c3f24['errorMessage']:_0x1c3f24['error']['message'],[_0x3ad38b,_0x52a130]=_0x4846b7['split']('\x20:\x20');if(_0x3ad38b==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x2a8b07,'credential-already-in-use',_0x1c3f24);if(_0x3ad38b==='EMAIL_EXISTS')throw tn(_0x2a8b07,'email-already-in-use',_0x1c3f24);if(_0x3ad38b==='USER_DISABLED')throw tn(_0x2a8b07,'user-disabled',_0x1c3f24);const _0x481254=_0x49a181[_0x3ad38b]||_0x3ad38b['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x52a130)throw Ia(_0x2a8b07,_0x481254,_0x52a130);Q(_0x2a8b07,_0x481254);}}catch(_0x4cd1da){if(_0x4cd1da instanceof Se)throw _0x4cd1da;Q(_0x2a8b07,'network-request-failed',{'message':String(_0x4cd1da)});}}async function Qt(_0x5c0521,_0x5cc2fb,_0x2bd639,_0x554e96,_0x41120a={}){const _0x3838a0=await Ae(_0x5c0521,_0x5cc2fb,_0x2bd639,_0x554e96,_0x41120a);return'mfaPendingCredential'in _0x3838a0&&Q(_0x5c0521,'multi-factor-auth-required',{'_serverResponse':_0x3838a0}),_0x3838a0;}async function Ta(_0x2aa538,_0x3a1397,_0x1a31fd,_0x37a04b){const _0x3ccc66=''+_0x3a1397+_0x1a31fd+'?'+_0x37a04b,_0x42bf77=_0x2aa538,_0x504f11=_0x42bf77['config']['emulator']?Cs(_0x2aa538['config'],_0x3ccc66):_0x2aa538['config']['apiScheme']+'://'+_0x3ccc66;return lf['includes'](_0x1a31fd)&&(await _0x42bf77['_persistenceManagerAvailable'],_0x42bf77['_getPersistenceType']()==='COOKIE')?_0x42bf77['_getPersistence']()['_getFinalTarget'](_0x504f11)['toString']():_0x504f11;}function uf(_0x50cc8e){switch(_0x50cc8e){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x9abcc6){this['auth']=_0x9abcc6,this['timer']=null,this['promise']=new Promise((_0x4cdd18,_0x2b6d13)=>{this['timer']=setTimeout(()=>_0x2b6d13(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x1b5754,_0x4539f2,_0x114805){const _0x414c80={'appName':_0x1b5754['name']};_0x114805['email']&&(_0x414c80['email']=_0x114805['email']),_0x114805['phoneNumber']&&(_0x414c80['phoneNumber']=_0x114805['phoneNumber']);const _0x65c2e3=X(_0x1b5754,_0x4539f2,_0x414c80);return _0x65c2e3['customData']['_tokenResponse']=_0x114805,_0x65c2e3;}function wr(_0x3ad6d0){return _0x3ad6d0!==void 0x0&&_0x3ad6d0['enterprise']!==void 0x0;}class ff{constructor(_0x31801b){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x31801b['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x31801b['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x31801b['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0xe02a20){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3c45bb of this['recaptchaEnforcementState'])if(_0x3c45bb['provider']&&_0x3c45bb['provider']===_0xe02a20)return uf(_0x3c45bb['enforcementState']);return null;}['isProviderEnabled'](_0x322afd){return this['getProviderEnforcementState'](_0x322afd)==='ENFORCE'||this['getProviderEnforcementState'](_0x322afd)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x166014,_0x32d3ef){return Ae(_0x166014,'GET','/v2/recaptchaConfig',Re(_0x166014,_0x32d3ef));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x36fa52,_0x395c91){return Ae(_0x36fa52,'POST','/v1/accounts:delete',_0x395c91);}async function bn(_0x159b74,_0x153c22){return Ae(_0x159b74,'POST','/v1/accounts:lookup',_0x153c22);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x4bc3c2){if(_0x4bc3c2)try{const _0x54e10a=new Date(Number(_0x4bc3c2));if(!isNaN(_0x54e10a['getTime']()))return _0x54e10a['toUTCString']();}catch{}}async function gf(_0x553527,_0x3b63c7=!0x1){const _0x476471=N(_0x553527),_0x4eb8b2=await _0x476471['getIdToken'](_0x3b63c7),_0x2846e2=Ts(_0x4eb8b2);m(_0x2846e2&&_0x2846e2['exp']&&_0x2846e2['auth_time']&&_0x2846e2['iat'],_0x476471['auth'],'internal-error');const _0x534122=typeof _0x2846e2['firebase']=='object'?_0x2846e2['firebase']:void 0x0,_0x562cd3=_0x534122==null?void 0x0:_0x534122['sign_in_provider'];return{'claims':_0x2846e2,'token':_0x4eb8b2,'authTime':Rt(li(_0x2846e2['auth_time'])),'issuedAtTime':Rt(li(_0x2846e2['iat'])),'expirationTime':Rt(li(_0x2846e2['exp'])),'signInProvider':_0x562cd3||null,'signInSecondFactor':(_0x534122==null?void 0x0:_0x534122['sign_in_second_factor'])||null};}function li(_0x43bf49){return Number(_0x43bf49)*0x3e8;}function Ts(_0x42c83b){const [_0x4feaef,_0x2c26f6,_0x229110]=_0x42c83b['split']('.');if(_0x4feaef===void 0x0||_0x2c26f6===void 0x0||_0x229110===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x2e9813=ln(_0x2c26f6);return _0x2e9813?JSON['parse'](_0x2e9813):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x261190){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x261190==null?void 0x0:_0x261190['toString']()),null;}}function Cr(_0x10e19f){const _0x103efa=Ts(_0x10e19f);return m(_0x103efa,'internal-error'),m(typeof _0x103efa['exp']<'u','internal-error'),m(typeof _0x103efa['iat']<'u','internal-error'),Number(_0x103efa['exp'])-Number(_0x103efa['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x2128f5,_0x9a851d,_0x5a8a29=!0x1){if(_0x5a8a29)return _0x9a851d;try{return await _0x9a851d;}catch(_0x2b296c){throw _0x2b296c instanceof Se&&mf(_0x2b296c)&&_0x2128f5['auth']['currentUser']===_0x2128f5&&await _0x2128f5['auth']['signOut'](),_0x2b296c;}}function mf({code:_0x4812bc}){return _0x4812bc==='auth/user-disabled'||_0x4812bc==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x5a0a67){this['user']=_0x5a0a67,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x7879e3){if(_0x7879e3){const _0x4b1273=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x4b1273;}else{this['errorBackoff']=0x7530;const _0x381924=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x381924);}}['schedule'](_0x1962f8=!0x1){if(!this['isRunning'])return;const _0x31f094=this['getInterval'](_0x1962f8);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x31f094);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0xf7df29){(_0xf7df29==null?void 0x0:_0xf7df29['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x335601,_0x4b38bc){this['createdAt']=_0x335601,this['lastLoginAt']=_0x4b38bc,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x4556bc){this['createdAt']=_0x4556bc['createdAt'],this['lastLoginAt']=_0x4556bc['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x5ca910){var _0x318844;const _0x40f301=_0x5ca910['auth'],_0x5773a3=await _0x5ca910['getIdToken'](),_0x49875b=await Ut(_0x5ca910,bn(_0x40f301,{'idToken':_0x5773a3}));m(_0x49875b==null?void 0x0:_0x49875b['users']['length'],_0x40f301,'internal-error');const _0x4959dc=_0x49875b['users'][0x0];_0x5ca910['_notifyReloadListener'](_0x4959dc);const _0x4aabbe=(_0x318844=_0x4959dc['providerUserInfo'])!=null&&_0x318844['length']?Sa(_0x4959dc['providerUserInfo']):[],_0x339ec2=Ef(_0x5ca910['providerData'],_0x4aabbe),_0x2a7977=_0x5ca910['isAnonymous'],_0x4d79b8=!(_0x5ca910['email']&&_0x4959dc['passwordHash'])&&!(_0x339ec2!=null&&_0x339ec2['length']),_0x3a5c61=_0x2a7977?_0x4d79b8:!0x1,_0x316ced={'uid':_0x4959dc['localId'],'displayName':_0x4959dc['displayName']||null,'photoURL':_0x4959dc['photoUrl']||null,'email':_0x4959dc['email']||null,'emailVerified':_0x4959dc['emailVerified']||!0x1,'phoneNumber':_0x4959dc['phoneNumber']||null,'tenantId':_0x4959dc['tenantId']||null,'providerData':_0x339ec2,'metadata':new Oi(_0x4959dc['createdAt'],_0x4959dc['lastLoginAt']),'isAnonymous':_0x3a5c61};Object['assign'](_0x5ca910,_0x316ced);}async function vf(_0x35d3dd){const _0x2a0c98=N(_0x35d3dd);await Rn(_0x2a0c98),await _0x2a0c98['auth']['_persistUserIfCurrent'](_0x2a0c98),_0x2a0c98['auth']['_notifyListenersIfCurrent'](_0x2a0c98);}function Ef(_0x4959cb,_0x2f610e){return[..._0x4959cb['filter'](_0x42ecba=>!_0x2f610e['some'](_0x4a1ef2=>_0x4a1ef2['providerId']===_0x42ecba['providerId'])),..._0x2f610e];}function Sa(_0x2004ed){return _0x2004ed['map'](({providerId:_0x411446,..._0x210f27})=>({'providerId':_0x411446,'uid':_0x210f27['rawId']||'','displayName':_0x210f27['displayName']||null,'email':_0x210f27['email']||null,'phoneNumber':_0x210f27['phoneNumber']||null,'photoURL':_0x210f27['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x4c34e3,_0x8eae8d){const _0x205fc8=await Ca(_0x4c34e3,{},async()=>{const _0x1ed24a=ct({'grant_type':'refresh_token','refresh_token':_0x8eae8d})['slice'](0x1),{tokenApiHost:_0x2f083d,apiKey:_0x2c41c0}=_0x4c34e3['config'],_0x40af6e=await Ta(_0x4c34e3,_0x2f083d,'/v1/token','key='+_0x2c41c0),_0x54fc76=await _0x4c34e3['_getAdditionalHeaders']();_0x54fc76['Content-Type']='application/x-www-form-urlencoded';const _0x1ff4b5={'method':'POST','headers':_0x54fc76,'body':_0x1ed24a};return _0x4c34e3['emulatorConfig']&&at(_0x4c34e3['emulatorConfig']['host'])&&(_0x1ff4b5['credentials']='include'),wa['fetch']()(_0x40af6e,_0x1ff4b5);});return{'accessToken':_0x205fc8['access_token'],'expiresIn':_0x205fc8['expires_in'],'refreshToken':_0x205fc8['refresh_token']};}async function wf(_0x5bfcea,_0x5ef15f){return Ae(_0x5bfcea,'POST','/v2/accounts:revokeToken',Re(_0x5bfcea,_0x5ef15f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x2d4a7c){m(_0x2d4a7c['idToken'],'internal-error'),m(typeof _0x2d4a7c['idToken']<'u','internal-error'),m(typeof _0x2d4a7c['refreshToken']<'u','internal-error');const _0x51b882='expiresIn'in _0x2d4a7c&&typeof _0x2d4a7c['expiresIn']<'u'?Number(_0x2d4a7c['expiresIn']):Cr(_0x2d4a7c['idToken']);this['updateTokensAndExpiration'](_0x2d4a7c['idToken'],_0x2d4a7c['refreshToken'],_0x51b882);}['updateFromIdToken'](_0x367b4d){m(_0x367b4d['length']!==0x0,'internal-error');const _0x8eb880=Cr(_0x367b4d);this['updateTokensAndExpiration'](_0x367b4d,null,_0x8eb880);}async['getToken'](_0x170c60,_0x547bc1=!0x1){return!_0x547bc1&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x170c60,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x170c60,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x4f64a3,_0x1a2b4f){const {accessToken:_0x426247,refreshToken:_0x24352e,expiresIn:_0x5ed7b1}=await If(_0x4f64a3,_0x1a2b4f);this['updateTokensAndExpiration'](_0x426247,_0x24352e,Number(_0x5ed7b1));}['updateTokensAndExpiration'](_0x4088ee,_0x3c0dec,_0x3b45d7){this['refreshToken']=_0x3c0dec||null,this['accessToken']=_0x4088ee||null,this['expirationTime']=Date['now']()+_0x3b45d7*0x3e8;}static['fromJSON'](_0x1af0fe,_0x2e8494){const {refreshToken:_0x3fe96d,accessToken:_0x123622,expirationTime:_0x4daa50}=_0x2e8494,_0x262841=new Qe();return _0x3fe96d&&(m(typeof _0x3fe96d=='string','internal-error',{'appName':_0x1af0fe}),_0x262841['refreshToken']=_0x3fe96d),_0x123622&&(m(typeof _0x123622=='string','internal-error',{'appName':_0x1af0fe}),_0x262841['accessToken']=_0x123622),_0x4daa50&&(m(typeof _0x4daa50=='number','internal-error',{'appName':_0x1af0fe}),_0x262841['expirationTime']=_0x4daa50),_0x262841;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x82b55d){this['accessToken']=_0x82b55d['accessToken'],this['refreshToken']=_0x82b55d['refreshToken'],this['expirationTime']=_0x82b55d['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x5862c4,_0x27aa7b){m(typeof _0x5862c4=='string'||typeof _0x5862c4>'u','internal-error',{'appName':_0x27aa7b});}class K{constructor({uid:_0x1c0cd7,auth:_0xa82335,stsTokenManager:_0x311a94,..._0x10d1ea}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1c0cd7,this['auth']=_0xa82335,this['stsTokenManager']=_0x311a94,this['accessToken']=_0x311a94['accessToken'],this['displayName']=_0x10d1ea['displayName']||null,this['email']=_0x10d1ea['email']||null,this['emailVerified']=_0x10d1ea['emailVerified']||!0x1,this['phoneNumber']=_0x10d1ea['phoneNumber']||null,this['photoURL']=_0x10d1ea['photoURL']||null,this['isAnonymous']=_0x10d1ea['isAnonymous']||!0x1,this['tenantId']=_0x10d1ea['tenantId']||null,this['providerData']=_0x10d1ea['providerData']?[..._0x10d1ea['providerData']]:[],this['metadata']=new Oi(_0x10d1ea['createdAt']||void 0x0,_0x10d1ea['lastLoginAt']||void 0x0);}async['getIdToken'](_0x51b2d6){const _0x57d687=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x51b2d6));return m(_0x57d687,this['auth'],'internal-error'),this['accessToken']!==_0x57d687&&(this['accessToken']=_0x57d687,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x57d687;}['getIdTokenResult'](_0x5c0d92){return gf(this,_0x5c0d92);}['reload'](){return vf(this);}['_assign'](_0x36bc95){this!==_0x36bc95&&(m(this['uid']===_0x36bc95['uid'],this['auth'],'internal-error'),this['displayName']=_0x36bc95['displayName'],this['photoURL']=_0x36bc95['photoURL'],this['email']=_0x36bc95['email'],this['emailVerified']=_0x36bc95['emailVerified'],this['phoneNumber']=_0x36bc95['phoneNumber'],this['isAnonymous']=_0x36bc95['isAnonymous'],this['tenantId']=_0x36bc95['tenantId'],this['providerData']=_0x36bc95['providerData']['map'](_0x230aa7=>({..._0x230aa7})),this['metadata']['_copy'](_0x36bc95['metadata']),this['stsTokenManager']['_assign'](_0x36bc95['stsTokenManager']));}['_clone'](_0x3cc97c){const _0x203f94=new K({...this,'auth':_0x3cc97c,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x203f94['metadata']['_copy'](this['metadata']),_0x203f94;}['_onReload'](_0x19c514){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x19c514,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0xc8e588){this['reloadListener']?this['reloadListener'](_0xc8e588):this['reloadUserInfo']=_0xc8e588;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x36e515,_0x588111=!0x1){let _0x343cd6=!0x1;_0x36e515['idToken']&&_0x36e515['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x36e515),_0x343cd6=!0x0),_0x588111&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x343cd6&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x45a92a=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x45a92a})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x50d9dc=>({..._0x50d9dc})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x7e8350,_0xf1b807){const _0x44e6a0=_0xf1b807['displayName']??void 0x0,_0x39d9ab=_0xf1b807['email']??void 0x0,_0x4aaf64=_0xf1b807['phoneNumber']??void 0x0,_0x2d585e=_0xf1b807['photoURL']??void 0x0,_0x1168a2=_0xf1b807['tenantId']??void 0x0,_0x4f3422=_0xf1b807['_redirectEventId']??void 0x0,_0xf97422=_0xf1b807['createdAt']??void 0x0,_0x1038e9=_0xf1b807['lastLoginAt']??void 0x0,{uid:_0x2421a6,emailVerified:_0x4efb95,isAnonymous:_0x644942,providerData:_0x5115e2,stsTokenManager:_0x400775}=_0xf1b807;m(_0x2421a6&&_0x400775,_0x7e8350,'internal-error');const _0x27f994=Qe['fromJSON'](this['name'],_0x400775);m(typeof _0x2421a6=='string',_0x7e8350,'internal-error'),le(_0x44e6a0,_0x7e8350['name']),le(_0x39d9ab,_0x7e8350['name']),m(typeof _0x4efb95=='boolean',_0x7e8350,'internal-error'),m(typeof _0x644942=='boolean',_0x7e8350,'internal-error'),le(_0x4aaf64,_0x7e8350['name']),le(_0x2d585e,_0x7e8350['name']),le(_0x1168a2,_0x7e8350['name']),le(_0x4f3422,_0x7e8350['name']),le(_0xf97422,_0x7e8350['name']),le(_0x1038e9,_0x7e8350['name']);const _0x5a7145=new K({'uid':_0x2421a6,'auth':_0x7e8350,'email':_0x39d9ab,'emailVerified':_0x4efb95,'displayName':_0x44e6a0,'isAnonymous':_0x644942,'photoURL':_0x2d585e,'phoneNumber':_0x4aaf64,'tenantId':_0x1168a2,'stsTokenManager':_0x27f994,'createdAt':_0xf97422,'lastLoginAt':_0x1038e9});return _0x5115e2&&Array['isArray'](_0x5115e2)&&(_0x5a7145['providerData']=_0x5115e2['map'](_0x5d4408=>({..._0x5d4408}))),_0x4f3422&&(_0x5a7145['_redirectEventId']=_0x4f3422),_0x5a7145;}static async['_fromIdTokenResponse'](_0x312792,_0x445d98,_0x5629ca=!0x1){const _0x551eae=new Qe();_0x551eae['updateFromServerResponse'](_0x445d98);const _0x182513=new K({'uid':_0x445d98['localId'],'auth':_0x312792,'stsTokenManager':_0x551eae,'isAnonymous':_0x5629ca});return await Rn(_0x182513),_0x182513;}static async['_fromGetAccountInfoResponse'](_0x4d7ebb,_0x5917a7,_0xcd33e3){const _0x2e9600=_0x5917a7['users'][0x0];m(_0x2e9600['localId']!==void 0x0,'internal-error');const _0x3542db=_0x2e9600['providerUserInfo']!==void 0x0?Sa(_0x2e9600['providerUserInfo']):[],_0x278bd5=!(_0x2e9600['email']&&_0x2e9600['passwordHash'])&&!(_0x3542db!=null&&_0x3542db['length']),_0x2de63b=new Qe();_0x2de63b['updateFromIdToken'](_0xcd33e3);const _0xa3cb22=new K({'uid':_0x2e9600['localId'],'auth':_0x4d7ebb,'stsTokenManager':_0x2de63b,'isAnonymous':_0x278bd5}),_0x54dd6d={'uid':_0x2e9600['localId'],'displayName':_0x2e9600['displayName']||null,'photoURL':_0x2e9600['photoUrl']||null,'email':_0x2e9600['email']||null,'emailVerified':_0x2e9600['emailVerified']||!0x1,'phoneNumber':_0x2e9600['phoneNumber']||null,'tenantId':_0x2e9600['tenantId']||null,'providerData':_0x3542db,'metadata':new Oi(_0x2e9600['createdAt'],_0x2e9600['lastLoginAt']),'isAnonymous':!(_0x2e9600['email']&&_0x2e9600['passwordHash'])&&!(_0x3542db!=null&&_0x3542db['length'])};return Object['assign'](_0xa3cb22,_0x54dd6d),_0xa3cb22;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x37ee34){ce(_0x37ee34 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x296db3=Tr['get'](_0x37ee34);return _0x296db3?(ce(_0x296db3 instanceof _0x37ee34,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x296db3):(_0x296db3=new _0x37ee34(),Tr['set'](_0x37ee34,_0x296db3),_0x296db3);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x508851,_0x1c723a){this['storage'][_0x508851]=_0x1c723a;}async['_get'](_0x318f21){const _0x35c911=this['storage'][_0x318f21];return _0x35c911===void 0x0?null:_0x35c911;}async['_remove'](_0x515632){delete this['storage'][_0x515632];}['_addListener'](_0x335fd0,_0x470f1f){}['_removeListener'](_0x3c2283,_0x4ed1e9){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x5696ff,_0x5211fb,_0x3e1c1c){return'firebase:'+_0x5696ff+':'+_0x5211fb+':'+_0x3e1c1c;}class Je{constructor(_0x282fcb,_0x1eac9b,_0x10212e){this['persistence']=_0x282fcb,this['auth']=_0x1eac9b,this['userKey']=_0x10212e;const {config:_0x3ad851,name:_0x53c0d5}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x3ad851['apiKey'],_0x53c0d5),this['fullPersistenceKey']=rn('persistence',_0x3ad851['apiKey'],_0x53c0d5),this['boundEventHandler']=_0x1eac9b['_onStorageEvent']['bind'](_0x1eac9b),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x15430c){return this['persistence']['_set'](this['fullUserKey'],_0x15430c['toJSON']());}async['getCurrentUser'](){const _0x50d9a6=await this['persistence']['_get'](this['fullUserKey']);if(!_0x50d9a6)return null;if(typeof _0x50d9a6=='string'){const _0x263cb8=await bn(this['auth'],{'idToken':_0x50d9a6})['catch'](()=>{});return _0x263cb8?K['_fromGetAccountInfoResponse'](this['auth'],_0x263cb8,_0x50d9a6):null;}return K['_fromJSON'](this['auth'],_0x50d9a6);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x53ace3){if(this['persistence']===_0x53ace3)return;const _0x2a6304=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x53ace3,_0x2a6304)return this['setCurrentUser'](_0x2a6304);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x2ad5ce,_0x136f4f,_0x4218f2='authUser'){if(!_0x136f4f['length'])return new Je(ie(Sr),_0x2ad5ce,_0x4218f2);const _0xc25dd5=(await Promise['all'](_0x136f4f['map'](async _0x266dad=>{if(await _0x266dad['_isAvailable']())return _0x266dad;})))['filter'](_0x33d4d0=>_0x33d4d0);let _0x30f6b0=_0xc25dd5[0x0]||ie(Sr);const _0x1bf159=rn(_0x4218f2,_0x2ad5ce['config']['apiKey'],_0x2ad5ce['name']);let _0x273e61=null;for(const _0x1d936f of _0x136f4f)try{const _0x47ccc4=await _0x1d936f['_get'](_0x1bf159);if(_0x47ccc4){let _0x3a19a6;if(typeof _0x47ccc4=='string'){const _0x2ecd8a=await bn(_0x2ad5ce,{'idToken':_0x47ccc4})['catch'](()=>{});if(!_0x2ecd8a)break;_0x3a19a6=await K['_fromGetAccountInfoResponse'](_0x2ad5ce,_0x2ecd8a,_0x47ccc4);}else _0x3a19a6=K['_fromJSON'](_0x2ad5ce,_0x47ccc4);_0x1d936f!==_0x30f6b0&&(_0x273e61=_0x3a19a6),_0x30f6b0=_0x1d936f;break;}}catch{}const _0x2fa841=_0xc25dd5['filter'](_0x12827d=>_0x12827d['_shouldAllowMigration']);return!_0x30f6b0['_shouldAllowMigration']||!_0x2fa841['length']?new Je(_0x30f6b0,_0x2ad5ce,_0x4218f2):(_0x30f6b0=_0x2fa841[0x0],_0x273e61&&await _0x30f6b0['_set'](_0x1bf159,_0x273e61['toJSON']()),await Promise['all'](_0x136f4f['map'](async _0x14e857=>{if(_0x14e857!==_0x30f6b0)try{await _0x14e857['_remove'](_0x1bf159);}catch{}})),new Je(_0x30f6b0,_0x2ad5ce,_0x4218f2));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x452547){const _0x411e05=_0x452547['toLowerCase']();if(_0x411e05['includes']('opera/')||_0x411e05['includes']('opr/')||_0x411e05['includes']('opios/'))return'Opera';if(Na(_0x411e05))return'IEMobile';if(_0x411e05['includes']('msie')||_0x411e05['includes']('trident/'))return'IE';if(_0x411e05['includes']('edge/'))return'Edge';if(Ra(_0x411e05))return'Firefox';if(_0x411e05['includes']('silk/'))return'Silk';if(Oa(_0x411e05))return'Blackberry';if(Da(_0x411e05))return'Webos';if(Aa(_0x411e05))return'Safari';if((_0x411e05['includes']('chrome/')||ka(_0x411e05))&&!_0x411e05['includes']('edge/'))return'Chrome';if(Pa(_0x411e05))return'Android';{const _0x3aa90b=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x4bcf31=_0x452547['match'](_0x3aa90b);if((_0x4bcf31==null?void 0x0:_0x4bcf31['length'])===0x2)return _0x4bcf31[0x1];}return'Other';}function Ra(_0x6b1747=W()){return/firefox\//i['test'](_0x6b1747);}function Aa(_0x7c20da=W()){const _0x889ea2=_0x7c20da['toLowerCase']();return _0x889ea2['includes']('safari/')&&!_0x889ea2['includes']('chrome/')&&!_0x889ea2['includes']('crios/')&&!_0x889ea2['includes']('android');}function ka(_0x384519=W()){return/crios\//i['test'](_0x384519);}function Na(_0x2737df=W()){return/iemobile/i['test'](_0x2737df);}function Pa(_0x54f259=W()){return/android/i['test'](_0x54f259);}function Oa(_0x319c43=W()){return/blackberry/i['test'](_0x319c43);}function Da(_0xae1a70=W()){return/webos/i['test'](_0xae1a70);}function Ss(_0x322b51=W()){return/iphone|ipad|ipod/i['test'](_0x322b51)||/macintosh/i['test'](_0x322b51)&&/mobile/i['test'](_0x322b51);}function Cf(_0x2654d3=W()){var _0x5bba25;return Ss(_0x2654d3)&&!!((_0x5bba25=window['navigator'])!=null&&_0x5bba25['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x5a708b=W()){return Ss(_0x5a708b)||Pa(_0x5a708b)||Da(_0x5a708b)||Oa(_0x5a708b)||/windows phone/i['test'](_0x5a708b)||Na(_0x5a708b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x42d99e,_0x36c349=[]){let _0x2436db;switch(_0x42d99e){case'Browser':_0x2436db=br(W());break;case'Worker':_0x2436db=br(W())+'-'+_0x42d99e;break;default:_0x2436db=_0x42d99e;}const _0x46fef0=_0x36c349['length']?_0x36c349['join'](','):'FirebaseCore-web';return _0x2436db+'/JsCore/'+lt+'/'+_0x46fef0;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x1c6bb3){this['auth']=_0x1c6bb3,this['queue']=[];}['pushCallback'](_0x562d04,_0x11539f){const _0x1dc7a4=_0x52efbb=>new Promise((_0x492ce2,_0x4680a2)=>{try{const _0x21ec3f=_0x562d04(_0x52efbb);_0x492ce2(_0x21ec3f);}catch(_0x342bb6){_0x4680a2(_0x342bb6);}});_0x1dc7a4['onAbort']=_0x11539f,this['queue']['push'](_0x1dc7a4);const _0x949676=this['queue']['length']-0x1;return()=>{this['queue'][_0x949676]=()=>Promise['resolve']();};}async['runMiddleware'](_0x3d4b6e){if(this['auth']['currentUser']===_0x3d4b6e)return;const _0x4dd271=[];try{for(const _0x46d582 of this['queue'])await _0x46d582(_0x3d4b6e),_0x46d582['onAbort']&&_0x4dd271['push'](_0x46d582['onAbort']);}catch(_0x482564){_0x4dd271['reverse']();for(const _0x2360dd of _0x4dd271)try{_0x2360dd();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x482564==null?void 0x0:_0x482564['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x24daa7,_0x1c19dc={}){return Ae(_0x24daa7,'GET','/v2/passwordPolicy',Re(_0x24daa7,_0x1c19dc));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x48d1bc){var _0x1d9443;const _0x19c854=_0x48d1bc['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x19c854['minPasswordLength']??Rf,_0x19c854['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x19c854['maxPasswordLength']),_0x19c854['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x19c854['containsLowercaseCharacter']),_0x19c854['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x19c854['containsUppercaseCharacter']),_0x19c854['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x19c854['containsNumericCharacter']),_0x19c854['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x19c854['containsNonAlphanumericCharacter']),this['enforcementState']=_0x48d1bc['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x1d9443=_0x48d1bc['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x1d9443['join'](''))??'',this['forceUpgradeOnSignin']=_0x48d1bc['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x48d1bc['schemaVersion'];}['validatePassword'](_0x40ca04){const _0x75f4f8={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x40ca04,_0x75f4f8),this['validatePasswordCharacterOptions'](_0x40ca04,_0x75f4f8),_0x75f4f8['isValid']&&(_0x75f4f8['isValid']=_0x75f4f8['meetsMinPasswordLength']??!0x0),_0x75f4f8['isValid']&&(_0x75f4f8['isValid']=_0x75f4f8['meetsMaxPasswordLength']??!0x0),_0x75f4f8['isValid']&&(_0x75f4f8['isValid']=_0x75f4f8['containsLowercaseLetter']??!0x0),_0x75f4f8['isValid']&&(_0x75f4f8['isValid']=_0x75f4f8['containsUppercaseLetter']??!0x0),_0x75f4f8['isValid']&&(_0x75f4f8['isValid']=_0x75f4f8['containsNumericCharacter']??!0x0),_0x75f4f8['isValid']&&(_0x75f4f8['isValid']=_0x75f4f8['containsNonAlphanumericCharacter']??!0x0),_0x75f4f8;}['validatePasswordLengthOptions'](_0x652f43,_0x574edf){const _0x1d66e6=this['customStrengthOptions']['minPasswordLength'],_0x14a207=this['customStrengthOptions']['maxPasswordLength'];_0x1d66e6&&(_0x574edf['meetsMinPasswordLength']=_0x652f43['length']>=_0x1d66e6),_0x14a207&&(_0x574edf['meetsMaxPasswordLength']=_0x652f43['length']<=_0x14a207);}['validatePasswordCharacterOptions'](_0x36dfb9,_0x34be43){this['updatePasswordCharacterOptionsStatuses'](_0x34be43,!0x1,!0x1,!0x1,!0x1);let _0x43912a;for(let _0x257ec3=0x0;_0x257ec3<_0x36dfb9['length'];_0x257ec3++)_0x43912a=_0x36dfb9['charAt'](_0x257ec3),this['updatePasswordCharacterOptionsStatuses'](_0x34be43,_0x43912a>='a'&&_0x43912a<='z',_0x43912a>='A'&&_0x43912a<='Z',_0x43912a>='0'&&_0x43912a<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x43912a));}['updatePasswordCharacterOptionsStatuses'](_0xe5b04c,_0x3826fd,_0x393ca5,_0x5386b8,_0x5c5f30){this['customStrengthOptions']['containsLowercaseLetter']&&(_0xe5b04c['containsLowercaseLetter']||(_0xe5b04c['containsLowercaseLetter']=_0x3826fd)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0xe5b04c['containsUppercaseLetter']||(_0xe5b04c['containsUppercaseLetter']=_0x393ca5)),this['customStrengthOptions']['containsNumericCharacter']&&(_0xe5b04c['containsNumericCharacter']||(_0xe5b04c['containsNumericCharacter']=_0x5386b8)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0xe5b04c['containsNonAlphanumericCharacter']||(_0xe5b04c['containsNonAlphanumericCharacter']=_0x5c5f30));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x1b615c,_0x119d42,_0x474070,_0x3eba50){this['app']=_0x1b615c,this['heartbeatServiceProvider']=_0x119d42,this['appCheckServiceProvider']=_0x474070,this['config']=_0x3eba50,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x1b615c['name'],this['clientVersion']=_0x3eba50['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x1a9632=>this['_resolvePersistenceManagerAvailable']=_0x1a9632);}['_initializeWithPersistence'](_0xc4a4a1,_0x2b02ec){return _0x2b02ec&&(this['_popupRedirectResolver']=ie(_0x2b02ec)),this['_initializationPromise']=this['queue'](async()=>{var _0x1b1bb8,_0xe8977,_0x1bc8f3;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0xc4a4a1),(_0x1b1bb8=this['_resolvePersistenceManagerAvailable'])==null||_0x1b1bb8['call'](this),!this['_deleted'])){if((_0xe8977=this['_popupRedirectResolver'])!=null&&_0xe8977['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x2b02ec),this['lastNotifiedUid']=((_0x1bc8f3=this['currentUser'])==null?void 0x0:_0x1bc8f3['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x43280f=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x43280f)){if(this['currentUser']&&_0x43280f&&this['currentUser']['uid']===_0x43280f['uid']){this['_currentUser']['_assign'](_0x43280f),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x43280f,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x5df0f7){try{const _0x255b7f=await bn(this,{'idToken':_0x5df0f7}),_0x5ecf3a=await K['_fromGetAccountInfoResponse'](this,_0x255b7f,_0x5df0f7);await this['directlySetCurrentUser'](_0x5ecf3a);}catch(_0x5ad6bb){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x5ad6bb),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x3bc657){var _0x54b2eb;if($(this['app'])){const _0x59d3ee=this['app']['settings']['authIdToken'];return _0x59d3ee?new Promise(_0x51bcdd=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x59d3ee)['then'](_0x51bcdd,_0x51bcdd));}):this['directlySetCurrentUser'](null);}const _0x284984=await this['assertedPersistence']['getCurrentUser']();let _0x3f2773=_0x284984,_0xca20f9=!0x1;if(_0x3bc657&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x12c106=(_0x54b2eb=this['redirectUser'])==null?void 0x0:_0x54b2eb['_redirectEventId'],_0x6032de=_0x3f2773==null?void 0x0:_0x3f2773['_redirectEventId'],_0x359815=await this['tryRedirectSignIn'](_0x3bc657);(!_0x12c106||_0x12c106===_0x6032de)&&(_0x359815!=null&&_0x359815['user'])&&(_0x3f2773=_0x359815['user'],_0xca20f9=!0x0);}if(!_0x3f2773)return this['directlySetCurrentUser'](null);if(!_0x3f2773['_redirectEventId']){if(_0xca20f9)try{await this['beforeStateQueue']['runMiddleware'](_0x3f2773);}catch(_0xd86a40){_0x3f2773=_0x284984,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0xd86a40));}return _0x3f2773?this['reloadAndSetCurrentUserOrClear'](_0x3f2773):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x3f2773['_redirectEventId']?this['directlySetCurrentUser'](_0x3f2773):this['reloadAndSetCurrentUserOrClear'](_0x3f2773);}async['tryRedirectSignIn'](_0xc271f3){let _0x1e5924=null;try{_0x1e5924=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0xc271f3,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x1e5924;}async['reloadAndSetCurrentUserOrClear'](_0x116f73){try{await Rn(_0x116f73);}catch(_0x2b7b2b){if((_0x2b7b2b==null?void 0x0:_0x2b7b2b['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x116f73);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x2c3e71){if($(this['app']))return Promise['reject'](re(this));const _0x4e0084=_0x2c3e71?N(_0x2c3e71):null;return _0x4e0084&&m(_0x4e0084['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x4e0084&&_0x4e0084['_clone'](this));}async['_updateCurrentUser'](_0x2f99ab,_0x312f5a=!0x1){if(!this['_deleted'])return _0x2f99ab&&m(this['tenantId']===_0x2f99ab['tenantId'],this,'tenant-id-mismatch'),_0x312f5a||await this['beforeStateQueue']['runMiddleware'](_0x2f99ab),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x2f99ab),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x4746a2){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x4746a2));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x555fbe){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x1cff1f=this['_getPasswordPolicyInternal']();return _0x1cff1f['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x1cff1f['validatePassword'](_0x555fbe);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x51a479=await bf(this),_0x361d2a=new Af(_0x51a479);this['tenantId']===null?this['_projectPasswordPolicy']=_0x361d2a:this['_tenantPasswordPolicies'][this['tenantId']]=_0x361d2a;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x274d9e){this['_errorFactory']=new Bt('auth','Firebase',_0x274d9e());}['onAuthStateChanged'](_0x2e40a0,_0x4d2b5b,_0x34473a){return this['registerStateListener'](this['authStateSubscription'],_0x2e40a0,_0x4d2b5b,_0x34473a);}['beforeAuthStateChanged'](_0x17ba4e,_0x5776c0){return this['beforeStateQueue']['pushCallback'](_0x17ba4e,_0x5776c0);}['onIdTokenChanged'](_0x41d032,_0x32697c,_0x4dc198){return this['registerStateListener'](this['idTokenSubscription'],_0x41d032,_0x32697c,_0x4dc198);}['authStateReady'](){return new Promise((_0x2d4957,_0x2107de)=>{if(this['currentUser'])_0x2d4957();else{const _0x5386a2=this['onAuthStateChanged'](()=>{_0x5386a2(),_0x2d4957();},_0x2107de);}});}async['revokeAccessToken'](_0x577018){if(this['currentUser']){const _0x314595=await this['currentUser']['getIdToken'](),_0x244904={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x577018,'idToken':_0x314595};this['tenantId']!=null&&(_0x244904['tenantId']=this['tenantId']),await wf(this,_0x244904);}}['toJSON'](){var _0x339c5e;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x339c5e=this['_currentUser'])==null?void 0x0:_0x339c5e['toJSON']()};}async['_setRedirectUser'](_0x16e0b1,_0x504214){const _0x221434=await this['getOrInitRedirectPersistenceManager'](_0x504214);return _0x16e0b1===null?_0x221434['removeCurrentUser']():_0x221434['setCurrentUser'](_0x16e0b1);}async['getOrInitRedirectPersistenceManager'](_0x3f4221){if(!this['redirectPersistenceManager']){const _0x1040f0=_0x3f4221&&ie(_0x3f4221)||this['_popupRedirectResolver'];m(_0x1040f0,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x1040f0['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x1335ea){var _0x57899f,_0x2c918f;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x57899f=this['_currentUser'])==null?void 0x0:_0x57899f['_redirectEventId'])===_0x1335ea?this['_currentUser']:((_0x2c918f=this['redirectUser'])==null?void 0x0:_0x2c918f['_redirectEventId'])===_0x1335ea?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x43ef19){if(_0x43ef19===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x43ef19));}['_notifyListenersIfCurrent'](_0x40ff9f){_0x40ff9f===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x451276;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x1e72d0=((_0x451276=this['currentUser'])==null?void 0x0:_0x451276['uid'])??null;this['lastNotifiedUid']!==_0x1e72d0&&(this['lastNotifiedUid']=_0x1e72d0,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x8cbae5,_0x3ee8e5,_0x633bd8,_0x37287c){if(this['_deleted'])return()=>{};const _0x2102cd=typeof _0x3ee8e5=='function'?_0x3ee8e5:_0x3ee8e5['next']['bind'](_0x3ee8e5);let _0x1a1208=!0x1;const _0x27c6df=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x27c6df,this,'internal-error'),_0x27c6df['then'](()=>{_0x1a1208||_0x2102cd(this['currentUser']);}),typeof _0x3ee8e5=='function'){const _0x2e640c=_0x8cbae5['addObserver'](_0x3ee8e5,_0x633bd8,_0x37287c);return()=>{_0x1a1208=!0x0,_0x2e640c();};}else{const _0x1316ef=_0x8cbae5['addObserver'](_0x3ee8e5);return()=>{_0x1a1208=!0x0,_0x1316ef();};}}async['directlySetCurrentUser'](_0x2bff8d){this['currentUser']&&this['currentUser']!==_0x2bff8d&&this['_currentUser']['_stopProactiveRefresh'](),_0x2bff8d&&this['isProactiveRefreshEnabled']&&_0x2bff8d['_startProactiveRefresh'](),this['currentUser']=_0x2bff8d,_0x2bff8d?await this['assertedPersistence']['setCurrentUser'](_0x2bff8d):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x1e3647){return this['operations']=this['operations']['then'](_0x1e3647,_0x1e3647),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x57968d){!_0x57968d||this['frameworks']['includes'](_0x57968d)||(this['frameworks']['push'](_0x57968d),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x397ac2;const _0x2ed6b2={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x2ed6b2['X-Firebase-gmpid']=this['app']['options']['appId']);const _0xf2989f=await((_0x397ac2=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x397ac2['getHeartbeatsHeader']());_0xf2989f&&(_0x2ed6b2['X-Firebase-Client']=_0xf2989f);const _0x47cdda=await this['_getAppCheckToken']();return _0x47cdda&&(_0x2ed6b2['X-Firebase-AppCheck']=_0x47cdda),_0x2ed6b2;}async['_getAppCheckToken'](){var _0x3bbe16;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x15faf9=await((_0x3bbe16=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x3bbe16['getToken']());return _0x15faf9!=null&&_0x15faf9['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x15faf9['error']),_0x15faf9==null?void 0x0:_0x15faf9['token'];}}function qe(_0x463850){return N(_0x463850);}class Rr{constructor(_0x38ab5e){this['auth']=_0x38ab5e,this['observer']=null,this['addObserver']=Tc(_0x1da210=>this['observer']=_0x1da210);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x1af05d){jn=_0x1af05d;}function xa(_0x1b72d0){return jn['loadJS'](_0x1b72d0);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x4dee0a){return'__'+_0x4dee0a+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x51197b){_0x51197b();}['execute'](_0x103ede,_0x5c9f76){return Promise['resolve']('token');}['render'](_0x4cd843,_0x4b5a6e){return'';}}class Lf{['ready'](_0x2913af){_0x2913af();}['execute'](_0x168f3c,_0x1da8ad){return Promise['resolve']('token');}['render'](_0x5f5854,_0x3bcb69){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x416174){this['type']=xf,this['auth']=qe(_0x416174);}async['verify'](_0x490abf='verify',_0x533abd=!0x1){async function _0x1d3bde(_0x3a4186){if(!_0x533abd){if(_0x3a4186['tenantId']==null&&_0x3a4186['_agentRecaptchaConfig']!=null)return _0x3a4186['_agentRecaptchaConfig']['siteKey'];if(_0x3a4186['tenantId']!=null&&_0x3a4186['_tenantRecaptchaConfigs'][_0x3a4186['tenantId']]!==void 0x0)return _0x3a4186['_tenantRecaptchaConfigs'][_0x3a4186['tenantId']]['siteKey'];}return new Promise(async(_0x3cc172,_0x10c39b)=>{pf(_0x3a4186,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x4a8ab2=>{if(_0x4a8ab2['recaptchaKey']===void 0x0)_0x10c39b(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x258228=new ff(_0x4a8ab2);return _0x3a4186['tenantId']==null?_0x3a4186['_agentRecaptchaConfig']=_0x258228:_0x3a4186['_tenantRecaptchaConfigs'][_0x3a4186['tenantId']]=_0x258228,_0x3cc172(_0x258228['siteKey']);}})['catch'](_0x34945a=>{_0x10c39b(_0x34945a);});});}function _0x35e956(_0x292c6e,_0x5b4122,_0x4c671c){const _0x2ea5bc=window['grecaptcha'];wr(_0x2ea5bc)?_0x2ea5bc['enterprise']['ready'](()=>{_0x2ea5bc['enterprise']['execute'](_0x292c6e,{'action':_0x490abf})['then'](_0xdd377b=>{_0x5b4122(_0xdd377b);})['catch'](()=>{_0x5b4122(Fa);});}):_0x4c671c(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x539944,_0x4febd3)=>{_0x1d3bde(this['auth'])['then'](_0x43a059=>{if(!_0x533abd&&wr(window['grecaptcha']))_0x35e956(_0x43a059,_0x539944,_0x4febd3);else{if(typeof window>'u'){_0x4febd3(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x1f9c69=Pf();_0x1f9c69['length']!==0x0&&(_0x1f9c69+=_0x43a059),xa(_0x1f9c69)['then'](()=>{_0x35e956(_0x43a059,_0x539944,_0x4febd3);})['catch'](_0x36d872=>{_0x4febd3(_0x36d872);});}})['catch'](_0x353b3b=>{_0x4febd3(_0x353b3b);});});}}async function Ar(_0x5ea0b0,_0x3c77e2,_0x4b87ef,_0x5f5ab6=!0x1,_0x1d9a4e=!0x1){const _0x481d4d=new Ff(_0x5ea0b0);let _0x22e0d2;if(_0x1d9a4e)_0x22e0d2=Fa;else try{_0x22e0d2=await _0x481d4d['verify'](_0x4b87ef);}catch{_0x22e0d2=await _0x481d4d['verify'](_0x4b87ef,!0x0);}const _0x4ad053={..._0x3c77e2};if(_0x4b87ef==='mfaSmsEnrollment'||_0x4b87ef==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x4ad053){const _0x10c55e=_0x4ad053['phoneEnrollmentInfo']['phoneNumber'],_0x3a6a09=_0x4ad053['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x4ad053,{'phoneEnrollmentInfo':{'phoneNumber':_0x10c55e,'recaptchaToken':_0x3a6a09,'captchaResponse':_0x22e0d2,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x4ad053){const _0x47473c=_0x4ad053['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x4ad053,{'phoneSignInInfo':{'recaptchaToken':_0x47473c,'captchaResponse':_0x22e0d2,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x4ad053;}return _0x5f5ab6?Object['assign'](_0x4ad053,{'captchaResp':_0x22e0d2}):Object['assign'](_0x4ad053,{'captchaResponse':_0x22e0d2}),Object['assign'](_0x4ad053,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x4ad053,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x4ad053;}async function Di(_0x3bed7d,_0x272d26,_0x2b9fd6,_0x5a242c,_0x131796){var _0x23da37;if((_0x23da37=_0x3bed7d['_getRecaptchaConfig']())!=null&&_0x23da37['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x4ed416=await Ar(_0x3bed7d,_0x272d26,_0x2b9fd6,_0x2b9fd6==='getOobCode');return _0x5a242c(_0x3bed7d,_0x4ed416);}else return _0x5a242c(_0x3bed7d,_0x272d26)['catch'](async _0x3f83aa=>{if(_0x3f83aa['code']==='auth/missing-recaptcha-token'){console['log'](_0x2b9fd6+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x113637=await Ar(_0x3bed7d,_0x272d26,_0x2b9fd6,_0x2b9fd6==='getOobCode');return _0x5a242c(_0x3bed7d,_0x113637);}else return Promise['reject'](_0x3f83aa);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x5829eb,_0x39fff2){const _0x287f1e=Bi(_0x5829eb,'auth');if(_0x287f1e['isInitialized']()){const _0x5c48ee=_0x287f1e['getImmediate'](),_0x36ca4c=_0x287f1e['getOptions']();if(Me(_0x36ca4c,_0x39fff2??{}))return _0x5c48ee;Q(_0x5c48ee,'already-initialized');}return _0x287f1e['initialize']({'options':_0x39fff2});}function Wf(_0x410df3,_0xe2c4bc){const _0x1d0b05=(_0xe2c4bc==null?void 0x0:_0xe2c4bc['persistence'])||[],_0x49ab41=(Array['isArray'](_0x1d0b05)?_0x1d0b05:[_0x1d0b05])['map'](ie);_0xe2c4bc!=null&&_0xe2c4bc['errorMap']&&_0x410df3['_updateErrorMap'](_0xe2c4bc['errorMap']),_0x410df3['_initializeWithPersistence'](_0x49ab41,_0xe2c4bc==null?void 0x0:_0xe2c4bc['popupRedirectResolver']);}function Bf(_0x2978ab,_0x11050e,_0x52442f){const _0x2df370=qe(_0x2978ab);m(/^https?:\/\//['test'](_0x11050e),_0x2df370,'invalid-emulator-scheme');const _0x499262=!0x1,_0x4919d2=Ua(_0x11050e),{host:_0x4029b6,port:_0x3abcd4}=Vf(_0x11050e),_0x326e47=_0x3abcd4===null?'':':'+_0x3abcd4,_0x1ea197={'url':_0x4919d2+'//'+_0x4029b6+_0x326e47+'/'},_0x158bb2=Object['freeze']({'host':_0x4029b6,'port':_0x3abcd4,'protocol':_0x4919d2['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x499262})});if(!_0x2df370['_canInitEmulator']){m(_0x2df370['config']['emulator']&&_0x2df370['emulatorConfig'],_0x2df370,'emulator-config-failed'),m(Me(_0x1ea197,_0x2df370['config']['emulator'])&&Me(_0x158bb2,_0x2df370['emulatorConfig']),_0x2df370,'emulator-config-failed');return;}_0x2df370['config']['emulator']=_0x1ea197,_0x2df370['emulatorConfig']=_0x158bb2,_0x2df370['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x4029b6)?(jr(_0x4919d2+'//'+_0x4029b6+_0x326e47),Kr('Auth',!0x0)):Hf();}function Ua(_0x28ecba){const _0xa59951=_0x28ecba['indexOf'](':');return _0xa59951<0x0?'':_0x28ecba['substr'](0x0,_0xa59951+0x1);}function Vf(_0x56602d){const _0x2859cc=Ua(_0x56602d),_0x454b70=/(\/\/)?([^?#/]+)/['exec'](_0x56602d['substr'](_0x2859cc['length']));if(!_0x454b70)return{'host':'','port':null};const _0xac0265=_0x454b70[0x2]['split']('@')['pop']()||'',_0x3cbb01=/^(\[[^\]]+\])(:|$)/['exec'](_0xac0265);if(_0x3cbb01){const _0x3b30ac=_0x3cbb01[0x1];return{'host':_0x3b30ac,'port':kr(_0xac0265['substr'](_0x3b30ac['length']+0x1))};}else{const [_0x4cf043,_0x59a35d]=_0xac0265['split'](':');return{'host':_0x4cf043,'port':kr(_0x59a35d)};}}function kr(_0xe6dbf3){if(!_0xe6dbf3)return null;const _0x19a009=Number(_0xe6dbf3);return isNaN(_0x19a009)?null:_0x19a009;}function Hf(){function _0x1382cf(){const _0x3c01e4=document['createElement']('p'),_0x207c22=_0x3c01e4['style'];_0x3c01e4['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x207c22['position']='fixed',_0x207c22['width']='100%',_0x207c22['backgroundColor']='#ffffff',_0x207c22['border']='.1em\x20solid\x20#000000',_0x207c22['color']='#b50000',_0x207c22['bottom']='0px',_0x207c22['left']='0px',_0x207c22['margin']='0px',_0x207c22['zIndex']='10000',_0x207c22['textAlign']='center',_0x3c01e4['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x3c01e4);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1382cf):_0x1382cf());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x13c2d3,_0x2bda3e){this['providerId']=_0x13c2d3,this['signInMethod']=_0x2bda3e;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x203b1e){return ne('not\x20implemented');}['_linkToIdToken'](_0x556a1a,_0x2baa52){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x2f95d5){return ne('not\x20implemented');}}async function $f(_0x75b6df,_0x225502){return Ae(_0x75b6df,'POST','/v1/accounts:signUp',_0x225502);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0xcb4883,_0x1f6ca3){return Qt(_0xcb4883,'POST','/v1/accounts:signInWithPassword',Re(_0xcb4883,_0x1f6ca3));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x26acb5,_0x1f4da0){return Qt(_0x26acb5,'POST','/v1/accounts:signInWithEmailLink',Re(_0x26acb5,_0x1f4da0));}async function zf(_0x3143a1,_0x19f880){return Qt(_0x3143a1,'POST','/v1/accounts:signInWithEmailLink',Re(_0x3143a1,_0x19f880));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x4eb808,_0x53984d,_0x4e4218,_0x162aa0=null){super('password',_0x4e4218),this['_email']=_0x4eb808,this['_password']=_0x53984d,this['_tenantId']=_0x162aa0;}static['_fromEmailAndPassword'](_0x299e64,_0x95a73f){return new Wt(_0x299e64,_0x95a73f,'password');}static['_fromEmailAndCode'](_0x298984,_0x3158f9,_0x599394=null){return new Wt(_0x298984,_0x3158f9,'emailLink',_0x599394);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x525df9){const _0x1fc119=typeof _0x525df9=='string'?JSON['parse'](_0x525df9):_0x525df9;if(_0x1fc119!=null&&_0x1fc119['email']&&(_0x1fc119!=null&&_0x1fc119['password'])){if(_0x1fc119['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x1fc119['email'],_0x1fc119['password']);if(_0x1fc119['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x1fc119['email'],_0x1fc119['password'],_0x1fc119['tenantId']);}return null;}async['_getIdTokenResponse'](_0x49959e){switch(this['signInMethod']){case'password':const _0x3aa69d={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x49959e,_0x3aa69d,'signInWithPassword',Gf);case'emailLink':return qf(_0x49959e,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x49959e,'internal-error');}}async['_linkToIdToken'](_0x324a93,_0x1c84f1){switch(this['signInMethod']){case'password':const _0x316094={'idToken':_0x1c84f1,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x324a93,_0x316094,'signUpPassword',$f);case'emailLink':return zf(_0x324a93,{'idToken':_0x1c84f1,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x324a93,'internal-error');}}['_getReauthenticationResolver'](_0x4a13ab){return this['_getIdTokenResponse'](_0x4a13ab);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x5bfc66,_0x1d159d){return Qt(_0x5bfc66,'POST','/v1/accounts:signInWithIdp',Re(_0x5bfc66,_0x1d159d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x407348){const _0x54c9f3=new Be(_0x407348['providerId'],_0x407348['signInMethod']);return _0x407348['idToken']||_0x407348['accessToken']?(_0x407348['idToken']&&(_0x54c9f3['idToken']=_0x407348['idToken']),_0x407348['accessToken']&&(_0x54c9f3['accessToken']=_0x407348['accessToken']),_0x407348['nonce']&&!_0x407348['pendingToken']&&(_0x54c9f3['nonce']=_0x407348['nonce']),_0x407348['pendingToken']&&(_0x54c9f3['pendingToken']=_0x407348['pendingToken'])):_0x407348['oauthToken']&&_0x407348['oauthTokenSecret']?(_0x54c9f3['accessToken']=_0x407348['oauthToken'],_0x54c9f3['secret']=_0x407348['oauthTokenSecret']):Q('argument-error'),_0x54c9f3;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x3aedb1){const _0x57c46f=typeof _0x3aedb1=='string'?JSON['parse'](_0x3aedb1):_0x3aedb1,{providerId:_0x6ffb32,signInMethod:_0x3c2bf7,..._0x57740b}=_0x57c46f;if(!_0x6ffb32||!_0x3c2bf7)return null;const _0x3ab920=new Be(_0x6ffb32,_0x3c2bf7);return _0x3ab920['idToken']=_0x57740b['idToken']||void 0x0,_0x3ab920['accessToken']=_0x57740b['accessToken']||void 0x0,_0x3ab920['secret']=_0x57740b['secret'],_0x3ab920['nonce']=_0x57740b['nonce'],_0x3ab920['pendingToken']=_0x57740b['pendingToken']||null,_0x3ab920;}['_getIdTokenResponse'](_0x206d89){const _0x1271da=this['buildRequest']();return Xe(_0x206d89,_0x1271da);}['_linkToIdToken'](_0x2ee20c,_0x49f8fb){const _0x110f51=this['buildRequest']();return _0x110f51['idToken']=_0x49f8fb,Xe(_0x2ee20c,_0x110f51);}['_getReauthenticationResolver'](_0x44d18d){const _0x3cd056=this['buildRequest']();return _0x3cd056['autoCreate']=!0x1,Xe(_0x44d18d,_0x3cd056);}['buildRequest'](){const _0x50faa1={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x50faa1['pendingToken']=this['pendingToken'];else{const _0x3b7c81={};this['idToken']&&(_0x3b7c81['id_token']=this['idToken']),this['accessToken']&&(_0x3b7c81['access_token']=this['accessToken']),this['secret']&&(_0x3b7c81['oauth_token_secret']=this['secret']),_0x3b7c81['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x3b7c81['nonce']=this['nonce']),_0x50faa1['postBody']=ct(_0x3b7c81);}return _0x50faa1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x58ca3f){switch(_0x58ca3f){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x36ba94){const _0x3767e2=vt(Et(_0x36ba94))['link'],_0x29dd48=_0x3767e2?vt(Et(_0x3767e2))['deep_link_id']:null,_0x496cf2=vt(Et(_0x36ba94))['deep_link_id'];return(_0x496cf2?vt(Et(_0x496cf2))['link']:null)||_0x496cf2||_0x29dd48||_0x3767e2||_0x36ba94;}class Rs{constructor(_0x2c45b5){const _0x33baf9=vt(Et(_0x2c45b5)),_0x1033d1=_0x33baf9['apiKey']??null,_0x3517fe=_0x33baf9['oobCode']??null,_0x8a0a4=Kf(_0x33baf9['mode']??null);m(_0x1033d1&&_0x3517fe&&_0x8a0a4,'argument-error'),this['apiKey']=_0x1033d1,this['operation']=_0x8a0a4,this['code']=_0x3517fe,this['continueUrl']=_0x33baf9['continueUrl']??null,this['languageCode']=_0x33baf9['lang']??null,this['tenantId']=_0x33baf9['tenantId']??null;}static['parseLink'](_0x1951ab){const _0x4dcdf5=Yf(_0x1951ab);try{return new Rs(_0x4dcdf5);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x3ad9b6,_0x1f2895){return Wt['_fromEmailAndPassword'](_0x3ad9b6,_0x1f2895);}static['credentialWithLink'](_0x1823af,_0x10d1d4){const _0x30b49f=Rs['parseLink'](_0x10d1d4);return m(_0x30b49f,'argument-error'),Wt['_fromEmailAndCode'](_0x1823af,_0x30b49f['code'],_0x30b49f['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x571220){this['providerId']=_0x571220,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x31fbf1){this['defaultLanguageCode']=_0x31fbf1;}['setCustomParameters'](_0x761e25){return this['customParameters']=_0x761e25,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x36c56a){return this['scopes']['includes'](_0x36c56a)||this['scopes']['push'](_0x36c56a),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x259c1c){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x259c1c});}static['credentialFromResult'](_0xc8c54d){return he['credentialFromTaggedObject'](_0xc8c54d);}static['credentialFromError'](_0x547139){return he['credentialFromTaggedObject'](_0x547139['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3f2d56}){if(!_0x3f2d56||!('oauthAccessToken'in _0x3f2d56)||!_0x3f2d56['oauthAccessToken'])return null;try{return he['credential'](_0x3f2d56['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x2b523c,_0x4ef021){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x2b523c,'accessToken':_0x4ef021});}static['credentialFromResult'](_0x298c23){return ue['credentialFromTaggedObject'](_0x298c23);}static['credentialFromError'](_0x531a31){return ue['credentialFromTaggedObject'](_0x531a31['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x226509}){if(!_0x226509)return null;const {oauthIdToken:_0x3c0cde,oauthAccessToken:_0x1e4278}=_0x226509;if(!_0x3c0cde&&!_0x1e4278)return null;try{return ue['credential'](_0x3c0cde,_0x1e4278);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x3dc1ba){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x3dc1ba});}static['credentialFromResult'](_0x26e951){return de['credentialFromTaggedObject'](_0x26e951);}static['credentialFromError'](_0x44f40e){return de['credentialFromTaggedObject'](_0x44f40e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x9493b}){if(!_0x9493b||!('oauthAccessToken'in _0x9493b)||!_0x9493b['oauthAccessToken'])return null;try{return de['credential'](_0x9493b['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x2c49db,_0x38e20f){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x2c49db,'oauthTokenSecret':_0x38e20f});}static['credentialFromResult'](_0x41fada){return fe['credentialFromTaggedObject'](_0x41fada);}static['credentialFromError'](_0x11ac76){return fe['credentialFromTaggedObject'](_0x11ac76['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x39510f}){if(!_0x39510f)return null;const {oauthAccessToken:_0xe9014e,oauthTokenSecret:_0x57b87d}=_0x39510f;if(!_0xe9014e||!_0x57b87d)return null;try{return fe['credential'](_0xe9014e,_0x57b87d);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0xf0689,_0x15b22f){return Qt(_0xf0689,'POST','/v1/accounts:signUp',Re(_0xf0689,_0x15b22f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x24b8c9){this['user']=_0x24b8c9['user'],this['providerId']=_0x24b8c9['providerId'],this['_tokenResponse']=_0x24b8c9['_tokenResponse'],this['operationType']=_0x24b8c9['operationType'];}static async['_fromIdTokenResponse'](_0x8422cc,_0x1d9bf0,_0x56152c,_0x592b96=!0x1){const _0x5e7842=await K['_fromIdTokenResponse'](_0x8422cc,_0x56152c,_0x592b96),_0x1512b9=Nr(_0x56152c);return new Ve({'user':_0x5e7842,'providerId':_0x1512b9,'_tokenResponse':_0x56152c,'operationType':_0x1d9bf0});}static async['_forOperation'](_0x49c341,_0x437ed3,_0x5c7f4e){await _0x49c341['_updateTokensIfNecessary'](_0x5c7f4e,!0x0);const _0x15440d=Nr(_0x5c7f4e);return new Ve({'user':_0x49c341,'providerId':_0x15440d,'_tokenResponse':_0x5c7f4e,'operationType':_0x437ed3});}}function Nr(_0x3dbb24){return _0x3dbb24['providerId']?_0x3dbb24['providerId']:'phoneNumber'in _0x3dbb24?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x4bcc67,_0x4452f8,_0x593572,_0x1a890a){super(_0x4452f8['code'],_0x4452f8['message']),this['operationType']=_0x593572,this['user']=_0x1a890a,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x4bcc67['name'],'tenantId':_0x4bcc67['tenantId']??void 0x0,'_serverResponse':_0x4452f8['customData']['_serverResponse'],'operationType':_0x593572};}static['_fromErrorAndOperation'](_0x7ff899,_0x3cc3a8,_0x147a0a,_0x3f2609){return new An(_0x7ff899,_0x3cc3a8,_0x147a0a,_0x3f2609);}}function Ba(_0x585a32,_0x9c4a65,_0xeecbdf,_0xd6b472){return(_0x9c4a65==='reauthenticate'?_0xeecbdf['_getReauthenticationResolver'](_0x585a32):_0xeecbdf['_getIdTokenResponse'](_0x585a32))['catch'](_0x1d8921=>{throw _0x1d8921['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x585a32,_0x1d8921,_0x9c4a65,_0xd6b472):_0x1d8921;});}async function Jf(_0x1ebf63,_0x58fdab,_0x26e880=!0x1){const _0x34983d=await Ut(_0x1ebf63,_0x58fdab['_linkToIdToken'](_0x1ebf63['auth'],await _0x1ebf63['getIdToken']()),_0x26e880);return Ve['_forOperation'](_0x1ebf63,'link',_0x34983d);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x2d1e2a,_0x5d1d5f,_0xb73e07=!0x1){const {auth:_0x1a7d96}=_0x2d1e2a;if($(_0x1a7d96['app']))return Promise['reject'](re(_0x1a7d96));const _0x17109b='reauthenticate';try{const _0x4a5737=await Ut(_0x2d1e2a,Ba(_0x1a7d96,_0x17109b,_0x5d1d5f,_0x2d1e2a),_0xb73e07);m(_0x4a5737['idToken'],_0x1a7d96,'internal-error');const _0x59fec2=Ts(_0x4a5737['idToken']);m(_0x59fec2,_0x1a7d96,'internal-error');const {sub:_0x135203}=_0x59fec2;return m(_0x2d1e2a['uid']===_0x135203,_0x1a7d96,'user-mismatch'),Ve['_forOperation'](_0x2d1e2a,_0x17109b,_0x4a5737);}catch(_0x1ccbab){throw(_0x1ccbab==null?void 0x0:_0x1ccbab['code'])==='auth/user-not-found'&&Q(_0x1a7d96,'user-mismatch'),_0x1ccbab;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x4df4ed,_0x3e2137,_0x4eb60c=!0x1){if($(_0x4df4ed['app']))return Promise['reject'](re(_0x4df4ed));const _0x87ba46='signIn',_0x2632c3=await Ba(_0x4df4ed,_0x87ba46,_0x3e2137),_0x356233=await Ve['_fromIdTokenResponse'](_0x4df4ed,_0x87ba46,_0x2632c3);return _0x4eb60c||await _0x4df4ed['_updateCurrentUser'](_0x356233['user']),_0x356233;}async function Zf(_0x38b5ed,_0x5e0616){return Va(qe(_0x38b5ed),_0x5e0616);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x107684){const _0x2d0a05=qe(_0x107684);_0x2d0a05['_getPasswordPolicyInternal']()&&await _0x2d0a05['_updatePasswordPolicy']();}async function P_(_0x29df46,_0x5333ab,_0x1f64d6){if($(_0x29df46['app']))return Promise['reject'](re(_0x29df46));const _0x187d56=qe(_0x29df46),_0xadc6b6=await Di(_0x187d56,{'returnSecureToken':!0x0,'email':_0x5333ab,'password':_0x1f64d6,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x1b986e=>{throw _0x1b986e['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x29df46),_0x1b986e;}),_0x1a52b3=await Ve['_fromIdTokenResponse'](_0x187d56,'signIn',_0xadc6b6);return await _0x187d56['_updateCurrentUser'](_0x1a52b3['user']),_0x1a52b3;}function O_(_0x846b90,_0x2c9c6f,_0x27438f){return $(_0x846b90['app'])?Promise['reject'](re(_0x846b90)):Zf(N(_0x846b90),pt['credential'](_0x2c9c6f,_0x27438f))['catch'](async _0x7301c1=>{throw _0x7301c1['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x846b90),_0x7301c1;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x14bfe1,_0x3a37e3){return N(_0x14bfe1)['setPersistence'](_0x3a37e3);}function ep(_0x39a1b4,_0x163606,_0x301d01,_0x4189a0){return N(_0x39a1b4)['onIdTokenChanged'](_0x163606,_0x301d01,_0x4189a0);}function tp(_0x3b5da1,_0x581666,_0x5635fd){return N(_0x3b5da1)['beforeAuthStateChanged'](_0x581666,_0x5635fd);}function M_(_0x54fde0,_0x452c58,_0x888ab6,_0x4d2fa1){return N(_0x54fde0)['onAuthStateChanged'](_0x452c58,_0x888ab6,_0x4d2fa1);}function L_(_0x4c2089){return N(_0x4c2089)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x48b471,_0x582545){this['storageRetriever']=_0x48b471,this['type']=_0x582545;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x46f33a,_0x237cb2){return this['storage']['setItem'](_0x46f33a,JSON['stringify'](_0x237cb2)),Promise['resolve']();}['_get'](_0x4c5c8e){const _0x24b439=this['storage']['getItem'](_0x4c5c8e);return Promise['resolve'](_0x24b439?JSON['parse'](_0x24b439):null);}['_remove'](_0x437b46){return this['storage']['removeItem'](_0x437b46),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x7ab458,_0x488406)=>this['onStorageEvent'](_0x7ab458,_0x488406),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x43d43c){for(const _0x2372fc of Object['keys'](this['listeners'])){const _0x4f047e=this['storage']['getItem'](_0x2372fc),_0x14ec70=this['localCache'][_0x2372fc];_0x4f047e!==_0x14ec70&&_0x43d43c(_0x2372fc,_0x14ec70,_0x4f047e);}}['onStorageEvent'](_0x268e89,_0x2ca7b3=!0x1){if(!_0x268e89['key']){this['forAllChangedKeys']((_0x21f928,_0x5d97d0,_0x541828)=>{this['notifyListeners'](_0x21f928,_0x541828);});return;}const _0x8f9a71=_0x268e89['key'];_0x2ca7b3?this['detachListener']():this['stopPolling']();const _0x4422ff=()=>{const _0x47c5d=this['storage']['getItem'](_0x8f9a71);!_0x2ca7b3&&this['localCache'][_0x8f9a71]===_0x47c5d||this['notifyListeners'](_0x8f9a71,_0x47c5d);},_0x30d8f8=this['storage']['getItem'](_0x8f9a71);Tf()&&_0x30d8f8!==_0x268e89['newValue']&&_0x268e89['newValue']!==_0x268e89['oldValue']?setTimeout(_0x4422ff,ip):_0x4422ff();}['notifyListeners'](_0x42de06,_0x1f4f8c){this['localCache'][_0x42de06]=_0x1f4f8c;const _0x573680=this['listeners'][_0x42de06];if(_0x573680){for(const _0x41ccd2 of Array['from'](_0x573680))_0x41ccd2(_0x1f4f8c&&JSON['parse'](_0x1f4f8c));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x33d868,_0x3448a6,_0x3ab38b)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x33d868,'oldValue':_0x3448a6,'newValue':_0x3ab38b}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x25c238,_0x1c20c5){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x25c238]||(this['listeners'][_0x25c238]=new Set(),this['localCache'][_0x25c238]=this['storage']['getItem'](_0x25c238)),this['listeners'][_0x25c238]['add'](_0x1c20c5);}['_removeListener'](_0x4743c3,_0x2bcf06){this['listeners'][_0x4743c3]&&(this['listeners'][_0x4743c3]['delete'](_0x2bcf06),this['listeners'][_0x4743c3]['size']===0x0&&delete this['listeners'][_0x4743c3]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x4252ff,_0x49ec8f){await super['_set'](_0x4252ff,_0x49ec8f),this['localCache'][_0x4252ff]=JSON['stringify'](_0x49ec8f);}async['_get'](_0x28c62a){const _0x3b0130=await super['_get'](_0x28c62a);return this['localCache'][_0x28c62a]=JSON['stringify'](_0x3b0130),_0x3b0130;}async['_remove'](_0x4910c1){await super['_remove'](_0x4910c1),delete this['localCache'][_0x4910c1];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x2f7402,_0x429625){}['_removeListener'](_0x21a390,_0x178ee8){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x1fe30f){return Promise['all'](_0x1fe30f['map'](async _0x7e7109=>{try{return{'fulfilled':!0x0,'value':await _0x7e7109};}catch(_0x728d53){return{'fulfilled':!0x1,'reason':_0x728d53};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x4d7b68){this['eventTarget']=_0x4d7b68,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x153d05){const _0x4d2e5d=this['receivers']['find'](_0x514c0a=>_0x514c0a['isListeningto'](_0x153d05));if(_0x4d2e5d)return _0x4d2e5d;const _0xa46979=new Kn(_0x153d05);return this['receivers']['push'](_0xa46979),_0xa46979;}['isListeningto'](_0x3dfc97){return this['eventTarget']===_0x3dfc97;}async['handleEvent'](_0x4ddc0a){const _0x505d51=_0x4ddc0a,{eventId:_0x2f4ebe,eventType:_0x233a1f,data:_0x2adb25}=_0x505d51['data'],_0x1cbd09=this['handlersMap'][_0x233a1f];if(!(_0x1cbd09!=null&&_0x1cbd09['size']))return;_0x505d51['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x2f4ebe,'eventType':_0x233a1f});const _0x47a4db=Array['from'](_0x1cbd09)['map'](async _0x1f56fe=>_0x1f56fe(_0x505d51['origin'],_0x2adb25)),_0x41e7fe=await rp(_0x47a4db);_0x505d51['ports'][0x0]['postMessage']({'status':'done','eventId':_0x2f4ebe,'eventType':_0x233a1f,'response':_0x41e7fe});}['_subscribe'](_0x213fdc,_0x531910){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x213fdc]||(this['handlersMap'][_0x213fdc]=new Set()),this['handlersMap'][_0x213fdc]['add'](_0x531910);}['_unsubscribe'](_0x10a009,_0x1d3a20){this['handlersMap'][_0x10a009]&&_0x1d3a20&&this['handlersMap'][_0x10a009]['delete'](_0x1d3a20),(!_0x1d3a20||this['handlersMap'][_0x10a009]['size']===0x0)&&delete this['handlersMap'][_0x10a009],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x1d7344='',_0x222ab3=0xa){let _0x1d6321='';for(let _0x4d5651=0x0;_0x4d5651<_0x222ab3;_0x4d5651++)_0x1d6321+=Math['floor'](Math['random']()*0xa);return _0x1d7344+_0x1d6321;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x3e741f){this['target']=_0x3e741f,this['handlers']=new Set();}['removeMessageHandler'](_0x547438){_0x547438['messageChannel']&&(_0x547438['messageChannel']['port1']['removeEventListener']('message',_0x547438['onMessage']),_0x547438['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x547438);}async['_send'](_0x2d2ffd,_0x6caf63,_0x56a27d=0x32){const _0x1de20b=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x1de20b)throw new Error('connection_unavailable');let _0xeb5820,_0x56141d;return new Promise((_0x1fc64c,_0x4f1a9f)=>{const _0x3454e0=As('',0x14);_0x1de20b['port1']['start']();const _0x306d93=setTimeout(()=>{_0x4f1a9f(new Error('unsupported_event'));},_0x56a27d);_0x56141d={'messageChannel':_0x1de20b,'onMessage'(_0x4625c5){const _0x1d3161=_0x4625c5;if(_0x1d3161['data']['eventId']===_0x3454e0)switch(_0x1d3161['data']['status']){case'ack':clearTimeout(_0x306d93),_0xeb5820=setTimeout(()=>{_0x4f1a9f(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0xeb5820),_0x1fc64c(_0x1d3161['data']['response']);break;default:clearTimeout(_0x306d93),clearTimeout(_0xeb5820),_0x4f1a9f(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x56141d),_0x1de20b['port1']['addEventListener']('message',_0x56141d['onMessage']),this['target']['postMessage']({'eventType':_0x2d2ffd,'eventId':_0x3454e0,'data':_0x6caf63},[_0x1de20b['port2']]);})['finally'](()=>{_0x56141d&&this['removeMessageHandler'](_0x56141d);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x4e4740){Z()['location']['href']=_0x4e4740;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x210222;return((_0x210222=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x210222['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x480e12){this['request']=_0x480e12;}['toPromise'](){return new Promise((_0x4e10a7,_0x1ad977)=>{this['request']['addEventListener']('success',()=>{_0x4e10a7(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x1ad977(this['request']['error']);});});}}function Yn(_0x104ff0,_0x4e59b6){return _0x104ff0['transaction']([Nn],_0x4e59b6?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x4607c8=indexedDB['deleteDatabase'](Ka);return new Xt(_0x4607c8)['toPromise']();}function Mi(){const _0x48b9f1=indexedDB['open'](Ka,up);return new Promise((_0x100e0f,_0x804c81)=>{_0x48b9f1['addEventListener']('error',()=>{_0x804c81(_0x48b9f1['error']);}),_0x48b9f1['addEventListener']('upgradeneeded',()=>{const _0x982084=_0x48b9f1['result'];try{_0x982084['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x32f820){_0x804c81(_0x32f820);}}),_0x48b9f1['addEventListener']('success',async()=>{const _0x4a8edf=_0x48b9f1['result'];_0x4a8edf['objectStoreNames']['contains'](Nn)?_0x100e0f(_0x4a8edf):(_0x4a8edf['close'](),await dp(),_0x100e0f(await Mi()));});});}async function Pr(_0x12a656,_0x472966,_0x274b0a){const _0x2f2848=Yn(_0x12a656,!0x0)['put']({[Ya]:_0x472966,'value':_0x274b0a});return new Xt(_0x2f2848)['toPromise']();}async function fp(_0x13a1f8,_0x1d3a48){const _0x2a88c3=Yn(_0x13a1f8,!0x1)['get'](_0x1d3a48),_0x4d1dc2=await new Xt(_0x2a88c3)['toPromise']();return _0x4d1dc2===void 0x0?null:_0x4d1dc2['value'];}function Or(_0x3f9a91,_0x2f507d){const _0x27815d=Yn(_0x3f9a91,!0x0)['delete'](_0x2f507d);return new Xt(_0x27815d)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x2fc148){let _0x562bbe=0x0;for(;;)try{const _0x2bba73=await this['_openDb']();return await _0x2fc148(_0x2bba73);}catch(_0x43e27c){if(_0x562bbe++>_p)throw _0x43e27c;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x106b89,_0x5d2ab2)=>({'keyProcessed':(await this['_poll']())['includes'](_0x5d2ab2['key'])})),this['receiver']['_subscribe']('ping',async(_0x5ba19b,_0x265887)=>['keyChanged']);}async['initializeSender'](){var _0x29db75,_0x21c656;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x3ccdb0=await this['sender']['_send']('ping',{},0x320);_0x3ccdb0&&(_0x29db75=_0x3ccdb0[0x0])!=null&&_0x29db75['fulfilled']&&(_0x21c656=_0x3ccdb0[0x0])!=null&&_0x21c656['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x138725){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x138725},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x530ecd=await Mi();return await Pr(_0x530ecd,kn,'1'),await Or(_0x530ecd,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x355187){this['pendingWrites']++;try{await _0x355187();}finally{this['pendingWrites']--;}}async['_set'](_0x2c8b29,_0xe319e0){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x25a419=>Pr(_0x25a419,_0x2c8b29,_0xe319e0)),this['localCache'][_0x2c8b29]=_0xe319e0,this['notifyServiceWorker'](_0x2c8b29)));}async['_get'](_0x4f89d4){const _0x371c39=await this['_withRetries'](_0xe0f358=>fp(_0xe0f358,_0x4f89d4));return this['localCache'][_0x4f89d4]=_0x371c39,_0x371c39;}async['_remove'](_0x29802f){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3c65b9=>Or(_0x3c65b9,_0x29802f)),delete this['localCache'][_0x29802f],this['notifyServiceWorker'](_0x29802f)));}async['_poll'](){const _0x5971b1=await this['_withRetries'](_0xedc96b=>{const _0x40a9f5=Yn(_0xedc96b,!0x1)['getAll']();return new Xt(_0x40a9f5)['toPromise']();});if(!_0x5971b1)return[];if(this['pendingWrites']!==0x0)return[];const _0xba3f59=[],_0x2cb84e=new Set();if(_0x5971b1['length']!==0x0){for(const {fbase_key:_0x27d0ae,value:_0x567aa1}of _0x5971b1)_0x2cb84e['add'](_0x27d0ae),JSON['stringify'](this['localCache'][_0x27d0ae])!==JSON['stringify'](_0x567aa1)&&(this['notifyListeners'](_0x27d0ae,_0x567aa1),_0xba3f59['push'](_0x27d0ae));}for(const _0x178644 of Object['keys'](this['localCache']))this['localCache'][_0x178644]&&!_0x2cb84e['has'](_0x178644)&&(this['notifyListeners'](_0x178644,null),_0xba3f59['push'](_0x178644));return _0xba3f59;}['notifyListeners'](_0x3544ec,_0x47135e){this['localCache'][_0x3544ec]=_0x47135e;const _0x30901a=this['listeners'][_0x3544ec];if(_0x30901a){for(const _0x2b99eb of Array['from'](_0x30901a))_0x2b99eb(_0x47135e);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x53f3eb,_0x542645){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x53f3eb]||(this['listeners'][_0x53f3eb]=new Set(),this['_get'](_0x53f3eb)),this['listeners'][_0x53f3eb]['add'](_0x542645);}['_removeListener'](_0xa00f08,_0x543a31){this['listeners'][_0xa00f08]&&(this['listeners'][_0xa00f08]['delete'](_0x543a31),this['listeners'][_0xa00f08]['size']===0x0&&delete this['listeners'][_0xa00f08]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x45bcaf,_0x17df84){return _0x17df84?ie(_0x17df84):(m(_0x45bcaf['_popupRedirectResolver'],_0x45bcaf,'argument-error'),_0x45bcaf['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x526674){super('custom','custom'),this['params']=_0x526674;}['_getIdTokenResponse'](_0x1f34d4){return Xe(_0x1f34d4,this['_buildIdpRequest']());}['_linkToIdToken'](_0x2af379,_0x1c2a20){return Xe(_0x2af379,this['_buildIdpRequest'](_0x1c2a20));}['_getReauthenticationResolver'](_0x108494){return Xe(_0x108494,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x4e287c){const _0x407ec7={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x4e287c&&(_0x407ec7['idToken']=_0x4e287c),_0x407ec7;}}function yp(_0x2b9b0a){return Va(_0x2b9b0a['auth'],new ks(_0x2b9b0a),_0x2b9b0a['bypassAuthState']);}function vp(_0x1ac35a){const {auth:_0x4763be,user:_0x598483}=_0x1ac35a;return m(_0x598483,_0x4763be,'internal-error'),Xf(_0x598483,new ks(_0x1ac35a),_0x1ac35a['bypassAuthState']);}async function Ep(_0x3129cb){const {auth:_0x500a58,user:_0x483afa}=_0x3129cb;return m(_0x483afa,_0x500a58,'internal-error'),Jf(_0x483afa,new ks(_0x3129cb),_0x3129cb['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x42d95a,_0x3750e6,_0x55fade,_0x28aa14,_0x3a12f5=!0x1){this['auth']=_0x42d95a,this['resolver']=_0x55fade,this['user']=_0x28aa14,this['bypassAuthState']=_0x3a12f5,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x3750e6)?_0x3750e6:[_0x3750e6];}['execute'](){return new Promise(async(_0x2fcb4f,_0x32e1db)=>{this['pendingPromise']={'resolve':_0x2fcb4f,'reject':_0x32e1db};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x54a98b){this['reject'](_0x54a98b);}});}async['onAuthEvent'](_0x3043b3){const {urlResponse:_0x306ab3,sessionId:_0x1af8c8,postBody:_0x5872b6,tenantId:_0x42cdeb,error:_0x2d3533,type:_0x27b355}=_0x3043b3;if(_0x2d3533){this['reject'](_0x2d3533);return;}const _0x324bfb={'auth':this['auth'],'requestUri':_0x306ab3,'sessionId':_0x1af8c8,'tenantId':_0x42cdeb||void 0x0,'postBody':_0x5872b6||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x27b355)(_0x324bfb));}catch(_0x2484e1){this['reject'](_0x2484e1);}}['onError'](_0x1d47cd){this['reject'](_0x1d47cd);}['getIdpTask'](_0x35a55c){switch(_0x35a55c){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x438851){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x438851),this['unregisterAndCleanUp']();}['reject'](_0x435566){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x435566),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x328e3e,_0x26e80d,_0x4847e2,_0x495701,_0x2a9d8c){super(_0x328e3e,_0x26e80d,_0x495701,_0x2a9d8c),this['provider']=_0x4847e2,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x244799=await this['execute']();return m(_0x244799,this['auth'],'internal-error'),_0x244799;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x19476b=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x19476b),this['authWindow']['associatedEvent']=_0x19476b,this['resolver']['_originValidation'](this['auth'])['catch'](_0x4b08e1=>{this['reject'](_0x4b08e1);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x1edf90=>{_0x1edf90||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x5d20ef;return((_0x5d20ef=this['authWindow'])==null?void 0x0:_0x5d20ef['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x183cc8=()=>{var _0x10c033,_0x31aa44;if((_0x31aa44=(_0x10c033=this['authWindow'])==null?void 0x0:_0x10c033['window'])!=null&&_0x31aa44['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x183cc8,Ip['get']());};_0x183cc8();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x467654,_0x2d8413,_0x2a8815=!0x1){super(_0x467654,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x2d8413,void 0x0,_0x2a8815),this['eventId']=null;}async['execute'](){let _0x117a46=on['get'](this['auth']['_key']());if(!_0x117a46){try{const _0x32fb2f=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x117a46=()=>Promise['resolve'](_0x32fb2f);}catch(_0x6ad1b4){_0x117a46=()=>Promise['reject'](_0x6ad1b4);}on['set'](this['auth']['_key'](),_0x117a46);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x117a46();}async['onAuthEvent'](_0x59e75a){if(_0x59e75a['type']==='signInViaRedirect')return super['onAuthEvent'](_0x59e75a);if(_0x59e75a['type']==='unknown'){this['resolve'](null);return;}if(_0x59e75a['eventId']){const _0x13f6da=await this['auth']['_redirectUserForId'](_0x59e75a['eventId']);if(_0x13f6da)return this['user']=_0x13f6da,super['onAuthEvent'](_0x59e75a);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x303d36,_0x33f004){const _0x1ee52d=Rp(_0x33f004),_0x51c51c=bp(_0x303d36);if(!await _0x51c51c['_isAvailable']())return!0x1;const _0x1ed4e6=await _0x51c51c['_get'](_0x1ee52d)==='true';return await _0x51c51c['_remove'](_0x1ee52d),_0x1ed4e6;}function Sp(_0x795a95,_0x5da18d){on['set'](_0x795a95['_key'](),_0x5da18d);}function bp(_0xd68e3){return ie(_0xd68e3['_redirectPersistence']);}function Rp(_0x4b7fc5){return rn(wp,_0x4b7fc5['config']['apiKey'],_0x4b7fc5['name']);}async function Ap(_0x444a5c,_0xb1088e,_0x5afcdc=!0x1){if($(_0x444a5c['app']))return Promise['reject'](re(_0x444a5c));const _0x3e4cc9=qe(_0x444a5c),_0x578acd=mp(_0x3e4cc9,_0xb1088e),_0xee2543=await new Cp(_0x3e4cc9,_0x578acd,_0x5afcdc)['execute']();return _0xee2543&&!_0x5afcdc&&(delete _0xee2543['user']['_redirectEventId'],await _0x3e4cc9['_persistUserIfCurrent'](_0xee2543['user']),await _0x3e4cc9['_setRedirectUser'](null,_0xb1088e)),_0xee2543;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x8ef105){this['auth']=_0x8ef105,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x17d091){this['consumers']['add'](_0x17d091),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x17d091)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x17d091),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x2ef01e){this['consumers']['delete'](_0x2ef01e);}['onEvent'](_0x570bca){if(this['hasEventBeenHandled'](_0x570bca))return!0x1;let _0x20745a=!0x1;return this['consumers']['forEach'](_0x54bacb=>{this['isEventForConsumer'](_0x570bca,_0x54bacb)&&(_0x20745a=!0x0,this['sendToConsumer'](_0x570bca,_0x54bacb),this['saveEventToCache'](_0x570bca));}),this['hasHandledPotentialRedirect']||!Pp(_0x570bca)||(this['hasHandledPotentialRedirect']=!0x0,_0x20745a||(this['queuedRedirectEvent']=_0x570bca,_0x20745a=!0x0)),_0x20745a;}['sendToConsumer'](_0x11182b,_0x52da1c){var _0x53ccd8;if(_0x11182b['error']&&!Xa(_0x11182b)){const _0x40d6d1=((_0x53ccd8=_0x11182b['error']['code'])==null?void 0x0:_0x53ccd8['split']('auth/')[0x1])||'internal-error';_0x52da1c['onError'](X(this['auth'],_0x40d6d1));}else _0x52da1c['onAuthEvent'](_0x11182b);}['isEventForConsumer'](_0x190ebf,_0x24c8da){const _0x112a25=_0x24c8da['eventId']===null||!!_0x190ebf['eventId']&&_0x190ebf['eventId']===_0x24c8da['eventId'];return _0x24c8da['filter']['includes'](_0x190ebf['type'])&&_0x112a25;}['hasEventBeenHandled'](_0x5d465d){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x5d465d));}['saveEventToCache'](_0x5ac144){this['cachedEventUids']['add'](Dr(_0x5ac144)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x4ee8dc){return[_0x4ee8dc['type'],_0x4ee8dc['eventId'],_0x4ee8dc['sessionId'],_0x4ee8dc['tenantId']]['filter'](_0x1ff797=>_0x1ff797)['join']('-');}function Xa({type:_0x3ecda3,error:_0x731fae}){return _0x3ecda3==='unknown'&&(_0x731fae==null?void 0x0:_0x731fae['code'])==='auth/no-auth-event';}function Pp(_0x1854de){switch(_0x1854de['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x1854de);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x5ae32f,_0x5245ce={}){return Ae(_0x5ae32f,'GET','/v1/projects',_0x5245ce);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x5a3bbd){if(_0x5a3bbd['config']['emulator'])return;const {authorizedDomains:_0x47425f}=await Op(_0x5a3bbd);for(const _0xe0216e of _0x47425f)try{if(xp(_0xe0216e))return;}catch{}Q(_0x5a3bbd,'unauthorized-domain');}function xp(_0x21fc22){const _0x5cafeb=Pi(),{protocol:_0x2df5fb,hostname:_0x23457b}=new URL(_0x5cafeb);if(_0x21fc22['startsWith']('chrome-extension://')){const _0x35253b=new URL(_0x21fc22);return _0x35253b['hostname']===''&&_0x23457b===''?_0x2df5fb==='chrome-extension:'&&_0x21fc22['replace']('chrome-extension://','')===_0x5cafeb['replace']('chrome-extension://',''):_0x2df5fb==='chrome-extension:'&&_0x35253b['hostname']===_0x23457b;}if(!Mp['test'](_0x2df5fb))return!0x1;if(Dp['test'](_0x21fc22))return _0x23457b===_0x21fc22;const _0x4196ed=_0x21fc22['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x4196ed+'|'+_0x4196ed+')$','i')['test'](_0x23457b);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x32d304=Z()['___jsl'];if(_0x32d304!=null&&_0x32d304['H']){for(const _0x5e29b3 of Object['keys'](_0x32d304['H']))if(_0x32d304['H'][_0x5e29b3]['r']=_0x32d304['H'][_0x5e29b3]['r']||[],_0x32d304['H'][_0x5e29b3]['L']=_0x32d304['H'][_0x5e29b3]['L']||[],_0x32d304['H'][_0x5e29b3]['r']=[..._0x32d304['H'][_0x5e29b3]['L']],_0x32d304['CP']){for(let _0x309e8c=0x0;_0x309e8c<_0x32d304['CP']['length'];_0x309e8c++)_0x32d304['CP'][_0x309e8c]=null;}}}function Up(_0x4a82fe){return new Promise((_0x5991bb,_0x3479cc)=>{var _0x309414,_0x15c71b,_0x5793bf;function _0x341b28(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x5991bb(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x3479cc(X(_0x4a82fe,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x15c71b=(_0x309414=Z()['gapi'])==null?void 0x0:_0x309414['iframes'])!=null&&_0x15c71b['Iframe'])_0x5991bb(gapi['iframes']['getContext']());else{if((_0x5793bf=Z()['gapi'])!=null&&_0x5793bf['load'])_0x341b28();else{const _0x34b3be=Df('iframefcb');return Z()[_0x34b3be]=()=>{gapi['load']?_0x341b28():_0x3479cc(X(_0x4a82fe,'network-request-failed'));},xa(Of()+'?onload='+_0x34b3be)['catch'](_0xb9d93c=>_0x3479cc(_0xb9d93c));}}})['catch'](_0x401315=>{throw an=null,_0x401315;});}let an=null;function Wp(_0x28e414){return an=an||Up(_0x28e414),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x38296f){const _0x3a0ab3=_0x38296f['config'];m(_0x3a0ab3['authDomain'],_0x38296f,'auth-domain-config-required');const _0x2cea79=_0x3a0ab3['emulator']?Cs(_0x3a0ab3,Hp):'https://'+_0x38296f['config']['authDomain']+'/'+Vp,_0x18eeaf={'apiKey':_0x3a0ab3['apiKey'],'appName':_0x38296f['name'],'v':lt},_0x41d092=Gp['get'](_0x38296f['config']['apiHost']);_0x41d092&&(_0x18eeaf['eid']=_0x41d092);const _0x26ae30=_0x38296f['_getFrameworks']();return _0x26ae30['length']&&(_0x18eeaf['fw']=_0x26ae30['join'](',')),_0x2cea79+'?'+ct(_0x18eeaf)['slice'](0x1);}async function zp(_0x2034df){const _0x545e0f=await Wp(_0x2034df),_0x40637d=Z()['gapi'];return m(_0x40637d,_0x2034df,'internal-error'),_0x545e0f['open']({'where':document['body'],'url':qp(_0x2034df),'messageHandlersFilter':_0x40637d['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x4cf2a7=>new Promise(async(_0x36f98d,_0x202584)=>{await _0x4cf2a7['restyle']({'setHideOnLeave':!0x1});const _0xb9063a=X(_0x2034df,'network-request-failed'),_0x6da8ea=Z()['setTimeout'](()=>{_0x202584(_0xb9063a);},Bp['get']());function _0x4438e8(){Z()['clearTimeout'](_0x6da8ea),_0x36f98d(_0x4cf2a7);}_0x4cf2a7['ping'](_0x4438e8)['then'](_0x4438e8,()=>{_0x202584(_0xb9063a);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x48422c){this['window']=_0x48422c,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x5b6104,_0x433c7c,_0x319236,_0x5b9579=Kp,_0x1aacc1=Yp){const _0x23a6f7=Math['max']((window['screen']['availHeight']-_0x1aacc1)/0x2,0x0)['toString'](),_0x1abe60=Math['max']((window['screen']['availWidth']-_0x5b9579)/0x2,0x0)['toString']();let _0x563ce8='';const _0x2f01a5={...jp,'width':_0x5b9579['toString'](),'height':_0x1aacc1['toString'](),'top':_0x23a6f7,'left':_0x1abe60},_0x7ed121=W()['toLowerCase']();_0x319236&&(_0x563ce8=ka(_0x7ed121)?Qp:_0x319236),Ra(_0x7ed121)&&(_0x433c7c=_0x433c7c||Jp,_0x2f01a5['scrollbars']='yes');const _0x176033=Object['entries'](_0x2f01a5)['reduce']((_0x1a34dd,[_0xc6d083,_0x23fca0])=>''+_0x1a34dd+_0xc6d083+'='+_0x23fca0+',','');if(Cf(_0x7ed121)&&_0x563ce8!=='_self')return Zp(_0x433c7c||'',_0x563ce8),new Lr(null);const _0x4883e5=window['open'](_0x433c7c||'',_0x563ce8,_0x176033);m(_0x4883e5,_0x5b6104,'popup-blocked');try{_0x4883e5['focus']();}catch{}return new Lr(_0x4883e5);}function Zp(_0xd6e444,_0x3dbdef){const _0x494f9e=document['createElement']('a');_0x494f9e['href']=_0xd6e444,_0x494f9e['target']=_0x3dbdef;const _0x4cf2a1=document['createEvent']('MouseEvent');_0x4cf2a1['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x494f9e['dispatchEvent'](_0x4cf2a1);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x338ab3,_0x254f03,_0x1e03f2,_0x5db5cf,_0xd5a8a3,_0x437f55){m(_0x338ab3['config']['authDomain'],_0x338ab3,'auth-domain-config-required'),m(_0x338ab3['config']['apiKey'],_0x338ab3,'invalid-api-key');const _0x6314={'apiKey':_0x338ab3['config']['apiKey'],'appName':_0x338ab3['name'],'authType':_0x1e03f2,'redirectUrl':_0x5db5cf,'v':lt,'eventId':_0xd5a8a3};if(_0x254f03 instanceof Wa){_0x254f03['setDefaultLanguage'](_0x338ab3['languageCode']),_0x6314['providerId']=_0x254f03['providerId']||'',ui(_0x254f03['getCustomParameters']())||(_0x6314['customParameters']=JSON['stringify'](_0x254f03['getCustomParameters']()));for(const [_0x4ddad5,_0x50d59c]of Object['entries']({}))_0x6314[_0x4ddad5]=_0x50d59c;}if(_0x254f03 instanceof Jt){const _0x3030e6=_0x254f03['getScopes']()['filter'](_0x35720a=>_0x35720a!=='');_0x3030e6['length']>0x0&&(_0x6314['scopes']=_0x3030e6['join'](','));}_0x338ab3['tenantId']&&(_0x6314['tid']=_0x338ab3['tenantId']);const _0x4a61a0=_0x6314;for(const _0x42e168 of Object['keys'](_0x4a61a0))_0x4a61a0[_0x42e168]===void 0x0&&delete _0x4a61a0[_0x42e168];const _0x5b0479=await _0x338ab3['_getAppCheckToken'](),_0x564a1b=_0x5b0479?'#'+n_+'='+encodeURIComponent(_0x5b0479):'';return i_(_0x338ab3)+'?'+ct(_0x4a61a0)['slice'](0x1)+_0x564a1b;}function i_({config:_0x2ba81d}){return _0x2ba81d['emulator']?Cs(_0x2ba81d,t_):'https://'+_0x2ba81d['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x3ec7b1,_0x59f22a,_0x3e5a50,_0x5873b1){var _0x2f411e;ce((_0x2f411e=this['eventManagers'][_0x3ec7b1['_key']()])==null?void 0x0:_0x2f411e['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x165533=await xr(_0x3ec7b1,_0x59f22a,_0x3e5a50,Pi(),_0x5873b1);return Xp(_0x3ec7b1,_0x165533,As());}async['_openRedirect'](_0x38567f,_0x115f55,_0xb3296d,_0x3d1c2d){await this['_originValidation'](_0x38567f);const _0x2082d7=await xr(_0x38567f,_0x115f55,_0xb3296d,Pi(),_0x3d1c2d);return ap(_0x2082d7),new Promise(()=>{});}['_initialize'](_0x4e2c73){const _0x445269=_0x4e2c73['_key']();if(this['eventManagers'][_0x445269]){const {manager:_0x387158,promise:_0x2fa4cf}=this['eventManagers'][_0x445269];return _0x387158?Promise['resolve'](_0x387158):(ce(_0x2fa4cf,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x2fa4cf);}const _0x207f91=this['initAndGetManager'](_0x4e2c73);return this['eventManagers'][_0x445269]={'promise':_0x207f91},_0x207f91['catch'](()=>{delete this['eventManagers'][_0x445269];}),_0x207f91;}async['initAndGetManager'](_0x48a69a){const _0x571062=await zp(_0x48a69a),_0x1f131d=new Np(_0x48a69a);return _0x571062['register']('authEvent',_0x5d6e10=>(m(_0x5d6e10==null?void 0x0:_0x5d6e10['authEvent'],_0x48a69a,'invalid-auth-event'),{'status':_0x1f131d['onEvent'](_0x5d6e10['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x48a69a['_key']()]={'manager':_0x1f131d},this['iframes'][_0x48a69a['_key']()]=_0x571062,_0x1f131d;}['_isIframeWebStorageSupported'](_0x500ee5,_0x24c0a4){this['iframes'][_0x500ee5['_key']()]['send'](hi,{'type':hi},_0x5288d2=>{var _0x27a3c6;const _0x4d3700=(_0x27a3c6=_0x5288d2==null?void 0x0:_0x5288d2[0x0])==null?void 0x0:_0x27a3c6[hi];_0x4d3700!==void 0x0&&_0x24c0a4(!!_0x4d3700),Q(_0x500ee5,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x2c0953){const _0x4c582c=_0x2c0953['_key']();return this['originValidationPromises'][_0x4c582c]||(this['originValidationPromises'][_0x4c582c]=Lp(_0x2c0953)),this['originValidationPromises'][_0x4c582c];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x834e39){this['auth']=_0x834e39,this['internalListeners']=new Map();}['getUid'](){var _0x3a49b2;return this['assertAuthConfigured'](),((_0x3a49b2=this['auth']['currentUser'])==null?void 0x0:_0x3a49b2['uid'])||null;}async['getToken'](_0x35677b){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x35677b)}:null;}['addAuthTokenListener'](_0x260fca){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x260fca))return;const _0x2ca4a4=this['auth']['onIdTokenChanged'](_0x208cc0=>{_0x260fca((_0x208cc0==null?void 0x0:_0x208cc0['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x260fca,_0x2ca4a4),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x4ddca4){this['assertAuthConfigured']();const _0x370a56=this['internalListeners']['get'](_0x4ddca4);_0x370a56&&(this['internalListeners']['delete'](_0x4ddca4),_0x370a56(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0xbfaf07){switch(_0xbfaf07){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x2201e7){Ze(new Le('auth',(_0x5e5c08,{options:_0x54ef46})=>{const _0x1bcee3=_0x5e5c08['getProvider']('app')['getImmediate'](),_0x3f698e=_0x5e5c08['getProvider']('heartbeat'),_0x39b6e4=_0x5e5c08['getProvider']('app-check-internal'),{apiKey:_0xb0dec0,authDomain:_0x4f822b}=_0x1bcee3['options'];m(_0xb0dec0&&!_0xb0dec0['includes'](':'),'invalid-api-key',{'appName':_0x1bcee3['name']});const _0x4cce9a={'apiKey':_0xb0dec0,'authDomain':_0x4f822b,'clientPlatform':_0x2201e7,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x2201e7)},_0x3e81cf=new kf(_0x1bcee3,_0x3f698e,_0x39b6e4,_0x4cce9a);return Wf(_0x3e81cf,_0x54ef46),_0x3e81cf;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x23f246,_0x3a3597,_0x395e76)=>{_0x23f246['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x5e8d02=>{const _0x4ff10d=qe(_0x5e8d02['getProvider']('auth')['getImmediate']());return(_0x114c45=>new o_(_0x114c45))(_0x4ff10d);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x2201e7)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x282be9=>async _0x3e3997=>{const _0x139320=_0x3e3997&&await _0x3e3997['getIdTokenResult'](),_0x3a058=_0x139320&&(new Date()['getTime']()-Date['parse'](_0x139320['issuedAtTime']))/0x3e8;if(_0x3a058&&_0x3a058>h_)return;const _0x39e1b7=_0x139320==null?void 0x0:_0x139320['token'];Wr!==_0x39e1b7&&(Wr=_0x39e1b7,await fetch(_0x282be9,{'method':_0x39e1b7?'POST':'DELETE','headers':_0x39e1b7?{'Authorization':'Bearer\x20'+_0x39e1b7}:{}}));};function x_(_0xdc256=Zr()){const _0x5edebe=Bi(_0xdc256,'auth');if(_0x5edebe['isInitialized']())return _0x5edebe['getImmediate']();const _0x19e9b4=Uf(_0xdc256,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0xb93ec9=zr('authTokenSyncURL');if(_0xb93ec9&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x18ef88=new URL(_0xb93ec9,location['origin']);if(location['origin']===_0x18ef88['origin']){const _0x5a3ef6=u_(_0x18ef88['toString']());tp(_0x19e9b4,_0x5a3ef6,()=>_0x5a3ef6(_0x19e9b4['currentUser'])),ep(_0x19e9b4,_0x2e9d15=>_0x5a3ef6(_0x2e9d15));}}const _0x2d01c2=Gr('auth');return _0x2d01c2&&Bf(_0x19e9b4,'http://'+_0x2d01c2),_0x19e9b4;}function d_(){var _0x17cc71;return((_0x17cc71=document['getElementsByTagName']('head'))==null?void 0x0:_0x17cc71[0x0])??document;}Nf({'loadJS'(_0x43e660){return new Promise((_0xc1ce6e,_0x53874e)=>{const _0x73ffc9=document['createElement']('script');_0x73ffc9['setAttribute']('src',_0x43e660),_0x73ffc9['onload']=_0xc1ce6e,_0x73ffc9['onerror']=_0x293062=>{const _0x398ead=X('internal-error');_0x398ead['customData']=_0x293062,_0x53874e(_0x398ead);},_0x73ffc9['type']='text/javascript',_0x73ffc9['charset']='UTF-8',d_()['appendChild'](_0x73ffc9);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};