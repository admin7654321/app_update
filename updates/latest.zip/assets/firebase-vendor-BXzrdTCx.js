const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x40dde3,_0x51cd64){if(!_0x40dde3)throw rt(_0x51cd64);},rt=function(_0x1e86fc){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x1e86fc);},Vr=function(_0x399739){const _0x11aa2a=[];let _0x51dc50=0x0;for(let _0x218f8b=0x0;_0x218f8b<_0x399739['length'];_0x218f8b++){let _0x79ad94=_0x399739['charCodeAt'](_0x218f8b);_0x79ad94<0x80?_0x11aa2a[_0x51dc50++]=_0x79ad94:_0x79ad94<0x800?(_0x11aa2a[_0x51dc50++]=_0x79ad94>>0x6|0xc0,_0x11aa2a[_0x51dc50++]=_0x79ad94&0x3f|0x80):(_0x79ad94&0xfc00)===0xd800&&_0x218f8b+0x1<_0x399739['length']&&(_0x399739['charCodeAt'](_0x218f8b+0x1)&0xfc00)===0xdc00?(_0x79ad94=0x10000+((_0x79ad94&0x3ff)<<0xa)+(_0x399739['charCodeAt'](++_0x218f8b)&0x3ff),_0x11aa2a[_0x51dc50++]=_0x79ad94>>0x12|0xf0,_0x11aa2a[_0x51dc50++]=_0x79ad94>>0xc&0x3f|0x80,_0x11aa2a[_0x51dc50++]=_0x79ad94>>0x6&0x3f|0x80,_0x11aa2a[_0x51dc50++]=_0x79ad94&0x3f|0x80):(_0x11aa2a[_0x51dc50++]=_0x79ad94>>0xc|0xe0,_0x11aa2a[_0x51dc50++]=_0x79ad94>>0x6&0x3f|0x80,_0x11aa2a[_0x51dc50++]=_0x79ad94&0x3f|0x80);}return _0x11aa2a;},ec=function(_0x35f65f){const _0x2b96bc=[];let _0x3109c7=0x0,_0x2ceebf=0x0;for(;_0x3109c7<_0x35f65f['length'];){const _0x5c3081=_0x35f65f[_0x3109c7++];if(_0x5c3081<0x80)_0x2b96bc[_0x2ceebf++]=String['fromCharCode'](_0x5c3081);else{if(_0x5c3081>0xbf&&_0x5c3081<0xe0){const _0x1e196b=_0x35f65f[_0x3109c7++];_0x2b96bc[_0x2ceebf++]=String['fromCharCode']((_0x5c3081&0x1f)<<0x6|_0x1e196b&0x3f);}else{if(_0x5c3081>0xef&&_0x5c3081<0x16d){const _0x342bcd=_0x35f65f[_0x3109c7++],_0x515d32=_0x35f65f[_0x3109c7++],_0x447dcf=_0x35f65f[_0x3109c7++],_0x431558=((_0x5c3081&0x7)<<0x12|(_0x342bcd&0x3f)<<0xc|(_0x515d32&0x3f)<<0x6|_0x447dcf&0x3f)-0x10000;_0x2b96bc[_0x2ceebf++]=String['fromCharCode'](0xd800+(_0x431558>>0xa)),_0x2b96bc[_0x2ceebf++]=String['fromCharCode'](0xdc00+(_0x431558&0x3ff));}else{const _0x110a5b=_0x35f65f[_0x3109c7++],_0x459193=_0x35f65f[_0x3109c7++];_0x2b96bc[_0x2ceebf++]=String['fromCharCode']((_0x5c3081&0xf)<<0xc|(_0x110a5b&0x3f)<<0x6|_0x459193&0x3f);}}}}return _0x2b96bc['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x33fc65,_0x4280a2){if(!Array['isArray'](_0x33fc65))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x293308=_0x4280a2?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x40472c=[];for(let _0x28f97f=0x0;_0x28f97f<_0x33fc65['length'];_0x28f97f+=0x3){const _0x395c1f=_0x33fc65[_0x28f97f],_0xde55d9=_0x28f97f+0x1<_0x33fc65['length'],_0x195217=_0xde55d9?_0x33fc65[_0x28f97f+0x1]:0x0,_0x27a098=_0x28f97f+0x2<_0x33fc65['length'],_0x6d61cd=_0x27a098?_0x33fc65[_0x28f97f+0x2]:0x0,_0x222748=_0x395c1f>>0x2,_0x4a417a=(_0x395c1f&0x3)<<0x4|_0x195217>>0x4;let _0x7c3d82=(_0x195217&0xf)<<0x2|_0x6d61cd>>0x6,_0x3353d9=_0x6d61cd&0x3f;_0x27a098||(_0x3353d9=0x40,_0xde55d9||(_0x7c3d82=0x40)),_0x40472c['push'](_0x293308[_0x222748],_0x293308[_0x4a417a],_0x293308[_0x7c3d82],_0x293308[_0x3353d9]);}return _0x40472c['join']('');},'encodeString'(_0x2f39f6,_0x1c4a5a){return this['HAS_NATIVE_SUPPORT']&&!_0x1c4a5a?btoa(_0x2f39f6):this['encodeByteArray'](Vr(_0x2f39f6),_0x1c4a5a);},'decodeString'(_0x1d8154,_0x5ba09f){return this['HAS_NATIVE_SUPPORT']&&!_0x5ba09f?atob(_0x1d8154):ec(this['decodeStringToByteArray'](_0x1d8154,_0x5ba09f));},'decodeStringToByteArray'(_0x481ca6,_0xb23224){this['init_']();const _0x128d7e=_0xb23224?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x190f30=[];for(let _0x2f97b1=0x0;_0x2f97b1<_0x481ca6['length'];){const _0x10bf7e=_0x128d7e[_0x481ca6['charAt'](_0x2f97b1++)],_0x151234=_0x2f97b1<_0x481ca6['length']?_0x128d7e[_0x481ca6['charAt'](_0x2f97b1)]:0x0;++_0x2f97b1;const _0x29d35b=_0x2f97b1<_0x481ca6['length']?_0x128d7e[_0x481ca6['charAt'](_0x2f97b1)]:0x40;++_0x2f97b1;const _0x12ab30=_0x2f97b1<_0x481ca6['length']?_0x128d7e[_0x481ca6['charAt'](_0x2f97b1)]:0x40;if(++_0x2f97b1,_0x10bf7e==null||_0x151234==null||_0x29d35b==null||_0x12ab30==null)throw new tc();const _0x105a80=_0x10bf7e<<0x2|_0x151234>>0x4;if(_0x190f30['push'](_0x105a80),_0x29d35b!==0x40){const _0x494734=_0x151234<<0x4&0xf0|_0x29d35b>>0x2;if(_0x190f30['push'](_0x494734),_0x12ab30!==0x40){const _0xf229a0=_0x29d35b<<0x6&0xc0|_0x12ab30;_0x190f30['push'](_0xf229a0);}}}return _0x190f30;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x3e52be=0x0;_0x3e52be<this['ENCODED_VALS']['length'];_0x3e52be++)this['byteToCharMap_'][_0x3e52be]=this['ENCODED_VALS']['charAt'](_0x3e52be),this['charToByteMap_'][this['byteToCharMap_'][_0x3e52be]]=_0x3e52be,this['byteToCharMapWebSafe_'][_0x3e52be]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3e52be),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x3e52be]]=_0x3e52be,_0x3e52be>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3e52be)]=_0x3e52be,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x3e52be)]=_0x3e52be);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x4c1568){const _0x451f0a=Vr(_0x4c1568);return Li['encodeByteArray'](_0x451f0a,!0x0);},cn=function(_0x17cfd6){return Hr(_0x17cfd6)['replace'](/\./g,'');},ln=function(_0x3f68cd){try{return Li['decodeString'](_0x3f68cd,!0x0);}catch(_0x1ea230){console['error']('base64Decode\x20failed:\x20',_0x1ea230);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x115428){return $r(void 0x0,_0x115428);}function $r(_0x27a37b,_0x2a39d0){if(!(_0x2a39d0 instanceof Object))return _0x2a39d0;switch(_0x2a39d0['constructor']){case Date:const _0x411e9a=_0x2a39d0;return new Date(_0x411e9a['getTime']());case Object:_0x27a37b===void 0x0&&(_0x27a37b={});break;case Array:_0x27a37b=[];break;default:return _0x2a39d0;}for(const _0x478ca0 in _0x2a39d0)!_0x2a39d0['hasOwnProperty'](_0x478ca0)||!ic(_0x478ca0)||(_0x27a37b[_0x478ca0]=$r(_0x27a37b[_0x478ca0],_0x2a39d0[_0x478ca0]));return _0x27a37b;}function ic(_0x59ca5d){return _0x59ca5d!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x23fdbb=Ns['__FIREBASE_DEFAULTS__'];if(_0x23fdbb)return JSON['parse'](_0x23fdbb);},ac=()=>{if(typeof document>'u')return;let _0x3fb68c;try{_0x3fb68c=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x2b81d1=_0x3fb68c&&ln(_0x3fb68c[0x1]);return _0x2b81d1&&JSON['parse'](_0x2b81d1);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0xc02dc8){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0xc02dc8);return;}},Gr=_0x159220=>{var _0x5b2673,_0x285a1d;return(_0x285a1d=(_0x5b2673=xi())==null?void 0x0:_0x5b2673['emulatorHosts'])==null?void 0x0:_0x285a1d[_0x159220];},cc=_0x5d567d=>{const _0x51a807=Gr(_0x5d567d);if(!_0x51a807)return;const _0x3cb531=_0x51a807['lastIndexOf'](':');if(_0x3cb531<=0x0||_0x3cb531+0x1===_0x51a807['length'])throw new Error('Invalid\x20host\x20'+_0x51a807+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x4823e0=parseInt(_0x51a807['substring'](_0x3cb531+0x1),0xa);return _0x51a807[0x0]==='['?[_0x51a807['substring'](0x1,_0x3cb531-0x1),_0x4823e0]:[_0x51a807['substring'](0x0,_0x3cb531),_0x4823e0];},qr=()=>{var _0x3ff6d7;return(_0x3ff6d7=xi())==null?void 0x0:_0x3ff6d7['config'];},zr=_0x4415b1=>{var _0x2c27b4;return(_0x2c27b4=xi())==null?void 0x0:_0x2c27b4['_'+_0x4415b1];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0xdac542,_0x24ec69)=>{this['resolve']=_0xdac542,this['reject']=_0x24ec69;});}['wrapCallback'](_0x31c5c9){return(_0xa51529,_0x7272ce)=>{_0xa51529?this['reject'](_0xa51529):this['resolve'](_0x7272ce),typeof _0x31c5c9=='function'&&(this['promise']['catch'](()=>{}),_0x31c5c9['length']===0x1?_0x31c5c9(_0xa51529):_0x31c5c9(_0xa51529,_0x7272ce));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x18f776){try{return(_0x18f776['startsWith']('http://')||_0x18f776['startsWith']('https://')?new URL(_0x18f776)['hostname']:_0x18f776)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x3e4df8){return(await fetch(_0x3e4df8,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x5c2018,_0x2b7bb6){if(_0x5c2018['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x389f07={'alg':'none','type':'JWT'},_0x4bf97a=_0x2b7bb6||'demo-project',_0xf8fa8d=_0x5c2018['iat']||0x0,_0x556aa9=_0x5c2018['sub']||_0x5c2018['user_id'];if(!_0x556aa9)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x3ad603={'iss':'https://securetoken.google.com/'+_0x4bf97a,'aud':_0x4bf97a,'iat':_0xf8fa8d,'exp':_0xf8fa8d+0xe10,'auth_time':_0xf8fa8d,'sub':_0x556aa9,'user_id':_0x556aa9,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x5c2018};return[cn(JSON['stringify'](_0x389f07)),cn(JSON['stringify'](_0x3ad603)),'']['join']('.');}const It={};function hc(){const _0x217c13={'prod':[],'emulator':[]};for(const _0x8650c1 of Object['keys'](It))It[_0x8650c1]?_0x217c13['emulator']['push'](_0x8650c1):_0x217c13['prod']['push'](_0x8650c1);return _0x217c13;}function uc(_0x1613ba){let _0x5efd38=document['getElementById'](_0x1613ba),_0x41f45d=!0x1;return _0x5efd38||(_0x5efd38=document['createElement']('div'),_0x5efd38['setAttribute']('id',_0x1613ba),_0x41f45d=!0x0),{'created':_0x41f45d,'element':_0x5efd38};}let Ps=!0x1;function Kr(_0x2df7c6,_0x24003a){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x2df7c6]===_0x24003a||It[_0x2df7c6]||Ps)return;It[_0x2df7c6]=_0x24003a;function _0xa6da89(_0x1e7265){return'__firebase__banner__'+_0x1e7265;}const _0x38f2a7='__firebase__banner',_0x2f4c5c=hc()['prod']['length']>0x0;function _0xfb8bcf(){const _0x37aba3=document['getElementById'](_0x38f2a7);_0x37aba3&&_0x37aba3['remove']();}function _0x7d850c(_0x2b3c15){_0x2b3c15['style']['display']='flex',_0x2b3c15['style']['background']='#7faaf0',_0x2b3c15['style']['position']='fixed',_0x2b3c15['style']['bottom']='5px',_0x2b3c15['style']['left']='5px',_0x2b3c15['style']['padding']='.5em',_0x2b3c15['style']['borderRadius']='5px',_0x2b3c15['style']['alignItems']='center';}function _0x2be6e1(_0x8cb19a,_0x28c7ba){_0x8cb19a['setAttribute']('width','24'),_0x8cb19a['setAttribute']('id',_0x28c7ba),_0x8cb19a['setAttribute']('height','24'),_0x8cb19a['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x8cb19a['setAttribute']('fill','none'),_0x8cb19a['style']['marginLeft']='-6px';}function _0x5c1ec7(){const _0x64039=document['createElement']('span');return _0x64039['style']['cursor']='pointer',_0x64039['style']['marginLeft']='16px',_0x64039['style']['fontSize']='24px',_0x64039['innerHTML']='\x20&times;',_0x64039['onclick']=()=>{Ps=!0x0,_0xfb8bcf();},_0x64039;}function _0x45d82f(_0x352b8a,_0x3b501c){_0x352b8a['setAttribute']('id',_0x3b501c),_0x352b8a['innerText']='Learn\x20more',_0x352b8a['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x352b8a['setAttribute']('target','__blank'),_0x352b8a['style']['paddingLeft']='5px',_0x352b8a['style']['textDecoration']='underline';}function _0x39940d(){const _0x278021=uc(_0x38f2a7),_0x4fde60=_0xa6da89('text'),_0x54049e=document['getElementById'](_0x4fde60)||document['createElement']('span'),_0x599695=_0xa6da89('learnmore'),_0x2dc75d=document['getElementById'](_0x599695)||document['createElement']('a'),_0x28d165=_0xa6da89('preprendIcon'),_0x58366b=document['getElementById'](_0x28d165)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x278021['created']){const _0x33c463=_0x278021['element'];_0x7d850c(_0x33c463),_0x45d82f(_0x2dc75d,_0x599695);const _0x2c246c=_0x5c1ec7();_0x2be6e1(_0x58366b,_0x28d165),_0x33c463['append'](_0x58366b,_0x54049e,_0x2dc75d,_0x2c246c),document['body']['appendChild'](_0x33c463);}_0x2f4c5c?(_0x54049e['innerText']='Preview\x20backend\x20disconnected.',_0x58366b['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x58366b['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x54049e['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x54049e['setAttribute']('id',_0x4fde60);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x39940d):_0x39940d();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x2243e2=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x2243e2=='object'&&_0x2243e2['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0xfcfba9=W();return _0xfcfba9['indexOf']('MSIE\x20')>=0x0||_0xfcfba9['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x14959e,_0xe89eb3)=>{try{let _0x6583f8=!0x0;const _0x5451e0='validate-browser-context-for-indexeddb-analytics-module',_0x2cf428=self['indexedDB']['open'](_0x5451e0);_0x2cf428['onsuccess']=()=>{_0x2cf428['result']['close'](),_0x6583f8||self['indexedDB']['deleteDatabase'](_0x5451e0),_0x14959e(!0x0);},_0x2cf428['onupgradeneeded']=()=>{_0x6583f8=!0x1;},_0x2cf428['onerror']=()=>{var _0xafc9c6;_0xe89eb3(((_0xafc9c6=_0x2cf428['error'])==null?void 0x0:_0xafc9c6['message'])||'');};}catch(_0x375cbe){_0xe89eb3(_0x375cbe);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x53b226,_0xdb0ed2,_0x136448){super(_0xdb0ed2),this['code']=_0x53b226,this['customData']=_0x136448,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x2637d6,_0x28e6c4,_0x4440ef){this['service']=_0x2637d6,this['serviceName']=_0x28e6c4,this['errors']=_0x4440ef;}['create'](_0x3aced8,..._0x441429){const _0x327c4b=_0x441429[0x0]||{},_0x2918c0=this['service']+'/'+_0x3aced8,_0x5e4ea9=this['errors'][_0x3aced8],_0x42e58d=_0x5e4ea9?vc(_0x5e4ea9,_0x327c4b):'Error',_0x3b0cff=this['serviceName']+':\x20'+_0x42e58d+'\x20('+_0x2918c0+').';return new Se(_0x2918c0,_0x3b0cff,_0x327c4b);}}function vc(_0x20650b,_0x317ffe){return _0x20650b['replace'](Ec,(_0x5cce6b,_0x54b6b4)=>{const _0x3c0114=_0x317ffe[_0x54b6b4];return _0x3c0114!=null?String(_0x3c0114):'<'+_0x54b6b4+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x12404d){return JSON['parse'](_0x12404d);}function O(_0x41caf0){return JSON['stringify'](_0x41caf0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x39248c){let _0x446e39={},_0xec9cc3={},_0x2a8a8a={},_0x5410fa='';try{const _0x2f1a97=_0x39248c['split']('.');_0x446e39=At(ln(_0x2f1a97[0x0])||''),_0xec9cc3=At(ln(_0x2f1a97[0x1])||''),_0x5410fa=_0x2f1a97[0x2],_0x2a8a8a=_0xec9cc3['d']||{},delete _0xec9cc3['d'];}catch{}return{'header':_0x446e39,'claims':_0xec9cc3,'data':_0x2a8a8a,'signature':_0x5410fa};},Ic=function(_0x2dc465){const _0x23f1f7=Qr(_0x2dc465),_0x17db18=_0x23f1f7['claims'];return!!_0x17db18&&typeof _0x17db18=='object'&&_0x17db18['hasOwnProperty']('iat');},wc=function(_0x4bf0a9){const _0x425cb2=Qr(_0x4bf0a9)['claims'];return typeof _0x425cb2=='object'&&_0x425cb2['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x5e9b71,_0x184e6b){return Object['prototype']['hasOwnProperty']['call'](_0x5e9b71,_0x184e6b);}function De(_0x3fef76,_0x3513e7){if(Object['prototype']['hasOwnProperty']['call'](_0x3fef76,_0x3513e7))return _0x3fef76[_0x3513e7];}function ui(_0x5b6fc4){for(const _0xedee37 in _0x5b6fc4)if(Object['prototype']['hasOwnProperty']['call'](_0x5b6fc4,_0xedee37))return!0x1;return!0x0;}function hn(_0xb86283,_0x1e0b43,_0x513391){const _0x11215a={};for(const _0x2f0511 in _0xb86283)Object['prototype']['hasOwnProperty']['call'](_0xb86283,_0x2f0511)&&(_0x11215a[_0x2f0511]=_0x1e0b43['call'](_0x513391,_0xb86283[_0x2f0511],_0x2f0511,_0xb86283));return _0x11215a;}function Me(_0x84ee7e,_0x2ba8f0){if(_0x84ee7e===_0x2ba8f0)return!0x0;const _0x17a091=Object['keys'](_0x84ee7e),_0x329d29=Object['keys'](_0x2ba8f0);for(const _0x25ab90 of _0x17a091){if(!_0x329d29['includes'](_0x25ab90))return!0x1;const _0x3fdadb=_0x84ee7e[_0x25ab90],_0x5236a6=_0x2ba8f0[_0x25ab90];if(Os(_0x3fdadb)&&Os(_0x5236a6)){if(!Me(_0x3fdadb,_0x5236a6))return!0x1;}else{if(_0x3fdadb!==_0x5236a6)return!0x1;}}for(const _0x1f642d of _0x329d29)if(!_0x17a091['includes'](_0x1f642d))return!0x1;return!0x0;}function Os(_0x514c2f){return _0x514c2f!==null&&typeof _0x514c2f=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x11f172){const _0x210265=[];for(const [_0xb3fae8,_0x2a007e]of Object['entries'](_0x11f172))Array['isArray'](_0x2a007e)?_0x2a007e['forEach'](_0xf3b0ec=>{_0x210265['push'](encodeURIComponent(_0xb3fae8)+'='+encodeURIComponent(_0xf3b0ec));}):_0x210265['push'](encodeURIComponent(_0xb3fae8)+'='+encodeURIComponent(_0x2a007e));return _0x210265['length']?'&'+_0x210265['join']('&'):'';}function vt(_0xfc2e6d){const _0x284c01={};return _0xfc2e6d['replace'](/^\?/,'')['split']('&')['forEach'](_0x3d29d2=>{if(_0x3d29d2){const [_0x2cdc3f,_0xca4fbb]=_0x3d29d2['split']('=');_0x284c01[decodeURIComponent(_0x2cdc3f)]=decodeURIComponent(_0xca4fbb);}}),_0x284c01;}function Et(_0x1c64c1){const _0x5cb47a=_0x1c64c1['indexOf']('?');if(!_0x5cb47a)return'';const _0x407576=_0x1c64c1['indexOf']('#',_0x5cb47a);return _0x1c64c1['substring'](_0x5cb47a,_0x407576>0x0?_0x407576:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x3396c2=0x1;_0x3396c2<this['blockSize'];++_0x3396c2)this['pad_'][_0x3396c2]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x5ab877,_0x13de03){_0x13de03||(_0x13de03=0x0);const _0x3006ba=this['W_'];if(typeof _0x5ab877=='string'){for(let _0x5e02a6=0x0;_0x5e02a6<0x10;_0x5e02a6++)_0x3006ba[_0x5e02a6]=_0x5ab877['charCodeAt'](_0x13de03)<<0x18|_0x5ab877['charCodeAt'](_0x13de03+0x1)<<0x10|_0x5ab877['charCodeAt'](_0x13de03+0x2)<<0x8|_0x5ab877['charCodeAt'](_0x13de03+0x3),_0x13de03+=0x4;}else{for(let _0x3addec=0x0;_0x3addec<0x10;_0x3addec++)_0x3006ba[_0x3addec]=_0x5ab877[_0x13de03]<<0x18|_0x5ab877[_0x13de03+0x1]<<0x10|_0x5ab877[_0x13de03+0x2]<<0x8|_0x5ab877[_0x13de03+0x3],_0x13de03+=0x4;}for(let _0x4b2ae1=0x10;_0x4b2ae1<0x50;_0x4b2ae1++){const _0x21eba1=_0x3006ba[_0x4b2ae1-0x3]^_0x3006ba[_0x4b2ae1-0x8]^_0x3006ba[_0x4b2ae1-0xe]^_0x3006ba[_0x4b2ae1-0x10];_0x3006ba[_0x4b2ae1]=(_0x21eba1<<0x1|_0x21eba1>>>0x1f)&0xffffffff;}let _0x16f784=this['chain_'][0x0],_0x361d1b=this['chain_'][0x1],_0x57c902=this['chain_'][0x2],_0x121b99=this['chain_'][0x3],_0x3a963b=this['chain_'][0x4],_0x7e1dba,_0x156986;for(let _0x40ef17=0x0;_0x40ef17<0x50;_0x40ef17++){_0x40ef17<0x28?_0x40ef17<0x14?(_0x7e1dba=_0x121b99^_0x361d1b&(_0x57c902^_0x121b99),_0x156986=0x5a827999):(_0x7e1dba=_0x361d1b^_0x57c902^_0x121b99,_0x156986=0x6ed9eba1):_0x40ef17<0x3c?(_0x7e1dba=_0x361d1b&_0x57c902|_0x121b99&(_0x361d1b|_0x57c902),_0x156986=0x8f1bbcdc):(_0x7e1dba=_0x361d1b^_0x57c902^_0x121b99,_0x156986=0xca62c1d6);const _0x5f0423=(_0x16f784<<0x5|_0x16f784>>>0x1b)+_0x7e1dba+_0x3a963b+_0x156986+_0x3006ba[_0x40ef17]&0xffffffff;_0x3a963b=_0x121b99,_0x121b99=_0x57c902,_0x57c902=(_0x361d1b<<0x1e|_0x361d1b>>>0x2)&0xffffffff,_0x361d1b=_0x16f784,_0x16f784=_0x5f0423;}this['chain_'][0x0]=this['chain_'][0x0]+_0x16f784&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x361d1b&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x57c902&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x121b99&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x3a963b&0xffffffff;}['update'](_0x3b3d1f,_0x4e4211){if(_0x3b3d1f==null)return;_0x4e4211===void 0x0&&(_0x4e4211=_0x3b3d1f['length']);const _0x33007b=_0x4e4211-this['blockSize'];let _0x234ea6=0x0;const _0x46f694=this['buf_'];let _0x27cc64=this['inbuf_'];for(;_0x234ea6<_0x4e4211;){if(_0x27cc64===0x0){for(;_0x234ea6<=_0x33007b;)this['compress_'](_0x3b3d1f,_0x234ea6),_0x234ea6+=this['blockSize'];}if(typeof _0x3b3d1f=='string'){for(;_0x234ea6<_0x4e4211;)if(_0x46f694[_0x27cc64]=_0x3b3d1f['charCodeAt'](_0x234ea6),++_0x27cc64,++_0x234ea6,_0x27cc64===this['blockSize']){this['compress_'](_0x46f694),_0x27cc64=0x0;break;}}else{for(;_0x234ea6<_0x4e4211;)if(_0x46f694[_0x27cc64]=_0x3b3d1f[_0x234ea6],++_0x27cc64,++_0x234ea6,_0x27cc64===this['blockSize']){this['compress_'](_0x46f694),_0x27cc64=0x0;break;}}}this['inbuf_']=_0x27cc64,this['total_']+=_0x4e4211;}['digest'](){const _0x2858dc=[];let _0x7aad6c=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x4d89c3=this['blockSize']-0x1;_0x4d89c3>=0x38;_0x4d89c3--)this['buf_'][_0x4d89c3]=_0x7aad6c&0xff,_0x7aad6c/=0x100;this['compress_'](this['buf_']);let _0x1f5b58=0x0;for(let _0x2deec3=0x0;_0x2deec3<0x5;_0x2deec3++)for(let _0x1a72e8=0x18;_0x1a72e8>=0x0;_0x1a72e8-=0x8)_0x2858dc[_0x1f5b58]=this['chain_'][_0x2deec3]>>_0x1a72e8&0xff,++_0x1f5b58;return _0x2858dc;}}function Tc(_0x21857e,_0x16d3ec){const _0x460bd7=new Sc(_0x21857e,_0x16d3ec);return _0x460bd7['subscribe']['bind'](_0x460bd7);}class Sc{constructor(_0x1c146c,_0x408ea6){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x408ea6,this['task']['then'](()=>{_0x1c146c(this);})['catch'](_0x393951=>{this['error'](_0x393951);});}['next'](_0x36667e){this['forEachObserver'](_0x500da1=>{_0x500da1['next'](_0x36667e);});}['error'](_0x42d698){this['forEachObserver'](_0x45bf53=>{_0x45bf53['error'](_0x42d698);}),this['close'](_0x42d698);}['complete'](){this['forEachObserver'](_0x1221cd=>{_0x1221cd['complete']();}),this['close']();}['subscribe'](_0x4218d1,_0x1b267b,_0x729fe1){let _0x268d1c;if(_0x4218d1===void 0x0&&_0x1b267b===void 0x0&&_0x729fe1===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x4218d1,['next','error','complete'])?_0x268d1c=_0x4218d1:_0x268d1c={'next':_0x4218d1,'error':_0x1b267b,'complete':_0x729fe1},_0x268d1c['next']===void 0x0&&(_0x268d1c['next']=Jn),_0x268d1c['error']===void 0x0&&(_0x268d1c['error']=Jn),_0x268d1c['complete']===void 0x0&&(_0x268d1c['complete']=Jn);const _0x31063b=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x268d1c['error'](this['finalError']):_0x268d1c['complete']();}catch{}}),this['observers']['push'](_0x268d1c),_0x31063b;}['unsubscribeOne'](_0x4de01f){this['observers']===void 0x0||this['observers'][_0x4de01f]===void 0x0||(delete this['observers'][_0x4de01f],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x4efa6f){if(!this['finalized']){for(let _0x3ef74b=0x0;_0x3ef74b<this['observers']['length'];_0x3ef74b++)this['sendOne'](_0x3ef74b,_0x4efa6f);}}['sendOne'](_0x3fd650,_0x401ec5){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x3fd650]!==void 0x0)try{_0x401ec5(this['observers'][_0x3fd650]);}catch(_0x37ea19){typeof console<'u'&&console['error']&&console['error'](_0x37ea19);}});}['close'](_0x3639ea){this['finalized']||(this['finalized']=!0x0,_0x3639ea!==void 0x0&&(this['finalError']=_0x3639ea),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x391df2,_0x3b6290){if(typeof _0x391df2!='object'||_0x391df2===null)return!0x1;for(const _0x58e8d7 of _0x3b6290)if(_0x58e8d7 in _0x391df2&&typeof _0x391df2[_0x58e8d7]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x34eb28,_0x4fd36f){return _0x34eb28+'\x20failed:\x20'+_0x4fd36f+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x2cbddb){const _0x10fd00=[];let _0x4d3786=0x0;for(let _0x41a144=0x0;_0x41a144<_0x2cbddb['length'];_0x41a144++){let _0x24e022=_0x2cbddb['charCodeAt'](_0x41a144);if(_0x24e022>=0xd800&&_0x24e022<=0xdbff){const _0x3908c0=_0x24e022-0xd800;_0x41a144++,f(_0x41a144<_0x2cbddb['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x125723=_0x2cbddb['charCodeAt'](_0x41a144)-0xdc00;_0x24e022=0x10000+(_0x3908c0<<0xa)+_0x125723;}_0x24e022<0x80?_0x10fd00[_0x4d3786++]=_0x24e022:_0x24e022<0x800?(_0x10fd00[_0x4d3786++]=_0x24e022>>0x6|0xc0,_0x10fd00[_0x4d3786++]=_0x24e022&0x3f|0x80):_0x24e022<0x10000?(_0x10fd00[_0x4d3786++]=_0x24e022>>0xc|0xe0,_0x10fd00[_0x4d3786++]=_0x24e022>>0x6&0x3f|0x80,_0x10fd00[_0x4d3786++]=_0x24e022&0x3f|0x80):(_0x10fd00[_0x4d3786++]=_0x24e022>>0x12|0xf0,_0x10fd00[_0x4d3786++]=_0x24e022>>0xc&0x3f|0x80,_0x10fd00[_0x4d3786++]=_0x24e022>>0x6&0x3f|0x80,_0x10fd00[_0x4d3786++]=_0x24e022&0x3f|0x80);}return _0x10fd00;},On=function(_0x1fef07){let _0x4ee801=0x0;for(let _0x327178=0x0;_0x327178<_0x1fef07['length'];_0x327178++){const _0x1a6e3c=_0x1fef07['charCodeAt'](_0x327178);_0x1a6e3c<0x80?_0x4ee801++:_0x1a6e3c<0x800?_0x4ee801+=0x2:_0x1a6e3c>=0xd800&&_0x1a6e3c<=0xdbff?(_0x4ee801+=0x4,_0x327178++):_0x4ee801+=0x3;}return _0x4ee801;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x4e5af6){return _0x4e5af6&&_0x4e5af6['_delegate']?_0x4e5af6['_delegate']:_0x4e5af6;}class Le{constructor(_0x43ab16,_0x293d6d,_0x412f26){this['name']=_0x43ab16,this['instanceFactory']=_0x293d6d,this['type']=_0x412f26,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x19d0ea){return this['instantiationMode']=_0x19d0ea,this;}['setMultipleInstances'](_0x2195be){return this['multipleInstances']=_0x2195be,this;}['setServiceProps'](_0x3f83cc){return this['serviceProps']=_0x3f83cc,this;}['setInstanceCreatedCallback'](_0x415e25){return this['onInstanceCreated']=_0x415e25,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x3e45f8,_0x4d7bf4){this['name']=_0x3e45f8,this['container']=_0x4d7bf4,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x23f080){const _0x2500ba=this['normalizeInstanceIdentifier'](_0x23f080);if(!this['instancesDeferred']['has'](_0x2500ba)){const _0xf6b50d=new ot();if(this['instancesDeferred']['set'](_0x2500ba,_0xf6b50d),this['isInitialized'](_0x2500ba)||this['shouldAutoInitialize']())try{const _0x532034=this['getOrInitializeService']({'instanceIdentifier':_0x2500ba});_0x532034&&_0xf6b50d['resolve'](_0x532034);}catch{}}return this['instancesDeferred']['get'](_0x2500ba)['promise'];}['getImmediate'](_0x477ad3){const _0x300c1a=this['normalizeInstanceIdentifier'](_0x477ad3==null?void 0x0:_0x477ad3['identifier']),_0x51aeb4=(_0x477ad3==null?void 0x0:_0x477ad3['optional'])??!0x1;if(this['isInitialized'](_0x300c1a)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x300c1a});}catch(_0x514d34){if(_0x51aeb4)return null;throw _0x514d34;}else{if(_0x51aeb4)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x8b4abb){if(_0x8b4abb['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x8b4abb['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x8b4abb,!!this['shouldAutoInitialize']()){if(Nc(_0x8b4abb))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x4004b1,_0x26174f]of this['instancesDeferred']['entries']()){const _0x280fdc=this['normalizeInstanceIdentifier'](_0x4004b1);try{const _0x17b1f2=this['getOrInitializeService']({'instanceIdentifier':_0x280fdc});_0x26174f['resolve'](_0x17b1f2);}catch{}}}}['clearInstance'](_0x54001d=Ne){this['instancesDeferred']['delete'](_0x54001d),this['instancesOptions']['delete'](_0x54001d),this['instances']['delete'](_0x54001d);}async['delete'](){const _0x3019b6=Array['from'](this['instances']['values']());await Promise['all']([..._0x3019b6['filter'](_0x1a531f=>'INTERNAL'in _0x1a531f)['map'](_0x33f4da=>_0x33f4da['INTERNAL']['delete']()),..._0x3019b6['filter'](_0x518bd7=>'_delete'in _0x518bd7)['map'](_0xe69c1=>_0xe69c1['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x1edec3=Ne){return this['instances']['has'](_0x1edec3);}['getOptions'](_0x2eb683=Ne){return this['instancesOptions']['get'](_0x2eb683)||{};}['initialize'](_0x317e8b={}){const {options:_0x52edd7={}}=_0x317e8b,_0x427688=this['normalizeInstanceIdentifier'](_0x317e8b['instanceIdentifier']);if(this['isInitialized'](_0x427688))throw Error(this['name']+'('+_0x427688+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x295ff9=this['getOrInitializeService']({'instanceIdentifier':_0x427688,'options':_0x52edd7});for(const [_0x4f9440,_0x598bb9]of this['instancesDeferred']['entries']()){const _0x52c6f4=this['normalizeInstanceIdentifier'](_0x4f9440);_0x427688===_0x52c6f4&&_0x598bb9['resolve'](_0x295ff9);}return _0x295ff9;}['onInit'](_0x3f8d36,_0xba85a7){const _0x32aa36=this['normalizeInstanceIdentifier'](_0xba85a7),_0x3cefb7=this['onInitCallbacks']['get'](_0x32aa36)??new Set();_0x3cefb7['add'](_0x3f8d36),this['onInitCallbacks']['set'](_0x32aa36,_0x3cefb7);const _0x5d04f4=this['instances']['get'](_0x32aa36);return _0x5d04f4&&_0x3f8d36(_0x5d04f4,_0x32aa36),()=>{_0x3cefb7['delete'](_0x3f8d36);};}['invokeOnInitCallbacks'](_0x1bc64d,_0x2ef78f){const _0x9def25=this['onInitCallbacks']['get'](_0x2ef78f);if(_0x9def25){for(const _0x475b67 of _0x9def25)try{_0x475b67(_0x1bc64d,_0x2ef78f);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x5e8766,options:_0x15d813={}}){let _0x4981eb=this['instances']['get'](_0x5e8766);if(!_0x4981eb&&this['component']&&(_0x4981eb=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x5e8766),'options':_0x15d813}),this['instances']['set'](_0x5e8766,_0x4981eb),this['instancesOptions']['set'](_0x5e8766,_0x15d813),this['invokeOnInitCallbacks'](_0x4981eb,_0x5e8766),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x5e8766,_0x4981eb);}catch{}return _0x4981eb||null;}['normalizeInstanceIdentifier'](_0x2949eb=Ne){return this['component']?this['component']['multipleInstances']?_0x2949eb:Ne:_0x2949eb;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x5e1d5d){return _0x5e1d5d===Ne?void 0x0:_0x5e1d5d;}function Nc(_0x6e807){return _0x6e807['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x24f7a8){this['name']=_0x24f7a8,this['providers']=new Map();}['addComponent'](_0x43ef84){const _0x109730=this['getProvider'](_0x43ef84['name']);if(_0x109730['isComponentSet']())throw new Error('Component\x20'+_0x43ef84['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x109730['setComponent'](_0x43ef84);}['addOrOverwriteComponent'](_0x231fe2){this['getProvider'](_0x231fe2['name'])['isComponentSet']()&&this['providers']['delete'](_0x231fe2['name']),this['addComponent'](_0x231fe2);}['getProvider'](_0x25d077){if(this['providers']['has'](_0x25d077))return this['providers']['get'](_0x25d077);const _0x436229=new Ac(_0x25d077,this);return this['providers']['set'](_0x25d077,_0x436229),_0x436229;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x176734){_0x176734[_0x176734['DEBUG']=0x0]='DEBUG',_0x176734[_0x176734['VERBOSE']=0x1]='VERBOSE',_0x176734[_0x176734['INFO']=0x2]='INFO',_0x176734[_0x176734['WARN']=0x3]='WARN',_0x176734[_0x176734['ERROR']=0x4]='ERROR',_0x176734[_0x176734['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x35d055,_0x2da26e,..._0x3a4531)=>{if(_0x2da26e<_0x35d055['logLevel'])return;const _0x559204=new Date()['toISOString'](),_0x518f2d=Mc[_0x2da26e];if(_0x518f2d)console[_0x518f2d]('['+_0x559204+']\x20\x20'+_0x35d055['name']+':',..._0x3a4531);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x2da26e+')');};class Ui{constructor(_0x233f7f){this['name']=_0x233f7f,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x41c908){if(!(_0x41c908 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x41c908+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x41c908;}['setLogLevel'](_0x39a810){this['_logLevel']=typeof _0x39a810=='string'?Oc[_0x39a810]:_0x39a810;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x326e00){if(typeof _0x326e00!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x326e00;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x35317e){this['_userLogHandler']=_0x35317e;}['debug'](..._0x3fac1c){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x3fac1c),this['_logHandler'](this,T['DEBUG'],..._0x3fac1c);}['log'](..._0x3617b5){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x3617b5),this['_logHandler'](this,T['VERBOSE'],..._0x3617b5);}['info'](..._0xeeef32){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0xeeef32),this['_logHandler'](this,T['INFO'],..._0xeeef32);}['warn'](..._0x2b5aa7){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x2b5aa7),this['_logHandler'](this,T['WARN'],..._0x2b5aa7);}['error'](..._0x475dd5){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x475dd5),this['_logHandler'](this,T['ERROR'],..._0x475dd5);}}const xc=(_0x2d6426,_0x3e3fd7)=>_0x3e3fd7['some'](_0xa45e06=>_0x2d6426 instanceof _0xa45e06);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x165266){const _0x98c8eb=new Promise((_0x26273d,_0x5ea43d)=>{const _0x988f1=()=>{_0x165266['removeEventListener']('success',_0x1634ae),_0x165266['removeEventListener']('error',_0xc1cf5a);},_0x1634ae=()=>{_0x26273d(_e(_0x165266['result'])),_0x988f1();},_0xc1cf5a=()=>{_0x5ea43d(_0x165266['error']),_0x988f1();};_0x165266['addEventListener']('success',_0x1634ae),_0x165266['addEventListener']('error',_0xc1cf5a);});return _0x98c8eb['then'](_0x3dc4b9=>{_0x3dc4b9 instanceof IDBCursor&&Jr['set'](_0x3dc4b9,_0x165266);})['catch'](()=>{}),Wi['set'](_0x98c8eb,_0x165266),_0x98c8eb;}function Bc(_0x3e8840){if(di['has'](_0x3e8840))return;const _0xc37b11=new Promise((_0xe8c08c,_0x48c402)=>{const _0x22a6cb=()=>{_0x3e8840['removeEventListener']('complete',_0x2c64f4),_0x3e8840['removeEventListener']('error',_0x56ca7d),_0x3e8840['removeEventListener']('abort',_0x56ca7d);},_0x2c64f4=()=>{_0xe8c08c(),_0x22a6cb();},_0x56ca7d=()=>{_0x48c402(_0x3e8840['error']||new DOMException('AbortError','AbortError')),_0x22a6cb();};_0x3e8840['addEventListener']('complete',_0x2c64f4),_0x3e8840['addEventListener']('error',_0x56ca7d),_0x3e8840['addEventListener']('abort',_0x56ca7d);});di['set'](_0x3e8840,_0xc37b11);}let fi={'get'(_0xc820dc,_0x5a6d08,_0x32852a){if(_0xc820dc instanceof IDBTransaction){if(_0x5a6d08==='done')return di['get'](_0xc820dc);if(_0x5a6d08==='objectStoreNames')return _0xc820dc['objectStoreNames']||Xr['get'](_0xc820dc);if(_0x5a6d08==='store')return _0x32852a['objectStoreNames'][0x1]?void 0x0:_0x32852a['objectStore'](_0x32852a['objectStoreNames'][0x0]);}return _e(_0xc820dc[_0x5a6d08]);},'set'(_0x1af604,_0x4ba5f5,_0x1e3ea9){return _0x1af604[_0x4ba5f5]=_0x1e3ea9,!0x0;},'has'(_0x29f1d9,_0x17aac1){return _0x29f1d9 instanceof IDBTransaction&&(_0x17aac1==='done'||_0x17aac1==='store')?!0x0:_0x17aac1 in _0x29f1d9;}};function Vc(_0x5422f7){fi=_0x5422f7(fi);}function Hc(_0x46d517){return _0x46d517===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x4ace85,..._0x2c0e26){const _0x2a7b92=_0x46d517['call'](Zn(this),_0x4ace85,..._0x2c0e26);return Xr['set'](_0x2a7b92,_0x4ace85['sort']?_0x4ace85['sort']():[_0x4ace85]),_e(_0x2a7b92);}:Uc()['includes'](_0x46d517)?function(..._0x274089){return _0x46d517['apply'](Zn(this),_0x274089),_e(Jr['get'](this));}:function(..._0x302ee9){return _e(_0x46d517['apply'](Zn(this),_0x302ee9));};}function $c(_0x41e844){return typeof _0x41e844=='function'?Hc(_0x41e844):(_0x41e844 instanceof IDBTransaction&&Bc(_0x41e844),xc(_0x41e844,Fc())?new Proxy(_0x41e844,fi):_0x41e844);}function _e(_0x56f2ba){if(_0x56f2ba instanceof IDBRequest)return Wc(_0x56f2ba);if(Xn['has'](_0x56f2ba))return Xn['get'](_0x56f2ba);const _0x516484=$c(_0x56f2ba);return _0x516484!==_0x56f2ba&&(Xn['set'](_0x56f2ba,_0x516484),Wi['set'](_0x516484,_0x56f2ba)),_0x516484;}const Zn=_0x29d8d0=>Wi['get'](_0x29d8d0);function Gc(_0x58d81a,_0x4b4bbb,{blocked:_0x1758a1,upgrade:_0x53be8c,blocking:_0x2915b6,terminated:_0xac49d6}={}){const _0x14b8f2=indexedDB['open'](_0x58d81a,_0x4b4bbb),_0x52592d=_e(_0x14b8f2);return _0x53be8c&&_0x14b8f2['addEventListener']('upgradeneeded',_0xc9b8f6=>{_0x53be8c(_e(_0x14b8f2['result']),_0xc9b8f6['oldVersion'],_0xc9b8f6['newVersion'],_e(_0x14b8f2['transaction']),_0xc9b8f6);}),_0x1758a1&&_0x14b8f2['addEventListener']('blocked',_0x583542=>_0x1758a1(_0x583542['oldVersion'],_0x583542['newVersion'],_0x583542)),_0x52592d['then'](_0x78f5cd=>{_0xac49d6&&_0x78f5cd['addEventListener']('close',()=>_0xac49d6()),_0x2915b6&&_0x78f5cd['addEventListener']('versionchange',_0x2cece0=>_0x2915b6(_0x2cece0['oldVersion'],_0x2cece0['newVersion'],_0x2cece0));})['catch'](()=>{}),_0x52592d;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x5f15cf,_0x23533c){if(!(_0x5f15cf instanceof IDBDatabase&&!(_0x23533c in _0x5f15cf)&&typeof _0x23533c=='string'))return;if(ei['get'](_0x23533c))return ei['get'](_0x23533c);const _0x1b436f=_0x23533c['replace'](/FromIndex$/,''),_0x3630c5=_0x23533c!==_0x1b436f,_0x107c8a=zc['includes'](_0x1b436f);if(!(_0x1b436f in(_0x3630c5?IDBIndex:IDBObjectStore)['prototype'])||!(_0x107c8a||qc['includes'](_0x1b436f)))return;const _0x17c7f6=async function(_0x2118ac,..._0x5179af){const _0x348dd9=this['transaction'](_0x2118ac,_0x107c8a?'readwrite':'readonly');let _0x41c6f2=_0x348dd9['store'];return _0x3630c5&&(_0x41c6f2=_0x41c6f2['index'](_0x5179af['shift']())),(await Promise['all']([_0x41c6f2[_0x1b436f](..._0x5179af),_0x107c8a&&_0x348dd9['done']]))[0x0];};return ei['set'](_0x23533c,_0x17c7f6),_0x17c7f6;}Vc(_0x2550e6=>({..._0x2550e6,'get':(_0x12c931,_0x22e897,_0x17e2de)=>Ls(_0x12c931,_0x22e897)||_0x2550e6['get'](_0x12c931,_0x22e897,_0x17e2de),'has':(_0x350e53,_0x2bbae4)=>!!Ls(_0x350e53,_0x2bbae4)||_0x2550e6['has'](_0x350e53,_0x2bbae4)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x7cf691){this['container']=_0x7cf691;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x302572=>{if(Kc(_0x302572)){const _0x484ef3=_0x302572['getImmediate']();return _0x484ef3['library']+'/'+_0x484ef3['version'];}else return null;})['filter'](_0x4c15d0=>_0x4c15d0)['join']('\x20');}}function Kc(_0x4a9067){const _0x5889f6=_0x4a9067['getComponent']();return(_0x5889f6==null?void 0x0:_0x5889f6['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x13c023,_0x2771be){try{_0x13c023['container']['addComponent'](_0x2771be);}catch(_0x4fe08b){oe['debug']('Component\x20'+_0x2771be['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x13c023['name'],_0x4fe08b);}}function Ze(_0xdf8503){const _0x4910c0=_0xdf8503['name'];if(mi['has'](_0x4910c0))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x4910c0+'.'),!0x1;mi['set'](_0x4910c0,_0xdf8503);for(const _0x59f806 of xe['values']())Fs(_0x59f806,_0xdf8503);for(const _0x3fec06 of gi['values']())Fs(_0x3fec06,_0xdf8503);return!0x0;}function Bi(_0x53227b,_0x15f9c4){const _0x35e6b0=_0x53227b['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x35e6b0&&_0x35e6b0['triggerHeartbeat'](),_0x53227b['container']['getProvider'](_0x15f9c4);}function $(_0x41cef7){return _0x41cef7==null?!0x1:_0x41cef7['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x2acf3c,_0x1d94ad,_0x4810d6){this['_isDeleted']=!0x1,this['_options']={..._0x2acf3c},this['_config']={..._0x1d94ad},this['_name']=_0x1d94ad['name'],this['_automaticDataCollectionEnabled']=_0x1d94ad['automaticDataCollectionEnabled'],this['_container']=_0x4810d6,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x2e25eb){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x2e25eb;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x454e3b){this['_isDeleted']=_0x454e3b;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x1b5755,_0x1070ce={}){let _0x3f4b41=_0x1b5755;typeof _0x1070ce!='object'&&(_0x1070ce={'name':_0x1070ce});const _0x3fba85={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x1070ce},_0x44c2b1=_0x3fba85['name'];if(typeof _0x44c2b1!='string'||!_0x44c2b1)throw ge['create']('bad-app-name',{'appName':String(_0x44c2b1)});if(_0x3f4b41||(_0x3f4b41=qr()),!_0x3f4b41)throw ge['create']('no-options');const _0x37fbe1=xe['get'](_0x44c2b1);if(_0x37fbe1){if(Me(_0x3f4b41,_0x37fbe1['options'])&&Me(_0x3fba85,_0x37fbe1['config']))return _0x37fbe1;throw ge['create']('duplicate-app',{'appName':_0x44c2b1});}const _0x1f6d86=new Pc(_0x44c2b1);for(const _0x54cfb0 of mi['values']())_0x1f6d86['addComponent'](_0x54cfb0);const _0x54aade=new Tl(_0x3f4b41,_0x3fba85,_0x1f6d86);return xe['set'](_0x44c2b1,_0x54aade),_0x54aade;}function Zr(_0x633593=_i){const _0x56f03a=xe['get'](_0x633593);if(!_0x56f03a&&_0x633593===_i&&qr())return Sl();if(!_0x56f03a)throw ge['create']('no-app',{'appName':_0x633593});return _0x56f03a;}function f_(){return Array['from'](xe['values']());}async function p_(_0x5edd12){let _0x10330e=!0x1;const _0x49b5e3=_0x5edd12['name'];xe['has'](_0x49b5e3)?(_0x10330e=!0x0,xe['delete'](_0x49b5e3)):gi['has'](_0x49b5e3)&&_0x5edd12['decRefCount']()<=0x0&&(gi['delete'](_0x49b5e3),_0x10330e=!0x0),_0x10330e&&(await Promise['all'](_0x5edd12['container']['getProviders']()['map'](_0x3e5dca=>_0x3e5dca['delete']())),_0x5edd12['isDeleted']=!0x0);}function me(_0x37de30,_0x321bf6,_0x146d99){let _0x2cc6eb=wl[_0x37de30]??_0x37de30;_0x146d99&&(_0x2cc6eb+='-'+_0x146d99);const _0x311bf4=_0x2cc6eb['match'](/\s|\//),_0x583465=_0x321bf6['match'](/\s|\//);if(_0x311bf4||_0x583465){const _0x5e3e21=['Unable\x20to\x20register\x20library\x20\x22'+_0x2cc6eb+'\x22\x20with\x20version\x20\x22'+_0x321bf6+'\x22:'];_0x311bf4&&_0x5e3e21['push']('library\x20name\x20\x22'+_0x2cc6eb+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x311bf4&&_0x583465&&_0x5e3e21['push']('and'),_0x583465&&_0x5e3e21['push']('version\x20name\x20\x22'+_0x321bf6+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x5e3e21['join']('\x20'));return;}Ze(new Le(_0x2cc6eb+'-version',()=>({'library':_0x2cc6eb,'version':_0x321bf6}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x5959b5,_0x5a210a)=>{switch(_0x5a210a){case 0x0:try{_0x5959b5['createObjectStore'](kt);}catch(_0x56a066){console['warn'](_0x56a066);}}}})['catch'](_0x198e5c=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x198e5c['message']});})),ti;}async function Al(_0x2bcdbf){try{const _0x39ff3f=(await eo())['transaction'](kt),_0x361e97=await _0x39ff3f['objectStore'](kt)['get'](to(_0x2bcdbf));return await _0x39ff3f['done'],_0x361e97;}catch(_0x2fa660){if(_0x2fa660 instanceof Se)oe['warn'](_0x2fa660['message']);else{const _0x37b985=ge['create']('idb-get',{'originalErrorMessage':_0x2fa660==null?void 0x0:_0x2fa660['message']});oe['warn'](_0x37b985['message']);}}}async function Us(_0x1745d6,_0x58a870){try{const _0x44af5c=(await eo())['transaction'](kt,'readwrite');await _0x44af5c['objectStore'](kt)['put'](_0x58a870,to(_0x1745d6)),await _0x44af5c['done'];}catch(_0x49d4d6){if(_0x49d4d6 instanceof Se)oe['warn'](_0x49d4d6['message']);else{const _0x212d5e=ge['create']('idb-set',{'originalErrorMessage':_0x49d4d6==null?void 0x0:_0x49d4d6['message']});oe['warn'](_0x212d5e['message']);}}}function to(_0x58f77d){return _0x58f77d['name']+'!'+_0x58f77d['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x5b1a47){this['container']=_0x5b1a47,this['_heartbeatsCache']=null;const _0xb33457=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0xb33457),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x275bb8=>(this['_heartbeatsCache']=_0x275bb8,_0x275bb8));}async['triggerHeartbeat'](){var _0x47fd7f,_0x107641;try{const _0x13d31c=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3bce81=Ws();if(((_0x47fd7f=this['_heartbeatsCache'])==null?void 0x0:_0x47fd7f['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x107641=this['_heartbeatsCache'])==null?void 0x0:_0x107641['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3bce81||this['_heartbeatsCache']['heartbeats']['some'](_0x9ffab4=>_0x9ffab4['date']===_0x3bce81))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3bce81,'agent':_0x13d31c}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x595a39=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x595a39,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x57eeb0){oe['warn'](_0x57eeb0);}}async['getHeartbeatsHeader'](){var _0x53be02;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x53be02=this['_heartbeatsCache'])==null?void 0x0:_0x53be02['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x585115=Ws(),{heartbeatsToSend:_0x67aab1,unsentEntries:_0x3bb28a}=Ol(this['_heartbeatsCache']['heartbeats']),_0x1f7d8c=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x67aab1}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x585115,_0x3bb28a['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x3bb28a,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x1f7d8c;}catch(_0x34ea6d){return oe['warn'](_0x34ea6d),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x2f0e1b,_0x1bcb6b=kl){const _0x1000bc=[];let _0x53ff07=_0x2f0e1b['slice']();for(const _0x4b1404 of _0x2f0e1b){const _0x51c734=_0x1000bc['find'](_0x435a1e=>_0x435a1e['agent']===_0x4b1404['agent']);if(_0x51c734){if(_0x51c734['dates']['push'](_0x4b1404['date']),Bs(_0x1000bc)>_0x1bcb6b){_0x51c734['dates']['pop']();break;}}else{if(_0x1000bc['push']({'agent':_0x4b1404['agent'],'dates':[_0x4b1404['date']]}),Bs(_0x1000bc)>_0x1bcb6b){_0x1000bc['pop']();break;}}_0x53ff07=_0x53ff07['slice'](0x1);}return{'heartbeatsToSend':_0x1000bc,'unsentEntries':_0x53ff07};}class Dl{constructor(_0x2cec74){this['app']=_0x2cec74,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x535339=await Al(this['app']);return _0x535339!=null&&_0x535339['heartbeats']?_0x535339:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x34a440){if(await this['_canUseIndexedDBPromise']){const _0x33ecac=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x34a440['lastSentHeartbeatDate']??_0x33ecac['lastSentHeartbeatDate'],'heartbeats':_0x34a440['heartbeats']});}else return;}async['add'](_0x473a65){if(await this['_canUseIndexedDBPromise']){const _0x5245a1=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x473a65['lastSentHeartbeatDate']??_0x5245a1['lastSentHeartbeatDate'],'heartbeats':[..._0x5245a1['heartbeats'],..._0x473a65['heartbeats']]});}else return;}}function Bs(_0x16b332){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x16b332}))['length'];}function Ml(_0x435201){if(_0x435201['length']===0x0)return-0x1;let _0x33422f=0x0,_0x44821c=_0x435201[0x0]['date'];for(let _0x20164d=0x1;_0x20164d<_0x435201['length'];_0x20164d++)_0x435201[_0x20164d]['date']<_0x44821c&&(_0x44821c=_0x435201[_0x20164d]['date'],_0x33422f=_0x20164d);return _0x33422f;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x1c51ed){Ze(new Le('platform-logger',_0x23b1c3=>new jc(_0x23b1c3),'PRIVATE')),Ze(new Le('heartbeat',_0x504eea=>new Pl(_0x504eea),'PRIVATE')),me(pi,xs,_0x1c51ed),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x5362b8){no=_0x5362b8;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x48e2b1){this['domStorage_']=_0x48e2b1,this['prefix_']='firebase:';}['set'](_0x9e9631,_0x34e2ac){_0x34e2ac==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x9e9631)):this['domStorage_']['setItem'](this['prefixedName_'](_0x9e9631),O(_0x34e2ac));}['get'](_0x8a60ae){const _0x1aa8ca=this['domStorage_']['getItem'](this['prefixedName_'](_0x8a60ae));return _0x1aa8ca==null?null:At(_0x1aa8ca);}['remove'](_0x100870){this['domStorage_']['removeItem'](this['prefixedName_'](_0x100870));}['prefixedName_'](_0x21582f){return this['prefix_']+_0x21582f;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x57f0e8,_0x3b5385){_0x3b5385==null?delete this['cache_'][_0x57f0e8]:this['cache_'][_0x57f0e8]=_0x3b5385;}['get'](_0x44c498){return J(this['cache_'],_0x44c498)?this['cache_'][_0x44c498]:null;}['remove'](_0x353fc5){delete this['cache_'][_0x353fc5];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0xf07e2f){try{if(typeof window<'u'&&typeof window[_0xf07e2f]<'u'){const _0x4201c1=window[_0xf07e2f];return _0x4201c1['setItem']('firebase:sentinel','cache'),_0x4201c1['removeItem']('firebase:sentinel'),new Wl(_0x4201c1);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x5a5ead=0x1;return function(){return _0x5a5ead++;};}()),ro=function(_0x36a555){const _0x450758=Rc(_0x36a555),_0x5c835f=new Cc();_0x5c835f['update'](_0x450758);const _0x2044e2=_0x5c835f['digest']();return Li['encodeByteArray'](_0x2044e2);},Vt=function(..._0x4f9fd5){let _0x531633='';for(let _0x18c4dc=0x0;_0x18c4dc<_0x4f9fd5['length'];_0x18c4dc++){const _0x6f7813=_0x4f9fd5[_0x18c4dc];Array['isArray'](_0x6f7813)||_0x6f7813&&typeof _0x6f7813=='object'&&typeof _0x6f7813['length']=='number'?_0x531633+=Vt['apply'](null,_0x6f7813):typeof _0x6f7813=='object'?_0x531633+=O(_0x6f7813):_0x531633+=_0x6f7813,_0x531633+='\x20';}return _0x531633;};let wt=null,Gs=!0x0;const Hl=function(_0x3cd463,_0x437219){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x2b57d9){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x52078a=Vt['apply'](null,_0x2b57d9);wt(_0x52078a);}},Ht=function(_0x51551e){return function(..._0x1eb450){L(_0x51551e,..._0x1eb450);};},yi=function(..._0x1779cb){const _0x58a544='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x1779cb);Ye['error'](_0x58a544);},ae=function(..._0x54a7fa){const _0x5a72c9='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x54a7fa);throw Ye['error'](_0x5a72c9),new Error(_0x5a72c9);},U=function(..._0x4bd71f){const _0x2ddb0e='FIREBASE\x20WARNING:\x20'+Vt(..._0x4bd71f);Ye['warn'](_0x2ddb0e);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x5a0b13){return typeof _0x5a0b13=='number'&&(_0x5a0b13!==_0x5a0b13||_0x5a0b13===Number['POSITIVE_INFINITY']||_0x5a0b13===Number['NEGATIVE_INFINITY']);},Gl=function(_0x2a0d6a){if(document['readyState']==='complete')_0x2a0d6a();else{let _0x580bac=!0x1;const _0x100693=function(){if(!document['body']){setTimeout(_0x100693,Math['floor'](0xa));return;}_0x580bac||(_0x580bac=!0x0,_0x2a0d6a());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x100693,!0x1),window['addEventListener']('load',_0x100693,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x100693();}),window['attachEvent']('onload',_0x100693));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x42a2c7,_0x3771ce){if(_0x42a2c7===_0x3771ce)return 0x0;if(_0x42a2c7===Fe||_0x3771ce===Ie)return-0x1;if(_0x3771ce===Fe||_0x42a2c7===Ie)return 0x1;{const _0x8544b1=qs(_0x42a2c7),_0x2b0531=qs(_0x3771ce);return _0x8544b1!==null?_0x2b0531!==null?_0x8544b1-_0x2b0531===0x0?_0x42a2c7['length']-_0x3771ce['length']:_0x8544b1-_0x2b0531:-0x1:_0x2b0531!==null?0x1:_0x42a2c7<_0x3771ce?-0x1:0x1;}},ql=function(_0x179d51,_0x193f96){return _0x179d51===_0x193f96?0x0:_0x179d51<_0x193f96?-0x1:0x1;},_t=function(_0x588e05,_0x3f5fbe){if(_0x3f5fbe&&_0x588e05 in _0x3f5fbe)return _0x3f5fbe[_0x588e05];throw new Error('Missing\x20required\x20key\x20('+_0x588e05+')\x20in\x20object:\x20'+O(_0x3f5fbe));},Hi=function(_0x1a9504){if(typeof _0x1a9504!='object'||_0x1a9504===null)return O(_0x1a9504);const _0x22ea7c=[];for(const _0x1f0749 in _0x1a9504)_0x22ea7c['push'](_0x1f0749);_0x22ea7c['sort']();let _0x1930c9='{';for(let _0x3dfee4=0x0;_0x3dfee4<_0x22ea7c['length'];_0x3dfee4++)_0x3dfee4!==0x0&&(_0x1930c9+=','),_0x1930c9+=O(_0x22ea7c[_0x3dfee4]),_0x1930c9+=':',_0x1930c9+=Hi(_0x1a9504[_0x22ea7c[_0x3dfee4]]);return _0x1930c9+='}',_0x1930c9;},oo=function(_0x559e28,_0x2c56b4){const _0x3a3e7c=_0x559e28['length'];if(_0x3a3e7c<=_0x2c56b4)return[_0x559e28];const _0x5ea7dd=[];for(let _0x4cc7f4=0x0;_0x4cc7f4<_0x3a3e7c;_0x4cc7f4+=_0x2c56b4)_0x4cc7f4+_0x2c56b4>_0x3a3e7c?_0x5ea7dd['push'](_0x559e28['substring'](_0x4cc7f4,_0x3a3e7c)):_0x5ea7dd['push'](_0x559e28['substring'](_0x4cc7f4,_0x4cc7f4+_0x2c56b4));return _0x5ea7dd;};function x(_0x645026,_0x1cbd6d){for(const _0x571574 in _0x645026)_0x645026['hasOwnProperty'](_0x571574)&&_0x1cbd6d(_0x571574,_0x645026[_0x571574]);}const ao=function(_0x7cf881){f(!Vi(_0x7cf881),'Invalid\x20JSON\x20number');const _0x1356d1=0xb,_0x483f99=0x34,_0x25b69c=(0x1<<_0x1356d1-0x1)-0x1;let _0x85aab7,_0x56a025,_0x593bf2,_0x9c585,_0x2a9c24;_0x7cf881===0x0?(_0x56a025=0x0,_0x593bf2=0x0,_0x85aab7=0x1/_0x7cf881===-0x1/0x0?0x1:0x0):(_0x85aab7=_0x7cf881<0x0,_0x7cf881=Math['abs'](_0x7cf881),_0x7cf881>=Math['pow'](0x2,0x1-_0x25b69c)?(_0x9c585=Math['min'](Math['floor'](Math['log'](_0x7cf881)/Math['LN2']),_0x25b69c),_0x56a025=_0x9c585+_0x25b69c,_0x593bf2=Math['round'](_0x7cf881*Math['pow'](0x2,_0x483f99-_0x9c585)-Math['pow'](0x2,_0x483f99))):(_0x56a025=0x0,_0x593bf2=Math['round'](_0x7cf881/Math['pow'](0x2,0x1-_0x25b69c-_0x483f99))));const _0x329493=[];for(_0x2a9c24=_0x483f99;_0x2a9c24;_0x2a9c24-=0x1)_0x329493['push'](_0x593bf2%0x2?0x1:0x0),_0x593bf2=Math['floor'](_0x593bf2/0x2);for(_0x2a9c24=_0x1356d1;_0x2a9c24;_0x2a9c24-=0x1)_0x329493['push'](_0x56a025%0x2?0x1:0x0),_0x56a025=Math['floor'](_0x56a025/0x2);_0x329493['push'](_0x85aab7?0x1:0x0),_0x329493['reverse']();const _0x5aaec6=_0x329493['join']('');let _0xa3500='';for(_0x2a9c24=0x0;_0x2a9c24<0x40;_0x2a9c24+=0x8){let _0x59116d=parseInt(_0x5aaec6['substr'](_0x2a9c24,0x8),0x2)['toString'](0x10);_0x59116d['length']===0x1&&(_0x59116d='0'+_0x59116d),_0xa3500=_0xa3500+_0x59116d;}return _0xa3500['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x50a25c,_0x4a355b){let _0x2f7a5f='Unknown\x20Error';_0x50a25c==='too_big'?_0x2f7a5f='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x50a25c==='permission_denied'?_0x2f7a5f='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x50a25c==='unavailable'&&(_0x2f7a5f='The\x20service\x20is\x20unavailable');const _0x1b91b0=new Error(_0x50a25c+'\x20at\x20'+_0x4a355b['_path']['toString']()+':\x20'+_0x2f7a5f);return _0x1b91b0['code']=_0x50a25c['toUpperCase'](),_0x1b91b0;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x21e87e){if(Yl['test'](_0x21e87e)){const _0x57f6d8=Number(_0x21e87e);if(_0x57f6d8>=Ql&&_0x57f6d8<=Jl)return _0x57f6d8;}return null;},ht=function(_0x48a00d){try{_0x48a00d();}catch(_0x5d753c){setTimeout(()=>{const _0x559a36=_0x5d753c['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x559a36),_0x5d753c;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x2769af,_0x3f64e2){const _0x4afe89=setTimeout(_0x2769af,_0x3f64e2);return typeof _0x4afe89=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x4afe89):typeof _0x4afe89=='object'&&_0x4afe89['unref']&&_0x4afe89['unref'](),_0x4afe89;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x470579,_0x42d498){this['appCheckProvider']=_0x42d498,this['appName']=_0x470579['name'],$(_0x470579)&&_0x470579['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x470579['settings']['appCheckToken']),this['appCheck']=_0x42d498==null?void 0x0:_0x42d498['getImmediate']({'optional':!0x0}),this['appCheck']||_0x42d498==null||_0x42d498['get']()['then'](_0x442c68=>this['appCheck']=_0x442c68);}['getToken'](_0x17d23d){if(this['serverAppAppCheckToken']){if(_0x17d23d)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x17d23d):new Promise((_0x11e803,_0xcf2bae)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x17d23d)['then'](_0x11e803,_0xcf2bae):_0x11e803(null);},0x0);});}['addTokenChangeListener'](_0x6f5865){var _0x5e8c08;(_0x5e8c08=this['appCheckProvider'])==null||_0x5e8c08['get']()['then'](_0x898421=>_0x898421['addTokenListener'](_0x6f5865));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0xee95fc,_0x173135,_0x293aaf){this['appName_']=_0xee95fc,this['firebaseOptions_']=_0x173135,this['authProvider_']=_0x293aaf,this['auth_']=null,this['auth_']=_0x293aaf['getImmediate']({'optional':!0x0}),this['auth_']||_0x293aaf['onInit'](_0x560897=>this['auth_']=_0x560897);}['getToken'](_0x509517){return this['auth_']?this['auth_']['getToken'](_0x509517)['catch'](_0x5c78e0=>_0x5c78e0&&_0x5c78e0['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x5c78e0)):new Promise((_0x23ccf7,_0x2e501d)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x509517)['then'](_0x23ccf7,_0x2e501d):_0x23ccf7(null);},0x0);});}['addTokenChangeListener'](_0x15ae09){this['auth_']?this['auth_']['addAuthTokenListener'](_0x15ae09):this['authProvider_']['get']()['then'](_0x52b320=>_0x52b320['addAuthTokenListener'](_0x15ae09));}['removeTokenChangeListener'](_0x1fba55){this['authProvider_']['get']()['then'](_0x2c81b0=>_0x2c81b0['removeAuthTokenListener'](_0x1fba55));}['notifyForInvalidToken'](){let _0xe5d0db='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0xe5d0db+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0xe5d0db+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0xe5d0db+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0xe5d0db);}}class nn{constructor(_0x543b67){this['accessToken']=_0x543b67;}['getToken'](_0x3957f0){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0xbf6b98){_0xbf6b98(this['accessToken']);}['removeTokenChangeListener'](_0x13e60c){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x5e43f3,_0x40dee2,_0x934c23,_0x3558b0,_0x763b2a=!0x1,_0x1c0d3a='',_0x3b9e1b=!0x1,_0x559bb1=!0x1,_0x3edd2a=null){this['secure']=_0x40dee2,this['namespace']=_0x934c23,this['webSocketOnly']=_0x3558b0,this['nodeAdmin']=_0x763b2a,this['persistenceKey']=_0x1c0d3a,this['includeNamespaceInQueryParams']=_0x3b9e1b,this['isUsingEmulator']=_0x559bb1,this['emulatorOptions']=_0x3edd2a,this['_host']=_0x5e43f3['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x5e43f3)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x32d534){_0x32d534!==this['internalHost']&&(this['internalHost']=_0x32d534,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x3f56e0=this['toURLString']();return this['persistenceKey']&&(_0x3f56e0+='<'+this['persistenceKey']+'>'),_0x3f56e0;}['toURLString'](){const _0x65e50c=this['secure']?'https://':'http://',_0x2525ce=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x65e50c+this['host']+'/'+_0x2525ce;}}function th(_0x2202dd){return _0x2202dd['host']!==_0x2202dd['internalHost']||_0x2202dd['isCustomHost']()||_0x2202dd['includeNamespaceInQueryParams'];}function vo(_0x22a69b,_0x5ef942,_0x4a4de3){f(typeof _0x5ef942=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x4a4de3=='object','typeof\x20params\x20must\x20==\x20object');let _0x3ae8e7;if(_0x5ef942===go)_0x3ae8e7=(_0x22a69b['secure']?'wss://':'ws://')+_0x22a69b['internalHost']+'/.ws?';else{if(_0x5ef942===mo)_0x3ae8e7=(_0x22a69b['secure']?'https://':'http://')+_0x22a69b['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x5ef942);}th(_0x22a69b)&&(_0x4a4de3['ns']=_0x22a69b['namespace']);const _0x27d5be=[];return x(_0x4a4de3,(_0x4b103a,_0x433c6c)=>{_0x27d5be['push'](_0x4b103a+'='+_0x433c6c);}),_0x3ae8e7+_0x27d5be['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x170c8a,_0x3d62fc=0x1){J(this['counters_'],_0x170c8a)||(this['counters_'][_0x170c8a]=0x0),this['counters_'][_0x170c8a]+=_0x3d62fc;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x3208f9){const _0x5a6241=_0x3208f9['toString']();return ni[_0x5a6241]||(ni[_0x5a6241]=new nh()),ni[_0x5a6241];}function ih(_0x4514d4,_0x27972b){const _0x2ea56c=_0x4514d4['toString']();return ii[_0x2ea56c]||(ii[_0x2ea56c]=_0x27972b()),ii[_0x2ea56c];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x4ce0d6){this['onMessage_']=_0x4ce0d6,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x55d92b,_0x4fda0a){this['closeAfterResponse']=_0x55d92b,this['onClose']=_0x4fda0a,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0xd8d23e,_0x2a15b1){for(this['pendingResponses'][_0xd8d23e]=_0x2a15b1;this['pendingResponses'][this['currentResponseNum']];){const _0x59d8da=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x332017=0x0;_0x332017<_0x59d8da['length'];++_0x332017)_0x59d8da[_0x332017]&&ht(()=>{this['onMessage_'](_0x59d8da[_0x332017]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x18219f,_0x58e4df,_0x2b4034,_0x50dca1,_0x4c1e25,_0x2f1e8b,_0x5b4a47){this['connId']=_0x18219f,this['repoInfo']=_0x58e4df,this['applicationId']=_0x2b4034,this['appCheckToken']=_0x50dca1,this['authToken']=_0x4c1e25,this['transportSessionId']=_0x2f1e8b,this['lastSessionId']=_0x5b4a47,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x18219f),this['stats_']=Gi(_0x58e4df),this['urlFn']=_0x4577cd=>(this['appCheckToken']&&(_0x4577cd[vi]=this['appCheckToken']),vo(_0x58e4df,mo,_0x4577cd));}['open'](_0x8e706,_0x2a0e28){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x2a0e28,this['myPacketOrderer']=new sh(_0x8e706),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x1423af)=>{const [_0x45de05,_0x2a1687,_0x50afb6,_0xec4cf7,_0x30ae7a]=_0x1423af;if(this['incrementIncomingBytes_'](_0x1423af),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x45de05===zs)this['id']=_0x2a1687,this['password']=_0x50afb6;else{if(_0x45de05===rh)_0x2a1687?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x2a1687,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x45de05);}}},(..._0x5a059f)=>{const [_0x346d7a,_0x476008]=_0x5a059f;this['incrementIncomingBytes_'](_0x5a059f),this['myPacketOrderer']['handleResponse'](_0x346d7a,_0x476008);},()=>{this['onClosed_']();},this['urlFn']);const _0xd37a30={};_0xd37a30[zs]='t',_0xd37a30[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0xd37a30[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0xd37a30[co]=$i,this['transportSessionId']&&(_0xd37a30[lo]=this['transportSessionId']),this['lastSessionId']&&(_0xd37a30[po]=this['lastSessionId']),this['applicationId']&&(_0xd37a30[_o]=this['applicationId']),this['appCheckToken']&&(_0xd37a30[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0xd37a30[ho]=uo);const _0x252d5a=this['urlFn'](_0xd37a30);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x252d5a),this['scriptTagHolder']['addTag'](_0x252d5a,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x182b27){const _0x4618a3=O(_0x182b27);this['bytesSent']+=_0x4618a3['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4618a3['length']);const _0xcc09a3=Hr(_0x4618a3),_0x4c4722=oo(_0xcc09a3,fh);for(let _0x3bce08=0x0;_0x3bce08<_0x4c4722['length'];_0x3bce08++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x4c4722['length'],_0x4c4722[_0x3bce08]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x12d4a0,_0x33557){this['myDisconnFrame']=document['createElement']('iframe');const _0x2d66ee={};_0x2d66ee[dh]='t',_0x2d66ee[Eo]=_0x12d4a0,_0x2d66ee[Io]=_0x33557,this['myDisconnFrame']['src']=this['urlFn'](_0x2d66ee),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x46d0cd){const _0x12258b=O(_0x46d0cd)['length'];this['bytesReceived']+=_0x12258b,this['stats_']['incrementCounter']('bytes_received',_0x12258b);}}class qi{constructor(_0x32e295,_0x252524,_0x17af2d,_0x29c6fe){this['onDisconnect']=_0x17af2d,this['urlFn']=_0x29c6fe,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x32e295,window[ah+this['uniqueCallbackIdentifier']]=_0x252524,this['myIFrame']=qi['createIFrame_']();let _0x1a1e68='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x1a1e68='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x6a8ea1='<html><body>'+_0x1a1e68+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x6a8ea1),this['myIFrame']['doc']['close']();}catch(_0x5bd612){L('frame\x20writing\x20exception'),_0x5bd612['stack']&&L(_0x5bd612['stack']),L(_0x5bd612);}}}static['createIFrame_'](){const _0x541a80=document['createElement']('iframe');if(_0x541a80['style']['display']='none',document['body']){document['body']['appendChild'](_0x541a80);try{_0x541a80['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x1c73f4=document['domain'];_0x541a80['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x1c73f4+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x541a80['contentDocument']?_0x541a80['doc']=_0x541a80['contentDocument']:_0x541a80['contentWindow']?_0x541a80['doc']=_0x541a80['contentWindow']['document']:_0x541a80['document']&&(_0x541a80['doc']=_0x541a80['document']),_0x541a80;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x44e5d1=this['onDisconnect'];_0x44e5d1&&(this['onDisconnect']=null,_0x44e5d1());}['startLongPoll'](_0x1af078,_0x257670){for(this['myID']=_0x1af078,this['myPW']=_0x257670,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0xf7211c={};_0xf7211c[Eo]=this['myID'],_0xf7211c[Io]=this['myPW'],_0xf7211c[wo]=this['currentSerial'];let _0x36f3c5=this['urlFn'](_0xf7211c),_0x197df7='',_0x20c9b3=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x197df7['length']<=Co;){const _0x3d9913=this['pendingSegs']['shift']();_0x197df7=_0x197df7+'&'+lh+_0x20c9b3+'='+_0x3d9913['seg']+'&'+hh+_0x20c9b3+'='+_0x3d9913['ts']+'&'+uh+_0x20c9b3+'='+_0x3d9913['d'],_0x20c9b3++;}return _0x36f3c5=_0x36f3c5+_0x197df7,this['addLongPollTag_'](_0x36f3c5,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x305812,_0x6a93c0,_0x35b893){this['pendingSegs']['push']({'seg':_0x305812,'ts':_0x6a93c0,'d':_0x35b893}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x4009d1,_0x5abb56){this['outstandingRequests']['add'](_0x5abb56);const _0x28ac01=()=>{this['outstandingRequests']['delete'](_0x5abb56),this['newRequest_']();},_0x22ccf2=setTimeout(_0x28ac01,Math['floor'](ph)),_0x25a4e9=()=>{clearTimeout(_0x22ccf2),_0x28ac01();};this['addTag'](_0x4009d1,_0x25a4e9);}['addTag'](_0x2c18c7,_0x416d41){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x545b4a=this['myIFrame']['doc']['createElement']('script');_0x545b4a['type']='text/javascript',_0x545b4a['async']=!0x0,_0x545b4a['src']=_0x2c18c7,_0x545b4a['onload']=_0x545b4a['onreadystatechange']=function(){const _0xcdeec1=_0x545b4a['readyState'];(!_0xcdeec1||_0xcdeec1==='loaded'||_0xcdeec1==='complete')&&(_0x545b4a['onload']=_0x545b4a['onreadystatechange']=null,_0x545b4a['parentNode']&&_0x545b4a['parentNode']['removeChild'](_0x545b4a),_0x416d41());},_0x545b4a['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x2c18c7),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x545b4a);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x220ee8,_0x4cc16b,_0x49dfed,_0x350bd7,_0x44ef3e,_0x28db9e,_0x28f880){this['connId']=_0x220ee8,this['applicationId']=_0x49dfed,this['appCheckToken']=_0x350bd7,this['authToken']=_0x44ef3e,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x4cc16b),this['connURL']=z['connectionURL_'](_0x4cc16b,_0x28db9e,_0x28f880,_0x350bd7,_0x49dfed),this['nodeAdmin']=_0x4cc16b['nodeAdmin'];}static['connectionURL_'](_0x5eba2,_0x3c3136,_0x4b9316,_0x358fe6,_0x222b8b){const _0x29c03d={};return _0x29c03d[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x29c03d[ho]=uo),_0x3c3136&&(_0x29c03d[lo]=_0x3c3136),_0x4b9316&&(_0x29c03d[po]=_0x4b9316),_0x358fe6&&(_0x29c03d[vi]=_0x358fe6),_0x222b8b&&(_0x29c03d[_o]=_0x222b8b),vo(_0x5eba2,go,_0x29c03d);}['open'](_0x5dce79,_0x41b029){this['onDisconnect']=_0x41b029,this['onMessage']=_0x5dce79,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0xb26315;_c(),this['mySock']=new un(this['connURL'],[],_0xb26315);}catch(_0x47996f){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x4420f9=_0x47996f['message']||_0x47996f['data'];_0x4420f9&&this['log_'](_0x4420f9),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x58d9c1=>{this['handleIncomingFrame'](_0x58d9c1);},this['mySock']['onerror']=_0x519e32=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x46e067=_0x519e32['message']||_0x519e32['data'];_0x46e067&&this['log_'](_0x46e067),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x3a74a0=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x392518=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x4eb8fd=navigator['userAgent']['match'](_0x392518);_0x4eb8fd&&_0x4eb8fd['length']>0x1&&parseFloat(_0x4eb8fd[0x1])<4.4&&(_0x3a74a0=!0x0);}return!_0x3a74a0&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x4282ff){if(this['frames']['push'](_0x4282ff),this['frames']['length']===this['totalFrames']){const _0x51a349=this['frames']['join']('');this['frames']=null;const _0x5f4b64=At(_0x51a349);this['onMessage'](_0x5f4b64);}}['handleNewFrameCount_'](_0x5202ef){this['totalFrames']=_0x5202ef,this['frames']=[];}['extractFrameCount_'](_0x525bf6){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x525bf6['length']<=0x6){const _0x1ff6ba=Number(_0x525bf6);if(!isNaN(_0x1ff6ba))return this['handleNewFrameCount_'](_0x1ff6ba),null;}return this['handleNewFrameCount_'](0x1),_0x525bf6;}['handleIncomingFrame'](_0x135a49){if(this['mySock']===null)return;const _0x362974=_0x135a49['data'];if(this['bytesReceived']+=_0x362974['length'],this['stats_']['incrementCounter']('bytes_received',_0x362974['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x362974);else{const _0x4af847=this['extractFrameCount_'](_0x362974);_0x4af847!==null&&this['appendFrame_'](_0x4af847);}}['send'](_0x614fd7){this['resetKeepAlive']();const _0x1a471a=O(_0x614fd7);this['bytesSent']+=_0x1a471a['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1a471a['length']);const _0x20c995=oo(_0x1a471a,gh);_0x20c995['length']>0x1&&this['sendString_'](String(_0x20c995['length']));for(let _0x133bff=0x0;_0x133bff<_0x20c995['length'];_0x133bff++)this['sendString_'](_0x20c995[_0x133bff]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0xfc8fcc){try{this['mySock']['send'](_0xfc8fcc);}catch(_0x398714){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x398714['message']||_0x398714['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x42e94f){this['initTransports_'](_0x42e94f);}['initTransports_'](_0x532a48){const _0x5cfcad=z&&z['isAvailable']();let _0xb540b5=_0x5cfcad&&!z['previouslyFailed']();if(_0x532a48['webSocketOnly']&&(_0x5cfcad||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0xb540b5=!0x0),_0xb540b5)this['transports_']=[z];else{const _0x2f219d=this['transports_']=[];for(const _0x3fee3b of Nt['ALL_TRANSPORTS'])_0x3fee3b&&_0x3fee3b['isAvailable']()&&_0x2f219d['push'](_0x3fee3b);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x2ff752,_0x5e0144,_0x2c501d,_0x57b594,_0x43132c,_0x38c10c,_0x2e22e5,_0x1beb9d,_0x23e13f,_0x275bf9){this['id']=_0x2ff752,this['repoInfo_']=_0x5e0144,this['applicationId_']=_0x2c501d,this['appCheckToken_']=_0x57b594,this['authToken_']=_0x43132c,this['onMessage_']=_0x38c10c,this['onReady_']=_0x2e22e5,this['onDisconnect_']=_0x1beb9d,this['onKill_']=_0x23e13f,this['lastSessionId']=_0x275bf9,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x5e0144),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x113c87=this['transportManager_']['initialTransport']();this['conn_']=new _0x113c87(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x113c87['responsesRequiredToBeHealthy']||0x0;const _0x3ac1d2=this['connReceiver_'](this['conn_']),_0x378083=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x3ac1d2,_0x378083);},Math['floor'](0x0));const _0x4153be=_0x113c87['healthyTimeout']||0x0;_0x4153be>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x4153be)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x56aa16){return _0x11a23f=>{_0x56aa16===this['conn_']?this['onConnectionLost_'](_0x11a23f):_0x56aa16===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x17ac75){return _0x1b5ed8=>{this['state_']!==0x2&&(_0x17ac75===this['rx_']?this['onPrimaryMessageReceived_'](_0x1b5ed8):_0x17ac75===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x1b5ed8):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x28feb5){const _0x4f8d4f={'t':'d','d':_0x28feb5};this['sendData_'](_0x4f8d4f);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x447f15){if(si in _0x447f15){const _0x25384c=_0x447f15[si];_0x25384c===Qs?this['upgradeIfSecondaryHealthy_']():_0x25384c===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x25384c===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x1ca25f){const _0x323a6c=_t('t',_0x1ca25f),_0x51db55=_t('d',_0x1ca25f);if(_0x323a6c==='c')this['onSecondaryControl_'](_0x51db55);else{if(_0x323a6c==='d')this['pendingDataMessages']['push'](_0x51db55);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x323a6c);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x220049){const _0x34529a=_t('t',_0x220049),_0x101262=_t('d',_0x220049);_0x34529a==='c'?this['onControl_'](_0x101262):_0x34529a==='d'&&this['onDataMessage_'](_0x101262);}['onDataMessage_'](_0x23bc0a){this['onPrimaryResponse_'](),this['onMessage_'](_0x23bc0a);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x4e5698){const _0x5433ff=_t(si,_0x4e5698);if(js in _0x4e5698){const _0x2e9096=_0x4e5698[js];if(_0x5433ff===Th){const _0x47b576={..._0x2e9096};this['repoInfo_']['isUsingEmulator']&&(_0x47b576['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x47b576);}else{if(_0x5433ff===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x312d2e=0x0;_0x312d2e<this['pendingDataMessages']['length'];++_0x312d2e)this['onDataMessage_'](this['pendingDataMessages'][_0x312d2e]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x5433ff===wh?this['onConnectionShutdown_'](_0x2e9096):_0x5433ff===Ks?this['onReset_'](_0x2e9096):_0x5433ff===Ch?yi('Server\x20Error:\x20'+_0x2e9096):_0x5433ff===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x5433ff);}}}['onHandshake_'](_0x21a4d5){const _0x2ab11b=_0x21a4d5['ts'],_0x58060d=_0x21a4d5['v'],_0x153b8b=_0x21a4d5['h'];this['sessionId']=_0x21a4d5['s'],this['repoInfo_']['host']=_0x153b8b,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x2ab11b),$i!==_0x58060d&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x7db3c3=this['transportManager_']['upgradeTransport']();_0x7db3c3&&this['startUpgrade_'](_0x7db3c3);}['startUpgrade_'](_0x53bca1){this['secondaryConn_']=new _0x53bca1(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x53bca1['responsesRequiredToBeHealthy']||0x0;const _0xacc840=this['connReceiver_'](this['secondaryConn_']),_0x664a5e=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0xacc840,_0x664a5e),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x447d7e){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x447d7e),this['repoInfo_']['host']=_0x447d7e,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x59b1f4,_0x9965e4){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x59b1f4,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x9965e4,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x25270c=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x25270c||this['rx_']===_0x25270c)&&this['close']();}['onConnectionLost_'](_0x3c5c13){this['conn_']=null,!_0x3c5c13&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x45dbb1){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x45dbb1),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x269e18){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x269e18);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x41d8dd,_0x4948f0,_0x30c55e,_0x402843){}['merge'](_0x26e612,_0x46e1ef,_0x573d81,_0x297c59){}['refreshAuthToken'](_0x46de94){}['refreshAppCheckToken'](_0x40421f){}['onDisconnectPut'](_0x4d4f9a,_0x45655b,_0x34c856){}['onDisconnectMerge'](_0x4c82d7,_0x58dcaf,_0xe78b60){}['onDisconnectCancel'](_0x53a78b,_0x3952c9){}['reportStats'](_0x3892c9){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x2758de){this['allowedEvents_']=_0x2758de,this['listeners_']={},f(Array['isArray'](_0x2758de)&&_0x2758de['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x3e445b,..._0x1f164d){if(Array['isArray'](this['listeners_'][_0x3e445b])){const _0x3c5ec2=[...this['listeners_'][_0x3e445b]];for(let _0x386151=0x0;_0x386151<_0x3c5ec2['length'];_0x386151++)_0x3c5ec2[_0x386151]['callback']['apply'](_0x3c5ec2[_0x386151]['context'],_0x1f164d);}}['on'](_0x4aa457,_0x31f8e6,_0x319f2c){this['validateEventType_'](_0x4aa457),this['listeners_'][_0x4aa457]=this['listeners_'][_0x4aa457]||[],this['listeners_'][_0x4aa457]['push']({'callback':_0x31f8e6,'context':_0x319f2c});const _0x1ddc25=this['getInitialEvent'](_0x4aa457);_0x1ddc25&&_0x31f8e6['apply'](_0x319f2c,_0x1ddc25);}['off'](_0x215760,_0x9489f2,_0x1fd072){this['validateEventType_'](_0x215760);const _0x146be2=this['listeners_'][_0x215760]||[];for(let _0x15b0b1=0x0;_0x15b0b1<_0x146be2['length'];_0x15b0b1++)if(_0x146be2[_0x15b0b1]['callback']===_0x9489f2&&(!_0x1fd072||_0x1fd072===_0x146be2[_0x15b0b1]['context'])){_0x146be2['splice'](_0x15b0b1,0x1);return;}}['validateEventType_'](_0x376883){f(this['allowedEvents_']['find'](_0x48d651=>_0x48d651===_0x376883),'Unknown\x20event:\x20'+_0x376883);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x42ad9b){return f(_0x42ad9b==='online','Unknown\x20event\x20type:\x20'+_0x42ad9b),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x1b3d98,_0x2dcc2f){if(_0x2dcc2f===void 0x0){this['pieces_']=_0x1b3d98['split']('/');let _0x2c9c51=0x0;for(let _0x508601=0x0;_0x508601<this['pieces_']['length'];_0x508601++)this['pieces_'][_0x508601]['length']>0x0&&(this['pieces_'][_0x2c9c51]=this['pieces_'][_0x508601],_0x2c9c51++);this['pieces_']['length']=_0x2c9c51,this['pieceNum_']=0x0;}else this['pieces_']=_0x1b3d98,this['pieceNum_']=_0x2dcc2f;}['toString'](){let _0x4ae87e='';for(let _0x26ef9b=this['pieceNum_'];_0x26ef9b<this['pieces_']['length'];_0x26ef9b++)this['pieces_'][_0x26ef9b]!==''&&(_0x4ae87e+='/'+this['pieces_'][_0x26ef9b]);return _0x4ae87e||'/';}}function w(){return new C('');}function y(_0x63d40e){return _0x63d40e['pieceNum_']>=_0x63d40e['pieces_']['length']?null:_0x63d40e['pieces_'][_0x63d40e['pieceNum_']];}function we(_0x598497){return _0x598497['pieces_']['length']-_0x598497['pieceNum_'];}function b(_0x13c1a0){let _0x46c361=_0x13c1a0['pieceNum_'];return _0x46c361<_0x13c1a0['pieces_']['length']&&_0x46c361++,new C(_0x13c1a0['pieces_'],_0x46c361);}function zi(_0xce7c27){return _0xce7c27['pieceNum_']<_0xce7c27['pieces_']['length']?_0xce7c27['pieces_'][_0xce7c27['pieces_']['length']-0x1]:null;}function bh(_0x2a8ca7){let _0x44a837='';for(let _0x54a9d0=_0x2a8ca7['pieceNum_'];_0x54a9d0<_0x2a8ca7['pieces_']['length'];_0x54a9d0++)_0x2a8ca7['pieces_'][_0x54a9d0]!==''&&(_0x44a837+='/'+encodeURIComponent(String(_0x2a8ca7['pieces_'][_0x54a9d0])));return _0x44a837||'/';}function Pt(_0x3ef192,_0x5a196a=0x0){return _0x3ef192['pieces_']['slice'](_0x3ef192['pieceNum_']+_0x5a196a);}function Ro(_0x1d056f){if(_0x1d056f['pieceNum_']>=_0x1d056f['pieces_']['length'])return null;const _0x3726fb=[];for(let _0x131ec0=_0x1d056f['pieceNum_'];_0x131ec0<_0x1d056f['pieces_']['length']-0x1;_0x131ec0++)_0x3726fb['push'](_0x1d056f['pieces_'][_0x131ec0]);return new C(_0x3726fb,0x0);}function k(_0x521e5f,_0x5f2623){const _0xc3576e=[];for(let _0x4dcc05=_0x521e5f['pieceNum_'];_0x4dcc05<_0x521e5f['pieces_']['length'];_0x4dcc05++)_0xc3576e['push'](_0x521e5f['pieces_'][_0x4dcc05]);if(_0x5f2623 instanceof C){for(let _0x9ec289=_0x5f2623['pieceNum_'];_0x9ec289<_0x5f2623['pieces_']['length'];_0x9ec289++)_0xc3576e['push'](_0x5f2623['pieces_'][_0x9ec289]);}else{const _0x6192ef=_0x5f2623['split']('/');for(let _0xb8ad62=0x0;_0xb8ad62<_0x6192ef['length'];_0xb8ad62++)_0x6192ef[_0xb8ad62]['length']>0x0&&_0xc3576e['push'](_0x6192ef[_0xb8ad62]);}return new C(_0xc3576e,0x0);}function v(_0x240de0){return _0x240de0['pieceNum_']>=_0x240de0['pieces_']['length'];}function F(_0x3240c1,_0x5636ac){const _0x18804a=y(_0x3240c1),_0x161388=y(_0x5636ac);if(_0x18804a===null)return _0x5636ac;if(_0x18804a===_0x161388)return F(b(_0x3240c1),b(_0x5636ac));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x5636ac+')\x20is\x20not\x20within\x20outerPath\x20('+_0x3240c1+')');}function Rh(_0x3ab9a5,_0x5f1b92){const _0x1e8fb4=Pt(_0x3ab9a5,0x0),_0x3b6a43=Pt(_0x5f1b92,0x0);for(let _0x3dd37d=0x0;_0x3dd37d<_0x1e8fb4['length']&&_0x3dd37d<_0x3b6a43['length'];_0x3dd37d++){const _0x40b236=He(_0x1e8fb4[_0x3dd37d],_0x3b6a43[_0x3dd37d]);if(_0x40b236!==0x0)return _0x40b236;}return _0x1e8fb4['length']===_0x3b6a43['length']?0x0:_0x1e8fb4['length']<_0x3b6a43['length']?-0x1:0x1;}function ji(_0x24f545,_0x4b4df4){if(we(_0x24f545)!==we(_0x4b4df4))return!0x1;for(let _0x231a7e=_0x24f545['pieceNum_'],_0x1c6db1=_0x4b4df4['pieceNum_'];_0x231a7e<=_0x24f545['pieces_']['length'];_0x231a7e++,_0x1c6db1++)if(_0x24f545['pieces_'][_0x231a7e]!==_0x4b4df4['pieces_'][_0x1c6db1])return!0x1;return!0x0;}function G(_0x34c3e7,_0xf7970c){let _0x5f1a4d=_0x34c3e7['pieceNum_'],_0x451bac=_0xf7970c['pieceNum_'];if(we(_0x34c3e7)>we(_0xf7970c))return!0x1;for(;_0x5f1a4d<_0x34c3e7['pieces_']['length'];){if(_0x34c3e7['pieces_'][_0x5f1a4d]!==_0xf7970c['pieces_'][_0x451bac])return!0x1;++_0x5f1a4d,++_0x451bac;}return!0x0;}class Ah{constructor(_0x14f70d,_0x209115){this['errorPrefix_']=_0x209115,this['parts_']=Pt(_0x14f70d,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x80a877=0x0;_0x80a877<this['parts_']['length'];_0x80a877++)this['byteLength_']+=On(this['parts_'][_0x80a877]);Ao(this);}}function kh(_0x19f18e,_0x407ce2){_0x19f18e['parts_']['length']>0x0&&(_0x19f18e['byteLength_']+=0x1),_0x19f18e['parts_']['push'](_0x407ce2),_0x19f18e['byteLength_']+=On(_0x407ce2),Ao(_0x19f18e);}function Nh(_0x563d88){const _0x5a878a=_0x563d88['parts_']['pop']();_0x563d88['byteLength_']-=On(_0x5a878a),_0x563d88['parts_']['length']>0x0&&(_0x563d88['byteLength_']-=0x1);}function Ao(_0x2cd1de){if(_0x2cd1de['byteLength_']>er)throw new Error(_0x2cd1de['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x2cd1de['byteLength_']+').');if(_0x2cd1de['parts_']['length']>Zs)throw new Error(_0x2cd1de['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x2cd1de));}function Pe(_0x4c1b01){return _0x4c1b01['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x4c1b01['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x24b195,_0x1cfa45;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x1cfa45='visibilitychange',_0x24b195='hidden'):typeof document['mozHidden']<'u'?(_0x1cfa45='mozvisibilitychange',_0x24b195='mozHidden'):typeof document['msHidden']<'u'?(_0x1cfa45='msvisibilitychange',_0x24b195='msHidden'):typeof document['webkitHidden']<'u'&&(_0x1cfa45='webkitvisibilitychange',_0x24b195='webkitHidden')),this['visible_']=!0x0,_0x1cfa45&&document['addEventListener'](_0x1cfa45,()=>{const _0x69458c=!document[_0x24b195];_0x69458c!==this['visible_']&&(this['visible_']=_0x69458c,this['trigger']('visible',_0x69458c));},!0x1);}['getInitialEvent'](_0x4b561f){return f(_0x4b561f==='visible','Unknown\x20event\x20type:\x20'+_0x4b561f),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x136dfc,_0x2b679c,_0x4c9194,_0x2c3775,_0x17e555,_0xde185,_0x37fc30,_0x499855){if(super(),this['repoInfo_']=_0x136dfc,this['applicationId_']=_0x2b679c,this['onDataUpdate_']=_0x4c9194,this['onConnectStatus_']=_0x2c3775,this['onServerInfoUpdate_']=_0x17e555,this['authTokenProvider_']=_0xde185,this['appCheckTokenProvider_']=_0x37fc30,this['authOverride_']=_0x499855,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x499855)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x136dfc['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x468843,_0x3b543a,_0x3a406e){const _0x2a2b2c=++this['requestNumber_'],_0x180e2b={'r':_0x2a2b2c,'a':_0x468843,'b':_0x3b543a};this['log_'](O(_0x180e2b)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x180e2b),_0x3a406e&&(this['requestCBHash_'][_0x2a2b2c]=_0x3a406e);}['get'](_0x2a23a5){this['initConnection_']();const _0x14c836=new ot(),_0x37c7c7={'action':'g','request':{'p':_0x2a23a5['_path']['toString'](),'q':_0x2a23a5['_queryObject']},'onComplete':_0x1dcfcc=>{const _0x2f1233=_0x1dcfcc['d'];_0x1dcfcc['s']==='ok'?_0x14c836['resolve'](_0x2f1233):_0x14c836['reject'](_0x2f1233);}};this['outstandingGets_']['push'](_0x37c7c7),this['outstandingGetCount_']++;const _0x25c8b4=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x25c8b4),_0x14c836['promise'];}['listen'](_0x38b056,_0x52e819,_0x409539,_0x53f1c2){this['initConnection_']();const _0x4b09d9=_0x38b056['_queryIdentifier'],_0x54144e=_0x38b056['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x54144e+'\x20'+_0x4b09d9),this['listens']['has'](_0x54144e)||this['listens']['set'](_0x54144e,new Map()),f(_0x38b056['_queryParams']['isDefault']()||!_0x38b056['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x54144e)['has'](_0x4b09d9),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x1e9825={'onComplete':_0x53f1c2,'hashFn':_0x52e819,'query':_0x38b056,'tag':_0x409539};this['listens']['get'](_0x54144e)['set'](_0x4b09d9,_0x1e9825),this['connected_']&&this['sendListen_'](_0x1e9825);}['sendGet_'](_0x41c8db){const _0xb789bc=this['outstandingGets_'][_0x41c8db];this['sendRequest']('g',_0xb789bc['request'],_0x9c265d=>{delete this['outstandingGets_'][_0x41c8db],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0xb789bc['onComplete']&&_0xb789bc['onComplete'](_0x9c265d);});}['sendListen_'](_0x417544){const _0x413f3e=_0x417544['query'],_0x1842e3=_0x413f3e['_path']['toString'](),_0x2faef1=_0x413f3e['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x1842e3+'\x20for\x20'+_0x2faef1);const _0x552efe={'p':_0x1842e3},_0x4096be='q';_0x417544['tag']&&(_0x552efe['q']=_0x413f3e['_queryObject'],_0x552efe['t']=_0x417544['tag']),_0x552efe['h']=_0x417544['hashFn'](),this['sendRequest'](_0x4096be,_0x552efe,_0x151afc=>{const _0x3600f2=_0x151afc['d'],_0x295913=_0x151afc['s'];se['warnOnListenWarnings_'](_0x3600f2,_0x413f3e),(this['listens']['get'](_0x1842e3)&&this['listens']['get'](_0x1842e3)['get'](_0x2faef1))===_0x417544&&(this['log_']('listen\x20response',_0x151afc),_0x295913!=='ok'&&this['removeListen_'](_0x1842e3,_0x2faef1),_0x417544['onComplete']&&_0x417544['onComplete'](_0x295913,_0x3600f2));});}static['warnOnListenWarnings_'](_0x32099b,_0x47116a){if(_0x32099b&&typeof _0x32099b=='object'&&J(_0x32099b,'w')){const _0x4352bb=De(_0x32099b,'w');if(Array['isArray'](_0x4352bb)&&~_0x4352bb['indexOf']('no_index')){const _0x13cf1e='\x22.indexOn\x22:\x20\x22'+_0x47116a['_queryParams']['getIndex']()['toString']()+'\x22',_0x1fa96b=_0x47116a['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x13cf1e+'\x20at\x20'+_0x1fa96b+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x5894fd){this['authToken_']=_0x5894fd,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x5894fd);}['reduceReconnectDelayIfAdminCredential_'](_0x15f043){(_0x15f043&&_0x15f043['length']===0x28||wc(_0x15f043))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x23b670){this['appCheckToken_']=_0x23b670,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x4af458=this['authToken_'],_0x504a73=Ic(_0x4af458)?'auth':'gauth',_0x23edd6={'cred':_0x4af458};this['authOverride_']===null?_0x23edd6['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x23edd6['authvar']=this['authOverride_']),this['sendRequest'](_0x504a73,_0x23edd6,_0x26c169=>{const _0x14d47c=_0x26c169['s'],_0x221772=_0x26c169['d']||'error';this['authToken_']===_0x4af458&&(_0x14d47c==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x14d47c,_0x221772));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x1d1377=>{const _0xa47407=_0x1d1377['s'],_0x13842e=_0x1d1377['d']||'error';_0xa47407==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0xa47407,_0x13842e);});}['unlisten'](_0x4f146e,_0x9809ab){const _0x42376c=_0x4f146e['_path']['toString'](),_0x24f279=_0x4f146e['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x42376c+'\x20'+_0x24f279),f(_0x4f146e['_queryParams']['isDefault']()||!_0x4f146e['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x42376c,_0x24f279)&&this['connected_']&&this['sendUnlisten_'](_0x42376c,_0x24f279,_0x4f146e['_queryObject'],_0x9809ab);}['sendUnlisten_'](_0x28c798,_0xb5da6d,_0x232627,_0xb84396){this['log_']('Unlisten\x20on\x20'+_0x28c798+'\x20for\x20'+_0xb5da6d);const _0x3ddd9e={'p':_0x28c798},_0x1fdc3c='n';_0xb84396&&(_0x3ddd9e['q']=_0x232627,_0x3ddd9e['t']=_0xb84396),this['sendRequest'](_0x1fdc3c,_0x3ddd9e);}['onDisconnectPut'](_0x327104,_0x13a557,_0x2ce4d3){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x327104,_0x13a557,_0x2ce4d3):this['onDisconnectRequestQueue_']['push']({'pathString':_0x327104,'action':'o','data':_0x13a557,'onComplete':_0x2ce4d3});}['onDisconnectMerge'](_0x2f02ab,_0x4c5c33,_0x56f98a){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x2f02ab,_0x4c5c33,_0x56f98a):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2f02ab,'action':'om','data':_0x4c5c33,'onComplete':_0x56f98a});}['onDisconnectCancel'](_0x350af2,_0x3aa0a8){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x350af2,null,_0x3aa0a8):this['onDisconnectRequestQueue_']['push']({'pathString':_0x350af2,'action':'oc','data':null,'onComplete':_0x3aa0a8});}['sendOnDisconnect_'](_0x4771c9,_0x14cc9e,_0x496af1,_0x5ccb15){const _0x9d0b55={'p':_0x14cc9e,'d':_0x496af1};this['log_']('onDisconnect\x20'+_0x4771c9,_0x9d0b55),this['sendRequest'](_0x4771c9,_0x9d0b55,_0x21e63a=>{_0x5ccb15&&setTimeout(()=>{_0x5ccb15(_0x21e63a['s'],_0x21e63a['d']);},Math['floor'](0x0));});}['put'](_0x126a78,_0x1fee2a,_0x334096,_0x26ff88){this['putInternal']('p',_0x126a78,_0x1fee2a,_0x334096,_0x26ff88);}['merge'](_0x4734d1,_0x596cd3,_0x8d0ca9,_0x40a989){this['putInternal']('m',_0x4734d1,_0x596cd3,_0x8d0ca9,_0x40a989);}['putInternal'](_0x25194f,_0x2423d4,_0x294569,_0x228a40,_0x2a43bf){this['initConnection_']();const _0x4d6f5f={'p':_0x2423d4,'d':_0x294569};_0x2a43bf!==void 0x0&&(_0x4d6f5f['h']=_0x2a43bf),this['outstandingPuts_']['push']({'action':_0x25194f,'request':_0x4d6f5f,'onComplete':_0x228a40}),this['outstandingPutCount_']++;const _0x34e81d=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x34e81d):this['log_']('Buffering\x20put:\x20'+_0x2423d4);}['sendPut_'](_0x13e6ce){const _0x31cd89=this['outstandingPuts_'][_0x13e6ce]['action'],_0x515f8b=this['outstandingPuts_'][_0x13e6ce]['request'],_0x31bfb5=this['outstandingPuts_'][_0x13e6ce]['onComplete'];this['outstandingPuts_'][_0x13e6ce]['queued']=this['connected_'],this['sendRequest'](_0x31cd89,_0x515f8b,_0x42406c=>{this['log_'](_0x31cd89+'\x20response',_0x42406c),delete this['outstandingPuts_'][_0x13e6ce],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x31bfb5&&_0x31bfb5(_0x42406c['s'],_0x42406c['d']);});}['reportStats'](_0x3ca53f){if(this['connected_']){const _0x3fd7a0={'c':_0x3ca53f};this['log_']('reportStats',_0x3fd7a0),this['sendRequest']('s',_0x3fd7a0,_0x344e72=>{if(_0x344e72['s']!=='ok'){const _0x52876f=_0x344e72['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x52876f);}});}}['onDataMessage_'](_0x4ba712){if('r'in _0x4ba712){this['log_']('from\x20server:\x20'+O(_0x4ba712));const _0x2d7545=_0x4ba712['r'],_0x3f3d2d=this['requestCBHash_'][_0x2d7545];_0x3f3d2d&&(delete this['requestCBHash_'][_0x2d7545],_0x3f3d2d(_0x4ba712['b']));}else{if('error'in _0x4ba712)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x4ba712['error'];'a'in _0x4ba712&&this['onDataPush_'](_0x4ba712['a'],_0x4ba712['b']);}}['onDataPush_'](_0x1daf61,_0x40ff26){this['log_']('handleServerMessage',_0x1daf61,_0x40ff26),_0x1daf61==='d'?this['onDataUpdate_'](_0x40ff26['p'],_0x40ff26['d'],!0x1,_0x40ff26['t']):_0x1daf61==='m'?this['onDataUpdate_'](_0x40ff26['p'],_0x40ff26['d'],!0x0,_0x40ff26['t']):_0x1daf61==='c'?this['onListenRevoked_'](_0x40ff26['p'],_0x40ff26['q']):_0x1daf61==='ac'?this['onAuthRevoked_'](_0x40ff26['s'],_0x40ff26['d']):_0x1daf61==='apc'?this['onAppCheckRevoked_'](_0x40ff26['s'],_0x40ff26['d']):_0x1daf61==='sd'?this['onSecurityDebugPacket_'](_0x40ff26):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x1daf61)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x3ce7ee,_0x431789){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x3ce7ee),this['lastSessionId']=_0x431789,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x2af417){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x2af417));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x42b6bc){_0x42b6bc&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x42b6bc;}['onOnline_'](_0x3dd45c){_0x3dd45c?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x32c25a=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x1263f4=Math['max'](0x0,this['reconnectDelay_']-_0x32c25a);_0x1263f4=Math['random']()*_0x1263f4,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x1263f4+'ms'),this['scheduleConnect_'](_0x1263f4),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x2c0a76=this['onDataMessage_']['bind'](this),_0x19a070=this['onReady_']['bind'](this),_0x4c7daa=this['onRealtimeDisconnect_']['bind'](this),_0x3fc99f=this['id']+':'+se['nextConnectionId_']++,_0x2e5edd=this['lastSessionId'];let _0x3055d8=!0x1,_0x4b5be5=null;const _0x5ae707=function(){_0x4b5be5?_0x4b5be5['close']():(_0x3055d8=!0x0,_0x4c7daa());},_0x66d7a3=function(_0x5ba1f0){f(_0x4b5be5,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x4b5be5['sendRequest'](_0x5ba1f0);};this['realtime_']={'close':_0x5ae707,'sendRequest':_0x66d7a3};const _0x22dec7=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x39bebf,_0x3e05e3]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x22dec7),this['appCheckTokenProvider_']['getToken'](_0x22dec7)]);_0x3055d8?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x39bebf&&_0x39bebf['accessToken'],this['appCheckToken_']=_0x3e05e3&&_0x3e05e3['token'],_0x4b5be5=new Sh(_0x3fc99f,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x2c0a76,_0x19a070,_0x4c7daa,_0x19cd69=>{U(_0x19cd69+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x2e5edd));}catch(_0x5e48e1){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x5e48e1),_0x3055d8||(this['repoInfo_']['nodeAdmin']&&U(_0x5e48e1),_0x5ae707());}}}['interrupt'](_0x5895a5){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x5895a5),this['interruptReasons_'][_0x5895a5]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x148f0d){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x148f0d),delete this['interruptReasons_'][_0x148f0d],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x38f614){const _0xe54f7f=_0x38f614-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0xe54f7f});}['cancelSentTransactions_'](){for(let _0x317757=0x0;_0x317757<this['outstandingPuts_']['length'];_0x317757++){const _0x35134f=this['outstandingPuts_'][_0x317757];_0x35134f&&'h'in _0x35134f['request']&&_0x35134f['queued']&&(_0x35134f['onComplete']&&_0x35134f['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x317757],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0xe3aa44,_0x1213b1){let _0x48e646;_0x1213b1?_0x48e646=_0x1213b1['map'](_0x58e2fe=>Hi(_0x58e2fe))['join']('$'):_0x48e646='default';const _0x141de4=this['removeListen_'](_0xe3aa44,_0x48e646);_0x141de4&&_0x141de4['onComplete']&&_0x141de4['onComplete']('permission_denied');}['removeListen_'](_0x23a2e9,_0x898e0e){const _0x3fc1df=new C(_0x23a2e9)['toString']();let _0x1d81d7;if(this['listens']['has'](_0x3fc1df)){const _0x69fa7e=this['listens']['get'](_0x3fc1df);_0x1d81d7=_0x69fa7e['get'](_0x898e0e),_0x69fa7e['delete'](_0x898e0e),_0x69fa7e['size']===0x0&&this['listens']['delete'](_0x3fc1df);}else _0x1d81d7=void 0x0;return _0x1d81d7;}['onAuthRevoked_'](_0x25ce9c,_0xe07fd){L('Auth\x20token\x20revoked:\x20'+_0x25ce9c+'/'+_0xe07fd),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x25ce9c==='invalid_token'||_0x25ce9c==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x1bade9,_0x52295d){L('App\x20check\x20token\x20revoked:\x20'+_0x1bade9+'/'+_0x52295d),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x1bade9==='invalid_token'||_0x1bade9==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x5949b6){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x5949b6):'msg'in _0x5949b6&&console['log']('FIREBASE:\x20'+_0x5949b6['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x5c6564 of this['listens']['values']())for(const _0x5b7a4b of _0x5c6564['values']())this['sendListen_'](_0x5b7a4b);for(let _0xd8c99b=0x0;_0xd8c99b<this['outstandingPuts_']['length'];_0xd8c99b++)this['outstandingPuts_'][_0xd8c99b]&&this['sendPut_'](_0xd8c99b);for(;this['onDisconnectRequestQueue_']['length'];){const _0x42afa4=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x42afa4['action'],_0x42afa4['pathString'],_0x42afa4['data'],_0x42afa4['onComplete']);}for(let _0x28cd2f=0x0;_0x28cd2f<this['outstandingGets_']['length'];_0x28cd2f++)this['outstandingGets_'][_0x28cd2f]&&this['sendGet_'](_0x28cd2f);}['sendConnectStats_'](){const _0x2fcd4f={};let _0xb062fd='js';_0x2fcd4f['sdk.'+_0xb062fd+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x2fcd4f['framework.cordova']=0x1:Yr()&&(_0x2fcd4f['framework.reactnative']=0x1),this['reportStats'](_0x2fcd4f);}['shouldReconnect_'](){const _0x2c41d1=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x2c41d1;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x376dbf,_0x5259ff){this['name']=_0x376dbf,this['node']=_0x5259ff;}static['Wrap'](_0x459f88,_0x3a8f44){return new E(_0x459f88,_0x3a8f44);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x167c68,_0x3d4497){const _0x598a24=new E(Fe,_0x167c68),_0x1a81f2=new E(Fe,_0x3d4497);return this['compare'](_0x598a24,_0x1a81f2)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x14735d){Zt=_0x14735d;}['compare'](_0x8c6891,_0xd347f9){return He(_0x8c6891['name'],_0xd347f9['name']);}['isDefinedOn'](_0x436a0a){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x9bc91d,_0x16f9e1){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x1e3041,_0xf22d74){return f(typeof _0x1e3041=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x1e3041,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x317cc5,_0x4620cc,_0xbd6a80,_0x5c6c9f,_0x53b8c5=null){this['isReverse_']=_0x5c6c9f,this['resultGenerator_']=_0x53b8c5,this['nodeStack_']=[];let _0x504441=0x1;for(;!_0x317cc5['isEmpty']();)if(_0x317cc5=_0x317cc5,_0x504441=_0x4620cc?_0xbd6a80(_0x317cc5['key'],_0x4620cc):0x1,_0x5c6c9f&&(_0x504441*=-0x1),_0x504441<0x0)this['isReverse_']?_0x317cc5=_0x317cc5['left']:_0x317cc5=_0x317cc5['right'];else{if(_0x504441===0x0){this['nodeStack_']['push'](_0x317cc5);break;}else this['nodeStack_']['push'](_0x317cc5),this['isReverse_']?_0x317cc5=_0x317cc5['right']:_0x317cc5=_0x317cc5['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x1e082b=this['nodeStack_']['pop'](),_0x54f012;if(this['resultGenerator_']?_0x54f012=this['resultGenerator_'](_0x1e082b['key'],_0x1e082b['value']):_0x54f012={'key':_0x1e082b['key'],'value':_0x1e082b['value']},this['isReverse_']){for(_0x1e082b=_0x1e082b['left'];!_0x1e082b['isEmpty']();)this['nodeStack_']['push'](_0x1e082b),_0x1e082b=_0x1e082b['right'];}else{for(_0x1e082b=_0x1e082b['right'];!_0x1e082b['isEmpty']();)this['nodeStack_']['push'](_0x1e082b),_0x1e082b=_0x1e082b['left'];}return _0x54f012;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0xd92a56=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0xd92a56['key'],_0xd92a56['value']):{'key':_0xd92a56['key'],'value':_0xd92a56['value']};}}class M{constructor(_0x13f358,_0x23e4cf,_0x2833f1,_0x1b225d,_0x4496f6){this['key']=_0x13f358,this['value']=_0x23e4cf,this['color']=_0x2833f1??M['RED'],this['left']=_0x1b225d??B['EMPTY_NODE'],this['right']=_0x4496f6??B['EMPTY_NODE'];}['copy'](_0x202d72,_0x4e5445,_0x5d3e4d,_0x1049c2,_0x27c0d0){return new M(_0x202d72??this['key'],_0x4e5445??this['value'],_0x5d3e4d??this['color'],_0x1049c2??this['left'],_0x27c0d0??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x2497e7){return this['left']['inorderTraversal'](_0x2497e7)||!!_0x2497e7(this['key'],this['value'])||this['right']['inorderTraversal'](_0x2497e7);}['reverseTraversal'](_0x2dacca){return this['right']['reverseTraversal'](_0x2dacca)||_0x2dacca(this['key'],this['value'])||this['left']['reverseTraversal'](_0x2dacca);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x516635,_0x337ad6,_0x576a39){let _0x4fe42f=this;const _0x5dc1c9=_0x576a39(_0x516635,_0x4fe42f['key']);return _0x5dc1c9<0x0?_0x4fe42f=_0x4fe42f['copy'](null,null,null,_0x4fe42f['left']['insert'](_0x516635,_0x337ad6,_0x576a39),null):_0x5dc1c9===0x0?_0x4fe42f=_0x4fe42f['copy'](null,_0x337ad6,null,null,null):_0x4fe42f=_0x4fe42f['copy'](null,null,null,null,_0x4fe42f['right']['insert'](_0x516635,_0x337ad6,_0x576a39)),_0x4fe42f['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x313049=this;return!_0x313049['left']['isRed_']()&&!_0x313049['left']['left']['isRed_']()&&(_0x313049=_0x313049['moveRedLeft_']()),_0x313049=_0x313049['copy'](null,null,null,_0x313049['left']['removeMin_'](),null),_0x313049['fixUp_']();}['remove'](_0x299dc8,_0x3a3be5){let _0x255ec1,_0x3b5791;if(_0x255ec1=this,_0x3a3be5(_0x299dc8,_0x255ec1['key'])<0x0)!_0x255ec1['left']['isEmpty']()&&!_0x255ec1['left']['isRed_']()&&!_0x255ec1['left']['left']['isRed_']()&&(_0x255ec1=_0x255ec1['moveRedLeft_']()),_0x255ec1=_0x255ec1['copy'](null,null,null,_0x255ec1['left']['remove'](_0x299dc8,_0x3a3be5),null);else{if(_0x255ec1['left']['isRed_']()&&(_0x255ec1=_0x255ec1['rotateRight_']()),!_0x255ec1['right']['isEmpty']()&&!_0x255ec1['right']['isRed_']()&&!_0x255ec1['right']['left']['isRed_']()&&(_0x255ec1=_0x255ec1['moveRedRight_']()),_0x3a3be5(_0x299dc8,_0x255ec1['key'])===0x0){if(_0x255ec1['right']['isEmpty']())return B['EMPTY_NODE'];_0x3b5791=_0x255ec1['right']['min_'](),_0x255ec1=_0x255ec1['copy'](_0x3b5791['key'],_0x3b5791['value'],null,null,_0x255ec1['right']['removeMin_']());}_0x255ec1=_0x255ec1['copy'](null,null,null,null,_0x255ec1['right']['remove'](_0x299dc8,_0x3a3be5));}return _0x255ec1['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x39fec4=this;return _0x39fec4['right']['isRed_']()&&!_0x39fec4['left']['isRed_']()&&(_0x39fec4=_0x39fec4['rotateLeft_']()),_0x39fec4['left']['isRed_']()&&_0x39fec4['left']['left']['isRed_']()&&(_0x39fec4=_0x39fec4['rotateRight_']()),_0x39fec4['left']['isRed_']()&&_0x39fec4['right']['isRed_']()&&(_0x39fec4=_0x39fec4['colorFlip_']()),_0x39fec4;}['moveRedLeft_'](){let _0x7c39df=this['colorFlip_']();return _0x7c39df['right']['left']['isRed_']()&&(_0x7c39df=_0x7c39df['copy'](null,null,null,null,_0x7c39df['right']['rotateRight_']()),_0x7c39df=_0x7c39df['rotateLeft_'](),_0x7c39df=_0x7c39df['colorFlip_']()),_0x7c39df;}['moveRedRight_'](){let _0x4e75a5=this['colorFlip_']();return _0x4e75a5['left']['left']['isRed_']()&&(_0x4e75a5=_0x4e75a5['rotateRight_'](),_0x4e75a5=_0x4e75a5['colorFlip_']()),_0x4e75a5;}['rotateLeft_'](){const _0x25f1b4=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x25f1b4,null);}['rotateRight_'](){const _0x1fe814=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x1fe814);}['colorFlip_'](){const _0x323dbb=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x17dec8=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x323dbb,_0x17dec8);}['checkMaxDepth_'](){const _0x5d2127=this['check_']();return Math['pow'](0x2,_0x5d2127)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x1ca566=this['left']['check_']();if(_0x1ca566!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x1ca566+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x1556a7,_0x2d72b3,_0x5ae311,_0xefb15b,_0x21009b){return this;}['insert'](_0x1069e6,_0x4850a7,_0x3fed60){return new M(_0x1069e6,_0x4850a7,null);}['remove'](_0x322925,_0x33d2a9){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x5c016f){return!0x1;}['reverseTraversal'](_0x125a12){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x1e9234,_0x2766ab=B['EMPTY_NODE']){this['comparator_']=_0x1e9234,this['root_']=_0x2766ab;}['insert'](_0x235632,_0x1ac96f){return new B(this['comparator_'],this['root_']['insert'](_0x235632,_0x1ac96f,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x2a5d26){return new B(this['comparator_'],this['root_']['remove'](_0x2a5d26,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x3ec6a7){let _0x1d8b45,_0x5f3850=this['root_'];for(;!_0x5f3850['isEmpty']();){if(_0x1d8b45=this['comparator_'](_0x3ec6a7,_0x5f3850['key']),_0x1d8b45===0x0)return _0x5f3850['value'];_0x1d8b45<0x0?_0x5f3850=_0x5f3850['left']:_0x1d8b45>0x0&&(_0x5f3850=_0x5f3850['right']);}return null;}['getPredecessorKey'](_0x439cf3){let _0x54ce67,_0x4eb0e5=this['root_'],_0x2f35e7=null;for(;!_0x4eb0e5['isEmpty']();)if(_0x54ce67=this['comparator_'](_0x439cf3,_0x4eb0e5['key']),_0x54ce67===0x0){if(_0x4eb0e5['left']['isEmpty']())return _0x2f35e7?_0x2f35e7['key']:null;for(_0x4eb0e5=_0x4eb0e5['left'];!_0x4eb0e5['right']['isEmpty']();)_0x4eb0e5=_0x4eb0e5['right'];return _0x4eb0e5['key'];}else _0x54ce67<0x0?_0x4eb0e5=_0x4eb0e5['left']:_0x54ce67>0x0&&(_0x2f35e7=_0x4eb0e5,_0x4eb0e5=_0x4eb0e5['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0xfad6e8){return this['root_']['inorderTraversal'](_0xfad6e8);}['reverseTraversal'](_0x41aab3){return this['root_']['reverseTraversal'](_0x41aab3);}['getIterator'](_0x3e13fe){return new en(this['root_'],null,this['comparator_'],!0x1,_0x3e13fe);}['getIteratorFrom'](_0xbab12b,_0x1db17f){return new en(this['root_'],_0xbab12b,this['comparator_'],!0x1,_0x1db17f);}['getReverseIteratorFrom'](_0x2b3680,_0x473180){return new en(this['root_'],_0x2b3680,this['comparator_'],!0x0,_0x473180);}['getReverseIterator'](_0x456628){return new en(this['root_'],null,this['comparator_'],!0x0,_0x456628);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x2a9e91,_0x1de132){return He(_0x2a9e91['name'],_0x1de132['name']);}function Yi(_0x4636ae,_0x947ebb){return He(_0x4636ae,_0x947ebb);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x1c16f9){Ei=_0x1c16f9;}const No=function(_0x1aee5f){return typeof _0x1aee5f=='number'?'number:'+ao(_0x1aee5f):'string:'+_0x1aee5f;},Po=function(_0x3e5994){if(_0x3e5994['isLeafNode']()){const _0x56e3f6=_0x3e5994['val']();f(typeof _0x56e3f6=='string'||typeof _0x56e3f6=='number'||typeof _0x56e3f6=='object'&&J(_0x56e3f6,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x3e5994===Ei||_0x3e5994['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x3e5994===Ei||_0x3e5994['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x73ae40){ir=_0x73ae40;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x3d9c48,_0x494dee=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x3d9c48,this['priorityNode_']=_0x494dee,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x158a69){return new D(this['value_'],_0x158a69);}['getImmediateChild'](_0xdd4369){return _0xdd4369==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x7da3cf){return v(_0x7da3cf)?this:y(_0x7da3cf)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0xecba4b,_0x24c970){return null;}['updateImmediateChild'](_0x5db4a8,_0x1c09b3){return _0x5db4a8==='.priority'?this['updatePriority'](_0x1c09b3):_0x1c09b3['isEmpty']()&&_0x5db4a8!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x5db4a8,_0x1c09b3)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x29b42e,_0x2e7295){const _0x35eb50=y(_0x29b42e);return _0x35eb50===null?_0x2e7295:_0x2e7295['isEmpty']()&&_0x35eb50!=='.priority'?this:(f(_0x35eb50!=='.priority'||we(_0x29b42e)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x35eb50,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x29b42e),_0x2e7295)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x33b382,_0x22c8e0){return!0x1;}['val'](_0x469e12){return _0x469e12&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x470c5d='';this['priorityNode_']['isEmpty']()||(_0x470c5d+='priority:'+No(this['priorityNode_']['val']())+':');const _0x569216=typeof this['value_'];_0x470c5d+=_0x569216+':',_0x569216==='number'?_0x470c5d+=ao(this['value_']):_0x470c5d+=this['value_'],this['lazyHash_']=ro(_0x470c5d);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x328cc0){return _0x328cc0===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x328cc0 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x328cc0['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x328cc0));}['compareToLeafNode_'](_0x3f1960){const _0x1ed203=typeof _0x3f1960['value_'],_0x22d24a=typeof this['value_'],_0x52c9f1=D['VALUE_TYPE_ORDER']['indexOf'](_0x1ed203),_0x300afd=D['VALUE_TYPE_ORDER']['indexOf'](_0x22d24a);return f(_0x52c9f1>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1ed203),f(_0x300afd>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x22d24a),_0x52c9f1===_0x300afd?_0x22d24a==='object'?0x0:this['value_']<_0x3f1960['value_']?-0x1:this['value_']===_0x3f1960['value_']?0x0:0x1:_0x300afd-_0x52c9f1;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x10b2ae){if(_0x10b2ae===this)return!0x0;if(_0x10b2ae['isLeafNode']()){const _0x17f120=_0x10b2ae;return this['value_']===_0x17f120['value_']&&this['priorityNode_']['equals'](_0x17f120['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x22b485){Oo=_0x22b485;}function Wh(_0x13e30b){Do=_0x13e30b;}class Bh extends Dn{['compare'](_0xb03a77,_0x2de20c){const _0x2ed704=_0xb03a77['node']['getPriority'](),_0x2010c5=_0x2de20c['node']['getPriority'](),_0x4106ec=_0x2ed704['compareTo'](_0x2010c5);return _0x4106ec===0x0?He(_0xb03a77['name'],_0x2de20c['name']):_0x4106ec;}['isDefinedOn'](_0x2214f4){return!_0x2214f4['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x50caab,_0x1b919c){return!_0x50caab['getPriority']()['equals'](_0x1b919c['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x51d414,_0x41bec5){const _0x42dc6b=Oo(_0x51d414);return new E(_0x41bec5,new D('[PRIORITY-POST]',_0x42dc6b));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x52c6bf){const _0x2c3cd1=_0x1cd8df=>parseInt(Math['log'](_0x1cd8df)/Vh,0xa),_0x3c054b=_0x571c92=>parseInt(Array(_0x571c92+0x1)['join']('1'),0x2);this['count']=_0x2c3cd1(_0x52c6bf+0x1),this['current_']=this['count']-0x1;const _0x5026e9=_0x3c054b(this['count']);this['bits_']=_0x52c6bf+0x1&_0x5026e9;}['nextBitIsOne'](){const _0x368c52=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x368c52;}}const fn=function(_0x21b80b,_0x3f7665,_0x212b47,_0x54624a){_0x21b80b['sort'](_0x3f7665);const _0x2f571a=function(_0x1bf0e8,_0xf9a43e){const _0x2a541b=_0xf9a43e-_0x1bf0e8;let _0x2a01e1,_0x48b7c8;if(_0x2a541b===0x0)return null;if(_0x2a541b===0x1)return _0x2a01e1=_0x21b80b[_0x1bf0e8],_0x48b7c8=_0x212b47?_0x212b47(_0x2a01e1):_0x2a01e1,new M(_0x48b7c8,_0x2a01e1['node'],M['BLACK'],null,null);{const _0xe9069=parseInt(_0x2a541b/0x2,0xa)+_0x1bf0e8,_0x4298b4=_0x2f571a(_0x1bf0e8,_0xe9069),_0x654fb7=_0x2f571a(_0xe9069+0x1,_0xf9a43e);return _0x2a01e1=_0x21b80b[_0xe9069],_0x48b7c8=_0x212b47?_0x212b47(_0x2a01e1):_0x2a01e1,new M(_0x48b7c8,_0x2a01e1['node'],M['BLACK'],_0x4298b4,_0x654fb7);}},_0x5d7d18=function(_0x37e4de){let _0xed13c0=null,_0xd842b=null,_0x5e2d78=_0x21b80b['length'];const _0x157145=function(_0x3c7d31,_0x29c7eb){const _0x1c1d15=_0x5e2d78-_0x3c7d31,_0x36dafc=_0x5e2d78;_0x5e2d78-=_0x3c7d31;const _0x5394d7=_0x2f571a(_0x1c1d15+0x1,_0x36dafc),_0x5570af=_0x21b80b[_0x1c1d15],_0x4b0568=_0x212b47?_0x212b47(_0x5570af):_0x5570af;_0x37521a(new M(_0x4b0568,_0x5570af['node'],_0x29c7eb,null,_0x5394d7));},_0x37521a=function(_0x58fa67){_0xed13c0?(_0xed13c0['left']=_0x58fa67,_0xed13c0=_0x58fa67):(_0xd842b=_0x58fa67,_0xed13c0=_0x58fa67);};for(let _0x328b1b=0x0;_0x328b1b<_0x37e4de['count'];++_0x328b1b){const _0x110478=_0x37e4de['nextBitIsOne'](),_0x44068e=Math['pow'](0x2,_0x37e4de['count']-(_0x328b1b+0x1));_0x110478?_0x157145(_0x44068e,M['BLACK']):(_0x157145(_0x44068e,M['BLACK']),_0x157145(_0x44068e,M['RED']));}return _0xd842b;},_0x56cfbb=new Hh(_0x21b80b['length']),_0x1d8bf2=_0x5d7d18(_0x56cfbb);return new B(_0x54624a||_0x3f7665,_0x1d8bf2);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x452541,_0x404f4f){this['indexes_']=_0x452541,this['indexSet_']=_0x404f4f;}['get'](_0x241a7e){const _0x2a4489=De(this['indexes_'],_0x241a7e);if(!_0x2a4489)throw new Error('No\x20index\x20defined\x20for\x20'+_0x241a7e);return _0x2a4489 instanceof B?_0x2a4489:null;}['hasIndex'](_0x12e61f){return J(this['indexSet_'],_0x12e61f['toString']());}['addIndex'](_0x38ca55,_0x89476e){f(_0x38ca55!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x766161=[];let _0x22daf5=!0x1;const _0x190e0e=_0x89476e['getIterator'](E['Wrap']);let _0x207fd4=_0x190e0e['getNext']();for(;_0x207fd4;)_0x22daf5=_0x22daf5||_0x38ca55['isDefinedOn'](_0x207fd4['node']),_0x766161['push'](_0x207fd4),_0x207fd4=_0x190e0e['getNext']();let _0x318b90;_0x22daf5?_0x318b90=fn(_0x766161,_0x38ca55['getCompare']()):_0x318b90=ze;const _0x348891=_0x38ca55['toString'](),_0x59f2c2={...this['indexSet_']};_0x59f2c2[_0x348891]=_0x38ca55;const _0xd4929a={...this['indexes_']};return _0xd4929a[_0x348891]=_0x318b90,new te(_0xd4929a,_0x59f2c2);}['addToIndexes'](_0x4fbd2e,_0x2836d6){const _0x537c50=hn(this['indexes_'],(_0x108309,_0x148480)=>{const _0x2eee27=De(this['indexSet_'],_0x148480);if(f(_0x2eee27,'Missing\x20index\x20implementation\x20for\x20'+_0x148480),_0x108309===ze){if(_0x2eee27['isDefinedOn'](_0x4fbd2e['node'])){const _0x81d48a=[],_0x2ce2a9=_0x2836d6['getIterator'](E['Wrap']);let _0x469de3=_0x2ce2a9['getNext']();for(;_0x469de3;)_0x469de3['name']!==_0x4fbd2e['name']&&_0x81d48a['push'](_0x469de3),_0x469de3=_0x2ce2a9['getNext']();return _0x81d48a['push'](_0x4fbd2e),fn(_0x81d48a,_0x2eee27['getCompare']());}else return ze;}else{const _0x172210=_0x2836d6['get'](_0x4fbd2e['name']);let _0x10a581=_0x108309;return _0x172210&&(_0x10a581=_0x10a581['remove'](new E(_0x4fbd2e['name'],_0x172210))),_0x10a581['insert'](_0x4fbd2e,_0x4fbd2e['node']);}});return new te(_0x537c50,this['indexSet_']);}['removeFromIndexes'](_0x232f85,_0x34308e){const _0xbc40d3=hn(this['indexes_'],_0x501e1d=>{if(_0x501e1d===ze)return _0x501e1d;{const _0x27605f=_0x34308e['get'](_0x232f85['name']);return _0x27605f?_0x501e1d['remove'](new E(_0x232f85['name'],_0x27605f)):_0x501e1d;}});return new te(_0xbc40d3,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x50764b,_0xce2054,_0x5e80c5){this['children_']=_0x50764b,this['priorityNode_']=_0xce2054,this['indexMap_']=_0x5e80c5,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x2a6344){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x2a6344,this['indexMap_']);}['getImmediateChild'](_0x414f83){if(_0x414f83==='.priority')return this['getPriority']();{const _0x588042=this['children_']['get'](_0x414f83);return _0x588042===null?mt:_0x588042;}}['getChild'](_0x487270){const _0x27acfa=y(_0x487270);return _0x27acfa===null?this:this['getImmediateChild'](_0x27acfa)['getChild'](b(_0x487270));}['hasChild'](_0x585d8e){return this['children_']['get'](_0x585d8e)!==null;}['updateImmediateChild'](_0x1da93d,_0x3e3199){if(f(_0x3e3199,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x1da93d==='.priority')return this['updatePriority'](_0x3e3199);{const _0x588fbd=new E(_0x1da93d,_0x3e3199);let _0x5f3276,_0x1b4590;_0x3e3199['isEmpty']()?(_0x5f3276=this['children_']['remove'](_0x1da93d),_0x1b4590=this['indexMap_']['removeFromIndexes'](_0x588fbd,this['children_'])):(_0x5f3276=this['children_']['insert'](_0x1da93d,_0x3e3199),_0x1b4590=this['indexMap_']['addToIndexes'](_0x588fbd,this['children_']));const _0x1eccb5=_0x5f3276['isEmpty']()?mt:this['priorityNode_'];return new g(_0x5f3276,_0x1eccb5,_0x1b4590);}}['updateChild'](_0x4c8ccc,_0x8b12e1){const _0x120748=y(_0x4c8ccc);if(_0x120748===null)return _0x8b12e1;{f(y(_0x4c8ccc)!=='.priority'||we(_0x4c8ccc)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x352e49=this['getImmediateChild'](_0x120748)['updateChild'](b(_0x4c8ccc),_0x8b12e1);return this['updateImmediateChild'](_0x120748,_0x352e49);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x55cf6c){if(this['isEmpty']())return null;const _0x5c6b99={};let _0x43ee99=0x0,_0x540505=0x0,_0x512699=!0x0;if(this['forEachChild'](R,(_0xfd3062,_0x4f4e9e)=>{_0x5c6b99[_0xfd3062]=_0x4f4e9e['val'](_0x55cf6c),_0x43ee99++,_0x512699&&g['INTEGER_REGEXP_']['test'](_0xfd3062)?_0x540505=Math['max'](_0x540505,Number(_0xfd3062)):_0x512699=!0x1;}),!_0x55cf6c&&_0x512699&&_0x540505<0x2*_0x43ee99){const _0x234496=[];for(const _0x1c9ac0 in _0x5c6b99)_0x234496[_0x1c9ac0]=_0x5c6b99[_0x1c9ac0];return _0x234496;}else return _0x55cf6c&&!this['getPriority']()['isEmpty']()&&(_0x5c6b99['.priority']=this['getPriority']()['val']()),_0x5c6b99;}['hash'](){if(this['lazyHash_']===null){let _0xb6e8e9='';this['getPriority']()['isEmpty']()||(_0xb6e8e9+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x29645d,_0x584ca4)=>{const _0xa26872=_0x584ca4['hash']();_0xa26872!==''&&(_0xb6e8e9+=':'+_0x29645d+':'+_0xa26872);}),this['lazyHash_']=_0xb6e8e9===''?'':ro(_0xb6e8e9);}return this['lazyHash_'];}['getPredecessorChildName'](_0x47f5c5,_0x39896e,_0x298e43){const _0x4ce949=this['resolveIndex_'](_0x298e43);if(_0x4ce949){const _0x19db04=_0x4ce949['getPredecessorKey'](new E(_0x47f5c5,_0x39896e));return _0x19db04?_0x19db04['name']:null;}else return this['children_']['getPredecessorKey'](_0x47f5c5);}['getFirstChildName'](_0x104dd0){const _0x208da8=this['resolveIndex_'](_0x104dd0);if(_0x208da8){const _0x391dc8=_0x208da8['minKey']();return _0x391dc8&&_0x391dc8['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x3a0370){const _0x55952e=this['getFirstChildName'](_0x3a0370);return _0x55952e?new E(_0x55952e,this['children_']['get'](_0x55952e)):null;}['getLastChildName'](_0x3d04c2){const _0x5533c5=this['resolveIndex_'](_0x3d04c2);if(_0x5533c5){const _0x33d783=_0x5533c5['maxKey']();return _0x33d783&&_0x33d783['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x231aed){const _0x1e747d=this['getLastChildName'](_0x231aed);return _0x1e747d?new E(_0x1e747d,this['children_']['get'](_0x1e747d)):null;}['forEachChild'](_0x514416,_0x17ad7b){const _0x1598a1=this['resolveIndex_'](_0x514416);return _0x1598a1?_0x1598a1['inorderTraversal'](_0x3dd18b=>_0x17ad7b(_0x3dd18b['name'],_0x3dd18b['node'])):this['children_']['inorderTraversal'](_0x17ad7b);}['getIterator'](_0x1d655b){return this['getIteratorFrom'](_0x1d655b['minPost'](),_0x1d655b);}['getIteratorFrom'](_0x10c17a,_0x13fb52){const _0x28966d=this['resolveIndex_'](_0x13fb52);if(_0x28966d)return _0x28966d['getIteratorFrom'](_0x10c17a,_0x113197=>_0x113197);{const _0x33a3eb=this['children_']['getIteratorFrom'](_0x10c17a['name'],E['Wrap']);let _0x333cae=_0x33a3eb['peek']();for(;_0x333cae!=null&&_0x13fb52['compare'](_0x333cae,_0x10c17a)<0x0;)_0x33a3eb['getNext'](),_0x333cae=_0x33a3eb['peek']();return _0x33a3eb;}}['getReverseIterator'](_0x40c6b6){return this['getReverseIteratorFrom'](_0x40c6b6['maxPost'](),_0x40c6b6);}['getReverseIteratorFrom'](_0x268f45,_0xaec5c4){const _0x34c038=this['resolveIndex_'](_0xaec5c4);if(_0x34c038)return _0x34c038['getReverseIteratorFrom'](_0x268f45,_0x17015a=>_0x17015a);{const _0x4873ad=this['children_']['getReverseIteratorFrom'](_0x268f45['name'],E['Wrap']);let _0x1a792e=_0x4873ad['peek']();for(;_0x1a792e!=null&&_0xaec5c4['compare'](_0x1a792e,_0x268f45)>0x0;)_0x4873ad['getNext'](),_0x1a792e=_0x4873ad['peek']();return _0x4873ad;}}['compareTo'](_0x1d047d){return this['isEmpty']()?_0x1d047d['isEmpty']()?0x0:-0x1:_0x1d047d['isLeafNode']()||_0x1d047d['isEmpty']()?0x1:_0x1d047d===$t?-0x1:0x0;}['withIndex'](_0x230b20){if(_0x230b20===ye||this['indexMap_']['hasIndex'](_0x230b20))return this;{const _0x39fcf8=this['indexMap_']['addIndex'](_0x230b20,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x39fcf8);}}['isIndexed'](_0x51da8a){return _0x51da8a===ye||this['indexMap_']['hasIndex'](_0x51da8a);}['equals'](_0x7686e7){if(_0x7686e7===this)return!0x0;if(_0x7686e7['isLeafNode']())return!0x1;{const _0x17e80e=_0x7686e7;if(this['getPriority']()['equals'](_0x17e80e['getPriority']())){if(this['children_']['count']()===_0x17e80e['children_']['count']()){const _0x89c96d=this['getIterator'](R),_0x32c391=_0x17e80e['getIterator'](R);let _0x5b1ac7=_0x89c96d['getNext'](),_0x3de656=_0x32c391['getNext']();for(;_0x5b1ac7&&_0x3de656;){if(_0x5b1ac7['name']!==_0x3de656['name']||!_0x5b1ac7['node']['equals'](_0x3de656['node']))return!0x1;_0x5b1ac7=_0x89c96d['getNext'](),_0x3de656=_0x32c391['getNext']();}return _0x5b1ac7===null&&_0x3de656===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x14cf4a){return _0x14cf4a===ye?null:this['indexMap_']['get'](_0x14cf4a['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x39c907){return _0x39c907===this?0x0:0x1;}['equals'](_0x4131a7){return _0x4131a7===this;}['getPriority'](){return this;}['getImmediateChild'](_0x218f35){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x559f9b,_0x30dcef=null){if(_0x559f9b===null)return g['EMPTY_NODE'];if(typeof _0x559f9b=='object'&&'.priority'in _0x559f9b&&(_0x30dcef=_0x559f9b['.priority']),f(_0x30dcef===null||typeof _0x30dcef=='string'||typeof _0x30dcef=='number'||typeof _0x30dcef=='object'&&'.sv'in _0x30dcef,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x30dcef),typeof _0x559f9b=='object'&&'.value'in _0x559f9b&&_0x559f9b['.value']!==null&&(_0x559f9b=_0x559f9b['.value']),typeof _0x559f9b!='object'||'.sv'in _0x559f9b){const _0x4489fe=_0x559f9b;return new D(_0x4489fe,P(_0x30dcef));}if(!(_0x559f9b instanceof Array)&&Gh){const _0x225e37=[];let _0x41d63d=!0x1;if(x(_0x559f9b,(_0x5df2f5,_0x28fe23)=>{if(_0x5df2f5['substring'](0x0,0x1)!=='.'){const _0x181a33=P(_0x28fe23);_0x181a33['isEmpty']()||(_0x41d63d=_0x41d63d||!_0x181a33['getPriority']()['isEmpty'](),_0x225e37['push'](new E(_0x5df2f5,_0x181a33)));}}),_0x225e37['length']===0x0)return g['EMPTY_NODE'];const _0x3f1e99=fn(_0x225e37,xh,_0x5157e6=>_0x5157e6['name'],Yi);if(_0x41d63d){const _0x1c673d=fn(_0x225e37,R['getCompare']());return new g(_0x3f1e99,P(_0x30dcef),new te({'.priority':_0x1c673d},{'.priority':R}));}else return new g(_0x3f1e99,P(_0x30dcef),te['Default']);}else{let _0x1f036f=g['EMPTY_NODE'];return x(_0x559f9b,(_0x5bef54,_0x1550fd)=>{if(J(_0x559f9b,_0x5bef54)&&_0x5bef54['substring'](0x0,0x1)!=='.'){const _0x426d03=P(_0x1550fd);(_0x426d03['isLeafNode']()||!_0x426d03['isEmpty']())&&(_0x1f036f=_0x1f036f['updateImmediateChild'](_0x5bef54,_0x426d03));}}),_0x1f036f['updatePriority'](P(_0x30dcef));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x1e679e){super(),this['indexPath_']=_0x1e679e,f(!v(_0x1e679e)&&y(_0x1e679e)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x3566fa){return _0x3566fa['getChild'](this['indexPath_']);}['isDefinedOn'](_0x2279f8){return!_0x2279f8['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x41a944,_0x595867){const _0x284651=this['extractChild'](_0x41a944['node']),_0x477264=this['extractChild'](_0x595867['node']),_0xdb286a=_0x284651['compareTo'](_0x477264);return _0xdb286a===0x0?He(_0x41a944['name'],_0x595867['name']):_0xdb286a;}['makePost'](_0xaa4770,_0x1c938f){const _0x2ad580=P(_0xaa4770),_0x48bddf=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x2ad580);return new E(_0x1c938f,_0x48bddf);}['maxPost'](){const _0x4e7181=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x4e7181);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x3b70a0,_0x2460dd){const _0x125de3=_0x3b70a0['node']['compareTo'](_0x2460dd['node']);return _0x125de3===0x0?He(_0x3b70a0['name'],_0x2460dd['name']):_0x125de3;}['isDefinedOn'](_0x1d5361){return!0x0;}['indexedValueChanged'](_0x273462,_0x2f7f0d){return!_0x273462['equals'](_0x2f7f0d);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x5917a4,_0x2ed4f2){const _0x565b31=P(_0x5917a4);return new E(_0x2ed4f2,_0x565b31);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x137469){return{'type':'value','snapshotNode':_0x137469};}function et(_0x2ecbf6,_0x528e81){return{'type':'child_added','snapshotNode':_0x528e81,'childName':_0x2ecbf6};}function Ot(_0x305bb2,_0x2e42c9){return{'type':'child_removed','snapshotNode':_0x2e42c9,'childName':_0x305bb2};}function Dt(_0x591a9b,_0x5f579a,_0x16e722){return{'type':'child_changed','snapshotNode':_0x5f579a,'childName':_0x591a9b,'oldSnap':_0x16e722};}function zh(_0x5a47e8,_0xbf4903){return{'type':'child_moved','snapshotNode':_0xbf4903,'childName':_0x5a47e8};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x432a94){this['index_']=_0x432a94;}['updateChild'](_0x56d408,_0x164f6b,_0x261fd5,_0x4f3fc5,_0x4abf08,_0x44bb32){f(_0x56d408['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x361c52=_0x56d408['getImmediateChild'](_0x164f6b);return _0x361c52['getChild'](_0x4f3fc5)['equals'](_0x261fd5['getChild'](_0x4f3fc5))&&_0x361c52['isEmpty']()===_0x261fd5['isEmpty']()||(_0x44bb32!=null&&(_0x261fd5['isEmpty']()?_0x56d408['hasChild'](_0x164f6b)?_0x44bb32['trackChildChange'](Ot(_0x164f6b,_0x361c52)):f(_0x56d408['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x361c52['isEmpty']()?_0x44bb32['trackChildChange'](et(_0x164f6b,_0x261fd5)):_0x44bb32['trackChildChange'](Dt(_0x164f6b,_0x261fd5,_0x361c52))),_0x56d408['isLeafNode']()&&_0x261fd5['isEmpty']())?_0x56d408:_0x56d408['updateImmediateChild'](_0x164f6b,_0x261fd5)['withIndex'](this['index_']);}['updateFullNode'](_0x352495,_0x28e476,_0x309c37){return _0x309c37!=null&&(_0x352495['isLeafNode']()||_0x352495['forEachChild'](R,(_0x4072e6,_0x5e03e5)=>{_0x28e476['hasChild'](_0x4072e6)||_0x309c37['trackChildChange'](Ot(_0x4072e6,_0x5e03e5));}),_0x28e476['isLeafNode']()||_0x28e476['forEachChild'](R,(_0x2cb47c,_0x277c62)=>{if(_0x352495['hasChild'](_0x2cb47c)){const _0x59f2b2=_0x352495['getImmediateChild'](_0x2cb47c);_0x59f2b2['equals'](_0x277c62)||_0x309c37['trackChildChange'](Dt(_0x2cb47c,_0x277c62,_0x59f2b2));}else _0x309c37['trackChildChange'](et(_0x2cb47c,_0x277c62));})),_0x28e476['withIndex'](this['index_']);}['updatePriority'](_0x2f7408,_0x3602b7){return _0x2f7408['isEmpty']()?g['EMPTY_NODE']:_0x2f7408['updatePriority'](_0x3602b7);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x1f5736){this['indexedFilter_']=new Ji(_0x1f5736['getIndex']()),this['index_']=_0x1f5736['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x1f5736),this['endPost_']=Mt['getEndPost_'](_0x1f5736),this['startIsInclusive_']=!_0x1f5736['startAfterSet_'],this['endIsInclusive_']=!_0x1f5736['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x355865){const _0x2dbb88=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x355865)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x355865)<0x0,_0x29592d=this['endIsInclusive_']?this['index_']['compare'](_0x355865,this['getEndPost']())<=0x0:this['index_']['compare'](_0x355865,this['getEndPost']())<0x0;return _0x2dbb88&&_0x29592d;}['updateChild'](_0x13e04f,_0x123276,_0x4df6f4,_0x3ea348,_0x26ed9f,_0x54f008){return this['matches'](new E(_0x123276,_0x4df6f4))||(_0x4df6f4=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x13e04f,_0x123276,_0x4df6f4,_0x3ea348,_0x26ed9f,_0x54f008);}['updateFullNode'](_0xcd861a,_0x1ee018,_0x120134){_0x1ee018['isLeafNode']()&&(_0x1ee018=g['EMPTY_NODE']);let _0x37a2d0=_0x1ee018['withIndex'](this['index_']);_0x37a2d0=_0x37a2d0['updatePriority'](g['EMPTY_NODE']);const _0x5e9713=this;return _0x1ee018['forEachChild'](R,(_0x366572,_0x2b2de1)=>{_0x5e9713['matches'](new E(_0x366572,_0x2b2de1))||(_0x37a2d0=_0x37a2d0['updateImmediateChild'](_0x366572,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0xcd861a,_0x37a2d0,_0x120134);}['updatePriority'](_0x40cc38,_0x35451e){return _0x40cc38;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x4656af){if(_0x4656af['hasStart']()){const _0x5470cf=_0x4656af['getIndexStartName']();return _0x4656af['getIndex']()['makePost'](_0x4656af['getIndexStartValue'](),_0x5470cf);}else return _0x4656af['getIndex']()['minPost']();}static['getEndPost_'](_0x5b6ef0){if(_0x5b6ef0['hasEnd']()){const _0x19702f=_0x5b6ef0['getIndexEndName']();return _0x5b6ef0['getIndex']()['makePost'](_0x5b6ef0['getIndexEndValue'](),_0x19702f);}else return _0x5b6ef0['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x1cff9c){this['withinDirectionalStart']=_0x2550e9=>this['reverse_']?this['withinEndPost'](_0x2550e9):this['withinStartPost'](_0x2550e9),this['withinDirectionalEnd']=_0x485307=>this['reverse_']?this['withinStartPost'](_0x485307):this['withinEndPost'](_0x485307),this['withinStartPost']=_0x47c74e=>{const _0x4aa7a9=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x47c74e);return this['startIsInclusive_']?_0x4aa7a9<=0x0:_0x4aa7a9<0x0;},this['withinEndPost']=_0x2efb63=>{const _0x27fa2d=this['index_']['compare'](_0x2efb63,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x27fa2d<=0x0:_0x27fa2d<0x0;},this['rangedFilter_']=new Mt(_0x1cff9c),this['index_']=_0x1cff9c['getIndex'](),this['limit_']=_0x1cff9c['getLimit'](),this['reverse_']=!_0x1cff9c['isViewFromLeft'](),this['startIsInclusive_']=!_0x1cff9c['startAfterSet_'],this['endIsInclusive_']=!_0x1cff9c['endBeforeSet_'];}['updateChild'](_0x15acd5,_0x580408,_0x513566,_0x1edf18,_0x4628f6,_0x24acc7){return this['rangedFilter_']['matches'](new E(_0x580408,_0x513566))||(_0x513566=g['EMPTY_NODE']),_0x15acd5['getImmediateChild'](_0x580408)['equals'](_0x513566)?_0x15acd5:_0x15acd5['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x15acd5,_0x580408,_0x513566,_0x1edf18,_0x4628f6,_0x24acc7):this['fullLimitUpdateChild_'](_0x15acd5,_0x580408,_0x513566,_0x4628f6,_0x24acc7);}['updateFullNode'](_0x315fe2,_0x461f7,_0x441c6b){let _0x305272;if(_0x461f7['isLeafNode']()||_0x461f7['isEmpty']())_0x305272=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x461f7['numChildren']()&&_0x461f7['isIndexed'](this['index_'])){_0x305272=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x3e8739;this['reverse_']?_0x3e8739=_0x461f7['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x3e8739=_0x461f7['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x51f72d=0x0;for(;_0x3e8739['hasNext']()&&_0x51f72d<this['limit_'];){const _0x5f0c19=_0x3e8739['getNext']();if(this['withinDirectionalStart'](_0x5f0c19)){if(this['withinDirectionalEnd'](_0x5f0c19))_0x305272=_0x305272['updateImmediateChild'](_0x5f0c19['name'],_0x5f0c19['node']),_0x51f72d++;else break;}else continue;}}else{_0x305272=_0x461f7['withIndex'](this['index_']),_0x305272=_0x305272['updatePriority'](g['EMPTY_NODE']);let _0xaeb3a0;this['reverse_']?_0xaeb3a0=_0x305272['getReverseIterator'](this['index_']):_0xaeb3a0=_0x305272['getIterator'](this['index_']);let _0xc7aba7=0x0;for(;_0xaeb3a0['hasNext']();){const _0x502c18=_0xaeb3a0['getNext']();_0xc7aba7<this['limit_']&&this['withinDirectionalStart'](_0x502c18)&&this['withinDirectionalEnd'](_0x502c18)?_0xc7aba7++:_0x305272=_0x305272['updateImmediateChild'](_0x502c18['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x315fe2,_0x305272,_0x441c6b);}['updatePriority'](_0x50ff57,_0x2e43a0){return _0x50ff57;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x3a9e14,_0x643e2c,_0x5e1993,_0xf4c018,_0x4a6f79){let _0x5897f9;if(this['reverse_']){const _0xa78a7b=this['index_']['getCompare']();_0x5897f9=(_0x24f261,_0x20e0ef)=>_0xa78a7b(_0x20e0ef,_0x24f261);}else _0x5897f9=this['index_']['getCompare']();const _0x12d7e3=_0x3a9e14;f(_0x12d7e3['numChildren']()===this['limit_'],'');const _0x2f7f4d=new E(_0x643e2c,_0x5e1993),_0x2471dc=this['reverse_']?_0x12d7e3['getFirstChild'](this['index_']):_0x12d7e3['getLastChild'](this['index_']),_0x4b66b0=this['rangedFilter_']['matches'](_0x2f7f4d);if(_0x12d7e3['hasChild'](_0x643e2c)){const _0x1fd95e=_0x12d7e3['getImmediateChild'](_0x643e2c);let _0x4762a6=_0xf4c018['getChildAfterChild'](this['index_'],_0x2471dc,this['reverse_']);for(;_0x4762a6!=null&&(_0x4762a6['name']===_0x643e2c||_0x12d7e3['hasChild'](_0x4762a6['name']));)_0x4762a6=_0xf4c018['getChildAfterChild'](this['index_'],_0x4762a6,this['reverse_']);const _0x5e6eba=_0x4762a6==null?0x1:_0x5897f9(_0x4762a6,_0x2f7f4d);if(_0x4b66b0&&!_0x5e1993['isEmpty']()&&_0x5e6eba>=0x0)return _0x4a6f79!=null&&_0x4a6f79['trackChildChange'](Dt(_0x643e2c,_0x5e1993,_0x1fd95e)),_0x12d7e3['updateImmediateChild'](_0x643e2c,_0x5e1993);{_0x4a6f79!=null&&_0x4a6f79['trackChildChange'](Ot(_0x643e2c,_0x1fd95e));const _0x158df8=_0x12d7e3['updateImmediateChild'](_0x643e2c,g['EMPTY_NODE']);return _0x4762a6!=null&&this['rangedFilter_']['matches'](_0x4762a6)?(_0x4a6f79!=null&&_0x4a6f79['trackChildChange'](et(_0x4762a6['name'],_0x4762a6['node'])),_0x158df8['updateImmediateChild'](_0x4762a6['name'],_0x4762a6['node'])):_0x158df8;}}else return _0x5e1993['isEmpty']()?_0x3a9e14:_0x4b66b0&&_0x5897f9(_0x2471dc,_0x2f7f4d)>=0x0?(_0x4a6f79!=null&&(_0x4a6f79['trackChildChange'](Ot(_0x2471dc['name'],_0x2471dc['node'])),_0x4a6f79['trackChildChange'](et(_0x643e2c,_0x5e1993))),_0x12d7e3['updateImmediateChild'](_0x643e2c,_0x5e1993)['updateImmediateChild'](_0x2471dc['name'],g['EMPTY_NODE'])):_0x3a9e14;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x425e69=new Xi();return _0x425e69['limitSet_']=this['limitSet_'],_0x425e69['limit_']=this['limit_'],_0x425e69['startSet_']=this['startSet_'],_0x425e69['startAfterSet_']=this['startAfterSet_'],_0x425e69['indexStartValue_']=this['indexStartValue_'],_0x425e69['startNameSet_']=this['startNameSet_'],_0x425e69['indexStartName_']=this['indexStartName_'],_0x425e69['endSet_']=this['endSet_'],_0x425e69['endBeforeSet_']=this['endBeforeSet_'],_0x425e69['indexEndValue_']=this['indexEndValue_'],_0x425e69['endNameSet_']=this['endNameSet_'],_0x425e69['indexEndName_']=this['indexEndName_'],_0x425e69['index_']=this['index_'],_0x425e69['viewFrom_']=this['viewFrom_'],_0x425e69;}}function Kh(_0x31ba0c){return _0x31ba0c['loadsAllData']()?new Ji(_0x31ba0c['getIndex']()):_0x31ba0c['hasLimit']()?new jh(_0x31ba0c):new Mt(_0x31ba0c);}function Yh(_0x46c2e2,_0x573600){const _0x40096f=_0x46c2e2['copy']();return _0x40096f['limitSet_']=!0x0,_0x40096f['limit_']=_0x573600,_0x40096f['viewFrom_']='l',_0x40096f;}function Qh(_0x205d51,_0x80079,_0x13f6e0){const _0xa1446c=_0x205d51['copy']();return _0xa1446c['startSet_']=!0x0,_0x80079===void 0x0&&(_0x80079=null),_0xa1446c['indexStartValue_']=_0x80079,_0x13f6e0!=null?(_0xa1446c['startNameSet_']=!0x0,_0xa1446c['indexStartName_']=_0x13f6e0):(_0xa1446c['startNameSet_']=!0x1,_0xa1446c['indexStartName_']=''),_0xa1446c;}function Jh(_0x374ce2,_0x5e33ac,_0x5e7802){const _0x419185=_0x374ce2['copy']();return _0x419185['endSet_']=!0x0,_0x5e33ac===void 0x0&&(_0x5e33ac=null),_0x419185['indexEndValue_']=_0x5e33ac,_0x5e7802!==void 0x0?(_0x419185['endNameSet_']=!0x0,_0x419185['indexEndName_']=_0x5e7802):(_0x419185['endNameSet_']=!0x1,_0x419185['indexEndName_']=''),_0x419185;}function xo(_0x3975ea,_0x2acde2){const _0x257334=_0x3975ea['copy']();return _0x257334['index_']=_0x2acde2,_0x257334;}function sr(_0xab9ae9){const _0xb22560={};if(_0xab9ae9['isDefault']())return _0xb22560;let _0x341802;if(_0xab9ae9['index_']===R?_0x341802='$priority':_0xab9ae9['index_']===Mo?_0x341802='$value':_0xab9ae9['index_']===ye?_0x341802='$key':(f(_0xab9ae9['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x341802=_0xab9ae9['index_']['toString']()),_0xb22560['orderBy']=O(_0x341802),_0xab9ae9['startSet_']){const _0x5df169=_0xab9ae9['startAfterSet_']?'startAfter':'startAt';_0xb22560[_0x5df169]=O(_0xab9ae9['indexStartValue_']),_0xab9ae9['startNameSet_']&&(_0xb22560[_0x5df169]+=','+O(_0xab9ae9['indexStartName_']));}if(_0xab9ae9['endSet_']){const _0x217df=_0xab9ae9['endBeforeSet_']?'endBefore':'endAt';_0xb22560[_0x217df]=O(_0xab9ae9['indexEndValue_']),_0xab9ae9['endNameSet_']&&(_0xb22560[_0x217df]+=','+O(_0xab9ae9['indexEndName_']));}return _0xab9ae9['limitSet_']&&(_0xab9ae9['isViewFromLeft']()?_0xb22560['limitToFirst']=_0xab9ae9['limit_']:_0xb22560['limitToLast']=_0xab9ae9['limit_']),_0xb22560;}function rr(_0x3ee63d){const _0x40802f={};if(_0x3ee63d['startSet_']&&(_0x40802f['sp']=_0x3ee63d['indexStartValue_'],_0x3ee63d['startNameSet_']&&(_0x40802f['sn']=_0x3ee63d['indexStartName_']),_0x40802f['sin']=!_0x3ee63d['startAfterSet_']),_0x3ee63d['endSet_']&&(_0x40802f['ep']=_0x3ee63d['indexEndValue_'],_0x3ee63d['endNameSet_']&&(_0x40802f['en']=_0x3ee63d['indexEndName_']),_0x40802f['ein']=!_0x3ee63d['endBeforeSet_']),_0x3ee63d['limitSet_']){_0x40802f['l']=_0x3ee63d['limit_'];let _0x3ce58b=_0x3ee63d['viewFrom_'];_0x3ce58b===''&&(_0x3ee63d['isViewFromLeft']()?_0x3ce58b='l':_0x3ce58b='r'),_0x40802f['vf']=_0x3ce58b;}return _0x3ee63d['index_']!==R&&(_0x40802f['i']=_0x3ee63d['index_']['toString']()),_0x40802f;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x4f8993){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x199514,_0x457ea5){return _0x457ea5!==void 0x0?'tag$'+_0x457ea5:(f(_0x199514['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x199514['_path']['toString']());}constructor(_0x1ebe42,_0x1c4790,_0x1b6658,_0x4358e3){super(),this['repoInfo_']=_0x1ebe42,this['onDataUpdate_']=_0x1c4790,this['authTokenProvider_']=_0x1b6658,this['appCheckTokenProvider_']=_0x4358e3,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x2ba886,_0x3ad011,_0x283a12,_0x1425f5){const _0x10be13=_0x2ba886['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x10be13+'\x20'+_0x2ba886['_queryIdentifier']);const _0x43c8c0=pn['getListenId_'](_0x2ba886,_0x283a12),_0x49e030={};this['listens_'][_0x43c8c0]=_0x49e030;const _0x1db54b=sr(_0x2ba886['_queryParams']);this['restRequest_'](_0x10be13+'.json',_0x1db54b,(_0x1a0d61,_0x114205)=>{let _0xc56984=_0x114205;if(_0x1a0d61===0x194&&(_0xc56984=null,_0x1a0d61=null),_0x1a0d61===null&&this['onDataUpdate_'](_0x10be13,_0xc56984,!0x1,_0x283a12),De(this['listens_'],_0x43c8c0)===_0x49e030){let _0x2768d3;_0x1a0d61?_0x1a0d61===0x191?_0x2768d3='permission_denied':_0x2768d3='rest_error:'+_0x1a0d61:_0x2768d3='ok',_0x1425f5(_0x2768d3,null);}});}['unlisten'](_0x3bcaa7,_0x1a5346){const _0x36473a=pn['getListenId_'](_0x3bcaa7,_0x1a5346);delete this['listens_'][_0x36473a];}['get'](_0x4620ce){const _0x3ec452=sr(_0x4620ce['_queryParams']),_0xec27d1=_0x4620ce['_path']['toString'](),_0x4c7b53=new ot();return this['restRequest_'](_0xec27d1+'.json',_0x3ec452,(_0x54009f,_0x14da03)=>{let _0x13a1f9=_0x14da03;_0x54009f===0x194&&(_0x13a1f9=null,_0x54009f=null),_0x54009f===null?(this['onDataUpdate_'](_0xec27d1,_0x13a1f9,!0x1,null),_0x4c7b53['resolve'](_0x13a1f9)):_0x4c7b53['reject'](new Error(_0x13a1f9));}),_0x4c7b53['promise'];}['refreshAuthToken'](_0x47e133){}['restRequest_'](_0x38fedf,_0x3f5ffd={},_0xaef799){return _0x3f5ffd['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x4ae567,_0x36804a])=>{_0x4ae567&&_0x4ae567['accessToken']&&(_0x3f5ffd['auth']=_0x4ae567['accessToken']),_0x36804a&&_0x36804a['token']&&(_0x3f5ffd['ac']=_0x36804a['token']);const _0x46692c=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x38fedf+'?ns='+this['repoInfo_']['namespace']+ct(_0x3f5ffd);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x46692c);const _0x2c2d34=new XMLHttpRequest();_0x2c2d34['onreadystatechange']=()=>{if(_0xaef799&&_0x2c2d34['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x46692c+'\x20received.\x20status:',_0x2c2d34['status'],'response:',_0x2c2d34['responseText']);let _0x36bb17=null;if(_0x2c2d34['status']>=0xc8&&_0x2c2d34['status']<0x12c){try{_0x36bb17=At(_0x2c2d34['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x46692c+':\x20'+_0x2c2d34['responseText']);}_0xaef799(null,_0x36bb17);}else _0x2c2d34['status']!==0x191&&_0x2c2d34['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x46692c+'\x20Status:\x20'+_0x2c2d34['status']),_0xaef799(_0x2c2d34['status']);_0xaef799=null;}},_0x2c2d34['open']('GET',_0x46692c,!0x0),_0x2c2d34['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x2107e4){return this['rootNode_']['getChild'](_0x2107e4);}['updateSnapshot'](_0x423f11,_0xba76f8){this['rootNode_']=this['rootNode_']['updateChild'](_0x423f11,_0xba76f8);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x30cb28,_0x278b4f,_0x9437db){if(v(_0x278b4f))_0x30cb28['value']=_0x9437db,_0x30cb28['children']['clear']();else{if(_0x30cb28['value']!==null)_0x30cb28['value']=_0x30cb28['value']['updateChild'](_0x278b4f,_0x9437db);else{const _0x32d74e=y(_0x278b4f);_0x30cb28['children']['has'](_0x32d74e)||_0x30cb28['children']['set'](_0x32d74e,_n());const _0x39dc4f=_0x30cb28['children']['get'](_0x32d74e);_0x278b4f=b(_0x278b4f),Fo(_0x39dc4f,_0x278b4f,_0x9437db);}}}function Ii(_0x1c67ce,_0x9ea5c9,_0x27e61d){_0x1c67ce['value']!==null?_0x27e61d(_0x9ea5c9,_0x1c67ce['value']):Zh(_0x1c67ce,(_0x18fd2e,_0x5b30ec)=>{const _0x4de4bf=new C(_0x9ea5c9['toString']()+'/'+_0x18fd2e);Ii(_0x5b30ec,_0x4de4bf,_0x27e61d);});}function Zh(_0x2f5f11,_0x1e1a6f){_0x2f5f11['children']['forEach']((_0x560a49,_0x187740)=>{_0x1e1a6f(_0x187740,_0x560a49);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x3ab08f){this['collection_']=_0x3ab08f,this['last_']=null;}['get'](){const _0x5d97bc=this['collection_']['get'](),_0x448ea0={..._0x5d97bc};return this['last_']&&x(this['last_'],(_0x55fc28,_0x4445d7)=>{_0x448ea0[_0x55fc28]=_0x448ea0[_0x55fc28]-_0x4445d7;}),this['last_']=_0x5d97bc,_0x448ea0;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x3e30e5,_0x39b76d){this['server_']=_0x39b76d,this['statsToReport_']={},this['statsListener_']=new eu(_0x3e30e5);const _0x15ee9a=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x15ee9a));}['reportStats_'](){const _0x5a96e4=this['statsListener_']['get'](),_0x26eba2={};let _0x404d93=!0x1;x(_0x5a96e4,(_0x408981,_0x38f7f9)=>{_0x38f7f9>0x0&&J(this['statsToReport_'],_0x408981)&&(_0x26eba2[_0x408981]=_0x38f7f9,_0x404d93=!0x0);}),_0x404d93&&this['server_']['reportStats'](_0x26eba2),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x5d5aae){_0x5d5aae[_0x5d5aae['OVERWRITE']=0x0]='OVERWRITE',_0x5d5aae[_0x5d5aae['MERGE']=0x1]='MERGE',_0x5d5aae[_0x5d5aae['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x5d5aae[_0x5d5aae['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x4e3517){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x4e3517,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x2c4ec5,_0x4f03c6,_0x4074d2){this['path']=_0x2c4ec5,this['affectedTree']=_0x4f03c6,this['revert']=_0x4074d2,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x2f0bb9){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x84bbd9=this['affectedTree']['subtree'](new C(_0x2f0bb9));return new gn(w(),_0x84bbd9,this['revert']);}}else return f(y(this['path'])===_0x2f0bb9,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x11b053,_0x3e28df){this['source']=_0x11b053,this['path']=_0x3e28df,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x3f7228){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x3f8ca4,_0x1c5f6a,_0x519a52){this['source']=_0x3f8ca4,this['path']=_0x1c5f6a,this['snap']=_0x519a52,this['type']=j['OVERWRITE'];}['operationForChild'](_0x4e3b40){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x4e3b40)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x456379,_0x5bc3d0,_0x51bfa9){this['source']=_0x456379,this['path']=_0x5bc3d0,this['children']=_0x51bfa9,this['type']=j['MERGE'];}['operationForChild'](_0x3980b2){if(v(this['path'])){const _0x28a4c1=this['children']['subtree'](new C(_0x3980b2));return _0x28a4c1['isEmpty']()?null:_0x28a4c1['value']?new Ue(this['source'],w(),_0x28a4c1['value']):new tt(this['source'],w(),_0x28a4c1);}else return f(y(this['path'])===_0x3980b2,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x16614a,_0x3e728b,_0x3b97b7){this['node_']=_0x16614a,this['fullyInitialized_']=_0x3e728b,this['filtered_']=_0x3b97b7;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x214247){if(v(_0x214247))return this['isFullyInitialized']()&&!this['filtered_'];const _0x14eed2=y(_0x214247);return this['isCompleteForChild'](_0x14eed2);}['isCompleteForChild'](_0x1b26c1){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x1b26c1);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x1e3e9c){this['query_']=_0x1e3e9c,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x17b05a,_0x296e38,_0x134fc9,_0x14bf7b){const _0x524ef2=[],_0x2ebf66=[];return _0x296e38['forEach'](_0xb0b929=>{_0xb0b929['type']==='child_changed'&&_0x17b05a['index_']['indexedValueChanged'](_0xb0b929['oldSnap'],_0xb0b929['snapshotNode'])&&_0x2ebf66['push'](zh(_0xb0b929['childName'],_0xb0b929['snapshotNode']));}),yt(_0x17b05a,_0x524ef2,'child_removed',_0x296e38,_0x14bf7b,_0x134fc9),yt(_0x17b05a,_0x524ef2,'child_added',_0x296e38,_0x14bf7b,_0x134fc9),yt(_0x17b05a,_0x524ef2,'child_moved',_0x2ebf66,_0x14bf7b,_0x134fc9),yt(_0x17b05a,_0x524ef2,'child_changed',_0x296e38,_0x14bf7b,_0x134fc9),yt(_0x17b05a,_0x524ef2,'value',_0x296e38,_0x14bf7b,_0x134fc9),_0x524ef2;}function yt(_0x41930b,_0x4590d1,_0x5401da,_0x3a0a6b,_0xf29b33,_0x58c1dd){const _0x419e82=_0x3a0a6b['filter'](_0x30ade4=>_0x30ade4['type']===_0x5401da);_0x419e82['sort']((_0x27481a,_0xe6367c)=>au(_0x41930b,_0x27481a,_0xe6367c)),_0x419e82['forEach'](_0x54d8c8=>{const _0x24587c=ou(_0x41930b,_0x54d8c8,_0x58c1dd);_0xf29b33['forEach'](_0x5e1425=>{_0x5e1425['respondsTo'](_0x54d8c8['type'])&&_0x4590d1['push'](_0x5e1425['createEvent'](_0x24587c,_0x41930b['query_']));});});}function ou(_0x50d9ba,_0x399365,_0x16b724){return _0x399365['type']==='value'||_0x399365['type']==='child_removed'||(_0x399365['prevName']=_0x16b724['getPredecessorChildName'](_0x399365['childName'],_0x399365['snapshotNode'],_0x50d9ba['index_'])),_0x399365;}function au(_0x4cd530,_0x5ba90f,_0x497d11){if(_0x5ba90f['childName']==null||_0x497d11['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x40355e=new E(_0x5ba90f['childName'],_0x5ba90f['snapshotNode']),_0x1ac762=new E(_0x497d11['childName'],_0x497d11['snapshotNode']);return _0x4cd530['index_']['compare'](_0x40355e,_0x1ac762);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x52c884,_0x5e8976){return{'eventCache':_0x52c884,'serverCache':_0x5e8976};}function Tt(_0x2cc64d,_0x3f321,_0x5890ff,_0x1a0498){return Mn(new Ce(_0x3f321,_0x5890ff,_0x1a0498),_0x2cc64d['serverCache']);}function Uo(_0x59c593,_0x4c7697,_0x128dd5,_0x4c9f67){return Mn(_0x59c593['eventCache'],new Ce(_0x4c7697,_0x128dd5,_0x4c9f67));}function mn(_0x33cd80){return _0x33cd80['eventCache']['isFullyInitialized']()?_0x33cd80['eventCache']['getNode']():null;}function We(_0x2dc8ea){return _0x2dc8ea['serverCache']['isFullyInitialized']()?_0x2dc8ea['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x385364){let _0x47090d=new S(null);return x(_0x385364,(_0x37771e,_0x1720fa)=>{_0x47090d=_0x47090d['set'](new C(_0x37771e),_0x1720fa);}),_0x47090d;}constructor(_0x232ac0,_0x1d92a8=cu()){this['value']=_0x232ac0,this['children']=_0x1d92a8;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x48ae29,_0x1bbff4){if(this['value']!=null&&_0x1bbff4(this['value']))return{'path':w(),'value':this['value']};if(v(_0x48ae29))return null;{const _0x30e0f7=y(_0x48ae29),_0x18a7d2=this['children']['get'](_0x30e0f7);if(_0x18a7d2!==null){const _0x55663d=_0x18a7d2['findRootMostMatchingPathAndValue'](b(_0x48ae29),_0x1bbff4);return _0x55663d!=null?{'path':k(new C(_0x30e0f7),_0x55663d['path']),'value':_0x55663d['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x9f1566){return this['findRootMostMatchingPathAndValue'](_0x9f1566,()=>!0x0);}['subtree'](_0x35c6f0){if(v(_0x35c6f0))return this;{const _0x1015a3=y(_0x35c6f0),_0x79607f=this['children']['get'](_0x1015a3);return _0x79607f!==null?_0x79607f['subtree'](b(_0x35c6f0)):new S(null);}}['set'](_0x45430f,_0x38467d){if(v(_0x45430f))return new S(_0x38467d,this['children']);{const _0x3b95c9=y(_0x45430f),_0x290290=(this['children']['get'](_0x3b95c9)||new S(null))['set'](b(_0x45430f),_0x38467d),_0x1434fc=this['children']['insert'](_0x3b95c9,_0x290290);return new S(this['value'],_0x1434fc);}}['remove'](_0x300978){if(v(_0x300978))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x102ff4=y(_0x300978),_0x574dd1=this['children']['get'](_0x102ff4);if(_0x574dd1){const _0x78466b=_0x574dd1['remove'](b(_0x300978));let _0x12e7a6;return _0x78466b['isEmpty']()?_0x12e7a6=this['children']['remove'](_0x102ff4):_0x12e7a6=this['children']['insert'](_0x102ff4,_0x78466b),this['value']===null&&_0x12e7a6['isEmpty']()?new S(null):new S(this['value'],_0x12e7a6);}else return this;}}['get'](_0x3e9fde){if(v(_0x3e9fde))return this['value'];{const _0x1d9e2f=y(_0x3e9fde),_0x355f6c=this['children']['get'](_0x1d9e2f);return _0x355f6c?_0x355f6c['get'](b(_0x3e9fde)):null;}}['setTree'](_0xd47d0f,_0x1176de){if(v(_0xd47d0f))return _0x1176de;{const _0xf3b7f1=y(_0xd47d0f),_0x2cc3f0=(this['children']['get'](_0xf3b7f1)||new S(null))['setTree'](b(_0xd47d0f),_0x1176de);let _0x33f2aa;return _0x2cc3f0['isEmpty']()?_0x33f2aa=this['children']['remove'](_0xf3b7f1):_0x33f2aa=this['children']['insert'](_0xf3b7f1,_0x2cc3f0),new S(this['value'],_0x33f2aa);}}['fold'](_0x42df64){return this['fold_'](w(),_0x42df64);}['fold_'](_0x32083b,_0x1f64af){const _0x2c41c6={};return this['children']['inorderTraversal']((_0x14e1c7,_0x59449e)=>{_0x2c41c6[_0x14e1c7]=_0x59449e['fold_'](k(_0x32083b,_0x14e1c7),_0x1f64af);}),_0x1f64af(_0x32083b,this['value'],_0x2c41c6);}['findOnPath'](_0x3847db,_0x1a1f31){return this['findOnPath_'](_0x3847db,w(),_0x1a1f31);}['findOnPath_'](_0x192fc8,_0x16addd,_0x1b28b7){const _0x58dd05=this['value']?_0x1b28b7(_0x16addd,this['value']):!0x1;if(_0x58dd05)return _0x58dd05;if(v(_0x192fc8))return null;{const _0x16180a=y(_0x192fc8),_0xc91bff=this['children']['get'](_0x16180a);return _0xc91bff?_0xc91bff['findOnPath_'](b(_0x192fc8),k(_0x16addd,_0x16180a),_0x1b28b7):null;}}['foreachOnPath'](_0x3df1b5,_0x748718){return this['foreachOnPath_'](_0x3df1b5,w(),_0x748718);}['foreachOnPath_'](_0x4fcfda,_0x3961cb,_0x13252f){if(v(_0x4fcfda))return this;{this['value']&&_0x13252f(_0x3961cb,this['value']);const _0x360bcd=y(_0x4fcfda),_0x523ed6=this['children']['get'](_0x360bcd);return _0x523ed6?_0x523ed6['foreachOnPath_'](b(_0x4fcfda),k(_0x3961cb,_0x360bcd),_0x13252f):new S(null);}}['foreach'](_0x556c28){this['foreach_'](w(),_0x556c28);}['foreach_'](_0x202a8f,_0x5541c1){this['children']['inorderTraversal']((_0x543ef9,_0x2b6d35)=>{_0x2b6d35['foreach_'](k(_0x202a8f,_0x543ef9),_0x5541c1);}),this['value']&&_0x5541c1(_0x202a8f,this['value']);}['foreachChild'](_0x477d3a){this['children']['inorderTraversal']((_0x58036c,_0x44e408)=>{_0x44e408['value']&&_0x477d3a(_0x58036c,_0x44e408['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x2b78ff){this['writeTree_']=_0x2b78ff;}static['empty'](){return new Y(new S(null));}}function St(_0x4562f7,_0x5e4ee9,_0x472352){if(v(_0x5e4ee9))return new Y(new S(_0x472352));{const _0x54a158=_0x4562f7['writeTree_']['findRootMostValueAndPath'](_0x5e4ee9);if(_0x54a158!=null){const _0x290212=_0x54a158['path'];let _0x2ea6e1=_0x54a158['value'];const _0x46d3f5=F(_0x290212,_0x5e4ee9);return _0x2ea6e1=_0x2ea6e1['updateChild'](_0x46d3f5,_0x472352),new Y(_0x4562f7['writeTree_']['set'](_0x290212,_0x2ea6e1));}else{const _0x575883=new S(_0x472352),_0x3f63b2=_0x4562f7['writeTree_']['setTree'](_0x5e4ee9,_0x575883);return new Y(_0x3f63b2);}}}function wi(_0x245393,_0x2de99f,_0x2f1527){let _0x1997ea=_0x245393;return x(_0x2f1527,(_0x3b4512,_0xe45e1f)=>{_0x1997ea=St(_0x1997ea,k(_0x2de99f,_0x3b4512),_0xe45e1f);}),_0x1997ea;}function ar(_0x2dc179,_0x237136){if(v(_0x237136))return Y['empty']();{const _0x19576a=_0x2dc179['writeTree_']['setTree'](_0x237136,new S(null));return new Y(_0x19576a);}}function Ci(_0x173880,_0xfd6288){return $e(_0x173880,_0xfd6288)!=null;}function $e(_0x5ccb46,_0x9d201a){const _0x1497b1=_0x5ccb46['writeTree_']['findRootMostValueAndPath'](_0x9d201a);return _0x1497b1!=null?_0x5ccb46['writeTree_']['get'](_0x1497b1['path'])['getChild'](F(_0x1497b1['path'],_0x9d201a)):null;}function cr(_0x41f608){const _0x50cd6c=[],_0x217e59=_0x41f608['writeTree_']['value'];return _0x217e59!=null?_0x217e59['isLeafNode']()||_0x217e59['forEachChild'](R,(_0x592c76,_0x3895f9)=>{_0x50cd6c['push'](new E(_0x592c76,_0x3895f9));}):_0x41f608['writeTree_']['children']['inorderTraversal']((_0xd8a5a1,_0x4bce56)=>{_0x4bce56['value']!=null&&_0x50cd6c['push'](new E(_0xd8a5a1,_0x4bce56['value']));}),_0x50cd6c;}function ve(_0x3b8aa9,_0x3b6ef0){if(v(_0x3b6ef0))return _0x3b8aa9;{const _0xfdf11f=$e(_0x3b8aa9,_0x3b6ef0);return _0xfdf11f!=null?new Y(new S(_0xfdf11f)):new Y(_0x3b8aa9['writeTree_']['subtree'](_0x3b6ef0));}}function Ti(_0x5c26c2){return _0x5c26c2['writeTree_']['isEmpty']();}function nt(_0x2d0075,_0x975930){return Wo(w(),_0x2d0075['writeTree_'],_0x975930);}function Wo(_0x15424b,_0x367aa2,_0x3cf698){if(_0x367aa2['value']!=null)return _0x3cf698['updateChild'](_0x15424b,_0x367aa2['value']);{let _0x145b8e=null;return _0x367aa2['children']['inorderTraversal']((_0x3c51c8,_0x13e22d)=>{_0x3c51c8==='.priority'?(f(_0x13e22d['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x145b8e=_0x13e22d['value']):_0x3cf698=Wo(k(_0x15424b,_0x3c51c8),_0x13e22d,_0x3cf698);}),!_0x3cf698['getChild'](_0x15424b)['isEmpty']()&&_0x145b8e!==null&&(_0x3cf698=_0x3cf698['updateChild'](k(_0x15424b,'.priority'),_0x145b8e)),_0x3cf698;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x17c9c7,_0x23b70d){return $o(_0x23b70d,_0x17c9c7);}function lu(_0x356cad,_0xca9c12,_0x432c2a,_0x45ded3,_0x27b088){f(_0x45ded3>_0x356cad['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x27b088===void 0x0&&(_0x27b088=!0x0),_0x356cad['allWrites']['push']({'path':_0xca9c12,'snap':_0x432c2a,'writeId':_0x45ded3,'visible':_0x27b088}),_0x27b088&&(_0x356cad['visibleWrites']=St(_0x356cad['visibleWrites'],_0xca9c12,_0x432c2a)),_0x356cad['lastWriteId']=_0x45ded3;}function hu(_0x25563f,_0x4cd921,_0x280b7b,_0x1d23c3){f(_0x1d23c3>_0x25563f['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x25563f['allWrites']['push']({'path':_0x4cd921,'children':_0x280b7b,'writeId':_0x1d23c3,'visible':!0x0}),_0x25563f['visibleWrites']=wi(_0x25563f['visibleWrites'],_0x4cd921,_0x280b7b),_0x25563f['lastWriteId']=_0x1d23c3;}function uu(_0x3e4a0d,_0x4df453){for(let _0x118169=0x0;_0x118169<_0x3e4a0d['allWrites']['length'];_0x118169++){const _0x2fb195=_0x3e4a0d['allWrites'][_0x118169];if(_0x2fb195['writeId']===_0x4df453)return _0x2fb195;}return null;}function du(_0x4d6615,_0x57dbcc){const _0x2762a5=_0x4d6615['allWrites']['findIndex'](_0x26e4fb=>_0x26e4fb['writeId']===_0x57dbcc);f(_0x2762a5>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x419505=_0x4d6615['allWrites'][_0x2762a5];_0x4d6615['allWrites']['splice'](_0x2762a5,0x1);let _0x50f597=_0x419505['visible'],_0x4b06f2=!0x1,_0x605a73=_0x4d6615['allWrites']['length']-0x1;for(;_0x50f597&&_0x605a73>=0x0;){const _0x14acbd=_0x4d6615['allWrites'][_0x605a73];_0x14acbd['visible']&&(_0x605a73>=_0x2762a5&&fu(_0x14acbd,_0x419505['path'])?_0x50f597=!0x1:G(_0x419505['path'],_0x14acbd['path'])&&(_0x4b06f2=!0x0)),_0x605a73--;}if(_0x50f597){if(_0x4b06f2)return pu(_0x4d6615),!0x0;if(_0x419505['snap'])_0x4d6615['visibleWrites']=ar(_0x4d6615['visibleWrites'],_0x419505['path']);else{const _0x6b1e1e=_0x419505['children'];x(_0x6b1e1e,_0x5154d3=>{_0x4d6615['visibleWrites']=ar(_0x4d6615['visibleWrites'],k(_0x419505['path'],_0x5154d3));});}return!0x0;}else return!0x1;}function fu(_0x1dc847,_0x2c4d01){if(_0x1dc847['snap'])return G(_0x1dc847['path'],_0x2c4d01);for(const _0x5b73ad in _0x1dc847['children'])if(_0x1dc847['children']['hasOwnProperty'](_0x5b73ad)&&G(k(_0x1dc847['path'],_0x5b73ad),_0x2c4d01))return!0x0;return!0x1;}function pu(_0x32e1b7){_0x32e1b7['visibleWrites']=Bo(_0x32e1b7['allWrites'],_u,w()),_0x32e1b7['allWrites']['length']>0x0?_0x32e1b7['lastWriteId']=_0x32e1b7['allWrites'][_0x32e1b7['allWrites']['length']-0x1]['writeId']:_0x32e1b7['lastWriteId']=-0x1;}function _u(_0x562585){return _0x562585['visible'];}function Bo(_0x20b4d5,_0x25e7cb,_0x59b46c){let _0x5cf2ed=Y['empty']();for(let _0x266dc1=0x0;_0x266dc1<_0x20b4d5['length'];++_0x266dc1){const _0x5fa090=_0x20b4d5[_0x266dc1];if(_0x25e7cb(_0x5fa090)){const _0x21219a=_0x5fa090['path'];let _0x2599fe;if(_0x5fa090['snap'])G(_0x59b46c,_0x21219a)?(_0x2599fe=F(_0x59b46c,_0x21219a),_0x5cf2ed=St(_0x5cf2ed,_0x2599fe,_0x5fa090['snap'])):G(_0x21219a,_0x59b46c)&&(_0x2599fe=F(_0x21219a,_0x59b46c),_0x5cf2ed=St(_0x5cf2ed,w(),_0x5fa090['snap']['getChild'](_0x2599fe)));else{if(_0x5fa090['children']){if(G(_0x59b46c,_0x21219a))_0x2599fe=F(_0x59b46c,_0x21219a),_0x5cf2ed=wi(_0x5cf2ed,_0x2599fe,_0x5fa090['children']);else{if(G(_0x21219a,_0x59b46c)){if(_0x2599fe=F(_0x21219a,_0x59b46c),v(_0x2599fe))_0x5cf2ed=wi(_0x5cf2ed,w(),_0x5fa090['children']);else{const _0x21274c=De(_0x5fa090['children'],y(_0x2599fe));if(_0x21274c){const _0x5c0389=_0x21274c['getChild'](b(_0x2599fe));_0x5cf2ed=St(_0x5cf2ed,w(),_0x5c0389);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x5cf2ed;}function Vo(_0x42b62c,_0x291470,_0x3200a5,_0x206db8,_0x317cd8){if(!_0x206db8&&!_0x317cd8){const _0x188bae=$e(_0x42b62c['visibleWrites'],_0x291470);if(_0x188bae!=null)return _0x188bae;{const _0x272846=ve(_0x42b62c['visibleWrites'],_0x291470);if(Ti(_0x272846))return _0x3200a5;if(_0x3200a5==null&&!Ci(_0x272846,w()))return null;{const _0xc89a1b=_0x3200a5||g['EMPTY_NODE'];return nt(_0x272846,_0xc89a1b);}}}else{const _0x15fc0=ve(_0x42b62c['visibleWrites'],_0x291470);if(!_0x317cd8&&Ti(_0x15fc0))return _0x3200a5;if(!_0x317cd8&&_0x3200a5==null&&!Ci(_0x15fc0,w()))return null;{const _0x2455e4=function(_0x16b391){return(_0x16b391['visible']||_0x317cd8)&&(!_0x206db8||!~_0x206db8['indexOf'](_0x16b391['writeId']))&&(G(_0x16b391['path'],_0x291470)||G(_0x291470,_0x16b391['path']));},_0x52793f=Bo(_0x42b62c['allWrites'],_0x2455e4,_0x291470),_0x1f1f8b=_0x3200a5||g['EMPTY_NODE'];return nt(_0x52793f,_0x1f1f8b);}}}function gu(_0x1d8f37,_0x55ffda,_0x2dcfab){let _0x55ef06=g['EMPTY_NODE'];const _0x2b11c9=$e(_0x1d8f37['visibleWrites'],_0x55ffda);if(_0x2b11c9)return _0x2b11c9['isLeafNode']()||_0x2b11c9['forEachChild'](R,(_0x2e1fdd,_0x3501fe)=>{_0x55ef06=_0x55ef06['updateImmediateChild'](_0x2e1fdd,_0x3501fe);}),_0x55ef06;if(_0x2dcfab){const _0x46dbbb=ve(_0x1d8f37['visibleWrites'],_0x55ffda);return _0x2dcfab['forEachChild'](R,(_0x2e1472,_0x46153a)=>{const _0x57c3cb=nt(ve(_0x46dbbb,new C(_0x2e1472)),_0x46153a);_0x55ef06=_0x55ef06['updateImmediateChild'](_0x2e1472,_0x57c3cb);}),cr(_0x46dbbb)['forEach'](_0x575bc2=>{_0x55ef06=_0x55ef06['updateImmediateChild'](_0x575bc2['name'],_0x575bc2['node']);}),_0x55ef06;}else{const _0x3830ef=ve(_0x1d8f37['visibleWrites'],_0x55ffda);return cr(_0x3830ef)['forEach'](_0x414128=>{_0x55ef06=_0x55ef06['updateImmediateChild'](_0x414128['name'],_0x414128['node']);}),_0x55ef06;}}function mu(_0x22614d,_0x3eb8da,_0x16860d,_0x393128,_0x26151f){f(_0x393128||_0x26151f,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x4a302b=k(_0x3eb8da,_0x16860d);if(Ci(_0x22614d['visibleWrites'],_0x4a302b))return null;{const _0x1de133=ve(_0x22614d['visibleWrites'],_0x4a302b);return Ti(_0x1de133)?_0x26151f['getChild'](_0x16860d):nt(_0x1de133,_0x26151f['getChild'](_0x16860d));}}function yu(_0x581ec2,_0x5e1f20,_0x539d31,_0x9dd6cc){const _0x584380=k(_0x5e1f20,_0x539d31),_0x236b80=$e(_0x581ec2['visibleWrites'],_0x584380);if(_0x236b80!=null)return _0x236b80;if(_0x9dd6cc['isCompleteForChild'](_0x539d31)){const _0x5165c3=ve(_0x581ec2['visibleWrites'],_0x584380);return nt(_0x5165c3,_0x9dd6cc['getNode']()['getImmediateChild'](_0x539d31));}else return null;}function vu(_0x3b2692,_0x4e91bb){return $e(_0x3b2692['visibleWrites'],_0x4e91bb);}function Eu(_0x5d9ff6,_0x55002a,_0x283718,_0xbac170,_0x17bd35,_0x3c75af,_0x6b0a10){let _0x29f604;const _0x2251a0=ve(_0x5d9ff6['visibleWrites'],_0x55002a),_0x1a1c80=$e(_0x2251a0,w());if(_0x1a1c80!=null)_0x29f604=_0x1a1c80;else{if(_0x283718!=null)_0x29f604=nt(_0x2251a0,_0x283718);else return[];}if(_0x29f604=_0x29f604['withIndex'](_0x6b0a10),!_0x29f604['isEmpty']()&&!_0x29f604['isLeafNode']()){const _0x13db2d=[],_0x4d9ef7=_0x6b0a10['getCompare'](),_0x32061=_0x3c75af?_0x29f604['getReverseIteratorFrom'](_0xbac170,_0x6b0a10):_0x29f604['getIteratorFrom'](_0xbac170,_0x6b0a10);let _0x2422f7=_0x32061['getNext']();for(;_0x2422f7&&_0x13db2d['length']<_0x17bd35;)_0x4d9ef7(_0x2422f7,_0xbac170)!==0x0&&_0x13db2d['push'](_0x2422f7),_0x2422f7=_0x32061['getNext']();return _0x13db2d;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x5df026,_0x3d7f36,_0x1489d7,_0x406f2b){return Vo(_0x5df026['writeTree'],_0x5df026['treePath'],_0x3d7f36,_0x1489d7,_0x406f2b);}function ns(_0x89593d,_0x257ab3){return gu(_0x89593d['writeTree'],_0x89593d['treePath'],_0x257ab3);}function lr(_0x6873df,_0x3913a3,_0x36fa44,_0x573d8a){return mu(_0x6873df['writeTree'],_0x6873df['treePath'],_0x3913a3,_0x36fa44,_0x573d8a);}function vn(_0x31e9c3,_0x414062){return vu(_0x31e9c3['writeTree'],k(_0x31e9c3['treePath'],_0x414062));}function wu(_0x58b2a4,_0x5a5213,_0x30f0fc,_0x339b78,_0x688c27,_0x21fe49){return Eu(_0x58b2a4['writeTree'],_0x58b2a4['treePath'],_0x5a5213,_0x30f0fc,_0x339b78,_0x688c27,_0x21fe49);}function is(_0xb0db4e,_0x448772,_0x13cba3){return yu(_0xb0db4e['writeTree'],_0xb0db4e['treePath'],_0x448772,_0x13cba3);}function Ho(_0x25e46c,_0x439371){return $o(k(_0x25e46c['treePath'],_0x439371),_0x25e46c['writeTree']);}function $o(_0x197c39,_0x319128){return{'treePath':_0x197c39,'writeTree':_0x319128};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0xb9f68e){const _0x153b96=_0xb9f68e['type'],_0x5ae9e9=_0xb9f68e['childName'];f(_0x153b96==='child_added'||_0x153b96==='child_changed'||_0x153b96==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x5ae9e9!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x479a54=this['changeMap']['get'](_0x5ae9e9);if(_0x479a54){const _0xdff2c1=_0x479a54['type'];if(_0x153b96==='child_added'&&_0xdff2c1==='child_removed')this['changeMap']['set'](_0x5ae9e9,Dt(_0x5ae9e9,_0xb9f68e['snapshotNode'],_0x479a54['snapshotNode']));else{if(_0x153b96==='child_removed'&&_0xdff2c1==='child_added')this['changeMap']['delete'](_0x5ae9e9);else{if(_0x153b96==='child_removed'&&_0xdff2c1==='child_changed')this['changeMap']['set'](_0x5ae9e9,Ot(_0x5ae9e9,_0x479a54['oldSnap']));else{if(_0x153b96==='child_changed'&&_0xdff2c1==='child_added')this['changeMap']['set'](_0x5ae9e9,et(_0x5ae9e9,_0xb9f68e['snapshotNode']));else{if(_0x153b96==='child_changed'&&_0xdff2c1==='child_changed')this['changeMap']['set'](_0x5ae9e9,Dt(_0x5ae9e9,_0xb9f68e['snapshotNode'],_0x479a54['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0xb9f68e+'\x20occurred\x20after\x20'+_0x479a54);}}}}}else this['changeMap']['set'](_0x5ae9e9,_0xb9f68e);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x72952){return null;}['getChildAfterChild'](_0x4f2735,_0x28cae3,_0x48a035){return null;}}const Go=new Tu();class ss{constructor(_0x5af0e6,_0x54abdd,_0x9a1966=null){this['writes_']=_0x5af0e6,this['viewCache_']=_0x54abdd,this['optCompleteServerCache_']=_0x9a1966;}['getCompleteChild'](_0x2442b5){const _0x1da934=this['viewCache_']['eventCache'];if(_0x1da934['isCompleteForChild'](_0x2442b5))return _0x1da934['getNode']()['getImmediateChild'](_0x2442b5);{const _0x21cb7e=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x2442b5,_0x21cb7e);}}['getChildAfterChild'](_0x25dc4b,_0x3606f6,_0x2cdf8d){const _0x32c8fe=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x25e0bd=wu(this['writes_'],_0x32c8fe,_0x3606f6,0x1,_0x2cdf8d,_0x25dc4b);return _0x25e0bd['length']===0x0?null:_0x25e0bd[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x4e3478){return{'filter':_0x4e3478};}function bu(_0x45617f,_0x2a44f0){f(_0x2a44f0['eventCache']['getNode']()['isIndexed'](_0x45617f['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x2a44f0['serverCache']['getNode']()['isIndexed'](_0x45617f['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x1af452,_0x1b0fbf,_0x55f457,_0x259c37,_0x53ab00){const _0x3c9fbb=new Cu();let _0xddd36d,_0x6a6c91;if(_0x55f457['type']===j['OVERWRITE']){const _0x53c97c=_0x55f457;_0x53c97c['source']['fromUser']?_0xddd36d=Si(_0x1af452,_0x1b0fbf,_0x53c97c['path'],_0x53c97c['snap'],_0x259c37,_0x53ab00,_0x3c9fbb):(f(_0x53c97c['source']['fromServer'],'Unknown\x20source.'),_0x6a6c91=_0x53c97c['source']['tagged']||_0x1b0fbf['serverCache']['isFiltered']()&&!v(_0x53c97c['path']),_0xddd36d=En(_0x1af452,_0x1b0fbf,_0x53c97c['path'],_0x53c97c['snap'],_0x259c37,_0x53ab00,_0x6a6c91,_0x3c9fbb));}else{if(_0x55f457['type']===j['MERGE']){const _0x1e6184=_0x55f457;_0x1e6184['source']['fromUser']?_0xddd36d=ku(_0x1af452,_0x1b0fbf,_0x1e6184['path'],_0x1e6184['children'],_0x259c37,_0x53ab00,_0x3c9fbb):(f(_0x1e6184['source']['fromServer'],'Unknown\x20source.'),_0x6a6c91=_0x1e6184['source']['tagged']||_0x1b0fbf['serverCache']['isFiltered'](),_0xddd36d=bi(_0x1af452,_0x1b0fbf,_0x1e6184['path'],_0x1e6184['children'],_0x259c37,_0x53ab00,_0x6a6c91,_0x3c9fbb));}else{if(_0x55f457['type']===j['ACK_USER_WRITE']){const _0x2d2367=_0x55f457;_0x2d2367['revert']?_0xddd36d=Ou(_0x1af452,_0x1b0fbf,_0x2d2367['path'],_0x259c37,_0x53ab00,_0x3c9fbb):_0xddd36d=Nu(_0x1af452,_0x1b0fbf,_0x2d2367['path'],_0x2d2367['affectedTree'],_0x259c37,_0x53ab00,_0x3c9fbb);}else{if(_0x55f457['type']===j['LISTEN_COMPLETE'])_0xddd36d=Pu(_0x1af452,_0x1b0fbf,_0x55f457['path'],_0x259c37,_0x3c9fbb);else throw rt('Unknown\x20operation\x20type:\x20'+_0x55f457['type']);}}}const _0x19be48=_0x3c9fbb['getChanges']();return Au(_0x1b0fbf,_0xddd36d,_0x19be48),{'viewCache':_0xddd36d,'changes':_0x19be48};}function Au(_0x40be47,_0x4ee2f7,_0x1535c1){const _0x3e0dcf=_0x4ee2f7['eventCache'];if(_0x3e0dcf['isFullyInitialized']()){const _0x1135aa=_0x3e0dcf['getNode']()['isLeafNode']()||_0x3e0dcf['getNode']()['isEmpty'](),_0x52b5d8=mn(_0x40be47);(_0x1535c1['length']>0x0||!_0x40be47['eventCache']['isFullyInitialized']()||_0x1135aa&&!_0x3e0dcf['getNode']()['equals'](_0x52b5d8)||!_0x3e0dcf['getNode']()['getPriority']()['equals'](_0x52b5d8['getPriority']()))&&_0x1535c1['push'](Lo(mn(_0x4ee2f7)));}}function qo(_0x840945,_0x3052ff,_0x2da201,_0x139c57,_0x164ef2,_0x3758e8){const _0xf1c38=_0x3052ff['eventCache'];if(vn(_0x139c57,_0x2da201)!=null)return _0x3052ff;{let _0x2101a2,_0x243313;if(v(_0x2da201)){if(f(_0x3052ff['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x3052ff['serverCache']['isFiltered']()){const _0x50bd0d=We(_0x3052ff),_0x3ea2f=_0x50bd0d instanceof g?_0x50bd0d:g['EMPTY_NODE'],_0x66a127=ns(_0x139c57,_0x3ea2f);_0x2101a2=_0x840945['filter']['updateFullNode'](_0x3052ff['eventCache']['getNode'](),_0x66a127,_0x3758e8);}else{const _0x4e5eb9=yn(_0x139c57,We(_0x3052ff));_0x2101a2=_0x840945['filter']['updateFullNode'](_0x3052ff['eventCache']['getNode'](),_0x4e5eb9,_0x3758e8);}}else{const _0x2ff3a8=y(_0x2da201);if(_0x2ff3a8==='.priority'){f(we(_0x2da201)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x74801e=_0xf1c38['getNode']();_0x243313=_0x3052ff['serverCache']['getNode']();const _0x4bc410=lr(_0x139c57,_0x2da201,_0x74801e,_0x243313);_0x4bc410!=null?_0x2101a2=_0x840945['filter']['updatePriority'](_0x74801e,_0x4bc410):_0x2101a2=_0xf1c38['getNode']();}else{const _0xb6530=b(_0x2da201);let _0x15e27c;if(_0xf1c38['isCompleteForChild'](_0x2ff3a8)){_0x243313=_0x3052ff['serverCache']['getNode']();const _0x148737=lr(_0x139c57,_0x2da201,_0xf1c38['getNode'](),_0x243313);_0x148737!=null?_0x15e27c=_0xf1c38['getNode']()['getImmediateChild'](_0x2ff3a8)['updateChild'](_0xb6530,_0x148737):_0x15e27c=_0xf1c38['getNode']()['getImmediateChild'](_0x2ff3a8);}else _0x15e27c=is(_0x139c57,_0x2ff3a8,_0x3052ff['serverCache']);_0x15e27c!=null?_0x2101a2=_0x840945['filter']['updateChild'](_0xf1c38['getNode'](),_0x2ff3a8,_0x15e27c,_0xb6530,_0x164ef2,_0x3758e8):_0x2101a2=_0xf1c38['getNode']();}}return Tt(_0x3052ff,_0x2101a2,_0xf1c38['isFullyInitialized']()||v(_0x2da201),_0x840945['filter']['filtersNodes']());}}function En(_0x308b03,_0x5d1b20,_0x32a5b9,_0x394a58,_0x147d83,_0x224799,_0x4ce36d,_0x3f3d6e){const _0x43e8dc=_0x5d1b20['serverCache'];let _0xef7dd7;const _0x482d3c=_0x4ce36d?_0x308b03['filter']:_0x308b03['filter']['getIndexedFilter']();if(v(_0x32a5b9))_0xef7dd7=_0x482d3c['updateFullNode'](_0x43e8dc['getNode'](),_0x394a58,null);else{if(_0x482d3c['filtersNodes']()&&!_0x43e8dc['isFiltered']()){const _0x3d92ab=_0x43e8dc['getNode']()['updateChild'](_0x32a5b9,_0x394a58);_0xef7dd7=_0x482d3c['updateFullNode'](_0x43e8dc['getNode'](),_0x3d92ab,null);}else{const _0xa19cfc=y(_0x32a5b9);if(!_0x43e8dc['isCompleteForPath'](_0x32a5b9)&&we(_0x32a5b9)>0x1)return _0x5d1b20;const _0x380e39=b(_0x32a5b9),_0x1be879=_0x43e8dc['getNode']()['getImmediateChild'](_0xa19cfc)['updateChild'](_0x380e39,_0x394a58);_0xa19cfc==='.priority'?_0xef7dd7=_0x482d3c['updatePriority'](_0x43e8dc['getNode'](),_0x1be879):_0xef7dd7=_0x482d3c['updateChild'](_0x43e8dc['getNode'](),_0xa19cfc,_0x1be879,_0x380e39,Go,null);}}const _0x2502af=Uo(_0x5d1b20,_0xef7dd7,_0x43e8dc['isFullyInitialized']()||v(_0x32a5b9),_0x482d3c['filtersNodes']()),_0x11ebf4=new ss(_0x147d83,_0x2502af,_0x224799);return qo(_0x308b03,_0x2502af,_0x32a5b9,_0x147d83,_0x11ebf4,_0x3f3d6e);}function Si(_0x5d42dc,_0x1a63d2,_0x5621fa,_0x3f784d,_0x4ddefb,_0x36c79c,_0x491fc6){const _0x2fe257=_0x1a63d2['eventCache'];let _0x3b91b6,_0x427b9a;const _0x198bf0=new ss(_0x4ddefb,_0x1a63d2,_0x36c79c);if(v(_0x5621fa))_0x427b9a=_0x5d42dc['filter']['updateFullNode'](_0x1a63d2['eventCache']['getNode'](),_0x3f784d,_0x491fc6),_0x3b91b6=Tt(_0x1a63d2,_0x427b9a,!0x0,_0x5d42dc['filter']['filtersNodes']());else{const _0x3e9929=y(_0x5621fa);if(_0x3e9929==='.priority')_0x427b9a=_0x5d42dc['filter']['updatePriority'](_0x1a63d2['eventCache']['getNode'](),_0x3f784d),_0x3b91b6=Tt(_0x1a63d2,_0x427b9a,_0x2fe257['isFullyInitialized'](),_0x2fe257['isFiltered']());else{const _0x2bd301=b(_0x5621fa),_0x4162ab=_0x2fe257['getNode']()['getImmediateChild'](_0x3e9929);let _0x4a2943;if(v(_0x2bd301))_0x4a2943=_0x3f784d;else{const _0x19e243=_0x198bf0['getCompleteChild'](_0x3e9929);_0x19e243!=null?zi(_0x2bd301)==='.priority'&&_0x19e243['getChild'](Ro(_0x2bd301))['isEmpty']()?_0x4a2943=_0x19e243:_0x4a2943=_0x19e243['updateChild'](_0x2bd301,_0x3f784d):_0x4a2943=g['EMPTY_NODE'];}if(_0x4162ab['equals'](_0x4a2943))_0x3b91b6=_0x1a63d2;else{const _0x576602=_0x5d42dc['filter']['updateChild'](_0x2fe257['getNode'](),_0x3e9929,_0x4a2943,_0x2bd301,_0x198bf0,_0x491fc6);_0x3b91b6=Tt(_0x1a63d2,_0x576602,_0x2fe257['isFullyInitialized'](),_0x5d42dc['filter']['filtersNodes']());}}}return _0x3b91b6;}function hr(_0x1ad1c4,_0x561d1e){return _0x1ad1c4['eventCache']['isCompleteForChild'](_0x561d1e);}function ku(_0xa7da8,_0x5adf5d,_0x4ed745,_0x4e590f,_0x5e7d5a,_0x2cd558,_0x2d0abd){let _0x505d42=_0x5adf5d;return _0x4e590f['foreach']((_0x4ee851,_0x4a6be3)=>{const _0x1b8484=k(_0x4ed745,_0x4ee851);hr(_0x5adf5d,y(_0x1b8484))&&(_0x505d42=Si(_0xa7da8,_0x505d42,_0x1b8484,_0x4a6be3,_0x5e7d5a,_0x2cd558,_0x2d0abd));}),_0x4e590f['foreach']((_0x1f2660,_0x3bc0f2)=>{const _0x4ddf82=k(_0x4ed745,_0x1f2660);hr(_0x5adf5d,y(_0x4ddf82))||(_0x505d42=Si(_0xa7da8,_0x505d42,_0x4ddf82,_0x3bc0f2,_0x5e7d5a,_0x2cd558,_0x2d0abd));}),_0x505d42;}function ur(_0x277273,_0x434d72,_0x509c8b){return _0x509c8b['foreach']((_0x5bc46a,_0x21b6c6)=>{_0x434d72=_0x434d72['updateChild'](_0x5bc46a,_0x21b6c6);}),_0x434d72;}function bi(_0x51b64,_0x1d6172,_0x12da32,_0x19852f,_0xa1022b,_0x44f27b,_0x2d8adb,_0x5620ad){if(_0x1d6172['serverCache']['getNode']()['isEmpty']()&&!_0x1d6172['serverCache']['isFullyInitialized']())return _0x1d6172;let _0x56d544=_0x1d6172,_0x220374;v(_0x12da32)?_0x220374=_0x19852f:_0x220374=new S(null)['setTree'](_0x12da32,_0x19852f);const _0x5e1a44=_0x1d6172['serverCache']['getNode']();return _0x220374['children']['inorderTraversal']((_0x4f1f4d,_0x3dfe81)=>{if(_0x5e1a44['hasChild'](_0x4f1f4d)){const _0x2f9324=_0x1d6172['serverCache']['getNode']()['getImmediateChild'](_0x4f1f4d),_0x216623=ur(_0x51b64,_0x2f9324,_0x3dfe81);_0x56d544=En(_0x51b64,_0x56d544,new C(_0x4f1f4d),_0x216623,_0xa1022b,_0x44f27b,_0x2d8adb,_0x5620ad);}}),_0x220374['children']['inorderTraversal']((_0x633acc,_0x17c58c)=>{const _0x3bb6f5=!_0x1d6172['serverCache']['isCompleteForChild'](_0x633acc)&&_0x17c58c['value']===null;if(!_0x5e1a44['hasChild'](_0x633acc)&&!_0x3bb6f5){const _0x449eb3=_0x1d6172['serverCache']['getNode']()['getImmediateChild'](_0x633acc),_0xfd1a94=ur(_0x51b64,_0x449eb3,_0x17c58c);_0x56d544=En(_0x51b64,_0x56d544,new C(_0x633acc),_0xfd1a94,_0xa1022b,_0x44f27b,_0x2d8adb,_0x5620ad);}}),_0x56d544;}function Nu(_0x119243,_0x5ed4eb,_0x1e7060,_0x1e4ad8,_0x35dfd8,_0x50a43d,_0x227e4f){if(vn(_0x35dfd8,_0x1e7060)!=null)return _0x5ed4eb;const _0x47b733=_0x5ed4eb['serverCache']['isFiltered'](),_0x14666d=_0x5ed4eb['serverCache'];if(_0x1e4ad8['value']!=null){if(v(_0x1e7060)&&_0x14666d['isFullyInitialized']()||_0x14666d['isCompleteForPath'](_0x1e7060))return En(_0x119243,_0x5ed4eb,_0x1e7060,_0x14666d['getNode']()['getChild'](_0x1e7060),_0x35dfd8,_0x50a43d,_0x47b733,_0x227e4f);if(v(_0x1e7060)){let _0x2d0097=new S(null);return _0x14666d['getNode']()['forEachChild'](ye,(_0x44a14b,_0x1fbab8)=>{_0x2d0097=_0x2d0097['set'](new C(_0x44a14b),_0x1fbab8);}),bi(_0x119243,_0x5ed4eb,_0x1e7060,_0x2d0097,_0x35dfd8,_0x50a43d,_0x47b733,_0x227e4f);}else return _0x5ed4eb;}else{let _0xf8017f=new S(null);return _0x1e4ad8['foreach']((_0x27f34e,_0x2e9baa)=>{const _0x37c78a=k(_0x1e7060,_0x27f34e);_0x14666d['isCompleteForPath'](_0x37c78a)&&(_0xf8017f=_0xf8017f['set'](_0x27f34e,_0x14666d['getNode']()['getChild'](_0x37c78a)));}),bi(_0x119243,_0x5ed4eb,_0x1e7060,_0xf8017f,_0x35dfd8,_0x50a43d,_0x47b733,_0x227e4f);}}function Pu(_0x388504,_0xe981b4,_0x14d183,_0x1c3d91,_0x80e09f){const _0x4aabbb=_0xe981b4['serverCache'],_0x2ef734=Uo(_0xe981b4,_0x4aabbb['getNode'](),_0x4aabbb['isFullyInitialized']()||v(_0x14d183),_0x4aabbb['isFiltered']());return qo(_0x388504,_0x2ef734,_0x14d183,_0x1c3d91,Go,_0x80e09f);}function Ou(_0x3c4380,_0xae66c0,_0x440c5c,_0x5c23a6,_0x217ed0,_0x5dbe33){let _0x275f07;if(vn(_0x5c23a6,_0x440c5c)!=null)return _0xae66c0;{const _0x296af3=new ss(_0x5c23a6,_0xae66c0,_0x217ed0),_0x2027e4=_0xae66c0['eventCache']['getNode']();let _0x2fe58f;if(v(_0x440c5c)||y(_0x440c5c)==='.priority'){let _0x48f46e;if(_0xae66c0['serverCache']['isFullyInitialized']())_0x48f46e=yn(_0x5c23a6,We(_0xae66c0));else{const _0x1bbb07=_0xae66c0['serverCache']['getNode']();f(_0x1bbb07 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x48f46e=ns(_0x5c23a6,_0x1bbb07);}_0x48f46e=_0x48f46e,_0x2fe58f=_0x3c4380['filter']['updateFullNode'](_0x2027e4,_0x48f46e,_0x5dbe33);}else{const _0x19ae4e=y(_0x440c5c);let _0x2efce3=is(_0x5c23a6,_0x19ae4e,_0xae66c0['serverCache']);_0x2efce3==null&&_0xae66c0['serverCache']['isCompleteForChild'](_0x19ae4e)&&(_0x2efce3=_0x2027e4['getImmediateChild'](_0x19ae4e)),_0x2efce3!=null?_0x2fe58f=_0x3c4380['filter']['updateChild'](_0x2027e4,_0x19ae4e,_0x2efce3,b(_0x440c5c),_0x296af3,_0x5dbe33):_0xae66c0['eventCache']['getNode']()['hasChild'](_0x19ae4e)?_0x2fe58f=_0x3c4380['filter']['updateChild'](_0x2027e4,_0x19ae4e,g['EMPTY_NODE'],b(_0x440c5c),_0x296af3,_0x5dbe33):_0x2fe58f=_0x2027e4,_0x2fe58f['isEmpty']()&&_0xae66c0['serverCache']['isFullyInitialized']()&&(_0x275f07=yn(_0x5c23a6,We(_0xae66c0)),_0x275f07['isLeafNode']()&&(_0x2fe58f=_0x3c4380['filter']['updateFullNode'](_0x2fe58f,_0x275f07,_0x5dbe33)));}return _0x275f07=_0xae66c0['serverCache']['isFullyInitialized']()||vn(_0x5c23a6,w())!=null,Tt(_0xae66c0,_0x2fe58f,_0x275f07,_0x3c4380['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x142ead,_0x44d588){this['query_']=_0x142ead,this['eventRegistrations_']=[];const _0x5b59d8=this['query_']['_queryParams'],_0x4e758d=new Ji(_0x5b59d8['getIndex']()),_0x2e6860=Kh(_0x5b59d8);this['processor_']=Su(_0x2e6860);const _0x482cab=_0x44d588['serverCache'],_0x3626ce=_0x44d588['eventCache'],_0x1b1211=_0x4e758d['updateFullNode'](g['EMPTY_NODE'],_0x482cab['getNode'](),null),_0x1f9a6e=_0x2e6860['updateFullNode'](g['EMPTY_NODE'],_0x3626ce['getNode'](),null),_0x3d9d90=new Ce(_0x1b1211,_0x482cab['isFullyInitialized'](),_0x4e758d['filtersNodes']()),_0x26e2ae=new Ce(_0x1f9a6e,_0x3626ce['isFullyInitialized'](),_0x2e6860['filtersNodes']());this['viewCache_']=Mn(_0x26e2ae,_0x3d9d90),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x5a0525){return _0x5a0525['viewCache_']['serverCache']['getNode']();}function Lu(_0x5165e){return mn(_0x5165e['viewCache_']);}function xu(_0x54ac15,_0x1af897){const _0x20e414=We(_0x54ac15['viewCache_']);return _0x20e414&&(_0x54ac15['query']['_queryParams']['loadsAllData']()||!v(_0x1af897)&&!_0x20e414['getImmediateChild'](y(_0x1af897))['isEmpty']())?_0x20e414['getChild'](_0x1af897):null;}function dr(_0x1e6f3a){return _0x1e6f3a['eventRegistrations_']['length']===0x0;}function Fu(_0x145b13,_0x2d8f6f){_0x145b13['eventRegistrations_']['push'](_0x2d8f6f);}function fr(_0x314744,_0xcd009e,_0x2aa5b5){const _0x59e3b3=[];if(_0x2aa5b5){f(_0xcd009e==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x2413c0=_0x314744['query']['_path'];_0x314744['eventRegistrations_']['forEach'](_0x527607=>{const _0x4ea8e7=_0x527607['createCancelEvent'](_0x2aa5b5,_0x2413c0);_0x4ea8e7&&_0x59e3b3['push'](_0x4ea8e7);});}if(_0xcd009e){let _0x3adaae=[];for(let _0xdd460a=0x0;_0xdd460a<_0x314744['eventRegistrations_']['length'];++_0xdd460a){const _0x5852e7=_0x314744['eventRegistrations_'][_0xdd460a];if(!_0x5852e7['matches'](_0xcd009e))_0x3adaae['push'](_0x5852e7);else{if(_0xcd009e['hasAnyCallback']()){_0x3adaae=_0x3adaae['concat'](_0x314744['eventRegistrations_']['slice'](_0xdd460a+0x1));break;}}}_0x314744['eventRegistrations_']=_0x3adaae;}else _0x314744['eventRegistrations_']=[];return _0x59e3b3;}function pr(_0x5efc1c,_0x3d68f6,_0x46ac77,_0x1a2b9c){_0x3d68f6['type']===j['MERGE']&&_0x3d68f6['source']['queryId']!==null&&(f(We(_0x5efc1c['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x5efc1c['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x473b92=_0x5efc1c['viewCache_'],_0x2aceb1=Ru(_0x5efc1c['processor_'],_0x473b92,_0x3d68f6,_0x46ac77,_0x1a2b9c);return bu(_0x5efc1c['processor_'],_0x2aceb1['viewCache']),f(_0x2aceb1['viewCache']['serverCache']['isFullyInitialized']()||!_0x473b92['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x5efc1c['viewCache_']=_0x2aceb1['viewCache'],zo(_0x5efc1c,_0x2aceb1['changes'],_0x2aceb1['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x5a826d,_0x15be0a){const _0x4043e5=_0x5a826d['viewCache_']['eventCache'],_0x5adc38=[];return _0x4043e5['getNode']()['isLeafNode']()||_0x4043e5['getNode']()['forEachChild'](R,(_0x2ac673,_0x3e865b)=>{_0x5adc38['push'](et(_0x2ac673,_0x3e865b));}),_0x4043e5['isFullyInitialized']()&&_0x5adc38['push'](Lo(_0x4043e5['getNode']())),zo(_0x5a826d,_0x5adc38,_0x4043e5['getNode'](),_0x15be0a);}function zo(_0x137337,_0x5ad195,_0x1da519,_0x173679){const _0x7fdf1e=_0x173679?[_0x173679]:_0x137337['eventRegistrations_'];return ru(_0x137337['eventGenerator_'],_0x5ad195,_0x1da519,_0x7fdf1e);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x1a0ab0){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x1a0ab0;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0xc02549){return _0xc02549['views']['size']===0x0;}function rs(_0x391962,_0xe933a1,_0x2af7fa,_0x4c04f9){const _0x931d52=_0xe933a1['source']['queryId'];if(_0x931d52!==null){const _0x3dab98=_0x391962['views']['get'](_0x931d52);return f(_0x3dab98!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x3dab98,_0xe933a1,_0x2af7fa,_0x4c04f9);}else{let _0x67a661=[];for(const _0x4c2c21 of _0x391962['views']['values']())_0x67a661=_0x67a661['concat'](pr(_0x4c2c21,_0xe933a1,_0x2af7fa,_0x4c04f9));return _0x67a661;}}function Ko(_0x5ca2fe,_0x2ca993,_0x4e16a7,_0x1d73b4,_0x4f79da){const _0x3a6a11=_0x2ca993['_queryIdentifier'],_0x49a346=_0x5ca2fe['views']['get'](_0x3a6a11);if(!_0x49a346){let _0xa0890a=yn(_0x4e16a7,_0x4f79da?_0x1d73b4:null),_0x4f84ce=!0x1;_0xa0890a?_0x4f84ce=!0x0:_0x1d73b4 instanceof g?(_0xa0890a=ns(_0x4e16a7,_0x1d73b4),_0x4f84ce=!0x1):(_0xa0890a=g['EMPTY_NODE'],_0x4f84ce=!0x1);const _0x414814=Mn(new Ce(_0xa0890a,_0x4f84ce,!0x1),new Ce(_0x1d73b4,_0x4f79da,!0x1));return new Du(_0x2ca993,_0x414814);}return _0x49a346;}function Hu(_0x232f05,_0xd796ea,_0x376120,_0x227385,_0x51f5ee,_0x55c9fe){const _0x4ee877=Ko(_0x232f05,_0xd796ea,_0x227385,_0x51f5ee,_0x55c9fe);return _0x232f05['views']['has'](_0xd796ea['_queryIdentifier'])||_0x232f05['views']['set'](_0xd796ea['_queryIdentifier'],_0x4ee877),Fu(_0x4ee877,_0x376120),Uu(_0x4ee877,_0x376120);}function $u(_0x1b737d,_0x20f391,_0x30a05d,_0x21a864){const _0x48c241=_0x20f391['_queryIdentifier'],_0xbf7421=[];let _0x2104a4=[];const _0x4527e4=Te(_0x1b737d);if(_0x48c241==='default'){for(const [_0x1080c9,_0x29f238]of _0x1b737d['views']['entries']())_0x2104a4=_0x2104a4['concat'](fr(_0x29f238,_0x30a05d,_0x21a864)),dr(_0x29f238)&&(_0x1b737d['views']['delete'](_0x1080c9),_0x29f238['query']['_queryParams']['loadsAllData']()||_0xbf7421['push'](_0x29f238['query']));}else{const _0x2bf907=_0x1b737d['views']['get'](_0x48c241);_0x2bf907&&(_0x2104a4=_0x2104a4['concat'](fr(_0x2bf907,_0x30a05d,_0x21a864)),dr(_0x2bf907)&&(_0x1b737d['views']['delete'](_0x48c241),_0x2bf907['query']['_queryParams']['loadsAllData']()||_0xbf7421['push'](_0x2bf907['query'])));}return _0x4527e4&&!Te(_0x1b737d)&&_0xbf7421['push'](new(Bu())(_0x20f391['_repo'],_0x20f391['_path'])),{'removed':_0xbf7421,'events':_0x2104a4};}function Yo(_0x52b497){const _0x39c2e8=[];for(const _0x30c57c of _0x52b497['views']['values']())_0x30c57c['query']['_queryParams']['loadsAllData']()||_0x39c2e8['push'](_0x30c57c);return _0x39c2e8;}function Ee(_0x3539fd,_0x45d9d8){let _0x47592a=null;for(const _0x3a421e of _0x3539fd['views']['values']())_0x47592a=_0x47592a||xu(_0x3a421e,_0x45d9d8);return _0x47592a;}function Qo(_0x5097da,_0x4fef9f){if(_0x4fef9f['_queryParams']['loadsAllData']())return xn(_0x5097da);{const _0x448e09=_0x4fef9f['_queryIdentifier'];return _0x5097da['views']['get'](_0x448e09);}}function Jo(_0x502c64,_0x595dc7){return Qo(_0x502c64,_0x595dc7)!=null;}function Te(_0x48406f){return xn(_0x48406f)!=null;}function xn(_0x37a384){for(const _0x1f15c6 of _0x37a384['views']['values']())if(_0x1f15c6['query']['_queryParams']['loadsAllData']())return _0x1f15c6;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x1003a9){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x1003a9;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x360e08){this['listenProvider_']=_0x360e08,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x4efa87,_0x294b39,_0x241b0d,_0x25b30d,_0x2552f1){return lu(_0x4efa87['pendingWriteTree_'],_0x294b39,_0x241b0d,_0x25b30d,_0x2552f1),_0x2552f1?ut(_0x4efa87,new Ue(Zi(),_0x294b39,_0x241b0d)):[];}function ju(_0x261280,_0x312bbb,_0x5c8076,_0x316897){hu(_0x261280['pendingWriteTree_'],_0x312bbb,_0x5c8076,_0x316897);const _0x33e479=S['fromObject'](_0x5c8076);return ut(_0x261280,new tt(Zi(),_0x312bbb,_0x33e479));}function pe(_0x596472,_0x1e9153,_0xfbd77d=!0x1){const _0x2cbab0=uu(_0x596472['pendingWriteTree_'],_0x1e9153);if(du(_0x596472['pendingWriteTree_'],_0x1e9153)){let _0x22d53a=new S(null);return _0x2cbab0['snap']!=null?_0x22d53a=_0x22d53a['set'](w(),!0x0):x(_0x2cbab0['children'],_0x3cd731=>{_0x22d53a=_0x22d53a['set'](new C(_0x3cd731),!0x0);}),ut(_0x596472,new gn(_0x2cbab0['path'],_0x22d53a,_0xfbd77d));}else return[];}function Gt(_0x56f14a,_0x2bb68e,_0x5d66c1){return ut(_0x56f14a,new Ue(es(),_0x2bb68e,_0x5d66c1));}function Ku(_0x500b4a,_0x5461bb,_0x6d3171){const _0x5fc3ac=S['fromObject'](_0x6d3171);return ut(_0x500b4a,new tt(es(),_0x5461bb,_0x5fc3ac));}function Yu(_0x413e03,_0x2bee09){return ut(_0x413e03,new Lt(es(),_0x2bee09));}function Qu(_0x2cef21,_0x4cc48b,_0x301739){const _0x40437c=as(_0x2cef21,_0x301739);if(_0x40437c){const _0x18d2b5=cs(_0x40437c),_0x1633f7=_0x18d2b5['path'],_0x362395=_0x18d2b5['queryId'],_0x1cf94f=F(_0x1633f7,_0x4cc48b),_0x477ee5=new Lt(ts(_0x362395),_0x1cf94f);return ls(_0x2cef21,_0x1633f7,_0x477ee5);}else return[];}function Cn(_0x45cbb2,_0x59d2a8,_0x13e90f,_0x6da70c,_0x5779ad=!0x1){const _0x43e8a2=_0x59d2a8['_path'],_0x166eb1=_0x45cbb2['syncPointTree_']['get'](_0x43e8a2);let _0x541dc0=[];if(_0x166eb1&&(_0x59d2a8['_queryIdentifier']==='default'||Jo(_0x166eb1,_0x59d2a8))){const _0x4583ef=$u(_0x166eb1,_0x59d2a8,_0x13e90f,_0x6da70c);Vu(_0x166eb1)&&(_0x45cbb2['syncPointTree_']=_0x45cbb2['syncPointTree_']['remove'](_0x43e8a2));const _0x3e10c8=_0x4583ef['removed'];if(_0x541dc0=_0x4583ef['events'],!_0x5779ad){const _0x370d0e=_0x3e10c8['findIndex'](_0x6c10cf=>_0x6c10cf['_queryParams']['loadsAllData']())!==-0x1,_0x892c6f=_0x45cbb2['syncPointTree_']['findOnPath'](_0x43e8a2,(_0x18b7fc,_0x5bd230)=>Te(_0x5bd230));if(_0x370d0e&&!_0x892c6f){const _0x24e99b=_0x45cbb2['syncPointTree_']['subtree'](_0x43e8a2);if(!_0x24e99b['isEmpty']()){const _0x492a56=Zu(_0x24e99b);for(let _0x45c8bd=0x0;_0x45c8bd<_0x492a56['length'];++_0x45c8bd){const _0x278d45=_0x492a56[_0x45c8bd],_0x3d75f2=_0x278d45['query'],_0x5bebb1=ta(_0x45cbb2,_0x278d45);_0x45cbb2['listenProvider_']['startListening'](bt(_0x3d75f2),xt(_0x45cbb2,_0x3d75f2),_0x5bebb1['hashFn'],_0x5bebb1['onComplete']);}}}!_0x892c6f&&_0x3e10c8['length']>0x0&&!_0x6da70c&&(_0x370d0e?_0x45cbb2['listenProvider_']['stopListening'](bt(_0x59d2a8),null):_0x3e10c8['forEach'](_0x262bd8=>{const _0x2411f4=_0x45cbb2['queryToTagMap']['get'](Un(_0x262bd8));_0x45cbb2['listenProvider_']['stopListening'](bt(_0x262bd8),_0x2411f4);}));}ed(_0x45cbb2,_0x3e10c8);}return _0x541dc0;}function Xo(_0x121232,_0x4cc903,_0x548c43,_0x346dbd){const _0x587106=as(_0x121232,_0x346dbd);if(_0x587106!=null){const _0x374b6d=cs(_0x587106),_0x5aa701=_0x374b6d['path'],_0xe61412=_0x374b6d['queryId'],_0x14608a=F(_0x5aa701,_0x4cc903),_0x696f80=new Ue(ts(_0xe61412),_0x14608a,_0x548c43);return ls(_0x121232,_0x5aa701,_0x696f80);}else return[];}function Ju(_0x413e45,_0x2d6e6f,_0x36843f,_0x284e7a){const _0x226254=as(_0x413e45,_0x284e7a);if(_0x226254){const _0x37625b=cs(_0x226254),_0x38a408=_0x37625b['path'],_0x3de3d2=_0x37625b['queryId'],_0x4ce3c0=F(_0x38a408,_0x2d6e6f),_0x15b3d2=S['fromObject'](_0x36843f),_0x52ec47=new tt(ts(_0x3de3d2),_0x4ce3c0,_0x15b3d2);return ls(_0x413e45,_0x38a408,_0x52ec47);}else return[];}function Ri(_0x4b7900,_0x137730,_0x55827d,_0x2a2ecc=!0x1){const _0xb9738c=_0x137730['_path'];let _0x492038=null,_0x14a184=!0x1;_0x4b7900['syncPointTree_']['foreachOnPath'](_0xb9738c,(_0x4ec645,_0x3dd352)=>{const _0x2b731f=F(_0x4ec645,_0xb9738c);_0x492038=_0x492038||Ee(_0x3dd352,_0x2b731f),_0x14a184=_0x14a184||Te(_0x3dd352);});let _0x822f9d=_0x4b7900['syncPointTree_']['get'](_0xb9738c);_0x822f9d?(_0x14a184=_0x14a184||Te(_0x822f9d),_0x492038=_0x492038||Ee(_0x822f9d,w())):(_0x822f9d=new jo(),_0x4b7900['syncPointTree_']=_0x4b7900['syncPointTree_']['set'](_0xb9738c,_0x822f9d));let _0x2be382;_0x492038!=null?_0x2be382=!0x0:(_0x2be382=!0x1,_0x492038=g['EMPTY_NODE'],_0x4b7900['syncPointTree_']['subtree'](_0xb9738c)['foreachChild']((_0x1c63a6,_0x56aea0)=>{const _0x118875=Ee(_0x56aea0,w());_0x118875&&(_0x492038=_0x492038['updateImmediateChild'](_0x1c63a6,_0x118875));}));const _0xc7f008=Jo(_0x822f9d,_0x137730);if(!_0xc7f008&&!_0x137730['_queryParams']['loadsAllData']()){const _0x5b433f=Un(_0x137730);f(!_0x4b7900['queryToTagMap']['has'](_0x5b433f),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x547b5c=td();_0x4b7900['queryToTagMap']['set'](_0x5b433f,_0x547b5c),_0x4b7900['tagToQueryMap']['set'](_0x547b5c,_0x5b433f);}const _0x53bb6b=Ln(_0x4b7900['pendingWriteTree_'],_0xb9738c);let _0x3d3d28=Hu(_0x822f9d,_0x137730,_0x55827d,_0x53bb6b,_0x492038,_0x2be382);if(!_0xc7f008&&!_0x14a184&&!_0x2a2ecc){const _0x51c0e7=Qo(_0x822f9d,_0x137730);_0x3d3d28=_0x3d3d28['concat'](nd(_0x4b7900,_0x137730,_0x51c0e7));}return _0x3d3d28;}function Fn(_0x21881e,_0x341b61,_0xe6aac3){const _0x5a277a=_0x21881e['pendingWriteTree_'],_0x3cd336=_0x21881e['syncPointTree_']['findOnPath'](_0x341b61,(_0x5278cc,_0x191c0f)=>{const _0x2c5c67=F(_0x5278cc,_0x341b61),_0x3684ca=Ee(_0x191c0f,_0x2c5c67);if(_0x3684ca)return _0x3684ca;});return Vo(_0x5a277a,_0x341b61,_0x3cd336,_0xe6aac3,!0x0);}function Xu(_0x5a675c,_0x58a2a9){const _0x1f100e=_0x58a2a9['_path'];let _0x231985=null;_0x5a675c['syncPointTree_']['foreachOnPath'](_0x1f100e,(_0x44f238,_0x50536d)=>{const _0x8326db=F(_0x44f238,_0x1f100e);_0x231985=_0x231985||Ee(_0x50536d,_0x8326db);});let _0x4d4f59=_0x5a675c['syncPointTree_']['get'](_0x1f100e);_0x4d4f59?_0x231985=_0x231985||Ee(_0x4d4f59,w()):(_0x4d4f59=new jo(),_0x5a675c['syncPointTree_']=_0x5a675c['syncPointTree_']['set'](_0x1f100e,_0x4d4f59));const _0x5639ff=_0x231985!=null,_0x230f2e=_0x5639ff?new Ce(_0x231985,!0x0,!0x1):null,_0x2ca30f=Ln(_0x5a675c['pendingWriteTree_'],_0x58a2a9['_path']),_0x502f1a=Ko(_0x4d4f59,_0x58a2a9,_0x2ca30f,_0x5639ff?_0x230f2e['getNode']():g['EMPTY_NODE'],_0x5639ff);return Lu(_0x502f1a);}function ut(_0x3b97f6,_0x17aae5){return Zo(_0x17aae5,_0x3b97f6['syncPointTree_'],null,Ln(_0x3b97f6['pendingWriteTree_'],w()));}function Zo(_0x514775,_0x323a82,_0x355ac9,_0x6a505d){if(v(_0x514775['path']))return ea(_0x514775,_0x323a82,_0x355ac9,_0x6a505d);{const _0x5ef1d5=_0x323a82['get'](w());_0x355ac9==null&&_0x5ef1d5!=null&&(_0x355ac9=Ee(_0x5ef1d5,w()));let _0x593257=[];const _0x21640e=y(_0x514775['path']),_0x5648bb=_0x514775['operationForChild'](_0x21640e),_0x57f556=_0x323a82['children']['get'](_0x21640e);if(_0x57f556&&_0x5648bb){const _0x273b1d=_0x355ac9?_0x355ac9['getImmediateChild'](_0x21640e):null,_0x9d6734=Ho(_0x6a505d,_0x21640e);_0x593257=_0x593257['concat'](Zo(_0x5648bb,_0x57f556,_0x273b1d,_0x9d6734));}return _0x5ef1d5&&(_0x593257=_0x593257['concat'](rs(_0x5ef1d5,_0x514775,_0x6a505d,_0x355ac9))),_0x593257;}}function ea(_0x1f3b5b,_0x6d25a0,_0x31d34f,_0x205b7e){const _0x3c47a5=_0x6d25a0['get'](w());_0x31d34f==null&&_0x3c47a5!=null&&(_0x31d34f=Ee(_0x3c47a5,w()));let _0x3e234b=[];return _0x6d25a0['children']['inorderTraversal']((_0x4a926d,_0x12a9d9)=>{const _0x1ea039=_0x31d34f?_0x31d34f['getImmediateChild'](_0x4a926d):null,_0x5c051a=Ho(_0x205b7e,_0x4a926d),_0x3d7ead=_0x1f3b5b['operationForChild'](_0x4a926d);_0x3d7ead&&(_0x3e234b=_0x3e234b['concat'](ea(_0x3d7ead,_0x12a9d9,_0x1ea039,_0x5c051a)));}),_0x3c47a5&&(_0x3e234b=_0x3e234b['concat'](rs(_0x3c47a5,_0x1f3b5b,_0x205b7e,_0x31d34f))),_0x3e234b;}function ta(_0x32190b,_0x319123){const _0x508b14=_0x319123['query'],_0x18c184=xt(_0x32190b,_0x508b14);return{'hashFn':()=>(Mu(_0x319123)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x488c0e=>{if(_0x488c0e==='ok')return _0x18c184?Qu(_0x32190b,_0x508b14['_path'],_0x18c184):Yu(_0x32190b,_0x508b14['_path']);{const _0x59ecf9=Kl(_0x488c0e,_0x508b14);return Cn(_0x32190b,_0x508b14,null,_0x59ecf9);}}};}function xt(_0x361203,_0x21945c){const _0x1192fa=Un(_0x21945c);return _0x361203['queryToTagMap']['get'](_0x1192fa);}function Un(_0x3b035f){return _0x3b035f['_path']['toString']()+'$'+_0x3b035f['_queryIdentifier'];}function as(_0x7d0fe8,_0x1bb427){return _0x7d0fe8['tagToQueryMap']['get'](_0x1bb427);}function cs(_0x5564ab){const _0x2ef619=_0x5564ab['indexOf']('$');return f(_0x2ef619!==-0x1&&_0x2ef619<_0x5564ab['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x5564ab['substr'](_0x2ef619+0x1),'path':new C(_0x5564ab['substr'](0x0,_0x2ef619))};}function ls(_0x39c6ab,_0x59a971,_0x2f93c8){const _0x67954=_0x39c6ab['syncPointTree_']['get'](_0x59a971);f(_0x67954,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x9bfc5c=Ln(_0x39c6ab['pendingWriteTree_'],_0x59a971);return rs(_0x67954,_0x2f93c8,_0x9bfc5c,null);}function Zu(_0x174c56){return _0x174c56['fold']((_0x419e12,_0x358cab,_0x1778c7)=>{if(_0x358cab&&Te(_0x358cab))return[xn(_0x358cab)];{let _0x5d4cfb=[];return _0x358cab&&(_0x5d4cfb=Yo(_0x358cab)),x(_0x1778c7,(_0x49285f,_0x229b1e)=>{_0x5d4cfb=_0x5d4cfb['concat'](_0x229b1e);}),_0x5d4cfb;}});}function bt(_0x2fab68){return _0x2fab68['_queryParams']['loadsAllData']()&&!_0x2fab68['_queryParams']['isDefault']()?new(qu())(_0x2fab68['_repo'],_0x2fab68['_path']):_0x2fab68;}function ed(_0x4b2e47,_0x1f4467){for(let _0x20b01f=0x0;_0x20b01f<_0x1f4467['length'];++_0x20b01f){const _0x11ceeb=_0x1f4467[_0x20b01f];if(!_0x11ceeb['_queryParams']['loadsAllData']()){const _0x45ef6e=Un(_0x11ceeb),_0x22c8a2=_0x4b2e47['queryToTagMap']['get'](_0x45ef6e);_0x4b2e47['queryToTagMap']['delete'](_0x45ef6e),_0x4b2e47['tagToQueryMap']['delete'](_0x22c8a2);}}}function td(){return zu++;}function nd(_0xef0e48,_0x29e326,_0x16faa1){const _0x3a1a13=_0x29e326['_path'],_0x5c1299=xt(_0xef0e48,_0x29e326),_0x4a21ce=ta(_0xef0e48,_0x16faa1),_0x31f12a=_0xef0e48['listenProvider_']['startListening'](bt(_0x29e326),_0x5c1299,_0x4a21ce['hashFn'],_0x4a21ce['onComplete']),_0x31bec3=_0xef0e48['syncPointTree_']['subtree'](_0x3a1a13);if(_0x5c1299)f(!Te(_0x31bec3['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0xfb0ba3=_0x31bec3['fold']((_0x23fc19,_0x2a09a4,_0x1aad48)=>{if(!v(_0x23fc19)&&_0x2a09a4&&Te(_0x2a09a4))return[xn(_0x2a09a4)['query']];{let _0x10ba81=[];return _0x2a09a4&&(_0x10ba81=_0x10ba81['concat'](Yo(_0x2a09a4)['map'](_0xb22841=>_0xb22841['query']))),x(_0x1aad48,(_0x165195,_0x5e2788)=>{_0x10ba81=_0x10ba81['concat'](_0x5e2788);}),_0x10ba81;}});for(let _0x162589=0x0;_0x162589<_0xfb0ba3['length'];++_0x162589){const _0x2b1e45=_0xfb0ba3[_0x162589];_0xef0e48['listenProvider_']['stopListening'](bt(_0x2b1e45),xt(_0xef0e48,_0x2b1e45));}}return _0x31f12a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x1aceec){this['node_']=_0x1aceec;}['getImmediateChild'](_0x2ff874){const _0x1a3f62=this['node_']['getImmediateChild'](_0x2ff874);return new hs(_0x1a3f62);}['node'](){return this['node_'];}}class us{constructor(_0xedbb56,_0x5cc97c){this['syncTree_']=_0xedbb56,this['path_']=_0x5cc97c;}['getImmediateChild'](_0x1d3773){const _0xa4b9c8=k(this['path_'],_0x1d3773);return new us(this['syncTree_'],_0xa4b9c8);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x2f2015){return _0x2f2015=_0x2f2015||{},_0x2f2015['timestamp']=_0x2f2015['timestamp']||new Date()['getTime'](),_0x2f2015;},gr=function(_0xd33a38,_0x12a1ba,_0x17d9a7){if(!_0xd33a38||typeof _0xd33a38!='object')return _0xd33a38;if(f('.sv'in _0xd33a38,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0xd33a38['.sv']=='string')return sd(_0xd33a38['.sv'],_0x12a1ba,_0x17d9a7);if(typeof _0xd33a38['.sv']=='object')return rd(_0xd33a38['.sv'],_0x12a1ba);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xd33a38,null,0x2));},sd=function(_0x372886,_0x4f3527,_0x34af8f){switch(_0x372886){case'timestamp':return _0x34af8f['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x372886);}},rd=function(_0x46924e,_0x351170,_0x4f1dd3){_0x46924e['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x46924e,null,0x2));const _0x1bb4ae=_0x46924e['increment'];typeof _0x1bb4ae!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x1bb4ae);const _0x3b0c25=_0x351170['node']();if(f(_0x3b0c25!==null&&typeof _0x3b0c25<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x3b0c25['isLeafNode']())return _0x1bb4ae;const _0x2afbd3=_0x3b0c25['getValue']();return typeof _0x2afbd3!='number'?_0x1bb4ae:_0x2afbd3+_0x1bb4ae;},na=function(_0x52ffca,_0x32b39c,_0x1d5dea,_0x526fc9){return fs(_0x32b39c,new us(_0x1d5dea,_0x52ffca),_0x526fc9);},ds=function(_0x536b75,_0x37c7b5,_0x1ec966){return fs(_0x536b75,new hs(_0x37c7b5),_0x1ec966);};function fs(_0x3ed1c9,_0x5c651e,_0x5a10f4){const _0x4739c1=_0x3ed1c9['getPriority']()['val'](),_0x4b5cf0=gr(_0x4739c1,_0x5c651e['getImmediateChild']('.priority'),_0x5a10f4);let _0x20d621;if(_0x3ed1c9['isLeafNode']()){const _0xec07d8=_0x3ed1c9,_0x550fbe=gr(_0xec07d8['getValue'](),_0x5c651e,_0x5a10f4);return _0x550fbe!==_0xec07d8['getValue']()||_0x4b5cf0!==_0xec07d8['getPriority']()['val']()?new D(_0x550fbe,P(_0x4b5cf0)):_0x3ed1c9;}else{const _0x33a5af=_0x3ed1c9;return _0x20d621=_0x33a5af,_0x4b5cf0!==_0x33a5af['getPriority']()['val']()&&(_0x20d621=_0x20d621['updatePriority'](new D(_0x4b5cf0))),_0x33a5af['forEachChild'](R,(_0x5dafec,_0x109b43)=>{const _0x4c30b7=fs(_0x109b43,_0x5c651e['getImmediateChild'](_0x5dafec),_0x5a10f4);_0x4c30b7!==_0x109b43&&(_0x20d621=_0x20d621['updateImmediateChild'](_0x5dafec,_0x4c30b7));}),_0x20d621;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0xa17954='',_0x54d66a=null,_0x5e9ab0={'children':{},'childCount':0x0}){this['name']=_0xa17954,this['parent']=_0x54d66a,this['node']=_0x5e9ab0;}}function Wn(_0x17f9d2,_0x515214){let _0x440ceb=_0x515214 instanceof C?_0x515214:new C(_0x515214),_0x18c487=_0x17f9d2,_0x4cc9f0=y(_0x440ceb);for(;_0x4cc9f0!==null;){const _0x4df030=De(_0x18c487['node']['children'],_0x4cc9f0)||{'children':{},'childCount':0x0};_0x18c487=new ps(_0x4cc9f0,_0x18c487,_0x4df030),_0x440ceb=b(_0x440ceb),_0x4cc9f0=y(_0x440ceb);}return _0x18c487;}function Ge(_0x3375c9){return _0x3375c9['node']['value'];}function _s(_0x13132b,_0x2d6dcf){_0x13132b['node']['value']=_0x2d6dcf,Ai(_0x13132b);}function ia(_0xd3ee1f){return _0xd3ee1f['node']['childCount']>0x0;}function od(_0xe8cb76){return Ge(_0xe8cb76)===void 0x0&&!ia(_0xe8cb76);}function Bn(_0x1f6de9,_0x9c91a9){x(_0x1f6de9['node']['children'],(_0x430380,_0x48bdfd)=>{_0x9c91a9(new ps(_0x430380,_0x1f6de9,_0x48bdfd));});}function sa(_0xbfe53f,_0x2a1264,_0x46361f,_0x2493dc){_0x46361f&&_0x2a1264(_0xbfe53f),Bn(_0xbfe53f,_0x299650=>{sa(_0x299650,_0x2a1264,!0x0);});}function ad(_0x378569,_0x5180be,_0xcc5f17){let _0x59c377=_0x378569['parent'];for(;_0x59c377!==null;){if(_0x5180be(_0x59c377))return!0x0;_0x59c377=_0x59c377['parent'];}return!0x1;}function qt(_0x280734){return new C(_0x280734['parent']===null?_0x280734['name']:qt(_0x280734['parent'])+'/'+_0x280734['name']);}function Ai(_0x192c74){_0x192c74['parent']!==null&&cd(_0x192c74['parent'],_0x192c74['name'],_0x192c74);}function cd(_0x4e0463,_0x4b91d1,_0x1316c2){const _0x2e0fb2=od(_0x1316c2),_0x5a156f=J(_0x4e0463['node']['children'],_0x4b91d1);_0x2e0fb2&&_0x5a156f?(delete _0x4e0463['node']['children'][_0x4b91d1],_0x4e0463['node']['childCount']--,Ai(_0x4e0463)):!_0x2e0fb2&&!_0x5a156f&&(_0x4e0463['node']['children'][_0x4b91d1]=_0x1316c2['node'],_0x4e0463['node']['childCount']++,Ai(_0x4e0463));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x17d016){return typeof _0x17d016=='string'&&_0x17d016['length']!==0x0&&!ld['test'](_0x17d016);},ra=function(_0x348152){return typeof _0x348152=='string'&&_0x348152['length']!==0x0&&!hd['test'](_0x348152);},ud=function(_0x17d320){return _0x17d320&&(_0x17d320=_0x17d320['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x17d320);},Tn=function(_0x1bb1b5){return _0x1bb1b5===null||typeof _0x1bb1b5=='string'||typeof _0x1bb1b5=='number'&&!Vi(_0x1bb1b5)||_0x1bb1b5&&typeof _0x1bb1b5=='object'&&J(_0x1bb1b5,'.sv');},zt=function(_0x527bd1,_0x167b3b,_0x1abbe4,_0x5b5f77){_0x5b5f77&&_0x167b3b===void 0x0||jt(Pn(_0x527bd1,'value'),_0x167b3b,_0x1abbe4);},jt=function(_0x57c6a7,_0x2e48d8,_0x31cc21){const _0x32408c=_0x31cc21 instanceof C?new Ah(_0x31cc21,_0x57c6a7):_0x31cc21;if(_0x2e48d8===void 0x0)throw new Error(_0x57c6a7+'contains\x20undefined\x20'+Pe(_0x32408c));if(typeof _0x2e48d8=='function')throw new Error(_0x57c6a7+'contains\x20a\x20function\x20'+Pe(_0x32408c)+'\x20with\x20contents\x20=\x20'+_0x2e48d8['toString']());if(Vi(_0x2e48d8))throw new Error(_0x57c6a7+'contains\x20'+_0x2e48d8['toString']()+'\x20'+Pe(_0x32408c));if(typeof _0x2e48d8=='string'&&_0x2e48d8['length']>ai/0x3&&On(_0x2e48d8)>ai)throw new Error(_0x57c6a7+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x32408c)+'\x20(\x27'+_0x2e48d8['substring'](0x0,0x32)+'...\x27)');if(_0x2e48d8&&typeof _0x2e48d8=='object'){let _0x27b768=!0x1,_0x3a1e62=!0x1;if(x(_0x2e48d8,(_0x10d298,_0x22cf7b)=>{if(_0x10d298==='.value')_0x27b768=!0x0;else{if(_0x10d298!=='.priority'&&_0x10d298!=='.sv'&&(_0x3a1e62=!0x0,!gs(_0x10d298)))throw new Error(_0x57c6a7+'\x20contains\x20an\x20invalid\x20key\x20('+_0x10d298+')\x20'+Pe(_0x32408c)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x32408c,_0x10d298),jt(_0x57c6a7,_0x22cf7b,_0x32408c),Nh(_0x32408c);}),_0x27b768&&_0x3a1e62)throw new Error(_0x57c6a7+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x32408c)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x4172bc,_0x35fede){let _0x1d7234,_0x52fa31;for(_0x1d7234=0x0;_0x1d7234<_0x35fede['length'];_0x1d7234++){_0x52fa31=_0x35fede[_0x1d7234];const _0x40f169=Pt(_0x52fa31);for(let _0x2dbb97=0x0;_0x2dbb97<_0x40f169['length'];_0x2dbb97++)if(!(_0x40f169[_0x2dbb97]==='.priority'&&_0x2dbb97===_0x40f169['length']-0x1)){if(!gs(_0x40f169[_0x2dbb97]))throw new Error(_0x4172bc+'contains\x20an\x20invalid\x20key\x20('+_0x40f169[_0x2dbb97]+')\x20in\x20path\x20'+_0x52fa31['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x35fede['sort'](Rh);let _0x134422=null;for(_0x1d7234=0x0;_0x1d7234<_0x35fede['length'];_0x1d7234++){if(_0x52fa31=_0x35fede[_0x1d7234],_0x134422!==null&&G(_0x134422,_0x52fa31))throw new Error(_0x4172bc+'contains\x20a\x20path\x20'+_0x134422['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x52fa31['toString']());_0x134422=_0x52fa31;}},fd=function(_0x108248,_0x4b2568,_0x1e7006,_0xc8c73e){const _0x12c6c7=Pn(_0x108248,'values');if(!(_0x4b2568&&typeof _0x4b2568=='object')||Array['isArray'](_0x4b2568))throw new Error(_0x12c6c7+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x24da66=[];x(_0x4b2568,(_0x3bfa48,_0x5dcabc)=>{const _0x298a6c=new C(_0x3bfa48);if(jt(_0x12c6c7,_0x5dcabc,k(_0x1e7006,_0x298a6c)),zi(_0x298a6c)==='.priority'&&!Tn(_0x5dcabc))throw new Error(_0x12c6c7+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x298a6c['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x24da66['push'](_0x298a6c);}),dd(_0x12c6c7,_0x24da66);},ms=function(_0x552299,_0x310da5,_0x4b5634,_0x117b64){if(!ra(_0x4b5634))throw new Error(Pn(_0x552299,_0x310da5)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x4b5634+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x31dd57,_0x550da0,_0x254ee1,_0x25b701){_0x254ee1&&(_0x254ee1=_0x254ee1['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x31dd57,_0x550da0,_0x254ee1);},ys=function(_0x202ef8,_0x40d155){if(y(_0x40d155)==='.info')throw new Error(_0x202ef8+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0xdbcb7f,_0x49f3b5){const _0x656702=_0x49f3b5['path']['toString']();if(typeof _0x49f3b5['repoInfo']['host']!='string'||_0x49f3b5['repoInfo']['host']['length']===0x0||!gs(_0x49f3b5['repoInfo']['namespace'])&&_0x49f3b5['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x656702['length']!==0x0&&!ud(_0x656702))throw new Error(Pn(_0xdbcb7f,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x23d327,_0x336ef4){let _0x348ea8=null;for(let _0x308b13=0x0;_0x308b13<_0x336ef4['length'];_0x308b13++){const _0x16291a=_0x336ef4[_0x308b13],_0x4f4fd5=_0x16291a['getPath']();_0x348ea8!==null&&!ji(_0x4f4fd5,_0x348ea8['path'])&&(_0x23d327['eventLists_']['push'](_0x348ea8),_0x348ea8=null),_0x348ea8===null&&(_0x348ea8={'events':[],'path':_0x4f4fd5}),_0x348ea8['events']['push'](_0x16291a);}_0x348ea8&&_0x23d327['eventLists_']['push'](_0x348ea8);}function oa(_0x273a62,_0x5ccf4e,_0x171d7d){Vn(_0x273a62,_0x171d7d),aa(_0x273a62,_0x2be760=>ji(_0x2be760,_0x5ccf4e));}function H(_0x218df9,_0x4d262e,_0x40eb74){Vn(_0x218df9,_0x40eb74),aa(_0x218df9,_0x512776=>G(_0x512776,_0x4d262e)||G(_0x4d262e,_0x512776));}function aa(_0x159c87,_0x501ab2){_0x159c87['recursionDepth_']++;let _0x21c37a=!0x0;for(let _0x44b278=0x0;_0x44b278<_0x159c87['eventLists_']['length'];_0x44b278++){const _0x54086c=_0x159c87['eventLists_'][_0x44b278];if(_0x54086c){const _0x26b783=_0x54086c['path'];_0x501ab2(_0x26b783)?(md(_0x159c87['eventLists_'][_0x44b278]),_0x159c87['eventLists_'][_0x44b278]=null):_0x21c37a=!0x1;}}_0x21c37a&&(_0x159c87['eventLists_']=[]),_0x159c87['recursionDepth_']--;}function md(_0x3abd87){for(let _0x204689=0x0;_0x204689<_0x3abd87['events']['length'];_0x204689++){const _0x4e6e51=_0x3abd87['events'][_0x204689];if(_0x4e6e51!==null){_0x3abd87['events'][_0x204689]=null;const _0x1acc05=_0x4e6e51['getEventRunner']();wt&&L('event:\x20'+_0x4e6e51['toString']()),ht(_0x1acc05);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x4ec6d9,_0x580f33,_0x9d5af9,_0x1d646f){this['repoInfo_']=_0x4ec6d9,this['forceRestClient_']=_0x580f33,this['authTokenProvider_']=_0x9d5af9,this['appCheckProvider_']=_0x1d646f,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x2ff0e0,_0x5171a1,_0x2e448a){if(_0x2ff0e0['stats_']=Gi(_0x2ff0e0['repoInfo_']),_0x2ff0e0['forceRestClient_']||Xl())_0x2ff0e0['server_']=new pn(_0x2ff0e0['repoInfo_'],(_0x5a37d0,_0x2fe3c8,_0x3b9694,_0x37ac53)=>{mr(_0x2ff0e0,_0x5a37d0,_0x2fe3c8,_0x3b9694,_0x37ac53);},_0x2ff0e0['authTokenProvider_'],_0x2ff0e0['appCheckProvider_']),setTimeout(()=>yr(_0x2ff0e0,!0x0),0x0);else{if(typeof _0x2e448a<'u'&&_0x2e448a!==null){if(typeof _0x2e448a!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x2e448a);}catch(_0x409ac6){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x409ac6);}}_0x2ff0e0['persistentConnection_']=new se(_0x2ff0e0['repoInfo_'],_0x5171a1,(_0x1ec6ff,_0x143815,_0x39155d,_0x3b8c89)=>{mr(_0x2ff0e0,_0x1ec6ff,_0x143815,_0x39155d,_0x3b8c89);},_0x478b99=>{yr(_0x2ff0e0,_0x478b99);},_0x3158ba=>{Id(_0x2ff0e0,_0x3158ba);},_0x2ff0e0['authTokenProvider_'],_0x2ff0e0['appCheckProvider_'],_0x2e448a),_0x2ff0e0['server_']=_0x2ff0e0['persistentConnection_'];}_0x2ff0e0['authTokenProvider_']['addTokenChangeListener'](_0x540bf6=>{_0x2ff0e0['server_']['refreshAuthToken'](_0x540bf6);}),_0x2ff0e0['appCheckProvider_']['addTokenChangeListener'](_0x25fe12=>{_0x2ff0e0['server_']['refreshAppCheckToken'](_0x25fe12['token']);}),_0x2ff0e0['statsReporter_']=ih(_0x2ff0e0['repoInfo_'],()=>new iu(_0x2ff0e0['stats_'],_0x2ff0e0['server_'])),_0x2ff0e0['infoData_']=new Xh(),_0x2ff0e0['infoSyncTree_']=new _r({'startListening':(_0x240011,_0x5300af,_0x4f5c5c,_0x271e4a)=>{let _0x358fef=[];const _0x1f0e18=_0x2ff0e0['infoData_']['getNode'](_0x240011['_path']);return _0x1f0e18['isEmpty']()||(_0x358fef=Gt(_0x2ff0e0['infoSyncTree_'],_0x240011['_path'],_0x1f0e18),setTimeout(()=>{_0x271e4a('ok');},0x0)),_0x358fef;},'stopListening':()=>{}}),vs(_0x2ff0e0,'connected',!0x1),_0x2ff0e0['serverSyncTree_']=new _r({'startListening':(_0x285352,_0x4157db,_0x4fc690,_0x3b4051)=>(_0x2ff0e0['server_']['listen'](_0x285352,_0x4fc690,_0x4157db,(_0x33e670,_0x1fd2b9)=>{const _0x5a7a7d=_0x3b4051(_0x33e670,_0x1fd2b9);H(_0x2ff0e0['eventQueue_'],_0x285352['_path'],_0x5a7a7d);}),[]),'stopListening':(_0x10fd44,_0x274ace)=>{_0x2ff0e0['server_']['unlisten'](_0x10fd44,_0x274ace);}});}function la(_0x392b92){const _0x4c2e28=_0x392b92['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x4c2e28;}function Kt(_0x2e7f7d){return id({'timestamp':la(_0x2e7f7d)});}function mr(_0x1bd767,_0x10e459,_0x1eaa3b,_0x75b3fd,_0x147117){_0x1bd767['dataUpdateCount']++;const _0x3768da=new C(_0x10e459);_0x1eaa3b=_0x1bd767['interceptServerDataCallback_']?_0x1bd767['interceptServerDataCallback_'](_0x10e459,_0x1eaa3b):_0x1eaa3b;let _0x59f681=[];if(_0x147117){if(_0x75b3fd){const _0x54f746=hn(_0x1eaa3b,_0x4ca97d=>P(_0x4ca97d));_0x59f681=Ju(_0x1bd767['serverSyncTree_'],_0x3768da,_0x54f746,_0x147117);}else{const _0x34b25c=P(_0x1eaa3b);_0x59f681=Xo(_0x1bd767['serverSyncTree_'],_0x3768da,_0x34b25c,_0x147117);}}else{if(_0x75b3fd){const _0x13c195=hn(_0x1eaa3b,_0x57a45e=>P(_0x57a45e));_0x59f681=Ku(_0x1bd767['serverSyncTree_'],_0x3768da,_0x13c195);}else{const _0x271022=P(_0x1eaa3b);_0x59f681=Gt(_0x1bd767['serverSyncTree_'],_0x3768da,_0x271022);}}let _0x3e6608=_0x3768da;_0x59f681['length']>0x0&&(_0x3e6608=it(_0x1bd767,_0x3768da)),H(_0x1bd767['eventQueue_'],_0x3e6608,_0x59f681);}function yr(_0x29d6f2,_0x1ebb62){vs(_0x29d6f2,'connected',_0x1ebb62),_0x1ebb62===!0x1&&Sd(_0x29d6f2);}function Id(_0x4fc4c4,_0x24599f){x(_0x24599f,(_0x26aec1,_0x464261)=>{vs(_0x4fc4c4,_0x26aec1,_0x464261);});}function vs(_0x3ad7ec,_0x45acc7,_0x478524){const _0x5f2339=new C('/.info/'+_0x45acc7),_0x37c789=P(_0x478524);_0x3ad7ec['infoData_']['updateSnapshot'](_0x5f2339,_0x37c789);const _0x49ccf4=Gt(_0x3ad7ec['infoSyncTree_'],_0x5f2339,_0x37c789);H(_0x3ad7ec['eventQueue_'],_0x5f2339,_0x49ccf4);}function Hn(_0x1e76ff){return _0x1e76ff['nextWriteId_']++;}function wd(_0x221b31,_0x3a21f6,_0x30d5b3){const _0x361c85=Xu(_0x221b31['serverSyncTree_'],_0x3a21f6);return _0x361c85!=null?Promise['resolve'](_0x361c85):_0x221b31['server_']['get'](_0x3a21f6)['then'](_0x5810eb=>{const _0x154434=P(_0x5810eb)['withIndex'](_0x3a21f6['_queryParams']['getIndex']());Ri(_0x221b31['serverSyncTree_'],_0x3a21f6,_0x30d5b3,!0x0);let _0xc0b04e;if(_0x3a21f6['_queryParams']['loadsAllData']())_0xc0b04e=Gt(_0x221b31['serverSyncTree_'],_0x3a21f6['_path'],_0x154434);else{const _0x2b07d9=xt(_0x221b31['serverSyncTree_'],_0x3a21f6);_0xc0b04e=Xo(_0x221b31['serverSyncTree_'],_0x3a21f6['_path'],_0x154434,_0x2b07d9);}return H(_0x221b31['eventQueue_'],_0x3a21f6['_path'],_0xc0b04e),Cn(_0x221b31['serverSyncTree_'],_0x3a21f6,_0x30d5b3,null,!0x0),_0x154434;},_0x17c9ba=>(dt(_0x221b31,'get\x20for\x20query\x20'+O(_0x3a21f6)+'\x20failed:\x20'+_0x17c9ba),Promise['reject'](new Error(_0x17c9ba))));}function Cd(_0xdd6db9,_0x41c0f8,_0x1924e1,_0x216ebd,_0x597a9){dt(_0xdd6db9,'set',{'path':_0x41c0f8['toString'](),'value':_0x1924e1,'priority':_0x216ebd});const _0x219895=Kt(_0xdd6db9),_0x124668=P(_0x1924e1,_0x216ebd),_0x7aed33=Fn(_0xdd6db9['serverSyncTree_'],_0x41c0f8),_0x4acac6=ds(_0x124668,_0x7aed33,_0x219895),_0x251002=Hn(_0xdd6db9),_0xdc0c2a=os(_0xdd6db9['serverSyncTree_'],_0x41c0f8,_0x4acac6,_0x251002,!0x0);Vn(_0xdd6db9['eventQueue_'],_0xdc0c2a),_0xdd6db9['server_']['put'](_0x41c0f8['toString'](),_0x124668['val'](!0x0),(_0x113af1,_0x47c6d0)=>{const _0x25c96e=_0x113af1==='ok';_0x25c96e||U('set\x20at\x20'+_0x41c0f8+'\x20failed:\x20'+_0x113af1);const _0xbf0355=pe(_0xdd6db9['serverSyncTree_'],_0x251002,!_0x25c96e);H(_0xdd6db9['eventQueue_'],_0x41c0f8,_0xbf0355),ki(_0xdd6db9,_0x597a9,_0x113af1,_0x47c6d0);});const _0x3a658d=Is(_0xdd6db9,_0x41c0f8);it(_0xdd6db9,_0x3a658d),H(_0xdd6db9['eventQueue_'],_0x3a658d,[]);}function Td(_0x2905e4,_0x4920aa,_0x176f9f,_0x5ca325){dt(_0x2905e4,'update',{'path':_0x4920aa['toString'](),'value':_0x176f9f});let _0x35af60=!0x0;const _0x1ea1b8=Kt(_0x2905e4),_0x25b7e4={};if(x(_0x176f9f,(_0x3e5a17,_0x981b0c)=>{_0x35af60=!0x1,_0x25b7e4[_0x3e5a17]=na(k(_0x4920aa,_0x3e5a17),P(_0x981b0c),_0x2905e4['serverSyncTree_'],_0x1ea1b8);}),_0x35af60)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x2905e4,_0x5ca325,'ok',void 0x0);else{const _0x38eaaa=Hn(_0x2905e4),_0x3a3bf6=ju(_0x2905e4['serverSyncTree_'],_0x4920aa,_0x25b7e4,_0x38eaaa);Vn(_0x2905e4['eventQueue_'],_0x3a3bf6),_0x2905e4['server_']['merge'](_0x4920aa['toString'](),_0x176f9f,(_0x4d831e,_0x455757)=>{const _0x1db6dc=_0x4d831e==='ok';_0x1db6dc||U('update\x20at\x20'+_0x4920aa+'\x20failed:\x20'+_0x4d831e);const _0x292a40=pe(_0x2905e4['serverSyncTree_'],_0x38eaaa,!_0x1db6dc),_0x3c4d4a=_0x292a40['length']>0x0?it(_0x2905e4,_0x4920aa):_0x4920aa;H(_0x2905e4['eventQueue_'],_0x3c4d4a,_0x292a40),ki(_0x2905e4,_0x5ca325,_0x4d831e,_0x455757);}),x(_0x176f9f,_0x135014=>{const _0x7da29a=Is(_0x2905e4,k(_0x4920aa,_0x135014));it(_0x2905e4,_0x7da29a);}),H(_0x2905e4['eventQueue_'],_0x4920aa,[]);}}function Sd(_0x490e35){dt(_0x490e35,'onDisconnectEvents');const _0x537e04=Kt(_0x490e35),_0x2a5122=_n();Ii(_0x490e35['onDisconnect_'],w(),(_0x2c3165,_0x2e693b)=>{const _0x1d7ef2=na(_0x2c3165,_0x2e693b,_0x490e35['serverSyncTree_'],_0x537e04);Fo(_0x2a5122,_0x2c3165,_0x1d7ef2);});let _0xcee4fa=[];Ii(_0x2a5122,w(),(_0x3f2660,_0x24a3e4)=>{_0xcee4fa=_0xcee4fa['concat'](Gt(_0x490e35['serverSyncTree_'],_0x3f2660,_0x24a3e4));const _0x2b581f=Is(_0x490e35,_0x3f2660);it(_0x490e35,_0x2b581f);}),_0x490e35['onDisconnect_']=_n(),H(_0x490e35['eventQueue_'],w(),_0xcee4fa);}function bd(_0x5c08ab,_0xe4a2be,_0xec90cb){let _0x3b4a82;y(_0xe4a2be['_path'])==='.info'?_0x3b4a82=Ri(_0x5c08ab['infoSyncTree_'],_0xe4a2be,_0xec90cb):_0x3b4a82=Ri(_0x5c08ab['serverSyncTree_'],_0xe4a2be,_0xec90cb),oa(_0x5c08ab['eventQueue_'],_0xe4a2be['_path'],_0x3b4a82);}function Rd(_0x5cfd5b,_0xbf2c1b,_0x58465c){let _0x44f26d;y(_0xbf2c1b['_path'])==='.info'?_0x44f26d=Cn(_0x5cfd5b['infoSyncTree_'],_0xbf2c1b,_0x58465c):_0x44f26d=Cn(_0x5cfd5b['serverSyncTree_'],_0xbf2c1b,_0x58465c),oa(_0x5cfd5b['eventQueue_'],_0xbf2c1b['_path'],_0x44f26d);}function ha(_0x311668){_0x311668['persistentConnection_']&&_0x311668['persistentConnection_']['interrupt'](ca);}function Ad(_0x1e6e62){_0x1e6e62['persistentConnection_']&&_0x1e6e62['persistentConnection_']['resume'](ca);}function dt(_0x50ba06,..._0x2e5f95){let _0x7ae39f='';_0x50ba06['persistentConnection_']&&(_0x7ae39f=_0x50ba06['persistentConnection_']['id']+':'),L(_0x7ae39f,..._0x2e5f95);}function ki(_0x63de7a,_0x465d87,_0x57c174,_0x3b1d57){_0x465d87&&ht(()=>{if(_0x57c174==='ok')_0x465d87(null);else{const _0x5935f1=(_0x57c174||'error')['toUpperCase']();let _0x49fc45=_0x5935f1;_0x3b1d57&&(_0x49fc45+=':\x20'+_0x3b1d57);const _0x56c1ca=new Error(_0x49fc45);_0x56c1ca['code']=_0x5935f1,_0x465d87(_0x56c1ca);}});}function kd(_0x204299,_0x5a19b3,_0x5522a7,_0x1d732f,_0x54f0b8,_0x1bfb52){dt(_0x204299,'transaction\x20on\x20'+_0x5a19b3);const _0x51936d={'path':_0x5a19b3,'update':_0x5522a7,'onComplete':_0x1d732f,'status':null,'order':so(),'applyLocally':_0x1bfb52,'retryCount':0x0,'unwatcher':_0x54f0b8,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x3b752a=Es(_0x204299,_0x5a19b3,void 0x0);_0x51936d['currentInputSnapshot']=_0x3b752a;const _0x1aea7d=_0x51936d['update'](_0x3b752a['val']());if(_0x1aea7d===void 0x0)_0x51936d['unwatcher'](),_0x51936d['currentOutputSnapshotRaw']=null,_0x51936d['currentOutputSnapshotResolved']=null,_0x51936d['onComplete']&&_0x51936d['onComplete'](null,!0x1,_0x51936d['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x1aea7d,_0x51936d['path']),_0x51936d['status']=0x0;const _0x485506=Wn(_0x204299['transactionQueueTree_'],_0x5a19b3),_0x325a79=Ge(_0x485506)||[];_0x325a79['push'](_0x51936d),_s(_0x485506,_0x325a79);let _0x3df550;typeof _0x1aea7d=='object'&&_0x1aea7d!==null&&J(_0x1aea7d,'.priority')?(_0x3df550=De(_0x1aea7d,'.priority'),f(Tn(_0x3df550),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x3df550=(Fn(_0x204299['serverSyncTree_'],_0x5a19b3)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x482d30=Kt(_0x204299),_0x327929=P(_0x1aea7d,_0x3df550),_0x2c34ed=ds(_0x327929,_0x3b752a,_0x482d30);_0x51936d['currentOutputSnapshotRaw']=_0x327929,_0x51936d['currentOutputSnapshotResolved']=_0x2c34ed,_0x51936d['currentWriteId']=Hn(_0x204299);const _0x361ae4=os(_0x204299['serverSyncTree_'],_0x5a19b3,_0x2c34ed,_0x51936d['currentWriteId'],_0x51936d['applyLocally']);H(_0x204299['eventQueue_'],_0x5a19b3,_0x361ae4),$n(_0x204299,_0x204299['transactionQueueTree_']);}}function Es(_0x3945af,_0x427cb7,_0x454d8d){return Fn(_0x3945af['serverSyncTree_'],_0x427cb7,_0x454d8d)||g['EMPTY_NODE'];}function $n(_0x276a55,_0x5ddf85=_0x276a55['transactionQueueTree_']){if(_0x5ddf85||Gn(_0x276a55,_0x5ddf85),Ge(_0x5ddf85)){const _0x1a1961=da(_0x276a55,_0x5ddf85);f(_0x1a1961['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x1a1961['every'](_0x35346c=>_0x35346c['status']===0x0)&&Nd(_0x276a55,qt(_0x5ddf85),_0x1a1961);}else ia(_0x5ddf85)&&Bn(_0x5ddf85,_0x45d297=>{$n(_0x276a55,_0x45d297);});}function Nd(_0x11d27c,_0xd95097,_0x23c90b){const _0x5b4586=_0x23c90b['map'](_0x1b400b=>_0x1b400b['currentWriteId']),_0x4ef453=Es(_0x11d27c,_0xd95097,_0x5b4586);let _0x562d86=_0x4ef453;const _0xd978df=_0x4ef453['hash']();for(let _0x36c746=0x0;_0x36c746<_0x23c90b['length'];_0x36c746++){const _0x412d34=_0x23c90b[_0x36c746];f(_0x412d34['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x412d34['status']=0x1,_0x412d34['retryCount']++;const _0x3e7260=F(_0xd95097,_0x412d34['path']);_0x562d86=_0x562d86['updateChild'](_0x3e7260,_0x412d34['currentOutputSnapshotRaw']);}const _0x2d78a2=_0x562d86['val'](!0x0),_0x557a3b=_0xd95097;_0x11d27c['server_']['put'](_0x557a3b['toString'](),_0x2d78a2,_0x38ba2c=>{dt(_0x11d27c,'transaction\x20put\x20response',{'path':_0x557a3b['toString'](),'status':_0x38ba2c});let _0x3440d2=[];if(_0x38ba2c==='ok'){const _0x4d5bd1=[];for(let _0x4b4f33=0x0;_0x4b4f33<_0x23c90b['length'];_0x4b4f33++)_0x23c90b[_0x4b4f33]['status']=0x2,_0x3440d2=_0x3440d2['concat'](pe(_0x11d27c['serverSyncTree_'],_0x23c90b[_0x4b4f33]['currentWriteId'])),_0x23c90b[_0x4b4f33]['onComplete']&&_0x4d5bd1['push'](()=>_0x23c90b[_0x4b4f33]['onComplete'](null,!0x0,_0x23c90b[_0x4b4f33]['currentOutputSnapshotResolved'])),_0x23c90b[_0x4b4f33]['unwatcher']();Gn(_0x11d27c,Wn(_0x11d27c['transactionQueueTree_'],_0xd95097)),$n(_0x11d27c,_0x11d27c['transactionQueueTree_']),H(_0x11d27c['eventQueue_'],_0xd95097,_0x3440d2);for(let _0x122a48=0x0;_0x122a48<_0x4d5bd1['length'];_0x122a48++)ht(_0x4d5bd1[_0x122a48]);}else{if(_0x38ba2c==='datastale'){for(let _0x14475b=0x0;_0x14475b<_0x23c90b['length'];_0x14475b++)_0x23c90b[_0x14475b]['status']===0x3?_0x23c90b[_0x14475b]['status']=0x4:_0x23c90b[_0x14475b]['status']=0x0;}else{U('transaction\x20at\x20'+_0x557a3b['toString']()+'\x20failed:\x20'+_0x38ba2c);for(let _0x39bb04=0x0;_0x39bb04<_0x23c90b['length'];_0x39bb04++)_0x23c90b[_0x39bb04]['status']=0x4,_0x23c90b[_0x39bb04]['abortReason']=_0x38ba2c;}it(_0x11d27c,_0xd95097);}},_0xd978df);}function it(_0x1dc5a2,_0x32ca11){const _0x55e482=ua(_0x1dc5a2,_0x32ca11),_0x197e88=qt(_0x55e482),_0x4b3e99=da(_0x1dc5a2,_0x55e482);return Pd(_0x1dc5a2,_0x4b3e99,_0x197e88),_0x197e88;}function Pd(_0x364f8c,_0x99781d,_0x3bca90){if(_0x99781d['length']===0x0)return;const _0x37458e=[];let _0x50f728=[];const _0x1215bb=_0x99781d['filter'](_0x554d28=>_0x554d28['status']===0x0)['map'](_0x108fb9=>_0x108fb9['currentWriteId']);for(let _0x4a775b=0x0;_0x4a775b<_0x99781d['length'];_0x4a775b++){const _0x131cb1=_0x99781d[_0x4a775b],_0x106e68=F(_0x3bca90,_0x131cb1['path']);let _0x231d78=!0x1,_0x5a2ba9;if(f(_0x106e68!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x131cb1['status']===0x4)_0x231d78=!0x0,_0x5a2ba9=_0x131cb1['abortReason'],_0x50f728=_0x50f728['concat'](pe(_0x364f8c['serverSyncTree_'],_0x131cb1['currentWriteId'],!0x0));else{if(_0x131cb1['status']===0x0){if(_0x131cb1['retryCount']>=yd)_0x231d78=!0x0,_0x5a2ba9='maxretry',_0x50f728=_0x50f728['concat'](pe(_0x364f8c['serverSyncTree_'],_0x131cb1['currentWriteId'],!0x0));else{const _0x494aea=Es(_0x364f8c,_0x131cb1['path'],_0x1215bb);_0x131cb1['currentInputSnapshot']=_0x494aea;const _0xe44305=_0x99781d[_0x4a775b]['update'](_0x494aea['val']());if(_0xe44305!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0xe44305,_0x131cb1['path']);let _0x3c0e07=P(_0xe44305);typeof _0xe44305=='object'&&_0xe44305!=null&&J(_0xe44305,'.priority')||(_0x3c0e07=_0x3c0e07['updatePriority'](_0x494aea['getPriority']()));const _0x53db1b=_0x131cb1['currentWriteId'],_0x3470df=Kt(_0x364f8c),_0x1562d4=ds(_0x3c0e07,_0x494aea,_0x3470df);_0x131cb1['currentOutputSnapshotRaw']=_0x3c0e07,_0x131cb1['currentOutputSnapshotResolved']=_0x1562d4,_0x131cb1['currentWriteId']=Hn(_0x364f8c),_0x1215bb['splice'](_0x1215bb['indexOf'](_0x53db1b),0x1),_0x50f728=_0x50f728['concat'](os(_0x364f8c['serverSyncTree_'],_0x131cb1['path'],_0x1562d4,_0x131cb1['currentWriteId'],_0x131cb1['applyLocally'])),_0x50f728=_0x50f728['concat'](pe(_0x364f8c['serverSyncTree_'],_0x53db1b,!0x0));}else _0x231d78=!0x0,_0x5a2ba9='nodata',_0x50f728=_0x50f728['concat'](pe(_0x364f8c['serverSyncTree_'],_0x131cb1['currentWriteId'],!0x0));}}}H(_0x364f8c['eventQueue_'],_0x3bca90,_0x50f728),_0x50f728=[],_0x231d78&&(_0x99781d[_0x4a775b]['status']=0x2,function(_0x4fd152){setTimeout(_0x4fd152,Math['floor'](0x0));}(_0x99781d[_0x4a775b]['unwatcher']),_0x99781d[_0x4a775b]['onComplete']&&(_0x5a2ba9==='nodata'?_0x37458e['push'](()=>_0x99781d[_0x4a775b]['onComplete'](null,!0x1,_0x99781d[_0x4a775b]['currentInputSnapshot'])):_0x37458e['push'](()=>_0x99781d[_0x4a775b]['onComplete'](new Error(_0x5a2ba9),!0x1,null))));}Gn(_0x364f8c,_0x364f8c['transactionQueueTree_']);for(let _0x27eaf3=0x0;_0x27eaf3<_0x37458e['length'];_0x27eaf3++)ht(_0x37458e[_0x27eaf3]);$n(_0x364f8c,_0x364f8c['transactionQueueTree_']);}function ua(_0x52ae24,_0x316928){let _0x606b75,_0x451d00=_0x52ae24['transactionQueueTree_'];for(_0x606b75=y(_0x316928);_0x606b75!==null&&Ge(_0x451d00)===void 0x0;)_0x451d00=Wn(_0x451d00,_0x606b75),_0x316928=b(_0x316928),_0x606b75=y(_0x316928);return _0x451d00;}function da(_0x311797,_0x1cf290){const _0x4f3c68=[];return fa(_0x311797,_0x1cf290,_0x4f3c68),_0x4f3c68['sort']((_0x452941,_0x25a40b)=>_0x452941['order']-_0x25a40b['order']),_0x4f3c68;}function fa(_0x3fca9b,_0x4ca925,_0xdd4b8e){const _0x56eb44=Ge(_0x4ca925);if(_0x56eb44){for(let _0x34a312=0x0;_0x34a312<_0x56eb44['length'];_0x34a312++)_0xdd4b8e['push'](_0x56eb44[_0x34a312]);}Bn(_0x4ca925,_0x1a987c=>{fa(_0x3fca9b,_0x1a987c,_0xdd4b8e);});}function Gn(_0x485ba5,_0x587431){const _0x5a2852=Ge(_0x587431);if(_0x5a2852){let _0x222a0d=0x0;for(let _0x111e33=0x0;_0x111e33<_0x5a2852['length'];_0x111e33++)_0x5a2852[_0x111e33]['status']!==0x2&&(_0x5a2852[_0x222a0d]=_0x5a2852[_0x111e33],_0x222a0d++);_0x5a2852['length']=_0x222a0d,_s(_0x587431,_0x5a2852['length']>0x0?_0x5a2852:void 0x0);}Bn(_0x587431,_0xcd044e=>{Gn(_0x485ba5,_0xcd044e);});}function Is(_0x2bcdcb,_0x3831aa){const _0x8b99e2=qt(ua(_0x2bcdcb,_0x3831aa)),_0x46f45a=Wn(_0x2bcdcb['transactionQueueTree_'],_0x3831aa);return ad(_0x46f45a,_0x592ce3=>{ci(_0x2bcdcb,_0x592ce3);}),ci(_0x2bcdcb,_0x46f45a),sa(_0x46f45a,_0x5db16d=>{ci(_0x2bcdcb,_0x5db16d);}),_0x8b99e2;}function ci(_0xa8e496,_0x4c1c22){const _0x33b530=Ge(_0x4c1c22);if(_0x33b530){const _0xc7eef9=[];let _0x23b5e4=[],_0x34f1bc=-0x1;for(let _0x2a56c0=0x0;_0x2a56c0<_0x33b530['length'];_0x2a56c0++)_0x33b530[_0x2a56c0]['status']===0x3||(_0x33b530[_0x2a56c0]['status']===0x1?(f(_0x34f1bc===_0x2a56c0-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x34f1bc=_0x2a56c0,_0x33b530[_0x2a56c0]['status']=0x3,_0x33b530[_0x2a56c0]['abortReason']='set'):(f(_0x33b530[_0x2a56c0]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x33b530[_0x2a56c0]['unwatcher'](),_0x23b5e4=_0x23b5e4['concat'](pe(_0xa8e496['serverSyncTree_'],_0x33b530[_0x2a56c0]['currentWriteId'],!0x0)),_0x33b530[_0x2a56c0]['onComplete']&&_0xc7eef9['push'](_0x33b530[_0x2a56c0]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x34f1bc===-0x1?_s(_0x4c1c22,void 0x0):_0x33b530['length']=_0x34f1bc+0x1,H(_0xa8e496['eventQueue_'],qt(_0x4c1c22),_0x23b5e4);for(let _0x34f5d3=0x0;_0x34f5d3<_0xc7eef9['length'];_0x34f5d3++)ht(_0xc7eef9[_0x34f5d3]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x1a66ad){let _0x2ca520='';const _0x3350c1=_0x1a66ad['split']('/');for(let _0x2bca79=0x0;_0x2bca79<_0x3350c1['length'];_0x2bca79++)if(_0x3350c1[_0x2bca79]['length']>0x0){let _0x11a8c0=_0x3350c1[_0x2bca79];try{_0x11a8c0=decodeURIComponent(_0x11a8c0['replace'](/\+/g,'\x20'));}catch{}_0x2ca520+='/'+_0x11a8c0;}return _0x2ca520;}function Dd(_0x140c65){const _0x586cac={};_0x140c65['charAt'](0x0)==='?'&&(_0x140c65=_0x140c65['substring'](0x1));for(const _0x1e4d18 of _0x140c65['split']('&')){if(_0x1e4d18['length']===0x0)continue;const _0x4fc46d=_0x1e4d18['split']('=');_0x4fc46d['length']===0x2?_0x586cac[decodeURIComponent(_0x4fc46d[0x0])]=decodeURIComponent(_0x4fc46d[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x1e4d18+'\x27\x20in\x20query\x20\x27'+_0x140c65+'\x27');}return _0x586cac;}const vr=function(_0x57abec,_0x338e43){const _0x3a2827=Md(_0x57abec),_0x1ce97b=_0x3a2827['namespace'];_0x3a2827['domain']==='firebase.com'&&ae(_0x3a2827['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x1ce97b||_0x1ce97b==='undefined')&&_0x3a2827['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x3a2827['secure']||$l();const _0x38b50d=_0x3a2827['scheme']==='ws'||_0x3a2827['scheme']==='wss';return{'repoInfo':new yo(_0x3a2827['host'],_0x3a2827['secure'],_0x1ce97b,_0x38b50d,_0x338e43,'',_0x1ce97b!==_0x3a2827['subdomain']),'path':new C(_0x3a2827['pathString'])};},Md=function(_0x1fee7a){let _0x9cf274='',_0x19a242='',_0x6404ab='',_0x4e3e38='',_0x24ef94='',_0xcaadb8=!0x0,_0x4f1afe='https',_0x57167f=0x1bb;if(typeof _0x1fee7a=='string'){let _0x5b23ad=_0x1fee7a['indexOf']('//');_0x5b23ad>=0x0&&(_0x4f1afe=_0x1fee7a['substring'](0x0,_0x5b23ad-0x1),_0x1fee7a=_0x1fee7a['substring'](_0x5b23ad+0x2));let _0x46c527=_0x1fee7a['indexOf']('/');_0x46c527===-0x1&&(_0x46c527=_0x1fee7a['length']);let _0x8cab4a=_0x1fee7a['indexOf']('?');_0x8cab4a===-0x1&&(_0x8cab4a=_0x1fee7a['length']),_0x9cf274=_0x1fee7a['substring'](0x0,Math['min'](_0x46c527,_0x8cab4a)),_0x46c527<_0x8cab4a&&(_0x4e3e38=Od(_0x1fee7a['substring'](_0x46c527,_0x8cab4a)));const _0x246ae1=Dd(_0x1fee7a['substring'](Math['min'](_0x1fee7a['length'],_0x8cab4a)));_0x5b23ad=_0x9cf274['indexOf'](':'),_0x5b23ad>=0x0?(_0xcaadb8=_0x4f1afe==='https'||_0x4f1afe==='wss',_0x57167f=parseInt(_0x9cf274['substring'](_0x5b23ad+0x1),0xa)):_0x5b23ad=_0x9cf274['length'];const _0x7fe843=_0x9cf274['slice'](0x0,_0x5b23ad);if(_0x7fe843['toLowerCase']()==='localhost')_0x19a242='localhost';else{if(_0x7fe843['split']('.')['length']<=0x2)_0x19a242=_0x7fe843;else{const _0x309375=_0x9cf274['indexOf']('.');_0x6404ab=_0x9cf274['substring'](0x0,_0x309375)['toLowerCase'](),_0x19a242=_0x9cf274['substring'](_0x309375+0x1),_0x24ef94=_0x6404ab;}}'ns'in _0x246ae1&&(_0x24ef94=_0x246ae1['ns']);}return{'host':_0x9cf274,'port':_0x57167f,'domain':_0x19a242,'subdomain':_0x6404ab,'secure':_0xcaadb8,'scheme':_0x4f1afe,'pathString':_0x4e3e38,'namespace':_0x24ef94};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x11a095=0x0;const _0x6a6e28=[];return function(_0x2d3b35){const _0x46e1a2=_0x2d3b35===_0x11a095;_0x11a095=_0x2d3b35;let _0x5daf69;const _0x512840=new Array(0x8);for(_0x5daf69=0x7;_0x5daf69>=0x0;_0x5daf69--)_0x512840[_0x5daf69]=Er['charAt'](_0x2d3b35%0x40),_0x2d3b35=Math['floor'](_0x2d3b35/0x40);f(_0x2d3b35===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x3aae2f=_0x512840['join']('');if(_0x46e1a2){for(_0x5daf69=0xb;_0x5daf69>=0x0&&_0x6a6e28[_0x5daf69]===0x3f;_0x5daf69--)_0x6a6e28[_0x5daf69]=0x0;_0x6a6e28[_0x5daf69]++;}else{for(_0x5daf69=0x0;_0x5daf69<0xc;_0x5daf69++)_0x6a6e28[_0x5daf69]=Math['floor'](Math['random']()*0x40);}for(_0x5daf69=0x0;_0x5daf69<0xc;_0x5daf69++)_0x3aae2f+=Er['charAt'](_0x6a6e28[_0x5daf69]);return f(_0x3aae2f['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x3aae2f;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x17bcf8,_0xde2c88,_0x21a050,_0x1ef356){this['eventType']=_0x17bcf8,this['eventRegistration']=_0xde2c88,this['snapshot']=_0x21a050,this['prevName']=_0x1ef356;}['getPath'](){const _0x320a98=this['snapshot']['ref'];return this['eventType']==='value'?_0x320a98['_path']:_0x320a98['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x15f586,_0x1f3eaa,_0x45c133){this['eventRegistration']=_0x15f586,this['error']=_0x1f3eaa,this['path']=_0x45c133;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x465871,_0x556159){this['snapshotCallback']=_0x465871,this['cancelCallback']=_0x556159;}['onValue'](_0x762dd1,_0x333538){this['snapshotCallback']['call'](null,_0x762dd1,_0x333538);}['onCancel'](_0x11f3d2){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x11f3d2);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x35d40a){return this['snapshotCallback']===_0x35d40a['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x35d40a['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x35d40a['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x491d4f,_0x47250b,_0x14f380,_0x2c49a4){this['_repo']=_0x491d4f,this['_path']=_0x47250b,this['_queryParams']=_0x14f380,this['_orderByCalled']=_0x2c49a4;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x4eca82=rr(this['_queryParams']),_0x331274=Hi(_0x4eca82);return _0x331274==='{}'?'default':_0x331274;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x51844d){if(_0x51844d=N(_0x51844d),!(_0x51844d instanceof be))return!0x1;const _0x2db532=this['_repo']===_0x51844d['_repo'],_0x439a22=ji(this['_path'],_0x51844d['_path']),_0x233be0=this['_queryIdentifier']===_0x51844d['_queryIdentifier'];return _0x2db532&&_0x439a22&&_0x233be0;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x41c90b,_0x39f9ed){if(_0x41c90b['_orderByCalled']===!0x0)throw new Error(_0x39f9ed+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x535c1d){let _0x2dc8e8=null,_0x53f5e4=null;if(_0x535c1d['hasStart']()&&(_0x2dc8e8=_0x535c1d['getIndexStartValue']()),_0x535c1d['hasEnd']()&&(_0x53f5e4=_0x535c1d['getIndexEndValue']()),_0x535c1d['getIndex']()===ye){const _0x2b505f='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x97412f='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x535c1d['hasStart']()){if(_0x535c1d['getIndexStartName']()!==Fe)throw new Error(_0x2b505f);if(typeof _0x2dc8e8!='string')throw new Error(_0x97412f);}if(_0x535c1d['hasEnd']()){if(_0x535c1d['getIndexEndName']()!==Ie)throw new Error(_0x2b505f);if(typeof _0x53f5e4!='string')throw new Error(_0x97412f);}}else{if(_0x535c1d['getIndex']()===R){if(_0x2dc8e8!=null&&!Tn(_0x2dc8e8)||_0x53f5e4!=null&&!Tn(_0x53f5e4))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x535c1d['getIndex']()instanceof Qi||_0x535c1d['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x2dc8e8!=null&&typeof _0x2dc8e8=='object'||_0x53f5e4!=null&&typeof _0x53f5e4=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x32d85a){if(_0x32d85a['hasStart']()&&_0x32d85a['hasEnd']()&&_0x32d85a['hasLimit']()&&!_0x32d85a['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x3be1cc,_0x2c4be9){super(_0x3be1cc,_0x2c4be9,new Xi(),!0x1);}get['parent'](){const _0x2a575c=Ro(this['_path']);return _0x2a575c===null?null:new ee(this['_repo'],_0x2a575c);}get['root'](){let _0x52179c=this;for(;_0x52179c['parent']!==null;)_0x52179c=_0x52179c['parent'];return _0x52179c;}}class st{constructor(_0xae5304,_0x376c0c,_0x3f1a24){this['_node']=_0xae5304,this['ref']=_0x376c0c,this['_index']=_0x3f1a24;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x21dad7){const _0x1a9b13=new C(_0x21dad7),_0xdaba6d=Ft(this['ref'],_0x21dad7);return new st(this['_node']['getChild'](_0x1a9b13),_0xdaba6d,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x5dd07c){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x1161a5,_0x4fb7f1)=>_0x5dd07c(new st(_0x4fb7f1,Ft(this['ref'],_0x1161a5),R)));}['hasChild'](_0xb2534){const _0x33ae0e=new C(_0xb2534);return!this['_node']['getChild'](_0x33ae0e)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x52aa1c,_0x46ad85){return _0x52aa1c=N(_0x52aa1c),_0x52aa1c['_checkNotDeleted']('ref'),_0x46ad85!==void 0x0?Ft(_0x52aa1c['_root'],_0x46ad85):_0x52aa1c['_root'];}function Ft(_0x14925a,_0x44ceec){return _0x14925a=N(_0x14925a),y(_0x14925a['_path'])===null?pd('child','path',_0x44ceec):ms('child','path',_0x44ceec),new ee(_0x14925a['_repo'],k(_0x14925a['_path'],_0x44ceec));}function g_(_0x58a2c2,_0x43595a){_0x58a2c2=N(_0x58a2c2),ys('push',_0x58a2c2['_path']),zt('push',_0x43595a,_0x58a2c2['_path'],!0x0);const _0x2ed767=la(_0x58a2c2['_repo']),_0x2e8b0a=Ld(_0x2ed767),_0x55f2c4=Ft(_0x58a2c2,_0x2e8b0a),_0x27c7ec=Ft(_0x58a2c2,_0x2e8b0a);let _0x2fe2ca;return _0x43595a!=null?_0x2fe2ca=Ud(_0x27c7ec,_0x43595a)['then'](()=>_0x27c7ec):_0x2fe2ca=Promise['resolve'](_0x27c7ec),_0x55f2c4['then']=_0x2fe2ca['then']['bind'](_0x2fe2ca),_0x55f2c4['catch']=_0x2fe2ca['then']['bind'](_0x2fe2ca,void 0x0),_0x55f2c4;}function Ud(_0x2a1a22,_0x4385a4){_0x2a1a22=N(_0x2a1a22),ys('set',_0x2a1a22['_path']),zt('set',_0x4385a4,_0x2a1a22['_path'],!0x1);const _0x43799c=new ot();return Cd(_0x2a1a22['_repo'],_0x2a1a22['_path'],_0x4385a4,null,_0x43799c['wrapCallback'](()=>{})),_0x43799c['promise'];}function m_(_0x35b69c,_0x5035a9){fd('update',_0x5035a9,_0x35b69c['_path']);const _0x522063=new ot();return Td(_0x35b69c['_repo'],_0x35b69c['_path'],_0x5035a9,_0x522063['wrapCallback'](()=>{})),_0x522063['promise'];}function y_(_0x15e1ba){_0x15e1ba=N(_0x15e1ba);const _0x2c33cc=new pa(()=>{}),_0x311595=new zn(_0x2c33cc);return wd(_0x15e1ba['_repo'],_0x15e1ba,_0x311595)['then'](_0x421d4d=>new st(_0x421d4d,new ee(_0x15e1ba['_repo'],_0x15e1ba['_path']),_0x15e1ba['_queryParams']['getIndex']()));}class zn{constructor(_0x5959c8){this['callbackContext']=_0x5959c8;}['respondsTo'](_0xde8437){return _0xde8437==='value';}['createEvent'](_0x1d54f2,_0x5b0049){const _0x4c8396=_0x5b0049['_queryParams']['getIndex']();return new xd('value',this,new st(_0x1d54f2['snapshotNode'],new ee(_0x5b0049['_repo'],_0x5b0049['_path']),_0x4c8396));}['getEventRunner'](_0x2964f0){return _0x2964f0['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x2964f0['error']):()=>this['callbackContext']['onValue'](_0x2964f0['snapshot'],null);}['createCancelEvent'](_0x424af1,_0x5892a8){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x424af1,_0x5892a8):null;}['matches'](_0x2d22a8){return _0x2d22a8 instanceof zn?!_0x2d22a8['callbackContext']||!this['callbackContext']?!0x0:_0x2d22a8['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x34ac08,_0x1c6975,_0x2befae,_0x2832e3,_0x36ee52){const _0x3e88a3=new pa(_0x2befae,void 0x0),_0xfdaac3=new zn(_0x3e88a3);return bd(_0x34ac08['_repo'],_0x34ac08,_0xfdaac3),()=>Rd(_0x34ac08['_repo'],_0x34ac08,_0xfdaac3);}function Bd(_0x50bf14,_0x2d123b,_0x591fda,_0x558ffd){return Wd(_0x50bf14,'value',_0x2d123b);}class ft{}class ma extends ft{constructor(_0x14d366,_0x319ff2){super(),this['_value']=_0x14d366,this['_key']=_0x319ff2,this['type']='endAt';}['_apply'](_0x3fc224){zt('endAt',this['_value'],_0x3fc224['_path'],!0x0);const _0x44a51f=Jh(_0x3fc224['_queryParams'],this['_value'],this['_key']);if(ga(_0x44a51f),qn(_0x44a51f),_0x3fc224['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x3fc224['_repo'],_0x3fc224['_path'],_0x44a51f,_0x3fc224['_orderByCalled']);}}function v_(_0x321a97,_0x3156e6){return new ma(_0x321a97,_0x3156e6);}class ya extends ft{constructor(_0x2b8aa8,_0x354659){super(),this['_value']=_0x2b8aa8,this['_key']=_0x354659,this['type']='startAt';}['_apply'](_0x28d4b8){zt('startAt',this['_value'],_0x28d4b8['_path'],!0x0);const _0x29e31b=Qh(_0x28d4b8['_queryParams'],this['_value'],this['_key']);if(ga(_0x29e31b),qn(_0x29e31b),_0x28d4b8['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x28d4b8['_repo'],_0x28d4b8['_path'],_0x29e31b,_0x28d4b8['_orderByCalled']);}}function E_(_0x3f8d2e=null,_0x153d0){return new ya(_0x3f8d2e,_0x153d0);}class Vd extends ft{constructor(_0x4f2980){super(),this['_limit']=_0x4f2980,this['type']='limitToFirst';}['_apply'](_0x3e4209){if(_0x3e4209['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x3e4209['_repo'],_0x3e4209['_path'],Yh(_0x3e4209['_queryParams'],this['_limit']),_0x3e4209['_orderByCalled']);}}function I_(_0x4e5be0){if(Math['floor'](_0x4e5be0)!==_0x4e5be0||_0x4e5be0<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x4e5be0);}class Hd extends ft{constructor(_0x3c9e11){super(),this['_path']=_0x3c9e11,this['type']='orderByChild';}['_apply'](_0x38aa31){_a(_0x38aa31,'orderByChild');const _0x40925a=new C(this['_path']);if(v(_0x40925a))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x3feca8=new Qi(_0x40925a),_0x2f592f=xo(_0x38aa31['_queryParams'],_0x3feca8);return qn(_0x2f592f),new be(_0x38aa31['_repo'],_0x38aa31['_path'],_0x2f592f,!0x0);}}function w_(_0x30dd63){if(_0x30dd63==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x30dd63==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x30dd63==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x30dd63),new Hd(_0x30dd63);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x514106){_a(_0x514106,'orderByKey');const _0x19fab7=xo(_0x514106['_queryParams'],ye);return qn(_0x19fab7),new be(_0x514106['_repo'],_0x514106['_path'],_0x19fab7,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x331953,_0x58d072){super(),this['_value']=_0x331953,this['_key']=_0x58d072,this['type']='equalTo';}['_apply'](_0x4ce736){if(zt('equalTo',this['_value'],_0x4ce736['_path'],!0x1),_0x4ce736['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x4ce736['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x4ce736));}}function T_(_0x1f5cd8,_0x7e85c9){return new Gd(_0x1f5cd8,_0x7e85c9);}function S_(_0x2ce3ee,..._0x3d9ef0){let _0x310480=N(_0x2ce3ee);for(const _0x521f63 of _0x3d9ef0)_0x310480=_0x521f63['_apply'](_0x310480);return _0x310480;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x1721ae,_0x535821,_0x1de4b4,_0x1e461e){const _0x37a3b4=_0x535821['lastIndexOf'](':'),_0x4021a0=_0x535821['substring'](0x0,_0x37a3b4),_0x43fb8e=at(_0x4021a0);_0x1721ae['repoInfo_']=new yo(_0x535821,_0x43fb8e,_0x1721ae['repoInfo_']['namespace'],_0x1721ae['repoInfo_']['webSocketOnly'],_0x1721ae['repoInfo_']['nodeAdmin'],_0x1721ae['repoInfo_']['persistenceKey'],_0x1721ae['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x1de4b4),_0x1e461e&&(_0x1721ae['authTokenProvider_']=_0x1e461e);}function Kd(_0x14a428,_0x19d6f2,_0x51c999,_0x2bdb83,_0x330bfd){let _0x8a837e=_0x2bdb83||_0x14a428['options']['databaseURL'];_0x8a837e===void 0x0&&(_0x14a428['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x14a428['options']['projectId']),_0x8a837e=_0x14a428['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x1662a4=vr(_0x8a837e,_0x330bfd),_0x581872=_0x1662a4['repoInfo'],_0x6c0738;typeof process<'u'&&Vs&&(_0x6c0738=Vs[qd]),_0x6c0738?(_0x8a837e='http://'+_0x6c0738+'?ns='+_0x581872['namespace'],_0x1662a4=vr(_0x8a837e,_0x330bfd),_0x581872=_0x1662a4['repoInfo']):_0x1662a4['repoInfo']['secure'];const _0x435f79=new eh(_0x14a428['name'],_0x14a428['options'],_0x19d6f2);_d('Invalid\x20Firebase\x20Database\x20URL',_0x1662a4),v(_0x1662a4['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x494467=Qd(_0x581872,_0x14a428,_0x435f79,new Zl(_0x14a428,_0x51c999));return new Jd(_0x494467,_0x14a428);}function Yd(_0x5097ec,_0x33d632){const _0xcf7bff=Ni[_0x33d632];(!_0xcf7bff||_0xcf7bff[_0x5097ec['key']]!==_0x5097ec)&&ae('Database\x20'+_0x33d632+'('+_0x5097ec['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x5097ec),delete _0xcf7bff[_0x5097ec['key']];}function Qd(_0x3ce3b6,_0x1c9f58,_0x4d53e6,_0x68e3be){let _0x5f3f9d=Ni[_0x1c9f58['name']];_0x5f3f9d||(_0x5f3f9d={},Ni[_0x1c9f58['name']]=_0x5f3f9d);let _0x1edea6=_0x5f3f9d[_0x3ce3b6['toURLString']()];return _0x1edea6&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x1edea6=new vd(_0x3ce3b6,zd,_0x4d53e6,_0x68e3be),_0x5f3f9d[_0x3ce3b6['toURLString']()]=_0x1edea6,_0x1edea6;}class Jd{constructor(_0x51772b,_0x45b477){this['_repoInternal']=_0x51772b,this['app']=_0x45b477,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x4f4699){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x4f4699+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x4d18a3=Zr(),_0x2d11e3){const _0x228317=Bi(_0x4d18a3,'database')['getImmediate']({'identifier':_0x2d11e3});if(!_0x228317['_instanceStarted']){const _0x5efed9=cc('database');_0x5efed9&&Xd(_0x228317,..._0x5efed9);}return _0x228317;}function Xd(_0x39556e,_0x5d513f,_0x36b90a,_0x415fa9={}){_0x39556e=N(_0x39556e),_0x39556e['_checkNotDeleted']('useEmulator');const _0x4ed08f=_0x5d513f+':'+_0x36b90a,_0x3813f3=_0x39556e['_repoInternal'];if(_0x39556e['_instanceStarted']){if(_0x4ed08f===_0x39556e['_repoInternal']['repoInfo_']['host']&&Me(_0x415fa9,_0x3813f3['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4c4553;if(_0x3813f3['repoInfo_']['nodeAdmin'])_0x415fa9['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4c4553=new nn(nn['OWNER']);else{if(_0x415fa9['mockUserToken']){const _0x362753=typeof _0x415fa9['mockUserToken']=='string'?_0x415fa9['mockUserToken']:lc(_0x415fa9['mockUserToken'],_0x39556e['app']['options']['projectId']);_0x4c4553=new nn(_0x362753);}}at(_0x5d513f)&&(jr(_0x5d513f),Kr('Database',!0x0)),jd(_0x3813f3,_0x4ed08f,_0x415fa9,_0x4c4553);}function R_(_0x4ca9de){_0x4ca9de=N(_0x4ca9de),_0x4ca9de['_checkNotDeleted']('goOffline'),ha(_0x4ca9de['_repo']);}function A_(_0x3c3358){_0x3c3358=N(_0x3c3358),_0x3c3358['_checkNotDeleted']('goOnline'),Ad(_0x3c3358['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0xe7da77){Ul(lt),Ze(new Le('database',(_0x1b942a,{instanceIdentifier:_0x1d5a8c})=>{const _0x1236a5=_0x1b942a['getProvider']('app')['getImmediate'](),_0x4a39d2=_0x1b942a['getProvider']('auth-internal'),_0x5b065a=_0x1b942a['getProvider']('app-check-internal');return Kd(_0x1236a5,_0x4a39d2,_0x5b065a,_0x1d5a8c);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0xe7da77),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x40f161,_0x59b58d){this['committed']=_0x40f161,this['snapshot']=_0x59b58d;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0xd8bd03,_0x15c6a8,_0x2561c3){if(_0xd8bd03=N(_0xd8bd03),ys('Reference.transaction',_0xd8bd03['_path']),_0xd8bd03['key']==='.length'||_0xd8bd03['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0xd8bd03['key']+'\x20is\x20a\x20read-only\x20object.';const _0x8fbcbb=!0x0,_0x567705=new ot(),_0x58f341=(_0x3ea8cd,_0x2945b7,_0x1bcee5)=>{let _0x31d8b1=null;_0x3ea8cd?_0x567705['reject'](_0x3ea8cd):(_0x31d8b1=new st(_0x1bcee5,new ee(_0xd8bd03['_repo'],_0xd8bd03['_path']),R),_0x567705['resolve'](new tf(_0x2945b7,_0x31d8b1)));},_0x41ec22=Bd(_0xd8bd03,()=>{});return kd(_0xd8bd03['_repo'],_0xd8bd03['_path'],_0x15c6a8,_0x58f341,_0x41ec22,_0x8fbcbb),_0x567705['promise'];}se['prototype']['simpleListen']=function(_0x4ede1d,_0x4ff886){this['sendRequest']('q',{'p':_0x4ede1d},_0x4ff886);},se['prototype']['echo']=function(_0xdb0f5e,_0xb9e0be){this['sendRequest']('echo',{'d':_0xdb0f5e},_0xb9e0be);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x19729e,..._0x51a2ea){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x19729e,..._0x51a2ea);}function sn(_0x221967,..._0x5dd84d){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x221967,..._0x5dd84d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x37414e,..._0x3d63a7){throw ws(_0x37414e,..._0x3d63a7);}function X(_0x22374a,..._0x239d1b){return ws(_0x22374a,..._0x239d1b);}function Ia(_0x12b39e,_0x21ef59,_0x590eb0){const _0x2e1e98={...nf(),[_0x21ef59]:_0x590eb0};return new Bt('auth','Firebase',_0x2e1e98)['create'](_0x21ef59,{'appName':_0x12b39e['name']});}function re(_0x40cab8){return Ia(_0x40cab8,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x41f3c1,..._0x211cd9){if(typeof _0x41f3c1!='string'){const _0x3b96e6=_0x211cd9[0x0],_0x17ee87=[..._0x211cd9['slice'](0x1)];return _0x17ee87[0x0]&&(_0x17ee87[0x0]['appName']=_0x41f3c1['name']),_0x41f3c1['_errorFactory']['create'](_0x3b96e6,..._0x17ee87);}return Ea['create'](_0x41f3c1,..._0x211cd9);}function m(_0x17a1fe,_0x31c4eb,..._0x1543a9){if(!_0x17a1fe)throw ws(_0x31c4eb,..._0x1543a9);}function ne(_0x234ba0){const _0x13c62a='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x234ba0;throw sn(_0x13c62a),new Error(_0x13c62a);}function ce(_0x4e6b82,_0x443487){_0x4e6b82||ne(_0x443487);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x438a5b;return typeof self<'u'&&((_0x438a5b=self['location'])==null?void 0x0:_0x438a5b['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0xac4d0;return typeof self<'u'&&((_0xac4d0=self['location'])==null?void 0x0:_0xac4d0['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x101123=navigator;return _0x101123['languages']&&_0x101123['languages'][0x0]||_0x101123['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x5a2dd2,_0x1caacd){this['shortDelay']=_0x5a2dd2,this['longDelay']=_0x1caacd,ce(_0x1caacd>_0x5a2dd2,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0xd50b68,_0x522900){ce(_0xd50b68['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x193500}=_0xd50b68['emulator'];return _0x522900?''+_0x193500+(_0x522900['startsWith']('/')?_0x522900['slice'](0x1):_0x522900):_0x193500;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0xb2f518,_0xb7e315,_0x54d55f){this['fetchImpl']=_0xb2f518,_0xb7e315&&(this['headersImpl']=_0xb7e315),_0x54d55f&&(this['responseImpl']=_0x54d55f);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x5892e2,_0x2a2656){return _0x5892e2['tenantId']&&!_0x2a2656['tenantId']?{..._0x2a2656,'tenantId':_0x5892e2['tenantId']}:_0x2a2656;}async function Ae(_0x3a4e6c,_0x5ce5ab,_0x4a45b8,_0x182830,_0x5b6bdc={}){return Ca(_0x3a4e6c,_0x5b6bdc,async()=>{let _0xe08622={},_0x3f4f2f={};_0x182830&&(_0x5ce5ab==='GET'?_0x3f4f2f=_0x182830:_0xe08622={'body':JSON['stringify'](_0x182830)});const _0x5ae96e=ct({'key':_0x3a4e6c['config']['apiKey'],..._0x3f4f2f})['slice'](0x1),_0x3a5d92=await _0x3a4e6c['_getAdditionalHeaders']();_0x3a5d92['Content-Type']='application/json',_0x3a4e6c['languageCode']&&(_0x3a5d92['X-Firebase-Locale']=_0x3a4e6c['languageCode']);const _0xbddb7={'method':_0x5ce5ab,'headers':_0x3a5d92,..._0xe08622};return dc()||(_0xbddb7['referrerPolicy']='no-referrer'),_0x3a4e6c['emulatorConfig']&&at(_0x3a4e6c['emulatorConfig']['host'])&&(_0xbddb7['credentials']='include'),wa['fetch']()(await Ta(_0x3a4e6c,_0x3a4e6c['config']['apiHost'],_0x4a45b8,_0x5ae96e),_0xbddb7);});}async function Ca(_0x64f883,_0x3f5009,_0x455b55){_0x64f883['_canInitEmulator']=!0x1;const _0x31b566={...cf,..._0x3f5009};try{const _0x2e562b=new df(_0x64f883),_0x2fdf66=await Promise['race']([_0x455b55(),_0x2e562b['promise']]);_0x2e562b['clearNetworkTimeout']();const _0x2575ad=await _0x2fdf66['json']();if('needConfirmation'in _0x2575ad)throw tn(_0x64f883,'account-exists-with-different-credential',_0x2575ad);if(_0x2fdf66['ok']&&!('errorMessage'in _0x2575ad))return _0x2575ad;{const _0x174764=_0x2fdf66['ok']?_0x2575ad['errorMessage']:_0x2575ad['error']['message'],[_0x320be4,_0x57ecf8]=_0x174764['split']('\x20:\x20');if(_0x320be4==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x64f883,'credential-already-in-use',_0x2575ad);if(_0x320be4==='EMAIL_EXISTS')throw tn(_0x64f883,'email-already-in-use',_0x2575ad);if(_0x320be4==='USER_DISABLED')throw tn(_0x64f883,'user-disabled',_0x2575ad);const _0x8e320=_0x31b566[_0x320be4]||_0x320be4['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x57ecf8)throw Ia(_0x64f883,_0x8e320,_0x57ecf8);Q(_0x64f883,_0x8e320);}}catch(_0x3eccd7){if(_0x3eccd7 instanceof Se)throw _0x3eccd7;Q(_0x64f883,'network-request-failed',{'message':String(_0x3eccd7)});}}async function Qt(_0x30c766,_0x42be37,_0x51d931,_0x26cb26,_0x2f380c={}){const _0x5ec0ba=await Ae(_0x30c766,_0x42be37,_0x51d931,_0x26cb26,_0x2f380c);return'mfaPendingCredential'in _0x5ec0ba&&Q(_0x30c766,'multi-factor-auth-required',{'_serverResponse':_0x5ec0ba}),_0x5ec0ba;}async function Ta(_0x8b3b8d,_0x95d7df,_0x46cbba,_0x2962fb){const _0x1cc46e=''+_0x95d7df+_0x46cbba+'?'+_0x2962fb,_0x36afc1=_0x8b3b8d,_0xc941e6=_0x36afc1['config']['emulator']?Cs(_0x8b3b8d['config'],_0x1cc46e):_0x8b3b8d['config']['apiScheme']+'://'+_0x1cc46e;return lf['includes'](_0x46cbba)&&(await _0x36afc1['_persistenceManagerAvailable'],_0x36afc1['_getPersistenceType']()==='COOKIE')?_0x36afc1['_getPersistence']()['_getFinalTarget'](_0xc941e6)['toString']():_0xc941e6;}function uf(_0x3020a7){switch(_0x3020a7){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x436601){this['auth']=_0x436601,this['timer']=null,this['promise']=new Promise((_0x192175,_0x22c1ba)=>{this['timer']=setTimeout(()=>_0x22c1ba(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x37005d,_0x369cd6,_0x1150f7){const _0x1e739b={'appName':_0x37005d['name']};_0x1150f7['email']&&(_0x1e739b['email']=_0x1150f7['email']),_0x1150f7['phoneNumber']&&(_0x1e739b['phoneNumber']=_0x1150f7['phoneNumber']);const _0x15202e=X(_0x37005d,_0x369cd6,_0x1e739b);return _0x15202e['customData']['_tokenResponse']=_0x1150f7,_0x15202e;}function wr(_0x48c278){return _0x48c278!==void 0x0&&_0x48c278['enterprise']!==void 0x0;}class ff{constructor(_0x40ac54){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x40ac54['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x40ac54['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x40ac54['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x4a64d5){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x4ed36f of this['recaptchaEnforcementState'])if(_0x4ed36f['provider']&&_0x4ed36f['provider']===_0x4a64d5)return uf(_0x4ed36f['enforcementState']);return null;}['isProviderEnabled'](_0x1e52b9){return this['getProviderEnforcementState'](_0x1e52b9)==='ENFORCE'||this['getProviderEnforcementState'](_0x1e52b9)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x210e1b,_0x4da4ff){return Ae(_0x210e1b,'GET','/v2/recaptchaConfig',Re(_0x210e1b,_0x4da4ff));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x725dff,_0x440201){return Ae(_0x725dff,'POST','/v1/accounts:delete',_0x440201);}async function bn(_0x5307bb,_0x4ba6ca){return Ae(_0x5307bb,'POST','/v1/accounts:lookup',_0x4ba6ca);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x40f62f){if(_0x40f62f)try{const _0x48408e=new Date(Number(_0x40f62f));if(!isNaN(_0x48408e['getTime']()))return _0x48408e['toUTCString']();}catch{}}async function gf(_0x4b9d05,_0x3d74fb=!0x1){const _0x50af7c=N(_0x4b9d05),_0xe13889=await _0x50af7c['getIdToken'](_0x3d74fb),_0x2cce3c=Ts(_0xe13889);m(_0x2cce3c&&_0x2cce3c['exp']&&_0x2cce3c['auth_time']&&_0x2cce3c['iat'],_0x50af7c['auth'],'internal-error');const _0x2b0562=typeof _0x2cce3c['firebase']=='object'?_0x2cce3c['firebase']:void 0x0,_0x5737dd=_0x2b0562==null?void 0x0:_0x2b0562['sign_in_provider'];return{'claims':_0x2cce3c,'token':_0xe13889,'authTime':Rt(li(_0x2cce3c['auth_time'])),'issuedAtTime':Rt(li(_0x2cce3c['iat'])),'expirationTime':Rt(li(_0x2cce3c['exp'])),'signInProvider':_0x5737dd||null,'signInSecondFactor':(_0x2b0562==null?void 0x0:_0x2b0562['sign_in_second_factor'])||null};}function li(_0xe5e5bc){return Number(_0xe5e5bc)*0x3e8;}function Ts(_0x3ddeac){const [_0x481774,_0x429907,_0x303720]=_0x3ddeac['split']('.');if(_0x481774===void 0x0||_0x429907===void 0x0||_0x303720===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x411e68=ln(_0x429907);return _0x411e68?JSON['parse'](_0x411e68):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x441106){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x441106==null?void 0x0:_0x441106['toString']()),null;}}function Cr(_0x19584d){const _0x26318a=Ts(_0x19584d);return m(_0x26318a,'internal-error'),m(typeof _0x26318a['exp']<'u','internal-error'),m(typeof _0x26318a['iat']<'u','internal-error'),Number(_0x26318a['exp'])-Number(_0x26318a['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x25ad10,_0x588bb2,_0x2a47d2=!0x1){if(_0x2a47d2)return _0x588bb2;try{return await _0x588bb2;}catch(_0x14e8e4){throw _0x14e8e4 instanceof Se&&mf(_0x14e8e4)&&_0x25ad10['auth']['currentUser']===_0x25ad10&&await _0x25ad10['auth']['signOut'](),_0x14e8e4;}}function mf({code:_0x110d40}){return _0x110d40==='auth/user-disabled'||_0x110d40==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x19ad81){this['user']=_0x19ad81,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x211491){if(_0x211491){const _0x3389f5=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x3389f5;}else{this['errorBackoff']=0x7530;const _0x16fa57=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x16fa57);}}['schedule'](_0x27c417=!0x1){if(!this['isRunning'])return;const _0x569569=this['getInterval'](_0x27c417);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x569569);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x6726a6){(_0x6726a6==null?void 0x0:_0x6726a6['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x423973,_0x3327bc){this['createdAt']=_0x423973,this['lastLoginAt']=_0x3327bc,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0xe6603c){this['createdAt']=_0xe6603c['createdAt'],this['lastLoginAt']=_0xe6603c['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x4fe590){var _0x431d5b;const _0x2e740d=_0x4fe590['auth'],_0x58cbc0=await _0x4fe590['getIdToken'](),_0x271536=await Ut(_0x4fe590,bn(_0x2e740d,{'idToken':_0x58cbc0}));m(_0x271536==null?void 0x0:_0x271536['users']['length'],_0x2e740d,'internal-error');const _0x3d196a=_0x271536['users'][0x0];_0x4fe590['_notifyReloadListener'](_0x3d196a);const _0x3e1298=(_0x431d5b=_0x3d196a['providerUserInfo'])!=null&&_0x431d5b['length']?Sa(_0x3d196a['providerUserInfo']):[],_0x5c84fa=Ef(_0x4fe590['providerData'],_0x3e1298),_0x5c6a4=_0x4fe590['isAnonymous'],_0x900138=!(_0x4fe590['email']&&_0x3d196a['passwordHash'])&&!(_0x5c84fa!=null&&_0x5c84fa['length']),_0x361c69=_0x5c6a4?_0x900138:!0x1,_0x50128c={'uid':_0x3d196a['localId'],'displayName':_0x3d196a['displayName']||null,'photoURL':_0x3d196a['photoUrl']||null,'email':_0x3d196a['email']||null,'emailVerified':_0x3d196a['emailVerified']||!0x1,'phoneNumber':_0x3d196a['phoneNumber']||null,'tenantId':_0x3d196a['tenantId']||null,'providerData':_0x5c84fa,'metadata':new Oi(_0x3d196a['createdAt'],_0x3d196a['lastLoginAt']),'isAnonymous':_0x361c69};Object['assign'](_0x4fe590,_0x50128c);}async function vf(_0x4516de){const _0x3a94d6=N(_0x4516de);await Rn(_0x3a94d6),await _0x3a94d6['auth']['_persistUserIfCurrent'](_0x3a94d6),_0x3a94d6['auth']['_notifyListenersIfCurrent'](_0x3a94d6);}function Ef(_0x3aeb27,_0x5b21c7){return[..._0x3aeb27['filter'](_0x44926d=>!_0x5b21c7['some'](_0xedcf13=>_0xedcf13['providerId']===_0x44926d['providerId'])),..._0x5b21c7];}function Sa(_0x3750ab){return _0x3750ab['map'](({providerId:_0x3e6010,..._0x46aff0})=>({'providerId':_0x3e6010,'uid':_0x46aff0['rawId']||'','displayName':_0x46aff0['displayName']||null,'email':_0x46aff0['email']||null,'phoneNumber':_0x46aff0['phoneNumber']||null,'photoURL':_0x46aff0['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x18c4ee,_0xe58e64){const _0x2d2b5e=await Ca(_0x18c4ee,{},async()=>{const _0x37c712=ct({'grant_type':'refresh_token','refresh_token':_0xe58e64})['slice'](0x1),{tokenApiHost:_0x889847,apiKey:_0x348318}=_0x18c4ee['config'],_0x415aad=await Ta(_0x18c4ee,_0x889847,'/v1/token','key='+_0x348318),_0x1ac928=await _0x18c4ee['_getAdditionalHeaders']();_0x1ac928['Content-Type']='application/x-www-form-urlencoded';const _0x1b653a={'method':'POST','headers':_0x1ac928,'body':_0x37c712};return _0x18c4ee['emulatorConfig']&&at(_0x18c4ee['emulatorConfig']['host'])&&(_0x1b653a['credentials']='include'),wa['fetch']()(_0x415aad,_0x1b653a);});return{'accessToken':_0x2d2b5e['access_token'],'expiresIn':_0x2d2b5e['expires_in'],'refreshToken':_0x2d2b5e['refresh_token']};}async function wf(_0x15d015,_0x39ae3f){return Ae(_0x15d015,'POST','/v2/accounts:revokeToken',Re(_0x15d015,_0x39ae3f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x21a042){m(_0x21a042['idToken'],'internal-error'),m(typeof _0x21a042['idToken']<'u','internal-error'),m(typeof _0x21a042['refreshToken']<'u','internal-error');const _0x4abbf9='expiresIn'in _0x21a042&&typeof _0x21a042['expiresIn']<'u'?Number(_0x21a042['expiresIn']):Cr(_0x21a042['idToken']);this['updateTokensAndExpiration'](_0x21a042['idToken'],_0x21a042['refreshToken'],_0x4abbf9);}['updateFromIdToken'](_0x48e006){m(_0x48e006['length']!==0x0,'internal-error');const _0x316e5c=Cr(_0x48e006);this['updateTokensAndExpiration'](_0x48e006,null,_0x316e5c);}async['getToken'](_0x134c31,_0x5a225c=!0x1){return!_0x5a225c&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x134c31,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x134c31,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x1886fd,_0xa9e101){const {accessToken:_0x45a68c,refreshToken:_0x341a09,expiresIn:_0x13d879}=await If(_0x1886fd,_0xa9e101);this['updateTokensAndExpiration'](_0x45a68c,_0x341a09,Number(_0x13d879));}['updateTokensAndExpiration'](_0x340f28,_0x48da54,_0x46a53f){this['refreshToken']=_0x48da54||null,this['accessToken']=_0x340f28||null,this['expirationTime']=Date['now']()+_0x46a53f*0x3e8;}static['fromJSON'](_0x3ee17c,_0x3b5c33){const {refreshToken:_0x1cd491,accessToken:_0x284cc1,expirationTime:_0x5b460e}=_0x3b5c33,_0x1dec5e=new Qe();return _0x1cd491&&(m(typeof _0x1cd491=='string','internal-error',{'appName':_0x3ee17c}),_0x1dec5e['refreshToken']=_0x1cd491),_0x284cc1&&(m(typeof _0x284cc1=='string','internal-error',{'appName':_0x3ee17c}),_0x1dec5e['accessToken']=_0x284cc1),_0x5b460e&&(m(typeof _0x5b460e=='number','internal-error',{'appName':_0x3ee17c}),_0x1dec5e['expirationTime']=_0x5b460e),_0x1dec5e;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x1f96ad){this['accessToken']=_0x1f96ad['accessToken'],this['refreshToken']=_0x1f96ad['refreshToken'],this['expirationTime']=_0x1f96ad['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x4bdd94,_0x5c6359){m(typeof _0x4bdd94=='string'||typeof _0x4bdd94>'u','internal-error',{'appName':_0x5c6359});}class K{constructor({uid:_0x1b045a,auth:_0x42fe6a,stsTokenManager:_0xb97c7f,..._0x1615df}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1b045a,this['auth']=_0x42fe6a,this['stsTokenManager']=_0xb97c7f,this['accessToken']=_0xb97c7f['accessToken'],this['displayName']=_0x1615df['displayName']||null,this['email']=_0x1615df['email']||null,this['emailVerified']=_0x1615df['emailVerified']||!0x1,this['phoneNumber']=_0x1615df['phoneNumber']||null,this['photoURL']=_0x1615df['photoURL']||null,this['isAnonymous']=_0x1615df['isAnonymous']||!0x1,this['tenantId']=_0x1615df['tenantId']||null,this['providerData']=_0x1615df['providerData']?[..._0x1615df['providerData']]:[],this['metadata']=new Oi(_0x1615df['createdAt']||void 0x0,_0x1615df['lastLoginAt']||void 0x0);}async['getIdToken'](_0x29890f){const _0x56e77f=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x29890f));return m(_0x56e77f,this['auth'],'internal-error'),this['accessToken']!==_0x56e77f&&(this['accessToken']=_0x56e77f,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x56e77f;}['getIdTokenResult'](_0x563517){return gf(this,_0x563517);}['reload'](){return vf(this);}['_assign'](_0x2a0188){this!==_0x2a0188&&(m(this['uid']===_0x2a0188['uid'],this['auth'],'internal-error'),this['displayName']=_0x2a0188['displayName'],this['photoURL']=_0x2a0188['photoURL'],this['email']=_0x2a0188['email'],this['emailVerified']=_0x2a0188['emailVerified'],this['phoneNumber']=_0x2a0188['phoneNumber'],this['isAnonymous']=_0x2a0188['isAnonymous'],this['tenantId']=_0x2a0188['tenantId'],this['providerData']=_0x2a0188['providerData']['map'](_0x286db2=>({..._0x286db2})),this['metadata']['_copy'](_0x2a0188['metadata']),this['stsTokenManager']['_assign'](_0x2a0188['stsTokenManager']));}['_clone'](_0x535e76){const _0x1b44c3=new K({...this,'auth':_0x535e76,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x1b44c3['metadata']['_copy'](this['metadata']),_0x1b44c3;}['_onReload'](_0x508a98){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x508a98,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x28d72d){this['reloadListener']?this['reloadListener'](_0x28d72d):this['reloadUserInfo']=_0x28d72d;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x823a88,_0x97d308=!0x1){let _0x3adc33=!0x1;_0x823a88['idToken']&&_0x823a88['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x823a88),_0x3adc33=!0x0),_0x97d308&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x3adc33&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x1cfa6c=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x1cfa6c})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x2dead8=>({..._0x2dead8})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x168bd3,_0x997168){const _0x368a86=_0x997168['displayName']??void 0x0,_0x38f007=_0x997168['email']??void 0x0,_0x33afd7=_0x997168['phoneNumber']??void 0x0,_0x58c290=_0x997168['photoURL']??void 0x0,_0x4da7e0=_0x997168['tenantId']??void 0x0,_0x1074d0=_0x997168['_redirectEventId']??void 0x0,_0x1dfe71=_0x997168['createdAt']??void 0x0,_0x10c1ce=_0x997168['lastLoginAt']??void 0x0,{uid:_0x3548f6,emailVerified:_0x45b538,isAnonymous:_0x5c1b23,providerData:_0x5cf809,stsTokenManager:_0x5f7e39}=_0x997168;m(_0x3548f6&&_0x5f7e39,_0x168bd3,'internal-error');const _0xe30c43=Qe['fromJSON'](this['name'],_0x5f7e39);m(typeof _0x3548f6=='string',_0x168bd3,'internal-error'),le(_0x368a86,_0x168bd3['name']),le(_0x38f007,_0x168bd3['name']),m(typeof _0x45b538=='boolean',_0x168bd3,'internal-error'),m(typeof _0x5c1b23=='boolean',_0x168bd3,'internal-error'),le(_0x33afd7,_0x168bd3['name']),le(_0x58c290,_0x168bd3['name']),le(_0x4da7e0,_0x168bd3['name']),le(_0x1074d0,_0x168bd3['name']),le(_0x1dfe71,_0x168bd3['name']),le(_0x10c1ce,_0x168bd3['name']);const _0x430caf=new K({'uid':_0x3548f6,'auth':_0x168bd3,'email':_0x38f007,'emailVerified':_0x45b538,'displayName':_0x368a86,'isAnonymous':_0x5c1b23,'photoURL':_0x58c290,'phoneNumber':_0x33afd7,'tenantId':_0x4da7e0,'stsTokenManager':_0xe30c43,'createdAt':_0x1dfe71,'lastLoginAt':_0x10c1ce});return _0x5cf809&&Array['isArray'](_0x5cf809)&&(_0x430caf['providerData']=_0x5cf809['map'](_0x5b6cf8=>({..._0x5b6cf8}))),_0x1074d0&&(_0x430caf['_redirectEventId']=_0x1074d0),_0x430caf;}static async['_fromIdTokenResponse'](_0x4b39d4,_0x365fc1,_0x20bd77=!0x1){const _0x77c0df=new Qe();_0x77c0df['updateFromServerResponse'](_0x365fc1);const _0x5298f0=new K({'uid':_0x365fc1['localId'],'auth':_0x4b39d4,'stsTokenManager':_0x77c0df,'isAnonymous':_0x20bd77});return await Rn(_0x5298f0),_0x5298f0;}static async['_fromGetAccountInfoResponse'](_0x506b1a,_0x739ed2,_0x4bceb3){const _0x5896f7=_0x739ed2['users'][0x0];m(_0x5896f7['localId']!==void 0x0,'internal-error');const _0x560e19=_0x5896f7['providerUserInfo']!==void 0x0?Sa(_0x5896f7['providerUserInfo']):[],_0x1d45e7=!(_0x5896f7['email']&&_0x5896f7['passwordHash'])&&!(_0x560e19!=null&&_0x560e19['length']),_0x15ef3e=new Qe();_0x15ef3e['updateFromIdToken'](_0x4bceb3);const _0x418b65=new K({'uid':_0x5896f7['localId'],'auth':_0x506b1a,'stsTokenManager':_0x15ef3e,'isAnonymous':_0x1d45e7}),_0x40e51a={'uid':_0x5896f7['localId'],'displayName':_0x5896f7['displayName']||null,'photoURL':_0x5896f7['photoUrl']||null,'email':_0x5896f7['email']||null,'emailVerified':_0x5896f7['emailVerified']||!0x1,'phoneNumber':_0x5896f7['phoneNumber']||null,'tenantId':_0x5896f7['tenantId']||null,'providerData':_0x560e19,'metadata':new Oi(_0x5896f7['createdAt'],_0x5896f7['lastLoginAt']),'isAnonymous':!(_0x5896f7['email']&&_0x5896f7['passwordHash'])&&!(_0x560e19!=null&&_0x560e19['length'])};return Object['assign'](_0x418b65,_0x40e51a),_0x418b65;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x532364){ce(_0x532364 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x18b25b=Tr['get'](_0x532364);return _0x18b25b?(ce(_0x18b25b instanceof _0x532364,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x18b25b):(_0x18b25b=new _0x532364(),Tr['set'](_0x532364,_0x18b25b),_0x18b25b);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0xc6e674,_0x2c3f38){this['storage'][_0xc6e674]=_0x2c3f38;}async['_get'](_0x458bf5){const _0x3d0ce4=this['storage'][_0x458bf5];return _0x3d0ce4===void 0x0?null:_0x3d0ce4;}async['_remove'](_0x285c89){delete this['storage'][_0x285c89];}['_addListener'](_0x8c12c4,_0x172413){}['_removeListener'](_0x18ec12,_0x43c5cc){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x4dec13,_0x469a03,_0x403bb5){return'firebase:'+_0x4dec13+':'+_0x469a03+':'+_0x403bb5;}class Je{constructor(_0x43e913,_0x187a4b,_0x141c42){this['persistence']=_0x43e913,this['auth']=_0x187a4b,this['userKey']=_0x141c42;const {config:_0x5bfbd5,name:_0x2e52f0}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x5bfbd5['apiKey'],_0x2e52f0),this['fullPersistenceKey']=rn('persistence',_0x5bfbd5['apiKey'],_0x2e52f0),this['boundEventHandler']=_0x187a4b['_onStorageEvent']['bind'](_0x187a4b),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x5e5c6e){return this['persistence']['_set'](this['fullUserKey'],_0x5e5c6e['toJSON']());}async['getCurrentUser'](){const _0x4127f8=await this['persistence']['_get'](this['fullUserKey']);if(!_0x4127f8)return null;if(typeof _0x4127f8=='string'){const _0x3c117b=await bn(this['auth'],{'idToken':_0x4127f8})['catch'](()=>{});return _0x3c117b?K['_fromGetAccountInfoResponse'](this['auth'],_0x3c117b,_0x4127f8):null;}return K['_fromJSON'](this['auth'],_0x4127f8);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x433a90){if(this['persistence']===_0x433a90)return;const _0x3475a0=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x433a90,_0x3475a0)return this['setCurrentUser'](_0x3475a0);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x33ac61,_0x266577,_0x75254e='authUser'){if(!_0x266577['length'])return new Je(ie(Sr),_0x33ac61,_0x75254e);const _0x35b9a6=(await Promise['all'](_0x266577['map'](async _0x830576=>{if(await _0x830576['_isAvailable']())return _0x830576;})))['filter'](_0x568da6=>_0x568da6);let _0x42927b=_0x35b9a6[0x0]||ie(Sr);const _0x14cd5c=rn(_0x75254e,_0x33ac61['config']['apiKey'],_0x33ac61['name']);let _0x58c90=null;for(const _0x4e5527 of _0x266577)try{const _0x39fc6a=await _0x4e5527['_get'](_0x14cd5c);if(_0x39fc6a){let _0x14e701;if(typeof _0x39fc6a=='string'){const _0x44f0b9=await bn(_0x33ac61,{'idToken':_0x39fc6a})['catch'](()=>{});if(!_0x44f0b9)break;_0x14e701=await K['_fromGetAccountInfoResponse'](_0x33ac61,_0x44f0b9,_0x39fc6a);}else _0x14e701=K['_fromJSON'](_0x33ac61,_0x39fc6a);_0x4e5527!==_0x42927b&&(_0x58c90=_0x14e701),_0x42927b=_0x4e5527;break;}}catch{}const _0x5bddf5=_0x35b9a6['filter'](_0x3f00b9=>_0x3f00b9['_shouldAllowMigration']);return!_0x42927b['_shouldAllowMigration']||!_0x5bddf5['length']?new Je(_0x42927b,_0x33ac61,_0x75254e):(_0x42927b=_0x5bddf5[0x0],_0x58c90&&await _0x42927b['_set'](_0x14cd5c,_0x58c90['toJSON']()),await Promise['all'](_0x266577['map'](async _0x5962d5=>{if(_0x5962d5!==_0x42927b)try{await _0x5962d5['_remove'](_0x14cd5c);}catch{}})),new Je(_0x42927b,_0x33ac61,_0x75254e));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x118c71){const _0x55a50c=_0x118c71['toLowerCase']();if(_0x55a50c['includes']('opera/')||_0x55a50c['includes']('opr/')||_0x55a50c['includes']('opios/'))return'Opera';if(Na(_0x55a50c))return'IEMobile';if(_0x55a50c['includes']('msie')||_0x55a50c['includes']('trident/'))return'IE';if(_0x55a50c['includes']('edge/'))return'Edge';if(Ra(_0x55a50c))return'Firefox';if(_0x55a50c['includes']('silk/'))return'Silk';if(Oa(_0x55a50c))return'Blackberry';if(Da(_0x55a50c))return'Webos';if(Aa(_0x55a50c))return'Safari';if((_0x55a50c['includes']('chrome/')||ka(_0x55a50c))&&!_0x55a50c['includes']('edge/'))return'Chrome';if(Pa(_0x55a50c))return'Android';{const _0x248af7=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x131534=_0x118c71['match'](_0x248af7);if((_0x131534==null?void 0x0:_0x131534['length'])===0x2)return _0x131534[0x1];}return'Other';}function Ra(_0x474ec6=W()){return/firefox\//i['test'](_0x474ec6);}function Aa(_0x588249=W()){const _0xda3ddf=_0x588249['toLowerCase']();return _0xda3ddf['includes']('safari/')&&!_0xda3ddf['includes']('chrome/')&&!_0xda3ddf['includes']('crios/')&&!_0xda3ddf['includes']('android');}function ka(_0x227eb7=W()){return/crios\//i['test'](_0x227eb7);}function Na(_0x16f816=W()){return/iemobile/i['test'](_0x16f816);}function Pa(_0x2512ae=W()){return/android/i['test'](_0x2512ae);}function Oa(_0x4216c9=W()){return/blackberry/i['test'](_0x4216c9);}function Da(_0x2973a3=W()){return/webos/i['test'](_0x2973a3);}function Ss(_0xc96711=W()){return/iphone|ipad|ipod/i['test'](_0xc96711)||/macintosh/i['test'](_0xc96711)&&/mobile/i['test'](_0xc96711);}function Cf(_0x14b83b=W()){var _0x4651c5;return Ss(_0x14b83b)&&!!((_0x4651c5=window['navigator'])!=null&&_0x4651c5['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x9c144=W()){return Ss(_0x9c144)||Pa(_0x9c144)||Da(_0x9c144)||Oa(_0x9c144)||/windows phone/i['test'](_0x9c144)||Na(_0x9c144);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x4e1cb1,_0x39f3a8=[]){let _0xb03ec1;switch(_0x4e1cb1){case'Browser':_0xb03ec1=br(W());break;case'Worker':_0xb03ec1=br(W())+'-'+_0x4e1cb1;break;default:_0xb03ec1=_0x4e1cb1;}const _0x488d3b=_0x39f3a8['length']?_0x39f3a8['join'](','):'FirebaseCore-web';return _0xb03ec1+'/JsCore/'+lt+'/'+_0x488d3b;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0xb15f0a){this['auth']=_0xb15f0a,this['queue']=[];}['pushCallback'](_0x330ec8,_0x531bd0){const _0x1491c0=_0x135943=>new Promise((_0x13ecd6,_0x4a5fee)=>{try{const _0xa458ea=_0x330ec8(_0x135943);_0x13ecd6(_0xa458ea);}catch(_0x236d41){_0x4a5fee(_0x236d41);}});_0x1491c0['onAbort']=_0x531bd0,this['queue']['push'](_0x1491c0);const _0x5174ae=this['queue']['length']-0x1;return()=>{this['queue'][_0x5174ae]=()=>Promise['resolve']();};}async['runMiddleware'](_0x4fe33c){if(this['auth']['currentUser']===_0x4fe33c)return;const _0x328292=[];try{for(const _0x253f63 of this['queue'])await _0x253f63(_0x4fe33c),_0x253f63['onAbort']&&_0x328292['push'](_0x253f63['onAbort']);}catch(_0x69b345){_0x328292['reverse']();for(const _0x6ead41 of _0x328292)try{_0x6ead41();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x69b345==null?void 0x0:_0x69b345['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x30e772,_0x445aa7={}){return Ae(_0x30e772,'GET','/v2/passwordPolicy',Re(_0x30e772,_0x445aa7));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x45a52c){var _0x15e30d;const _0x5560fd=_0x45a52c['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x5560fd['minPasswordLength']??Rf,_0x5560fd['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x5560fd['maxPasswordLength']),_0x5560fd['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x5560fd['containsLowercaseCharacter']),_0x5560fd['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x5560fd['containsUppercaseCharacter']),_0x5560fd['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x5560fd['containsNumericCharacter']),_0x5560fd['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x5560fd['containsNonAlphanumericCharacter']),this['enforcementState']=_0x45a52c['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x15e30d=_0x45a52c['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x15e30d['join'](''))??'',this['forceUpgradeOnSignin']=_0x45a52c['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x45a52c['schemaVersion'];}['validatePassword'](_0x198d16){const _0x2a8190={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x198d16,_0x2a8190),this['validatePasswordCharacterOptions'](_0x198d16,_0x2a8190),_0x2a8190['isValid']&&(_0x2a8190['isValid']=_0x2a8190['meetsMinPasswordLength']??!0x0),_0x2a8190['isValid']&&(_0x2a8190['isValid']=_0x2a8190['meetsMaxPasswordLength']??!0x0),_0x2a8190['isValid']&&(_0x2a8190['isValid']=_0x2a8190['containsLowercaseLetter']??!0x0),_0x2a8190['isValid']&&(_0x2a8190['isValid']=_0x2a8190['containsUppercaseLetter']??!0x0),_0x2a8190['isValid']&&(_0x2a8190['isValid']=_0x2a8190['containsNumericCharacter']??!0x0),_0x2a8190['isValid']&&(_0x2a8190['isValid']=_0x2a8190['containsNonAlphanumericCharacter']??!0x0),_0x2a8190;}['validatePasswordLengthOptions'](_0x4e38ea,_0x258d8f){const _0x35bc30=this['customStrengthOptions']['minPasswordLength'],_0x27777b=this['customStrengthOptions']['maxPasswordLength'];_0x35bc30&&(_0x258d8f['meetsMinPasswordLength']=_0x4e38ea['length']>=_0x35bc30),_0x27777b&&(_0x258d8f['meetsMaxPasswordLength']=_0x4e38ea['length']<=_0x27777b);}['validatePasswordCharacterOptions'](_0xd0aa98,_0x11fd0d){this['updatePasswordCharacterOptionsStatuses'](_0x11fd0d,!0x1,!0x1,!0x1,!0x1);let _0x53b89f;for(let _0x4f8b89=0x0;_0x4f8b89<_0xd0aa98['length'];_0x4f8b89++)_0x53b89f=_0xd0aa98['charAt'](_0x4f8b89),this['updatePasswordCharacterOptionsStatuses'](_0x11fd0d,_0x53b89f>='a'&&_0x53b89f<='z',_0x53b89f>='A'&&_0x53b89f<='Z',_0x53b89f>='0'&&_0x53b89f<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x53b89f));}['updatePasswordCharacterOptionsStatuses'](_0x5a47e6,_0x2b6d36,_0x26265a,_0x470192,_0x12af8a){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5a47e6['containsLowercaseLetter']||(_0x5a47e6['containsLowercaseLetter']=_0x2b6d36)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5a47e6['containsUppercaseLetter']||(_0x5a47e6['containsUppercaseLetter']=_0x26265a)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5a47e6['containsNumericCharacter']||(_0x5a47e6['containsNumericCharacter']=_0x470192)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5a47e6['containsNonAlphanumericCharacter']||(_0x5a47e6['containsNonAlphanumericCharacter']=_0x12af8a));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x208aac,_0x5033f4,_0x23fdca,_0x2d402e){this['app']=_0x208aac,this['heartbeatServiceProvider']=_0x5033f4,this['appCheckServiceProvider']=_0x23fdca,this['config']=_0x2d402e,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x208aac['name'],this['clientVersion']=_0x2d402e['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0xf1eb9f=>this['_resolvePersistenceManagerAvailable']=_0xf1eb9f);}['_initializeWithPersistence'](_0x331b45,_0x4b9103){return _0x4b9103&&(this['_popupRedirectResolver']=ie(_0x4b9103)),this['_initializationPromise']=this['queue'](async()=>{var _0x180b32,_0x4066a6,_0x478ff5;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x331b45),(_0x180b32=this['_resolvePersistenceManagerAvailable'])==null||_0x180b32['call'](this),!this['_deleted'])){if((_0x4066a6=this['_popupRedirectResolver'])!=null&&_0x4066a6['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x4b9103),this['lastNotifiedUid']=((_0x478ff5=this['currentUser'])==null?void 0x0:_0x478ff5['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x323681=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x323681)){if(this['currentUser']&&_0x323681&&this['currentUser']['uid']===_0x323681['uid']){this['_currentUser']['_assign'](_0x323681),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x323681,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x5ef908){try{const _0x56c0b8=await bn(this,{'idToken':_0x5ef908}),_0x4662da=await K['_fromGetAccountInfoResponse'](this,_0x56c0b8,_0x5ef908);await this['directlySetCurrentUser'](_0x4662da);}catch(_0x6a2c85){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x6a2c85),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0xdf85f3){var _0x10487b;if($(this['app'])){const _0x2e977c=this['app']['settings']['authIdToken'];return _0x2e977c?new Promise(_0x333be8=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2e977c)['then'](_0x333be8,_0x333be8));}):this['directlySetCurrentUser'](null);}const _0x10331d=await this['assertedPersistence']['getCurrentUser']();let _0x5c9d72=_0x10331d,_0x35fb13=!0x1;if(_0xdf85f3&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0xba8088=(_0x10487b=this['redirectUser'])==null?void 0x0:_0x10487b['_redirectEventId'],_0x57f86c=_0x5c9d72==null?void 0x0:_0x5c9d72['_redirectEventId'],_0x2ccef8=await this['tryRedirectSignIn'](_0xdf85f3);(!_0xba8088||_0xba8088===_0x57f86c)&&(_0x2ccef8!=null&&_0x2ccef8['user'])&&(_0x5c9d72=_0x2ccef8['user'],_0x35fb13=!0x0);}if(!_0x5c9d72)return this['directlySetCurrentUser'](null);if(!_0x5c9d72['_redirectEventId']){if(_0x35fb13)try{await this['beforeStateQueue']['runMiddleware'](_0x5c9d72);}catch(_0x25cd7e){_0x5c9d72=_0x10331d,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x25cd7e));}return _0x5c9d72?this['reloadAndSetCurrentUserOrClear'](_0x5c9d72):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x5c9d72['_redirectEventId']?this['directlySetCurrentUser'](_0x5c9d72):this['reloadAndSetCurrentUserOrClear'](_0x5c9d72);}async['tryRedirectSignIn'](_0x344d26){let _0x58564e=null;try{_0x58564e=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x344d26,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x58564e;}async['reloadAndSetCurrentUserOrClear'](_0x32d72f){try{await Rn(_0x32d72f);}catch(_0xb86a11){if((_0xb86a11==null?void 0x0:_0xb86a11['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x32d72f);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x960ec8){if($(this['app']))return Promise['reject'](re(this));const _0x545f37=_0x960ec8?N(_0x960ec8):null;return _0x545f37&&m(_0x545f37['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x545f37&&_0x545f37['_clone'](this));}async['_updateCurrentUser'](_0x53c550,_0x4c6a4e=!0x1){if(!this['_deleted'])return _0x53c550&&m(this['tenantId']===_0x53c550['tenantId'],this,'tenant-id-mismatch'),_0x4c6a4e||await this['beforeStateQueue']['runMiddleware'](_0x53c550),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x53c550),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x45b527){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x45b527));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x1661d8){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x399be7=this['_getPasswordPolicyInternal']();return _0x399be7['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x399be7['validatePassword'](_0x1661d8);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x1ce0e5=await bf(this),_0x55f189=new Af(_0x1ce0e5);this['tenantId']===null?this['_projectPasswordPolicy']=_0x55f189:this['_tenantPasswordPolicies'][this['tenantId']]=_0x55f189;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x527962){this['_errorFactory']=new Bt('auth','Firebase',_0x527962());}['onAuthStateChanged'](_0x389309,_0x2974b9,_0x3fb973){return this['registerStateListener'](this['authStateSubscription'],_0x389309,_0x2974b9,_0x3fb973);}['beforeAuthStateChanged'](_0x37ee8f,_0x70c87f){return this['beforeStateQueue']['pushCallback'](_0x37ee8f,_0x70c87f);}['onIdTokenChanged'](_0x5e4f04,_0x178b52,_0x778cf){return this['registerStateListener'](this['idTokenSubscription'],_0x5e4f04,_0x178b52,_0x778cf);}['authStateReady'](){return new Promise((_0x52dfc1,_0x434565)=>{if(this['currentUser'])_0x52dfc1();else{const _0x3cd8f9=this['onAuthStateChanged'](()=>{_0x3cd8f9(),_0x52dfc1();},_0x434565);}});}async['revokeAccessToken'](_0x5a71e5){if(this['currentUser']){const _0xc1eef2=await this['currentUser']['getIdToken'](),_0x39a120={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x5a71e5,'idToken':_0xc1eef2};this['tenantId']!=null&&(_0x39a120['tenantId']=this['tenantId']),await wf(this,_0x39a120);}}['toJSON'](){var _0x489cec;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x489cec=this['_currentUser'])==null?void 0x0:_0x489cec['toJSON']()};}async['_setRedirectUser'](_0xffd6e3,_0x52f6d4){const _0x417013=await this['getOrInitRedirectPersistenceManager'](_0x52f6d4);return _0xffd6e3===null?_0x417013['removeCurrentUser']():_0x417013['setCurrentUser'](_0xffd6e3);}async['getOrInitRedirectPersistenceManager'](_0x3e1100){if(!this['redirectPersistenceManager']){const _0x44b01f=_0x3e1100&&ie(_0x3e1100)||this['_popupRedirectResolver'];m(_0x44b01f,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x44b01f['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x2a9785){var _0x351777,_0x486b53;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x351777=this['_currentUser'])==null?void 0x0:_0x351777['_redirectEventId'])===_0x2a9785?this['_currentUser']:((_0x486b53=this['redirectUser'])==null?void 0x0:_0x486b53['_redirectEventId'])===_0x2a9785?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2f42fd){if(_0x2f42fd===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2f42fd));}['_notifyListenersIfCurrent'](_0x4f3454){_0x4f3454===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x547ec8;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x24cea3=((_0x547ec8=this['currentUser'])==null?void 0x0:_0x547ec8['uid'])??null;this['lastNotifiedUid']!==_0x24cea3&&(this['lastNotifiedUid']=_0x24cea3,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x22478d,_0x2458df,_0x4cf482,_0x2bf66d){if(this['_deleted'])return()=>{};const _0x386201=typeof _0x2458df=='function'?_0x2458df:_0x2458df['next']['bind'](_0x2458df);let _0x32359c=!0x1;const _0x5222d8=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x5222d8,this,'internal-error'),_0x5222d8['then'](()=>{_0x32359c||_0x386201(this['currentUser']);}),typeof _0x2458df=='function'){const _0x4b009d=_0x22478d['addObserver'](_0x2458df,_0x4cf482,_0x2bf66d);return()=>{_0x32359c=!0x0,_0x4b009d();};}else{const _0x25f81a=_0x22478d['addObserver'](_0x2458df);return()=>{_0x32359c=!0x0,_0x25f81a();};}}async['directlySetCurrentUser'](_0x32dd8a){this['currentUser']&&this['currentUser']!==_0x32dd8a&&this['_currentUser']['_stopProactiveRefresh'](),_0x32dd8a&&this['isProactiveRefreshEnabled']&&_0x32dd8a['_startProactiveRefresh'](),this['currentUser']=_0x32dd8a,_0x32dd8a?await this['assertedPersistence']['setCurrentUser'](_0x32dd8a):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x496bb8){return this['operations']=this['operations']['then'](_0x496bb8,_0x496bb8),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4ec201){!_0x4ec201||this['frameworks']['includes'](_0x4ec201)||(this['frameworks']['push'](_0x4ec201),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x3d27ba;const _0x37365d={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x37365d['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x3ab246=await((_0x3d27ba=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x3d27ba['getHeartbeatsHeader']());_0x3ab246&&(_0x37365d['X-Firebase-Client']=_0x3ab246);const _0x4b4393=await this['_getAppCheckToken']();return _0x4b4393&&(_0x37365d['X-Firebase-AppCheck']=_0x4b4393),_0x37365d;}async['_getAppCheckToken'](){var _0x7095d4;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x10d068=await((_0x7095d4=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x7095d4['getToken']());return _0x10d068!=null&&_0x10d068['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x10d068['error']),_0x10d068==null?void 0x0:_0x10d068['token'];}}function qe(_0x3c4ae4){return N(_0x3c4ae4);}class Rr{constructor(_0x53534e){this['auth']=_0x53534e,this['observer']=null,this['addObserver']=Tc(_0x5c1f1c=>this['observer']=_0x5c1f1c);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x44284f){jn=_0x44284f;}function xa(_0x4a7910){return jn['loadJS'](_0x4a7910);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x3f980a){return'__'+_0x3f980a+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x277d55){_0x277d55();}['execute'](_0x53bf6e,_0x459336){return Promise['resolve']('token');}['render'](_0x5a5aba,_0x79ffc8){return'';}}class Lf{['ready'](_0x4cf1ee){_0x4cf1ee();}['execute'](_0x411fb5,_0xbce614){return Promise['resolve']('token');}['render'](_0xd51f7,_0x5ec29f){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x3c6a22){this['type']=xf,this['auth']=qe(_0x3c6a22);}async['verify'](_0x35628a='verify',_0x5f0f4d=!0x1){async function _0x8ac235(_0x45aa20){if(!_0x5f0f4d){if(_0x45aa20['tenantId']==null&&_0x45aa20['_agentRecaptchaConfig']!=null)return _0x45aa20['_agentRecaptchaConfig']['siteKey'];if(_0x45aa20['tenantId']!=null&&_0x45aa20['_tenantRecaptchaConfigs'][_0x45aa20['tenantId']]!==void 0x0)return _0x45aa20['_tenantRecaptchaConfigs'][_0x45aa20['tenantId']]['siteKey'];}return new Promise(async(_0x403931,_0x355533)=>{pf(_0x45aa20,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x47621a=>{if(_0x47621a['recaptchaKey']===void 0x0)_0x355533(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x2291e9=new ff(_0x47621a);return _0x45aa20['tenantId']==null?_0x45aa20['_agentRecaptchaConfig']=_0x2291e9:_0x45aa20['_tenantRecaptchaConfigs'][_0x45aa20['tenantId']]=_0x2291e9,_0x403931(_0x2291e9['siteKey']);}})['catch'](_0x437812=>{_0x355533(_0x437812);});});}function _0x4a1fc1(_0x21fa6b,_0xb7c370,_0x427fdf){const _0x5f3966=window['grecaptcha'];wr(_0x5f3966)?_0x5f3966['enterprise']['ready'](()=>{_0x5f3966['enterprise']['execute'](_0x21fa6b,{'action':_0x35628a})['then'](_0x3ef552=>{_0xb7c370(_0x3ef552);})['catch'](()=>{_0xb7c370(Fa);});}):_0x427fdf(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x562b15,_0xc8e59b)=>{_0x8ac235(this['auth'])['then'](_0x5ef102=>{if(!_0x5f0f4d&&wr(window['grecaptcha']))_0x4a1fc1(_0x5ef102,_0x562b15,_0xc8e59b);else{if(typeof window>'u'){_0xc8e59b(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x298dcb=Pf();_0x298dcb['length']!==0x0&&(_0x298dcb+=_0x5ef102),xa(_0x298dcb)['then'](()=>{_0x4a1fc1(_0x5ef102,_0x562b15,_0xc8e59b);})['catch'](_0x382227=>{_0xc8e59b(_0x382227);});}})['catch'](_0x173e52=>{_0xc8e59b(_0x173e52);});});}}async function Ar(_0x12df8d,_0x1f6804,_0xe50147,_0x30ce2c=!0x1,_0x34f026=!0x1){const _0xcd4401=new Ff(_0x12df8d);let _0x259656;if(_0x34f026)_0x259656=Fa;else try{_0x259656=await _0xcd4401['verify'](_0xe50147);}catch{_0x259656=await _0xcd4401['verify'](_0xe50147,!0x0);}const _0x1ef0e0={..._0x1f6804};if(_0xe50147==='mfaSmsEnrollment'||_0xe50147==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x1ef0e0){const _0x3c3234=_0x1ef0e0['phoneEnrollmentInfo']['phoneNumber'],_0x3bb72a=_0x1ef0e0['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x1ef0e0,{'phoneEnrollmentInfo':{'phoneNumber':_0x3c3234,'recaptchaToken':_0x3bb72a,'captchaResponse':_0x259656,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x1ef0e0){const _0x424c1b=_0x1ef0e0['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x1ef0e0,{'phoneSignInInfo':{'recaptchaToken':_0x424c1b,'captchaResponse':_0x259656,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x1ef0e0;}return _0x30ce2c?Object['assign'](_0x1ef0e0,{'captchaResp':_0x259656}):Object['assign'](_0x1ef0e0,{'captchaResponse':_0x259656}),Object['assign'](_0x1ef0e0,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x1ef0e0,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x1ef0e0;}async function Di(_0x23a2e8,_0x4c60f3,_0x4d04ed,_0x25ef5a,_0x13ba74){var _0x575fc4;if((_0x575fc4=_0x23a2e8['_getRecaptchaConfig']())!=null&&_0x575fc4['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0xaccbd6=await Ar(_0x23a2e8,_0x4c60f3,_0x4d04ed,_0x4d04ed==='getOobCode');return _0x25ef5a(_0x23a2e8,_0xaccbd6);}else return _0x25ef5a(_0x23a2e8,_0x4c60f3)['catch'](async _0x4ec825=>{if(_0x4ec825['code']==='auth/missing-recaptcha-token'){console['log'](_0x4d04ed+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x43b587=await Ar(_0x23a2e8,_0x4c60f3,_0x4d04ed,_0x4d04ed==='getOobCode');return _0x25ef5a(_0x23a2e8,_0x43b587);}else return Promise['reject'](_0x4ec825);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x2631d9,_0x48d34a){const _0x538b68=Bi(_0x2631d9,'auth');if(_0x538b68['isInitialized']()){const _0x16a394=_0x538b68['getImmediate'](),_0x6ebb47=_0x538b68['getOptions']();if(Me(_0x6ebb47,_0x48d34a??{}))return _0x16a394;Q(_0x16a394,'already-initialized');}return _0x538b68['initialize']({'options':_0x48d34a});}function Wf(_0x47d370,_0x3873b1){const _0x3d73a6=(_0x3873b1==null?void 0x0:_0x3873b1['persistence'])||[],_0x13cd7c=(Array['isArray'](_0x3d73a6)?_0x3d73a6:[_0x3d73a6])['map'](ie);_0x3873b1!=null&&_0x3873b1['errorMap']&&_0x47d370['_updateErrorMap'](_0x3873b1['errorMap']),_0x47d370['_initializeWithPersistence'](_0x13cd7c,_0x3873b1==null?void 0x0:_0x3873b1['popupRedirectResolver']);}function Bf(_0x4e0763,_0x1b8976,_0x26654f){const _0x5c4376=qe(_0x4e0763);m(/^https?:\/\//['test'](_0x1b8976),_0x5c4376,'invalid-emulator-scheme');const _0x428db8=!0x1,_0x569aca=Ua(_0x1b8976),{host:_0x2c9ddc,port:_0x5ef8a6}=Vf(_0x1b8976),_0x271ade=_0x5ef8a6===null?'':':'+_0x5ef8a6,_0x937f01={'url':_0x569aca+'//'+_0x2c9ddc+_0x271ade+'/'},_0x13ea62=Object['freeze']({'host':_0x2c9ddc,'port':_0x5ef8a6,'protocol':_0x569aca['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x428db8})});if(!_0x5c4376['_canInitEmulator']){m(_0x5c4376['config']['emulator']&&_0x5c4376['emulatorConfig'],_0x5c4376,'emulator-config-failed'),m(Me(_0x937f01,_0x5c4376['config']['emulator'])&&Me(_0x13ea62,_0x5c4376['emulatorConfig']),_0x5c4376,'emulator-config-failed');return;}_0x5c4376['config']['emulator']=_0x937f01,_0x5c4376['emulatorConfig']=_0x13ea62,_0x5c4376['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x2c9ddc)?(jr(_0x569aca+'//'+_0x2c9ddc+_0x271ade),Kr('Auth',!0x0)):Hf();}function Ua(_0x2c9cd8){const _0x5e2585=_0x2c9cd8['indexOf'](':');return _0x5e2585<0x0?'':_0x2c9cd8['substr'](0x0,_0x5e2585+0x1);}function Vf(_0x1eda5e){const _0x345e1f=Ua(_0x1eda5e),_0x38e04c=/(\/\/)?([^?#/]+)/['exec'](_0x1eda5e['substr'](_0x345e1f['length']));if(!_0x38e04c)return{'host':'','port':null};const _0x418a8a=_0x38e04c[0x2]['split']('@')['pop']()||'',_0x16b49e=/^(\[[^\]]+\])(:|$)/['exec'](_0x418a8a);if(_0x16b49e){const _0x29b39b=_0x16b49e[0x1];return{'host':_0x29b39b,'port':kr(_0x418a8a['substr'](_0x29b39b['length']+0x1))};}else{const [_0x27acc9,_0x18d08f]=_0x418a8a['split'](':');return{'host':_0x27acc9,'port':kr(_0x18d08f)};}}function kr(_0x5ddc0e){if(!_0x5ddc0e)return null;const _0x4c05e9=Number(_0x5ddc0e);return isNaN(_0x4c05e9)?null:_0x4c05e9;}function Hf(){function _0x569844(){const _0x3a4699=document['createElement']('p'),_0xa09038=_0x3a4699['style'];_0x3a4699['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0xa09038['position']='fixed',_0xa09038['width']='100%',_0xa09038['backgroundColor']='#ffffff',_0xa09038['border']='.1em\x20solid\x20#000000',_0xa09038['color']='#b50000',_0xa09038['bottom']='0px',_0xa09038['left']='0px',_0xa09038['margin']='0px',_0xa09038['zIndex']='10000',_0xa09038['textAlign']='center',_0x3a4699['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x3a4699);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x569844):_0x569844());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x465ce2,_0x5f95c9){this['providerId']=_0x465ce2,this['signInMethod']=_0x5f95c9;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x11d1c5){return ne('not\x20implemented');}['_linkToIdToken'](_0x51a6ac,_0x3c3246){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x39a473){return ne('not\x20implemented');}}async function $f(_0xb98581,_0x370f16){return Ae(_0xb98581,'POST','/v1/accounts:signUp',_0x370f16);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x1e44a3,_0x353f76){return Qt(_0x1e44a3,'POST','/v1/accounts:signInWithPassword',Re(_0x1e44a3,_0x353f76));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x5a44a9,_0x3c977f){return Qt(_0x5a44a9,'POST','/v1/accounts:signInWithEmailLink',Re(_0x5a44a9,_0x3c977f));}async function zf(_0x2aac8c,_0x24438b){return Qt(_0x2aac8c,'POST','/v1/accounts:signInWithEmailLink',Re(_0x2aac8c,_0x24438b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x55f956,_0x3ba046,_0x37d6bc,_0x539f39=null){super('password',_0x37d6bc),this['_email']=_0x55f956,this['_password']=_0x3ba046,this['_tenantId']=_0x539f39;}static['_fromEmailAndPassword'](_0x2d5eed,_0x2b0e65){return new Wt(_0x2d5eed,_0x2b0e65,'password');}static['_fromEmailAndCode'](_0x3d4892,_0xeebada,_0x50ca2d=null){return new Wt(_0x3d4892,_0xeebada,'emailLink',_0x50ca2d);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x52e3d0){const _0x5b7420=typeof _0x52e3d0=='string'?JSON['parse'](_0x52e3d0):_0x52e3d0;if(_0x5b7420!=null&&_0x5b7420['email']&&(_0x5b7420!=null&&_0x5b7420['password'])){if(_0x5b7420['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x5b7420['email'],_0x5b7420['password']);if(_0x5b7420['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x5b7420['email'],_0x5b7420['password'],_0x5b7420['tenantId']);}return null;}async['_getIdTokenResponse'](_0x35227a){switch(this['signInMethod']){case'password':const _0x80d339={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x35227a,_0x80d339,'signInWithPassword',Gf);case'emailLink':return qf(_0x35227a,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x35227a,'internal-error');}}async['_linkToIdToken'](_0x141605,_0x276b5c){switch(this['signInMethod']){case'password':const _0x1d73e4={'idToken':_0x276b5c,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x141605,_0x1d73e4,'signUpPassword',$f);case'emailLink':return zf(_0x141605,{'idToken':_0x276b5c,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x141605,'internal-error');}}['_getReauthenticationResolver'](_0x22a8fc){return this['_getIdTokenResponse'](_0x22a8fc);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x13ca1f,_0x4fd4f3){return Qt(_0x13ca1f,'POST','/v1/accounts:signInWithIdp',Re(_0x13ca1f,_0x4fd4f3));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x3342aa){const _0xd948b7=new Be(_0x3342aa['providerId'],_0x3342aa['signInMethod']);return _0x3342aa['idToken']||_0x3342aa['accessToken']?(_0x3342aa['idToken']&&(_0xd948b7['idToken']=_0x3342aa['idToken']),_0x3342aa['accessToken']&&(_0xd948b7['accessToken']=_0x3342aa['accessToken']),_0x3342aa['nonce']&&!_0x3342aa['pendingToken']&&(_0xd948b7['nonce']=_0x3342aa['nonce']),_0x3342aa['pendingToken']&&(_0xd948b7['pendingToken']=_0x3342aa['pendingToken'])):_0x3342aa['oauthToken']&&_0x3342aa['oauthTokenSecret']?(_0xd948b7['accessToken']=_0x3342aa['oauthToken'],_0xd948b7['secret']=_0x3342aa['oauthTokenSecret']):Q('argument-error'),_0xd948b7;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x4c82ea){const _0x3a97a5=typeof _0x4c82ea=='string'?JSON['parse'](_0x4c82ea):_0x4c82ea,{providerId:_0x32449b,signInMethod:_0x4bc120,..._0xf8e1e0}=_0x3a97a5;if(!_0x32449b||!_0x4bc120)return null;const _0x2d2b97=new Be(_0x32449b,_0x4bc120);return _0x2d2b97['idToken']=_0xf8e1e0['idToken']||void 0x0,_0x2d2b97['accessToken']=_0xf8e1e0['accessToken']||void 0x0,_0x2d2b97['secret']=_0xf8e1e0['secret'],_0x2d2b97['nonce']=_0xf8e1e0['nonce'],_0x2d2b97['pendingToken']=_0xf8e1e0['pendingToken']||null,_0x2d2b97;}['_getIdTokenResponse'](_0x5d491a){const _0x3780ad=this['buildRequest']();return Xe(_0x5d491a,_0x3780ad);}['_linkToIdToken'](_0x245de8,_0x44dcb6){const _0x18e25a=this['buildRequest']();return _0x18e25a['idToken']=_0x44dcb6,Xe(_0x245de8,_0x18e25a);}['_getReauthenticationResolver'](_0x63343b){const _0x949b7f=this['buildRequest']();return _0x949b7f['autoCreate']=!0x1,Xe(_0x63343b,_0x949b7f);}['buildRequest'](){const _0x5be3bc={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x5be3bc['pendingToken']=this['pendingToken'];else{const _0x33bece={};this['idToken']&&(_0x33bece['id_token']=this['idToken']),this['accessToken']&&(_0x33bece['access_token']=this['accessToken']),this['secret']&&(_0x33bece['oauth_token_secret']=this['secret']),_0x33bece['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x33bece['nonce']=this['nonce']),_0x5be3bc['postBody']=ct(_0x33bece);}return _0x5be3bc;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x974b6b){switch(_0x974b6b){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0xd5fb07){const _0x4ba878=vt(Et(_0xd5fb07))['link'],_0x59f967=_0x4ba878?vt(Et(_0x4ba878))['deep_link_id']:null,_0x187c48=vt(Et(_0xd5fb07))['deep_link_id'];return(_0x187c48?vt(Et(_0x187c48))['link']:null)||_0x187c48||_0x59f967||_0x4ba878||_0xd5fb07;}class Rs{constructor(_0x5e92d9){const _0x11517c=vt(Et(_0x5e92d9)),_0x3d5379=_0x11517c['apiKey']??null,_0x5b8000=_0x11517c['oobCode']??null,_0x27d112=Kf(_0x11517c['mode']??null);m(_0x3d5379&&_0x5b8000&&_0x27d112,'argument-error'),this['apiKey']=_0x3d5379,this['operation']=_0x27d112,this['code']=_0x5b8000,this['continueUrl']=_0x11517c['continueUrl']??null,this['languageCode']=_0x11517c['lang']??null,this['tenantId']=_0x11517c['tenantId']??null;}static['parseLink'](_0x1d87d7){const _0x1f2bdc=Yf(_0x1d87d7);try{return new Rs(_0x1f2bdc);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x226cc2,_0x270bf7){return Wt['_fromEmailAndPassword'](_0x226cc2,_0x270bf7);}static['credentialWithLink'](_0x5480df,_0x53d05b){const _0x3ed9da=Rs['parseLink'](_0x53d05b);return m(_0x3ed9da,'argument-error'),Wt['_fromEmailAndCode'](_0x5480df,_0x3ed9da['code'],_0x3ed9da['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x54421c){this['providerId']=_0x54421c,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x5b3320){this['defaultLanguageCode']=_0x5b3320;}['setCustomParameters'](_0x452b8f){return this['customParameters']=_0x452b8f,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5457ef){return this['scopes']['includes'](_0x5457ef)||this['scopes']['push'](_0x5457ef),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x1b23c0){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x1b23c0});}static['credentialFromResult'](_0x41018a){return he['credentialFromTaggedObject'](_0x41018a);}static['credentialFromError'](_0x2d8276){return he['credentialFromTaggedObject'](_0x2d8276['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4d5f1b}){if(!_0x4d5f1b||!('oauthAccessToken'in _0x4d5f1b)||!_0x4d5f1b['oauthAccessToken'])return null;try{return he['credential'](_0x4d5f1b['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x534816,_0x23800a){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x534816,'accessToken':_0x23800a});}static['credentialFromResult'](_0x29becc){return ue['credentialFromTaggedObject'](_0x29becc);}static['credentialFromError'](_0x1d244c){return ue['credentialFromTaggedObject'](_0x1d244c['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x55ccc2}){if(!_0x55ccc2)return null;const {oauthIdToken:_0x40b54f,oauthAccessToken:_0x2dc84f}=_0x55ccc2;if(!_0x40b54f&&!_0x2dc84f)return null;try{return ue['credential'](_0x40b54f,_0x2dc84f);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x1c826d){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x1c826d});}static['credentialFromResult'](_0x3863af){return de['credentialFromTaggedObject'](_0x3863af);}static['credentialFromError'](_0xf3ca82){return de['credentialFromTaggedObject'](_0xf3ca82['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x43fc35}){if(!_0x43fc35||!('oauthAccessToken'in _0x43fc35)||!_0x43fc35['oauthAccessToken'])return null;try{return de['credential'](_0x43fc35['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x1c1f35,_0x5b6eb0){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x1c1f35,'oauthTokenSecret':_0x5b6eb0});}static['credentialFromResult'](_0x3d9651){return fe['credentialFromTaggedObject'](_0x3d9651);}static['credentialFromError'](_0x74dba4){return fe['credentialFromTaggedObject'](_0x74dba4['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x155562}){if(!_0x155562)return null;const {oauthAccessToken:_0x1eaeb2,oauthTokenSecret:_0x2ecb60}=_0x155562;if(!_0x1eaeb2||!_0x2ecb60)return null;try{return fe['credential'](_0x1eaeb2,_0x2ecb60);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x3b7d45,_0x1d6a5c){return Qt(_0x3b7d45,'POST','/v1/accounts:signUp',Re(_0x3b7d45,_0x1d6a5c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x3fd8d2){this['user']=_0x3fd8d2['user'],this['providerId']=_0x3fd8d2['providerId'],this['_tokenResponse']=_0x3fd8d2['_tokenResponse'],this['operationType']=_0x3fd8d2['operationType'];}static async['_fromIdTokenResponse'](_0x29ab1e,_0x285663,_0x2a8504,_0x25baf8=!0x1){const _0x4277b5=await K['_fromIdTokenResponse'](_0x29ab1e,_0x2a8504,_0x25baf8),_0x1ab4c1=Nr(_0x2a8504);return new Ve({'user':_0x4277b5,'providerId':_0x1ab4c1,'_tokenResponse':_0x2a8504,'operationType':_0x285663});}static async['_forOperation'](_0x46fa48,_0x15dde2,_0x5164cf){await _0x46fa48['_updateTokensIfNecessary'](_0x5164cf,!0x0);const _0x36b1ed=Nr(_0x5164cf);return new Ve({'user':_0x46fa48,'providerId':_0x36b1ed,'_tokenResponse':_0x5164cf,'operationType':_0x15dde2});}}function Nr(_0x275cf3){return _0x275cf3['providerId']?_0x275cf3['providerId']:'phoneNumber'in _0x275cf3?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x197d28,_0x44c200,_0x47f360,_0x11489b){super(_0x44c200['code'],_0x44c200['message']),this['operationType']=_0x47f360,this['user']=_0x11489b,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x197d28['name'],'tenantId':_0x197d28['tenantId']??void 0x0,'_serverResponse':_0x44c200['customData']['_serverResponse'],'operationType':_0x47f360};}static['_fromErrorAndOperation'](_0x3b68bf,_0xd3ae07,_0x140c33,_0x5f019b){return new An(_0x3b68bf,_0xd3ae07,_0x140c33,_0x5f019b);}}function Ba(_0x1700ae,_0x2105e8,_0x551c58,_0x16b1eb){return(_0x2105e8==='reauthenticate'?_0x551c58['_getReauthenticationResolver'](_0x1700ae):_0x551c58['_getIdTokenResponse'](_0x1700ae))['catch'](_0x1ba94a=>{throw _0x1ba94a['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x1700ae,_0x1ba94a,_0x2105e8,_0x16b1eb):_0x1ba94a;});}async function Jf(_0x1bf20b,_0x187282,_0x3c7f46=!0x1){const _0x2cd60a=await Ut(_0x1bf20b,_0x187282['_linkToIdToken'](_0x1bf20b['auth'],await _0x1bf20b['getIdToken']()),_0x3c7f46);return Ve['_forOperation'](_0x1bf20b,'link',_0x2cd60a);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x5e254c,_0x16edbf,_0x5da9cf=!0x1){const {auth:_0x3b388b}=_0x5e254c;if($(_0x3b388b['app']))return Promise['reject'](re(_0x3b388b));const _0x1819ef='reauthenticate';try{const _0x2a8dd9=await Ut(_0x5e254c,Ba(_0x3b388b,_0x1819ef,_0x16edbf,_0x5e254c),_0x5da9cf);m(_0x2a8dd9['idToken'],_0x3b388b,'internal-error');const _0x303881=Ts(_0x2a8dd9['idToken']);m(_0x303881,_0x3b388b,'internal-error');const {sub:_0x12cb8b}=_0x303881;return m(_0x5e254c['uid']===_0x12cb8b,_0x3b388b,'user-mismatch'),Ve['_forOperation'](_0x5e254c,_0x1819ef,_0x2a8dd9);}catch(_0x1dd7a5){throw(_0x1dd7a5==null?void 0x0:_0x1dd7a5['code'])==='auth/user-not-found'&&Q(_0x3b388b,'user-mismatch'),_0x1dd7a5;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x162d65,_0x8810fe,_0x5468b2=!0x1){if($(_0x162d65['app']))return Promise['reject'](re(_0x162d65));const _0x360ada='signIn',_0x1dc087=await Ba(_0x162d65,_0x360ada,_0x8810fe),_0x1adf3c=await Ve['_fromIdTokenResponse'](_0x162d65,_0x360ada,_0x1dc087);return _0x5468b2||await _0x162d65['_updateCurrentUser'](_0x1adf3c['user']),_0x1adf3c;}async function Zf(_0x2772bc,_0x3716ab){return Va(qe(_0x2772bc),_0x3716ab);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x5631bc){const _0x4d6ab6=qe(_0x5631bc);_0x4d6ab6['_getPasswordPolicyInternal']()&&await _0x4d6ab6['_updatePasswordPolicy']();}async function P_(_0x280fc2,_0x596929,_0x1f6498){if($(_0x280fc2['app']))return Promise['reject'](re(_0x280fc2));const _0xb85a5b=qe(_0x280fc2),_0x1e4a30=await Di(_0xb85a5b,{'returnSecureToken':!0x0,'email':_0x596929,'password':_0x1f6498,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x5f113f=>{throw _0x5f113f['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x280fc2),_0x5f113f;}),_0x5a36b7=await Ve['_fromIdTokenResponse'](_0xb85a5b,'signIn',_0x1e4a30);return await _0xb85a5b['_updateCurrentUser'](_0x5a36b7['user']),_0x5a36b7;}function O_(_0x41e590,_0x511a56,_0x55b3ca){return $(_0x41e590['app'])?Promise['reject'](re(_0x41e590)):Zf(N(_0x41e590),pt['credential'](_0x511a56,_0x55b3ca))['catch'](async _0x53026a=>{throw _0x53026a['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x41e590),_0x53026a;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x4c8f9d,_0xef530e){return N(_0x4c8f9d)['setPersistence'](_0xef530e);}function ep(_0x5067ed,_0x4749b9,_0x1a1cdc,_0x41e684){return N(_0x5067ed)['onIdTokenChanged'](_0x4749b9,_0x1a1cdc,_0x41e684);}function tp(_0xffdb19,_0x26f891,_0x440777){return N(_0xffdb19)['beforeAuthStateChanged'](_0x26f891,_0x440777);}function M_(_0x1a3e3f,_0x3d7dab,_0x175099,_0x5bdf8d){return N(_0x1a3e3f)['onAuthStateChanged'](_0x3d7dab,_0x175099,_0x5bdf8d);}function L_(_0x261b7a){return N(_0x261b7a)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x55b396,_0x38f74b){this['storageRetriever']=_0x55b396,this['type']=_0x38f74b;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x54de95,_0x1c87ff){return this['storage']['setItem'](_0x54de95,JSON['stringify'](_0x1c87ff)),Promise['resolve']();}['_get'](_0x32b8af){const _0x2dc45c=this['storage']['getItem'](_0x32b8af);return Promise['resolve'](_0x2dc45c?JSON['parse'](_0x2dc45c):null);}['_remove'](_0x555346){return this['storage']['removeItem'](_0x555346),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x3eb9e8,_0xd9bf15)=>this['onStorageEvent'](_0x3eb9e8,_0xd9bf15),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x3f9c82){for(const _0x1881c5 of Object['keys'](this['listeners'])){const _0x1e49e5=this['storage']['getItem'](_0x1881c5),_0x3ab339=this['localCache'][_0x1881c5];_0x1e49e5!==_0x3ab339&&_0x3f9c82(_0x1881c5,_0x3ab339,_0x1e49e5);}}['onStorageEvent'](_0x550a20,_0x1f3024=!0x1){if(!_0x550a20['key']){this['forAllChangedKeys']((_0x35f669,_0x2dcb15,_0x120a11)=>{this['notifyListeners'](_0x35f669,_0x120a11);});return;}const _0x1c52d7=_0x550a20['key'];_0x1f3024?this['detachListener']():this['stopPolling']();const _0x4e27e5=()=>{const _0x38c4e1=this['storage']['getItem'](_0x1c52d7);!_0x1f3024&&this['localCache'][_0x1c52d7]===_0x38c4e1||this['notifyListeners'](_0x1c52d7,_0x38c4e1);},_0x46ac15=this['storage']['getItem'](_0x1c52d7);Tf()&&_0x46ac15!==_0x550a20['newValue']&&_0x550a20['newValue']!==_0x550a20['oldValue']?setTimeout(_0x4e27e5,ip):_0x4e27e5();}['notifyListeners'](_0x6df47c,_0x55cd1f){this['localCache'][_0x6df47c]=_0x55cd1f;const _0x5c2a4b=this['listeners'][_0x6df47c];if(_0x5c2a4b){for(const _0x5772e7 of Array['from'](_0x5c2a4b))_0x5772e7(_0x55cd1f&&JSON['parse'](_0x55cd1f));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x429dfb,_0x57bb0b,_0x4243a8)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x429dfb,'oldValue':_0x57bb0b,'newValue':_0x4243a8}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x1d79c2,_0x2a82ad){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x1d79c2]||(this['listeners'][_0x1d79c2]=new Set(),this['localCache'][_0x1d79c2]=this['storage']['getItem'](_0x1d79c2)),this['listeners'][_0x1d79c2]['add'](_0x2a82ad);}['_removeListener'](_0x31833c,_0x5703db){this['listeners'][_0x31833c]&&(this['listeners'][_0x31833c]['delete'](_0x5703db),this['listeners'][_0x31833c]['size']===0x0&&delete this['listeners'][_0x31833c]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x1fd6be,_0x369294){await super['_set'](_0x1fd6be,_0x369294),this['localCache'][_0x1fd6be]=JSON['stringify'](_0x369294);}async['_get'](_0x1f4bd2){const _0x5b8c4d=await super['_get'](_0x1f4bd2);return this['localCache'][_0x1f4bd2]=JSON['stringify'](_0x5b8c4d),_0x5b8c4d;}async['_remove'](_0x2bc266){await super['_remove'](_0x2bc266),delete this['localCache'][_0x2bc266];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x4dd95b,_0x40e4e0){}['_removeListener'](_0xf9041a,_0x5cf09e){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x2dfe5b){return Promise['all'](_0x2dfe5b['map'](async _0x113d64=>{try{return{'fulfilled':!0x0,'value':await _0x113d64};}catch(_0x2c103c){return{'fulfilled':!0x1,'reason':_0x2c103c};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x88c1d9){this['eventTarget']=_0x88c1d9,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x5621bf){const _0x5b5eb6=this['receivers']['find'](_0x2eae5b=>_0x2eae5b['isListeningto'](_0x5621bf));if(_0x5b5eb6)return _0x5b5eb6;const _0x296cc7=new Kn(_0x5621bf);return this['receivers']['push'](_0x296cc7),_0x296cc7;}['isListeningto'](_0x499732){return this['eventTarget']===_0x499732;}async['handleEvent'](_0x37eb07){const _0x21cb82=_0x37eb07,{eventId:_0x39cbd5,eventType:_0x554791,data:_0x442334}=_0x21cb82['data'],_0x4a5232=this['handlersMap'][_0x554791];if(!(_0x4a5232!=null&&_0x4a5232['size']))return;_0x21cb82['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x39cbd5,'eventType':_0x554791});const _0x4fe9c1=Array['from'](_0x4a5232)['map'](async _0x4d9abf=>_0x4d9abf(_0x21cb82['origin'],_0x442334)),_0x1513a3=await rp(_0x4fe9c1);_0x21cb82['ports'][0x0]['postMessage']({'status':'done','eventId':_0x39cbd5,'eventType':_0x554791,'response':_0x1513a3});}['_subscribe'](_0x126b0c,_0x51cad2){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x126b0c]||(this['handlersMap'][_0x126b0c]=new Set()),this['handlersMap'][_0x126b0c]['add'](_0x51cad2);}['_unsubscribe'](_0x3890d9,_0x1e50e8){this['handlersMap'][_0x3890d9]&&_0x1e50e8&&this['handlersMap'][_0x3890d9]['delete'](_0x1e50e8),(!_0x1e50e8||this['handlersMap'][_0x3890d9]['size']===0x0)&&delete this['handlersMap'][_0x3890d9],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x267c3a='',_0x44bab2=0xa){let _0x58ccdd='';for(let _0x2a3256=0x0;_0x2a3256<_0x44bab2;_0x2a3256++)_0x58ccdd+=Math['floor'](Math['random']()*0xa);return _0x267c3a+_0x58ccdd;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x3b7d51){this['target']=_0x3b7d51,this['handlers']=new Set();}['removeMessageHandler'](_0x574f53){_0x574f53['messageChannel']&&(_0x574f53['messageChannel']['port1']['removeEventListener']('message',_0x574f53['onMessage']),_0x574f53['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x574f53);}async['_send'](_0x1eb1b3,_0x17a61b,_0x4c6d36=0x32){const _0x3bf381=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x3bf381)throw new Error('connection_unavailable');let _0x34b841,_0x31e47e;return new Promise((_0x29bb34,_0x59f074)=>{const _0x34c58b=As('',0x14);_0x3bf381['port1']['start']();const _0xd52bb1=setTimeout(()=>{_0x59f074(new Error('unsupported_event'));},_0x4c6d36);_0x31e47e={'messageChannel':_0x3bf381,'onMessage'(_0x3fd6d3){const _0x5ee698=_0x3fd6d3;if(_0x5ee698['data']['eventId']===_0x34c58b)switch(_0x5ee698['data']['status']){case'ack':clearTimeout(_0xd52bb1),_0x34b841=setTimeout(()=>{_0x59f074(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x34b841),_0x29bb34(_0x5ee698['data']['response']);break;default:clearTimeout(_0xd52bb1),clearTimeout(_0x34b841),_0x59f074(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x31e47e),_0x3bf381['port1']['addEventListener']('message',_0x31e47e['onMessage']),this['target']['postMessage']({'eventType':_0x1eb1b3,'eventId':_0x34c58b,'data':_0x17a61b},[_0x3bf381['port2']]);})['finally'](()=>{_0x31e47e&&this['removeMessageHandler'](_0x31e47e);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x46972c){Z()['location']['href']=_0x46972c;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x55630d;return((_0x55630d=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x55630d['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x2034d6){this['request']=_0x2034d6;}['toPromise'](){return new Promise((_0x579d10,_0x15c4c3)=>{this['request']['addEventListener']('success',()=>{_0x579d10(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x15c4c3(this['request']['error']);});});}}function Yn(_0xb7e83c,_0x50ca72){return _0xb7e83c['transaction']([Nn],_0x50ca72?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x3fb3d9=indexedDB['deleteDatabase'](Ka);return new Xt(_0x3fb3d9)['toPromise']();}function Mi(){const _0x3aee6e=indexedDB['open'](Ka,up);return new Promise((_0x1258b8,_0x46814f)=>{_0x3aee6e['addEventListener']('error',()=>{_0x46814f(_0x3aee6e['error']);}),_0x3aee6e['addEventListener']('upgradeneeded',()=>{const _0x419e2e=_0x3aee6e['result'];try{_0x419e2e['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x2339b8){_0x46814f(_0x2339b8);}}),_0x3aee6e['addEventListener']('success',async()=>{const _0x1b3849=_0x3aee6e['result'];_0x1b3849['objectStoreNames']['contains'](Nn)?_0x1258b8(_0x1b3849):(_0x1b3849['close'](),await dp(),_0x1258b8(await Mi()));});});}async function Pr(_0x5c66f7,_0x581fce,_0x43aeb3){const _0x256073=Yn(_0x5c66f7,!0x0)['put']({[Ya]:_0x581fce,'value':_0x43aeb3});return new Xt(_0x256073)['toPromise']();}async function fp(_0x1ef98d,_0x25e284){const _0x25951b=Yn(_0x1ef98d,!0x1)['get'](_0x25e284),_0x1f8bbe=await new Xt(_0x25951b)['toPromise']();return _0x1f8bbe===void 0x0?null:_0x1f8bbe['value'];}function Or(_0x33ea3b,_0x5c6f08){const _0xcbc4ac=Yn(_0x33ea3b,!0x0)['delete'](_0x5c6f08);return new Xt(_0xcbc4ac)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x2a1a09){let _0xf859c0=0x0;for(;;)try{const _0x55ff82=await this['_openDb']();return await _0x2a1a09(_0x55ff82);}catch(_0x31c4ca){if(_0xf859c0++>_p)throw _0x31c4ca;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x25ebdb,_0xa2244)=>({'keyProcessed':(await this['_poll']())['includes'](_0xa2244['key'])})),this['receiver']['_subscribe']('ping',async(_0x556894,_0x80e136)=>['keyChanged']);}async['initializeSender'](){var _0x136439,_0x511e4c;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x3722d8=await this['sender']['_send']('ping',{},0x320);_0x3722d8&&(_0x136439=_0x3722d8[0x0])!=null&&_0x136439['fulfilled']&&(_0x511e4c=_0x3722d8[0x0])!=null&&_0x511e4c['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x36893b){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x36893b},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x5eeb4f=await Mi();return await Pr(_0x5eeb4f,kn,'1'),await Or(_0x5eeb4f,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x27e3ff){this['pendingWrites']++;try{await _0x27e3ff();}finally{this['pendingWrites']--;}}async['_set'](_0x120019,_0x2f1709){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3a5eed=>Pr(_0x3a5eed,_0x120019,_0x2f1709)),this['localCache'][_0x120019]=_0x2f1709,this['notifyServiceWorker'](_0x120019)));}async['_get'](_0x4eb48a){const _0x23dd4a=await this['_withRetries'](_0x124911=>fp(_0x124911,_0x4eb48a));return this['localCache'][_0x4eb48a]=_0x23dd4a,_0x23dd4a;}async['_remove'](_0x318b54){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x25dd7b=>Or(_0x25dd7b,_0x318b54)),delete this['localCache'][_0x318b54],this['notifyServiceWorker'](_0x318b54)));}async['_poll'](){const _0x371498=await this['_withRetries'](_0x21a146=>{const _0x38a0ff=Yn(_0x21a146,!0x1)['getAll']();return new Xt(_0x38a0ff)['toPromise']();});if(!_0x371498)return[];if(this['pendingWrites']!==0x0)return[];const _0xcc0709=[],_0x1fb00b=new Set();if(_0x371498['length']!==0x0){for(const {fbase_key:_0x1daef8,value:_0xb44b07}of _0x371498)_0x1fb00b['add'](_0x1daef8),JSON['stringify'](this['localCache'][_0x1daef8])!==JSON['stringify'](_0xb44b07)&&(this['notifyListeners'](_0x1daef8,_0xb44b07),_0xcc0709['push'](_0x1daef8));}for(const _0x2a1df5 of Object['keys'](this['localCache']))this['localCache'][_0x2a1df5]&&!_0x1fb00b['has'](_0x2a1df5)&&(this['notifyListeners'](_0x2a1df5,null),_0xcc0709['push'](_0x2a1df5));return _0xcc0709;}['notifyListeners'](_0x402dd1,_0x4c7189){this['localCache'][_0x402dd1]=_0x4c7189;const _0x50900b=this['listeners'][_0x402dd1];if(_0x50900b){for(const _0x2704fb of Array['from'](_0x50900b))_0x2704fb(_0x4c7189);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x3f3ee3,_0x25cc7f){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x3f3ee3]||(this['listeners'][_0x3f3ee3]=new Set(),this['_get'](_0x3f3ee3)),this['listeners'][_0x3f3ee3]['add'](_0x25cc7f);}['_removeListener'](_0x5a0a65,_0xccfb9b){this['listeners'][_0x5a0a65]&&(this['listeners'][_0x5a0a65]['delete'](_0xccfb9b),this['listeners'][_0x5a0a65]['size']===0x0&&delete this['listeners'][_0x5a0a65]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x53b2c6,_0x491776){return _0x491776?ie(_0x491776):(m(_0x53b2c6['_popupRedirectResolver'],_0x53b2c6,'argument-error'),_0x53b2c6['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x2fac26){super('custom','custom'),this['params']=_0x2fac26;}['_getIdTokenResponse'](_0x1ef856){return Xe(_0x1ef856,this['_buildIdpRequest']());}['_linkToIdToken'](_0x3d1505,_0x5bcab8){return Xe(_0x3d1505,this['_buildIdpRequest'](_0x5bcab8));}['_getReauthenticationResolver'](_0x49940d){return Xe(_0x49940d,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x49610e){const _0xf968a2={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x49610e&&(_0xf968a2['idToken']=_0x49610e),_0xf968a2;}}function yp(_0x29851e){return Va(_0x29851e['auth'],new ks(_0x29851e),_0x29851e['bypassAuthState']);}function vp(_0x48dec9){const {auth:_0x58c04b,user:_0x247d47}=_0x48dec9;return m(_0x247d47,_0x58c04b,'internal-error'),Xf(_0x247d47,new ks(_0x48dec9),_0x48dec9['bypassAuthState']);}async function Ep(_0x192039){const {auth:_0x3a9b34,user:_0x2aebc2}=_0x192039;return m(_0x2aebc2,_0x3a9b34,'internal-error'),Jf(_0x2aebc2,new ks(_0x192039),_0x192039['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x2f2b3e,_0x46cf5e,_0x5e844a,_0x4d3997,_0xd07d61=!0x1){this['auth']=_0x2f2b3e,this['resolver']=_0x5e844a,this['user']=_0x4d3997,this['bypassAuthState']=_0xd07d61,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x46cf5e)?_0x46cf5e:[_0x46cf5e];}['execute'](){return new Promise(async(_0x2426ac,_0x1d8e39)=>{this['pendingPromise']={'resolve':_0x2426ac,'reject':_0x1d8e39};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0xf495f){this['reject'](_0xf495f);}});}async['onAuthEvent'](_0x2be4d){const {urlResponse:_0x3228a0,sessionId:_0x4d2136,postBody:_0x55103b,tenantId:_0x40595c,error:_0x5f02c6,type:_0x50ded3}=_0x2be4d;if(_0x5f02c6){this['reject'](_0x5f02c6);return;}const _0x306c2b={'auth':this['auth'],'requestUri':_0x3228a0,'sessionId':_0x4d2136,'tenantId':_0x40595c||void 0x0,'postBody':_0x55103b||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x50ded3)(_0x306c2b));}catch(_0x8755c6){this['reject'](_0x8755c6);}}['onError'](_0xd788b9){this['reject'](_0xd788b9);}['getIdpTask'](_0x4895d2){switch(_0x4895d2){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x51a476){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x51a476),this['unregisterAndCleanUp']();}['reject'](_0x5c0a40){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x5c0a40),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x38036a,_0x4925b1,_0x107720,_0x20deba,_0x241afe){super(_0x38036a,_0x4925b1,_0x20deba,_0x241afe),this['provider']=_0x107720,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x294227=await this['execute']();return m(_0x294227,this['auth'],'internal-error'),_0x294227;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x198217=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x198217),this['authWindow']['associatedEvent']=_0x198217,this['resolver']['_originValidation'](this['auth'])['catch'](_0x3e294f=>{this['reject'](_0x3e294f);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x1130d0=>{_0x1130d0||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x1ef4f0;return((_0x1ef4f0=this['authWindow'])==null?void 0x0:_0x1ef4f0['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x3d15bc=()=>{var _0x4b26bd,_0x524693;if((_0x524693=(_0x4b26bd=this['authWindow'])==null?void 0x0:_0x4b26bd['window'])!=null&&_0x524693['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x3d15bc,Ip['get']());};_0x3d15bc();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x4222e2,_0x5260cd,_0x3c91f8=!0x1){super(_0x4222e2,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x5260cd,void 0x0,_0x3c91f8),this['eventId']=null;}async['execute'](){let _0x328766=on['get'](this['auth']['_key']());if(!_0x328766){try{const _0x47d7df=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x328766=()=>Promise['resolve'](_0x47d7df);}catch(_0x59ed2e){_0x328766=()=>Promise['reject'](_0x59ed2e);}on['set'](this['auth']['_key'](),_0x328766);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x328766();}async['onAuthEvent'](_0x168977){if(_0x168977['type']==='signInViaRedirect')return super['onAuthEvent'](_0x168977);if(_0x168977['type']==='unknown'){this['resolve'](null);return;}if(_0x168977['eventId']){const _0x466d61=await this['auth']['_redirectUserForId'](_0x168977['eventId']);if(_0x466d61)return this['user']=_0x466d61,super['onAuthEvent'](_0x168977);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x526a44,_0x1809bc){const _0x29dadc=Rp(_0x1809bc),_0x1d682d=bp(_0x526a44);if(!await _0x1d682d['_isAvailable']())return!0x1;const _0x4ca1fe=await _0x1d682d['_get'](_0x29dadc)==='true';return await _0x1d682d['_remove'](_0x29dadc),_0x4ca1fe;}function Sp(_0x371a7b,_0x1f9f5c){on['set'](_0x371a7b['_key'](),_0x1f9f5c);}function bp(_0x466e98){return ie(_0x466e98['_redirectPersistence']);}function Rp(_0x33f14a){return rn(wp,_0x33f14a['config']['apiKey'],_0x33f14a['name']);}async function Ap(_0x32d9dc,_0xaa694a,_0x5b6435=!0x1){if($(_0x32d9dc['app']))return Promise['reject'](re(_0x32d9dc));const _0x3e56e8=qe(_0x32d9dc),_0x4c0206=mp(_0x3e56e8,_0xaa694a),_0x3e14f8=await new Cp(_0x3e56e8,_0x4c0206,_0x5b6435)['execute']();return _0x3e14f8&&!_0x5b6435&&(delete _0x3e14f8['user']['_redirectEventId'],await _0x3e56e8['_persistUserIfCurrent'](_0x3e14f8['user']),await _0x3e56e8['_setRedirectUser'](null,_0xaa694a)),_0x3e14f8;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x2d4177){this['auth']=_0x2d4177,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0xe627c6){this['consumers']['add'](_0xe627c6),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0xe627c6)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0xe627c6),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x102896){this['consumers']['delete'](_0x102896);}['onEvent'](_0x31b4a4){if(this['hasEventBeenHandled'](_0x31b4a4))return!0x1;let _0x2c003d=!0x1;return this['consumers']['forEach'](_0x3377d4=>{this['isEventForConsumer'](_0x31b4a4,_0x3377d4)&&(_0x2c003d=!0x0,this['sendToConsumer'](_0x31b4a4,_0x3377d4),this['saveEventToCache'](_0x31b4a4));}),this['hasHandledPotentialRedirect']||!Pp(_0x31b4a4)||(this['hasHandledPotentialRedirect']=!0x0,_0x2c003d||(this['queuedRedirectEvent']=_0x31b4a4,_0x2c003d=!0x0)),_0x2c003d;}['sendToConsumer'](_0x5c7fd0,_0x45de5e){var _0x2620d7;if(_0x5c7fd0['error']&&!Xa(_0x5c7fd0)){const _0x5aaefc=((_0x2620d7=_0x5c7fd0['error']['code'])==null?void 0x0:_0x2620d7['split']('auth/')[0x1])||'internal-error';_0x45de5e['onError'](X(this['auth'],_0x5aaefc));}else _0x45de5e['onAuthEvent'](_0x5c7fd0);}['isEventForConsumer'](_0x204b39,_0x463c25){const _0xc8b44=_0x463c25['eventId']===null||!!_0x204b39['eventId']&&_0x204b39['eventId']===_0x463c25['eventId'];return _0x463c25['filter']['includes'](_0x204b39['type'])&&_0xc8b44;}['hasEventBeenHandled'](_0x22e7b4){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x22e7b4));}['saveEventToCache'](_0xfd8bcf){this['cachedEventUids']['add'](Dr(_0xfd8bcf)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x4bac9e){return[_0x4bac9e['type'],_0x4bac9e['eventId'],_0x4bac9e['sessionId'],_0x4bac9e['tenantId']]['filter'](_0x4fb953=>_0x4fb953)['join']('-');}function Xa({type:_0x43bb35,error:_0x580772}){return _0x43bb35==='unknown'&&(_0x580772==null?void 0x0:_0x580772['code'])==='auth/no-auth-event';}function Pp(_0x1cea1e){switch(_0x1cea1e['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x1cea1e);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x414cd7,_0x1cb6ea={}){return Ae(_0x414cd7,'GET','/v1/projects',_0x1cb6ea);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x36073c){if(_0x36073c['config']['emulator'])return;const {authorizedDomains:_0x5e1e9a}=await Op(_0x36073c);for(const _0x145c5d of _0x5e1e9a)try{if(xp(_0x145c5d))return;}catch{}Q(_0x36073c,'unauthorized-domain');}function xp(_0xb89edd){const _0x3a9fb0=Pi(),{protocol:_0x4c6353,hostname:_0x3b2155}=new URL(_0x3a9fb0);if(_0xb89edd['startsWith']('chrome-extension://')){const _0x4e16ba=new URL(_0xb89edd);return _0x4e16ba['hostname']===''&&_0x3b2155===''?_0x4c6353==='chrome-extension:'&&_0xb89edd['replace']('chrome-extension://','')===_0x3a9fb0['replace']('chrome-extension://',''):_0x4c6353==='chrome-extension:'&&_0x4e16ba['hostname']===_0x3b2155;}if(!Mp['test'](_0x4c6353))return!0x1;if(Dp['test'](_0xb89edd))return _0x3b2155===_0xb89edd;const _0x2f15af=_0xb89edd['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x2f15af+'|'+_0x2f15af+')$','i')['test'](_0x3b2155);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x486a0b=Z()['___jsl'];if(_0x486a0b!=null&&_0x486a0b['H']){for(const _0xda041a of Object['keys'](_0x486a0b['H']))if(_0x486a0b['H'][_0xda041a]['r']=_0x486a0b['H'][_0xda041a]['r']||[],_0x486a0b['H'][_0xda041a]['L']=_0x486a0b['H'][_0xda041a]['L']||[],_0x486a0b['H'][_0xda041a]['r']=[..._0x486a0b['H'][_0xda041a]['L']],_0x486a0b['CP']){for(let _0x4f0212=0x0;_0x4f0212<_0x486a0b['CP']['length'];_0x4f0212++)_0x486a0b['CP'][_0x4f0212]=null;}}}function Up(_0x2c1ab9){return new Promise((_0x32ae8f,_0x54e6c2)=>{var _0x13a953,_0x471ee0,_0x533bf2;function _0x4aafbf(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x32ae8f(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x54e6c2(X(_0x2c1ab9,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x471ee0=(_0x13a953=Z()['gapi'])==null?void 0x0:_0x13a953['iframes'])!=null&&_0x471ee0['Iframe'])_0x32ae8f(gapi['iframes']['getContext']());else{if((_0x533bf2=Z()['gapi'])!=null&&_0x533bf2['load'])_0x4aafbf();else{const _0x58e2d5=Df('iframefcb');return Z()[_0x58e2d5]=()=>{gapi['load']?_0x4aafbf():_0x54e6c2(X(_0x2c1ab9,'network-request-failed'));},xa(Of()+'?onload='+_0x58e2d5)['catch'](_0x5113f2=>_0x54e6c2(_0x5113f2));}}})['catch'](_0x4d498c=>{throw an=null,_0x4d498c;});}let an=null;function Wp(_0x29d221){return an=an||Up(_0x29d221),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x141cfc){const _0x21ffe1=_0x141cfc['config'];m(_0x21ffe1['authDomain'],_0x141cfc,'auth-domain-config-required');const _0x15da38=_0x21ffe1['emulator']?Cs(_0x21ffe1,Hp):'https://'+_0x141cfc['config']['authDomain']+'/'+Vp,_0x55b58e={'apiKey':_0x21ffe1['apiKey'],'appName':_0x141cfc['name'],'v':lt},_0x3c0024=Gp['get'](_0x141cfc['config']['apiHost']);_0x3c0024&&(_0x55b58e['eid']=_0x3c0024);const _0x455c31=_0x141cfc['_getFrameworks']();return _0x455c31['length']&&(_0x55b58e['fw']=_0x455c31['join'](',')),_0x15da38+'?'+ct(_0x55b58e)['slice'](0x1);}async function zp(_0x3912d1){const _0x18277d=await Wp(_0x3912d1),_0x429efd=Z()['gapi'];return m(_0x429efd,_0x3912d1,'internal-error'),_0x18277d['open']({'where':document['body'],'url':qp(_0x3912d1),'messageHandlersFilter':_0x429efd['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x466c7f=>new Promise(async(_0x4e476a,_0x252d23)=>{await _0x466c7f['restyle']({'setHideOnLeave':!0x1});const _0x2d8bc9=X(_0x3912d1,'network-request-failed'),_0x7cae1b=Z()['setTimeout'](()=>{_0x252d23(_0x2d8bc9);},Bp['get']());function _0x4eeed2(){Z()['clearTimeout'](_0x7cae1b),_0x4e476a(_0x466c7f);}_0x466c7f['ping'](_0x4eeed2)['then'](_0x4eeed2,()=>{_0x252d23(_0x2d8bc9);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x48f8ea){this['window']=_0x48f8ea,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x5dfcba,_0x234358,_0x5d0e82,_0x50588a=Kp,_0x4339ed=Yp){const _0x3047e8=Math['max']((window['screen']['availHeight']-_0x4339ed)/0x2,0x0)['toString'](),_0x2e17ef=Math['max']((window['screen']['availWidth']-_0x50588a)/0x2,0x0)['toString']();let _0x151bdb='';const _0xff1fb9={...jp,'width':_0x50588a['toString'](),'height':_0x4339ed['toString'](),'top':_0x3047e8,'left':_0x2e17ef},_0x319ffa=W()['toLowerCase']();_0x5d0e82&&(_0x151bdb=ka(_0x319ffa)?Qp:_0x5d0e82),Ra(_0x319ffa)&&(_0x234358=_0x234358||Jp,_0xff1fb9['scrollbars']='yes');const _0x3e9413=Object['entries'](_0xff1fb9)['reduce']((_0x927349,[_0x37ce52,_0x3325ea])=>''+_0x927349+_0x37ce52+'='+_0x3325ea+',','');if(Cf(_0x319ffa)&&_0x151bdb!=='_self')return Zp(_0x234358||'',_0x151bdb),new Lr(null);const _0x392720=window['open'](_0x234358||'',_0x151bdb,_0x3e9413);m(_0x392720,_0x5dfcba,'popup-blocked');try{_0x392720['focus']();}catch{}return new Lr(_0x392720);}function Zp(_0x3bd2f0,_0x3d3ff9){const _0x3159ab=document['createElement']('a');_0x3159ab['href']=_0x3bd2f0,_0x3159ab['target']=_0x3d3ff9;const _0x2a63ae=document['createEvent']('MouseEvent');_0x2a63ae['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x3159ab['dispatchEvent'](_0x2a63ae);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0xb6b56b,_0x3409d1,_0x1f8f81,_0xe4c5cb,_0x61b3fb,_0xb95364){m(_0xb6b56b['config']['authDomain'],_0xb6b56b,'auth-domain-config-required'),m(_0xb6b56b['config']['apiKey'],_0xb6b56b,'invalid-api-key');const _0x120acd={'apiKey':_0xb6b56b['config']['apiKey'],'appName':_0xb6b56b['name'],'authType':_0x1f8f81,'redirectUrl':_0xe4c5cb,'v':lt,'eventId':_0x61b3fb};if(_0x3409d1 instanceof Wa){_0x3409d1['setDefaultLanguage'](_0xb6b56b['languageCode']),_0x120acd['providerId']=_0x3409d1['providerId']||'',ui(_0x3409d1['getCustomParameters']())||(_0x120acd['customParameters']=JSON['stringify'](_0x3409d1['getCustomParameters']()));for(const [_0x2ee113,_0x280acc]of Object['entries']({}))_0x120acd[_0x2ee113]=_0x280acc;}if(_0x3409d1 instanceof Jt){const _0xb62eaa=_0x3409d1['getScopes']()['filter'](_0x1e36ad=>_0x1e36ad!=='');_0xb62eaa['length']>0x0&&(_0x120acd['scopes']=_0xb62eaa['join'](','));}_0xb6b56b['tenantId']&&(_0x120acd['tid']=_0xb6b56b['tenantId']);const _0x3b19e0=_0x120acd;for(const _0x41c857 of Object['keys'](_0x3b19e0))_0x3b19e0[_0x41c857]===void 0x0&&delete _0x3b19e0[_0x41c857];const _0x2e0b18=await _0xb6b56b['_getAppCheckToken'](),_0x43ac1e=_0x2e0b18?'#'+n_+'='+encodeURIComponent(_0x2e0b18):'';return i_(_0xb6b56b)+'?'+ct(_0x3b19e0)['slice'](0x1)+_0x43ac1e;}function i_({config:_0x2fcfd5}){return _0x2fcfd5['emulator']?Cs(_0x2fcfd5,t_):'https://'+_0x2fcfd5['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x4191a2,_0x3c1ada,_0x34297e,_0x19c47b){var _0x3e0362;ce((_0x3e0362=this['eventManagers'][_0x4191a2['_key']()])==null?void 0x0:_0x3e0362['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x44e7fd=await xr(_0x4191a2,_0x3c1ada,_0x34297e,Pi(),_0x19c47b);return Xp(_0x4191a2,_0x44e7fd,As());}async['_openRedirect'](_0x5e509e,_0x140774,_0x2614da,_0x514607){await this['_originValidation'](_0x5e509e);const _0x5bc43a=await xr(_0x5e509e,_0x140774,_0x2614da,Pi(),_0x514607);return ap(_0x5bc43a),new Promise(()=>{});}['_initialize'](_0x2d5a76){const _0x39fa5d=_0x2d5a76['_key']();if(this['eventManagers'][_0x39fa5d]){const {manager:_0x117c87,promise:_0x3a2874}=this['eventManagers'][_0x39fa5d];return _0x117c87?Promise['resolve'](_0x117c87):(ce(_0x3a2874,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x3a2874);}const _0x442eb6=this['initAndGetManager'](_0x2d5a76);return this['eventManagers'][_0x39fa5d]={'promise':_0x442eb6},_0x442eb6['catch'](()=>{delete this['eventManagers'][_0x39fa5d];}),_0x442eb6;}async['initAndGetManager'](_0x591fcc){const _0x1b2610=await zp(_0x591fcc),_0x14e488=new Np(_0x591fcc);return _0x1b2610['register']('authEvent',_0x297034=>(m(_0x297034==null?void 0x0:_0x297034['authEvent'],_0x591fcc,'invalid-auth-event'),{'status':_0x14e488['onEvent'](_0x297034['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x591fcc['_key']()]={'manager':_0x14e488},this['iframes'][_0x591fcc['_key']()]=_0x1b2610,_0x14e488;}['_isIframeWebStorageSupported'](_0x33d15e,_0x2045ed){this['iframes'][_0x33d15e['_key']()]['send'](hi,{'type':hi},_0x48dce0=>{var _0x2b0b9b;const _0x46c167=(_0x2b0b9b=_0x48dce0==null?void 0x0:_0x48dce0[0x0])==null?void 0x0:_0x2b0b9b[hi];_0x46c167!==void 0x0&&_0x2045ed(!!_0x46c167),Q(_0x33d15e,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x167d59){const _0x2d0b15=_0x167d59['_key']();return this['originValidationPromises'][_0x2d0b15]||(this['originValidationPromises'][_0x2d0b15]=Lp(_0x167d59)),this['originValidationPromises'][_0x2d0b15];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x333157){this['auth']=_0x333157,this['internalListeners']=new Map();}['getUid'](){var _0xf1e03d;return this['assertAuthConfigured'](),((_0xf1e03d=this['auth']['currentUser'])==null?void 0x0:_0xf1e03d['uid'])||null;}async['getToken'](_0x30f188){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x30f188)}:null;}['addAuthTokenListener'](_0x5ca63c){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x5ca63c))return;const _0x579358=this['auth']['onIdTokenChanged'](_0x293b41=>{_0x5ca63c((_0x293b41==null?void 0x0:_0x293b41['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x5ca63c,_0x579358),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x355fcb){this['assertAuthConfigured']();const _0x44cb79=this['internalListeners']['get'](_0x355fcb);_0x44cb79&&(this['internalListeners']['delete'](_0x355fcb),_0x44cb79(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x18afc5){switch(_0x18afc5){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x5b6424){Ze(new Le('auth',(_0x1b5953,{options:_0x39a15d})=>{const _0x32022a=_0x1b5953['getProvider']('app')['getImmediate'](),_0x5e4944=_0x1b5953['getProvider']('heartbeat'),_0x168d3e=_0x1b5953['getProvider']('app-check-internal'),{apiKey:_0x1ec6cf,authDomain:_0x5881bf}=_0x32022a['options'];m(_0x1ec6cf&&!_0x1ec6cf['includes'](':'),'invalid-api-key',{'appName':_0x32022a['name']});const _0x5a5ea6={'apiKey':_0x1ec6cf,'authDomain':_0x5881bf,'clientPlatform':_0x5b6424,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x5b6424)},_0x29f270=new kf(_0x32022a,_0x5e4944,_0x168d3e,_0x5a5ea6);return Wf(_0x29f270,_0x39a15d),_0x29f270;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x1cce8e,_0x7ae3a3,_0x4f176d)=>{_0x1cce8e['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x4e6102=>{const _0x5d731b=qe(_0x4e6102['getProvider']('auth')['getImmediate']());return(_0x5f1f1b=>new o_(_0x5f1f1b))(_0x5d731b);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x5b6424)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x39aba4=>async _0x53a079=>{const _0x1bb92b=_0x53a079&&await _0x53a079['getIdTokenResult'](),_0x6776e=_0x1bb92b&&(new Date()['getTime']()-Date['parse'](_0x1bb92b['issuedAtTime']))/0x3e8;if(_0x6776e&&_0x6776e>h_)return;const _0x173d9b=_0x1bb92b==null?void 0x0:_0x1bb92b['token'];Wr!==_0x173d9b&&(Wr=_0x173d9b,await fetch(_0x39aba4,{'method':_0x173d9b?'POST':'DELETE','headers':_0x173d9b?{'Authorization':'Bearer\x20'+_0x173d9b}:{}}));};function x_(_0x57e1d5=Zr()){const _0x1d289d=Bi(_0x57e1d5,'auth');if(_0x1d289d['isInitialized']())return _0x1d289d['getImmediate']();const _0x3a31ee=Uf(_0x57e1d5,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x4bc050=zr('authTokenSyncURL');if(_0x4bc050&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x3dc45c=new URL(_0x4bc050,location['origin']);if(location['origin']===_0x3dc45c['origin']){const _0x5f95b4=u_(_0x3dc45c['toString']());tp(_0x3a31ee,_0x5f95b4,()=>_0x5f95b4(_0x3a31ee['currentUser'])),ep(_0x3a31ee,_0x86be94=>_0x5f95b4(_0x86be94));}}const _0x5d8d13=Gr('auth');return _0x5d8d13&&Bf(_0x3a31ee,'http://'+_0x5d8d13),_0x3a31ee;}function d_(){var _0x35634b;return((_0x35634b=document['getElementsByTagName']('head'))==null?void 0x0:_0x35634b[0x0])??document;}Nf({'loadJS'(_0x311e17){return new Promise((_0x4f77f2,_0x350982)=>{const _0x4d4ab5=document['createElement']('script');_0x4d4ab5['setAttribute']('src',_0x311e17),_0x4d4ab5['onload']=_0x4f77f2,_0x4d4ab5['onerror']=_0x2e3a08=>{const _0x520a46=X('internal-error');_0x520a46['customData']=_0x2e3a08,_0x350982(_0x520a46);},_0x4d4ab5['type']='text/javascript',_0x4d4ab5['charset']='UTF-8',d_()['appendChild'](_0x4d4ab5);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};