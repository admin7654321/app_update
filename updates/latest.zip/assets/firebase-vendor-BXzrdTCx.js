const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x1e388f,_0x36a27a){if(!_0x1e388f)throw rt(_0x36a27a);},rt=function(_0x9c3425){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x9c3425);},Vr=function(_0x4d560f){const _0x1e4465=[];let _0x127d53=0x0;for(let _0x454fc8=0x0;_0x454fc8<_0x4d560f['length'];_0x454fc8++){let _0x82dc25=_0x4d560f['charCodeAt'](_0x454fc8);_0x82dc25<0x80?_0x1e4465[_0x127d53++]=_0x82dc25:_0x82dc25<0x800?(_0x1e4465[_0x127d53++]=_0x82dc25>>0x6|0xc0,_0x1e4465[_0x127d53++]=_0x82dc25&0x3f|0x80):(_0x82dc25&0xfc00)===0xd800&&_0x454fc8+0x1<_0x4d560f['length']&&(_0x4d560f['charCodeAt'](_0x454fc8+0x1)&0xfc00)===0xdc00?(_0x82dc25=0x10000+((_0x82dc25&0x3ff)<<0xa)+(_0x4d560f['charCodeAt'](++_0x454fc8)&0x3ff),_0x1e4465[_0x127d53++]=_0x82dc25>>0x12|0xf0,_0x1e4465[_0x127d53++]=_0x82dc25>>0xc&0x3f|0x80,_0x1e4465[_0x127d53++]=_0x82dc25>>0x6&0x3f|0x80,_0x1e4465[_0x127d53++]=_0x82dc25&0x3f|0x80):(_0x1e4465[_0x127d53++]=_0x82dc25>>0xc|0xe0,_0x1e4465[_0x127d53++]=_0x82dc25>>0x6&0x3f|0x80,_0x1e4465[_0x127d53++]=_0x82dc25&0x3f|0x80);}return _0x1e4465;},ec=function(_0x5a0eb1){const _0x4da233=[];let _0x57832f=0x0,_0x555aba=0x0;for(;_0x57832f<_0x5a0eb1['length'];){const _0x7440ba=_0x5a0eb1[_0x57832f++];if(_0x7440ba<0x80)_0x4da233[_0x555aba++]=String['fromCharCode'](_0x7440ba);else{if(_0x7440ba>0xbf&&_0x7440ba<0xe0){const _0x177563=_0x5a0eb1[_0x57832f++];_0x4da233[_0x555aba++]=String['fromCharCode']((_0x7440ba&0x1f)<<0x6|_0x177563&0x3f);}else{if(_0x7440ba>0xef&&_0x7440ba<0x16d){const _0x25fe59=_0x5a0eb1[_0x57832f++],_0x5ba000=_0x5a0eb1[_0x57832f++],_0x494fe7=_0x5a0eb1[_0x57832f++],_0x1ace39=((_0x7440ba&0x7)<<0x12|(_0x25fe59&0x3f)<<0xc|(_0x5ba000&0x3f)<<0x6|_0x494fe7&0x3f)-0x10000;_0x4da233[_0x555aba++]=String['fromCharCode'](0xd800+(_0x1ace39>>0xa)),_0x4da233[_0x555aba++]=String['fromCharCode'](0xdc00+(_0x1ace39&0x3ff));}else{const _0x585ff7=_0x5a0eb1[_0x57832f++],_0x2cfd82=_0x5a0eb1[_0x57832f++];_0x4da233[_0x555aba++]=String['fromCharCode']((_0x7440ba&0xf)<<0xc|(_0x585ff7&0x3f)<<0x6|_0x2cfd82&0x3f);}}}}return _0x4da233['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x11c00c,_0x442a0e){if(!Array['isArray'](_0x11c00c))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x395ae6=_0x442a0e?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x26d79c=[];for(let _0x46e3a1=0x0;_0x46e3a1<_0x11c00c['length'];_0x46e3a1+=0x3){const _0x1da429=_0x11c00c[_0x46e3a1],_0x2cc7a1=_0x46e3a1+0x1<_0x11c00c['length'],_0x14f545=_0x2cc7a1?_0x11c00c[_0x46e3a1+0x1]:0x0,_0x1a33f8=_0x46e3a1+0x2<_0x11c00c['length'],_0x4b4149=_0x1a33f8?_0x11c00c[_0x46e3a1+0x2]:0x0,_0x5b625b=_0x1da429>>0x2,_0x17f522=(_0x1da429&0x3)<<0x4|_0x14f545>>0x4;let _0x50f505=(_0x14f545&0xf)<<0x2|_0x4b4149>>0x6,_0x334787=_0x4b4149&0x3f;_0x1a33f8||(_0x334787=0x40,_0x2cc7a1||(_0x50f505=0x40)),_0x26d79c['push'](_0x395ae6[_0x5b625b],_0x395ae6[_0x17f522],_0x395ae6[_0x50f505],_0x395ae6[_0x334787]);}return _0x26d79c['join']('');},'encodeString'(_0x285c50,_0x5734ae){return this['HAS_NATIVE_SUPPORT']&&!_0x5734ae?btoa(_0x285c50):this['encodeByteArray'](Vr(_0x285c50),_0x5734ae);},'decodeString'(_0xe45f7f,_0x4b5c40){return this['HAS_NATIVE_SUPPORT']&&!_0x4b5c40?atob(_0xe45f7f):ec(this['decodeStringToByteArray'](_0xe45f7f,_0x4b5c40));},'decodeStringToByteArray'(_0x53bc15,_0x309d06){this['init_']();const _0x599e98=_0x309d06?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x3ac01a=[];for(let _0x101de1=0x0;_0x101de1<_0x53bc15['length'];){const _0x557483=_0x599e98[_0x53bc15['charAt'](_0x101de1++)],_0x4c8153=_0x101de1<_0x53bc15['length']?_0x599e98[_0x53bc15['charAt'](_0x101de1)]:0x0;++_0x101de1;const _0x18fe3a=_0x101de1<_0x53bc15['length']?_0x599e98[_0x53bc15['charAt'](_0x101de1)]:0x40;++_0x101de1;const _0x5e4d7a=_0x101de1<_0x53bc15['length']?_0x599e98[_0x53bc15['charAt'](_0x101de1)]:0x40;if(++_0x101de1,_0x557483==null||_0x4c8153==null||_0x18fe3a==null||_0x5e4d7a==null)throw new tc();const _0x23e70d=_0x557483<<0x2|_0x4c8153>>0x4;if(_0x3ac01a['push'](_0x23e70d),_0x18fe3a!==0x40){const _0x33361b=_0x4c8153<<0x4&0xf0|_0x18fe3a>>0x2;if(_0x3ac01a['push'](_0x33361b),_0x5e4d7a!==0x40){const _0x4459ef=_0x18fe3a<<0x6&0xc0|_0x5e4d7a;_0x3ac01a['push'](_0x4459ef);}}}return _0x3ac01a;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x321134=0x0;_0x321134<this['ENCODED_VALS']['length'];_0x321134++)this['byteToCharMap_'][_0x321134]=this['ENCODED_VALS']['charAt'](_0x321134),this['charToByteMap_'][this['byteToCharMap_'][_0x321134]]=_0x321134,this['byteToCharMapWebSafe_'][_0x321134]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x321134),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x321134]]=_0x321134,_0x321134>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x321134)]=_0x321134,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x321134)]=_0x321134);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0xc7d7f9){const _0x8919c5=Vr(_0xc7d7f9);return Li['encodeByteArray'](_0x8919c5,!0x0);},cn=function(_0x11bdb0){return Hr(_0x11bdb0)['replace'](/\./g,'');},ln=function(_0x246695){try{return Li['decodeString'](_0x246695,!0x0);}catch(_0x5d097b){console['error']('base64Decode\x20failed:\x20',_0x5d097b);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x404698){return $r(void 0x0,_0x404698);}function $r(_0x513a01,_0x52b563){if(!(_0x52b563 instanceof Object))return _0x52b563;switch(_0x52b563['constructor']){case Date:const _0x251c51=_0x52b563;return new Date(_0x251c51['getTime']());case Object:_0x513a01===void 0x0&&(_0x513a01={});break;case Array:_0x513a01=[];break;default:return _0x52b563;}for(const _0x3927bd in _0x52b563)!_0x52b563['hasOwnProperty'](_0x3927bd)||!ic(_0x3927bd)||(_0x513a01[_0x3927bd]=$r(_0x513a01[_0x3927bd],_0x52b563[_0x3927bd]));return _0x513a01;}function ic(_0x5abbc9){return _0x5abbc9!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x373703=Ns['__FIREBASE_DEFAULTS__'];if(_0x373703)return JSON['parse'](_0x373703);},ac=()=>{if(typeof document>'u')return;let _0x4a5362;try{_0x4a5362=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0xb1ec43=_0x4a5362&&ln(_0x4a5362[0x1]);return _0xb1ec43&&JSON['parse'](_0xb1ec43);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x3eb704){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x3eb704);return;}},Gr=_0x533d33=>{var _0x1ac9cb,_0x397b73;return(_0x397b73=(_0x1ac9cb=xi())==null?void 0x0:_0x1ac9cb['emulatorHosts'])==null?void 0x0:_0x397b73[_0x533d33];},cc=_0x131ead=>{const _0x2096f1=Gr(_0x131ead);if(!_0x2096f1)return;const _0x23eace=_0x2096f1['lastIndexOf'](':');if(_0x23eace<=0x0||_0x23eace+0x1===_0x2096f1['length'])throw new Error('Invalid\x20host\x20'+_0x2096f1+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x2a6373=parseInt(_0x2096f1['substring'](_0x23eace+0x1),0xa);return _0x2096f1[0x0]==='['?[_0x2096f1['substring'](0x1,_0x23eace-0x1),_0x2a6373]:[_0x2096f1['substring'](0x0,_0x23eace),_0x2a6373];},qr=()=>{var _0x3e6cce;return(_0x3e6cce=xi())==null?void 0x0:_0x3e6cce['config'];},zr=_0x2247c3=>{var _0x13dfea;return(_0x13dfea=xi())==null?void 0x0:_0x13dfea['_'+_0x2247c3];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x4b7c36,_0x1d06e3)=>{this['resolve']=_0x4b7c36,this['reject']=_0x1d06e3;});}['wrapCallback'](_0x341df9){return(_0x2829c4,_0x38f549)=>{_0x2829c4?this['reject'](_0x2829c4):this['resolve'](_0x38f549),typeof _0x341df9=='function'&&(this['promise']['catch'](()=>{}),_0x341df9['length']===0x1?_0x341df9(_0x2829c4):_0x341df9(_0x2829c4,_0x38f549));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x5c1930){try{return(_0x5c1930['startsWith']('http://')||_0x5c1930['startsWith']('https://')?new URL(_0x5c1930)['hostname']:_0x5c1930)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0xcb11b){return(await fetch(_0xcb11b,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x4f24db,_0x553943){if(_0x4f24db['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x47133a={'alg':'none','type':'JWT'},_0x120bde=_0x553943||'demo-project',_0x37bd92=_0x4f24db['iat']||0x0,_0x2ef806=_0x4f24db['sub']||_0x4f24db['user_id'];if(!_0x2ef806)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x37f241={'iss':'https://securetoken.google.com/'+_0x120bde,'aud':_0x120bde,'iat':_0x37bd92,'exp':_0x37bd92+0xe10,'auth_time':_0x37bd92,'sub':_0x2ef806,'user_id':_0x2ef806,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x4f24db};return[cn(JSON['stringify'](_0x47133a)),cn(JSON['stringify'](_0x37f241)),'']['join']('.');}const It={};function hc(){const _0x46a5dc={'prod':[],'emulator':[]};for(const _0x10a875 of Object['keys'](It))It[_0x10a875]?_0x46a5dc['emulator']['push'](_0x10a875):_0x46a5dc['prod']['push'](_0x10a875);return _0x46a5dc;}function uc(_0x17a2a9){let _0x4ea278=document['getElementById'](_0x17a2a9),_0x1ab1e5=!0x1;return _0x4ea278||(_0x4ea278=document['createElement']('div'),_0x4ea278['setAttribute']('id',_0x17a2a9),_0x1ab1e5=!0x0),{'created':_0x1ab1e5,'element':_0x4ea278};}let Ps=!0x1;function Kr(_0x39ec48,_0x4dd4ff){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x39ec48]===_0x4dd4ff||It[_0x39ec48]||Ps)return;It[_0x39ec48]=_0x4dd4ff;function _0x2190ee(_0x4acadd){return'__firebase__banner__'+_0x4acadd;}const _0x318d16='__firebase__banner',_0x4a3046=hc()['prod']['length']>0x0;function _0x96b1de(){const _0x30ad92=document['getElementById'](_0x318d16);_0x30ad92&&_0x30ad92['remove']();}function _0x5e30c5(_0x3eb068){_0x3eb068['style']['display']='flex',_0x3eb068['style']['background']='#7faaf0',_0x3eb068['style']['position']='fixed',_0x3eb068['style']['bottom']='5px',_0x3eb068['style']['left']='5px',_0x3eb068['style']['padding']='.5em',_0x3eb068['style']['borderRadius']='5px',_0x3eb068['style']['alignItems']='center';}function _0x265b31(_0x4b1e21,_0x4faa9a){_0x4b1e21['setAttribute']('width','24'),_0x4b1e21['setAttribute']('id',_0x4faa9a),_0x4b1e21['setAttribute']('height','24'),_0x4b1e21['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x4b1e21['setAttribute']('fill','none'),_0x4b1e21['style']['marginLeft']='-6px';}function _0x4d7487(){const _0xc67286=document['createElement']('span');return _0xc67286['style']['cursor']='pointer',_0xc67286['style']['marginLeft']='16px',_0xc67286['style']['fontSize']='24px',_0xc67286['innerHTML']='\x20&times;',_0xc67286['onclick']=()=>{Ps=!0x0,_0x96b1de();},_0xc67286;}function _0x290f85(_0xcc365d,_0x6ffd56){_0xcc365d['setAttribute']('id',_0x6ffd56),_0xcc365d['innerText']='Learn\x20more',_0xcc365d['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0xcc365d['setAttribute']('target','__blank'),_0xcc365d['style']['paddingLeft']='5px',_0xcc365d['style']['textDecoration']='underline';}function _0x28cdae(){const _0x4da8e3=uc(_0x318d16),_0x1e6878=_0x2190ee('text'),_0x4d58a9=document['getElementById'](_0x1e6878)||document['createElement']('span'),_0x12c49f=_0x2190ee('learnmore'),_0x4682ab=document['getElementById'](_0x12c49f)||document['createElement']('a'),_0x599671=_0x2190ee('preprendIcon'),_0x482413=document['getElementById'](_0x599671)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x4da8e3['created']){const _0x2d694c=_0x4da8e3['element'];_0x5e30c5(_0x2d694c),_0x290f85(_0x4682ab,_0x12c49f);const _0x301653=_0x4d7487();_0x265b31(_0x482413,_0x599671),_0x2d694c['append'](_0x482413,_0x4d58a9,_0x4682ab,_0x301653),document['body']['appendChild'](_0x2d694c);}_0x4a3046?(_0x4d58a9['innerText']='Preview\x20backend\x20disconnected.',_0x482413['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x482413['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x4d58a9['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x4d58a9['setAttribute']('id',_0x1e6878);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x28cdae):_0x28cdae();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x460c73=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x460c73=='object'&&_0x460c73['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x511168=W();return _0x511168['indexOf']('MSIE\x20')>=0x0||_0x511168['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x15fcfe,_0x4d8680)=>{try{let _0x2a8b74=!0x0;const _0x4a9c29='validate-browser-context-for-indexeddb-analytics-module',_0x509774=self['indexedDB']['open'](_0x4a9c29);_0x509774['onsuccess']=()=>{_0x509774['result']['close'](),_0x2a8b74||self['indexedDB']['deleteDatabase'](_0x4a9c29),_0x15fcfe(!0x0);},_0x509774['onupgradeneeded']=()=>{_0x2a8b74=!0x1;},_0x509774['onerror']=()=>{var _0x728bf4;_0x4d8680(((_0x728bf4=_0x509774['error'])==null?void 0x0:_0x728bf4['message'])||'');};}catch(_0x1e8256){_0x4d8680(_0x1e8256);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x5e6fae,_0x56bd5c,_0x48026e){super(_0x56bd5c),this['code']=_0x5e6fae,this['customData']=_0x48026e,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0xc3c35f,_0xfd2030,_0x378199){this['service']=_0xc3c35f,this['serviceName']=_0xfd2030,this['errors']=_0x378199;}['create'](_0x2dbacd,..._0x188d4e){const _0x516691=_0x188d4e[0x0]||{},_0x5c1182=this['service']+'/'+_0x2dbacd,_0x2aff25=this['errors'][_0x2dbacd],_0x11aace=_0x2aff25?vc(_0x2aff25,_0x516691):'Error',_0x89d884=this['serviceName']+':\x20'+_0x11aace+'\x20('+_0x5c1182+').';return new Se(_0x5c1182,_0x89d884,_0x516691);}}function vc(_0x4979f9,_0x4a26dc){return _0x4979f9['replace'](Ec,(_0x8c627f,_0x1d72a2)=>{const _0x323ff8=_0x4a26dc[_0x1d72a2];return _0x323ff8!=null?String(_0x323ff8):'<'+_0x1d72a2+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x5dbe35){return JSON['parse'](_0x5dbe35);}function O(_0x5903a5){return JSON['stringify'](_0x5903a5);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x1f9a45){let _0x2a4fab={},_0x5632b8={},_0x6912bc={},_0x32c0a7='';try{const _0x56ec3d=_0x1f9a45['split']('.');_0x2a4fab=At(ln(_0x56ec3d[0x0])||''),_0x5632b8=At(ln(_0x56ec3d[0x1])||''),_0x32c0a7=_0x56ec3d[0x2],_0x6912bc=_0x5632b8['d']||{},delete _0x5632b8['d'];}catch{}return{'header':_0x2a4fab,'claims':_0x5632b8,'data':_0x6912bc,'signature':_0x32c0a7};},Ic=function(_0x4a54f4){const _0x5d44bb=Qr(_0x4a54f4),_0x53061f=_0x5d44bb['claims'];return!!_0x53061f&&typeof _0x53061f=='object'&&_0x53061f['hasOwnProperty']('iat');},wc=function(_0x473408){const _0x405fde=Qr(_0x473408)['claims'];return typeof _0x405fde=='object'&&_0x405fde['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x5240dd,_0x330f7f){return Object['prototype']['hasOwnProperty']['call'](_0x5240dd,_0x330f7f);}function De(_0x266cbc,_0x50e7ef){if(Object['prototype']['hasOwnProperty']['call'](_0x266cbc,_0x50e7ef))return _0x266cbc[_0x50e7ef];}function ui(_0x30e6b1){for(const _0x259df0 in _0x30e6b1)if(Object['prototype']['hasOwnProperty']['call'](_0x30e6b1,_0x259df0))return!0x1;return!0x0;}function hn(_0x3d0e7e,_0x4aa268,_0x5bd39a){const _0x1e5e33={};for(const _0x4865e9 in _0x3d0e7e)Object['prototype']['hasOwnProperty']['call'](_0x3d0e7e,_0x4865e9)&&(_0x1e5e33[_0x4865e9]=_0x4aa268['call'](_0x5bd39a,_0x3d0e7e[_0x4865e9],_0x4865e9,_0x3d0e7e));return _0x1e5e33;}function Me(_0x391ab1,_0x8728c4){if(_0x391ab1===_0x8728c4)return!0x0;const _0x88dd6e=Object['keys'](_0x391ab1),_0x5ef00f=Object['keys'](_0x8728c4);for(const _0x293660 of _0x88dd6e){if(!_0x5ef00f['includes'](_0x293660))return!0x1;const _0x49dace=_0x391ab1[_0x293660],_0xd2f5d6=_0x8728c4[_0x293660];if(Os(_0x49dace)&&Os(_0xd2f5d6)){if(!Me(_0x49dace,_0xd2f5d6))return!0x1;}else{if(_0x49dace!==_0xd2f5d6)return!0x1;}}for(const _0x4f9fc1 of _0x5ef00f)if(!_0x88dd6e['includes'](_0x4f9fc1))return!0x1;return!0x0;}function Os(_0x24133){return _0x24133!==null&&typeof _0x24133=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x29ef8b){const _0x22f6fd=[];for(const [_0x2da102,_0x5429c0]of Object['entries'](_0x29ef8b))Array['isArray'](_0x5429c0)?_0x5429c0['forEach'](_0x53ca77=>{_0x22f6fd['push'](encodeURIComponent(_0x2da102)+'='+encodeURIComponent(_0x53ca77));}):_0x22f6fd['push'](encodeURIComponent(_0x2da102)+'='+encodeURIComponent(_0x5429c0));return _0x22f6fd['length']?'&'+_0x22f6fd['join']('&'):'';}function vt(_0x61842f){const _0x393635={};return _0x61842f['replace'](/^\?/,'')['split']('&')['forEach'](_0x1fd49f=>{if(_0x1fd49f){const [_0xd24199,_0x5d24c7]=_0x1fd49f['split']('=');_0x393635[decodeURIComponent(_0xd24199)]=decodeURIComponent(_0x5d24c7);}}),_0x393635;}function Et(_0x1a25be){const _0x15580f=_0x1a25be['indexOf']('?');if(!_0x15580f)return'';const _0x1a86cd=_0x1a25be['indexOf']('#',_0x15580f);return _0x1a25be['substring'](_0x15580f,_0x1a86cd>0x0?_0x1a86cd:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x2ebbd7=0x1;_0x2ebbd7<this['blockSize'];++_0x2ebbd7)this['pad_'][_0x2ebbd7]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x3f147e,_0x3108ad){_0x3108ad||(_0x3108ad=0x0);const _0x8fa9e2=this['W_'];if(typeof _0x3f147e=='string'){for(let _0x38f129=0x0;_0x38f129<0x10;_0x38f129++)_0x8fa9e2[_0x38f129]=_0x3f147e['charCodeAt'](_0x3108ad)<<0x18|_0x3f147e['charCodeAt'](_0x3108ad+0x1)<<0x10|_0x3f147e['charCodeAt'](_0x3108ad+0x2)<<0x8|_0x3f147e['charCodeAt'](_0x3108ad+0x3),_0x3108ad+=0x4;}else{for(let _0x5bdef5=0x0;_0x5bdef5<0x10;_0x5bdef5++)_0x8fa9e2[_0x5bdef5]=_0x3f147e[_0x3108ad]<<0x18|_0x3f147e[_0x3108ad+0x1]<<0x10|_0x3f147e[_0x3108ad+0x2]<<0x8|_0x3f147e[_0x3108ad+0x3],_0x3108ad+=0x4;}for(let _0x446fb4=0x10;_0x446fb4<0x50;_0x446fb4++){const _0x543dbe=_0x8fa9e2[_0x446fb4-0x3]^_0x8fa9e2[_0x446fb4-0x8]^_0x8fa9e2[_0x446fb4-0xe]^_0x8fa9e2[_0x446fb4-0x10];_0x8fa9e2[_0x446fb4]=(_0x543dbe<<0x1|_0x543dbe>>>0x1f)&0xffffffff;}let _0x15c458=this['chain_'][0x0],_0x5ce475=this['chain_'][0x1],_0x11eff9=this['chain_'][0x2],_0x18ec48=this['chain_'][0x3],_0x353d2c=this['chain_'][0x4],_0x33e8ea,_0x971458;for(let _0x1a079f=0x0;_0x1a079f<0x50;_0x1a079f++){_0x1a079f<0x28?_0x1a079f<0x14?(_0x33e8ea=_0x18ec48^_0x5ce475&(_0x11eff9^_0x18ec48),_0x971458=0x5a827999):(_0x33e8ea=_0x5ce475^_0x11eff9^_0x18ec48,_0x971458=0x6ed9eba1):_0x1a079f<0x3c?(_0x33e8ea=_0x5ce475&_0x11eff9|_0x18ec48&(_0x5ce475|_0x11eff9),_0x971458=0x8f1bbcdc):(_0x33e8ea=_0x5ce475^_0x11eff9^_0x18ec48,_0x971458=0xca62c1d6);const _0x19b664=(_0x15c458<<0x5|_0x15c458>>>0x1b)+_0x33e8ea+_0x353d2c+_0x971458+_0x8fa9e2[_0x1a079f]&0xffffffff;_0x353d2c=_0x18ec48,_0x18ec48=_0x11eff9,_0x11eff9=(_0x5ce475<<0x1e|_0x5ce475>>>0x2)&0xffffffff,_0x5ce475=_0x15c458,_0x15c458=_0x19b664;}this['chain_'][0x0]=this['chain_'][0x0]+_0x15c458&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5ce475&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x11eff9&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x18ec48&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x353d2c&0xffffffff;}['update'](_0x8b428f,_0xf4c518){if(_0x8b428f==null)return;_0xf4c518===void 0x0&&(_0xf4c518=_0x8b428f['length']);const _0x48779b=_0xf4c518-this['blockSize'];let _0xe6c648=0x0;const _0x29f2d0=this['buf_'];let _0x33ce20=this['inbuf_'];for(;_0xe6c648<_0xf4c518;){if(_0x33ce20===0x0){for(;_0xe6c648<=_0x48779b;)this['compress_'](_0x8b428f,_0xe6c648),_0xe6c648+=this['blockSize'];}if(typeof _0x8b428f=='string'){for(;_0xe6c648<_0xf4c518;)if(_0x29f2d0[_0x33ce20]=_0x8b428f['charCodeAt'](_0xe6c648),++_0x33ce20,++_0xe6c648,_0x33ce20===this['blockSize']){this['compress_'](_0x29f2d0),_0x33ce20=0x0;break;}}else{for(;_0xe6c648<_0xf4c518;)if(_0x29f2d0[_0x33ce20]=_0x8b428f[_0xe6c648],++_0x33ce20,++_0xe6c648,_0x33ce20===this['blockSize']){this['compress_'](_0x29f2d0),_0x33ce20=0x0;break;}}}this['inbuf_']=_0x33ce20,this['total_']+=_0xf4c518;}['digest'](){const _0x3c6f29=[];let _0x21ae51=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x53e7c2=this['blockSize']-0x1;_0x53e7c2>=0x38;_0x53e7c2--)this['buf_'][_0x53e7c2]=_0x21ae51&0xff,_0x21ae51/=0x100;this['compress_'](this['buf_']);let _0x5b5847=0x0;for(let _0x5c71b5=0x0;_0x5c71b5<0x5;_0x5c71b5++)for(let _0x234a2d=0x18;_0x234a2d>=0x0;_0x234a2d-=0x8)_0x3c6f29[_0x5b5847]=this['chain_'][_0x5c71b5]>>_0x234a2d&0xff,++_0x5b5847;return _0x3c6f29;}}function Tc(_0x31b841,_0x321835){const _0x598ffa=new Sc(_0x31b841,_0x321835);return _0x598ffa['subscribe']['bind'](_0x598ffa);}class Sc{constructor(_0x3a4309,_0xb9eb61){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0xb9eb61,this['task']['then'](()=>{_0x3a4309(this);})['catch'](_0x1d492f=>{this['error'](_0x1d492f);});}['next'](_0xfcc84c){this['forEachObserver'](_0x9d77de=>{_0x9d77de['next'](_0xfcc84c);});}['error'](_0x7129d9){this['forEachObserver'](_0xf74115=>{_0xf74115['error'](_0x7129d9);}),this['close'](_0x7129d9);}['complete'](){this['forEachObserver'](_0x20df52=>{_0x20df52['complete']();}),this['close']();}['subscribe'](_0x15eaf4,_0x5bba3a,_0x1f2e16){let _0x120ae5;if(_0x15eaf4===void 0x0&&_0x5bba3a===void 0x0&&_0x1f2e16===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x15eaf4,['next','error','complete'])?_0x120ae5=_0x15eaf4:_0x120ae5={'next':_0x15eaf4,'error':_0x5bba3a,'complete':_0x1f2e16},_0x120ae5['next']===void 0x0&&(_0x120ae5['next']=Jn),_0x120ae5['error']===void 0x0&&(_0x120ae5['error']=Jn),_0x120ae5['complete']===void 0x0&&(_0x120ae5['complete']=Jn);const _0x25ad2a=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x120ae5['error'](this['finalError']):_0x120ae5['complete']();}catch{}}),this['observers']['push'](_0x120ae5),_0x25ad2a;}['unsubscribeOne'](_0x3e65b2){this['observers']===void 0x0||this['observers'][_0x3e65b2]===void 0x0||(delete this['observers'][_0x3e65b2],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x521727){if(!this['finalized']){for(let _0x3a8b4d=0x0;_0x3a8b4d<this['observers']['length'];_0x3a8b4d++)this['sendOne'](_0x3a8b4d,_0x521727);}}['sendOne'](_0x41779a,_0x5ba8a8){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x41779a]!==void 0x0)try{_0x5ba8a8(this['observers'][_0x41779a]);}catch(_0x475427){typeof console<'u'&&console['error']&&console['error'](_0x475427);}});}['close'](_0xbeb728){this['finalized']||(this['finalized']=!0x0,_0xbeb728!==void 0x0&&(this['finalError']=_0xbeb728),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x1ce160,_0x384811){if(typeof _0x1ce160!='object'||_0x1ce160===null)return!0x1;for(const _0x320b4b of _0x384811)if(_0x320b4b in _0x1ce160&&typeof _0x1ce160[_0x320b4b]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x1fa19a,_0x8df909){return _0x1fa19a+'\x20failed:\x20'+_0x8df909+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x16cc3a){const _0x467e91=[];let _0x242995=0x0;for(let _0x3be2b6=0x0;_0x3be2b6<_0x16cc3a['length'];_0x3be2b6++){let _0xa9d294=_0x16cc3a['charCodeAt'](_0x3be2b6);if(_0xa9d294>=0xd800&&_0xa9d294<=0xdbff){const _0x35f1e7=_0xa9d294-0xd800;_0x3be2b6++,f(_0x3be2b6<_0x16cc3a['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x31012e=_0x16cc3a['charCodeAt'](_0x3be2b6)-0xdc00;_0xa9d294=0x10000+(_0x35f1e7<<0xa)+_0x31012e;}_0xa9d294<0x80?_0x467e91[_0x242995++]=_0xa9d294:_0xa9d294<0x800?(_0x467e91[_0x242995++]=_0xa9d294>>0x6|0xc0,_0x467e91[_0x242995++]=_0xa9d294&0x3f|0x80):_0xa9d294<0x10000?(_0x467e91[_0x242995++]=_0xa9d294>>0xc|0xe0,_0x467e91[_0x242995++]=_0xa9d294>>0x6&0x3f|0x80,_0x467e91[_0x242995++]=_0xa9d294&0x3f|0x80):(_0x467e91[_0x242995++]=_0xa9d294>>0x12|0xf0,_0x467e91[_0x242995++]=_0xa9d294>>0xc&0x3f|0x80,_0x467e91[_0x242995++]=_0xa9d294>>0x6&0x3f|0x80,_0x467e91[_0x242995++]=_0xa9d294&0x3f|0x80);}return _0x467e91;},On=function(_0x4c5637){let _0xa32429=0x0;for(let _0xe1385f=0x0;_0xe1385f<_0x4c5637['length'];_0xe1385f++){const _0x539f79=_0x4c5637['charCodeAt'](_0xe1385f);_0x539f79<0x80?_0xa32429++:_0x539f79<0x800?_0xa32429+=0x2:_0x539f79>=0xd800&&_0x539f79<=0xdbff?(_0xa32429+=0x4,_0xe1385f++):_0xa32429+=0x3;}return _0xa32429;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x14bee9){return _0x14bee9&&_0x14bee9['_delegate']?_0x14bee9['_delegate']:_0x14bee9;}class Le{constructor(_0x262e0d,_0x372c5e,_0x21332b){this['name']=_0x262e0d,this['instanceFactory']=_0x372c5e,this['type']=_0x21332b,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x413c10){return this['instantiationMode']=_0x413c10,this;}['setMultipleInstances'](_0x38bced){return this['multipleInstances']=_0x38bced,this;}['setServiceProps'](_0x4c16f7){return this['serviceProps']=_0x4c16f7,this;}['setInstanceCreatedCallback'](_0xed80c3){return this['onInstanceCreated']=_0xed80c3,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0xd90024,_0x535d91){this['name']=_0xd90024,this['container']=_0x535d91,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x2f8214){const _0x2847b1=this['normalizeInstanceIdentifier'](_0x2f8214);if(!this['instancesDeferred']['has'](_0x2847b1)){const _0x3f3793=new ot();if(this['instancesDeferred']['set'](_0x2847b1,_0x3f3793),this['isInitialized'](_0x2847b1)||this['shouldAutoInitialize']())try{const _0x2e938b=this['getOrInitializeService']({'instanceIdentifier':_0x2847b1});_0x2e938b&&_0x3f3793['resolve'](_0x2e938b);}catch{}}return this['instancesDeferred']['get'](_0x2847b1)['promise'];}['getImmediate'](_0xd40840){const _0x4b098b=this['normalizeInstanceIdentifier'](_0xd40840==null?void 0x0:_0xd40840['identifier']),_0x559b06=(_0xd40840==null?void 0x0:_0xd40840['optional'])??!0x1;if(this['isInitialized'](_0x4b098b)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4b098b});}catch(_0x28ca6c){if(_0x559b06)return null;throw _0x28ca6c;}else{if(_0x559b06)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x29704e){if(_0x29704e['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x29704e['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x29704e,!!this['shouldAutoInitialize']()){if(Nc(_0x29704e))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x317807,_0x117e42]of this['instancesDeferred']['entries']()){const _0x51de51=this['normalizeInstanceIdentifier'](_0x317807);try{const _0x3292cf=this['getOrInitializeService']({'instanceIdentifier':_0x51de51});_0x117e42['resolve'](_0x3292cf);}catch{}}}}['clearInstance'](_0x320d21=Ne){this['instancesDeferred']['delete'](_0x320d21),this['instancesOptions']['delete'](_0x320d21),this['instances']['delete'](_0x320d21);}async['delete'](){const _0x3e9633=Array['from'](this['instances']['values']());await Promise['all']([..._0x3e9633['filter'](_0x59c336=>'INTERNAL'in _0x59c336)['map'](_0x355312=>_0x355312['INTERNAL']['delete']()),..._0x3e9633['filter'](_0x5c5095=>'_delete'in _0x5c5095)['map'](_0x66e56c=>_0x66e56c['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x4ae778=Ne){return this['instances']['has'](_0x4ae778);}['getOptions'](_0x28af27=Ne){return this['instancesOptions']['get'](_0x28af27)||{};}['initialize'](_0x35e65b={}){const {options:_0x505139={}}=_0x35e65b,_0x536f32=this['normalizeInstanceIdentifier'](_0x35e65b['instanceIdentifier']);if(this['isInitialized'](_0x536f32))throw Error(this['name']+'('+_0x536f32+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x4a95bb=this['getOrInitializeService']({'instanceIdentifier':_0x536f32,'options':_0x505139});for(const [_0x1218f1,_0x2ec1a2]of this['instancesDeferred']['entries']()){const _0x2a55cf=this['normalizeInstanceIdentifier'](_0x1218f1);_0x536f32===_0x2a55cf&&_0x2ec1a2['resolve'](_0x4a95bb);}return _0x4a95bb;}['onInit'](_0x3c110c,_0x3223b7){const _0x165a3c=this['normalizeInstanceIdentifier'](_0x3223b7),_0x488c9b=this['onInitCallbacks']['get'](_0x165a3c)??new Set();_0x488c9b['add'](_0x3c110c),this['onInitCallbacks']['set'](_0x165a3c,_0x488c9b);const _0x2b635b=this['instances']['get'](_0x165a3c);return _0x2b635b&&_0x3c110c(_0x2b635b,_0x165a3c),()=>{_0x488c9b['delete'](_0x3c110c);};}['invokeOnInitCallbacks'](_0x4aabbe,_0x1963a5){const _0x41ccff=this['onInitCallbacks']['get'](_0x1963a5);if(_0x41ccff){for(const _0x2a36a2 of _0x41ccff)try{_0x2a36a2(_0x4aabbe,_0x1963a5);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x571500,options:_0x19c32b={}}){let _0x1e7185=this['instances']['get'](_0x571500);if(!_0x1e7185&&this['component']&&(_0x1e7185=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x571500),'options':_0x19c32b}),this['instances']['set'](_0x571500,_0x1e7185),this['instancesOptions']['set'](_0x571500,_0x19c32b),this['invokeOnInitCallbacks'](_0x1e7185,_0x571500),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x571500,_0x1e7185);}catch{}return _0x1e7185||null;}['normalizeInstanceIdentifier'](_0x24f6f9=Ne){return this['component']?this['component']['multipleInstances']?_0x24f6f9:Ne:_0x24f6f9;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x26c800){return _0x26c800===Ne?void 0x0:_0x26c800;}function Nc(_0x2d50d9){return _0x2d50d9['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x2d45ad){this['name']=_0x2d45ad,this['providers']=new Map();}['addComponent'](_0x1f9383){const _0x369cfd=this['getProvider'](_0x1f9383['name']);if(_0x369cfd['isComponentSet']())throw new Error('Component\x20'+_0x1f9383['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x369cfd['setComponent'](_0x1f9383);}['addOrOverwriteComponent'](_0x27fb58){this['getProvider'](_0x27fb58['name'])['isComponentSet']()&&this['providers']['delete'](_0x27fb58['name']),this['addComponent'](_0x27fb58);}['getProvider'](_0x33aeac){if(this['providers']['has'](_0x33aeac))return this['providers']['get'](_0x33aeac);const _0x31f044=new Ac(_0x33aeac,this);return this['providers']['set'](_0x33aeac,_0x31f044),_0x31f044;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x24a118){_0x24a118[_0x24a118['DEBUG']=0x0]='DEBUG',_0x24a118[_0x24a118['VERBOSE']=0x1]='VERBOSE',_0x24a118[_0x24a118['INFO']=0x2]='INFO',_0x24a118[_0x24a118['WARN']=0x3]='WARN',_0x24a118[_0x24a118['ERROR']=0x4]='ERROR',_0x24a118[_0x24a118['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0xa4ba2c,_0x7003c7,..._0x14f97a)=>{if(_0x7003c7<_0xa4ba2c['logLevel'])return;const _0x1c59cc=new Date()['toISOString'](),_0x1d4f94=Mc[_0x7003c7];if(_0x1d4f94)console[_0x1d4f94]('['+_0x1c59cc+']\x20\x20'+_0xa4ba2c['name']+':',..._0x14f97a);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x7003c7+')');};class Ui{constructor(_0x5ba227){this['name']=_0x5ba227,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x3229a0){if(!(_0x3229a0 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x3229a0+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x3229a0;}['setLogLevel'](_0x23fe2f){this['_logLevel']=typeof _0x23fe2f=='string'?Oc[_0x23fe2f]:_0x23fe2f;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x4b84bf){if(typeof _0x4b84bf!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x4b84bf;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x30f247){this['_userLogHandler']=_0x30f247;}['debug'](..._0x4f89b7){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x4f89b7),this['_logHandler'](this,T['DEBUG'],..._0x4f89b7);}['log'](..._0x27b539){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x27b539),this['_logHandler'](this,T['VERBOSE'],..._0x27b539);}['info'](..._0x3eef77){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x3eef77),this['_logHandler'](this,T['INFO'],..._0x3eef77);}['warn'](..._0x898929){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x898929),this['_logHandler'](this,T['WARN'],..._0x898929);}['error'](..._0x154488){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x154488),this['_logHandler'](this,T['ERROR'],..._0x154488);}}const xc=(_0x30001e,_0x448148)=>_0x448148['some'](_0x3e0452=>_0x30001e instanceof _0x3e0452);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x49c072){const _0x506d8f=new Promise((_0x42039a,_0x471c03)=>{const _0x377fc6=()=>{_0x49c072['removeEventListener']('success',_0x306c09),_0x49c072['removeEventListener']('error',_0x617de0);},_0x306c09=()=>{_0x42039a(_e(_0x49c072['result'])),_0x377fc6();},_0x617de0=()=>{_0x471c03(_0x49c072['error']),_0x377fc6();};_0x49c072['addEventListener']('success',_0x306c09),_0x49c072['addEventListener']('error',_0x617de0);});return _0x506d8f['then'](_0x1f8ccc=>{_0x1f8ccc instanceof IDBCursor&&Jr['set'](_0x1f8ccc,_0x49c072);})['catch'](()=>{}),Wi['set'](_0x506d8f,_0x49c072),_0x506d8f;}function Bc(_0x4793c5){if(di['has'](_0x4793c5))return;const _0x201450=new Promise((_0xa850b7,_0x343b63)=>{const _0x5ccbae=()=>{_0x4793c5['removeEventListener']('complete',_0x58b4a6),_0x4793c5['removeEventListener']('error',_0xcff3de),_0x4793c5['removeEventListener']('abort',_0xcff3de);},_0x58b4a6=()=>{_0xa850b7(),_0x5ccbae();},_0xcff3de=()=>{_0x343b63(_0x4793c5['error']||new DOMException('AbortError','AbortError')),_0x5ccbae();};_0x4793c5['addEventListener']('complete',_0x58b4a6),_0x4793c5['addEventListener']('error',_0xcff3de),_0x4793c5['addEventListener']('abort',_0xcff3de);});di['set'](_0x4793c5,_0x201450);}let fi={'get'(_0xd86c7f,_0x4cc000,_0x41c822){if(_0xd86c7f instanceof IDBTransaction){if(_0x4cc000==='done')return di['get'](_0xd86c7f);if(_0x4cc000==='objectStoreNames')return _0xd86c7f['objectStoreNames']||Xr['get'](_0xd86c7f);if(_0x4cc000==='store')return _0x41c822['objectStoreNames'][0x1]?void 0x0:_0x41c822['objectStore'](_0x41c822['objectStoreNames'][0x0]);}return _e(_0xd86c7f[_0x4cc000]);},'set'(_0x375f85,_0xc54541,_0x3b228e){return _0x375f85[_0xc54541]=_0x3b228e,!0x0;},'has'(_0x57cf4a,_0x21c1c3){return _0x57cf4a instanceof IDBTransaction&&(_0x21c1c3==='done'||_0x21c1c3==='store')?!0x0:_0x21c1c3 in _0x57cf4a;}};function Vc(_0x15b9f7){fi=_0x15b9f7(fi);}function Hc(_0x220f2a){return _0x220f2a===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x5ecc05,..._0x5b4b03){const _0x5b5e39=_0x220f2a['call'](Zn(this),_0x5ecc05,..._0x5b4b03);return Xr['set'](_0x5b5e39,_0x5ecc05['sort']?_0x5ecc05['sort']():[_0x5ecc05]),_e(_0x5b5e39);}:Uc()['includes'](_0x220f2a)?function(..._0x15dec7){return _0x220f2a['apply'](Zn(this),_0x15dec7),_e(Jr['get'](this));}:function(..._0x3330cf){return _e(_0x220f2a['apply'](Zn(this),_0x3330cf));};}function $c(_0x37e3b1){return typeof _0x37e3b1=='function'?Hc(_0x37e3b1):(_0x37e3b1 instanceof IDBTransaction&&Bc(_0x37e3b1),xc(_0x37e3b1,Fc())?new Proxy(_0x37e3b1,fi):_0x37e3b1);}function _e(_0x2c952b){if(_0x2c952b instanceof IDBRequest)return Wc(_0x2c952b);if(Xn['has'](_0x2c952b))return Xn['get'](_0x2c952b);const _0x5d1677=$c(_0x2c952b);return _0x5d1677!==_0x2c952b&&(Xn['set'](_0x2c952b,_0x5d1677),Wi['set'](_0x5d1677,_0x2c952b)),_0x5d1677;}const Zn=_0x2bc058=>Wi['get'](_0x2bc058);function Gc(_0x3e197e,_0x1552db,{blocked:_0x34e030,upgrade:_0xa2f64d,blocking:_0x4fa403,terminated:_0x13fea7}={}){const _0x4cd2c4=indexedDB['open'](_0x3e197e,_0x1552db),_0x11f9b2=_e(_0x4cd2c4);return _0xa2f64d&&_0x4cd2c4['addEventListener']('upgradeneeded',_0xe5ecd4=>{_0xa2f64d(_e(_0x4cd2c4['result']),_0xe5ecd4['oldVersion'],_0xe5ecd4['newVersion'],_e(_0x4cd2c4['transaction']),_0xe5ecd4);}),_0x34e030&&_0x4cd2c4['addEventListener']('blocked',_0x1b1d64=>_0x34e030(_0x1b1d64['oldVersion'],_0x1b1d64['newVersion'],_0x1b1d64)),_0x11f9b2['then'](_0x573e1e=>{_0x13fea7&&_0x573e1e['addEventListener']('close',()=>_0x13fea7()),_0x4fa403&&_0x573e1e['addEventListener']('versionchange',_0x31d996=>_0x4fa403(_0x31d996['oldVersion'],_0x31d996['newVersion'],_0x31d996));})['catch'](()=>{}),_0x11f9b2;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x457c66,_0x2b5b92){if(!(_0x457c66 instanceof IDBDatabase&&!(_0x2b5b92 in _0x457c66)&&typeof _0x2b5b92=='string'))return;if(ei['get'](_0x2b5b92))return ei['get'](_0x2b5b92);const _0x15cec5=_0x2b5b92['replace'](/FromIndex$/,''),_0x4cb033=_0x2b5b92!==_0x15cec5,_0x583458=zc['includes'](_0x15cec5);if(!(_0x15cec5 in(_0x4cb033?IDBIndex:IDBObjectStore)['prototype'])||!(_0x583458||qc['includes'](_0x15cec5)))return;const _0x20f0ad=async function(_0x51be36,..._0x2ddcbc){const _0x5f5661=this['transaction'](_0x51be36,_0x583458?'readwrite':'readonly');let _0x908172=_0x5f5661['store'];return _0x4cb033&&(_0x908172=_0x908172['index'](_0x2ddcbc['shift']())),(await Promise['all']([_0x908172[_0x15cec5](..._0x2ddcbc),_0x583458&&_0x5f5661['done']]))[0x0];};return ei['set'](_0x2b5b92,_0x20f0ad),_0x20f0ad;}Vc(_0x355a65=>({..._0x355a65,'get':(_0x279511,_0x1ba9d2,_0x4aea24)=>Ls(_0x279511,_0x1ba9d2)||_0x355a65['get'](_0x279511,_0x1ba9d2,_0x4aea24),'has':(_0x14d1c9,_0x3814f3)=>!!Ls(_0x14d1c9,_0x3814f3)||_0x355a65['has'](_0x14d1c9,_0x3814f3)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x54a97f){this['container']=_0x54a97f;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x2a4482=>{if(Kc(_0x2a4482)){const _0x4026da=_0x2a4482['getImmediate']();return _0x4026da['library']+'/'+_0x4026da['version'];}else return null;})['filter'](_0x51e2d3=>_0x51e2d3)['join']('\x20');}}function Kc(_0x20a77f){const _0x2b4f47=_0x20a77f['getComponent']();return(_0x2b4f47==null?void 0x0:_0x2b4f47['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x34a430,_0x26f7e6){try{_0x34a430['container']['addComponent'](_0x26f7e6);}catch(_0x3d4be9){oe['debug']('Component\x20'+_0x26f7e6['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x34a430['name'],_0x3d4be9);}}function Ze(_0x89ca36){const _0x5a46ed=_0x89ca36['name'];if(mi['has'](_0x5a46ed))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x5a46ed+'.'),!0x1;mi['set'](_0x5a46ed,_0x89ca36);for(const _0x162854 of xe['values']())Fs(_0x162854,_0x89ca36);for(const _0x41e54d of gi['values']())Fs(_0x41e54d,_0x89ca36);return!0x0;}function Bi(_0x5f02bd,_0x1ebb23){const _0x10e19d=_0x5f02bd['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x10e19d&&_0x10e19d['triggerHeartbeat'](),_0x5f02bd['container']['getProvider'](_0x1ebb23);}function $(_0x4b6a3d){return _0x4b6a3d==null?!0x1:_0x4b6a3d['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x4d00ea,_0x7579f4,_0x50a8ba){this['_isDeleted']=!0x1,this['_options']={..._0x4d00ea},this['_config']={..._0x7579f4},this['_name']=_0x7579f4['name'],this['_automaticDataCollectionEnabled']=_0x7579f4['automaticDataCollectionEnabled'],this['_container']=_0x50a8ba,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x357e2b){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x357e2b;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x3bc509){this['_isDeleted']=_0x3bc509;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x292f12,_0x259022={}){let _0xbe8626=_0x292f12;typeof _0x259022!='object'&&(_0x259022={'name':_0x259022});const _0x26ec40={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x259022},_0x519f57=_0x26ec40['name'];if(typeof _0x519f57!='string'||!_0x519f57)throw ge['create']('bad-app-name',{'appName':String(_0x519f57)});if(_0xbe8626||(_0xbe8626=qr()),!_0xbe8626)throw ge['create']('no-options');const _0x56f87c=xe['get'](_0x519f57);if(_0x56f87c){if(Me(_0xbe8626,_0x56f87c['options'])&&Me(_0x26ec40,_0x56f87c['config']))return _0x56f87c;throw ge['create']('duplicate-app',{'appName':_0x519f57});}const _0x1116a7=new Pc(_0x519f57);for(const _0x2aa0fd of mi['values']())_0x1116a7['addComponent'](_0x2aa0fd);const _0x596fd7=new Tl(_0xbe8626,_0x26ec40,_0x1116a7);return xe['set'](_0x519f57,_0x596fd7),_0x596fd7;}function Zr(_0x257a2e=_i){const _0x20b704=xe['get'](_0x257a2e);if(!_0x20b704&&_0x257a2e===_i&&qr())return Sl();if(!_0x20b704)throw ge['create']('no-app',{'appName':_0x257a2e});return _0x20b704;}function f_(){return Array['from'](xe['values']());}async function p_(_0x4500e3){let _0x3a6e16=!0x1;const _0x3a4945=_0x4500e3['name'];xe['has'](_0x3a4945)?(_0x3a6e16=!0x0,xe['delete'](_0x3a4945)):gi['has'](_0x3a4945)&&_0x4500e3['decRefCount']()<=0x0&&(gi['delete'](_0x3a4945),_0x3a6e16=!0x0),_0x3a6e16&&(await Promise['all'](_0x4500e3['container']['getProviders']()['map'](_0x217f6c=>_0x217f6c['delete']())),_0x4500e3['isDeleted']=!0x0);}function me(_0x3d8468,_0xfb07ff,_0x1315d5){let _0x2f4dc2=wl[_0x3d8468]??_0x3d8468;_0x1315d5&&(_0x2f4dc2+='-'+_0x1315d5);const _0x3da06b=_0x2f4dc2['match'](/\s|\//),_0x3f4f2f=_0xfb07ff['match'](/\s|\//);if(_0x3da06b||_0x3f4f2f){const _0x5d4148=['Unable\x20to\x20register\x20library\x20\x22'+_0x2f4dc2+'\x22\x20with\x20version\x20\x22'+_0xfb07ff+'\x22:'];_0x3da06b&&_0x5d4148['push']('library\x20name\x20\x22'+_0x2f4dc2+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x3da06b&&_0x3f4f2f&&_0x5d4148['push']('and'),_0x3f4f2f&&_0x5d4148['push']('version\x20name\x20\x22'+_0xfb07ff+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x5d4148['join']('\x20'));return;}Ze(new Le(_0x2f4dc2+'-version',()=>({'library':_0x2f4dc2,'version':_0xfb07ff}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x591ca2,_0x2aa70d)=>{switch(_0x2aa70d){case 0x0:try{_0x591ca2['createObjectStore'](kt);}catch(_0x51232d){console['warn'](_0x51232d);}}}})['catch'](_0x350194=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x350194['message']});})),ti;}async function Al(_0x2b2c09){try{const _0x53a405=(await eo())['transaction'](kt),_0xd9447d=await _0x53a405['objectStore'](kt)['get'](to(_0x2b2c09));return await _0x53a405['done'],_0xd9447d;}catch(_0x411d95){if(_0x411d95 instanceof Se)oe['warn'](_0x411d95['message']);else{const _0x54a042=ge['create']('idb-get',{'originalErrorMessage':_0x411d95==null?void 0x0:_0x411d95['message']});oe['warn'](_0x54a042['message']);}}}async function Us(_0x4db9e3,_0x1ae5c9){try{const _0x46d252=(await eo())['transaction'](kt,'readwrite');await _0x46d252['objectStore'](kt)['put'](_0x1ae5c9,to(_0x4db9e3)),await _0x46d252['done'];}catch(_0x5ea63d){if(_0x5ea63d instanceof Se)oe['warn'](_0x5ea63d['message']);else{const _0x1376e8=ge['create']('idb-set',{'originalErrorMessage':_0x5ea63d==null?void 0x0:_0x5ea63d['message']});oe['warn'](_0x1376e8['message']);}}}function to(_0x192d87){return _0x192d87['name']+'!'+_0x192d87['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x1859c9){this['container']=_0x1859c9,this['_heartbeatsCache']=null;const _0x434608=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x434608),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0xbd8ec7=>(this['_heartbeatsCache']=_0xbd8ec7,_0xbd8ec7));}async['triggerHeartbeat'](){var _0x22714f,_0x26abe4;try{const _0x1c8b1f=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x14c790=Ws();if(((_0x22714f=this['_heartbeatsCache'])==null?void 0x0:_0x22714f['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x26abe4=this['_heartbeatsCache'])==null?void 0x0:_0x26abe4['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x14c790||this['_heartbeatsCache']['heartbeats']['some'](_0xfa65de=>_0xfa65de['date']===_0x14c790))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x14c790,'agent':_0x1c8b1f}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0xd82299=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0xd82299,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x33ec6e){oe['warn'](_0x33ec6e);}}async['getHeartbeatsHeader'](){var _0x59764d;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x59764d=this['_heartbeatsCache'])==null?void 0x0:_0x59764d['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x16eda6=Ws(),{heartbeatsToSend:_0x4e2b3c,unsentEntries:_0x41d9dc}=Ol(this['_heartbeatsCache']['heartbeats']),_0x2a0d06=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x4e2b3c}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x16eda6,_0x41d9dc['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x41d9dc,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x2a0d06;}catch(_0x204ac4){return oe['warn'](_0x204ac4),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x1881a5,_0x492de8=kl){const _0x298d82=[];let _0x593214=_0x1881a5['slice']();for(const _0x3e88f1 of _0x1881a5){const _0xfe33fe=_0x298d82['find'](_0x4a7112=>_0x4a7112['agent']===_0x3e88f1['agent']);if(_0xfe33fe){if(_0xfe33fe['dates']['push'](_0x3e88f1['date']),Bs(_0x298d82)>_0x492de8){_0xfe33fe['dates']['pop']();break;}}else{if(_0x298d82['push']({'agent':_0x3e88f1['agent'],'dates':[_0x3e88f1['date']]}),Bs(_0x298d82)>_0x492de8){_0x298d82['pop']();break;}}_0x593214=_0x593214['slice'](0x1);}return{'heartbeatsToSend':_0x298d82,'unsentEntries':_0x593214};}class Dl{constructor(_0x4751c3){this['app']=_0x4751c3,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x2dc0ad=await Al(this['app']);return _0x2dc0ad!=null&&_0x2dc0ad['heartbeats']?_0x2dc0ad:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x3181ef){if(await this['_canUseIndexedDBPromise']){const _0x3290fe=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x3181ef['lastSentHeartbeatDate']??_0x3290fe['lastSentHeartbeatDate'],'heartbeats':_0x3181ef['heartbeats']});}else return;}async['add'](_0x51d821){if(await this['_canUseIndexedDBPromise']){const _0x3a252d=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x51d821['lastSentHeartbeatDate']??_0x3a252d['lastSentHeartbeatDate'],'heartbeats':[..._0x3a252d['heartbeats'],..._0x51d821['heartbeats']]});}else return;}}function Bs(_0x85d4e9){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x85d4e9}))['length'];}function Ml(_0xb1666b){if(_0xb1666b['length']===0x0)return-0x1;let _0x3bb12f=0x0,_0x408708=_0xb1666b[0x0]['date'];for(let _0x403330=0x1;_0x403330<_0xb1666b['length'];_0x403330++)_0xb1666b[_0x403330]['date']<_0x408708&&(_0x408708=_0xb1666b[_0x403330]['date'],_0x3bb12f=_0x403330);return _0x3bb12f;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x103627){Ze(new Le('platform-logger',_0x387a18=>new jc(_0x387a18),'PRIVATE')),Ze(new Le('heartbeat',_0x327a43=>new Pl(_0x327a43),'PRIVATE')),me(pi,xs,_0x103627),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x923ee4){no=_0x923ee4;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x3075a3){this['domStorage_']=_0x3075a3,this['prefix_']='firebase:';}['set'](_0x20727e,_0x9ec680){_0x9ec680==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x20727e)):this['domStorage_']['setItem'](this['prefixedName_'](_0x20727e),O(_0x9ec680));}['get'](_0x488cf4){const _0x360046=this['domStorage_']['getItem'](this['prefixedName_'](_0x488cf4));return _0x360046==null?null:At(_0x360046);}['remove'](_0x43a065){this['domStorage_']['removeItem'](this['prefixedName_'](_0x43a065));}['prefixedName_'](_0x45a55f){return this['prefix_']+_0x45a55f;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x435774,_0x30933c){_0x30933c==null?delete this['cache_'][_0x435774]:this['cache_'][_0x435774]=_0x30933c;}['get'](_0x11b210){return J(this['cache_'],_0x11b210)?this['cache_'][_0x11b210]:null;}['remove'](_0x3c0e6a){delete this['cache_'][_0x3c0e6a];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0xac16a8){try{if(typeof window<'u'&&typeof window[_0xac16a8]<'u'){const _0x4ab7b6=window[_0xac16a8];return _0x4ab7b6['setItem']('firebase:sentinel','cache'),_0x4ab7b6['removeItem']('firebase:sentinel'),new Wl(_0x4ab7b6);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x1ff4c8=0x1;return function(){return _0x1ff4c8++;};}()),ro=function(_0x53604b){const _0x22e503=Rc(_0x53604b),_0xa0f816=new Cc();_0xa0f816['update'](_0x22e503);const _0x14b9ce=_0xa0f816['digest']();return Li['encodeByteArray'](_0x14b9ce);},Vt=function(..._0x23b655){let _0xa3817a='';for(let _0x36ecad=0x0;_0x36ecad<_0x23b655['length'];_0x36ecad++){const _0x21ece8=_0x23b655[_0x36ecad];Array['isArray'](_0x21ece8)||_0x21ece8&&typeof _0x21ece8=='object'&&typeof _0x21ece8['length']=='number'?_0xa3817a+=Vt['apply'](null,_0x21ece8):typeof _0x21ece8=='object'?_0xa3817a+=O(_0x21ece8):_0xa3817a+=_0x21ece8,_0xa3817a+='\x20';}return _0xa3817a;};let wt=null,Gs=!0x0;const Hl=function(_0x17890c,_0x29b6dc){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x458d6c){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x17a7a8=Vt['apply'](null,_0x458d6c);wt(_0x17a7a8);}},Ht=function(_0x44c17a){return function(..._0x27bcf3){L(_0x44c17a,..._0x27bcf3);};},yi=function(..._0x7ff4e3){const _0x305ac5='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x7ff4e3);Ye['error'](_0x305ac5);},ae=function(..._0x3d0ad6){const _0x2de1d7='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x3d0ad6);throw Ye['error'](_0x2de1d7),new Error(_0x2de1d7);},U=function(..._0x5228c6){const _0x2eeb81='FIREBASE\x20WARNING:\x20'+Vt(..._0x5228c6);Ye['warn'](_0x2eeb81);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x22f9b5){return typeof _0x22f9b5=='number'&&(_0x22f9b5!==_0x22f9b5||_0x22f9b5===Number['POSITIVE_INFINITY']||_0x22f9b5===Number['NEGATIVE_INFINITY']);},Gl=function(_0x50c34d){if(document['readyState']==='complete')_0x50c34d();else{let _0x42c2db=!0x1;const _0x492635=function(){if(!document['body']){setTimeout(_0x492635,Math['floor'](0xa));return;}_0x42c2db||(_0x42c2db=!0x0,_0x50c34d());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x492635,!0x1),window['addEventListener']('load',_0x492635,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x492635();}),window['attachEvent']('onload',_0x492635));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x246211,_0x508d49){if(_0x246211===_0x508d49)return 0x0;if(_0x246211===Fe||_0x508d49===Ie)return-0x1;if(_0x508d49===Fe||_0x246211===Ie)return 0x1;{const _0x260635=qs(_0x246211),_0x408263=qs(_0x508d49);return _0x260635!==null?_0x408263!==null?_0x260635-_0x408263===0x0?_0x246211['length']-_0x508d49['length']:_0x260635-_0x408263:-0x1:_0x408263!==null?0x1:_0x246211<_0x508d49?-0x1:0x1;}},ql=function(_0x279071,_0x248ab6){return _0x279071===_0x248ab6?0x0:_0x279071<_0x248ab6?-0x1:0x1;},_t=function(_0x297bd4,_0xd8b882){if(_0xd8b882&&_0x297bd4 in _0xd8b882)return _0xd8b882[_0x297bd4];throw new Error('Missing\x20required\x20key\x20('+_0x297bd4+')\x20in\x20object:\x20'+O(_0xd8b882));},Hi=function(_0x3dbc3e){if(typeof _0x3dbc3e!='object'||_0x3dbc3e===null)return O(_0x3dbc3e);const _0xf67ee9=[];for(const _0x4209e4 in _0x3dbc3e)_0xf67ee9['push'](_0x4209e4);_0xf67ee9['sort']();let _0x1dce69='{';for(let _0x3734f6=0x0;_0x3734f6<_0xf67ee9['length'];_0x3734f6++)_0x3734f6!==0x0&&(_0x1dce69+=','),_0x1dce69+=O(_0xf67ee9[_0x3734f6]),_0x1dce69+=':',_0x1dce69+=Hi(_0x3dbc3e[_0xf67ee9[_0x3734f6]]);return _0x1dce69+='}',_0x1dce69;},oo=function(_0x444a3a,_0x27a434){const _0x42f7dd=_0x444a3a['length'];if(_0x42f7dd<=_0x27a434)return[_0x444a3a];const _0x3a25bf=[];for(let _0x46853c=0x0;_0x46853c<_0x42f7dd;_0x46853c+=_0x27a434)_0x46853c+_0x27a434>_0x42f7dd?_0x3a25bf['push'](_0x444a3a['substring'](_0x46853c,_0x42f7dd)):_0x3a25bf['push'](_0x444a3a['substring'](_0x46853c,_0x46853c+_0x27a434));return _0x3a25bf;};function x(_0x5002a4,_0x45ab2e){for(const _0x2b8e45 in _0x5002a4)_0x5002a4['hasOwnProperty'](_0x2b8e45)&&_0x45ab2e(_0x2b8e45,_0x5002a4[_0x2b8e45]);}const ao=function(_0x4d7e37){f(!Vi(_0x4d7e37),'Invalid\x20JSON\x20number');const _0x3b54b8=0xb,_0x5d1300=0x34,_0x42ee9d=(0x1<<_0x3b54b8-0x1)-0x1;let _0x3c81e5,_0x26e5bb,_0x4e5f39,_0x4968f0,_0x1ce5fa;_0x4d7e37===0x0?(_0x26e5bb=0x0,_0x4e5f39=0x0,_0x3c81e5=0x1/_0x4d7e37===-0x1/0x0?0x1:0x0):(_0x3c81e5=_0x4d7e37<0x0,_0x4d7e37=Math['abs'](_0x4d7e37),_0x4d7e37>=Math['pow'](0x2,0x1-_0x42ee9d)?(_0x4968f0=Math['min'](Math['floor'](Math['log'](_0x4d7e37)/Math['LN2']),_0x42ee9d),_0x26e5bb=_0x4968f0+_0x42ee9d,_0x4e5f39=Math['round'](_0x4d7e37*Math['pow'](0x2,_0x5d1300-_0x4968f0)-Math['pow'](0x2,_0x5d1300))):(_0x26e5bb=0x0,_0x4e5f39=Math['round'](_0x4d7e37/Math['pow'](0x2,0x1-_0x42ee9d-_0x5d1300))));const _0x5c2ea9=[];for(_0x1ce5fa=_0x5d1300;_0x1ce5fa;_0x1ce5fa-=0x1)_0x5c2ea9['push'](_0x4e5f39%0x2?0x1:0x0),_0x4e5f39=Math['floor'](_0x4e5f39/0x2);for(_0x1ce5fa=_0x3b54b8;_0x1ce5fa;_0x1ce5fa-=0x1)_0x5c2ea9['push'](_0x26e5bb%0x2?0x1:0x0),_0x26e5bb=Math['floor'](_0x26e5bb/0x2);_0x5c2ea9['push'](_0x3c81e5?0x1:0x0),_0x5c2ea9['reverse']();const _0x1c7e53=_0x5c2ea9['join']('');let _0x269031='';for(_0x1ce5fa=0x0;_0x1ce5fa<0x40;_0x1ce5fa+=0x8){let _0x2b521d=parseInt(_0x1c7e53['substr'](_0x1ce5fa,0x8),0x2)['toString'](0x10);_0x2b521d['length']===0x1&&(_0x2b521d='0'+_0x2b521d),_0x269031=_0x269031+_0x2b521d;}return _0x269031['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x17c022,_0x4ce508){let _0x3c1340='Unknown\x20Error';_0x17c022==='too_big'?_0x3c1340='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x17c022==='permission_denied'?_0x3c1340='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x17c022==='unavailable'&&(_0x3c1340='The\x20service\x20is\x20unavailable');const _0x72734d=new Error(_0x17c022+'\x20at\x20'+_0x4ce508['_path']['toString']()+':\x20'+_0x3c1340);return _0x72734d['code']=_0x17c022['toUpperCase'](),_0x72734d;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x3f91b9){if(Yl['test'](_0x3f91b9)){const _0x44c928=Number(_0x3f91b9);if(_0x44c928>=Ql&&_0x44c928<=Jl)return _0x44c928;}return null;},ht=function(_0x230da7){try{_0x230da7();}catch(_0x1f4fb5){setTimeout(()=>{const _0x48537b=_0x1f4fb5['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x48537b),_0x1f4fb5;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x44b3bc,_0x4bff4f){const _0x37960a=setTimeout(_0x44b3bc,_0x4bff4f);return typeof _0x37960a=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x37960a):typeof _0x37960a=='object'&&_0x37960a['unref']&&_0x37960a['unref'](),_0x37960a;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x174107,_0x4fa411){this['appCheckProvider']=_0x4fa411,this['appName']=_0x174107['name'],$(_0x174107)&&_0x174107['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x174107['settings']['appCheckToken']),this['appCheck']=_0x4fa411==null?void 0x0:_0x4fa411['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4fa411==null||_0x4fa411['get']()['then'](_0x2cc71f=>this['appCheck']=_0x2cc71f);}['getToken'](_0x126727){if(this['serverAppAppCheckToken']){if(_0x126727)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x126727):new Promise((_0x2ae4f3,_0xcfb8f0)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x126727)['then'](_0x2ae4f3,_0xcfb8f0):_0x2ae4f3(null);},0x0);});}['addTokenChangeListener'](_0x265b17){var _0x3c70e6;(_0x3c70e6=this['appCheckProvider'])==null||_0x3c70e6['get']()['then'](_0x8f80e3=>_0x8f80e3['addTokenListener'](_0x265b17));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x37ff35,_0x93fd23,_0x5eb23e){this['appName_']=_0x37ff35,this['firebaseOptions_']=_0x93fd23,this['authProvider_']=_0x5eb23e,this['auth_']=null,this['auth_']=_0x5eb23e['getImmediate']({'optional':!0x0}),this['auth_']||_0x5eb23e['onInit'](_0x3e6d7e=>this['auth_']=_0x3e6d7e);}['getToken'](_0x4ca5c6){return this['auth_']?this['auth_']['getToken'](_0x4ca5c6)['catch'](_0x435f33=>_0x435f33&&_0x435f33['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x435f33)):new Promise((_0x19f672,_0x492fe2)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x4ca5c6)['then'](_0x19f672,_0x492fe2):_0x19f672(null);},0x0);});}['addTokenChangeListener'](_0x38de4a){this['auth_']?this['auth_']['addAuthTokenListener'](_0x38de4a):this['authProvider_']['get']()['then'](_0x7d0b1c=>_0x7d0b1c['addAuthTokenListener'](_0x38de4a));}['removeTokenChangeListener'](_0x3f893f){this['authProvider_']['get']()['then'](_0x28afb8=>_0x28afb8['removeAuthTokenListener'](_0x3f893f));}['notifyForInvalidToken'](){let _0x3e4d2a='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x3e4d2a+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x3e4d2a+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x3e4d2a+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x3e4d2a);}}class nn{constructor(_0xbed2f7){this['accessToken']=_0xbed2f7;}['getToken'](_0x247b9a){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x56efc5){_0x56efc5(this['accessToken']);}['removeTokenChangeListener'](_0x272efa){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x4094e1,_0x1e973b,_0x3860bf,_0x19d458,_0x3e2023=!0x1,_0x45c0f7='',_0x6df1df=!0x1,_0x3d365d=!0x1,_0x148a29=null){this['secure']=_0x1e973b,this['namespace']=_0x3860bf,this['webSocketOnly']=_0x19d458,this['nodeAdmin']=_0x3e2023,this['persistenceKey']=_0x45c0f7,this['includeNamespaceInQueryParams']=_0x6df1df,this['isUsingEmulator']=_0x3d365d,this['emulatorOptions']=_0x148a29,this['_host']=_0x4094e1['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x4094e1)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x168492){_0x168492!==this['internalHost']&&(this['internalHost']=_0x168492,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x2a4cc6=this['toURLString']();return this['persistenceKey']&&(_0x2a4cc6+='<'+this['persistenceKey']+'>'),_0x2a4cc6;}['toURLString'](){const _0x373174=this['secure']?'https://':'http://',_0xfb5476=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x373174+this['host']+'/'+_0xfb5476;}}function th(_0x32a039){return _0x32a039['host']!==_0x32a039['internalHost']||_0x32a039['isCustomHost']()||_0x32a039['includeNamespaceInQueryParams'];}function vo(_0xa98b5e,_0x4c6d62,_0x272eb8){f(typeof _0x4c6d62=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x272eb8=='object','typeof\x20params\x20must\x20==\x20object');let _0xcd36ea;if(_0x4c6d62===go)_0xcd36ea=(_0xa98b5e['secure']?'wss://':'ws://')+_0xa98b5e['internalHost']+'/.ws?';else{if(_0x4c6d62===mo)_0xcd36ea=(_0xa98b5e['secure']?'https://':'http://')+_0xa98b5e['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x4c6d62);}th(_0xa98b5e)&&(_0x272eb8['ns']=_0xa98b5e['namespace']);const _0xae9541=[];return x(_0x272eb8,(_0x1288a7,_0x541452)=>{_0xae9541['push'](_0x1288a7+'='+_0x541452);}),_0xcd36ea+_0xae9541['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x431bea,_0x4eeb71=0x1){J(this['counters_'],_0x431bea)||(this['counters_'][_0x431bea]=0x0),this['counters_'][_0x431bea]+=_0x4eeb71;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x4ac85e){const _0x48b917=_0x4ac85e['toString']();return ni[_0x48b917]||(ni[_0x48b917]=new nh()),ni[_0x48b917];}function ih(_0x5d7586,_0x48feb1){const _0x5a552d=_0x5d7586['toString']();return ii[_0x5a552d]||(ii[_0x5a552d]=_0x48feb1()),ii[_0x5a552d];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x18f465){this['onMessage_']=_0x18f465,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x4f3d0a,_0x4e9099){this['closeAfterResponse']=_0x4f3d0a,this['onClose']=_0x4e9099,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x12cafc,_0x1dc6b1){for(this['pendingResponses'][_0x12cafc]=_0x1dc6b1;this['pendingResponses'][this['currentResponseNum']];){const _0x182d6d=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x3afd13=0x0;_0x3afd13<_0x182d6d['length'];++_0x3afd13)_0x182d6d[_0x3afd13]&&ht(()=>{this['onMessage_'](_0x182d6d[_0x3afd13]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x3b4990,_0x269f97,_0x287614,_0xee26ab,_0xce6e7d,_0x4f635f,_0x5e727d){this['connId']=_0x3b4990,this['repoInfo']=_0x269f97,this['applicationId']=_0x287614,this['appCheckToken']=_0xee26ab,this['authToken']=_0xce6e7d,this['transportSessionId']=_0x4f635f,this['lastSessionId']=_0x5e727d,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x3b4990),this['stats_']=Gi(_0x269f97),this['urlFn']=_0x2d6daf=>(this['appCheckToken']&&(_0x2d6daf[vi]=this['appCheckToken']),vo(_0x269f97,mo,_0x2d6daf));}['open'](_0x1fcf65,_0xc83d89){this['curSegmentNum']=0x0,this['onDisconnect_']=_0xc83d89,this['myPacketOrderer']=new sh(_0x1fcf65),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x41e901)=>{const [_0x4e2376,_0x3a157c,_0x2d1b30,_0x24d2a9,_0xc08163]=_0x41e901;if(this['incrementIncomingBytes_'](_0x41e901),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x4e2376===zs)this['id']=_0x3a157c,this['password']=_0x2d1b30;else{if(_0x4e2376===rh)_0x3a157c?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x3a157c,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x4e2376);}}},(..._0x268d07)=>{const [_0x1cb205,_0xbb62fa]=_0x268d07;this['incrementIncomingBytes_'](_0x268d07),this['myPacketOrderer']['handleResponse'](_0x1cb205,_0xbb62fa);},()=>{this['onClosed_']();},this['urlFn']);const _0x395798={};_0x395798[zs]='t',_0x395798[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x395798[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x395798[co]=$i,this['transportSessionId']&&(_0x395798[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x395798[po]=this['lastSessionId']),this['applicationId']&&(_0x395798[_o]=this['applicationId']),this['appCheckToken']&&(_0x395798[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x395798[ho]=uo);const _0x9325c6=this['urlFn'](_0x395798);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x9325c6),this['scriptTagHolder']['addTag'](_0x9325c6,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x899f05){const _0xa08433=O(_0x899f05);this['bytesSent']+=_0xa08433['length'],this['stats_']['incrementCounter']('bytes_sent',_0xa08433['length']);const _0x5b155c=Hr(_0xa08433),_0x53d467=oo(_0x5b155c,fh);for(let _0xfa2741=0x0;_0xfa2741<_0x53d467['length'];_0xfa2741++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x53d467['length'],_0x53d467[_0xfa2741]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x4bcd00,_0x53acd3){this['myDisconnFrame']=document['createElement']('iframe');const _0x38aeab={};_0x38aeab[dh]='t',_0x38aeab[Eo]=_0x4bcd00,_0x38aeab[Io]=_0x53acd3,this['myDisconnFrame']['src']=this['urlFn'](_0x38aeab),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x335589){const _0x10b42b=O(_0x335589)['length'];this['bytesReceived']+=_0x10b42b,this['stats_']['incrementCounter']('bytes_received',_0x10b42b);}}class qi{constructor(_0x1e5cf6,_0x254134,_0x23ba12,_0x1f8867){this['onDisconnect']=_0x23ba12,this['urlFn']=_0x1f8867,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x1e5cf6,window[ah+this['uniqueCallbackIdentifier']]=_0x254134,this['myIFrame']=qi['createIFrame_']();let _0x222596='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x222596='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x11812b='<html><body>'+_0x222596+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x11812b),this['myIFrame']['doc']['close']();}catch(_0x59a99f){L('frame\x20writing\x20exception'),_0x59a99f['stack']&&L(_0x59a99f['stack']),L(_0x59a99f);}}}static['createIFrame_'](){const _0x38aabd=document['createElement']('iframe');if(_0x38aabd['style']['display']='none',document['body']){document['body']['appendChild'](_0x38aabd);try{_0x38aabd['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x5826b3=document['domain'];_0x38aabd['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x5826b3+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x38aabd['contentDocument']?_0x38aabd['doc']=_0x38aabd['contentDocument']:_0x38aabd['contentWindow']?_0x38aabd['doc']=_0x38aabd['contentWindow']['document']:_0x38aabd['document']&&(_0x38aabd['doc']=_0x38aabd['document']),_0x38aabd;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x383ec6=this['onDisconnect'];_0x383ec6&&(this['onDisconnect']=null,_0x383ec6());}['startLongPoll'](_0x14661b,_0x3029fc){for(this['myID']=_0x14661b,this['myPW']=_0x3029fc,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x5c57dc={};_0x5c57dc[Eo]=this['myID'],_0x5c57dc[Io]=this['myPW'],_0x5c57dc[wo]=this['currentSerial'];let _0x422fb1=this['urlFn'](_0x5c57dc),_0xed84a8='',_0x402c3b=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0xed84a8['length']<=Co;){const _0x52d9a8=this['pendingSegs']['shift']();_0xed84a8=_0xed84a8+'&'+lh+_0x402c3b+'='+_0x52d9a8['seg']+'&'+hh+_0x402c3b+'='+_0x52d9a8['ts']+'&'+uh+_0x402c3b+'='+_0x52d9a8['d'],_0x402c3b++;}return _0x422fb1=_0x422fb1+_0xed84a8,this['addLongPollTag_'](_0x422fb1,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x57074c,_0xd0e55b,_0xff05a6){this['pendingSegs']['push']({'seg':_0x57074c,'ts':_0xd0e55b,'d':_0xff05a6}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0xb1d312,_0x366af2){this['outstandingRequests']['add'](_0x366af2);const _0x73f167=()=>{this['outstandingRequests']['delete'](_0x366af2),this['newRequest_']();},_0x54c3b2=setTimeout(_0x73f167,Math['floor'](ph)),_0x4e9537=()=>{clearTimeout(_0x54c3b2),_0x73f167();};this['addTag'](_0xb1d312,_0x4e9537);}['addTag'](_0x45b89a,_0x3636d7){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x34d28c=this['myIFrame']['doc']['createElement']('script');_0x34d28c['type']='text/javascript',_0x34d28c['async']=!0x0,_0x34d28c['src']=_0x45b89a,_0x34d28c['onload']=_0x34d28c['onreadystatechange']=function(){const _0x2f33d8=_0x34d28c['readyState'];(!_0x2f33d8||_0x2f33d8==='loaded'||_0x2f33d8==='complete')&&(_0x34d28c['onload']=_0x34d28c['onreadystatechange']=null,_0x34d28c['parentNode']&&_0x34d28c['parentNode']['removeChild'](_0x34d28c),_0x3636d7());},_0x34d28c['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x45b89a),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x34d28c);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x5cf3e7,_0xf78396,_0x1eaae4,_0x56ccfb,_0x463946,_0x16939b,_0x56f13a){this['connId']=_0x5cf3e7,this['applicationId']=_0x1eaae4,this['appCheckToken']=_0x56ccfb,this['authToken']=_0x463946,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0xf78396),this['connURL']=z['connectionURL_'](_0xf78396,_0x16939b,_0x56f13a,_0x56ccfb,_0x1eaae4),this['nodeAdmin']=_0xf78396['nodeAdmin'];}static['connectionURL_'](_0x4affea,_0x349650,_0x59949f,_0x28749c,_0x50d280){const _0x1089d8={};return _0x1089d8[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x1089d8[ho]=uo),_0x349650&&(_0x1089d8[lo]=_0x349650),_0x59949f&&(_0x1089d8[po]=_0x59949f),_0x28749c&&(_0x1089d8[vi]=_0x28749c),_0x50d280&&(_0x1089d8[_o]=_0x50d280),vo(_0x4affea,go,_0x1089d8);}['open'](_0x44e954,_0x21d18e){this['onDisconnect']=_0x21d18e,this['onMessage']=_0x44e954,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x25988b;_c(),this['mySock']=new un(this['connURL'],[],_0x25988b);}catch(_0x3ccfdc){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x3f6acc=_0x3ccfdc['message']||_0x3ccfdc['data'];_0x3f6acc&&this['log_'](_0x3f6acc),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x303957=>{this['handleIncomingFrame'](_0x303957);},this['mySock']['onerror']=_0x135a62=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x6d7449=_0x135a62['message']||_0x135a62['data'];_0x6d7449&&this['log_'](_0x6d7449),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x2ef2e1=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x1adeb3=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x4d1cf7=navigator['userAgent']['match'](_0x1adeb3);_0x4d1cf7&&_0x4d1cf7['length']>0x1&&parseFloat(_0x4d1cf7[0x1])<4.4&&(_0x2ef2e1=!0x0);}return!_0x2ef2e1&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0xa376c7){if(this['frames']['push'](_0xa376c7),this['frames']['length']===this['totalFrames']){const _0x3b9d63=this['frames']['join']('');this['frames']=null;const _0x59aeae=At(_0x3b9d63);this['onMessage'](_0x59aeae);}}['handleNewFrameCount_'](_0x1aba5b){this['totalFrames']=_0x1aba5b,this['frames']=[];}['extractFrameCount_'](_0x431b50){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x431b50['length']<=0x6){const _0x296e80=Number(_0x431b50);if(!isNaN(_0x296e80))return this['handleNewFrameCount_'](_0x296e80),null;}return this['handleNewFrameCount_'](0x1),_0x431b50;}['handleIncomingFrame'](_0x502372){if(this['mySock']===null)return;const _0x3f5dde=_0x502372['data'];if(this['bytesReceived']+=_0x3f5dde['length'],this['stats_']['incrementCounter']('bytes_received',_0x3f5dde['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x3f5dde);else{const _0x1cf7cd=this['extractFrameCount_'](_0x3f5dde);_0x1cf7cd!==null&&this['appendFrame_'](_0x1cf7cd);}}['send'](_0x14533b){this['resetKeepAlive']();const _0x5e8864=O(_0x14533b);this['bytesSent']+=_0x5e8864['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5e8864['length']);const _0x2bdb9c=oo(_0x5e8864,gh);_0x2bdb9c['length']>0x1&&this['sendString_'](String(_0x2bdb9c['length']));for(let _0x2c7bb2=0x0;_0x2c7bb2<_0x2bdb9c['length'];_0x2c7bb2++)this['sendString_'](_0x2bdb9c[_0x2c7bb2]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x16be76){try{this['mySock']['send'](_0x16be76);}catch(_0x4570fe){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x4570fe['message']||_0x4570fe['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x480181){this['initTransports_'](_0x480181);}['initTransports_'](_0x4b3485){const _0x2edc43=z&&z['isAvailable']();let _0x302d1b=_0x2edc43&&!z['previouslyFailed']();if(_0x4b3485['webSocketOnly']&&(_0x2edc43||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x302d1b=!0x0),_0x302d1b)this['transports_']=[z];else{const _0x5ec0da=this['transports_']=[];for(const _0xc850b8 of Nt['ALL_TRANSPORTS'])_0xc850b8&&_0xc850b8['isAvailable']()&&_0x5ec0da['push'](_0xc850b8);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x2c7819,_0x28a92a,_0x8017e7,_0x16d272,_0x535cca,_0x3b7a22,_0x460de9,_0x5c2bf3,_0x427f1f,_0x1586ab){this['id']=_0x2c7819,this['repoInfo_']=_0x28a92a,this['applicationId_']=_0x8017e7,this['appCheckToken_']=_0x16d272,this['authToken_']=_0x535cca,this['onMessage_']=_0x3b7a22,this['onReady_']=_0x460de9,this['onDisconnect_']=_0x5c2bf3,this['onKill_']=_0x427f1f,this['lastSessionId']=_0x1586ab,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x28a92a),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x24e3e8=this['transportManager_']['initialTransport']();this['conn_']=new _0x24e3e8(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x24e3e8['responsesRequiredToBeHealthy']||0x0;const _0x164909=this['connReceiver_'](this['conn_']),_0x3eecbd=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x164909,_0x3eecbd);},Math['floor'](0x0));const _0x599c95=_0x24e3e8['healthyTimeout']||0x0;_0x599c95>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x599c95)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x5f249f){return _0xcb6ae1=>{_0x5f249f===this['conn_']?this['onConnectionLost_'](_0xcb6ae1):_0x5f249f===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x142832){return _0x3c0575=>{this['state_']!==0x2&&(_0x142832===this['rx_']?this['onPrimaryMessageReceived_'](_0x3c0575):_0x142832===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x3c0575):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x45d8d1){const _0x1955c7={'t':'d','d':_0x45d8d1};this['sendData_'](_0x1955c7);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x475cdc){if(si in _0x475cdc){const _0x2d32bc=_0x475cdc[si];_0x2d32bc===Qs?this['upgradeIfSecondaryHealthy_']():_0x2d32bc===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x2d32bc===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x15ca93){const _0x207eeb=_t('t',_0x15ca93),_0x1fef39=_t('d',_0x15ca93);if(_0x207eeb==='c')this['onSecondaryControl_'](_0x1fef39);else{if(_0x207eeb==='d')this['pendingDataMessages']['push'](_0x1fef39);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x207eeb);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x4a5e42){const _0x5779c4=_t('t',_0x4a5e42),_0x348240=_t('d',_0x4a5e42);_0x5779c4==='c'?this['onControl_'](_0x348240):_0x5779c4==='d'&&this['onDataMessage_'](_0x348240);}['onDataMessage_'](_0x593bfa){this['onPrimaryResponse_'](),this['onMessage_'](_0x593bfa);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x151657){const _0x19a5f9=_t(si,_0x151657);if(js in _0x151657){const _0x3e6fea=_0x151657[js];if(_0x19a5f9===Th){const _0x384528={..._0x3e6fea};this['repoInfo_']['isUsingEmulator']&&(_0x384528['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x384528);}else{if(_0x19a5f9===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x2cc483=0x0;_0x2cc483<this['pendingDataMessages']['length'];++_0x2cc483)this['onDataMessage_'](this['pendingDataMessages'][_0x2cc483]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x19a5f9===wh?this['onConnectionShutdown_'](_0x3e6fea):_0x19a5f9===Ks?this['onReset_'](_0x3e6fea):_0x19a5f9===Ch?yi('Server\x20Error:\x20'+_0x3e6fea):_0x19a5f9===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x19a5f9);}}}['onHandshake_'](_0x66deb7){const _0x503da8=_0x66deb7['ts'],_0x4842ec=_0x66deb7['v'],_0x50a12a=_0x66deb7['h'];this['sessionId']=_0x66deb7['s'],this['repoInfo_']['host']=_0x50a12a,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x503da8),$i!==_0x4842ec&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x15a3fa=this['transportManager_']['upgradeTransport']();_0x15a3fa&&this['startUpgrade_'](_0x15a3fa);}['startUpgrade_'](_0x4dfb01){this['secondaryConn_']=new _0x4dfb01(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x4dfb01['responsesRequiredToBeHealthy']||0x0;const _0x4087d8=this['connReceiver_'](this['secondaryConn_']),_0x198f7e=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x4087d8,_0x198f7e),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x389116){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x389116),this['repoInfo_']['host']=_0x389116,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x2ae28c,_0x22dd72){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x2ae28c,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x22dd72,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x64f4ae=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x64f4ae||this['rx_']===_0x64f4ae)&&this['close']();}['onConnectionLost_'](_0x540777){this['conn_']=null,!_0x540777&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x4ec774){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x4ec774),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x29b9a3){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x29b9a3);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x33930a,_0x4a5642,_0x6b5246,_0x2804f5){}['merge'](_0x49776f,_0x390806,_0x1f0184,_0xbe204){}['refreshAuthToken'](_0x515365){}['refreshAppCheckToken'](_0x3ff1b3){}['onDisconnectPut'](_0x4cbf50,_0xe9bcf3,_0x1679ae){}['onDisconnectMerge'](_0x152632,_0x223376,_0x1d49b2){}['onDisconnectCancel'](_0x4e0cfe,_0x42bfa4){}['reportStats'](_0x37788c){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x2ff0bf){this['allowedEvents_']=_0x2ff0bf,this['listeners_']={},f(Array['isArray'](_0x2ff0bf)&&_0x2ff0bf['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x55ec20,..._0x130487){if(Array['isArray'](this['listeners_'][_0x55ec20])){const _0x4d67ac=[...this['listeners_'][_0x55ec20]];for(let _0x416492=0x0;_0x416492<_0x4d67ac['length'];_0x416492++)_0x4d67ac[_0x416492]['callback']['apply'](_0x4d67ac[_0x416492]['context'],_0x130487);}}['on'](_0x57bca0,_0xa114d0,_0x45877c){this['validateEventType_'](_0x57bca0),this['listeners_'][_0x57bca0]=this['listeners_'][_0x57bca0]||[],this['listeners_'][_0x57bca0]['push']({'callback':_0xa114d0,'context':_0x45877c});const _0x138629=this['getInitialEvent'](_0x57bca0);_0x138629&&_0xa114d0['apply'](_0x45877c,_0x138629);}['off'](_0x22d618,_0x5e467d,_0xd40b68){this['validateEventType_'](_0x22d618);const _0x10e7ba=this['listeners_'][_0x22d618]||[];for(let _0x5e2d64=0x0;_0x5e2d64<_0x10e7ba['length'];_0x5e2d64++)if(_0x10e7ba[_0x5e2d64]['callback']===_0x5e467d&&(!_0xd40b68||_0xd40b68===_0x10e7ba[_0x5e2d64]['context'])){_0x10e7ba['splice'](_0x5e2d64,0x1);return;}}['validateEventType_'](_0x3fd9f3){f(this['allowedEvents_']['find'](_0xcc0526=>_0xcc0526===_0x3fd9f3),'Unknown\x20event:\x20'+_0x3fd9f3);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0xe44710){return f(_0xe44710==='online','Unknown\x20event\x20type:\x20'+_0xe44710),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0xa41684,_0x16db76){if(_0x16db76===void 0x0){this['pieces_']=_0xa41684['split']('/');let _0x206872=0x0;for(let _0x565fba=0x0;_0x565fba<this['pieces_']['length'];_0x565fba++)this['pieces_'][_0x565fba]['length']>0x0&&(this['pieces_'][_0x206872]=this['pieces_'][_0x565fba],_0x206872++);this['pieces_']['length']=_0x206872,this['pieceNum_']=0x0;}else this['pieces_']=_0xa41684,this['pieceNum_']=_0x16db76;}['toString'](){let _0x2c3b57='';for(let _0x260114=this['pieceNum_'];_0x260114<this['pieces_']['length'];_0x260114++)this['pieces_'][_0x260114]!==''&&(_0x2c3b57+='/'+this['pieces_'][_0x260114]);return _0x2c3b57||'/';}}function w(){return new C('');}function y(_0xa876e6){return _0xa876e6['pieceNum_']>=_0xa876e6['pieces_']['length']?null:_0xa876e6['pieces_'][_0xa876e6['pieceNum_']];}function we(_0xf6017a){return _0xf6017a['pieces_']['length']-_0xf6017a['pieceNum_'];}function b(_0x497d8f){let _0x53456c=_0x497d8f['pieceNum_'];return _0x53456c<_0x497d8f['pieces_']['length']&&_0x53456c++,new C(_0x497d8f['pieces_'],_0x53456c);}function zi(_0x126196){return _0x126196['pieceNum_']<_0x126196['pieces_']['length']?_0x126196['pieces_'][_0x126196['pieces_']['length']-0x1]:null;}function bh(_0x28d224){let _0x71a486='';for(let _0x42f374=_0x28d224['pieceNum_'];_0x42f374<_0x28d224['pieces_']['length'];_0x42f374++)_0x28d224['pieces_'][_0x42f374]!==''&&(_0x71a486+='/'+encodeURIComponent(String(_0x28d224['pieces_'][_0x42f374])));return _0x71a486||'/';}function Pt(_0x3a4aca,_0x4a2701=0x0){return _0x3a4aca['pieces_']['slice'](_0x3a4aca['pieceNum_']+_0x4a2701);}function Ro(_0x3abf39){if(_0x3abf39['pieceNum_']>=_0x3abf39['pieces_']['length'])return null;const _0x296146=[];for(let _0x2521ad=_0x3abf39['pieceNum_'];_0x2521ad<_0x3abf39['pieces_']['length']-0x1;_0x2521ad++)_0x296146['push'](_0x3abf39['pieces_'][_0x2521ad]);return new C(_0x296146,0x0);}function k(_0x242b7e,_0x172128){const _0x18a434=[];for(let _0x2e2a2e=_0x242b7e['pieceNum_'];_0x2e2a2e<_0x242b7e['pieces_']['length'];_0x2e2a2e++)_0x18a434['push'](_0x242b7e['pieces_'][_0x2e2a2e]);if(_0x172128 instanceof C){for(let _0x3915da=_0x172128['pieceNum_'];_0x3915da<_0x172128['pieces_']['length'];_0x3915da++)_0x18a434['push'](_0x172128['pieces_'][_0x3915da]);}else{const _0x259a9f=_0x172128['split']('/');for(let _0x4a75ac=0x0;_0x4a75ac<_0x259a9f['length'];_0x4a75ac++)_0x259a9f[_0x4a75ac]['length']>0x0&&_0x18a434['push'](_0x259a9f[_0x4a75ac]);}return new C(_0x18a434,0x0);}function v(_0x38b3ff){return _0x38b3ff['pieceNum_']>=_0x38b3ff['pieces_']['length'];}function F(_0xedef6f,_0x4c501){const _0x46fd81=y(_0xedef6f),_0x163ac3=y(_0x4c501);if(_0x46fd81===null)return _0x4c501;if(_0x46fd81===_0x163ac3)return F(b(_0xedef6f),b(_0x4c501));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x4c501+')\x20is\x20not\x20within\x20outerPath\x20('+_0xedef6f+')');}function Rh(_0x35c6b1,_0x3dc72d){const _0x5ec5d7=Pt(_0x35c6b1,0x0),_0x2aa397=Pt(_0x3dc72d,0x0);for(let _0x3d9eed=0x0;_0x3d9eed<_0x5ec5d7['length']&&_0x3d9eed<_0x2aa397['length'];_0x3d9eed++){const _0x1ed413=He(_0x5ec5d7[_0x3d9eed],_0x2aa397[_0x3d9eed]);if(_0x1ed413!==0x0)return _0x1ed413;}return _0x5ec5d7['length']===_0x2aa397['length']?0x0:_0x5ec5d7['length']<_0x2aa397['length']?-0x1:0x1;}function ji(_0x26b228,_0x55c6b5){if(we(_0x26b228)!==we(_0x55c6b5))return!0x1;for(let _0x26257f=_0x26b228['pieceNum_'],_0x5cf6a8=_0x55c6b5['pieceNum_'];_0x26257f<=_0x26b228['pieces_']['length'];_0x26257f++,_0x5cf6a8++)if(_0x26b228['pieces_'][_0x26257f]!==_0x55c6b5['pieces_'][_0x5cf6a8])return!0x1;return!0x0;}function G(_0x458b5d,_0x2c5a09){let _0x217598=_0x458b5d['pieceNum_'],_0x2729f0=_0x2c5a09['pieceNum_'];if(we(_0x458b5d)>we(_0x2c5a09))return!0x1;for(;_0x217598<_0x458b5d['pieces_']['length'];){if(_0x458b5d['pieces_'][_0x217598]!==_0x2c5a09['pieces_'][_0x2729f0])return!0x1;++_0x217598,++_0x2729f0;}return!0x0;}class Ah{constructor(_0x5b5d40,_0x1097b3){this['errorPrefix_']=_0x1097b3,this['parts_']=Pt(_0x5b5d40,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x59bad3=0x0;_0x59bad3<this['parts_']['length'];_0x59bad3++)this['byteLength_']+=On(this['parts_'][_0x59bad3]);Ao(this);}}function kh(_0x230472,_0xa199db){_0x230472['parts_']['length']>0x0&&(_0x230472['byteLength_']+=0x1),_0x230472['parts_']['push'](_0xa199db),_0x230472['byteLength_']+=On(_0xa199db),Ao(_0x230472);}function Nh(_0x2c2f85){const _0x459292=_0x2c2f85['parts_']['pop']();_0x2c2f85['byteLength_']-=On(_0x459292),_0x2c2f85['parts_']['length']>0x0&&(_0x2c2f85['byteLength_']-=0x1);}function Ao(_0x5c5a09){if(_0x5c5a09['byteLength_']>er)throw new Error(_0x5c5a09['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x5c5a09['byteLength_']+').');if(_0x5c5a09['parts_']['length']>Zs)throw new Error(_0x5c5a09['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x5c5a09));}function Pe(_0x5b9db5){return _0x5b9db5['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x5b9db5['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x22d30d,_0x2d49cb;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x2d49cb='visibilitychange',_0x22d30d='hidden'):typeof document['mozHidden']<'u'?(_0x2d49cb='mozvisibilitychange',_0x22d30d='mozHidden'):typeof document['msHidden']<'u'?(_0x2d49cb='msvisibilitychange',_0x22d30d='msHidden'):typeof document['webkitHidden']<'u'&&(_0x2d49cb='webkitvisibilitychange',_0x22d30d='webkitHidden')),this['visible_']=!0x0,_0x2d49cb&&document['addEventListener'](_0x2d49cb,()=>{const _0x5c5f6a=!document[_0x22d30d];_0x5c5f6a!==this['visible_']&&(this['visible_']=_0x5c5f6a,this['trigger']('visible',_0x5c5f6a));},!0x1);}['getInitialEvent'](_0x53dc16){return f(_0x53dc16==='visible','Unknown\x20event\x20type:\x20'+_0x53dc16),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x48b02c,_0x397c54,_0xa953ae,_0x62ec32,_0x16c92b,_0x13571f,_0xd132da,_0x5b0788){if(super(),this['repoInfo_']=_0x48b02c,this['applicationId_']=_0x397c54,this['onDataUpdate_']=_0xa953ae,this['onConnectStatus_']=_0x62ec32,this['onServerInfoUpdate_']=_0x16c92b,this['authTokenProvider_']=_0x13571f,this['appCheckTokenProvider_']=_0xd132da,this['authOverride_']=_0x5b0788,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x5b0788)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x48b02c['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x4c056b,_0x1a8421,_0x2bc060){const _0x36009e=++this['requestNumber_'],_0xe8cb9e={'r':_0x36009e,'a':_0x4c056b,'b':_0x1a8421};this['log_'](O(_0xe8cb9e)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0xe8cb9e),_0x2bc060&&(this['requestCBHash_'][_0x36009e]=_0x2bc060);}['get'](_0x2f9ed4){this['initConnection_']();const _0x4114ff=new ot(),_0x47e404={'action':'g','request':{'p':_0x2f9ed4['_path']['toString'](),'q':_0x2f9ed4['_queryObject']},'onComplete':_0x5ee2f4=>{const _0x39584c=_0x5ee2f4['d'];_0x5ee2f4['s']==='ok'?_0x4114ff['resolve'](_0x39584c):_0x4114ff['reject'](_0x39584c);}};this['outstandingGets_']['push'](_0x47e404),this['outstandingGetCount_']++;const _0x429cd7=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x429cd7),_0x4114ff['promise'];}['listen'](_0x59142a,_0x3641da,_0x34f720,_0x1f5b87){this['initConnection_']();const _0x2ec286=_0x59142a['_queryIdentifier'],_0x1ec0fd=_0x59142a['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1ec0fd+'\x20'+_0x2ec286),this['listens']['has'](_0x1ec0fd)||this['listens']['set'](_0x1ec0fd,new Map()),f(_0x59142a['_queryParams']['isDefault']()||!_0x59142a['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x1ec0fd)['has'](_0x2ec286),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0xe888bf={'onComplete':_0x1f5b87,'hashFn':_0x3641da,'query':_0x59142a,'tag':_0x34f720};this['listens']['get'](_0x1ec0fd)['set'](_0x2ec286,_0xe888bf),this['connected_']&&this['sendListen_'](_0xe888bf);}['sendGet_'](_0x5458e9){const _0x172ca1=this['outstandingGets_'][_0x5458e9];this['sendRequest']('g',_0x172ca1['request'],_0x52b710=>{delete this['outstandingGets_'][_0x5458e9],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x172ca1['onComplete']&&_0x172ca1['onComplete'](_0x52b710);});}['sendListen_'](_0x112cb0){const _0x27344b=_0x112cb0['query'],_0x37e38a=_0x27344b['_path']['toString'](),_0x47d98b=_0x27344b['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x37e38a+'\x20for\x20'+_0x47d98b);const _0x48f388={'p':_0x37e38a},_0x195424='q';_0x112cb0['tag']&&(_0x48f388['q']=_0x27344b['_queryObject'],_0x48f388['t']=_0x112cb0['tag']),_0x48f388['h']=_0x112cb0['hashFn'](),this['sendRequest'](_0x195424,_0x48f388,_0x4a237c=>{const _0x292d90=_0x4a237c['d'],_0xf4f95=_0x4a237c['s'];se['warnOnListenWarnings_'](_0x292d90,_0x27344b),(this['listens']['get'](_0x37e38a)&&this['listens']['get'](_0x37e38a)['get'](_0x47d98b))===_0x112cb0&&(this['log_']('listen\x20response',_0x4a237c),_0xf4f95!=='ok'&&this['removeListen_'](_0x37e38a,_0x47d98b),_0x112cb0['onComplete']&&_0x112cb0['onComplete'](_0xf4f95,_0x292d90));});}static['warnOnListenWarnings_'](_0x4a4480,_0x144062){if(_0x4a4480&&typeof _0x4a4480=='object'&&J(_0x4a4480,'w')){const _0x4d71c8=De(_0x4a4480,'w');if(Array['isArray'](_0x4d71c8)&&~_0x4d71c8['indexOf']('no_index')){const _0x575a2a='\x22.indexOn\x22:\x20\x22'+_0x144062['_queryParams']['getIndex']()['toString']()+'\x22',_0x59fb8a=_0x144062['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x575a2a+'\x20at\x20'+_0x59fb8a+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x3396c8){this['authToken_']=_0x3396c8,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x3396c8);}['reduceReconnectDelayIfAdminCredential_'](_0xd0edb6){(_0xd0edb6&&_0xd0edb6['length']===0x28||wc(_0xd0edb6))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x895a58){this['appCheckToken_']=_0x895a58,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x7f8073=this['authToken_'],_0x196a0a=Ic(_0x7f8073)?'auth':'gauth',_0xff29c2={'cred':_0x7f8073};this['authOverride_']===null?_0xff29c2['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0xff29c2['authvar']=this['authOverride_']),this['sendRequest'](_0x196a0a,_0xff29c2,_0x4557b3=>{const _0x195b6e=_0x4557b3['s'],_0xc4c5d3=_0x4557b3['d']||'error';this['authToken_']===_0x7f8073&&(_0x195b6e==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x195b6e,_0xc4c5d3));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x10af24=>{const _0x52e27e=_0x10af24['s'],_0x435247=_0x10af24['d']||'error';_0x52e27e==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x52e27e,_0x435247);});}['unlisten'](_0x35a848,_0x3a55d0){const _0x45ff21=_0x35a848['_path']['toString'](),_0xd29488=_0x35a848['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x45ff21+'\x20'+_0xd29488),f(_0x35a848['_queryParams']['isDefault']()||!_0x35a848['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x45ff21,_0xd29488)&&this['connected_']&&this['sendUnlisten_'](_0x45ff21,_0xd29488,_0x35a848['_queryObject'],_0x3a55d0);}['sendUnlisten_'](_0x11ead3,_0x55531e,_0x36d6b5,_0x1b66e7){this['log_']('Unlisten\x20on\x20'+_0x11ead3+'\x20for\x20'+_0x55531e);const _0x3cbad9={'p':_0x11ead3},_0x4b0340='n';_0x1b66e7&&(_0x3cbad9['q']=_0x36d6b5,_0x3cbad9['t']=_0x1b66e7),this['sendRequest'](_0x4b0340,_0x3cbad9);}['onDisconnectPut'](_0x793cee,_0x166d72,_0x1ce673){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x793cee,_0x166d72,_0x1ce673):this['onDisconnectRequestQueue_']['push']({'pathString':_0x793cee,'action':'o','data':_0x166d72,'onComplete':_0x1ce673});}['onDisconnectMerge'](_0x1bfec7,_0x400498,_0x105efc){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x1bfec7,_0x400498,_0x105efc):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1bfec7,'action':'om','data':_0x400498,'onComplete':_0x105efc});}['onDisconnectCancel'](_0x47c844,_0x4d5ca2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x47c844,null,_0x4d5ca2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x47c844,'action':'oc','data':null,'onComplete':_0x4d5ca2});}['sendOnDisconnect_'](_0x3a96ae,_0x10efc8,_0x111db1,_0x227ce9){const _0x24f872={'p':_0x10efc8,'d':_0x111db1};this['log_']('onDisconnect\x20'+_0x3a96ae,_0x24f872),this['sendRequest'](_0x3a96ae,_0x24f872,_0x52a83f=>{_0x227ce9&&setTimeout(()=>{_0x227ce9(_0x52a83f['s'],_0x52a83f['d']);},Math['floor'](0x0));});}['put'](_0x14737b,_0x8dece4,_0x536b86,_0x427422){this['putInternal']('p',_0x14737b,_0x8dece4,_0x536b86,_0x427422);}['merge'](_0x15e11e,_0x59037f,_0x54d50e,_0x51e87b){this['putInternal']('m',_0x15e11e,_0x59037f,_0x54d50e,_0x51e87b);}['putInternal'](_0x7b10a7,_0x357952,_0x28394c,_0x227bce,_0x3c1ca1){this['initConnection_']();const _0x43d55c={'p':_0x357952,'d':_0x28394c};_0x3c1ca1!==void 0x0&&(_0x43d55c['h']=_0x3c1ca1),this['outstandingPuts_']['push']({'action':_0x7b10a7,'request':_0x43d55c,'onComplete':_0x227bce}),this['outstandingPutCount_']++;const _0x2015be=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x2015be):this['log_']('Buffering\x20put:\x20'+_0x357952);}['sendPut_'](_0x4abb24){const _0x1fe134=this['outstandingPuts_'][_0x4abb24]['action'],_0x82fac8=this['outstandingPuts_'][_0x4abb24]['request'],_0x1e8116=this['outstandingPuts_'][_0x4abb24]['onComplete'];this['outstandingPuts_'][_0x4abb24]['queued']=this['connected_'],this['sendRequest'](_0x1fe134,_0x82fac8,_0x41654e=>{this['log_'](_0x1fe134+'\x20response',_0x41654e),delete this['outstandingPuts_'][_0x4abb24],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x1e8116&&_0x1e8116(_0x41654e['s'],_0x41654e['d']);});}['reportStats'](_0x4bd5bd){if(this['connected_']){const _0x97fa5d={'c':_0x4bd5bd};this['log_']('reportStats',_0x97fa5d),this['sendRequest']('s',_0x97fa5d,_0x40279b=>{if(_0x40279b['s']!=='ok'){const _0x49aa3e=_0x40279b['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x49aa3e);}});}}['onDataMessage_'](_0x426fa8){if('r'in _0x426fa8){this['log_']('from\x20server:\x20'+O(_0x426fa8));const _0x276041=_0x426fa8['r'],_0x794fe=this['requestCBHash_'][_0x276041];_0x794fe&&(delete this['requestCBHash_'][_0x276041],_0x794fe(_0x426fa8['b']));}else{if('error'in _0x426fa8)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x426fa8['error'];'a'in _0x426fa8&&this['onDataPush_'](_0x426fa8['a'],_0x426fa8['b']);}}['onDataPush_'](_0xa7762c,_0x494ad1){this['log_']('handleServerMessage',_0xa7762c,_0x494ad1),_0xa7762c==='d'?this['onDataUpdate_'](_0x494ad1['p'],_0x494ad1['d'],!0x1,_0x494ad1['t']):_0xa7762c==='m'?this['onDataUpdate_'](_0x494ad1['p'],_0x494ad1['d'],!0x0,_0x494ad1['t']):_0xa7762c==='c'?this['onListenRevoked_'](_0x494ad1['p'],_0x494ad1['q']):_0xa7762c==='ac'?this['onAuthRevoked_'](_0x494ad1['s'],_0x494ad1['d']):_0xa7762c==='apc'?this['onAppCheckRevoked_'](_0x494ad1['s'],_0x494ad1['d']):_0xa7762c==='sd'?this['onSecurityDebugPacket_'](_0x494ad1):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0xa7762c)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x2a4193,_0x4ea4f1){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x2a4193),this['lastSessionId']=_0x4ea4f1,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x10bf87){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x10bf87));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x14b6f9){_0x14b6f9&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x14b6f9;}['onOnline_'](_0x56138a){_0x56138a?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x2de5c5=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x52d2a9=Math['max'](0x0,this['reconnectDelay_']-_0x2de5c5);_0x52d2a9=Math['random']()*_0x52d2a9,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x52d2a9+'ms'),this['scheduleConnect_'](_0x52d2a9),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x46d3ce=this['onDataMessage_']['bind'](this),_0x568b3a=this['onReady_']['bind'](this),_0x2a34d4=this['onRealtimeDisconnect_']['bind'](this),_0xe3db32=this['id']+':'+se['nextConnectionId_']++,_0x114d20=this['lastSessionId'];let _0x517c4c=!0x1,_0x33945a=null;const _0x2db81d=function(){_0x33945a?_0x33945a['close']():(_0x517c4c=!0x0,_0x2a34d4());},_0x226b0e=function(_0x4ea294){f(_0x33945a,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x33945a['sendRequest'](_0x4ea294);};this['realtime_']={'close':_0x2db81d,'sendRequest':_0x226b0e};const _0x2d53fa=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x2ec662,_0x50dde8]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x2d53fa),this['appCheckTokenProvider_']['getToken'](_0x2d53fa)]);_0x517c4c?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x2ec662&&_0x2ec662['accessToken'],this['appCheckToken_']=_0x50dde8&&_0x50dde8['token'],_0x33945a=new Sh(_0xe3db32,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x46d3ce,_0x568b3a,_0x2a34d4,_0x14b963=>{U(_0x14b963+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x114d20));}catch(_0x5000ac){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x5000ac),_0x517c4c||(this['repoInfo_']['nodeAdmin']&&U(_0x5000ac),_0x2db81d());}}}['interrupt'](_0x2a447f){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x2a447f),this['interruptReasons_'][_0x2a447f]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0xf56add){L('Resuming\x20connection\x20for\x20reason:\x20'+_0xf56add),delete this['interruptReasons_'][_0xf56add],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x3e6fff){const _0x142918=_0x3e6fff-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x142918});}['cancelSentTransactions_'](){for(let _0x48e5de=0x0;_0x48e5de<this['outstandingPuts_']['length'];_0x48e5de++){const _0x28a16e=this['outstandingPuts_'][_0x48e5de];_0x28a16e&&'h'in _0x28a16e['request']&&_0x28a16e['queued']&&(_0x28a16e['onComplete']&&_0x28a16e['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x48e5de],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x37b0f1,_0x22dbb0){let _0x4860db;_0x22dbb0?_0x4860db=_0x22dbb0['map'](_0x3f642e=>Hi(_0x3f642e))['join']('$'):_0x4860db='default';const _0x2e7ff4=this['removeListen_'](_0x37b0f1,_0x4860db);_0x2e7ff4&&_0x2e7ff4['onComplete']&&_0x2e7ff4['onComplete']('permission_denied');}['removeListen_'](_0x88acc3,_0x45da9a){const _0x34676b=new C(_0x88acc3)['toString']();let _0x4b1d8c;if(this['listens']['has'](_0x34676b)){const _0xb15abf=this['listens']['get'](_0x34676b);_0x4b1d8c=_0xb15abf['get'](_0x45da9a),_0xb15abf['delete'](_0x45da9a),_0xb15abf['size']===0x0&&this['listens']['delete'](_0x34676b);}else _0x4b1d8c=void 0x0;return _0x4b1d8c;}['onAuthRevoked_'](_0x2e3051,_0x54fbca){L('Auth\x20token\x20revoked:\x20'+_0x2e3051+'/'+_0x54fbca),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x2e3051==='invalid_token'||_0x2e3051==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x3b0fe5,_0x4f3cea){L('App\x20check\x20token\x20revoked:\x20'+_0x3b0fe5+'/'+_0x4f3cea),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x3b0fe5==='invalid_token'||_0x3b0fe5==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x2f9f2d){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x2f9f2d):'msg'in _0x2f9f2d&&console['log']('FIREBASE:\x20'+_0x2f9f2d['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x58501e of this['listens']['values']())for(const _0x9b598b of _0x58501e['values']())this['sendListen_'](_0x9b598b);for(let _0x1d3428=0x0;_0x1d3428<this['outstandingPuts_']['length'];_0x1d3428++)this['outstandingPuts_'][_0x1d3428]&&this['sendPut_'](_0x1d3428);for(;this['onDisconnectRequestQueue_']['length'];){const _0x16b4ec=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x16b4ec['action'],_0x16b4ec['pathString'],_0x16b4ec['data'],_0x16b4ec['onComplete']);}for(let _0x54f2a2=0x0;_0x54f2a2<this['outstandingGets_']['length'];_0x54f2a2++)this['outstandingGets_'][_0x54f2a2]&&this['sendGet_'](_0x54f2a2);}['sendConnectStats_'](){const _0x4f1cf5={};let _0x1ede9f='js';_0x4f1cf5['sdk.'+_0x1ede9f+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x4f1cf5['framework.cordova']=0x1:Yr()&&(_0x4f1cf5['framework.reactnative']=0x1),this['reportStats'](_0x4f1cf5);}['shouldReconnect_'](){const _0x3c0c83=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x3c0c83;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x4263d7,_0x4a10c7){this['name']=_0x4263d7,this['node']=_0x4a10c7;}static['Wrap'](_0x271409,_0x302edc){return new E(_0x271409,_0x302edc);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x805bc9,_0x262c77){const _0x139e03=new E(Fe,_0x805bc9),_0x43d592=new E(Fe,_0x262c77);return this['compare'](_0x139e03,_0x43d592)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x549871){Zt=_0x549871;}['compare'](_0x2aaef3,_0x4f8c12){return He(_0x2aaef3['name'],_0x4f8c12['name']);}['isDefinedOn'](_0x54d782){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x60ee04,_0x17f1bf){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x20848a,_0x2fb4dc){return f(typeof _0x20848a=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x20848a,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x3d0240,_0x239ecb,_0x5db9fd,_0x4585f8,_0x143b6f=null){this['isReverse_']=_0x4585f8,this['resultGenerator_']=_0x143b6f,this['nodeStack_']=[];let _0x117431=0x1;for(;!_0x3d0240['isEmpty']();)if(_0x3d0240=_0x3d0240,_0x117431=_0x239ecb?_0x5db9fd(_0x3d0240['key'],_0x239ecb):0x1,_0x4585f8&&(_0x117431*=-0x1),_0x117431<0x0)this['isReverse_']?_0x3d0240=_0x3d0240['left']:_0x3d0240=_0x3d0240['right'];else{if(_0x117431===0x0){this['nodeStack_']['push'](_0x3d0240);break;}else this['nodeStack_']['push'](_0x3d0240),this['isReverse_']?_0x3d0240=_0x3d0240['right']:_0x3d0240=_0x3d0240['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x1cc193=this['nodeStack_']['pop'](),_0xb41d5;if(this['resultGenerator_']?_0xb41d5=this['resultGenerator_'](_0x1cc193['key'],_0x1cc193['value']):_0xb41d5={'key':_0x1cc193['key'],'value':_0x1cc193['value']},this['isReverse_']){for(_0x1cc193=_0x1cc193['left'];!_0x1cc193['isEmpty']();)this['nodeStack_']['push'](_0x1cc193),_0x1cc193=_0x1cc193['right'];}else{for(_0x1cc193=_0x1cc193['right'];!_0x1cc193['isEmpty']();)this['nodeStack_']['push'](_0x1cc193),_0x1cc193=_0x1cc193['left'];}return _0xb41d5;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x5c6492=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x5c6492['key'],_0x5c6492['value']):{'key':_0x5c6492['key'],'value':_0x5c6492['value']};}}class M{constructor(_0x1f28c5,_0x1c214a,_0x3e4ed2,_0x19c5d2,_0x26fe1c){this['key']=_0x1f28c5,this['value']=_0x1c214a,this['color']=_0x3e4ed2??M['RED'],this['left']=_0x19c5d2??B['EMPTY_NODE'],this['right']=_0x26fe1c??B['EMPTY_NODE'];}['copy'](_0x5f2c8f,_0xfd4a11,_0x593f86,_0x1c1825,_0x21d351){return new M(_0x5f2c8f??this['key'],_0xfd4a11??this['value'],_0x593f86??this['color'],_0x1c1825??this['left'],_0x21d351??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x3970af){return this['left']['inorderTraversal'](_0x3970af)||!!_0x3970af(this['key'],this['value'])||this['right']['inorderTraversal'](_0x3970af);}['reverseTraversal'](_0x22ea24){return this['right']['reverseTraversal'](_0x22ea24)||_0x22ea24(this['key'],this['value'])||this['left']['reverseTraversal'](_0x22ea24);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x3857e8,_0x5cdc74,_0x354df6){let _0x2f0ba7=this;const _0x1ec66a=_0x354df6(_0x3857e8,_0x2f0ba7['key']);return _0x1ec66a<0x0?_0x2f0ba7=_0x2f0ba7['copy'](null,null,null,_0x2f0ba7['left']['insert'](_0x3857e8,_0x5cdc74,_0x354df6),null):_0x1ec66a===0x0?_0x2f0ba7=_0x2f0ba7['copy'](null,_0x5cdc74,null,null,null):_0x2f0ba7=_0x2f0ba7['copy'](null,null,null,null,_0x2f0ba7['right']['insert'](_0x3857e8,_0x5cdc74,_0x354df6)),_0x2f0ba7['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x3536d0=this;return!_0x3536d0['left']['isRed_']()&&!_0x3536d0['left']['left']['isRed_']()&&(_0x3536d0=_0x3536d0['moveRedLeft_']()),_0x3536d0=_0x3536d0['copy'](null,null,null,_0x3536d0['left']['removeMin_'](),null),_0x3536d0['fixUp_']();}['remove'](_0x26cee4,_0x30a00a){let _0x4578b3,_0x104e8e;if(_0x4578b3=this,_0x30a00a(_0x26cee4,_0x4578b3['key'])<0x0)!_0x4578b3['left']['isEmpty']()&&!_0x4578b3['left']['isRed_']()&&!_0x4578b3['left']['left']['isRed_']()&&(_0x4578b3=_0x4578b3['moveRedLeft_']()),_0x4578b3=_0x4578b3['copy'](null,null,null,_0x4578b3['left']['remove'](_0x26cee4,_0x30a00a),null);else{if(_0x4578b3['left']['isRed_']()&&(_0x4578b3=_0x4578b3['rotateRight_']()),!_0x4578b3['right']['isEmpty']()&&!_0x4578b3['right']['isRed_']()&&!_0x4578b3['right']['left']['isRed_']()&&(_0x4578b3=_0x4578b3['moveRedRight_']()),_0x30a00a(_0x26cee4,_0x4578b3['key'])===0x0){if(_0x4578b3['right']['isEmpty']())return B['EMPTY_NODE'];_0x104e8e=_0x4578b3['right']['min_'](),_0x4578b3=_0x4578b3['copy'](_0x104e8e['key'],_0x104e8e['value'],null,null,_0x4578b3['right']['removeMin_']());}_0x4578b3=_0x4578b3['copy'](null,null,null,null,_0x4578b3['right']['remove'](_0x26cee4,_0x30a00a));}return _0x4578b3['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x3c58c=this;return _0x3c58c['right']['isRed_']()&&!_0x3c58c['left']['isRed_']()&&(_0x3c58c=_0x3c58c['rotateLeft_']()),_0x3c58c['left']['isRed_']()&&_0x3c58c['left']['left']['isRed_']()&&(_0x3c58c=_0x3c58c['rotateRight_']()),_0x3c58c['left']['isRed_']()&&_0x3c58c['right']['isRed_']()&&(_0x3c58c=_0x3c58c['colorFlip_']()),_0x3c58c;}['moveRedLeft_'](){let _0x340bcc=this['colorFlip_']();return _0x340bcc['right']['left']['isRed_']()&&(_0x340bcc=_0x340bcc['copy'](null,null,null,null,_0x340bcc['right']['rotateRight_']()),_0x340bcc=_0x340bcc['rotateLeft_'](),_0x340bcc=_0x340bcc['colorFlip_']()),_0x340bcc;}['moveRedRight_'](){let _0x1f591a=this['colorFlip_']();return _0x1f591a['left']['left']['isRed_']()&&(_0x1f591a=_0x1f591a['rotateRight_'](),_0x1f591a=_0x1f591a['colorFlip_']()),_0x1f591a;}['rotateLeft_'](){const _0x517dca=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x517dca,null);}['rotateRight_'](){const _0x3c49e2=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x3c49e2);}['colorFlip_'](){const _0x5fbef4=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x39a743=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x5fbef4,_0x39a743);}['checkMaxDepth_'](){const _0x6b9a44=this['check_']();return Math['pow'](0x2,_0x6b9a44)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2c6620=this['left']['check_']();if(_0x2c6620!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2c6620+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x4b0681,_0x360920,_0x52dc4a,_0x3354fc,_0x463c89){return this;}['insert'](_0x795108,_0x14fdb8,_0x370911){return new M(_0x795108,_0x14fdb8,null);}['remove'](_0x50e7ca,_0x160757){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x4c5e20){return!0x1;}['reverseTraversal'](_0xfa4a97){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x11978f,_0x3e2a7b=B['EMPTY_NODE']){this['comparator_']=_0x11978f,this['root_']=_0x3e2a7b;}['insert'](_0x51713a,_0xe2b953){return new B(this['comparator_'],this['root_']['insert'](_0x51713a,_0xe2b953,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x5679ba){return new B(this['comparator_'],this['root_']['remove'](_0x5679ba,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0xde66de){let _0x4bfcda,_0x4dac10=this['root_'];for(;!_0x4dac10['isEmpty']();){if(_0x4bfcda=this['comparator_'](_0xde66de,_0x4dac10['key']),_0x4bfcda===0x0)return _0x4dac10['value'];_0x4bfcda<0x0?_0x4dac10=_0x4dac10['left']:_0x4bfcda>0x0&&(_0x4dac10=_0x4dac10['right']);}return null;}['getPredecessorKey'](_0x326188){let _0x481d64,_0x568782=this['root_'],_0x1e7b0e=null;for(;!_0x568782['isEmpty']();)if(_0x481d64=this['comparator_'](_0x326188,_0x568782['key']),_0x481d64===0x0){if(_0x568782['left']['isEmpty']())return _0x1e7b0e?_0x1e7b0e['key']:null;for(_0x568782=_0x568782['left'];!_0x568782['right']['isEmpty']();)_0x568782=_0x568782['right'];return _0x568782['key'];}else _0x481d64<0x0?_0x568782=_0x568782['left']:_0x481d64>0x0&&(_0x1e7b0e=_0x568782,_0x568782=_0x568782['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x172e7f){return this['root_']['inorderTraversal'](_0x172e7f);}['reverseTraversal'](_0x1d108a){return this['root_']['reverseTraversal'](_0x1d108a);}['getIterator'](_0x429ddd){return new en(this['root_'],null,this['comparator_'],!0x1,_0x429ddd);}['getIteratorFrom'](_0x4a6665,_0x363607){return new en(this['root_'],_0x4a6665,this['comparator_'],!0x1,_0x363607);}['getReverseIteratorFrom'](_0x1d3e73,_0x322076){return new en(this['root_'],_0x1d3e73,this['comparator_'],!0x0,_0x322076);}['getReverseIterator'](_0x575b4b){return new en(this['root_'],null,this['comparator_'],!0x0,_0x575b4b);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x407832,_0xb1216a){return He(_0x407832['name'],_0xb1216a['name']);}function Yi(_0x3fe721,_0x3a5608){return He(_0x3fe721,_0x3a5608);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x530d3b){Ei=_0x530d3b;}const No=function(_0x11bde8){return typeof _0x11bde8=='number'?'number:'+ao(_0x11bde8):'string:'+_0x11bde8;},Po=function(_0x25fa5c){if(_0x25fa5c['isLeafNode']()){const _0x248177=_0x25fa5c['val']();f(typeof _0x248177=='string'||typeof _0x248177=='number'||typeof _0x248177=='object'&&J(_0x248177,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x25fa5c===Ei||_0x25fa5c['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x25fa5c===Ei||_0x25fa5c['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x36c677){ir=_0x36c677;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x495ecb,_0xe549e7=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x495ecb,this['priorityNode_']=_0xe549e7,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1ad98){return new D(this['value_'],_0x1ad98);}['getImmediateChild'](_0x2e9e5e){return _0x2e9e5e==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x3783bd){return v(_0x3783bd)?this:y(_0x3783bd)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x514bf9,_0x56f9e4){return null;}['updateImmediateChild'](_0x1617d3,_0x845d55){return _0x1617d3==='.priority'?this['updatePriority'](_0x845d55):_0x845d55['isEmpty']()&&_0x1617d3!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x1617d3,_0x845d55)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x3da446,_0x30bd77){const _0x1a4791=y(_0x3da446);return _0x1a4791===null?_0x30bd77:_0x30bd77['isEmpty']()&&_0x1a4791!=='.priority'?this:(f(_0x1a4791!=='.priority'||we(_0x3da446)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x1a4791,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x3da446),_0x30bd77)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x3d0949,_0x16a482){return!0x1;}['val'](_0x48e9f5){return _0x48e9f5&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x1c3155='';this['priorityNode_']['isEmpty']()||(_0x1c3155+='priority:'+No(this['priorityNode_']['val']())+':');const _0x4ba4f5=typeof this['value_'];_0x1c3155+=_0x4ba4f5+':',_0x4ba4f5==='number'?_0x1c3155+=ao(this['value_']):_0x1c3155+=this['value_'],this['lazyHash_']=ro(_0x1c3155);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x26abb8){return _0x26abb8===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x26abb8 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x26abb8['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x26abb8));}['compareToLeafNode_'](_0x484940){const _0x3b210e=typeof _0x484940['value_'],_0x43bfab=typeof this['value_'],_0x1f1751=D['VALUE_TYPE_ORDER']['indexOf'](_0x3b210e),_0x52459f=D['VALUE_TYPE_ORDER']['indexOf'](_0x43bfab);return f(_0x1f1751>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x3b210e),f(_0x52459f>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x43bfab),_0x1f1751===_0x52459f?_0x43bfab==='object'?0x0:this['value_']<_0x484940['value_']?-0x1:this['value_']===_0x484940['value_']?0x0:0x1:_0x52459f-_0x1f1751;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x544cfe){if(_0x544cfe===this)return!0x0;if(_0x544cfe['isLeafNode']()){const _0x32f242=_0x544cfe;return this['value_']===_0x32f242['value_']&&this['priorityNode_']['equals'](_0x32f242['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x5c5e17){Oo=_0x5c5e17;}function Wh(_0x4e20ea){Do=_0x4e20ea;}class Bh extends Dn{['compare'](_0x4cc462,_0xf09f83){const _0x52ab49=_0x4cc462['node']['getPriority'](),_0x5abfb9=_0xf09f83['node']['getPriority'](),_0x13846e=_0x52ab49['compareTo'](_0x5abfb9);return _0x13846e===0x0?He(_0x4cc462['name'],_0xf09f83['name']):_0x13846e;}['isDefinedOn'](_0x4ebacf){return!_0x4ebacf['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x14c559,_0xb4fa41){return!_0x14c559['getPriority']()['equals'](_0xb4fa41['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x469bf2,_0x4f8a95){const _0x41a870=Oo(_0x469bf2);return new E(_0x4f8a95,new D('[PRIORITY-POST]',_0x41a870));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x3fc6ff){const _0x3596d7=_0xa53b0e=>parseInt(Math['log'](_0xa53b0e)/Vh,0xa),_0x4f748b=_0x29806b=>parseInt(Array(_0x29806b+0x1)['join']('1'),0x2);this['count']=_0x3596d7(_0x3fc6ff+0x1),this['current_']=this['count']-0x1;const _0x21461d=_0x4f748b(this['count']);this['bits_']=_0x3fc6ff+0x1&_0x21461d;}['nextBitIsOne'](){const _0x323c76=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x323c76;}}const fn=function(_0x4fa5b3,_0x4abccf,_0x4aff87,_0x45ffa6){_0x4fa5b3['sort'](_0x4abccf);const _0x17b43d=function(_0x4626a9,_0x392fa7){const _0x2f46cb=_0x392fa7-_0x4626a9;let _0x25dbd4,_0x2c0773;if(_0x2f46cb===0x0)return null;if(_0x2f46cb===0x1)return _0x25dbd4=_0x4fa5b3[_0x4626a9],_0x2c0773=_0x4aff87?_0x4aff87(_0x25dbd4):_0x25dbd4,new M(_0x2c0773,_0x25dbd4['node'],M['BLACK'],null,null);{const _0x59e7a9=parseInt(_0x2f46cb/0x2,0xa)+_0x4626a9,_0x519b06=_0x17b43d(_0x4626a9,_0x59e7a9),_0x4926e0=_0x17b43d(_0x59e7a9+0x1,_0x392fa7);return _0x25dbd4=_0x4fa5b3[_0x59e7a9],_0x2c0773=_0x4aff87?_0x4aff87(_0x25dbd4):_0x25dbd4,new M(_0x2c0773,_0x25dbd4['node'],M['BLACK'],_0x519b06,_0x4926e0);}},_0x59130d=function(_0x1baa2f){let _0x3192ac=null,_0x3779cb=null,_0x276d32=_0x4fa5b3['length'];const _0x12f30c=function(_0x21baf9,_0x270cc6){const _0x4c02d3=_0x276d32-_0x21baf9,_0x36f7d8=_0x276d32;_0x276d32-=_0x21baf9;const _0x90b8ef=_0x17b43d(_0x4c02d3+0x1,_0x36f7d8),_0x2e93c0=_0x4fa5b3[_0x4c02d3],_0x5a359f=_0x4aff87?_0x4aff87(_0x2e93c0):_0x2e93c0;_0x915afe(new M(_0x5a359f,_0x2e93c0['node'],_0x270cc6,null,_0x90b8ef));},_0x915afe=function(_0x17153a){_0x3192ac?(_0x3192ac['left']=_0x17153a,_0x3192ac=_0x17153a):(_0x3779cb=_0x17153a,_0x3192ac=_0x17153a);};for(let _0x38ff75=0x0;_0x38ff75<_0x1baa2f['count'];++_0x38ff75){const _0x4ee621=_0x1baa2f['nextBitIsOne'](),_0x1e6a4d=Math['pow'](0x2,_0x1baa2f['count']-(_0x38ff75+0x1));_0x4ee621?_0x12f30c(_0x1e6a4d,M['BLACK']):(_0x12f30c(_0x1e6a4d,M['BLACK']),_0x12f30c(_0x1e6a4d,M['RED']));}return _0x3779cb;},_0x4dbf8b=new Hh(_0x4fa5b3['length']),_0x3c3f6d=_0x59130d(_0x4dbf8b);return new B(_0x45ffa6||_0x4abccf,_0x3c3f6d);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x46a8f7,_0x4aa442){this['indexes_']=_0x46a8f7,this['indexSet_']=_0x4aa442;}['get'](_0x1672d2){const _0x301186=De(this['indexes_'],_0x1672d2);if(!_0x301186)throw new Error('No\x20index\x20defined\x20for\x20'+_0x1672d2);return _0x301186 instanceof B?_0x301186:null;}['hasIndex'](_0x50d909){return J(this['indexSet_'],_0x50d909['toString']());}['addIndex'](_0x1b44ab,_0x4330b5){f(_0x1b44ab!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x4f9e93=[];let _0xe4ac39=!0x1;const _0x59b1b5=_0x4330b5['getIterator'](E['Wrap']);let _0x3f144a=_0x59b1b5['getNext']();for(;_0x3f144a;)_0xe4ac39=_0xe4ac39||_0x1b44ab['isDefinedOn'](_0x3f144a['node']),_0x4f9e93['push'](_0x3f144a),_0x3f144a=_0x59b1b5['getNext']();let _0x2a5b89;_0xe4ac39?_0x2a5b89=fn(_0x4f9e93,_0x1b44ab['getCompare']()):_0x2a5b89=ze;const _0x1a2000=_0x1b44ab['toString'](),_0x44fbfb={...this['indexSet_']};_0x44fbfb[_0x1a2000]=_0x1b44ab;const _0x28b8ab={...this['indexes_']};return _0x28b8ab[_0x1a2000]=_0x2a5b89,new te(_0x28b8ab,_0x44fbfb);}['addToIndexes'](_0x226ed1,_0x2538e0){const _0x32c8cf=hn(this['indexes_'],(_0x282658,_0x53cf60)=>{const _0x493815=De(this['indexSet_'],_0x53cf60);if(f(_0x493815,'Missing\x20index\x20implementation\x20for\x20'+_0x53cf60),_0x282658===ze){if(_0x493815['isDefinedOn'](_0x226ed1['node'])){const _0x5190c3=[],_0x3fe7c3=_0x2538e0['getIterator'](E['Wrap']);let _0x2d9d0e=_0x3fe7c3['getNext']();for(;_0x2d9d0e;)_0x2d9d0e['name']!==_0x226ed1['name']&&_0x5190c3['push'](_0x2d9d0e),_0x2d9d0e=_0x3fe7c3['getNext']();return _0x5190c3['push'](_0x226ed1),fn(_0x5190c3,_0x493815['getCompare']());}else return ze;}else{const _0x16e948=_0x2538e0['get'](_0x226ed1['name']);let _0x4d6171=_0x282658;return _0x16e948&&(_0x4d6171=_0x4d6171['remove'](new E(_0x226ed1['name'],_0x16e948))),_0x4d6171['insert'](_0x226ed1,_0x226ed1['node']);}});return new te(_0x32c8cf,this['indexSet_']);}['removeFromIndexes'](_0x563779,_0x452ecb){const _0x56d771=hn(this['indexes_'],_0x12711d=>{if(_0x12711d===ze)return _0x12711d;{const _0x5285e2=_0x452ecb['get'](_0x563779['name']);return _0x5285e2?_0x12711d['remove'](new E(_0x563779['name'],_0x5285e2)):_0x12711d;}});return new te(_0x56d771,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x236efd,_0x302b15,_0x565158){this['children_']=_0x236efd,this['priorityNode_']=_0x302b15,this['indexMap_']=_0x565158,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x19be4b){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x19be4b,this['indexMap_']);}['getImmediateChild'](_0x35d862){if(_0x35d862==='.priority')return this['getPriority']();{const _0x1606d8=this['children_']['get'](_0x35d862);return _0x1606d8===null?mt:_0x1606d8;}}['getChild'](_0x183a9b){const _0x3e151d=y(_0x183a9b);return _0x3e151d===null?this:this['getImmediateChild'](_0x3e151d)['getChild'](b(_0x183a9b));}['hasChild'](_0x50bfe4){return this['children_']['get'](_0x50bfe4)!==null;}['updateImmediateChild'](_0x5e161e,_0x2644b2){if(f(_0x2644b2,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x5e161e==='.priority')return this['updatePriority'](_0x2644b2);{const _0x13f170=new E(_0x5e161e,_0x2644b2);let _0x290921,_0x32475e;_0x2644b2['isEmpty']()?(_0x290921=this['children_']['remove'](_0x5e161e),_0x32475e=this['indexMap_']['removeFromIndexes'](_0x13f170,this['children_'])):(_0x290921=this['children_']['insert'](_0x5e161e,_0x2644b2),_0x32475e=this['indexMap_']['addToIndexes'](_0x13f170,this['children_']));const _0x403f4f=_0x290921['isEmpty']()?mt:this['priorityNode_'];return new g(_0x290921,_0x403f4f,_0x32475e);}}['updateChild'](_0x1116dd,_0x620db9){const _0x2129cc=y(_0x1116dd);if(_0x2129cc===null)return _0x620db9;{f(y(_0x1116dd)!=='.priority'||we(_0x1116dd)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x1a238f=this['getImmediateChild'](_0x2129cc)['updateChild'](b(_0x1116dd),_0x620db9);return this['updateImmediateChild'](_0x2129cc,_0x1a238f);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x7b7512){if(this['isEmpty']())return null;const _0x510558={};let _0x303038=0x0,_0x182a32=0x0,_0x59d727=!0x0;if(this['forEachChild'](R,(_0x4b05c7,_0x29426d)=>{_0x510558[_0x4b05c7]=_0x29426d['val'](_0x7b7512),_0x303038++,_0x59d727&&g['INTEGER_REGEXP_']['test'](_0x4b05c7)?_0x182a32=Math['max'](_0x182a32,Number(_0x4b05c7)):_0x59d727=!0x1;}),!_0x7b7512&&_0x59d727&&_0x182a32<0x2*_0x303038){const _0x3b9e77=[];for(const _0x4954be in _0x510558)_0x3b9e77[_0x4954be]=_0x510558[_0x4954be];return _0x3b9e77;}else return _0x7b7512&&!this['getPriority']()['isEmpty']()&&(_0x510558['.priority']=this['getPriority']()['val']()),_0x510558;}['hash'](){if(this['lazyHash_']===null){let _0x382ce5='';this['getPriority']()['isEmpty']()||(_0x382ce5+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x56402e,_0x520ef5)=>{const _0xf388c4=_0x520ef5['hash']();_0xf388c4!==''&&(_0x382ce5+=':'+_0x56402e+':'+_0xf388c4);}),this['lazyHash_']=_0x382ce5===''?'':ro(_0x382ce5);}return this['lazyHash_'];}['getPredecessorChildName'](_0x459b8a,_0x48fa7f,_0x190167){const _0x34f5d0=this['resolveIndex_'](_0x190167);if(_0x34f5d0){const _0x46982a=_0x34f5d0['getPredecessorKey'](new E(_0x459b8a,_0x48fa7f));return _0x46982a?_0x46982a['name']:null;}else return this['children_']['getPredecessorKey'](_0x459b8a);}['getFirstChildName'](_0x2e2fe4){const _0x139350=this['resolveIndex_'](_0x2e2fe4);if(_0x139350){const _0x45bd2b=_0x139350['minKey']();return _0x45bd2b&&_0x45bd2b['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x3f2d5d){const _0x22834c=this['getFirstChildName'](_0x3f2d5d);return _0x22834c?new E(_0x22834c,this['children_']['get'](_0x22834c)):null;}['getLastChildName'](_0x123d78){const _0x379f4a=this['resolveIndex_'](_0x123d78);if(_0x379f4a){const _0x206652=_0x379f4a['maxKey']();return _0x206652&&_0x206652['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x5b7bab){const _0x106405=this['getLastChildName'](_0x5b7bab);return _0x106405?new E(_0x106405,this['children_']['get'](_0x106405)):null;}['forEachChild'](_0x13a83f,_0x16cbda){const _0x537bfd=this['resolveIndex_'](_0x13a83f);return _0x537bfd?_0x537bfd['inorderTraversal'](_0x587ed6=>_0x16cbda(_0x587ed6['name'],_0x587ed6['node'])):this['children_']['inorderTraversal'](_0x16cbda);}['getIterator'](_0x22b6c8){return this['getIteratorFrom'](_0x22b6c8['minPost'](),_0x22b6c8);}['getIteratorFrom'](_0x4113ba,_0x5b010c){const _0x4f09b9=this['resolveIndex_'](_0x5b010c);if(_0x4f09b9)return _0x4f09b9['getIteratorFrom'](_0x4113ba,_0x738522=>_0x738522);{const _0x27abf1=this['children_']['getIteratorFrom'](_0x4113ba['name'],E['Wrap']);let _0x464c16=_0x27abf1['peek']();for(;_0x464c16!=null&&_0x5b010c['compare'](_0x464c16,_0x4113ba)<0x0;)_0x27abf1['getNext'](),_0x464c16=_0x27abf1['peek']();return _0x27abf1;}}['getReverseIterator'](_0x4069a2){return this['getReverseIteratorFrom'](_0x4069a2['maxPost'](),_0x4069a2);}['getReverseIteratorFrom'](_0x3b2724,_0x535350){const _0x39c71c=this['resolveIndex_'](_0x535350);if(_0x39c71c)return _0x39c71c['getReverseIteratorFrom'](_0x3b2724,_0x21f8b0=>_0x21f8b0);{const _0x36e32b=this['children_']['getReverseIteratorFrom'](_0x3b2724['name'],E['Wrap']);let _0x28b4f7=_0x36e32b['peek']();for(;_0x28b4f7!=null&&_0x535350['compare'](_0x28b4f7,_0x3b2724)>0x0;)_0x36e32b['getNext'](),_0x28b4f7=_0x36e32b['peek']();return _0x36e32b;}}['compareTo'](_0x4e0e61){return this['isEmpty']()?_0x4e0e61['isEmpty']()?0x0:-0x1:_0x4e0e61['isLeafNode']()||_0x4e0e61['isEmpty']()?0x1:_0x4e0e61===$t?-0x1:0x0;}['withIndex'](_0x4f50f4){if(_0x4f50f4===ye||this['indexMap_']['hasIndex'](_0x4f50f4))return this;{const _0x3ee15a=this['indexMap_']['addIndex'](_0x4f50f4,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x3ee15a);}}['isIndexed'](_0x55da23){return _0x55da23===ye||this['indexMap_']['hasIndex'](_0x55da23);}['equals'](_0x4e3f32){if(_0x4e3f32===this)return!0x0;if(_0x4e3f32['isLeafNode']())return!0x1;{const _0x41cb30=_0x4e3f32;if(this['getPriority']()['equals'](_0x41cb30['getPriority']())){if(this['children_']['count']()===_0x41cb30['children_']['count']()){const _0x3c1345=this['getIterator'](R),_0x3d59b4=_0x41cb30['getIterator'](R);let _0x3de769=_0x3c1345['getNext'](),_0x393ac3=_0x3d59b4['getNext']();for(;_0x3de769&&_0x393ac3;){if(_0x3de769['name']!==_0x393ac3['name']||!_0x3de769['node']['equals'](_0x393ac3['node']))return!0x1;_0x3de769=_0x3c1345['getNext'](),_0x393ac3=_0x3d59b4['getNext']();}return _0x3de769===null&&_0x393ac3===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x5927f2){return _0x5927f2===ye?null:this['indexMap_']['get'](_0x5927f2['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0xb1113c){return _0xb1113c===this?0x0:0x1;}['equals'](_0x31e09e){return _0x31e09e===this;}['getPriority'](){return this;}['getImmediateChild'](_0x1e3378){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x192b1b,_0x428c9b=null){if(_0x192b1b===null)return g['EMPTY_NODE'];if(typeof _0x192b1b=='object'&&'.priority'in _0x192b1b&&(_0x428c9b=_0x192b1b['.priority']),f(_0x428c9b===null||typeof _0x428c9b=='string'||typeof _0x428c9b=='number'||typeof _0x428c9b=='object'&&'.sv'in _0x428c9b,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x428c9b),typeof _0x192b1b=='object'&&'.value'in _0x192b1b&&_0x192b1b['.value']!==null&&(_0x192b1b=_0x192b1b['.value']),typeof _0x192b1b!='object'||'.sv'in _0x192b1b){const _0x29c357=_0x192b1b;return new D(_0x29c357,P(_0x428c9b));}if(!(_0x192b1b instanceof Array)&&Gh){const _0x14348d=[];let _0x3fa5e2=!0x1;if(x(_0x192b1b,(_0x36513d,_0xb5437d)=>{if(_0x36513d['substring'](0x0,0x1)!=='.'){const _0x698f53=P(_0xb5437d);_0x698f53['isEmpty']()||(_0x3fa5e2=_0x3fa5e2||!_0x698f53['getPriority']()['isEmpty'](),_0x14348d['push'](new E(_0x36513d,_0x698f53)));}}),_0x14348d['length']===0x0)return g['EMPTY_NODE'];const _0x1c33fe=fn(_0x14348d,xh,_0x3f1966=>_0x3f1966['name'],Yi);if(_0x3fa5e2){const _0x4f85c1=fn(_0x14348d,R['getCompare']());return new g(_0x1c33fe,P(_0x428c9b),new te({'.priority':_0x4f85c1},{'.priority':R}));}else return new g(_0x1c33fe,P(_0x428c9b),te['Default']);}else{let _0x1c1380=g['EMPTY_NODE'];return x(_0x192b1b,(_0x43f707,_0x359ef9)=>{if(J(_0x192b1b,_0x43f707)&&_0x43f707['substring'](0x0,0x1)!=='.'){const _0x411e64=P(_0x359ef9);(_0x411e64['isLeafNode']()||!_0x411e64['isEmpty']())&&(_0x1c1380=_0x1c1380['updateImmediateChild'](_0x43f707,_0x411e64));}}),_0x1c1380['updatePriority'](P(_0x428c9b));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x5b741c){super(),this['indexPath_']=_0x5b741c,f(!v(_0x5b741c)&&y(_0x5b741c)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x1827f5){return _0x1827f5['getChild'](this['indexPath_']);}['isDefinedOn'](_0x1c4505){return!_0x1c4505['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x5de534,_0x35f605){const _0x5adaec=this['extractChild'](_0x5de534['node']),_0x5b7ade=this['extractChild'](_0x35f605['node']),_0x783dc0=_0x5adaec['compareTo'](_0x5b7ade);return _0x783dc0===0x0?He(_0x5de534['name'],_0x35f605['name']):_0x783dc0;}['makePost'](_0x159b57,_0x68dc43){const _0x52ed56=P(_0x159b57),_0x3a8e82=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x52ed56);return new E(_0x68dc43,_0x3a8e82);}['maxPost'](){const _0x4ca5df=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x4ca5df);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x199cdb,_0x32c21e){const _0x691ec3=_0x199cdb['node']['compareTo'](_0x32c21e['node']);return _0x691ec3===0x0?He(_0x199cdb['name'],_0x32c21e['name']):_0x691ec3;}['isDefinedOn'](_0x2dbbd2){return!0x0;}['indexedValueChanged'](_0x14f9df,_0x56f56a){return!_0x14f9df['equals'](_0x56f56a);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x1aa010,_0x38ce37){const _0x2c4d2e=P(_0x1aa010);return new E(_0x38ce37,_0x2c4d2e);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x23a76f){return{'type':'value','snapshotNode':_0x23a76f};}function et(_0x509f54,_0xaf62f0){return{'type':'child_added','snapshotNode':_0xaf62f0,'childName':_0x509f54};}function Ot(_0x373693,_0x4e254c){return{'type':'child_removed','snapshotNode':_0x4e254c,'childName':_0x373693};}function Dt(_0x85a0bf,_0xc998ab,_0xd50d36){return{'type':'child_changed','snapshotNode':_0xc998ab,'childName':_0x85a0bf,'oldSnap':_0xd50d36};}function zh(_0xa38189,_0x375ae7){return{'type':'child_moved','snapshotNode':_0x375ae7,'childName':_0xa38189};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x42cad8){this['index_']=_0x42cad8;}['updateChild'](_0x33b81c,_0x26878d,_0x5658ad,_0x1ff5f0,_0x425129,_0x2a5abb){f(_0x33b81c['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x1db152=_0x33b81c['getImmediateChild'](_0x26878d);return _0x1db152['getChild'](_0x1ff5f0)['equals'](_0x5658ad['getChild'](_0x1ff5f0))&&_0x1db152['isEmpty']()===_0x5658ad['isEmpty']()||(_0x2a5abb!=null&&(_0x5658ad['isEmpty']()?_0x33b81c['hasChild'](_0x26878d)?_0x2a5abb['trackChildChange'](Ot(_0x26878d,_0x1db152)):f(_0x33b81c['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x1db152['isEmpty']()?_0x2a5abb['trackChildChange'](et(_0x26878d,_0x5658ad)):_0x2a5abb['trackChildChange'](Dt(_0x26878d,_0x5658ad,_0x1db152))),_0x33b81c['isLeafNode']()&&_0x5658ad['isEmpty']())?_0x33b81c:_0x33b81c['updateImmediateChild'](_0x26878d,_0x5658ad)['withIndex'](this['index_']);}['updateFullNode'](_0x4a2784,_0x5d904b,_0x4de0af){return _0x4de0af!=null&&(_0x4a2784['isLeafNode']()||_0x4a2784['forEachChild'](R,(_0x57938b,_0x34fb8e)=>{_0x5d904b['hasChild'](_0x57938b)||_0x4de0af['trackChildChange'](Ot(_0x57938b,_0x34fb8e));}),_0x5d904b['isLeafNode']()||_0x5d904b['forEachChild'](R,(_0xe33aea,_0x1e325a)=>{if(_0x4a2784['hasChild'](_0xe33aea)){const _0x43fb0d=_0x4a2784['getImmediateChild'](_0xe33aea);_0x43fb0d['equals'](_0x1e325a)||_0x4de0af['trackChildChange'](Dt(_0xe33aea,_0x1e325a,_0x43fb0d));}else _0x4de0af['trackChildChange'](et(_0xe33aea,_0x1e325a));})),_0x5d904b['withIndex'](this['index_']);}['updatePriority'](_0x146bc3,_0x3decc8){return _0x146bc3['isEmpty']()?g['EMPTY_NODE']:_0x146bc3['updatePriority'](_0x3decc8);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x529792){this['indexedFilter_']=new Ji(_0x529792['getIndex']()),this['index_']=_0x529792['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x529792),this['endPost_']=Mt['getEndPost_'](_0x529792),this['startIsInclusive_']=!_0x529792['startAfterSet_'],this['endIsInclusive_']=!_0x529792['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x5afb7a){const _0x39350f=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x5afb7a)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x5afb7a)<0x0,_0x8eedf0=this['endIsInclusive_']?this['index_']['compare'](_0x5afb7a,this['getEndPost']())<=0x0:this['index_']['compare'](_0x5afb7a,this['getEndPost']())<0x0;return _0x39350f&&_0x8eedf0;}['updateChild'](_0xa5375f,_0x562786,_0x2fd06c,_0x3ace58,_0xc7ee58,_0x4d40e1){return this['matches'](new E(_0x562786,_0x2fd06c))||(_0x2fd06c=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0xa5375f,_0x562786,_0x2fd06c,_0x3ace58,_0xc7ee58,_0x4d40e1);}['updateFullNode'](_0x258f27,_0x8aec7b,_0x296903){_0x8aec7b['isLeafNode']()&&(_0x8aec7b=g['EMPTY_NODE']);let _0x55d7ec=_0x8aec7b['withIndex'](this['index_']);_0x55d7ec=_0x55d7ec['updatePriority'](g['EMPTY_NODE']);const _0x1d4bca=this;return _0x8aec7b['forEachChild'](R,(_0x267460,_0x4cebea)=>{_0x1d4bca['matches'](new E(_0x267460,_0x4cebea))||(_0x55d7ec=_0x55d7ec['updateImmediateChild'](_0x267460,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x258f27,_0x55d7ec,_0x296903);}['updatePriority'](_0x563174,_0x1a59f6){return _0x563174;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x28b808){if(_0x28b808['hasStart']()){const _0x22f48f=_0x28b808['getIndexStartName']();return _0x28b808['getIndex']()['makePost'](_0x28b808['getIndexStartValue'](),_0x22f48f);}else return _0x28b808['getIndex']()['minPost']();}static['getEndPost_'](_0x524a03){if(_0x524a03['hasEnd']()){const _0x48a52e=_0x524a03['getIndexEndName']();return _0x524a03['getIndex']()['makePost'](_0x524a03['getIndexEndValue'](),_0x48a52e);}else return _0x524a03['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x18b2e9){this['withinDirectionalStart']=_0x10b5c7=>this['reverse_']?this['withinEndPost'](_0x10b5c7):this['withinStartPost'](_0x10b5c7),this['withinDirectionalEnd']=_0x4c1ca4=>this['reverse_']?this['withinStartPost'](_0x4c1ca4):this['withinEndPost'](_0x4c1ca4),this['withinStartPost']=_0x5ad4cc=>{const _0x3fb51a=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x5ad4cc);return this['startIsInclusive_']?_0x3fb51a<=0x0:_0x3fb51a<0x0;},this['withinEndPost']=_0x4f7d40=>{const _0x50c235=this['index_']['compare'](_0x4f7d40,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x50c235<=0x0:_0x50c235<0x0;},this['rangedFilter_']=new Mt(_0x18b2e9),this['index_']=_0x18b2e9['getIndex'](),this['limit_']=_0x18b2e9['getLimit'](),this['reverse_']=!_0x18b2e9['isViewFromLeft'](),this['startIsInclusive_']=!_0x18b2e9['startAfterSet_'],this['endIsInclusive_']=!_0x18b2e9['endBeforeSet_'];}['updateChild'](_0x183eed,_0x5b530a,_0x364a6a,_0xdebb44,_0x19d6c9,_0x25b1a6){return this['rangedFilter_']['matches'](new E(_0x5b530a,_0x364a6a))||(_0x364a6a=g['EMPTY_NODE']),_0x183eed['getImmediateChild'](_0x5b530a)['equals'](_0x364a6a)?_0x183eed:_0x183eed['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x183eed,_0x5b530a,_0x364a6a,_0xdebb44,_0x19d6c9,_0x25b1a6):this['fullLimitUpdateChild_'](_0x183eed,_0x5b530a,_0x364a6a,_0x19d6c9,_0x25b1a6);}['updateFullNode'](_0x2c0be3,_0xfc2053,_0x49159c){let _0x1b1264;if(_0xfc2053['isLeafNode']()||_0xfc2053['isEmpty']())_0x1b1264=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0xfc2053['numChildren']()&&_0xfc2053['isIndexed'](this['index_'])){_0x1b1264=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x218fa8;this['reverse_']?_0x218fa8=_0xfc2053['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x218fa8=_0xfc2053['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x281da7=0x0;for(;_0x218fa8['hasNext']()&&_0x281da7<this['limit_'];){const _0x5d0585=_0x218fa8['getNext']();if(this['withinDirectionalStart'](_0x5d0585)){if(this['withinDirectionalEnd'](_0x5d0585))_0x1b1264=_0x1b1264['updateImmediateChild'](_0x5d0585['name'],_0x5d0585['node']),_0x281da7++;else break;}else continue;}}else{_0x1b1264=_0xfc2053['withIndex'](this['index_']),_0x1b1264=_0x1b1264['updatePriority'](g['EMPTY_NODE']);let _0x9f4dbb;this['reverse_']?_0x9f4dbb=_0x1b1264['getReverseIterator'](this['index_']):_0x9f4dbb=_0x1b1264['getIterator'](this['index_']);let _0x219a53=0x0;for(;_0x9f4dbb['hasNext']();){const _0x431ef4=_0x9f4dbb['getNext']();_0x219a53<this['limit_']&&this['withinDirectionalStart'](_0x431ef4)&&this['withinDirectionalEnd'](_0x431ef4)?_0x219a53++:_0x1b1264=_0x1b1264['updateImmediateChild'](_0x431ef4['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x2c0be3,_0x1b1264,_0x49159c);}['updatePriority'](_0x6db74f,_0x37bbd7){return _0x6db74f;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x3e93ac,_0x8e203b,_0x797064,_0x127f5c,_0x387df2){let _0x5d8bfc;if(this['reverse_']){const _0x2937af=this['index_']['getCompare']();_0x5d8bfc=(_0x49f925,_0x3e3ca3)=>_0x2937af(_0x3e3ca3,_0x49f925);}else _0x5d8bfc=this['index_']['getCompare']();const _0xd66ccb=_0x3e93ac;f(_0xd66ccb['numChildren']()===this['limit_'],'');const _0x597ebf=new E(_0x8e203b,_0x797064),_0x1e86fb=this['reverse_']?_0xd66ccb['getFirstChild'](this['index_']):_0xd66ccb['getLastChild'](this['index_']),_0xad986b=this['rangedFilter_']['matches'](_0x597ebf);if(_0xd66ccb['hasChild'](_0x8e203b)){const _0x269303=_0xd66ccb['getImmediateChild'](_0x8e203b);let _0x2326a0=_0x127f5c['getChildAfterChild'](this['index_'],_0x1e86fb,this['reverse_']);for(;_0x2326a0!=null&&(_0x2326a0['name']===_0x8e203b||_0xd66ccb['hasChild'](_0x2326a0['name']));)_0x2326a0=_0x127f5c['getChildAfterChild'](this['index_'],_0x2326a0,this['reverse_']);const _0x5f2c50=_0x2326a0==null?0x1:_0x5d8bfc(_0x2326a0,_0x597ebf);if(_0xad986b&&!_0x797064['isEmpty']()&&_0x5f2c50>=0x0)return _0x387df2!=null&&_0x387df2['trackChildChange'](Dt(_0x8e203b,_0x797064,_0x269303)),_0xd66ccb['updateImmediateChild'](_0x8e203b,_0x797064);{_0x387df2!=null&&_0x387df2['trackChildChange'](Ot(_0x8e203b,_0x269303));const _0x452f69=_0xd66ccb['updateImmediateChild'](_0x8e203b,g['EMPTY_NODE']);return _0x2326a0!=null&&this['rangedFilter_']['matches'](_0x2326a0)?(_0x387df2!=null&&_0x387df2['trackChildChange'](et(_0x2326a0['name'],_0x2326a0['node'])),_0x452f69['updateImmediateChild'](_0x2326a0['name'],_0x2326a0['node'])):_0x452f69;}}else return _0x797064['isEmpty']()?_0x3e93ac:_0xad986b&&_0x5d8bfc(_0x1e86fb,_0x597ebf)>=0x0?(_0x387df2!=null&&(_0x387df2['trackChildChange'](Ot(_0x1e86fb['name'],_0x1e86fb['node'])),_0x387df2['trackChildChange'](et(_0x8e203b,_0x797064))),_0xd66ccb['updateImmediateChild'](_0x8e203b,_0x797064)['updateImmediateChild'](_0x1e86fb['name'],g['EMPTY_NODE'])):_0x3e93ac;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x591f51=new Xi();return _0x591f51['limitSet_']=this['limitSet_'],_0x591f51['limit_']=this['limit_'],_0x591f51['startSet_']=this['startSet_'],_0x591f51['startAfterSet_']=this['startAfterSet_'],_0x591f51['indexStartValue_']=this['indexStartValue_'],_0x591f51['startNameSet_']=this['startNameSet_'],_0x591f51['indexStartName_']=this['indexStartName_'],_0x591f51['endSet_']=this['endSet_'],_0x591f51['endBeforeSet_']=this['endBeforeSet_'],_0x591f51['indexEndValue_']=this['indexEndValue_'],_0x591f51['endNameSet_']=this['endNameSet_'],_0x591f51['indexEndName_']=this['indexEndName_'],_0x591f51['index_']=this['index_'],_0x591f51['viewFrom_']=this['viewFrom_'],_0x591f51;}}function Kh(_0x3f970f){return _0x3f970f['loadsAllData']()?new Ji(_0x3f970f['getIndex']()):_0x3f970f['hasLimit']()?new jh(_0x3f970f):new Mt(_0x3f970f);}function Yh(_0x76122f,_0x2537c6){const _0x5af2af=_0x76122f['copy']();return _0x5af2af['limitSet_']=!0x0,_0x5af2af['limit_']=_0x2537c6,_0x5af2af['viewFrom_']='l',_0x5af2af;}function Qh(_0x53917a,_0x360127,_0x368d10){const _0x1ab0d2=_0x53917a['copy']();return _0x1ab0d2['startSet_']=!0x0,_0x360127===void 0x0&&(_0x360127=null),_0x1ab0d2['indexStartValue_']=_0x360127,_0x368d10!=null?(_0x1ab0d2['startNameSet_']=!0x0,_0x1ab0d2['indexStartName_']=_0x368d10):(_0x1ab0d2['startNameSet_']=!0x1,_0x1ab0d2['indexStartName_']=''),_0x1ab0d2;}function Jh(_0x152587,_0x3e1cfc,_0xf5a3bd){const _0x5c937f=_0x152587['copy']();return _0x5c937f['endSet_']=!0x0,_0x3e1cfc===void 0x0&&(_0x3e1cfc=null),_0x5c937f['indexEndValue_']=_0x3e1cfc,_0xf5a3bd!==void 0x0?(_0x5c937f['endNameSet_']=!0x0,_0x5c937f['indexEndName_']=_0xf5a3bd):(_0x5c937f['endNameSet_']=!0x1,_0x5c937f['indexEndName_']=''),_0x5c937f;}function xo(_0x44af55,_0x529192){const _0x116edc=_0x44af55['copy']();return _0x116edc['index_']=_0x529192,_0x116edc;}function sr(_0x4627c3){const _0x4b2604={};if(_0x4627c3['isDefault']())return _0x4b2604;let _0x11dca2;if(_0x4627c3['index_']===R?_0x11dca2='$priority':_0x4627c3['index_']===Mo?_0x11dca2='$value':_0x4627c3['index_']===ye?_0x11dca2='$key':(f(_0x4627c3['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x11dca2=_0x4627c3['index_']['toString']()),_0x4b2604['orderBy']=O(_0x11dca2),_0x4627c3['startSet_']){const _0xa1d297=_0x4627c3['startAfterSet_']?'startAfter':'startAt';_0x4b2604[_0xa1d297]=O(_0x4627c3['indexStartValue_']),_0x4627c3['startNameSet_']&&(_0x4b2604[_0xa1d297]+=','+O(_0x4627c3['indexStartName_']));}if(_0x4627c3['endSet_']){const _0x3cf550=_0x4627c3['endBeforeSet_']?'endBefore':'endAt';_0x4b2604[_0x3cf550]=O(_0x4627c3['indexEndValue_']),_0x4627c3['endNameSet_']&&(_0x4b2604[_0x3cf550]+=','+O(_0x4627c3['indexEndName_']));}return _0x4627c3['limitSet_']&&(_0x4627c3['isViewFromLeft']()?_0x4b2604['limitToFirst']=_0x4627c3['limit_']:_0x4b2604['limitToLast']=_0x4627c3['limit_']),_0x4b2604;}function rr(_0x48bbc1){const _0xabeea={};if(_0x48bbc1['startSet_']&&(_0xabeea['sp']=_0x48bbc1['indexStartValue_'],_0x48bbc1['startNameSet_']&&(_0xabeea['sn']=_0x48bbc1['indexStartName_']),_0xabeea['sin']=!_0x48bbc1['startAfterSet_']),_0x48bbc1['endSet_']&&(_0xabeea['ep']=_0x48bbc1['indexEndValue_'],_0x48bbc1['endNameSet_']&&(_0xabeea['en']=_0x48bbc1['indexEndName_']),_0xabeea['ein']=!_0x48bbc1['endBeforeSet_']),_0x48bbc1['limitSet_']){_0xabeea['l']=_0x48bbc1['limit_'];let _0x249c2c=_0x48bbc1['viewFrom_'];_0x249c2c===''&&(_0x48bbc1['isViewFromLeft']()?_0x249c2c='l':_0x249c2c='r'),_0xabeea['vf']=_0x249c2c;}return _0x48bbc1['index_']!==R&&(_0xabeea['i']=_0x48bbc1['index_']['toString']()),_0xabeea;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x5a44dd){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x28468f,_0x1475fb){return _0x1475fb!==void 0x0?'tag$'+_0x1475fb:(f(_0x28468f['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x28468f['_path']['toString']());}constructor(_0x3af060,_0xb02dcd,_0x18ff72,_0x107403){super(),this['repoInfo_']=_0x3af060,this['onDataUpdate_']=_0xb02dcd,this['authTokenProvider_']=_0x18ff72,this['appCheckTokenProvider_']=_0x107403,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x5be1e0,_0x1a2d82,_0x1adcae,_0x4fff29){const _0x335054=_0x5be1e0['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x335054+'\x20'+_0x5be1e0['_queryIdentifier']);const _0x9d00a5=pn['getListenId_'](_0x5be1e0,_0x1adcae),_0x474dbd={};this['listens_'][_0x9d00a5]=_0x474dbd;const _0x7275d6=sr(_0x5be1e0['_queryParams']);this['restRequest_'](_0x335054+'.json',_0x7275d6,(_0x26ac37,_0x43b153)=>{let _0x2aab90=_0x43b153;if(_0x26ac37===0x194&&(_0x2aab90=null,_0x26ac37=null),_0x26ac37===null&&this['onDataUpdate_'](_0x335054,_0x2aab90,!0x1,_0x1adcae),De(this['listens_'],_0x9d00a5)===_0x474dbd){let _0x5dbac7;_0x26ac37?_0x26ac37===0x191?_0x5dbac7='permission_denied':_0x5dbac7='rest_error:'+_0x26ac37:_0x5dbac7='ok',_0x4fff29(_0x5dbac7,null);}});}['unlisten'](_0x19d211,_0x22ef9f){const _0x437979=pn['getListenId_'](_0x19d211,_0x22ef9f);delete this['listens_'][_0x437979];}['get'](_0x2fb83b){const _0x42aedc=sr(_0x2fb83b['_queryParams']),_0x251f47=_0x2fb83b['_path']['toString'](),_0x29a86d=new ot();return this['restRequest_'](_0x251f47+'.json',_0x42aedc,(_0x59962b,_0x3869ea)=>{let _0x35f8ec=_0x3869ea;_0x59962b===0x194&&(_0x35f8ec=null,_0x59962b=null),_0x59962b===null?(this['onDataUpdate_'](_0x251f47,_0x35f8ec,!0x1,null),_0x29a86d['resolve'](_0x35f8ec)):_0x29a86d['reject'](new Error(_0x35f8ec));}),_0x29a86d['promise'];}['refreshAuthToken'](_0xfc3326){}['restRequest_'](_0x18a530,_0x5856f0={},_0xaf1a2d){return _0x5856f0['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x519858,_0x1e1c7c])=>{_0x519858&&_0x519858['accessToken']&&(_0x5856f0['auth']=_0x519858['accessToken']),_0x1e1c7c&&_0x1e1c7c['token']&&(_0x5856f0['ac']=_0x1e1c7c['token']);const _0x38c49e=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x18a530+'?ns='+this['repoInfo_']['namespace']+ct(_0x5856f0);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x38c49e);const _0x36dc2e=new XMLHttpRequest();_0x36dc2e['onreadystatechange']=()=>{if(_0xaf1a2d&&_0x36dc2e['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x38c49e+'\x20received.\x20status:',_0x36dc2e['status'],'response:',_0x36dc2e['responseText']);let _0x5959b3=null;if(_0x36dc2e['status']>=0xc8&&_0x36dc2e['status']<0x12c){try{_0x5959b3=At(_0x36dc2e['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x38c49e+':\x20'+_0x36dc2e['responseText']);}_0xaf1a2d(null,_0x5959b3);}else _0x36dc2e['status']!==0x191&&_0x36dc2e['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x38c49e+'\x20Status:\x20'+_0x36dc2e['status']),_0xaf1a2d(_0x36dc2e['status']);_0xaf1a2d=null;}},_0x36dc2e['open']('GET',_0x38c49e,!0x0),_0x36dc2e['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x2abcdb){return this['rootNode_']['getChild'](_0x2abcdb);}['updateSnapshot'](_0x3f1f49,_0x1cc52f){this['rootNode_']=this['rootNode_']['updateChild'](_0x3f1f49,_0x1cc52f);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x3503f3,_0x292b9f,_0x586b62){if(v(_0x292b9f))_0x3503f3['value']=_0x586b62,_0x3503f3['children']['clear']();else{if(_0x3503f3['value']!==null)_0x3503f3['value']=_0x3503f3['value']['updateChild'](_0x292b9f,_0x586b62);else{const _0x407212=y(_0x292b9f);_0x3503f3['children']['has'](_0x407212)||_0x3503f3['children']['set'](_0x407212,_n());const _0x65bb15=_0x3503f3['children']['get'](_0x407212);_0x292b9f=b(_0x292b9f),Fo(_0x65bb15,_0x292b9f,_0x586b62);}}}function Ii(_0x3bf35d,_0x3a6a23,_0x26e5c1){_0x3bf35d['value']!==null?_0x26e5c1(_0x3a6a23,_0x3bf35d['value']):Zh(_0x3bf35d,(_0xb3f0c8,_0x28e40b)=>{const _0x38d776=new C(_0x3a6a23['toString']()+'/'+_0xb3f0c8);Ii(_0x28e40b,_0x38d776,_0x26e5c1);});}function Zh(_0x40b7e3,_0x20001b){_0x40b7e3['children']['forEach']((_0x160a1e,_0x5c1f14)=>{_0x20001b(_0x5c1f14,_0x160a1e);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0xfb713f){this['collection_']=_0xfb713f,this['last_']=null;}['get'](){const _0x1a437d=this['collection_']['get'](),_0x80bd97={..._0x1a437d};return this['last_']&&x(this['last_'],(_0x576192,_0x4389d8)=>{_0x80bd97[_0x576192]=_0x80bd97[_0x576192]-_0x4389d8;}),this['last_']=_0x1a437d,_0x80bd97;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x44346a,_0x5b696d){this['server_']=_0x5b696d,this['statsToReport_']={},this['statsListener_']=new eu(_0x44346a);const _0x335798=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x335798));}['reportStats_'](){const _0x2af8f7=this['statsListener_']['get'](),_0xc065f3={};let _0x23f339=!0x1;x(_0x2af8f7,(_0x37a421,_0xcd09a4)=>{_0xcd09a4>0x0&&J(this['statsToReport_'],_0x37a421)&&(_0xc065f3[_0x37a421]=_0xcd09a4,_0x23f339=!0x0);}),_0x23f339&&this['server_']['reportStats'](_0xc065f3),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x43cc30){_0x43cc30[_0x43cc30['OVERWRITE']=0x0]='OVERWRITE',_0x43cc30[_0x43cc30['MERGE']=0x1]='MERGE',_0x43cc30[_0x43cc30['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x43cc30[_0x43cc30['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x29bb9c){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x29bb9c,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x247eb9,_0x524f05,_0x31bd2d){this['path']=_0x247eb9,this['affectedTree']=_0x524f05,this['revert']=_0x31bd2d,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x344eb6){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x30cbcd=this['affectedTree']['subtree'](new C(_0x344eb6));return new gn(w(),_0x30cbcd,this['revert']);}}else return f(y(this['path'])===_0x344eb6,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x1c7410,_0x1cc807){this['source']=_0x1c7410,this['path']=_0x1cc807,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x53205f){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x1a9aea,_0x557603,_0x45b27a){this['source']=_0x1a9aea,this['path']=_0x557603,this['snap']=_0x45b27a,this['type']=j['OVERWRITE'];}['operationForChild'](_0x4bd526){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x4bd526)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x33b080,_0x40c4da,_0x1124d8){this['source']=_0x33b080,this['path']=_0x40c4da,this['children']=_0x1124d8,this['type']=j['MERGE'];}['operationForChild'](_0x5f4ddb){if(v(this['path'])){const _0x5a3bbb=this['children']['subtree'](new C(_0x5f4ddb));return _0x5a3bbb['isEmpty']()?null:_0x5a3bbb['value']?new Ue(this['source'],w(),_0x5a3bbb['value']):new tt(this['source'],w(),_0x5a3bbb);}else return f(y(this['path'])===_0x5f4ddb,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x2c55a2,_0x57b3c5,_0x1a6807){this['node_']=_0x2c55a2,this['fullyInitialized_']=_0x57b3c5,this['filtered_']=_0x1a6807;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x5d27a0){if(v(_0x5d27a0))return this['isFullyInitialized']()&&!this['filtered_'];const _0x4315c4=y(_0x5d27a0);return this['isCompleteForChild'](_0x4315c4);}['isCompleteForChild'](_0x9b2305){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x9b2305);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x59060a){this['query_']=_0x59060a,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x202760,_0x455c33,_0x18edb2,_0x51653e){const _0x4de0d8=[],_0x11e988=[];return _0x455c33['forEach'](_0x5bd861=>{_0x5bd861['type']==='child_changed'&&_0x202760['index_']['indexedValueChanged'](_0x5bd861['oldSnap'],_0x5bd861['snapshotNode'])&&_0x11e988['push'](zh(_0x5bd861['childName'],_0x5bd861['snapshotNode']));}),yt(_0x202760,_0x4de0d8,'child_removed',_0x455c33,_0x51653e,_0x18edb2),yt(_0x202760,_0x4de0d8,'child_added',_0x455c33,_0x51653e,_0x18edb2),yt(_0x202760,_0x4de0d8,'child_moved',_0x11e988,_0x51653e,_0x18edb2),yt(_0x202760,_0x4de0d8,'child_changed',_0x455c33,_0x51653e,_0x18edb2),yt(_0x202760,_0x4de0d8,'value',_0x455c33,_0x51653e,_0x18edb2),_0x4de0d8;}function yt(_0x37934b,_0x50c0e2,_0x864a3b,_0x1e7488,_0xe82a77,_0x456d52){const _0x5453f8=_0x1e7488['filter'](_0x1ed177=>_0x1ed177['type']===_0x864a3b);_0x5453f8['sort']((_0x6add16,_0x21ab77)=>au(_0x37934b,_0x6add16,_0x21ab77)),_0x5453f8['forEach'](_0x12ee7d=>{const _0x12b58c=ou(_0x37934b,_0x12ee7d,_0x456d52);_0xe82a77['forEach'](_0x4e135e=>{_0x4e135e['respondsTo'](_0x12ee7d['type'])&&_0x50c0e2['push'](_0x4e135e['createEvent'](_0x12b58c,_0x37934b['query_']));});});}function ou(_0x14d98d,_0x5bd396,_0x5d4076){return _0x5bd396['type']==='value'||_0x5bd396['type']==='child_removed'||(_0x5bd396['prevName']=_0x5d4076['getPredecessorChildName'](_0x5bd396['childName'],_0x5bd396['snapshotNode'],_0x14d98d['index_'])),_0x5bd396;}function au(_0x445861,_0x24f6f6,_0x444aa0){if(_0x24f6f6['childName']==null||_0x444aa0['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x5bef9f=new E(_0x24f6f6['childName'],_0x24f6f6['snapshotNode']),_0x2dae0b=new E(_0x444aa0['childName'],_0x444aa0['snapshotNode']);return _0x445861['index_']['compare'](_0x5bef9f,_0x2dae0b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x411109,_0x523127){return{'eventCache':_0x411109,'serverCache':_0x523127};}function Tt(_0x165560,_0x5030de,_0x166a9d,_0x1120b3){return Mn(new Ce(_0x5030de,_0x166a9d,_0x1120b3),_0x165560['serverCache']);}function Uo(_0x17bb3c,_0x114cd3,_0x3424a0,_0x253e5d){return Mn(_0x17bb3c['eventCache'],new Ce(_0x114cd3,_0x3424a0,_0x253e5d));}function mn(_0x36ef86){return _0x36ef86['eventCache']['isFullyInitialized']()?_0x36ef86['eventCache']['getNode']():null;}function We(_0x165e15){return _0x165e15['serverCache']['isFullyInitialized']()?_0x165e15['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x4884a4){let _0x1c6cab=new S(null);return x(_0x4884a4,(_0x564f93,_0x4aaeba)=>{_0x1c6cab=_0x1c6cab['set'](new C(_0x564f93),_0x4aaeba);}),_0x1c6cab;}constructor(_0x5e1959,_0x194b02=cu()){this['value']=_0x5e1959,this['children']=_0x194b02;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x4e3c14,_0x36759c){if(this['value']!=null&&_0x36759c(this['value']))return{'path':w(),'value':this['value']};if(v(_0x4e3c14))return null;{const _0x5ef9c9=y(_0x4e3c14),_0x474c15=this['children']['get'](_0x5ef9c9);if(_0x474c15!==null){const _0xe8a288=_0x474c15['findRootMostMatchingPathAndValue'](b(_0x4e3c14),_0x36759c);return _0xe8a288!=null?{'path':k(new C(_0x5ef9c9),_0xe8a288['path']),'value':_0xe8a288['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x164be4){return this['findRootMostMatchingPathAndValue'](_0x164be4,()=>!0x0);}['subtree'](_0x57c581){if(v(_0x57c581))return this;{const _0x429fb9=y(_0x57c581),_0x4a98ad=this['children']['get'](_0x429fb9);return _0x4a98ad!==null?_0x4a98ad['subtree'](b(_0x57c581)):new S(null);}}['set'](_0x44eb6b,_0x422d0e){if(v(_0x44eb6b))return new S(_0x422d0e,this['children']);{const _0x412778=y(_0x44eb6b),_0x4736d3=(this['children']['get'](_0x412778)||new S(null))['set'](b(_0x44eb6b),_0x422d0e),_0xef14ee=this['children']['insert'](_0x412778,_0x4736d3);return new S(this['value'],_0xef14ee);}}['remove'](_0x3446a9){if(v(_0x3446a9))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x153550=y(_0x3446a9),_0x3458c6=this['children']['get'](_0x153550);if(_0x3458c6){const _0x49fc6b=_0x3458c6['remove'](b(_0x3446a9));let _0x3a4e8e;return _0x49fc6b['isEmpty']()?_0x3a4e8e=this['children']['remove'](_0x153550):_0x3a4e8e=this['children']['insert'](_0x153550,_0x49fc6b),this['value']===null&&_0x3a4e8e['isEmpty']()?new S(null):new S(this['value'],_0x3a4e8e);}else return this;}}['get'](_0x216abb){if(v(_0x216abb))return this['value'];{const _0x4ea9c2=y(_0x216abb),_0x9a6698=this['children']['get'](_0x4ea9c2);return _0x9a6698?_0x9a6698['get'](b(_0x216abb)):null;}}['setTree'](_0x16d403,_0x407aac){if(v(_0x16d403))return _0x407aac;{const _0xcc6088=y(_0x16d403),_0xaeeb2=(this['children']['get'](_0xcc6088)||new S(null))['setTree'](b(_0x16d403),_0x407aac);let _0x34fec3;return _0xaeeb2['isEmpty']()?_0x34fec3=this['children']['remove'](_0xcc6088):_0x34fec3=this['children']['insert'](_0xcc6088,_0xaeeb2),new S(this['value'],_0x34fec3);}}['fold'](_0x19bbb3){return this['fold_'](w(),_0x19bbb3);}['fold_'](_0xb0077e,_0x1585ab){const _0x94801e={};return this['children']['inorderTraversal']((_0xefdde6,_0x16d0a5)=>{_0x94801e[_0xefdde6]=_0x16d0a5['fold_'](k(_0xb0077e,_0xefdde6),_0x1585ab);}),_0x1585ab(_0xb0077e,this['value'],_0x94801e);}['findOnPath'](_0x4e55a,_0x5ea90a){return this['findOnPath_'](_0x4e55a,w(),_0x5ea90a);}['findOnPath_'](_0x26a82c,_0x49493a,_0x175727){const _0x255e86=this['value']?_0x175727(_0x49493a,this['value']):!0x1;if(_0x255e86)return _0x255e86;if(v(_0x26a82c))return null;{const _0x511d32=y(_0x26a82c),_0xe33cc3=this['children']['get'](_0x511d32);return _0xe33cc3?_0xe33cc3['findOnPath_'](b(_0x26a82c),k(_0x49493a,_0x511d32),_0x175727):null;}}['foreachOnPath'](_0x4a42f4,_0x230629){return this['foreachOnPath_'](_0x4a42f4,w(),_0x230629);}['foreachOnPath_'](_0x1b5825,_0xa08ec4,_0x57bd4d){if(v(_0x1b5825))return this;{this['value']&&_0x57bd4d(_0xa08ec4,this['value']);const _0x30cdda=y(_0x1b5825),_0xab0553=this['children']['get'](_0x30cdda);return _0xab0553?_0xab0553['foreachOnPath_'](b(_0x1b5825),k(_0xa08ec4,_0x30cdda),_0x57bd4d):new S(null);}}['foreach'](_0x8dc1a4){this['foreach_'](w(),_0x8dc1a4);}['foreach_'](_0x33d1f8,_0x5f44b6){this['children']['inorderTraversal']((_0x1cbcc1,_0x3e68b7)=>{_0x3e68b7['foreach_'](k(_0x33d1f8,_0x1cbcc1),_0x5f44b6);}),this['value']&&_0x5f44b6(_0x33d1f8,this['value']);}['foreachChild'](_0x2bc76a){this['children']['inorderTraversal']((_0x590fb8,_0x4ec09d)=>{_0x4ec09d['value']&&_0x2bc76a(_0x590fb8,_0x4ec09d['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x368c68){this['writeTree_']=_0x368c68;}static['empty'](){return new Y(new S(null));}}function St(_0x536559,_0x3a0aff,_0x43ca8b){if(v(_0x3a0aff))return new Y(new S(_0x43ca8b));{const _0x472ea2=_0x536559['writeTree_']['findRootMostValueAndPath'](_0x3a0aff);if(_0x472ea2!=null){const _0x3f5ca1=_0x472ea2['path'];let _0x1c4775=_0x472ea2['value'];const _0xf334f8=F(_0x3f5ca1,_0x3a0aff);return _0x1c4775=_0x1c4775['updateChild'](_0xf334f8,_0x43ca8b),new Y(_0x536559['writeTree_']['set'](_0x3f5ca1,_0x1c4775));}else{const _0x1e30a4=new S(_0x43ca8b),_0xd4d8ec=_0x536559['writeTree_']['setTree'](_0x3a0aff,_0x1e30a4);return new Y(_0xd4d8ec);}}}function wi(_0x15e155,_0x48f1a5,_0x19f458){let _0x301536=_0x15e155;return x(_0x19f458,(_0x508c31,_0x195e65)=>{_0x301536=St(_0x301536,k(_0x48f1a5,_0x508c31),_0x195e65);}),_0x301536;}function ar(_0x24cfb2,_0x68fa57){if(v(_0x68fa57))return Y['empty']();{const _0xebdfc7=_0x24cfb2['writeTree_']['setTree'](_0x68fa57,new S(null));return new Y(_0xebdfc7);}}function Ci(_0x15e2cc,_0x523235){return $e(_0x15e2cc,_0x523235)!=null;}function $e(_0x3e4f24,_0x10b0ad){const _0x4fbaa0=_0x3e4f24['writeTree_']['findRootMostValueAndPath'](_0x10b0ad);return _0x4fbaa0!=null?_0x3e4f24['writeTree_']['get'](_0x4fbaa0['path'])['getChild'](F(_0x4fbaa0['path'],_0x10b0ad)):null;}function cr(_0x4664de){const _0x2cd10a=[],_0x4ba845=_0x4664de['writeTree_']['value'];return _0x4ba845!=null?_0x4ba845['isLeafNode']()||_0x4ba845['forEachChild'](R,(_0x448496,_0x26345e)=>{_0x2cd10a['push'](new E(_0x448496,_0x26345e));}):_0x4664de['writeTree_']['children']['inorderTraversal']((_0x485afe,_0xa41706)=>{_0xa41706['value']!=null&&_0x2cd10a['push'](new E(_0x485afe,_0xa41706['value']));}),_0x2cd10a;}function ve(_0x1ed6bd,_0x13cd74){if(v(_0x13cd74))return _0x1ed6bd;{const _0x78eeac=$e(_0x1ed6bd,_0x13cd74);return _0x78eeac!=null?new Y(new S(_0x78eeac)):new Y(_0x1ed6bd['writeTree_']['subtree'](_0x13cd74));}}function Ti(_0x599f3f){return _0x599f3f['writeTree_']['isEmpty']();}function nt(_0x2f0825,_0x344cf6){return Wo(w(),_0x2f0825['writeTree_'],_0x344cf6);}function Wo(_0x39a58c,_0x43bfe8,_0x5117cb){if(_0x43bfe8['value']!=null)return _0x5117cb['updateChild'](_0x39a58c,_0x43bfe8['value']);{let _0x150f5f=null;return _0x43bfe8['children']['inorderTraversal']((_0x2d99d3,_0x2baebe)=>{_0x2d99d3==='.priority'?(f(_0x2baebe['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x150f5f=_0x2baebe['value']):_0x5117cb=Wo(k(_0x39a58c,_0x2d99d3),_0x2baebe,_0x5117cb);}),!_0x5117cb['getChild'](_0x39a58c)['isEmpty']()&&_0x150f5f!==null&&(_0x5117cb=_0x5117cb['updateChild'](k(_0x39a58c,'.priority'),_0x150f5f)),_0x5117cb;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0xb8da27,_0x22be7a){return $o(_0x22be7a,_0xb8da27);}function lu(_0x123448,_0x183fe9,_0x166dfb,_0x14f81a,_0x187878){f(_0x14f81a>_0x123448['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x187878===void 0x0&&(_0x187878=!0x0),_0x123448['allWrites']['push']({'path':_0x183fe9,'snap':_0x166dfb,'writeId':_0x14f81a,'visible':_0x187878}),_0x187878&&(_0x123448['visibleWrites']=St(_0x123448['visibleWrites'],_0x183fe9,_0x166dfb)),_0x123448['lastWriteId']=_0x14f81a;}function hu(_0xcb7915,_0x3c1617,_0x46bb2d,_0x46fcde){f(_0x46fcde>_0xcb7915['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0xcb7915['allWrites']['push']({'path':_0x3c1617,'children':_0x46bb2d,'writeId':_0x46fcde,'visible':!0x0}),_0xcb7915['visibleWrites']=wi(_0xcb7915['visibleWrites'],_0x3c1617,_0x46bb2d),_0xcb7915['lastWriteId']=_0x46fcde;}function uu(_0x465d9c,_0xe0797a){for(let _0xe50b71=0x0;_0xe50b71<_0x465d9c['allWrites']['length'];_0xe50b71++){const _0x233ddd=_0x465d9c['allWrites'][_0xe50b71];if(_0x233ddd['writeId']===_0xe0797a)return _0x233ddd;}return null;}function du(_0x298085,_0x3bc58a){const _0xdd8ffd=_0x298085['allWrites']['findIndex'](_0x243713=>_0x243713['writeId']===_0x3bc58a);f(_0xdd8ffd>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x5b6a7f=_0x298085['allWrites'][_0xdd8ffd];_0x298085['allWrites']['splice'](_0xdd8ffd,0x1);let _0x4efa72=_0x5b6a7f['visible'],_0x2dc00e=!0x1,_0x313fd0=_0x298085['allWrites']['length']-0x1;for(;_0x4efa72&&_0x313fd0>=0x0;){const _0x4a768d=_0x298085['allWrites'][_0x313fd0];_0x4a768d['visible']&&(_0x313fd0>=_0xdd8ffd&&fu(_0x4a768d,_0x5b6a7f['path'])?_0x4efa72=!0x1:G(_0x5b6a7f['path'],_0x4a768d['path'])&&(_0x2dc00e=!0x0)),_0x313fd0--;}if(_0x4efa72){if(_0x2dc00e)return pu(_0x298085),!0x0;if(_0x5b6a7f['snap'])_0x298085['visibleWrites']=ar(_0x298085['visibleWrites'],_0x5b6a7f['path']);else{const _0x4972c8=_0x5b6a7f['children'];x(_0x4972c8,_0x2f74a4=>{_0x298085['visibleWrites']=ar(_0x298085['visibleWrites'],k(_0x5b6a7f['path'],_0x2f74a4));});}return!0x0;}else return!0x1;}function fu(_0x40bd7a,_0x2d4daf){if(_0x40bd7a['snap'])return G(_0x40bd7a['path'],_0x2d4daf);for(const _0x4d531f in _0x40bd7a['children'])if(_0x40bd7a['children']['hasOwnProperty'](_0x4d531f)&&G(k(_0x40bd7a['path'],_0x4d531f),_0x2d4daf))return!0x0;return!0x1;}function pu(_0x29927a){_0x29927a['visibleWrites']=Bo(_0x29927a['allWrites'],_u,w()),_0x29927a['allWrites']['length']>0x0?_0x29927a['lastWriteId']=_0x29927a['allWrites'][_0x29927a['allWrites']['length']-0x1]['writeId']:_0x29927a['lastWriteId']=-0x1;}function _u(_0xff26eb){return _0xff26eb['visible'];}function Bo(_0x1f577e,_0x651a8b,_0x3fc1f1){let _0x4e84c3=Y['empty']();for(let _0x4a1c11=0x0;_0x4a1c11<_0x1f577e['length'];++_0x4a1c11){const _0x455677=_0x1f577e[_0x4a1c11];if(_0x651a8b(_0x455677)){const _0x5d4a82=_0x455677['path'];let _0x3d8182;if(_0x455677['snap'])G(_0x3fc1f1,_0x5d4a82)?(_0x3d8182=F(_0x3fc1f1,_0x5d4a82),_0x4e84c3=St(_0x4e84c3,_0x3d8182,_0x455677['snap'])):G(_0x5d4a82,_0x3fc1f1)&&(_0x3d8182=F(_0x5d4a82,_0x3fc1f1),_0x4e84c3=St(_0x4e84c3,w(),_0x455677['snap']['getChild'](_0x3d8182)));else{if(_0x455677['children']){if(G(_0x3fc1f1,_0x5d4a82))_0x3d8182=F(_0x3fc1f1,_0x5d4a82),_0x4e84c3=wi(_0x4e84c3,_0x3d8182,_0x455677['children']);else{if(G(_0x5d4a82,_0x3fc1f1)){if(_0x3d8182=F(_0x5d4a82,_0x3fc1f1),v(_0x3d8182))_0x4e84c3=wi(_0x4e84c3,w(),_0x455677['children']);else{const _0x4fc912=De(_0x455677['children'],y(_0x3d8182));if(_0x4fc912){const _0x43f4aa=_0x4fc912['getChild'](b(_0x3d8182));_0x4e84c3=St(_0x4e84c3,w(),_0x43f4aa);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x4e84c3;}function Vo(_0x5d6919,_0x4117b1,_0x3cb527,_0x209199,_0x813962){if(!_0x209199&&!_0x813962){const _0xad434=$e(_0x5d6919['visibleWrites'],_0x4117b1);if(_0xad434!=null)return _0xad434;{const _0x7b9df8=ve(_0x5d6919['visibleWrites'],_0x4117b1);if(Ti(_0x7b9df8))return _0x3cb527;if(_0x3cb527==null&&!Ci(_0x7b9df8,w()))return null;{const _0x8b312f=_0x3cb527||g['EMPTY_NODE'];return nt(_0x7b9df8,_0x8b312f);}}}else{const _0x2fdcfb=ve(_0x5d6919['visibleWrites'],_0x4117b1);if(!_0x813962&&Ti(_0x2fdcfb))return _0x3cb527;if(!_0x813962&&_0x3cb527==null&&!Ci(_0x2fdcfb,w()))return null;{const _0x26029f=function(_0x3d56ad){return(_0x3d56ad['visible']||_0x813962)&&(!_0x209199||!~_0x209199['indexOf'](_0x3d56ad['writeId']))&&(G(_0x3d56ad['path'],_0x4117b1)||G(_0x4117b1,_0x3d56ad['path']));},_0x3d0956=Bo(_0x5d6919['allWrites'],_0x26029f,_0x4117b1),_0x573014=_0x3cb527||g['EMPTY_NODE'];return nt(_0x3d0956,_0x573014);}}}function gu(_0x567964,_0x5aa983,_0x43315e){let _0xae389f=g['EMPTY_NODE'];const _0x100cc2=$e(_0x567964['visibleWrites'],_0x5aa983);if(_0x100cc2)return _0x100cc2['isLeafNode']()||_0x100cc2['forEachChild'](R,(_0x30a674,_0x4c6fad)=>{_0xae389f=_0xae389f['updateImmediateChild'](_0x30a674,_0x4c6fad);}),_0xae389f;if(_0x43315e){const _0x2557fe=ve(_0x567964['visibleWrites'],_0x5aa983);return _0x43315e['forEachChild'](R,(_0x443316,_0x5aa4a4)=>{const _0x27c042=nt(ve(_0x2557fe,new C(_0x443316)),_0x5aa4a4);_0xae389f=_0xae389f['updateImmediateChild'](_0x443316,_0x27c042);}),cr(_0x2557fe)['forEach'](_0x1e72b5=>{_0xae389f=_0xae389f['updateImmediateChild'](_0x1e72b5['name'],_0x1e72b5['node']);}),_0xae389f;}else{const _0x4a15fb=ve(_0x567964['visibleWrites'],_0x5aa983);return cr(_0x4a15fb)['forEach'](_0x2a9c75=>{_0xae389f=_0xae389f['updateImmediateChild'](_0x2a9c75['name'],_0x2a9c75['node']);}),_0xae389f;}}function mu(_0x22125e,_0x14cdf7,_0x5931f2,_0x593acf,_0x3c657f){f(_0x593acf||_0x3c657f,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x5e154d=k(_0x14cdf7,_0x5931f2);if(Ci(_0x22125e['visibleWrites'],_0x5e154d))return null;{const _0xdbbb11=ve(_0x22125e['visibleWrites'],_0x5e154d);return Ti(_0xdbbb11)?_0x3c657f['getChild'](_0x5931f2):nt(_0xdbbb11,_0x3c657f['getChild'](_0x5931f2));}}function yu(_0x259725,_0x126548,_0x374eed,_0x20dfe0){const _0x4e6a79=k(_0x126548,_0x374eed),_0x5d35a4=$e(_0x259725['visibleWrites'],_0x4e6a79);if(_0x5d35a4!=null)return _0x5d35a4;if(_0x20dfe0['isCompleteForChild'](_0x374eed)){const _0x3a742b=ve(_0x259725['visibleWrites'],_0x4e6a79);return nt(_0x3a742b,_0x20dfe0['getNode']()['getImmediateChild'](_0x374eed));}else return null;}function vu(_0x5a74c1,_0x2a41e8){return $e(_0x5a74c1['visibleWrites'],_0x2a41e8);}function Eu(_0x5d984e,_0x393f7a,_0x18d711,_0x525104,_0x43ad83,_0x499ffe,_0x321d27){let _0x43ce98;const _0x5b5c01=ve(_0x5d984e['visibleWrites'],_0x393f7a),_0x5d92f9=$e(_0x5b5c01,w());if(_0x5d92f9!=null)_0x43ce98=_0x5d92f9;else{if(_0x18d711!=null)_0x43ce98=nt(_0x5b5c01,_0x18d711);else return[];}if(_0x43ce98=_0x43ce98['withIndex'](_0x321d27),!_0x43ce98['isEmpty']()&&!_0x43ce98['isLeafNode']()){const _0x4c3226=[],_0xc39e79=_0x321d27['getCompare'](),_0x2358a2=_0x499ffe?_0x43ce98['getReverseIteratorFrom'](_0x525104,_0x321d27):_0x43ce98['getIteratorFrom'](_0x525104,_0x321d27);let _0xef249f=_0x2358a2['getNext']();for(;_0xef249f&&_0x4c3226['length']<_0x43ad83;)_0xc39e79(_0xef249f,_0x525104)!==0x0&&_0x4c3226['push'](_0xef249f),_0xef249f=_0x2358a2['getNext']();return _0x4c3226;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x362be4,_0x35b996,_0x3512c8,_0x31af4a){return Vo(_0x362be4['writeTree'],_0x362be4['treePath'],_0x35b996,_0x3512c8,_0x31af4a);}function ns(_0x14c64a,_0x449ca0){return gu(_0x14c64a['writeTree'],_0x14c64a['treePath'],_0x449ca0);}function lr(_0x21da13,_0x1fdcd6,_0x52700e,_0x73246b){return mu(_0x21da13['writeTree'],_0x21da13['treePath'],_0x1fdcd6,_0x52700e,_0x73246b);}function vn(_0x5efbb9,_0x2716b6){return vu(_0x5efbb9['writeTree'],k(_0x5efbb9['treePath'],_0x2716b6));}function wu(_0x58e691,_0x3920fb,_0x1ef5e0,_0x3c2354,_0x271acf,_0x5b3d8b){return Eu(_0x58e691['writeTree'],_0x58e691['treePath'],_0x3920fb,_0x1ef5e0,_0x3c2354,_0x271acf,_0x5b3d8b);}function is(_0x174165,_0x301b41,_0x55d0aa){return yu(_0x174165['writeTree'],_0x174165['treePath'],_0x301b41,_0x55d0aa);}function Ho(_0x5c3c2e,_0x1bc3d0){return $o(k(_0x5c3c2e['treePath'],_0x1bc3d0),_0x5c3c2e['writeTree']);}function $o(_0x33185c,_0x25d608){return{'treePath':_0x33185c,'writeTree':_0x25d608};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x519798){const _0x19815c=_0x519798['type'],_0x581722=_0x519798['childName'];f(_0x19815c==='child_added'||_0x19815c==='child_changed'||_0x19815c==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x581722!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x1111d3=this['changeMap']['get'](_0x581722);if(_0x1111d3){const _0x478c90=_0x1111d3['type'];if(_0x19815c==='child_added'&&_0x478c90==='child_removed')this['changeMap']['set'](_0x581722,Dt(_0x581722,_0x519798['snapshotNode'],_0x1111d3['snapshotNode']));else{if(_0x19815c==='child_removed'&&_0x478c90==='child_added')this['changeMap']['delete'](_0x581722);else{if(_0x19815c==='child_removed'&&_0x478c90==='child_changed')this['changeMap']['set'](_0x581722,Ot(_0x581722,_0x1111d3['oldSnap']));else{if(_0x19815c==='child_changed'&&_0x478c90==='child_added')this['changeMap']['set'](_0x581722,et(_0x581722,_0x519798['snapshotNode']));else{if(_0x19815c==='child_changed'&&_0x478c90==='child_changed')this['changeMap']['set'](_0x581722,Dt(_0x581722,_0x519798['snapshotNode'],_0x1111d3['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x519798+'\x20occurred\x20after\x20'+_0x1111d3);}}}}}else this['changeMap']['set'](_0x581722,_0x519798);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x599cc0){return null;}['getChildAfterChild'](_0x52f4f6,_0x447723,_0x31cc4c){return null;}}const Go=new Tu();class ss{constructor(_0x31c551,_0x34d515,_0x1866df=null){this['writes_']=_0x31c551,this['viewCache_']=_0x34d515,this['optCompleteServerCache_']=_0x1866df;}['getCompleteChild'](_0x1da60e){const _0x1171bc=this['viewCache_']['eventCache'];if(_0x1171bc['isCompleteForChild'](_0x1da60e))return _0x1171bc['getNode']()['getImmediateChild'](_0x1da60e);{const _0x3e9365=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x1da60e,_0x3e9365);}}['getChildAfterChild'](_0x7263c1,_0x22c51d,_0x13e470){const _0x74caef=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x57d82a=wu(this['writes_'],_0x74caef,_0x22c51d,0x1,_0x13e470,_0x7263c1);return _0x57d82a['length']===0x0?null:_0x57d82a[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0xaccaa0){return{'filter':_0xaccaa0};}function bu(_0x419e11,_0x744da0){f(_0x744da0['eventCache']['getNode']()['isIndexed'](_0x419e11['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x744da0['serverCache']['getNode']()['isIndexed'](_0x419e11['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x14aa9a,_0x1e409f,_0xed3f2,_0x32f557,_0x411baa){const _0x4bca65=new Cu();let _0x1653ca,_0x5b5931;if(_0xed3f2['type']===j['OVERWRITE']){const _0xc0b80f=_0xed3f2;_0xc0b80f['source']['fromUser']?_0x1653ca=Si(_0x14aa9a,_0x1e409f,_0xc0b80f['path'],_0xc0b80f['snap'],_0x32f557,_0x411baa,_0x4bca65):(f(_0xc0b80f['source']['fromServer'],'Unknown\x20source.'),_0x5b5931=_0xc0b80f['source']['tagged']||_0x1e409f['serverCache']['isFiltered']()&&!v(_0xc0b80f['path']),_0x1653ca=En(_0x14aa9a,_0x1e409f,_0xc0b80f['path'],_0xc0b80f['snap'],_0x32f557,_0x411baa,_0x5b5931,_0x4bca65));}else{if(_0xed3f2['type']===j['MERGE']){const _0x583a7f=_0xed3f2;_0x583a7f['source']['fromUser']?_0x1653ca=ku(_0x14aa9a,_0x1e409f,_0x583a7f['path'],_0x583a7f['children'],_0x32f557,_0x411baa,_0x4bca65):(f(_0x583a7f['source']['fromServer'],'Unknown\x20source.'),_0x5b5931=_0x583a7f['source']['tagged']||_0x1e409f['serverCache']['isFiltered'](),_0x1653ca=bi(_0x14aa9a,_0x1e409f,_0x583a7f['path'],_0x583a7f['children'],_0x32f557,_0x411baa,_0x5b5931,_0x4bca65));}else{if(_0xed3f2['type']===j['ACK_USER_WRITE']){const _0x4c5554=_0xed3f2;_0x4c5554['revert']?_0x1653ca=Ou(_0x14aa9a,_0x1e409f,_0x4c5554['path'],_0x32f557,_0x411baa,_0x4bca65):_0x1653ca=Nu(_0x14aa9a,_0x1e409f,_0x4c5554['path'],_0x4c5554['affectedTree'],_0x32f557,_0x411baa,_0x4bca65);}else{if(_0xed3f2['type']===j['LISTEN_COMPLETE'])_0x1653ca=Pu(_0x14aa9a,_0x1e409f,_0xed3f2['path'],_0x32f557,_0x4bca65);else throw rt('Unknown\x20operation\x20type:\x20'+_0xed3f2['type']);}}}const _0x5e9881=_0x4bca65['getChanges']();return Au(_0x1e409f,_0x1653ca,_0x5e9881),{'viewCache':_0x1653ca,'changes':_0x5e9881};}function Au(_0x4fe681,_0x4134e4,_0x4c0ef0){const _0x35be26=_0x4134e4['eventCache'];if(_0x35be26['isFullyInitialized']()){const _0x20637f=_0x35be26['getNode']()['isLeafNode']()||_0x35be26['getNode']()['isEmpty'](),_0x141a81=mn(_0x4fe681);(_0x4c0ef0['length']>0x0||!_0x4fe681['eventCache']['isFullyInitialized']()||_0x20637f&&!_0x35be26['getNode']()['equals'](_0x141a81)||!_0x35be26['getNode']()['getPriority']()['equals'](_0x141a81['getPriority']()))&&_0x4c0ef0['push'](Lo(mn(_0x4134e4)));}}function qo(_0x8c17a2,_0x2a3a45,_0x5678c7,_0x293602,_0x26206e,_0xad1dee){const _0x310ad0=_0x2a3a45['eventCache'];if(vn(_0x293602,_0x5678c7)!=null)return _0x2a3a45;{let _0x51096f,_0x4543cd;if(v(_0x5678c7)){if(f(_0x2a3a45['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x2a3a45['serverCache']['isFiltered']()){const _0x113de6=We(_0x2a3a45),_0x2ec81f=_0x113de6 instanceof g?_0x113de6:g['EMPTY_NODE'],_0x29f1d8=ns(_0x293602,_0x2ec81f);_0x51096f=_0x8c17a2['filter']['updateFullNode'](_0x2a3a45['eventCache']['getNode'](),_0x29f1d8,_0xad1dee);}else{const _0x4810f4=yn(_0x293602,We(_0x2a3a45));_0x51096f=_0x8c17a2['filter']['updateFullNode'](_0x2a3a45['eventCache']['getNode'](),_0x4810f4,_0xad1dee);}}else{const _0x40f94b=y(_0x5678c7);if(_0x40f94b==='.priority'){f(we(_0x5678c7)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x3b73d9=_0x310ad0['getNode']();_0x4543cd=_0x2a3a45['serverCache']['getNode']();const _0x1044ad=lr(_0x293602,_0x5678c7,_0x3b73d9,_0x4543cd);_0x1044ad!=null?_0x51096f=_0x8c17a2['filter']['updatePriority'](_0x3b73d9,_0x1044ad):_0x51096f=_0x310ad0['getNode']();}else{const _0x31642f=b(_0x5678c7);let _0x37f00a;if(_0x310ad0['isCompleteForChild'](_0x40f94b)){_0x4543cd=_0x2a3a45['serverCache']['getNode']();const _0x37e9af=lr(_0x293602,_0x5678c7,_0x310ad0['getNode'](),_0x4543cd);_0x37e9af!=null?_0x37f00a=_0x310ad0['getNode']()['getImmediateChild'](_0x40f94b)['updateChild'](_0x31642f,_0x37e9af):_0x37f00a=_0x310ad0['getNode']()['getImmediateChild'](_0x40f94b);}else _0x37f00a=is(_0x293602,_0x40f94b,_0x2a3a45['serverCache']);_0x37f00a!=null?_0x51096f=_0x8c17a2['filter']['updateChild'](_0x310ad0['getNode'](),_0x40f94b,_0x37f00a,_0x31642f,_0x26206e,_0xad1dee):_0x51096f=_0x310ad0['getNode']();}}return Tt(_0x2a3a45,_0x51096f,_0x310ad0['isFullyInitialized']()||v(_0x5678c7),_0x8c17a2['filter']['filtersNodes']());}}function En(_0x4ffeb8,_0x27e51e,_0x3c8105,_0x5d2ec9,_0x1e26bf,_0x4d6f3b,_0x30b58d,_0xc0ad3a){const _0x274426=_0x27e51e['serverCache'];let _0x5727f5;const _0x203cfc=_0x30b58d?_0x4ffeb8['filter']:_0x4ffeb8['filter']['getIndexedFilter']();if(v(_0x3c8105))_0x5727f5=_0x203cfc['updateFullNode'](_0x274426['getNode'](),_0x5d2ec9,null);else{if(_0x203cfc['filtersNodes']()&&!_0x274426['isFiltered']()){const _0x5c5b1d=_0x274426['getNode']()['updateChild'](_0x3c8105,_0x5d2ec9);_0x5727f5=_0x203cfc['updateFullNode'](_0x274426['getNode'](),_0x5c5b1d,null);}else{const _0x53d211=y(_0x3c8105);if(!_0x274426['isCompleteForPath'](_0x3c8105)&&we(_0x3c8105)>0x1)return _0x27e51e;const _0x32c722=b(_0x3c8105),_0x100561=_0x274426['getNode']()['getImmediateChild'](_0x53d211)['updateChild'](_0x32c722,_0x5d2ec9);_0x53d211==='.priority'?_0x5727f5=_0x203cfc['updatePriority'](_0x274426['getNode'](),_0x100561):_0x5727f5=_0x203cfc['updateChild'](_0x274426['getNode'](),_0x53d211,_0x100561,_0x32c722,Go,null);}}const _0x425715=Uo(_0x27e51e,_0x5727f5,_0x274426['isFullyInitialized']()||v(_0x3c8105),_0x203cfc['filtersNodes']()),_0x5d8d0e=new ss(_0x1e26bf,_0x425715,_0x4d6f3b);return qo(_0x4ffeb8,_0x425715,_0x3c8105,_0x1e26bf,_0x5d8d0e,_0xc0ad3a);}function Si(_0x3e5df0,_0x51e3d7,_0x908b8f,_0x527a85,_0x533e55,_0x355b59,_0x29c6a8){const _0x3863ba=_0x51e3d7['eventCache'];let _0x5e8f72,_0x1b3ee2;const _0x1d8d40=new ss(_0x533e55,_0x51e3d7,_0x355b59);if(v(_0x908b8f))_0x1b3ee2=_0x3e5df0['filter']['updateFullNode'](_0x51e3d7['eventCache']['getNode'](),_0x527a85,_0x29c6a8),_0x5e8f72=Tt(_0x51e3d7,_0x1b3ee2,!0x0,_0x3e5df0['filter']['filtersNodes']());else{const _0x33b33c=y(_0x908b8f);if(_0x33b33c==='.priority')_0x1b3ee2=_0x3e5df0['filter']['updatePriority'](_0x51e3d7['eventCache']['getNode'](),_0x527a85),_0x5e8f72=Tt(_0x51e3d7,_0x1b3ee2,_0x3863ba['isFullyInitialized'](),_0x3863ba['isFiltered']());else{const _0x29a16e=b(_0x908b8f),_0x543991=_0x3863ba['getNode']()['getImmediateChild'](_0x33b33c);let _0x41cbcc;if(v(_0x29a16e))_0x41cbcc=_0x527a85;else{const _0x3106e2=_0x1d8d40['getCompleteChild'](_0x33b33c);_0x3106e2!=null?zi(_0x29a16e)==='.priority'&&_0x3106e2['getChild'](Ro(_0x29a16e))['isEmpty']()?_0x41cbcc=_0x3106e2:_0x41cbcc=_0x3106e2['updateChild'](_0x29a16e,_0x527a85):_0x41cbcc=g['EMPTY_NODE'];}if(_0x543991['equals'](_0x41cbcc))_0x5e8f72=_0x51e3d7;else{const _0x3f6796=_0x3e5df0['filter']['updateChild'](_0x3863ba['getNode'](),_0x33b33c,_0x41cbcc,_0x29a16e,_0x1d8d40,_0x29c6a8);_0x5e8f72=Tt(_0x51e3d7,_0x3f6796,_0x3863ba['isFullyInitialized'](),_0x3e5df0['filter']['filtersNodes']());}}}return _0x5e8f72;}function hr(_0x34b3f3,_0x16e9a9){return _0x34b3f3['eventCache']['isCompleteForChild'](_0x16e9a9);}function ku(_0x1c2ad3,_0x2b523f,_0x2f59c4,_0x1dafa5,_0x3f3302,_0x15f9a1,_0x397a5c){let _0x1853fb=_0x2b523f;return _0x1dafa5['foreach']((_0xfd060f,_0x41e377)=>{const _0x4800c6=k(_0x2f59c4,_0xfd060f);hr(_0x2b523f,y(_0x4800c6))&&(_0x1853fb=Si(_0x1c2ad3,_0x1853fb,_0x4800c6,_0x41e377,_0x3f3302,_0x15f9a1,_0x397a5c));}),_0x1dafa5['foreach']((_0x128856,_0x2511b0)=>{const _0x5e3535=k(_0x2f59c4,_0x128856);hr(_0x2b523f,y(_0x5e3535))||(_0x1853fb=Si(_0x1c2ad3,_0x1853fb,_0x5e3535,_0x2511b0,_0x3f3302,_0x15f9a1,_0x397a5c));}),_0x1853fb;}function ur(_0x417724,_0x3edb32,_0x328b5a){return _0x328b5a['foreach']((_0x5bece0,_0x39b361)=>{_0x3edb32=_0x3edb32['updateChild'](_0x5bece0,_0x39b361);}),_0x3edb32;}function bi(_0x41752c,_0x7bab87,_0x6fee47,_0x551924,_0x3a2ec1,_0x1c9ae0,_0x55942f,_0x26103e){if(_0x7bab87['serverCache']['getNode']()['isEmpty']()&&!_0x7bab87['serverCache']['isFullyInitialized']())return _0x7bab87;let _0x4dddc4=_0x7bab87,_0x7c013a;v(_0x6fee47)?_0x7c013a=_0x551924:_0x7c013a=new S(null)['setTree'](_0x6fee47,_0x551924);const _0x314bfe=_0x7bab87['serverCache']['getNode']();return _0x7c013a['children']['inorderTraversal']((_0x8ca123,_0x3530f0)=>{if(_0x314bfe['hasChild'](_0x8ca123)){const _0x35707f=_0x7bab87['serverCache']['getNode']()['getImmediateChild'](_0x8ca123),_0x24c02a=ur(_0x41752c,_0x35707f,_0x3530f0);_0x4dddc4=En(_0x41752c,_0x4dddc4,new C(_0x8ca123),_0x24c02a,_0x3a2ec1,_0x1c9ae0,_0x55942f,_0x26103e);}}),_0x7c013a['children']['inorderTraversal']((_0x20e849,_0x558a4b)=>{const _0x137ad8=!_0x7bab87['serverCache']['isCompleteForChild'](_0x20e849)&&_0x558a4b['value']===null;if(!_0x314bfe['hasChild'](_0x20e849)&&!_0x137ad8){const _0x95a747=_0x7bab87['serverCache']['getNode']()['getImmediateChild'](_0x20e849),_0x6fb1a0=ur(_0x41752c,_0x95a747,_0x558a4b);_0x4dddc4=En(_0x41752c,_0x4dddc4,new C(_0x20e849),_0x6fb1a0,_0x3a2ec1,_0x1c9ae0,_0x55942f,_0x26103e);}}),_0x4dddc4;}function Nu(_0x28ca58,_0x196f68,_0x541fe2,_0x2a8efc,_0x4db1b0,_0x44a0c9,_0x8b98ee){if(vn(_0x4db1b0,_0x541fe2)!=null)return _0x196f68;const _0x442b68=_0x196f68['serverCache']['isFiltered'](),_0x249516=_0x196f68['serverCache'];if(_0x2a8efc['value']!=null){if(v(_0x541fe2)&&_0x249516['isFullyInitialized']()||_0x249516['isCompleteForPath'](_0x541fe2))return En(_0x28ca58,_0x196f68,_0x541fe2,_0x249516['getNode']()['getChild'](_0x541fe2),_0x4db1b0,_0x44a0c9,_0x442b68,_0x8b98ee);if(v(_0x541fe2)){let _0x5afd41=new S(null);return _0x249516['getNode']()['forEachChild'](ye,(_0x4ebad8,_0x1508d8)=>{_0x5afd41=_0x5afd41['set'](new C(_0x4ebad8),_0x1508d8);}),bi(_0x28ca58,_0x196f68,_0x541fe2,_0x5afd41,_0x4db1b0,_0x44a0c9,_0x442b68,_0x8b98ee);}else return _0x196f68;}else{let _0x3c44ea=new S(null);return _0x2a8efc['foreach']((_0x3d02a6,_0x1e6db1)=>{const _0x4e7a56=k(_0x541fe2,_0x3d02a6);_0x249516['isCompleteForPath'](_0x4e7a56)&&(_0x3c44ea=_0x3c44ea['set'](_0x3d02a6,_0x249516['getNode']()['getChild'](_0x4e7a56)));}),bi(_0x28ca58,_0x196f68,_0x541fe2,_0x3c44ea,_0x4db1b0,_0x44a0c9,_0x442b68,_0x8b98ee);}}function Pu(_0x5caf67,_0x5d06a7,_0x16a8f5,_0x3abfda,_0x30c545){const _0x2b881c=_0x5d06a7['serverCache'],_0x3efd43=Uo(_0x5d06a7,_0x2b881c['getNode'](),_0x2b881c['isFullyInitialized']()||v(_0x16a8f5),_0x2b881c['isFiltered']());return qo(_0x5caf67,_0x3efd43,_0x16a8f5,_0x3abfda,Go,_0x30c545);}function Ou(_0x4e49ff,_0x401486,_0x580871,_0x2b96b9,_0x5e489c,_0x386408){let _0x484200;if(vn(_0x2b96b9,_0x580871)!=null)return _0x401486;{const _0xef7f12=new ss(_0x2b96b9,_0x401486,_0x5e489c),_0x41a781=_0x401486['eventCache']['getNode']();let _0x5c7582;if(v(_0x580871)||y(_0x580871)==='.priority'){let _0x3811d2;if(_0x401486['serverCache']['isFullyInitialized']())_0x3811d2=yn(_0x2b96b9,We(_0x401486));else{const _0x1024e8=_0x401486['serverCache']['getNode']();f(_0x1024e8 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x3811d2=ns(_0x2b96b9,_0x1024e8);}_0x3811d2=_0x3811d2,_0x5c7582=_0x4e49ff['filter']['updateFullNode'](_0x41a781,_0x3811d2,_0x386408);}else{const _0x27824a=y(_0x580871);let _0x587817=is(_0x2b96b9,_0x27824a,_0x401486['serverCache']);_0x587817==null&&_0x401486['serverCache']['isCompleteForChild'](_0x27824a)&&(_0x587817=_0x41a781['getImmediateChild'](_0x27824a)),_0x587817!=null?_0x5c7582=_0x4e49ff['filter']['updateChild'](_0x41a781,_0x27824a,_0x587817,b(_0x580871),_0xef7f12,_0x386408):_0x401486['eventCache']['getNode']()['hasChild'](_0x27824a)?_0x5c7582=_0x4e49ff['filter']['updateChild'](_0x41a781,_0x27824a,g['EMPTY_NODE'],b(_0x580871),_0xef7f12,_0x386408):_0x5c7582=_0x41a781,_0x5c7582['isEmpty']()&&_0x401486['serverCache']['isFullyInitialized']()&&(_0x484200=yn(_0x2b96b9,We(_0x401486)),_0x484200['isLeafNode']()&&(_0x5c7582=_0x4e49ff['filter']['updateFullNode'](_0x5c7582,_0x484200,_0x386408)));}return _0x484200=_0x401486['serverCache']['isFullyInitialized']()||vn(_0x2b96b9,w())!=null,Tt(_0x401486,_0x5c7582,_0x484200,_0x4e49ff['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x737e97,_0x1540a0){this['query_']=_0x737e97,this['eventRegistrations_']=[];const _0x484d76=this['query_']['_queryParams'],_0x4664e6=new Ji(_0x484d76['getIndex']()),_0x241f77=Kh(_0x484d76);this['processor_']=Su(_0x241f77);const _0x5e2f32=_0x1540a0['serverCache'],_0x1a4c65=_0x1540a0['eventCache'],_0x5afed9=_0x4664e6['updateFullNode'](g['EMPTY_NODE'],_0x5e2f32['getNode'](),null),_0x23ced2=_0x241f77['updateFullNode'](g['EMPTY_NODE'],_0x1a4c65['getNode'](),null),_0x52d599=new Ce(_0x5afed9,_0x5e2f32['isFullyInitialized'](),_0x4664e6['filtersNodes']()),_0x36642c=new Ce(_0x23ced2,_0x1a4c65['isFullyInitialized'](),_0x241f77['filtersNodes']());this['viewCache_']=Mn(_0x36642c,_0x52d599),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x3d5935){return _0x3d5935['viewCache_']['serverCache']['getNode']();}function Lu(_0x3dacfe){return mn(_0x3dacfe['viewCache_']);}function xu(_0x4a7178,_0x5e9ea5){const _0x5ea184=We(_0x4a7178['viewCache_']);return _0x5ea184&&(_0x4a7178['query']['_queryParams']['loadsAllData']()||!v(_0x5e9ea5)&&!_0x5ea184['getImmediateChild'](y(_0x5e9ea5))['isEmpty']())?_0x5ea184['getChild'](_0x5e9ea5):null;}function dr(_0x20497b){return _0x20497b['eventRegistrations_']['length']===0x0;}function Fu(_0x5e29ea,_0xbd38fd){_0x5e29ea['eventRegistrations_']['push'](_0xbd38fd);}function fr(_0x22e13d,_0x98ae09,_0x39649c){const _0x33fadb=[];if(_0x39649c){f(_0x98ae09==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x1b5dbb=_0x22e13d['query']['_path'];_0x22e13d['eventRegistrations_']['forEach'](_0x493f9f=>{const _0x2f7f63=_0x493f9f['createCancelEvent'](_0x39649c,_0x1b5dbb);_0x2f7f63&&_0x33fadb['push'](_0x2f7f63);});}if(_0x98ae09){let _0x3d660d=[];for(let _0x1adbc9=0x0;_0x1adbc9<_0x22e13d['eventRegistrations_']['length'];++_0x1adbc9){const _0x4682eb=_0x22e13d['eventRegistrations_'][_0x1adbc9];if(!_0x4682eb['matches'](_0x98ae09))_0x3d660d['push'](_0x4682eb);else{if(_0x98ae09['hasAnyCallback']()){_0x3d660d=_0x3d660d['concat'](_0x22e13d['eventRegistrations_']['slice'](_0x1adbc9+0x1));break;}}}_0x22e13d['eventRegistrations_']=_0x3d660d;}else _0x22e13d['eventRegistrations_']=[];return _0x33fadb;}function pr(_0x4382ba,_0x2d0c39,_0xea8431,_0x4ff47a){_0x2d0c39['type']===j['MERGE']&&_0x2d0c39['source']['queryId']!==null&&(f(We(_0x4382ba['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x4382ba['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x46bd82=_0x4382ba['viewCache_'],_0x4b5a75=Ru(_0x4382ba['processor_'],_0x46bd82,_0x2d0c39,_0xea8431,_0x4ff47a);return bu(_0x4382ba['processor_'],_0x4b5a75['viewCache']),f(_0x4b5a75['viewCache']['serverCache']['isFullyInitialized']()||!_0x46bd82['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x4382ba['viewCache_']=_0x4b5a75['viewCache'],zo(_0x4382ba,_0x4b5a75['changes'],_0x4b5a75['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x2125f8,_0x229f63){const _0x7f3fa3=_0x2125f8['viewCache_']['eventCache'],_0x475f33=[];return _0x7f3fa3['getNode']()['isLeafNode']()||_0x7f3fa3['getNode']()['forEachChild'](R,(_0x4631c6,_0x50820f)=>{_0x475f33['push'](et(_0x4631c6,_0x50820f));}),_0x7f3fa3['isFullyInitialized']()&&_0x475f33['push'](Lo(_0x7f3fa3['getNode']())),zo(_0x2125f8,_0x475f33,_0x7f3fa3['getNode'](),_0x229f63);}function zo(_0x507428,_0x3eb34a,_0x37dd3f,_0xf74246){const _0x1e7e4f=_0xf74246?[_0xf74246]:_0x507428['eventRegistrations_'];return ru(_0x507428['eventGenerator_'],_0x3eb34a,_0x37dd3f,_0x1e7e4f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x417b4a){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x417b4a;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x1bbc40){return _0x1bbc40['views']['size']===0x0;}function rs(_0x250820,_0x4b7794,_0x3415eb,_0x4caef5){const _0x35a83b=_0x4b7794['source']['queryId'];if(_0x35a83b!==null){const _0x106cda=_0x250820['views']['get'](_0x35a83b);return f(_0x106cda!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x106cda,_0x4b7794,_0x3415eb,_0x4caef5);}else{let _0x233fbb=[];for(const _0x44f2fb of _0x250820['views']['values']())_0x233fbb=_0x233fbb['concat'](pr(_0x44f2fb,_0x4b7794,_0x3415eb,_0x4caef5));return _0x233fbb;}}function Ko(_0x70fda5,_0x339b19,_0x1e090d,_0x4f31ec,_0x282263){const _0x1ac716=_0x339b19['_queryIdentifier'],_0xe8d6a2=_0x70fda5['views']['get'](_0x1ac716);if(!_0xe8d6a2){let _0x5cac7d=yn(_0x1e090d,_0x282263?_0x4f31ec:null),_0x8e578a=!0x1;_0x5cac7d?_0x8e578a=!0x0:_0x4f31ec instanceof g?(_0x5cac7d=ns(_0x1e090d,_0x4f31ec),_0x8e578a=!0x1):(_0x5cac7d=g['EMPTY_NODE'],_0x8e578a=!0x1);const _0x58f302=Mn(new Ce(_0x5cac7d,_0x8e578a,!0x1),new Ce(_0x4f31ec,_0x282263,!0x1));return new Du(_0x339b19,_0x58f302);}return _0xe8d6a2;}function Hu(_0x64569a,_0x50fd6d,_0x5e0e9a,_0xfeb3d7,_0x5d9554,_0x12184a){const _0x35117e=Ko(_0x64569a,_0x50fd6d,_0xfeb3d7,_0x5d9554,_0x12184a);return _0x64569a['views']['has'](_0x50fd6d['_queryIdentifier'])||_0x64569a['views']['set'](_0x50fd6d['_queryIdentifier'],_0x35117e),Fu(_0x35117e,_0x5e0e9a),Uu(_0x35117e,_0x5e0e9a);}function $u(_0x4c9290,_0x20667b,_0x18aa92,_0x547270){const _0x4229eb=_0x20667b['_queryIdentifier'],_0x17df1a=[];let _0x46e371=[];const _0x32f98e=Te(_0x4c9290);if(_0x4229eb==='default'){for(const [_0x17352e,_0x555d58]of _0x4c9290['views']['entries']())_0x46e371=_0x46e371['concat'](fr(_0x555d58,_0x18aa92,_0x547270)),dr(_0x555d58)&&(_0x4c9290['views']['delete'](_0x17352e),_0x555d58['query']['_queryParams']['loadsAllData']()||_0x17df1a['push'](_0x555d58['query']));}else{const _0x5574d4=_0x4c9290['views']['get'](_0x4229eb);_0x5574d4&&(_0x46e371=_0x46e371['concat'](fr(_0x5574d4,_0x18aa92,_0x547270)),dr(_0x5574d4)&&(_0x4c9290['views']['delete'](_0x4229eb),_0x5574d4['query']['_queryParams']['loadsAllData']()||_0x17df1a['push'](_0x5574d4['query'])));}return _0x32f98e&&!Te(_0x4c9290)&&_0x17df1a['push'](new(Bu())(_0x20667b['_repo'],_0x20667b['_path'])),{'removed':_0x17df1a,'events':_0x46e371};}function Yo(_0x5eb045){const _0x1ccd0c=[];for(const _0x5e3f3e of _0x5eb045['views']['values']())_0x5e3f3e['query']['_queryParams']['loadsAllData']()||_0x1ccd0c['push'](_0x5e3f3e);return _0x1ccd0c;}function Ee(_0x5d5201,_0x5c2d54){let _0x26c63b=null;for(const _0x284f28 of _0x5d5201['views']['values']())_0x26c63b=_0x26c63b||xu(_0x284f28,_0x5c2d54);return _0x26c63b;}function Qo(_0x130ef3,_0x2e5c18){if(_0x2e5c18['_queryParams']['loadsAllData']())return xn(_0x130ef3);{const _0x155ff7=_0x2e5c18['_queryIdentifier'];return _0x130ef3['views']['get'](_0x155ff7);}}function Jo(_0x30b5d6,_0x1d15f9){return Qo(_0x30b5d6,_0x1d15f9)!=null;}function Te(_0x3ba977){return xn(_0x3ba977)!=null;}function xn(_0x5b9b26){for(const _0x1838cd of _0x5b9b26['views']['values']())if(_0x1838cd['query']['_queryParams']['loadsAllData']())return _0x1838cd;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x48a0a2){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x48a0a2;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x351602){this['listenProvider_']=_0x351602,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0xa1c426,_0x165976,_0x2c6e5a,_0x559d48,_0x5b1747){return lu(_0xa1c426['pendingWriteTree_'],_0x165976,_0x2c6e5a,_0x559d48,_0x5b1747),_0x5b1747?ut(_0xa1c426,new Ue(Zi(),_0x165976,_0x2c6e5a)):[];}function ju(_0x4b853e,_0xaab96f,_0x3a508f,_0x4d0337){hu(_0x4b853e['pendingWriteTree_'],_0xaab96f,_0x3a508f,_0x4d0337);const _0x5a0954=S['fromObject'](_0x3a508f);return ut(_0x4b853e,new tt(Zi(),_0xaab96f,_0x5a0954));}function pe(_0x1c79a5,_0x532445,_0x5436d6=!0x1){const _0x3f84b0=uu(_0x1c79a5['pendingWriteTree_'],_0x532445);if(du(_0x1c79a5['pendingWriteTree_'],_0x532445)){let _0x1ee2ff=new S(null);return _0x3f84b0['snap']!=null?_0x1ee2ff=_0x1ee2ff['set'](w(),!0x0):x(_0x3f84b0['children'],_0x54ac52=>{_0x1ee2ff=_0x1ee2ff['set'](new C(_0x54ac52),!0x0);}),ut(_0x1c79a5,new gn(_0x3f84b0['path'],_0x1ee2ff,_0x5436d6));}else return[];}function Gt(_0x394934,_0xeac04,_0x27e75f){return ut(_0x394934,new Ue(es(),_0xeac04,_0x27e75f));}function Ku(_0x24cd05,_0x6887b0,_0x1db885){const _0x3f6a55=S['fromObject'](_0x1db885);return ut(_0x24cd05,new tt(es(),_0x6887b0,_0x3f6a55));}function Yu(_0x23c125,_0xe73945){return ut(_0x23c125,new Lt(es(),_0xe73945));}function Qu(_0x12ce9e,_0x19bc47,_0x27323e){const _0x37f680=as(_0x12ce9e,_0x27323e);if(_0x37f680){const _0x2a8c51=cs(_0x37f680),_0x6959d=_0x2a8c51['path'],_0x4c90e5=_0x2a8c51['queryId'],_0x111cf8=F(_0x6959d,_0x19bc47),_0x1b23bc=new Lt(ts(_0x4c90e5),_0x111cf8);return ls(_0x12ce9e,_0x6959d,_0x1b23bc);}else return[];}function Cn(_0x316d11,_0x2014ab,_0x9f6a48,_0x703cee,_0x443304=!0x1){const _0x2007c7=_0x2014ab['_path'],_0x3ff44b=_0x316d11['syncPointTree_']['get'](_0x2007c7);let _0x18643e=[];if(_0x3ff44b&&(_0x2014ab['_queryIdentifier']==='default'||Jo(_0x3ff44b,_0x2014ab))){const _0xa2cffa=$u(_0x3ff44b,_0x2014ab,_0x9f6a48,_0x703cee);Vu(_0x3ff44b)&&(_0x316d11['syncPointTree_']=_0x316d11['syncPointTree_']['remove'](_0x2007c7));const _0xdb53b0=_0xa2cffa['removed'];if(_0x18643e=_0xa2cffa['events'],!_0x443304){const _0x48ad79=_0xdb53b0['findIndex'](_0x3e8c13=>_0x3e8c13['_queryParams']['loadsAllData']())!==-0x1,_0x5c5f8c=_0x316d11['syncPointTree_']['findOnPath'](_0x2007c7,(_0xe81c8d,_0x40bf0e)=>Te(_0x40bf0e));if(_0x48ad79&&!_0x5c5f8c){const _0x1f6f00=_0x316d11['syncPointTree_']['subtree'](_0x2007c7);if(!_0x1f6f00['isEmpty']()){const _0x57db4f=Zu(_0x1f6f00);for(let _0x175520=0x0;_0x175520<_0x57db4f['length'];++_0x175520){const _0x56e0a9=_0x57db4f[_0x175520],_0x522d3d=_0x56e0a9['query'],_0x2222cf=ta(_0x316d11,_0x56e0a9);_0x316d11['listenProvider_']['startListening'](bt(_0x522d3d),xt(_0x316d11,_0x522d3d),_0x2222cf['hashFn'],_0x2222cf['onComplete']);}}}!_0x5c5f8c&&_0xdb53b0['length']>0x0&&!_0x703cee&&(_0x48ad79?_0x316d11['listenProvider_']['stopListening'](bt(_0x2014ab),null):_0xdb53b0['forEach'](_0x4aaa84=>{const _0x506449=_0x316d11['queryToTagMap']['get'](Un(_0x4aaa84));_0x316d11['listenProvider_']['stopListening'](bt(_0x4aaa84),_0x506449);}));}ed(_0x316d11,_0xdb53b0);}return _0x18643e;}function Xo(_0x36d8c3,_0x4c2181,_0x1c3417,_0x33436a){const _0x1cd6cd=as(_0x36d8c3,_0x33436a);if(_0x1cd6cd!=null){const _0x5b8455=cs(_0x1cd6cd),_0x50eb09=_0x5b8455['path'],_0x1a087a=_0x5b8455['queryId'],_0x1edca0=F(_0x50eb09,_0x4c2181),_0x5594ec=new Ue(ts(_0x1a087a),_0x1edca0,_0x1c3417);return ls(_0x36d8c3,_0x50eb09,_0x5594ec);}else return[];}function Ju(_0x116a57,_0x3aba25,_0x29d9c5,_0x2407e5){const _0x169c73=as(_0x116a57,_0x2407e5);if(_0x169c73){const _0x123238=cs(_0x169c73),_0x1c3da7=_0x123238['path'],_0x2279db=_0x123238['queryId'],_0x2df9a7=F(_0x1c3da7,_0x3aba25),_0x5eb652=S['fromObject'](_0x29d9c5),_0x3ba9e5=new tt(ts(_0x2279db),_0x2df9a7,_0x5eb652);return ls(_0x116a57,_0x1c3da7,_0x3ba9e5);}else return[];}function Ri(_0x18e14d,_0x43cab4,_0x156e3d,_0x590a36=!0x1){const _0x499f26=_0x43cab4['_path'];let _0x504b1d=null,_0x50b681=!0x1;_0x18e14d['syncPointTree_']['foreachOnPath'](_0x499f26,(_0x1e7533,_0x53c8fa)=>{const _0x30f323=F(_0x1e7533,_0x499f26);_0x504b1d=_0x504b1d||Ee(_0x53c8fa,_0x30f323),_0x50b681=_0x50b681||Te(_0x53c8fa);});let _0x2c63d1=_0x18e14d['syncPointTree_']['get'](_0x499f26);_0x2c63d1?(_0x50b681=_0x50b681||Te(_0x2c63d1),_0x504b1d=_0x504b1d||Ee(_0x2c63d1,w())):(_0x2c63d1=new jo(),_0x18e14d['syncPointTree_']=_0x18e14d['syncPointTree_']['set'](_0x499f26,_0x2c63d1));let _0x1422b;_0x504b1d!=null?_0x1422b=!0x0:(_0x1422b=!0x1,_0x504b1d=g['EMPTY_NODE'],_0x18e14d['syncPointTree_']['subtree'](_0x499f26)['foreachChild']((_0x5bf870,_0x284968)=>{const _0x20c089=Ee(_0x284968,w());_0x20c089&&(_0x504b1d=_0x504b1d['updateImmediateChild'](_0x5bf870,_0x20c089));}));const _0x5b4c76=Jo(_0x2c63d1,_0x43cab4);if(!_0x5b4c76&&!_0x43cab4['_queryParams']['loadsAllData']()){const _0x8dcb55=Un(_0x43cab4);f(!_0x18e14d['queryToTagMap']['has'](_0x8dcb55),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x2a68fa=td();_0x18e14d['queryToTagMap']['set'](_0x8dcb55,_0x2a68fa),_0x18e14d['tagToQueryMap']['set'](_0x2a68fa,_0x8dcb55);}const _0x8cd882=Ln(_0x18e14d['pendingWriteTree_'],_0x499f26);let _0x3390f1=Hu(_0x2c63d1,_0x43cab4,_0x156e3d,_0x8cd882,_0x504b1d,_0x1422b);if(!_0x5b4c76&&!_0x50b681&&!_0x590a36){const _0x167d6c=Qo(_0x2c63d1,_0x43cab4);_0x3390f1=_0x3390f1['concat'](nd(_0x18e14d,_0x43cab4,_0x167d6c));}return _0x3390f1;}function Fn(_0x5ba532,_0x175d09,_0x5bd705){const _0xb75b6=_0x5ba532['pendingWriteTree_'],_0x38c6a7=_0x5ba532['syncPointTree_']['findOnPath'](_0x175d09,(_0x27c69b,_0x252773)=>{const _0x77d756=F(_0x27c69b,_0x175d09),_0x41d944=Ee(_0x252773,_0x77d756);if(_0x41d944)return _0x41d944;});return Vo(_0xb75b6,_0x175d09,_0x38c6a7,_0x5bd705,!0x0);}function Xu(_0x453274,_0x49f9d6){const _0x4bd998=_0x49f9d6['_path'];let _0x1efd2c=null;_0x453274['syncPointTree_']['foreachOnPath'](_0x4bd998,(_0x16e17c,_0x1458ad)=>{const _0x3d40c0=F(_0x16e17c,_0x4bd998);_0x1efd2c=_0x1efd2c||Ee(_0x1458ad,_0x3d40c0);});let _0x93af68=_0x453274['syncPointTree_']['get'](_0x4bd998);_0x93af68?_0x1efd2c=_0x1efd2c||Ee(_0x93af68,w()):(_0x93af68=new jo(),_0x453274['syncPointTree_']=_0x453274['syncPointTree_']['set'](_0x4bd998,_0x93af68));const _0x2ba366=_0x1efd2c!=null,_0x2bf643=_0x2ba366?new Ce(_0x1efd2c,!0x0,!0x1):null,_0x15876a=Ln(_0x453274['pendingWriteTree_'],_0x49f9d6['_path']),_0xa2c8c=Ko(_0x93af68,_0x49f9d6,_0x15876a,_0x2ba366?_0x2bf643['getNode']():g['EMPTY_NODE'],_0x2ba366);return Lu(_0xa2c8c);}function ut(_0xbc625a,_0x4a70e8){return Zo(_0x4a70e8,_0xbc625a['syncPointTree_'],null,Ln(_0xbc625a['pendingWriteTree_'],w()));}function Zo(_0xe64ae1,_0x252cb7,_0x21c258,_0x5ec280){if(v(_0xe64ae1['path']))return ea(_0xe64ae1,_0x252cb7,_0x21c258,_0x5ec280);{const _0x1be2db=_0x252cb7['get'](w());_0x21c258==null&&_0x1be2db!=null&&(_0x21c258=Ee(_0x1be2db,w()));let _0x1881d4=[];const _0x5ac0d0=y(_0xe64ae1['path']),_0x3cf6f9=_0xe64ae1['operationForChild'](_0x5ac0d0),_0x305c70=_0x252cb7['children']['get'](_0x5ac0d0);if(_0x305c70&&_0x3cf6f9){const _0x565a64=_0x21c258?_0x21c258['getImmediateChild'](_0x5ac0d0):null,_0x25c110=Ho(_0x5ec280,_0x5ac0d0);_0x1881d4=_0x1881d4['concat'](Zo(_0x3cf6f9,_0x305c70,_0x565a64,_0x25c110));}return _0x1be2db&&(_0x1881d4=_0x1881d4['concat'](rs(_0x1be2db,_0xe64ae1,_0x5ec280,_0x21c258))),_0x1881d4;}}function ea(_0x7b6344,_0x36922c,_0x2516ba,_0xcfedfb){const _0x58d96f=_0x36922c['get'](w());_0x2516ba==null&&_0x58d96f!=null&&(_0x2516ba=Ee(_0x58d96f,w()));let _0x2f8eee=[];return _0x36922c['children']['inorderTraversal']((_0x221dd7,_0x1956f3)=>{const _0x3a9c4b=_0x2516ba?_0x2516ba['getImmediateChild'](_0x221dd7):null,_0x47b366=Ho(_0xcfedfb,_0x221dd7),_0x3c7f8c=_0x7b6344['operationForChild'](_0x221dd7);_0x3c7f8c&&(_0x2f8eee=_0x2f8eee['concat'](ea(_0x3c7f8c,_0x1956f3,_0x3a9c4b,_0x47b366)));}),_0x58d96f&&(_0x2f8eee=_0x2f8eee['concat'](rs(_0x58d96f,_0x7b6344,_0xcfedfb,_0x2516ba))),_0x2f8eee;}function ta(_0x5bb95a,_0x286ee6){const _0x5ebe4c=_0x286ee6['query'],_0x45d1a1=xt(_0x5bb95a,_0x5ebe4c);return{'hashFn':()=>(Mu(_0x286ee6)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x136e2b=>{if(_0x136e2b==='ok')return _0x45d1a1?Qu(_0x5bb95a,_0x5ebe4c['_path'],_0x45d1a1):Yu(_0x5bb95a,_0x5ebe4c['_path']);{const _0x3ad941=Kl(_0x136e2b,_0x5ebe4c);return Cn(_0x5bb95a,_0x5ebe4c,null,_0x3ad941);}}};}function xt(_0xa210f7,_0x1fcd63){const _0x3570f3=Un(_0x1fcd63);return _0xa210f7['queryToTagMap']['get'](_0x3570f3);}function Un(_0x4579d2){return _0x4579d2['_path']['toString']()+'$'+_0x4579d2['_queryIdentifier'];}function as(_0x136913,_0x48e6bb){return _0x136913['tagToQueryMap']['get'](_0x48e6bb);}function cs(_0x91ff3d){const _0x457e43=_0x91ff3d['indexOf']('$');return f(_0x457e43!==-0x1&&_0x457e43<_0x91ff3d['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x91ff3d['substr'](_0x457e43+0x1),'path':new C(_0x91ff3d['substr'](0x0,_0x457e43))};}function ls(_0x1f6405,_0x2b3e0f,_0xd44955){const _0x7f3127=_0x1f6405['syncPointTree_']['get'](_0x2b3e0f);f(_0x7f3127,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0xcfd735=Ln(_0x1f6405['pendingWriteTree_'],_0x2b3e0f);return rs(_0x7f3127,_0xd44955,_0xcfd735,null);}function Zu(_0x34f4a8){return _0x34f4a8['fold']((_0x2a388c,_0xcf80aa,_0x1d59d3)=>{if(_0xcf80aa&&Te(_0xcf80aa))return[xn(_0xcf80aa)];{let _0x38b7fd=[];return _0xcf80aa&&(_0x38b7fd=Yo(_0xcf80aa)),x(_0x1d59d3,(_0x247eb5,_0xfd162)=>{_0x38b7fd=_0x38b7fd['concat'](_0xfd162);}),_0x38b7fd;}});}function bt(_0x175fd6){return _0x175fd6['_queryParams']['loadsAllData']()&&!_0x175fd6['_queryParams']['isDefault']()?new(qu())(_0x175fd6['_repo'],_0x175fd6['_path']):_0x175fd6;}function ed(_0x7b7895,_0x2e6d58){for(let _0x37984f=0x0;_0x37984f<_0x2e6d58['length'];++_0x37984f){const _0x443571=_0x2e6d58[_0x37984f];if(!_0x443571['_queryParams']['loadsAllData']()){const _0x12419a=Un(_0x443571),_0x5c5073=_0x7b7895['queryToTagMap']['get'](_0x12419a);_0x7b7895['queryToTagMap']['delete'](_0x12419a),_0x7b7895['tagToQueryMap']['delete'](_0x5c5073);}}}function td(){return zu++;}function nd(_0x17cc88,_0xa9c49b,_0xacee98){const _0x4a2e77=_0xa9c49b['_path'],_0x1b7e81=xt(_0x17cc88,_0xa9c49b),_0x363900=ta(_0x17cc88,_0xacee98),_0x1addc3=_0x17cc88['listenProvider_']['startListening'](bt(_0xa9c49b),_0x1b7e81,_0x363900['hashFn'],_0x363900['onComplete']),_0x4afb5d=_0x17cc88['syncPointTree_']['subtree'](_0x4a2e77);if(_0x1b7e81)f(!Te(_0x4afb5d['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x53418c=_0x4afb5d['fold']((_0x397597,_0x1eb6a9,_0xae5ac5)=>{if(!v(_0x397597)&&_0x1eb6a9&&Te(_0x1eb6a9))return[xn(_0x1eb6a9)['query']];{let _0x11a817=[];return _0x1eb6a9&&(_0x11a817=_0x11a817['concat'](Yo(_0x1eb6a9)['map'](_0x370bfb=>_0x370bfb['query']))),x(_0xae5ac5,(_0x562ab0,_0x7efb31)=>{_0x11a817=_0x11a817['concat'](_0x7efb31);}),_0x11a817;}});for(let _0xd4830b=0x0;_0xd4830b<_0x53418c['length'];++_0xd4830b){const _0x19987c=_0x53418c[_0xd4830b];_0x17cc88['listenProvider_']['stopListening'](bt(_0x19987c),xt(_0x17cc88,_0x19987c));}}return _0x1addc3;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x47b71f){this['node_']=_0x47b71f;}['getImmediateChild'](_0x5c10e6){const _0x3faf09=this['node_']['getImmediateChild'](_0x5c10e6);return new hs(_0x3faf09);}['node'](){return this['node_'];}}class us{constructor(_0x1e089e,_0x86aae6){this['syncTree_']=_0x1e089e,this['path_']=_0x86aae6;}['getImmediateChild'](_0x54face){const _0x2d16e9=k(this['path_'],_0x54face);return new us(this['syncTree_'],_0x2d16e9);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x20faf5){return _0x20faf5=_0x20faf5||{},_0x20faf5['timestamp']=_0x20faf5['timestamp']||new Date()['getTime'](),_0x20faf5;},gr=function(_0x28e376,_0x134c0a,_0x444401){if(!_0x28e376||typeof _0x28e376!='object')return _0x28e376;if(f('.sv'in _0x28e376,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x28e376['.sv']=='string')return sd(_0x28e376['.sv'],_0x134c0a,_0x444401);if(typeof _0x28e376['.sv']=='object')return rd(_0x28e376['.sv'],_0x134c0a);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x28e376,null,0x2));},sd=function(_0x2011b8,_0x4c01d8,_0x2cd107){switch(_0x2011b8){case'timestamp':return _0x2cd107['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x2011b8);}},rd=function(_0x378eaa,_0x1a28e4,_0x126a5c){_0x378eaa['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x378eaa,null,0x2));const _0x499cd7=_0x378eaa['increment'];typeof _0x499cd7!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x499cd7);const _0x1c21e9=_0x1a28e4['node']();if(f(_0x1c21e9!==null&&typeof _0x1c21e9<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x1c21e9['isLeafNode']())return _0x499cd7;const _0x25dcb8=_0x1c21e9['getValue']();return typeof _0x25dcb8!='number'?_0x499cd7:_0x25dcb8+_0x499cd7;},na=function(_0x4d0b16,_0x3a4adc,_0xfba6bf,_0x5409db){return fs(_0x3a4adc,new us(_0xfba6bf,_0x4d0b16),_0x5409db);},ds=function(_0x2f1233,_0xd83a46,_0xbcfb4b){return fs(_0x2f1233,new hs(_0xd83a46),_0xbcfb4b);};function fs(_0x379c25,_0x5c68e8,_0xb7078){const _0x239ef5=_0x379c25['getPriority']()['val'](),_0x14a764=gr(_0x239ef5,_0x5c68e8['getImmediateChild']('.priority'),_0xb7078);let _0x32aa38;if(_0x379c25['isLeafNode']()){const _0x3a7c09=_0x379c25,_0x186596=gr(_0x3a7c09['getValue'](),_0x5c68e8,_0xb7078);return _0x186596!==_0x3a7c09['getValue']()||_0x14a764!==_0x3a7c09['getPriority']()['val']()?new D(_0x186596,P(_0x14a764)):_0x379c25;}else{const _0x20974f=_0x379c25;return _0x32aa38=_0x20974f,_0x14a764!==_0x20974f['getPriority']()['val']()&&(_0x32aa38=_0x32aa38['updatePriority'](new D(_0x14a764))),_0x20974f['forEachChild'](R,(_0x443946,_0x34038c)=>{const _0x542e6e=fs(_0x34038c,_0x5c68e8['getImmediateChild'](_0x443946),_0xb7078);_0x542e6e!==_0x34038c&&(_0x32aa38=_0x32aa38['updateImmediateChild'](_0x443946,_0x542e6e));}),_0x32aa38;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x549c81='',_0x2d7794=null,_0x39700b={'children':{},'childCount':0x0}){this['name']=_0x549c81,this['parent']=_0x2d7794,this['node']=_0x39700b;}}function Wn(_0x2ed1cf,_0x1b9a8a){let _0x1bac64=_0x1b9a8a instanceof C?_0x1b9a8a:new C(_0x1b9a8a),_0x594121=_0x2ed1cf,_0x326d9d=y(_0x1bac64);for(;_0x326d9d!==null;){const _0x153e84=De(_0x594121['node']['children'],_0x326d9d)||{'children':{},'childCount':0x0};_0x594121=new ps(_0x326d9d,_0x594121,_0x153e84),_0x1bac64=b(_0x1bac64),_0x326d9d=y(_0x1bac64);}return _0x594121;}function Ge(_0x5e28b5){return _0x5e28b5['node']['value'];}function _s(_0x327c93,_0x3f8ca5){_0x327c93['node']['value']=_0x3f8ca5,Ai(_0x327c93);}function ia(_0x318564){return _0x318564['node']['childCount']>0x0;}function od(_0x18f553){return Ge(_0x18f553)===void 0x0&&!ia(_0x18f553);}function Bn(_0x4f7ebe,_0x2ca62c){x(_0x4f7ebe['node']['children'],(_0x374a78,_0xf32d50)=>{_0x2ca62c(new ps(_0x374a78,_0x4f7ebe,_0xf32d50));});}function sa(_0x5cc905,_0x18639f,_0x319df5,_0xd60d89){_0x319df5&&_0x18639f(_0x5cc905),Bn(_0x5cc905,_0xbac3c5=>{sa(_0xbac3c5,_0x18639f,!0x0);});}function ad(_0xcee89,_0x3ed5cb,_0x3c4b02){let _0x5932f1=_0xcee89['parent'];for(;_0x5932f1!==null;){if(_0x3ed5cb(_0x5932f1))return!0x0;_0x5932f1=_0x5932f1['parent'];}return!0x1;}function qt(_0x15f767){return new C(_0x15f767['parent']===null?_0x15f767['name']:qt(_0x15f767['parent'])+'/'+_0x15f767['name']);}function Ai(_0x4ca274){_0x4ca274['parent']!==null&&cd(_0x4ca274['parent'],_0x4ca274['name'],_0x4ca274);}function cd(_0x56818a,_0x1f1037,_0x815cc0){const _0x45b914=od(_0x815cc0),_0x3334b3=J(_0x56818a['node']['children'],_0x1f1037);_0x45b914&&_0x3334b3?(delete _0x56818a['node']['children'][_0x1f1037],_0x56818a['node']['childCount']--,Ai(_0x56818a)):!_0x45b914&&!_0x3334b3&&(_0x56818a['node']['children'][_0x1f1037]=_0x815cc0['node'],_0x56818a['node']['childCount']++,Ai(_0x56818a));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x20cd20){return typeof _0x20cd20=='string'&&_0x20cd20['length']!==0x0&&!ld['test'](_0x20cd20);},ra=function(_0x332c76){return typeof _0x332c76=='string'&&_0x332c76['length']!==0x0&&!hd['test'](_0x332c76);},ud=function(_0x1578bb){return _0x1578bb&&(_0x1578bb=_0x1578bb['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x1578bb);},Tn=function(_0x555b9f){return _0x555b9f===null||typeof _0x555b9f=='string'||typeof _0x555b9f=='number'&&!Vi(_0x555b9f)||_0x555b9f&&typeof _0x555b9f=='object'&&J(_0x555b9f,'.sv');},zt=function(_0x5db309,_0x37e1be,_0x24c849,_0x31ff26){_0x31ff26&&_0x37e1be===void 0x0||jt(Pn(_0x5db309,'value'),_0x37e1be,_0x24c849);},jt=function(_0x170289,_0x26f026,_0xb71ea2){const _0xa01da9=_0xb71ea2 instanceof C?new Ah(_0xb71ea2,_0x170289):_0xb71ea2;if(_0x26f026===void 0x0)throw new Error(_0x170289+'contains\x20undefined\x20'+Pe(_0xa01da9));if(typeof _0x26f026=='function')throw new Error(_0x170289+'contains\x20a\x20function\x20'+Pe(_0xa01da9)+'\x20with\x20contents\x20=\x20'+_0x26f026['toString']());if(Vi(_0x26f026))throw new Error(_0x170289+'contains\x20'+_0x26f026['toString']()+'\x20'+Pe(_0xa01da9));if(typeof _0x26f026=='string'&&_0x26f026['length']>ai/0x3&&On(_0x26f026)>ai)throw new Error(_0x170289+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0xa01da9)+'\x20(\x27'+_0x26f026['substring'](0x0,0x32)+'...\x27)');if(_0x26f026&&typeof _0x26f026=='object'){let _0x414622=!0x1,_0x4665a8=!0x1;if(x(_0x26f026,(_0x4ac894,_0x39cc66)=>{if(_0x4ac894==='.value')_0x414622=!0x0;else{if(_0x4ac894!=='.priority'&&_0x4ac894!=='.sv'&&(_0x4665a8=!0x0,!gs(_0x4ac894)))throw new Error(_0x170289+'\x20contains\x20an\x20invalid\x20key\x20('+_0x4ac894+')\x20'+Pe(_0xa01da9)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0xa01da9,_0x4ac894),jt(_0x170289,_0x39cc66,_0xa01da9),Nh(_0xa01da9);}),_0x414622&&_0x4665a8)throw new Error(_0x170289+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0xa01da9)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x3646d2,_0x37bf2b){let _0x44bed8,_0x19ded2;for(_0x44bed8=0x0;_0x44bed8<_0x37bf2b['length'];_0x44bed8++){_0x19ded2=_0x37bf2b[_0x44bed8];const _0x4a42e3=Pt(_0x19ded2);for(let _0x1d4d95=0x0;_0x1d4d95<_0x4a42e3['length'];_0x1d4d95++)if(!(_0x4a42e3[_0x1d4d95]==='.priority'&&_0x1d4d95===_0x4a42e3['length']-0x1)){if(!gs(_0x4a42e3[_0x1d4d95]))throw new Error(_0x3646d2+'contains\x20an\x20invalid\x20key\x20('+_0x4a42e3[_0x1d4d95]+')\x20in\x20path\x20'+_0x19ded2['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x37bf2b['sort'](Rh);let _0x296885=null;for(_0x44bed8=0x0;_0x44bed8<_0x37bf2b['length'];_0x44bed8++){if(_0x19ded2=_0x37bf2b[_0x44bed8],_0x296885!==null&&G(_0x296885,_0x19ded2))throw new Error(_0x3646d2+'contains\x20a\x20path\x20'+_0x296885['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x19ded2['toString']());_0x296885=_0x19ded2;}},fd=function(_0x14aa46,_0x2fe243,_0x199a50,_0x298a78){const _0xc1caa7=Pn(_0x14aa46,'values');if(!(_0x2fe243&&typeof _0x2fe243=='object')||Array['isArray'](_0x2fe243))throw new Error(_0xc1caa7+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x10ea77=[];x(_0x2fe243,(_0x3d4ee7,_0x539f3c)=>{const _0x554b4c=new C(_0x3d4ee7);if(jt(_0xc1caa7,_0x539f3c,k(_0x199a50,_0x554b4c)),zi(_0x554b4c)==='.priority'&&!Tn(_0x539f3c))throw new Error(_0xc1caa7+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x554b4c['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x10ea77['push'](_0x554b4c);}),dd(_0xc1caa7,_0x10ea77);},ms=function(_0x30dc77,_0x5c75d3,_0x1c0fff,_0x4e310e){if(!ra(_0x1c0fff))throw new Error(Pn(_0x30dc77,_0x5c75d3)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x1c0fff+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x49ffbe,_0x490b8a,_0x541f5c,_0x184e57){_0x541f5c&&(_0x541f5c=_0x541f5c['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x49ffbe,_0x490b8a,_0x541f5c);},ys=function(_0x1fe447,_0x1d9d8c){if(y(_0x1d9d8c)==='.info')throw new Error(_0x1fe447+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x43a0b2,_0x48e096){const _0x1d7f5e=_0x48e096['path']['toString']();if(typeof _0x48e096['repoInfo']['host']!='string'||_0x48e096['repoInfo']['host']['length']===0x0||!gs(_0x48e096['repoInfo']['namespace'])&&_0x48e096['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x1d7f5e['length']!==0x0&&!ud(_0x1d7f5e))throw new Error(Pn(_0x43a0b2,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x4cac94,_0x3ca4d3){let _0x5bf57b=null;for(let _0x12348b=0x0;_0x12348b<_0x3ca4d3['length'];_0x12348b++){const _0x28da6f=_0x3ca4d3[_0x12348b],_0x4484ee=_0x28da6f['getPath']();_0x5bf57b!==null&&!ji(_0x4484ee,_0x5bf57b['path'])&&(_0x4cac94['eventLists_']['push'](_0x5bf57b),_0x5bf57b=null),_0x5bf57b===null&&(_0x5bf57b={'events':[],'path':_0x4484ee}),_0x5bf57b['events']['push'](_0x28da6f);}_0x5bf57b&&_0x4cac94['eventLists_']['push'](_0x5bf57b);}function oa(_0x1af002,_0x38b981,_0x14071b){Vn(_0x1af002,_0x14071b),aa(_0x1af002,_0x2d04fc=>ji(_0x2d04fc,_0x38b981));}function H(_0x2c5da5,_0x17c75f,_0x1166b5){Vn(_0x2c5da5,_0x1166b5),aa(_0x2c5da5,_0x5cd74c=>G(_0x5cd74c,_0x17c75f)||G(_0x17c75f,_0x5cd74c));}function aa(_0x55f831,_0x426136){_0x55f831['recursionDepth_']++;let _0x1cc493=!0x0;for(let _0x1dff41=0x0;_0x1dff41<_0x55f831['eventLists_']['length'];_0x1dff41++){const _0x2991b7=_0x55f831['eventLists_'][_0x1dff41];if(_0x2991b7){const _0x4b32fc=_0x2991b7['path'];_0x426136(_0x4b32fc)?(md(_0x55f831['eventLists_'][_0x1dff41]),_0x55f831['eventLists_'][_0x1dff41]=null):_0x1cc493=!0x1;}}_0x1cc493&&(_0x55f831['eventLists_']=[]),_0x55f831['recursionDepth_']--;}function md(_0x48e76d){for(let _0x32f6b9=0x0;_0x32f6b9<_0x48e76d['events']['length'];_0x32f6b9++){const _0x36655f=_0x48e76d['events'][_0x32f6b9];if(_0x36655f!==null){_0x48e76d['events'][_0x32f6b9]=null;const _0x22fdd5=_0x36655f['getEventRunner']();wt&&L('event:\x20'+_0x36655f['toString']()),ht(_0x22fdd5);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x4afd43,_0x46cf21,_0x539bf8,_0x5b1b35){this['repoInfo_']=_0x4afd43,this['forceRestClient_']=_0x46cf21,this['authTokenProvider_']=_0x539bf8,this['appCheckProvider_']=_0x5b1b35,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x180e7e,_0x4664d8,_0x2749af){if(_0x180e7e['stats_']=Gi(_0x180e7e['repoInfo_']),_0x180e7e['forceRestClient_']||Xl())_0x180e7e['server_']=new pn(_0x180e7e['repoInfo_'],(_0x4ae5ff,_0x2f7448,_0xd0287b,_0x177303)=>{mr(_0x180e7e,_0x4ae5ff,_0x2f7448,_0xd0287b,_0x177303);},_0x180e7e['authTokenProvider_'],_0x180e7e['appCheckProvider_']),setTimeout(()=>yr(_0x180e7e,!0x0),0x0);else{if(typeof _0x2749af<'u'&&_0x2749af!==null){if(typeof _0x2749af!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x2749af);}catch(_0x1f9357){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x1f9357);}}_0x180e7e['persistentConnection_']=new se(_0x180e7e['repoInfo_'],_0x4664d8,(_0x246de6,_0x210527,_0x172c22,_0x3bbf6c)=>{mr(_0x180e7e,_0x246de6,_0x210527,_0x172c22,_0x3bbf6c);},_0x56a034=>{yr(_0x180e7e,_0x56a034);},_0x1a84fd=>{Id(_0x180e7e,_0x1a84fd);},_0x180e7e['authTokenProvider_'],_0x180e7e['appCheckProvider_'],_0x2749af),_0x180e7e['server_']=_0x180e7e['persistentConnection_'];}_0x180e7e['authTokenProvider_']['addTokenChangeListener'](_0x2c3041=>{_0x180e7e['server_']['refreshAuthToken'](_0x2c3041);}),_0x180e7e['appCheckProvider_']['addTokenChangeListener'](_0x10829b=>{_0x180e7e['server_']['refreshAppCheckToken'](_0x10829b['token']);}),_0x180e7e['statsReporter_']=ih(_0x180e7e['repoInfo_'],()=>new iu(_0x180e7e['stats_'],_0x180e7e['server_'])),_0x180e7e['infoData_']=new Xh(),_0x180e7e['infoSyncTree_']=new _r({'startListening':(_0x186eeb,_0x23e002,_0x112c00,_0x1eeb93)=>{let _0x404fc1=[];const _0x417188=_0x180e7e['infoData_']['getNode'](_0x186eeb['_path']);return _0x417188['isEmpty']()||(_0x404fc1=Gt(_0x180e7e['infoSyncTree_'],_0x186eeb['_path'],_0x417188),setTimeout(()=>{_0x1eeb93('ok');},0x0)),_0x404fc1;},'stopListening':()=>{}}),vs(_0x180e7e,'connected',!0x1),_0x180e7e['serverSyncTree_']=new _r({'startListening':(_0x2894c1,_0x345f20,_0x317cec,_0x17f680)=>(_0x180e7e['server_']['listen'](_0x2894c1,_0x317cec,_0x345f20,(_0x2c494d,_0x17b6f1)=>{const _0x1a2749=_0x17f680(_0x2c494d,_0x17b6f1);H(_0x180e7e['eventQueue_'],_0x2894c1['_path'],_0x1a2749);}),[]),'stopListening':(_0x48d6c8,_0x521339)=>{_0x180e7e['server_']['unlisten'](_0x48d6c8,_0x521339);}});}function la(_0x344448){const _0x248a93=_0x344448['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x248a93;}function Kt(_0x4e7c10){return id({'timestamp':la(_0x4e7c10)});}function mr(_0x102782,_0x452eea,_0x4cd92f,_0x137185,_0x342e65){_0x102782['dataUpdateCount']++;const _0x1dca01=new C(_0x452eea);_0x4cd92f=_0x102782['interceptServerDataCallback_']?_0x102782['interceptServerDataCallback_'](_0x452eea,_0x4cd92f):_0x4cd92f;let _0x2df9ba=[];if(_0x342e65){if(_0x137185){const _0x99efb5=hn(_0x4cd92f,_0x1709e9=>P(_0x1709e9));_0x2df9ba=Ju(_0x102782['serverSyncTree_'],_0x1dca01,_0x99efb5,_0x342e65);}else{const _0x447426=P(_0x4cd92f);_0x2df9ba=Xo(_0x102782['serverSyncTree_'],_0x1dca01,_0x447426,_0x342e65);}}else{if(_0x137185){const _0x3c8dda=hn(_0x4cd92f,_0x56264c=>P(_0x56264c));_0x2df9ba=Ku(_0x102782['serverSyncTree_'],_0x1dca01,_0x3c8dda);}else{const _0x1f493e=P(_0x4cd92f);_0x2df9ba=Gt(_0x102782['serverSyncTree_'],_0x1dca01,_0x1f493e);}}let _0x7b593b=_0x1dca01;_0x2df9ba['length']>0x0&&(_0x7b593b=it(_0x102782,_0x1dca01)),H(_0x102782['eventQueue_'],_0x7b593b,_0x2df9ba);}function yr(_0x831837,_0x4ccf91){vs(_0x831837,'connected',_0x4ccf91),_0x4ccf91===!0x1&&Sd(_0x831837);}function Id(_0x2e36f5,_0x510e2b){x(_0x510e2b,(_0x2e60ab,_0x2d68c9)=>{vs(_0x2e36f5,_0x2e60ab,_0x2d68c9);});}function vs(_0x4f4d2d,_0x15134a,_0x5d5c55){const _0x1d7ce3=new C('/.info/'+_0x15134a),_0x52301c=P(_0x5d5c55);_0x4f4d2d['infoData_']['updateSnapshot'](_0x1d7ce3,_0x52301c);const _0x316975=Gt(_0x4f4d2d['infoSyncTree_'],_0x1d7ce3,_0x52301c);H(_0x4f4d2d['eventQueue_'],_0x1d7ce3,_0x316975);}function Hn(_0x410d85){return _0x410d85['nextWriteId_']++;}function wd(_0x39c5a9,_0x5a0505,_0x5bbcdf){const _0x2f726d=Xu(_0x39c5a9['serverSyncTree_'],_0x5a0505);return _0x2f726d!=null?Promise['resolve'](_0x2f726d):_0x39c5a9['server_']['get'](_0x5a0505)['then'](_0x5e4c6a=>{const _0x1e99bb=P(_0x5e4c6a)['withIndex'](_0x5a0505['_queryParams']['getIndex']());Ri(_0x39c5a9['serverSyncTree_'],_0x5a0505,_0x5bbcdf,!0x0);let _0x248ab0;if(_0x5a0505['_queryParams']['loadsAllData']())_0x248ab0=Gt(_0x39c5a9['serverSyncTree_'],_0x5a0505['_path'],_0x1e99bb);else{const _0x3b35ea=xt(_0x39c5a9['serverSyncTree_'],_0x5a0505);_0x248ab0=Xo(_0x39c5a9['serverSyncTree_'],_0x5a0505['_path'],_0x1e99bb,_0x3b35ea);}return H(_0x39c5a9['eventQueue_'],_0x5a0505['_path'],_0x248ab0),Cn(_0x39c5a9['serverSyncTree_'],_0x5a0505,_0x5bbcdf,null,!0x0),_0x1e99bb;},_0x527250=>(dt(_0x39c5a9,'get\x20for\x20query\x20'+O(_0x5a0505)+'\x20failed:\x20'+_0x527250),Promise['reject'](new Error(_0x527250))));}function Cd(_0x163dca,_0x4d6671,_0x4d07fd,_0x559047,_0x288602){dt(_0x163dca,'set',{'path':_0x4d6671['toString'](),'value':_0x4d07fd,'priority':_0x559047});const _0x22bbeb=Kt(_0x163dca),_0x41515f=P(_0x4d07fd,_0x559047),_0x469d20=Fn(_0x163dca['serverSyncTree_'],_0x4d6671),_0x2842bc=ds(_0x41515f,_0x469d20,_0x22bbeb),_0x6da9fd=Hn(_0x163dca),_0x45d83d=os(_0x163dca['serverSyncTree_'],_0x4d6671,_0x2842bc,_0x6da9fd,!0x0);Vn(_0x163dca['eventQueue_'],_0x45d83d),_0x163dca['server_']['put'](_0x4d6671['toString'](),_0x41515f['val'](!0x0),(_0x4ead9e,_0x37de22)=>{const _0x46e9d1=_0x4ead9e==='ok';_0x46e9d1||U('set\x20at\x20'+_0x4d6671+'\x20failed:\x20'+_0x4ead9e);const _0x17159b=pe(_0x163dca['serverSyncTree_'],_0x6da9fd,!_0x46e9d1);H(_0x163dca['eventQueue_'],_0x4d6671,_0x17159b),ki(_0x163dca,_0x288602,_0x4ead9e,_0x37de22);});const _0x438e73=Is(_0x163dca,_0x4d6671);it(_0x163dca,_0x438e73),H(_0x163dca['eventQueue_'],_0x438e73,[]);}function Td(_0xf4b24b,_0x466be6,_0xb2409d,_0x2e8fd5){dt(_0xf4b24b,'update',{'path':_0x466be6['toString'](),'value':_0xb2409d});let _0x3758c7=!0x0;const _0x232046=Kt(_0xf4b24b),_0x146494={};if(x(_0xb2409d,(_0x4c1841,_0x138cc6)=>{_0x3758c7=!0x1,_0x146494[_0x4c1841]=na(k(_0x466be6,_0x4c1841),P(_0x138cc6),_0xf4b24b['serverSyncTree_'],_0x232046);}),_0x3758c7)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0xf4b24b,_0x2e8fd5,'ok',void 0x0);else{const _0x506112=Hn(_0xf4b24b),_0x4b5c38=ju(_0xf4b24b['serverSyncTree_'],_0x466be6,_0x146494,_0x506112);Vn(_0xf4b24b['eventQueue_'],_0x4b5c38),_0xf4b24b['server_']['merge'](_0x466be6['toString'](),_0xb2409d,(_0x4f106e,_0x516ec4)=>{const _0x16d630=_0x4f106e==='ok';_0x16d630||U('update\x20at\x20'+_0x466be6+'\x20failed:\x20'+_0x4f106e);const _0x51b0ac=pe(_0xf4b24b['serverSyncTree_'],_0x506112,!_0x16d630),_0x2209f0=_0x51b0ac['length']>0x0?it(_0xf4b24b,_0x466be6):_0x466be6;H(_0xf4b24b['eventQueue_'],_0x2209f0,_0x51b0ac),ki(_0xf4b24b,_0x2e8fd5,_0x4f106e,_0x516ec4);}),x(_0xb2409d,_0x39a69b=>{const _0x30876e=Is(_0xf4b24b,k(_0x466be6,_0x39a69b));it(_0xf4b24b,_0x30876e);}),H(_0xf4b24b['eventQueue_'],_0x466be6,[]);}}function Sd(_0x4b4a1c){dt(_0x4b4a1c,'onDisconnectEvents');const _0xefb6f4=Kt(_0x4b4a1c),_0x78ed24=_n();Ii(_0x4b4a1c['onDisconnect_'],w(),(_0xd7490b,_0x1851f1)=>{const _0x4b347c=na(_0xd7490b,_0x1851f1,_0x4b4a1c['serverSyncTree_'],_0xefb6f4);Fo(_0x78ed24,_0xd7490b,_0x4b347c);});let _0xd603bd=[];Ii(_0x78ed24,w(),(_0x275a5d,_0x55985f)=>{_0xd603bd=_0xd603bd['concat'](Gt(_0x4b4a1c['serverSyncTree_'],_0x275a5d,_0x55985f));const _0x9d0fe2=Is(_0x4b4a1c,_0x275a5d);it(_0x4b4a1c,_0x9d0fe2);}),_0x4b4a1c['onDisconnect_']=_n(),H(_0x4b4a1c['eventQueue_'],w(),_0xd603bd);}function bd(_0x3bb7d2,_0xc8a4bf,_0x3b436e){let _0x444cfd;y(_0xc8a4bf['_path'])==='.info'?_0x444cfd=Ri(_0x3bb7d2['infoSyncTree_'],_0xc8a4bf,_0x3b436e):_0x444cfd=Ri(_0x3bb7d2['serverSyncTree_'],_0xc8a4bf,_0x3b436e),oa(_0x3bb7d2['eventQueue_'],_0xc8a4bf['_path'],_0x444cfd);}function Rd(_0x4d9c4e,_0x7de9be,_0x3b41ea){let _0x423bed;y(_0x7de9be['_path'])==='.info'?_0x423bed=Cn(_0x4d9c4e['infoSyncTree_'],_0x7de9be,_0x3b41ea):_0x423bed=Cn(_0x4d9c4e['serverSyncTree_'],_0x7de9be,_0x3b41ea),oa(_0x4d9c4e['eventQueue_'],_0x7de9be['_path'],_0x423bed);}function ha(_0x5cc3a2){_0x5cc3a2['persistentConnection_']&&_0x5cc3a2['persistentConnection_']['interrupt'](ca);}function Ad(_0xe7c15b){_0xe7c15b['persistentConnection_']&&_0xe7c15b['persistentConnection_']['resume'](ca);}function dt(_0x57e75c,..._0x3594e3){let _0x26c938='';_0x57e75c['persistentConnection_']&&(_0x26c938=_0x57e75c['persistentConnection_']['id']+':'),L(_0x26c938,..._0x3594e3);}function ki(_0x308444,_0x1e6b26,_0x3bc51b,_0x48ac56){_0x1e6b26&&ht(()=>{if(_0x3bc51b==='ok')_0x1e6b26(null);else{const _0x4c59ff=(_0x3bc51b||'error')['toUpperCase']();let _0x37e58a=_0x4c59ff;_0x48ac56&&(_0x37e58a+=':\x20'+_0x48ac56);const _0x4f007e=new Error(_0x37e58a);_0x4f007e['code']=_0x4c59ff,_0x1e6b26(_0x4f007e);}});}function kd(_0x1a889b,_0x16a851,_0x56558f,_0x8348fc,_0x42a5f3,_0x52c389){dt(_0x1a889b,'transaction\x20on\x20'+_0x16a851);const _0x425e71={'path':_0x16a851,'update':_0x56558f,'onComplete':_0x8348fc,'status':null,'order':so(),'applyLocally':_0x52c389,'retryCount':0x0,'unwatcher':_0x42a5f3,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x1805e5=Es(_0x1a889b,_0x16a851,void 0x0);_0x425e71['currentInputSnapshot']=_0x1805e5;const _0x3ae28b=_0x425e71['update'](_0x1805e5['val']());if(_0x3ae28b===void 0x0)_0x425e71['unwatcher'](),_0x425e71['currentOutputSnapshotRaw']=null,_0x425e71['currentOutputSnapshotResolved']=null,_0x425e71['onComplete']&&_0x425e71['onComplete'](null,!0x1,_0x425e71['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x3ae28b,_0x425e71['path']),_0x425e71['status']=0x0;const _0x373605=Wn(_0x1a889b['transactionQueueTree_'],_0x16a851),_0x384c1e=Ge(_0x373605)||[];_0x384c1e['push'](_0x425e71),_s(_0x373605,_0x384c1e);let _0x3f5955;typeof _0x3ae28b=='object'&&_0x3ae28b!==null&&J(_0x3ae28b,'.priority')?(_0x3f5955=De(_0x3ae28b,'.priority'),f(Tn(_0x3f5955),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x3f5955=(Fn(_0x1a889b['serverSyncTree_'],_0x16a851)||g['EMPTY_NODE'])['getPriority']()['val']();const _0xf3070f=Kt(_0x1a889b),_0x2ff37e=P(_0x3ae28b,_0x3f5955),_0x3e469e=ds(_0x2ff37e,_0x1805e5,_0xf3070f);_0x425e71['currentOutputSnapshotRaw']=_0x2ff37e,_0x425e71['currentOutputSnapshotResolved']=_0x3e469e,_0x425e71['currentWriteId']=Hn(_0x1a889b);const _0x21f3ce=os(_0x1a889b['serverSyncTree_'],_0x16a851,_0x3e469e,_0x425e71['currentWriteId'],_0x425e71['applyLocally']);H(_0x1a889b['eventQueue_'],_0x16a851,_0x21f3ce),$n(_0x1a889b,_0x1a889b['transactionQueueTree_']);}}function Es(_0x236023,_0x72ecd4,_0xc8f031){return Fn(_0x236023['serverSyncTree_'],_0x72ecd4,_0xc8f031)||g['EMPTY_NODE'];}function $n(_0x3a9a5f,_0x26f155=_0x3a9a5f['transactionQueueTree_']){if(_0x26f155||Gn(_0x3a9a5f,_0x26f155),Ge(_0x26f155)){const _0xe8870d=da(_0x3a9a5f,_0x26f155);f(_0xe8870d['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0xe8870d['every'](_0x388bb9=>_0x388bb9['status']===0x0)&&Nd(_0x3a9a5f,qt(_0x26f155),_0xe8870d);}else ia(_0x26f155)&&Bn(_0x26f155,_0x27c793=>{$n(_0x3a9a5f,_0x27c793);});}function Nd(_0x489349,_0x2ce55d,_0x5370f6){const _0x2915f0=_0x5370f6['map'](_0x5b28f3=>_0x5b28f3['currentWriteId']),_0x1b03e9=Es(_0x489349,_0x2ce55d,_0x2915f0);let _0x2e69b1=_0x1b03e9;const _0x539e6e=_0x1b03e9['hash']();for(let _0x599045=0x0;_0x599045<_0x5370f6['length'];_0x599045++){const _0x426860=_0x5370f6[_0x599045];f(_0x426860['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x426860['status']=0x1,_0x426860['retryCount']++;const _0x1918cf=F(_0x2ce55d,_0x426860['path']);_0x2e69b1=_0x2e69b1['updateChild'](_0x1918cf,_0x426860['currentOutputSnapshotRaw']);}const _0xfe8b27=_0x2e69b1['val'](!0x0),_0x1438bc=_0x2ce55d;_0x489349['server_']['put'](_0x1438bc['toString'](),_0xfe8b27,_0x207cf1=>{dt(_0x489349,'transaction\x20put\x20response',{'path':_0x1438bc['toString'](),'status':_0x207cf1});let _0xe81c2=[];if(_0x207cf1==='ok'){const _0x5dfaa0=[];for(let _0x1a3f8b=0x0;_0x1a3f8b<_0x5370f6['length'];_0x1a3f8b++)_0x5370f6[_0x1a3f8b]['status']=0x2,_0xe81c2=_0xe81c2['concat'](pe(_0x489349['serverSyncTree_'],_0x5370f6[_0x1a3f8b]['currentWriteId'])),_0x5370f6[_0x1a3f8b]['onComplete']&&_0x5dfaa0['push'](()=>_0x5370f6[_0x1a3f8b]['onComplete'](null,!0x0,_0x5370f6[_0x1a3f8b]['currentOutputSnapshotResolved'])),_0x5370f6[_0x1a3f8b]['unwatcher']();Gn(_0x489349,Wn(_0x489349['transactionQueueTree_'],_0x2ce55d)),$n(_0x489349,_0x489349['transactionQueueTree_']),H(_0x489349['eventQueue_'],_0x2ce55d,_0xe81c2);for(let _0x1db927=0x0;_0x1db927<_0x5dfaa0['length'];_0x1db927++)ht(_0x5dfaa0[_0x1db927]);}else{if(_0x207cf1==='datastale'){for(let _0x426884=0x0;_0x426884<_0x5370f6['length'];_0x426884++)_0x5370f6[_0x426884]['status']===0x3?_0x5370f6[_0x426884]['status']=0x4:_0x5370f6[_0x426884]['status']=0x0;}else{U('transaction\x20at\x20'+_0x1438bc['toString']()+'\x20failed:\x20'+_0x207cf1);for(let _0x1acaef=0x0;_0x1acaef<_0x5370f6['length'];_0x1acaef++)_0x5370f6[_0x1acaef]['status']=0x4,_0x5370f6[_0x1acaef]['abortReason']=_0x207cf1;}it(_0x489349,_0x2ce55d);}},_0x539e6e);}function it(_0x46a202,_0x477d58){const _0x3086ed=ua(_0x46a202,_0x477d58),_0x592bdf=qt(_0x3086ed),_0x505e33=da(_0x46a202,_0x3086ed);return Pd(_0x46a202,_0x505e33,_0x592bdf),_0x592bdf;}function Pd(_0x16f879,_0x3ba603,_0x44c27c){if(_0x3ba603['length']===0x0)return;const _0x5c662d=[];let _0x1c0f03=[];const _0x355df6=_0x3ba603['filter'](_0x1b4968=>_0x1b4968['status']===0x0)['map'](_0x35d31a=>_0x35d31a['currentWriteId']);for(let _0x30f682=0x0;_0x30f682<_0x3ba603['length'];_0x30f682++){const _0x489bd3=_0x3ba603[_0x30f682],_0xbd2776=F(_0x44c27c,_0x489bd3['path']);let _0xeb350b=!0x1,_0x463373;if(f(_0xbd2776!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x489bd3['status']===0x4)_0xeb350b=!0x0,_0x463373=_0x489bd3['abortReason'],_0x1c0f03=_0x1c0f03['concat'](pe(_0x16f879['serverSyncTree_'],_0x489bd3['currentWriteId'],!0x0));else{if(_0x489bd3['status']===0x0){if(_0x489bd3['retryCount']>=yd)_0xeb350b=!0x0,_0x463373='maxretry',_0x1c0f03=_0x1c0f03['concat'](pe(_0x16f879['serverSyncTree_'],_0x489bd3['currentWriteId'],!0x0));else{const _0x75e780=Es(_0x16f879,_0x489bd3['path'],_0x355df6);_0x489bd3['currentInputSnapshot']=_0x75e780;const _0x374a5c=_0x3ba603[_0x30f682]['update'](_0x75e780['val']());if(_0x374a5c!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x374a5c,_0x489bd3['path']);let _0x415dc3=P(_0x374a5c);typeof _0x374a5c=='object'&&_0x374a5c!=null&&J(_0x374a5c,'.priority')||(_0x415dc3=_0x415dc3['updatePriority'](_0x75e780['getPriority']()));const _0x1d59ac=_0x489bd3['currentWriteId'],_0x21bad0=Kt(_0x16f879),_0x1e3783=ds(_0x415dc3,_0x75e780,_0x21bad0);_0x489bd3['currentOutputSnapshotRaw']=_0x415dc3,_0x489bd3['currentOutputSnapshotResolved']=_0x1e3783,_0x489bd3['currentWriteId']=Hn(_0x16f879),_0x355df6['splice'](_0x355df6['indexOf'](_0x1d59ac),0x1),_0x1c0f03=_0x1c0f03['concat'](os(_0x16f879['serverSyncTree_'],_0x489bd3['path'],_0x1e3783,_0x489bd3['currentWriteId'],_0x489bd3['applyLocally'])),_0x1c0f03=_0x1c0f03['concat'](pe(_0x16f879['serverSyncTree_'],_0x1d59ac,!0x0));}else _0xeb350b=!0x0,_0x463373='nodata',_0x1c0f03=_0x1c0f03['concat'](pe(_0x16f879['serverSyncTree_'],_0x489bd3['currentWriteId'],!0x0));}}}H(_0x16f879['eventQueue_'],_0x44c27c,_0x1c0f03),_0x1c0f03=[],_0xeb350b&&(_0x3ba603[_0x30f682]['status']=0x2,function(_0x855a38){setTimeout(_0x855a38,Math['floor'](0x0));}(_0x3ba603[_0x30f682]['unwatcher']),_0x3ba603[_0x30f682]['onComplete']&&(_0x463373==='nodata'?_0x5c662d['push'](()=>_0x3ba603[_0x30f682]['onComplete'](null,!0x1,_0x3ba603[_0x30f682]['currentInputSnapshot'])):_0x5c662d['push'](()=>_0x3ba603[_0x30f682]['onComplete'](new Error(_0x463373),!0x1,null))));}Gn(_0x16f879,_0x16f879['transactionQueueTree_']);for(let _0x30cc78=0x0;_0x30cc78<_0x5c662d['length'];_0x30cc78++)ht(_0x5c662d[_0x30cc78]);$n(_0x16f879,_0x16f879['transactionQueueTree_']);}function ua(_0x5cf79d,_0x5a7ba7){let _0x5811fe,_0x97e911=_0x5cf79d['transactionQueueTree_'];for(_0x5811fe=y(_0x5a7ba7);_0x5811fe!==null&&Ge(_0x97e911)===void 0x0;)_0x97e911=Wn(_0x97e911,_0x5811fe),_0x5a7ba7=b(_0x5a7ba7),_0x5811fe=y(_0x5a7ba7);return _0x97e911;}function da(_0x395e4d,_0x7627c7){const _0x5be78a=[];return fa(_0x395e4d,_0x7627c7,_0x5be78a),_0x5be78a['sort']((_0x23dc41,_0x1b03b7)=>_0x23dc41['order']-_0x1b03b7['order']),_0x5be78a;}function fa(_0xd806e7,_0x5f1366,_0x5587dc){const _0x365a58=Ge(_0x5f1366);if(_0x365a58){for(let _0x27ab88=0x0;_0x27ab88<_0x365a58['length'];_0x27ab88++)_0x5587dc['push'](_0x365a58[_0x27ab88]);}Bn(_0x5f1366,_0x59dcdd=>{fa(_0xd806e7,_0x59dcdd,_0x5587dc);});}function Gn(_0x1e87f8,_0x242a98){const _0xf71b1c=Ge(_0x242a98);if(_0xf71b1c){let _0x4ecb3c=0x0;for(let _0x3a6140=0x0;_0x3a6140<_0xf71b1c['length'];_0x3a6140++)_0xf71b1c[_0x3a6140]['status']!==0x2&&(_0xf71b1c[_0x4ecb3c]=_0xf71b1c[_0x3a6140],_0x4ecb3c++);_0xf71b1c['length']=_0x4ecb3c,_s(_0x242a98,_0xf71b1c['length']>0x0?_0xf71b1c:void 0x0);}Bn(_0x242a98,_0x485579=>{Gn(_0x1e87f8,_0x485579);});}function Is(_0x2281c7,_0x5c04cb){const _0x51a5c4=qt(ua(_0x2281c7,_0x5c04cb)),_0x87d6e5=Wn(_0x2281c7['transactionQueueTree_'],_0x5c04cb);return ad(_0x87d6e5,_0x385dcd=>{ci(_0x2281c7,_0x385dcd);}),ci(_0x2281c7,_0x87d6e5),sa(_0x87d6e5,_0x5013c2=>{ci(_0x2281c7,_0x5013c2);}),_0x51a5c4;}function ci(_0x5959c8,_0x1d71c8){const _0x1256e0=Ge(_0x1d71c8);if(_0x1256e0){const _0x2e4875=[];let _0x151507=[],_0x3fd7a6=-0x1;for(let _0x2bb0b3=0x0;_0x2bb0b3<_0x1256e0['length'];_0x2bb0b3++)_0x1256e0[_0x2bb0b3]['status']===0x3||(_0x1256e0[_0x2bb0b3]['status']===0x1?(f(_0x3fd7a6===_0x2bb0b3-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x3fd7a6=_0x2bb0b3,_0x1256e0[_0x2bb0b3]['status']=0x3,_0x1256e0[_0x2bb0b3]['abortReason']='set'):(f(_0x1256e0[_0x2bb0b3]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x1256e0[_0x2bb0b3]['unwatcher'](),_0x151507=_0x151507['concat'](pe(_0x5959c8['serverSyncTree_'],_0x1256e0[_0x2bb0b3]['currentWriteId'],!0x0)),_0x1256e0[_0x2bb0b3]['onComplete']&&_0x2e4875['push'](_0x1256e0[_0x2bb0b3]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x3fd7a6===-0x1?_s(_0x1d71c8,void 0x0):_0x1256e0['length']=_0x3fd7a6+0x1,H(_0x5959c8['eventQueue_'],qt(_0x1d71c8),_0x151507);for(let _0x57b2f0=0x0;_0x57b2f0<_0x2e4875['length'];_0x57b2f0++)ht(_0x2e4875[_0x57b2f0]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x34ff0d){let _0x51df3c='';const _0x4d159c=_0x34ff0d['split']('/');for(let _0x1908a7=0x0;_0x1908a7<_0x4d159c['length'];_0x1908a7++)if(_0x4d159c[_0x1908a7]['length']>0x0){let _0x4202b4=_0x4d159c[_0x1908a7];try{_0x4202b4=decodeURIComponent(_0x4202b4['replace'](/\+/g,'\x20'));}catch{}_0x51df3c+='/'+_0x4202b4;}return _0x51df3c;}function Dd(_0x3603cf){const _0x58e01b={};_0x3603cf['charAt'](0x0)==='?'&&(_0x3603cf=_0x3603cf['substring'](0x1));for(const _0x45284 of _0x3603cf['split']('&')){if(_0x45284['length']===0x0)continue;const _0x1de610=_0x45284['split']('=');_0x1de610['length']===0x2?_0x58e01b[decodeURIComponent(_0x1de610[0x0])]=decodeURIComponent(_0x1de610[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x45284+'\x27\x20in\x20query\x20\x27'+_0x3603cf+'\x27');}return _0x58e01b;}const vr=function(_0x2e0dbe,_0x15e34f){const _0x56af1e=Md(_0x2e0dbe),_0x539eae=_0x56af1e['namespace'];_0x56af1e['domain']==='firebase.com'&&ae(_0x56af1e['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x539eae||_0x539eae==='undefined')&&_0x56af1e['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x56af1e['secure']||$l();const _0x2f8517=_0x56af1e['scheme']==='ws'||_0x56af1e['scheme']==='wss';return{'repoInfo':new yo(_0x56af1e['host'],_0x56af1e['secure'],_0x539eae,_0x2f8517,_0x15e34f,'',_0x539eae!==_0x56af1e['subdomain']),'path':new C(_0x56af1e['pathString'])};},Md=function(_0x4ca102){let _0x4427fe='',_0x9ff74a='',_0x2fdd45='',_0x533594='',_0x152464='',_0x5ad15b=!0x0,_0x41e979='https',_0x30b425=0x1bb;if(typeof _0x4ca102=='string'){let _0xcaca6a=_0x4ca102['indexOf']('//');_0xcaca6a>=0x0&&(_0x41e979=_0x4ca102['substring'](0x0,_0xcaca6a-0x1),_0x4ca102=_0x4ca102['substring'](_0xcaca6a+0x2));let _0x345360=_0x4ca102['indexOf']('/');_0x345360===-0x1&&(_0x345360=_0x4ca102['length']);let _0xacc261=_0x4ca102['indexOf']('?');_0xacc261===-0x1&&(_0xacc261=_0x4ca102['length']),_0x4427fe=_0x4ca102['substring'](0x0,Math['min'](_0x345360,_0xacc261)),_0x345360<_0xacc261&&(_0x533594=Od(_0x4ca102['substring'](_0x345360,_0xacc261)));const _0x468fd7=Dd(_0x4ca102['substring'](Math['min'](_0x4ca102['length'],_0xacc261)));_0xcaca6a=_0x4427fe['indexOf'](':'),_0xcaca6a>=0x0?(_0x5ad15b=_0x41e979==='https'||_0x41e979==='wss',_0x30b425=parseInt(_0x4427fe['substring'](_0xcaca6a+0x1),0xa)):_0xcaca6a=_0x4427fe['length'];const _0x2b78b4=_0x4427fe['slice'](0x0,_0xcaca6a);if(_0x2b78b4['toLowerCase']()==='localhost')_0x9ff74a='localhost';else{if(_0x2b78b4['split']('.')['length']<=0x2)_0x9ff74a=_0x2b78b4;else{const _0x3ba64b=_0x4427fe['indexOf']('.');_0x2fdd45=_0x4427fe['substring'](0x0,_0x3ba64b)['toLowerCase'](),_0x9ff74a=_0x4427fe['substring'](_0x3ba64b+0x1),_0x152464=_0x2fdd45;}}'ns'in _0x468fd7&&(_0x152464=_0x468fd7['ns']);}return{'host':_0x4427fe,'port':_0x30b425,'domain':_0x9ff74a,'subdomain':_0x2fdd45,'secure':_0x5ad15b,'scheme':_0x41e979,'pathString':_0x533594,'namespace':_0x152464};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x58ace8=0x0;const _0x3d9bd2=[];return function(_0x49b812){const _0xf83858=_0x49b812===_0x58ace8;_0x58ace8=_0x49b812;let _0x38a1fb;const _0x4f0db8=new Array(0x8);for(_0x38a1fb=0x7;_0x38a1fb>=0x0;_0x38a1fb--)_0x4f0db8[_0x38a1fb]=Er['charAt'](_0x49b812%0x40),_0x49b812=Math['floor'](_0x49b812/0x40);f(_0x49b812===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x102e00=_0x4f0db8['join']('');if(_0xf83858){for(_0x38a1fb=0xb;_0x38a1fb>=0x0&&_0x3d9bd2[_0x38a1fb]===0x3f;_0x38a1fb--)_0x3d9bd2[_0x38a1fb]=0x0;_0x3d9bd2[_0x38a1fb]++;}else{for(_0x38a1fb=0x0;_0x38a1fb<0xc;_0x38a1fb++)_0x3d9bd2[_0x38a1fb]=Math['floor'](Math['random']()*0x40);}for(_0x38a1fb=0x0;_0x38a1fb<0xc;_0x38a1fb++)_0x102e00+=Er['charAt'](_0x3d9bd2[_0x38a1fb]);return f(_0x102e00['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x102e00;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x28ca4b,_0x3ddbce,_0x3c1cc5,_0x26ee4a){this['eventType']=_0x28ca4b,this['eventRegistration']=_0x3ddbce,this['snapshot']=_0x3c1cc5,this['prevName']=_0x26ee4a;}['getPath'](){const _0x3f589b=this['snapshot']['ref'];return this['eventType']==='value'?_0x3f589b['_path']:_0x3f589b['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x5ba7d6,_0x190b48,_0x306067){this['eventRegistration']=_0x5ba7d6,this['error']=_0x190b48,this['path']=_0x306067;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x12fd5c,_0x4e0363){this['snapshotCallback']=_0x12fd5c,this['cancelCallback']=_0x4e0363;}['onValue'](_0x2f310d,_0x10b47f){this['snapshotCallback']['call'](null,_0x2f310d,_0x10b47f);}['onCancel'](_0x5a9272){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x5a9272);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x2eaec3){return this['snapshotCallback']===_0x2eaec3['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x2eaec3['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x2eaec3['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x188ed3,_0x1f60f1,_0x1717ce,_0x2c09b1){this['_repo']=_0x188ed3,this['_path']=_0x1f60f1,this['_queryParams']=_0x1717ce,this['_orderByCalled']=_0x2c09b1;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x5e17c1=rr(this['_queryParams']),_0x43b63e=Hi(_0x5e17c1);return _0x43b63e==='{}'?'default':_0x43b63e;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x4cfe04){if(_0x4cfe04=N(_0x4cfe04),!(_0x4cfe04 instanceof be))return!0x1;const _0x1605b9=this['_repo']===_0x4cfe04['_repo'],_0x2da85e=ji(this['_path'],_0x4cfe04['_path']),_0x25f0a9=this['_queryIdentifier']===_0x4cfe04['_queryIdentifier'];return _0x1605b9&&_0x2da85e&&_0x25f0a9;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x5f1de0,_0x299c0f){if(_0x5f1de0['_orderByCalled']===!0x0)throw new Error(_0x299c0f+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x3fa3a6){let _0x546912=null,_0x359665=null;if(_0x3fa3a6['hasStart']()&&(_0x546912=_0x3fa3a6['getIndexStartValue']()),_0x3fa3a6['hasEnd']()&&(_0x359665=_0x3fa3a6['getIndexEndValue']()),_0x3fa3a6['getIndex']()===ye){const _0x1e1d81='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x40b592='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x3fa3a6['hasStart']()){if(_0x3fa3a6['getIndexStartName']()!==Fe)throw new Error(_0x1e1d81);if(typeof _0x546912!='string')throw new Error(_0x40b592);}if(_0x3fa3a6['hasEnd']()){if(_0x3fa3a6['getIndexEndName']()!==Ie)throw new Error(_0x1e1d81);if(typeof _0x359665!='string')throw new Error(_0x40b592);}}else{if(_0x3fa3a6['getIndex']()===R){if(_0x546912!=null&&!Tn(_0x546912)||_0x359665!=null&&!Tn(_0x359665))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x3fa3a6['getIndex']()instanceof Qi||_0x3fa3a6['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x546912!=null&&typeof _0x546912=='object'||_0x359665!=null&&typeof _0x359665=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x1ac837){if(_0x1ac837['hasStart']()&&_0x1ac837['hasEnd']()&&_0x1ac837['hasLimit']()&&!_0x1ac837['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x2390d8,_0x47c05e){super(_0x2390d8,_0x47c05e,new Xi(),!0x1);}get['parent'](){const _0x30745f=Ro(this['_path']);return _0x30745f===null?null:new ee(this['_repo'],_0x30745f);}get['root'](){let _0x2a7216=this;for(;_0x2a7216['parent']!==null;)_0x2a7216=_0x2a7216['parent'];return _0x2a7216;}}class st{constructor(_0x349cf8,_0x240ef1,_0x545bed){this['_node']=_0x349cf8,this['ref']=_0x240ef1,this['_index']=_0x545bed;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x552b68){const _0x344c01=new C(_0x552b68),_0x5e0fd2=Ft(this['ref'],_0x552b68);return new st(this['_node']['getChild'](_0x344c01),_0x5e0fd2,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x360aa4){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x108fb2,_0x59bc44)=>_0x360aa4(new st(_0x59bc44,Ft(this['ref'],_0x108fb2),R)));}['hasChild'](_0x51476){const _0x25f849=new C(_0x51476);return!this['_node']['getChild'](_0x25f849)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x1f4703,_0x34f9b0){return _0x1f4703=N(_0x1f4703),_0x1f4703['_checkNotDeleted']('ref'),_0x34f9b0!==void 0x0?Ft(_0x1f4703['_root'],_0x34f9b0):_0x1f4703['_root'];}function Ft(_0x265c34,_0x21cb31){return _0x265c34=N(_0x265c34),y(_0x265c34['_path'])===null?pd('child','path',_0x21cb31):ms('child','path',_0x21cb31),new ee(_0x265c34['_repo'],k(_0x265c34['_path'],_0x21cb31));}function g_(_0x730d31,_0x17f750){_0x730d31=N(_0x730d31),ys('push',_0x730d31['_path']),zt('push',_0x17f750,_0x730d31['_path'],!0x0);const _0x5cb5f9=la(_0x730d31['_repo']),_0x494afd=Ld(_0x5cb5f9),_0x24bead=Ft(_0x730d31,_0x494afd),_0x39bebe=Ft(_0x730d31,_0x494afd);let _0x2ec1a9;return _0x17f750!=null?_0x2ec1a9=Ud(_0x39bebe,_0x17f750)['then'](()=>_0x39bebe):_0x2ec1a9=Promise['resolve'](_0x39bebe),_0x24bead['then']=_0x2ec1a9['then']['bind'](_0x2ec1a9),_0x24bead['catch']=_0x2ec1a9['then']['bind'](_0x2ec1a9,void 0x0),_0x24bead;}function Ud(_0x44b02c,_0x393705){_0x44b02c=N(_0x44b02c),ys('set',_0x44b02c['_path']),zt('set',_0x393705,_0x44b02c['_path'],!0x1);const _0x3797a9=new ot();return Cd(_0x44b02c['_repo'],_0x44b02c['_path'],_0x393705,null,_0x3797a9['wrapCallback'](()=>{})),_0x3797a9['promise'];}function m_(_0x4beb7e,_0x551d15){fd('update',_0x551d15,_0x4beb7e['_path']);const _0xc1c9cd=new ot();return Td(_0x4beb7e['_repo'],_0x4beb7e['_path'],_0x551d15,_0xc1c9cd['wrapCallback'](()=>{})),_0xc1c9cd['promise'];}function y_(_0x3b2a38){_0x3b2a38=N(_0x3b2a38);const _0x196708=new pa(()=>{}),_0x120872=new zn(_0x196708);return wd(_0x3b2a38['_repo'],_0x3b2a38,_0x120872)['then'](_0x3557b4=>new st(_0x3557b4,new ee(_0x3b2a38['_repo'],_0x3b2a38['_path']),_0x3b2a38['_queryParams']['getIndex']()));}class zn{constructor(_0x3daf27){this['callbackContext']=_0x3daf27;}['respondsTo'](_0x1c3722){return _0x1c3722==='value';}['createEvent'](_0x4310ce,_0x434972){const _0x320379=_0x434972['_queryParams']['getIndex']();return new xd('value',this,new st(_0x4310ce['snapshotNode'],new ee(_0x434972['_repo'],_0x434972['_path']),_0x320379));}['getEventRunner'](_0x4d3706){return _0x4d3706['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x4d3706['error']):()=>this['callbackContext']['onValue'](_0x4d3706['snapshot'],null);}['createCancelEvent'](_0x2aa9e5,_0x46a3aa){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x2aa9e5,_0x46a3aa):null;}['matches'](_0x54f45b){return _0x54f45b instanceof zn?!_0x54f45b['callbackContext']||!this['callbackContext']?!0x0:_0x54f45b['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x2c0930,_0x3440de,_0x232458,_0x447841,_0x172571){const _0x174af9=new pa(_0x232458,void 0x0),_0x93e2cd=new zn(_0x174af9);return bd(_0x2c0930['_repo'],_0x2c0930,_0x93e2cd),()=>Rd(_0x2c0930['_repo'],_0x2c0930,_0x93e2cd);}function Bd(_0x5690c5,_0x558c6b,_0x174a6e,_0x31933b){return Wd(_0x5690c5,'value',_0x558c6b);}class ft{}class ma extends ft{constructor(_0x506779,_0x2ee73d){super(),this['_value']=_0x506779,this['_key']=_0x2ee73d,this['type']='endAt';}['_apply'](_0x3be18c){zt('endAt',this['_value'],_0x3be18c['_path'],!0x0);const _0x1e35ba=Jh(_0x3be18c['_queryParams'],this['_value'],this['_key']);if(ga(_0x1e35ba),qn(_0x1e35ba),_0x3be18c['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x3be18c['_repo'],_0x3be18c['_path'],_0x1e35ba,_0x3be18c['_orderByCalled']);}}function v_(_0x5bd53,_0x637381){return new ma(_0x5bd53,_0x637381);}class ya extends ft{constructor(_0x1c40ce,_0x44f026){super(),this['_value']=_0x1c40ce,this['_key']=_0x44f026,this['type']='startAt';}['_apply'](_0x5a3101){zt('startAt',this['_value'],_0x5a3101['_path'],!0x0);const _0x29c435=Qh(_0x5a3101['_queryParams'],this['_value'],this['_key']);if(ga(_0x29c435),qn(_0x29c435),_0x5a3101['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x5a3101['_repo'],_0x5a3101['_path'],_0x29c435,_0x5a3101['_orderByCalled']);}}function E_(_0x33f85a=null,_0x209df8){return new ya(_0x33f85a,_0x209df8);}class Vd extends ft{constructor(_0x102beb){super(),this['_limit']=_0x102beb,this['type']='limitToFirst';}['_apply'](_0x46d581){if(_0x46d581['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x46d581['_repo'],_0x46d581['_path'],Yh(_0x46d581['_queryParams'],this['_limit']),_0x46d581['_orderByCalled']);}}function I_(_0x4e408b){if(Math['floor'](_0x4e408b)!==_0x4e408b||_0x4e408b<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x4e408b);}class Hd extends ft{constructor(_0x22749f){super(),this['_path']=_0x22749f,this['type']='orderByChild';}['_apply'](_0x579c9f){_a(_0x579c9f,'orderByChild');const _0x45d86a=new C(this['_path']);if(v(_0x45d86a))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x54505f=new Qi(_0x45d86a),_0x23a141=xo(_0x579c9f['_queryParams'],_0x54505f);return qn(_0x23a141),new be(_0x579c9f['_repo'],_0x579c9f['_path'],_0x23a141,!0x0);}}function w_(_0x213225){if(_0x213225==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x213225==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x213225==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x213225),new Hd(_0x213225);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x3b91ec){_a(_0x3b91ec,'orderByKey');const _0x2b484f=xo(_0x3b91ec['_queryParams'],ye);return qn(_0x2b484f),new be(_0x3b91ec['_repo'],_0x3b91ec['_path'],_0x2b484f,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x33deb3,_0x4a0e52){super(),this['_value']=_0x33deb3,this['_key']=_0x4a0e52,this['type']='equalTo';}['_apply'](_0x401c6d){if(zt('equalTo',this['_value'],_0x401c6d['_path'],!0x1),_0x401c6d['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x401c6d['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x401c6d));}}function T_(_0x276032,_0x2d37af){return new Gd(_0x276032,_0x2d37af);}function S_(_0x3babe4,..._0x15dc44){let _0x17e761=N(_0x3babe4);for(const _0xc41530 of _0x15dc44)_0x17e761=_0xc41530['_apply'](_0x17e761);return _0x17e761;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x4af438,_0x249b5a,_0x425895,_0x1567a5){const _0x1f28f0=_0x249b5a['lastIndexOf'](':'),_0x3d92c9=_0x249b5a['substring'](0x0,_0x1f28f0),_0x4051f1=at(_0x3d92c9);_0x4af438['repoInfo_']=new yo(_0x249b5a,_0x4051f1,_0x4af438['repoInfo_']['namespace'],_0x4af438['repoInfo_']['webSocketOnly'],_0x4af438['repoInfo_']['nodeAdmin'],_0x4af438['repoInfo_']['persistenceKey'],_0x4af438['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x425895),_0x1567a5&&(_0x4af438['authTokenProvider_']=_0x1567a5);}function Kd(_0x2db0f3,_0x6ab4bb,_0x2a5043,_0x5b81ba,_0x2331a0){let _0x44f721=_0x5b81ba||_0x2db0f3['options']['databaseURL'];_0x44f721===void 0x0&&(_0x2db0f3['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x2db0f3['options']['projectId']),_0x44f721=_0x2db0f3['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x209174=vr(_0x44f721,_0x2331a0),_0x4eb930=_0x209174['repoInfo'],_0x18fe49;typeof process<'u'&&Vs&&(_0x18fe49=Vs[qd]),_0x18fe49?(_0x44f721='http://'+_0x18fe49+'?ns='+_0x4eb930['namespace'],_0x209174=vr(_0x44f721,_0x2331a0),_0x4eb930=_0x209174['repoInfo']):_0x209174['repoInfo']['secure'];const _0x1a0752=new eh(_0x2db0f3['name'],_0x2db0f3['options'],_0x6ab4bb);_d('Invalid\x20Firebase\x20Database\x20URL',_0x209174),v(_0x209174['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x373269=Qd(_0x4eb930,_0x2db0f3,_0x1a0752,new Zl(_0x2db0f3,_0x2a5043));return new Jd(_0x373269,_0x2db0f3);}function Yd(_0x4cc2e0,_0x339c83){const _0x567566=Ni[_0x339c83];(!_0x567566||_0x567566[_0x4cc2e0['key']]!==_0x4cc2e0)&&ae('Database\x20'+_0x339c83+'('+_0x4cc2e0['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x4cc2e0),delete _0x567566[_0x4cc2e0['key']];}function Qd(_0x287a8a,_0x8467a6,_0x3b6fc7,_0x42dad7){let _0x3e5d6d=Ni[_0x8467a6['name']];_0x3e5d6d||(_0x3e5d6d={},Ni[_0x8467a6['name']]=_0x3e5d6d);let _0x3aaed4=_0x3e5d6d[_0x287a8a['toURLString']()];return _0x3aaed4&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x3aaed4=new vd(_0x287a8a,zd,_0x3b6fc7,_0x42dad7),_0x3e5d6d[_0x287a8a['toURLString']()]=_0x3aaed4,_0x3aaed4;}class Jd{constructor(_0x51f5a1,_0x2367cb){this['_repoInternal']=_0x51f5a1,this['app']=_0x2367cb,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x4d9f98){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x4d9f98+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x1d0f8e=Zr(),_0x2d89dd){const _0x3b2e48=Bi(_0x1d0f8e,'database')['getImmediate']({'identifier':_0x2d89dd});if(!_0x3b2e48['_instanceStarted']){const _0x27304f=cc('database');_0x27304f&&Xd(_0x3b2e48,..._0x27304f);}return _0x3b2e48;}function Xd(_0xc7427,_0x211657,_0x3c6aa4,_0x5b603a={}){_0xc7427=N(_0xc7427),_0xc7427['_checkNotDeleted']('useEmulator');const _0x11a414=_0x211657+':'+_0x3c6aa4,_0x3f7831=_0xc7427['_repoInternal'];if(_0xc7427['_instanceStarted']){if(_0x11a414===_0xc7427['_repoInternal']['repoInfo_']['host']&&Me(_0x5b603a,_0x3f7831['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x1033c9;if(_0x3f7831['repoInfo_']['nodeAdmin'])_0x5b603a['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x1033c9=new nn(nn['OWNER']);else{if(_0x5b603a['mockUserToken']){const _0x1df7fb=typeof _0x5b603a['mockUserToken']=='string'?_0x5b603a['mockUserToken']:lc(_0x5b603a['mockUserToken'],_0xc7427['app']['options']['projectId']);_0x1033c9=new nn(_0x1df7fb);}}at(_0x211657)&&(jr(_0x211657),Kr('Database',!0x0)),jd(_0x3f7831,_0x11a414,_0x5b603a,_0x1033c9);}function R_(_0x3cf36a){_0x3cf36a=N(_0x3cf36a),_0x3cf36a['_checkNotDeleted']('goOffline'),ha(_0x3cf36a['_repo']);}function A_(_0xe0a695){_0xe0a695=N(_0xe0a695),_0xe0a695['_checkNotDeleted']('goOnline'),Ad(_0xe0a695['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x21892a){Ul(lt),Ze(new Le('database',(_0x12cb40,{instanceIdentifier:_0x31d268})=>{const _0x1dc4a6=_0x12cb40['getProvider']('app')['getImmediate'](),_0x574c9d=_0x12cb40['getProvider']('auth-internal'),_0xeaa120=_0x12cb40['getProvider']('app-check-internal');return Kd(_0x1dc4a6,_0x574c9d,_0xeaa120,_0x31d268);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x21892a),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x4f7d01,_0x23444a){this['committed']=_0x4f7d01,this['snapshot']=_0x23444a;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x3b83a2,_0x212b8c,_0x440fac){if(_0x3b83a2=N(_0x3b83a2),ys('Reference.transaction',_0x3b83a2['_path']),_0x3b83a2['key']==='.length'||_0x3b83a2['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x3b83a2['key']+'\x20is\x20a\x20read-only\x20object.';const _0x1d3165=!0x0,_0xdef2ad=new ot(),_0x4c3873=(_0x19201a,_0x3593c6,_0x538ad3)=>{let _0x32648e=null;_0x19201a?_0xdef2ad['reject'](_0x19201a):(_0x32648e=new st(_0x538ad3,new ee(_0x3b83a2['_repo'],_0x3b83a2['_path']),R),_0xdef2ad['resolve'](new tf(_0x3593c6,_0x32648e)));},_0x39df11=Bd(_0x3b83a2,()=>{});return kd(_0x3b83a2['_repo'],_0x3b83a2['_path'],_0x212b8c,_0x4c3873,_0x39df11,_0x1d3165),_0xdef2ad['promise'];}se['prototype']['simpleListen']=function(_0x546ec2,_0x11375a){this['sendRequest']('q',{'p':_0x546ec2},_0x11375a);},se['prototype']['echo']=function(_0x4ca3c0,_0x1619ee){this['sendRequest']('echo',{'d':_0x4ca3c0},_0x1619ee);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x25d100,..._0x59e8b3){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x25d100,..._0x59e8b3);}function sn(_0x550cd9,..._0xbd8e1e){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x550cd9,..._0xbd8e1e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x29f1bc,..._0x578a22){throw ws(_0x29f1bc,..._0x578a22);}function X(_0x236446,..._0x3f143a){return ws(_0x236446,..._0x3f143a);}function Ia(_0x4b6e9b,_0x218277,_0x291e73){const _0x2131e6={...nf(),[_0x218277]:_0x291e73};return new Bt('auth','Firebase',_0x2131e6)['create'](_0x218277,{'appName':_0x4b6e9b['name']});}function re(_0x117dcb){return Ia(_0x117dcb,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x54fe06,..._0x461e29){if(typeof _0x54fe06!='string'){const _0x1f7dd4=_0x461e29[0x0],_0x411039=[..._0x461e29['slice'](0x1)];return _0x411039[0x0]&&(_0x411039[0x0]['appName']=_0x54fe06['name']),_0x54fe06['_errorFactory']['create'](_0x1f7dd4,..._0x411039);}return Ea['create'](_0x54fe06,..._0x461e29);}function m(_0x4e94b6,_0x10d0ef,..._0x276c45){if(!_0x4e94b6)throw ws(_0x10d0ef,..._0x276c45);}function ne(_0x55a0ad){const _0x155e34='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x55a0ad;throw sn(_0x155e34),new Error(_0x155e34);}function ce(_0xf6bfa0,_0x27952e){_0xf6bfa0||ne(_0x27952e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x33edae;return typeof self<'u'&&((_0x33edae=self['location'])==null?void 0x0:_0x33edae['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x3a5a5f;return typeof self<'u'&&((_0x3a5a5f=self['location'])==null?void 0x0:_0x3a5a5f['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x2fa5de=navigator;return _0x2fa5de['languages']&&_0x2fa5de['languages'][0x0]||_0x2fa5de['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x380855,_0x228927){this['shortDelay']=_0x380855,this['longDelay']=_0x228927,ce(_0x228927>_0x380855,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x3f1eee,_0x35b904){ce(_0x3f1eee['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x33c9aa}=_0x3f1eee['emulator'];return _0x35b904?''+_0x33c9aa+(_0x35b904['startsWith']('/')?_0x35b904['slice'](0x1):_0x35b904):_0x33c9aa;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x13aaf2,_0x5470ef,_0x1644e0){this['fetchImpl']=_0x13aaf2,_0x5470ef&&(this['headersImpl']=_0x5470ef),_0x1644e0&&(this['responseImpl']=_0x1644e0);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x3b13c5,_0x579f8e){return _0x3b13c5['tenantId']&&!_0x579f8e['tenantId']?{..._0x579f8e,'tenantId':_0x3b13c5['tenantId']}:_0x579f8e;}async function Ae(_0x37dbf3,_0x141d5d,_0x24a0fa,_0xb0dc4e,_0x29b3fa={}){return Ca(_0x37dbf3,_0x29b3fa,async()=>{let _0x3bc3e4={},_0x173059={};_0xb0dc4e&&(_0x141d5d==='GET'?_0x173059=_0xb0dc4e:_0x3bc3e4={'body':JSON['stringify'](_0xb0dc4e)});const _0x5930ec=ct({'key':_0x37dbf3['config']['apiKey'],..._0x173059})['slice'](0x1),_0x53ef86=await _0x37dbf3['_getAdditionalHeaders']();_0x53ef86['Content-Type']='application/json',_0x37dbf3['languageCode']&&(_0x53ef86['X-Firebase-Locale']=_0x37dbf3['languageCode']);const _0x56bbb9={'method':_0x141d5d,'headers':_0x53ef86,..._0x3bc3e4};return dc()||(_0x56bbb9['referrerPolicy']='no-referrer'),_0x37dbf3['emulatorConfig']&&at(_0x37dbf3['emulatorConfig']['host'])&&(_0x56bbb9['credentials']='include'),wa['fetch']()(await Ta(_0x37dbf3,_0x37dbf3['config']['apiHost'],_0x24a0fa,_0x5930ec),_0x56bbb9);});}async function Ca(_0x345b0b,_0x70dfdc,_0x61ca43){_0x345b0b['_canInitEmulator']=!0x1;const _0x15648d={...cf,..._0x70dfdc};try{const _0x4e9635=new df(_0x345b0b),_0x7c32bc=await Promise['race']([_0x61ca43(),_0x4e9635['promise']]);_0x4e9635['clearNetworkTimeout']();const _0x444902=await _0x7c32bc['json']();if('needConfirmation'in _0x444902)throw tn(_0x345b0b,'account-exists-with-different-credential',_0x444902);if(_0x7c32bc['ok']&&!('errorMessage'in _0x444902))return _0x444902;{const _0xb55962=_0x7c32bc['ok']?_0x444902['errorMessage']:_0x444902['error']['message'],[_0x541905,_0x5a60f5]=_0xb55962['split']('\x20:\x20');if(_0x541905==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x345b0b,'credential-already-in-use',_0x444902);if(_0x541905==='EMAIL_EXISTS')throw tn(_0x345b0b,'email-already-in-use',_0x444902);if(_0x541905==='USER_DISABLED')throw tn(_0x345b0b,'user-disabled',_0x444902);const _0x25c73e=_0x15648d[_0x541905]||_0x541905['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x5a60f5)throw Ia(_0x345b0b,_0x25c73e,_0x5a60f5);Q(_0x345b0b,_0x25c73e);}}catch(_0x4dbd3f){if(_0x4dbd3f instanceof Se)throw _0x4dbd3f;Q(_0x345b0b,'network-request-failed',{'message':String(_0x4dbd3f)});}}async function Qt(_0x10f4b9,_0x1a74f0,_0x37230b,_0xd7121d,_0x1c1c6f={}){const _0x3d4ea3=await Ae(_0x10f4b9,_0x1a74f0,_0x37230b,_0xd7121d,_0x1c1c6f);return'mfaPendingCredential'in _0x3d4ea3&&Q(_0x10f4b9,'multi-factor-auth-required',{'_serverResponse':_0x3d4ea3}),_0x3d4ea3;}async function Ta(_0x387c6d,_0xff0a05,_0x5092d5,_0x26df6c){const _0x4c149d=''+_0xff0a05+_0x5092d5+'?'+_0x26df6c,_0x5a7883=_0x387c6d,_0x126117=_0x5a7883['config']['emulator']?Cs(_0x387c6d['config'],_0x4c149d):_0x387c6d['config']['apiScheme']+'://'+_0x4c149d;return lf['includes'](_0x5092d5)&&(await _0x5a7883['_persistenceManagerAvailable'],_0x5a7883['_getPersistenceType']()==='COOKIE')?_0x5a7883['_getPersistence']()['_getFinalTarget'](_0x126117)['toString']():_0x126117;}function uf(_0x3a74c9){switch(_0x3a74c9){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x530eef){this['auth']=_0x530eef,this['timer']=null,this['promise']=new Promise((_0x332a04,_0x4962f9)=>{this['timer']=setTimeout(()=>_0x4962f9(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x60a8f8,_0x41f099,_0x58d1bd){const _0x5233df={'appName':_0x60a8f8['name']};_0x58d1bd['email']&&(_0x5233df['email']=_0x58d1bd['email']),_0x58d1bd['phoneNumber']&&(_0x5233df['phoneNumber']=_0x58d1bd['phoneNumber']);const _0x38fdfd=X(_0x60a8f8,_0x41f099,_0x5233df);return _0x38fdfd['customData']['_tokenResponse']=_0x58d1bd,_0x38fdfd;}function wr(_0x4659a6){return _0x4659a6!==void 0x0&&_0x4659a6['enterprise']!==void 0x0;}class ff{constructor(_0x5f06d7){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x5f06d7['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x5f06d7['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x5f06d7['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x18173d){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x5940ed of this['recaptchaEnforcementState'])if(_0x5940ed['provider']&&_0x5940ed['provider']===_0x18173d)return uf(_0x5940ed['enforcementState']);return null;}['isProviderEnabled'](_0x2200a0){return this['getProviderEnforcementState'](_0x2200a0)==='ENFORCE'||this['getProviderEnforcementState'](_0x2200a0)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x15d129,_0x30e61e){return Ae(_0x15d129,'GET','/v2/recaptchaConfig',Re(_0x15d129,_0x30e61e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x4da654,_0x1b01d8){return Ae(_0x4da654,'POST','/v1/accounts:delete',_0x1b01d8);}async function bn(_0x6f023c,_0x12ae27){return Ae(_0x6f023c,'POST','/v1/accounts:lookup',_0x12ae27);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x5077a9){if(_0x5077a9)try{const _0x9a22e2=new Date(Number(_0x5077a9));if(!isNaN(_0x9a22e2['getTime']()))return _0x9a22e2['toUTCString']();}catch{}}async function gf(_0x527ec6,_0x454a0e=!0x1){const _0xdf0989=N(_0x527ec6),_0xcc490=await _0xdf0989['getIdToken'](_0x454a0e),_0x163b0e=Ts(_0xcc490);m(_0x163b0e&&_0x163b0e['exp']&&_0x163b0e['auth_time']&&_0x163b0e['iat'],_0xdf0989['auth'],'internal-error');const _0x5b43c5=typeof _0x163b0e['firebase']=='object'?_0x163b0e['firebase']:void 0x0,_0x400f66=_0x5b43c5==null?void 0x0:_0x5b43c5['sign_in_provider'];return{'claims':_0x163b0e,'token':_0xcc490,'authTime':Rt(li(_0x163b0e['auth_time'])),'issuedAtTime':Rt(li(_0x163b0e['iat'])),'expirationTime':Rt(li(_0x163b0e['exp'])),'signInProvider':_0x400f66||null,'signInSecondFactor':(_0x5b43c5==null?void 0x0:_0x5b43c5['sign_in_second_factor'])||null};}function li(_0x5a8e00){return Number(_0x5a8e00)*0x3e8;}function Ts(_0x4edf2c){const [_0x4653f5,_0x44c4d3,_0x3fd922]=_0x4edf2c['split']('.');if(_0x4653f5===void 0x0||_0x44c4d3===void 0x0||_0x3fd922===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x1b6a19=ln(_0x44c4d3);return _0x1b6a19?JSON['parse'](_0x1b6a19):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x4d0493){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x4d0493==null?void 0x0:_0x4d0493['toString']()),null;}}function Cr(_0x415aae){const _0xd2fc1d=Ts(_0x415aae);return m(_0xd2fc1d,'internal-error'),m(typeof _0xd2fc1d['exp']<'u','internal-error'),m(typeof _0xd2fc1d['iat']<'u','internal-error'),Number(_0xd2fc1d['exp'])-Number(_0xd2fc1d['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x176aac,_0xab4e8d,_0x10751b=!0x1){if(_0x10751b)return _0xab4e8d;try{return await _0xab4e8d;}catch(_0x4b7bff){throw _0x4b7bff instanceof Se&&mf(_0x4b7bff)&&_0x176aac['auth']['currentUser']===_0x176aac&&await _0x176aac['auth']['signOut'](),_0x4b7bff;}}function mf({code:_0xb4de6e}){return _0xb4de6e==='auth/user-disabled'||_0xb4de6e==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x29b05e){this['user']=_0x29b05e,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x5dd7e2){if(_0x5dd7e2){const _0x314537=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x314537;}else{this['errorBackoff']=0x7530;const _0x684bc1=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x684bc1);}}['schedule'](_0x3df567=!0x1){if(!this['isRunning'])return;const _0x32acf3=this['getInterval'](_0x3df567);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x32acf3);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x180fd0){(_0x180fd0==null?void 0x0:_0x180fd0['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x1e1c2d,_0x122252){this['createdAt']=_0x1e1c2d,this['lastLoginAt']=_0x122252,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x1adec8){this['createdAt']=_0x1adec8['createdAt'],this['lastLoginAt']=_0x1adec8['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x5afb5c){var _0x5a2169;const _0x4787d2=_0x5afb5c['auth'],_0x993cd9=await _0x5afb5c['getIdToken'](),_0x29bf05=await Ut(_0x5afb5c,bn(_0x4787d2,{'idToken':_0x993cd9}));m(_0x29bf05==null?void 0x0:_0x29bf05['users']['length'],_0x4787d2,'internal-error');const _0x40ead7=_0x29bf05['users'][0x0];_0x5afb5c['_notifyReloadListener'](_0x40ead7);const _0x56b116=(_0x5a2169=_0x40ead7['providerUserInfo'])!=null&&_0x5a2169['length']?Sa(_0x40ead7['providerUserInfo']):[],_0x92b836=Ef(_0x5afb5c['providerData'],_0x56b116),_0x145776=_0x5afb5c['isAnonymous'],_0x10695a=!(_0x5afb5c['email']&&_0x40ead7['passwordHash'])&&!(_0x92b836!=null&&_0x92b836['length']),_0x58fa35=_0x145776?_0x10695a:!0x1,_0x9b6608={'uid':_0x40ead7['localId'],'displayName':_0x40ead7['displayName']||null,'photoURL':_0x40ead7['photoUrl']||null,'email':_0x40ead7['email']||null,'emailVerified':_0x40ead7['emailVerified']||!0x1,'phoneNumber':_0x40ead7['phoneNumber']||null,'tenantId':_0x40ead7['tenantId']||null,'providerData':_0x92b836,'metadata':new Oi(_0x40ead7['createdAt'],_0x40ead7['lastLoginAt']),'isAnonymous':_0x58fa35};Object['assign'](_0x5afb5c,_0x9b6608);}async function vf(_0x48f5cf){const _0x395d8e=N(_0x48f5cf);await Rn(_0x395d8e),await _0x395d8e['auth']['_persistUserIfCurrent'](_0x395d8e),_0x395d8e['auth']['_notifyListenersIfCurrent'](_0x395d8e);}function Ef(_0x10c0c8,_0x49cde1){return[..._0x10c0c8['filter'](_0x1a17cb=>!_0x49cde1['some'](_0x51d6c6=>_0x51d6c6['providerId']===_0x1a17cb['providerId'])),..._0x49cde1];}function Sa(_0x14f090){return _0x14f090['map'](({providerId:_0x1be415,..._0x5e6644})=>({'providerId':_0x1be415,'uid':_0x5e6644['rawId']||'','displayName':_0x5e6644['displayName']||null,'email':_0x5e6644['email']||null,'phoneNumber':_0x5e6644['phoneNumber']||null,'photoURL':_0x5e6644['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x45dc64,_0x405183){const _0x1c36a3=await Ca(_0x45dc64,{},async()=>{const _0x47cf7e=ct({'grant_type':'refresh_token','refresh_token':_0x405183})['slice'](0x1),{tokenApiHost:_0x466302,apiKey:_0xe18954}=_0x45dc64['config'],_0x10f176=await Ta(_0x45dc64,_0x466302,'/v1/token','key='+_0xe18954),_0x2d4711=await _0x45dc64['_getAdditionalHeaders']();_0x2d4711['Content-Type']='application/x-www-form-urlencoded';const _0x34f9d9={'method':'POST','headers':_0x2d4711,'body':_0x47cf7e};return _0x45dc64['emulatorConfig']&&at(_0x45dc64['emulatorConfig']['host'])&&(_0x34f9d9['credentials']='include'),wa['fetch']()(_0x10f176,_0x34f9d9);});return{'accessToken':_0x1c36a3['access_token'],'expiresIn':_0x1c36a3['expires_in'],'refreshToken':_0x1c36a3['refresh_token']};}async function wf(_0x397900,_0x1e61b8){return Ae(_0x397900,'POST','/v2/accounts:revokeToken',Re(_0x397900,_0x1e61b8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x5120e0){m(_0x5120e0['idToken'],'internal-error'),m(typeof _0x5120e0['idToken']<'u','internal-error'),m(typeof _0x5120e0['refreshToken']<'u','internal-error');const _0x245ff8='expiresIn'in _0x5120e0&&typeof _0x5120e0['expiresIn']<'u'?Number(_0x5120e0['expiresIn']):Cr(_0x5120e0['idToken']);this['updateTokensAndExpiration'](_0x5120e0['idToken'],_0x5120e0['refreshToken'],_0x245ff8);}['updateFromIdToken'](_0x25f4e8){m(_0x25f4e8['length']!==0x0,'internal-error');const _0x353e37=Cr(_0x25f4e8);this['updateTokensAndExpiration'](_0x25f4e8,null,_0x353e37);}async['getToken'](_0x1dfeac,_0xbd1396=!0x1){return!_0xbd1396&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x1dfeac,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x1dfeac,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x4610dc,_0x41086b){const {accessToken:_0x305044,refreshToken:_0x1224b5,expiresIn:_0x4bed62}=await If(_0x4610dc,_0x41086b);this['updateTokensAndExpiration'](_0x305044,_0x1224b5,Number(_0x4bed62));}['updateTokensAndExpiration'](_0x89fcf0,_0x72dc26,_0x54ab5d){this['refreshToken']=_0x72dc26||null,this['accessToken']=_0x89fcf0||null,this['expirationTime']=Date['now']()+_0x54ab5d*0x3e8;}static['fromJSON'](_0x248075,_0xb10c35){const {refreshToken:_0x4fc027,accessToken:_0x1a935a,expirationTime:_0x936230}=_0xb10c35,_0x275abd=new Qe();return _0x4fc027&&(m(typeof _0x4fc027=='string','internal-error',{'appName':_0x248075}),_0x275abd['refreshToken']=_0x4fc027),_0x1a935a&&(m(typeof _0x1a935a=='string','internal-error',{'appName':_0x248075}),_0x275abd['accessToken']=_0x1a935a),_0x936230&&(m(typeof _0x936230=='number','internal-error',{'appName':_0x248075}),_0x275abd['expirationTime']=_0x936230),_0x275abd;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x1f84b2){this['accessToken']=_0x1f84b2['accessToken'],this['refreshToken']=_0x1f84b2['refreshToken'],this['expirationTime']=_0x1f84b2['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x1184df,_0x4685b3){m(typeof _0x1184df=='string'||typeof _0x1184df>'u','internal-error',{'appName':_0x4685b3});}class K{constructor({uid:_0x16bace,auth:_0x5becb8,stsTokenManager:_0x14913e,..._0xb32799}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x16bace,this['auth']=_0x5becb8,this['stsTokenManager']=_0x14913e,this['accessToken']=_0x14913e['accessToken'],this['displayName']=_0xb32799['displayName']||null,this['email']=_0xb32799['email']||null,this['emailVerified']=_0xb32799['emailVerified']||!0x1,this['phoneNumber']=_0xb32799['phoneNumber']||null,this['photoURL']=_0xb32799['photoURL']||null,this['isAnonymous']=_0xb32799['isAnonymous']||!0x1,this['tenantId']=_0xb32799['tenantId']||null,this['providerData']=_0xb32799['providerData']?[..._0xb32799['providerData']]:[],this['metadata']=new Oi(_0xb32799['createdAt']||void 0x0,_0xb32799['lastLoginAt']||void 0x0);}async['getIdToken'](_0x2b0fcb){const _0x17f703=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x2b0fcb));return m(_0x17f703,this['auth'],'internal-error'),this['accessToken']!==_0x17f703&&(this['accessToken']=_0x17f703,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x17f703;}['getIdTokenResult'](_0x75abf2){return gf(this,_0x75abf2);}['reload'](){return vf(this);}['_assign'](_0x5b12b3){this!==_0x5b12b3&&(m(this['uid']===_0x5b12b3['uid'],this['auth'],'internal-error'),this['displayName']=_0x5b12b3['displayName'],this['photoURL']=_0x5b12b3['photoURL'],this['email']=_0x5b12b3['email'],this['emailVerified']=_0x5b12b3['emailVerified'],this['phoneNumber']=_0x5b12b3['phoneNumber'],this['isAnonymous']=_0x5b12b3['isAnonymous'],this['tenantId']=_0x5b12b3['tenantId'],this['providerData']=_0x5b12b3['providerData']['map'](_0x5aa18b=>({..._0x5aa18b})),this['metadata']['_copy'](_0x5b12b3['metadata']),this['stsTokenManager']['_assign'](_0x5b12b3['stsTokenManager']));}['_clone'](_0x7dc2bb){const _0x5f1eeb=new K({...this,'auth':_0x7dc2bb,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x5f1eeb['metadata']['_copy'](this['metadata']),_0x5f1eeb;}['_onReload'](_0x167d3a){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x167d3a,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x2c2fa8){this['reloadListener']?this['reloadListener'](_0x2c2fa8):this['reloadUserInfo']=_0x2c2fa8;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x12a362,_0x22dae8=!0x1){let _0x1d8a6d=!0x1;_0x12a362['idToken']&&_0x12a362['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x12a362),_0x1d8a6d=!0x0),_0x22dae8&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x1d8a6d&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x5f20a7=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x5f20a7})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x3b316a=>({..._0x3b316a})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x30c1de,_0x4227b2){const _0x281bac=_0x4227b2['displayName']??void 0x0,_0x4cb26d=_0x4227b2['email']??void 0x0,_0x112ec3=_0x4227b2['phoneNumber']??void 0x0,_0xdbcd9=_0x4227b2['photoURL']??void 0x0,_0x73fed7=_0x4227b2['tenantId']??void 0x0,_0x2abe23=_0x4227b2['_redirectEventId']??void 0x0,_0x50c221=_0x4227b2['createdAt']??void 0x0,_0x29153c=_0x4227b2['lastLoginAt']??void 0x0,{uid:_0x11f57b,emailVerified:_0x52ed3a,isAnonymous:_0xd1a7f8,providerData:_0x592f3b,stsTokenManager:_0x30ff0b}=_0x4227b2;m(_0x11f57b&&_0x30ff0b,_0x30c1de,'internal-error');const _0x3adab9=Qe['fromJSON'](this['name'],_0x30ff0b);m(typeof _0x11f57b=='string',_0x30c1de,'internal-error'),le(_0x281bac,_0x30c1de['name']),le(_0x4cb26d,_0x30c1de['name']),m(typeof _0x52ed3a=='boolean',_0x30c1de,'internal-error'),m(typeof _0xd1a7f8=='boolean',_0x30c1de,'internal-error'),le(_0x112ec3,_0x30c1de['name']),le(_0xdbcd9,_0x30c1de['name']),le(_0x73fed7,_0x30c1de['name']),le(_0x2abe23,_0x30c1de['name']),le(_0x50c221,_0x30c1de['name']),le(_0x29153c,_0x30c1de['name']);const _0x4b2a56=new K({'uid':_0x11f57b,'auth':_0x30c1de,'email':_0x4cb26d,'emailVerified':_0x52ed3a,'displayName':_0x281bac,'isAnonymous':_0xd1a7f8,'photoURL':_0xdbcd9,'phoneNumber':_0x112ec3,'tenantId':_0x73fed7,'stsTokenManager':_0x3adab9,'createdAt':_0x50c221,'lastLoginAt':_0x29153c});return _0x592f3b&&Array['isArray'](_0x592f3b)&&(_0x4b2a56['providerData']=_0x592f3b['map'](_0x3691eb=>({..._0x3691eb}))),_0x2abe23&&(_0x4b2a56['_redirectEventId']=_0x2abe23),_0x4b2a56;}static async['_fromIdTokenResponse'](_0x784a89,_0x3b53af,_0x5b6ab1=!0x1){const _0x4a7b1e=new Qe();_0x4a7b1e['updateFromServerResponse'](_0x3b53af);const _0x5654a9=new K({'uid':_0x3b53af['localId'],'auth':_0x784a89,'stsTokenManager':_0x4a7b1e,'isAnonymous':_0x5b6ab1});return await Rn(_0x5654a9),_0x5654a9;}static async['_fromGetAccountInfoResponse'](_0x5a4ac8,_0x3d2cfc,_0x385c81){const _0xb14403=_0x3d2cfc['users'][0x0];m(_0xb14403['localId']!==void 0x0,'internal-error');const _0x2ba981=_0xb14403['providerUserInfo']!==void 0x0?Sa(_0xb14403['providerUserInfo']):[],_0x5e687c=!(_0xb14403['email']&&_0xb14403['passwordHash'])&&!(_0x2ba981!=null&&_0x2ba981['length']),_0x36bb65=new Qe();_0x36bb65['updateFromIdToken'](_0x385c81);const _0x1d32d0=new K({'uid':_0xb14403['localId'],'auth':_0x5a4ac8,'stsTokenManager':_0x36bb65,'isAnonymous':_0x5e687c}),_0x3a0f79={'uid':_0xb14403['localId'],'displayName':_0xb14403['displayName']||null,'photoURL':_0xb14403['photoUrl']||null,'email':_0xb14403['email']||null,'emailVerified':_0xb14403['emailVerified']||!0x1,'phoneNumber':_0xb14403['phoneNumber']||null,'tenantId':_0xb14403['tenantId']||null,'providerData':_0x2ba981,'metadata':new Oi(_0xb14403['createdAt'],_0xb14403['lastLoginAt']),'isAnonymous':!(_0xb14403['email']&&_0xb14403['passwordHash'])&&!(_0x2ba981!=null&&_0x2ba981['length'])};return Object['assign'](_0x1d32d0,_0x3a0f79),_0x1d32d0;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x26d898){ce(_0x26d898 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x487b0f=Tr['get'](_0x26d898);return _0x487b0f?(ce(_0x487b0f instanceof _0x26d898,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x487b0f):(_0x487b0f=new _0x26d898(),Tr['set'](_0x26d898,_0x487b0f),_0x487b0f);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x11239b,_0x118d7c){this['storage'][_0x11239b]=_0x118d7c;}async['_get'](_0x24491d){const _0x28d982=this['storage'][_0x24491d];return _0x28d982===void 0x0?null:_0x28d982;}async['_remove'](_0x378b1d){delete this['storage'][_0x378b1d];}['_addListener'](_0x9fc135,_0x3cc761){}['_removeListener'](_0x22ed8b,_0xc52055){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x1844af,_0x44d74a,_0x6ff33e){return'firebase:'+_0x1844af+':'+_0x44d74a+':'+_0x6ff33e;}class Je{constructor(_0x3668a6,_0x3d7169,_0xf5fc9f){this['persistence']=_0x3668a6,this['auth']=_0x3d7169,this['userKey']=_0xf5fc9f;const {config:_0x4f6657,name:_0x218e51}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x4f6657['apiKey'],_0x218e51),this['fullPersistenceKey']=rn('persistence',_0x4f6657['apiKey'],_0x218e51),this['boundEventHandler']=_0x3d7169['_onStorageEvent']['bind'](_0x3d7169),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0xa7c0b9){return this['persistence']['_set'](this['fullUserKey'],_0xa7c0b9['toJSON']());}async['getCurrentUser'](){const _0x12e14b=await this['persistence']['_get'](this['fullUserKey']);if(!_0x12e14b)return null;if(typeof _0x12e14b=='string'){const _0x406714=await bn(this['auth'],{'idToken':_0x12e14b})['catch'](()=>{});return _0x406714?K['_fromGetAccountInfoResponse'](this['auth'],_0x406714,_0x12e14b):null;}return K['_fromJSON'](this['auth'],_0x12e14b);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x280af2){if(this['persistence']===_0x280af2)return;const _0x5efa5f=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x280af2,_0x5efa5f)return this['setCurrentUser'](_0x5efa5f);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x4726f8,_0x4fdad4,_0x2877c2='authUser'){if(!_0x4fdad4['length'])return new Je(ie(Sr),_0x4726f8,_0x2877c2);const _0x368fbe=(await Promise['all'](_0x4fdad4['map'](async _0x5bc6e=>{if(await _0x5bc6e['_isAvailable']())return _0x5bc6e;})))['filter'](_0x833738=>_0x833738);let _0x2aac96=_0x368fbe[0x0]||ie(Sr);const _0x2b97f0=rn(_0x2877c2,_0x4726f8['config']['apiKey'],_0x4726f8['name']);let _0x1b8353=null;for(const _0x23722c of _0x4fdad4)try{const _0x41f5f5=await _0x23722c['_get'](_0x2b97f0);if(_0x41f5f5){let _0x1bb044;if(typeof _0x41f5f5=='string'){const _0x3e05f7=await bn(_0x4726f8,{'idToken':_0x41f5f5})['catch'](()=>{});if(!_0x3e05f7)break;_0x1bb044=await K['_fromGetAccountInfoResponse'](_0x4726f8,_0x3e05f7,_0x41f5f5);}else _0x1bb044=K['_fromJSON'](_0x4726f8,_0x41f5f5);_0x23722c!==_0x2aac96&&(_0x1b8353=_0x1bb044),_0x2aac96=_0x23722c;break;}}catch{}const _0x4acfb2=_0x368fbe['filter'](_0x38f519=>_0x38f519['_shouldAllowMigration']);return!_0x2aac96['_shouldAllowMigration']||!_0x4acfb2['length']?new Je(_0x2aac96,_0x4726f8,_0x2877c2):(_0x2aac96=_0x4acfb2[0x0],_0x1b8353&&await _0x2aac96['_set'](_0x2b97f0,_0x1b8353['toJSON']()),await Promise['all'](_0x4fdad4['map'](async _0x17e249=>{if(_0x17e249!==_0x2aac96)try{await _0x17e249['_remove'](_0x2b97f0);}catch{}})),new Je(_0x2aac96,_0x4726f8,_0x2877c2));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x3195df){const _0x23580f=_0x3195df['toLowerCase']();if(_0x23580f['includes']('opera/')||_0x23580f['includes']('opr/')||_0x23580f['includes']('opios/'))return'Opera';if(Na(_0x23580f))return'IEMobile';if(_0x23580f['includes']('msie')||_0x23580f['includes']('trident/'))return'IE';if(_0x23580f['includes']('edge/'))return'Edge';if(Ra(_0x23580f))return'Firefox';if(_0x23580f['includes']('silk/'))return'Silk';if(Oa(_0x23580f))return'Blackberry';if(Da(_0x23580f))return'Webos';if(Aa(_0x23580f))return'Safari';if((_0x23580f['includes']('chrome/')||ka(_0x23580f))&&!_0x23580f['includes']('edge/'))return'Chrome';if(Pa(_0x23580f))return'Android';{const _0x20b532=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x37994a=_0x3195df['match'](_0x20b532);if((_0x37994a==null?void 0x0:_0x37994a['length'])===0x2)return _0x37994a[0x1];}return'Other';}function Ra(_0x1fd084=W()){return/firefox\//i['test'](_0x1fd084);}function Aa(_0x410f9e=W()){const _0x1031d7=_0x410f9e['toLowerCase']();return _0x1031d7['includes']('safari/')&&!_0x1031d7['includes']('chrome/')&&!_0x1031d7['includes']('crios/')&&!_0x1031d7['includes']('android');}function ka(_0x4461cd=W()){return/crios\//i['test'](_0x4461cd);}function Na(_0x16a6d3=W()){return/iemobile/i['test'](_0x16a6d3);}function Pa(_0x404429=W()){return/android/i['test'](_0x404429);}function Oa(_0x54e5d7=W()){return/blackberry/i['test'](_0x54e5d7);}function Da(_0x2c0d15=W()){return/webos/i['test'](_0x2c0d15);}function Ss(_0x36870f=W()){return/iphone|ipad|ipod/i['test'](_0x36870f)||/macintosh/i['test'](_0x36870f)&&/mobile/i['test'](_0x36870f);}function Cf(_0x8b3f8e=W()){var _0x20aeb0;return Ss(_0x8b3f8e)&&!!((_0x20aeb0=window['navigator'])!=null&&_0x20aeb0['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x10a645=W()){return Ss(_0x10a645)||Pa(_0x10a645)||Da(_0x10a645)||Oa(_0x10a645)||/windows phone/i['test'](_0x10a645)||Na(_0x10a645);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x33bd0c,_0x40b4b7=[]){let _0x5ba23d;switch(_0x33bd0c){case'Browser':_0x5ba23d=br(W());break;case'Worker':_0x5ba23d=br(W())+'-'+_0x33bd0c;break;default:_0x5ba23d=_0x33bd0c;}const _0x35bd81=_0x40b4b7['length']?_0x40b4b7['join'](','):'FirebaseCore-web';return _0x5ba23d+'/JsCore/'+lt+'/'+_0x35bd81;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x28e8c6){this['auth']=_0x28e8c6,this['queue']=[];}['pushCallback'](_0x95304a,_0x46e78c){const _0x5e23a5=_0xf741d0=>new Promise((_0x6dbdbe,_0xaef0f6)=>{try{const _0x4c9f67=_0x95304a(_0xf741d0);_0x6dbdbe(_0x4c9f67);}catch(_0x43e4b1){_0xaef0f6(_0x43e4b1);}});_0x5e23a5['onAbort']=_0x46e78c,this['queue']['push'](_0x5e23a5);const _0x4699a2=this['queue']['length']-0x1;return()=>{this['queue'][_0x4699a2]=()=>Promise['resolve']();};}async['runMiddleware'](_0x3ae1ed){if(this['auth']['currentUser']===_0x3ae1ed)return;const _0x1c61be=[];try{for(const _0x2151d6 of this['queue'])await _0x2151d6(_0x3ae1ed),_0x2151d6['onAbort']&&_0x1c61be['push'](_0x2151d6['onAbort']);}catch(_0x236e3c){_0x1c61be['reverse']();for(const _0x1aa6b4 of _0x1c61be)try{_0x1aa6b4();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x236e3c==null?void 0x0:_0x236e3c['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0xaee076,_0x5d5fbe={}){return Ae(_0xaee076,'GET','/v2/passwordPolicy',Re(_0xaee076,_0x5d5fbe));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x4708af){var _0x344d7e;const _0x33d076=_0x4708af['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x33d076['minPasswordLength']??Rf,_0x33d076['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x33d076['maxPasswordLength']),_0x33d076['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x33d076['containsLowercaseCharacter']),_0x33d076['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x33d076['containsUppercaseCharacter']),_0x33d076['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x33d076['containsNumericCharacter']),_0x33d076['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x33d076['containsNonAlphanumericCharacter']),this['enforcementState']=_0x4708af['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x344d7e=_0x4708af['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x344d7e['join'](''))??'',this['forceUpgradeOnSignin']=_0x4708af['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x4708af['schemaVersion'];}['validatePassword'](_0x1b02d2){const _0x199fb7={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x1b02d2,_0x199fb7),this['validatePasswordCharacterOptions'](_0x1b02d2,_0x199fb7),_0x199fb7['isValid']&&(_0x199fb7['isValid']=_0x199fb7['meetsMinPasswordLength']??!0x0),_0x199fb7['isValid']&&(_0x199fb7['isValid']=_0x199fb7['meetsMaxPasswordLength']??!0x0),_0x199fb7['isValid']&&(_0x199fb7['isValid']=_0x199fb7['containsLowercaseLetter']??!0x0),_0x199fb7['isValid']&&(_0x199fb7['isValid']=_0x199fb7['containsUppercaseLetter']??!0x0),_0x199fb7['isValid']&&(_0x199fb7['isValid']=_0x199fb7['containsNumericCharacter']??!0x0),_0x199fb7['isValid']&&(_0x199fb7['isValid']=_0x199fb7['containsNonAlphanumericCharacter']??!0x0),_0x199fb7;}['validatePasswordLengthOptions'](_0x4d275c,_0x505a4d){const _0xb5e0be=this['customStrengthOptions']['minPasswordLength'],_0x534e86=this['customStrengthOptions']['maxPasswordLength'];_0xb5e0be&&(_0x505a4d['meetsMinPasswordLength']=_0x4d275c['length']>=_0xb5e0be),_0x534e86&&(_0x505a4d['meetsMaxPasswordLength']=_0x4d275c['length']<=_0x534e86);}['validatePasswordCharacterOptions'](_0x303843,_0x343a46){this['updatePasswordCharacterOptionsStatuses'](_0x343a46,!0x1,!0x1,!0x1,!0x1);let _0x4f01ac;for(let _0x2c8cfc=0x0;_0x2c8cfc<_0x303843['length'];_0x2c8cfc++)_0x4f01ac=_0x303843['charAt'](_0x2c8cfc),this['updatePasswordCharacterOptionsStatuses'](_0x343a46,_0x4f01ac>='a'&&_0x4f01ac<='z',_0x4f01ac>='A'&&_0x4f01ac<='Z',_0x4f01ac>='0'&&_0x4f01ac<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x4f01ac));}['updatePasswordCharacterOptionsStatuses'](_0x123ae7,_0x19cd30,_0x22427b,_0x57b318,_0x3b3c0d){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x123ae7['containsLowercaseLetter']||(_0x123ae7['containsLowercaseLetter']=_0x19cd30)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x123ae7['containsUppercaseLetter']||(_0x123ae7['containsUppercaseLetter']=_0x22427b)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x123ae7['containsNumericCharacter']||(_0x123ae7['containsNumericCharacter']=_0x57b318)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x123ae7['containsNonAlphanumericCharacter']||(_0x123ae7['containsNonAlphanumericCharacter']=_0x3b3c0d));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x25f1c5,_0x3ed3c2,_0x1af27d,_0x1aa0fa){this['app']=_0x25f1c5,this['heartbeatServiceProvider']=_0x3ed3c2,this['appCheckServiceProvider']=_0x1af27d,this['config']=_0x1aa0fa,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x25f1c5['name'],this['clientVersion']=_0x1aa0fa['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x24101f=>this['_resolvePersistenceManagerAvailable']=_0x24101f);}['_initializeWithPersistence'](_0x5e478c,_0x388c36){return _0x388c36&&(this['_popupRedirectResolver']=ie(_0x388c36)),this['_initializationPromise']=this['queue'](async()=>{var _0x2675c7,_0x56ef62,_0x42f51c;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x5e478c),(_0x2675c7=this['_resolvePersistenceManagerAvailable'])==null||_0x2675c7['call'](this),!this['_deleted'])){if((_0x56ef62=this['_popupRedirectResolver'])!=null&&_0x56ef62['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x388c36),this['lastNotifiedUid']=((_0x42f51c=this['currentUser'])==null?void 0x0:_0x42f51c['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x2d1f40=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x2d1f40)){if(this['currentUser']&&_0x2d1f40&&this['currentUser']['uid']===_0x2d1f40['uid']){this['_currentUser']['_assign'](_0x2d1f40),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x2d1f40,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x197794){try{const _0x2a4863=await bn(this,{'idToken':_0x197794}),_0xb2f6ca=await K['_fromGetAccountInfoResponse'](this,_0x2a4863,_0x197794);await this['directlySetCurrentUser'](_0xb2f6ca);}catch(_0x503070){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x503070),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x44df64){var _0xd65ee3;if($(this['app'])){const _0x177453=this['app']['settings']['authIdToken'];return _0x177453?new Promise(_0x276118=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x177453)['then'](_0x276118,_0x276118));}):this['directlySetCurrentUser'](null);}const _0x1b2683=await this['assertedPersistence']['getCurrentUser']();let _0x649d43=_0x1b2683,_0x54d730=!0x1;if(_0x44df64&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x31730f=(_0xd65ee3=this['redirectUser'])==null?void 0x0:_0xd65ee3['_redirectEventId'],_0x3d3137=_0x649d43==null?void 0x0:_0x649d43['_redirectEventId'],_0x5b6091=await this['tryRedirectSignIn'](_0x44df64);(!_0x31730f||_0x31730f===_0x3d3137)&&(_0x5b6091!=null&&_0x5b6091['user'])&&(_0x649d43=_0x5b6091['user'],_0x54d730=!0x0);}if(!_0x649d43)return this['directlySetCurrentUser'](null);if(!_0x649d43['_redirectEventId']){if(_0x54d730)try{await this['beforeStateQueue']['runMiddleware'](_0x649d43);}catch(_0x340b2d){_0x649d43=_0x1b2683,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x340b2d));}return _0x649d43?this['reloadAndSetCurrentUserOrClear'](_0x649d43):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x649d43['_redirectEventId']?this['directlySetCurrentUser'](_0x649d43):this['reloadAndSetCurrentUserOrClear'](_0x649d43);}async['tryRedirectSignIn'](_0x4059a8){let _0x3ddc62=null;try{_0x3ddc62=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x4059a8,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x3ddc62;}async['reloadAndSetCurrentUserOrClear'](_0x226d9c){try{await Rn(_0x226d9c);}catch(_0x21e346){if((_0x21e346==null?void 0x0:_0x21e346['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x226d9c);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x2a53b2){if($(this['app']))return Promise['reject'](re(this));const _0x4d7919=_0x2a53b2?N(_0x2a53b2):null;return _0x4d7919&&m(_0x4d7919['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x4d7919&&_0x4d7919['_clone'](this));}async['_updateCurrentUser'](_0x51ee33,_0x5c620a=!0x1){if(!this['_deleted'])return _0x51ee33&&m(this['tenantId']===_0x51ee33['tenantId'],this,'tenant-id-mismatch'),_0x5c620a||await this['beforeStateQueue']['runMiddleware'](_0x51ee33),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x51ee33),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0xf1df0c){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0xf1df0c));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x283871){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x223a5b=this['_getPasswordPolicyInternal']();return _0x223a5b['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x223a5b['validatePassword'](_0x283871);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x4bae07=await bf(this),_0x407394=new Af(_0x4bae07);this['tenantId']===null?this['_projectPasswordPolicy']=_0x407394:this['_tenantPasswordPolicies'][this['tenantId']]=_0x407394;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x54d307){this['_errorFactory']=new Bt('auth','Firebase',_0x54d307());}['onAuthStateChanged'](_0x4f15e6,_0x1143bf,_0x56e3f8){return this['registerStateListener'](this['authStateSubscription'],_0x4f15e6,_0x1143bf,_0x56e3f8);}['beforeAuthStateChanged'](_0x58185a,_0x192ba3){return this['beforeStateQueue']['pushCallback'](_0x58185a,_0x192ba3);}['onIdTokenChanged'](_0x4715dd,_0xef117a,_0x27f6d7){return this['registerStateListener'](this['idTokenSubscription'],_0x4715dd,_0xef117a,_0x27f6d7);}['authStateReady'](){return new Promise((_0x445937,_0x18b858)=>{if(this['currentUser'])_0x445937();else{const _0x5e0752=this['onAuthStateChanged'](()=>{_0x5e0752(),_0x445937();},_0x18b858);}});}async['revokeAccessToken'](_0x1e34cd){if(this['currentUser']){const _0x13bb30=await this['currentUser']['getIdToken'](),_0x5a1174={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x1e34cd,'idToken':_0x13bb30};this['tenantId']!=null&&(_0x5a1174['tenantId']=this['tenantId']),await wf(this,_0x5a1174);}}['toJSON'](){var _0x5bbf79;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x5bbf79=this['_currentUser'])==null?void 0x0:_0x5bbf79['toJSON']()};}async['_setRedirectUser'](_0x54d767,_0x67f3c6){const _0x76e3c3=await this['getOrInitRedirectPersistenceManager'](_0x67f3c6);return _0x54d767===null?_0x76e3c3['removeCurrentUser']():_0x76e3c3['setCurrentUser'](_0x54d767);}async['getOrInitRedirectPersistenceManager'](_0x2f7ff5){if(!this['redirectPersistenceManager']){const _0x134e73=_0x2f7ff5&&ie(_0x2f7ff5)||this['_popupRedirectResolver'];m(_0x134e73,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x134e73['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x13283f){var _0x2566d3,_0x6088b1;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x2566d3=this['_currentUser'])==null?void 0x0:_0x2566d3['_redirectEventId'])===_0x13283f?this['_currentUser']:((_0x6088b1=this['redirectUser'])==null?void 0x0:_0x6088b1['_redirectEventId'])===_0x13283f?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2c0e6a){if(_0x2c0e6a===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2c0e6a));}['_notifyListenersIfCurrent'](_0x221d57){_0x221d57===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x49dc3e;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x4d1101=((_0x49dc3e=this['currentUser'])==null?void 0x0:_0x49dc3e['uid'])??null;this['lastNotifiedUid']!==_0x4d1101&&(this['lastNotifiedUid']=_0x4d1101,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x26b616,_0x128944,_0x46d77c,_0x2df8b9){if(this['_deleted'])return()=>{};const _0x56ba60=typeof _0x128944=='function'?_0x128944:_0x128944['next']['bind'](_0x128944);let _0x39cf20=!0x1;const _0x5b80d0=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x5b80d0,this,'internal-error'),_0x5b80d0['then'](()=>{_0x39cf20||_0x56ba60(this['currentUser']);}),typeof _0x128944=='function'){const _0x543ef7=_0x26b616['addObserver'](_0x128944,_0x46d77c,_0x2df8b9);return()=>{_0x39cf20=!0x0,_0x543ef7();};}else{const _0xe0bbfa=_0x26b616['addObserver'](_0x128944);return()=>{_0x39cf20=!0x0,_0xe0bbfa();};}}async['directlySetCurrentUser'](_0x217d7f){this['currentUser']&&this['currentUser']!==_0x217d7f&&this['_currentUser']['_stopProactiveRefresh'](),_0x217d7f&&this['isProactiveRefreshEnabled']&&_0x217d7f['_startProactiveRefresh'](),this['currentUser']=_0x217d7f,_0x217d7f?await this['assertedPersistence']['setCurrentUser'](_0x217d7f):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x4647){return this['operations']=this['operations']['then'](_0x4647,_0x4647),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4a6897){!_0x4a6897||this['frameworks']['includes'](_0x4a6897)||(this['frameworks']['push'](_0x4a6897),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x32adb0;const _0x18c499={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x18c499['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x1d1253=await((_0x32adb0=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x32adb0['getHeartbeatsHeader']());_0x1d1253&&(_0x18c499['X-Firebase-Client']=_0x1d1253);const _0x72cabe=await this['_getAppCheckToken']();return _0x72cabe&&(_0x18c499['X-Firebase-AppCheck']=_0x72cabe),_0x18c499;}async['_getAppCheckToken'](){var _0x3ede34;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x3c4bd6=await((_0x3ede34=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x3ede34['getToken']());return _0x3c4bd6!=null&&_0x3c4bd6['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x3c4bd6['error']),_0x3c4bd6==null?void 0x0:_0x3c4bd6['token'];}}function qe(_0xabf960){return N(_0xabf960);}class Rr{constructor(_0x379b9c){this['auth']=_0x379b9c,this['observer']=null,this['addObserver']=Tc(_0x11b9b8=>this['observer']=_0x11b9b8);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x1d3575){jn=_0x1d3575;}function xa(_0x32e8ba){return jn['loadJS'](_0x32e8ba);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x354bed){return'__'+_0x354bed+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x4fe331){_0x4fe331();}['execute'](_0x58bbe7,_0x4f11c2){return Promise['resolve']('token');}['render'](_0x9a8581,_0x4a2eeb){return'';}}class Lf{['ready'](_0x5e0c81){_0x5e0c81();}['execute'](_0x460219,_0x46c88e){return Promise['resolve']('token');}['render'](_0x454bc7,_0x1ec615){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0xd4f53a){this['type']=xf,this['auth']=qe(_0xd4f53a);}async['verify'](_0x509a6d='verify',_0x59942b=!0x1){async function _0x4beeed(_0x4c72e5){if(!_0x59942b){if(_0x4c72e5['tenantId']==null&&_0x4c72e5['_agentRecaptchaConfig']!=null)return _0x4c72e5['_agentRecaptchaConfig']['siteKey'];if(_0x4c72e5['tenantId']!=null&&_0x4c72e5['_tenantRecaptchaConfigs'][_0x4c72e5['tenantId']]!==void 0x0)return _0x4c72e5['_tenantRecaptchaConfigs'][_0x4c72e5['tenantId']]['siteKey'];}return new Promise(async(_0x1b7bd6,_0x5a0519)=>{pf(_0x4c72e5,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x433423=>{if(_0x433423['recaptchaKey']===void 0x0)_0x5a0519(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x15d0b4=new ff(_0x433423);return _0x4c72e5['tenantId']==null?_0x4c72e5['_agentRecaptchaConfig']=_0x15d0b4:_0x4c72e5['_tenantRecaptchaConfigs'][_0x4c72e5['tenantId']]=_0x15d0b4,_0x1b7bd6(_0x15d0b4['siteKey']);}})['catch'](_0x513707=>{_0x5a0519(_0x513707);});});}function _0x3ce719(_0x5ec7de,_0x3778d3,_0x28b6db){const _0x39ce9d=window['grecaptcha'];wr(_0x39ce9d)?_0x39ce9d['enterprise']['ready'](()=>{_0x39ce9d['enterprise']['execute'](_0x5ec7de,{'action':_0x509a6d})['then'](_0x8a68b7=>{_0x3778d3(_0x8a68b7);})['catch'](()=>{_0x3778d3(Fa);});}):_0x28b6db(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x4ac604,_0x2689f5)=>{_0x4beeed(this['auth'])['then'](_0x567e8c=>{if(!_0x59942b&&wr(window['grecaptcha']))_0x3ce719(_0x567e8c,_0x4ac604,_0x2689f5);else{if(typeof window>'u'){_0x2689f5(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x276a40=Pf();_0x276a40['length']!==0x0&&(_0x276a40+=_0x567e8c),xa(_0x276a40)['then'](()=>{_0x3ce719(_0x567e8c,_0x4ac604,_0x2689f5);})['catch'](_0x350d5a=>{_0x2689f5(_0x350d5a);});}})['catch'](_0x5bca36=>{_0x2689f5(_0x5bca36);});});}}async function Ar(_0x3c3bbf,_0x2f797d,_0x8ea6dd,_0x32a0c4=!0x1,_0x15a170=!0x1){const _0x4eea5f=new Ff(_0x3c3bbf);let _0x566102;if(_0x15a170)_0x566102=Fa;else try{_0x566102=await _0x4eea5f['verify'](_0x8ea6dd);}catch{_0x566102=await _0x4eea5f['verify'](_0x8ea6dd,!0x0);}const _0x15fb8a={..._0x2f797d};if(_0x8ea6dd==='mfaSmsEnrollment'||_0x8ea6dd==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x15fb8a){const _0x3e613c=_0x15fb8a['phoneEnrollmentInfo']['phoneNumber'],_0x2cf3d8=_0x15fb8a['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x15fb8a,{'phoneEnrollmentInfo':{'phoneNumber':_0x3e613c,'recaptchaToken':_0x2cf3d8,'captchaResponse':_0x566102,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x15fb8a){const _0x591c15=_0x15fb8a['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x15fb8a,{'phoneSignInInfo':{'recaptchaToken':_0x591c15,'captchaResponse':_0x566102,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x15fb8a;}return _0x32a0c4?Object['assign'](_0x15fb8a,{'captchaResp':_0x566102}):Object['assign'](_0x15fb8a,{'captchaResponse':_0x566102}),Object['assign'](_0x15fb8a,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x15fb8a,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x15fb8a;}async function Di(_0x57ddfd,_0x36709e,_0x47be35,_0x2012e2,_0x2f3e5a){var _0x5492a6;if((_0x5492a6=_0x57ddfd['_getRecaptchaConfig']())!=null&&_0x5492a6['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x331922=await Ar(_0x57ddfd,_0x36709e,_0x47be35,_0x47be35==='getOobCode');return _0x2012e2(_0x57ddfd,_0x331922);}else return _0x2012e2(_0x57ddfd,_0x36709e)['catch'](async _0x341486=>{if(_0x341486['code']==='auth/missing-recaptcha-token'){console['log'](_0x47be35+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x4440c9=await Ar(_0x57ddfd,_0x36709e,_0x47be35,_0x47be35==='getOobCode');return _0x2012e2(_0x57ddfd,_0x4440c9);}else return Promise['reject'](_0x341486);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x3ffe94,_0x14e917){const _0x44552d=Bi(_0x3ffe94,'auth');if(_0x44552d['isInitialized']()){const _0x34be23=_0x44552d['getImmediate'](),_0x342021=_0x44552d['getOptions']();if(Me(_0x342021,_0x14e917??{}))return _0x34be23;Q(_0x34be23,'already-initialized');}return _0x44552d['initialize']({'options':_0x14e917});}function Wf(_0x3465d9,_0x1e323d){const _0x57e16e=(_0x1e323d==null?void 0x0:_0x1e323d['persistence'])||[],_0x463e32=(Array['isArray'](_0x57e16e)?_0x57e16e:[_0x57e16e])['map'](ie);_0x1e323d!=null&&_0x1e323d['errorMap']&&_0x3465d9['_updateErrorMap'](_0x1e323d['errorMap']),_0x3465d9['_initializeWithPersistence'](_0x463e32,_0x1e323d==null?void 0x0:_0x1e323d['popupRedirectResolver']);}function Bf(_0x5f51fb,_0x2ed007,_0xf9e135){const _0xce4b07=qe(_0x5f51fb);m(/^https?:\/\//['test'](_0x2ed007),_0xce4b07,'invalid-emulator-scheme');const _0x235df8=!0x1,_0x152244=Ua(_0x2ed007),{host:_0x1a4ae5,port:_0x855e04}=Vf(_0x2ed007),_0x81c4f6=_0x855e04===null?'':':'+_0x855e04,_0x13a7b0={'url':_0x152244+'//'+_0x1a4ae5+_0x81c4f6+'/'},_0x1fb839=Object['freeze']({'host':_0x1a4ae5,'port':_0x855e04,'protocol':_0x152244['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x235df8})});if(!_0xce4b07['_canInitEmulator']){m(_0xce4b07['config']['emulator']&&_0xce4b07['emulatorConfig'],_0xce4b07,'emulator-config-failed'),m(Me(_0x13a7b0,_0xce4b07['config']['emulator'])&&Me(_0x1fb839,_0xce4b07['emulatorConfig']),_0xce4b07,'emulator-config-failed');return;}_0xce4b07['config']['emulator']=_0x13a7b0,_0xce4b07['emulatorConfig']=_0x1fb839,_0xce4b07['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x1a4ae5)?(jr(_0x152244+'//'+_0x1a4ae5+_0x81c4f6),Kr('Auth',!0x0)):Hf();}function Ua(_0x5d5b17){const _0x514659=_0x5d5b17['indexOf'](':');return _0x514659<0x0?'':_0x5d5b17['substr'](0x0,_0x514659+0x1);}function Vf(_0x3b7a0a){const _0x3d5922=Ua(_0x3b7a0a),_0x202a1c=/(\/\/)?([^?#/]+)/['exec'](_0x3b7a0a['substr'](_0x3d5922['length']));if(!_0x202a1c)return{'host':'','port':null};const _0x3c1a87=_0x202a1c[0x2]['split']('@')['pop']()||'',_0x2d333a=/^(\[[^\]]+\])(:|$)/['exec'](_0x3c1a87);if(_0x2d333a){const _0x5e6e99=_0x2d333a[0x1];return{'host':_0x5e6e99,'port':kr(_0x3c1a87['substr'](_0x5e6e99['length']+0x1))};}else{const [_0xa314b5,_0x89466c]=_0x3c1a87['split'](':');return{'host':_0xa314b5,'port':kr(_0x89466c)};}}function kr(_0x1a03ad){if(!_0x1a03ad)return null;const _0x1c353d=Number(_0x1a03ad);return isNaN(_0x1c353d)?null:_0x1c353d;}function Hf(){function _0x510faf(){const _0x375b9a=document['createElement']('p'),_0x2e6214=_0x375b9a['style'];_0x375b9a['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x2e6214['position']='fixed',_0x2e6214['width']='100%',_0x2e6214['backgroundColor']='#ffffff',_0x2e6214['border']='.1em\x20solid\x20#000000',_0x2e6214['color']='#b50000',_0x2e6214['bottom']='0px',_0x2e6214['left']='0px',_0x2e6214['margin']='0px',_0x2e6214['zIndex']='10000',_0x2e6214['textAlign']='center',_0x375b9a['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x375b9a);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x510faf):_0x510faf());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x37f2a8,_0x291949){this['providerId']=_0x37f2a8,this['signInMethod']=_0x291949;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x3644fe){return ne('not\x20implemented');}['_linkToIdToken'](_0x12cfee,_0x599984){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x6ee79c){return ne('not\x20implemented');}}async function $f(_0x449717,_0x1e0911){return Ae(_0x449717,'POST','/v1/accounts:signUp',_0x1e0911);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x3eb707,_0x1b8fce){return Qt(_0x3eb707,'POST','/v1/accounts:signInWithPassword',Re(_0x3eb707,_0x1b8fce));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x21714a,_0x4ede9b){return Qt(_0x21714a,'POST','/v1/accounts:signInWithEmailLink',Re(_0x21714a,_0x4ede9b));}async function zf(_0x1c2136,_0x33dca0){return Qt(_0x1c2136,'POST','/v1/accounts:signInWithEmailLink',Re(_0x1c2136,_0x33dca0));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x5e2fc7,_0x5bf5e2,_0x591264,_0x52d008=null){super('password',_0x591264),this['_email']=_0x5e2fc7,this['_password']=_0x5bf5e2,this['_tenantId']=_0x52d008;}static['_fromEmailAndPassword'](_0x185035,_0x1fcd1b){return new Wt(_0x185035,_0x1fcd1b,'password');}static['_fromEmailAndCode'](_0x18441b,_0x31b43b,_0x2b9f38=null){return new Wt(_0x18441b,_0x31b43b,'emailLink',_0x2b9f38);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x192259){const _0x31e33f=typeof _0x192259=='string'?JSON['parse'](_0x192259):_0x192259;if(_0x31e33f!=null&&_0x31e33f['email']&&(_0x31e33f!=null&&_0x31e33f['password'])){if(_0x31e33f['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x31e33f['email'],_0x31e33f['password']);if(_0x31e33f['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x31e33f['email'],_0x31e33f['password'],_0x31e33f['tenantId']);}return null;}async['_getIdTokenResponse'](_0x3facb2){switch(this['signInMethod']){case'password':const _0x520efa={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x3facb2,_0x520efa,'signInWithPassword',Gf);case'emailLink':return qf(_0x3facb2,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x3facb2,'internal-error');}}async['_linkToIdToken'](_0x1475ee,_0x1a0474){switch(this['signInMethod']){case'password':const _0x1975f1={'idToken':_0x1a0474,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x1475ee,_0x1975f1,'signUpPassword',$f);case'emailLink':return zf(_0x1475ee,{'idToken':_0x1a0474,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x1475ee,'internal-error');}}['_getReauthenticationResolver'](_0x3e401f){return this['_getIdTokenResponse'](_0x3e401f);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x189714,_0x4b03b7){return Qt(_0x189714,'POST','/v1/accounts:signInWithIdp',Re(_0x189714,_0x4b03b7));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0xa8161f){const _0x2a8433=new Be(_0xa8161f['providerId'],_0xa8161f['signInMethod']);return _0xa8161f['idToken']||_0xa8161f['accessToken']?(_0xa8161f['idToken']&&(_0x2a8433['idToken']=_0xa8161f['idToken']),_0xa8161f['accessToken']&&(_0x2a8433['accessToken']=_0xa8161f['accessToken']),_0xa8161f['nonce']&&!_0xa8161f['pendingToken']&&(_0x2a8433['nonce']=_0xa8161f['nonce']),_0xa8161f['pendingToken']&&(_0x2a8433['pendingToken']=_0xa8161f['pendingToken'])):_0xa8161f['oauthToken']&&_0xa8161f['oauthTokenSecret']?(_0x2a8433['accessToken']=_0xa8161f['oauthToken'],_0x2a8433['secret']=_0xa8161f['oauthTokenSecret']):Q('argument-error'),_0x2a8433;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x223a09){const _0x6fc939=typeof _0x223a09=='string'?JSON['parse'](_0x223a09):_0x223a09,{providerId:_0x2f57a8,signInMethod:_0x33b136,..._0x1a0938}=_0x6fc939;if(!_0x2f57a8||!_0x33b136)return null;const _0x59aee1=new Be(_0x2f57a8,_0x33b136);return _0x59aee1['idToken']=_0x1a0938['idToken']||void 0x0,_0x59aee1['accessToken']=_0x1a0938['accessToken']||void 0x0,_0x59aee1['secret']=_0x1a0938['secret'],_0x59aee1['nonce']=_0x1a0938['nonce'],_0x59aee1['pendingToken']=_0x1a0938['pendingToken']||null,_0x59aee1;}['_getIdTokenResponse'](_0x3a30fc){const _0x4c1015=this['buildRequest']();return Xe(_0x3a30fc,_0x4c1015);}['_linkToIdToken'](_0x6096c,_0x28d162){const _0x2586af=this['buildRequest']();return _0x2586af['idToken']=_0x28d162,Xe(_0x6096c,_0x2586af);}['_getReauthenticationResolver'](_0xd85af7){const _0x4e60fa=this['buildRequest']();return _0x4e60fa['autoCreate']=!0x1,Xe(_0xd85af7,_0x4e60fa);}['buildRequest'](){const _0x4ceb83={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x4ceb83['pendingToken']=this['pendingToken'];else{const _0x5e511c={};this['idToken']&&(_0x5e511c['id_token']=this['idToken']),this['accessToken']&&(_0x5e511c['access_token']=this['accessToken']),this['secret']&&(_0x5e511c['oauth_token_secret']=this['secret']),_0x5e511c['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x5e511c['nonce']=this['nonce']),_0x4ceb83['postBody']=ct(_0x5e511c);}return _0x4ceb83;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x313ff9){switch(_0x313ff9){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x4b1b45){const _0x5aa57e=vt(Et(_0x4b1b45))['link'],_0x15b424=_0x5aa57e?vt(Et(_0x5aa57e))['deep_link_id']:null,_0x459a9e=vt(Et(_0x4b1b45))['deep_link_id'];return(_0x459a9e?vt(Et(_0x459a9e))['link']:null)||_0x459a9e||_0x15b424||_0x5aa57e||_0x4b1b45;}class Rs{constructor(_0x73f80){const _0x308e55=vt(Et(_0x73f80)),_0x483d7f=_0x308e55['apiKey']??null,_0x202d97=_0x308e55['oobCode']??null,_0x436204=Kf(_0x308e55['mode']??null);m(_0x483d7f&&_0x202d97&&_0x436204,'argument-error'),this['apiKey']=_0x483d7f,this['operation']=_0x436204,this['code']=_0x202d97,this['continueUrl']=_0x308e55['continueUrl']??null,this['languageCode']=_0x308e55['lang']??null,this['tenantId']=_0x308e55['tenantId']??null;}static['parseLink'](_0x5d8b64){const _0x31b507=Yf(_0x5d8b64);try{return new Rs(_0x31b507);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x3c35af,_0x1a3d2d){return Wt['_fromEmailAndPassword'](_0x3c35af,_0x1a3d2d);}static['credentialWithLink'](_0x1329c5,_0x36e47e){const _0x781598=Rs['parseLink'](_0x36e47e);return m(_0x781598,'argument-error'),Wt['_fromEmailAndCode'](_0x1329c5,_0x781598['code'],_0x781598['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x3e4ac6){this['providerId']=_0x3e4ac6,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x36009f){this['defaultLanguageCode']=_0x36009f;}['setCustomParameters'](_0x2d2a1d){return this['customParameters']=_0x2d2a1d,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x3a62dc){return this['scopes']['includes'](_0x3a62dc)||this['scopes']['push'](_0x3a62dc),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0xd47ea6){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0xd47ea6});}static['credentialFromResult'](_0x3672d1){return he['credentialFromTaggedObject'](_0x3672d1);}static['credentialFromError'](_0x260d57){return he['credentialFromTaggedObject'](_0x260d57['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x30a037}){if(!_0x30a037||!('oauthAccessToken'in _0x30a037)||!_0x30a037['oauthAccessToken'])return null;try{return he['credential'](_0x30a037['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x52a4ae,_0x43b6b2){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x52a4ae,'accessToken':_0x43b6b2});}static['credentialFromResult'](_0x4f1522){return ue['credentialFromTaggedObject'](_0x4f1522);}static['credentialFromError'](_0x30f967){return ue['credentialFromTaggedObject'](_0x30f967['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3d75e5}){if(!_0x3d75e5)return null;const {oauthIdToken:_0x1b524e,oauthAccessToken:_0xc0c0cf}=_0x3d75e5;if(!_0x1b524e&&!_0xc0c0cf)return null;try{return ue['credential'](_0x1b524e,_0xc0c0cf);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x57da91){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x57da91});}static['credentialFromResult'](_0x2e644e){return de['credentialFromTaggedObject'](_0x2e644e);}static['credentialFromError'](_0x4bd8cc){return de['credentialFromTaggedObject'](_0x4bd8cc['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x291007}){if(!_0x291007||!('oauthAccessToken'in _0x291007)||!_0x291007['oauthAccessToken'])return null;try{return de['credential'](_0x291007['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x292373,_0x535a7e){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x292373,'oauthTokenSecret':_0x535a7e});}static['credentialFromResult'](_0x572bc3){return fe['credentialFromTaggedObject'](_0x572bc3);}static['credentialFromError'](_0x504dde){return fe['credentialFromTaggedObject'](_0x504dde['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x13e85f}){if(!_0x13e85f)return null;const {oauthAccessToken:_0x4204fa,oauthTokenSecret:_0x570718}=_0x13e85f;if(!_0x4204fa||!_0x570718)return null;try{return fe['credential'](_0x4204fa,_0x570718);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x168b4d,_0x37148b){return Qt(_0x168b4d,'POST','/v1/accounts:signUp',Re(_0x168b4d,_0x37148b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0xfec925){this['user']=_0xfec925['user'],this['providerId']=_0xfec925['providerId'],this['_tokenResponse']=_0xfec925['_tokenResponse'],this['operationType']=_0xfec925['operationType'];}static async['_fromIdTokenResponse'](_0x591898,_0x25d6e0,_0x25cc75,_0x39e7c2=!0x1){const _0xdc9fd8=await K['_fromIdTokenResponse'](_0x591898,_0x25cc75,_0x39e7c2),_0x31afe9=Nr(_0x25cc75);return new Ve({'user':_0xdc9fd8,'providerId':_0x31afe9,'_tokenResponse':_0x25cc75,'operationType':_0x25d6e0});}static async['_forOperation'](_0x1b53f2,_0x4785a4,_0x1ece27){await _0x1b53f2['_updateTokensIfNecessary'](_0x1ece27,!0x0);const _0x5679e0=Nr(_0x1ece27);return new Ve({'user':_0x1b53f2,'providerId':_0x5679e0,'_tokenResponse':_0x1ece27,'operationType':_0x4785a4});}}function Nr(_0x4f628d){return _0x4f628d['providerId']?_0x4f628d['providerId']:'phoneNumber'in _0x4f628d?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0xff0d4,_0x5b8771,_0x1ab262,_0x2fe17a){super(_0x5b8771['code'],_0x5b8771['message']),this['operationType']=_0x1ab262,this['user']=_0x2fe17a,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0xff0d4['name'],'tenantId':_0xff0d4['tenantId']??void 0x0,'_serverResponse':_0x5b8771['customData']['_serverResponse'],'operationType':_0x1ab262};}static['_fromErrorAndOperation'](_0xf316e8,_0x110027,_0x42527e,_0x15debe){return new An(_0xf316e8,_0x110027,_0x42527e,_0x15debe);}}function Ba(_0x53d1dc,_0x2ccfc7,_0x2edb27,_0x24179b){return(_0x2ccfc7==='reauthenticate'?_0x2edb27['_getReauthenticationResolver'](_0x53d1dc):_0x2edb27['_getIdTokenResponse'](_0x53d1dc))['catch'](_0x5be23e=>{throw _0x5be23e['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x53d1dc,_0x5be23e,_0x2ccfc7,_0x24179b):_0x5be23e;});}async function Jf(_0x59ad1c,_0x3b9b9b,_0x26dcde=!0x1){const _0x20a4ef=await Ut(_0x59ad1c,_0x3b9b9b['_linkToIdToken'](_0x59ad1c['auth'],await _0x59ad1c['getIdToken']()),_0x26dcde);return Ve['_forOperation'](_0x59ad1c,'link',_0x20a4ef);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x3f6514,_0x3e36e3,_0x38149c=!0x1){const {auth:_0x3099dd}=_0x3f6514;if($(_0x3099dd['app']))return Promise['reject'](re(_0x3099dd));const _0x169bc5='reauthenticate';try{const _0x423dbb=await Ut(_0x3f6514,Ba(_0x3099dd,_0x169bc5,_0x3e36e3,_0x3f6514),_0x38149c);m(_0x423dbb['idToken'],_0x3099dd,'internal-error');const _0x26eff6=Ts(_0x423dbb['idToken']);m(_0x26eff6,_0x3099dd,'internal-error');const {sub:_0x221bf2}=_0x26eff6;return m(_0x3f6514['uid']===_0x221bf2,_0x3099dd,'user-mismatch'),Ve['_forOperation'](_0x3f6514,_0x169bc5,_0x423dbb);}catch(_0x1024b3){throw(_0x1024b3==null?void 0x0:_0x1024b3['code'])==='auth/user-not-found'&&Q(_0x3099dd,'user-mismatch'),_0x1024b3;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x24323d,_0x4a2af3,_0x2257af=!0x1){if($(_0x24323d['app']))return Promise['reject'](re(_0x24323d));const _0x3948f0='signIn',_0x35a14f=await Ba(_0x24323d,_0x3948f0,_0x4a2af3),_0x4792f0=await Ve['_fromIdTokenResponse'](_0x24323d,_0x3948f0,_0x35a14f);return _0x2257af||await _0x24323d['_updateCurrentUser'](_0x4792f0['user']),_0x4792f0;}async function Zf(_0x296588,_0x27166b){return Va(qe(_0x296588),_0x27166b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x20f81){const _0x161f99=qe(_0x20f81);_0x161f99['_getPasswordPolicyInternal']()&&await _0x161f99['_updatePasswordPolicy']();}async function P_(_0x3e52c3,_0x30c45a,_0x1d49fe){if($(_0x3e52c3['app']))return Promise['reject'](re(_0x3e52c3));const _0x2b549e=qe(_0x3e52c3),_0x2e2c80=await Di(_0x2b549e,{'returnSecureToken':!0x0,'email':_0x30c45a,'password':_0x1d49fe,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x165f32=>{throw _0x165f32['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x3e52c3),_0x165f32;}),_0x1a2d78=await Ve['_fromIdTokenResponse'](_0x2b549e,'signIn',_0x2e2c80);return await _0x2b549e['_updateCurrentUser'](_0x1a2d78['user']),_0x1a2d78;}function O_(_0x3e260b,_0x46c680,_0x157b90){return $(_0x3e260b['app'])?Promise['reject'](re(_0x3e260b)):Zf(N(_0x3e260b),pt['credential'](_0x46c680,_0x157b90))['catch'](async _0x59e1c3=>{throw _0x59e1c3['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x3e260b),_0x59e1c3;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0xcaa12f,_0x22d308){return N(_0xcaa12f)['setPersistence'](_0x22d308);}function ep(_0x3cc30d,_0x24406f,_0x42448d,_0xcef50e){return N(_0x3cc30d)['onIdTokenChanged'](_0x24406f,_0x42448d,_0xcef50e);}function tp(_0x2ac911,_0xfc822e,_0x326d82){return N(_0x2ac911)['beforeAuthStateChanged'](_0xfc822e,_0x326d82);}function M_(_0x16d69d,_0x5035bb,_0x248e08,_0x395017){return N(_0x16d69d)['onAuthStateChanged'](_0x5035bb,_0x248e08,_0x395017);}function L_(_0x37c004){return N(_0x37c004)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x5c4482,_0xa7c153){this['storageRetriever']=_0x5c4482,this['type']=_0xa7c153;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x39b0d8,_0x225a17){return this['storage']['setItem'](_0x39b0d8,JSON['stringify'](_0x225a17)),Promise['resolve']();}['_get'](_0x5cc4d4){const _0x11f308=this['storage']['getItem'](_0x5cc4d4);return Promise['resolve'](_0x11f308?JSON['parse'](_0x11f308):null);}['_remove'](_0x1e0799){return this['storage']['removeItem'](_0x1e0799),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x5bae75,_0x2d9a1f)=>this['onStorageEvent'](_0x5bae75,_0x2d9a1f),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x316b9c){for(const _0x698af6 of Object['keys'](this['listeners'])){const _0x140082=this['storage']['getItem'](_0x698af6),_0x451c4f=this['localCache'][_0x698af6];_0x140082!==_0x451c4f&&_0x316b9c(_0x698af6,_0x451c4f,_0x140082);}}['onStorageEvent'](_0x2fa75a,_0x5767c0=!0x1){if(!_0x2fa75a['key']){this['forAllChangedKeys']((_0x57fb93,_0x5b8c59,_0x4902d4)=>{this['notifyListeners'](_0x57fb93,_0x4902d4);});return;}const _0x391022=_0x2fa75a['key'];_0x5767c0?this['detachListener']():this['stopPolling']();const _0x1dbddc=()=>{const _0x57bec8=this['storage']['getItem'](_0x391022);!_0x5767c0&&this['localCache'][_0x391022]===_0x57bec8||this['notifyListeners'](_0x391022,_0x57bec8);},_0x4903b7=this['storage']['getItem'](_0x391022);Tf()&&_0x4903b7!==_0x2fa75a['newValue']&&_0x2fa75a['newValue']!==_0x2fa75a['oldValue']?setTimeout(_0x1dbddc,ip):_0x1dbddc();}['notifyListeners'](_0x4ebed7,_0x344406){this['localCache'][_0x4ebed7]=_0x344406;const _0x85e4bc=this['listeners'][_0x4ebed7];if(_0x85e4bc){for(const _0x5068c3 of Array['from'](_0x85e4bc))_0x5068c3(_0x344406&&JSON['parse'](_0x344406));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x225cd8,_0x2cc4da,_0x4f255)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x225cd8,'oldValue':_0x2cc4da,'newValue':_0x4f255}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x16ce3f,_0x4cc54f){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x16ce3f]||(this['listeners'][_0x16ce3f]=new Set(),this['localCache'][_0x16ce3f]=this['storage']['getItem'](_0x16ce3f)),this['listeners'][_0x16ce3f]['add'](_0x4cc54f);}['_removeListener'](_0x3dae19,_0x399dc7){this['listeners'][_0x3dae19]&&(this['listeners'][_0x3dae19]['delete'](_0x399dc7),this['listeners'][_0x3dae19]['size']===0x0&&delete this['listeners'][_0x3dae19]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x3c91b3,_0x446b8c){await super['_set'](_0x3c91b3,_0x446b8c),this['localCache'][_0x3c91b3]=JSON['stringify'](_0x446b8c);}async['_get'](_0x186f9a){const _0x2a061f=await super['_get'](_0x186f9a);return this['localCache'][_0x186f9a]=JSON['stringify'](_0x2a061f),_0x2a061f;}async['_remove'](_0x5d4031){await super['_remove'](_0x5d4031),delete this['localCache'][_0x5d4031];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x2b5ecb,_0x1b5db8){}['_removeListener'](_0x405c29,_0x32fc05){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x553511){return Promise['all'](_0x553511['map'](async _0x51f9cc=>{try{return{'fulfilled':!0x0,'value':await _0x51f9cc};}catch(_0x156525){return{'fulfilled':!0x1,'reason':_0x156525};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x46da9f){this['eventTarget']=_0x46da9f,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x3ac225){const _0x459e8c=this['receivers']['find'](_0x38cc62=>_0x38cc62['isListeningto'](_0x3ac225));if(_0x459e8c)return _0x459e8c;const _0x389ead=new Kn(_0x3ac225);return this['receivers']['push'](_0x389ead),_0x389ead;}['isListeningto'](_0x6ce80d){return this['eventTarget']===_0x6ce80d;}async['handleEvent'](_0x39c094){const _0x24562e=_0x39c094,{eventId:_0x13f3c5,eventType:_0x2af375,data:_0x467276}=_0x24562e['data'],_0x4e89a4=this['handlersMap'][_0x2af375];if(!(_0x4e89a4!=null&&_0x4e89a4['size']))return;_0x24562e['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x13f3c5,'eventType':_0x2af375});const _0x4d8e67=Array['from'](_0x4e89a4)['map'](async _0x417837=>_0x417837(_0x24562e['origin'],_0x467276)),_0x4193e6=await rp(_0x4d8e67);_0x24562e['ports'][0x0]['postMessage']({'status':'done','eventId':_0x13f3c5,'eventType':_0x2af375,'response':_0x4193e6});}['_subscribe'](_0x52de24,_0x2698a1){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x52de24]||(this['handlersMap'][_0x52de24]=new Set()),this['handlersMap'][_0x52de24]['add'](_0x2698a1);}['_unsubscribe'](_0x3fcd0a,_0x3ea3f7){this['handlersMap'][_0x3fcd0a]&&_0x3ea3f7&&this['handlersMap'][_0x3fcd0a]['delete'](_0x3ea3f7),(!_0x3ea3f7||this['handlersMap'][_0x3fcd0a]['size']===0x0)&&delete this['handlersMap'][_0x3fcd0a],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x2ee8c8='',_0x57cbfd=0xa){let _0x4a22e5='';for(let _0x4acfa0=0x0;_0x4acfa0<_0x57cbfd;_0x4acfa0++)_0x4a22e5+=Math['floor'](Math['random']()*0xa);return _0x2ee8c8+_0x4a22e5;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x64844){this['target']=_0x64844,this['handlers']=new Set();}['removeMessageHandler'](_0x5f4d01){_0x5f4d01['messageChannel']&&(_0x5f4d01['messageChannel']['port1']['removeEventListener']('message',_0x5f4d01['onMessage']),_0x5f4d01['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x5f4d01);}async['_send'](_0x1582b6,_0x13e4ca,_0x37ea22=0x32){const _0x4d8233=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4d8233)throw new Error('connection_unavailable');let _0x4c847c,_0x13ad59;return new Promise((_0x4aeb04,_0x5477e0)=>{const _0x513780=As('',0x14);_0x4d8233['port1']['start']();const _0x356956=setTimeout(()=>{_0x5477e0(new Error('unsupported_event'));},_0x37ea22);_0x13ad59={'messageChannel':_0x4d8233,'onMessage'(_0x5604e3){const _0x28568e=_0x5604e3;if(_0x28568e['data']['eventId']===_0x513780)switch(_0x28568e['data']['status']){case'ack':clearTimeout(_0x356956),_0x4c847c=setTimeout(()=>{_0x5477e0(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x4c847c),_0x4aeb04(_0x28568e['data']['response']);break;default:clearTimeout(_0x356956),clearTimeout(_0x4c847c),_0x5477e0(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x13ad59),_0x4d8233['port1']['addEventListener']('message',_0x13ad59['onMessage']),this['target']['postMessage']({'eventType':_0x1582b6,'eventId':_0x513780,'data':_0x13e4ca},[_0x4d8233['port2']]);})['finally'](()=>{_0x13ad59&&this['removeMessageHandler'](_0x13ad59);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x5b529e){Z()['location']['href']=_0x5b529e;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x9fc3b8;return((_0x9fc3b8=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x9fc3b8['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x5240ff){this['request']=_0x5240ff;}['toPromise'](){return new Promise((_0x310934,_0x1ff2b4)=>{this['request']['addEventListener']('success',()=>{_0x310934(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x1ff2b4(this['request']['error']);});});}}function Yn(_0x14640e,_0x5c623f){return _0x14640e['transaction']([Nn],_0x5c623f?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x5dbc60=indexedDB['deleteDatabase'](Ka);return new Xt(_0x5dbc60)['toPromise']();}function Mi(){const _0x413d3d=indexedDB['open'](Ka,up);return new Promise((_0x45d019,_0x53107e)=>{_0x413d3d['addEventListener']('error',()=>{_0x53107e(_0x413d3d['error']);}),_0x413d3d['addEventListener']('upgradeneeded',()=>{const _0x170627=_0x413d3d['result'];try{_0x170627['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0xe40a53){_0x53107e(_0xe40a53);}}),_0x413d3d['addEventListener']('success',async()=>{const _0xc82266=_0x413d3d['result'];_0xc82266['objectStoreNames']['contains'](Nn)?_0x45d019(_0xc82266):(_0xc82266['close'](),await dp(),_0x45d019(await Mi()));});});}async function Pr(_0x2e5379,_0x18135b,_0x3fc389){const _0x4eada1=Yn(_0x2e5379,!0x0)['put']({[Ya]:_0x18135b,'value':_0x3fc389});return new Xt(_0x4eada1)['toPromise']();}async function fp(_0x1362d5,_0x78baff){const _0x1ae383=Yn(_0x1362d5,!0x1)['get'](_0x78baff),_0x472869=await new Xt(_0x1ae383)['toPromise']();return _0x472869===void 0x0?null:_0x472869['value'];}function Or(_0x127a56,_0x4d7033){const _0x5949e8=Yn(_0x127a56,!0x0)['delete'](_0x4d7033);return new Xt(_0x5949e8)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x2c064c){let _0x10cb7d=0x0;for(;;)try{const _0x581c05=await this['_openDb']();return await _0x2c064c(_0x581c05);}catch(_0x2489ed){if(_0x10cb7d++>_p)throw _0x2489ed;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x17ff3b,_0x50b63d)=>({'keyProcessed':(await this['_poll']())['includes'](_0x50b63d['key'])})),this['receiver']['_subscribe']('ping',async(_0x9aeae6,_0x499d46)=>['keyChanged']);}async['initializeSender'](){var _0x110be5,_0xe5a152;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x275499=await this['sender']['_send']('ping',{},0x320);_0x275499&&(_0x110be5=_0x275499[0x0])!=null&&_0x110be5['fulfilled']&&(_0xe5a152=_0x275499[0x0])!=null&&_0xe5a152['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x36b996){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x36b996},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x3e8fea=await Mi();return await Pr(_0x3e8fea,kn,'1'),await Or(_0x3e8fea,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x48cf38){this['pendingWrites']++;try{await _0x48cf38();}finally{this['pendingWrites']--;}}async['_set'](_0xd560b1,_0x442dd9){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1935d4=>Pr(_0x1935d4,_0xd560b1,_0x442dd9)),this['localCache'][_0xd560b1]=_0x442dd9,this['notifyServiceWorker'](_0xd560b1)));}async['_get'](_0x5bca9a){const _0x39f20a=await this['_withRetries'](_0x62f731=>fp(_0x62f731,_0x5bca9a));return this['localCache'][_0x5bca9a]=_0x39f20a,_0x39f20a;}async['_remove'](_0x3a986f){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x114c66=>Or(_0x114c66,_0x3a986f)),delete this['localCache'][_0x3a986f],this['notifyServiceWorker'](_0x3a986f)));}async['_poll'](){const _0x1bb29b=await this['_withRetries'](_0x6f29fd=>{const _0x5d0f41=Yn(_0x6f29fd,!0x1)['getAll']();return new Xt(_0x5d0f41)['toPromise']();});if(!_0x1bb29b)return[];if(this['pendingWrites']!==0x0)return[];const _0x589c67=[],_0x260859=new Set();if(_0x1bb29b['length']!==0x0){for(const {fbase_key:_0xcd6cb2,value:_0xa7d873}of _0x1bb29b)_0x260859['add'](_0xcd6cb2),JSON['stringify'](this['localCache'][_0xcd6cb2])!==JSON['stringify'](_0xa7d873)&&(this['notifyListeners'](_0xcd6cb2,_0xa7d873),_0x589c67['push'](_0xcd6cb2));}for(const _0x21416a of Object['keys'](this['localCache']))this['localCache'][_0x21416a]&&!_0x260859['has'](_0x21416a)&&(this['notifyListeners'](_0x21416a,null),_0x589c67['push'](_0x21416a));return _0x589c67;}['notifyListeners'](_0x20a820,_0x3b4d07){this['localCache'][_0x20a820]=_0x3b4d07;const _0x120990=this['listeners'][_0x20a820];if(_0x120990){for(const _0x1b3a49 of Array['from'](_0x120990))_0x1b3a49(_0x3b4d07);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x369187,_0x3994ce){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x369187]||(this['listeners'][_0x369187]=new Set(),this['_get'](_0x369187)),this['listeners'][_0x369187]['add'](_0x3994ce);}['_removeListener'](_0x17235f,_0x3e8e5c){this['listeners'][_0x17235f]&&(this['listeners'][_0x17235f]['delete'](_0x3e8e5c),this['listeners'][_0x17235f]['size']===0x0&&delete this['listeners'][_0x17235f]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x2efc99,_0x14912e){return _0x14912e?ie(_0x14912e):(m(_0x2efc99['_popupRedirectResolver'],_0x2efc99,'argument-error'),_0x2efc99['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x1ae182){super('custom','custom'),this['params']=_0x1ae182;}['_getIdTokenResponse'](_0x24ad74){return Xe(_0x24ad74,this['_buildIdpRequest']());}['_linkToIdToken'](_0x4a0d76,_0x557078){return Xe(_0x4a0d76,this['_buildIdpRequest'](_0x557078));}['_getReauthenticationResolver'](_0x36de97){return Xe(_0x36de97,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x562854){const _0x451aa5={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x562854&&(_0x451aa5['idToken']=_0x562854),_0x451aa5;}}function yp(_0x46d0df){return Va(_0x46d0df['auth'],new ks(_0x46d0df),_0x46d0df['bypassAuthState']);}function vp(_0x5e7ba4){const {auth:_0x754b16,user:_0x4475cc}=_0x5e7ba4;return m(_0x4475cc,_0x754b16,'internal-error'),Xf(_0x4475cc,new ks(_0x5e7ba4),_0x5e7ba4['bypassAuthState']);}async function Ep(_0x5e1a19){const {auth:_0x544df2,user:_0x1ab21c}=_0x5e1a19;return m(_0x1ab21c,_0x544df2,'internal-error'),Jf(_0x1ab21c,new ks(_0x5e1a19),_0x5e1a19['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x49d861,_0x2dab0a,_0x50f5c6,_0x4d9890,_0x5bb763=!0x1){this['auth']=_0x49d861,this['resolver']=_0x50f5c6,this['user']=_0x4d9890,this['bypassAuthState']=_0x5bb763,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x2dab0a)?_0x2dab0a:[_0x2dab0a];}['execute'](){return new Promise(async(_0x567740,_0x22dfff)=>{this['pendingPromise']={'resolve':_0x567740,'reject':_0x22dfff};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x2fe9a8){this['reject'](_0x2fe9a8);}});}async['onAuthEvent'](_0x24c753){const {urlResponse:_0x4d6f09,sessionId:_0x448a80,postBody:_0x1b07f5,tenantId:_0x16d342,error:_0x3b0ca8,type:_0x513aa7}=_0x24c753;if(_0x3b0ca8){this['reject'](_0x3b0ca8);return;}const _0x24e82b={'auth':this['auth'],'requestUri':_0x4d6f09,'sessionId':_0x448a80,'tenantId':_0x16d342||void 0x0,'postBody':_0x1b07f5||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x513aa7)(_0x24e82b));}catch(_0x243036){this['reject'](_0x243036);}}['onError'](_0x5a3415){this['reject'](_0x5a3415);}['getIdpTask'](_0x2753d7){switch(_0x2753d7){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x4f2bb5){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x4f2bb5),this['unregisterAndCleanUp']();}['reject'](_0x7a67cc){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x7a67cc),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x54939f,_0x4cd991,_0xf192b9,_0x5af363,_0x2c7a5f){super(_0x54939f,_0x4cd991,_0x5af363,_0x2c7a5f),this['provider']=_0xf192b9,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x183a40=await this['execute']();return m(_0x183a40,this['auth'],'internal-error'),_0x183a40;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x34bce8=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x34bce8),this['authWindow']['associatedEvent']=_0x34bce8,this['resolver']['_originValidation'](this['auth'])['catch'](_0x42edb5=>{this['reject'](_0x42edb5);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x71bd6f=>{_0x71bd6f||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x3c7bc0;return((_0x3c7bc0=this['authWindow'])==null?void 0x0:_0x3c7bc0['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x3dea31=()=>{var _0x493a5d,_0x5043b4;if((_0x5043b4=(_0x493a5d=this['authWindow'])==null?void 0x0:_0x493a5d['window'])!=null&&_0x5043b4['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x3dea31,Ip['get']());};_0x3dea31();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x4f0130,_0x578535,_0x3bcda6=!0x1){super(_0x4f0130,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x578535,void 0x0,_0x3bcda6),this['eventId']=null;}async['execute'](){let _0x5bcba6=on['get'](this['auth']['_key']());if(!_0x5bcba6){try{const _0x405b3c=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x5bcba6=()=>Promise['resolve'](_0x405b3c);}catch(_0x208b96){_0x5bcba6=()=>Promise['reject'](_0x208b96);}on['set'](this['auth']['_key'](),_0x5bcba6);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x5bcba6();}async['onAuthEvent'](_0x2f0257){if(_0x2f0257['type']==='signInViaRedirect')return super['onAuthEvent'](_0x2f0257);if(_0x2f0257['type']==='unknown'){this['resolve'](null);return;}if(_0x2f0257['eventId']){const _0x5bc02e=await this['auth']['_redirectUserForId'](_0x2f0257['eventId']);if(_0x5bc02e)return this['user']=_0x5bc02e,super['onAuthEvent'](_0x2f0257);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x18577c,_0x7f9a12){const _0x4a6c8f=Rp(_0x7f9a12),_0x235196=bp(_0x18577c);if(!await _0x235196['_isAvailable']())return!0x1;const _0x5c12f1=await _0x235196['_get'](_0x4a6c8f)==='true';return await _0x235196['_remove'](_0x4a6c8f),_0x5c12f1;}function Sp(_0x1f564c,_0x2539f2){on['set'](_0x1f564c['_key'](),_0x2539f2);}function bp(_0x120992){return ie(_0x120992['_redirectPersistence']);}function Rp(_0x5db1f9){return rn(wp,_0x5db1f9['config']['apiKey'],_0x5db1f9['name']);}async function Ap(_0x12e564,_0x45870c,_0x31b4cd=!0x1){if($(_0x12e564['app']))return Promise['reject'](re(_0x12e564));const _0x3f710d=qe(_0x12e564),_0x49dd5e=mp(_0x3f710d,_0x45870c),_0x3839f7=await new Cp(_0x3f710d,_0x49dd5e,_0x31b4cd)['execute']();return _0x3839f7&&!_0x31b4cd&&(delete _0x3839f7['user']['_redirectEventId'],await _0x3f710d['_persistUserIfCurrent'](_0x3839f7['user']),await _0x3f710d['_setRedirectUser'](null,_0x45870c)),_0x3839f7;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x58192b){this['auth']=_0x58192b,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x32c764){this['consumers']['add'](_0x32c764),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x32c764)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x32c764),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x4ec818){this['consumers']['delete'](_0x4ec818);}['onEvent'](_0x3b8508){if(this['hasEventBeenHandled'](_0x3b8508))return!0x1;let _0x347e01=!0x1;return this['consumers']['forEach'](_0xd15d40=>{this['isEventForConsumer'](_0x3b8508,_0xd15d40)&&(_0x347e01=!0x0,this['sendToConsumer'](_0x3b8508,_0xd15d40),this['saveEventToCache'](_0x3b8508));}),this['hasHandledPotentialRedirect']||!Pp(_0x3b8508)||(this['hasHandledPotentialRedirect']=!0x0,_0x347e01||(this['queuedRedirectEvent']=_0x3b8508,_0x347e01=!0x0)),_0x347e01;}['sendToConsumer'](_0x594b0b,_0x5d49dc){var _0x4e6c67;if(_0x594b0b['error']&&!Xa(_0x594b0b)){const _0x4826cc=((_0x4e6c67=_0x594b0b['error']['code'])==null?void 0x0:_0x4e6c67['split']('auth/')[0x1])||'internal-error';_0x5d49dc['onError'](X(this['auth'],_0x4826cc));}else _0x5d49dc['onAuthEvent'](_0x594b0b);}['isEventForConsumer'](_0x5bf879,_0x56ceec){const _0x236b66=_0x56ceec['eventId']===null||!!_0x5bf879['eventId']&&_0x5bf879['eventId']===_0x56ceec['eventId'];return _0x56ceec['filter']['includes'](_0x5bf879['type'])&&_0x236b66;}['hasEventBeenHandled'](_0x40a10d){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x40a10d));}['saveEventToCache'](_0x405f69){this['cachedEventUids']['add'](Dr(_0x405f69)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x3e820b){return[_0x3e820b['type'],_0x3e820b['eventId'],_0x3e820b['sessionId'],_0x3e820b['tenantId']]['filter'](_0x25488f=>_0x25488f)['join']('-');}function Xa({type:_0x28d7ff,error:_0x28a778}){return _0x28d7ff==='unknown'&&(_0x28a778==null?void 0x0:_0x28a778['code'])==='auth/no-auth-event';}function Pp(_0x312b5b){switch(_0x312b5b['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x312b5b);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x159cd6,_0x3b763c={}){return Ae(_0x159cd6,'GET','/v1/projects',_0x3b763c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x1e11e9){if(_0x1e11e9['config']['emulator'])return;const {authorizedDomains:_0x54ba0c}=await Op(_0x1e11e9);for(const _0x25a916 of _0x54ba0c)try{if(xp(_0x25a916))return;}catch{}Q(_0x1e11e9,'unauthorized-domain');}function xp(_0x282dd1){const _0x4e5ab3=Pi(),{protocol:_0x45fe55,hostname:_0x25f38e}=new URL(_0x4e5ab3);if(_0x282dd1['startsWith']('chrome-extension://')){const _0x1cdde2=new URL(_0x282dd1);return _0x1cdde2['hostname']===''&&_0x25f38e===''?_0x45fe55==='chrome-extension:'&&_0x282dd1['replace']('chrome-extension://','')===_0x4e5ab3['replace']('chrome-extension://',''):_0x45fe55==='chrome-extension:'&&_0x1cdde2['hostname']===_0x25f38e;}if(!Mp['test'](_0x45fe55))return!0x1;if(Dp['test'](_0x282dd1))return _0x25f38e===_0x282dd1;const _0x5de909=_0x282dd1['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x5de909+'|'+_0x5de909+')$','i')['test'](_0x25f38e);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x1cd023=Z()['___jsl'];if(_0x1cd023!=null&&_0x1cd023['H']){for(const _0x3cdc0b of Object['keys'](_0x1cd023['H']))if(_0x1cd023['H'][_0x3cdc0b]['r']=_0x1cd023['H'][_0x3cdc0b]['r']||[],_0x1cd023['H'][_0x3cdc0b]['L']=_0x1cd023['H'][_0x3cdc0b]['L']||[],_0x1cd023['H'][_0x3cdc0b]['r']=[..._0x1cd023['H'][_0x3cdc0b]['L']],_0x1cd023['CP']){for(let _0x1a2dbe=0x0;_0x1a2dbe<_0x1cd023['CP']['length'];_0x1a2dbe++)_0x1cd023['CP'][_0x1a2dbe]=null;}}}function Up(_0x2ff84b){return new Promise((_0x255a3d,_0x28ecc2)=>{var _0x5a5511,_0x57d515,_0x3ada43;function _0xd11e17(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x255a3d(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x28ecc2(X(_0x2ff84b,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x57d515=(_0x5a5511=Z()['gapi'])==null?void 0x0:_0x5a5511['iframes'])!=null&&_0x57d515['Iframe'])_0x255a3d(gapi['iframes']['getContext']());else{if((_0x3ada43=Z()['gapi'])!=null&&_0x3ada43['load'])_0xd11e17();else{const _0x206b98=Df('iframefcb');return Z()[_0x206b98]=()=>{gapi['load']?_0xd11e17():_0x28ecc2(X(_0x2ff84b,'network-request-failed'));},xa(Of()+'?onload='+_0x206b98)['catch'](_0x38d74f=>_0x28ecc2(_0x38d74f));}}})['catch'](_0x57888e=>{throw an=null,_0x57888e;});}let an=null;function Wp(_0x1aee4b){return an=an||Up(_0x1aee4b),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x9cbe5b){const _0x300676=_0x9cbe5b['config'];m(_0x300676['authDomain'],_0x9cbe5b,'auth-domain-config-required');const _0x567bf4=_0x300676['emulator']?Cs(_0x300676,Hp):'https://'+_0x9cbe5b['config']['authDomain']+'/'+Vp,_0x7c9874={'apiKey':_0x300676['apiKey'],'appName':_0x9cbe5b['name'],'v':lt},_0x115009=Gp['get'](_0x9cbe5b['config']['apiHost']);_0x115009&&(_0x7c9874['eid']=_0x115009);const _0x597b76=_0x9cbe5b['_getFrameworks']();return _0x597b76['length']&&(_0x7c9874['fw']=_0x597b76['join'](',')),_0x567bf4+'?'+ct(_0x7c9874)['slice'](0x1);}async function zp(_0x18f6d5){const _0xcb6543=await Wp(_0x18f6d5),_0x5ed892=Z()['gapi'];return m(_0x5ed892,_0x18f6d5,'internal-error'),_0xcb6543['open']({'where':document['body'],'url':qp(_0x18f6d5),'messageHandlersFilter':_0x5ed892['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x236b74=>new Promise(async(_0x885d3d,_0x9ba86d)=>{await _0x236b74['restyle']({'setHideOnLeave':!0x1});const _0x189812=X(_0x18f6d5,'network-request-failed'),_0x4b6ca6=Z()['setTimeout'](()=>{_0x9ba86d(_0x189812);},Bp['get']());function _0x3ac9aa(){Z()['clearTimeout'](_0x4b6ca6),_0x885d3d(_0x236b74);}_0x236b74['ping'](_0x3ac9aa)['then'](_0x3ac9aa,()=>{_0x9ba86d(_0x189812);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x545e11){this['window']=_0x545e11,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x377490,_0x13a870,_0x53582b,_0xf651f3=Kp,_0x16d186=Yp){const _0x391aa6=Math['max']((window['screen']['availHeight']-_0x16d186)/0x2,0x0)['toString'](),_0x5ec20c=Math['max']((window['screen']['availWidth']-_0xf651f3)/0x2,0x0)['toString']();let _0x35c538='';const _0x154acc={...jp,'width':_0xf651f3['toString'](),'height':_0x16d186['toString'](),'top':_0x391aa6,'left':_0x5ec20c},_0x4100e6=W()['toLowerCase']();_0x53582b&&(_0x35c538=ka(_0x4100e6)?Qp:_0x53582b),Ra(_0x4100e6)&&(_0x13a870=_0x13a870||Jp,_0x154acc['scrollbars']='yes');const _0x3a6e4f=Object['entries'](_0x154acc)['reduce']((_0x5ec220,[_0x2dfbf4,_0xe54692])=>''+_0x5ec220+_0x2dfbf4+'='+_0xe54692+',','');if(Cf(_0x4100e6)&&_0x35c538!=='_self')return Zp(_0x13a870||'',_0x35c538),new Lr(null);const _0x2e44f5=window['open'](_0x13a870||'',_0x35c538,_0x3a6e4f);m(_0x2e44f5,_0x377490,'popup-blocked');try{_0x2e44f5['focus']();}catch{}return new Lr(_0x2e44f5);}function Zp(_0x2b7ecb,_0x351c1d){const _0x4f164c=document['createElement']('a');_0x4f164c['href']=_0x2b7ecb,_0x4f164c['target']=_0x351c1d;const _0x61e473=document['createEvent']('MouseEvent');_0x61e473['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x4f164c['dispatchEvent'](_0x61e473);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x360261,_0x2a009a,_0x813043,_0x66bafa,_0x4495c2,_0x6302f6){m(_0x360261['config']['authDomain'],_0x360261,'auth-domain-config-required'),m(_0x360261['config']['apiKey'],_0x360261,'invalid-api-key');const _0x2ba213={'apiKey':_0x360261['config']['apiKey'],'appName':_0x360261['name'],'authType':_0x813043,'redirectUrl':_0x66bafa,'v':lt,'eventId':_0x4495c2};if(_0x2a009a instanceof Wa){_0x2a009a['setDefaultLanguage'](_0x360261['languageCode']),_0x2ba213['providerId']=_0x2a009a['providerId']||'',ui(_0x2a009a['getCustomParameters']())||(_0x2ba213['customParameters']=JSON['stringify'](_0x2a009a['getCustomParameters']()));for(const [_0x2a0ead,_0x5bf665]of Object['entries']({}))_0x2ba213[_0x2a0ead]=_0x5bf665;}if(_0x2a009a instanceof Jt){const _0x310d66=_0x2a009a['getScopes']()['filter'](_0x4a7643=>_0x4a7643!=='');_0x310d66['length']>0x0&&(_0x2ba213['scopes']=_0x310d66['join'](','));}_0x360261['tenantId']&&(_0x2ba213['tid']=_0x360261['tenantId']);const _0x890507=_0x2ba213;for(const _0x9cf2c7 of Object['keys'](_0x890507))_0x890507[_0x9cf2c7]===void 0x0&&delete _0x890507[_0x9cf2c7];const _0x369071=await _0x360261['_getAppCheckToken'](),_0xe05250=_0x369071?'#'+n_+'='+encodeURIComponent(_0x369071):'';return i_(_0x360261)+'?'+ct(_0x890507)['slice'](0x1)+_0xe05250;}function i_({config:_0x7484bc}){return _0x7484bc['emulator']?Cs(_0x7484bc,t_):'https://'+_0x7484bc['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x3b5722,_0x5c5426,_0x932f10,_0x2506f4){var _0x5e5044;ce((_0x5e5044=this['eventManagers'][_0x3b5722['_key']()])==null?void 0x0:_0x5e5044['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x142d35=await xr(_0x3b5722,_0x5c5426,_0x932f10,Pi(),_0x2506f4);return Xp(_0x3b5722,_0x142d35,As());}async['_openRedirect'](_0x5c3052,_0x2906b8,_0x4ab457,_0x3dd74e){await this['_originValidation'](_0x5c3052);const _0x23225a=await xr(_0x5c3052,_0x2906b8,_0x4ab457,Pi(),_0x3dd74e);return ap(_0x23225a),new Promise(()=>{});}['_initialize'](_0x649ec9){const _0x114487=_0x649ec9['_key']();if(this['eventManagers'][_0x114487]){const {manager:_0x30415d,promise:_0x2c846d}=this['eventManagers'][_0x114487];return _0x30415d?Promise['resolve'](_0x30415d):(ce(_0x2c846d,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x2c846d);}const _0x8b1bef=this['initAndGetManager'](_0x649ec9);return this['eventManagers'][_0x114487]={'promise':_0x8b1bef},_0x8b1bef['catch'](()=>{delete this['eventManagers'][_0x114487];}),_0x8b1bef;}async['initAndGetManager'](_0x23c014){const _0x434110=await zp(_0x23c014),_0x27b49a=new Np(_0x23c014);return _0x434110['register']('authEvent',_0x36c30e=>(m(_0x36c30e==null?void 0x0:_0x36c30e['authEvent'],_0x23c014,'invalid-auth-event'),{'status':_0x27b49a['onEvent'](_0x36c30e['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x23c014['_key']()]={'manager':_0x27b49a},this['iframes'][_0x23c014['_key']()]=_0x434110,_0x27b49a;}['_isIframeWebStorageSupported'](_0xc869d7,_0x14324a){this['iframes'][_0xc869d7['_key']()]['send'](hi,{'type':hi},_0x10ca23=>{var _0x25be9c;const _0xa745bc=(_0x25be9c=_0x10ca23==null?void 0x0:_0x10ca23[0x0])==null?void 0x0:_0x25be9c[hi];_0xa745bc!==void 0x0&&_0x14324a(!!_0xa745bc),Q(_0xc869d7,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x5f46ea){const _0x2bc804=_0x5f46ea['_key']();return this['originValidationPromises'][_0x2bc804]||(this['originValidationPromises'][_0x2bc804]=Lp(_0x5f46ea)),this['originValidationPromises'][_0x2bc804];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x466c0d){this['auth']=_0x466c0d,this['internalListeners']=new Map();}['getUid'](){var _0x545ce7;return this['assertAuthConfigured'](),((_0x545ce7=this['auth']['currentUser'])==null?void 0x0:_0x545ce7['uid'])||null;}async['getToken'](_0x4e32cc){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x4e32cc)}:null;}['addAuthTokenListener'](_0x403ed7){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x403ed7))return;const _0x51c71f=this['auth']['onIdTokenChanged'](_0x12db5c=>{_0x403ed7((_0x12db5c==null?void 0x0:_0x12db5c['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x403ed7,_0x51c71f),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x2c52ec){this['assertAuthConfigured']();const _0x2e22d6=this['internalListeners']['get'](_0x2c52ec);_0x2e22d6&&(this['internalListeners']['delete'](_0x2c52ec),_0x2e22d6(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x3be0a1){switch(_0x3be0a1){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x98f7e6){Ze(new Le('auth',(_0x57734a,{options:_0x2a68a3})=>{const _0x52855c=_0x57734a['getProvider']('app')['getImmediate'](),_0x5be94c=_0x57734a['getProvider']('heartbeat'),_0x722e77=_0x57734a['getProvider']('app-check-internal'),{apiKey:_0x383d2c,authDomain:_0x5d8b62}=_0x52855c['options'];m(_0x383d2c&&!_0x383d2c['includes'](':'),'invalid-api-key',{'appName':_0x52855c['name']});const _0x4f7be9={'apiKey':_0x383d2c,'authDomain':_0x5d8b62,'clientPlatform':_0x98f7e6,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x98f7e6)},_0x233de6=new kf(_0x52855c,_0x5be94c,_0x722e77,_0x4f7be9);return Wf(_0x233de6,_0x2a68a3),_0x233de6;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x217abd,_0x12a9bd,_0x54c017)=>{_0x217abd['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x5c3252=>{const _0x218479=qe(_0x5c3252['getProvider']('auth')['getImmediate']());return(_0x17919e=>new o_(_0x17919e))(_0x218479);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x98f7e6)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x29ad1b=>async _0x32395e=>{const _0x3427d7=_0x32395e&&await _0x32395e['getIdTokenResult'](),_0x408768=_0x3427d7&&(new Date()['getTime']()-Date['parse'](_0x3427d7['issuedAtTime']))/0x3e8;if(_0x408768&&_0x408768>h_)return;const _0x50b0d0=_0x3427d7==null?void 0x0:_0x3427d7['token'];Wr!==_0x50b0d0&&(Wr=_0x50b0d0,await fetch(_0x29ad1b,{'method':_0x50b0d0?'POST':'DELETE','headers':_0x50b0d0?{'Authorization':'Bearer\x20'+_0x50b0d0}:{}}));};function x_(_0x3c6063=Zr()){const _0x27a810=Bi(_0x3c6063,'auth');if(_0x27a810['isInitialized']())return _0x27a810['getImmediate']();const _0x5ea556=Uf(_0x3c6063,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x4a0b4b=zr('authTokenSyncURL');if(_0x4a0b4b&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x29dd61=new URL(_0x4a0b4b,location['origin']);if(location['origin']===_0x29dd61['origin']){const _0xc28ca3=u_(_0x29dd61['toString']());tp(_0x5ea556,_0xc28ca3,()=>_0xc28ca3(_0x5ea556['currentUser'])),ep(_0x5ea556,_0x27be7d=>_0xc28ca3(_0x27be7d));}}const _0x598403=Gr('auth');return _0x598403&&Bf(_0x5ea556,'http://'+_0x598403),_0x5ea556;}function d_(){var _0x3a914e;return((_0x3a914e=document['getElementsByTagName']('head'))==null?void 0x0:_0x3a914e[0x0])??document;}Nf({'loadJS'(_0x38c575){return new Promise((_0x44f7e1,_0x168989)=>{const _0x2dae28=document['createElement']('script');_0x2dae28['setAttribute']('src',_0x38c575),_0x2dae28['onload']=_0x44f7e1,_0x2dae28['onerror']=_0x59dd14=>{const _0x438fb0=X('internal-error');_0x438fb0['customData']=_0x59dd14,_0x168989(_0x438fb0);},_0x2dae28['type']='text/javascript',_0x2dae28['charset']='UTF-8',d_()['appendChild'](_0x2dae28);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};