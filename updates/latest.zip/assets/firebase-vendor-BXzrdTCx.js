const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x1bedb0,_0x12f9fa){if(!_0x1bedb0)throw rt(_0x12f9fa);},rt=function(_0x943178){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x943178);},Vr=function(_0x3b7beb){const _0x18c59f=[];let _0x2f082b=0x0;for(let _0x2283ba=0x0;_0x2283ba<_0x3b7beb['length'];_0x2283ba++){let _0x48073e=_0x3b7beb['charCodeAt'](_0x2283ba);_0x48073e<0x80?_0x18c59f[_0x2f082b++]=_0x48073e:_0x48073e<0x800?(_0x18c59f[_0x2f082b++]=_0x48073e>>0x6|0xc0,_0x18c59f[_0x2f082b++]=_0x48073e&0x3f|0x80):(_0x48073e&0xfc00)===0xd800&&_0x2283ba+0x1<_0x3b7beb['length']&&(_0x3b7beb['charCodeAt'](_0x2283ba+0x1)&0xfc00)===0xdc00?(_0x48073e=0x10000+((_0x48073e&0x3ff)<<0xa)+(_0x3b7beb['charCodeAt'](++_0x2283ba)&0x3ff),_0x18c59f[_0x2f082b++]=_0x48073e>>0x12|0xf0,_0x18c59f[_0x2f082b++]=_0x48073e>>0xc&0x3f|0x80,_0x18c59f[_0x2f082b++]=_0x48073e>>0x6&0x3f|0x80,_0x18c59f[_0x2f082b++]=_0x48073e&0x3f|0x80):(_0x18c59f[_0x2f082b++]=_0x48073e>>0xc|0xe0,_0x18c59f[_0x2f082b++]=_0x48073e>>0x6&0x3f|0x80,_0x18c59f[_0x2f082b++]=_0x48073e&0x3f|0x80);}return _0x18c59f;},ec=function(_0x5bc95f){const _0x571776=[];let _0x318e22=0x0,_0x3e1d4f=0x0;for(;_0x318e22<_0x5bc95f['length'];){const _0x5c8d1c=_0x5bc95f[_0x318e22++];if(_0x5c8d1c<0x80)_0x571776[_0x3e1d4f++]=String['fromCharCode'](_0x5c8d1c);else{if(_0x5c8d1c>0xbf&&_0x5c8d1c<0xe0){const _0x51870d=_0x5bc95f[_0x318e22++];_0x571776[_0x3e1d4f++]=String['fromCharCode']((_0x5c8d1c&0x1f)<<0x6|_0x51870d&0x3f);}else{if(_0x5c8d1c>0xef&&_0x5c8d1c<0x16d){const _0x594158=_0x5bc95f[_0x318e22++],_0x3afe0f=_0x5bc95f[_0x318e22++],_0x59180a=_0x5bc95f[_0x318e22++],_0x5407e5=((_0x5c8d1c&0x7)<<0x12|(_0x594158&0x3f)<<0xc|(_0x3afe0f&0x3f)<<0x6|_0x59180a&0x3f)-0x10000;_0x571776[_0x3e1d4f++]=String['fromCharCode'](0xd800+(_0x5407e5>>0xa)),_0x571776[_0x3e1d4f++]=String['fromCharCode'](0xdc00+(_0x5407e5&0x3ff));}else{const _0xe5cdce=_0x5bc95f[_0x318e22++],_0x25e5a2=_0x5bc95f[_0x318e22++];_0x571776[_0x3e1d4f++]=String['fromCharCode']((_0x5c8d1c&0xf)<<0xc|(_0xe5cdce&0x3f)<<0x6|_0x25e5a2&0x3f);}}}}return _0x571776['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x4a934a,_0x5dd4d4){if(!Array['isArray'](_0x4a934a))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x395e26=_0x5dd4d4?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x529565=[];for(let _0x17973f=0x0;_0x17973f<_0x4a934a['length'];_0x17973f+=0x3){const _0x50b7ad=_0x4a934a[_0x17973f],_0xf40029=_0x17973f+0x1<_0x4a934a['length'],_0x1419d5=_0xf40029?_0x4a934a[_0x17973f+0x1]:0x0,_0x1b5d3b=_0x17973f+0x2<_0x4a934a['length'],_0x1e5451=_0x1b5d3b?_0x4a934a[_0x17973f+0x2]:0x0,_0x1073c=_0x50b7ad>>0x2,_0x3115f1=(_0x50b7ad&0x3)<<0x4|_0x1419d5>>0x4;let _0x136629=(_0x1419d5&0xf)<<0x2|_0x1e5451>>0x6,_0x5f5ce2=_0x1e5451&0x3f;_0x1b5d3b||(_0x5f5ce2=0x40,_0xf40029||(_0x136629=0x40)),_0x529565['push'](_0x395e26[_0x1073c],_0x395e26[_0x3115f1],_0x395e26[_0x136629],_0x395e26[_0x5f5ce2]);}return _0x529565['join']('');},'encodeString'(_0x1b291a,_0x3c42a3){return this['HAS_NATIVE_SUPPORT']&&!_0x3c42a3?btoa(_0x1b291a):this['encodeByteArray'](Vr(_0x1b291a),_0x3c42a3);},'decodeString'(_0x63017d,_0x1f0282){return this['HAS_NATIVE_SUPPORT']&&!_0x1f0282?atob(_0x63017d):ec(this['decodeStringToByteArray'](_0x63017d,_0x1f0282));},'decodeStringToByteArray'(_0x30d3ef,_0x2d860e){this['init_']();const _0x2d9dec=_0x2d860e?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x113f26=[];for(let _0x5b731e=0x0;_0x5b731e<_0x30d3ef['length'];){const _0x1a6389=_0x2d9dec[_0x30d3ef['charAt'](_0x5b731e++)],_0x4e2bb7=_0x5b731e<_0x30d3ef['length']?_0x2d9dec[_0x30d3ef['charAt'](_0x5b731e)]:0x0;++_0x5b731e;const _0x34d2e0=_0x5b731e<_0x30d3ef['length']?_0x2d9dec[_0x30d3ef['charAt'](_0x5b731e)]:0x40;++_0x5b731e;const _0x2a4de9=_0x5b731e<_0x30d3ef['length']?_0x2d9dec[_0x30d3ef['charAt'](_0x5b731e)]:0x40;if(++_0x5b731e,_0x1a6389==null||_0x4e2bb7==null||_0x34d2e0==null||_0x2a4de9==null)throw new tc();const _0x566de4=_0x1a6389<<0x2|_0x4e2bb7>>0x4;if(_0x113f26['push'](_0x566de4),_0x34d2e0!==0x40){const _0x41d7e7=_0x4e2bb7<<0x4&0xf0|_0x34d2e0>>0x2;if(_0x113f26['push'](_0x41d7e7),_0x2a4de9!==0x40){const _0xeedf33=_0x34d2e0<<0x6&0xc0|_0x2a4de9;_0x113f26['push'](_0xeedf33);}}}return _0x113f26;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x2f08fe=0x0;_0x2f08fe<this['ENCODED_VALS']['length'];_0x2f08fe++)this['byteToCharMap_'][_0x2f08fe]=this['ENCODED_VALS']['charAt'](_0x2f08fe),this['charToByteMap_'][this['byteToCharMap_'][_0x2f08fe]]=_0x2f08fe,this['byteToCharMapWebSafe_'][_0x2f08fe]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x2f08fe),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x2f08fe]]=_0x2f08fe,_0x2f08fe>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x2f08fe)]=_0x2f08fe,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x2f08fe)]=_0x2f08fe);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x1fc873){const _0x36c866=Vr(_0x1fc873);return Li['encodeByteArray'](_0x36c866,!0x0);},cn=function(_0x4a8924){return Hr(_0x4a8924)['replace'](/\./g,'');},ln=function(_0x79b6){try{return Li['decodeString'](_0x79b6,!0x0);}catch(_0x2acc86){console['error']('base64Decode\x20failed:\x20',_0x2acc86);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x333106){return $r(void 0x0,_0x333106);}function $r(_0x238860,_0x49eb9f){if(!(_0x49eb9f instanceof Object))return _0x49eb9f;switch(_0x49eb9f['constructor']){case Date:const _0x5d523d=_0x49eb9f;return new Date(_0x5d523d['getTime']());case Object:_0x238860===void 0x0&&(_0x238860={});break;case Array:_0x238860=[];break;default:return _0x49eb9f;}for(const _0x40e831 in _0x49eb9f)!_0x49eb9f['hasOwnProperty'](_0x40e831)||!ic(_0x40e831)||(_0x238860[_0x40e831]=$r(_0x238860[_0x40e831],_0x49eb9f[_0x40e831]));return _0x238860;}function ic(_0x51074f){return _0x51074f!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x39b9c3=Ns['__FIREBASE_DEFAULTS__'];if(_0x39b9c3)return JSON['parse'](_0x39b9c3);},ac=()=>{if(typeof document>'u')return;let _0x1134ef;try{_0x1134ef=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x625a5d=_0x1134ef&&ln(_0x1134ef[0x1]);return _0x625a5d&&JSON['parse'](_0x625a5d);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x2dd289){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x2dd289);return;}},Gr=_0x775181=>{var _0x5c8d50,_0x89cfca;return(_0x89cfca=(_0x5c8d50=xi())==null?void 0x0:_0x5c8d50['emulatorHosts'])==null?void 0x0:_0x89cfca[_0x775181];},cc=_0x36d1df=>{const _0x18485c=Gr(_0x36d1df);if(!_0x18485c)return;const _0x4cdf7d=_0x18485c['lastIndexOf'](':');if(_0x4cdf7d<=0x0||_0x4cdf7d+0x1===_0x18485c['length'])throw new Error('Invalid\x20host\x20'+_0x18485c+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x44350d=parseInt(_0x18485c['substring'](_0x4cdf7d+0x1),0xa);return _0x18485c[0x0]==='['?[_0x18485c['substring'](0x1,_0x4cdf7d-0x1),_0x44350d]:[_0x18485c['substring'](0x0,_0x4cdf7d),_0x44350d];},qr=()=>{var _0x246cfd;return(_0x246cfd=xi())==null?void 0x0:_0x246cfd['config'];},zr=_0x193d33=>{var _0xfc7bfd;return(_0xfc7bfd=xi())==null?void 0x0:_0xfc7bfd['_'+_0x193d33];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x32ab17,_0x276642)=>{this['resolve']=_0x32ab17,this['reject']=_0x276642;});}['wrapCallback'](_0x281336){return(_0x1b1474,_0x2344f0)=>{_0x1b1474?this['reject'](_0x1b1474):this['resolve'](_0x2344f0),typeof _0x281336=='function'&&(this['promise']['catch'](()=>{}),_0x281336['length']===0x1?_0x281336(_0x1b1474):_0x281336(_0x1b1474,_0x2344f0));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x4de596){try{return(_0x4de596['startsWith']('http://')||_0x4de596['startsWith']('https://')?new URL(_0x4de596)['hostname']:_0x4de596)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x14b2c4){return(await fetch(_0x14b2c4,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0xe1f89e,_0x5eb1d2){if(_0xe1f89e['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x1849fc={'alg':'none','type':'JWT'},_0x1d5650=_0x5eb1d2||'demo-project',_0x206c09=_0xe1f89e['iat']||0x0,_0x562b5f=_0xe1f89e['sub']||_0xe1f89e['user_id'];if(!_0x562b5f)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x189870={'iss':'https://securetoken.google.com/'+_0x1d5650,'aud':_0x1d5650,'iat':_0x206c09,'exp':_0x206c09+0xe10,'auth_time':_0x206c09,'sub':_0x562b5f,'user_id':_0x562b5f,'firebase':{'sign_in_provider':'custom','identities':{}},..._0xe1f89e};return[cn(JSON['stringify'](_0x1849fc)),cn(JSON['stringify'](_0x189870)),'']['join']('.');}const It={};function hc(){const _0x51cf8c={'prod':[],'emulator':[]};for(const _0x1616d6 of Object['keys'](It))It[_0x1616d6]?_0x51cf8c['emulator']['push'](_0x1616d6):_0x51cf8c['prod']['push'](_0x1616d6);return _0x51cf8c;}function uc(_0x437f3f){let _0x4de08c=document['getElementById'](_0x437f3f),_0x19b933=!0x1;return _0x4de08c||(_0x4de08c=document['createElement']('div'),_0x4de08c['setAttribute']('id',_0x437f3f),_0x19b933=!0x0),{'created':_0x19b933,'element':_0x4de08c};}let Ps=!0x1;function Kr(_0x1f0602,_0x257bbd){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x1f0602]===_0x257bbd||It[_0x1f0602]||Ps)return;It[_0x1f0602]=_0x257bbd;function _0x550687(_0x3cdee0){return'__firebase__banner__'+_0x3cdee0;}const _0x656287='__firebase__banner',_0x572861=hc()['prod']['length']>0x0;function _0x2439c6(){const _0x113902=document['getElementById'](_0x656287);_0x113902&&_0x113902['remove']();}function _0x260236(_0x68f34d){_0x68f34d['style']['display']='flex',_0x68f34d['style']['background']='#7faaf0',_0x68f34d['style']['position']='fixed',_0x68f34d['style']['bottom']='5px',_0x68f34d['style']['left']='5px',_0x68f34d['style']['padding']='.5em',_0x68f34d['style']['borderRadius']='5px',_0x68f34d['style']['alignItems']='center';}function _0x52909f(_0x17da9e,_0x4a104b){_0x17da9e['setAttribute']('width','24'),_0x17da9e['setAttribute']('id',_0x4a104b),_0x17da9e['setAttribute']('height','24'),_0x17da9e['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x17da9e['setAttribute']('fill','none'),_0x17da9e['style']['marginLeft']='-6px';}function _0x134d65(){const _0x34e8a7=document['createElement']('span');return _0x34e8a7['style']['cursor']='pointer',_0x34e8a7['style']['marginLeft']='16px',_0x34e8a7['style']['fontSize']='24px',_0x34e8a7['innerHTML']='\x20&times;',_0x34e8a7['onclick']=()=>{Ps=!0x0,_0x2439c6();},_0x34e8a7;}function _0x1b4340(_0x4c8aa3,_0x344c7f){_0x4c8aa3['setAttribute']('id',_0x344c7f),_0x4c8aa3['innerText']='Learn\x20more',_0x4c8aa3['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x4c8aa3['setAttribute']('target','__blank'),_0x4c8aa3['style']['paddingLeft']='5px',_0x4c8aa3['style']['textDecoration']='underline';}function _0x4b438a(){const _0x4103a7=uc(_0x656287),_0x49f0d4=_0x550687('text'),_0xe9b7df=document['getElementById'](_0x49f0d4)||document['createElement']('span'),_0x3533c4=_0x550687('learnmore'),_0x5120a8=document['getElementById'](_0x3533c4)||document['createElement']('a'),_0x27a84f=_0x550687('preprendIcon'),_0x166f53=document['getElementById'](_0x27a84f)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x4103a7['created']){const _0x31ed90=_0x4103a7['element'];_0x260236(_0x31ed90),_0x1b4340(_0x5120a8,_0x3533c4);const _0x14b1f2=_0x134d65();_0x52909f(_0x166f53,_0x27a84f),_0x31ed90['append'](_0x166f53,_0xe9b7df,_0x5120a8,_0x14b1f2),document['body']['appendChild'](_0x31ed90);}_0x572861?(_0xe9b7df['innerText']='Preview\x20backend\x20disconnected.',_0x166f53['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x166f53['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0xe9b7df['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0xe9b7df['setAttribute']('id',_0x49f0d4);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x4b438a):_0x4b438a();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x573cfa=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x573cfa=='object'&&_0x573cfa['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x228318=W();return _0x228318['indexOf']('MSIE\x20')>=0x0||_0x228318['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x4d5ef2,_0x589e4e)=>{try{let _0x4ad4f0=!0x0;const _0x18bc44='validate-browser-context-for-indexeddb-analytics-module',_0x35fad6=self['indexedDB']['open'](_0x18bc44);_0x35fad6['onsuccess']=()=>{_0x35fad6['result']['close'](),_0x4ad4f0||self['indexedDB']['deleteDatabase'](_0x18bc44),_0x4d5ef2(!0x0);},_0x35fad6['onupgradeneeded']=()=>{_0x4ad4f0=!0x1;},_0x35fad6['onerror']=()=>{var _0x139822;_0x589e4e(((_0x139822=_0x35fad6['error'])==null?void 0x0:_0x139822['message'])||'');};}catch(_0x485d33){_0x589e4e(_0x485d33);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x990fe8,_0x25b3c1,_0x135120){super(_0x25b3c1),this['code']=_0x990fe8,this['customData']=_0x135120,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x1a6b76,_0x91b94c,_0x49ad5b){this['service']=_0x1a6b76,this['serviceName']=_0x91b94c,this['errors']=_0x49ad5b;}['create'](_0xe71630,..._0x15fc89){const _0x3fc845=_0x15fc89[0x0]||{},_0x135967=this['service']+'/'+_0xe71630,_0x50a8ee=this['errors'][_0xe71630],_0x609a=_0x50a8ee?vc(_0x50a8ee,_0x3fc845):'Error',_0x23b1d0=this['serviceName']+':\x20'+_0x609a+'\x20('+_0x135967+').';return new Se(_0x135967,_0x23b1d0,_0x3fc845);}}function vc(_0x5f24ee,_0x3bcd6c){return _0x5f24ee['replace'](Ec,(_0xe21e3,_0x11da3e)=>{const _0x272a98=_0x3bcd6c[_0x11da3e];return _0x272a98!=null?String(_0x272a98):'<'+_0x11da3e+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x29c436){return JSON['parse'](_0x29c436);}function O(_0x580e5a){return JSON['stringify'](_0x580e5a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x12eb6e){let _0x9cd1d1={},_0x2a84d0={},_0x5de15a={},_0x24b021='';try{const _0x21c248=_0x12eb6e['split']('.');_0x9cd1d1=At(ln(_0x21c248[0x0])||''),_0x2a84d0=At(ln(_0x21c248[0x1])||''),_0x24b021=_0x21c248[0x2],_0x5de15a=_0x2a84d0['d']||{},delete _0x2a84d0['d'];}catch{}return{'header':_0x9cd1d1,'claims':_0x2a84d0,'data':_0x5de15a,'signature':_0x24b021};},Ic=function(_0x2d493c){const _0x5ddb39=Qr(_0x2d493c),_0x5b19e3=_0x5ddb39['claims'];return!!_0x5b19e3&&typeof _0x5b19e3=='object'&&_0x5b19e3['hasOwnProperty']('iat');},wc=function(_0x5df844){const _0x23ba55=Qr(_0x5df844)['claims'];return typeof _0x23ba55=='object'&&_0x23ba55['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x110b4c,_0x45d438){return Object['prototype']['hasOwnProperty']['call'](_0x110b4c,_0x45d438);}function De(_0x119e08,_0x1ea030){if(Object['prototype']['hasOwnProperty']['call'](_0x119e08,_0x1ea030))return _0x119e08[_0x1ea030];}function ui(_0x3d8264){for(const _0x2ceb0a in _0x3d8264)if(Object['prototype']['hasOwnProperty']['call'](_0x3d8264,_0x2ceb0a))return!0x1;return!0x0;}function hn(_0x7f568f,_0x418c59,_0x4d9726){const _0x52bea3={};for(const _0x5e75ef in _0x7f568f)Object['prototype']['hasOwnProperty']['call'](_0x7f568f,_0x5e75ef)&&(_0x52bea3[_0x5e75ef]=_0x418c59['call'](_0x4d9726,_0x7f568f[_0x5e75ef],_0x5e75ef,_0x7f568f));return _0x52bea3;}function Me(_0x5a6574,_0x5f3f82){if(_0x5a6574===_0x5f3f82)return!0x0;const _0x1f69fc=Object['keys'](_0x5a6574),_0x444682=Object['keys'](_0x5f3f82);for(const _0xad9fb9 of _0x1f69fc){if(!_0x444682['includes'](_0xad9fb9))return!0x1;const _0x4d9565=_0x5a6574[_0xad9fb9],_0xe92c17=_0x5f3f82[_0xad9fb9];if(Os(_0x4d9565)&&Os(_0xe92c17)){if(!Me(_0x4d9565,_0xe92c17))return!0x1;}else{if(_0x4d9565!==_0xe92c17)return!0x1;}}for(const _0xc7790d of _0x444682)if(!_0x1f69fc['includes'](_0xc7790d))return!0x1;return!0x0;}function Os(_0x1ed0bf){return _0x1ed0bf!==null&&typeof _0x1ed0bf=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x367a9b){const _0x569461=[];for(const [_0x46d0d1,_0x138678]of Object['entries'](_0x367a9b))Array['isArray'](_0x138678)?_0x138678['forEach'](_0x3fb7ed=>{_0x569461['push'](encodeURIComponent(_0x46d0d1)+'='+encodeURIComponent(_0x3fb7ed));}):_0x569461['push'](encodeURIComponent(_0x46d0d1)+'='+encodeURIComponent(_0x138678));return _0x569461['length']?'&'+_0x569461['join']('&'):'';}function vt(_0x4f894f){const _0x562915={};return _0x4f894f['replace'](/^\?/,'')['split']('&')['forEach'](_0x4931d5=>{if(_0x4931d5){const [_0xe8a438,_0x5e2a46]=_0x4931d5['split']('=');_0x562915[decodeURIComponent(_0xe8a438)]=decodeURIComponent(_0x5e2a46);}}),_0x562915;}function Et(_0x598746){const _0x98b0d=_0x598746['indexOf']('?');if(!_0x98b0d)return'';const _0x1bf437=_0x598746['indexOf']('#',_0x98b0d);return _0x598746['substring'](_0x98b0d,_0x1bf437>0x0?_0x1bf437:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x11d68e=0x1;_0x11d68e<this['blockSize'];++_0x11d68e)this['pad_'][_0x11d68e]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x309d85,_0x27b5ea){_0x27b5ea||(_0x27b5ea=0x0);const _0x54ff99=this['W_'];if(typeof _0x309d85=='string'){for(let _0x4a5dff=0x0;_0x4a5dff<0x10;_0x4a5dff++)_0x54ff99[_0x4a5dff]=_0x309d85['charCodeAt'](_0x27b5ea)<<0x18|_0x309d85['charCodeAt'](_0x27b5ea+0x1)<<0x10|_0x309d85['charCodeAt'](_0x27b5ea+0x2)<<0x8|_0x309d85['charCodeAt'](_0x27b5ea+0x3),_0x27b5ea+=0x4;}else{for(let _0x4fdd03=0x0;_0x4fdd03<0x10;_0x4fdd03++)_0x54ff99[_0x4fdd03]=_0x309d85[_0x27b5ea]<<0x18|_0x309d85[_0x27b5ea+0x1]<<0x10|_0x309d85[_0x27b5ea+0x2]<<0x8|_0x309d85[_0x27b5ea+0x3],_0x27b5ea+=0x4;}for(let _0x217ef7=0x10;_0x217ef7<0x50;_0x217ef7++){const _0x5a27d8=_0x54ff99[_0x217ef7-0x3]^_0x54ff99[_0x217ef7-0x8]^_0x54ff99[_0x217ef7-0xe]^_0x54ff99[_0x217ef7-0x10];_0x54ff99[_0x217ef7]=(_0x5a27d8<<0x1|_0x5a27d8>>>0x1f)&0xffffffff;}let _0x5b68a8=this['chain_'][0x0],_0x430a36=this['chain_'][0x1],_0x35863=this['chain_'][0x2],_0x5a7fca=this['chain_'][0x3],_0x2c23d1=this['chain_'][0x4],_0x163c51,_0x34a1a4;for(let _0x5ed319=0x0;_0x5ed319<0x50;_0x5ed319++){_0x5ed319<0x28?_0x5ed319<0x14?(_0x163c51=_0x5a7fca^_0x430a36&(_0x35863^_0x5a7fca),_0x34a1a4=0x5a827999):(_0x163c51=_0x430a36^_0x35863^_0x5a7fca,_0x34a1a4=0x6ed9eba1):_0x5ed319<0x3c?(_0x163c51=_0x430a36&_0x35863|_0x5a7fca&(_0x430a36|_0x35863),_0x34a1a4=0x8f1bbcdc):(_0x163c51=_0x430a36^_0x35863^_0x5a7fca,_0x34a1a4=0xca62c1d6);const _0x5c965a=(_0x5b68a8<<0x5|_0x5b68a8>>>0x1b)+_0x163c51+_0x2c23d1+_0x34a1a4+_0x54ff99[_0x5ed319]&0xffffffff;_0x2c23d1=_0x5a7fca,_0x5a7fca=_0x35863,_0x35863=(_0x430a36<<0x1e|_0x430a36>>>0x2)&0xffffffff,_0x430a36=_0x5b68a8,_0x5b68a8=_0x5c965a;}this['chain_'][0x0]=this['chain_'][0x0]+_0x5b68a8&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x430a36&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x35863&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x5a7fca&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x2c23d1&0xffffffff;}['update'](_0x1102e9,_0x46a55a){if(_0x1102e9==null)return;_0x46a55a===void 0x0&&(_0x46a55a=_0x1102e9['length']);const _0x2ad529=_0x46a55a-this['blockSize'];let _0x43cf58=0x0;const _0x188e3e=this['buf_'];let _0x19394c=this['inbuf_'];for(;_0x43cf58<_0x46a55a;){if(_0x19394c===0x0){for(;_0x43cf58<=_0x2ad529;)this['compress_'](_0x1102e9,_0x43cf58),_0x43cf58+=this['blockSize'];}if(typeof _0x1102e9=='string'){for(;_0x43cf58<_0x46a55a;)if(_0x188e3e[_0x19394c]=_0x1102e9['charCodeAt'](_0x43cf58),++_0x19394c,++_0x43cf58,_0x19394c===this['blockSize']){this['compress_'](_0x188e3e),_0x19394c=0x0;break;}}else{for(;_0x43cf58<_0x46a55a;)if(_0x188e3e[_0x19394c]=_0x1102e9[_0x43cf58],++_0x19394c,++_0x43cf58,_0x19394c===this['blockSize']){this['compress_'](_0x188e3e),_0x19394c=0x0;break;}}}this['inbuf_']=_0x19394c,this['total_']+=_0x46a55a;}['digest'](){const _0x19fdc0=[];let _0x520181=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x2dbde1=this['blockSize']-0x1;_0x2dbde1>=0x38;_0x2dbde1--)this['buf_'][_0x2dbde1]=_0x520181&0xff,_0x520181/=0x100;this['compress_'](this['buf_']);let _0x472053=0x0;for(let _0x5ad1bd=0x0;_0x5ad1bd<0x5;_0x5ad1bd++)for(let _0x16b1fb=0x18;_0x16b1fb>=0x0;_0x16b1fb-=0x8)_0x19fdc0[_0x472053]=this['chain_'][_0x5ad1bd]>>_0x16b1fb&0xff,++_0x472053;return _0x19fdc0;}}function Tc(_0x4c4a62,_0x256134){const _0x54fd12=new Sc(_0x4c4a62,_0x256134);return _0x54fd12['subscribe']['bind'](_0x54fd12);}class Sc{constructor(_0x23bf00,_0x12e33a){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x12e33a,this['task']['then'](()=>{_0x23bf00(this);})['catch'](_0xdfe45e=>{this['error'](_0xdfe45e);});}['next'](_0x1fd94c){this['forEachObserver'](_0x2cf075=>{_0x2cf075['next'](_0x1fd94c);});}['error'](_0x5c076c){this['forEachObserver'](_0x38c3b4=>{_0x38c3b4['error'](_0x5c076c);}),this['close'](_0x5c076c);}['complete'](){this['forEachObserver'](_0x177615=>{_0x177615['complete']();}),this['close']();}['subscribe'](_0x1fb352,_0x2c48d8,_0x3e2dd6){let _0x472f21;if(_0x1fb352===void 0x0&&_0x2c48d8===void 0x0&&_0x3e2dd6===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x1fb352,['next','error','complete'])?_0x472f21=_0x1fb352:_0x472f21={'next':_0x1fb352,'error':_0x2c48d8,'complete':_0x3e2dd6},_0x472f21['next']===void 0x0&&(_0x472f21['next']=Jn),_0x472f21['error']===void 0x0&&(_0x472f21['error']=Jn),_0x472f21['complete']===void 0x0&&(_0x472f21['complete']=Jn);const _0x15e4d7=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x472f21['error'](this['finalError']):_0x472f21['complete']();}catch{}}),this['observers']['push'](_0x472f21),_0x15e4d7;}['unsubscribeOne'](_0x205f20){this['observers']===void 0x0||this['observers'][_0x205f20]===void 0x0||(delete this['observers'][_0x205f20],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x1a9808){if(!this['finalized']){for(let _0x54840b=0x0;_0x54840b<this['observers']['length'];_0x54840b++)this['sendOne'](_0x54840b,_0x1a9808);}}['sendOne'](_0x46f486,_0x1492dd){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x46f486]!==void 0x0)try{_0x1492dd(this['observers'][_0x46f486]);}catch(_0x451d27){typeof console<'u'&&console['error']&&console['error'](_0x451d27);}});}['close'](_0x34616a){this['finalized']||(this['finalized']=!0x0,_0x34616a!==void 0x0&&(this['finalError']=_0x34616a),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x299e27,_0x29089e){if(typeof _0x299e27!='object'||_0x299e27===null)return!0x1;for(const _0x38468d of _0x29089e)if(_0x38468d in _0x299e27&&typeof _0x299e27[_0x38468d]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0xc4721f,_0x284a23){return _0xc4721f+'\x20failed:\x20'+_0x284a23+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x27b914){const _0x46be7a=[];let _0x3647b9=0x0;for(let _0x24825c=0x0;_0x24825c<_0x27b914['length'];_0x24825c++){let _0x198e7a=_0x27b914['charCodeAt'](_0x24825c);if(_0x198e7a>=0xd800&&_0x198e7a<=0xdbff){const _0x926858=_0x198e7a-0xd800;_0x24825c++,f(_0x24825c<_0x27b914['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x2fffcb=_0x27b914['charCodeAt'](_0x24825c)-0xdc00;_0x198e7a=0x10000+(_0x926858<<0xa)+_0x2fffcb;}_0x198e7a<0x80?_0x46be7a[_0x3647b9++]=_0x198e7a:_0x198e7a<0x800?(_0x46be7a[_0x3647b9++]=_0x198e7a>>0x6|0xc0,_0x46be7a[_0x3647b9++]=_0x198e7a&0x3f|0x80):_0x198e7a<0x10000?(_0x46be7a[_0x3647b9++]=_0x198e7a>>0xc|0xe0,_0x46be7a[_0x3647b9++]=_0x198e7a>>0x6&0x3f|0x80,_0x46be7a[_0x3647b9++]=_0x198e7a&0x3f|0x80):(_0x46be7a[_0x3647b9++]=_0x198e7a>>0x12|0xf0,_0x46be7a[_0x3647b9++]=_0x198e7a>>0xc&0x3f|0x80,_0x46be7a[_0x3647b9++]=_0x198e7a>>0x6&0x3f|0x80,_0x46be7a[_0x3647b9++]=_0x198e7a&0x3f|0x80);}return _0x46be7a;},On=function(_0x4d2a95){let _0x27c759=0x0;for(let _0xdd1c58=0x0;_0xdd1c58<_0x4d2a95['length'];_0xdd1c58++){const _0x3e0666=_0x4d2a95['charCodeAt'](_0xdd1c58);_0x3e0666<0x80?_0x27c759++:_0x3e0666<0x800?_0x27c759+=0x2:_0x3e0666>=0xd800&&_0x3e0666<=0xdbff?(_0x27c759+=0x4,_0xdd1c58++):_0x27c759+=0x3;}return _0x27c759;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x42e182){return _0x42e182&&_0x42e182['_delegate']?_0x42e182['_delegate']:_0x42e182;}class Le{constructor(_0x5f6e62,_0x24fa03,_0x27585c){this['name']=_0x5f6e62,this['instanceFactory']=_0x24fa03,this['type']=_0x27585c,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x4b0c23){return this['instantiationMode']=_0x4b0c23,this;}['setMultipleInstances'](_0x37d427){return this['multipleInstances']=_0x37d427,this;}['setServiceProps'](_0x485ecf){return this['serviceProps']=_0x485ecf,this;}['setInstanceCreatedCallback'](_0x238344){return this['onInstanceCreated']=_0x238344,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0xfdae64,_0x2f1665){this['name']=_0xfdae64,this['container']=_0x2f1665,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0xd0e25c){const _0x25efa2=this['normalizeInstanceIdentifier'](_0xd0e25c);if(!this['instancesDeferred']['has'](_0x25efa2)){const _0x25c3dd=new ot();if(this['instancesDeferred']['set'](_0x25efa2,_0x25c3dd),this['isInitialized'](_0x25efa2)||this['shouldAutoInitialize']())try{const _0x2725dd=this['getOrInitializeService']({'instanceIdentifier':_0x25efa2});_0x2725dd&&_0x25c3dd['resolve'](_0x2725dd);}catch{}}return this['instancesDeferred']['get'](_0x25efa2)['promise'];}['getImmediate'](_0x5853c6){const _0x35461f=this['normalizeInstanceIdentifier'](_0x5853c6==null?void 0x0:_0x5853c6['identifier']),_0x4eb8b7=(_0x5853c6==null?void 0x0:_0x5853c6['optional'])??!0x1;if(this['isInitialized'](_0x35461f)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x35461f});}catch(_0x3decb3){if(_0x4eb8b7)return null;throw _0x3decb3;}else{if(_0x4eb8b7)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x51401d){if(_0x51401d['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x51401d['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x51401d,!!this['shouldAutoInitialize']()){if(Nc(_0x51401d))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x2e0e6b,_0xd8d4d6]of this['instancesDeferred']['entries']()){const _0x5a8af1=this['normalizeInstanceIdentifier'](_0x2e0e6b);try{const _0x12d272=this['getOrInitializeService']({'instanceIdentifier':_0x5a8af1});_0xd8d4d6['resolve'](_0x12d272);}catch{}}}}['clearInstance'](_0x3c2f5e=Ne){this['instancesDeferred']['delete'](_0x3c2f5e),this['instancesOptions']['delete'](_0x3c2f5e),this['instances']['delete'](_0x3c2f5e);}async['delete'](){const _0x43f0a1=Array['from'](this['instances']['values']());await Promise['all']([..._0x43f0a1['filter'](_0x4b491e=>'INTERNAL'in _0x4b491e)['map'](_0xec756b=>_0xec756b['INTERNAL']['delete']()),..._0x43f0a1['filter'](_0x4a52a3=>'_delete'in _0x4a52a3)['map'](_0x5361d9=>_0x5361d9['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x1e42d9=Ne){return this['instances']['has'](_0x1e42d9);}['getOptions'](_0x163d24=Ne){return this['instancesOptions']['get'](_0x163d24)||{};}['initialize'](_0x3d1458={}){const {options:_0x448f34={}}=_0x3d1458,_0x43777f=this['normalizeInstanceIdentifier'](_0x3d1458['instanceIdentifier']);if(this['isInitialized'](_0x43777f))throw Error(this['name']+'('+_0x43777f+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x3ddcac=this['getOrInitializeService']({'instanceIdentifier':_0x43777f,'options':_0x448f34});for(const [_0x2cb112,_0x291893]of this['instancesDeferred']['entries']()){const _0x4af285=this['normalizeInstanceIdentifier'](_0x2cb112);_0x43777f===_0x4af285&&_0x291893['resolve'](_0x3ddcac);}return _0x3ddcac;}['onInit'](_0x442a3a,_0x184a69){const _0x4d0c13=this['normalizeInstanceIdentifier'](_0x184a69),_0x2d11c9=this['onInitCallbacks']['get'](_0x4d0c13)??new Set();_0x2d11c9['add'](_0x442a3a),this['onInitCallbacks']['set'](_0x4d0c13,_0x2d11c9);const _0x2d7bda=this['instances']['get'](_0x4d0c13);return _0x2d7bda&&_0x442a3a(_0x2d7bda,_0x4d0c13),()=>{_0x2d11c9['delete'](_0x442a3a);};}['invokeOnInitCallbacks'](_0x2834bc,_0x2f17ad){const _0x5cfde1=this['onInitCallbacks']['get'](_0x2f17ad);if(_0x5cfde1){for(const _0x108582 of _0x5cfde1)try{_0x108582(_0x2834bc,_0x2f17ad);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x208ecd,options:_0x2531d6={}}){let _0x1b9c95=this['instances']['get'](_0x208ecd);if(!_0x1b9c95&&this['component']&&(_0x1b9c95=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x208ecd),'options':_0x2531d6}),this['instances']['set'](_0x208ecd,_0x1b9c95),this['instancesOptions']['set'](_0x208ecd,_0x2531d6),this['invokeOnInitCallbacks'](_0x1b9c95,_0x208ecd),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x208ecd,_0x1b9c95);}catch{}return _0x1b9c95||null;}['normalizeInstanceIdentifier'](_0x486c60=Ne){return this['component']?this['component']['multipleInstances']?_0x486c60:Ne:_0x486c60;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x25ced9){return _0x25ced9===Ne?void 0x0:_0x25ced9;}function Nc(_0x324034){return _0x324034['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x3c1600){this['name']=_0x3c1600,this['providers']=new Map();}['addComponent'](_0x5585e5){const _0x370ba4=this['getProvider'](_0x5585e5['name']);if(_0x370ba4['isComponentSet']())throw new Error('Component\x20'+_0x5585e5['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x370ba4['setComponent'](_0x5585e5);}['addOrOverwriteComponent'](_0x436d4a){this['getProvider'](_0x436d4a['name'])['isComponentSet']()&&this['providers']['delete'](_0x436d4a['name']),this['addComponent'](_0x436d4a);}['getProvider'](_0x5b2500){if(this['providers']['has'](_0x5b2500))return this['providers']['get'](_0x5b2500);const _0x2f7f1c=new Ac(_0x5b2500,this);return this['providers']['set'](_0x5b2500,_0x2f7f1c),_0x2f7f1c;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x48c85e){_0x48c85e[_0x48c85e['DEBUG']=0x0]='DEBUG',_0x48c85e[_0x48c85e['VERBOSE']=0x1]='VERBOSE',_0x48c85e[_0x48c85e['INFO']=0x2]='INFO',_0x48c85e[_0x48c85e['WARN']=0x3]='WARN',_0x48c85e[_0x48c85e['ERROR']=0x4]='ERROR',_0x48c85e[_0x48c85e['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x215313,_0x16781a,..._0x5afc8c)=>{if(_0x16781a<_0x215313['logLevel'])return;const _0x21d504=new Date()['toISOString'](),_0x1d44c2=Mc[_0x16781a];if(_0x1d44c2)console[_0x1d44c2]('['+_0x21d504+']\x20\x20'+_0x215313['name']+':',..._0x5afc8c);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x16781a+')');};class Ui{constructor(_0x358749){this['name']=_0x358749,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x454fc7){if(!(_0x454fc7 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x454fc7+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x454fc7;}['setLogLevel'](_0x366321){this['_logLevel']=typeof _0x366321=='string'?Oc[_0x366321]:_0x366321;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x1da702){if(typeof _0x1da702!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x1da702;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x67d693){this['_userLogHandler']=_0x67d693;}['debug'](..._0x2ebb75){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x2ebb75),this['_logHandler'](this,T['DEBUG'],..._0x2ebb75);}['log'](..._0x407920){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x407920),this['_logHandler'](this,T['VERBOSE'],..._0x407920);}['info'](..._0x23c598){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x23c598),this['_logHandler'](this,T['INFO'],..._0x23c598);}['warn'](..._0x6564d9){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x6564d9),this['_logHandler'](this,T['WARN'],..._0x6564d9);}['error'](..._0x2cfa96){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x2cfa96),this['_logHandler'](this,T['ERROR'],..._0x2cfa96);}}const xc=(_0xeaa887,_0x529423)=>_0x529423['some'](_0x54cb69=>_0xeaa887 instanceof _0x54cb69);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x522f96){const _0x44f3f6=new Promise((_0x428898,_0x3e2a3e)=>{const _0x452b92=()=>{_0x522f96['removeEventListener']('success',_0x17c64b),_0x522f96['removeEventListener']('error',_0xdba9b4);},_0x17c64b=()=>{_0x428898(_e(_0x522f96['result'])),_0x452b92();},_0xdba9b4=()=>{_0x3e2a3e(_0x522f96['error']),_0x452b92();};_0x522f96['addEventListener']('success',_0x17c64b),_0x522f96['addEventListener']('error',_0xdba9b4);});return _0x44f3f6['then'](_0x3859d3=>{_0x3859d3 instanceof IDBCursor&&Jr['set'](_0x3859d3,_0x522f96);})['catch'](()=>{}),Wi['set'](_0x44f3f6,_0x522f96),_0x44f3f6;}function Bc(_0x30cbb0){if(di['has'](_0x30cbb0))return;const _0x40b343=new Promise((_0x268e8a,_0x12654f)=>{const _0x3c1989=()=>{_0x30cbb0['removeEventListener']('complete',_0x1db8fb),_0x30cbb0['removeEventListener']('error',_0x30f7f5),_0x30cbb0['removeEventListener']('abort',_0x30f7f5);},_0x1db8fb=()=>{_0x268e8a(),_0x3c1989();},_0x30f7f5=()=>{_0x12654f(_0x30cbb0['error']||new DOMException('AbortError','AbortError')),_0x3c1989();};_0x30cbb0['addEventListener']('complete',_0x1db8fb),_0x30cbb0['addEventListener']('error',_0x30f7f5),_0x30cbb0['addEventListener']('abort',_0x30f7f5);});di['set'](_0x30cbb0,_0x40b343);}let fi={'get'(_0x33abbc,_0x43ca84,_0x988101){if(_0x33abbc instanceof IDBTransaction){if(_0x43ca84==='done')return di['get'](_0x33abbc);if(_0x43ca84==='objectStoreNames')return _0x33abbc['objectStoreNames']||Xr['get'](_0x33abbc);if(_0x43ca84==='store')return _0x988101['objectStoreNames'][0x1]?void 0x0:_0x988101['objectStore'](_0x988101['objectStoreNames'][0x0]);}return _e(_0x33abbc[_0x43ca84]);},'set'(_0x1ee024,_0x56ae6a,_0x4dc1ad){return _0x1ee024[_0x56ae6a]=_0x4dc1ad,!0x0;},'has'(_0xb48501,_0x343dce){return _0xb48501 instanceof IDBTransaction&&(_0x343dce==='done'||_0x343dce==='store')?!0x0:_0x343dce in _0xb48501;}};function Vc(_0x3e2342){fi=_0x3e2342(fi);}function Hc(_0x53fd20){return _0x53fd20===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x186e3f,..._0x307067){const _0x50f322=_0x53fd20['call'](Zn(this),_0x186e3f,..._0x307067);return Xr['set'](_0x50f322,_0x186e3f['sort']?_0x186e3f['sort']():[_0x186e3f]),_e(_0x50f322);}:Uc()['includes'](_0x53fd20)?function(..._0x4c4c9c){return _0x53fd20['apply'](Zn(this),_0x4c4c9c),_e(Jr['get'](this));}:function(..._0x48c3e5){return _e(_0x53fd20['apply'](Zn(this),_0x48c3e5));};}function $c(_0x67dca1){return typeof _0x67dca1=='function'?Hc(_0x67dca1):(_0x67dca1 instanceof IDBTransaction&&Bc(_0x67dca1),xc(_0x67dca1,Fc())?new Proxy(_0x67dca1,fi):_0x67dca1);}function _e(_0x51d1ab){if(_0x51d1ab instanceof IDBRequest)return Wc(_0x51d1ab);if(Xn['has'](_0x51d1ab))return Xn['get'](_0x51d1ab);const _0x297ab5=$c(_0x51d1ab);return _0x297ab5!==_0x51d1ab&&(Xn['set'](_0x51d1ab,_0x297ab5),Wi['set'](_0x297ab5,_0x51d1ab)),_0x297ab5;}const Zn=_0xb53902=>Wi['get'](_0xb53902);function Gc(_0x1be384,_0x4fe17b,{blocked:_0x369aba,upgrade:_0x35b720,blocking:_0x56e9dc,terminated:_0x5e03fc}={}){const _0x289f53=indexedDB['open'](_0x1be384,_0x4fe17b),_0x26d7f8=_e(_0x289f53);return _0x35b720&&_0x289f53['addEventListener']('upgradeneeded',_0x2a4372=>{_0x35b720(_e(_0x289f53['result']),_0x2a4372['oldVersion'],_0x2a4372['newVersion'],_e(_0x289f53['transaction']),_0x2a4372);}),_0x369aba&&_0x289f53['addEventListener']('blocked',_0x542433=>_0x369aba(_0x542433['oldVersion'],_0x542433['newVersion'],_0x542433)),_0x26d7f8['then'](_0x442ef3=>{_0x5e03fc&&_0x442ef3['addEventListener']('close',()=>_0x5e03fc()),_0x56e9dc&&_0x442ef3['addEventListener']('versionchange',_0x412fd1=>_0x56e9dc(_0x412fd1['oldVersion'],_0x412fd1['newVersion'],_0x412fd1));})['catch'](()=>{}),_0x26d7f8;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x1ad9b9,_0x20ac5e){if(!(_0x1ad9b9 instanceof IDBDatabase&&!(_0x20ac5e in _0x1ad9b9)&&typeof _0x20ac5e=='string'))return;if(ei['get'](_0x20ac5e))return ei['get'](_0x20ac5e);const _0x56ba61=_0x20ac5e['replace'](/FromIndex$/,''),_0x442806=_0x20ac5e!==_0x56ba61,_0x1c6809=zc['includes'](_0x56ba61);if(!(_0x56ba61 in(_0x442806?IDBIndex:IDBObjectStore)['prototype'])||!(_0x1c6809||qc['includes'](_0x56ba61)))return;const _0x2401ac=async function(_0x264b9e,..._0x2783cd){const _0x56fe84=this['transaction'](_0x264b9e,_0x1c6809?'readwrite':'readonly');let _0xce6091=_0x56fe84['store'];return _0x442806&&(_0xce6091=_0xce6091['index'](_0x2783cd['shift']())),(await Promise['all']([_0xce6091[_0x56ba61](..._0x2783cd),_0x1c6809&&_0x56fe84['done']]))[0x0];};return ei['set'](_0x20ac5e,_0x2401ac),_0x2401ac;}Vc(_0x5d1cf6=>({..._0x5d1cf6,'get':(_0x59f56a,_0x1a792b,_0x4dca46)=>Ls(_0x59f56a,_0x1a792b)||_0x5d1cf6['get'](_0x59f56a,_0x1a792b,_0x4dca46),'has':(_0x837815,_0x5a1494)=>!!Ls(_0x837815,_0x5a1494)||_0x5d1cf6['has'](_0x837815,_0x5a1494)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x3fa423){this['container']=_0x3fa423;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x59c22a=>{if(Kc(_0x59c22a)){const _0x498271=_0x59c22a['getImmediate']();return _0x498271['library']+'/'+_0x498271['version'];}else return null;})['filter'](_0x31cd35=>_0x31cd35)['join']('\x20');}}function Kc(_0x654351){const _0x3c6380=_0x654351['getComponent']();return(_0x3c6380==null?void 0x0:_0x3c6380['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x1d90d6,_0x53092a){try{_0x1d90d6['container']['addComponent'](_0x53092a);}catch(_0x43a866){oe['debug']('Component\x20'+_0x53092a['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x1d90d6['name'],_0x43a866);}}function Ze(_0x1b774f){const _0x11a088=_0x1b774f['name'];if(mi['has'](_0x11a088))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x11a088+'.'),!0x1;mi['set'](_0x11a088,_0x1b774f);for(const _0x34098d of xe['values']())Fs(_0x34098d,_0x1b774f);for(const _0x59d98c of gi['values']())Fs(_0x59d98c,_0x1b774f);return!0x0;}function Bi(_0x355793,_0xcf5c63){const _0xc035b3=_0x355793['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0xc035b3&&_0xc035b3['triggerHeartbeat'](),_0x355793['container']['getProvider'](_0xcf5c63);}function $(_0x85806c){return _0x85806c==null?!0x1:_0x85806c['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x2f9122,_0x3a9f14,_0x420fdc){this['_isDeleted']=!0x1,this['_options']={..._0x2f9122},this['_config']={..._0x3a9f14},this['_name']=_0x3a9f14['name'],this['_automaticDataCollectionEnabled']=_0x3a9f14['automaticDataCollectionEnabled'],this['_container']=_0x420fdc,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x4632e5){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x4632e5;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x193c29){this['_isDeleted']=_0x193c29;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x2ac2d0,_0x2ea555={}){let _0x1e7c21=_0x2ac2d0;typeof _0x2ea555!='object'&&(_0x2ea555={'name':_0x2ea555});const _0x4267d0={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x2ea555},_0x46415e=_0x4267d0['name'];if(typeof _0x46415e!='string'||!_0x46415e)throw ge['create']('bad-app-name',{'appName':String(_0x46415e)});if(_0x1e7c21||(_0x1e7c21=qr()),!_0x1e7c21)throw ge['create']('no-options');const _0x46076e=xe['get'](_0x46415e);if(_0x46076e){if(Me(_0x1e7c21,_0x46076e['options'])&&Me(_0x4267d0,_0x46076e['config']))return _0x46076e;throw ge['create']('duplicate-app',{'appName':_0x46415e});}const _0x57ff13=new Pc(_0x46415e);for(const _0x1c80e4 of mi['values']())_0x57ff13['addComponent'](_0x1c80e4);const _0x1a44eb=new Tl(_0x1e7c21,_0x4267d0,_0x57ff13);return xe['set'](_0x46415e,_0x1a44eb),_0x1a44eb;}function Zr(_0x26d646=_i){const _0x2f5e12=xe['get'](_0x26d646);if(!_0x2f5e12&&_0x26d646===_i&&qr())return Sl();if(!_0x2f5e12)throw ge['create']('no-app',{'appName':_0x26d646});return _0x2f5e12;}function f_(){return Array['from'](xe['values']());}async function p_(_0x3d4150){let _0xc71691=!0x1;const _0x35312a=_0x3d4150['name'];xe['has'](_0x35312a)?(_0xc71691=!0x0,xe['delete'](_0x35312a)):gi['has'](_0x35312a)&&_0x3d4150['decRefCount']()<=0x0&&(gi['delete'](_0x35312a),_0xc71691=!0x0),_0xc71691&&(await Promise['all'](_0x3d4150['container']['getProviders']()['map'](_0x3956b6=>_0x3956b6['delete']())),_0x3d4150['isDeleted']=!0x0);}function me(_0x315422,_0x480e19,_0x5d4131){let _0x369949=wl[_0x315422]??_0x315422;_0x5d4131&&(_0x369949+='-'+_0x5d4131);const _0x3c837e=_0x369949['match'](/\s|\//),_0x4c4938=_0x480e19['match'](/\s|\//);if(_0x3c837e||_0x4c4938){const _0x288f6e=['Unable\x20to\x20register\x20library\x20\x22'+_0x369949+'\x22\x20with\x20version\x20\x22'+_0x480e19+'\x22:'];_0x3c837e&&_0x288f6e['push']('library\x20name\x20\x22'+_0x369949+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x3c837e&&_0x4c4938&&_0x288f6e['push']('and'),_0x4c4938&&_0x288f6e['push']('version\x20name\x20\x22'+_0x480e19+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x288f6e['join']('\x20'));return;}Ze(new Le(_0x369949+'-version',()=>({'library':_0x369949,'version':_0x480e19}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x2fa3a0,_0x5d3617)=>{switch(_0x5d3617){case 0x0:try{_0x2fa3a0['createObjectStore'](kt);}catch(_0x408a15){console['warn'](_0x408a15);}}}})['catch'](_0x402220=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x402220['message']});})),ti;}async function Al(_0xe759d9){try{const _0x22c1c8=(await eo())['transaction'](kt),_0x351985=await _0x22c1c8['objectStore'](kt)['get'](to(_0xe759d9));return await _0x22c1c8['done'],_0x351985;}catch(_0x454726){if(_0x454726 instanceof Se)oe['warn'](_0x454726['message']);else{const _0x1eaeea=ge['create']('idb-get',{'originalErrorMessage':_0x454726==null?void 0x0:_0x454726['message']});oe['warn'](_0x1eaeea['message']);}}}async function Us(_0x9ff4fc,_0x31bc84){try{const _0x8d7b7=(await eo())['transaction'](kt,'readwrite');await _0x8d7b7['objectStore'](kt)['put'](_0x31bc84,to(_0x9ff4fc)),await _0x8d7b7['done'];}catch(_0x1bb166){if(_0x1bb166 instanceof Se)oe['warn'](_0x1bb166['message']);else{const _0x5b2247=ge['create']('idb-set',{'originalErrorMessage':_0x1bb166==null?void 0x0:_0x1bb166['message']});oe['warn'](_0x5b2247['message']);}}}function to(_0x17b9a8){return _0x17b9a8['name']+'!'+_0x17b9a8['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x30a59e){this['container']=_0x30a59e,this['_heartbeatsCache']=null;const _0x1eab08=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x1eab08),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x468c4f=>(this['_heartbeatsCache']=_0x468c4f,_0x468c4f));}async['triggerHeartbeat'](){var _0x2c196e,_0x1f60a1;try{const _0x4b6f8b=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x277d55=Ws();if(((_0x2c196e=this['_heartbeatsCache'])==null?void 0x0:_0x2c196e['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x1f60a1=this['_heartbeatsCache'])==null?void 0x0:_0x1f60a1['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x277d55||this['_heartbeatsCache']['heartbeats']['some'](_0x4544d8=>_0x4544d8['date']===_0x277d55))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x277d55,'agent':_0x4b6f8b}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x161a2e=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x161a2e,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x3eaa5b){oe['warn'](_0x3eaa5b);}}async['getHeartbeatsHeader'](){var _0x59f91f;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x59f91f=this['_heartbeatsCache'])==null?void 0x0:_0x59f91f['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x40c785=Ws(),{heartbeatsToSend:_0x3b003b,unsentEntries:_0x52aa17}=Ol(this['_heartbeatsCache']['heartbeats']),_0x19ede8=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x3b003b}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x40c785,_0x52aa17['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x52aa17,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x19ede8;}catch(_0x42cafa){return oe['warn'](_0x42cafa),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x1ffe6a,_0x25e082=kl){const _0x4d8f5a=[];let _0x2f7743=_0x1ffe6a['slice']();for(const _0x20085b of _0x1ffe6a){const _0x59599a=_0x4d8f5a['find'](_0x3202d9=>_0x3202d9['agent']===_0x20085b['agent']);if(_0x59599a){if(_0x59599a['dates']['push'](_0x20085b['date']),Bs(_0x4d8f5a)>_0x25e082){_0x59599a['dates']['pop']();break;}}else{if(_0x4d8f5a['push']({'agent':_0x20085b['agent'],'dates':[_0x20085b['date']]}),Bs(_0x4d8f5a)>_0x25e082){_0x4d8f5a['pop']();break;}}_0x2f7743=_0x2f7743['slice'](0x1);}return{'heartbeatsToSend':_0x4d8f5a,'unsentEntries':_0x2f7743};}class Dl{constructor(_0x4f48f3){this['app']=_0x4f48f3,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0xfe99be=await Al(this['app']);return _0xfe99be!=null&&_0xfe99be['heartbeats']?_0xfe99be:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x40aa9c){if(await this['_canUseIndexedDBPromise']){const _0xe52c0d=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x40aa9c['lastSentHeartbeatDate']??_0xe52c0d['lastSentHeartbeatDate'],'heartbeats':_0x40aa9c['heartbeats']});}else return;}async['add'](_0x522416){if(await this['_canUseIndexedDBPromise']){const _0x35bbbe=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x522416['lastSentHeartbeatDate']??_0x35bbbe['lastSentHeartbeatDate'],'heartbeats':[..._0x35bbbe['heartbeats'],..._0x522416['heartbeats']]});}else return;}}function Bs(_0x38d7da){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x38d7da}))['length'];}function Ml(_0x1750bf){if(_0x1750bf['length']===0x0)return-0x1;let _0xe43b3e=0x0,_0x3eb99d=_0x1750bf[0x0]['date'];for(let _0x451caf=0x1;_0x451caf<_0x1750bf['length'];_0x451caf++)_0x1750bf[_0x451caf]['date']<_0x3eb99d&&(_0x3eb99d=_0x1750bf[_0x451caf]['date'],_0xe43b3e=_0x451caf);return _0xe43b3e;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x1e6c5b){Ze(new Le('platform-logger',_0x470c93=>new jc(_0x470c93),'PRIVATE')),Ze(new Le('heartbeat',_0x5cb0f0=>new Pl(_0x5cb0f0),'PRIVATE')),me(pi,xs,_0x1e6c5b),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x4663ac){no=_0x4663ac;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x190b62){this['domStorage_']=_0x190b62,this['prefix_']='firebase:';}['set'](_0x5e7ec3,_0x338f22){_0x338f22==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x5e7ec3)):this['domStorage_']['setItem'](this['prefixedName_'](_0x5e7ec3),O(_0x338f22));}['get'](_0x48b793){const _0x5ef5cd=this['domStorage_']['getItem'](this['prefixedName_'](_0x48b793));return _0x5ef5cd==null?null:At(_0x5ef5cd);}['remove'](_0x1a73ab){this['domStorage_']['removeItem'](this['prefixedName_'](_0x1a73ab));}['prefixedName_'](_0x402977){return this['prefix_']+_0x402977;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x27d362,_0x5bdbcf){_0x5bdbcf==null?delete this['cache_'][_0x27d362]:this['cache_'][_0x27d362]=_0x5bdbcf;}['get'](_0x1a27ec){return J(this['cache_'],_0x1a27ec)?this['cache_'][_0x1a27ec]:null;}['remove'](_0x444fad){delete this['cache_'][_0x444fad];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x4ce62b){try{if(typeof window<'u'&&typeof window[_0x4ce62b]<'u'){const _0x41d058=window[_0x4ce62b];return _0x41d058['setItem']('firebase:sentinel','cache'),_0x41d058['removeItem']('firebase:sentinel'),new Wl(_0x41d058);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x176336=0x1;return function(){return _0x176336++;};}()),ro=function(_0x585f7f){const _0x48e7b6=Rc(_0x585f7f),_0x3675df=new Cc();_0x3675df['update'](_0x48e7b6);const _0x4ceb41=_0x3675df['digest']();return Li['encodeByteArray'](_0x4ceb41);},Vt=function(..._0xb4c931){let _0x327cfa='';for(let _0x3ebb15=0x0;_0x3ebb15<_0xb4c931['length'];_0x3ebb15++){const _0xef9df4=_0xb4c931[_0x3ebb15];Array['isArray'](_0xef9df4)||_0xef9df4&&typeof _0xef9df4=='object'&&typeof _0xef9df4['length']=='number'?_0x327cfa+=Vt['apply'](null,_0xef9df4):typeof _0xef9df4=='object'?_0x327cfa+=O(_0xef9df4):_0x327cfa+=_0xef9df4,_0x327cfa+='\x20';}return _0x327cfa;};let wt=null,Gs=!0x0;const Hl=function(_0x106673,_0x3e16ac){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x4cf923){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x15fb68=Vt['apply'](null,_0x4cf923);wt(_0x15fb68);}},Ht=function(_0x360f73){return function(..._0x137616){L(_0x360f73,..._0x137616);};},yi=function(..._0x3e4acb){const _0x66ed1a='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x3e4acb);Ye['error'](_0x66ed1a);},ae=function(..._0x4140b2){const _0x2d29c8='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x4140b2);throw Ye['error'](_0x2d29c8),new Error(_0x2d29c8);},U=function(..._0x536060){const _0x174d9e='FIREBASE\x20WARNING:\x20'+Vt(..._0x536060);Ye['warn'](_0x174d9e);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x1d2c1a){return typeof _0x1d2c1a=='number'&&(_0x1d2c1a!==_0x1d2c1a||_0x1d2c1a===Number['POSITIVE_INFINITY']||_0x1d2c1a===Number['NEGATIVE_INFINITY']);},Gl=function(_0x26eab5){if(document['readyState']==='complete')_0x26eab5();else{let _0x2d77da=!0x1;const _0x4d4b6e=function(){if(!document['body']){setTimeout(_0x4d4b6e,Math['floor'](0xa));return;}_0x2d77da||(_0x2d77da=!0x0,_0x26eab5());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x4d4b6e,!0x1),window['addEventListener']('load',_0x4d4b6e,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x4d4b6e();}),window['attachEvent']('onload',_0x4d4b6e));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x2ce859,_0xb20393){if(_0x2ce859===_0xb20393)return 0x0;if(_0x2ce859===Fe||_0xb20393===Ie)return-0x1;if(_0xb20393===Fe||_0x2ce859===Ie)return 0x1;{const _0x586212=qs(_0x2ce859),_0x621d60=qs(_0xb20393);return _0x586212!==null?_0x621d60!==null?_0x586212-_0x621d60===0x0?_0x2ce859['length']-_0xb20393['length']:_0x586212-_0x621d60:-0x1:_0x621d60!==null?0x1:_0x2ce859<_0xb20393?-0x1:0x1;}},ql=function(_0x468fb7,_0x49b768){return _0x468fb7===_0x49b768?0x0:_0x468fb7<_0x49b768?-0x1:0x1;},_t=function(_0x50a4fa,_0x1ac381){if(_0x1ac381&&_0x50a4fa in _0x1ac381)return _0x1ac381[_0x50a4fa];throw new Error('Missing\x20required\x20key\x20('+_0x50a4fa+')\x20in\x20object:\x20'+O(_0x1ac381));},Hi=function(_0x44754d){if(typeof _0x44754d!='object'||_0x44754d===null)return O(_0x44754d);const _0x587bd0=[];for(const _0x51e05b in _0x44754d)_0x587bd0['push'](_0x51e05b);_0x587bd0['sort']();let _0x560202='{';for(let _0x305f94=0x0;_0x305f94<_0x587bd0['length'];_0x305f94++)_0x305f94!==0x0&&(_0x560202+=','),_0x560202+=O(_0x587bd0[_0x305f94]),_0x560202+=':',_0x560202+=Hi(_0x44754d[_0x587bd0[_0x305f94]]);return _0x560202+='}',_0x560202;},oo=function(_0x50f07e,_0x3584a2){const _0x32c20f=_0x50f07e['length'];if(_0x32c20f<=_0x3584a2)return[_0x50f07e];const _0x87a598=[];for(let _0x706e19=0x0;_0x706e19<_0x32c20f;_0x706e19+=_0x3584a2)_0x706e19+_0x3584a2>_0x32c20f?_0x87a598['push'](_0x50f07e['substring'](_0x706e19,_0x32c20f)):_0x87a598['push'](_0x50f07e['substring'](_0x706e19,_0x706e19+_0x3584a2));return _0x87a598;};function x(_0x27048f,_0x54b304){for(const _0x30c767 in _0x27048f)_0x27048f['hasOwnProperty'](_0x30c767)&&_0x54b304(_0x30c767,_0x27048f[_0x30c767]);}const ao=function(_0x305ff2){f(!Vi(_0x305ff2),'Invalid\x20JSON\x20number');const _0x1e9409=0xb,_0x2cbb8e=0x34,_0x2709d4=(0x1<<_0x1e9409-0x1)-0x1;let _0x49608a,_0x3a9f9b,_0x2d44c1,_0x2958e7,_0x4bc631;_0x305ff2===0x0?(_0x3a9f9b=0x0,_0x2d44c1=0x0,_0x49608a=0x1/_0x305ff2===-0x1/0x0?0x1:0x0):(_0x49608a=_0x305ff2<0x0,_0x305ff2=Math['abs'](_0x305ff2),_0x305ff2>=Math['pow'](0x2,0x1-_0x2709d4)?(_0x2958e7=Math['min'](Math['floor'](Math['log'](_0x305ff2)/Math['LN2']),_0x2709d4),_0x3a9f9b=_0x2958e7+_0x2709d4,_0x2d44c1=Math['round'](_0x305ff2*Math['pow'](0x2,_0x2cbb8e-_0x2958e7)-Math['pow'](0x2,_0x2cbb8e))):(_0x3a9f9b=0x0,_0x2d44c1=Math['round'](_0x305ff2/Math['pow'](0x2,0x1-_0x2709d4-_0x2cbb8e))));const _0x1eec67=[];for(_0x4bc631=_0x2cbb8e;_0x4bc631;_0x4bc631-=0x1)_0x1eec67['push'](_0x2d44c1%0x2?0x1:0x0),_0x2d44c1=Math['floor'](_0x2d44c1/0x2);for(_0x4bc631=_0x1e9409;_0x4bc631;_0x4bc631-=0x1)_0x1eec67['push'](_0x3a9f9b%0x2?0x1:0x0),_0x3a9f9b=Math['floor'](_0x3a9f9b/0x2);_0x1eec67['push'](_0x49608a?0x1:0x0),_0x1eec67['reverse']();const _0x325ad6=_0x1eec67['join']('');let _0x4db82b='';for(_0x4bc631=0x0;_0x4bc631<0x40;_0x4bc631+=0x8){let _0x49f6e8=parseInt(_0x325ad6['substr'](_0x4bc631,0x8),0x2)['toString'](0x10);_0x49f6e8['length']===0x1&&(_0x49f6e8='0'+_0x49f6e8),_0x4db82b=_0x4db82b+_0x49f6e8;}return _0x4db82b['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x4a256a,_0x159dab){let _0x52599b='Unknown\x20Error';_0x4a256a==='too_big'?_0x52599b='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x4a256a==='permission_denied'?_0x52599b='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x4a256a==='unavailable'&&(_0x52599b='The\x20service\x20is\x20unavailable');const _0x1e9e41=new Error(_0x4a256a+'\x20at\x20'+_0x159dab['_path']['toString']()+':\x20'+_0x52599b);return _0x1e9e41['code']=_0x4a256a['toUpperCase'](),_0x1e9e41;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x2efbd3){if(Yl['test'](_0x2efbd3)){const _0x28d667=Number(_0x2efbd3);if(_0x28d667>=Ql&&_0x28d667<=Jl)return _0x28d667;}return null;},ht=function(_0x1847b9){try{_0x1847b9();}catch(_0x4c2b6a){setTimeout(()=>{const _0x254370=_0x4c2b6a['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x254370),_0x4c2b6a;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x40868d,_0x548956){const _0x1887eb=setTimeout(_0x40868d,_0x548956);return typeof _0x1887eb=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x1887eb):typeof _0x1887eb=='object'&&_0x1887eb['unref']&&_0x1887eb['unref'](),_0x1887eb;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x4bf784,_0x23051d){this['appCheckProvider']=_0x23051d,this['appName']=_0x4bf784['name'],$(_0x4bf784)&&_0x4bf784['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x4bf784['settings']['appCheckToken']),this['appCheck']=_0x23051d==null?void 0x0:_0x23051d['getImmediate']({'optional':!0x0}),this['appCheck']||_0x23051d==null||_0x23051d['get']()['then'](_0x7251ed=>this['appCheck']=_0x7251ed);}['getToken'](_0x345a35){if(this['serverAppAppCheckToken']){if(_0x345a35)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x345a35):new Promise((_0x18b9e8,_0x5ec644)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x345a35)['then'](_0x18b9e8,_0x5ec644):_0x18b9e8(null);},0x0);});}['addTokenChangeListener'](_0x54e385){var _0x101092;(_0x101092=this['appCheckProvider'])==null||_0x101092['get']()['then'](_0x18a650=>_0x18a650['addTokenListener'](_0x54e385));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x273b40,_0x496590,_0x1e0b7c){this['appName_']=_0x273b40,this['firebaseOptions_']=_0x496590,this['authProvider_']=_0x1e0b7c,this['auth_']=null,this['auth_']=_0x1e0b7c['getImmediate']({'optional':!0x0}),this['auth_']||_0x1e0b7c['onInit'](_0xc11e06=>this['auth_']=_0xc11e06);}['getToken'](_0x364c2f){return this['auth_']?this['auth_']['getToken'](_0x364c2f)['catch'](_0x1b28c9=>_0x1b28c9&&_0x1b28c9['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x1b28c9)):new Promise((_0x4355e6,_0x5b4db2)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x364c2f)['then'](_0x4355e6,_0x5b4db2):_0x4355e6(null);},0x0);});}['addTokenChangeListener'](_0x49dfa3){this['auth_']?this['auth_']['addAuthTokenListener'](_0x49dfa3):this['authProvider_']['get']()['then'](_0x42665d=>_0x42665d['addAuthTokenListener'](_0x49dfa3));}['removeTokenChangeListener'](_0x102412){this['authProvider_']['get']()['then'](_0x3a4bdc=>_0x3a4bdc['removeAuthTokenListener'](_0x102412));}['notifyForInvalidToken'](){let _0xc27dad='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0xc27dad+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0xc27dad+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0xc27dad+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0xc27dad);}}class nn{constructor(_0x12353a){this['accessToken']=_0x12353a;}['getToken'](_0x467e79){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x20bccb){_0x20bccb(this['accessToken']);}['removeTokenChangeListener'](_0x1cd377){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x566437,_0x3c8016,_0x2b4052,_0x2ce937,_0x121b3e=!0x1,_0x4e49bc='',_0x31ac0a=!0x1,_0x32d036=!0x1,_0x25ab80=null){this['secure']=_0x3c8016,this['namespace']=_0x2b4052,this['webSocketOnly']=_0x2ce937,this['nodeAdmin']=_0x121b3e,this['persistenceKey']=_0x4e49bc,this['includeNamespaceInQueryParams']=_0x31ac0a,this['isUsingEmulator']=_0x32d036,this['emulatorOptions']=_0x25ab80,this['_host']=_0x566437['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x566437)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x5b1915){_0x5b1915!==this['internalHost']&&(this['internalHost']=_0x5b1915,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x322328=this['toURLString']();return this['persistenceKey']&&(_0x322328+='<'+this['persistenceKey']+'>'),_0x322328;}['toURLString'](){const _0xdfccc8=this['secure']?'https://':'http://',_0x374231=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0xdfccc8+this['host']+'/'+_0x374231;}}function th(_0x2f75ab){return _0x2f75ab['host']!==_0x2f75ab['internalHost']||_0x2f75ab['isCustomHost']()||_0x2f75ab['includeNamespaceInQueryParams'];}function vo(_0x5167b1,_0x5371f2,_0x44c7ca){f(typeof _0x5371f2=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x44c7ca=='object','typeof\x20params\x20must\x20==\x20object');let _0x2128e4;if(_0x5371f2===go)_0x2128e4=(_0x5167b1['secure']?'wss://':'ws://')+_0x5167b1['internalHost']+'/.ws?';else{if(_0x5371f2===mo)_0x2128e4=(_0x5167b1['secure']?'https://':'http://')+_0x5167b1['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x5371f2);}th(_0x5167b1)&&(_0x44c7ca['ns']=_0x5167b1['namespace']);const _0x1a56a9=[];return x(_0x44c7ca,(_0x512a63,_0x2fbc43)=>{_0x1a56a9['push'](_0x512a63+'='+_0x2fbc43);}),_0x2128e4+_0x1a56a9['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x1fd715,_0x2102ef=0x1){J(this['counters_'],_0x1fd715)||(this['counters_'][_0x1fd715]=0x0),this['counters_'][_0x1fd715]+=_0x2102ef;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x5236aa){const _0x2769fc=_0x5236aa['toString']();return ni[_0x2769fc]||(ni[_0x2769fc]=new nh()),ni[_0x2769fc];}function ih(_0x57be76,_0x967550){const _0x11a8e8=_0x57be76['toString']();return ii[_0x11a8e8]||(ii[_0x11a8e8]=_0x967550()),ii[_0x11a8e8];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x425938){this['onMessage_']=_0x425938,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x477729,_0x3f164e){this['closeAfterResponse']=_0x477729,this['onClose']=_0x3f164e,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x13f711,_0x5366bc){for(this['pendingResponses'][_0x13f711]=_0x5366bc;this['pendingResponses'][this['currentResponseNum']];){const _0x4f8c53=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x3bf637=0x0;_0x3bf637<_0x4f8c53['length'];++_0x3bf637)_0x4f8c53[_0x3bf637]&&ht(()=>{this['onMessage_'](_0x4f8c53[_0x3bf637]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x134819,_0x52f3a7,_0x4dc242,_0xeda754,_0x20608a,_0x4c62b5,_0x6b89c){this['connId']=_0x134819,this['repoInfo']=_0x52f3a7,this['applicationId']=_0x4dc242,this['appCheckToken']=_0xeda754,this['authToken']=_0x20608a,this['transportSessionId']=_0x4c62b5,this['lastSessionId']=_0x6b89c,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x134819),this['stats_']=Gi(_0x52f3a7),this['urlFn']=_0x3ec041=>(this['appCheckToken']&&(_0x3ec041[vi]=this['appCheckToken']),vo(_0x52f3a7,mo,_0x3ec041));}['open'](_0x1f269a,_0x5eb121){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x5eb121,this['myPacketOrderer']=new sh(_0x1f269a),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x58b52e)=>{const [_0x5cd741,_0x4312b7,_0x8ac6ec,_0x52ca1e,_0x5da57b]=_0x58b52e;if(this['incrementIncomingBytes_'](_0x58b52e),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x5cd741===zs)this['id']=_0x4312b7,this['password']=_0x8ac6ec;else{if(_0x5cd741===rh)_0x4312b7?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x4312b7,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x5cd741);}}},(..._0x548dab)=>{const [_0x7f473a,_0x24e0e2]=_0x548dab;this['incrementIncomingBytes_'](_0x548dab),this['myPacketOrderer']['handleResponse'](_0x7f473a,_0x24e0e2);},()=>{this['onClosed_']();},this['urlFn']);const _0xbc88fd={};_0xbc88fd[zs]='t',_0xbc88fd[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0xbc88fd[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0xbc88fd[co]=$i,this['transportSessionId']&&(_0xbc88fd[lo]=this['transportSessionId']),this['lastSessionId']&&(_0xbc88fd[po]=this['lastSessionId']),this['applicationId']&&(_0xbc88fd[_o]=this['applicationId']),this['appCheckToken']&&(_0xbc88fd[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0xbc88fd[ho]=uo);const _0x19e0d7=this['urlFn'](_0xbc88fd);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x19e0d7),this['scriptTagHolder']['addTag'](_0x19e0d7,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x2cbf00){const _0x1fc0a2=O(_0x2cbf00);this['bytesSent']+=_0x1fc0a2['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1fc0a2['length']);const _0x570109=Hr(_0x1fc0a2),_0x165cac=oo(_0x570109,fh);for(let _0x561af2=0x0;_0x561af2<_0x165cac['length'];_0x561af2++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x165cac['length'],_0x165cac[_0x561af2]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x4395e5,_0x175929){this['myDisconnFrame']=document['createElement']('iframe');const _0x56e1c6={};_0x56e1c6[dh]='t',_0x56e1c6[Eo]=_0x4395e5,_0x56e1c6[Io]=_0x175929,this['myDisconnFrame']['src']=this['urlFn'](_0x56e1c6),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x26a88b){const _0x20284e=O(_0x26a88b)['length'];this['bytesReceived']+=_0x20284e,this['stats_']['incrementCounter']('bytes_received',_0x20284e);}}class qi{constructor(_0x1ac673,_0x1c6c54,_0x1daf6e,_0x58ca54){this['onDisconnect']=_0x1daf6e,this['urlFn']=_0x58ca54,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x1ac673,window[ah+this['uniqueCallbackIdentifier']]=_0x1c6c54,this['myIFrame']=qi['createIFrame_']();let _0x2386ac='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x2386ac='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0xcbadd='<html><body>'+_0x2386ac+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0xcbadd),this['myIFrame']['doc']['close']();}catch(_0x44de20){L('frame\x20writing\x20exception'),_0x44de20['stack']&&L(_0x44de20['stack']),L(_0x44de20);}}}static['createIFrame_'](){const _0x1089d1=document['createElement']('iframe');if(_0x1089d1['style']['display']='none',document['body']){document['body']['appendChild'](_0x1089d1);try{_0x1089d1['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x279a30=document['domain'];_0x1089d1['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x279a30+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x1089d1['contentDocument']?_0x1089d1['doc']=_0x1089d1['contentDocument']:_0x1089d1['contentWindow']?_0x1089d1['doc']=_0x1089d1['contentWindow']['document']:_0x1089d1['document']&&(_0x1089d1['doc']=_0x1089d1['document']),_0x1089d1;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x11cd7f=this['onDisconnect'];_0x11cd7f&&(this['onDisconnect']=null,_0x11cd7f());}['startLongPoll'](_0x2b5157,_0xf3bbdc){for(this['myID']=_0x2b5157,this['myPW']=_0xf3bbdc,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x4fe224={};_0x4fe224[Eo]=this['myID'],_0x4fe224[Io]=this['myPW'],_0x4fe224[wo]=this['currentSerial'];let _0x13363b=this['urlFn'](_0x4fe224),_0x4a78cb='',_0x3a5949=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x4a78cb['length']<=Co;){const _0x567cd4=this['pendingSegs']['shift']();_0x4a78cb=_0x4a78cb+'&'+lh+_0x3a5949+'='+_0x567cd4['seg']+'&'+hh+_0x3a5949+'='+_0x567cd4['ts']+'&'+uh+_0x3a5949+'='+_0x567cd4['d'],_0x3a5949++;}return _0x13363b=_0x13363b+_0x4a78cb,this['addLongPollTag_'](_0x13363b,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x35c83d,_0x573d38,_0x352bb7){this['pendingSegs']['push']({'seg':_0x35c83d,'ts':_0x573d38,'d':_0x352bb7}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0xa465a8,_0x4e02fb){this['outstandingRequests']['add'](_0x4e02fb);const _0x105352=()=>{this['outstandingRequests']['delete'](_0x4e02fb),this['newRequest_']();},_0x1f51ad=setTimeout(_0x105352,Math['floor'](ph)),_0x29d0d0=()=>{clearTimeout(_0x1f51ad),_0x105352();};this['addTag'](_0xa465a8,_0x29d0d0);}['addTag'](_0x461994,_0x122f95){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0xecdcc4=this['myIFrame']['doc']['createElement']('script');_0xecdcc4['type']='text/javascript',_0xecdcc4['async']=!0x0,_0xecdcc4['src']=_0x461994,_0xecdcc4['onload']=_0xecdcc4['onreadystatechange']=function(){const _0x6fd188=_0xecdcc4['readyState'];(!_0x6fd188||_0x6fd188==='loaded'||_0x6fd188==='complete')&&(_0xecdcc4['onload']=_0xecdcc4['onreadystatechange']=null,_0xecdcc4['parentNode']&&_0xecdcc4['parentNode']['removeChild'](_0xecdcc4),_0x122f95());},_0xecdcc4['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x461994),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0xecdcc4);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x58b856,_0x342fe4,_0x13aa20,_0xe79972,_0xbac838,_0x5136b9,_0x172271){this['connId']=_0x58b856,this['applicationId']=_0x13aa20,this['appCheckToken']=_0xe79972,this['authToken']=_0xbac838,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x342fe4),this['connURL']=z['connectionURL_'](_0x342fe4,_0x5136b9,_0x172271,_0xe79972,_0x13aa20),this['nodeAdmin']=_0x342fe4['nodeAdmin'];}static['connectionURL_'](_0x3e5af2,_0x23d6af,_0xaabd55,_0x233699,_0xc21a1e){const _0x997e67={};return _0x997e67[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x997e67[ho]=uo),_0x23d6af&&(_0x997e67[lo]=_0x23d6af),_0xaabd55&&(_0x997e67[po]=_0xaabd55),_0x233699&&(_0x997e67[vi]=_0x233699),_0xc21a1e&&(_0x997e67[_o]=_0xc21a1e),vo(_0x3e5af2,go,_0x997e67);}['open'](_0x550406,_0x2e6761){this['onDisconnect']=_0x2e6761,this['onMessage']=_0x550406,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x364759;_c(),this['mySock']=new un(this['connURL'],[],_0x364759);}catch(_0x5b87f7){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x50ef40=_0x5b87f7['message']||_0x5b87f7['data'];_0x50ef40&&this['log_'](_0x50ef40),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x26b602=>{this['handleIncomingFrame'](_0x26b602);},this['mySock']['onerror']=_0x25d5a1=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x43870c=_0x25d5a1['message']||_0x25d5a1['data'];_0x43870c&&this['log_'](_0x43870c),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0xfe0ea8=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x390662=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x2812ff=navigator['userAgent']['match'](_0x390662);_0x2812ff&&_0x2812ff['length']>0x1&&parseFloat(_0x2812ff[0x1])<4.4&&(_0xfe0ea8=!0x0);}return!_0xfe0ea8&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x4f5ec3){if(this['frames']['push'](_0x4f5ec3),this['frames']['length']===this['totalFrames']){const _0x2a73f3=this['frames']['join']('');this['frames']=null;const _0x4de02b=At(_0x2a73f3);this['onMessage'](_0x4de02b);}}['handleNewFrameCount_'](_0x7ac24a){this['totalFrames']=_0x7ac24a,this['frames']=[];}['extractFrameCount_'](_0x555d83){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x555d83['length']<=0x6){const _0x5786c7=Number(_0x555d83);if(!isNaN(_0x5786c7))return this['handleNewFrameCount_'](_0x5786c7),null;}return this['handleNewFrameCount_'](0x1),_0x555d83;}['handleIncomingFrame'](_0x1cdeda){if(this['mySock']===null)return;const _0x45229e=_0x1cdeda['data'];if(this['bytesReceived']+=_0x45229e['length'],this['stats_']['incrementCounter']('bytes_received',_0x45229e['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x45229e);else{const _0x5a3ebf=this['extractFrameCount_'](_0x45229e);_0x5a3ebf!==null&&this['appendFrame_'](_0x5a3ebf);}}['send'](_0x11c4e1){this['resetKeepAlive']();const _0x4a60f1=O(_0x11c4e1);this['bytesSent']+=_0x4a60f1['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4a60f1['length']);const _0x12ae4b=oo(_0x4a60f1,gh);_0x12ae4b['length']>0x1&&this['sendString_'](String(_0x12ae4b['length']));for(let _0x518a3a=0x0;_0x518a3a<_0x12ae4b['length'];_0x518a3a++)this['sendString_'](_0x12ae4b[_0x518a3a]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0xb6c601){try{this['mySock']['send'](_0xb6c601);}catch(_0x216a61){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x216a61['message']||_0x216a61['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5b9c6f){this['initTransports_'](_0x5b9c6f);}['initTransports_'](_0x4823cb){const _0x4c0f35=z&&z['isAvailable']();let _0x2a08c0=_0x4c0f35&&!z['previouslyFailed']();if(_0x4823cb['webSocketOnly']&&(_0x4c0f35||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x2a08c0=!0x0),_0x2a08c0)this['transports_']=[z];else{const _0x57f2b4=this['transports_']=[];for(const _0x2cc38f of Nt['ALL_TRANSPORTS'])_0x2cc38f&&_0x2cc38f['isAvailable']()&&_0x57f2b4['push'](_0x2cc38f);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x4a7af8,_0x43a2e3,_0x63be01,_0x49f60e,_0x185f4d,_0x3b57b3,_0x25c71f,_0x37ee46,_0x528e8e,_0x347743){this['id']=_0x4a7af8,this['repoInfo_']=_0x43a2e3,this['applicationId_']=_0x63be01,this['appCheckToken_']=_0x49f60e,this['authToken_']=_0x185f4d,this['onMessage_']=_0x3b57b3,this['onReady_']=_0x25c71f,this['onDisconnect_']=_0x37ee46,this['onKill_']=_0x528e8e,this['lastSessionId']=_0x347743,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x43a2e3),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x1a4bca=this['transportManager_']['initialTransport']();this['conn_']=new _0x1a4bca(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x1a4bca['responsesRequiredToBeHealthy']||0x0;const _0x21155e=this['connReceiver_'](this['conn_']),_0x5c03e6=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x21155e,_0x5c03e6);},Math['floor'](0x0));const _0x282fc0=_0x1a4bca['healthyTimeout']||0x0;_0x282fc0>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x282fc0)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x307eb8){return _0x2d290b=>{_0x307eb8===this['conn_']?this['onConnectionLost_'](_0x2d290b):_0x307eb8===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x1cea42){return _0x513953=>{this['state_']!==0x2&&(_0x1cea42===this['rx_']?this['onPrimaryMessageReceived_'](_0x513953):_0x1cea42===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x513953):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x4a1dcb){const _0x1d00d1={'t':'d','d':_0x4a1dcb};this['sendData_'](_0x1d00d1);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0xa2f452){if(si in _0xa2f452){const _0x3659f5=_0xa2f452[si];_0x3659f5===Qs?this['upgradeIfSecondaryHealthy_']():_0x3659f5===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x3659f5===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x11a80b){const _0x2961b4=_t('t',_0x11a80b),_0x4df047=_t('d',_0x11a80b);if(_0x2961b4==='c')this['onSecondaryControl_'](_0x4df047);else{if(_0x2961b4==='d')this['pendingDataMessages']['push'](_0x4df047);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x2961b4);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x17074d){const _0x1cd3ee=_t('t',_0x17074d),_0x106ebd=_t('d',_0x17074d);_0x1cd3ee==='c'?this['onControl_'](_0x106ebd):_0x1cd3ee==='d'&&this['onDataMessage_'](_0x106ebd);}['onDataMessage_'](_0xa65302){this['onPrimaryResponse_'](),this['onMessage_'](_0xa65302);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x46fbab){const _0x5b46b6=_t(si,_0x46fbab);if(js in _0x46fbab){const _0x3e2f0c=_0x46fbab[js];if(_0x5b46b6===Th){const _0x4fa5fe={..._0x3e2f0c};this['repoInfo_']['isUsingEmulator']&&(_0x4fa5fe['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x4fa5fe);}else{if(_0x5b46b6===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x182369=0x0;_0x182369<this['pendingDataMessages']['length'];++_0x182369)this['onDataMessage_'](this['pendingDataMessages'][_0x182369]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x5b46b6===wh?this['onConnectionShutdown_'](_0x3e2f0c):_0x5b46b6===Ks?this['onReset_'](_0x3e2f0c):_0x5b46b6===Ch?yi('Server\x20Error:\x20'+_0x3e2f0c):_0x5b46b6===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x5b46b6);}}}['onHandshake_'](_0x3434c3){const _0x1e5576=_0x3434c3['ts'],_0x2af3ac=_0x3434c3['v'],_0x49f8ab=_0x3434c3['h'];this['sessionId']=_0x3434c3['s'],this['repoInfo_']['host']=_0x49f8ab,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x1e5576),$i!==_0x2af3ac&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x21f86c=this['transportManager_']['upgradeTransport']();_0x21f86c&&this['startUpgrade_'](_0x21f86c);}['startUpgrade_'](_0x2473a5){this['secondaryConn_']=new _0x2473a5(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x2473a5['responsesRequiredToBeHealthy']||0x0;const _0x161d6f=this['connReceiver_'](this['secondaryConn_']),_0x531d91=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x161d6f,_0x531d91),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x2ea843){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x2ea843),this['repoInfo_']['host']=_0x2ea843,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x4a6900,_0x3da5a4){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x4a6900,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x3da5a4,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x455606=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x455606||this['rx_']===_0x455606)&&this['close']();}['onConnectionLost_'](_0x3f714c){this['conn_']=null,!_0x3f714c&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x52cad2){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x52cad2),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x477ee2){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x477ee2);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x3bd64a,_0x4848c0,_0x651cf2,_0x5b30f3){}['merge'](_0x3e3520,_0x387a6d,_0x56dfe9,_0x40b872){}['refreshAuthToken'](_0x4270c5){}['refreshAppCheckToken'](_0x3602d6){}['onDisconnectPut'](_0x3bfe2c,_0x2f6c02,_0x33bcab){}['onDisconnectMerge'](_0x284690,_0x580650,_0x8382d3){}['onDisconnectCancel'](_0xbb27eb,_0x18e29d){}['reportStats'](_0x411568){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x3dfa1c){this['allowedEvents_']=_0x3dfa1c,this['listeners_']={},f(Array['isArray'](_0x3dfa1c)&&_0x3dfa1c['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x1195ec,..._0x33b445){if(Array['isArray'](this['listeners_'][_0x1195ec])){const _0x208af6=[...this['listeners_'][_0x1195ec]];for(let _0x45490d=0x0;_0x45490d<_0x208af6['length'];_0x45490d++)_0x208af6[_0x45490d]['callback']['apply'](_0x208af6[_0x45490d]['context'],_0x33b445);}}['on'](_0x12a011,_0x129f4f,_0x281aad){this['validateEventType_'](_0x12a011),this['listeners_'][_0x12a011]=this['listeners_'][_0x12a011]||[],this['listeners_'][_0x12a011]['push']({'callback':_0x129f4f,'context':_0x281aad});const _0x50283e=this['getInitialEvent'](_0x12a011);_0x50283e&&_0x129f4f['apply'](_0x281aad,_0x50283e);}['off'](_0x4b439f,_0x3ceb3b,_0x485a13){this['validateEventType_'](_0x4b439f);const _0x520052=this['listeners_'][_0x4b439f]||[];for(let _0x5128e9=0x0;_0x5128e9<_0x520052['length'];_0x5128e9++)if(_0x520052[_0x5128e9]['callback']===_0x3ceb3b&&(!_0x485a13||_0x485a13===_0x520052[_0x5128e9]['context'])){_0x520052['splice'](_0x5128e9,0x1);return;}}['validateEventType_'](_0x3b2ce7){f(this['allowedEvents_']['find'](_0x2da772=>_0x2da772===_0x3b2ce7),'Unknown\x20event:\x20'+_0x3b2ce7);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0xd0a8b9){return f(_0xd0a8b9==='online','Unknown\x20event\x20type:\x20'+_0xd0a8b9),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x24cfeb,_0x14b4d9){if(_0x14b4d9===void 0x0){this['pieces_']=_0x24cfeb['split']('/');let _0xc41e6a=0x0;for(let _0x389824=0x0;_0x389824<this['pieces_']['length'];_0x389824++)this['pieces_'][_0x389824]['length']>0x0&&(this['pieces_'][_0xc41e6a]=this['pieces_'][_0x389824],_0xc41e6a++);this['pieces_']['length']=_0xc41e6a,this['pieceNum_']=0x0;}else this['pieces_']=_0x24cfeb,this['pieceNum_']=_0x14b4d9;}['toString'](){let _0x4c89a8='';for(let _0x23ab04=this['pieceNum_'];_0x23ab04<this['pieces_']['length'];_0x23ab04++)this['pieces_'][_0x23ab04]!==''&&(_0x4c89a8+='/'+this['pieces_'][_0x23ab04]);return _0x4c89a8||'/';}}function w(){return new C('');}function y(_0x2c4585){return _0x2c4585['pieceNum_']>=_0x2c4585['pieces_']['length']?null:_0x2c4585['pieces_'][_0x2c4585['pieceNum_']];}function we(_0x162663){return _0x162663['pieces_']['length']-_0x162663['pieceNum_'];}function b(_0x5493b1){let _0x245209=_0x5493b1['pieceNum_'];return _0x245209<_0x5493b1['pieces_']['length']&&_0x245209++,new C(_0x5493b1['pieces_'],_0x245209);}function zi(_0x31b3a3){return _0x31b3a3['pieceNum_']<_0x31b3a3['pieces_']['length']?_0x31b3a3['pieces_'][_0x31b3a3['pieces_']['length']-0x1]:null;}function bh(_0xd857f4){let _0xec2409='';for(let _0x423069=_0xd857f4['pieceNum_'];_0x423069<_0xd857f4['pieces_']['length'];_0x423069++)_0xd857f4['pieces_'][_0x423069]!==''&&(_0xec2409+='/'+encodeURIComponent(String(_0xd857f4['pieces_'][_0x423069])));return _0xec2409||'/';}function Pt(_0x2fc3ab,_0x51b58e=0x0){return _0x2fc3ab['pieces_']['slice'](_0x2fc3ab['pieceNum_']+_0x51b58e);}function Ro(_0xe89932){if(_0xe89932['pieceNum_']>=_0xe89932['pieces_']['length'])return null;const _0x149bc1=[];for(let _0x3860e3=_0xe89932['pieceNum_'];_0x3860e3<_0xe89932['pieces_']['length']-0x1;_0x3860e3++)_0x149bc1['push'](_0xe89932['pieces_'][_0x3860e3]);return new C(_0x149bc1,0x0);}function k(_0x4c026c,_0x113676){const _0x1c2c2b=[];for(let _0x3573af=_0x4c026c['pieceNum_'];_0x3573af<_0x4c026c['pieces_']['length'];_0x3573af++)_0x1c2c2b['push'](_0x4c026c['pieces_'][_0x3573af]);if(_0x113676 instanceof C){for(let _0x20ec8c=_0x113676['pieceNum_'];_0x20ec8c<_0x113676['pieces_']['length'];_0x20ec8c++)_0x1c2c2b['push'](_0x113676['pieces_'][_0x20ec8c]);}else{const _0x1eb517=_0x113676['split']('/');for(let _0x810a02=0x0;_0x810a02<_0x1eb517['length'];_0x810a02++)_0x1eb517[_0x810a02]['length']>0x0&&_0x1c2c2b['push'](_0x1eb517[_0x810a02]);}return new C(_0x1c2c2b,0x0);}function v(_0x32f7d2){return _0x32f7d2['pieceNum_']>=_0x32f7d2['pieces_']['length'];}function F(_0x236cfd,_0x3ec76e){const _0x21acf2=y(_0x236cfd),_0x505ee7=y(_0x3ec76e);if(_0x21acf2===null)return _0x3ec76e;if(_0x21acf2===_0x505ee7)return F(b(_0x236cfd),b(_0x3ec76e));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x3ec76e+')\x20is\x20not\x20within\x20outerPath\x20('+_0x236cfd+')');}function Rh(_0x2d158a,_0x247f4f){const _0x453b27=Pt(_0x2d158a,0x0),_0x43f877=Pt(_0x247f4f,0x0);for(let _0x376580=0x0;_0x376580<_0x453b27['length']&&_0x376580<_0x43f877['length'];_0x376580++){const _0x390ec7=He(_0x453b27[_0x376580],_0x43f877[_0x376580]);if(_0x390ec7!==0x0)return _0x390ec7;}return _0x453b27['length']===_0x43f877['length']?0x0:_0x453b27['length']<_0x43f877['length']?-0x1:0x1;}function ji(_0x96bad0,_0x43a8b4){if(we(_0x96bad0)!==we(_0x43a8b4))return!0x1;for(let _0x3ecee3=_0x96bad0['pieceNum_'],_0x4e8e6c=_0x43a8b4['pieceNum_'];_0x3ecee3<=_0x96bad0['pieces_']['length'];_0x3ecee3++,_0x4e8e6c++)if(_0x96bad0['pieces_'][_0x3ecee3]!==_0x43a8b4['pieces_'][_0x4e8e6c])return!0x1;return!0x0;}function G(_0x2b84ce,_0x1d58a8){let _0x354afd=_0x2b84ce['pieceNum_'],_0x577174=_0x1d58a8['pieceNum_'];if(we(_0x2b84ce)>we(_0x1d58a8))return!0x1;for(;_0x354afd<_0x2b84ce['pieces_']['length'];){if(_0x2b84ce['pieces_'][_0x354afd]!==_0x1d58a8['pieces_'][_0x577174])return!0x1;++_0x354afd,++_0x577174;}return!0x0;}class Ah{constructor(_0x36bc15,_0x51b057){this['errorPrefix_']=_0x51b057,this['parts_']=Pt(_0x36bc15,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x2e80d8=0x0;_0x2e80d8<this['parts_']['length'];_0x2e80d8++)this['byteLength_']+=On(this['parts_'][_0x2e80d8]);Ao(this);}}function kh(_0xb0ced0,_0x31760e){_0xb0ced0['parts_']['length']>0x0&&(_0xb0ced0['byteLength_']+=0x1),_0xb0ced0['parts_']['push'](_0x31760e),_0xb0ced0['byteLength_']+=On(_0x31760e),Ao(_0xb0ced0);}function Nh(_0x32c6f2){const _0x3d592d=_0x32c6f2['parts_']['pop']();_0x32c6f2['byteLength_']-=On(_0x3d592d),_0x32c6f2['parts_']['length']>0x0&&(_0x32c6f2['byteLength_']-=0x1);}function Ao(_0x31444a){if(_0x31444a['byteLength_']>er)throw new Error(_0x31444a['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x31444a['byteLength_']+').');if(_0x31444a['parts_']['length']>Zs)throw new Error(_0x31444a['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x31444a));}function Pe(_0x24b880){return _0x24b880['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x24b880['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x295e37,_0x1f1c1a;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x1f1c1a='visibilitychange',_0x295e37='hidden'):typeof document['mozHidden']<'u'?(_0x1f1c1a='mozvisibilitychange',_0x295e37='mozHidden'):typeof document['msHidden']<'u'?(_0x1f1c1a='msvisibilitychange',_0x295e37='msHidden'):typeof document['webkitHidden']<'u'&&(_0x1f1c1a='webkitvisibilitychange',_0x295e37='webkitHidden')),this['visible_']=!0x0,_0x1f1c1a&&document['addEventListener'](_0x1f1c1a,()=>{const _0x4f453f=!document[_0x295e37];_0x4f453f!==this['visible_']&&(this['visible_']=_0x4f453f,this['trigger']('visible',_0x4f453f));},!0x1);}['getInitialEvent'](_0x2618a7){return f(_0x2618a7==='visible','Unknown\x20event\x20type:\x20'+_0x2618a7),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x4b21c1,_0x3d738b,_0x438bb0,_0x238cf7,_0x34c427,_0x3d9258,_0x2933e7,_0xb20f1c){if(super(),this['repoInfo_']=_0x4b21c1,this['applicationId_']=_0x3d738b,this['onDataUpdate_']=_0x438bb0,this['onConnectStatus_']=_0x238cf7,this['onServerInfoUpdate_']=_0x34c427,this['authTokenProvider_']=_0x3d9258,this['appCheckTokenProvider_']=_0x2933e7,this['authOverride_']=_0xb20f1c,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0xb20f1c)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x4b21c1['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x25d00d,_0xe98f9d,_0x5ca1cf){const _0x25a21a=++this['requestNumber_'],_0x402c6a={'r':_0x25a21a,'a':_0x25d00d,'b':_0xe98f9d};this['log_'](O(_0x402c6a)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x402c6a),_0x5ca1cf&&(this['requestCBHash_'][_0x25a21a]=_0x5ca1cf);}['get'](_0xe6da3a){this['initConnection_']();const _0x2e76a9=new ot(),_0x4b3185={'action':'g','request':{'p':_0xe6da3a['_path']['toString'](),'q':_0xe6da3a['_queryObject']},'onComplete':_0x2054ec=>{const _0x16c858=_0x2054ec['d'];_0x2054ec['s']==='ok'?_0x2e76a9['resolve'](_0x16c858):_0x2e76a9['reject'](_0x16c858);}};this['outstandingGets_']['push'](_0x4b3185),this['outstandingGetCount_']++;const _0x2aecb5=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x2aecb5),_0x2e76a9['promise'];}['listen'](_0x41f3d1,_0x1ab4b0,_0x29f9ee,_0x40cb17){this['initConnection_']();const _0x36e6ae=_0x41f3d1['_queryIdentifier'],_0x2efa3e=_0x41f3d1['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2efa3e+'\x20'+_0x36e6ae),this['listens']['has'](_0x2efa3e)||this['listens']['set'](_0x2efa3e,new Map()),f(_0x41f3d1['_queryParams']['isDefault']()||!_0x41f3d1['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x2efa3e)['has'](_0x36e6ae),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x387106={'onComplete':_0x40cb17,'hashFn':_0x1ab4b0,'query':_0x41f3d1,'tag':_0x29f9ee};this['listens']['get'](_0x2efa3e)['set'](_0x36e6ae,_0x387106),this['connected_']&&this['sendListen_'](_0x387106);}['sendGet_'](_0x240eb0){const _0x18db88=this['outstandingGets_'][_0x240eb0];this['sendRequest']('g',_0x18db88['request'],_0xc91577=>{delete this['outstandingGets_'][_0x240eb0],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x18db88['onComplete']&&_0x18db88['onComplete'](_0xc91577);});}['sendListen_'](_0x241145){const _0xf475b3=_0x241145['query'],_0x506275=_0xf475b3['_path']['toString'](),_0x285a9e=_0xf475b3['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x506275+'\x20for\x20'+_0x285a9e);const _0x3c4e10={'p':_0x506275},_0x4918fb='q';_0x241145['tag']&&(_0x3c4e10['q']=_0xf475b3['_queryObject'],_0x3c4e10['t']=_0x241145['tag']),_0x3c4e10['h']=_0x241145['hashFn'](),this['sendRequest'](_0x4918fb,_0x3c4e10,_0x1a63de=>{const _0x2e616e=_0x1a63de['d'],_0x280cff=_0x1a63de['s'];se['warnOnListenWarnings_'](_0x2e616e,_0xf475b3),(this['listens']['get'](_0x506275)&&this['listens']['get'](_0x506275)['get'](_0x285a9e))===_0x241145&&(this['log_']('listen\x20response',_0x1a63de),_0x280cff!=='ok'&&this['removeListen_'](_0x506275,_0x285a9e),_0x241145['onComplete']&&_0x241145['onComplete'](_0x280cff,_0x2e616e));});}static['warnOnListenWarnings_'](_0xf7684,_0x44771e){if(_0xf7684&&typeof _0xf7684=='object'&&J(_0xf7684,'w')){const _0x387ebe=De(_0xf7684,'w');if(Array['isArray'](_0x387ebe)&&~_0x387ebe['indexOf']('no_index')){const _0x179418='\x22.indexOn\x22:\x20\x22'+_0x44771e['_queryParams']['getIndex']()['toString']()+'\x22',_0xa6cba7=_0x44771e['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x179418+'\x20at\x20'+_0xa6cba7+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x11aee4){this['authToken_']=_0x11aee4,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x11aee4);}['reduceReconnectDelayIfAdminCredential_'](_0x4c44d1){(_0x4c44d1&&_0x4c44d1['length']===0x28||wc(_0x4c44d1))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x400402){this['appCheckToken_']=_0x400402,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x360984=this['authToken_'],_0x11ceb0=Ic(_0x360984)?'auth':'gauth',_0x356fc6={'cred':_0x360984};this['authOverride_']===null?_0x356fc6['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x356fc6['authvar']=this['authOverride_']),this['sendRequest'](_0x11ceb0,_0x356fc6,_0x3b2d04=>{const _0xf0971c=_0x3b2d04['s'],_0x2d5247=_0x3b2d04['d']||'error';this['authToken_']===_0x360984&&(_0xf0971c==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0xf0971c,_0x2d5247));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x453c97=>{const _0x20695d=_0x453c97['s'],_0x1ac929=_0x453c97['d']||'error';_0x20695d==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x20695d,_0x1ac929);});}['unlisten'](_0x1779fb,_0xa7910b){const _0x103244=_0x1779fb['_path']['toString'](),_0x14142f=_0x1779fb['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x103244+'\x20'+_0x14142f),f(_0x1779fb['_queryParams']['isDefault']()||!_0x1779fb['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x103244,_0x14142f)&&this['connected_']&&this['sendUnlisten_'](_0x103244,_0x14142f,_0x1779fb['_queryObject'],_0xa7910b);}['sendUnlisten_'](_0xbbfd0,_0x5b8a60,_0x585b06,_0x405fd6){this['log_']('Unlisten\x20on\x20'+_0xbbfd0+'\x20for\x20'+_0x5b8a60);const _0x2ba3f7={'p':_0xbbfd0},_0x39d8de='n';_0x405fd6&&(_0x2ba3f7['q']=_0x585b06,_0x2ba3f7['t']=_0x405fd6),this['sendRequest'](_0x39d8de,_0x2ba3f7);}['onDisconnectPut'](_0x4d9fff,_0x47fcb3,_0x40d06e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x4d9fff,_0x47fcb3,_0x40d06e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4d9fff,'action':'o','data':_0x47fcb3,'onComplete':_0x40d06e});}['onDisconnectMerge'](_0x483f67,_0x2729f8,_0x2ee552){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x483f67,_0x2729f8,_0x2ee552):this['onDisconnectRequestQueue_']['push']({'pathString':_0x483f67,'action':'om','data':_0x2729f8,'onComplete':_0x2ee552});}['onDisconnectCancel'](_0x55f23a,_0x461d37){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x55f23a,null,_0x461d37):this['onDisconnectRequestQueue_']['push']({'pathString':_0x55f23a,'action':'oc','data':null,'onComplete':_0x461d37});}['sendOnDisconnect_'](_0x2fbfe1,_0x493996,_0x52afde,_0x541d29){const _0x1af28f={'p':_0x493996,'d':_0x52afde};this['log_']('onDisconnect\x20'+_0x2fbfe1,_0x1af28f),this['sendRequest'](_0x2fbfe1,_0x1af28f,_0x146ca8=>{_0x541d29&&setTimeout(()=>{_0x541d29(_0x146ca8['s'],_0x146ca8['d']);},Math['floor'](0x0));});}['put'](_0x21d494,_0x1aa736,_0x11c85b,_0x406a56){this['putInternal']('p',_0x21d494,_0x1aa736,_0x11c85b,_0x406a56);}['merge'](_0x174365,_0x2f6b71,_0x242c0e,_0x379c19){this['putInternal']('m',_0x174365,_0x2f6b71,_0x242c0e,_0x379c19);}['putInternal'](_0x5102cf,_0x2f05c9,_0x134834,_0x4347bf,_0x98314){this['initConnection_']();const _0x401766={'p':_0x2f05c9,'d':_0x134834};_0x98314!==void 0x0&&(_0x401766['h']=_0x98314),this['outstandingPuts_']['push']({'action':_0x5102cf,'request':_0x401766,'onComplete':_0x4347bf}),this['outstandingPutCount_']++;const _0x1b42f2=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x1b42f2):this['log_']('Buffering\x20put:\x20'+_0x2f05c9);}['sendPut_'](_0x1e9c45){const _0x1d2f49=this['outstandingPuts_'][_0x1e9c45]['action'],_0x4bfc46=this['outstandingPuts_'][_0x1e9c45]['request'],_0x55566c=this['outstandingPuts_'][_0x1e9c45]['onComplete'];this['outstandingPuts_'][_0x1e9c45]['queued']=this['connected_'],this['sendRequest'](_0x1d2f49,_0x4bfc46,_0x3a22f2=>{this['log_'](_0x1d2f49+'\x20response',_0x3a22f2),delete this['outstandingPuts_'][_0x1e9c45],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x55566c&&_0x55566c(_0x3a22f2['s'],_0x3a22f2['d']);});}['reportStats'](_0x41bf88){if(this['connected_']){const _0x13f82d={'c':_0x41bf88};this['log_']('reportStats',_0x13f82d),this['sendRequest']('s',_0x13f82d,_0x27264e=>{if(_0x27264e['s']!=='ok'){const _0xba127b=_0x27264e['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0xba127b);}});}}['onDataMessage_'](_0x35cd32){if('r'in _0x35cd32){this['log_']('from\x20server:\x20'+O(_0x35cd32));const _0x44d5a4=_0x35cd32['r'],_0x5a1a0d=this['requestCBHash_'][_0x44d5a4];_0x5a1a0d&&(delete this['requestCBHash_'][_0x44d5a4],_0x5a1a0d(_0x35cd32['b']));}else{if('error'in _0x35cd32)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x35cd32['error'];'a'in _0x35cd32&&this['onDataPush_'](_0x35cd32['a'],_0x35cd32['b']);}}['onDataPush_'](_0x53d859,_0x3b09d5){this['log_']('handleServerMessage',_0x53d859,_0x3b09d5),_0x53d859==='d'?this['onDataUpdate_'](_0x3b09d5['p'],_0x3b09d5['d'],!0x1,_0x3b09d5['t']):_0x53d859==='m'?this['onDataUpdate_'](_0x3b09d5['p'],_0x3b09d5['d'],!0x0,_0x3b09d5['t']):_0x53d859==='c'?this['onListenRevoked_'](_0x3b09d5['p'],_0x3b09d5['q']):_0x53d859==='ac'?this['onAuthRevoked_'](_0x3b09d5['s'],_0x3b09d5['d']):_0x53d859==='apc'?this['onAppCheckRevoked_'](_0x3b09d5['s'],_0x3b09d5['d']):_0x53d859==='sd'?this['onSecurityDebugPacket_'](_0x3b09d5):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x53d859)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x2afc11,_0x5eef7c){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x2afc11),this['lastSessionId']=_0x5eef7c,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x31967b){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x31967b));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x1e1d87){_0x1e1d87&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x1e1d87;}['onOnline_'](_0xcc2137){_0xcc2137?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x22bb20=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x3fc96e=Math['max'](0x0,this['reconnectDelay_']-_0x22bb20);_0x3fc96e=Math['random']()*_0x3fc96e,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x3fc96e+'ms'),this['scheduleConnect_'](_0x3fc96e),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x2f73ba=this['onDataMessage_']['bind'](this),_0x2cfee6=this['onReady_']['bind'](this),_0x7006aa=this['onRealtimeDisconnect_']['bind'](this),_0x12fb31=this['id']+':'+se['nextConnectionId_']++,_0x4d45f4=this['lastSessionId'];let _0x1683a2=!0x1,_0x1834f9=null;const _0x1f0934=function(){_0x1834f9?_0x1834f9['close']():(_0x1683a2=!0x0,_0x7006aa());},_0x3ad1fa=function(_0x3e3390){f(_0x1834f9,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x1834f9['sendRequest'](_0x3e3390);};this['realtime_']={'close':_0x1f0934,'sendRequest':_0x3ad1fa};const _0x174dce=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x508bb0,_0x41fea6]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x174dce),this['appCheckTokenProvider_']['getToken'](_0x174dce)]);_0x1683a2?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x508bb0&&_0x508bb0['accessToken'],this['appCheckToken_']=_0x41fea6&&_0x41fea6['token'],_0x1834f9=new Sh(_0x12fb31,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x2f73ba,_0x2cfee6,_0x7006aa,_0x138361=>{U(_0x138361+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x4d45f4));}catch(_0x1cb907){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x1cb907),_0x1683a2||(this['repoInfo_']['nodeAdmin']&&U(_0x1cb907),_0x1f0934());}}}['interrupt'](_0x3ccb54){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x3ccb54),this['interruptReasons_'][_0x3ccb54]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0xf17303){L('Resuming\x20connection\x20for\x20reason:\x20'+_0xf17303),delete this['interruptReasons_'][_0xf17303],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x49be1b){const _0x2080e9=_0x49be1b-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x2080e9});}['cancelSentTransactions_'](){for(let _0xf3a31e=0x0;_0xf3a31e<this['outstandingPuts_']['length'];_0xf3a31e++){const _0x4ee431=this['outstandingPuts_'][_0xf3a31e];_0x4ee431&&'h'in _0x4ee431['request']&&_0x4ee431['queued']&&(_0x4ee431['onComplete']&&_0x4ee431['onComplete']('disconnect'),delete this['outstandingPuts_'][_0xf3a31e],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x3a8c0f,_0x3456ef){let _0x478d07;_0x3456ef?_0x478d07=_0x3456ef['map'](_0x25fb81=>Hi(_0x25fb81))['join']('$'):_0x478d07='default';const _0x170c08=this['removeListen_'](_0x3a8c0f,_0x478d07);_0x170c08&&_0x170c08['onComplete']&&_0x170c08['onComplete']('permission_denied');}['removeListen_'](_0x64ffba,_0x47e850){const _0x714189=new C(_0x64ffba)['toString']();let _0x59508f;if(this['listens']['has'](_0x714189)){const _0x1df300=this['listens']['get'](_0x714189);_0x59508f=_0x1df300['get'](_0x47e850),_0x1df300['delete'](_0x47e850),_0x1df300['size']===0x0&&this['listens']['delete'](_0x714189);}else _0x59508f=void 0x0;return _0x59508f;}['onAuthRevoked_'](_0x1b505a,_0x377704){L('Auth\x20token\x20revoked:\x20'+_0x1b505a+'/'+_0x377704),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x1b505a==='invalid_token'||_0x1b505a==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x315ce3,_0x194571){L('App\x20check\x20token\x20revoked:\x20'+_0x315ce3+'/'+_0x194571),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x315ce3==='invalid_token'||_0x315ce3==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x47ce4a){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x47ce4a):'msg'in _0x47ce4a&&console['log']('FIREBASE:\x20'+_0x47ce4a['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x191e64 of this['listens']['values']())for(const _0x156ce8 of _0x191e64['values']())this['sendListen_'](_0x156ce8);for(let _0x3c3ede=0x0;_0x3c3ede<this['outstandingPuts_']['length'];_0x3c3ede++)this['outstandingPuts_'][_0x3c3ede]&&this['sendPut_'](_0x3c3ede);for(;this['onDisconnectRequestQueue_']['length'];){const _0x1aa6f0=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x1aa6f0['action'],_0x1aa6f0['pathString'],_0x1aa6f0['data'],_0x1aa6f0['onComplete']);}for(let _0x51b659=0x0;_0x51b659<this['outstandingGets_']['length'];_0x51b659++)this['outstandingGets_'][_0x51b659]&&this['sendGet_'](_0x51b659);}['sendConnectStats_'](){const _0x4e59a3={};let _0x287753='js';_0x4e59a3['sdk.'+_0x287753+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x4e59a3['framework.cordova']=0x1:Yr()&&(_0x4e59a3['framework.reactnative']=0x1),this['reportStats'](_0x4e59a3);}['shouldReconnect_'](){const _0x372f7c=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x372f7c;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x36e879,_0xb6665b){this['name']=_0x36e879,this['node']=_0xb6665b;}static['Wrap'](_0x8819ee,_0x12c26f){return new E(_0x8819ee,_0x12c26f);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x3d999c,_0x1100cd){const _0x1df860=new E(Fe,_0x3d999c),_0x1e19db=new E(Fe,_0x1100cd);return this['compare'](_0x1df860,_0x1e19db)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x5c8f52){Zt=_0x5c8f52;}['compare'](_0x5962ff,_0x20094f){return He(_0x5962ff['name'],_0x20094f['name']);}['isDefinedOn'](_0x20e284){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x389ff8,_0x1778c9){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x184ad2,_0x295833){return f(typeof _0x184ad2=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x184ad2,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x33b75f,_0x442f66,_0x3823e7,_0x5be4b0,_0x4c2844=null){this['isReverse_']=_0x5be4b0,this['resultGenerator_']=_0x4c2844,this['nodeStack_']=[];let _0x515190=0x1;for(;!_0x33b75f['isEmpty']();)if(_0x33b75f=_0x33b75f,_0x515190=_0x442f66?_0x3823e7(_0x33b75f['key'],_0x442f66):0x1,_0x5be4b0&&(_0x515190*=-0x1),_0x515190<0x0)this['isReverse_']?_0x33b75f=_0x33b75f['left']:_0x33b75f=_0x33b75f['right'];else{if(_0x515190===0x0){this['nodeStack_']['push'](_0x33b75f);break;}else this['nodeStack_']['push'](_0x33b75f),this['isReverse_']?_0x33b75f=_0x33b75f['right']:_0x33b75f=_0x33b75f['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0xb6b3ab=this['nodeStack_']['pop'](),_0x551fb0;if(this['resultGenerator_']?_0x551fb0=this['resultGenerator_'](_0xb6b3ab['key'],_0xb6b3ab['value']):_0x551fb0={'key':_0xb6b3ab['key'],'value':_0xb6b3ab['value']},this['isReverse_']){for(_0xb6b3ab=_0xb6b3ab['left'];!_0xb6b3ab['isEmpty']();)this['nodeStack_']['push'](_0xb6b3ab),_0xb6b3ab=_0xb6b3ab['right'];}else{for(_0xb6b3ab=_0xb6b3ab['right'];!_0xb6b3ab['isEmpty']();)this['nodeStack_']['push'](_0xb6b3ab),_0xb6b3ab=_0xb6b3ab['left'];}return _0x551fb0;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x3b2c7e=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x3b2c7e['key'],_0x3b2c7e['value']):{'key':_0x3b2c7e['key'],'value':_0x3b2c7e['value']};}}class M{constructor(_0x9e398c,_0xe7fff4,_0x49ecea,_0x361251,_0x17b2fc){this['key']=_0x9e398c,this['value']=_0xe7fff4,this['color']=_0x49ecea??M['RED'],this['left']=_0x361251??B['EMPTY_NODE'],this['right']=_0x17b2fc??B['EMPTY_NODE'];}['copy'](_0x2afb6e,_0x293875,_0xc0c0c7,_0x62b575,_0x20bc6b){return new M(_0x2afb6e??this['key'],_0x293875??this['value'],_0xc0c0c7??this['color'],_0x62b575??this['left'],_0x20bc6b??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x3ca378){return this['left']['inorderTraversal'](_0x3ca378)||!!_0x3ca378(this['key'],this['value'])||this['right']['inorderTraversal'](_0x3ca378);}['reverseTraversal'](_0x33eea9){return this['right']['reverseTraversal'](_0x33eea9)||_0x33eea9(this['key'],this['value'])||this['left']['reverseTraversal'](_0x33eea9);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x199a40,_0x23cb32,_0x3f3c3f){let _0x5051d3=this;const _0x1e1171=_0x3f3c3f(_0x199a40,_0x5051d3['key']);return _0x1e1171<0x0?_0x5051d3=_0x5051d3['copy'](null,null,null,_0x5051d3['left']['insert'](_0x199a40,_0x23cb32,_0x3f3c3f),null):_0x1e1171===0x0?_0x5051d3=_0x5051d3['copy'](null,_0x23cb32,null,null,null):_0x5051d3=_0x5051d3['copy'](null,null,null,null,_0x5051d3['right']['insert'](_0x199a40,_0x23cb32,_0x3f3c3f)),_0x5051d3['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x28a5ba=this;return!_0x28a5ba['left']['isRed_']()&&!_0x28a5ba['left']['left']['isRed_']()&&(_0x28a5ba=_0x28a5ba['moveRedLeft_']()),_0x28a5ba=_0x28a5ba['copy'](null,null,null,_0x28a5ba['left']['removeMin_'](),null),_0x28a5ba['fixUp_']();}['remove'](_0x1d54e6,_0x3f1504){let _0x2c813b,_0x1b7147;if(_0x2c813b=this,_0x3f1504(_0x1d54e6,_0x2c813b['key'])<0x0)!_0x2c813b['left']['isEmpty']()&&!_0x2c813b['left']['isRed_']()&&!_0x2c813b['left']['left']['isRed_']()&&(_0x2c813b=_0x2c813b['moveRedLeft_']()),_0x2c813b=_0x2c813b['copy'](null,null,null,_0x2c813b['left']['remove'](_0x1d54e6,_0x3f1504),null);else{if(_0x2c813b['left']['isRed_']()&&(_0x2c813b=_0x2c813b['rotateRight_']()),!_0x2c813b['right']['isEmpty']()&&!_0x2c813b['right']['isRed_']()&&!_0x2c813b['right']['left']['isRed_']()&&(_0x2c813b=_0x2c813b['moveRedRight_']()),_0x3f1504(_0x1d54e6,_0x2c813b['key'])===0x0){if(_0x2c813b['right']['isEmpty']())return B['EMPTY_NODE'];_0x1b7147=_0x2c813b['right']['min_'](),_0x2c813b=_0x2c813b['copy'](_0x1b7147['key'],_0x1b7147['value'],null,null,_0x2c813b['right']['removeMin_']());}_0x2c813b=_0x2c813b['copy'](null,null,null,null,_0x2c813b['right']['remove'](_0x1d54e6,_0x3f1504));}return _0x2c813b['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x4a5ab2=this;return _0x4a5ab2['right']['isRed_']()&&!_0x4a5ab2['left']['isRed_']()&&(_0x4a5ab2=_0x4a5ab2['rotateLeft_']()),_0x4a5ab2['left']['isRed_']()&&_0x4a5ab2['left']['left']['isRed_']()&&(_0x4a5ab2=_0x4a5ab2['rotateRight_']()),_0x4a5ab2['left']['isRed_']()&&_0x4a5ab2['right']['isRed_']()&&(_0x4a5ab2=_0x4a5ab2['colorFlip_']()),_0x4a5ab2;}['moveRedLeft_'](){let _0x1e5320=this['colorFlip_']();return _0x1e5320['right']['left']['isRed_']()&&(_0x1e5320=_0x1e5320['copy'](null,null,null,null,_0x1e5320['right']['rotateRight_']()),_0x1e5320=_0x1e5320['rotateLeft_'](),_0x1e5320=_0x1e5320['colorFlip_']()),_0x1e5320;}['moveRedRight_'](){let _0x24fa28=this['colorFlip_']();return _0x24fa28['left']['left']['isRed_']()&&(_0x24fa28=_0x24fa28['rotateRight_'](),_0x24fa28=_0x24fa28['colorFlip_']()),_0x24fa28;}['rotateLeft_'](){const _0x1ba254=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x1ba254,null);}['rotateRight_'](){const _0x54a489=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x54a489);}['colorFlip_'](){const _0x23b6ed=this['left']['copy'](null,null,!this['left']['color'],null,null),_0xc2e3c8=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x23b6ed,_0xc2e3c8);}['checkMaxDepth_'](){const _0x24ce65=this['check_']();return Math['pow'](0x2,_0x24ce65)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x168c3f=this['left']['check_']();if(_0x168c3f!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x168c3f+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x5f4972,_0xced51b,_0x40ec2f,_0x23bf2d,_0x24f72b){return this;}['insert'](_0x136200,_0xef5436,_0x3ca526){return new M(_0x136200,_0xef5436,null);}['remove'](_0x5e9dca,_0x2736f0){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x4a7e9e){return!0x1;}['reverseTraversal'](_0x28c794){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x26633b,_0x465c50=B['EMPTY_NODE']){this['comparator_']=_0x26633b,this['root_']=_0x465c50;}['insert'](_0x48bca2,_0x120adc){return new B(this['comparator_'],this['root_']['insert'](_0x48bca2,_0x120adc,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x37304f){return new B(this['comparator_'],this['root_']['remove'](_0x37304f,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x12c6fc){let _0x4ac7f3,_0x3e0f47=this['root_'];for(;!_0x3e0f47['isEmpty']();){if(_0x4ac7f3=this['comparator_'](_0x12c6fc,_0x3e0f47['key']),_0x4ac7f3===0x0)return _0x3e0f47['value'];_0x4ac7f3<0x0?_0x3e0f47=_0x3e0f47['left']:_0x4ac7f3>0x0&&(_0x3e0f47=_0x3e0f47['right']);}return null;}['getPredecessorKey'](_0x25ae87){let _0x3d0191,_0x35060c=this['root_'],_0x16abfd=null;for(;!_0x35060c['isEmpty']();)if(_0x3d0191=this['comparator_'](_0x25ae87,_0x35060c['key']),_0x3d0191===0x0){if(_0x35060c['left']['isEmpty']())return _0x16abfd?_0x16abfd['key']:null;for(_0x35060c=_0x35060c['left'];!_0x35060c['right']['isEmpty']();)_0x35060c=_0x35060c['right'];return _0x35060c['key'];}else _0x3d0191<0x0?_0x35060c=_0x35060c['left']:_0x3d0191>0x0&&(_0x16abfd=_0x35060c,_0x35060c=_0x35060c['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x2cd47a){return this['root_']['inorderTraversal'](_0x2cd47a);}['reverseTraversal'](_0x5a423c){return this['root_']['reverseTraversal'](_0x5a423c);}['getIterator'](_0x2025f2){return new en(this['root_'],null,this['comparator_'],!0x1,_0x2025f2);}['getIteratorFrom'](_0xd00157,_0x279ecf){return new en(this['root_'],_0xd00157,this['comparator_'],!0x1,_0x279ecf);}['getReverseIteratorFrom'](_0x5c151c,_0x4027eb){return new en(this['root_'],_0x5c151c,this['comparator_'],!0x0,_0x4027eb);}['getReverseIterator'](_0x4d1399){return new en(this['root_'],null,this['comparator_'],!0x0,_0x4d1399);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x199b8d,_0xcb66ee){return He(_0x199b8d['name'],_0xcb66ee['name']);}function Yi(_0x23a6c0,_0x10418f){return He(_0x23a6c0,_0x10418f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x27c2a3){Ei=_0x27c2a3;}const No=function(_0x5b32f6){return typeof _0x5b32f6=='number'?'number:'+ao(_0x5b32f6):'string:'+_0x5b32f6;},Po=function(_0x115924){if(_0x115924['isLeafNode']()){const _0x2e5a55=_0x115924['val']();f(typeof _0x2e5a55=='string'||typeof _0x2e5a55=='number'||typeof _0x2e5a55=='object'&&J(_0x2e5a55,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x115924===Ei||_0x115924['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x115924===Ei||_0x115924['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0xd3504c){ir=_0xd3504c;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x47f338,_0x50a41a=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x47f338,this['priorityNode_']=_0x50a41a,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x315747){return new D(this['value_'],_0x315747);}['getImmediateChild'](_0x50e88f){return _0x50e88f==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x393fe9){return v(_0x393fe9)?this:y(_0x393fe9)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x29b895,_0x565ca6){return null;}['updateImmediateChild'](_0x27e121,_0x2ed0f5){return _0x27e121==='.priority'?this['updatePriority'](_0x2ed0f5):_0x2ed0f5['isEmpty']()&&_0x27e121!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x27e121,_0x2ed0f5)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x1a6e00,_0x44c65c){const _0x2db895=y(_0x1a6e00);return _0x2db895===null?_0x44c65c:_0x44c65c['isEmpty']()&&_0x2db895!=='.priority'?this:(f(_0x2db895!=='.priority'||we(_0x1a6e00)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x2db895,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x1a6e00),_0x44c65c)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x54386a,_0x48cec3){return!0x1;}['val'](_0x5a7a3e){return _0x5a7a3e&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x9f6ca2='';this['priorityNode_']['isEmpty']()||(_0x9f6ca2+='priority:'+No(this['priorityNode_']['val']())+':');const _0x2dedab=typeof this['value_'];_0x9f6ca2+=_0x2dedab+':',_0x2dedab==='number'?_0x9f6ca2+=ao(this['value_']):_0x9f6ca2+=this['value_'],this['lazyHash_']=ro(_0x9f6ca2);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x33accd){return _0x33accd===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x33accd instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x33accd['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x33accd));}['compareToLeafNode_'](_0x2917ef){const _0x428fff=typeof _0x2917ef['value_'],_0x1cb4e5=typeof this['value_'],_0x36d3ae=D['VALUE_TYPE_ORDER']['indexOf'](_0x428fff),_0x4cb685=D['VALUE_TYPE_ORDER']['indexOf'](_0x1cb4e5);return f(_0x36d3ae>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x428fff),f(_0x4cb685>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1cb4e5),_0x36d3ae===_0x4cb685?_0x1cb4e5==='object'?0x0:this['value_']<_0x2917ef['value_']?-0x1:this['value_']===_0x2917ef['value_']?0x0:0x1:_0x4cb685-_0x36d3ae;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x5566e3){if(_0x5566e3===this)return!0x0;if(_0x5566e3['isLeafNode']()){const _0x1ca798=_0x5566e3;return this['value_']===_0x1ca798['value_']&&this['priorityNode_']['equals'](_0x1ca798['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0xbcdbba){Oo=_0xbcdbba;}function Wh(_0x58e102){Do=_0x58e102;}class Bh extends Dn{['compare'](_0x534277,_0x411d3b){const _0x457f98=_0x534277['node']['getPriority'](),_0x856cfa=_0x411d3b['node']['getPriority'](),_0x3c4604=_0x457f98['compareTo'](_0x856cfa);return _0x3c4604===0x0?He(_0x534277['name'],_0x411d3b['name']):_0x3c4604;}['isDefinedOn'](_0x382ef6){return!_0x382ef6['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x5cc200,_0x52dfbe){return!_0x5cc200['getPriority']()['equals'](_0x52dfbe['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x4f7228,_0x29207f){const _0x46b97e=Oo(_0x4f7228);return new E(_0x29207f,new D('[PRIORITY-POST]',_0x46b97e));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x26ffdd){const _0x1c497f=_0x8318b5=>parseInt(Math['log'](_0x8318b5)/Vh,0xa),_0x4dbedc=_0x196ed9=>parseInt(Array(_0x196ed9+0x1)['join']('1'),0x2);this['count']=_0x1c497f(_0x26ffdd+0x1),this['current_']=this['count']-0x1;const _0x5611f7=_0x4dbedc(this['count']);this['bits_']=_0x26ffdd+0x1&_0x5611f7;}['nextBitIsOne'](){const _0x14f642=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x14f642;}}const fn=function(_0x5d02f3,_0x1805e1,_0x43e7a4,_0xb04a8c){_0x5d02f3['sort'](_0x1805e1);const _0x2e60dd=function(_0xc220e,_0x2f0131){const _0x27b76d=_0x2f0131-_0xc220e;let _0x270724,_0x2e86c5;if(_0x27b76d===0x0)return null;if(_0x27b76d===0x1)return _0x270724=_0x5d02f3[_0xc220e],_0x2e86c5=_0x43e7a4?_0x43e7a4(_0x270724):_0x270724,new M(_0x2e86c5,_0x270724['node'],M['BLACK'],null,null);{const _0x333458=parseInt(_0x27b76d/0x2,0xa)+_0xc220e,_0x483f26=_0x2e60dd(_0xc220e,_0x333458),_0x1811ef=_0x2e60dd(_0x333458+0x1,_0x2f0131);return _0x270724=_0x5d02f3[_0x333458],_0x2e86c5=_0x43e7a4?_0x43e7a4(_0x270724):_0x270724,new M(_0x2e86c5,_0x270724['node'],M['BLACK'],_0x483f26,_0x1811ef);}},_0x4f1cb7=function(_0x32d233){let _0x5d562d=null,_0x4ac77f=null,_0x41ec47=_0x5d02f3['length'];const _0x54bf7f=function(_0xef87d,_0x1d4dbd){const _0x425f0c=_0x41ec47-_0xef87d,_0x1885ab=_0x41ec47;_0x41ec47-=_0xef87d;const _0x4fa59b=_0x2e60dd(_0x425f0c+0x1,_0x1885ab),_0x28cf37=_0x5d02f3[_0x425f0c],_0x1701f7=_0x43e7a4?_0x43e7a4(_0x28cf37):_0x28cf37;_0x1f559c(new M(_0x1701f7,_0x28cf37['node'],_0x1d4dbd,null,_0x4fa59b));},_0x1f559c=function(_0x58c925){_0x5d562d?(_0x5d562d['left']=_0x58c925,_0x5d562d=_0x58c925):(_0x4ac77f=_0x58c925,_0x5d562d=_0x58c925);};for(let _0x1cd1e8=0x0;_0x1cd1e8<_0x32d233['count'];++_0x1cd1e8){const _0x5b28ec=_0x32d233['nextBitIsOne'](),_0x383091=Math['pow'](0x2,_0x32d233['count']-(_0x1cd1e8+0x1));_0x5b28ec?_0x54bf7f(_0x383091,M['BLACK']):(_0x54bf7f(_0x383091,M['BLACK']),_0x54bf7f(_0x383091,M['RED']));}return _0x4ac77f;},_0x566f9b=new Hh(_0x5d02f3['length']),_0x3f7bcb=_0x4f1cb7(_0x566f9b);return new B(_0xb04a8c||_0x1805e1,_0x3f7bcb);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x4f8356,_0x7e8b80){this['indexes_']=_0x4f8356,this['indexSet_']=_0x7e8b80;}['get'](_0x8affeb){const _0x3ce799=De(this['indexes_'],_0x8affeb);if(!_0x3ce799)throw new Error('No\x20index\x20defined\x20for\x20'+_0x8affeb);return _0x3ce799 instanceof B?_0x3ce799:null;}['hasIndex'](_0x3cc5b1){return J(this['indexSet_'],_0x3cc5b1['toString']());}['addIndex'](_0x448afe,_0x41060d){f(_0x448afe!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x48c4f2=[];let _0x340f75=!0x1;const _0x493b19=_0x41060d['getIterator'](E['Wrap']);let _0x451215=_0x493b19['getNext']();for(;_0x451215;)_0x340f75=_0x340f75||_0x448afe['isDefinedOn'](_0x451215['node']),_0x48c4f2['push'](_0x451215),_0x451215=_0x493b19['getNext']();let _0x1c77f3;_0x340f75?_0x1c77f3=fn(_0x48c4f2,_0x448afe['getCompare']()):_0x1c77f3=ze;const _0x379fd6=_0x448afe['toString'](),_0x35f14e={...this['indexSet_']};_0x35f14e[_0x379fd6]=_0x448afe;const _0xf00c21={...this['indexes_']};return _0xf00c21[_0x379fd6]=_0x1c77f3,new te(_0xf00c21,_0x35f14e);}['addToIndexes'](_0x506121,_0xd4c200){const _0x125275=hn(this['indexes_'],(_0x55cad0,_0x8466a1)=>{const _0x26480a=De(this['indexSet_'],_0x8466a1);if(f(_0x26480a,'Missing\x20index\x20implementation\x20for\x20'+_0x8466a1),_0x55cad0===ze){if(_0x26480a['isDefinedOn'](_0x506121['node'])){const _0x4ccef5=[],_0x525e27=_0xd4c200['getIterator'](E['Wrap']);let _0x201782=_0x525e27['getNext']();for(;_0x201782;)_0x201782['name']!==_0x506121['name']&&_0x4ccef5['push'](_0x201782),_0x201782=_0x525e27['getNext']();return _0x4ccef5['push'](_0x506121),fn(_0x4ccef5,_0x26480a['getCompare']());}else return ze;}else{const _0xb42b49=_0xd4c200['get'](_0x506121['name']);let _0x559a42=_0x55cad0;return _0xb42b49&&(_0x559a42=_0x559a42['remove'](new E(_0x506121['name'],_0xb42b49))),_0x559a42['insert'](_0x506121,_0x506121['node']);}});return new te(_0x125275,this['indexSet_']);}['removeFromIndexes'](_0x418e1a,_0x4e4f9a){const _0x390d35=hn(this['indexes_'],_0xd82696=>{if(_0xd82696===ze)return _0xd82696;{const _0x37a9d0=_0x4e4f9a['get'](_0x418e1a['name']);return _0x37a9d0?_0xd82696['remove'](new E(_0x418e1a['name'],_0x37a9d0)):_0xd82696;}});return new te(_0x390d35,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x4ab70e,_0x5f59be,_0x573751){this['children_']=_0x4ab70e,this['priorityNode_']=_0x5f59be,this['indexMap_']=_0x573751,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x2ed699){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x2ed699,this['indexMap_']);}['getImmediateChild'](_0xb68a80){if(_0xb68a80==='.priority')return this['getPriority']();{const _0x58a52e=this['children_']['get'](_0xb68a80);return _0x58a52e===null?mt:_0x58a52e;}}['getChild'](_0x473ae6){const _0x24fce1=y(_0x473ae6);return _0x24fce1===null?this:this['getImmediateChild'](_0x24fce1)['getChild'](b(_0x473ae6));}['hasChild'](_0x5ee7a3){return this['children_']['get'](_0x5ee7a3)!==null;}['updateImmediateChild'](_0x181d60,_0x5c7496){if(f(_0x5c7496,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x181d60==='.priority')return this['updatePriority'](_0x5c7496);{const _0x58ed2b=new E(_0x181d60,_0x5c7496);let _0x32fdde,_0x55915b;_0x5c7496['isEmpty']()?(_0x32fdde=this['children_']['remove'](_0x181d60),_0x55915b=this['indexMap_']['removeFromIndexes'](_0x58ed2b,this['children_'])):(_0x32fdde=this['children_']['insert'](_0x181d60,_0x5c7496),_0x55915b=this['indexMap_']['addToIndexes'](_0x58ed2b,this['children_']));const _0x3b9cb9=_0x32fdde['isEmpty']()?mt:this['priorityNode_'];return new g(_0x32fdde,_0x3b9cb9,_0x55915b);}}['updateChild'](_0x110df0,_0x9b56ab){const _0x385a79=y(_0x110df0);if(_0x385a79===null)return _0x9b56ab;{f(y(_0x110df0)!=='.priority'||we(_0x110df0)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x4244a7=this['getImmediateChild'](_0x385a79)['updateChild'](b(_0x110df0),_0x9b56ab);return this['updateImmediateChild'](_0x385a79,_0x4244a7);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x37f201){if(this['isEmpty']())return null;const _0x57f308={};let _0x4660e9=0x0,_0x203ae0=0x0,_0x3eecb8=!0x0;if(this['forEachChild'](R,(_0x207735,_0x3f9ff1)=>{_0x57f308[_0x207735]=_0x3f9ff1['val'](_0x37f201),_0x4660e9++,_0x3eecb8&&g['INTEGER_REGEXP_']['test'](_0x207735)?_0x203ae0=Math['max'](_0x203ae0,Number(_0x207735)):_0x3eecb8=!0x1;}),!_0x37f201&&_0x3eecb8&&_0x203ae0<0x2*_0x4660e9){const _0x31dcec=[];for(const _0x5b7172 in _0x57f308)_0x31dcec[_0x5b7172]=_0x57f308[_0x5b7172];return _0x31dcec;}else return _0x37f201&&!this['getPriority']()['isEmpty']()&&(_0x57f308['.priority']=this['getPriority']()['val']()),_0x57f308;}['hash'](){if(this['lazyHash_']===null){let _0x1d29dc='';this['getPriority']()['isEmpty']()||(_0x1d29dc+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x11083e,_0x1242a0)=>{const _0x5004d4=_0x1242a0['hash']();_0x5004d4!==''&&(_0x1d29dc+=':'+_0x11083e+':'+_0x5004d4);}),this['lazyHash_']=_0x1d29dc===''?'':ro(_0x1d29dc);}return this['lazyHash_'];}['getPredecessorChildName'](_0x21dde8,_0x4c0ea5,_0x4346f3){const _0x2f53c4=this['resolveIndex_'](_0x4346f3);if(_0x2f53c4){const _0x407581=_0x2f53c4['getPredecessorKey'](new E(_0x21dde8,_0x4c0ea5));return _0x407581?_0x407581['name']:null;}else return this['children_']['getPredecessorKey'](_0x21dde8);}['getFirstChildName'](_0x596d13){const _0x1176cf=this['resolveIndex_'](_0x596d13);if(_0x1176cf){const _0x1849da=_0x1176cf['minKey']();return _0x1849da&&_0x1849da['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x430091){const _0x1e8522=this['getFirstChildName'](_0x430091);return _0x1e8522?new E(_0x1e8522,this['children_']['get'](_0x1e8522)):null;}['getLastChildName'](_0x3626c5){const _0x957683=this['resolveIndex_'](_0x3626c5);if(_0x957683){const _0x42537c=_0x957683['maxKey']();return _0x42537c&&_0x42537c['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x37a1f5){const _0x271b29=this['getLastChildName'](_0x37a1f5);return _0x271b29?new E(_0x271b29,this['children_']['get'](_0x271b29)):null;}['forEachChild'](_0x1534ed,_0x376d4e){const _0x77eb8d=this['resolveIndex_'](_0x1534ed);return _0x77eb8d?_0x77eb8d['inorderTraversal'](_0x3175d9=>_0x376d4e(_0x3175d9['name'],_0x3175d9['node'])):this['children_']['inorderTraversal'](_0x376d4e);}['getIterator'](_0x884755){return this['getIteratorFrom'](_0x884755['minPost'](),_0x884755);}['getIteratorFrom'](_0x5e4f87,_0x5d93e6){const _0xaf9233=this['resolveIndex_'](_0x5d93e6);if(_0xaf9233)return _0xaf9233['getIteratorFrom'](_0x5e4f87,_0x25832b=>_0x25832b);{const _0x3da0bd=this['children_']['getIteratorFrom'](_0x5e4f87['name'],E['Wrap']);let _0x45699=_0x3da0bd['peek']();for(;_0x45699!=null&&_0x5d93e6['compare'](_0x45699,_0x5e4f87)<0x0;)_0x3da0bd['getNext'](),_0x45699=_0x3da0bd['peek']();return _0x3da0bd;}}['getReverseIterator'](_0x43e6ca){return this['getReverseIteratorFrom'](_0x43e6ca['maxPost'](),_0x43e6ca);}['getReverseIteratorFrom'](_0x19cf0c,_0x40e9de){const _0x169898=this['resolveIndex_'](_0x40e9de);if(_0x169898)return _0x169898['getReverseIteratorFrom'](_0x19cf0c,_0x2da06f=>_0x2da06f);{const _0x275b63=this['children_']['getReverseIteratorFrom'](_0x19cf0c['name'],E['Wrap']);let _0x2f76a6=_0x275b63['peek']();for(;_0x2f76a6!=null&&_0x40e9de['compare'](_0x2f76a6,_0x19cf0c)>0x0;)_0x275b63['getNext'](),_0x2f76a6=_0x275b63['peek']();return _0x275b63;}}['compareTo'](_0x1e1897){return this['isEmpty']()?_0x1e1897['isEmpty']()?0x0:-0x1:_0x1e1897['isLeafNode']()||_0x1e1897['isEmpty']()?0x1:_0x1e1897===$t?-0x1:0x0;}['withIndex'](_0xa2d3){if(_0xa2d3===ye||this['indexMap_']['hasIndex'](_0xa2d3))return this;{const _0x3bf87e=this['indexMap_']['addIndex'](_0xa2d3,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x3bf87e);}}['isIndexed'](_0x284a4e){return _0x284a4e===ye||this['indexMap_']['hasIndex'](_0x284a4e);}['equals'](_0x38a94e){if(_0x38a94e===this)return!0x0;if(_0x38a94e['isLeafNode']())return!0x1;{const _0x1a10ca=_0x38a94e;if(this['getPriority']()['equals'](_0x1a10ca['getPriority']())){if(this['children_']['count']()===_0x1a10ca['children_']['count']()){const _0x294ac5=this['getIterator'](R),_0x540fbf=_0x1a10ca['getIterator'](R);let _0x40f8c7=_0x294ac5['getNext'](),_0x2a0c8d=_0x540fbf['getNext']();for(;_0x40f8c7&&_0x2a0c8d;){if(_0x40f8c7['name']!==_0x2a0c8d['name']||!_0x40f8c7['node']['equals'](_0x2a0c8d['node']))return!0x1;_0x40f8c7=_0x294ac5['getNext'](),_0x2a0c8d=_0x540fbf['getNext']();}return _0x40f8c7===null&&_0x2a0c8d===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x3985de){return _0x3985de===ye?null:this['indexMap_']['get'](_0x3985de['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x294aa5){return _0x294aa5===this?0x0:0x1;}['equals'](_0x2c97c1){return _0x2c97c1===this;}['getPriority'](){return this;}['getImmediateChild'](_0x326f8d){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x110836,_0x120bca=null){if(_0x110836===null)return g['EMPTY_NODE'];if(typeof _0x110836=='object'&&'.priority'in _0x110836&&(_0x120bca=_0x110836['.priority']),f(_0x120bca===null||typeof _0x120bca=='string'||typeof _0x120bca=='number'||typeof _0x120bca=='object'&&'.sv'in _0x120bca,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x120bca),typeof _0x110836=='object'&&'.value'in _0x110836&&_0x110836['.value']!==null&&(_0x110836=_0x110836['.value']),typeof _0x110836!='object'||'.sv'in _0x110836){const _0x298631=_0x110836;return new D(_0x298631,P(_0x120bca));}if(!(_0x110836 instanceof Array)&&Gh){const _0xd0f4c9=[];let _0xd3f918=!0x1;if(x(_0x110836,(_0x36553d,_0x520afa)=>{if(_0x36553d['substring'](0x0,0x1)!=='.'){const _0x1d4a9a=P(_0x520afa);_0x1d4a9a['isEmpty']()||(_0xd3f918=_0xd3f918||!_0x1d4a9a['getPriority']()['isEmpty'](),_0xd0f4c9['push'](new E(_0x36553d,_0x1d4a9a)));}}),_0xd0f4c9['length']===0x0)return g['EMPTY_NODE'];const _0x1b6ff6=fn(_0xd0f4c9,xh,_0x4e0d8a=>_0x4e0d8a['name'],Yi);if(_0xd3f918){const _0x1a7ddd=fn(_0xd0f4c9,R['getCompare']());return new g(_0x1b6ff6,P(_0x120bca),new te({'.priority':_0x1a7ddd},{'.priority':R}));}else return new g(_0x1b6ff6,P(_0x120bca),te['Default']);}else{let _0x4b28cb=g['EMPTY_NODE'];return x(_0x110836,(_0x551791,_0x4a0916)=>{if(J(_0x110836,_0x551791)&&_0x551791['substring'](0x0,0x1)!=='.'){const _0x587446=P(_0x4a0916);(_0x587446['isLeafNode']()||!_0x587446['isEmpty']())&&(_0x4b28cb=_0x4b28cb['updateImmediateChild'](_0x551791,_0x587446));}}),_0x4b28cb['updatePriority'](P(_0x120bca));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x21bf9f){super(),this['indexPath_']=_0x21bf9f,f(!v(_0x21bf9f)&&y(_0x21bf9f)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x42752d){return _0x42752d['getChild'](this['indexPath_']);}['isDefinedOn'](_0x306707){return!_0x306707['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x3f7eae,_0x4b1813){const _0x3f93ec=this['extractChild'](_0x3f7eae['node']),_0x2bbd89=this['extractChild'](_0x4b1813['node']),_0x1e8447=_0x3f93ec['compareTo'](_0x2bbd89);return _0x1e8447===0x0?He(_0x3f7eae['name'],_0x4b1813['name']):_0x1e8447;}['makePost'](_0x543c6a,_0x400623){const _0x28e615=P(_0x543c6a),_0x31f799=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x28e615);return new E(_0x400623,_0x31f799);}['maxPost'](){const _0x1fb949=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x1fb949);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x122233,_0x2d4a19){const _0x5e5172=_0x122233['node']['compareTo'](_0x2d4a19['node']);return _0x5e5172===0x0?He(_0x122233['name'],_0x2d4a19['name']):_0x5e5172;}['isDefinedOn'](_0x133ec5){return!0x0;}['indexedValueChanged'](_0x25b90a,_0x184ae3){return!_0x25b90a['equals'](_0x184ae3);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x4a7d00,_0x4de92d){const _0x3fa2aa=P(_0x4a7d00);return new E(_0x4de92d,_0x3fa2aa);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x3e2392){return{'type':'value','snapshotNode':_0x3e2392};}function et(_0x23aceb,_0x2fd676){return{'type':'child_added','snapshotNode':_0x2fd676,'childName':_0x23aceb};}function Ot(_0x38604a,_0x381f03){return{'type':'child_removed','snapshotNode':_0x381f03,'childName':_0x38604a};}function Dt(_0x5192aa,_0x3f0f95,_0x2543f7){return{'type':'child_changed','snapshotNode':_0x3f0f95,'childName':_0x5192aa,'oldSnap':_0x2543f7};}function zh(_0x3c3dd4,_0x59c587){return{'type':'child_moved','snapshotNode':_0x59c587,'childName':_0x3c3dd4};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x2edf5b){this['index_']=_0x2edf5b;}['updateChild'](_0xbc3899,_0x3036ff,_0x407420,_0x3a2709,_0x2584a2,_0x23c467){f(_0xbc3899['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x231d5c=_0xbc3899['getImmediateChild'](_0x3036ff);return _0x231d5c['getChild'](_0x3a2709)['equals'](_0x407420['getChild'](_0x3a2709))&&_0x231d5c['isEmpty']()===_0x407420['isEmpty']()||(_0x23c467!=null&&(_0x407420['isEmpty']()?_0xbc3899['hasChild'](_0x3036ff)?_0x23c467['trackChildChange'](Ot(_0x3036ff,_0x231d5c)):f(_0xbc3899['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x231d5c['isEmpty']()?_0x23c467['trackChildChange'](et(_0x3036ff,_0x407420)):_0x23c467['trackChildChange'](Dt(_0x3036ff,_0x407420,_0x231d5c))),_0xbc3899['isLeafNode']()&&_0x407420['isEmpty']())?_0xbc3899:_0xbc3899['updateImmediateChild'](_0x3036ff,_0x407420)['withIndex'](this['index_']);}['updateFullNode'](_0x3e5ea8,_0x4a89a6,_0x3a60da){return _0x3a60da!=null&&(_0x3e5ea8['isLeafNode']()||_0x3e5ea8['forEachChild'](R,(_0x32dc36,_0x55fdcc)=>{_0x4a89a6['hasChild'](_0x32dc36)||_0x3a60da['trackChildChange'](Ot(_0x32dc36,_0x55fdcc));}),_0x4a89a6['isLeafNode']()||_0x4a89a6['forEachChild'](R,(_0xc0ebe1,_0x330f6f)=>{if(_0x3e5ea8['hasChild'](_0xc0ebe1)){const _0x53ede4=_0x3e5ea8['getImmediateChild'](_0xc0ebe1);_0x53ede4['equals'](_0x330f6f)||_0x3a60da['trackChildChange'](Dt(_0xc0ebe1,_0x330f6f,_0x53ede4));}else _0x3a60da['trackChildChange'](et(_0xc0ebe1,_0x330f6f));})),_0x4a89a6['withIndex'](this['index_']);}['updatePriority'](_0x3dea7a,_0x16c72b){return _0x3dea7a['isEmpty']()?g['EMPTY_NODE']:_0x3dea7a['updatePriority'](_0x16c72b);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x42f6f5){this['indexedFilter_']=new Ji(_0x42f6f5['getIndex']()),this['index_']=_0x42f6f5['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x42f6f5),this['endPost_']=Mt['getEndPost_'](_0x42f6f5),this['startIsInclusive_']=!_0x42f6f5['startAfterSet_'],this['endIsInclusive_']=!_0x42f6f5['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x4e7d7e){const _0x45c7dd=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x4e7d7e)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x4e7d7e)<0x0,_0x471703=this['endIsInclusive_']?this['index_']['compare'](_0x4e7d7e,this['getEndPost']())<=0x0:this['index_']['compare'](_0x4e7d7e,this['getEndPost']())<0x0;return _0x45c7dd&&_0x471703;}['updateChild'](_0x2b952d,_0x56b413,_0xb8639,_0x239a82,_0x4b70db,_0x522bee){return this['matches'](new E(_0x56b413,_0xb8639))||(_0xb8639=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x2b952d,_0x56b413,_0xb8639,_0x239a82,_0x4b70db,_0x522bee);}['updateFullNode'](_0x4efde2,_0x11e484,_0x2dbe75){_0x11e484['isLeafNode']()&&(_0x11e484=g['EMPTY_NODE']);let _0x15c7c8=_0x11e484['withIndex'](this['index_']);_0x15c7c8=_0x15c7c8['updatePriority'](g['EMPTY_NODE']);const _0x5b1f15=this;return _0x11e484['forEachChild'](R,(_0x46dd25,_0x295194)=>{_0x5b1f15['matches'](new E(_0x46dd25,_0x295194))||(_0x15c7c8=_0x15c7c8['updateImmediateChild'](_0x46dd25,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x4efde2,_0x15c7c8,_0x2dbe75);}['updatePriority'](_0x433263,_0x3968b0){return _0x433263;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x31f4e6){if(_0x31f4e6['hasStart']()){const _0x3f8f80=_0x31f4e6['getIndexStartName']();return _0x31f4e6['getIndex']()['makePost'](_0x31f4e6['getIndexStartValue'](),_0x3f8f80);}else return _0x31f4e6['getIndex']()['minPost']();}static['getEndPost_'](_0x501932){if(_0x501932['hasEnd']()){const _0x532b32=_0x501932['getIndexEndName']();return _0x501932['getIndex']()['makePost'](_0x501932['getIndexEndValue'](),_0x532b32);}else return _0x501932['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x5ec945){this['withinDirectionalStart']=_0x2ca148=>this['reverse_']?this['withinEndPost'](_0x2ca148):this['withinStartPost'](_0x2ca148),this['withinDirectionalEnd']=_0x1d3b18=>this['reverse_']?this['withinStartPost'](_0x1d3b18):this['withinEndPost'](_0x1d3b18),this['withinStartPost']=_0x22fafd=>{const _0xe9d4a=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x22fafd);return this['startIsInclusive_']?_0xe9d4a<=0x0:_0xe9d4a<0x0;},this['withinEndPost']=_0x1cad97=>{const _0x5b6d58=this['index_']['compare'](_0x1cad97,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x5b6d58<=0x0:_0x5b6d58<0x0;},this['rangedFilter_']=new Mt(_0x5ec945),this['index_']=_0x5ec945['getIndex'](),this['limit_']=_0x5ec945['getLimit'](),this['reverse_']=!_0x5ec945['isViewFromLeft'](),this['startIsInclusive_']=!_0x5ec945['startAfterSet_'],this['endIsInclusive_']=!_0x5ec945['endBeforeSet_'];}['updateChild'](_0x1f8d84,_0x2a8449,_0x1d76ff,_0x155e15,_0x545878,_0x33159b){return this['rangedFilter_']['matches'](new E(_0x2a8449,_0x1d76ff))||(_0x1d76ff=g['EMPTY_NODE']),_0x1f8d84['getImmediateChild'](_0x2a8449)['equals'](_0x1d76ff)?_0x1f8d84:_0x1f8d84['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x1f8d84,_0x2a8449,_0x1d76ff,_0x155e15,_0x545878,_0x33159b):this['fullLimitUpdateChild_'](_0x1f8d84,_0x2a8449,_0x1d76ff,_0x545878,_0x33159b);}['updateFullNode'](_0x10baf8,_0x343729,_0x24bc9e){let _0x4f9e59;if(_0x343729['isLeafNode']()||_0x343729['isEmpty']())_0x4f9e59=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x343729['numChildren']()&&_0x343729['isIndexed'](this['index_'])){_0x4f9e59=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x1eb784;this['reverse_']?_0x1eb784=_0x343729['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x1eb784=_0x343729['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x13f28a=0x0;for(;_0x1eb784['hasNext']()&&_0x13f28a<this['limit_'];){const _0xd047ee=_0x1eb784['getNext']();if(this['withinDirectionalStart'](_0xd047ee)){if(this['withinDirectionalEnd'](_0xd047ee))_0x4f9e59=_0x4f9e59['updateImmediateChild'](_0xd047ee['name'],_0xd047ee['node']),_0x13f28a++;else break;}else continue;}}else{_0x4f9e59=_0x343729['withIndex'](this['index_']),_0x4f9e59=_0x4f9e59['updatePriority'](g['EMPTY_NODE']);let _0x548724;this['reverse_']?_0x548724=_0x4f9e59['getReverseIterator'](this['index_']):_0x548724=_0x4f9e59['getIterator'](this['index_']);let _0x436bbb=0x0;for(;_0x548724['hasNext']();){const _0x5b2c26=_0x548724['getNext']();_0x436bbb<this['limit_']&&this['withinDirectionalStart'](_0x5b2c26)&&this['withinDirectionalEnd'](_0x5b2c26)?_0x436bbb++:_0x4f9e59=_0x4f9e59['updateImmediateChild'](_0x5b2c26['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x10baf8,_0x4f9e59,_0x24bc9e);}['updatePriority'](_0x112632,_0x5f3419){return _0x112632;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x1e6593,_0x44207c,_0x205dfc,_0x114fc0,_0x37728b){let _0x530f27;if(this['reverse_']){const _0x5ef1b1=this['index_']['getCompare']();_0x530f27=(_0x2f94b6,_0x33765e)=>_0x5ef1b1(_0x33765e,_0x2f94b6);}else _0x530f27=this['index_']['getCompare']();const _0x4d7b50=_0x1e6593;f(_0x4d7b50['numChildren']()===this['limit_'],'');const _0x1f0524=new E(_0x44207c,_0x205dfc),_0x4355a5=this['reverse_']?_0x4d7b50['getFirstChild'](this['index_']):_0x4d7b50['getLastChild'](this['index_']),_0x19d85b=this['rangedFilter_']['matches'](_0x1f0524);if(_0x4d7b50['hasChild'](_0x44207c)){const _0x51702a=_0x4d7b50['getImmediateChild'](_0x44207c);let _0x3f2ba6=_0x114fc0['getChildAfterChild'](this['index_'],_0x4355a5,this['reverse_']);for(;_0x3f2ba6!=null&&(_0x3f2ba6['name']===_0x44207c||_0x4d7b50['hasChild'](_0x3f2ba6['name']));)_0x3f2ba6=_0x114fc0['getChildAfterChild'](this['index_'],_0x3f2ba6,this['reverse_']);const _0x55f797=_0x3f2ba6==null?0x1:_0x530f27(_0x3f2ba6,_0x1f0524);if(_0x19d85b&&!_0x205dfc['isEmpty']()&&_0x55f797>=0x0)return _0x37728b!=null&&_0x37728b['trackChildChange'](Dt(_0x44207c,_0x205dfc,_0x51702a)),_0x4d7b50['updateImmediateChild'](_0x44207c,_0x205dfc);{_0x37728b!=null&&_0x37728b['trackChildChange'](Ot(_0x44207c,_0x51702a));const _0x313fe1=_0x4d7b50['updateImmediateChild'](_0x44207c,g['EMPTY_NODE']);return _0x3f2ba6!=null&&this['rangedFilter_']['matches'](_0x3f2ba6)?(_0x37728b!=null&&_0x37728b['trackChildChange'](et(_0x3f2ba6['name'],_0x3f2ba6['node'])),_0x313fe1['updateImmediateChild'](_0x3f2ba6['name'],_0x3f2ba6['node'])):_0x313fe1;}}else return _0x205dfc['isEmpty']()?_0x1e6593:_0x19d85b&&_0x530f27(_0x4355a5,_0x1f0524)>=0x0?(_0x37728b!=null&&(_0x37728b['trackChildChange'](Ot(_0x4355a5['name'],_0x4355a5['node'])),_0x37728b['trackChildChange'](et(_0x44207c,_0x205dfc))),_0x4d7b50['updateImmediateChild'](_0x44207c,_0x205dfc)['updateImmediateChild'](_0x4355a5['name'],g['EMPTY_NODE'])):_0x1e6593;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x2adf52=new Xi();return _0x2adf52['limitSet_']=this['limitSet_'],_0x2adf52['limit_']=this['limit_'],_0x2adf52['startSet_']=this['startSet_'],_0x2adf52['startAfterSet_']=this['startAfterSet_'],_0x2adf52['indexStartValue_']=this['indexStartValue_'],_0x2adf52['startNameSet_']=this['startNameSet_'],_0x2adf52['indexStartName_']=this['indexStartName_'],_0x2adf52['endSet_']=this['endSet_'],_0x2adf52['endBeforeSet_']=this['endBeforeSet_'],_0x2adf52['indexEndValue_']=this['indexEndValue_'],_0x2adf52['endNameSet_']=this['endNameSet_'],_0x2adf52['indexEndName_']=this['indexEndName_'],_0x2adf52['index_']=this['index_'],_0x2adf52['viewFrom_']=this['viewFrom_'],_0x2adf52;}}function Kh(_0x3c0dda){return _0x3c0dda['loadsAllData']()?new Ji(_0x3c0dda['getIndex']()):_0x3c0dda['hasLimit']()?new jh(_0x3c0dda):new Mt(_0x3c0dda);}function Yh(_0x201054,_0x574bf6){const _0x3199ac=_0x201054['copy']();return _0x3199ac['limitSet_']=!0x0,_0x3199ac['limit_']=_0x574bf6,_0x3199ac['viewFrom_']='l',_0x3199ac;}function Qh(_0x2ecfbf,_0x37da2,_0x46ad7b){const _0x4ce65b=_0x2ecfbf['copy']();return _0x4ce65b['startSet_']=!0x0,_0x37da2===void 0x0&&(_0x37da2=null),_0x4ce65b['indexStartValue_']=_0x37da2,_0x46ad7b!=null?(_0x4ce65b['startNameSet_']=!0x0,_0x4ce65b['indexStartName_']=_0x46ad7b):(_0x4ce65b['startNameSet_']=!0x1,_0x4ce65b['indexStartName_']=''),_0x4ce65b;}function Jh(_0x441fcd,_0x13fb62,_0x40260f){const _0x8a452a=_0x441fcd['copy']();return _0x8a452a['endSet_']=!0x0,_0x13fb62===void 0x0&&(_0x13fb62=null),_0x8a452a['indexEndValue_']=_0x13fb62,_0x40260f!==void 0x0?(_0x8a452a['endNameSet_']=!0x0,_0x8a452a['indexEndName_']=_0x40260f):(_0x8a452a['endNameSet_']=!0x1,_0x8a452a['indexEndName_']=''),_0x8a452a;}function xo(_0x3f422e,_0x4f9d85){const _0x426290=_0x3f422e['copy']();return _0x426290['index_']=_0x4f9d85,_0x426290;}function sr(_0x13bff9){const _0x2d7d55={};if(_0x13bff9['isDefault']())return _0x2d7d55;let _0x383913;if(_0x13bff9['index_']===R?_0x383913='$priority':_0x13bff9['index_']===Mo?_0x383913='$value':_0x13bff9['index_']===ye?_0x383913='$key':(f(_0x13bff9['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x383913=_0x13bff9['index_']['toString']()),_0x2d7d55['orderBy']=O(_0x383913),_0x13bff9['startSet_']){const _0xf1bb89=_0x13bff9['startAfterSet_']?'startAfter':'startAt';_0x2d7d55[_0xf1bb89]=O(_0x13bff9['indexStartValue_']),_0x13bff9['startNameSet_']&&(_0x2d7d55[_0xf1bb89]+=','+O(_0x13bff9['indexStartName_']));}if(_0x13bff9['endSet_']){const _0x3a91ad=_0x13bff9['endBeforeSet_']?'endBefore':'endAt';_0x2d7d55[_0x3a91ad]=O(_0x13bff9['indexEndValue_']),_0x13bff9['endNameSet_']&&(_0x2d7d55[_0x3a91ad]+=','+O(_0x13bff9['indexEndName_']));}return _0x13bff9['limitSet_']&&(_0x13bff9['isViewFromLeft']()?_0x2d7d55['limitToFirst']=_0x13bff9['limit_']:_0x2d7d55['limitToLast']=_0x13bff9['limit_']),_0x2d7d55;}function rr(_0x20a8b3){const _0x50eef1={};if(_0x20a8b3['startSet_']&&(_0x50eef1['sp']=_0x20a8b3['indexStartValue_'],_0x20a8b3['startNameSet_']&&(_0x50eef1['sn']=_0x20a8b3['indexStartName_']),_0x50eef1['sin']=!_0x20a8b3['startAfterSet_']),_0x20a8b3['endSet_']&&(_0x50eef1['ep']=_0x20a8b3['indexEndValue_'],_0x20a8b3['endNameSet_']&&(_0x50eef1['en']=_0x20a8b3['indexEndName_']),_0x50eef1['ein']=!_0x20a8b3['endBeforeSet_']),_0x20a8b3['limitSet_']){_0x50eef1['l']=_0x20a8b3['limit_'];let _0x28bf14=_0x20a8b3['viewFrom_'];_0x28bf14===''&&(_0x20a8b3['isViewFromLeft']()?_0x28bf14='l':_0x28bf14='r'),_0x50eef1['vf']=_0x28bf14;}return _0x20a8b3['index_']!==R&&(_0x50eef1['i']=_0x20a8b3['index_']['toString']()),_0x50eef1;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x3b7e37){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x5d5330,_0x540a27){return _0x540a27!==void 0x0?'tag$'+_0x540a27:(f(_0x5d5330['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x5d5330['_path']['toString']());}constructor(_0x4e0045,_0x1a61dc,_0x59f1eb,_0x1df160){super(),this['repoInfo_']=_0x4e0045,this['onDataUpdate_']=_0x1a61dc,this['authTokenProvider_']=_0x59f1eb,this['appCheckTokenProvider_']=_0x1df160,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x2d3bdc,_0x41cc41,_0x22154f,_0x2510cb){const _0x172cf1=_0x2d3bdc['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x172cf1+'\x20'+_0x2d3bdc['_queryIdentifier']);const _0x22fa14=pn['getListenId_'](_0x2d3bdc,_0x22154f),_0x5746ba={};this['listens_'][_0x22fa14]=_0x5746ba;const _0x3f5612=sr(_0x2d3bdc['_queryParams']);this['restRequest_'](_0x172cf1+'.json',_0x3f5612,(_0x4cff4e,_0x202ff8)=>{let _0x1de622=_0x202ff8;if(_0x4cff4e===0x194&&(_0x1de622=null,_0x4cff4e=null),_0x4cff4e===null&&this['onDataUpdate_'](_0x172cf1,_0x1de622,!0x1,_0x22154f),De(this['listens_'],_0x22fa14)===_0x5746ba){let _0x5b4fb7;_0x4cff4e?_0x4cff4e===0x191?_0x5b4fb7='permission_denied':_0x5b4fb7='rest_error:'+_0x4cff4e:_0x5b4fb7='ok',_0x2510cb(_0x5b4fb7,null);}});}['unlisten'](_0x4afa7b,_0x4aa2ce){const _0x223a2b=pn['getListenId_'](_0x4afa7b,_0x4aa2ce);delete this['listens_'][_0x223a2b];}['get'](_0x485269){const _0x333155=sr(_0x485269['_queryParams']),_0x4c065d=_0x485269['_path']['toString'](),_0x15d4f3=new ot();return this['restRequest_'](_0x4c065d+'.json',_0x333155,(_0x1236a6,_0x6f3ff8)=>{let _0x54e2c6=_0x6f3ff8;_0x1236a6===0x194&&(_0x54e2c6=null,_0x1236a6=null),_0x1236a6===null?(this['onDataUpdate_'](_0x4c065d,_0x54e2c6,!0x1,null),_0x15d4f3['resolve'](_0x54e2c6)):_0x15d4f3['reject'](new Error(_0x54e2c6));}),_0x15d4f3['promise'];}['refreshAuthToken'](_0x1dfe84){}['restRequest_'](_0x2de0df,_0x3f1354={},_0x36991a){return _0x3f1354['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x148b25,_0x6e0cc6])=>{_0x148b25&&_0x148b25['accessToken']&&(_0x3f1354['auth']=_0x148b25['accessToken']),_0x6e0cc6&&_0x6e0cc6['token']&&(_0x3f1354['ac']=_0x6e0cc6['token']);const _0x46b2ee=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x2de0df+'?ns='+this['repoInfo_']['namespace']+ct(_0x3f1354);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x46b2ee);const _0x32360f=new XMLHttpRequest();_0x32360f['onreadystatechange']=()=>{if(_0x36991a&&_0x32360f['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x46b2ee+'\x20received.\x20status:',_0x32360f['status'],'response:',_0x32360f['responseText']);let _0x37415a=null;if(_0x32360f['status']>=0xc8&&_0x32360f['status']<0x12c){try{_0x37415a=At(_0x32360f['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x46b2ee+':\x20'+_0x32360f['responseText']);}_0x36991a(null,_0x37415a);}else _0x32360f['status']!==0x191&&_0x32360f['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x46b2ee+'\x20Status:\x20'+_0x32360f['status']),_0x36991a(_0x32360f['status']);_0x36991a=null;}},_0x32360f['open']('GET',_0x46b2ee,!0x0),_0x32360f['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x1ed793){return this['rootNode_']['getChild'](_0x1ed793);}['updateSnapshot'](_0xb0ee13,_0x30904d){this['rootNode_']=this['rootNode_']['updateChild'](_0xb0ee13,_0x30904d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x43a3f7,_0x1f49ec,_0x54bad0){if(v(_0x1f49ec))_0x43a3f7['value']=_0x54bad0,_0x43a3f7['children']['clear']();else{if(_0x43a3f7['value']!==null)_0x43a3f7['value']=_0x43a3f7['value']['updateChild'](_0x1f49ec,_0x54bad0);else{const _0x205ac5=y(_0x1f49ec);_0x43a3f7['children']['has'](_0x205ac5)||_0x43a3f7['children']['set'](_0x205ac5,_n());const _0x23b0af=_0x43a3f7['children']['get'](_0x205ac5);_0x1f49ec=b(_0x1f49ec),Fo(_0x23b0af,_0x1f49ec,_0x54bad0);}}}function Ii(_0x3b7b26,_0x19c30c,_0xa822c6){_0x3b7b26['value']!==null?_0xa822c6(_0x19c30c,_0x3b7b26['value']):Zh(_0x3b7b26,(_0x3f8139,_0x1cc343)=>{const _0x93cd4=new C(_0x19c30c['toString']()+'/'+_0x3f8139);Ii(_0x1cc343,_0x93cd4,_0xa822c6);});}function Zh(_0x482163,_0x4e62a0){_0x482163['children']['forEach']((_0x68adda,_0x4bd924)=>{_0x4e62a0(_0x4bd924,_0x68adda);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x51f0b3){this['collection_']=_0x51f0b3,this['last_']=null;}['get'](){const _0x23a114=this['collection_']['get'](),_0x39eb44={..._0x23a114};return this['last_']&&x(this['last_'],(_0x29e040,_0x85a569)=>{_0x39eb44[_0x29e040]=_0x39eb44[_0x29e040]-_0x85a569;}),this['last_']=_0x23a114,_0x39eb44;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x302fce,_0x32004b){this['server_']=_0x32004b,this['statsToReport_']={},this['statsListener_']=new eu(_0x302fce);const _0x3082f2=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x3082f2));}['reportStats_'](){const _0x5b5ddc=this['statsListener_']['get'](),_0xdeeaa6={};let _0x4a8cbc=!0x1;x(_0x5b5ddc,(_0x24bebb,_0x19e3be)=>{_0x19e3be>0x0&&J(this['statsToReport_'],_0x24bebb)&&(_0xdeeaa6[_0x24bebb]=_0x19e3be,_0x4a8cbc=!0x0);}),_0x4a8cbc&&this['server_']['reportStats'](_0xdeeaa6),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x8d218c){_0x8d218c[_0x8d218c['OVERWRITE']=0x0]='OVERWRITE',_0x8d218c[_0x8d218c['MERGE']=0x1]='MERGE',_0x8d218c[_0x8d218c['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x8d218c[_0x8d218c['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x5eac3d){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x5eac3d,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x147ea9,_0xefd08,_0x6d3c2d){this['path']=_0x147ea9,this['affectedTree']=_0xefd08,this['revert']=_0x6d3c2d,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x3aaefb){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x49846e=this['affectedTree']['subtree'](new C(_0x3aaefb));return new gn(w(),_0x49846e,this['revert']);}}else return f(y(this['path'])===_0x3aaefb,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x58b141,_0x31c4e2){this['source']=_0x58b141,this['path']=_0x31c4e2,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x5876c8){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x295bc7,_0x1f413b,_0x2bc76e){this['source']=_0x295bc7,this['path']=_0x1f413b,this['snap']=_0x2bc76e,this['type']=j['OVERWRITE'];}['operationForChild'](_0x3aa225){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x3aa225)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x9f2da0,_0x580ea3,_0x2661b3){this['source']=_0x9f2da0,this['path']=_0x580ea3,this['children']=_0x2661b3,this['type']=j['MERGE'];}['operationForChild'](_0x50e494){if(v(this['path'])){const _0x57e2fa=this['children']['subtree'](new C(_0x50e494));return _0x57e2fa['isEmpty']()?null:_0x57e2fa['value']?new Ue(this['source'],w(),_0x57e2fa['value']):new tt(this['source'],w(),_0x57e2fa);}else return f(y(this['path'])===_0x50e494,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0xa1a46,_0x4e8402,_0x4fea86){this['node_']=_0xa1a46,this['fullyInitialized_']=_0x4e8402,this['filtered_']=_0x4fea86;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0xb28fed){if(v(_0xb28fed))return this['isFullyInitialized']()&&!this['filtered_'];const _0x127fca=y(_0xb28fed);return this['isCompleteForChild'](_0x127fca);}['isCompleteForChild'](_0xda2004){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0xda2004);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x11753c){this['query_']=_0x11753c,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x3fd84f,_0x1a14e7,_0x217dda,_0x5a0cdd){const _0xade6a4=[],_0x112df9=[];return _0x1a14e7['forEach'](_0x4ce267=>{_0x4ce267['type']==='child_changed'&&_0x3fd84f['index_']['indexedValueChanged'](_0x4ce267['oldSnap'],_0x4ce267['snapshotNode'])&&_0x112df9['push'](zh(_0x4ce267['childName'],_0x4ce267['snapshotNode']));}),yt(_0x3fd84f,_0xade6a4,'child_removed',_0x1a14e7,_0x5a0cdd,_0x217dda),yt(_0x3fd84f,_0xade6a4,'child_added',_0x1a14e7,_0x5a0cdd,_0x217dda),yt(_0x3fd84f,_0xade6a4,'child_moved',_0x112df9,_0x5a0cdd,_0x217dda),yt(_0x3fd84f,_0xade6a4,'child_changed',_0x1a14e7,_0x5a0cdd,_0x217dda),yt(_0x3fd84f,_0xade6a4,'value',_0x1a14e7,_0x5a0cdd,_0x217dda),_0xade6a4;}function yt(_0x471d22,_0x52f711,_0x30ce11,_0x23a4c6,_0x369313,_0x25acd1){const _0x4de47a=_0x23a4c6['filter'](_0x4aea63=>_0x4aea63['type']===_0x30ce11);_0x4de47a['sort']((_0x534fdf,_0x14474e)=>au(_0x471d22,_0x534fdf,_0x14474e)),_0x4de47a['forEach'](_0x5eca86=>{const _0x3c2e9f=ou(_0x471d22,_0x5eca86,_0x25acd1);_0x369313['forEach'](_0x3524e4=>{_0x3524e4['respondsTo'](_0x5eca86['type'])&&_0x52f711['push'](_0x3524e4['createEvent'](_0x3c2e9f,_0x471d22['query_']));});});}function ou(_0x44e606,_0x2e2b9c,_0x2f4d60){return _0x2e2b9c['type']==='value'||_0x2e2b9c['type']==='child_removed'||(_0x2e2b9c['prevName']=_0x2f4d60['getPredecessorChildName'](_0x2e2b9c['childName'],_0x2e2b9c['snapshotNode'],_0x44e606['index_'])),_0x2e2b9c;}function au(_0x33acfe,_0xcd385e,_0xbd2d8b){if(_0xcd385e['childName']==null||_0xbd2d8b['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x3faf80=new E(_0xcd385e['childName'],_0xcd385e['snapshotNode']),_0x56cdb0=new E(_0xbd2d8b['childName'],_0xbd2d8b['snapshotNode']);return _0x33acfe['index_']['compare'](_0x3faf80,_0x56cdb0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0xfec764,_0xe0f2ae){return{'eventCache':_0xfec764,'serverCache':_0xe0f2ae};}function Tt(_0x4f37fc,_0x2183f6,_0x41a2d4,_0x521adb){return Mn(new Ce(_0x2183f6,_0x41a2d4,_0x521adb),_0x4f37fc['serverCache']);}function Uo(_0x2204da,_0x2fb691,_0x254434,_0x27d882){return Mn(_0x2204da['eventCache'],new Ce(_0x2fb691,_0x254434,_0x27d882));}function mn(_0x17ff8d){return _0x17ff8d['eventCache']['isFullyInitialized']()?_0x17ff8d['eventCache']['getNode']():null;}function We(_0x478ae3){return _0x478ae3['serverCache']['isFullyInitialized']()?_0x478ae3['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x5d0c3b){let _0x4ffb58=new S(null);return x(_0x5d0c3b,(_0x495ffe,_0x117f53)=>{_0x4ffb58=_0x4ffb58['set'](new C(_0x495ffe),_0x117f53);}),_0x4ffb58;}constructor(_0x25734c,_0x2ed385=cu()){this['value']=_0x25734c,this['children']=_0x2ed385;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x51aac7,_0x31867d){if(this['value']!=null&&_0x31867d(this['value']))return{'path':w(),'value':this['value']};if(v(_0x51aac7))return null;{const _0x5ccdd8=y(_0x51aac7),_0x533e35=this['children']['get'](_0x5ccdd8);if(_0x533e35!==null){const _0xfb64ff=_0x533e35['findRootMostMatchingPathAndValue'](b(_0x51aac7),_0x31867d);return _0xfb64ff!=null?{'path':k(new C(_0x5ccdd8),_0xfb64ff['path']),'value':_0xfb64ff['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x1da90d){return this['findRootMostMatchingPathAndValue'](_0x1da90d,()=>!0x0);}['subtree'](_0x4cccbc){if(v(_0x4cccbc))return this;{const _0x33dead=y(_0x4cccbc),_0x4fb155=this['children']['get'](_0x33dead);return _0x4fb155!==null?_0x4fb155['subtree'](b(_0x4cccbc)):new S(null);}}['set'](_0x34ef24,_0x2ed3b0){if(v(_0x34ef24))return new S(_0x2ed3b0,this['children']);{const _0x4618da=y(_0x34ef24),_0x4ced7e=(this['children']['get'](_0x4618da)||new S(null))['set'](b(_0x34ef24),_0x2ed3b0),_0x41aa0a=this['children']['insert'](_0x4618da,_0x4ced7e);return new S(this['value'],_0x41aa0a);}}['remove'](_0x5517bc){if(v(_0x5517bc))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x193954=y(_0x5517bc),_0x14b854=this['children']['get'](_0x193954);if(_0x14b854){const _0x532baa=_0x14b854['remove'](b(_0x5517bc));let _0x5b6d80;return _0x532baa['isEmpty']()?_0x5b6d80=this['children']['remove'](_0x193954):_0x5b6d80=this['children']['insert'](_0x193954,_0x532baa),this['value']===null&&_0x5b6d80['isEmpty']()?new S(null):new S(this['value'],_0x5b6d80);}else return this;}}['get'](_0x10eb86){if(v(_0x10eb86))return this['value'];{const _0x2b0721=y(_0x10eb86),_0x20c693=this['children']['get'](_0x2b0721);return _0x20c693?_0x20c693['get'](b(_0x10eb86)):null;}}['setTree'](_0x445d63,_0x2d43ae){if(v(_0x445d63))return _0x2d43ae;{const _0x2bd587=y(_0x445d63),_0x1a6688=(this['children']['get'](_0x2bd587)||new S(null))['setTree'](b(_0x445d63),_0x2d43ae);let _0x58ce07;return _0x1a6688['isEmpty']()?_0x58ce07=this['children']['remove'](_0x2bd587):_0x58ce07=this['children']['insert'](_0x2bd587,_0x1a6688),new S(this['value'],_0x58ce07);}}['fold'](_0x5d9077){return this['fold_'](w(),_0x5d9077);}['fold_'](_0x15b491,_0x3345e3){const _0x4c4d52={};return this['children']['inorderTraversal']((_0xea9ca4,_0x141a3e)=>{_0x4c4d52[_0xea9ca4]=_0x141a3e['fold_'](k(_0x15b491,_0xea9ca4),_0x3345e3);}),_0x3345e3(_0x15b491,this['value'],_0x4c4d52);}['findOnPath'](_0x5460f4,_0xdb82cd){return this['findOnPath_'](_0x5460f4,w(),_0xdb82cd);}['findOnPath_'](_0x320613,_0x512b45,_0x41aec5){const _0x7341b3=this['value']?_0x41aec5(_0x512b45,this['value']):!0x1;if(_0x7341b3)return _0x7341b3;if(v(_0x320613))return null;{const _0x56d1e3=y(_0x320613),_0x10c8d8=this['children']['get'](_0x56d1e3);return _0x10c8d8?_0x10c8d8['findOnPath_'](b(_0x320613),k(_0x512b45,_0x56d1e3),_0x41aec5):null;}}['foreachOnPath'](_0x352c25,_0xa400e3){return this['foreachOnPath_'](_0x352c25,w(),_0xa400e3);}['foreachOnPath_'](_0x2d3afd,_0x128b2b,_0x49aa0a){if(v(_0x2d3afd))return this;{this['value']&&_0x49aa0a(_0x128b2b,this['value']);const _0x4a6b2f=y(_0x2d3afd),_0x3aa74a=this['children']['get'](_0x4a6b2f);return _0x3aa74a?_0x3aa74a['foreachOnPath_'](b(_0x2d3afd),k(_0x128b2b,_0x4a6b2f),_0x49aa0a):new S(null);}}['foreach'](_0x3f5e10){this['foreach_'](w(),_0x3f5e10);}['foreach_'](_0x286437,_0x4820ef){this['children']['inorderTraversal']((_0x54ca51,_0x1da195)=>{_0x1da195['foreach_'](k(_0x286437,_0x54ca51),_0x4820ef);}),this['value']&&_0x4820ef(_0x286437,this['value']);}['foreachChild'](_0x52cfac){this['children']['inorderTraversal']((_0x32d7a3,_0x19acbc)=>{_0x19acbc['value']&&_0x52cfac(_0x32d7a3,_0x19acbc['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x2764db){this['writeTree_']=_0x2764db;}static['empty'](){return new Y(new S(null));}}function St(_0x2b420e,_0x158e94,_0x2f60e8){if(v(_0x158e94))return new Y(new S(_0x2f60e8));{const _0x452c14=_0x2b420e['writeTree_']['findRootMostValueAndPath'](_0x158e94);if(_0x452c14!=null){const _0x5772d0=_0x452c14['path'];let _0x362468=_0x452c14['value'];const _0x4d471d=F(_0x5772d0,_0x158e94);return _0x362468=_0x362468['updateChild'](_0x4d471d,_0x2f60e8),new Y(_0x2b420e['writeTree_']['set'](_0x5772d0,_0x362468));}else{const _0x410ab8=new S(_0x2f60e8),_0x51dc4e=_0x2b420e['writeTree_']['setTree'](_0x158e94,_0x410ab8);return new Y(_0x51dc4e);}}}function wi(_0x4c2e6b,_0x9b663e,_0x465f6d){let _0x205f46=_0x4c2e6b;return x(_0x465f6d,(_0xa6da3a,_0x40e4ac)=>{_0x205f46=St(_0x205f46,k(_0x9b663e,_0xa6da3a),_0x40e4ac);}),_0x205f46;}function ar(_0x58e754,_0x5d6366){if(v(_0x5d6366))return Y['empty']();{const _0x12643c=_0x58e754['writeTree_']['setTree'](_0x5d6366,new S(null));return new Y(_0x12643c);}}function Ci(_0x4e71ba,_0x2af4a8){return $e(_0x4e71ba,_0x2af4a8)!=null;}function $e(_0x467a68,_0x46c10e){const _0x35ca8c=_0x467a68['writeTree_']['findRootMostValueAndPath'](_0x46c10e);return _0x35ca8c!=null?_0x467a68['writeTree_']['get'](_0x35ca8c['path'])['getChild'](F(_0x35ca8c['path'],_0x46c10e)):null;}function cr(_0x3a2357){const _0x531b5a=[],_0x45f393=_0x3a2357['writeTree_']['value'];return _0x45f393!=null?_0x45f393['isLeafNode']()||_0x45f393['forEachChild'](R,(_0x3080f8,_0x16c2ce)=>{_0x531b5a['push'](new E(_0x3080f8,_0x16c2ce));}):_0x3a2357['writeTree_']['children']['inorderTraversal']((_0x2ce8c9,_0x524061)=>{_0x524061['value']!=null&&_0x531b5a['push'](new E(_0x2ce8c9,_0x524061['value']));}),_0x531b5a;}function ve(_0x1d8ab8,_0xbe1f80){if(v(_0xbe1f80))return _0x1d8ab8;{const _0x2106b1=$e(_0x1d8ab8,_0xbe1f80);return _0x2106b1!=null?new Y(new S(_0x2106b1)):new Y(_0x1d8ab8['writeTree_']['subtree'](_0xbe1f80));}}function Ti(_0x650286){return _0x650286['writeTree_']['isEmpty']();}function nt(_0x1e277b,_0x50c81f){return Wo(w(),_0x1e277b['writeTree_'],_0x50c81f);}function Wo(_0x49c4f0,_0x104541,_0x5059e9){if(_0x104541['value']!=null)return _0x5059e9['updateChild'](_0x49c4f0,_0x104541['value']);{let _0x100e81=null;return _0x104541['children']['inorderTraversal']((_0x5b3dbf,_0x39f384)=>{_0x5b3dbf==='.priority'?(f(_0x39f384['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x100e81=_0x39f384['value']):_0x5059e9=Wo(k(_0x49c4f0,_0x5b3dbf),_0x39f384,_0x5059e9);}),!_0x5059e9['getChild'](_0x49c4f0)['isEmpty']()&&_0x100e81!==null&&(_0x5059e9=_0x5059e9['updateChild'](k(_0x49c4f0,'.priority'),_0x100e81)),_0x5059e9;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x155560,_0x2025ff){return $o(_0x2025ff,_0x155560);}function lu(_0x2dbf4b,_0x266ec9,_0xd4e41d,_0x3119eb,_0x260d7e){f(_0x3119eb>_0x2dbf4b['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x260d7e===void 0x0&&(_0x260d7e=!0x0),_0x2dbf4b['allWrites']['push']({'path':_0x266ec9,'snap':_0xd4e41d,'writeId':_0x3119eb,'visible':_0x260d7e}),_0x260d7e&&(_0x2dbf4b['visibleWrites']=St(_0x2dbf4b['visibleWrites'],_0x266ec9,_0xd4e41d)),_0x2dbf4b['lastWriteId']=_0x3119eb;}function hu(_0x53910f,_0xe706cc,_0xc5f21f,_0x2bcd66){f(_0x2bcd66>_0x53910f['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x53910f['allWrites']['push']({'path':_0xe706cc,'children':_0xc5f21f,'writeId':_0x2bcd66,'visible':!0x0}),_0x53910f['visibleWrites']=wi(_0x53910f['visibleWrites'],_0xe706cc,_0xc5f21f),_0x53910f['lastWriteId']=_0x2bcd66;}function uu(_0x148c93,_0x37c1c6){for(let _0x11dbf1=0x0;_0x11dbf1<_0x148c93['allWrites']['length'];_0x11dbf1++){const _0x41d867=_0x148c93['allWrites'][_0x11dbf1];if(_0x41d867['writeId']===_0x37c1c6)return _0x41d867;}return null;}function du(_0x49e6bb,_0x160f35){const _0x302596=_0x49e6bb['allWrites']['findIndex'](_0x21bc39=>_0x21bc39['writeId']===_0x160f35);f(_0x302596>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x4b82b3=_0x49e6bb['allWrites'][_0x302596];_0x49e6bb['allWrites']['splice'](_0x302596,0x1);let _0x222a72=_0x4b82b3['visible'],_0x142526=!0x1,_0xe8bac5=_0x49e6bb['allWrites']['length']-0x1;for(;_0x222a72&&_0xe8bac5>=0x0;){const _0x11c32a=_0x49e6bb['allWrites'][_0xe8bac5];_0x11c32a['visible']&&(_0xe8bac5>=_0x302596&&fu(_0x11c32a,_0x4b82b3['path'])?_0x222a72=!0x1:G(_0x4b82b3['path'],_0x11c32a['path'])&&(_0x142526=!0x0)),_0xe8bac5--;}if(_0x222a72){if(_0x142526)return pu(_0x49e6bb),!0x0;if(_0x4b82b3['snap'])_0x49e6bb['visibleWrites']=ar(_0x49e6bb['visibleWrites'],_0x4b82b3['path']);else{const _0x4235f7=_0x4b82b3['children'];x(_0x4235f7,_0x278def=>{_0x49e6bb['visibleWrites']=ar(_0x49e6bb['visibleWrites'],k(_0x4b82b3['path'],_0x278def));});}return!0x0;}else return!0x1;}function fu(_0x329765,_0xdc560b){if(_0x329765['snap'])return G(_0x329765['path'],_0xdc560b);for(const _0x2bd635 in _0x329765['children'])if(_0x329765['children']['hasOwnProperty'](_0x2bd635)&&G(k(_0x329765['path'],_0x2bd635),_0xdc560b))return!0x0;return!0x1;}function pu(_0x520b4d){_0x520b4d['visibleWrites']=Bo(_0x520b4d['allWrites'],_u,w()),_0x520b4d['allWrites']['length']>0x0?_0x520b4d['lastWriteId']=_0x520b4d['allWrites'][_0x520b4d['allWrites']['length']-0x1]['writeId']:_0x520b4d['lastWriteId']=-0x1;}function _u(_0x47f61e){return _0x47f61e['visible'];}function Bo(_0x591829,_0x829207,_0xe8eae4){let _0x1a97ea=Y['empty']();for(let _0xc0e823=0x0;_0xc0e823<_0x591829['length'];++_0xc0e823){const _0x458123=_0x591829[_0xc0e823];if(_0x829207(_0x458123)){const _0x4ed776=_0x458123['path'];let _0x2b64f4;if(_0x458123['snap'])G(_0xe8eae4,_0x4ed776)?(_0x2b64f4=F(_0xe8eae4,_0x4ed776),_0x1a97ea=St(_0x1a97ea,_0x2b64f4,_0x458123['snap'])):G(_0x4ed776,_0xe8eae4)&&(_0x2b64f4=F(_0x4ed776,_0xe8eae4),_0x1a97ea=St(_0x1a97ea,w(),_0x458123['snap']['getChild'](_0x2b64f4)));else{if(_0x458123['children']){if(G(_0xe8eae4,_0x4ed776))_0x2b64f4=F(_0xe8eae4,_0x4ed776),_0x1a97ea=wi(_0x1a97ea,_0x2b64f4,_0x458123['children']);else{if(G(_0x4ed776,_0xe8eae4)){if(_0x2b64f4=F(_0x4ed776,_0xe8eae4),v(_0x2b64f4))_0x1a97ea=wi(_0x1a97ea,w(),_0x458123['children']);else{const _0x2db610=De(_0x458123['children'],y(_0x2b64f4));if(_0x2db610){const _0x1e8fec=_0x2db610['getChild'](b(_0x2b64f4));_0x1a97ea=St(_0x1a97ea,w(),_0x1e8fec);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x1a97ea;}function Vo(_0x1894f3,_0x86e047,_0x587673,_0x54b3fb,_0x5df8fc){if(!_0x54b3fb&&!_0x5df8fc){const _0x5bd8e0=$e(_0x1894f3['visibleWrites'],_0x86e047);if(_0x5bd8e0!=null)return _0x5bd8e0;{const _0x1e3803=ve(_0x1894f3['visibleWrites'],_0x86e047);if(Ti(_0x1e3803))return _0x587673;if(_0x587673==null&&!Ci(_0x1e3803,w()))return null;{const _0x4d5048=_0x587673||g['EMPTY_NODE'];return nt(_0x1e3803,_0x4d5048);}}}else{const _0x3b5ea2=ve(_0x1894f3['visibleWrites'],_0x86e047);if(!_0x5df8fc&&Ti(_0x3b5ea2))return _0x587673;if(!_0x5df8fc&&_0x587673==null&&!Ci(_0x3b5ea2,w()))return null;{const _0x315267=function(_0x3d04d4){return(_0x3d04d4['visible']||_0x5df8fc)&&(!_0x54b3fb||!~_0x54b3fb['indexOf'](_0x3d04d4['writeId']))&&(G(_0x3d04d4['path'],_0x86e047)||G(_0x86e047,_0x3d04d4['path']));},_0x512c03=Bo(_0x1894f3['allWrites'],_0x315267,_0x86e047),_0x5708b5=_0x587673||g['EMPTY_NODE'];return nt(_0x512c03,_0x5708b5);}}}function gu(_0x1cb1f6,_0x430bdf,_0x307874){let _0x1359af=g['EMPTY_NODE'];const _0x3be6f3=$e(_0x1cb1f6['visibleWrites'],_0x430bdf);if(_0x3be6f3)return _0x3be6f3['isLeafNode']()||_0x3be6f3['forEachChild'](R,(_0x926a9c,_0x467ad3)=>{_0x1359af=_0x1359af['updateImmediateChild'](_0x926a9c,_0x467ad3);}),_0x1359af;if(_0x307874){const _0x171c9d=ve(_0x1cb1f6['visibleWrites'],_0x430bdf);return _0x307874['forEachChild'](R,(_0x3d0179,_0xb18a72)=>{const _0x563a89=nt(ve(_0x171c9d,new C(_0x3d0179)),_0xb18a72);_0x1359af=_0x1359af['updateImmediateChild'](_0x3d0179,_0x563a89);}),cr(_0x171c9d)['forEach'](_0x4e7a4c=>{_0x1359af=_0x1359af['updateImmediateChild'](_0x4e7a4c['name'],_0x4e7a4c['node']);}),_0x1359af;}else{const _0xa3c472=ve(_0x1cb1f6['visibleWrites'],_0x430bdf);return cr(_0xa3c472)['forEach'](_0x231c1b=>{_0x1359af=_0x1359af['updateImmediateChild'](_0x231c1b['name'],_0x231c1b['node']);}),_0x1359af;}}function mu(_0x3dfeaa,_0x4d2ec5,_0x71e9f4,_0x201348,_0x574a58){f(_0x201348||_0x574a58,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x4d56ea=k(_0x4d2ec5,_0x71e9f4);if(Ci(_0x3dfeaa['visibleWrites'],_0x4d56ea))return null;{const _0x2d5d42=ve(_0x3dfeaa['visibleWrites'],_0x4d56ea);return Ti(_0x2d5d42)?_0x574a58['getChild'](_0x71e9f4):nt(_0x2d5d42,_0x574a58['getChild'](_0x71e9f4));}}function yu(_0x71554f,_0xe7d136,_0x5a6398,_0x1a9bd3){const _0x4e5455=k(_0xe7d136,_0x5a6398),_0x5a7b74=$e(_0x71554f['visibleWrites'],_0x4e5455);if(_0x5a7b74!=null)return _0x5a7b74;if(_0x1a9bd3['isCompleteForChild'](_0x5a6398)){const _0x114c62=ve(_0x71554f['visibleWrites'],_0x4e5455);return nt(_0x114c62,_0x1a9bd3['getNode']()['getImmediateChild'](_0x5a6398));}else return null;}function vu(_0x5c47c9,_0x322b6b){return $e(_0x5c47c9['visibleWrites'],_0x322b6b);}function Eu(_0xa0682f,_0x5d69cf,_0x1158b8,_0x298795,_0x2f757b,_0x1b3059,_0x516d28){let _0x4fb334;const _0x31e00f=ve(_0xa0682f['visibleWrites'],_0x5d69cf),_0x53289a=$e(_0x31e00f,w());if(_0x53289a!=null)_0x4fb334=_0x53289a;else{if(_0x1158b8!=null)_0x4fb334=nt(_0x31e00f,_0x1158b8);else return[];}if(_0x4fb334=_0x4fb334['withIndex'](_0x516d28),!_0x4fb334['isEmpty']()&&!_0x4fb334['isLeafNode']()){const _0x5951bc=[],_0x438991=_0x516d28['getCompare'](),_0x57e6db=_0x1b3059?_0x4fb334['getReverseIteratorFrom'](_0x298795,_0x516d28):_0x4fb334['getIteratorFrom'](_0x298795,_0x516d28);let _0x43aabd=_0x57e6db['getNext']();for(;_0x43aabd&&_0x5951bc['length']<_0x2f757b;)_0x438991(_0x43aabd,_0x298795)!==0x0&&_0x5951bc['push'](_0x43aabd),_0x43aabd=_0x57e6db['getNext']();return _0x5951bc;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x472507,_0x89e5bc,_0x5c06ba,_0x4b730a){return Vo(_0x472507['writeTree'],_0x472507['treePath'],_0x89e5bc,_0x5c06ba,_0x4b730a);}function ns(_0x5b4754,_0x2e73ac){return gu(_0x5b4754['writeTree'],_0x5b4754['treePath'],_0x2e73ac);}function lr(_0x38dc6e,_0x298c72,_0x23dfba,_0x96c01c){return mu(_0x38dc6e['writeTree'],_0x38dc6e['treePath'],_0x298c72,_0x23dfba,_0x96c01c);}function vn(_0x38c139,_0x5ef92c){return vu(_0x38c139['writeTree'],k(_0x38c139['treePath'],_0x5ef92c));}function wu(_0x19733a,_0x1b20b4,_0x70c85f,_0x28962d,_0x1a6b5f,_0x468f17){return Eu(_0x19733a['writeTree'],_0x19733a['treePath'],_0x1b20b4,_0x70c85f,_0x28962d,_0x1a6b5f,_0x468f17);}function is(_0x2ba157,_0x4a40bd,_0x5c5c11){return yu(_0x2ba157['writeTree'],_0x2ba157['treePath'],_0x4a40bd,_0x5c5c11);}function Ho(_0x547fb6,_0x277104){return $o(k(_0x547fb6['treePath'],_0x277104),_0x547fb6['writeTree']);}function $o(_0x5ef984,_0x5f3080){return{'treePath':_0x5ef984,'writeTree':_0x5f3080};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x36fbdc){const _0x24f2dc=_0x36fbdc['type'],_0xca30a1=_0x36fbdc['childName'];f(_0x24f2dc==='child_added'||_0x24f2dc==='child_changed'||_0x24f2dc==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0xca30a1!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x1d9edb=this['changeMap']['get'](_0xca30a1);if(_0x1d9edb){const _0x4c5625=_0x1d9edb['type'];if(_0x24f2dc==='child_added'&&_0x4c5625==='child_removed')this['changeMap']['set'](_0xca30a1,Dt(_0xca30a1,_0x36fbdc['snapshotNode'],_0x1d9edb['snapshotNode']));else{if(_0x24f2dc==='child_removed'&&_0x4c5625==='child_added')this['changeMap']['delete'](_0xca30a1);else{if(_0x24f2dc==='child_removed'&&_0x4c5625==='child_changed')this['changeMap']['set'](_0xca30a1,Ot(_0xca30a1,_0x1d9edb['oldSnap']));else{if(_0x24f2dc==='child_changed'&&_0x4c5625==='child_added')this['changeMap']['set'](_0xca30a1,et(_0xca30a1,_0x36fbdc['snapshotNode']));else{if(_0x24f2dc==='child_changed'&&_0x4c5625==='child_changed')this['changeMap']['set'](_0xca30a1,Dt(_0xca30a1,_0x36fbdc['snapshotNode'],_0x1d9edb['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x36fbdc+'\x20occurred\x20after\x20'+_0x1d9edb);}}}}}else this['changeMap']['set'](_0xca30a1,_0x36fbdc);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x1eb189){return null;}['getChildAfterChild'](_0x3e4fa7,_0x510236,_0x3ab812){return null;}}const Go=new Tu();class ss{constructor(_0x4641d7,_0x1e0fa5,_0x3b0cac=null){this['writes_']=_0x4641d7,this['viewCache_']=_0x1e0fa5,this['optCompleteServerCache_']=_0x3b0cac;}['getCompleteChild'](_0x3c76fb){const _0x330840=this['viewCache_']['eventCache'];if(_0x330840['isCompleteForChild'](_0x3c76fb))return _0x330840['getNode']()['getImmediateChild'](_0x3c76fb);{const _0x5df4bd=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x3c76fb,_0x5df4bd);}}['getChildAfterChild'](_0xd8fbf,_0x4f3de2,_0xa72641){const _0xd0aaeb=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x1dbf00=wu(this['writes_'],_0xd0aaeb,_0x4f3de2,0x1,_0xa72641,_0xd8fbf);return _0x1dbf00['length']===0x0?null:_0x1dbf00[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x5d02a1){return{'filter':_0x5d02a1};}function bu(_0x35a93d,_0x5dc4c7){f(_0x5dc4c7['eventCache']['getNode']()['isIndexed'](_0x35a93d['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x5dc4c7['serverCache']['getNode']()['isIndexed'](_0x35a93d['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x11b454,_0x63125d,_0x3ef650,_0x367136,_0x5abf77){const _0x3c7aaa=new Cu();let _0x33764b,_0x3f8913;if(_0x3ef650['type']===j['OVERWRITE']){const _0x1a5b91=_0x3ef650;_0x1a5b91['source']['fromUser']?_0x33764b=Si(_0x11b454,_0x63125d,_0x1a5b91['path'],_0x1a5b91['snap'],_0x367136,_0x5abf77,_0x3c7aaa):(f(_0x1a5b91['source']['fromServer'],'Unknown\x20source.'),_0x3f8913=_0x1a5b91['source']['tagged']||_0x63125d['serverCache']['isFiltered']()&&!v(_0x1a5b91['path']),_0x33764b=En(_0x11b454,_0x63125d,_0x1a5b91['path'],_0x1a5b91['snap'],_0x367136,_0x5abf77,_0x3f8913,_0x3c7aaa));}else{if(_0x3ef650['type']===j['MERGE']){const _0x2ec9ad=_0x3ef650;_0x2ec9ad['source']['fromUser']?_0x33764b=ku(_0x11b454,_0x63125d,_0x2ec9ad['path'],_0x2ec9ad['children'],_0x367136,_0x5abf77,_0x3c7aaa):(f(_0x2ec9ad['source']['fromServer'],'Unknown\x20source.'),_0x3f8913=_0x2ec9ad['source']['tagged']||_0x63125d['serverCache']['isFiltered'](),_0x33764b=bi(_0x11b454,_0x63125d,_0x2ec9ad['path'],_0x2ec9ad['children'],_0x367136,_0x5abf77,_0x3f8913,_0x3c7aaa));}else{if(_0x3ef650['type']===j['ACK_USER_WRITE']){const _0x272ccb=_0x3ef650;_0x272ccb['revert']?_0x33764b=Ou(_0x11b454,_0x63125d,_0x272ccb['path'],_0x367136,_0x5abf77,_0x3c7aaa):_0x33764b=Nu(_0x11b454,_0x63125d,_0x272ccb['path'],_0x272ccb['affectedTree'],_0x367136,_0x5abf77,_0x3c7aaa);}else{if(_0x3ef650['type']===j['LISTEN_COMPLETE'])_0x33764b=Pu(_0x11b454,_0x63125d,_0x3ef650['path'],_0x367136,_0x3c7aaa);else throw rt('Unknown\x20operation\x20type:\x20'+_0x3ef650['type']);}}}const _0x5015ba=_0x3c7aaa['getChanges']();return Au(_0x63125d,_0x33764b,_0x5015ba),{'viewCache':_0x33764b,'changes':_0x5015ba};}function Au(_0x428070,_0x107100,_0x4a7d2a){const _0x15a8a3=_0x107100['eventCache'];if(_0x15a8a3['isFullyInitialized']()){const _0x231339=_0x15a8a3['getNode']()['isLeafNode']()||_0x15a8a3['getNode']()['isEmpty'](),_0x5eea99=mn(_0x428070);(_0x4a7d2a['length']>0x0||!_0x428070['eventCache']['isFullyInitialized']()||_0x231339&&!_0x15a8a3['getNode']()['equals'](_0x5eea99)||!_0x15a8a3['getNode']()['getPriority']()['equals'](_0x5eea99['getPriority']()))&&_0x4a7d2a['push'](Lo(mn(_0x107100)));}}function qo(_0x518c8e,_0x256d10,_0x48ee12,_0x20b9d1,_0x4744a6,_0x458a4b){const _0x598468=_0x256d10['eventCache'];if(vn(_0x20b9d1,_0x48ee12)!=null)return _0x256d10;{let _0x38771a,_0x12381d;if(v(_0x48ee12)){if(f(_0x256d10['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x256d10['serverCache']['isFiltered']()){const _0x18fec0=We(_0x256d10),_0x1d4f22=_0x18fec0 instanceof g?_0x18fec0:g['EMPTY_NODE'],_0x198ec1=ns(_0x20b9d1,_0x1d4f22);_0x38771a=_0x518c8e['filter']['updateFullNode'](_0x256d10['eventCache']['getNode'](),_0x198ec1,_0x458a4b);}else{const _0x10efa1=yn(_0x20b9d1,We(_0x256d10));_0x38771a=_0x518c8e['filter']['updateFullNode'](_0x256d10['eventCache']['getNode'](),_0x10efa1,_0x458a4b);}}else{const _0x111ddc=y(_0x48ee12);if(_0x111ddc==='.priority'){f(we(_0x48ee12)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0xeb5c11=_0x598468['getNode']();_0x12381d=_0x256d10['serverCache']['getNode']();const _0x576051=lr(_0x20b9d1,_0x48ee12,_0xeb5c11,_0x12381d);_0x576051!=null?_0x38771a=_0x518c8e['filter']['updatePriority'](_0xeb5c11,_0x576051):_0x38771a=_0x598468['getNode']();}else{const _0x288d70=b(_0x48ee12);let _0xfba0f6;if(_0x598468['isCompleteForChild'](_0x111ddc)){_0x12381d=_0x256d10['serverCache']['getNode']();const _0x36f068=lr(_0x20b9d1,_0x48ee12,_0x598468['getNode'](),_0x12381d);_0x36f068!=null?_0xfba0f6=_0x598468['getNode']()['getImmediateChild'](_0x111ddc)['updateChild'](_0x288d70,_0x36f068):_0xfba0f6=_0x598468['getNode']()['getImmediateChild'](_0x111ddc);}else _0xfba0f6=is(_0x20b9d1,_0x111ddc,_0x256d10['serverCache']);_0xfba0f6!=null?_0x38771a=_0x518c8e['filter']['updateChild'](_0x598468['getNode'](),_0x111ddc,_0xfba0f6,_0x288d70,_0x4744a6,_0x458a4b):_0x38771a=_0x598468['getNode']();}}return Tt(_0x256d10,_0x38771a,_0x598468['isFullyInitialized']()||v(_0x48ee12),_0x518c8e['filter']['filtersNodes']());}}function En(_0x2a0ab0,_0x84bc54,_0x2fc726,_0x582840,_0x52dafe,_0xa23256,_0x22aa0a,_0x25fcfb){const _0x1d5a83=_0x84bc54['serverCache'];let _0xc0e240;const _0x355012=_0x22aa0a?_0x2a0ab0['filter']:_0x2a0ab0['filter']['getIndexedFilter']();if(v(_0x2fc726))_0xc0e240=_0x355012['updateFullNode'](_0x1d5a83['getNode'](),_0x582840,null);else{if(_0x355012['filtersNodes']()&&!_0x1d5a83['isFiltered']()){const _0x524d15=_0x1d5a83['getNode']()['updateChild'](_0x2fc726,_0x582840);_0xc0e240=_0x355012['updateFullNode'](_0x1d5a83['getNode'](),_0x524d15,null);}else{const _0x283d92=y(_0x2fc726);if(!_0x1d5a83['isCompleteForPath'](_0x2fc726)&&we(_0x2fc726)>0x1)return _0x84bc54;const _0x334cf9=b(_0x2fc726),_0x31a6e8=_0x1d5a83['getNode']()['getImmediateChild'](_0x283d92)['updateChild'](_0x334cf9,_0x582840);_0x283d92==='.priority'?_0xc0e240=_0x355012['updatePriority'](_0x1d5a83['getNode'](),_0x31a6e8):_0xc0e240=_0x355012['updateChild'](_0x1d5a83['getNode'](),_0x283d92,_0x31a6e8,_0x334cf9,Go,null);}}const _0x2573e1=Uo(_0x84bc54,_0xc0e240,_0x1d5a83['isFullyInitialized']()||v(_0x2fc726),_0x355012['filtersNodes']()),_0x4fe516=new ss(_0x52dafe,_0x2573e1,_0xa23256);return qo(_0x2a0ab0,_0x2573e1,_0x2fc726,_0x52dafe,_0x4fe516,_0x25fcfb);}function Si(_0x21116e,_0x3726d6,_0xe9b5f3,_0x386cf7,_0x20025d,_0x1b023e,_0x203536){const _0x26bc93=_0x3726d6['eventCache'];let _0x315776,_0x190261;const _0x1919c3=new ss(_0x20025d,_0x3726d6,_0x1b023e);if(v(_0xe9b5f3))_0x190261=_0x21116e['filter']['updateFullNode'](_0x3726d6['eventCache']['getNode'](),_0x386cf7,_0x203536),_0x315776=Tt(_0x3726d6,_0x190261,!0x0,_0x21116e['filter']['filtersNodes']());else{const _0x2da653=y(_0xe9b5f3);if(_0x2da653==='.priority')_0x190261=_0x21116e['filter']['updatePriority'](_0x3726d6['eventCache']['getNode'](),_0x386cf7),_0x315776=Tt(_0x3726d6,_0x190261,_0x26bc93['isFullyInitialized'](),_0x26bc93['isFiltered']());else{const _0x15ae11=b(_0xe9b5f3),_0x2f604c=_0x26bc93['getNode']()['getImmediateChild'](_0x2da653);let _0x41bb4e;if(v(_0x15ae11))_0x41bb4e=_0x386cf7;else{const _0x37e647=_0x1919c3['getCompleteChild'](_0x2da653);_0x37e647!=null?zi(_0x15ae11)==='.priority'&&_0x37e647['getChild'](Ro(_0x15ae11))['isEmpty']()?_0x41bb4e=_0x37e647:_0x41bb4e=_0x37e647['updateChild'](_0x15ae11,_0x386cf7):_0x41bb4e=g['EMPTY_NODE'];}if(_0x2f604c['equals'](_0x41bb4e))_0x315776=_0x3726d6;else{const _0x432ded=_0x21116e['filter']['updateChild'](_0x26bc93['getNode'](),_0x2da653,_0x41bb4e,_0x15ae11,_0x1919c3,_0x203536);_0x315776=Tt(_0x3726d6,_0x432ded,_0x26bc93['isFullyInitialized'](),_0x21116e['filter']['filtersNodes']());}}}return _0x315776;}function hr(_0x5e6978,_0x445d0){return _0x5e6978['eventCache']['isCompleteForChild'](_0x445d0);}function ku(_0x350b5f,_0x2d4353,_0x4add39,_0x3a9f5f,_0x142e43,_0x4aac68,_0x314dca){let _0x83b68d=_0x2d4353;return _0x3a9f5f['foreach']((_0x386317,_0x4b0794)=>{const _0x39b131=k(_0x4add39,_0x386317);hr(_0x2d4353,y(_0x39b131))&&(_0x83b68d=Si(_0x350b5f,_0x83b68d,_0x39b131,_0x4b0794,_0x142e43,_0x4aac68,_0x314dca));}),_0x3a9f5f['foreach']((_0x540290,_0x49b876)=>{const _0x570513=k(_0x4add39,_0x540290);hr(_0x2d4353,y(_0x570513))||(_0x83b68d=Si(_0x350b5f,_0x83b68d,_0x570513,_0x49b876,_0x142e43,_0x4aac68,_0x314dca));}),_0x83b68d;}function ur(_0x863747,_0x3fb8c0,_0x216e2f){return _0x216e2f['foreach']((_0x55c622,_0x94ee3a)=>{_0x3fb8c0=_0x3fb8c0['updateChild'](_0x55c622,_0x94ee3a);}),_0x3fb8c0;}function bi(_0xbe2d4f,_0x31f352,_0x30b1ce,_0x22014f,_0x3e9622,_0x55bb0f,_0xe24558,_0x281eb0){if(_0x31f352['serverCache']['getNode']()['isEmpty']()&&!_0x31f352['serverCache']['isFullyInitialized']())return _0x31f352;let _0x45444f=_0x31f352,_0x3494f0;v(_0x30b1ce)?_0x3494f0=_0x22014f:_0x3494f0=new S(null)['setTree'](_0x30b1ce,_0x22014f);const _0xfe87f5=_0x31f352['serverCache']['getNode']();return _0x3494f0['children']['inorderTraversal']((_0xe59419,_0x2ef41a)=>{if(_0xfe87f5['hasChild'](_0xe59419)){const _0x53f5ce=_0x31f352['serverCache']['getNode']()['getImmediateChild'](_0xe59419),_0x4c50ce=ur(_0xbe2d4f,_0x53f5ce,_0x2ef41a);_0x45444f=En(_0xbe2d4f,_0x45444f,new C(_0xe59419),_0x4c50ce,_0x3e9622,_0x55bb0f,_0xe24558,_0x281eb0);}}),_0x3494f0['children']['inorderTraversal']((_0x5f12cf,_0x59c6b2)=>{const _0x4c39a6=!_0x31f352['serverCache']['isCompleteForChild'](_0x5f12cf)&&_0x59c6b2['value']===null;if(!_0xfe87f5['hasChild'](_0x5f12cf)&&!_0x4c39a6){const _0x5c21a5=_0x31f352['serverCache']['getNode']()['getImmediateChild'](_0x5f12cf),_0x4c48eb=ur(_0xbe2d4f,_0x5c21a5,_0x59c6b2);_0x45444f=En(_0xbe2d4f,_0x45444f,new C(_0x5f12cf),_0x4c48eb,_0x3e9622,_0x55bb0f,_0xe24558,_0x281eb0);}}),_0x45444f;}function Nu(_0x51084c,_0x22b76f,_0x4b0eee,_0x22d7c4,_0xbece5e,_0x3abffd,_0x55f135){if(vn(_0xbece5e,_0x4b0eee)!=null)return _0x22b76f;const _0x34fa09=_0x22b76f['serverCache']['isFiltered'](),_0x49549d=_0x22b76f['serverCache'];if(_0x22d7c4['value']!=null){if(v(_0x4b0eee)&&_0x49549d['isFullyInitialized']()||_0x49549d['isCompleteForPath'](_0x4b0eee))return En(_0x51084c,_0x22b76f,_0x4b0eee,_0x49549d['getNode']()['getChild'](_0x4b0eee),_0xbece5e,_0x3abffd,_0x34fa09,_0x55f135);if(v(_0x4b0eee)){let _0x41eab3=new S(null);return _0x49549d['getNode']()['forEachChild'](ye,(_0x639a62,_0x1abb97)=>{_0x41eab3=_0x41eab3['set'](new C(_0x639a62),_0x1abb97);}),bi(_0x51084c,_0x22b76f,_0x4b0eee,_0x41eab3,_0xbece5e,_0x3abffd,_0x34fa09,_0x55f135);}else return _0x22b76f;}else{let _0x2d1174=new S(null);return _0x22d7c4['foreach']((_0x1d2a3c,_0x344c29)=>{const _0xaeeb50=k(_0x4b0eee,_0x1d2a3c);_0x49549d['isCompleteForPath'](_0xaeeb50)&&(_0x2d1174=_0x2d1174['set'](_0x1d2a3c,_0x49549d['getNode']()['getChild'](_0xaeeb50)));}),bi(_0x51084c,_0x22b76f,_0x4b0eee,_0x2d1174,_0xbece5e,_0x3abffd,_0x34fa09,_0x55f135);}}function Pu(_0x5877bc,_0x478b4e,_0x470228,_0x4e4305,_0x81de91){const _0x5b7998=_0x478b4e['serverCache'],_0x57aa2b=Uo(_0x478b4e,_0x5b7998['getNode'](),_0x5b7998['isFullyInitialized']()||v(_0x470228),_0x5b7998['isFiltered']());return qo(_0x5877bc,_0x57aa2b,_0x470228,_0x4e4305,Go,_0x81de91);}function Ou(_0x3a8211,_0x32f043,_0x3b8ca2,_0x1630dd,_0x248fe9,_0x2b3067){let _0x5a1b3a;if(vn(_0x1630dd,_0x3b8ca2)!=null)return _0x32f043;{const _0x5db9d9=new ss(_0x1630dd,_0x32f043,_0x248fe9),_0x2499d6=_0x32f043['eventCache']['getNode']();let _0x1534d1;if(v(_0x3b8ca2)||y(_0x3b8ca2)==='.priority'){let _0x30256c;if(_0x32f043['serverCache']['isFullyInitialized']())_0x30256c=yn(_0x1630dd,We(_0x32f043));else{const _0xb9b374=_0x32f043['serverCache']['getNode']();f(_0xb9b374 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x30256c=ns(_0x1630dd,_0xb9b374);}_0x30256c=_0x30256c,_0x1534d1=_0x3a8211['filter']['updateFullNode'](_0x2499d6,_0x30256c,_0x2b3067);}else{const _0x4e3fba=y(_0x3b8ca2);let _0x45127e=is(_0x1630dd,_0x4e3fba,_0x32f043['serverCache']);_0x45127e==null&&_0x32f043['serverCache']['isCompleteForChild'](_0x4e3fba)&&(_0x45127e=_0x2499d6['getImmediateChild'](_0x4e3fba)),_0x45127e!=null?_0x1534d1=_0x3a8211['filter']['updateChild'](_0x2499d6,_0x4e3fba,_0x45127e,b(_0x3b8ca2),_0x5db9d9,_0x2b3067):_0x32f043['eventCache']['getNode']()['hasChild'](_0x4e3fba)?_0x1534d1=_0x3a8211['filter']['updateChild'](_0x2499d6,_0x4e3fba,g['EMPTY_NODE'],b(_0x3b8ca2),_0x5db9d9,_0x2b3067):_0x1534d1=_0x2499d6,_0x1534d1['isEmpty']()&&_0x32f043['serverCache']['isFullyInitialized']()&&(_0x5a1b3a=yn(_0x1630dd,We(_0x32f043)),_0x5a1b3a['isLeafNode']()&&(_0x1534d1=_0x3a8211['filter']['updateFullNode'](_0x1534d1,_0x5a1b3a,_0x2b3067)));}return _0x5a1b3a=_0x32f043['serverCache']['isFullyInitialized']()||vn(_0x1630dd,w())!=null,Tt(_0x32f043,_0x1534d1,_0x5a1b3a,_0x3a8211['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x48c23e,_0x5d3bfa){this['query_']=_0x48c23e,this['eventRegistrations_']=[];const _0x42dbc1=this['query_']['_queryParams'],_0x31270e=new Ji(_0x42dbc1['getIndex']()),_0x1cfd7c=Kh(_0x42dbc1);this['processor_']=Su(_0x1cfd7c);const _0x477440=_0x5d3bfa['serverCache'],_0x490d0c=_0x5d3bfa['eventCache'],_0xee6512=_0x31270e['updateFullNode'](g['EMPTY_NODE'],_0x477440['getNode'](),null),_0x35b9fa=_0x1cfd7c['updateFullNode'](g['EMPTY_NODE'],_0x490d0c['getNode'](),null),_0x4fcc61=new Ce(_0xee6512,_0x477440['isFullyInitialized'](),_0x31270e['filtersNodes']()),_0x344b08=new Ce(_0x35b9fa,_0x490d0c['isFullyInitialized'](),_0x1cfd7c['filtersNodes']());this['viewCache_']=Mn(_0x344b08,_0x4fcc61),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x68c318){return _0x68c318['viewCache_']['serverCache']['getNode']();}function Lu(_0x1d57a1){return mn(_0x1d57a1['viewCache_']);}function xu(_0x18ed18,_0x30eedc){const _0x44011e=We(_0x18ed18['viewCache_']);return _0x44011e&&(_0x18ed18['query']['_queryParams']['loadsAllData']()||!v(_0x30eedc)&&!_0x44011e['getImmediateChild'](y(_0x30eedc))['isEmpty']())?_0x44011e['getChild'](_0x30eedc):null;}function dr(_0x45b06d){return _0x45b06d['eventRegistrations_']['length']===0x0;}function Fu(_0x5c6a8e,_0x25cc44){_0x5c6a8e['eventRegistrations_']['push'](_0x25cc44);}function fr(_0x4faff0,_0x5a37d0,_0x40d0e0){const _0x1093c3=[];if(_0x40d0e0){f(_0x5a37d0==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x177e2a=_0x4faff0['query']['_path'];_0x4faff0['eventRegistrations_']['forEach'](_0x6ab2f2=>{const _0x17902c=_0x6ab2f2['createCancelEvent'](_0x40d0e0,_0x177e2a);_0x17902c&&_0x1093c3['push'](_0x17902c);});}if(_0x5a37d0){let _0x283486=[];for(let _0x504ec7=0x0;_0x504ec7<_0x4faff0['eventRegistrations_']['length'];++_0x504ec7){const _0x23cfa7=_0x4faff0['eventRegistrations_'][_0x504ec7];if(!_0x23cfa7['matches'](_0x5a37d0))_0x283486['push'](_0x23cfa7);else{if(_0x5a37d0['hasAnyCallback']()){_0x283486=_0x283486['concat'](_0x4faff0['eventRegistrations_']['slice'](_0x504ec7+0x1));break;}}}_0x4faff0['eventRegistrations_']=_0x283486;}else _0x4faff0['eventRegistrations_']=[];return _0x1093c3;}function pr(_0x48d3dd,_0x450fa1,_0x581f76,_0x5f28f0){_0x450fa1['type']===j['MERGE']&&_0x450fa1['source']['queryId']!==null&&(f(We(_0x48d3dd['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x48d3dd['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x24c646=_0x48d3dd['viewCache_'],_0x1230fd=Ru(_0x48d3dd['processor_'],_0x24c646,_0x450fa1,_0x581f76,_0x5f28f0);return bu(_0x48d3dd['processor_'],_0x1230fd['viewCache']),f(_0x1230fd['viewCache']['serverCache']['isFullyInitialized']()||!_0x24c646['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x48d3dd['viewCache_']=_0x1230fd['viewCache'],zo(_0x48d3dd,_0x1230fd['changes'],_0x1230fd['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x2ca081,_0x45f4a1){const _0x18ea59=_0x2ca081['viewCache_']['eventCache'],_0x2f2cc9=[];return _0x18ea59['getNode']()['isLeafNode']()||_0x18ea59['getNode']()['forEachChild'](R,(_0x50d6cb,_0xb255b)=>{_0x2f2cc9['push'](et(_0x50d6cb,_0xb255b));}),_0x18ea59['isFullyInitialized']()&&_0x2f2cc9['push'](Lo(_0x18ea59['getNode']())),zo(_0x2ca081,_0x2f2cc9,_0x18ea59['getNode'](),_0x45f4a1);}function zo(_0x271a75,_0x279787,_0x40f4d6,_0x5b9161){const _0x22f7c7=_0x5b9161?[_0x5b9161]:_0x271a75['eventRegistrations_'];return ru(_0x271a75['eventGenerator_'],_0x279787,_0x40f4d6,_0x22f7c7);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x2a3a90){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x2a3a90;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x14f9a0){return _0x14f9a0['views']['size']===0x0;}function rs(_0x228f2f,_0x160c04,_0x3dcd5c,_0x4b427b){const _0xc85b37=_0x160c04['source']['queryId'];if(_0xc85b37!==null){const _0x288613=_0x228f2f['views']['get'](_0xc85b37);return f(_0x288613!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x288613,_0x160c04,_0x3dcd5c,_0x4b427b);}else{let _0x465320=[];for(const _0x221203 of _0x228f2f['views']['values']())_0x465320=_0x465320['concat'](pr(_0x221203,_0x160c04,_0x3dcd5c,_0x4b427b));return _0x465320;}}function Ko(_0x32855a,_0x3859d4,_0x11e224,_0x997f8e,_0x3009f5){const _0x38b27e=_0x3859d4['_queryIdentifier'],_0x2cf3c4=_0x32855a['views']['get'](_0x38b27e);if(!_0x2cf3c4){let _0x3d5a4f=yn(_0x11e224,_0x3009f5?_0x997f8e:null),_0x111590=!0x1;_0x3d5a4f?_0x111590=!0x0:_0x997f8e instanceof g?(_0x3d5a4f=ns(_0x11e224,_0x997f8e),_0x111590=!0x1):(_0x3d5a4f=g['EMPTY_NODE'],_0x111590=!0x1);const _0x147ec6=Mn(new Ce(_0x3d5a4f,_0x111590,!0x1),new Ce(_0x997f8e,_0x3009f5,!0x1));return new Du(_0x3859d4,_0x147ec6);}return _0x2cf3c4;}function Hu(_0xf16c62,_0x4fc741,_0x3c2380,_0x44379e,_0x31b1dc,_0x2cd1d8){const _0x21fe05=Ko(_0xf16c62,_0x4fc741,_0x44379e,_0x31b1dc,_0x2cd1d8);return _0xf16c62['views']['has'](_0x4fc741['_queryIdentifier'])||_0xf16c62['views']['set'](_0x4fc741['_queryIdentifier'],_0x21fe05),Fu(_0x21fe05,_0x3c2380),Uu(_0x21fe05,_0x3c2380);}function $u(_0x4653c7,_0x29895a,_0x2f2d26,_0x1242f7){const _0x57e431=_0x29895a['_queryIdentifier'],_0x5bb3fe=[];let _0x4c0324=[];const _0x2f0300=Te(_0x4653c7);if(_0x57e431==='default'){for(const [_0xc1792a,_0x12fb72]of _0x4653c7['views']['entries']())_0x4c0324=_0x4c0324['concat'](fr(_0x12fb72,_0x2f2d26,_0x1242f7)),dr(_0x12fb72)&&(_0x4653c7['views']['delete'](_0xc1792a),_0x12fb72['query']['_queryParams']['loadsAllData']()||_0x5bb3fe['push'](_0x12fb72['query']));}else{const _0x58394d=_0x4653c7['views']['get'](_0x57e431);_0x58394d&&(_0x4c0324=_0x4c0324['concat'](fr(_0x58394d,_0x2f2d26,_0x1242f7)),dr(_0x58394d)&&(_0x4653c7['views']['delete'](_0x57e431),_0x58394d['query']['_queryParams']['loadsAllData']()||_0x5bb3fe['push'](_0x58394d['query'])));}return _0x2f0300&&!Te(_0x4653c7)&&_0x5bb3fe['push'](new(Bu())(_0x29895a['_repo'],_0x29895a['_path'])),{'removed':_0x5bb3fe,'events':_0x4c0324};}function Yo(_0x21bb98){const _0x5380fb=[];for(const _0x3bb8be of _0x21bb98['views']['values']())_0x3bb8be['query']['_queryParams']['loadsAllData']()||_0x5380fb['push'](_0x3bb8be);return _0x5380fb;}function Ee(_0x538f0a,_0x358197){let _0x149796=null;for(const _0xc1f9f8 of _0x538f0a['views']['values']())_0x149796=_0x149796||xu(_0xc1f9f8,_0x358197);return _0x149796;}function Qo(_0x2033cf,_0xd49929){if(_0xd49929['_queryParams']['loadsAllData']())return xn(_0x2033cf);{const _0x10c8d0=_0xd49929['_queryIdentifier'];return _0x2033cf['views']['get'](_0x10c8d0);}}function Jo(_0x312a3a,_0x393b7c){return Qo(_0x312a3a,_0x393b7c)!=null;}function Te(_0x547373){return xn(_0x547373)!=null;}function xn(_0x4b50a7){for(const _0x551cfc of _0x4b50a7['views']['values']())if(_0x551cfc['query']['_queryParams']['loadsAllData']())return _0x551cfc;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x17b8b7){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x17b8b7;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x7798b7){this['listenProvider_']=_0x7798b7,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x573811,_0x4a3236,_0x15cdd7,_0x3db0d6,_0x1081ef){return lu(_0x573811['pendingWriteTree_'],_0x4a3236,_0x15cdd7,_0x3db0d6,_0x1081ef),_0x1081ef?ut(_0x573811,new Ue(Zi(),_0x4a3236,_0x15cdd7)):[];}function ju(_0x1e2b8f,_0x21b74c,_0x3836cb,_0xc93de3){hu(_0x1e2b8f['pendingWriteTree_'],_0x21b74c,_0x3836cb,_0xc93de3);const _0x6059d3=S['fromObject'](_0x3836cb);return ut(_0x1e2b8f,new tt(Zi(),_0x21b74c,_0x6059d3));}function pe(_0x1b775e,_0x55606a,_0x474b3a=!0x1){const _0x4f7e1c=uu(_0x1b775e['pendingWriteTree_'],_0x55606a);if(du(_0x1b775e['pendingWriteTree_'],_0x55606a)){let _0x1f36ad=new S(null);return _0x4f7e1c['snap']!=null?_0x1f36ad=_0x1f36ad['set'](w(),!0x0):x(_0x4f7e1c['children'],_0x5ea276=>{_0x1f36ad=_0x1f36ad['set'](new C(_0x5ea276),!0x0);}),ut(_0x1b775e,new gn(_0x4f7e1c['path'],_0x1f36ad,_0x474b3a));}else return[];}function Gt(_0x46c7a2,_0x55c6e6,_0x185e84){return ut(_0x46c7a2,new Ue(es(),_0x55c6e6,_0x185e84));}function Ku(_0x343e8d,_0x37bdee,_0x232876){const _0x6b9024=S['fromObject'](_0x232876);return ut(_0x343e8d,new tt(es(),_0x37bdee,_0x6b9024));}function Yu(_0x7d0bf9,_0x2c55da){return ut(_0x7d0bf9,new Lt(es(),_0x2c55da));}function Qu(_0x46f351,_0x84112e,_0x18b5b6){const _0x190026=as(_0x46f351,_0x18b5b6);if(_0x190026){const _0x1e15d4=cs(_0x190026),_0x2090f6=_0x1e15d4['path'],_0x2b6985=_0x1e15d4['queryId'],_0x23865e=F(_0x2090f6,_0x84112e),_0x4374d8=new Lt(ts(_0x2b6985),_0x23865e);return ls(_0x46f351,_0x2090f6,_0x4374d8);}else return[];}function Cn(_0xa7947b,_0x2e95fc,_0x278881,_0x135d54,_0x162d34=!0x1){const _0x147f31=_0x2e95fc['_path'],_0x36b0a3=_0xa7947b['syncPointTree_']['get'](_0x147f31);let _0x53540b=[];if(_0x36b0a3&&(_0x2e95fc['_queryIdentifier']==='default'||Jo(_0x36b0a3,_0x2e95fc))){const _0x3178de=$u(_0x36b0a3,_0x2e95fc,_0x278881,_0x135d54);Vu(_0x36b0a3)&&(_0xa7947b['syncPointTree_']=_0xa7947b['syncPointTree_']['remove'](_0x147f31));const _0x23b1cf=_0x3178de['removed'];if(_0x53540b=_0x3178de['events'],!_0x162d34){const _0xfb6f4d=_0x23b1cf['findIndex'](_0x1e72bd=>_0x1e72bd['_queryParams']['loadsAllData']())!==-0x1,_0x42e9cb=_0xa7947b['syncPointTree_']['findOnPath'](_0x147f31,(_0x2447d6,_0x3ed3e1)=>Te(_0x3ed3e1));if(_0xfb6f4d&&!_0x42e9cb){const _0x169aed=_0xa7947b['syncPointTree_']['subtree'](_0x147f31);if(!_0x169aed['isEmpty']()){const _0x908add=Zu(_0x169aed);for(let _0x2a0a92=0x0;_0x2a0a92<_0x908add['length'];++_0x2a0a92){const _0x45a6be=_0x908add[_0x2a0a92],_0x20eb7f=_0x45a6be['query'],_0xa4bce2=ta(_0xa7947b,_0x45a6be);_0xa7947b['listenProvider_']['startListening'](bt(_0x20eb7f),xt(_0xa7947b,_0x20eb7f),_0xa4bce2['hashFn'],_0xa4bce2['onComplete']);}}}!_0x42e9cb&&_0x23b1cf['length']>0x0&&!_0x135d54&&(_0xfb6f4d?_0xa7947b['listenProvider_']['stopListening'](bt(_0x2e95fc),null):_0x23b1cf['forEach'](_0x1dac14=>{const _0x2af6b=_0xa7947b['queryToTagMap']['get'](Un(_0x1dac14));_0xa7947b['listenProvider_']['stopListening'](bt(_0x1dac14),_0x2af6b);}));}ed(_0xa7947b,_0x23b1cf);}return _0x53540b;}function Xo(_0x2c1f3c,_0x15f7cc,_0x530438,_0x2e62db){const _0x56dca7=as(_0x2c1f3c,_0x2e62db);if(_0x56dca7!=null){const _0x27e487=cs(_0x56dca7),_0x242688=_0x27e487['path'],_0x4af6e4=_0x27e487['queryId'],_0x203960=F(_0x242688,_0x15f7cc),_0x27135c=new Ue(ts(_0x4af6e4),_0x203960,_0x530438);return ls(_0x2c1f3c,_0x242688,_0x27135c);}else return[];}function Ju(_0x382116,_0x17215b,_0x5ae963,_0x5d2375){const _0x929edd=as(_0x382116,_0x5d2375);if(_0x929edd){const _0x41e995=cs(_0x929edd),_0x515851=_0x41e995['path'],_0x499629=_0x41e995['queryId'],_0x4e5eeb=F(_0x515851,_0x17215b),_0xe2b28f=S['fromObject'](_0x5ae963),_0x371d91=new tt(ts(_0x499629),_0x4e5eeb,_0xe2b28f);return ls(_0x382116,_0x515851,_0x371d91);}else return[];}function Ri(_0x31e77d,_0x13f673,_0x26e66c,_0x2daa1d=!0x1){const _0x40d106=_0x13f673['_path'];let _0x5c56a8=null,_0x45793c=!0x1;_0x31e77d['syncPointTree_']['foreachOnPath'](_0x40d106,(_0x4193f7,_0xfcae2)=>{const _0x317914=F(_0x4193f7,_0x40d106);_0x5c56a8=_0x5c56a8||Ee(_0xfcae2,_0x317914),_0x45793c=_0x45793c||Te(_0xfcae2);});let _0x2aa45c=_0x31e77d['syncPointTree_']['get'](_0x40d106);_0x2aa45c?(_0x45793c=_0x45793c||Te(_0x2aa45c),_0x5c56a8=_0x5c56a8||Ee(_0x2aa45c,w())):(_0x2aa45c=new jo(),_0x31e77d['syncPointTree_']=_0x31e77d['syncPointTree_']['set'](_0x40d106,_0x2aa45c));let _0x345319;_0x5c56a8!=null?_0x345319=!0x0:(_0x345319=!0x1,_0x5c56a8=g['EMPTY_NODE'],_0x31e77d['syncPointTree_']['subtree'](_0x40d106)['foreachChild']((_0x162b0c,_0x1b2b8c)=>{const _0x4dac5f=Ee(_0x1b2b8c,w());_0x4dac5f&&(_0x5c56a8=_0x5c56a8['updateImmediateChild'](_0x162b0c,_0x4dac5f));}));const _0x18d662=Jo(_0x2aa45c,_0x13f673);if(!_0x18d662&&!_0x13f673['_queryParams']['loadsAllData']()){const _0x200841=Un(_0x13f673);f(!_0x31e77d['queryToTagMap']['has'](_0x200841),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x46036d=td();_0x31e77d['queryToTagMap']['set'](_0x200841,_0x46036d),_0x31e77d['tagToQueryMap']['set'](_0x46036d,_0x200841);}const _0x8c4d30=Ln(_0x31e77d['pendingWriteTree_'],_0x40d106);let _0xca00c6=Hu(_0x2aa45c,_0x13f673,_0x26e66c,_0x8c4d30,_0x5c56a8,_0x345319);if(!_0x18d662&&!_0x45793c&&!_0x2daa1d){const _0x493b11=Qo(_0x2aa45c,_0x13f673);_0xca00c6=_0xca00c6['concat'](nd(_0x31e77d,_0x13f673,_0x493b11));}return _0xca00c6;}function Fn(_0x406209,_0x1ed717,_0x2f27be){const _0x1e273d=_0x406209['pendingWriteTree_'],_0x3375cf=_0x406209['syncPointTree_']['findOnPath'](_0x1ed717,(_0x17a4e6,_0x20d8a2)=>{const _0x166c72=F(_0x17a4e6,_0x1ed717),_0x3159e6=Ee(_0x20d8a2,_0x166c72);if(_0x3159e6)return _0x3159e6;});return Vo(_0x1e273d,_0x1ed717,_0x3375cf,_0x2f27be,!0x0);}function Xu(_0x2fe0a9,_0xb7da34){const _0x444988=_0xb7da34['_path'];let _0x4e5c91=null;_0x2fe0a9['syncPointTree_']['foreachOnPath'](_0x444988,(_0x33b1ff,_0x93a1ab)=>{const _0x1e8602=F(_0x33b1ff,_0x444988);_0x4e5c91=_0x4e5c91||Ee(_0x93a1ab,_0x1e8602);});let _0x16259c=_0x2fe0a9['syncPointTree_']['get'](_0x444988);_0x16259c?_0x4e5c91=_0x4e5c91||Ee(_0x16259c,w()):(_0x16259c=new jo(),_0x2fe0a9['syncPointTree_']=_0x2fe0a9['syncPointTree_']['set'](_0x444988,_0x16259c));const _0x2d46fc=_0x4e5c91!=null,_0x536e9e=_0x2d46fc?new Ce(_0x4e5c91,!0x0,!0x1):null,_0x2a0d1d=Ln(_0x2fe0a9['pendingWriteTree_'],_0xb7da34['_path']),_0x3e8542=Ko(_0x16259c,_0xb7da34,_0x2a0d1d,_0x2d46fc?_0x536e9e['getNode']():g['EMPTY_NODE'],_0x2d46fc);return Lu(_0x3e8542);}function ut(_0x1f7132,_0xfa013e){return Zo(_0xfa013e,_0x1f7132['syncPointTree_'],null,Ln(_0x1f7132['pendingWriteTree_'],w()));}function Zo(_0x46c35f,_0x16a199,_0xe0e7c0,_0x1bddec){if(v(_0x46c35f['path']))return ea(_0x46c35f,_0x16a199,_0xe0e7c0,_0x1bddec);{const _0x4b756f=_0x16a199['get'](w());_0xe0e7c0==null&&_0x4b756f!=null&&(_0xe0e7c0=Ee(_0x4b756f,w()));let _0x403a66=[];const _0x50b356=y(_0x46c35f['path']),_0x2e1bad=_0x46c35f['operationForChild'](_0x50b356),_0x47fd20=_0x16a199['children']['get'](_0x50b356);if(_0x47fd20&&_0x2e1bad){const _0x286c34=_0xe0e7c0?_0xe0e7c0['getImmediateChild'](_0x50b356):null,_0x44fac3=Ho(_0x1bddec,_0x50b356);_0x403a66=_0x403a66['concat'](Zo(_0x2e1bad,_0x47fd20,_0x286c34,_0x44fac3));}return _0x4b756f&&(_0x403a66=_0x403a66['concat'](rs(_0x4b756f,_0x46c35f,_0x1bddec,_0xe0e7c0))),_0x403a66;}}function ea(_0x306026,_0x1c42ed,_0x533bae,_0x10d188){const _0x56e930=_0x1c42ed['get'](w());_0x533bae==null&&_0x56e930!=null&&(_0x533bae=Ee(_0x56e930,w()));let _0x141d64=[];return _0x1c42ed['children']['inorderTraversal']((_0x1a7366,_0x3ba82e)=>{const _0x4aaaff=_0x533bae?_0x533bae['getImmediateChild'](_0x1a7366):null,_0x4bd2e5=Ho(_0x10d188,_0x1a7366),_0x3256cd=_0x306026['operationForChild'](_0x1a7366);_0x3256cd&&(_0x141d64=_0x141d64['concat'](ea(_0x3256cd,_0x3ba82e,_0x4aaaff,_0x4bd2e5)));}),_0x56e930&&(_0x141d64=_0x141d64['concat'](rs(_0x56e930,_0x306026,_0x10d188,_0x533bae))),_0x141d64;}function ta(_0x241863,_0x4ef437){const _0x466b62=_0x4ef437['query'],_0x1c38bc=xt(_0x241863,_0x466b62);return{'hashFn':()=>(Mu(_0x4ef437)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x7cdec6=>{if(_0x7cdec6==='ok')return _0x1c38bc?Qu(_0x241863,_0x466b62['_path'],_0x1c38bc):Yu(_0x241863,_0x466b62['_path']);{const _0x779d41=Kl(_0x7cdec6,_0x466b62);return Cn(_0x241863,_0x466b62,null,_0x779d41);}}};}function xt(_0x4c06f3,_0x5bc243){const _0xf9422d=Un(_0x5bc243);return _0x4c06f3['queryToTagMap']['get'](_0xf9422d);}function Un(_0x21aa97){return _0x21aa97['_path']['toString']()+'$'+_0x21aa97['_queryIdentifier'];}function as(_0x528f84,_0x38c17e){return _0x528f84['tagToQueryMap']['get'](_0x38c17e);}function cs(_0x40dd5d){const _0x348856=_0x40dd5d['indexOf']('$');return f(_0x348856!==-0x1&&_0x348856<_0x40dd5d['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x40dd5d['substr'](_0x348856+0x1),'path':new C(_0x40dd5d['substr'](0x0,_0x348856))};}function ls(_0x4d5f2d,_0xa729a1,_0x2b6876){const _0x516e98=_0x4d5f2d['syncPointTree_']['get'](_0xa729a1);f(_0x516e98,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x4cf34f=Ln(_0x4d5f2d['pendingWriteTree_'],_0xa729a1);return rs(_0x516e98,_0x2b6876,_0x4cf34f,null);}function Zu(_0x383aaa){return _0x383aaa['fold']((_0x4747e6,_0x4c9231,_0xfb3346)=>{if(_0x4c9231&&Te(_0x4c9231))return[xn(_0x4c9231)];{let _0x2db4d3=[];return _0x4c9231&&(_0x2db4d3=Yo(_0x4c9231)),x(_0xfb3346,(_0x5e79a3,_0x1bf582)=>{_0x2db4d3=_0x2db4d3['concat'](_0x1bf582);}),_0x2db4d3;}});}function bt(_0x17322a){return _0x17322a['_queryParams']['loadsAllData']()&&!_0x17322a['_queryParams']['isDefault']()?new(qu())(_0x17322a['_repo'],_0x17322a['_path']):_0x17322a;}function ed(_0x4fcfd7,_0x1ef52c){for(let _0x48aaa1=0x0;_0x48aaa1<_0x1ef52c['length'];++_0x48aaa1){const _0xf36e1a=_0x1ef52c[_0x48aaa1];if(!_0xf36e1a['_queryParams']['loadsAllData']()){const _0x2f9c6f=Un(_0xf36e1a),_0x2efa20=_0x4fcfd7['queryToTagMap']['get'](_0x2f9c6f);_0x4fcfd7['queryToTagMap']['delete'](_0x2f9c6f),_0x4fcfd7['tagToQueryMap']['delete'](_0x2efa20);}}}function td(){return zu++;}function nd(_0x397ea7,_0x595d99,_0x35a7e6){const _0x542272=_0x595d99['_path'],_0x515ffb=xt(_0x397ea7,_0x595d99),_0x58db10=ta(_0x397ea7,_0x35a7e6),_0x33692f=_0x397ea7['listenProvider_']['startListening'](bt(_0x595d99),_0x515ffb,_0x58db10['hashFn'],_0x58db10['onComplete']),_0x1ea3c9=_0x397ea7['syncPointTree_']['subtree'](_0x542272);if(_0x515ffb)f(!Te(_0x1ea3c9['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x3c89e0=_0x1ea3c9['fold']((_0x384ec5,_0x13b80c,_0x36a813)=>{if(!v(_0x384ec5)&&_0x13b80c&&Te(_0x13b80c))return[xn(_0x13b80c)['query']];{let _0xa9b295=[];return _0x13b80c&&(_0xa9b295=_0xa9b295['concat'](Yo(_0x13b80c)['map'](_0x134e3a=>_0x134e3a['query']))),x(_0x36a813,(_0x285d85,_0x13f355)=>{_0xa9b295=_0xa9b295['concat'](_0x13f355);}),_0xa9b295;}});for(let _0x53fa41=0x0;_0x53fa41<_0x3c89e0['length'];++_0x53fa41){const _0xd4a1d8=_0x3c89e0[_0x53fa41];_0x397ea7['listenProvider_']['stopListening'](bt(_0xd4a1d8),xt(_0x397ea7,_0xd4a1d8));}}return _0x33692f;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x221156){this['node_']=_0x221156;}['getImmediateChild'](_0x5a46c8){const _0x39487a=this['node_']['getImmediateChild'](_0x5a46c8);return new hs(_0x39487a);}['node'](){return this['node_'];}}class us{constructor(_0x46ffaf,_0x544293){this['syncTree_']=_0x46ffaf,this['path_']=_0x544293;}['getImmediateChild'](_0x33f052){const _0x35dac1=k(this['path_'],_0x33f052);return new us(this['syncTree_'],_0x35dac1);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x16868a){return _0x16868a=_0x16868a||{},_0x16868a['timestamp']=_0x16868a['timestamp']||new Date()['getTime'](),_0x16868a;},gr=function(_0x1091b,_0x2e6a9b,_0x239648){if(!_0x1091b||typeof _0x1091b!='object')return _0x1091b;if(f('.sv'in _0x1091b,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x1091b['.sv']=='string')return sd(_0x1091b['.sv'],_0x2e6a9b,_0x239648);if(typeof _0x1091b['.sv']=='object')return rd(_0x1091b['.sv'],_0x2e6a9b);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1091b,null,0x2));},sd=function(_0x2d80f0,_0x3fcd10,_0x8cc1f7){switch(_0x2d80f0){case'timestamp':return _0x8cc1f7['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x2d80f0);}},rd=function(_0x1a0498,_0x3e28de,_0x2e0391){_0x1a0498['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1a0498,null,0x2));const _0x33225a=_0x1a0498['increment'];typeof _0x33225a!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x33225a);const _0xb9928f=_0x3e28de['node']();if(f(_0xb9928f!==null&&typeof _0xb9928f<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0xb9928f['isLeafNode']())return _0x33225a;const _0x169e76=_0xb9928f['getValue']();return typeof _0x169e76!='number'?_0x33225a:_0x169e76+_0x33225a;},na=function(_0x36becd,_0x4146e3,_0x23d16e,_0x5cb12b){return fs(_0x4146e3,new us(_0x23d16e,_0x36becd),_0x5cb12b);},ds=function(_0x55bab9,_0x3cfccf,_0x102fff){return fs(_0x55bab9,new hs(_0x3cfccf),_0x102fff);};function fs(_0x3f1999,_0x367e69,_0x8cd43a){const _0x4cde8c=_0x3f1999['getPriority']()['val'](),_0xa0188e=gr(_0x4cde8c,_0x367e69['getImmediateChild']('.priority'),_0x8cd43a);let _0x5be2f8;if(_0x3f1999['isLeafNode']()){const _0x26553e=_0x3f1999,_0xa07e4d=gr(_0x26553e['getValue'](),_0x367e69,_0x8cd43a);return _0xa07e4d!==_0x26553e['getValue']()||_0xa0188e!==_0x26553e['getPriority']()['val']()?new D(_0xa07e4d,P(_0xa0188e)):_0x3f1999;}else{const _0x138cfa=_0x3f1999;return _0x5be2f8=_0x138cfa,_0xa0188e!==_0x138cfa['getPriority']()['val']()&&(_0x5be2f8=_0x5be2f8['updatePriority'](new D(_0xa0188e))),_0x138cfa['forEachChild'](R,(_0x1b9b38,_0x34fb94)=>{const _0x49db58=fs(_0x34fb94,_0x367e69['getImmediateChild'](_0x1b9b38),_0x8cd43a);_0x49db58!==_0x34fb94&&(_0x5be2f8=_0x5be2f8['updateImmediateChild'](_0x1b9b38,_0x49db58));}),_0x5be2f8;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x19232c='',_0x52b804=null,_0x35f320={'children':{},'childCount':0x0}){this['name']=_0x19232c,this['parent']=_0x52b804,this['node']=_0x35f320;}}function Wn(_0x37031a,_0x141f35){let _0x4f9aaa=_0x141f35 instanceof C?_0x141f35:new C(_0x141f35),_0x36f402=_0x37031a,_0x430e15=y(_0x4f9aaa);for(;_0x430e15!==null;){const _0x2b8315=De(_0x36f402['node']['children'],_0x430e15)||{'children':{},'childCount':0x0};_0x36f402=new ps(_0x430e15,_0x36f402,_0x2b8315),_0x4f9aaa=b(_0x4f9aaa),_0x430e15=y(_0x4f9aaa);}return _0x36f402;}function Ge(_0x144b27){return _0x144b27['node']['value'];}function _s(_0x2f2042,_0x1e8526){_0x2f2042['node']['value']=_0x1e8526,Ai(_0x2f2042);}function ia(_0x38ec6a){return _0x38ec6a['node']['childCount']>0x0;}function od(_0x5bb85d){return Ge(_0x5bb85d)===void 0x0&&!ia(_0x5bb85d);}function Bn(_0x279ece,_0x589af7){x(_0x279ece['node']['children'],(_0xf23a93,_0x29599a)=>{_0x589af7(new ps(_0xf23a93,_0x279ece,_0x29599a));});}function sa(_0x282a78,_0x2e625d,_0x44d3c6,_0x3bd9f9){_0x44d3c6&&_0x2e625d(_0x282a78),Bn(_0x282a78,_0x5736f9=>{sa(_0x5736f9,_0x2e625d,!0x0);});}function ad(_0x44097b,_0x4f4c91,_0x373085){let _0x3a0e56=_0x44097b['parent'];for(;_0x3a0e56!==null;){if(_0x4f4c91(_0x3a0e56))return!0x0;_0x3a0e56=_0x3a0e56['parent'];}return!0x1;}function qt(_0x415aea){return new C(_0x415aea['parent']===null?_0x415aea['name']:qt(_0x415aea['parent'])+'/'+_0x415aea['name']);}function Ai(_0x2481cf){_0x2481cf['parent']!==null&&cd(_0x2481cf['parent'],_0x2481cf['name'],_0x2481cf);}function cd(_0x4fa80f,_0xc4098,_0x3a888a){const _0x468fcb=od(_0x3a888a),_0x49534b=J(_0x4fa80f['node']['children'],_0xc4098);_0x468fcb&&_0x49534b?(delete _0x4fa80f['node']['children'][_0xc4098],_0x4fa80f['node']['childCount']--,Ai(_0x4fa80f)):!_0x468fcb&&!_0x49534b&&(_0x4fa80f['node']['children'][_0xc4098]=_0x3a888a['node'],_0x4fa80f['node']['childCount']++,Ai(_0x4fa80f));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x50a057){return typeof _0x50a057=='string'&&_0x50a057['length']!==0x0&&!ld['test'](_0x50a057);},ra=function(_0x455cd4){return typeof _0x455cd4=='string'&&_0x455cd4['length']!==0x0&&!hd['test'](_0x455cd4);},ud=function(_0x1ec6cf){return _0x1ec6cf&&(_0x1ec6cf=_0x1ec6cf['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x1ec6cf);},Tn=function(_0x4c2205){return _0x4c2205===null||typeof _0x4c2205=='string'||typeof _0x4c2205=='number'&&!Vi(_0x4c2205)||_0x4c2205&&typeof _0x4c2205=='object'&&J(_0x4c2205,'.sv');},zt=function(_0x4342d5,_0x3fe9ff,_0xfe4b9c,_0x348499){_0x348499&&_0x3fe9ff===void 0x0||jt(Pn(_0x4342d5,'value'),_0x3fe9ff,_0xfe4b9c);},jt=function(_0x5665ec,_0xbc519d,_0x578be0){const _0x19f4eb=_0x578be0 instanceof C?new Ah(_0x578be0,_0x5665ec):_0x578be0;if(_0xbc519d===void 0x0)throw new Error(_0x5665ec+'contains\x20undefined\x20'+Pe(_0x19f4eb));if(typeof _0xbc519d=='function')throw new Error(_0x5665ec+'contains\x20a\x20function\x20'+Pe(_0x19f4eb)+'\x20with\x20contents\x20=\x20'+_0xbc519d['toString']());if(Vi(_0xbc519d))throw new Error(_0x5665ec+'contains\x20'+_0xbc519d['toString']()+'\x20'+Pe(_0x19f4eb));if(typeof _0xbc519d=='string'&&_0xbc519d['length']>ai/0x3&&On(_0xbc519d)>ai)throw new Error(_0x5665ec+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x19f4eb)+'\x20(\x27'+_0xbc519d['substring'](0x0,0x32)+'...\x27)');if(_0xbc519d&&typeof _0xbc519d=='object'){let _0x5cf94d=!0x1,_0x22511c=!0x1;if(x(_0xbc519d,(_0x54c001,_0xa595c1)=>{if(_0x54c001==='.value')_0x5cf94d=!0x0;else{if(_0x54c001!=='.priority'&&_0x54c001!=='.sv'&&(_0x22511c=!0x0,!gs(_0x54c001)))throw new Error(_0x5665ec+'\x20contains\x20an\x20invalid\x20key\x20('+_0x54c001+')\x20'+Pe(_0x19f4eb)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x19f4eb,_0x54c001),jt(_0x5665ec,_0xa595c1,_0x19f4eb),Nh(_0x19f4eb);}),_0x5cf94d&&_0x22511c)throw new Error(_0x5665ec+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x19f4eb)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x318d6d,_0x431655){let _0x497624,_0x43741f;for(_0x497624=0x0;_0x497624<_0x431655['length'];_0x497624++){_0x43741f=_0x431655[_0x497624];const _0x120383=Pt(_0x43741f);for(let _0x4ab825=0x0;_0x4ab825<_0x120383['length'];_0x4ab825++)if(!(_0x120383[_0x4ab825]==='.priority'&&_0x4ab825===_0x120383['length']-0x1)){if(!gs(_0x120383[_0x4ab825]))throw new Error(_0x318d6d+'contains\x20an\x20invalid\x20key\x20('+_0x120383[_0x4ab825]+')\x20in\x20path\x20'+_0x43741f['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x431655['sort'](Rh);let _0x206b88=null;for(_0x497624=0x0;_0x497624<_0x431655['length'];_0x497624++){if(_0x43741f=_0x431655[_0x497624],_0x206b88!==null&&G(_0x206b88,_0x43741f))throw new Error(_0x318d6d+'contains\x20a\x20path\x20'+_0x206b88['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x43741f['toString']());_0x206b88=_0x43741f;}},fd=function(_0x1814d4,_0x4bcdc8,_0x16e966,_0x4a8d23){const _0x1fe701=Pn(_0x1814d4,'values');if(!(_0x4bcdc8&&typeof _0x4bcdc8=='object')||Array['isArray'](_0x4bcdc8))throw new Error(_0x1fe701+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x49639d=[];x(_0x4bcdc8,(_0x4475cd,_0x4c9d60)=>{const _0x3611de=new C(_0x4475cd);if(jt(_0x1fe701,_0x4c9d60,k(_0x16e966,_0x3611de)),zi(_0x3611de)==='.priority'&&!Tn(_0x4c9d60))throw new Error(_0x1fe701+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x3611de['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x49639d['push'](_0x3611de);}),dd(_0x1fe701,_0x49639d);},ms=function(_0x14ca98,_0x5d204e,_0x7a751,_0x556a29){if(!ra(_0x7a751))throw new Error(Pn(_0x14ca98,_0x5d204e)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x7a751+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x3c7247,_0x4def94,_0x7a2515,_0x55b19c){_0x7a2515&&(_0x7a2515=_0x7a2515['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x3c7247,_0x4def94,_0x7a2515);},ys=function(_0x512dc6,_0x2f28c2){if(y(_0x2f28c2)==='.info')throw new Error(_0x512dc6+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x12b874,_0x32ffdd){const _0x2531b9=_0x32ffdd['path']['toString']();if(typeof _0x32ffdd['repoInfo']['host']!='string'||_0x32ffdd['repoInfo']['host']['length']===0x0||!gs(_0x32ffdd['repoInfo']['namespace'])&&_0x32ffdd['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x2531b9['length']!==0x0&&!ud(_0x2531b9))throw new Error(Pn(_0x12b874,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x1dd876,_0x39abf8){let _0x3c67ef=null;for(let _0x1ddafc=0x0;_0x1ddafc<_0x39abf8['length'];_0x1ddafc++){const _0x240764=_0x39abf8[_0x1ddafc],_0x5baf96=_0x240764['getPath']();_0x3c67ef!==null&&!ji(_0x5baf96,_0x3c67ef['path'])&&(_0x1dd876['eventLists_']['push'](_0x3c67ef),_0x3c67ef=null),_0x3c67ef===null&&(_0x3c67ef={'events':[],'path':_0x5baf96}),_0x3c67ef['events']['push'](_0x240764);}_0x3c67ef&&_0x1dd876['eventLists_']['push'](_0x3c67ef);}function oa(_0xb4b62c,_0xd75334,_0x43bf0b){Vn(_0xb4b62c,_0x43bf0b),aa(_0xb4b62c,_0x55d550=>ji(_0x55d550,_0xd75334));}function H(_0xb62065,_0xc30106,_0x3100fd){Vn(_0xb62065,_0x3100fd),aa(_0xb62065,_0x20c234=>G(_0x20c234,_0xc30106)||G(_0xc30106,_0x20c234));}function aa(_0x4b38ae,_0x481793){_0x4b38ae['recursionDepth_']++;let _0x2b4220=!0x0;for(let _0x2e882a=0x0;_0x2e882a<_0x4b38ae['eventLists_']['length'];_0x2e882a++){const _0xec64d=_0x4b38ae['eventLists_'][_0x2e882a];if(_0xec64d){const _0x1cdbb9=_0xec64d['path'];_0x481793(_0x1cdbb9)?(md(_0x4b38ae['eventLists_'][_0x2e882a]),_0x4b38ae['eventLists_'][_0x2e882a]=null):_0x2b4220=!0x1;}}_0x2b4220&&(_0x4b38ae['eventLists_']=[]),_0x4b38ae['recursionDepth_']--;}function md(_0x12757c){for(let _0x586a4f=0x0;_0x586a4f<_0x12757c['events']['length'];_0x586a4f++){const _0x27038e=_0x12757c['events'][_0x586a4f];if(_0x27038e!==null){_0x12757c['events'][_0x586a4f]=null;const _0x5deba0=_0x27038e['getEventRunner']();wt&&L('event:\x20'+_0x27038e['toString']()),ht(_0x5deba0);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x13941a,_0x16cbae,_0x42fc00,_0xed012c){this['repoInfo_']=_0x13941a,this['forceRestClient_']=_0x16cbae,this['authTokenProvider_']=_0x42fc00,this['appCheckProvider_']=_0xed012c,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x7d9960,_0x114eac,_0x4fdf21){if(_0x7d9960['stats_']=Gi(_0x7d9960['repoInfo_']),_0x7d9960['forceRestClient_']||Xl())_0x7d9960['server_']=new pn(_0x7d9960['repoInfo_'],(_0x38509d,_0x3d6167,_0x2d4cd4,_0x4fe1bc)=>{mr(_0x7d9960,_0x38509d,_0x3d6167,_0x2d4cd4,_0x4fe1bc);},_0x7d9960['authTokenProvider_'],_0x7d9960['appCheckProvider_']),setTimeout(()=>yr(_0x7d9960,!0x0),0x0);else{if(typeof _0x4fdf21<'u'&&_0x4fdf21!==null){if(typeof _0x4fdf21!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x4fdf21);}catch(_0x4502e2){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x4502e2);}}_0x7d9960['persistentConnection_']=new se(_0x7d9960['repoInfo_'],_0x114eac,(_0x328bdf,_0x374bdc,_0x2f97bb,_0x304687)=>{mr(_0x7d9960,_0x328bdf,_0x374bdc,_0x2f97bb,_0x304687);},_0x276218=>{yr(_0x7d9960,_0x276218);},_0x2e26bc=>{Id(_0x7d9960,_0x2e26bc);},_0x7d9960['authTokenProvider_'],_0x7d9960['appCheckProvider_'],_0x4fdf21),_0x7d9960['server_']=_0x7d9960['persistentConnection_'];}_0x7d9960['authTokenProvider_']['addTokenChangeListener'](_0x4de6da=>{_0x7d9960['server_']['refreshAuthToken'](_0x4de6da);}),_0x7d9960['appCheckProvider_']['addTokenChangeListener'](_0x4122ad=>{_0x7d9960['server_']['refreshAppCheckToken'](_0x4122ad['token']);}),_0x7d9960['statsReporter_']=ih(_0x7d9960['repoInfo_'],()=>new iu(_0x7d9960['stats_'],_0x7d9960['server_'])),_0x7d9960['infoData_']=new Xh(),_0x7d9960['infoSyncTree_']=new _r({'startListening':(_0x33cbdd,_0x4e6d4f,_0x14c5d7,_0x266599)=>{let _0x3b2c55=[];const _0x1cd1b0=_0x7d9960['infoData_']['getNode'](_0x33cbdd['_path']);return _0x1cd1b0['isEmpty']()||(_0x3b2c55=Gt(_0x7d9960['infoSyncTree_'],_0x33cbdd['_path'],_0x1cd1b0),setTimeout(()=>{_0x266599('ok');},0x0)),_0x3b2c55;},'stopListening':()=>{}}),vs(_0x7d9960,'connected',!0x1),_0x7d9960['serverSyncTree_']=new _r({'startListening':(_0x1b3d31,_0xa4eadb,_0x3433cc,_0x29aca2)=>(_0x7d9960['server_']['listen'](_0x1b3d31,_0x3433cc,_0xa4eadb,(_0x714047,_0x1cd9b3)=>{const _0x31cc52=_0x29aca2(_0x714047,_0x1cd9b3);H(_0x7d9960['eventQueue_'],_0x1b3d31['_path'],_0x31cc52);}),[]),'stopListening':(_0x128d73,_0x496df1)=>{_0x7d9960['server_']['unlisten'](_0x128d73,_0x496df1);}});}function la(_0x507fb8){const _0x50f26a=_0x507fb8['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x50f26a;}function Kt(_0xf09bdf){return id({'timestamp':la(_0xf09bdf)});}function mr(_0x1a24f9,_0x3250ce,_0x581ab1,_0x108175,_0x2953f8){_0x1a24f9['dataUpdateCount']++;const _0x4b6f52=new C(_0x3250ce);_0x581ab1=_0x1a24f9['interceptServerDataCallback_']?_0x1a24f9['interceptServerDataCallback_'](_0x3250ce,_0x581ab1):_0x581ab1;let _0x5855ff=[];if(_0x2953f8){if(_0x108175){const _0x1fa122=hn(_0x581ab1,_0x4570f5=>P(_0x4570f5));_0x5855ff=Ju(_0x1a24f9['serverSyncTree_'],_0x4b6f52,_0x1fa122,_0x2953f8);}else{const _0x561195=P(_0x581ab1);_0x5855ff=Xo(_0x1a24f9['serverSyncTree_'],_0x4b6f52,_0x561195,_0x2953f8);}}else{if(_0x108175){const _0x5dd1a5=hn(_0x581ab1,_0x2ac128=>P(_0x2ac128));_0x5855ff=Ku(_0x1a24f9['serverSyncTree_'],_0x4b6f52,_0x5dd1a5);}else{const _0x339082=P(_0x581ab1);_0x5855ff=Gt(_0x1a24f9['serverSyncTree_'],_0x4b6f52,_0x339082);}}let _0x20d27b=_0x4b6f52;_0x5855ff['length']>0x0&&(_0x20d27b=it(_0x1a24f9,_0x4b6f52)),H(_0x1a24f9['eventQueue_'],_0x20d27b,_0x5855ff);}function yr(_0x3822eb,_0x321f27){vs(_0x3822eb,'connected',_0x321f27),_0x321f27===!0x1&&Sd(_0x3822eb);}function Id(_0x22f94c,_0x343ac4){x(_0x343ac4,(_0x527285,_0x31629d)=>{vs(_0x22f94c,_0x527285,_0x31629d);});}function vs(_0x23f4d2,_0xe24cd7,_0x16a30a){const _0xe881a0=new C('/.info/'+_0xe24cd7),_0x5b0523=P(_0x16a30a);_0x23f4d2['infoData_']['updateSnapshot'](_0xe881a0,_0x5b0523);const _0x470c50=Gt(_0x23f4d2['infoSyncTree_'],_0xe881a0,_0x5b0523);H(_0x23f4d2['eventQueue_'],_0xe881a0,_0x470c50);}function Hn(_0x3d012a){return _0x3d012a['nextWriteId_']++;}function wd(_0x3f5cf4,_0x2a1d34,_0x547cd6){const _0x5e3b05=Xu(_0x3f5cf4['serverSyncTree_'],_0x2a1d34);return _0x5e3b05!=null?Promise['resolve'](_0x5e3b05):_0x3f5cf4['server_']['get'](_0x2a1d34)['then'](_0x3ea41a=>{const _0x18f42e=P(_0x3ea41a)['withIndex'](_0x2a1d34['_queryParams']['getIndex']());Ri(_0x3f5cf4['serverSyncTree_'],_0x2a1d34,_0x547cd6,!0x0);let _0x17022f;if(_0x2a1d34['_queryParams']['loadsAllData']())_0x17022f=Gt(_0x3f5cf4['serverSyncTree_'],_0x2a1d34['_path'],_0x18f42e);else{const _0x5dd8d0=xt(_0x3f5cf4['serverSyncTree_'],_0x2a1d34);_0x17022f=Xo(_0x3f5cf4['serverSyncTree_'],_0x2a1d34['_path'],_0x18f42e,_0x5dd8d0);}return H(_0x3f5cf4['eventQueue_'],_0x2a1d34['_path'],_0x17022f),Cn(_0x3f5cf4['serverSyncTree_'],_0x2a1d34,_0x547cd6,null,!0x0),_0x18f42e;},_0x11af04=>(dt(_0x3f5cf4,'get\x20for\x20query\x20'+O(_0x2a1d34)+'\x20failed:\x20'+_0x11af04),Promise['reject'](new Error(_0x11af04))));}function Cd(_0x1b5b04,_0x4bdf11,_0x253671,_0x5e9674,_0x598486){dt(_0x1b5b04,'set',{'path':_0x4bdf11['toString'](),'value':_0x253671,'priority':_0x5e9674});const _0x4d7d4d=Kt(_0x1b5b04),_0x5c7651=P(_0x253671,_0x5e9674),_0x50d966=Fn(_0x1b5b04['serverSyncTree_'],_0x4bdf11),_0x34af38=ds(_0x5c7651,_0x50d966,_0x4d7d4d),_0x790f96=Hn(_0x1b5b04),_0x2c6bd4=os(_0x1b5b04['serverSyncTree_'],_0x4bdf11,_0x34af38,_0x790f96,!0x0);Vn(_0x1b5b04['eventQueue_'],_0x2c6bd4),_0x1b5b04['server_']['put'](_0x4bdf11['toString'](),_0x5c7651['val'](!0x0),(_0x5db747,_0x1449ee)=>{const _0x56810a=_0x5db747==='ok';_0x56810a||U('set\x20at\x20'+_0x4bdf11+'\x20failed:\x20'+_0x5db747);const _0x44c9ad=pe(_0x1b5b04['serverSyncTree_'],_0x790f96,!_0x56810a);H(_0x1b5b04['eventQueue_'],_0x4bdf11,_0x44c9ad),ki(_0x1b5b04,_0x598486,_0x5db747,_0x1449ee);});const _0x15b350=Is(_0x1b5b04,_0x4bdf11);it(_0x1b5b04,_0x15b350),H(_0x1b5b04['eventQueue_'],_0x15b350,[]);}function Td(_0x3ab2cb,_0x37b402,_0x20f25f,_0x1ff105){dt(_0x3ab2cb,'update',{'path':_0x37b402['toString'](),'value':_0x20f25f});let _0x14e3e7=!0x0;const _0x2d399c=Kt(_0x3ab2cb),_0xb7331c={};if(x(_0x20f25f,(_0x110c8b,_0x3a8bd4)=>{_0x14e3e7=!0x1,_0xb7331c[_0x110c8b]=na(k(_0x37b402,_0x110c8b),P(_0x3a8bd4),_0x3ab2cb['serverSyncTree_'],_0x2d399c);}),_0x14e3e7)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x3ab2cb,_0x1ff105,'ok',void 0x0);else{const _0xcd8a74=Hn(_0x3ab2cb),_0x263d1e=ju(_0x3ab2cb['serverSyncTree_'],_0x37b402,_0xb7331c,_0xcd8a74);Vn(_0x3ab2cb['eventQueue_'],_0x263d1e),_0x3ab2cb['server_']['merge'](_0x37b402['toString'](),_0x20f25f,(_0x4f50f4,_0x1ccea2)=>{const _0x988362=_0x4f50f4==='ok';_0x988362||U('update\x20at\x20'+_0x37b402+'\x20failed:\x20'+_0x4f50f4);const _0x563371=pe(_0x3ab2cb['serverSyncTree_'],_0xcd8a74,!_0x988362),_0x57732e=_0x563371['length']>0x0?it(_0x3ab2cb,_0x37b402):_0x37b402;H(_0x3ab2cb['eventQueue_'],_0x57732e,_0x563371),ki(_0x3ab2cb,_0x1ff105,_0x4f50f4,_0x1ccea2);}),x(_0x20f25f,_0x50dba6=>{const _0x12b37e=Is(_0x3ab2cb,k(_0x37b402,_0x50dba6));it(_0x3ab2cb,_0x12b37e);}),H(_0x3ab2cb['eventQueue_'],_0x37b402,[]);}}function Sd(_0x4e2676){dt(_0x4e2676,'onDisconnectEvents');const _0x56fa03=Kt(_0x4e2676),_0xbd4872=_n();Ii(_0x4e2676['onDisconnect_'],w(),(_0x2135d6,_0x5eb946)=>{const _0x32f008=na(_0x2135d6,_0x5eb946,_0x4e2676['serverSyncTree_'],_0x56fa03);Fo(_0xbd4872,_0x2135d6,_0x32f008);});let _0x446a7a=[];Ii(_0xbd4872,w(),(_0x3238ad,_0x6103bc)=>{_0x446a7a=_0x446a7a['concat'](Gt(_0x4e2676['serverSyncTree_'],_0x3238ad,_0x6103bc));const _0x1b041f=Is(_0x4e2676,_0x3238ad);it(_0x4e2676,_0x1b041f);}),_0x4e2676['onDisconnect_']=_n(),H(_0x4e2676['eventQueue_'],w(),_0x446a7a);}function bd(_0x4f19ca,_0x3c50bc,_0x3365e7){let _0x30ea08;y(_0x3c50bc['_path'])==='.info'?_0x30ea08=Ri(_0x4f19ca['infoSyncTree_'],_0x3c50bc,_0x3365e7):_0x30ea08=Ri(_0x4f19ca['serverSyncTree_'],_0x3c50bc,_0x3365e7),oa(_0x4f19ca['eventQueue_'],_0x3c50bc['_path'],_0x30ea08);}function Rd(_0x3ef823,_0x2f7e5b,_0x471a17){let _0x457d17;y(_0x2f7e5b['_path'])==='.info'?_0x457d17=Cn(_0x3ef823['infoSyncTree_'],_0x2f7e5b,_0x471a17):_0x457d17=Cn(_0x3ef823['serverSyncTree_'],_0x2f7e5b,_0x471a17),oa(_0x3ef823['eventQueue_'],_0x2f7e5b['_path'],_0x457d17);}function ha(_0x29b6bc){_0x29b6bc['persistentConnection_']&&_0x29b6bc['persistentConnection_']['interrupt'](ca);}function Ad(_0x1e37ce){_0x1e37ce['persistentConnection_']&&_0x1e37ce['persistentConnection_']['resume'](ca);}function dt(_0x3f527f,..._0x44e485){let _0xeddd55='';_0x3f527f['persistentConnection_']&&(_0xeddd55=_0x3f527f['persistentConnection_']['id']+':'),L(_0xeddd55,..._0x44e485);}function ki(_0x5d9977,_0x3fa01f,_0x245b59,_0x57d976){_0x3fa01f&&ht(()=>{if(_0x245b59==='ok')_0x3fa01f(null);else{const _0x2968b3=(_0x245b59||'error')['toUpperCase']();let _0x105544=_0x2968b3;_0x57d976&&(_0x105544+=':\x20'+_0x57d976);const _0x27c674=new Error(_0x105544);_0x27c674['code']=_0x2968b3,_0x3fa01f(_0x27c674);}});}function kd(_0x2b1c91,_0x298539,_0x23631f,_0xcaccef,_0x1f4da7,_0x2037e3){dt(_0x2b1c91,'transaction\x20on\x20'+_0x298539);const _0x130c54={'path':_0x298539,'update':_0x23631f,'onComplete':_0xcaccef,'status':null,'order':so(),'applyLocally':_0x2037e3,'retryCount':0x0,'unwatcher':_0x1f4da7,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x30ca9c=Es(_0x2b1c91,_0x298539,void 0x0);_0x130c54['currentInputSnapshot']=_0x30ca9c;const _0x4bca79=_0x130c54['update'](_0x30ca9c['val']());if(_0x4bca79===void 0x0)_0x130c54['unwatcher'](),_0x130c54['currentOutputSnapshotRaw']=null,_0x130c54['currentOutputSnapshotResolved']=null,_0x130c54['onComplete']&&_0x130c54['onComplete'](null,!0x1,_0x130c54['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4bca79,_0x130c54['path']),_0x130c54['status']=0x0;const _0xa8958b=Wn(_0x2b1c91['transactionQueueTree_'],_0x298539),_0x5b6454=Ge(_0xa8958b)||[];_0x5b6454['push'](_0x130c54),_s(_0xa8958b,_0x5b6454);let _0x5c8622;typeof _0x4bca79=='object'&&_0x4bca79!==null&&J(_0x4bca79,'.priority')?(_0x5c8622=De(_0x4bca79,'.priority'),f(Tn(_0x5c8622),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x5c8622=(Fn(_0x2b1c91['serverSyncTree_'],_0x298539)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x456de8=Kt(_0x2b1c91),_0x5135e5=P(_0x4bca79,_0x5c8622),_0x3f2c3=ds(_0x5135e5,_0x30ca9c,_0x456de8);_0x130c54['currentOutputSnapshotRaw']=_0x5135e5,_0x130c54['currentOutputSnapshotResolved']=_0x3f2c3,_0x130c54['currentWriteId']=Hn(_0x2b1c91);const _0x1394da=os(_0x2b1c91['serverSyncTree_'],_0x298539,_0x3f2c3,_0x130c54['currentWriteId'],_0x130c54['applyLocally']);H(_0x2b1c91['eventQueue_'],_0x298539,_0x1394da),$n(_0x2b1c91,_0x2b1c91['transactionQueueTree_']);}}function Es(_0x4d0d72,_0x256b64,_0x263443){return Fn(_0x4d0d72['serverSyncTree_'],_0x256b64,_0x263443)||g['EMPTY_NODE'];}function $n(_0x56c7b7,_0x53a0be=_0x56c7b7['transactionQueueTree_']){if(_0x53a0be||Gn(_0x56c7b7,_0x53a0be),Ge(_0x53a0be)){const _0x4ab9e6=da(_0x56c7b7,_0x53a0be);f(_0x4ab9e6['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x4ab9e6['every'](_0x38927c=>_0x38927c['status']===0x0)&&Nd(_0x56c7b7,qt(_0x53a0be),_0x4ab9e6);}else ia(_0x53a0be)&&Bn(_0x53a0be,_0xe5dca1=>{$n(_0x56c7b7,_0xe5dca1);});}function Nd(_0x57a1d1,_0x117464,_0x402afa){const _0x5c6d75=_0x402afa['map'](_0xb95362=>_0xb95362['currentWriteId']),_0x29af85=Es(_0x57a1d1,_0x117464,_0x5c6d75);let _0xad9757=_0x29af85;const _0x4c6a7b=_0x29af85['hash']();for(let _0x526251=0x0;_0x526251<_0x402afa['length'];_0x526251++){const _0x44ff6c=_0x402afa[_0x526251];f(_0x44ff6c['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x44ff6c['status']=0x1,_0x44ff6c['retryCount']++;const _0x5ec1ed=F(_0x117464,_0x44ff6c['path']);_0xad9757=_0xad9757['updateChild'](_0x5ec1ed,_0x44ff6c['currentOutputSnapshotRaw']);}const _0x39ad7f=_0xad9757['val'](!0x0),_0x564876=_0x117464;_0x57a1d1['server_']['put'](_0x564876['toString'](),_0x39ad7f,_0x3043cf=>{dt(_0x57a1d1,'transaction\x20put\x20response',{'path':_0x564876['toString'](),'status':_0x3043cf});let _0x1a53af=[];if(_0x3043cf==='ok'){const _0xf4dc8e=[];for(let _0x12af23=0x0;_0x12af23<_0x402afa['length'];_0x12af23++)_0x402afa[_0x12af23]['status']=0x2,_0x1a53af=_0x1a53af['concat'](pe(_0x57a1d1['serverSyncTree_'],_0x402afa[_0x12af23]['currentWriteId'])),_0x402afa[_0x12af23]['onComplete']&&_0xf4dc8e['push'](()=>_0x402afa[_0x12af23]['onComplete'](null,!0x0,_0x402afa[_0x12af23]['currentOutputSnapshotResolved'])),_0x402afa[_0x12af23]['unwatcher']();Gn(_0x57a1d1,Wn(_0x57a1d1['transactionQueueTree_'],_0x117464)),$n(_0x57a1d1,_0x57a1d1['transactionQueueTree_']),H(_0x57a1d1['eventQueue_'],_0x117464,_0x1a53af);for(let _0x3b2320=0x0;_0x3b2320<_0xf4dc8e['length'];_0x3b2320++)ht(_0xf4dc8e[_0x3b2320]);}else{if(_0x3043cf==='datastale'){for(let _0x149eb7=0x0;_0x149eb7<_0x402afa['length'];_0x149eb7++)_0x402afa[_0x149eb7]['status']===0x3?_0x402afa[_0x149eb7]['status']=0x4:_0x402afa[_0x149eb7]['status']=0x0;}else{U('transaction\x20at\x20'+_0x564876['toString']()+'\x20failed:\x20'+_0x3043cf);for(let _0x512124=0x0;_0x512124<_0x402afa['length'];_0x512124++)_0x402afa[_0x512124]['status']=0x4,_0x402afa[_0x512124]['abortReason']=_0x3043cf;}it(_0x57a1d1,_0x117464);}},_0x4c6a7b);}function it(_0x4c35ed,_0x511b70){const _0x4ad0f3=ua(_0x4c35ed,_0x511b70),_0x250f66=qt(_0x4ad0f3),_0x4a752d=da(_0x4c35ed,_0x4ad0f3);return Pd(_0x4c35ed,_0x4a752d,_0x250f66),_0x250f66;}function Pd(_0xefd60d,_0x52d8ef,_0x423d97){if(_0x52d8ef['length']===0x0)return;const _0x30f496=[];let _0x57a222=[];const _0x45a044=_0x52d8ef['filter'](_0x286a3e=>_0x286a3e['status']===0x0)['map'](_0x2a1f86=>_0x2a1f86['currentWriteId']);for(let _0x494e68=0x0;_0x494e68<_0x52d8ef['length'];_0x494e68++){const _0x249cf0=_0x52d8ef[_0x494e68],_0x49a2e9=F(_0x423d97,_0x249cf0['path']);let _0x2564f7=!0x1,_0x4cee35;if(f(_0x49a2e9!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x249cf0['status']===0x4)_0x2564f7=!0x0,_0x4cee35=_0x249cf0['abortReason'],_0x57a222=_0x57a222['concat'](pe(_0xefd60d['serverSyncTree_'],_0x249cf0['currentWriteId'],!0x0));else{if(_0x249cf0['status']===0x0){if(_0x249cf0['retryCount']>=yd)_0x2564f7=!0x0,_0x4cee35='maxretry',_0x57a222=_0x57a222['concat'](pe(_0xefd60d['serverSyncTree_'],_0x249cf0['currentWriteId'],!0x0));else{const _0x3ac2d8=Es(_0xefd60d,_0x249cf0['path'],_0x45a044);_0x249cf0['currentInputSnapshot']=_0x3ac2d8;const _0x3a9542=_0x52d8ef[_0x494e68]['update'](_0x3ac2d8['val']());if(_0x3a9542!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x3a9542,_0x249cf0['path']);let _0x1fcbe2=P(_0x3a9542);typeof _0x3a9542=='object'&&_0x3a9542!=null&&J(_0x3a9542,'.priority')||(_0x1fcbe2=_0x1fcbe2['updatePriority'](_0x3ac2d8['getPriority']()));const _0x1b63d3=_0x249cf0['currentWriteId'],_0x25c874=Kt(_0xefd60d),_0x188f5b=ds(_0x1fcbe2,_0x3ac2d8,_0x25c874);_0x249cf0['currentOutputSnapshotRaw']=_0x1fcbe2,_0x249cf0['currentOutputSnapshotResolved']=_0x188f5b,_0x249cf0['currentWriteId']=Hn(_0xefd60d),_0x45a044['splice'](_0x45a044['indexOf'](_0x1b63d3),0x1),_0x57a222=_0x57a222['concat'](os(_0xefd60d['serverSyncTree_'],_0x249cf0['path'],_0x188f5b,_0x249cf0['currentWriteId'],_0x249cf0['applyLocally'])),_0x57a222=_0x57a222['concat'](pe(_0xefd60d['serverSyncTree_'],_0x1b63d3,!0x0));}else _0x2564f7=!0x0,_0x4cee35='nodata',_0x57a222=_0x57a222['concat'](pe(_0xefd60d['serverSyncTree_'],_0x249cf0['currentWriteId'],!0x0));}}}H(_0xefd60d['eventQueue_'],_0x423d97,_0x57a222),_0x57a222=[],_0x2564f7&&(_0x52d8ef[_0x494e68]['status']=0x2,function(_0x556bbe){setTimeout(_0x556bbe,Math['floor'](0x0));}(_0x52d8ef[_0x494e68]['unwatcher']),_0x52d8ef[_0x494e68]['onComplete']&&(_0x4cee35==='nodata'?_0x30f496['push'](()=>_0x52d8ef[_0x494e68]['onComplete'](null,!0x1,_0x52d8ef[_0x494e68]['currentInputSnapshot'])):_0x30f496['push'](()=>_0x52d8ef[_0x494e68]['onComplete'](new Error(_0x4cee35),!0x1,null))));}Gn(_0xefd60d,_0xefd60d['transactionQueueTree_']);for(let _0x5d75d9=0x0;_0x5d75d9<_0x30f496['length'];_0x5d75d9++)ht(_0x30f496[_0x5d75d9]);$n(_0xefd60d,_0xefd60d['transactionQueueTree_']);}function ua(_0x2edee2,_0x23f5cc){let _0x598e7a,_0x154a6f=_0x2edee2['transactionQueueTree_'];for(_0x598e7a=y(_0x23f5cc);_0x598e7a!==null&&Ge(_0x154a6f)===void 0x0;)_0x154a6f=Wn(_0x154a6f,_0x598e7a),_0x23f5cc=b(_0x23f5cc),_0x598e7a=y(_0x23f5cc);return _0x154a6f;}function da(_0x24f045,_0x1a06c1){const _0x329e48=[];return fa(_0x24f045,_0x1a06c1,_0x329e48),_0x329e48['sort']((_0x5c5608,_0xa99eee)=>_0x5c5608['order']-_0xa99eee['order']),_0x329e48;}function fa(_0x5834d6,_0x4d0d6b,_0x333fb6){const _0x34dcd2=Ge(_0x4d0d6b);if(_0x34dcd2){for(let _0x2a18f0=0x0;_0x2a18f0<_0x34dcd2['length'];_0x2a18f0++)_0x333fb6['push'](_0x34dcd2[_0x2a18f0]);}Bn(_0x4d0d6b,_0x27caea=>{fa(_0x5834d6,_0x27caea,_0x333fb6);});}function Gn(_0x4ad9f6,_0x48f289){const _0x3addc5=Ge(_0x48f289);if(_0x3addc5){let _0x855713=0x0;for(let _0x44cae9=0x0;_0x44cae9<_0x3addc5['length'];_0x44cae9++)_0x3addc5[_0x44cae9]['status']!==0x2&&(_0x3addc5[_0x855713]=_0x3addc5[_0x44cae9],_0x855713++);_0x3addc5['length']=_0x855713,_s(_0x48f289,_0x3addc5['length']>0x0?_0x3addc5:void 0x0);}Bn(_0x48f289,_0x3fdf3f=>{Gn(_0x4ad9f6,_0x3fdf3f);});}function Is(_0x260d0c,_0x176ccc){const _0x5956dd=qt(ua(_0x260d0c,_0x176ccc)),_0x1c5115=Wn(_0x260d0c['transactionQueueTree_'],_0x176ccc);return ad(_0x1c5115,_0x2481ed=>{ci(_0x260d0c,_0x2481ed);}),ci(_0x260d0c,_0x1c5115),sa(_0x1c5115,_0x378799=>{ci(_0x260d0c,_0x378799);}),_0x5956dd;}function ci(_0x4f43f9,_0x4fb993){const _0x261cd8=Ge(_0x4fb993);if(_0x261cd8){const _0x2a6cee=[];let _0x20ec9c=[],_0x1fcee8=-0x1;for(let _0x27396f=0x0;_0x27396f<_0x261cd8['length'];_0x27396f++)_0x261cd8[_0x27396f]['status']===0x3||(_0x261cd8[_0x27396f]['status']===0x1?(f(_0x1fcee8===_0x27396f-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x1fcee8=_0x27396f,_0x261cd8[_0x27396f]['status']=0x3,_0x261cd8[_0x27396f]['abortReason']='set'):(f(_0x261cd8[_0x27396f]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x261cd8[_0x27396f]['unwatcher'](),_0x20ec9c=_0x20ec9c['concat'](pe(_0x4f43f9['serverSyncTree_'],_0x261cd8[_0x27396f]['currentWriteId'],!0x0)),_0x261cd8[_0x27396f]['onComplete']&&_0x2a6cee['push'](_0x261cd8[_0x27396f]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x1fcee8===-0x1?_s(_0x4fb993,void 0x0):_0x261cd8['length']=_0x1fcee8+0x1,H(_0x4f43f9['eventQueue_'],qt(_0x4fb993),_0x20ec9c);for(let _0x304031=0x0;_0x304031<_0x2a6cee['length'];_0x304031++)ht(_0x2a6cee[_0x304031]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x4cbd09){let _0x400ce3='';const _0x3e20c6=_0x4cbd09['split']('/');for(let _0x27b553=0x0;_0x27b553<_0x3e20c6['length'];_0x27b553++)if(_0x3e20c6[_0x27b553]['length']>0x0){let _0x4d3160=_0x3e20c6[_0x27b553];try{_0x4d3160=decodeURIComponent(_0x4d3160['replace'](/\+/g,'\x20'));}catch{}_0x400ce3+='/'+_0x4d3160;}return _0x400ce3;}function Dd(_0x1c11f7){const _0x388dcb={};_0x1c11f7['charAt'](0x0)==='?'&&(_0x1c11f7=_0x1c11f7['substring'](0x1));for(const _0x25df3d of _0x1c11f7['split']('&')){if(_0x25df3d['length']===0x0)continue;const _0x10f3ed=_0x25df3d['split']('=');_0x10f3ed['length']===0x2?_0x388dcb[decodeURIComponent(_0x10f3ed[0x0])]=decodeURIComponent(_0x10f3ed[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x25df3d+'\x27\x20in\x20query\x20\x27'+_0x1c11f7+'\x27');}return _0x388dcb;}const vr=function(_0x59e062,_0x2b3ab6){const _0x4da1d7=Md(_0x59e062),_0x281992=_0x4da1d7['namespace'];_0x4da1d7['domain']==='firebase.com'&&ae(_0x4da1d7['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x281992||_0x281992==='undefined')&&_0x4da1d7['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x4da1d7['secure']||$l();const _0x13dcde=_0x4da1d7['scheme']==='ws'||_0x4da1d7['scheme']==='wss';return{'repoInfo':new yo(_0x4da1d7['host'],_0x4da1d7['secure'],_0x281992,_0x13dcde,_0x2b3ab6,'',_0x281992!==_0x4da1d7['subdomain']),'path':new C(_0x4da1d7['pathString'])};},Md=function(_0x4a302e){let _0xcf6dff='',_0x8f6618='',_0x37886c='',_0x3c18d8='',_0xb32b4b='',_0x3e5502=!0x0,_0x37d0ef='https',_0x4de772=0x1bb;if(typeof _0x4a302e=='string'){let _0xfaa588=_0x4a302e['indexOf']('//');_0xfaa588>=0x0&&(_0x37d0ef=_0x4a302e['substring'](0x0,_0xfaa588-0x1),_0x4a302e=_0x4a302e['substring'](_0xfaa588+0x2));let _0x3156ee=_0x4a302e['indexOf']('/');_0x3156ee===-0x1&&(_0x3156ee=_0x4a302e['length']);let _0x256f4a=_0x4a302e['indexOf']('?');_0x256f4a===-0x1&&(_0x256f4a=_0x4a302e['length']),_0xcf6dff=_0x4a302e['substring'](0x0,Math['min'](_0x3156ee,_0x256f4a)),_0x3156ee<_0x256f4a&&(_0x3c18d8=Od(_0x4a302e['substring'](_0x3156ee,_0x256f4a)));const _0x706295=Dd(_0x4a302e['substring'](Math['min'](_0x4a302e['length'],_0x256f4a)));_0xfaa588=_0xcf6dff['indexOf'](':'),_0xfaa588>=0x0?(_0x3e5502=_0x37d0ef==='https'||_0x37d0ef==='wss',_0x4de772=parseInt(_0xcf6dff['substring'](_0xfaa588+0x1),0xa)):_0xfaa588=_0xcf6dff['length'];const _0x1145a8=_0xcf6dff['slice'](0x0,_0xfaa588);if(_0x1145a8['toLowerCase']()==='localhost')_0x8f6618='localhost';else{if(_0x1145a8['split']('.')['length']<=0x2)_0x8f6618=_0x1145a8;else{const _0x546151=_0xcf6dff['indexOf']('.');_0x37886c=_0xcf6dff['substring'](0x0,_0x546151)['toLowerCase'](),_0x8f6618=_0xcf6dff['substring'](_0x546151+0x1),_0xb32b4b=_0x37886c;}}'ns'in _0x706295&&(_0xb32b4b=_0x706295['ns']);}return{'host':_0xcf6dff,'port':_0x4de772,'domain':_0x8f6618,'subdomain':_0x37886c,'secure':_0x3e5502,'scheme':_0x37d0ef,'pathString':_0x3c18d8,'namespace':_0xb32b4b};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x4b7070=0x0;const _0x22dddb=[];return function(_0x3982eb){const _0x380e12=_0x3982eb===_0x4b7070;_0x4b7070=_0x3982eb;let _0x4a85d1;const _0x5ea308=new Array(0x8);for(_0x4a85d1=0x7;_0x4a85d1>=0x0;_0x4a85d1--)_0x5ea308[_0x4a85d1]=Er['charAt'](_0x3982eb%0x40),_0x3982eb=Math['floor'](_0x3982eb/0x40);f(_0x3982eb===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x17960f=_0x5ea308['join']('');if(_0x380e12){for(_0x4a85d1=0xb;_0x4a85d1>=0x0&&_0x22dddb[_0x4a85d1]===0x3f;_0x4a85d1--)_0x22dddb[_0x4a85d1]=0x0;_0x22dddb[_0x4a85d1]++;}else{for(_0x4a85d1=0x0;_0x4a85d1<0xc;_0x4a85d1++)_0x22dddb[_0x4a85d1]=Math['floor'](Math['random']()*0x40);}for(_0x4a85d1=0x0;_0x4a85d1<0xc;_0x4a85d1++)_0x17960f+=Er['charAt'](_0x22dddb[_0x4a85d1]);return f(_0x17960f['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x17960f;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x11ca15,_0x18ea4f,_0x74509d,_0x2a1548){this['eventType']=_0x11ca15,this['eventRegistration']=_0x18ea4f,this['snapshot']=_0x74509d,this['prevName']=_0x2a1548;}['getPath'](){const _0x1f3461=this['snapshot']['ref'];return this['eventType']==='value'?_0x1f3461['_path']:_0x1f3461['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x57ef42,_0x2fe430,_0x156c33){this['eventRegistration']=_0x57ef42,this['error']=_0x2fe430,this['path']=_0x156c33;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x55e8cf,_0x513a67){this['snapshotCallback']=_0x55e8cf,this['cancelCallback']=_0x513a67;}['onValue'](_0x372147,_0x5847da){this['snapshotCallback']['call'](null,_0x372147,_0x5847da);}['onCancel'](_0x382566){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x382566);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x3b84dc){return this['snapshotCallback']===_0x3b84dc['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x3b84dc['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x3b84dc['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x3c4673,_0x18fb96,_0x505fd1,_0x109097){this['_repo']=_0x3c4673,this['_path']=_0x18fb96,this['_queryParams']=_0x505fd1,this['_orderByCalled']=_0x109097;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x291fc8=rr(this['_queryParams']),_0x2b021e=Hi(_0x291fc8);return _0x2b021e==='{}'?'default':_0x2b021e;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x225c34){if(_0x225c34=N(_0x225c34),!(_0x225c34 instanceof be))return!0x1;const _0x1b9199=this['_repo']===_0x225c34['_repo'],_0xb51a3b=ji(this['_path'],_0x225c34['_path']),_0x356226=this['_queryIdentifier']===_0x225c34['_queryIdentifier'];return _0x1b9199&&_0xb51a3b&&_0x356226;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x41b409,_0xf10e0d){if(_0x41b409['_orderByCalled']===!0x0)throw new Error(_0xf10e0d+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x25c47a){let _0x41d691=null,_0x4252d2=null;if(_0x25c47a['hasStart']()&&(_0x41d691=_0x25c47a['getIndexStartValue']()),_0x25c47a['hasEnd']()&&(_0x4252d2=_0x25c47a['getIndexEndValue']()),_0x25c47a['getIndex']()===ye){const _0x842084='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x4d89e6='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x25c47a['hasStart']()){if(_0x25c47a['getIndexStartName']()!==Fe)throw new Error(_0x842084);if(typeof _0x41d691!='string')throw new Error(_0x4d89e6);}if(_0x25c47a['hasEnd']()){if(_0x25c47a['getIndexEndName']()!==Ie)throw new Error(_0x842084);if(typeof _0x4252d2!='string')throw new Error(_0x4d89e6);}}else{if(_0x25c47a['getIndex']()===R){if(_0x41d691!=null&&!Tn(_0x41d691)||_0x4252d2!=null&&!Tn(_0x4252d2))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x25c47a['getIndex']()instanceof Qi||_0x25c47a['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x41d691!=null&&typeof _0x41d691=='object'||_0x4252d2!=null&&typeof _0x4252d2=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x1026e9){if(_0x1026e9['hasStart']()&&_0x1026e9['hasEnd']()&&_0x1026e9['hasLimit']()&&!_0x1026e9['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x514d86,_0x30b14f){super(_0x514d86,_0x30b14f,new Xi(),!0x1);}get['parent'](){const _0x284e2b=Ro(this['_path']);return _0x284e2b===null?null:new ee(this['_repo'],_0x284e2b);}get['root'](){let _0x337a1a=this;for(;_0x337a1a['parent']!==null;)_0x337a1a=_0x337a1a['parent'];return _0x337a1a;}}class st{constructor(_0x2110af,_0x12400f,_0x3e03b0){this['_node']=_0x2110af,this['ref']=_0x12400f,this['_index']=_0x3e03b0;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x49c6d6){const _0x4ce18b=new C(_0x49c6d6),_0x41f0db=Ft(this['ref'],_0x49c6d6);return new st(this['_node']['getChild'](_0x4ce18b),_0x41f0db,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x219f5b){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x28a546,_0x5748fd)=>_0x219f5b(new st(_0x5748fd,Ft(this['ref'],_0x28a546),R)));}['hasChild'](_0x4fe320){const _0x150407=new C(_0x4fe320);return!this['_node']['getChild'](_0x150407)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x132fff,_0x5cdb28){return _0x132fff=N(_0x132fff),_0x132fff['_checkNotDeleted']('ref'),_0x5cdb28!==void 0x0?Ft(_0x132fff['_root'],_0x5cdb28):_0x132fff['_root'];}function Ft(_0x1fe30b,_0x148785){return _0x1fe30b=N(_0x1fe30b),y(_0x1fe30b['_path'])===null?pd('child','path',_0x148785):ms('child','path',_0x148785),new ee(_0x1fe30b['_repo'],k(_0x1fe30b['_path'],_0x148785));}function g_(_0x2e84af,_0xbde685){_0x2e84af=N(_0x2e84af),ys('push',_0x2e84af['_path']),zt('push',_0xbde685,_0x2e84af['_path'],!0x0);const _0xb2abb7=la(_0x2e84af['_repo']),_0x1a16ce=Ld(_0xb2abb7),_0x17cb89=Ft(_0x2e84af,_0x1a16ce),_0x3402e0=Ft(_0x2e84af,_0x1a16ce);let _0x522efc;return _0xbde685!=null?_0x522efc=Ud(_0x3402e0,_0xbde685)['then'](()=>_0x3402e0):_0x522efc=Promise['resolve'](_0x3402e0),_0x17cb89['then']=_0x522efc['then']['bind'](_0x522efc),_0x17cb89['catch']=_0x522efc['then']['bind'](_0x522efc,void 0x0),_0x17cb89;}function Ud(_0x2366d8,_0x3ba032){_0x2366d8=N(_0x2366d8),ys('set',_0x2366d8['_path']),zt('set',_0x3ba032,_0x2366d8['_path'],!0x1);const _0x304de1=new ot();return Cd(_0x2366d8['_repo'],_0x2366d8['_path'],_0x3ba032,null,_0x304de1['wrapCallback'](()=>{})),_0x304de1['promise'];}function m_(_0x36c272,_0x187b1d){fd('update',_0x187b1d,_0x36c272['_path']);const _0x4dde84=new ot();return Td(_0x36c272['_repo'],_0x36c272['_path'],_0x187b1d,_0x4dde84['wrapCallback'](()=>{})),_0x4dde84['promise'];}function y_(_0x175008){_0x175008=N(_0x175008);const _0x4c252a=new pa(()=>{}),_0x251665=new zn(_0x4c252a);return wd(_0x175008['_repo'],_0x175008,_0x251665)['then'](_0x54e263=>new st(_0x54e263,new ee(_0x175008['_repo'],_0x175008['_path']),_0x175008['_queryParams']['getIndex']()));}class zn{constructor(_0x2bcea0){this['callbackContext']=_0x2bcea0;}['respondsTo'](_0x596ac0){return _0x596ac0==='value';}['createEvent'](_0x1994c0,_0x167b3f){const _0xfdf598=_0x167b3f['_queryParams']['getIndex']();return new xd('value',this,new st(_0x1994c0['snapshotNode'],new ee(_0x167b3f['_repo'],_0x167b3f['_path']),_0xfdf598));}['getEventRunner'](_0x572ada){return _0x572ada['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x572ada['error']):()=>this['callbackContext']['onValue'](_0x572ada['snapshot'],null);}['createCancelEvent'](_0x5ad2f2,_0x3720d1){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x5ad2f2,_0x3720d1):null;}['matches'](_0x52fc4f){return _0x52fc4f instanceof zn?!_0x52fc4f['callbackContext']||!this['callbackContext']?!0x0:_0x52fc4f['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x178fa7,_0x30197a,_0x4f72f1,_0x1e63c7,_0x226b12){const _0x210466=new pa(_0x4f72f1,void 0x0),_0x568104=new zn(_0x210466);return bd(_0x178fa7['_repo'],_0x178fa7,_0x568104),()=>Rd(_0x178fa7['_repo'],_0x178fa7,_0x568104);}function Bd(_0x546687,_0x4f27d2,_0x220010,_0x306cd8){return Wd(_0x546687,'value',_0x4f27d2);}class ft{}class ma extends ft{constructor(_0x31731b,_0x102459){super(),this['_value']=_0x31731b,this['_key']=_0x102459,this['type']='endAt';}['_apply'](_0x20500b){zt('endAt',this['_value'],_0x20500b['_path'],!0x0);const _0x33b9ad=Jh(_0x20500b['_queryParams'],this['_value'],this['_key']);if(ga(_0x33b9ad),qn(_0x33b9ad),_0x20500b['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x20500b['_repo'],_0x20500b['_path'],_0x33b9ad,_0x20500b['_orderByCalled']);}}function v_(_0x182938,_0x4951f3){return new ma(_0x182938,_0x4951f3);}class ya extends ft{constructor(_0x2226ed,_0x4cd5a4){super(),this['_value']=_0x2226ed,this['_key']=_0x4cd5a4,this['type']='startAt';}['_apply'](_0x129875){zt('startAt',this['_value'],_0x129875['_path'],!0x0);const _0xebb877=Qh(_0x129875['_queryParams'],this['_value'],this['_key']);if(ga(_0xebb877),qn(_0xebb877),_0x129875['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x129875['_repo'],_0x129875['_path'],_0xebb877,_0x129875['_orderByCalled']);}}function E_(_0x163550=null,_0x98f67e){return new ya(_0x163550,_0x98f67e);}class Vd extends ft{constructor(_0x2549b2){super(),this['_limit']=_0x2549b2,this['type']='limitToFirst';}['_apply'](_0x482617){if(_0x482617['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x482617['_repo'],_0x482617['_path'],Yh(_0x482617['_queryParams'],this['_limit']),_0x482617['_orderByCalled']);}}function I_(_0x381442){if(Math['floor'](_0x381442)!==_0x381442||_0x381442<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x381442);}class Hd extends ft{constructor(_0x2d6e38){super(),this['_path']=_0x2d6e38,this['type']='orderByChild';}['_apply'](_0x49a896){_a(_0x49a896,'orderByChild');const _0xe0b5c0=new C(this['_path']);if(v(_0xe0b5c0))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x5ec082=new Qi(_0xe0b5c0),_0x1e3088=xo(_0x49a896['_queryParams'],_0x5ec082);return qn(_0x1e3088),new be(_0x49a896['_repo'],_0x49a896['_path'],_0x1e3088,!0x0);}}function w_(_0x566d89){if(_0x566d89==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x566d89==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x566d89==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x566d89),new Hd(_0x566d89);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x4cfa06){_a(_0x4cfa06,'orderByKey');const _0x336d46=xo(_0x4cfa06['_queryParams'],ye);return qn(_0x336d46),new be(_0x4cfa06['_repo'],_0x4cfa06['_path'],_0x336d46,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0xd047a1,_0x4fb431){super(),this['_value']=_0xd047a1,this['_key']=_0x4fb431,this['type']='equalTo';}['_apply'](_0x5c68a4){if(zt('equalTo',this['_value'],_0x5c68a4['_path'],!0x1),_0x5c68a4['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x5c68a4['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x5c68a4));}}function T_(_0xc4ec83,_0xb0de84){return new Gd(_0xc4ec83,_0xb0de84);}function S_(_0x3db55d,..._0x4abeba){let _0x117a78=N(_0x3db55d);for(const _0x344770 of _0x4abeba)_0x117a78=_0x344770['_apply'](_0x117a78);return _0x117a78;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x3ce46f,_0x37fec4,_0xe73627,_0x476f57){const _0x159fc1=_0x37fec4['lastIndexOf'](':'),_0x2b1e69=_0x37fec4['substring'](0x0,_0x159fc1),_0x7af1fc=at(_0x2b1e69);_0x3ce46f['repoInfo_']=new yo(_0x37fec4,_0x7af1fc,_0x3ce46f['repoInfo_']['namespace'],_0x3ce46f['repoInfo_']['webSocketOnly'],_0x3ce46f['repoInfo_']['nodeAdmin'],_0x3ce46f['repoInfo_']['persistenceKey'],_0x3ce46f['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0xe73627),_0x476f57&&(_0x3ce46f['authTokenProvider_']=_0x476f57);}function Kd(_0x47f8ef,_0x54b6c7,_0x4d37b8,_0x287692,_0x44fdc8){let _0x3563ef=_0x287692||_0x47f8ef['options']['databaseURL'];_0x3563ef===void 0x0&&(_0x47f8ef['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x47f8ef['options']['projectId']),_0x3563ef=_0x47f8ef['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x116bd3=vr(_0x3563ef,_0x44fdc8),_0x334ac4=_0x116bd3['repoInfo'],_0x4ce0da;typeof process<'u'&&Vs&&(_0x4ce0da=Vs[qd]),_0x4ce0da?(_0x3563ef='http://'+_0x4ce0da+'?ns='+_0x334ac4['namespace'],_0x116bd3=vr(_0x3563ef,_0x44fdc8),_0x334ac4=_0x116bd3['repoInfo']):_0x116bd3['repoInfo']['secure'];const _0x1bec3e=new eh(_0x47f8ef['name'],_0x47f8ef['options'],_0x54b6c7);_d('Invalid\x20Firebase\x20Database\x20URL',_0x116bd3),v(_0x116bd3['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x3d23a2=Qd(_0x334ac4,_0x47f8ef,_0x1bec3e,new Zl(_0x47f8ef,_0x4d37b8));return new Jd(_0x3d23a2,_0x47f8ef);}function Yd(_0x47e0e1,_0xe89031){const _0x3c187c=Ni[_0xe89031];(!_0x3c187c||_0x3c187c[_0x47e0e1['key']]!==_0x47e0e1)&&ae('Database\x20'+_0xe89031+'('+_0x47e0e1['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x47e0e1),delete _0x3c187c[_0x47e0e1['key']];}function Qd(_0x36058f,_0x27ad20,_0x4f3258,_0x59450a){let _0x438cf8=Ni[_0x27ad20['name']];_0x438cf8||(_0x438cf8={},Ni[_0x27ad20['name']]=_0x438cf8);let _0x37a6e8=_0x438cf8[_0x36058f['toURLString']()];return _0x37a6e8&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x37a6e8=new vd(_0x36058f,zd,_0x4f3258,_0x59450a),_0x438cf8[_0x36058f['toURLString']()]=_0x37a6e8,_0x37a6e8;}class Jd{constructor(_0x5ac6de,_0x594b00){this['_repoInternal']=_0x5ac6de,this['app']=_0x594b00,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x538ac9){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x538ac9+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x292b96=Zr(),_0x583a1f){const _0x295f42=Bi(_0x292b96,'database')['getImmediate']({'identifier':_0x583a1f});if(!_0x295f42['_instanceStarted']){const _0x405cf0=cc('database');_0x405cf0&&Xd(_0x295f42,..._0x405cf0);}return _0x295f42;}function Xd(_0x5e01ee,_0x1521e4,_0x589fea,_0x23d4f6={}){_0x5e01ee=N(_0x5e01ee),_0x5e01ee['_checkNotDeleted']('useEmulator');const _0x45795f=_0x1521e4+':'+_0x589fea,_0xc892b2=_0x5e01ee['_repoInternal'];if(_0x5e01ee['_instanceStarted']){if(_0x45795f===_0x5e01ee['_repoInternal']['repoInfo_']['host']&&Me(_0x23d4f6,_0xc892b2['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4848cf;if(_0xc892b2['repoInfo_']['nodeAdmin'])_0x23d4f6['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4848cf=new nn(nn['OWNER']);else{if(_0x23d4f6['mockUserToken']){const _0x209198=typeof _0x23d4f6['mockUserToken']=='string'?_0x23d4f6['mockUserToken']:lc(_0x23d4f6['mockUserToken'],_0x5e01ee['app']['options']['projectId']);_0x4848cf=new nn(_0x209198);}}at(_0x1521e4)&&(jr(_0x1521e4),Kr('Database',!0x0)),jd(_0xc892b2,_0x45795f,_0x23d4f6,_0x4848cf);}function R_(_0x5958f2){_0x5958f2=N(_0x5958f2),_0x5958f2['_checkNotDeleted']('goOffline'),ha(_0x5958f2['_repo']);}function A_(_0x35402b){_0x35402b=N(_0x35402b),_0x35402b['_checkNotDeleted']('goOnline'),Ad(_0x35402b['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x21f22e){Ul(lt),Ze(new Le('database',(_0x5c9f71,{instanceIdentifier:_0xa39341})=>{const _0x39be42=_0x5c9f71['getProvider']('app')['getImmediate'](),_0x4f8d8b=_0x5c9f71['getProvider']('auth-internal'),_0x23d432=_0x5c9f71['getProvider']('app-check-internal');return Kd(_0x39be42,_0x4f8d8b,_0x23d432,_0xa39341);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x21f22e),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x322c0c,_0x8fdbb7){this['committed']=_0x322c0c,this['snapshot']=_0x8fdbb7;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x19d4ae,_0x534d98,_0x2dbf91){if(_0x19d4ae=N(_0x19d4ae),ys('Reference.transaction',_0x19d4ae['_path']),_0x19d4ae['key']==='.length'||_0x19d4ae['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x19d4ae['key']+'\x20is\x20a\x20read-only\x20object.';const _0x2279d4=!0x0,_0x3a1437=new ot(),_0x4d0c9e=(_0x33eecc,_0x212f65,_0x37cf90)=>{let _0x1fdcd4=null;_0x33eecc?_0x3a1437['reject'](_0x33eecc):(_0x1fdcd4=new st(_0x37cf90,new ee(_0x19d4ae['_repo'],_0x19d4ae['_path']),R),_0x3a1437['resolve'](new tf(_0x212f65,_0x1fdcd4)));},_0x1af653=Bd(_0x19d4ae,()=>{});return kd(_0x19d4ae['_repo'],_0x19d4ae['_path'],_0x534d98,_0x4d0c9e,_0x1af653,_0x2279d4),_0x3a1437['promise'];}se['prototype']['simpleListen']=function(_0x312c2c,_0x427103){this['sendRequest']('q',{'p':_0x312c2c},_0x427103);},se['prototype']['echo']=function(_0x47986f,_0x5f4723){this['sendRequest']('echo',{'d':_0x47986f},_0x5f4723);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x19273e,..._0x5580d2){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x19273e,..._0x5580d2);}function sn(_0x27f683,..._0x31adbd){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x27f683,..._0x31adbd);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x14053b,..._0x23d787){throw ws(_0x14053b,..._0x23d787);}function X(_0x3733bf,..._0x251cc4){return ws(_0x3733bf,..._0x251cc4);}function Ia(_0x32e26f,_0x369c51,_0x57bb78){const _0x3a0d01={...nf(),[_0x369c51]:_0x57bb78};return new Bt('auth','Firebase',_0x3a0d01)['create'](_0x369c51,{'appName':_0x32e26f['name']});}function re(_0x358808){return Ia(_0x358808,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x20d4b0,..._0xf8eb56){if(typeof _0x20d4b0!='string'){const _0xbf3fd4=_0xf8eb56[0x0],_0x2f0bef=[..._0xf8eb56['slice'](0x1)];return _0x2f0bef[0x0]&&(_0x2f0bef[0x0]['appName']=_0x20d4b0['name']),_0x20d4b0['_errorFactory']['create'](_0xbf3fd4,..._0x2f0bef);}return Ea['create'](_0x20d4b0,..._0xf8eb56);}function m(_0xd57244,_0x3b3485,..._0x30c384){if(!_0xd57244)throw ws(_0x3b3485,..._0x30c384);}function ne(_0x7fe48){const _0x1842b9='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x7fe48;throw sn(_0x1842b9),new Error(_0x1842b9);}function ce(_0x6953af,_0x1bc953){_0x6953af||ne(_0x1bc953);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x209a9a;return typeof self<'u'&&((_0x209a9a=self['location'])==null?void 0x0:_0x209a9a['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x4cc2d4;return typeof self<'u'&&((_0x4cc2d4=self['location'])==null?void 0x0:_0x4cc2d4['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x4090aa=navigator;return _0x4090aa['languages']&&_0x4090aa['languages'][0x0]||_0x4090aa['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x501e3f,_0x5b1ea6){this['shortDelay']=_0x501e3f,this['longDelay']=_0x5b1ea6,ce(_0x5b1ea6>_0x501e3f,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x3f8704,_0x4d8b43){ce(_0x3f8704['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x2a29cc}=_0x3f8704['emulator'];return _0x4d8b43?''+_0x2a29cc+(_0x4d8b43['startsWith']('/')?_0x4d8b43['slice'](0x1):_0x4d8b43):_0x2a29cc;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x3b493d,_0x41655e,_0x46c319){this['fetchImpl']=_0x3b493d,_0x41655e&&(this['headersImpl']=_0x41655e),_0x46c319&&(this['responseImpl']=_0x46c319);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x55c0bc,_0x5c2050){return _0x55c0bc['tenantId']&&!_0x5c2050['tenantId']?{..._0x5c2050,'tenantId':_0x55c0bc['tenantId']}:_0x5c2050;}async function Ae(_0x8372f2,_0x2a0ea1,_0x447f15,_0x2356a1,_0x362151={}){return Ca(_0x8372f2,_0x362151,async()=>{let _0x51f8ad={},_0x511089={};_0x2356a1&&(_0x2a0ea1==='GET'?_0x511089=_0x2356a1:_0x51f8ad={'body':JSON['stringify'](_0x2356a1)});const _0x3ff22a=ct({'key':_0x8372f2['config']['apiKey'],..._0x511089})['slice'](0x1),_0x5917cd=await _0x8372f2['_getAdditionalHeaders']();_0x5917cd['Content-Type']='application/json',_0x8372f2['languageCode']&&(_0x5917cd['X-Firebase-Locale']=_0x8372f2['languageCode']);const _0x285f73={'method':_0x2a0ea1,'headers':_0x5917cd,..._0x51f8ad};return dc()||(_0x285f73['referrerPolicy']='no-referrer'),_0x8372f2['emulatorConfig']&&at(_0x8372f2['emulatorConfig']['host'])&&(_0x285f73['credentials']='include'),wa['fetch']()(await Ta(_0x8372f2,_0x8372f2['config']['apiHost'],_0x447f15,_0x3ff22a),_0x285f73);});}async function Ca(_0x7aa015,_0x69f25b,_0x5ca834){_0x7aa015['_canInitEmulator']=!0x1;const _0x285928={...cf,..._0x69f25b};try{const _0x2edb54=new df(_0x7aa015),_0x305df4=await Promise['race']([_0x5ca834(),_0x2edb54['promise']]);_0x2edb54['clearNetworkTimeout']();const _0x1c9962=await _0x305df4['json']();if('needConfirmation'in _0x1c9962)throw tn(_0x7aa015,'account-exists-with-different-credential',_0x1c9962);if(_0x305df4['ok']&&!('errorMessage'in _0x1c9962))return _0x1c9962;{const _0x5a31bf=_0x305df4['ok']?_0x1c9962['errorMessage']:_0x1c9962['error']['message'],[_0xf93fbc,_0x3d7327]=_0x5a31bf['split']('\x20:\x20');if(_0xf93fbc==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x7aa015,'credential-already-in-use',_0x1c9962);if(_0xf93fbc==='EMAIL_EXISTS')throw tn(_0x7aa015,'email-already-in-use',_0x1c9962);if(_0xf93fbc==='USER_DISABLED')throw tn(_0x7aa015,'user-disabled',_0x1c9962);const _0xff6975=_0x285928[_0xf93fbc]||_0xf93fbc['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x3d7327)throw Ia(_0x7aa015,_0xff6975,_0x3d7327);Q(_0x7aa015,_0xff6975);}}catch(_0x57b716){if(_0x57b716 instanceof Se)throw _0x57b716;Q(_0x7aa015,'network-request-failed',{'message':String(_0x57b716)});}}async function Qt(_0x47335e,_0x54b60f,_0x36e91f,_0x1bfe40,_0x570ec7={}){const _0x385c1b=await Ae(_0x47335e,_0x54b60f,_0x36e91f,_0x1bfe40,_0x570ec7);return'mfaPendingCredential'in _0x385c1b&&Q(_0x47335e,'multi-factor-auth-required',{'_serverResponse':_0x385c1b}),_0x385c1b;}async function Ta(_0x44bc35,_0x20ebd9,_0x1a84b4,_0x19f083){const _0x49906b=''+_0x20ebd9+_0x1a84b4+'?'+_0x19f083,_0x5cd47f=_0x44bc35,_0x38d676=_0x5cd47f['config']['emulator']?Cs(_0x44bc35['config'],_0x49906b):_0x44bc35['config']['apiScheme']+'://'+_0x49906b;return lf['includes'](_0x1a84b4)&&(await _0x5cd47f['_persistenceManagerAvailable'],_0x5cd47f['_getPersistenceType']()==='COOKIE')?_0x5cd47f['_getPersistence']()['_getFinalTarget'](_0x38d676)['toString']():_0x38d676;}function uf(_0x218854){switch(_0x218854){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x557f9d){this['auth']=_0x557f9d,this['timer']=null,this['promise']=new Promise((_0x259497,_0x42bb00)=>{this['timer']=setTimeout(()=>_0x42bb00(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x4f9a50,_0xa5c676,_0x357f5e){const _0x52bb17={'appName':_0x4f9a50['name']};_0x357f5e['email']&&(_0x52bb17['email']=_0x357f5e['email']),_0x357f5e['phoneNumber']&&(_0x52bb17['phoneNumber']=_0x357f5e['phoneNumber']);const _0x1da813=X(_0x4f9a50,_0xa5c676,_0x52bb17);return _0x1da813['customData']['_tokenResponse']=_0x357f5e,_0x1da813;}function wr(_0x4e0838){return _0x4e0838!==void 0x0&&_0x4e0838['enterprise']!==void 0x0;}class ff{constructor(_0x249ed8){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x249ed8['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x249ed8['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x249ed8['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0xa1b0ce){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x50af3a of this['recaptchaEnforcementState'])if(_0x50af3a['provider']&&_0x50af3a['provider']===_0xa1b0ce)return uf(_0x50af3a['enforcementState']);return null;}['isProviderEnabled'](_0x47e53f){return this['getProviderEnforcementState'](_0x47e53f)==='ENFORCE'||this['getProviderEnforcementState'](_0x47e53f)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x40638d,_0x4570b4){return Ae(_0x40638d,'GET','/v2/recaptchaConfig',Re(_0x40638d,_0x4570b4));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x1a49f9,_0x19eb5b){return Ae(_0x1a49f9,'POST','/v1/accounts:delete',_0x19eb5b);}async function bn(_0x52964e,_0x35caff){return Ae(_0x52964e,'POST','/v1/accounts:lookup',_0x35caff);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x331885){if(_0x331885)try{const _0x5be010=new Date(Number(_0x331885));if(!isNaN(_0x5be010['getTime']()))return _0x5be010['toUTCString']();}catch{}}async function gf(_0x2b70b9,_0x4938fc=!0x1){const _0x2ddd07=N(_0x2b70b9),_0x44e8d7=await _0x2ddd07['getIdToken'](_0x4938fc),_0xc35fa1=Ts(_0x44e8d7);m(_0xc35fa1&&_0xc35fa1['exp']&&_0xc35fa1['auth_time']&&_0xc35fa1['iat'],_0x2ddd07['auth'],'internal-error');const _0x113e83=typeof _0xc35fa1['firebase']=='object'?_0xc35fa1['firebase']:void 0x0,_0x5692aa=_0x113e83==null?void 0x0:_0x113e83['sign_in_provider'];return{'claims':_0xc35fa1,'token':_0x44e8d7,'authTime':Rt(li(_0xc35fa1['auth_time'])),'issuedAtTime':Rt(li(_0xc35fa1['iat'])),'expirationTime':Rt(li(_0xc35fa1['exp'])),'signInProvider':_0x5692aa||null,'signInSecondFactor':(_0x113e83==null?void 0x0:_0x113e83['sign_in_second_factor'])||null};}function li(_0x433907){return Number(_0x433907)*0x3e8;}function Ts(_0x4f636b){const [_0x14f306,_0xdba04b,_0x3244e2]=_0x4f636b['split']('.');if(_0x14f306===void 0x0||_0xdba04b===void 0x0||_0x3244e2===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x55636a=ln(_0xdba04b);return _0x55636a?JSON['parse'](_0x55636a):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x4ac0f4){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x4ac0f4==null?void 0x0:_0x4ac0f4['toString']()),null;}}function Cr(_0x315bc3){const _0x436c11=Ts(_0x315bc3);return m(_0x436c11,'internal-error'),m(typeof _0x436c11['exp']<'u','internal-error'),m(typeof _0x436c11['iat']<'u','internal-error'),Number(_0x436c11['exp'])-Number(_0x436c11['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x529357,_0x2b1e1d,_0x4f8df8=!0x1){if(_0x4f8df8)return _0x2b1e1d;try{return await _0x2b1e1d;}catch(_0x1ed3c8){throw _0x1ed3c8 instanceof Se&&mf(_0x1ed3c8)&&_0x529357['auth']['currentUser']===_0x529357&&await _0x529357['auth']['signOut'](),_0x1ed3c8;}}function mf({code:_0x116472}){return _0x116472==='auth/user-disabled'||_0x116472==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x343685){this['user']=_0x343685,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x3a6338){if(_0x3a6338){const _0x11d9be=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x11d9be;}else{this['errorBackoff']=0x7530;const _0x57f5eb=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x57f5eb);}}['schedule'](_0xe62198=!0x1){if(!this['isRunning'])return;const _0x1b66b6=this['getInterval'](_0xe62198);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x1b66b6);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x458cd3){(_0x458cd3==null?void 0x0:_0x458cd3['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x556cd8,_0x21000a){this['createdAt']=_0x556cd8,this['lastLoginAt']=_0x21000a,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x2096dc){this['createdAt']=_0x2096dc['createdAt'],this['lastLoginAt']=_0x2096dc['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x3d1cd0){var _0x5a2197;const _0x14668f=_0x3d1cd0['auth'],_0x1f61d2=await _0x3d1cd0['getIdToken'](),_0x3f8966=await Ut(_0x3d1cd0,bn(_0x14668f,{'idToken':_0x1f61d2}));m(_0x3f8966==null?void 0x0:_0x3f8966['users']['length'],_0x14668f,'internal-error');const _0x48c2d7=_0x3f8966['users'][0x0];_0x3d1cd0['_notifyReloadListener'](_0x48c2d7);const _0x42b868=(_0x5a2197=_0x48c2d7['providerUserInfo'])!=null&&_0x5a2197['length']?Sa(_0x48c2d7['providerUserInfo']):[],_0x4d34c9=Ef(_0x3d1cd0['providerData'],_0x42b868),_0x18f22e=_0x3d1cd0['isAnonymous'],_0x2d99cf=!(_0x3d1cd0['email']&&_0x48c2d7['passwordHash'])&&!(_0x4d34c9!=null&&_0x4d34c9['length']),_0x15bb7f=_0x18f22e?_0x2d99cf:!0x1,_0x59af28={'uid':_0x48c2d7['localId'],'displayName':_0x48c2d7['displayName']||null,'photoURL':_0x48c2d7['photoUrl']||null,'email':_0x48c2d7['email']||null,'emailVerified':_0x48c2d7['emailVerified']||!0x1,'phoneNumber':_0x48c2d7['phoneNumber']||null,'tenantId':_0x48c2d7['tenantId']||null,'providerData':_0x4d34c9,'metadata':new Oi(_0x48c2d7['createdAt'],_0x48c2d7['lastLoginAt']),'isAnonymous':_0x15bb7f};Object['assign'](_0x3d1cd0,_0x59af28);}async function vf(_0x5ce398){const _0x4a301e=N(_0x5ce398);await Rn(_0x4a301e),await _0x4a301e['auth']['_persistUserIfCurrent'](_0x4a301e),_0x4a301e['auth']['_notifyListenersIfCurrent'](_0x4a301e);}function Ef(_0x16ddd5,_0x3cde44){return[..._0x16ddd5['filter'](_0x3758cc=>!_0x3cde44['some'](_0x4376e9=>_0x4376e9['providerId']===_0x3758cc['providerId'])),..._0x3cde44];}function Sa(_0x3dfa13){return _0x3dfa13['map'](({providerId:_0x4f922a,..._0x270aeb})=>({'providerId':_0x4f922a,'uid':_0x270aeb['rawId']||'','displayName':_0x270aeb['displayName']||null,'email':_0x270aeb['email']||null,'phoneNumber':_0x270aeb['phoneNumber']||null,'photoURL':_0x270aeb['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x4adc63,_0x35f8d5){const _0x533045=await Ca(_0x4adc63,{},async()=>{const _0x1e120e=ct({'grant_type':'refresh_token','refresh_token':_0x35f8d5})['slice'](0x1),{tokenApiHost:_0x402436,apiKey:_0x488399}=_0x4adc63['config'],_0x30b159=await Ta(_0x4adc63,_0x402436,'/v1/token','key='+_0x488399),_0x430aad=await _0x4adc63['_getAdditionalHeaders']();_0x430aad['Content-Type']='application/x-www-form-urlencoded';const _0x54cb81={'method':'POST','headers':_0x430aad,'body':_0x1e120e};return _0x4adc63['emulatorConfig']&&at(_0x4adc63['emulatorConfig']['host'])&&(_0x54cb81['credentials']='include'),wa['fetch']()(_0x30b159,_0x54cb81);});return{'accessToken':_0x533045['access_token'],'expiresIn':_0x533045['expires_in'],'refreshToken':_0x533045['refresh_token']};}async function wf(_0x406ef0,_0x5b96fd){return Ae(_0x406ef0,'POST','/v2/accounts:revokeToken',Re(_0x406ef0,_0x5b96fd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x4f9aab){m(_0x4f9aab['idToken'],'internal-error'),m(typeof _0x4f9aab['idToken']<'u','internal-error'),m(typeof _0x4f9aab['refreshToken']<'u','internal-error');const _0x504e2d='expiresIn'in _0x4f9aab&&typeof _0x4f9aab['expiresIn']<'u'?Number(_0x4f9aab['expiresIn']):Cr(_0x4f9aab['idToken']);this['updateTokensAndExpiration'](_0x4f9aab['idToken'],_0x4f9aab['refreshToken'],_0x504e2d);}['updateFromIdToken'](_0x5959e2){m(_0x5959e2['length']!==0x0,'internal-error');const _0x7a950=Cr(_0x5959e2);this['updateTokensAndExpiration'](_0x5959e2,null,_0x7a950);}async['getToken'](_0x353398,_0x5a7594=!0x1){return!_0x5a7594&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x353398,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x353398,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x3b0d9c,_0x3404c3){const {accessToken:_0x530fc8,refreshToken:_0xdec6c0,expiresIn:_0x56a931}=await If(_0x3b0d9c,_0x3404c3);this['updateTokensAndExpiration'](_0x530fc8,_0xdec6c0,Number(_0x56a931));}['updateTokensAndExpiration'](_0x373ccb,_0x2f594d,_0x110ba3){this['refreshToken']=_0x2f594d||null,this['accessToken']=_0x373ccb||null,this['expirationTime']=Date['now']()+_0x110ba3*0x3e8;}static['fromJSON'](_0x1c9c35,_0x59ad3c){const {refreshToken:_0x4a0881,accessToken:_0x3ffe8f,expirationTime:_0x277b72}=_0x59ad3c,_0x456a9f=new Qe();return _0x4a0881&&(m(typeof _0x4a0881=='string','internal-error',{'appName':_0x1c9c35}),_0x456a9f['refreshToken']=_0x4a0881),_0x3ffe8f&&(m(typeof _0x3ffe8f=='string','internal-error',{'appName':_0x1c9c35}),_0x456a9f['accessToken']=_0x3ffe8f),_0x277b72&&(m(typeof _0x277b72=='number','internal-error',{'appName':_0x1c9c35}),_0x456a9f['expirationTime']=_0x277b72),_0x456a9f;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x302c33){this['accessToken']=_0x302c33['accessToken'],this['refreshToken']=_0x302c33['refreshToken'],this['expirationTime']=_0x302c33['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x506c9d,_0x5a1afa){m(typeof _0x506c9d=='string'||typeof _0x506c9d>'u','internal-error',{'appName':_0x5a1afa});}class K{constructor({uid:_0x4dd968,auth:_0x34b56c,stsTokenManager:_0x6d5e8f,..._0x4e332c}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x4dd968,this['auth']=_0x34b56c,this['stsTokenManager']=_0x6d5e8f,this['accessToken']=_0x6d5e8f['accessToken'],this['displayName']=_0x4e332c['displayName']||null,this['email']=_0x4e332c['email']||null,this['emailVerified']=_0x4e332c['emailVerified']||!0x1,this['phoneNumber']=_0x4e332c['phoneNumber']||null,this['photoURL']=_0x4e332c['photoURL']||null,this['isAnonymous']=_0x4e332c['isAnonymous']||!0x1,this['tenantId']=_0x4e332c['tenantId']||null,this['providerData']=_0x4e332c['providerData']?[..._0x4e332c['providerData']]:[],this['metadata']=new Oi(_0x4e332c['createdAt']||void 0x0,_0x4e332c['lastLoginAt']||void 0x0);}async['getIdToken'](_0x5418c8){const _0x981733=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x5418c8));return m(_0x981733,this['auth'],'internal-error'),this['accessToken']!==_0x981733&&(this['accessToken']=_0x981733,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x981733;}['getIdTokenResult'](_0x27971d){return gf(this,_0x27971d);}['reload'](){return vf(this);}['_assign'](_0x4f3ecd){this!==_0x4f3ecd&&(m(this['uid']===_0x4f3ecd['uid'],this['auth'],'internal-error'),this['displayName']=_0x4f3ecd['displayName'],this['photoURL']=_0x4f3ecd['photoURL'],this['email']=_0x4f3ecd['email'],this['emailVerified']=_0x4f3ecd['emailVerified'],this['phoneNumber']=_0x4f3ecd['phoneNumber'],this['isAnonymous']=_0x4f3ecd['isAnonymous'],this['tenantId']=_0x4f3ecd['tenantId'],this['providerData']=_0x4f3ecd['providerData']['map'](_0x15e81b=>({..._0x15e81b})),this['metadata']['_copy'](_0x4f3ecd['metadata']),this['stsTokenManager']['_assign'](_0x4f3ecd['stsTokenManager']));}['_clone'](_0x4bcd06){const _0x23e119=new K({...this,'auth':_0x4bcd06,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x23e119['metadata']['_copy'](this['metadata']),_0x23e119;}['_onReload'](_0x464a60){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x464a60,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x1c2718){this['reloadListener']?this['reloadListener'](_0x1c2718):this['reloadUserInfo']=_0x1c2718;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x39dc15,_0x54c162=!0x1){let _0x2965f2=!0x1;_0x39dc15['idToken']&&_0x39dc15['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x39dc15),_0x2965f2=!0x0),_0x54c162&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x2965f2&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x554acc=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x554acc})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x3982b8=>({..._0x3982b8})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x135e37,_0xf49b6f){const _0x45b663=_0xf49b6f['displayName']??void 0x0,_0x379811=_0xf49b6f['email']??void 0x0,_0x4d22a9=_0xf49b6f['phoneNumber']??void 0x0,_0x5fd89e=_0xf49b6f['photoURL']??void 0x0,_0x45018d=_0xf49b6f['tenantId']??void 0x0,_0x39764b=_0xf49b6f['_redirectEventId']??void 0x0,_0xcfee30=_0xf49b6f['createdAt']??void 0x0,_0x24a514=_0xf49b6f['lastLoginAt']??void 0x0,{uid:_0x337c4a,emailVerified:_0x5a7abb,isAnonymous:_0x4c95db,providerData:_0x7bbb2d,stsTokenManager:_0xa7dfa0}=_0xf49b6f;m(_0x337c4a&&_0xa7dfa0,_0x135e37,'internal-error');const _0x3aaff7=Qe['fromJSON'](this['name'],_0xa7dfa0);m(typeof _0x337c4a=='string',_0x135e37,'internal-error'),le(_0x45b663,_0x135e37['name']),le(_0x379811,_0x135e37['name']),m(typeof _0x5a7abb=='boolean',_0x135e37,'internal-error'),m(typeof _0x4c95db=='boolean',_0x135e37,'internal-error'),le(_0x4d22a9,_0x135e37['name']),le(_0x5fd89e,_0x135e37['name']),le(_0x45018d,_0x135e37['name']),le(_0x39764b,_0x135e37['name']),le(_0xcfee30,_0x135e37['name']),le(_0x24a514,_0x135e37['name']);const _0x2bf3b3=new K({'uid':_0x337c4a,'auth':_0x135e37,'email':_0x379811,'emailVerified':_0x5a7abb,'displayName':_0x45b663,'isAnonymous':_0x4c95db,'photoURL':_0x5fd89e,'phoneNumber':_0x4d22a9,'tenantId':_0x45018d,'stsTokenManager':_0x3aaff7,'createdAt':_0xcfee30,'lastLoginAt':_0x24a514});return _0x7bbb2d&&Array['isArray'](_0x7bbb2d)&&(_0x2bf3b3['providerData']=_0x7bbb2d['map'](_0x4627b7=>({..._0x4627b7}))),_0x39764b&&(_0x2bf3b3['_redirectEventId']=_0x39764b),_0x2bf3b3;}static async['_fromIdTokenResponse'](_0x5f58f0,_0x5bf2c1,_0x1a6974=!0x1){const _0x127a3d=new Qe();_0x127a3d['updateFromServerResponse'](_0x5bf2c1);const _0x1546a8=new K({'uid':_0x5bf2c1['localId'],'auth':_0x5f58f0,'stsTokenManager':_0x127a3d,'isAnonymous':_0x1a6974});return await Rn(_0x1546a8),_0x1546a8;}static async['_fromGetAccountInfoResponse'](_0x5c89ff,_0x3e3d24,_0x291919){const _0x50869f=_0x3e3d24['users'][0x0];m(_0x50869f['localId']!==void 0x0,'internal-error');const _0x52ff25=_0x50869f['providerUserInfo']!==void 0x0?Sa(_0x50869f['providerUserInfo']):[],_0x15d82a=!(_0x50869f['email']&&_0x50869f['passwordHash'])&&!(_0x52ff25!=null&&_0x52ff25['length']),_0x11557d=new Qe();_0x11557d['updateFromIdToken'](_0x291919);const _0x1607d1=new K({'uid':_0x50869f['localId'],'auth':_0x5c89ff,'stsTokenManager':_0x11557d,'isAnonymous':_0x15d82a}),_0x55d93b={'uid':_0x50869f['localId'],'displayName':_0x50869f['displayName']||null,'photoURL':_0x50869f['photoUrl']||null,'email':_0x50869f['email']||null,'emailVerified':_0x50869f['emailVerified']||!0x1,'phoneNumber':_0x50869f['phoneNumber']||null,'tenantId':_0x50869f['tenantId']||null,'providerData':_0x52ff25,'metadata':new Oi(_0x50869f['createdAt'],_0x50869f['lastLoginAt']),'isAnonymous':!(_0x50869f['email']&&_0x50869f['passwordHash'])&&!(_0x52ff25!=null&&_0x52ff25['length'])};return Object['assign'](_0x1607d1,_0x55d93b),_0x1607d1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x4339c0){ce(_0x4339c0 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x22d5b6=Tr['get'](_0x4339c0);return _0x22d5b6?(ce(_0x22d5b6 instanceof _0x4339c0,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x22d5b6):(_0x22d5b6=new _0x4339c0(),Tr['set'](_0x4339c0,_0x22d5b6),_0x22d5b6);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x36f20d,_0x30230e){this['storage'][_0x36f20d]=_0x30230e;}async['_get'](_0x8d0507){const _0x4e6c3d=this['storage'][_0x8d0507];return _0x4e6c3d===void 0x0?null:_0x4e6c3d;}async['_remove'](_0x5c2818){delete this['storage'][_0x5c2818];}['_addListener'](_0x5844fc,_0x4e6341){}['_removeListener'](_0x3cbfbf,_0x18b0d1){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x55f4a3,_0xefbe33,_0x3217fa){return'firebase:'+_0x55f4a3+':'+_0xefbe33+':'+_0x3217fa;}class Je{constructor(_0x5bb9a9,_0x4b30b1,_0x4a343e){this['persistence']=_0x5bb9a9,this['auth']=_0x4b30b1,this['userKey']=_0x4a343e;const {config:_0x5cb791,name:_0x11b398}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x5cb791['apiKey'],_0x11b398),this['fullPersistenceKey']=rn('persistence',_0x5cb791['apiKey'],_0x11b398),this['boundEventHandler']=_0x4b30b1['_onStorageEvent']['bind'](_0x4b30b1),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x4deeed){return this['persistence']['_set'](this['fullUserKey'],_0x4deeed['toJSON']());}async['getCurrentUser'](){const _0x19a85e=await this['persistence']['_get'](this['fullUserKey']);if(!_0x19a85e)return null;if(typeof _0x19a85e=='string'){const _0x2dc925=await bn(this['auth'],{'idToken':_0x19a85e})['catch'](()=>{});return _0x2dc925?K['_fromGetAccountInfoResponse'](this['auth'],_0x2dc925,_0x19a85e):null;}return K['_fromJSON'](this['auth'],_0x19a85e);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x4f4185){if(this['persistence']===_0x4f4185)return;const _0x4ba1a2=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x4f4185,_0x4ba1a2)return this['setCurrentUser'](_0x4ba1a2);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x290de1,_0xa28ad0,_0xb615cd='authUser'){if(!_0xa28ad0['length'])return new Je(ie(Sr),_0x290de1,_0xb615cd);const _0x34c3d4=(await Promise['all'](_0xa28ad0['map'](async _0x45e026=>{if(await _0x45e026['_isAvailable']())return _0x45e026;})))['filter'](_0x46fb17=>_0x46fb17);let _0x461a32=_0x34c3d4[0x0]||ie(Sr);const _0x5a85fa=rn(_0xb615cd,_0x290de1['config']['apiKey'],_0x290de1['name']);let _0x49aeea=null;for(const _0x1d1fb0 of _0xa28ad0)try{const _0x4f4619=await _0x1d1fb0['_get'](_0x5a85fa);if(_0x4f4619){let _0x9b3508;if(typeof _0x4f4619=='string'){const _0x411787=await bn(_0x290de1,{'idToken':_0x4f4619})['catch'](()=>{});if(!_0x411787)break;_0x9b3508=await K['_fromGetAccountInfoResponse'](_0x290de1,_0x411787,_0x4f4619);}else _0x9b3508=K['_fromJSON'](_0x290de1,_0x4f4619);_0x1d1fb0!==_0x461a32&&(_0x49aeea=_0x9b3508),_0x461a32=_0x1d1fb0;break;}}catch{}const _0x460d69=_0x34c3d4['filter'](_0xb2fa1e=>_0xb2fa1e['_shouldAllowMigration']);return!_0x461a32['_shouldAllowMigration']||!_0x460d69['length']?new Je(_0x461a32,_0x290de1,_0xb615cd):(_0x461a32=_0x460d69[0x0],_0x49aeea&&await _0x461a32['_set'](_0x5a85fa,_0x49aeea['toJSON']()),await Promise['all'](_0xa28ad0['map'](async _0xd444ef=>{if(_0xd444ef!==_0x461a32)try{await _0xd444ef['_remove'](_0x5a85fa);}catch{}})),new Je(_0x461a32,_0x290de1,_0xb615cd));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0xe14468){const _0x54eecc=_0xe14468['toLowerCase']();if(_0x54eecc['includes']('opera/')||_0x54eecc['includes']('opr/')||_0x54eecc['includes']('opios/'))return'Opera';if(Na(_0x54eecc))return'IEMobile';if(_0x54eecc['includes']('msie')||_0x54eecc['includes']('trident/'))return'IE';if(_0x54eecc['includes']('edge/'))return'Edge';if(Ra(_0x54eecc))return'Firefox';if(_0x54eecc['includes']('silk/'))return'Silk';if(Oa(_0x54eecc))return'Blackberry';if(Da(_0x54eecc))return'Webos';if(Aa(_0x54eecc))return'Safari';if((_0x54eecc['includes']('chrome/')||ka(_0x54eecc))&&!_0x54eecc['includes']('edge/'))return'Chrome';if(Pa(_0x54eecc))return'Android';{const _0x5ac630=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x2cfa95=_0xe14468['match'](_0x5ac630);if((_0x2cfa95==null?void 0x0:_0x2cfa95['length'])===0x2)return _0x2cfa95[0x1];}return'Other';}function Ra(_0x55fb67=W()){return/firefox\//i['test'](_0x55fb67);}function Aa(_0x59e73a=W()){const _0x57e0f3=_0x59e73a['toLowerCase']();return _0x57e0f3['includes']('safari/')&&!_0x57e0f3['includes']('chrome/')&&!_0x57e0f3['includes']('crios/')&&!_0x57e0f3['includes']('android');}function ka(_0x29620d=W()){return/crios\//i['test'](_0x29620d);}function Na(_0x3babb1=W()){return/iemobile/i['test'](_0x3babb1);}function Pa(_0x11e56c=W()){return/android/i['test'](_0x11e56c);}function Oa(_0xf9f2eb=W()){return/blackberry/i['test'](_0xf9f2eb);}function Da(_0x192e49=W()){return/webos/i['test'](_0x192e49);}function Ss(_0x3c3b2f=W()){return/iphone|ipad|ipod/i['test'](_0x3c3b2f)||/macintosh/i['test'](_0x3c3b2f)&&/mobile/i['test'](_0x3c3b2f);}function Cf(_0x5710de=W()){var _0x36adcf;return Ss(_0x5710de)&&!!((_0x36adcf=window['navigator'])!=null&&_0x36adcf['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x5c9735=W()){return Ss(_0x5c9735)||Pa(_0x5c9735)||Da(_0x5c9735)||Oa(_0x5c9735)||/windows phone/i['test'](_0x5c9735)||Na(_0x5c9735);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x702b54,_0xcdda3c=[]){let _0x1d69f8;switch(_0x702b54){case'Browser':_0x1d69f8=br(W());break;case'Worker':_0x1d69f8=br(W())+'-'+_0x702b54;break;default:_0x1d69f8=_0x702b54;}const _0x168318=_0xcdda3c['length']?_0xcdda3c['join'](','):'FirebaseCore-web';return _0x1d69f8+'/JsCore/'+lt+'/'+_0x168318;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0xa00ee7){this['auth']=_0xa00ee7,this['queue']=[];}['pushCallback'](_0x5d67e5,_0x2873a7){const _0x3f73c2=_0x250e25=>new Promise((_0x1075b6,_0x41058b)=>{try{const _0x359b11=_0x5d67e5(_0x250e25);_0x1075b6(_0x359b11);}catch(_0x3a0f88){_0x41058b(_0x3a0f88);}});_0x3f73c2['onAbort']=_0x2873a7,this['queue']['push'](_0x3f73c2);const _0x3411d1=this['queue']['length']-0x1;return()=>{this['queue'][_0x3411d1]=()=>Promise['resolve']();};}async['runMiddleware'](_0x8e0709){if(this['auth']['currentUser']===_0x8e0709)return;const _0x4bc20f=[];try{for(const _0x59b7a2 of this['queue'])await _0x59b7a2(_0x8e0709),_0x59b7a2['onAbort']&&_0x4bc20f['push'](_0x59b7a2['onAbort']);}catch(_0x20196c){_0x4bc20f['reverse']();for(const _0x2bf631 of _0x4bc20f)try{_0x2bf631();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x20196c==null?void 0x0:_0x20196c['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x23b15c,_0x11a2b4={}){return Ae(_0x23b15c,'GET','/v2/passwordPolicy',Re(_0x23b15c,_0x11a2b4));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x3581b9){var _0x2cbf1a;const _0x4f16a4=_0x3581b9['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x4f16a4['minPasswordLength']??Rf,_0x4f16a4['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x4f16a4['maxPasswordLength']),_0x4f16a4['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x4f16a4['containsLowercaseCharacter']),_0x4f16a4['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x4f16a4['containsUppercaseCharacter']),_0x4f16a4['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x4f16a4['containsNumericCharacter']),_0x4f16a4['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x4f16a4['containsNonAlphanumericCharacter']),this['enforcementState']=_0x3581b9['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x2cbf1a=_0x3581b9['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x2cbf1a['join'](''))??'',this['forceUpgradeOnSignin']=_0x3581b9['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x3581b9['schemaVersion'];}['validatePassword'](_0x12a3ce){const _0x296192={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x12a3ce,_0x296192),this['validatePasswordCharacterOptions'](_0x12a3ce,_0x296192),_0x296192['isValid']&&(_0x296192['isValid']=_0x296192['meetsMinPasswordLength']??!0x0),_0x296192['isValid']&&(_0x296192['isValid']=_0x296192['meetsMaxPasswordLength']??!0x0),_0x296192['isValid']&&(_0x296192['isValid']=_0x296192['containsLowercaseLetter']??!0x0),_0x296192['isValid']&&(_0x296192['isValid']=_0x296192['containsUppercaseLetter']??!0x0),_0x296192['isValid']&&(_0x296192['isValid']=_0x296192['containsNumericCharacter']??!0x0),_0x296192['isValid']&&(_0x296192['isValid']=_0x296192['containsNonAlphanumericCharacter']??!0x0),_0x296192;}['validatePasswordLengthOptions'](_0x47281d,_0x241f04){const _0x2fe0b2=this['customStrengthOptions']['minPasswordLength'],_0x4e20bf=this['customStrengthOptions']['maxPasswordLength'];_0x2fe0b2&&(_0x241f04['meetsMinPasswordLength']=_0x47281d['length']>=_0x2fe0b2),_0x4e20bf&&(_0x241f04['meetsMaxPasswordLength']=_0x47281d['length']<=_0x4e20bf);}['validatePasswordCharacterOptions'](_0x1aac95,_0xbd4092){this['updatePasswordCharacterOptionsStatuses'](_0xbd4092,!0x1,!0x1,!0x1,!0x1);let _0x3b09af;for(let _0x4ce1b7=0x0;_0x4ce1b7<_0x1aac95['length'];_0x4ce1b7++)_0x3b09af=_0x1aac95['charAt'](_0x4ce1b7),this['updatePasswordCharacterOptionsStatuses'](_0xbd4092,_0x3b09af>='a'&&_0x3b09af<='z',_0x3b09af>='A'&&_0x3b09af<='Z',_0x3b09af>='0'&&_0x3b09af<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x3b09af));}['updatePasswordCharacterOptionsStatuses'](_0x240627,_0x553533,_0x194d5b,_0xc7b5ee,_0x1a2f26){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x240627['containsLowercaseLetter']||(_0x240627['containsLowercaseLetter']=_0x553533)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x240627['containsUppercaseLetter']||(_0x240627['containsUppercaseLetter']=_0x194d5b)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x240627['containsNumericCharacter']||(_0x240627['containsNumericCharacter']=_0xc7b5ee)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x240627['containsNonAlphanumericCharacter']||(_0x240627['containsNonAlphanumericCharacter']=_0x1a2f26));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x3cfe0c,_0x5c9620,_0x70a2cd,_0x207514){this['app']=_0x3cfe0c,this['heartbeatServiceProvider']=_0x5c9620,this['appCheckServiceProvider']=_0x70a2cd,this['config']=_0x207514,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x3cfe0c['name'],this['clientVersion']=_0x207514['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x2d5d7e=>this['_resolvePersistenceManagerAvailable']=_0x2d5d7e);}['_initializeWithPersistence'](_0x3e813c,_0x1959f3){return _0x1959f3&&(this['_popupRedirectResolver']=ie(_0x1959f3)),this['_initializationPromise']=this['queue'](async()=>{var _0x3be4de,_0x47e677,_0x2a1d7d;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x3e813c),(_0x3be4de=this['_resolvePersistenceManagerAvailable'])==null||_0x3be4de['call'](this),!this['_deleted'])){if((_0x47e677=this['_popupRedirectResolver'])!=null&&_0x47e677['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x1959f3),this['lastNotifiedUid']=((_0x2a1d7d=this['currentUser'])==null?void 0x0:_0x2a1d7d['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x409452=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x409452)){if(this['currentUser']&&_0x409452&&this['currentUser']['uid']===_0x409452['uid']){this['_currentUser']['_assign'](_0x409452),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x409452,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x17a15d){try{const _0x13248a=await bn(this,{'idToken':_0x17a15d}),_0x3a9f45=await K['_fromGetAccountInfoResponse'](this,_0x13248a,_0x17a15d);await this['directlySetCurrentUser'](_0x3a9f45);}catch(_0x283001){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x283001),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x170abd){var _0x2d16b4;if($(this['app'])){const _0xa38cc6=this['app']['settings']['authIdToken'];return _0xa38cc6?new Promise(_0xd873cb=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0xa38cc6)['then'](_0xd873cb,_0xd873cb));}):this['directlySetCurrentUser'](null);}const _0x3aa5eb=await this['assertedPersistence']['getCurrentUser']();let _0x240dfa=_0x3aa5eb,_0x27a4aa=!0x1;if(_0x170abd&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0xc6f1a8=(_0x2d16b4=this['redirectUser'])==null?void 0x0:_0x2d16b4['_redirectEventId'],_0x3a31f6=_0x240dfa==null?void 0x0:_0x240dfa['_redirectEventId'],_0x2fa627=await this['tryRedirectSignIn'](_0x170abd);(!_0xc6f1a8||_0xc6f1a8===_0x3a31f6)&&(_0x2fa627!=null&&_0x2fa627['user'])&&(_0x240dfa=_0x2fa627['user'],_0x27a4aa=!0x0);}if(!_0x240dfa)return this['directlySetCurrentUser'](null);if(!_0x240dfa['_redirectEventId']){if(_0x27a4aa)try{await this['beforeStateQueue']['runMiddleware'](_0x240dfa);}catch(_0xc82699){_0x240dfa=_0x3aa5eb,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0xc82699));}return _0x240dfa?this['reloadAndSetCurrentUserOrClear'](_0x240dfa):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x240dfa['_redirectEventId']?this['directlySetCurrentUser'](_0x240dfa):this['reloadAndSetCurrentUserOrClear'](_0x240dfa);}async['tryRedirectSignIn'](_0x1772e7){let _0x42898d=null;try{_0x42898d=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x1772e7,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x42898d;}async['reloadAndSetCurrentUserOrClear'](_0x5115d5){try{await Rn(_0x5115d5);}catch(_0x369375){if((_0x369375==null?void 0x0:_0x369375['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x5115d5);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x414259){if($(this['app']))return Promise['reject'](re(this));const _0x507a05=_0x414259?N(_0x414259):null;return _0x507a05&&m(_0x507a05['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x507a05&&_0x507a05['_clone'](this));}async['_updateCurrentUser'](_0x1c9c0a,_0x5af2f5=!0x1){if(!this['_deleted'])return _0x1c9c0a&&m(this['tenantId']===_0x1c9c0a['tenantId'],this,'tenant-id-mismatch'),_0x5af2f5||await this['beforeStateQueue']['runMiddleware'](_0x1c9c0a),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x1c9c0a),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x3d80b4){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x3d80b4));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x1379a8){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x5f3d13=this['_getPasswordPolicyInternal']();return _0x5f3d13['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x5f3d13['validatePassword'](_0x1379a8);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x23dc92=await bf(this),_0x267e8e=new Af(_0x23dc92);this['tenantId']===null?this['_projectPasswordPolicy']=_0x267e8e:this['_tenantPasswordPolicies'][this['tenantId']]=_0x267e8e;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0xb3f14){this['_errorFactory']=new Bt('auth','Firebase',_0xb3f14());}['onAuthStateChanged'](_0x45feeb,_0x179eaa,_0x2f6308){return this['registerStateListener'](this['authStateSubscription'],_0x45feeb,_0x179eaa,_0x2f6308);}['beforeAuthStateChanged'](_0x411108,_0xd83878){return this['beforeStateQueue']['pushCallback'](_0x411108,_0xd83878);}['onIdTokenChanged'](_0x33005b,_0x1290b9,_0x108221){return this['registerStateListener'](this['idTokenSubscription'],_0x33005b,_0x1290b9,_0x108221);}['authStateReady'](){return new Promise((_0x141bd3,_0x366131)=>{if(this['currentUser'])_0x141bd3();else{const _0x191c9b=this['onAuthStateChanged'](()=>{_0x191c9b(),_0x141bd3();},_0x366131);}});}async['revokeAccessToken'](_0x4ea44e){if(this['currentUser']){const _0x2f1220=await this['currentUser']['getIdToken'](),_0x50c43c={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x4ea44e,'idToken':_0x2f1220};this['tenantId']!=null&&(_0x50c43c['tenantId']=this['tenantId']),await wf(this,_0x50c43c);}}['toJSON'](){var _0x2c8edb;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x2c8edb=this['_currentUser'])==null?void 0x0:_0x2c8edb['toJSON']()};}async['_setRedirectUser'](_0x42f568,_0xa04132){const _0x1cd782=await this['getOrInitRedirectPersistenceManager'](_0xa04132);return _0x42f568===null?_0x1cd782['removeCurrentUser']():_0x1cd782['setCurrentUser'](_0x42f568);}async['getOrInitRedirectPersistenceManager'](_0x9d9c8c){if(!this['redirectPersistenceManager']){const _0x38ce33=_0x9d9c8c&&ie(_0x9d9c8c)||this['_popupRedirectResolver'];m(_0x38ce33,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x38ce33['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x4d3f0b){var _0x3dcaf1,_0x375e78;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3dcaf1=this['_currentUser'])==null?void 0x0:_0x3dcaf1['_redirectEventId'])===_0x4d3f0b?this['_currentUser']:((_0x375e78=this['redirectUser'])==null?void 0x0:_0x375e78['_redirectEventId'])===_0x4d3f0b?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x536864){if(_0x536864===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x536864));}['_notifyListenersIfCurrent'](_0x1fa91a){_0x1fa91a===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x57cb6c;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x1df498=((_0x57cb6c=this['currentUser'])==null?void 0x0:_0x57cb6c['uid'])??null;this['lastNotifiedUid']!==_0x1df498&&(this['lastNotifiedUid']=_0x1df498,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x3ab714,_0x29a7d3,_0x2f2c63,_0x705b11){if(this['_deleted'])return()=>{};const _0x5a278d=typeof _0x29a7d3=='function'?_0x29a7d3:_0x29a7d3['next']['bind'](_0x29a7d3);let _0x1eb4cc=!0x1;const _0x37cfe1=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x37cfe1,this,'internal-error'),_0x37cfe1['then'](()=>{_0x1eb4cc||_0x5a278d(this['currentUser']);}),typeof _0x29a7d3=='function'){const _0x495f5d=_0x3ab714['addObserver'](_0x29a7d3,_0x2f2c63,_0x705b11);return()=>{_0x1eb4cc=!0x0,_0x495f5d();};}else{const _0x108e4b=_0x3ab714['addObserver'](_0x29a7d3);return()=>{_0x1eb4cc=!0x0,_0x108e4b();};}}async['directlySetCurrentUser'](_0xf5b873){this['currentUser']&&this['currentUser']!==_0xf5b873&&this['_currentUser']['_stopProactiveRefresh'](),_0xf5b873&&this['isProactiveRefreshEnabled']&&_0xf5b873['_startProactiveRefresh'](),this['currentUser']=_0xf5b873,_0xf5b873?await this['assertedPersistence']['setCurrentUser'](_0xf5b873):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x301277){return this['operations']=this['operations']['then'](_0x301277,_0x301277),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x50ab34){!_0x50ab34||this['frameworks']['includes'](_0x50ab34)||(this['frameworks']['push'](_0x50ab34),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0xa86491;const _0x19929e={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x19929e['X-Firebase-gmpid']=this['app']['options']['appId']);const _0xc756c1=await((_0xa86491=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xa86491['getHeartbeatsHeader']());_0xc756c1&&(_0x19929e['X-Firebase-Client']=_0xc756c1);const _0x20a16d=await this['_getAppCheckToken']();return _0x20a16d&&(_0x19929e['X-Firebase-AppCheck']=_0x20a16d),_0x19929e;}async['_getAppCheckToken'](){var _0x2d0101;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x40e75b=await((_0x2d0101=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x2d0101['getToken']());return _0x40e75b!=null&&_0x40e75b['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x40e75b['error']),_0x40e75b==null?void 0x0:_0x40e75b['token'];}}function qe(_0x1d41d6){return N(_0x1d41d6);}class Rr{constructor(_0xacec0f){this['auth']=_0xacec0f,this['observer']=null,this['addObserver']=Tc(_0x302709=>this['observer']=_0x302709);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x37a423){jn=_0x37a423;}function xa(_0x52828f){return jn['loadJS'](_0x52828f);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x1d20a9){return'__'+_0x1d20a9+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x1fb7c7){_0x1fb7c7();}['execute'](_0x592c29,_0x597e42){return Promise['resolve']('token');}['render'](_0x26b7d8,_0x37b3a6){return'';}}class Lf{['ready'](_0x20dee0){_0x20dee0();}['execute'](_0x447c5d,_0x24a9a8){return Promise['resolve']('token');}['render'](_0x2d77d2,_0x51a613){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x1ec12b){this['type']=xf,this['auth']=qe(_0x1ec12b);}async['verify'](_0x52e79c='verify',_0x1ef3e0=!0x1){async function _0x4b389c(_0xce5d65){if(!_0x1ef3e0){if(_0xce5d65['tenantId']==null&&_0xce5d65['_agentRecaptchaConfig']!=null)return _0xce5d65['_agentRecaptchaConfig']['siteKey'];if(_0xce5d65['tenantId']!=null&&_0xce5d65['_tenantRecaptchaConfigs'][_0xce5d65['tenantId']]!==void 0x0)return _0xce5d65['_tenantRecaptchaConfigs'][_0xce5d65['tenantId']]['siteKey'];}return new Promise(async(_0x5dbc85,_0x18da7c)=>{pf(_0xce5d65,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x2263cf=>{if(_0x2263cf['recaptchaKey']===void 0x0)_0x18da7c(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x5b4044=new ff(_0x2263cf);return _0xce5d65['tenantId']==null?_0xce5d65['_agentRecaptchaConfig']=_0x5b4044:_0xce5d65['_tenantRecaptchaConfigs'][_0xce5d65['tenantId']]=_0x5b4044,_0x5dbc85(_0x5b4044['siteKey']);}})['catch'](_0x59b5ba=>{_0x18da7c(_0x59b5ba);});});}function _0x1b4e3c(_0x70fd38,_0xe3e58a,_0x13688f){const _0x1be8f1=window['grecaptcha'];wr(_0x1be8f1)?_0x1be8f1['enterprise']['ready'](()=>{_0x1be8f1['enterprise']['execute'](_0x70fd38,{'action':_0x52e79c})['then'](_0x48b492=>{_0xe3e58a(_0x48b492);})['catch'](()=>{_0xe3e58a(Fa);});}):_0x13688f(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x1983c7,_0x358b83)=>{_0x4b389c(this['auth'])['then'](_0x35997a=>{if(!_0x1ef3e0&&wr(window['grecaptcha']))_0x1b4e3c(_0x35997a,_0x1983c7,_0x358b83);else{if(typeof window>'u'){_0x358b83(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x1ccad9=Pf();_0x1ccad9['length']!==0x0&&(_0x1ccad9+=_0x35997a),xa(_0x1ccad9)['then'](()=>{_0x1b4e3c(_0x35997a,_0x1983c7,_0x358b83);})['catch'](_0xad77c4=>{_0x358b83(_0xad77c4);});}})['catch'](_0x24d615=>{_0x358b83(_0x24d615);});});}}async function Ar(_0x875b97,_0x1fecd3,_0x5bd2f0,_0x2479cc=!0x1,_0x43b7df=!0x1){const _0x2071c1=new Ff(_0x875b97);let _0xd8787;if(_0x43b7df)_0xd8787=Fa;else try{_0xd8787=await _0x2071c1['verify'](_0x5bd2f0);}catch{_0xd8787=await _0x2071c1['verify'](_0x5bd2f0,!0x0);}const _0x24f7a8={..._0x1fecd3};if(_0x5bd2f0==='mfaSmsEnrollment'||_0x5bd2f0==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x24f7a8){const _0x4b643b=_0x24f7a8['phoneEnrollmentInfo']['phoneNumber'],_0x3984a5=_0x24f7a8['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x24f7a8,{'phoneEnrollmentInfo':{'phoneNumber':_0x4b643b,'recaptchaToken':_0x3984a5,'captchaResponse':_0xd8787,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x24f7a8){const _0x426990=_0x24f7a8['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x24f7a8,{'phoneSignInInfo':{'recaptchaToken':_0x426990,'captchaResponse':_0xd8787,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x24f7a8;}return _0x2479cc?Object['assign'](_0x24f7a8,{'captchaResp':_0xd8787}):Object['assign'](_0x24f7a8,{'captchaResponse':_0xd8787}),Object['assign'](_0x24f7a8,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x24f7a8,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x24f7a8;}async function Di(_0x26ec89,_0x44bff6,_0xc56ac3,_0x3ac320,_0x4f4baa){var _0x10642a;if((_0x10642a=_0x26ec89['_getRecaptchaConfig']())!=null&&_0x10642a['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x4f7eef=await Ar(_0x26ec89,_0x44bff6,_0xc56ac3,_0xc56ac3==='getOobCode');return _0x3ac320(_0x26ec89,_0x4f7eef);}else return _0x3ac320(_0x26ec89,_0x44bff6)['catch'](async _0x258fba=>{if(_0x258fba['code']==='auth/missing-recaptcha-token'){console['log'](_0xc56ac3+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x1888c5=await Ar(_0x26ec89,_0x44bff6,_0xc56ac3,_0xc56ac3==='getOobCode');return _0x3ac320(_0x26ec89,_0x1888c5);}else return Promise['reject'](_0x258fba);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x51bec9,_0x421bf6){const _0x7e81ee=Bi(_0x51bec9,'auth');if(_0x7e81ee['isInitialized']()){const _0x282369=_0x7e81ee['getImmediate'](),_0x5b894d=_0x7e81ee['getOptions']();if(Me(_0x5b894d,_0x421bf6??{}))return _0x282369;Q(_0x282369,'already-initialized');}return _0x7e81ee['initialize']({'options':_0x421bf6});}function Wf(_0x24bfc4,_0x33a0ec){const _0x49486c=(_0x33a0ec==null?void 0x0:_0x33a0ec['persistence'])||[],_0x9cb44a=(Array['isArray'](_0x49486c)?_0x49486c:[_0x49486c])['map'](ie);_0x33a0ec!=null&&_0x33a0ec['errorMap']&&_0x24bfc4['_updateErrorMap'](_0x33a0ec['errorMap']),_0x24bfc4['_initializeWithPersistence'](_0x9cb44a,_0x33a0ec==null?void 0x0:_0x33a0ec['popupRedirectResolver']);}function Bf(_0x4d6e2c,_0x31d554,_0x4951e2){const _0x17cb37=qe(_0x4d6e2c);m(/^https?:\/\//['test'](_0x31d554),_0x17cb37,'invalid-emulator-scheme');const _0x2b3f90=!0x1,_0x4a4682=Ua(_0x31d554),{host:_0x2b1fd9,port:_0x58baa8}=Vf(_0x31d554),_0x429123=_0x58baa8===null?'':':'+_0x58baa8,_0x2b1f40={'url':_0x4a4682+'//'+_0x2b1fd9+_0x429123+'/'},_0x32fc13=Object['freeze']({'host':_0x2b1fd9,'port':_0x58baa8,'protocol':_0x4a4682['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x2b3f90})});if(!_0x17cb37['_canInitEmulator']){m(_0x17cb37['config']['emulator']&&_0x17cb37['emulatorConfig'],_0x17cb37,'emulator-config-failed'),m(Me(_0x2b1f40,_0x17cb37['config']['emulator'])&&Me(_0x32fc13,_0x17cb37['emulatorConfig']),_0x17cb37,'emulator-config-failed');return;}_0x17cb37['config']['emulator']=_0x2b1f40,_0x17cb37['emulatorConfig']=_0x32fc13,_0x17cb37['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x2b1fd9)?(jr(_0x4a4682+'//'+_0x2b1fd9+_0x429123),Kr('Auth',!0x0)):Hf();}function Ua(_0x25850a){const _0x4933eb=_0x25850a['indexOf'](':');return _0x4933eb<0x0?'':_0x25850a['substr'](0x0,_0x4933eb+0x1);}function Vf(_0x2232a7){const _0x334bfd=Ua(_0x2232a7),_0x594519=/(\/\/)?([^?#/]+)/['exec'](_0x2232a7['substr'](_0x334bfd['length']));if(!_0x594519)return{'host':'','port':null};const _0xffb882=_0x594519[0x2]['split']('@')['pop']()||'',_0xfc519e=/^(\[[^\]]+\])(:|$)/['exec'](_0xffb882);if(_0xfc519e){const _0xb9cc39=_0xfc519e[0x1];return{'host':_0xb9cc39,'port':kr(_0xffb882['substr'](_0xb9cc39['length']+0x1))};}else{const [_0x5387a2,_0x28c947]=_0xffb882['split'](':');return{'host':_0x5387a2,'port':kr(_0x28c947)};}}function kr(_0xaad603){if(!_0xaad603)return null;const _0x1a2c6c=Number(_0xaad603);return isNaN(_0x1a2c6c)?null:_0x1a2c6c;}function Hf(){function _0x2d47b8(){const _0xc9fa5b=document['createElement']('p'),_0x5291e3=_0xc9fa5b['style'];_0xc9fa5b['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x5291e3['position']='fixed',_0x5291e3['width']='100%',_0x5291e3['backgroundColor']='#ffffff',_0x5291e3['border']='.1em\x20solid\x20#000000',_0x5291e3['color']='#b50000',_0x5291e3['bottom']='0px',_0x5291e3['left']='0px',_0x5291e3['margin']='0px',_0x5291e3['zIndex']='10000',_0x5291e3['textAlign']='center',_0xc9fa5b['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0xc9fa5b);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x2d47b8):_0x2d47b8());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x5a3843,_0xe16ad7){this['providerId']=_0x5a3843,this['signInMethod']=_0xe16ad7;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x470025){return ne('not\x20implemented');}['_linkToIdToken'](_0x25eb96,_0x1e95c5){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x2eaf4e){return ne('not\x20implemented');}}async function $f(_0xaf3409,_0x24b22d){return Ae(_0xaf3409,'POST','/v1/accounts:signUp',_0x24b22d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x4dfb15,_0x562c91){return Qt(_0x4dfb15,'POST','/v1/accounts:signInWithPassword',Re(_0x4dfb15,_0x562c91));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x2fc527,_0x4e276c){return Qt(_0x2fc527,'POST','/v1/accounts:signInWithEmailLink',Re(_0x2fc527,_0x4e276c));}async function zf(_0x55f556,_0x4b34e6){return Qt(_0x55f556,'POST','/v1/accounts:signInWithEmailLink',Re(_0x55f556,_0x4b34e6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x180ecc,_0x207041,_0x19c5b2,_0x86995e=null){super('password',_0x19c5b2),this['_email']=_0x180ecc,this['_password']=_0x207041,this['_tenantId']=_0x86995e;}static['_fromEmailAndPassword'](_0x393872,_0x2c2cb8){return new Wt(_0x393872,_0x2c2cb8,'password');}static['_fromEmailAndCode'](_0x35cfb1,_0x49fe09,_0x21f243=null){return new Wt(_0x35cfb1,_0x49fe09,'emailLink',_0x21f243);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x25ff89){const _0x1e1e9d=typeof _0x25ff89=='string'?JSON['parse'](_0x25ff89):_0x25ff89;if(_0x1e1e9d!=null&&_0x1e1e9d['email']&&(_0x1e1e9d!=null&&_0x1e1e9d['password'])){if(_0x1e1e9d['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x1e1e9d['email'],_0x1e1e9d['password']);if(_0x1e1e9d['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x1e1e9d['email'],_0x1e1e9d['password'],_0x1e1e9d['tenantId']);}return null;}async['_getIdTokenResponse'](_0x2964bb){switch(this['signInMethod']){case'password':const _0x2798ff={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x2964bb,_0x2798ff,'signInWithPassword',Gf);case'emailLink':return qf(_0x2964bb,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x2964bb,'internal-error');}}async['_linkToIdToken'](_0x1890a9,_0x3b86be){switch(this['signInMethod']){case'password':const _0x1f4a9f={'idToken':_0x3b86be,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x1890a9,_0x1f4a9f,'signUpPassword',$f);case'emailLink':return zf(_0x1890a9,{'idToken':_0x3b86be,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x1890a9,'internal-error');}}['_getReauthenticationResolver'](_0x4b5bcf){return this['_getIdTokenResponse'](_0x4b5bcf);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x31a634,_0x1d4254){return Qt(_0x31a634,'POST','/v1/accounts:signInWithIdp',Re(_0x31a634,_0x1d4254));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x57845b){const _0x19ab03=new Be(_0x57845b['providerId'],_0x57845b['signInMethod']);return _0x57845b['idToken']||_0x57845b['accessToken']?(_0x57845b['idToken']&&(_0x19ab03['idToken']=_0x57845b['idToken']),_0x57845b['accessToken']&&(_0x19ab03['accessToken']=_0x57845b['accessToken']),_0x57845b['nonce']&&!_0x57845b['pendingToken']&&(_0x19ab03['nonce']=_0x57845b['nonce']),_0x57845b['pendingToken']&&(_0x19ab03['pendingToken']=_0x57845b['pendingToken'])):_0x57845b['oauthToken']&&_0x57845b['oauthTokenSecret']?(_0x19ab03['accessToken']=_0x57845b['oauthToken'],_0x19ab03['secret']=_0x57845b['oauthTokenSecret']):Q('argument-error'),_0x19ab03;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x14a8ce){const _0x3e6fad=typeof _0x14a8ce=='string'?JSON['parse'](_0x14a8ce):_0x14a8ce,{providerId:_0x586bf0,signInMethod:_0x904dc8,..._0x11860f}=_0x3e6fad;if(!_0x586bf0||!_0x904dc8)return null;const _0x3e0dce=new Be(_0x586bf0,_0x904dc8);return _0x3e0dce['idToken']=_0x11860f['idToken']||void 0x0,_0x3e0dce['accessToken']=_0x11860f['accessToken']||void 0x0,_0x3e0dce['secret']=_0x11860f['secret'],_0x3e0dce['nonce']=_0x11860f['nonce'],_0x3e0dce['pendingToken']=_0x11860f['pendingToken']||null,_0x3e0dce;}['_getIdTokenResponse'](_0x3cb945){const _0x523261=this['buildRequest']();return Xe(_0x3cb945,_0x523261);}['_linkToIdToken'](_0x1c928d,_0x6df64d){const _0x1ab6db=this['buildRequest']();return _0x1ab6db['idToken']=_0x6df64d,Xe(_0x1c928d,_0x1ab6db);}['_getReauthenticationResolver'](_0x11ce1f){const _0x1b69c5=this['buildRequest']();return _0x1b69c5['autoCreate']=!0x1,Xe(_0x11ce1f,_0x1b69c5);}['buildRequest'](){const _0x8d30cc={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x8d30cc['pendingToken']=this['pendingToken'];else{const _0x338b03={};this['idToken']&&(_0x338b03['id_token']=this['idToken']),this['accessToken']&&(_0x338b03['access_token']=this['accessToken']),this['secret']&&(_0x338b03['oauth_token_secret']=this['secret']),_0x338b03['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x338b03['nonce']=this['nonce']),_0x8d30cc['postBody']=ct(_0x338b03);}return _0x8d30cc;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x14fd9b){switch(_0x14fd9b){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x2f84b2){const _0x534167=vt(Et(_0x2f84b2))['link'],_0x168b7d=_0x534167?vt(Et(_0x534167))['deep_link_id']:null,_0x89774a=vt(Et(_0x2f84b2))['deep_link_id'];return(_0x89774a?vt(Et(_0x89774a))['link']:null)||_0x89774a||_0x168b7d||_0x534167||_0x2f84b2;}class Rs{constructor(_0x56f724){const _0x39605e=vt(Et(_0x56f724)),_0x5e74ff=_0x39605e['apiKey']??null,_0x32debd=_0x39605e['oobCode']??null,_0x1ab907=Kf(_0x39605e['mode']??null);m(_0x5e74ff&&_0x32debd&&_0x1ab907,'argument-error'),this['apiKey']=_0x5e74ff,this['operation']=_0x1ab907,this['code']=_0x32debd,this['continueUrl']=_0x39605e['continueUrl']??null,this['languageCode']=_0x39605e['lang']??null,this['tenantId']=_0x39605e['tenantId']??null;}static['parseLink'](_0x106c22){const _0x21a713=Yf(_0x106c22);try{return new Rs(_0x21a713);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x459ceb,_0x110540){return Wt['_fromEmailAndPassword'](_0x459ceb,_0x110540);}static['credentialWithLink'](_0x6f86d3,_0x21c30e){const _0x551dc4=Rs['parseLink'](_0x21c30e);return m(_0x551dc4,'argument-error'),Wt['_fromEmailAndCode'](_0x6f86d3,_0x551dc4['code'],_0x551dc4['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x5d0f4a){this['providerId']=_0x5d0f4a,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x2924c9){this['defaultLanguageCode']=_0x2924c9;}['setCustomParameters'](_0x4157ac){return this['customParameters']=_0x4157ac,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0xb28df8){return this['scopes']['includes'](_0xb28df8)||this['scopes']['push'](_0xb28df8),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x257f74){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x257f74});}static['credentialFromResult'](_0x5c316a){return he['credentialFromTaggedObject'](_0x5c316a);}static['credentialFromError'](_0x43f63){return he['credentialFromTaggedObject'](_0x43f63['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2e1648}){if(!_0x2e1648||!('oauthAccessToken'in _0x2e1648)||!_0x2e1648['oauthAccessToken'])return null;try{return he['credential'](_0x2e1648['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x124a5a,_0xeb9ff9){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x124a5a,'accessToken':_0xeb9ff9});}static['credentialFromResult'](_0x3afce1){return ue['credentialFromTaggedObject'](_0x3afce1);}static['credentialFromError'](_0x36959e){return ue['credentialFromTaggedObject'](_0x36959e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5345ab}){if(!_0x5345ab)return null;const {oauthIdToken:_0x5da15e,oauthAccessToken:_0x459b55}=_0x5345ab;if(!_0x5da15e&&!_0x459b55)return null;try{return ue['credential'](_0x5da15e,_0x459b55);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x4e9bf0){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x4e9bf0});}static['credentialFromResult'](_0xb42fe7){return de['credentialFromTaggedObject'](_0xb42fe7);}static['credentialFromError'](_0x276700){return de['credentialFromTaggedObject'](_0x276700['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xc56e37}){if(!_0xc56e37||!('oauthAccessToken'in _0xc56e37)||!_0xc56e37['oauthAccessToken'])return null;try{return de['credential'](_0xc56e37['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x586f00,_0x57cbbc){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x586f00,'oauthTokenSecret':_0x57cbbc});}static['credentialFromResult'](_0x56767c){return fe['credentialFromTaggedObject'](_0x56767c);}static['credentialFromError'](_0x3da9fd){return fe['credentialFromTaggedObject'](_0x3da9fd['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5ef8f0}){if(!_0x5ef8f0)return null;const {oauthAccessToken:_0x469095,oauthTokenSecret:_0x1448c7}=_0x5ef8f0;if(!_0x469095||!_0x1448c7)return null;try{return fe['credential'](_0x469095,_0x1448c7);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x1a88d6,_0x43466f){return Qt(_0x1a88d6,'POST','/v1/accounts:signUp',Re(_0x1a88d6,_0x43466f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x13544a){this['user']=_0x13544a['user'],this['providerId']=_0x13544a['providerId'],this['_tokenResponse']=_0x13544a['_tokenResponse'],this['operationType']=_0x13544a['operationType'];}static async['_fromIdTokenResponse'](_0x5c2f58,_0x4e6756,_0x90e118,_0x50e5a9=!0x1){const _0x7e52fc=await K['_fromIdTokenResponse'](_0x5c2f58,_0x90e118,_0x50e5a9),_0x5def68=Nr(_0x90e118);return new Ve({'user':_0x7e52fc,'providerId':_0x5def68,'_tokenResponse':_0x90e118,'operationType':_0x4e6756});}static async['_forOperation'](_0x34cd61,_0x2c7904,_0x3e1485){await _0x34cd61['_updateTokensIfNecessary'](_0x3e1485,!0x0);const _0x1c8f44=Nr(_0x3e1485);return new Ve({'user':_0x34cd61,'providerId':_0x1c8f44,'_tokenResponse':_0x3e1485,'operationType':_0x2c7904});}}function Nr(_0x2320d5){return _0x2320d5['providerId']?_0x2320d5['providerId']:'phoneNumber'in _0x2320d5?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x5a41bf,_0x1ad5f0,_0x269845,_0xc9b6b5){super(_0x1ad5f0['code'],_0x1ad5f0['message']),this['operationType']=_0x269845,this['user']=_0xc9b6b5,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x5a41bf['name'],'tenantId':_0x5a41bf['tenantId']??void 0x0,'_serverResponse':_0x1ad5f0['customData']['_serverResponse'],'operationType':_0x269845};}static['_fromErrorAndOperation'](_0x44a1c5,_0x5ab111,_0x5739d4,_0x2f521d){return new An(_0x44a1c5,_0x5ab111,_0x5739d4,_0x2f521d);}}function Ba(_0xfae08,_0x412c01,_0x3d7f61,_0x59360a){return(_0x412c01==='reauthenticate'?_0x3d7f61['_getReauthenticationResolver'](_0xfae08):_0x3d7f61['_getIdTokenResponse'](_0xfae08))['catch'](_0x67c223=>{throw _0x67c223['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0xfae08,_0x67c223,_0x412c01,_0x59360a):_0x67c223;});}async function Jf(_0x99656,_0x552245,_0x454925=!0x1){const _0x1e09ac=await Ut(_0x99656,_0x552245['_linkToIdToken'](_0x99656['auth'],await _0x99656['getIdToken']()),_0x454925);return Ve['_forOperation'](_0x99656,'link',_0x1e09ac);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x1b91c0,_0x39eb82,_0x2e75e9=!0x1){const {auth:_0xd8925f}=_0x1b91c0;if($(_0xd8925f['app']))return Promise['reject'](re(_0xd8925f));const _0xf5bb47='reauthenticate';try{const _0xfd311a=await Ut(_0x1b91c0,Ba(_0xd8925f,_0xf5bb47,_0x39eb82,_0x1b91c0),_0x2e75e9);m(_0xfd311a['idToken'],_0xd8925f,'internal-error');const _0x148faf=Ts(_0xfd311a['idToken']);m(_0x148faf,_0xd8925f,'internal-error');const {sub:_0x7bd813}=_0x148faf;return m(_0x1b91c0['uid']===_0x7bd813,_0xd8925f,'user-mismatch'),Ve['_forOperation'](_0x1b91c0,_0xf5bb47,_0xfd311a);}catch(_0x9a8562){throw(_0x9a8562==null?void 0x0:_0x9a8562['code'])==='auth/user-not-found'&&Q(_0xd8925f,'user-mismatch'),_0x9a8562;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x4556be,_0x40a60a,_0x151d29=!0x1){if($(_0x4556be['app']))return Promise['reject'](re(_0x4556be));const _0x2a1894='signIn',_0x28c3d6=await Ba(_0x4556be,_0x2a1894,_0x40a60a),_0x17d6ee=await Ve['_fromIdTokenResponse'](_0x4556be,_0x2a1894,_0x28c3d6);return _0x151d29||await _0x4556be['_updateCurrentUser'](_0x17d6ee['user']),_0x17d6ee;}async function Zf(_0x54f570,_0x55b299){return Va(qe(_0x54f570),_0x55b299);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x144fc3){const _0x4ecc38=qe(_0x144fc3);_0x4ecc38['_getPasswordPolicyInternal']()&&await _0x4ecc38['_updatePasswordPolicy']();}async function P_(_0x2c7bf9,_0x48ca8f,_0x17c04d){if($(_0x2c7bf9['app']))return Promise['reject'](re(_0x2c7bf9));const _0x23994b=qe(_0x2c7bf9),_0x1b1aae=await Di(_0x23994b,{'returnSecureToken':!0x0,'email':_0x48ca8f,'password':_0x17c04d,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x3e1010=>{throw _0x3e1010['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x2c7bf9),_0x3e1010;}),_0x5ca659=await Ve['_fromIdTokenResponse'](_0x23994b,'signIn',_0x1b1aae);return await _0x23994b['_updateCurrentUser'](_0x5ca659['user']),_0x5ca659;}function O_(_0x531e31,_0x50aecb,_0x6a66e4){return $(_0x531e31['app'])?Promise['reject'](re(_0x531e31)):Zf(N(_0x531e31),pt['credential'](_0x50aecb,_0x6a66e4))['catch'](async _0x42f658=>{throw _0x42f658['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x531e31),_0x42f658;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x4626aa,_0x43137d){return N(_0x4626aa)['setPersistence'](_0x43137d);}function ep(_0x2b1d0c,_0x331109,_0x153025,_0x3eb310){return N(_0x2b1d0c)['onIdTokenChanged'](_0x331109,_0x153025,_0x3eb310);}function tp(_0x2e7c72,_0x5cb94a,_0x6fea21){return N(_0x2e7c72)['beforeAuthStateChanged'](_0x5cb94a,_0x6fea21);}function M_(_0x3170e2,_0x13e749,_0x16cb3f,_0xd0e92c){return N(_0x3170e2)['onAuthStateChanged'](_0x13e749,_0x16cb3f,_0xd0e92c);}function L_(_0x1a4243){return N(_0x1a4243)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x3ecf64,_0x2845a7){this['storageRetriever']=_0x3ecf64,this['type']=_0x2845a7;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x7c15db,_0x1d7198){return this['storage']['setItem'](_0x7c15db,JSON['stringify'](_0x1d7198)),Promise['resolve']();}['_get'](_0x44b500){const _0x3fb71=this['storage']['getItem'](_0x44b500);return Promise['resolve'](_0x3fb71?JSON['parse'](_0x3fb71):null);}['_remove'](_0x1b3568){return this['storage']['removeItem'](_0x1b3568),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x37599a,_0xb18e35)=>this['onStorageEvent'](_0x37599a,_0xb18e35),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x2736cc){for(const _0x389bdd of Object['keys'](this['listeners'])){const _0x5d12f1=this['storage']['getItem'](_0x389bdd),_0x2a14cb=this['localCache'][_0x389bdd];_0x5d12f1!==_0x2a14cb&&_0x2736cc(_0x389bdd,_0x2a14cb,_0x5d12f1);}}['onStorageEvent'](_0x4422b9,_0x4f4cb3=!0x1){if(!_0x4422b9['key']){this['forAllChangedKeys']((_0x522d6c,_0x2e3496,_0x40d602)=>{this['notifyListeners'](_0x522d6c,_0x40d602);});return;}const _0x11fc9b=_0x4422b9['key'];_0x4f4cb3?this['detachListener']():this['stopPolling']();const _0x46889d=()=>{const _0x3c8992=this['storage']['getItem'](_0x11fc9b);!_0x4f4cb3&&this['localCache'][_0x11fc9b]===_0x3c8992||this['notifyListeners'](_0x11fc9b,_0x3c8992);},_0x1e9d95=this['storage']['getItem'](_0x11fc9b);Tf()&&_0x1e9d95!==_0x4422b9['newValue']&&_0x4422b9['newValue']!==_0x4422b9['oldValue']?setTimeout(_0x46889d,ip):_0x46889d();}['notifyListeners'](_0xda0ebe,_0x32ad08){this['localCache'][_0xda0ebe]=_0x32ad08;const _0x73fa80=this['listeners'][_0xda0ebe];if(_0x73fa80){for(const _0x374418 of Array['from'](_0x73fa80))_0x374418(_0x32ad08&&JSON['parse'](_0x32ad08));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x6ac2bf,_0xed2943,_0x4d6f95)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x6ac2bf,'oldValue':_0xed2943,'newValue':_0x4d6f95}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x25889b,_0x19ed0a){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x25889b]||(this['listeners'][_0x25889b]=new Set(),this['localCache'][_0x25889b]=this['storage']['getItem'](_0x25889b)),this['listeners'][_0x25889b]['add'](_0x19ed0a);}['_removeListener'](_0xc0b8ad,_0x47389c){this['listeners'][_0xc0b8ad]&&(this['listeners'][_0xc0b8ad]['delete'](_0x47389c),this['listeners'][_0xc0b8ad]['size']===0x0&&delete this['listeners'][_0xc0b8ad]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x5319b6,_0x2d107d){await super['_set'](_0x5319b6,_0x2d107d),this['localCache'][_0x5319b6]=JSON['stringify'](_0x2d107d);}async['_get'](_0x1c54ba){const _0x512040=await super['_get'](_0x1c54ba);return this['localCache'][_0x1c54ba]=JSON['stringify'](_0x512040),_0x512040;}async['_remove'](_0x59fa52){await super['_remove'](_0x59fa52),delete this['localCache'][_0x59fa52];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x3ee7e1,_0x468ff3){}['_removeListener'](_0xf5494d,_0x4b4b4b){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x1c7a32){return Promise['all'](_0x1c7a32['map'](async _0x528d1c=>{try{return{'fulfilled':!0x0,'value':await _0x528d1c};}catch(_0x58c9dc){return{'fulfilled':!0x1,'reason':_0x58c9dc};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x250e23){this['eventTarget']=_0x250e23,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x1fbc74){const _0x23ffe2=this['receivers']['find'](_0x56cfd0=>_0x56cfd0['isListeningto'](_0x1fbc74));if(_0x23ffe2)return _0x23ffe2;const _0x353285=new Kn(_0x1fbc74);return this['receivers']['push'](_0x353285),_0x353285;}['isListeningto'](_0x406b75){return this['eventTarget']===_0x406b75;}async['handleEvent'](_0x25f771){const _0x24ab8b=_0x25f771,{eventId:_0x244067,eventType:_0x4cd449,data:_0x451775}=_0x24ab8b['data'],_0xf36848=this['handlersMap'][_0x4cd449];if(!(_0xf36848!=null&&_0xf36848['size']))return;_0x24ab8b['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x244067,'eventType':_0x4cd449});const _0x453374=Array['from'](_0xf36848)['map'](async _0x26b6f3=>_0x26b6f3(_0x24ab8b['origin'],_0x451775)),_0x342c75=await rp(_0x453374);_0x24ab8b['ports'][0x0]['postMessage']({'status':'done','eventId':_0x244067,'eventType':_0x4cd449,'response':_0x342c75});}['_subscribe'](_0x557ffc,_0x578e57){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x557ffc]||(this['handlersMap'][_0x557ffc]=new Set()),this['handlersMap'][_0x557ffc]['add'](_0x578e57);}['_unsubscribe'](_0x53e184,_0x11d137){this['handlersMap'][_0x53e184]&&_0x11d137&&this['handlersMap'][_0x53e184]['delete'](_0x11d137),(!_0x11d137||this['handlersMap'][_0x53e184]['size']===0x0)&&delete this['handlersMap'][_0x53e184],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x7975ee='',_0x4557c4=0xa){let _0x108527='';for(let _0x5ab909=0x0;_0x5ab909<_0x4557c4;_0x5ab909++)_0x108527+=Math['floor'](Math['random']()*0xa);return _0x7975ee+_0x108527;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x4e6a9e){this['target']=_0x4e6a9e,this['handlers']=new Set();}['removeMessageHandler'](_0x2113f7){_0x2113f7['messageChannel']&&(_0x2113f7['messageChannel']['port1']['removeEventListener']('message',_0x2113f7['onMessage']),_0x2113f7['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x2113f7);}async['_send'](_0xaa63c8,_0x30f630,_0x5ccfdc=0x32){const _0x32f5ee=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x32f5ee)throw new Error('connection_unavailable');let _0x516ece,_0x2b7d30;return new Promise((_0x48ac1f,_0x430c79)=>{const _0x5abfdf=As('',0x14);_0x32f5ee['port1']['start']();const _0x5c9914=setTimeout(()=>{_0x430c79(new Error('unsupported_event'));},_0x5ccfdc);_0x2b7d30={'messageChannel':_0x32f5ee,'onMessage'(_0x31fe9f){const _0x48ccb2=_0x31fe9f;if(_0x48ccb2['data']['eventId']===_0x5abfdf)switch(_0x48ccb2['data']['status']){case'ack':clearTimeout(_0x5c9914),_0x516ece=setTimeout(()=>{_0x430c79(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x516ece),_0x48ac1f(_0x48ccb2['data']['response']);break;default:clearTimeout(_0x5c9914),clearTimeout(_0x516ece),_0x430c79(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x2b7d30),_0x32f5ee['port1']['addEventListener']('message',_0x2b7d30['onMessage']),this['target']['postMessage']({'eventType':_0xaa63c8,'eventId':_0x5abfdf,'data':_0x30f630},[_0x32f5ee['port2']]);})['finally'](()=>{_0x2b7d30&&this['removeMessageHandler'](_0x2b7d30);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x16fba9){Z()['location']['href']=_0x16fba9;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x56e181;return((_0x56e181=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x56e181['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x33dae4){this['request']=_0x33dae4;}['toPromise'](){return new Promise((_0x35e131,_0x1ae1c2)=>{this['request']['addEventListener']('success',()=>{_0x35e131(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x1ae1c2(this['request']['error']);});});}}function Yn(_0x5d7280,_0x5e3931){return _0x5d7280['transaction']([Nn],_0x5e3931?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x347467=indexedDB['deleteDatabase'](Ka);return new Xt(_0x347467)['toPromise']();}function Mi(){const _0x3769bd=indexedDB['open'](Ka,up);return new Promise((_0xba2d49,_0x51c5c3)=>{_0x3769bd['addEventListener']('error',()=>{_0x51c5c3(_0x3769bd['error']);}),_0x3769bd['addEventListener']('upgradeneeded',()=>{const _0x5c8c11=_0x3769bd['result'];try{_0x5c8c11['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x4147f8){_0x51c5c3(_0x4147f8);}}),_0x3769bd['addEventListener']('success',async()=>{const _0x1b593b=_0x3769bd['result'];_0x1b593b['objectStoreNames']['contains'](Nn)?_0xba2d49(_0x1b593b):(_0x1b593b['close'](),await dp(),_0xba2d49(await Mi()));});});}async function Pr(_0x43abdc,_0x288198,_0x51b9a5){const _0x47beba=Yn(_0x43abdc,!0x0)['put']({[Ya]:_0x288198,'value':_0x51b9a5});return new Xt(_0x47beba)['toPromise']();}async function fp(_0x2e7565,_0x46d679){const _0x5273e6=Yn(_0x2e7565,!0x1)['get'](_0x46d679),_0x34bfba=await new Xt(_0x5273e6)['toPromise']();return _0x34bfba===void 0x0?null:_0x34bfba['value'];}function Or(_0x44ebc7,_0x2f8caf){const _0x4a0cf3=Yn(_0x44ebc7,!0x0)['delete'](_0x2f8caf);return new Xt(_0x4a0cf3)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x259e67){let _0x73281=0x0;for(;;)try{const _0x19bbf0=await this['_openDb']();return await _0x259e67(_0x19bbf0);}catch(_0x2bbd11){if(_0x73281++>_p)throw _0x2bbd11;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x219b86,_0x3f0b1a)=>({'keyProcessed':(await this['_poll']())['includes'](_0x3f0b1a['key'])})),this['receiver']['_subscribe']('ping',async(_0xadb7f1,_0x4ab327)=>['keyChanged']);}async['initializeSender'](){var _0x305cdc,_0x26dc61;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x1112cd=await this['sender']['_send']('ping',{},0x320);_0x1112cd&&(_0x305cdc=_0x1112cd[0x0])!=null&&_0x305cdc['fulfilled']&&(_0x26dc61=_0x1112cd[0x0])!=null&&_0x26dc61['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x1314f2){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x1314f2},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x496f11=await Mi();return await Pr(_0x496f11,kn,'1'),await Or(_0x496f11,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x49d4b1){this['pendingWrites']++;try{await _0x49d4b1();}finally{this['pendingWrites']--;}}async['_set'](_0x5ab786,_0x471a36){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4e9c20=>Pr(_0x4e9c20,_0x5ab786,_0x471a36)),this['localCache'][_0x5ab786]=_0x471a36,this['notifyServiceWorker'](_0x5ab786)));}async['_get'](_0xe57e4e){const _0x5ec28a=await this['_withRetries'](_0x6927e2=>fp(_0x6927e2,_0xe57e4e));return this['localCache'][_0xe57e4e]=_0x5ec28a,_0x5ec28a;}async['_remove'](_0x377eb9){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4884ed=>Or(_0x4884ed,_0x377eb9)),delete this['localCache'][_0x377eb9],this['notifyServiceWorker'](_0x377eb9)));}async['_poll'](){const _0x3815cf=await this['_withRetries'](_0xb7693f=>{const _0x5de8bf=Yn(_0xb7693f,!0x1)['getAll']();return new Xt(_0x5de8bf)['toPromise']();});if(!_0x3815cf)return[];if(this['pendingWrites']!==0x0)return[];const _0x37b147=[],_0x18dcfb=new Set();if(_0x3815cf['length']!==0x0){for(const {fbase_key:_0x46ce00,value:_0x37c5f7}of _0x3815cf)_0x18dcfb['add'](_0x46ce00),JSON['stringify'](this['localCache'][_0x46ce00])!==JSON['stringify'](_0x37c5f7)&&(this['notifyListeners'](_0x46ce00,_0x37c5f7),_0x37b147['push'](_0x46ce00));}for(const _0x219a16 of Object['keys'](this['localCache']))this['localCache'][_0x219a16]&&!_0x18dcfb['has'](_0x219a16)&&(this['notifyListeners'](_0x219a16,null),_0x37b147['push'](_0x219a16));return _0x37b147;}['notifyListeners'](_0x3c48ed,_0x14806c){this['localCache'][_0x3c48ed]=_0x14806c;const _0x333e33=this['listeners'][_0x3c48ed];if(_0x333e33){for(const _0xf1dbbb of Array['from'](_0x333e33))_0xf1dbbb(_0x14806c);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x4b4dca,_0x5c39c9){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x4b4dca]||(this['listeners'][_0x4b4dca]=new Set(),this['_get'](_0x4b4dca)),this['listeners'][_0x4b4dca]['add'](_0x5c39c9);}['_removeListener'](_0x298b25,_0x49527f){this['listeners'][_0x298b25]&&(this['listeners'][_0x298b25]['delete'](_0x49527f),this['listeners'][_0x298b25]['size']===0x0&&delete this['listeners'][_0x298b25]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x2c2c54,_0xe2b7b0){return _0xe2b7b0?ie(_0xe2b7b0):(m(_0x2c2c54['_popupRedirectResolver'],_0x2c2c54,'argument-error'),_0x2c2c54['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x3a0a43){super('custom','custom'),this['params']=_0x3a0a43;}['_getIdTokenResponse'](_0x4e74cf){return Xe(_0x4e74cf,this['_buildIdpRequest']());}['_linkToIdToken'](_0x16c533,_0x44a816){return Xe(_0x16c533,this['_buildIdpRequest'](_0x44a816));}['_getReauthenticationResolver'](_0x101b26){return Xe(_0x101b26,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x546e5a){const _0x2e8c3a={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x546e5a&&(_0x2e8c3a['idToken']=_0x546e5a),_0x2e8c3a;}}function yp(_0x3282df){return Va(_0x3282df['auth'],new ks(_0x3282df),_0x3282df['bypassAuthState']);}function vp(_0x439936){const {auth:_0x51db57,user:_0x2a7ae2}=_0x439936;return m(_0x2a7ae2,_0x51db57,'internal-error'),Xf(_0x2a7ae2,new ks(_0x439936),_0x439936['bypassAuthState']);}async function Ep(_0x1fa817){const {auth:_0x1f1184,user:_0x1ee3b1}=_0x1fa817;return m(_0x1ee3b1,_0x1f1184,'internal-error'),Jf(_0x1ee3b1,new ks(_0x1fa817),_0x1fa817['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x1a1003,_0x4439ea,_0x371516,_0x2b5071,_0x514ed3=!0x1){this['auth']=_0x1a1003,this['resolver']=_0x371516,this['user']=_0x2b5071,this['bypassAuthState']=_0x514ed3,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x4439ea)?_0x4439ea:[_0x4439ea];}['execute'](){return new Promise(async(_0x5a4794,_0x451b65)=>{this['pendingPromise']={'resolve':_0x5a4794,'reject':_0x451b65};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x74512f){this['reject'](_0x74512f);}});}async['onAuthEvent'](_0x4aafa5){const {urlResponse:_0x371d4e,sessionId:_0x24ab13,postBody:_0x36a3e6,tenantId:_0x3dc541,error:_0x5f49bf,type:_0x593a2a}=_0x4aafa5;if(_0x5f49bf){this['reject'](_0x5f49bf);return;}const _0x2d5b1b={'auth':this['auth'],'requestUri':_0x371d4e,'sessionId':_0x24ab13,'tenantId':_0x3dc541||void 0x0,'postBody':_0x36a3e6||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x593a2a)(_0x2d5b1b));}catch(_0x187347){this['reject'](_0x187347);}}['onError'](_0x468c56){this['reject'](_0x468c56);}['getIdpTask'](_0x53771b){switch(_0x53771b){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x174f7a){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x174f7a),this['unregisterAndCleanUp']();}['reject'](_0x281193){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x281193),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x10217a,_0x3c9171,_0x2f3783,_0x342aec,_0x373325){super(_0x10217a,_0x3c9171,_0x342aec,_0x373325),this['provider']=_0x2f3783,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x3c6d11=await this['execute']();return m(_0x3c6d11,this['auth'],'internal-error'),_0x3c6d11;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x1b92cb=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x1b92cb),this['authWindow']['associatedEvent']=_0x1b92cb,this['resolver']['_originValidation'](this['auth'])['catch'](_0x4bb003=>{this['reject'](_0x4bb003);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x131811=>{_0x131811||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x2307b2;return((_0x2307b2=this['authWindow'])==null?void 0x0:_0x2307b2['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x4168e8=()=>{var _0x133b0f,_0x4ae1f8;if((_0x4ae1f8=(_0x133b0f=this['authWindow'])==null?void 0x0:_0x133b0f['window'])!=null&&_0x4ae1f8['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x4168e8,Ip['get']());};_0x4168e8();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x4dd9d6,_0x49ffc6,_0x5d6f1d=!0x1){super(_0x4dd9d6,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x49ffc6,void 0x0,_0x5d6f1d),this['eventId']=null;}async['execute'](){let _0x46b7b7=on['get'](this['auth']['_key']());if(!_0x46b7b7){try{const _0x149f02=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x46b7b7=()=>Promise['resolve'](_0x149f02);}catch(_0x335801){_0x46b7b7=()=>Promise['reject'](_0x335801);}on['set'](this['auth']['_key'](),_0x46b7b7);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x46b7b7();}async['onAuthEvent'](_0x5d6dab){if(_0x5d6dab['type']==='signInViaRedirect')return super['onAuthEvent'](_0x5d6dab);if(_0x5d6dab['type']==='unknown'){this['resolve'](null);return;}if(_0x5d6dab['eventId']){const _0x2d6637=await this['auth']['_redirectUserForId'](_0x5d6dab['eventId']);if(_0x2d6637)return this['user']=_0x2d6637,super['onAuthEvent'](_0x5d6dab);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x69c6c3,_0x2c3220){const _0x52cdb9=Rp(_0x2c3220),_0xbbf5d=bp(_0x69c6c3);if(!await _0xbbf5d['_isAvailable']())return!0x1;const _0x41a3d1=await _0xbbf5d['_get'](_0x52cdb9)==='true';return await _0xbbf5d['_remove'](_0x52cdb9),_0x41a3d1;}function Sp(_0x4ff93f,_0x43e3e7){on['set'](_0x4ff93f['_key'](),_0x43e3e7);}function bp(_0x4b2c2e){return ie(_0x4b2c2e['_redirectPersistence']);}function Rp(_0x4e69bc){return rn(wp,_0x4e69bc['config']['apiKey'],_0x4e69bc['name']);}async function Ap(_0x48b99f,_0x1e9a76,_0x4e0e34=!0x1){if($(_0x48b99f['app']))return Promise['reject'](re(_0x48b99f));const _0x164d5b=qe(_0x48b99f),_0xf2ddaf=mp(_0x164d5b,_0x1e9a76),_0x121ae2=await new Cp(_0x164d5b,_0xf2ddaf,_0x4e0e34)['execute']();return _0x121ae2&&!_0x4e0e34&&(delete _0x121ae2['user']['_redirectEventId'],await _0x164d5b['_persistUserIfCurrent'](_0x121ae2['user']),await _0x164d5b['_setRedirectUser'](null,_0x1e9a76)),_0x121ae2;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x14b34b){this['auth']=_0x14b34b,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0xb43b2a){this['consumers']['add'](_0xb43b2a),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0xb43b2a)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0xb43b2a),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x184ab6){this['consumers']['delete'](_0x184ab6);}['onEvent'](_0x5924da){if(this['hasEventBeenHandled'](_0x5924da))return!0x1;let _0x343dac=!0x1;return this['consumers']['forEach'](_0x243b26=>{this['isEventForConsumer'](_0x5924da,_0x243b26)&&(_0x343dac=!0x0,this['sendToConsumer'](_0x5924da,_0x243b26),this['saveEventToCache'](_0x5924da));}),this['hasHandledPotentialRedirect']||!Pp(_0x5924da)||(this['hasHandledPotentialRedirect']=!0x0,_0x343dac||(this['queuedRedirectEvent']=_0x5924da,_0x343dac=!0x0)),_0x343dac;}['sendToConsumer'](_0x5eaae5,_0x49763a){var _0x1408d6;if(_0x5eaae5['error']&&!Xa(_0x5eaae5)){const _0x43b91a=((_0x1408d6=_0x5eaae5['error']['code'])==null?void 0x0:_0x1408d6['split']('auth/')[0x1])||'internal-error';_0x49763a['onError'](X(this['auth'],_0x43b91a));}else _0x49763a['onAuthEvent'](_0x5eaae5);}['isEventForConsumer'](_0x4b54cb,_0x528df7){const _0x46f9d4=_0x528df7['eventId']===null||!!_0x4b54cb['eventId']&&_0x4b54cb['eventId']===_0x528df7['eventId'];return _0x528df7['filter']['includes'](_0x4b54cb['type'])&&_0x46f9d4;}['hasEventBeenHandled'](_0x4157b8){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x4157b8));}['saveEventToCache'](_0x2f8f49){this['cachedEventUids']['add'](Dr(_0x2f8f49)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x499739){return[_0x499739['type'],_0x499739['eventId'],_0x499739['sessionId'],_0x499739['tenantId']]['filter'](_0xe31f1a=>_0xe31f1a)['join']('-');}function Xa({type:_0xca90ee,error:_0x41c06d}){return _0xca90ee==='unknown'&&(_0x41c06d==null?void 0x0:_0x41c06d['code'])==='auth/no-auth-event';}function Pp(_0x1f81ac){switch(_0x1f81ac['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x1f81ac);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x3b514d,_0x4d2685={}){return Ae(_0x3b514d,'GET','/v1/projects',_0x4d2685);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x5bf0b9){if(_0x5bf0b9['config']['emulator'])return;const {authorizedDomains:_0xb8efb1}=await Op(_0x5bf0b9);for(const _0x53f33e of _0xb8efb1)try{if(xp(_0x53f33e))return;}catch{}Q(_0x5bf0b9,'unauthorized-domain');}function xp(_0x2eb266){const _0x39bba1=Pi(),{protocol:_0x4fc05a,hostname:_0x31df05}=new URL(_0x39bba1);if(_0x2eb266['startsWith']('chrome-extension://')){const _0x2e0f5d=new URL(_0x2eb266);return _0x2e0f5d['hostname']===''&&_0x31df05===''?_0x4fc05a==='chrome-extension:'&&_0x2eb266['replace']('chrome-extension://','')===_0x39bba1['replace']('chrome-extension://',''):_0x4fc05a==='chrome-extension:'&&_0x2e0f5d['hostname']===_0x31df05;}if(!Mp['test'](_0x4fc05a))return!0x1;if(Dp['test'](_0x2eb266))return _0x31df05===_0x2eb266;const _0x5b31a6=_0x2eb266['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x5b31a6+'|'+_0x5b31a6+')$','i')['test'](_0x31df05);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x2a9823=Z()['___jsl'];if(_0x2a9823!=null&&_0x2a9823['H']){for(const _0x30a497 of Object['keys'](_0x2a9823['H']))if(_0x2a9823['H'][_0x30a497]['r']=_0x2a9823['H'][_0x30a497]['r']||[],_0x2a9823['H'][_0x30a497]['L']=_0x2a9823['H'][_0x30a497]['L']||[],_0x2a9823['H'][_0x30a497]['r']=[..._0x2a9823['H'][_0x30a497]['L']],_0x2a9823['CP']){for(let _0xece13a=0x0;_0xece13a<_0x2a9823['CP']['length'];_0xece13a++)_0x2a9823['CP'][_0xece13a]=null;}}}function Up(_0x11b69c){return new Promise((_0xf9b021,_0x528a9b)=>{var _0xc92be5,_0x1f7dea,_0x48e068;function _0xa18bfe(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0xf9b021(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x528a9b(X(_0x11b69c,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x1f7dea=(_0xc92be5=Z()['gapi'])==null?void 0x0:_0xc92be5['iframes'])!=null&&_0x1f7dea['Iframe'])_0xf9b021(gapi['iframes']['getContext']());else{if((_0x48e068=Z()['gapi'])!=null&&_0x48e068['load'])_0xa18bfe();else{const _0x591cdb=Df('iframefcb');return Z()[_0x591cdb]=()=>{gapi['load']?_0xa18bfe():_0x528a9b(X(_0x11b69c,'network-request-failed'));},xa(Of()+'?onload='+_0x591cdb)['catch'](_0x549d4a=>_0x528a9b(_0x549d4a));}}})['catch'](_0x3d334e=>{throw an=null,_0x3d334e;});}let an=null;function Wp(_0x520182){return an=an||Up(_0x520182),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x2760be){const _0x4521c1=_0x2760be['config'];m(_0x4521c1['authDomain'],_0x2760be,'auth-domain-config-required');const _0x29c0a7=_0x4521c1['emulator']?Cs(_0x4521c1,Hp):'https://'+_0x2760be['config']['authDomain']+'/'+Vp,_0x1b23ec={'apiKey':_0x4521c1['apiKey'],'appName':_0x2760be['name'],'v':lt},_0x245c25=Gp['get'](_0x2760be['config']['apiHost']);_0x245c25&&(_0x1b23ec['eid']=_0x245c25);const _0xd5ffd0=_0x2760be['_getFrameworks']();return _0xd5ffd0['length']&&(_0x1b23ec['fw']=_0xd5ffd0['join'](',')),_0x29c0a7+'?'+ct(_0x1b23ec)['slice'](0x1);}async function zp(_0x2bc634){const _0x3648a9=await Wp(_0x2bc634),_0x5dee55=Z()['gapi'];return m(_0x5dee55,_0x2bc634,'internal-error'),_0x3648a9['open']({'where':document['body'],'url':qp(_0x2bc634),'messageHandlersFilter':_0x5dee55['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x1e5790=>new Promise(async(_0x5e53e9,_0x231d59)=>{await _0x1e5790['restyle']({'setHideOnLeave':!0x1});const _0xa9a469=X(_0x2bc634,'network-request-failed'),_0x3ff0df=Z()['setTimeout'](()=>{_0x231d59(_0xa9a469);},Bp['get']());function _0x5cf73e(){Z()['clearTimeout'](_0x3ff0df),_0x5e53e9(_0x1e5790);}_0x1e5790['ping'](_0x5cf73e)['then'](_0x5cf73e,()=>{_0x231d59(_0xa9a469);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x1999cc){this['window']=_0x1999cc,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x482f13,_0x48ce4e,_0x446f01,_0x39400f=Kp,_0xf69cc2=Yp){const _0x3a6838=Math['max']((window['screen']['availHeight']-_0xf69cc2)/0x2,0x0)['toString'](),_0x2b8db9=Math['max']((window['screen']['availWidth']-_0x39400f)/0x2,0x0)['toString']();let _0x579c61='';const _0x2de4b5={...jp,'width':_0x39400f['toString'](),'height':_0xf69cc2['toString'](),'top':_0x3a6838,'left':_0x2b8db9},_0x39ba73=W()['toLowerCase']();_0x446f01&&(_0x579c61=ka(_0x39ba73)?Qp:_0x446f01),Ra(_0x39ba73)&&(_0x48ce4e=_0x48ce4e||Jp,_0x2de4b5['scrollbars']='yes');const _0x36324c=Object['entries'](_0x2de4b5)['reduce']((_0x2c5071,[_0x3f779a,_0x6fde8a])=>''+_0x2c5071+_0x3f779a+'='+_0x6fde8a+',','');if(Cf(_0x39ba73)&&_0x579c61!=='_self')return Zp(_0x48ce4e||'',_0x579c61),new Lr(null);const _0x1dfb22=window['open'](_0x48ce4e||'',_0x579c61,_0x36324c);m(_0x1dfb22,_0x482f13,'popup-blocked');try{_0x1dfb22['focus']();}catch{}return new Lr(_0x1dfb22);}function Zp(_0x36aabc,_0x2f3abd){const _0x49da09=document['createElement']('a');_0x49da09['href']=_0x36aabc,_0x49da09['target']=_0x2f3abd;const _0xbd1a6f=document['createEvent']('MouseEvent');_0xbd1a6f['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x49da09['dispatchEvent'](_0xbd1a6f);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x1de917,_0x2bb6f1,_0x3d69eb,_0x5c2e5d,_0x2e4fe0,_0xbe7af8){m(_0x1de917['config']['authDomain'],_0x1de917,'auth-domain-config-required'),m(_0x1de917['config']['apiKey'],_0x1de917,'invalid-api-key');const _0x55313a={'apiKey':_0x1de917['config']['apiKey'],'appName':_0x1de917['name'],'authType':_0x3d69eb,'redirectUrl':_0x5c2e5d,'v':lt,'eventId':_0x2e4fe0};if(_0x2bb6f1 instanceof Wa){_0x2bb6f1['setDefaultLanguage'](_0x1de917['languageCode']),_0x55313a['providerId']=_0x2bb6f1['providerId']||'',ui(_0x2bb6f1['getCustomParameters']())||(_0x55313a['customParameters']=JSON['stringify'](_0x2bb6f1['getCustomParameters']()));for(const [_0x29b964,_0x331b53]of Object['entries']({}))_0x55313a[_0x29b964]=_0x331b53;}if(_0x2bb6f1 instanceof Jt){const _0xd533b1=_0x2bb6f1['getScopes']()['filter'](_0x809dfe=>_0x809dfe!=='');_0xd533b1['length']>0x0&&(_0x55313a['scopes']=_0xd533b1['join'](','));}_0x1de917['tenantId']&&(_0x55313a['tid']=_0x1de917['tenantId']);const _0x49aa4c=_0x55313a;for(const _0x102feb of Object['keys'](_0x49aa4c))_0x49aa4c[_0x102feb]===void 0x0&&delete _0x49aa4c[_0x102feb];const _0x5b3b38=await _0x1de917['_getAppCheckToken'](),_0x211027=_0x5b3b38?'#'+n_+'='+encodeURIComponent(_0x5b3b38):'';return i_(_0x1de917)+'?'+ct(_0x49aa4c)['slice'](0x1)+_0x211027;}function i_({config:_0x1ef7cf}){return _0x1ef7cf['emulator']?Cs(_0x1ef7cf,t_):'https://'+_0x1ef7cf['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x3fb964,_0x196518,_0x282f57,_0x106a06){var _0x273eb5;ce((_0x273eb5=this['eventManagers'][_0x3fb964['_key']()])==null?void 0x0:_0x273eb5['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x2733b8=await xr(_0x3fb964,_0x196518,_0x282f57,Pi(),_0x106a06);return Xp(_0x3fb964,_0x2733b8,As());}async['_openRedirect'](_0x3fdc00,_0x465ee6,_0x877b6d,_0xd03467){await this['_originValidation'](_0x3fdc00);const _0x455e80=await xr(_0x3fdc00,_0x465ee6,_0x877b6d,Pi(),_0xd03467);return ap(_0x455e80),new Promise(()=>{});}['_initialize'](_0xc2911a){const _0x47ea89=_0xc2911a['_key']();if(this['eventManagers'][_0x47ea89]){const {manager:_0x420f4c,promise:_0x41353b}=this['eventManagers'][_0x47ea89];return _0x420f4c?Promise['resolve'](_0x420f4c):(ce(_0x41353b,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x41353b);}const _0xac4c91=this['initAndGetManager'](_0xc2911a);return this['eventManagers'][_0x47ea89]={'promise':_0xac4c91},_0xac4c91['catch'](()=>{delete this['eventManagers'][_0x47ea89];}),_0xac4c91;}async['initAndGetManager'](_0x23ad60){const _0x47c4a1=await zp(_0x23ad60),_0x3e705f=new Np(_0x23ad60);return _0x47c4a1['register']('authEvent',_0x3fa39b=>(m(_0x3fa39b==null?void 0x0:_0x3fa39b['authEvent'],_0x23ad60,'invalid-auth-event'),{'status':_0x3e705f['onEvent'](_0x3fa39b['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x23ad60['_key']()]={'manager':_0x3e705f},this['iframes'][_0x23ad60['_key']()]=_0x47c4a1,_0x3e705f;}['_isIframeWebStorageSupported'](_0x553ac2,_0x262a9c){this['iframes'][_0x553ac2['_key']()]['send'](hi,{'type':hi},_0x1432cd=>{var _0x16c459;const _0x14a26e=(_0x16c459=_0x1432cd==null?void 0x0:_0x1432cd[0x0])==null?void 0x0:_0x16c459[hi];_0x14a26e!==void 0x0&&_0x262a9c(!!_0x14a26e),Q(_0x553ac2,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0xe63f75){const _0x12ff2c=_0xe63f75['_key']();return this['originValidationPromises'][_0x12ff2c]||(this['originValidationPromises'][_0x12ff2c]=Lp(_0xe63f75)),this['originValidationPromises'][_0x12ff2c];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x484668){this['auth']=_0x484668,this['internalListeners']=new Map();}['getUid'](){var _0x5584fc;return this['assertAuthConfigured'](),((_0x5584fc=this['auth']['currentUser'])==null?void 0x0:_0x5584fc['uid'])||null;}async['getToken'](_0x5c0cda){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x5c0cda)}:null;}['addAuthTokenListener'](_0x2abf67){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x2abf67))return;const _0x132cc2=this['auth']['onIdTokenChanged'](_0x2043d1=>{_0x2abf67((_0x2043d1==null?void 0x0:_0x2043d1['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x2abf67,_0x132cc2),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x12c52a){this['assertAuthConfigured']();const _0x9e9bbe=this['internalListeners']['get'](_0x12c52a);_0x9e9bbe&&(this['internalListeners']['delete'](_0x12c52a),_0x9e9bbe(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x339359){switch(_0x339359){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0xc853ae){Ze(new Le('auth',(_0x3968a8,{options:_0xcb4774})=>{const _0x2a858e=_0x3968a8['getProvider']('app')['getImmediate'](),_0x428362=_0x3968a8['getProvider']('heartbeat'),_0x23e8b9=_0x3968a8['getProvider']('app-check-internal'),{apiKey:_0x30513d,authDomain:_0x26d712}=_0x2a858e['options'];m(_0x30513d&&!_0x30513d['includes'](':'),'invalid-api-key',{'appName':_0x2a858e['name']});const _0x4fc3fe={'apiKey':_0x30513d,'authDomain':_0x26d712,'clientPlatform':_0xc853ae,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0xc853ae)},_0x215bb1=new kf(_0x2a858e,_0x428362,_0x23e8b9,_0x4fc3fe);return Wf(_0x215bb1,_0xcb4774),_0x215bb1;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x5c0b86,_0x3bb505,_0x52fd2f)=>{_0x5c0b86['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x5c12c0=>{const _0x182978=qe(_0x5c12c0['getProvider']('auth')['getImmediate']());return(_0x349e62=>new o_(_0x349e62))(_0x182978);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0xc853ae)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x22ba07=>async _0x232dde=>{const _0x303d71=_0x232dde&&await _0x232dde['getIdTokenResult'](),_0x1e1fb5=_0x303d71&&(new Date()['getTime']()-Date['parse'](_0x303d71['issuedAtTime']))/0x3e8;if(_0x1e1fb5&&_0x1e1fb5>h_)return;const _0x5c5a07=_0x303d71==null?void 0x0:_0x303d71['token'];Wr!==_0x5c5a07&&(Wr=_0x5c5a07,await fetch(_0x22ba07,{'method':_0x5c5a07?'POST':'DELETE','headers':_0x5c5a07?{'Authorization':'Bearer\x20'+_0x5c5a07}:{}}));};function x_(_0x233852=Zr()){const _0x4b227c=Bi(_0x233852,'auth');if(_0x4b227c['isInitialized']())return _0x4b227c['getImmediate']();const _0x3df99e=Uf(_0x233852,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x45c15a=zr('authTokenSyncURL');if(_0x45c15a&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x3e3cdc=new URL(_0x45c15a,location['origin']);if(location['origin']===_0x3e3cdc['origin']){const _0x4178b8=u_(_0x3e3cdc['toString']());tp(_0x3df99e,_0x4178b8,()=>_0x4178b8(_0x3df99e['currentUser'])),ep(_0x3df99e,_0x190444=>_0x4178b8(_0x190444));}}const _0x442b16=Gr('auth');return _0x442b16&&Bf(_0x3df99e,'http://'+_0x442b16),_0x3df99e;}function d_(){var _0x551200;return((_0x551200=document['getElementsByTagName']('head'))==null?void 0x0:_0x551200[0x0])??document;}Nf({'loadJS'(_0x20ea3a){return new Promise((_0x2e3897,_0xf11b6f)=>{const _0xb0e940=document['createElement']('script');_0xb0e940['setAttribute']('src',_0x20ea3a),_0xb0e940['onload']=_0x2e3897,_0xb0e940['onerror']=_0x5b2236=>{const _0x14c60f=X('internal-error');_0x14c60f['customData']=_0x5b2236,_0xf11b6f(_0x14c60f);},_0xb0e940['type']='text/javascript',_0xb0e940['charset']='UTF-8',d_()['appendChild'](_0xb0e940);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};