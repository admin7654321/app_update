const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x36616e,_0x5d3cc2){if(!_0x36616e)throw rt(_0x5d3cc2);},rt=function(_0x37d7bf){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x37d7bf);},Vr=function(_0x63ca17){const _0x2bd310=[];let _0x59aa6c=0x0;for(let _0x2620ba=0x0;_0x2620ba<_0x63ca17['length'];_0x2620ba++){let _0x124aa7=_0x63ca17['charCodeAt'](_0x2620ba);_0x124aa7<0x80?_0x2bd310[_0x59aa6c++]=_0x124aa7:_0x124aa7<0x800?(_0x2bd310[_0x59aa6c++]=_0x124aa7>>0x6|0xc0,_0x2bd310[_0x59aa6c++]=_0x124aa7&0x3f|0x80):(_0x124aa7&0xfc00)===0xd800&&_0x2620ba+0x1<_0x63ca17['length']&&(_0x63ca17['charCodeAt'](_0x2620ba+0x1)&0xfc00)===0xdc00?(_0x124aa7=0x10000+((_0x124aa7&0x3ff)<<0xa)+(_0x63ca17['charCodeAt'](++_0x2620ba)&0x3ff),_0x2bd310[_0x59aa6c++]=_0x124aa7>>0x12|0xf0,_0x2bd310[_0x59aa6c++]=_0x124aa7>>0xc&0x3f|0x80,_0x2bd310[_0x59aa6c++]=_0x124aa7>>0x6&0x3f|0x80,_0x2bd310[_0x59aa6c++]=_0x124aa7&0x3f|0x80):(_0x2bd310[_0x59aa6c++]=_0x124aa7>>0xc|0xe0,_0x2bd310[_0x59aa6c++]=_0x124aa7>>0x6&0x3f|0x80,_0x2bd310[_0x59aa6c++]=_0x124aa7&0x3f|0x80);}return _0x2bd310;},ec=function(_0x522b0a){const _0x457f59=[];let _0x458023=0x0,_0x8f5af7=0x0;for(;_0x458023<_0x522b0a['length'];){const _0x4b417f=_0x522b0a[_0x458023++];if(_0x4b417f<0x80)_0x457f59[_0x8f5af7++]=String['fromCharCode'](_0x4b417f);else{if(_0x4b417f>0xbf&&_0x4b417f<0xe0){const _0x19f2c7=_0x522b0a[_0x458023++];_0x457f59[_0x8f5af7++]=String['fromCharCode']((_0x4b417f&0x1f)<<0x6|_0x19f2c7&0x3f);}else{if(_0x4b417f>0xef&&_0x4b417f<0x16d){const _0x365c02=_0x522b0a[_0x458023++],_0x438247=_0x522b0a[_0x458023++],_0x5961f0=_0x522b0a[_0x458023++],_0x22d52e=((_0x4b417f&0x7)<<0x12|(_0x365c02&0x3f)<<0xc|(_0x438247&0x3f)<<0x6|_0x5961f0&0x3f)-0x10000;_0x457f59[_0x8f5af7++]=String['fromCharCode'](0xd800+(_0x22d52e>>0xa)),_0x457f59[_0x8f5af7++]=String['fromCharCode'](0xdc00+(_0x22d52e&0x3ff));}else{const _0x39c350=_0x522b0a[_0x458023++],_0x10d2cd=_0x522b0a[_0x458023++];_0x457f59[_0x8f5af7++]=String['fromCharCode']((_0x4b417f&0xf)<<0xc|(_0x39c350&0x3f)<<0x6|_0x10d2cd&0x3f);}}}}return _0x457f59['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x5132ee,_0x41d109){if(!Array['isArray'](_0x5132ee))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x1f4887=_0x41d109?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x3a661d=[];for(let _0x3820ac=0x0;_0x3820ac<_0x5132ee['length'];_0x3820ac+=0x3){const _0x5ccad8=_0x5132ee[_0x3820ac],_0x3d3b94=_0x3820ac+0x1<_0x5132ee['length'],_0x525df7=_0x3d3b94?_0x5132ee[_0x3820ac+0x1]:0x0,_0x4e0b27=_0x3820ac+0x2<_0x5132ee['length'],_0x29350c=_0x4e0b27?_0x5132ee[_0x3820ac+0x2]:0x0,_0x283c38=_0x5ccad8>>0x2,_0x486ef5=(_0x5ccad8&0x3)<<0x4|_0x525df7>>0x4;let _0x1a3c58=(_0x525df7&0xf)<<0x2|_0x29350c>>0x6,_0x1f2224=_0x29350c&0x3f;_0x4e0b27||(_0x1f2224=0x40,_0x3d3b94||(_0x1a3c58=0x40)),_0x3a661d['push'](_0x1f4887[_0x283c38],_0x1f4887[_0x486ef5],_0x1f4887[_0x1a3c58],_0x1f4887[_0x1f2224]);}return _0x3a661d['join']('');},'encodeString'(_0x238bca,_0x2ca079){return this['HAS_NATIVE_SUPPORT']&&!_0x2ca079?btoa(_0x238bca):this['encodeByteArray'](Vr(_0x238bca),_0x2ca079);},'decodeString'(_0x3cda93,_0x4cb179){return this['HAS_NATIVE_SUPPORT']&&!_0x4cb179?atob(_0x3cda93):ec(this['decodeStringToByteArray'](_0x3cda93,_0x4cb179));},'decodeStringToByteArray'(_0x2cdea5,_0x25d411){this['init_']();const _0x1ae7fa=_0x25d411?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x164dec=[];for(let _0x569f66=0x0;_0x569f66<_0x2cdea5['length'];){const _0x11aeea=_0x1ae7fa[_0x2cdea5['charAt'](_0x569f66++)],_0x4e569b=_0x569f66<_0x2cdea5['length']?_0x1ae7fa[_0x2cdea5['charAt'](_0x569f66)]:0x0;++_0x569f66;const _0x3ec0bb=_0x569f66<_0x2cdea5['length']?_0x1ae7fa[_0x2cdea5['charAt'](_0x569f66)]:0x40;++_0x569f66;const _0x491dc9=_0x569f66<_0x2cdea5['length']?_0x1ae7fa[_0x2cdea5['charAt'](_0x569f66)]:0x40;if(++_0x569f66,_0x11aeea==null||_0x4e569b==null||_0x3ec0bb==null||_0x491dc9==null)throw new tc();const _0x552e24=_0x11aeea<<0x2|_0x4e569b>>0x4;if(_0x164dec['push'](_0x552e24),_0x3ec0bb!==0x40){const _0x46fee6=_0x4e569b<<0x4&0xf0|_0x3ec0bb>>0x2;if(_0x164dec['push'](_0x46fee6),_0x491dc9!==0x40){const _0x3f3c9e=_0x3ec0bb<<0x6&0xc0|_0x491dc9;_0x164dec['push'](_0x3f3c9e);}}}return _0x164dec;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x3de282=0x0;_0x3de282<this['ENCODED_VALS']['length'];_0x3de282++)this['byteToCharMap_'][_0x3de282]=this['ENCODED_VALS']['charAt'](_0x3de282),this['charToByteMap_'][this['byteToCharMap_'][_0x3de282]]=_0x3de282,this['byteToCharMapWebSafe_'][_0x3de282]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3de282),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x3de282]]=_0x3de282,_0x3de282>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3de282)]=_0x3de282,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x3de282)]=_0x3de282);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x1c965e){const _0x49de92=Vr(_0x1c965e);return Li['encodeByteArray'](_0x49de92,!0x0);},cn=function(_0x2db087){return Hr(_0x2db087)['replace'](/\./g,'');},ln=function(_0x2bf47c){try{return Li['decodeString'](_0x2bf47c,!0x0);}catch(_0x3ce0b){console['error']('base64Decode\x20failed:\x20',_0x3ce0b);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x152f51){return $r(void 0x0,_0x152f51);}function $r(_0x2323d9,_0x4540a6){if(!(_0x4540a6 instanceof Object))return _0x4540a6;switch(_0x4540a6['constructor']){case Date:const _0x14c688=_0x4540a6;return new Date(_0x14c688['getTime']());case Object:_0x2323d9===void 0x0&&(_0x2323d9={});break;case Array:_0x2323d9=[];break;default:return _0x4540a6;}for(const _0x236933 in _0x4540a6)!_0x4540a6['hasOwnProperty'](_0x236933)||!ic(_0x236933)||(_0x2323d9[_0x236933]=$r(_0x2323d9[_0x236933],_0x4540a6[_0x236933]));return _0x2323d9;}function ic(_0x14bd1c){return _0x14bd1c!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x211b96=Ns['__FIREBASE_DEFAULTS__'];if(_0x211b96)return JSON['parse'](_0x211b96);},ac=()=>{if(typeof document>'u')return;let _0x3f9d8d;try{_0x3f9d8d=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x1b3546=_0x3f9d8d&&ln(_0x3f9d8d[0x1]);return _0x1b3546&&JSON['parse'](_0x1b3546);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x1b634b){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x1b634b);return;}},Gr=_0x47ffd3=>{var _0x280764,_0x5ed64b;return(_0x5ed64b=(_0x280764=xi())==null?void 0x0:_0x280764['emulatorHosts'])==null?void 0x0:_0x5ed64b[_0x47ffd3];},cc=_0x1c7709=>{const _0x438dfc=Gr(_0x1c7709);if(!_0x438dfc)return;const _0x1d4140=_0x438dfc['lastIndexOf'](':');if(_0x1d4140<=0x0||_0x1d4140+0x1===_0x438dfc['length'])throw new Error('Invalid\x20host\x20'+_0x438dfc+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x344d74=parseInt(_0x438dfc['substring'](_0x1d4140+0x1),0xa);return _0x438dfc[0x0]==='['?[_0x438dfc['substring'](0x1,_0x1d4140-0x1),_0x344d74]:[_0x438dfc['substring'](0x0,_0x1d4140),_0x344d74];},qr=()=>{var _0x5235a2;return(_0x5235a2=xi())==null?void 0x0:_0x5235a2['config'];},zr=_0x154064=>{var _0x38f3d9;return(_0x38f3d9=xi())==null?void 0x0:_0x38f3d9['_'+_0x154064];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0xde64d5,_0x1f9e5c)=>{this['resolve']=_0xde64d5,this['reject']=_0x1f9e5c;});}['wrapCallback'](_0x5bd7e0){return(_0x467c9a,_0x39b7d2)=>{_0x467c9a?this['reject'](_0x467c9a):this['resolve'](_0x39b7d2),typeof _0x5bd7e0=='function'&&(this['promise']['catch'](()=>{}),_0x5bd7e0['length']===0x1?_0x5bd7e0(_0x467c9a):_0x5bd7e0(_0x467c9a,_0x39b7d2));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x257b07){try{return(_0x257b07['startsWith']('http://')||_0x257b07['startsWith']('https://')?new URL(_0x257b07)['hostname']:_0x257b07)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x12c1a8){return(await fetch(_0x12c1a8,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x255016,_0x528fdd){if(_0x255016['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x5b382d={'alg':'none','type':'JWT'},_0x1f2462=_0x528fdd||'demo-project',_0x167171=_0x255016['iat']||0x0,_0xd9fe1a=_0x255016['sub']||_0x255016['user_id'];if(!_0xd9fe1a)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x3e0617={'iss':'https://securetoken.google.com/'+_0x1f2462,'aud':_0x1f2462,'iat':_0x167171,'exp':_0x167171+0xe10,'auth_time':_0x167171,'sub':_0xd9fe1a,'user_id':_0xd9fe1a,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x255016};return[cn(JSON['stringify'](_0x5b382d)),cn(JSON['stringify'](_0x3e0617)),'']['join']('.');}const It={};function hc(){const _0x38b349={'prod':[],'emulator':[]};for(const _0x1b0e88 of Object['keys'](It))It[_0x1b0e88]?_0x38b349['emulator']['push'](_0x1b0e88):_0x38b349['prod']['push'](_0x1b0e88);return _0x38b349;}function uc(_0x4fdce1){let _0x4b550b=document['getElementById'](_0x4fdce1),_0x3f9680=!0x1;return _0x4b550b||(_0x4b550b=document['createElement']('div'),_0x4b550b['setAttribute']('id',_0x4fdce1),_0x3f9680=!0x0),{'created':_0x3f9680,'element':_0x4b550b};}let Ps=!0x1;function Kr(_0x5d686d,_0x1086d0){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x5d686d]===_0x1086d0||It[_0x5d686d]||Ps)return;It[_0x5d686d]=_0x1086d0;function _0x58ffcc(_0x2dc5d0){return'__firebase__banner__'+_0x2dc5d0;}const _0x4da012='__firebase__banner',_0x554cc2=hc()['prod']['length']>0x0;function _0x373d31(){const _0x1c3008=document['getElementById'](_0x4da012);_0x1c3008&&_0x1c3008['remove']();}function _0x3a3648(_0x5829f2){_0x5829f2['style']['display']='flex',_0x5829f2['style']['background']='#7faaf0',_0x5829f2['style']['position']='fixed',_0x5829f2['style']['bottom']='5px',_0x5829f2['style']['left']='5px',_0x5829f2['style']['padding']='.5em',_0x5829f2['style']['borderRadius']='5px',_0x5829f2['style']['alignItems']='center';}function _0x3d03c6(_0x30049e,_0x2c6bc9){_0x30049e['setAttribute']('width','24'),_0x30049e['setAttribute']('id',_0x2c6bc9),_0x30049e['setAttribute']('height','24'),_0x30049e['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x30049e['setAttribute']('fill','none'),_0x30049e['style']['marginLeft']='-6px';}function _0x4f7dcc(){const _0x4cba21=document['createElement']('span');return _0x4cba21['style']['cursor']='pointer',_0x4cba21['style']['marginLeft']='16px',_0x4cba21['style']['fontSize']='24px',_0x4cba21['innerHTML']='\x20&times;',_0x4cba21['onclick']=()=>{Ps=!0x0,_0x373d31();},_0x4cba21;}function _0x56a004(_0xf5443d,_0x2943f9){_0xf5443d['setAttribute']('id',_0x2943f9),_0xf5443d['innerText']='Learn\x20more',_0xf5443d['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0xf5443d['setAttribute']('target','__blank'),_0xf5443d['style']['paddingLeft']='5px',_0xf5443d['style']['textDecoration']='underline';}function _0x5bdbeb(){const _0x467c54=uc(_0x4da012),_0x1fe8b6=_0x58ffcc('text'),_0x38535e=document['getElementById'](_0x1fe8b6)||document['createElement']('span'),_0x5f0339=_0x58ffcc('learnmore'),_0x31298f=document['getElementById'](_0x5f0339)||document['createElement']('a'),_0x3112f2=_0x58ffcc('preprendIcon'),_0x40c678=document['getElementById'](_0x3112f2)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x467c54['created']){const _0x10d522=_0x467c54['element'];_0x3a3648(_0x10d522),_0x56a004(_0x31298f,_0x5f0339);const _0xfcffb8=_0x4f7dcc();_0x3d03c6(_0x40c678,_0x3112f2),_0x10d522['append'](_0x40c678,_0x38535e,_0x31298f,_0xfcffb8),document['body']['appendChild'](_0x10d522);}_0x554cc2?(_0x38535e['innerText']='Preview\x20backend\x20disconnected.',_0x40c678['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x40c678['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x38535e['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x38535e['setAttribute']('id',_0x1fe8b6);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x5bdbeb):_0x5bdbeb();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x4f1cfb=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x4f1cfb=='object'&&_0x4f1cfb['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x4ad2b5=W();return _0x4ad2b5['indexOf']('MSIE\x20')>=0x0||_0x4ad2b5['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x566111,_0x26a70b)=>{try{let _0x454b53=!0x0;const _0x4eb6d8='validate-browser-context-for-indexeddb-analytics-module',_0x540c4a=self['indexedDB']['open'](_0x4eb6d8);_0x540c4a['onsuccess']=()=>{_0x540c4a['result']['close'](),_0x454b53||self['indexedDB']['deleteDatabase'](_0x4eb6d8),_0x566111(!0x0);},_0x540c4a['onupgradeneeded']=()=>{_0x454b53=!0x1;},_0x540c4a['onerror']=()=>{var _0xb3fcdc;_0x26a70b(((_0xb3fcdc=_0x540c4a['error'])==null?void 0x0:_0xb3fcdc['message'])||'');};}catch(_0x8a69f5){_0x26a70b(_0x8a69f5);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x1679e9,_0x2e775b,_0xa6cdb4){super(_0x2e775b),this['code']=_0x1679e9,this['customData']=_0xa6cdb4,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x5e49cc,_0x31e620,_0x3af6e1){this['service']=_0x5e49cc,this['serviceName']=_0x31e620,this['errors']=_0x3af6e1;}['create'](_0x580c08,..._0x242d73){const _0x2f9ae1=_0x242d73[0x0]||{},_0x3d18bd=this['service']+'/'+_0x580c08,_0x33f9b8=this['errors'][_0x580c08],_0x1f4802=_0x33f9b8?vc(_0x33f9b8,_0x2f9ae1):'Error',_0x59da89=this['serviceName']+':\x20'+_0x1f4802+'\x20('+_0x3d18bd+').';return new Se(_0x3d18bd,_0x59da89,_0x2f9ae1);}}function vc(_0x4d2342,_0x17a23b){return _0x4d2342['replace'](Ec,(_0x50e31e,_0x5cf343)=>{const _0x5f130c=_0x17a23b[_0x5cf343];return _0x5f130c!=null?String(_0x5f130c):'<'+_0x5cf343+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x4eee38){return JSON['parse'](_0x4eee38);}function O(_0x1a287a){return JSON['stringify'](_0x1a287a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x12bb69){let _0x5c54ff={},_0x480cb={},_0x45a4be={},_0x1eba7c='';try{const _0x10b5dc=_0x12bb69['split']('.');_0x5c54ff=At(ln(_0x10b5dc[0x0])||''),_0x480cb=At(ln(_0x10b5dc[0x1])||''),_0x1eba7c=_0x10b5dc[0x2],_0x45a4be=_0x480cb['d']||{},delete _0x480cb['d'];}catch{}return{'header':_0x5c54ff,'claims':_0x480cb,'data':_0x45a4be,'signature':_0x1eba7c};},Ic=function(_0x5198cc){const _0x1ea528=Qr(_0x5198cc),_0x47af37=_0x1ea528['claims'];return!!_0x47af37&&typeof _0x47af37=='object'&&_0x47af37['hasOwnProperty']('iat');},wc=function(_0x158901){const _0x5353cc=Qr(_0x158901)['claims'];return typeof _0x5353cc=='object'&&_0x5353cc['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x46208a,_0x50cf3e){return Object['prototype']['hasOwnProperty']['call'](_0x46208a,_0x50cf3e);}function De(_0x2d4125,_0x34de36){if(Object['prototype']['hasOwnProperty']['call'](_0x2d4125,_0x34de36))return _0x2d4125[_0x34de36];}function ui(_0x47ccc5){for(const _0x100e13 in _0x47ccc5)if(Object['prototype']['hasOwnProperty']['call'](_0x47ccc5,_0x100e13))return!0x1;return!0x0;}function hn(_0x150196,_0x3991ce,_0x4d4b81){const _0x29b5d9={};for(const _0x1f420a in _0x150196)Object['prototype']['hasOwnProperty']['call'](_0x150196,_0x1f420a)&&(_0x29b5d9[_0x1f420a]=_0x3991ce['call'](_0x4d4b81,_0x150196[_0x1f420a],_0x1f420a,_0x150196));return _0x29b5d9;}function Me(_0x4dfac5,_0x528cba){if(_0x4dfac5===_0x528cba)return!0x0;const _0x5cef8e=Object['keys'](_0x4dfac5),_0x340a1f=Object['keys'](_0x528cba);for(const _0x5bfe68 of _0x5cef8e){if(!_0x340a1f['includes'](_0x5bfe68))return!0x1;const _0x44343f=_0x4dfac5[_0x5bfe68],_0x4b125c=_0x528cba[_0x5bfe68];if(Os(_0x44343f)&&Os(_0x4b125c)){if(!Me(_0x44343f,_0x4b125c))return!0x1;}else{if(_0x44343f!==_0x4b125c)return!0x1;}}for(const _0x5a3aaa of _0x340a1f)if(!_0x5cef8e['includes'](_0x5a3aaa))return!0x1;return!0x0;}function Os(_0x224e52){return _0x224e52!==null&&typeof _0x224e52=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x2b2c1a){const _0x4aa506=[];for(const [_0x25f400,_0x349563]of Object['entries'](_0x2b2c1a))Array['isArray'](_0x349563)?_0x349563['forEach'](_0x6e939d=>{_0x4aa506['push'](encodeURIComponent(_0x25f400)+'='+encodeURIComponent(_0x6e939d));}):_0x4aa506['push'](encodeURIComponent(_0x25f400)+'='+encodeURIComponent(_0x349563));return _0x4aa506['length']?'&'+_0x4aa506['join']('&'):'';}function vt(_0x14f8fe){const _0x19b785={};return _0x14f8fe['replace'](/^\?/,'')['split']('&')['forEach'](_0xa37b07=>{if(_0xa37b07){const [_0x2bb2fc,_0x5207f7]=_0xa37b07['split']('=');_0x19b785[decodeURIComponent(_0x2bb2fc)]=decodeURIComponent(_0x5207f7);}}),_0x19b785;}function Et(_0x521a0a){const _0x4fc0b3=_0x521a0a['indexOf']('?');if(!_0x4fc0b3)return'';const _0x8fdb2b=_0x521a0a['indexOf']('#',_0x4fc0b3);return _0x521a0a['substring'](_0x4fc0b3,_0x8fdb2b>0x0?_0x8fdb2b:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x5f0b77=0x1;_0x5f0b77<this['blockSize'];++_0x5f0b77)this['pad_'][_0x5f0b77]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x4453bf,_0x1a5bfa){_0x1a5bfa||(_0x1a5bfa=0x0);const _0x143772=this['W_'];if(typeof _0x4453bf=='string'){for(let _0x54c1d3=0x0;_0x54c1d3<0x10;_0x54c1d3++)_0x143772[_0x54c1d3]=_0x4453bf['charCodeAt'](_0x1a5bfa)<<0x18|_0x4453bf['charCodeAt'](_0x1a5bfa+0x1)<<0x10|_0x4453bf['charCodeAt'](_0x1a5bfa+0x2)<<0x8|_0x4453bf['charCodeAt'](_0x1a5bfa+0x3),_0x1a5bfa+=0x4;}else{for(let _0x46ce86=0x0;_0x46ce86<0x10;_0x46ce86++)_0x143772[_0x46ce86]=_0x4453bf[_0x1a5bfa]<<0x18|_0x4453bf[_0x1a5bfa+0x1]<<0x10|_0x4453bf[_0x1a5bfa+0x2]<<0x8|_0x4453bf[_0x1a5bfa+0x3],_0x1a5bfa+=0x4;}for(let _0x1e6491=0x10;_0x1e6491<0x50;_0x1e6491++){const _0x493262=_0x143772[_0x1e6491-0x3]^_0x143772[_0x1e6491-0x8]^_0x143772[_0x1e6491-0xe]^_0x143772[_0x1e6491-0x10];_0x143772[_0x1e6491]=(_0x493262<<0x1|_0x493262>>>0x1f)&0xffffffff;}let _0x304029=this['chain_'][0x0],_0x31e5c9=this['chain_'][0x1],_0x13148a=this['chain_'][0x2],_0x5eeb3e=this['chain_'][0x3],_0x40e6c6=this['chain_'][0x4],_0x1df183,_0x4b66c7;for(let _0x324115=0x0;_0x324115<0x50;_0x324115++){_0x324115<0x28?_0x324115<0x14?(_0x1df183=_0x5eeb3e^_0x31e5c9&(_0x13148a^_0x5eeb3e),_0x4b66c7=0x5a827999):(_0x1df183=_0x31e5c9^_0x13148a^_0x5eeb3e,_0x4b66c7=0x6ed9eba1):_0x324115<0x3c?(_0x1df183=_0x31e5c9&_0x13148a|_0x5eeb3e&(_0x31e5c9|_0x13148a),_0x4b66c7=0x8f1bbcdc):(_0x1df183=_0x31e5c9^_0x13148a^_0x5eeb3e,_0x4b66c7=0xca62c1d6);const _0x5d4a9e=(_0x304029<<0x5|_0x304029>>>0x1b)+_0x1df183+_0x40e6c6+_0x4b66c7+_0x143772[_0x324115]&0xffffffff;_0x40e6c6=_0x5eeb3e,_0x5eeb3e=_0x13148a,_0x13148a=(_0x31e5c9<<0x1e|_0x31e5c9>>>0x2)&0xffffffff,_0x31e5c9=_0x304029,_0x304029=_0x5d4a9e;}this['chain_'][0x0]=this['chain_'][0x0]+_0x304029&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x31e5c9&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x13148a&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x5eeb3e&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x40e6c6&0xffffffff;}['update'](_0x4dca71,_0x2d974a){if(_0x4dca71==null)return;_0x2d974a===void 0x0&&(_0x2d974a=_0x4dca71['length']);const _0x3397f7=_0x2d974a-this['blockSize'];let _0x5c4d46=0x0;const _0x1e5086=this['buf_'];let _0xdbbace=this['inbuf_'];for(;_0x5c4d46<_0x2d974a;){if(_0xdbbace===0x0){for(;_0x5c4d46<=_0x3397f7;)this['compress_'](_0x4dca71,_0x5c4d46),_0x5c4d46+=this['blockSize'];}if(typeof _0x4dca71=='string'){for(;_0x5c4d46<_0x2d974a;)if(_0x1e5086[_0xdbbace]=_0x4dca71['charCodeAt'](_0x5c4d46),++_0xdbbace,++_0x5c4d46,_0xdbbace===this['blockSize']){this['compress_'](_0x1e5086),_0xdbbace=0x0;break;}}else{for(;_0x5c4d46<_0x2d974a;)if(_0x1e5086[_0xdbbace]=_0x4dca71[_0x5c4d46],++_0xdbbace,++_0x5c4d46,_0xdbbace===this['blockSize']){this['compress_'](_0x1e5086),_0xdbbace=0x0;break;}}}this['inbuf_']=_0xdbbace,this['total_']+=_0x2d974a;}['digest'](){const _0x352f85=[];let _0xaadac7=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x4b4d89=this['blockSize']-0x1;_0x4b4d89>=0x38;_0x4b4d89--)this['buf_'][_0x4b4d89]=_0xaadac7&0xff,_0xaadac7/=0x100;this['compress_'](this['buf_']);let _0x2a4980=0x0;for(let _0x5200e1=0x0;_0x5200e1<0x5;_0x5200e1++)for(let _0x15ec9d=0x18;_0x15ec9d>=0x0;_0x15ec9d-=0x8)_0x352f85[_0x2a4980]=this['chain_'][_0x5200e1]>>_0x15ec9d&0xff,++_0x2a4980;return _0x352f85;}}function Tc(_0x188640,_0x5cb272){const _0x56cfd0=new Sc(_0x188640,_0x5cb272);return _0x56cfd0['subscribe']['bind'](_0x56cfd0);}class Sc{constructor(_0x28c3fb,_0x4c0eb7){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x4c0eb7,this['task']['then'](()=>{_0x28c3fb(this);})['catch'](_0x40e15a=>{this['error'](_0x40e15a);});}['next'](_0x566266){this['forEachObserver'](_0x41f285=>{_0x41f285['next'](_0x566266);});}['error'](_0x59fb46){this['forEachObserver'](_0x1413ed=>{_0x1413ed['error'](_0x59fb46);}),this['close'](_0x59fb46);}['complete'](){this['forEachObserver'](_0x1e76a3=>{_0x1e76a3['complete']();}),this['close']();}['subscribe'](_0x1e5113,_0x47b642,_0x57a4c0){let _0x4ad8c5;if(_0x1e5113===void 0x0&&_0x47b642===void 0x0&&_0x57a4c0===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x1e5113,['next','error','complete'])?_0x4ad8c5=_0x1e5113:_0x4ad8c5={'next':_0x1e5113,'error':_0x47b642,'complete':_0x57a4c0},_0x4ad8c5['next']===void 0x0&&(_0x4ad8c5['next']=Jn),_0x4ad8c5['error']===void 0x0&&(_0x4ad8c5['error']=Jn),_0x4ad8c5['complete']===void 0x0&&(_0x4ad8c5['complete']=Jn);const _0x3bf3cb=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x4ad8c5['error'](this['finalError']):_0x4ad8c5['complete']();}catch{}}),this['observers']['push'](_0x4ad8c5),_0x3bf3cb;}['unsubscribeOne'](_0x2f5384){this['observers']===void 0x0||this['observers'][_0x2f5384]===void 0x0||(delete this['observers'][_0x2f5384],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x199c4d){if(!this['finalized']){for(let _0x741afd=0x0;_0x741afd<this['observers']['length'];_0x741afd++)this['sendOne'](_0x741afd,_0x199c4d);}}['sendOne'](_0x28a470,_0x133f78){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x28a470]!==void 0x0)try{_0x133f78(this['observers'][_0x28a470]);}catch(_0x7a9e98){typeof console<'u'&&console['error']&&console['error'](_0x7a9e98);}});}['close'](_0x17452d){this['finalized']||(this['finalized']=!0x0,_0x17452d!==void 0x0&&(this['finalError']=_0x17452d),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x46b1cb,_0x5c2051){if(typeof _0x46b1cb!='object'||_0x46b1cb===null)return!0x1;for(const _0x369f31 of _0x5c2051)if(_0x369f31 in _0x46b1cb&&typeof _0x46b1cb[_0x369f31]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x1791de,_0x3c31c3){return _0x1791de+'\x20failed:\x20'+_0x3c31c3+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x239859){const _0x2c622f=[];let _0x3283ac=0x0;for(let _0x38c33c=0x0;_0x38c33c<_0x239859['length'];_0x38c33c++){let _0x5758ef=_0x239859['charCodeAt'](_0x38c33c);if(_0x5758ef>=0xd800&&_0x5758ef<=0xdbff){const _0x24f049=_0x5758ef-0xd800;_0x38c33c++,f(_0x38c33c<_0x239859['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x673eb1=_0x239859['charCodeAt'](_0x38c33c)-0xdc00;_0x5758ef=0x10000+(_0x24f049<<0xa)+_0x673eb1;}_0x5758ef<0x80?_0x2c622f[_0x3283ac++]=_0x5758ef:_0x5758ef<0x800?(_0x2c622f[_0x3283ac++]=_0x5758ef>>0x6|0xc0,_0x2c622f[_0x3283ac++]=_0x5758ef&0x3f|0x80):_0x5758ef<0x10000?(_0x2c622f[_0x3283ac++]=_0x5758ef>>0xc|0xe0,_0x2c622f[_0x3283ac++]=_0x5758ef>>0x6&0x3f|0x80,_0x2c622f[_0x3283ac++]=_0x5758ef&0x3f|0x80):(_0x2c622f[_0x3283ac++]=_0x5758ef>>0x12|0xf0,_0x2c622f[_0x3283ac++]=_0x5758ef>>0xc&0x3f|0x80,_0x2c622f[_0x3283ac++]=_0x5758ef>>0x6&0x3f|0x80,_0x2c622f[_0x3283ac++]=_0x5758ef&0x3f|0x80);}return _0x2c622f;},On=function(_0x35eecc){let _0xaeefc=0x0;for(let _0x5ee46c=0x0;_0x5ee46c<_0x35eecc['length'];_0x5ee46c++){const _0x489577=_0x35eecc['charCodeAt'](_0x5ee46c);_0x489577<0x80?_0xaeefc++:_0x489577<0x800?_0xaeefc+=0x2:_0x489577>=0xd800&&_0x489577<=0xdbff?(_0xaeefc+=0x4,_0x5ee46c++):_0xaeefc+=0x3;}return _0xaeefc;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x11c9b1){return _0x11c9b1&&_0x11c9b1['_delegate']?_0x11c9b1['_delegate']:_0x11c9b1;}class Le{constructor(_0x5d697d,_0x50b876,_0x445356){this['name']=_0x5d697d,this['instanceFactory']=_0x50b876,this['type']=_0x445356,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x56b848){return this['instantiationMode']=_0x56b848,this;}['setMultipleInstances'](_0x427e6b){return this['multipleInstances']=_0x427e6b,this;}['setServiceProps'](_0x32a249){return this['serviceProps']=_0x32a249,this;}['setInstanceCreatedCallback'](_0x310c5d){return this['onInstanceCreated']=_0x310c5d,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x1c26e2,_0x8ab6c7){this['name']=_0x1c26e2,this['container']=_0x8ab6c7,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0xc11bac){const _0x388d95=this['normalizeInstanceIdentifier'](_0xc11bac);if(!this['instancesDeferred']['has'](_0x388d95)){const _0x574087=new ot();if(this['instancesDeferred']['set'](_0x388d95,_0x574087),this['isInitialized'](_0x388d95)||this['shouldAutoInitialize']())try{const _0xafeaf=this['getOrInitializeService']({'instanceIdentifier':_0x388d95});_0xafeaf&&_0x574087['resolve'](_0xafeaf);}catch{}}return this['instancesDeferred']['get'](_0x388d95)['promise'];}['getImmediate'](_0x16ce68){const _0x295645=this['normalizeInstanceIdentifier'](_0x16ce68==null?void 0x0:_0x16ce68['identifier']),_0x4dc40c=(_0x16ce68==null?void 0x0:_0x16ce68['optional'])??!0x1;if(this['isInitialized'](_0x295645)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x295645});}catch(_0x7b210c){if(_0x4dc40c)return null;throw _0x7b210c;}else{if(_0x4dc40c)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x207295){if(_0x207295['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x207295['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x207295,!!this['shouldAutoInitialize']()){if(Nc(_0x207295))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x577305,_0x5a6ab0]of this['instancesDeferred']['entries']()){const _0x32b300=this['normalizeInstanceIdentifier'](_0x577305);try{const _0x3ba7dc=this['getOrInitializeService']({'instanceIdentifier':_0x32b300});_0x5a6ab0['resolve'](_0x3ba7dc);}catch{}}}}['clearInstance'](_0x4405ee=Ne){this['instancesDeferred']['delete'](_0x4405ee),this['instancesOptions']['delete'](_0x4405ee),this['instances']['delete'](_0x4405ee);}async['delete'](){const _0x3844bd=Array['from'](this['instances']['values']());await Promise['all']([..._0x3844bd['filter'](_0x480ff0=>'INTERNAL'in _0x480ff0)['map'](_0x1406d7=>_0x1406d7['INTERNAL']['delete']()),..._0x3844bd['filter'](_0x34d3d0=>'_delete'in _0x34d3d0)['map'](_0x674677=>_0x674677['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x4dd40f=Ne){return this['instances']['has'](_0x4dd40f);}['getOptions'](_0x4d02b5=Ne){return this['instancesOptions']['get'](_0x4d02b5)||{};}['initialize'](_0x3ce274={}){const {options:_0x2c6a14={}}=_0x3ce274,_0x43ca7f=this['normalizeInstanceIdentifier'](_0x3ce274['instanceIdentifier']);if(this['isInitialized'](_0x43ca7f))throw Error(this['name']+'('+_0x43ca7f+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x12d9e9=this['getOrInitializeService']({'instanceIdentifier':_0x43ca7f,'options':_0x2c6a14});for(const [_0x589602,_0x576b28]of this['instancesDeferred']['entries']()){const _0x4a05c1=this['normalizeInstanceIdentifier'](_0x589602);_0x43ca7f===_0x4a05c1&&_0x576b28['resolve'](_0x12d9e9);}return _0x12d9e9;}['onInit'](_0x4035f2,_0x2bc4dc){const _0x29216e=this['normalizeInstanceIdentifier'](_0x2bc4dc),_0x223b68=this['onInitCallbacks']['get'](_0x29216e)??new Set();_0x223b68['add'](_0x4035f2),this['onInitCallbacks']['set'](_0x29216e,_0x223b68);const _0x256262=this['instances']['get'](_0x29216e);return _0x256262&&_0x4035f2(_0x256262,_0x29216e),()=>{_0x223b68['delete'](_0x4035f2);};}['invokeOnInitCallbacks'](_0x2dfaf7,_0x20435b){const _0x37832e=this['onInitCallbacks']['get'](_0x20435b);if(_0x37832e){for(const _0x14acc3 of _0x37832e)try{_0x14acc3(_0x2dfaf7,_0x20435b);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x3f227d,options:_0x1647d8={}}){let _0x57475a=this['instances']['get'](_0x3f227d);if(!_0x57475a&&this['component']&&(_0x57475a=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x3f227d),'options':_0x1647d8}),this['instances']['set'](_0x3f227d,_0x57475a),this['instancesOptions']['set'](_0x3f227d,_0x1647d8),this['invokeOnInitCallbacks'](_0x57475a,_0x3f227d),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x3f227d,_0x57475a);}catch{}return _0x57475a||null;}['normalizeInstanceIdentifier'](_0x26d7c5=Ne){return this['component']?this['component']['multipleInstances']?_0x26d7c5:Ne:_0x26d7c5;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x1c9174){return _0x1c9174===Ne?void 0x0:_0x1c9174;}function Nc(_0x764b88){return _0x764b88['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0xad7cd4){this['name']=_0xad7cd4,this['providers']=new Map();}['addComponent'](_0x449fd5){const _0x432621=this['getProvider'](_0x449fd5['name']);if(_0x432621['isComponentSet']())throw new Error('Component\x20'+_0x449fd5['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x432621['setComponent'](_0x449fd5);}['addOrOverwriteComponent'](_0x4cf298){this['getProvider'](_0x4cf298['name'])['isComponentSet']()&&this['providers']['delete'](_0x4cf298['name']),this['addComponent'](_0x4cf298);}['getProvider'](_0x5703e5){if(this['providers']['has'](_0x5703e5))return this['providers']['get'](_0x5703e5);const _0x220d04=new Ac(_0x5703e5,this);return this['providers']['set'](_0x5703e5,_0x220d04),_0x220d04;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x4463df){_0x4463df[_0x4463df['DEBUG']=0x0]='DEBUG',_0x4463df[_0x4463df['VERBOSE']=0x1]='VERBOSE',_0x4463df[_0x4463df['INFO']=0x2]='INFO',_0x4463df[_0x4463df['WARN']=0x3]='WARN',_0x4463df[_0x4463df['ERROR']=0x4]='ERROR',_0x4463df[_0x4463df['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x1a089c,_0x3bd338,..._0x36b375)=>{if(_0x3bd338<_0x1a089c['logLevel'])return;const _0x589aba=new Date()['toISOString'](),_0x4dcb56=Mc[_0x3bd338];if(_0x4dcb56)console[_0x4dcb56]('['+_0x589aba+']\x20\x20'+_0x1a089c['name']+':',..._0x36b375);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x3bd338+')');};class Ui{constructor(_0x311eb2){this['name']=_0x311eb2,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0xc56d52){if(!(_0xc56d52 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0xc56d52+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0xc56d52;}['setLogLevel'](_0x31baeb){this['_logLevel']=typeof _0x31baeb=='string'?Oc[_0x31baeb]:_0x31baeb;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x5e43b0){if(typeof _0x5e43b0!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x5e43b0;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x2305ab){this['_userLogHandler']=_0x2305ab;}['debug'](..._0x535f8f){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x535f8f),this['_logHandler'](this,T['DEBUG'],..._0x535f8f);}['log'](..._0x36da5c){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x36da5c),this['_logHandler'](this,T['VERBOSE'],..._0x36da5c);}['info'](..._0x1d1ff6){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x1d1ff6),this['_logHandler'](this,T['INFO'],..._0x1d1ff6);}['warn'](..._0x40fa49){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x40fa49),this['_logHandler'](this,T['WARN'],..._0x40fa49);}['error'](..._0x4aaa60){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x4aaa60),this['_logHandler'](this,T['ERROR'],..._0x4aaa60);}}const xc=(_0x300bc3,_0x2ecc95)=>_0x2ecc95['some'](_0x4e2c4b=>_0x300bc3 instanceof _0x4e2c4b);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0xd1887f){const _0x268051=new Promise((_0x9563f5,_0x2eb527)=>{const _0x1cde10=()=>{_0xd1887f['removeEventListener']('success',_0x25fc73),_0xd1887f['removeEventListener']('error',_0x4393be);},_0x25fc73=()=>{_0x9563f5(_e(_0xd1887f['result'])),_0x1cde10();},_0x4393be=()=>{_0x2eb527(_0xd1887f['error']),_0x1cde10();};_0xd1887f['addEventListener']('success',_0x25fc73),_0xd1887f['addEventListener']('error',_0x4393be);});return _0x268051['then'](_0x425e96=>{_0x425e96 instanceof IDBCursor&&Jr['set'](_0x425e96,_0xd1887f);})['catch'](()=>{}),Wi['set'](_0x268051,_0xd1887f),_0x268051;}function Bc(_0x201d34){if(di['has'](_0x201d34))return;const _0x441027=new Promise((_0x736424,_0x4763d2)=>{const _0x4ecfd1=()=>{_0x201d34['removeEventListener']('complete',_0x2221cf),_0x201d34['removeEventListener']('error',_0x46c817),_0x201d34['removeEventListener']('abort',_0x46c817);},_0x2221cf=()=>{_0x736424(),_0x4ecfd1();},_0x46c817=()=>{_0x4763d2(_0x201d34['error']||new DOMException('AbortError','AbortError')),_0x4ecfd1();};_0x201d34['addEventListener']('complete',_0x2221cf),_0x201d34['addEventListener']('error',_0x46c817),_0x201d34['addEventListener']('abort',_0x46c817);});di['set'](_0x201d34,_0x441027);}let fi={'get'(_0x62afa6,_0x42dff8,_0x5a4366){if(_0x62afa6 instanceof IDBTransaction){if(_0x42dff8==='done')return di['get'](_0x62afa6);if(_0x42dff8==='objectStoreNames')return _0x62afa6['objectStoreNames']||Xr['get'](_0x62afa6);if(_0x42dff8==='store')return _0x5a4366['objectStoreNames'][0x1]?void 0x0:_0x5a4366['objectStore'](_0x5a4366['objectStoreNames'][0x0]);}return _e(_0x62afa6[_0x42dff8]);},'set'(_0x2320e2,_0x575a8,_0x1e0dfb){return _0x2320e2[_0x575a8]=_0x1e0dfb,!0x0;},'has'(_0x54f8be,_0x192529){return _0x54f8be instanceof IDBTransaction&&(_0x192529==='done'||_0x192529==='store')?!0x0:_0x192529 in _0x54f8be;}};function Vc(_0x751088){fi=_0x751088(fi);}function Hc(_0x289af4){return _0x289af4===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x392cd7,..._0x2c1f0a){const _0x27e425=_0x289af4['call'](Zn(this),_0x392cd7,..._0x2c1f0a);return Xr['set'](_0x27e425,_0x392cd7['sort']?_0x392cd7['sort']():[_0x392cd7]),_e(_0x27e425);}:Uc()['includes'](_0x289af4)?function(..._0x3cec13){return _0x289af4['apply'](Zn(this),_0x3cec13),_e(Jr['get'](this));}:function(..._0x219c44){return _e(_0x289af4['apply'](Zn(this),_0x219c44));};}function $c(_0x2bac32){return typeof _0x2bac32=='function'?Hc(_0x2bac32):(_0x2bac32 instanceof IDBTransaction&&Bc(_0x2bac32),xc(_0x2bac32,Fc())?new Proxy(_0x2bac32,fi):_0x2bac32);}function _e(_0x1f89e1){if(_0x1f89e1 instanceof IDBRequest)return Wc(_0x1f89e1);if(Xn['has'](_0x1f89e1))return Xn['get'](_0x1f89e1);const _0x4b6eca=$c(_0x1f89e1);return _0x4b6eca!==_0x1f89e1&&(Xn['set'](_0x1f89e1,_0x4b6eca),Wi['set'](_0x4b6eca,_0x1f89e1)),_0x4b6eca;}const Zn=_0x8abb2f=>Wi['get'](_0x8abb2f);function Gc(_0x22cf3b,_0x396bdb,{blocked:_0x4e6437,upgrade:_0x2616e3,blocking:_0x110e53,terminated:_0x29142a}={}){const _0x25ca44=indexedDB['open'](_0x22cf3b,_0x396bdb),_0x66502c=_e(_0x25ca44);return _0x2616e3&&_0x25ca44['addEventListener']('upgradeneeded',_0x126964=>{_0x2616e3(_e(_0x25ca44['result']),_0x126964['oldVersion'],_0x126964['newVersion'],_e(_0x25ca44['transaction']),_0x126964);}),_0x4e6437&&_0x25ca44['addEventListener']('blocked',_0x33db69=>_0x4e6437(_0x33db69['oldVersion'],_0x33db69['newVersion'],_0x33db69)),_0x66502c['then'](_0x5d8de1=>{_0x29142a&&_0x5d8de1['addEventListener']('close',()=>_0x29142a()),_0x110e53&&_0x5d8de1['addEventListener']('versionchange',_0x38721d=>_0x110e53(_0x38721d['oldVersion'],_0x38721d['newVersion'],_0x38721d));})['catch'](()=>{}),_0x66502c;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x24b6a8,_0x4fec6e){if(!(_0x24b6a8 instanceof IDBDatabase&&!(_0x4fec6e in _0x24b6a8)&&typeof _0x4fec6e=='string'))return;if(ei['get'](_0x4fec6e))return ei['get'](_0x4fec6e);const _0x537acd=_0x4fec6e['replace'](/FromIndex$/,''),_0x1c0abe=_0x4fec6e!==_0x537acd,_0x2978a8=zc['includes'](_0x537acd);if(!(_0x537acd in(_0x1c0abe?IDBIndex:IDBObjectStore)['prototype'])||!(_0x2978a8||qc['includes'](_0x537acd)))return;const _0x47e362=async function(_0x4db818,..._0x522094){const _0x2af9c0=this['transaction'](_0x4db818,_0x2978a8?'readwrite':'readonly');let _0x12ee4d=_0x2af9c0['store'];return _0x1c0abe&&(_0x12ee4d=_0x12ee4d['index'](_0x522094['shift']())),(await Promise['all']([_0x12ee4d[_0x537acd](..._0x522094),_0x2978a8&&_0x2af9c0['done']]))[0x0];};return ei['set'](_0x4fec6e,_0x47e362),_0x47e362;}Vc(_0x26df37=>({..._0x26df37,'get':(_0x12b553,_0x41e7bf,_0x1c28e4)=>Ls(_0x12b553,_0x41e7bf)||_0x26df37['get'](_0x12b553,_0x41e7bf,_0x1c28e4),'has':(_0x44434d,_0xd2f6d0)=>!!Ls(_0x44434d,_0xd2f6d0)||_0x26df37['has'](_0x44434d,_0xd2f6d0)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x51dd58){this['container']=_0x51dd58;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x54767f=>{if(Kc(_0x54767f)){const _0x9d0ee1=_0x54767f['getImmediate']();return _0x9d0ee1['library']+'/'+_0x9d0ee1['version'];}else return null;})['filter'](_0x183c24=>_0x183c24)['join']('\x20');}}function Kc(_0x9f0694){const _0x48dd42=_0x9f0694['getComponent']();return(_0x48dd42==null?void 0x0:_0x48dd42['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x420cdc,_0x31a86c){try{_0x420cdc['container']['addComponent'](_0x31a86c);}catch(_0x40ff56){oe['debug']('Component\x20'+_0x31a86c['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x420cdc['name'],_0x40ff56);}}function Ze(_0x378683){const _0x5ecdb8=_0x378683['name'];if(mi['has'](_0x5ecdb8))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x5ecdb8+'.'),!0x1;mi['set'](_0x5ecdb8,_0x378683);for(const _0xe2d0e7 of xe['values']())Fs(_0xe2d0e7,_0x378683);for(const _0xa7b5fe of gi['values']())Fs(_0xa7b5fe,_0x378683);return!0x0;}function Bi(_0x54a870,_0x2dc56d){const _0x450ee8=_0x54a870['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x450ee8&&_0x450ee8['triggerHeartbeat'](),_0x54a870['container']['getProvider'](_0x2dc56d);}function $(_0x3b9066){return _0x3b9066==null?!0x1:_0x3b9066['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x1ac118,_0x438271,_0x2e362f){this['_isDeleted']=!0x1,this['_options']={..._0x1ac118},this['_config']={..._0x438271},this['_name']=_0x438271['name'],this['_automaticDataCollectionEnabled']=_0x438271['automaticDataCollectionEnabled'],this['_container']=_0x2e362f,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x54fd33){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x54fd33;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x17eec7){this['_isDeleted']=_0x17eec7;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x2781f9,_0x1b005e={}){let _0x21e578=_0x2781f9;typeof _0x1b005e!='object'&&(_0x1b005e={'name':_0x1b005e});const _0x4214a8={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x1b005e},_0x8e4eae=_0x4214a8['name'];if(typeof _0x8e4eae!='string'||!_0x8e4eae)throw ge['create']('bad-app-name',{'appName':String(_0x8e4eae)});if(_0x21e578||(_0x21e578=qr()),!_0x21e578)throw ge['create']('no-options');const _0x40575f=xe['get'](_0x8e4eae);if(_0x40575f){if(Me(_0x21e578,_0x40575f['options'])&&Me(_0x4214a8,_0x40575f['config']))return _0x40575f;throw ge['create']('duplicate-app',{'appName':_0x8e4eae});}const _0x1e5ea7=new Pc(_0x8e4eae);for(const _0x436993 of mi['values']())_0x1e5ea7['addComponent'](_0x436993);const _0x2b0796=new Tl(_0x21e578,_0x4214a8,_0x1e5ea7);return xe['set'](_0x8e4eae,_0x2b0796),_0x2b0796;}function Zr(_0x466e21=_i){const _0x4a8008=xe['get'](_0x466e21);if(!_0x4a8008&&_0x466e21===_i&&qr())return Sl();if(!_0x4a8008)throw ge['create']('no-app',{'appName':_0x466e21});return _0x4a8008;}function f_(){return Array['from'](xe['values']());}async function p_(_0x1cd02f){let _0xbca672=!0x1;const _0x3fa6dd=_0x1cd02f['name'];xe['has'](_0x3fa6dd)?(_0xbca672=!0x0,xe['delete'](_0x3fa6dd)):gi['has'](_0x3fa6dd)&&_0x1cd02f['decRefCount']()<=0x0&&(gi['delete'](_0x3fa6dd),_0xbca672=!0x0),_0xbca672&&(await Promise['all'](_0x1cd02f['container']['getProviders']()['map'](_0x104240=>_0x104240['delete']())),_0x1cd02f['isDeleted']=!0x0);}function me(_0x49ab9b,_0x29590f,_0x4db0dd){let _0x5bd9bd=wl[_0x49ab9b]??_0x49ab9b;_0x4db0dd&&(_0x5bd9bd+='-'+_0x4db0dd);const _0x54d20a=_0x5bd9bd['match'](/\s|\//),_0x4df52b=_0x29590f['match'](/\s|\//);if(_0x54d20a||_0x4df52b){const _0x5c1516=['Unable\x20to\x20register\x20library\x20\x22'+_0x5bd9bd+'\x22\x20with\x20version\x20\x22'+_0x29590f+'\x22:'];_0x54d20a&&_0x5c1516['push']('library\x20name\x20\x22'+_0x5bd9bd+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x54d20a&&_0x4df52b&&_0x5c1516['push']('and'),_0x4df52b&&_0x5c1516['push']('version\x20name\x20\x22'+_0x29590f+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x5c1516['join']('\x20'));return;}Ze(new Le(_0x5bd9bd+'-version',()=>({'library':_0x5bd9bd,'version':_0x29590f}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x224bcc,_0x30a882)=>{switch(_0x30a882){case 0x0:try{_0x224bcc['createObjectStore'](kt);}catch(_0x540914){console['warn'](_0x540914);}}}})['catch'](_0x529743=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x529743['message']});})),ti;}async function Al(_0x4e4f7d){try{const _0x1762b9=(await eo())['transaction'](kt),_0x2d9d4f=await _0x1762b9['objectStore'](kt)['get'](to(_0x4e4f7d));return await _0x1762b9['done'],_0x2d9d4f;}catch(_0x4ef2c1){if(_0x4ef2c1 instanceof Se)oe['warn'](_0x4ef2c1['message']);else{const _0x363975=ge['create']('idb-get',{'originalErrorMessage':_0x4ef2c1==null?void 0x0:_0x4ef2c1['message']});oe['warn'](_0x363975['message']);}}}async function Us(_0x401a80,_0x35f4e7){try{const _0x29de45=(await eo())['transaction'](kt,'readwrite');await _0x29de45['objectStore'](kt)['put'](_0x35f4e7,to(_0x401a80)),await _0x29de45['done'];}catch(_0x271c1d){if(_0x271c1d instanceof Se)oe['warn'](_0x271c1d['message']);else{const _0x9a23f3=ge['create']('idb-set',{'originalErrorMessage':_0x271c1d==null?void 0x0:_0x271c1d['message']});oe['warn'](_0x9a23f3['message']);}}}function to(_0x133309){return _0x133309['name']+'!'+_0x133309['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x3a809b){this['container']=_0x3a809b,this['_heartbeatsCache']=null;const _0x9a6d24=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x9a6d24),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x517a96=>(this['_heartbeatsCache']=_0x517a96,_0x517a96));}async['triggerHeartbeat'](){var _0x2f717f,_0x3dead7;try{const _0x26378d=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x391703=Ws();if(((_0x2f717f=this['_heartbeatsCache'])==null?void 0x0:_0x2f717f['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x3dead7=this['_heartbeatsCache'])==null?void 0x0:_0x3dead7['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x391703||this['_heartbeatsCache']['heartbeats']['some'](_0x5b25ae=>_0x5b25ae['date']===_0x391703))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x391703,'agent':_0x26378d}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x3dbe5c=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x3dbe5c,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x495fc8){oe['warn'](_0x495fc8);}}async['getHeartbeatsHeader'](){var _0x3a5f17;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x3a5f17=this['_heartbeatsCache'])==null?void 0x0:_0x3a5f17['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x396f3e=Ws(),{heartbeatsToSend:_0x4e03d3,unsentEntries:_0x4148c8}=Ol(this['_heartbeatsCache']['heartbeats']),_0x68c656=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x4e03d3}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x396f3e,_0x4148c8['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x4148c8,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x68c656;}catch(_0x50b081){return oe['warn'](_0x50b081),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x51dc48,_0x35c305=kl){const _0x428195=[];let _0x228871=_0x51dc48['slice']();for(const _0x56a1fb of _0x51dc48){const _0x594284=_0x428195['find'](_0x3894b7=>_0x3894b7['agent']===_0x56a1fb['agent']);if(_0x594284){if(_0x594284['dates']['push'](_0x56a1fb['date']),Bs(_0x428195)>_0x35c305){_0x594284['dates']['pop']();break;}}else{if(_0x428195['push']({'agent':_0x56a1fb['agent'],'dates':[_0x56a1fb['date']]}),Bs(_0x428195)>_0x35c305){_0x428195['pop']();break;}}_0x228871=_0x228871['slice'](0x1);}return{'heartbeatsToSend':_0x428195,'unsentEntries':_0x228871};}class Dl{constructor(_0x46bb86){this['app']=_0x46bb86,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x222738=await Al(this['app']);return _0x222738!=null&&_0x222738['heartbeats']?_0x222738:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x106f7e){if(await this['_canUseIndexedDBPromise']){const _0x4ffdb3=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x106f7e['lastSentHeartbeatDate']??_0x4ffdb3['lastSentHeartbeatDate'],'heartbeats':_0x106f7e['heartbeats']});}else return;}async['add'](_0x326f6a){if(await this['_canUseIndexedDBPromise']){const _0x26d4a9=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x326f6a['lastSentHeartbeatDate']??_0x26d4a9['lastSentHeartbeatDate'],'heartbeats':[..._0x26d4a9['heartbeats'],..._0x326f6a['heartbeats']]});}else return;}}function Bs(_0x4d9203){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x4d9203}))['length'];}function Ml(_0x11e0e0){if(_0x11e0e0['length']===0x0)return-0x1;let _0x48b52d=0x0,_0x1d116b=_0x11e0e0[0x0]['date'];for(let _0x4e2e9c=0x1;_0x4e2e9c<_0x11e0e0['length'];_0x4e2e9c++)_0x11e0e0[_0x4e2e9c]['date']<_0x1d116b&&(_0x1d116b=_0x11e0e0[_0x4e2e9c]['date'],_0x48b52d=_0x4e2e9c);return _0x48b52d;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x30494b){Ze(new Le('platform-logger',_0x5c5903=>new jc(_0x5c5903),'PRIVATE')),Ze(new Le('heartbeat',_0x431284=>new Pl(_0x431284),'PRIVATE')),me(pi,xs,_0x30494b),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x2d173c){no=_0x2d173c;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x59c87d){this['domStorage_']=_0x59c87d,this['prefix_']='firebase:';}['set'](_0x93e0ab,_0x597479){_0x597479==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x93e0ab)):this['domStorage_']['setItem'](this['prefixedName_'](_0x93e0ab),O(_0x597479));}['get'](_0x146d2b){const _0x4d1875=this['domStorage_']['getItem'](this['prefixedName_'](_0x146d2b));return _0x4d1875==null?null:At(_0x4d1875);}['remove'](_0x5c30af){this['domStorage_']['removeItem'](this['prefixedName_'](_0x5c30af));}['prefixedName_'](_0x306141){return this['prefix_']+_0x306141;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x223e85,_0x5b2fb5){_0x5b2fb5==null?delete this['cache_'][_0x223e85]:this['cache_'][_0x223e85]=_0x5b2fb5;}['get'](_0x457415){return J(this['cache_'],_0x457415)?this['cache_'][_0x457415]:null;}['remove'](_0x20d675){delete this['cache_'][_0x20d675];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x422011){try{if(typeof window<'u'&&typeof window[_0x422011]<'u'){const _0x258282=window[_0x422011];return _0x258282['setItem']('firebase:sentinel','cache'),_0x258282['removeItem']('firebase:sentinel'),new Wl(_0x258282);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x5914f9=0x1;return function(){return _0x5914f9++;};}()),ro=function(_0x553267){const _0x22cf51=Rc(_0x553267),_0x460da2=new Cc();_0x460da2['update'](_0x22cf51);const _0x46ebae=_0x460da2['digest']();return Li['encodeByteArray'](_0x46ebae);},Vt=function(..._0x477c89){let _0x28adf5='';for(let _0x407513=0x0;_0x407513<_0x477c89['length'];_0x407513++){const _0x3e4c38=_0x477c89[_0x407513];Array['isArray'](_0x3e4c38)||_0x3e4c38&&typeof _0x3e4c38=='object'&&typeof _0x3e4c38['length']=='number'?_0x28adf5+=Vt['apply'](null,_0x3e4c38):typeof _0x3e4c38=='object'?_0x28adf5+=O(_0x3e4c38):_0x28adf5+=_0x3e4c38,_0x28adf5+='\x20';}return _0x28adf5;};let wt=null,Gs=!0x0;const Hl=function(_0x149137,_0x3d25eb){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x1edb1a){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x7e2920=Vt['apply'](null,_0x1edb1a);wt(_0x7e2920);}},Ht=function(_0x5bbfc5){return function(..._0x5bc6f5){L(_0x5bbfc5,..._0x5bc6f5);};},yi=function(..._0x188472){const _0x143c84='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x188472);Ye['error'](_0x143c84);},ae=function(..._0x5310bd){const _0x32e905='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x5310bd);throw Ye['error'](_0x32e905),new Error(_0x32e905);},U=function(..._0x164162){const _0x1c02a1='FIREBASE\x20WARNING:\x20'+Vt(..._0x164162);Ye['warn'](_0x1c02a1);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x36c416){return typeof _0x36c416=='number'&&(_0x36c416!==_0x36c416||_0x36c416===Number['POSITIVE_INFINITY']||_0x36c416===Number['NEGATIVE_INFINITY']);},Gl=function(_0x3b8f02){if(document['readyState']==='complete')_0x3b8f02();else{let _0x39ec38=!0x1;const _0x4f6cab=function(){if(!document['body']){setTimeout(_0x4f6cab,Math['floor'](0xa));return;}_0x39ec38||(_0x39ec38=!0x0,_0x3b8f02());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x4f6cab,!0x1),window['addEventListener']('load',_0x4f6cab,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x4f6cab();}),window['attachEvent']('onload',_0x4f6cab));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x10f0aa,_0x26784f){if(_0x10f0aa===_0x26784f)return 0x0;if(_0x10f0aa===Fe||_0x26784f===Ie)return-0x1;if(_0x26784f===Fe||_0x10f0aa===Ie)return 0x1;{const _0x48bf03=qs(_0x10f0aa),_0x6daf6=qs(_0x26784f);return _0x48bf03!==null?_0x6daf6!==null?_0x48bf03-_0x6daf6===0x0?_0x10f0aa['length']-_0x26784f['length']:_0x48bf03-_0x6daf6:-0x1:_0x6daf6!==null?0x1:_0x10f0aa<_0x26784f?-0x1:0x1;}},ql=function(_0x36a852,_0x51fbc3){return _0x36a852===_0x51fbc3?0x0:_0x36a852<_0x51fbc3?-0x1:0x1;},_t=function(_0x53b3e9,_0x4a587c){if(_0x4a587c&&_0x53b3e9 in _0x4a587c)return _0x4a587c[_0x53b3e9];throw new Error('Missing\x20required\x20key\x20('+_0x53b3e9+')\x20in\x20object:\x20'+O(_0x4a587c));},Hi=function(_0x21fb65){if(typeof _0x21fb65!='object'||_0x21fb65===null)return O(_0x21fb65);const _0x31e855=[];for(const _0xb49d5 in _0x21fb65)_0x31e855['push'](_0xb49d5);_0x31e855['sort']();let _0x243d8b='{';for(let _0x5d8c47=0x0;_0x5d8c47<_0x31e855['length'];_0x5d8c47++)_0x5d8c47!==0x0&&(_0x243d8b+=','),_0x243d8b+=O(_0x31e855[_0x5d8c47]),_0x243d8b+=':',_0x243d8b+=Hi(_0x21fb65[_0x31e855[_0x5d8c47]]);return _0x243d8b+='}',_0x243d8b;},oo=function(_0x2eab4c,_0x129365){const _0x311c47=_0x2eab4c['length'];if(_0x311c47<=_0x129365)return[_0x2eab4c];const _0x3109dd=[];for(let _0x5063d3=0x0;_0x5063d3<_0x311c47;_0x5063d3+=_0x129365)_0x5063d3+_0x129365>_0x311c47?_0x3109dd['push'](_0x2eab4c['substring'](_0x5063d3,_0x311c47)):_0x3109dd['push'](_0x2eab4c['substring'](_0x5063d3,_0x5063d3+_0x129365));return _0x3109dd;};function x(_0x3e6c92,_0x1b4c2b){for(const _0x1a3196 in _0x3e6c92)_0x3e6c92['hasOwnProperty'](_0x1a3196)&&_0x1b4c2b(_0x1a3196,_0x3e6c92[_0x1a3196]);}const ao=function(_0x118f28){f(!Vi(_0x118f28),'Invalid\x20JSON\x20number');const _0x53a6f8=0xb,_0x15ea98=0x34,_0x3ac91a=(0x1<<_0x53a6f8-0x1)-0x1;let _0x1c8e86,_0x319f7f,_0x26da79,_0x3f9319,_0x5933b5;_0x118f28===0x0?(_0x319f7f=0x0,_0x26da79=0x0,_0x1c8e86=0x1/_0x118f28===-0x1/0x0?0x1:0x0):(_0x1c8e86=_0x118f28<0x0,_0x118f28=Math['abs'](_0x118f28),_0x118f28>=Math['pow'](0x2,0x1-_0x3ac91a)?(_0x3f9319=Math['min'](Math['floor'](Math['log'](_0x118f28)/Math['LN2']),_0x3ac91a),_0x319f7f=_0x3f9319+_0x3ac91a,_0x26da79=Math['round'](_0x118f28*Math['pow'](0x2,_0x15ea98-_0x3f9319)-Math['pow'](0x2,_0x15ea98))):(_0x319f7f=0x0,_0x26da79=Math['round'](_0x118f28/Math['pow'](0x2,0x1-_0x3ac91a-_0x15ea98))));const _0x11c0f1=[];for(_0x5933b5=_0x15ea98;_0x5933b5;_0x5933b5-=0x1)_0x11c0f1['push'](_0x26da79%0x2?0x1:0x0),_0x26da79=Math['floor'](_0x26da79/0x2);for(_0x5933b5=_0x53a6f8;_0x5933b5;_0x5933b5-=0x1)_0x11c0f1['push'](_0x319f7f%0x2?0x1:0x0),_0x319f7f=Math['floor'](_0x319f7f/0x2);_0x11c0f1['push'](_0x1c8e86?0x1:0x0),_0x11c0f1['reverse']();const _0x536c01=_0x11c0f1['join']('');let _0x3dd905='';for(_0x5933b5=0x0;_0x5933b5<0x40;_0x5933b5+=0x8){let _0x3045ba=parseInt(_0x536c01['substr'](_0x5933b5,0x8),0x2)['toString'](0x10);_0x3045ba['length']===0x1&&(_0x3045ba='0'+_0x3045ba),_0x3dd905=_0x3dd905+_0x3045ba;}return _0x3dd905['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x156187,_0xe6210d){let _0x32a70b='Unknown\x20Error';_0x156187==='too_big'?_0x32a70b='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x156187==='permission_denied'?_0x32a70b='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x156187==='unavailable'&&(_0x32a70b='The\x20service\x20is\x20unavailable');const _0x78d4f9=new Error(_0x156187+'\x20at\x20'+_0xe6210d['_path']['toString']()+':\x20'+_0x32a70b);return _0x78d4f9['code']=_0x156187['toUpperCase'](),_0x78d4f9;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0xe0a147){if(Yl['test'](_0xe0a147)){const _0x1e7c65=Number(_0xe0a147);if(_0x1e7c65>=Ql&&_0x1e7c65<=Jl)return _0x1e7c65;}return null;},ht=function(_0x59c685){try{_0x59c685();}catch(_0x4f6adf){setTimeout(()=>{const _0x4091be=_0x4f6adf['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x4091be),_0x4f6adf;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x1d485e,_0x9bcf56){const _0x31a29a=setTimeout(_0x1d485e,_0x9bcf56);return typeof _0x31a29a=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x31a29a):typeof _0x31a29a=='object'&&_0x31a29a['unref']&&_0x31a29a['unref'](),_0x31a29a;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x5709ef,_0x34ec7e){this['appCheckProvider']=_0x34ec7e,this['appName']=_0x5709ef['name'],$(_0x5709ef)&&_0x5709ef['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x5709ef['settings']['appCheckToken']),this['appCheck']=_0x34ec7e==null?void 0x0:_0x34ec7e['getImmediate']({'optional':!0x0}),this['appCheck']||_0x34ec7e==null||_0x34ec7e['get']()['then'](_0x2d2937=>this['appCheck']=_0x2d2937);}['getToken'](_0x1b1cd5){if(this['serverAppAppCheckToken']){if(_0x1b1cd5)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x1b1cd5):new Promise((_0x39be97,_0x3054b5)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x1b1cd5)['then'](_0x39be97,_0x3054b5):_0x39be97(null);},0x0);});}['addTokenChangeListener'](_0x47c63b){var _0x2ec0d7;(_0x2ec0d7=this['appCheckProvider'])==null||_0x2ec0d7['get']()['then'](_0x72943a=>_0x72943a['addTokenListener'](_0x47c63b));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x3a3a38,_0x27fc5c,_0x2e4942){this['appName_']=_0x3a3a38,this['firebaseOptions_']=_0x27fc5c,this['authProvider_']=_0x2e4942,this['auth_']=null,this['auth_']=_0x2e4942['getImmediate']({'optional':!0x0}),this['auth_']||_0x2e4942['onInit'](_0x1dda6a=>this['auth_']=_0x1dda6a);}['getToken'](_0x2315b7){return this['auth_']?this['auth_']['getToken'](_0x2315b7)['catch'](_0x2d53fa=>_0x2d53fa&&_0x2d53fa['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x2d53fa)):new Promise((_0x5ceb92,_0x28f2f4)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x2315b7)['then'](_0x5ceb92,_0x28f2f4):_0x5ceb92(null);},0x0);});}['addTokenChangeListener'](_0xfe5965){this['auth_']?this['auth_']['addAuthTokenListener'](_0xfe5965):this['authProvider_']['get']()['then'](_0x7216f7=>_0x7216f7['addAuthTokenListener'](_0xfe5965));}['removeTokenChangeListener'](_0x58f693){this['authProvider_']['get']()['then'](_0x54521d=>_0x54521d['removeAuthTokenListener'](_0x58f693));}['notifyForInvalidToken'](){let _0x398410='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x398410+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x398410+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x398410+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x398410);}}class nn{constructor(_0x3af647){this['accessToken']=_0x3af647;}['getToken'](_0x530262){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x20670c){_0x20670c(this['accessToken']);}['removeTokenChangeListener'](_0x46c5cf){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x1e6468,_0x4a9336,_0x21d9cf,_0x3281ad,_0x337372=!0x1,_0x23e3d6='',_0x1676b0=!0x1,_0x29583d=!0x1,_0x542b72=null){this['secure']=_0x4a9336,this['namespace']=_0x21d9cf,this['webSocketOnly']=_0x3281ad,this['nodeAdmin']=_0x337372,this['persistenceKey']=_0x23e3d6,this['includeNamespaceInQueryParams']=_0x1676b0,this['isUsingEmulator']=_0x29583d,this['emulatorOptions']=_0x542b72,this['_host']=_0x1e6468['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x1e6468)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x463db0){_0x463db0!==this['internalHost']&&(this['internalHost']=_0x463db0,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x5e5ccc=this['toURLString']();return this['persistenceKey']&&(_0x5e5ccc+='<'+this['persistenceKey']+'>'),_0x5e5ccc;}['toURLString'](){const _0x5b9681=this['secure']?'https://':'http://',_0x2180ae=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x5b9681+this['host']+'/'+_0x2180ae;}}function th(_0x24cea6){return _0x24cea6['host']!==_0x24cea6['internalHost']||_0x24cea6['isCustomHost']()||_0x24cea6['includeNamespaceInQueryParams'];}function vo(_0x4d70f0,_0x1fc404,_0x47dc2c){f(typeof _0x1fc404=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x47dc2c=='object','typeof\x20params\x20must\x20==\x20object');let _0x1f3001;if(_0x1fc404===go)_0x1f3001=(_0x4d70f0['secure']?'wss://':'ws://')+_0x4d70f0['internalHost']+'/.ws?';else{if(_0x1fc404===mo)_0x1f3001=(_0x4d70f0['secure']?'https://':'http://')+_0x4d70f0['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x1fc404);}th(_0x4d70f0)&&(_0x47dc2c['ns']=_0x4d70f0['namespace']);const _0x4699ff=[];return x(_0x47dc2c,(_0x890be7,_0x3596c2)=>{_0x4699ff['push'](_0x890be7+'='+_0x3596c2);}),_0x1f3001+_0x4699ff['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x32e747,_0x5e854e=0x1){J(this['counters_'],_0x32e747)||(this['counters_'][_0x32e747]=0x0),this['counters_'][_0x32e747]+=_0x5e854e;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x4b1561){const _0x2a0d1a=_0x4b1561['toString']();return ni[_0x2a0d1a]||(ni[_0x2a0d1a]=new nh()),ni[_0x2a0d1a];}function ih(_0x30ba03,_0x2ebfb4){const _0x217210=_0x30ba03['toString']();return ii[_0x217210]||(ii[_0x217210]=_0x2ebfb4()),ii[_0x217210];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0xe291c2){this['onMessage_']=_0xe291c2,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x51d47c,_0x9ec073){this['closeAfterResponse']=_0x51d47c,this['onClose']=_0x9ec073,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x465165,_0x24a281){for(this['pendingResponses'][_0x465165]=_0x24a281;this['pendingResponses'][this['currentResponseNum']];){const _0x211051=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0xb0b05b=0x0;_0xb0b05b<_0x211051['length'];++_0xb0b05b)_0x211051[_0xb0b05b]&&ht(()=>{this['onMessage_'](_0x211051[_0xb0b05b]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x23f43c,_0x14f361,_0xc08c16,_0x3871bd,_0xf1eb9f,_0x1e6926,_0x394c93){this['connId']=_0x23f43c,this['repoInfo']=_0x14f361,this['applicationId']=_0xc08c16,this['appCheckToken']=_0x3871bd,this['authToken']=_0xf1eb9f,this['transportSessionId']=_0x1e6926,this['lastSessionId']=_0x394c93,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x23f43c),this['stats_']=Gi(_0x14f361),this['urlFn']=_0x371f0c=>(this['appCheckToken']&&(_0x371f0c[vi]=this['appCheckToken']),vo(_0x14f361,mo,_0x371f0c));}['open'](_0x4c6b1a,_0x398e10){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x398e10,this['myPacketOrderer']=new sh(_0x4c6b1a),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x2fe82c)=>{const [_0x4bfefd,_0x2e983f,_0x295103,_0x2df625,_0x58eda9]=_0x2fe82c;if(this['incrementIncomingBytes_'](_0x2fe82c),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x4bfefd===zs)this['id']=_0x2e983f,this['password']=_0x295103;else{if(_0x4bfefd===rh)_0x2e983f?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x2e983f,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x4bfefd);}}},(..._0xb1b86e)=>{const [_0x37c064,_0x184a66]=_0xb1b86e;this['incrementIncomingBytes_'](_0xb1b86e),this['myPacketOrderer']['handleResponse'](_0x37c064,_0x184a66);},()=>{this['onClosed_']();},this['urlFn']);const _0x3fdf86={};_0x3fdf86[zs]='t',_0x3fdf86[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x3fdf86[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x3fdf86[co]=$i,this['transportSessionId']&&(_0x3fdf86[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x3fdf86[po]=this['lastSessionId']),this['applicationId']&&(_0x3fdf86[_o]=this['applicationId']),this['appCheckToken']&&(_0x3fdf86[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3fdf86[ho]=uo);const _0x5554ef=this['urlFn'](_0x3fdf86);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x5554ef),this['scriptTagHolder']['addTag'](_0x5554ef,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x73d732){const _0x48c798=O(_0x73d732);this['bytesSent']+=_0x48c798['length'],this['stats_']['incrementCounter']('bytes_sent',_0x48c798['length']);const _0x12b433=Hr(_0x48c798),_0x1dd9bf=oo(_0x12b433,fh);for(let _0x3ba2d4=0x0;_0x3ba2d4<_0x1dd9bf['length'];_0x3ba2d4++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x1dd9bf['length'],_0x1dd9bf[_0x3ba2d4]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x1f739b,_0x2b8c4d){this['myDisconnFrame']=document['createElement']('iframe');const _0x155ce6={};_0x155ce6[dh]='t',_0x155ce6[Eo]=_0x1f739b,_0x155ce6[Io]=_0x2b8c4d,this['myDisconnFrame']['src']=this['urlFn'](_0x155ce6),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x170089){const _0x5bbd3c=O(_0x170089)['length'];this['bytesReceived']+=_0x5bbd3c,this['stats_']['incrementCounter']('bytes_received',_0x5bbd3c);}}class qi{constructor(_0x2f78d2,_0x5537fa,_0x13224f,_0x421311){this['onDisconnect']=_0x13224f,this['urlFn']=_0x421311,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x2f78d2,window[ah+this['uniqueCallbackIdentifier']]=_0x5537fa,this['myIFrame']=qi['createIFrame_']();let _0x2ba883='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x2ba883='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x54c476='<html><body>'+_0x2ba883+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x54c476),this['myIFrame']['doc']['close']();}catch(_0x3eba1a){L('frame\x20writing\x20exception'),_0x3eba1a['stack']&&L(_0x3eba1a['stack']),L(_0x3eba1a);}}}static['createIFrame_'](){const _0x1c48ae=document['createElement']('iframe');if(_0x1c48ae['style']['display']='none',document['body']){document['body']['appendChild'](_0x1c48ae);try{_0x1c48ae['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0xe5be4=document['domain'];_0x1c48ae['src']='javascript:void((function(){document.open();document.domain=\x27'+_0xe5be4+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x1c48ae['contentDocument']?_0x1c48ae['doc']=_0x1c48ae['contentDocument']:_0x1c48ae['contentWindow']?_0x1c48ae['doc']=_0x1c48ae['contentWindow']['document']:_0x1c48ae['document']&&(_0x1c48ae['doc']=_0x1c48ae['document']),_0x1c48ae;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x1f539c=this['onDisconnect'];_0x1f539c&&(this['onDisconnect']=null,_0x1f539c());}['startLongPoll'](_0x3aa9ae,_0x14a24e){for(this['myID']=_0x3aa9ae,this['myPW']=_0x14a24e,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x38af6e={};_0x38af6e[Eo]=this['myID'],_0x38af6e[Io]=this['myPW'],_0x38af6e[wo]=this['currentSerial'];let _0x5b6e80=this['urlFn'](_0x38af6e),_0x1747d4='',_0x547044=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x1747d4['length']<=Co;){const _0x393ad6=this['pendingSegs']['shift']();_0x1747d4=_0x1747d4+'&'+lh+_0x547044+'='+_0x393ad6['seg']+'&'+hh+_0x547044+'='+_0x393ad6['ts']+'&'+uh+_0x547044+'='+_0x393ad6['d'],_0x547044++;}return _0x5b6e80=_0x5b6e80+_0x1747d4,this['addLongPollTag_'](_0x5b6e80,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x2a3661,_0x3135fe,_0x11a2af){this['pendingSegs']['push']({'seg':_0x2a3661,'ts':_0x3135fe,'d':_0x11a2af}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x435fae,_0x637305){this['outstandingRequests']['add'](_0x637305);const _0x5e62af=()=>{this['outstandingRequests']['delete'](_0x637305),this['newRequest_']();},_0x15621f=setTimeout(_0x5e62af,Math['floor'](ph)),_0x4003b4=()=>{clearTimeout(_0x15621f),_0x5e62af();};this['addTag'](_0x435fae,_0x4003b4);}['addTag'](_0x286bda,_0x39d9b5){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x5b7cb5=this['myIFrame']['doc']['createElement']('script');_0x5b7cb5['type']='text/javascript',_0x5b7cb5['async']=!0x0,_0x5b7cb5['src']=_0x286bda,_0x5b7cb5['onload']=_0x5b7cb5['onreadystatechange']=function(){const _0x4c4d77=_0x5b7cb5['readyState'];(!_0x4c4d77||_0x4c4d77==='loaded'||_0x4c4d77==='complete')&&(_0x5b7cb5['onload']=_0x5b7cb5['onreadystatechange']=null,_0x5b7cb5['parentNode']&&_0x5b7cb5['parentNode']['removeChild'](_0x5b7cb5),_0x39d9b5());},_0x5b7cb5['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x286bda),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x5b7cb5);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x2a8dc6,_0x2fc02e,_0x29fd5e,_0x536baf,_0xd4c168,_0x37ee81,_0x5ba629){this['connId']=_0x2a8dc6,this['applicationId']=_0x29fd5e,this['appCheckToken']=_0x536baf,this['authToken']=_0xd4c168,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x2fc02e),this['connURL']=z['connectionURL_'](_0x2fc02e,_0x37ee81,_0x5ba629,_0x536baf,_0x29fd5e),this['nodeAdmin']=_0x2fc02e['nodeAdmin'];}static['connectionURL_'](_0x15b5c9,_0x35ee78,_0x475bff,_0x280f7a,_0x4756b1){const _0x19e145={};return _0x19e145[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x19e145[ho]=uo),_0x35ee78&&(_0x19e145[lo]=_0x35ee78),_0x475bff&&(_0x19e145[po]=_0x475bff),_0x280f7a&&(_0x19e145[vi]=_0x280f7a),_0x4756b1&&(_0x19e145[_o]=_0x4756b1),vo(_0x15b5c9,go,_0x19e145);}['open'](_0x26d289,_0x153414){this['onDisconnect']=_0x153414,this['onMessage']=_0x26d289,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x30265d;_c(),this['mySock']=new un(this['connURL'],[],_0x30265d);}catch(_0x461109){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x2679c4=_0x461109['message']||_0x461109['data'];_0x2679c4&&this['log_'](_0x2679c4),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x473cba=>{this['handleIncomingFrame'](_0x473cba);},this['mySock']['onerror']=_0x1c00e7=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x139edf=_0x1c00e7['message']||_0x1c00e7['data'];_0x139edf&&this['log_'](_0x139edf),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x55b6cc=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x388e20=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x362059=navigator['userAgent']['match'](_0x388e20);_0x362059&&_0x362059['length']>0x1&&parseFloat(_0x362059[0x1])<4.4&&(_0x55b6cc=!0x0);}return!_0x55b6cc&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x3641d7){if(this['frames']['push'](_0x3641d7),this['frames']['length']===this['totalFrames']){const _0x5e85b2=this['frames']['join']('');this['frames']=null;const _0x1c57c1=At(_0x5e85b2);this['onMessage'](_0x1c57c1);}}['handleNewFrameCount_'](_0x3056b7){this['totalFrames']=_0x3056b7,this['frames']=[];}['extractFrameCount_'](_0x4d6cc4){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x4d6cc4['length']<=0x6){const _0x2ee597=Number(_0x4d6cc4);if(!isNaN(_0x2ee597))return this['handleNewFrameCount_'](_0x2ee597),null;}return this['handleNewFrameCount_'](0x1),_0x4d6cc4;}['handleIncomingFrame'](_0x28fb7a){if(this['mySock']===null)return;const _0x4f307d=_0x28fb7a['data'];if(this['bytesReceived']+=_0x4f307d['length'],this['stats_']['incrementCounter']('bytes_received',_0x4f307d['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x4f307d);else{const _0x6faa2e=this['extractFrameCount_'](_0x4f307d);_0x6faa2e!==null&&this['appendFrame_'](_0x6faa2e);}}['send'](_0x286e36){this['resetKeepAlive']();const _0x3fb468=O(_0x286e36);this['bytesSent']+=_0x3fb468['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3fb468['length']);const _0x583e79=oo(_0x3fb468,gh);_0x583e79['length']>0x1&&this['sendString_'](String(_0x583e79['length']));for(let _0x5e250e=0x0;_0x5e250e<_0x583e79['length'];_0x5e250e++)this['sendString_'](_0x583e79[_0x5e250e]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x1b7da2){try{this['mySock']['send'](_0x1b7da2);}catch(_0x2c95ff){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x2c95ff['message']||_0x2c95ff['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x415452){this['initTransports_'](_0x415452);}['initTransports_'](_0x18112f){const _0x328a3e=z&&z['isAvailable']();let _0x4787d5=_0x328a3e&&!z['previouslyFailed']();if(_0x18112f['webSocketOnly']&&(_0x328a3e||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x4787d5=!0x0),_0x4787d5)this['transports_']=[z];else{const _0x20c7f7=this['transports_']=[];for(const _0x4ca8fe of Nt['ALL_TRANSPORTS'])_0x4ca8fe&&_0x4ca8fe['isAvailable']()&&_0x20c7f7['push'](_0x4ca8fe);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x25b691,_0x19eda4,_0x513579,_0x3369cc,_0x22a423,_0x18cbf2,_0x1ee675,_0x576b9d,_0x42ff90,_0x53245b){this['id']=_0x25b691,this['repoInfo_']=_0x19eda4,this['applicationId_']=_0x513579,this['appCheckToken_']=_0x3369cc,this['authToken_']=_0x22a423,this['onMessage_']=_0x18cbf2,this['onReady_']=_0x1ee675,this['onDisconnect_']=_0x576b9d,this['onKill_']=_0x42ff90,this['lastSessionId']=_0x53245b,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x19eda4),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x479073=this['transportManager_']['initialTransport']();this['conn_']=new _0x479073(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x479073['responsesRequiredToBeHealthy']||0x0;const _0x2dc874=this['connReceiver_'](this['conn_']),_0x241e15=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x2dc874,_0x241e15);},Math['floor'](0x0));const _0x5eba0d=_0x479073['healthyTimeout']||0x0;_0x5eba0d>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x5eba0d)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x4bd83c){return _0x569c24=>{_0x4bd83c===this['conn_']?this['onConnectionLost_'](_0x569c24):_0x4bd83c===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x1acb86){return _0x61a078=>{this['state_']!==0x2&&(_0x1acb86===this['rx_']?this['onPrimaryMessageReceived_'](_0x61a078):_0x1acb86===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x61a078):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x4e2e84){const _0x26743c={'t':'d','d':_0x4e2e84};this['sendData_'](_0x26743c);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1a1cc3){if(si in _0x1a1cc3){const _0x50eb7c=_0x1a1cc3[si];_0x50eb7c===Qs?this['upgradeIfSecondaryHealthy_']():_0x50eb7c===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x50eb7c===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x6b24a4){const _0xb24683=_t('t',_0x6b24a4),_0x3f62b0=_t('d',_0x6b24a4);if(_0xb24683==='c')this['onSecondaryControl_'](_0x3f62b0);else{if(_0xb24683==='d')this['pendingDataMessages']['push'](_0x3f62b0);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0xb24683);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x2b819d){const _0x2c7ebb=_t('t',_0x2b819d),_0x567606=_t('d',_0x2b819d);_0x2c7ebb==='c'?this['onControl_'](_0x567606):_0x2c7ebb==='d'&&this['onDataMessage_'](_0x567606);}['onDataMessage_'](_0x1a1591){this['onPrimaryResponse_'](),this['onMessage_'](_0x1a1591);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x53a49c){const _0x257b75=_t(si,_0x53a49c);if(js in _0x53a49c){const _0x12c4a1=_0x53a49c[js];if(_0x257b75===Th){const _0x24544f={..._0x12c4a1};this['repoInfo_']['isUsingEmulator']&&(_0x24544f['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x24544f);}else{if(_0x257b75===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0xc14897=0x0;_0xc14897<this['pendingDataMessages']['length'];++_0xc14897)this['onDataMessage_'](this['pendingDataMessages'][_0xc14897]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x257b75===wh?this['onConnectionShutdown_'](_0x12c4a1):_0x257b75===Ks?this['onReset_'](_0x12c4a1):_0x257b75===Ch?yi('Server\x20Error:\x20'+_0x12c4a1):_0x257b75===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x257b75);}}}['onHandshake_'](_0x2e44ca){const _0x1f57aa=_0x2e44ca['ts'],_0x467311=_0x2e44ca['v'],_0x10c434=_0x2e44ca['h'];this['sessionId']=_0x2e44ca['s'],this['repoInfo_']['host']=_0x10c434,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x1f57aa),$i!==_0x467311&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x5d1a80=this['transportManager_']['upgradeTransport']();_0x5d1a80&&this['startUpgrade_'](_0x5d1a80);}['startUpgrade_'](_0x119613){this['secondaryConn_']=new _0x119613(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x119613['responsesRequiredToBeHealthy']||0x0;const _0x234fd2=this['connReceiver_'](this['secondaryConn_']),_0x54d221=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x234fd2,_0x54d221),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x4ee038){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x4ee038),this['repoInfo_']['host']=_0x4ee038,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x5156c8,_0x3275df){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x5156c8,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x3275df,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x5b8eac=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x5b8eac||this['rx_']===_0x5b8eac)&&this['close']();}['onConnectionLost_'](_0x4afd40){this['conn_']=null,!_0x4afd40&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x51fbcf){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x51fbcf),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x49cfb2){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x49cfb2);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x17f8df,_0x4974de,_0x56908c,_0x1e4d6d){}['merge'](_0x29c9d4,_0x379404,_0x3daf47,_0x294257){}['refreshAuthToken'](_0x2138cc){}['refreshAppCheckToken'](_0x3338d5){}['onDisconnectPut'](_0x254df0,_0x546342,_0x4b7da7){}['onDisconnectMerge'](_0x13db6c,_0x4e29e7,_0xd80835){}['onDisconnectCancel'](_0x1b93ac,_0x3deae1){}['reportStats'](_0x565679){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x59611a){this['allowedEvents_']=_0x59611a,this['listeners_']={},f(Array['isArray'](_0x59611a)&&_0x59611a['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x593df,..._0x565a1c){if(Array['isArray'](this['listeners_'][_0x593df])){const _0x3da2b0=[...this['listeners_'][_0x593df]];for(let _0x43c41f=0x0;_0x43c41f<_0x3da2b0['length'];_0x43c41f++)_0x3da2b0[_0x43c41f]['callback']['apply'](_0x3da2b0[_0x43c41f]['context'],_0x565a1c);}}['on'](_0x5b5751,_0x3d2be5,_0x1aa9cb){this['validateEventType_'](_0x5b5751),this['listeners_'][_0x5b5751]=this['listeners_'][_0x5b5751]||[],this['listeners_'][_0x5b5751]['push']({'callback':_0x3d2be5,'context':_0x1aa9cb});const _0x2c9706=this['getInitialEvent'](_0x5b5751);_0x2c9706&&_0x3d2be5['apply'](_0x1aa9cb,_0x2c9706);}['off'](_0x517774,_0x356445,_0x44cc49){this['validateEventType_'](_0x517774);const _0x302cad=this['listeners_'][_0x517774]||[];for(let _0x25103a=0x0;_0x25103a<_0x302cad['length'];_0x25103a++)if(_0x302cad[_0x25103a]['callback']===_0x356445&&(!_0x44cc49||_0x44cc49===_0x302cad[_0x25103a]['context'])){_0x302cad['splice'](_0x25103a,0x1);return;}}['validateEventType_'](_0x369fc8){f(this['allowedEvents_']['find'](_0xc536b5=>_0xc536b5===_0x369fc8),'Unknown\x20event:\x20'+_0x369fc8);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x301f08){return f(_0x301f08==='online','Unknown\x20event\x20type:\x20'+_0x301f08),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x3d3e57,_0x31638d){if(_0x31638d===void 0x0){this['pieces_']=_0x3d3e57['split']('/');let _0x31b5c6=0x0;for(let _0x344d58=0x0;_0x344d58<this['pieces_']['length'];_0x344d58++)this['pieces_'][_0x344d58]['length']>0x0&&(this['pieces_'][_0x31b5c6]=this['pieces_'][_0x344d58],_0x31b5c6++);this['pieces_']['length']=_0x31b5c6,this['pieceNum_']=0x0;}else this['pieces_']=_0x3d3e57,this['pieceNum_']=_0x31638d;}['toString'](){let _0x2ee529='';for(let _0x4d202e=this['pieceNum_'];_0x4d202e<this['pieces_']['length'];_0x4d202e++)this['pieces_'][_0x4d202e]!==''&&(_0x2ee529+='/'+this['pieces_'][_0x4d202e]);return _0x2ee529||'/';}}function w(){return new C('');}function y(_0x7347f6){return _0x7347f6['pieceNum_']>=_0x7347f6['pieces_']['length']?null:_0x7347f6['pieces_'][_0x7347f6['pieceNum_']];}function we(_0x4b1d2a){return _0x4b1d2a['pieces_']['length']-_0x4b1d2a['pieceNum_'];}function b(_0x549667){let _0xc32ee4=_0x549667['pieceNum_'];return _0xc32ee4<_0x549667['pieces_']['length']&&_0xc32ee4++,new C(_0x549667['pieces_'],_0xc32ee4);}function zi(_0x559932){return _0x559932['pieceNum_']<_0x559932['pieces_']['length']?_0x559932['pieces_'][_0x559932['pieces_']['length']-0x1]:null;}function bh(_0x53f113){let _0x2c37a3='';for(let _0xe18f0e=_0x53f113['pieceNum_'];_0xe18f0e<_0x53f113['pieces_']['length'];_0xe18f0e++)_0x53f113['pieces_'][_0xe18f0e]!==''&&(_0x2c37a3+='/'+encodeURIComponent(String(_0x53f113['pieces_'][_0xe18f0e])));return _0x2c37a3||'/';}function Pt(_0x5539d3,_0x1f4d6b=0x0){return _0x5539d3['pieces_']['slice'](_0x5539d3['pieceNum_']+_0x1f4d6b);}function Ro(_0x4964ae){if(_0x4964ae['pieceNum_']>=_0x4964ae['pieces_']['length'])return null;const _0x52daf6=[];for(let _0x119ed0=_0x4964ae['pieceNum_'];_0x119ed0<_0x4964ae['pieces_']['length']-0x1;_0x119ed0++)_0x52daf6['push'](_0x4964ae['pieces_'][_0x119ed0]);return new C(_0x52daf6,0x0);}function k(_0x295958,_0x51e9e8){const _0x1d2a4b=[];for(let _0x3fa774=_0x295958['pieceNum_'];_0x3fa774<_0x295958['pieces_']['length'];_0x3fa774++)_0x1d2a4b['push'](_0x295958['pieces_'][_0x3fa774]);if(_0x51e9e8 instanceof C){for(let _0x26a9fd=_0x51e9e8['pieceNum_'];_0x26a9fd<_0x51e9e8['pieces_']['length'];_0x26a9fd++)_0x1d2a4b['push'](_0x51e9e8['pieces_'][_0x26a9fd]);}else{const _0xc6457d=_0x51e9e8['split']('/');for(let _0x5bcc6a=0x0;_0x5bcc6a<_0xc6457d['length'];_0x5bcc6a++)_0xc6457d[_0x5bcc6a]['length']>0x0&&_0x1d2a4b['push'](_0xc6457d[_0x5bcc6a]);}return new C(_0x1d2a4b,0x0);}function v(_0x565de3){return _0x565de3['pieceNum_']>=_0x565de3['pieces_']['length'];}function F(_0x3c6cf8,_0x5a414e){const _0x528d74=y(_0x3c6cf8),_0x33cb06=y(_0x5a414e);if(_0x528d74===null)return _0x5a414e;if(_0x528d74===_0x33cb06)return F(b(_0x3c6cf8),b(_0x5a414e));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x5a414e+')\x20is\x20not\x20within\x20outerPath\x20('+_0x3c6cf8+')');}function Rh(_0x534ac8,_0x262c77){const _0x2b4eed=Pt(_0x534ac8,0x0),_0x139bf5=Pt(_0x262c77,0x0);for(let _0xeae342=0x0;_0xeae342<_0x2b4eed['length']&&_0xeae342<_0x139bf5['length'];_0xeae342++){const _0x16f6f7=He(_0x2b4eed[_0xeae342],_0x139bf5[_0xeae342]);if(_0x16f6f7!==0x0)return _0x16f6f7;}return _0x2b4eed['length']===_0x139bf5['length']?0x0:_0x2b4eed['length']<_0x139bf5['length']?-0x1:0x1;}function ji(_0x2a00e9,_0x234b97){if(we(_0x2a00e9)!==we(_0x234b97))return!0x1;for(let _0x24a5d7=_0x2a00e9['pieceNum_'],_0x2881ca=_0x234b97['pieceNum_'];_0x24a5d7<=_0x2a00e9['pieces_']['length'];_0x24a5d7++,_0x2881ca++)if(_0x2a00e9['pieces_'][_0x24a5d7]!==_0x234b97['pieces_'][_0x2881ca])return!0x1;return!0x0;}function G(_0x542a36,_0x47370){let _0x2f2398=_0x542a36['pieceNum_'],_0x294356=_0x47370['pieceNum_'];if(we(_0x542a36)>we(_0x47370))return!0x1;for(;_0x2f2398<_0x542a36['pieces_']['length'];){if(_0x542a36['pieces_'][_0x2f2398]!==_0x47370['pieces_'][_0x294356])return!0x1;++_0x2f2398,++_0x294356;}return!0x0;}class Ah{constructor(_0x21a8d0,_0x2e72dd){this['errorPrefix_']=_0x2e72dd,this['parts_']=Pt(_0x21a8d0,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x4faeaa=0x0;_0x4faeaa<this['parts_']['length'];_0x4faeaa++)this['byteLength_']+=On(this['parts_'][_0x4faeaa]);Ao(this);}}function kh(_0x258d4e,_0x46afe1){_0x258d4e['parts_']['length']>0x0&&(_0x258d4e['byteLength_']+=0x1),_0x258d4e['parts_']['push'](_0x46afe1),_0x258d4e['byteLength_']+=On(_0x46afe1),Ao(_0x258d4e);}function Nh(_0x5be825){const _0x103c26=_0x5be825['parts_']['pop']();_0x5be825['byteLength_']-=On(_0x103c26),_0x5be825['parts_']['length']>0x0&&(_0x5be825['byteLength_']-=0x1);}function Ao(_0x846e9c){if(_0x846e9c['byteLength_']>er)throw new Error(_0x846e9c['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x846e9c['byteLength_']+').');if(_0x846e9c['parts_']['length']>Zs)throw new Error(_0x846e9c['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x846e9c));}function Pe(_0x2a3a02){return _0x2a3a02['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x2a3a02['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x3002a1,_0x3bb5ab;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x3bb5ab='visibilitychange',_0x3002a1='hidden'):typeof document['mozHidden']<'u'?(_0x3bb5ab='mozvisibilitychange',_0x3002a1='mozHidden'):typeof document['msHidden']<'u'?(_0x3bb5ab='msvisibilitychange',_0x3002a1='msHidden'):typeof document['webkitHidden']<'u'&&(_0x3bb5ab='webkitvisibilitychange',_0x3002a1='webkitHidden')),this['visible_']=!0x0,_0x3bb5ab&&document['addEventListener'](_0x3bb5ab,()=>{const _0x430fc9=!document[_0x3002a1];_0x430fc9!==this['visible_']&&(this['visible_']=_0x430fc9,this['trigger']('visible',_0x430fc9));},!0x1);}['getInitialEvent'](_0x25764f){return f(_0x25764f==='visible','Unknown\x20event\x20type:\x20'+_0x25764f),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x20f567,_0x1bafb5,_0x2fea92,_0x502871,_0x23abcc,_0x38f884,_0x226973,_0x186928){if(super(),this['repoInfo_']=_0x20f567,this['applicationId_']=_0x1bafb5,this['onDataUpdate_']=_0x2fea92,this['onConnectStatus_']=_0x502871,this['onServerInfoUpdate_']=_0x23abcc,this['authTokenProvider_']=_0x38f884,this['appCheckTokenProvider_']=_0x226973,this['authOverride_']=_0x186928,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x186928)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x20f567['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x4d3a02,_0x316ea3,_0x440d16){const _0x4f790d=++this['requestNumber_'],_0x29aaf7={'r':_0x4f790d,'a':_0x4d3a02,'b':_0x316ea3};this['log_'](O(_0x29aaf7)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x29aaf7),_0x440d16&&(this['requestCBHash_'][_0x4f790d]=_0x440d16);}['get'](_0x6c9d07){this['initConnection_']();const _0xb4afd6=new ot(),_0x541d25={'action':'g','request':{'p':_0x6c9d07['_path']['toString'](),'q':_0x6c9d07['_queryObject']},'onComplete':_0x49adcf=>{const _0x303ae5=_0x49adcf['d'];_0x49adcf['s']==='ok'?_0xb4afd6['resolve'](_0x303ae5):_0xb4afd6['reject'](_0x303ae5);}};this['outstandingGets_']['push'](_0x541d25),this['outstandingGetCount_']++;const _0xaab655=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0xaab655),_0xb4afd6['promise'];}['listen'](_0x5320eb,_0x5ea376,_0x3ea333,_0x54d29b){this['initConnection_']();const _0x240116=_0x5320eb['_queryIdentifier'],_0x260bdb=_0x5320eb['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x260bdb+'\x20'+_0x240116),this['listens']['has'](_0x260bdb)||this['listens']['set'](_0x260bdb,new Map()),f(_0x5320eb['_queryParams']['isDefault']()||!_0x5320eb['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x260bdb)['has'](_0x240116),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x195233={'onComplete':_0x54d29b,'hashFn':_0x5ea376,'query':_0x5320eb,'tag':_0x3ea333};this['listens']['get'](_0x260bdb)['set'](_0x240116,_0x195233),this['connected_']&&this['sendListen_'](_0x195233);}['sendGet_'](_0x426266){const _0x5a1556=this['outstandingGets_'][_0x426266];this['sendRequest']('g',_0x5a1556['request'],_0x1e482e=>{delete this['outstandingGets_'][_0x426266],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x5a1556['onComplete']&&_0x5a1556['onComplete'](_0x1e482e);});}['sendListen_'](_0x618ff){const _0x3a1267=_0x618ff['query'],_0x43c857=_0x3a1267['_path']['toString'](),_0x23fb1a=_0x3a1267['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x43c857+'\x20for\x20'+_0x23fb1a);const _0x50f6d1={'p':_0x43c857},_0x57a740='q';_0x618ff['tag']&&(_0x50f6d1['q']=_0x3a1267['_queryObject'],_0x50f6d1['t']=_0x618ff['tag']),_0x50f6d1['h']=_0x618ff['hashFn'](),this['sendRequest'](_0x57a740,_0x50f6d1,_0x50c250=>{const _0x338a82=_0x50c250['d'],_0x52057c=_0x50c250['s'];se['warnOnListenWarnings_'](_0x338a82,_0x3a1267),(this['listens']['get'](_0x43c857)&&this['listens']['get'](_0x43c857)['get'](_0x23fb1a))===_0x618ff&&(this['log_']('listen\x20response',_0x50c250),_0x52057c!=='ok'&&this['removeListen_'](_0x43c857,_0x23fb1a),_0x618ff['onComplete']&&_0x618ff['onComplete'](_0x52057c,_0x338a82));});}static['warnOnListenWarnings_'](_0x27768a,_0xbd62ee){if(_0x27768a&&typeof _0x27768a=='object'&&J(_0x27768a,'w')){const _0x2974db=De(_0x27768a,'w');if(Array['isArray'](_0x2974db)&&~_0x2974db['indexOf']('no_index')){const _0x272180='\x22.indexOn\x22:\x20\x22'+_0xbd62ee['_queryParams']['getIndex']()['toString']()+'\x22',_0x32a8a8=_0xbd62ee['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x272180+'\x20at\x20'+_0x32a8a8+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x144fb7){this['authToken_']=_0x144fb7,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x144fb7);}['reduceReconnectDelayIfAdminCredential_'](_0x16d0d1){(_0x16d0d1&&_0x16d0d1['length']===0x28||wc(_0x16d0d1))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x593b81){this['appCheckToken_']=_0x593b81,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x2e4826=this['authToken_'],_0x34526e=Ic(_0x2e4826)?'auth':'gauth',_0x1025ca={'cred':_0x2e4826};this['authOverride_']===null?_0x1025ca['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x1025ca['authvar']=this['authOverride_']),this['sendRequest'](_0x34526e,_0x1025ca,_0xd5baa8=>{const _0x751aad=_0xd5baa8['s'],_0x29f6bc=_0xd5baa8['d']||'error';this['authToken_']===_0x2e4826&&(_0x751aad==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x751aad,_0x29f6bc));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0xfd19d9=>{const _0x150dc2=_0xfd19d9['s'],_0x347b67=_0xfd19d9['d']||'error';_0x150dc2==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x150dc2,_0x347b67);});}['unlisten'](_0xffd8c4,_0x2e85e9){const _0x17722f=_0xffd8c4['_path']['toString'](),_0x228355=_0xffd8c4['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x17722f+'\x20'+_0x228355),f(_0xffd8c4['_queryParams']['isDefault']()||!_0xffd8c4['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x17722f,_0x228355)&&this['connected_']&&this['sendUnlisten_'](_0x17722f,_0x228355,_0xffd8c4['_queryObject'],_0x2e85e9);}['sendUnlisten_'](_0x194e27,_0x12321a,_0xce2c1c,_0x43fb0d){this['log_']('Unlisten\x20on\x20'+_0x194e27+'\x20for\x20'+_0x12321a);const _0x2bfcbf={'p':_0x194e27},_0x1acf2e='n';_0x43fb0d&&(_0x2bfcbf['q']=_0xce2c1c,_0x2bfcbf['t']=_0x43fb0d),this['sendRequest'](_0x1acf2e,_0x2bfcbf);}['onDisconnectPut'](_0x4347ea,_0x1f01be,_0x5eccc3){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x4347ea,_0x1f01be,_0x5eccc3):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4347ea,'action':'o','data':_0x1f01be,'onComplete':_0x5eccc3});}['onDisconnectMerge'](_0x30366b,_0xca2a1a,_0x509be2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x30366b,_0xca2a1a,_0x509be2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x30366b,'action':'om','data':_0xca2a1a,'onComplete':_0x509be2});}['onDisconnectCancel'](_0x5deacf,_0x2761a4){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x5deacf,null,_0x2761a4):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5deacf,'action':'oc','data':null,'onComplete':_0x2761a4});}['sendOnDisconnect_'](_0x4f2749,_0x6011d,_0x450230,_0x86d73a){const _0x1bf2d7={'p':_0x6011d,'d':_0x450230};this['log_']('onDisconnect\x20'+_0x4f2749,_0x1bf2d7),this['sendRequest'](_0x4f2749,_0x1bf2d7,_0x53c719=>{_0x86d73a&&setTimeout(()=>{_0x86d73a(_0x53c719['s'],_0x53c719['d']);},Math['floor'](0x0));});}['put'](_0x28b269,_0x1e6e2e,_0x1dd91e,_0xbf1f0f){this['putInternal']('p',_0x28b269,_0x1e6e2e,_0x1dd91e,_0xbf1f0f);}['merge'](_0x292095,_0x1588a8,_0x2b63c4,_0x5b201f){this['putInternal']('m',_0x292095,_0x1588a8,_0x2b63c4,_0x5b201f);}['putInternal'](_0xa8006d,_0x48c1e9,_0x174725,_0x1e7b8d,_0x536ca0){this['initConnection_']();const _0x18b281={'p':_0x48c1e9,'d':_0x174725};_0x536ca0!==void 0x0&&(_0x18b281['h']=_0x536ca0),this['outstandingPuts_']['push']({'action':_0xa8006d,'request':_0x18b281,'onComplete':_0x1e7b8d}),this['outstandingPutCount_']++;const _0x4bae22=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x4bae22):this['log_']('Buffering\x20put:\x20'+_0x48c1e9);}['sendPut_'](_0x2abc63){const _0x2f00cb=this['outstandingPuts_'][_0x2abc63]['action'],_0x208d6f=this['outstandingPuts_'][_0x2abc63]['request'],_0x2b9c36=this['outstandingPuts_'][_0x2abc63]['onComplete'];this['outstandingPuts_'][_0x2abc63]['queued']=this['connected_'],this['sendRequest'](_0x2f00cb,_0x208d6f,_0x3aa209=>{this['log_'](_0x2f00cb+'\x20response',_0x3aa209),delete this['outstandingPuts_'][_0x2abc63],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x2b9c36&&_0x2b9c36(_0x3aa209['s'],_0x3aa209['d']);});}['reportStats'](_0x5a1d58){if(this['connected_']){const _0x1cfc84={'c':_0x5a1d58};this['log_']('reportStats',_0x1cfc84),this['sendRequest']('s',_0x1cfc84,_0x5dd2ab=>{if(_0x5dd2ab['s']!=='ok'){const _0x2c00f0=_0x5dd2ab['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x2c00f0);}});}}['onDataMessage_'](_0x5485ba){if('r'in _0x5485ba){this['log_']('from\x20server:\x20'+O(_0x5485ba));const _0x1b1599=_0x5485ba['r'],_0x350e9d=this['requestCBHash_'][_0x1b1599];_0x350e9d&&(delete this['requestCBHash_'][_0x1b1599],_0x350e9d(_0x5485ba['b']));}else{if('error'in _0x5485ba)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x5485ba['error'];'a'in _0x5485ba&&this['onDataPush_'](_0x5485ba['a'],_0x5485ba['b']);}}['onDataPush_'](_0x4e9a89,_0x335b90){this['log_']('handleServerMessage',_0x4e9a89,_0x335b90),_0x4e9a89==='d'?this['onDataUpdate_'](_0x335b90['p'],_0x335b90['d'],!0x1,_0x335b90['t']):_0x4e9a89==='m'?this['onDataUpdate_'](_0x335b90['p'],_0x335b90['d'],!0x0,_0x335b90['t']):_0x4e9a89==='c'?this['onListenRevoked_'](_0x335b90['p'],_0x335b90['q']):_0x4e9a89==='ac'?this['onAuthRevoked_'](_0x335b90['s'],_0x335b90['d']):_0x4e9a89==='apc'?this['onAppCheckRevoked_'](_0x335b90['s'],_0x335b90['d']):_0x4e9a89==='sd'?this['onSecurityDebugPacket_'](_0x335b90):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x4e9a89)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x5e7670,_0x451b25){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x5e7670),this['lastSessionId']=_0x451b25,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x34e7eb){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x34e7eb));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x389ef8){_0x389ef8&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x389ef8;}['onOnline_'](_0x273e64){_0x273e64?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0xdb80c=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x545f39=Math['max'](0x0,this['reconnectDelay_']-_0xdb80c);_0x545f39=Math['random']()*_0x545f39,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x545f39+'ms'),this['scheduleConnect_'](_0x545f39),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x472a5e=this['onDataMessage_']['bind'](this),_0xa3187f=this['onReady_']['bind'](this),_0x1628ae=this['onRealtimeDisconnect_']['bind'](this),_0x538ba4=this['id']+':'+se['nextConnectionId_']++,_0x3f2f07=this['lastSessionId'];let _0x11909e=!0x1,_0x321ae7=null;const _0x5afa08=function(){_0x321ae7?_0x321ae7['close']():(_0x11909e=!0x0,_0x1628ae());},_0x1bc581=function(_0x28cc70){f(_0x321ae7,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x321ae7['sendRequest'](_0x28cc70);};this['realtime_']={'close':_0x5afa08,'sendRequest':_0x1bc581};const _0x39f1ac=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x95107f,_0x3e6656]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x39f1ac),this['appCheckTokenProvider_']['getToken'](_0x39f1ac)]);_0x11909e?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x95107f&&_0x95107f['accessToken'],this['appCheckToken_']=_0x3e6656&&_0x3e6656['token'],_0x321ae7=new Sh(_0x538ba4,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x472a5e,_0xa3187f,_0x1628ae,_0x51175a=>{U(_0x51175a+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x3f2f07));}catch(_0x1e8d33){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x1e8d33),_0x11909e||(this['repoInfo_']['nodeAdmin']&&U(_0x1e8d33),_0x5afa08());}}}['interrupt'](_0x246cad){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x246cad),this['interruptReasons_'][_0x246cad]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x4d71e1){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x4d71e1),delete this['interruptReasons_'][_0x4d71e1],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x16d3ef){const _0x14be1b=_0x16d3ef-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x14be1b});}['cancelSentTransactions_'](){for(let _0x2ba7d1=0x0;_0x2ba7d1<this['outstandingPuts_']['length'];_0x2ba7d1++){const _0x382cf7=this['outstandingPuts_'][_0x2ba7d1];_0x382cf7&&'h'in _0x382cf7['request']&&_0x382cf7['queued']&&(_0x382cf7['onComplete']&&_0x382cf7['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x2ba7d1],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x134ff6,_0xd7c9c4){let _0xa9cfba;_0xd7c9c4?_0xa9cfba=_0xd7c9c4['map'](_0x3e7c83=>Hi(_0x3e7c83))['join']('$'):_0xa9cfba='default';const _0x643eae=this['removeListen_'](_0x134ff6,_0xa9cfba);_0x643eae&&_0x643eae['onComplete']&&_0x643eae['onComplete']('permission_denied');}['removeListen_'](_0x851e80,_0x2218ba){const _0x436b6=new C(_0x851e80)['toString']();let _0x3178f6;if(this['listens']['has'](_0x436b6)){const _0x1bfcd4=this['listens']['get'](_0x436b6);_0x3178f6=_0x1bfcd4['get'](_0x2218ba),_0x1bfcd4['delete'](_0x2218ba),_0x1bfcd4['size']===0x0&&this['listens']['delete'](_0x436b6);}else _0x3178f6=void 0x0;return _0x3178f6;}['onAuthRevoked_'](_0x3fa2c2,_0x5e96f7){L('Auth\x20token\x20revoked:\x20'+_0x3fa2c2+'/'+_0x5e96f7),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x3fa2c2==='invalid_token'||_0x3fa2c2==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x124f50,_0x32d2e5){L('App\x20check\x20token\x20revoked:\x20'+_0x124f50+'/'+_0x32d2e5),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x124f50==='invalid_token'||_0x124f50==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x769b02){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x769b02):'msg'in _0x769b02&&console['log']('FIREBASE:\x20'+_0x769b02['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x24557d of this['listens']['values']())for(const _0x5e46ee of _0x24557d['values']())this['sendListen_'](_0x5e46ee);for(let _0xf25a99=0x0;_0xf25a99<this['outstandingPuts_']['length'];_0xf25a99++)this['outstandingPuts_'][_0xf25a99]&&this['sendPut_'](_0xf25a99);for(;this['onDisconnectRequestQueue_']['length'];){const _0x3f2f73=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x3f2f73['action'],_0x3f2f73['pathString'],_0x3f2f73['data'],_0x3f2f73['onComplete']);}for(let _0x1880f7=0x0;_0x1880f7<this['outstandingGets_']['length'];_0x1880f7++)this['outstandingGets_'][_0x1880f7]&&this['sendGet_'](_0x1880f7);}['sendConnectStats_'](){const _0x16045a={};let _0x585b1b='js';_0x16045a['sdk.'+_0x585b1b+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x16045a['framework.cordova']=0x1:Yr()&&(_0x16045a['framework.reactnative']=0x1),this['reportStats'](_0x16045a);}['shouldReconnect_'](){const _0x40aef2=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x40aef2;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x1d75fa,_0x35ffdd){this['name']=_0x1d75fa,this['node']=_0x35ffdd;}static['Wrap'](_0xe266d1,_0x32d3a3){return new E(_0xe266d1,_0x32d3a3);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x2a4234,_0x452eae){const _0x329084=new E(Fe,_0x2a4234),_0x24e9bb=new E(Fe,_0x452eae);return this['compare'](_0x329084,_0x24e9bb)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x6485e1){Zt=_0x6485e1;}['compare'](_0x5c46ae,_0x3be9fb){return He(_0x5c46ae['name'],_0x3be9fb['name']);}['isDefinedOn'](_0xca8962){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x46d349,_0x18d15f){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x3cf68d,_0x57e60a){return f(typeof _0x3cf68d=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x3cf68d,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x2e54b9,_0x4aabd4,_0x49bbe5,_0x563b4a,_0x3e2ade=null){this['isReverse_']=_0x563b4a,this['resultGenerator_']=_0x3e2ade,this['nodeStack_']=[];let _0x12065f=0x1;for(;!_0x2e54b9['isEmpty']();)if(_0x2e54b9=_0x2e54b9,_0x12065f=_0x4aabd4?_0x49bbe5(_0x2e54b9['key'],_0x4aabd4):0x1,_0x563b4a&&(_0x12065f*=-0x1),_0x12065f<0x0)this['isReverse_']?_0x2e54b9=_0x2e54b9['left']:_0x2e54b9=_0x2e54b9['right'];else{if(_0x12065f===0x0){this['nodeStack_']['push'](_0x2e54b9);break;}else this['nodeStack_']['push'](_0x2e54b9),this['isReverse_']?_0x2e54b9=_0x2e54b9['right']:_0x2e54b9=_0x2e54b9['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x5aec22=this['nodeStack_']['pop'](),_0x20db2c;if(this['resultGenerator_']?_0x20db2c=this['resultGenerator_'](_0x5aec22['key'],_0x5aec22['value']):_0x20db2c={'key':_0x5aec22['key'],'value':_0x5aec22['value']},this['isReverse_']){for(_0x5aec22=_0x5aec22['left'];!_0x5aec22['isEmpty']();)this['nodeStack_']['push'](_0x5aec22),_0x5aec22=_0x5aec22['right'];}else{for(_0x5aec22=_0x5aec22['right'];!_0x5aec22['isEmpty']();)this['nodeStack_']['push'](_0x5aec22),_0x5aec22=_0x5aec22['left'];}return _0x20db2c;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x4a56d3=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x4a56d3['key'],_0x4a56d3['value']):{'key':_0x4a56d3['key'],'value':_0x4a56d3['value']};}}class M{constructor(_0x2ee97a,_0x2cce75,_0x90d593,_0x1ea190,_0x4543b7){this['key']=_0x2ee97a,this['value']=_0x2cce75,this['color']=_0x90d593??M['RED'],this['left']=_0x1ea190??B['EMPTY_NODE'],this['right']=_0x4543b7??B['EMPTY_NODE'];}['copy'](_0x23156c,_0x409ea9,_0x5ccc99,_0x7ac4df,_0x58534b){return new M(_0x23156c??this['key'],_0x409ea9??this['value'],_0x5ccc99??this['color'],_0x7ac4df??this['left'],_0x58534b??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x316c65){return this['left']['inorderTraversal'](_0x316c65)||!!_0x316c65(this['key'],this['value'])||this['right']['inorderTraversal'](_0x316c65);}['reverseTraversal'](_0x4b6d19){return this['right']['reverseTraversal'](_0x4b6d19)||_0x4b6d19(this['key'],this['value'])||this['left']['reverseTraversal'](_0x4b6d19);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x325287,_0x3a9ef3,_0x531e98){let _0x18fd67=this;const _0x2f9955=_0x531e98(_0x325287,_0x18fd67['key']);return _0x2f9955<0x0?_0x18fd67=_0x18fd67['copy'](null,null,null,_0x18fd67['left']['insert'](_0x325287,_0x3a9ef3,_0x531e98),null):_0x2f9955===0x0?_0x18fd67=_0x18fd67['copy'](null,_0x3a9ef3,null,null,null):_0x18fd67=_0x18fd67['copy'](null,null,null,null,_0x18fd67['right']['insert'](_0x325287,_0x3a9ef3,_0x531e98)),_0x18fd67['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x3fdf85=this;return!_0x3fdf85['left']['isRed_']()&&!_0x3fdf85['left']['left']['isRed_']()&&(_0x3fdf85=_0x3fdf85['moveRedLeft_']()),_0x3fdf85=_0x3fdf85['copy'](null,null,null,_0x3fdf85['left']['removeMin_'](),null),_0x3fdf85['fixUp_']();}['remove'](_0x141c3e,_0x5352fe){let _0x44cf3d,_0x522df5;if(_0x44cf3d=this,_0x5352fe(_0x141c3e,_0x44cf3d['key'])<0x0)!_0x44cf3d['left']['isEmpty']()&&!_0x44cf3d['left']['isRed_']()&&!_0x44cf3d['left']['left']['isRed_']()&&(_0x44cf3d=_0x44cf3d['moveRedLeft_']()),_0x44cf3d=_0x44cf3d['copy'](null,null,null,_0x44cf3d['left']['remove'](_0x141c3e,_0x5352fe),null);else{if(_0x44cf3d['left']['isRed_']()&&(_0x44cf3d=_0x44cf3d['rotateRight_']()),!_0x44cf3d['right']['isEmpty']()&&!_0x44cf3d['right']['isRed_']()&&!_0x44cf3d['right']['left']['isRed_']()&&(_0x44cf3d=_0x44cf3d['moveRedRight_']()),_0x5352fe(_0x141c3e,_0x44cf3d['key'])===0x0){if(_0x44cf3d['right']['isEmpty']())return B['EMPTY_NODE'];_0x522df5=_0x44cf3d['right']['min_'](),_0x44cf3d=_0x44cf3d['copy'](_0x522df5['key'],_0x522df5['value'],null,null,_0x44cf3d['right']['removeMin_']());}_0x44cf3d=_0x44cf3d['copy'](null,null,null,null,_0x44cf3d['right']['remove'](_0x141c3e,_0x5352fe));}return _0x44cf3d['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x4ea935=this;return _0x4ea935['right']['isRed_']()&&!_0x4ea935['left']['isRed_']()&&(_0x4ea935=_0x4ea935['rotateLeft_']()),_0x4ea935['left']['isRed_']()&&_0x4ea935['left']['left']['isRed_']()&&(_0x4ea935=_0x4ea935['rotateRight_']()),_0x4ea935['left']['isRed_']()&&_0x4ea935['right']['isRed_']()&&(_0x4ea935=_0x4ea935['colorFlip_']()),_0x4ea935;}['moveRedLeft_'](){let _0x1fc029=this['colorFlip_']();return _0x1fc029['right']['left']['isRed_']()&&(_0x1fc029=_0x1fc029['copy'](null,null,null,null,_0x1fc029['right']['rotateRight_']()),_0x1fc029=_0x1fc029['rotateLeft_'](),_0x1fc029=_0x1fc029['colorFlip_']()),_0x1fc029;}['moveRedRight_'](){let _0x3fbab1=this['colorFlip_']();return _0x3fbab1['left']['left']['isRed_']()&&(_0x3fbab1=_0x3fbab1['rotateRight_'](),_0x3fbab1=_0x3fbab1['colorFlip_']()),_0x3fbab1;}['rotateLeft_'](){const _0x53d01f=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x53d01f,null);}['rotateRight_'](){const _0x34cafa=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x34cafa);}['colorFlip_'](){const _0x5b5077=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x22e08e=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x5b5077,_0x22e08e);}['checkMaxDepth_'](){const _0x3ac69c=this['check_']();return Math['pow'](0x2,_0x3ac69c)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0xa1ea20=this['left']['check_']();if(_0xa1ea20!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0xa1ea20+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x10b456,_0x82cc79,_0x116960,_0x28f9e7,_0x48b482){return this;}['insert'](_0x39a91e,_0x57f757,_0x464b80){return new M(_0x39a91e,_0x57f757,null);}['remove'](_0x2ff4fc,_0x513fa6){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x3b1b7b){return!0x1;}['reverseTraversal'](_0x3739a5){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x28acd7,_0x2a637f=B['EMPTY_NODE']){this['comparator_']=_0x28acd7,this['root_']=_0x2a637f;}['insert'](_0x6fad1c,_0x3c4738){return new B(this['comparator_'],this['root_']['insert'](_0x6fad1c,_0x3c4738,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x4197cc){return new B(this['comparator_'],this['root_']['remove'](_0x4197cc,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x1053bc){let _0x107709,_0x59b5b2=this['root_'];for(;!_0x59b5b2['isEmpty']();){if(_0x107709=this['comparator_'](_0x1053bc,_0x59b5b2['key']),_0x107709===0x0)return _0x59b5b2['value'];_0x107709<0x0?_0x59b5b2=_0x59b5b2['left']:_0x107709>0x0&&(_0x59b5b2=_0x59b5b2['right']);}return null;}['getPredecessorKey'](_0x52ddee){let _0x231c17,_0x3a6660=this['root_'],_0x478ff8=null;for(;!_0x3a6660['isEmpty']();)if(_0x231c17=this['comparator_'](_0x52ddee,_0x3a6660['key']),_0x231c17===0x0){if(_0x3a6660['left']['isEmpty']())return _0x478ff8?_0x478ff8['key']:null;for(_0x3a6660=_0x3a6660['left'];!_0x3a6660['right']['isEmpty']();)_0x3a6660=_0x3a6660['right'];return _0x3a6660['key'];}else _0x231c17<0x0?_0x3a6660=_0x3a6660['left']:_0x231c17>0x0&&(_0x478ff8=_0x3a6660,_0x3a6660=_0x3a6660['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x4d92fb){return this['root_']['inorderTraversal'](_0x4d92fb);}['reverseTraversal'](_0x339aa6){return this['root_']['reverseTraversal'](_0x339aa6);}['getIterator'](_0x5524ab){return new en(this['root_'],null,this['comparator_'],!0x1,_0x5524ab);}['getIteratorFrom'](_0x4f139f,_0x1c5408){return new en(this['root_'],_0x4f139f,this['comparator_'],!0x1,_0x1c5408);}['getReverseIteratorFrom'](_0x56669b,_0x14a5ca){return new en(this['root_'],_0x56669b,this['comparator_'],!0x0,_0x14a5ca);}['getReverseIterator'](_0x52bcfa){return new en(this['root_'],null,this['comparator_'],!0x0,_0x52bcfa);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x1828ca,_0x2a801f){return He(_0x1828ca['name'],_0x2a801f['name']);}function Yi(_0x38c317,_0x427081){return He(_0x38c317,_0x427081);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x327b69){Ei=_0x327b69;}const No=function(_0x5257b6){return typeof _0x5257b6=='number'?'number:'+ao(_0x5257b6):'string:'+_0x5257b6;},Po=function(_0x2f872a){if(_0x2f872a['isLeafNode']()){const _0x8e6ab9=_0x2f872a['val']();f(typeof _0x8e6ab9=='string'||typeof _0x8e6ab9=='number'||typeof _0x8e6ab9=='object'&&J(_0x8e6ab9,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x2f872a===Ei||_0x2f872a['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x2f872a===Ei||_0x2f872a['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x1b03d0){ir=_0x1b03d0;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x482712,_0x43c124=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x482712,this['priorityNode_']=_0x43c124,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x33c869){return new D(this['value_'],_0x33c869);}['getImmediateChild'](_0x55db2f){return _0x55db2f==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x55ed22){return v(_0x55ed22)?this:y(_0x55ed22)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x4a21b1,_0x474e56){return null;}['updateImmediateChild'](_0x2b2f5d,_0x2935ab){return _0x2b2f5d==='.priority'?this['updatePriority'](_0x2935ab):_0x2935ab['isEmpty']()&&_0x2b2f5d!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x2b2f5d,_0x2935ab)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x553aa5,_0x1ec57e){const _0x58377a=y(_0x553aa5);return _0x58377a===null?_0x1ec57e:_0x1ec57e['isEmpty']()&&_0x58377a!=='.priority'?this:(f(_0x58377a!=='.priority'||we(_0x553aa5)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x58377a,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x553aa5),_0x1ec57e)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x161ea0,_0x5ccbd4){return!0x1;}['val'](_0x34a11d){return _0x34a11d&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x3580b1='';this['priorityNode_']['isEmpty']()||(_0x3580b1+='priority:'+No(this['priorityNode_']['val']())+':');const _0x18ffe6=typeof this['value_'];_0x3580b1+=_0x18ffe6+':',_0x18ffe6==='number'?_0x3580b1+=ao(this['value_']):_0x3580b1+=this['value_'],this['lazyHash_']=ro(_0x3580b1);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x529079){return _0x529079===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x529079 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x529079['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x529079));}['compareToLeafNode_'](_0x1870f9){const _0x2ba20a=typeof _0x1870f9['value_'],_0x4b005d=typeof this['value_'],_0xa9fb4b=D['VALUE_TYPE_ORDER']['indexOf'](_0x2ba20a),_0x5c8889=D['VALUE_TYPE_ORDER']['indexOf'](_0x4b005d);return f(_0xa9fb4b>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x2ba20a),f(_0x5c8889>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4b005d),_0xa9fb4b===_0x5c8889?_0x4b005d==='object'?0x0:this['value_']<_0x1870f9['value_']?-0x1:this['value_']===_0x1870f9['value_']?0x0:0x1:_0x5c8889-_0xa9fb4b;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x4842d6){if(_0x4842d6===this)return!0x0;if(_0x4842d6['isLeafNode']()){const _0x3fc162=_0x4842d6;return this['value_']===_0x3fc162['value_']&&this['priorityNode_']['equals'](_0x3fc162['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x33be33){Oo=_0x33be33;}function Wh(_0x2b5e8b){Do=_0x2b5e8b;}class Bh extends Dn{['compare'](_0x22ffd7,_0x5888f8){const _0x526ef9=_0x22ffd7['node']['getPriority'](),_0x538df0=_0x5888f8['node']['getPriority'](),_0x43db2c=_0x526ef9['compareTo'](_0x538df0);return _0x43db2c===0x0?He(_0x22ffd7['name'],_0x5888f8['name']):_0x43db2c;}['isDefinedOn'](_0x5ae841){return!_0x5ae841['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x249f74,_0x1c7e80){return!_0x249f74['getPriority']()['equals'](_0x1c7e80['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x220b40,_0x46dc7e){const _0x361ce4=Oo(_0x220b40);return new E(_0x46dc7e,new D('[PRIORITY-POST]',_0x361ce4));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x341213){const _0x29cff5=_0x1c33c0=>parseInt(Math['log'](_0x1c33c0)/Vh,0xa),_0x41150a=_0xbe55ea=>parseInt(Array(_0xbe55ea+0x1)['join']('1'),0x2);this['count']=_0x29cff5(_0x341213+0x1),this['current_']=this['count']-0x1;const _0x46154f=_0x41150a(this['count']);this['bits_']=_0x341213+0x1&_0x46154f;}['nextBitIsOne'](){const _0x3e3ef0=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x3e3ef0;}}const fn=function(_0x50bc88,_0x36e444,_0x1c0534,_0x270005){_0x50bc88['sort'](_0x36e444);const _0x2048e5=function(_0x30dbaa,_0x119ad1){const _0x270f7e=_0x119ad1-_0x30dbaa;let _0x337dfa,_0x2b0883;if(_0x270f7e===0x0)return null;if(_0x270f7e===0x1)return _0x337dfa=_0x50bc88[_0x30dbaa],_0x2b0883=_0x1c0534?_0x1c0534(_0x337dfa):_0x337dfa,new M(_0x2b0883,_0x337dfa['node'],M['BLACK'],null,null);{const _0x1054ec=parseInt(_0x270f7e/0x2,0xa)+_0x30dbaa,_0xc9ee84=_0x2048e5(_0x30dbaa,_0x1054ec),_0x3db3ff=_0x2048e5(_0x1054ec+0x1,_0x119ad1);return _0x337dfa=_0x50bc88[_0x1054ec],_0x2b0883=_0x1c0534?_0x1c0534(_0x337dfa):_0x337dfa,new M(_0x2b0883,_0x337dfa['node'],M['BLACK'],_0xc9ee84,_0x3db3ff);}},_0x349541=function(_0x5ca12e){let _0x5224d2=null,_0x40e28b=null,_0x31cc1b=_0x50bc88['length'];const _0x36ba3d=function(_0x35ba6f,_0x591146){const _0x84309=_0x31cc1b-_0x35ba6f,_0x563470=_0x31cc1b;_0x31cc1b-=_0x35ba6f;const _0x305f8f=_0x2048e5(_0x84309+0x1,_0x563470),_0x49554a=_0x50bc88[_0x84309],_0x4de3c2=_0x1c0534?_0x1c0534(_0x49554a):_0x49554a;_0x58228f(new M(_0x4de3c2,_0x49554a['node'],_0x591146,null,_0x305f8f));},_0x58228f=function(_0x1fe602){_0x5224d2?(_0x5224d2['left']=_0x1fe602,_0x5224d2=_0x1fe602):(_0x40e28b=_0x1fe602,_0x5224d2=_0x1fe602);};for(let _0x3076dc=0x0;_0x3076dc<_0x5ca12e['count'];++_0x3076dc){const _0x2c0c02=_0x5ca12e['nextBitIsOne'](),_0x36b56e=Math['pow'](0x2,_0x5ca12e['count']-(_0x3076dc+0x1));_0x2c0c02?_0x36ba3d(_0x36b56e,M['BLACK']):(_0x36ba3d(_0x36b56e,M['BLACK']),_0x36ba3d(_0x36b56e,M['RED']));}return _0x40e28b;},_0x13faab=new Hh(_0x50bc88['length']),_0x12a958=_0x349541(_0x13faab);return new B(_0x270005||_0x36e444,_0x12a958);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x1e9fea,_0x26d418){this['indexes_']=_0x1e9fea,this['indexSet_']=_0x26d418;}['get'](_0x30d70c){const _0x299b0e=De(this['indexes_'],_0x30d70c);if(!_0x299b0e)throw new Error('No\x20index\x20defined\x20for\x20'+_0x30d70c);return _0x299b0e instanceof B?_0x299b0e:null;}['hasIndex'](_0x22048b){return J(this['indexSet_'],_0x22048b['toString']());}['addIndex'](_0x410923,_0x402b29){f(_0x410923!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x493ab6=[];let _0x3efdcb=!0x1;const _0x3a3900=_0x402b29['getIterator'](E['Wrap']);let _0x13dad4=_0x3a3900['getNext']();for(;_0x13dad4;)_0x3efdcb=_0x3efdcb||_0x410923['isDefinedOn'](_0x13dad4['node']),_0x493ab6['push'](_0x13dad4),_0x13dad4=_0x3a3900['getNext']();let _0x56d76e;_0x3efdcb?_0x56d76e=fn(_0x493ab6,_0x410923['getCompare']()):_0x56d76e=ze;const _0x43cb1=_0x410923['toString'](),_0x55e1bf={...this['indexSet_']};_0x55e1bf[_0x43cb1]=_0x410923;const _0xdcc800={...this['indexes_']};return _0xdcc800[_0x43cb1]=_0x56d76e,new te(_0xdcc800,_0x55e1bf);}['addToIndexes'](_0x104129,_0x506d32){const _0x156056=hn(this['indexes_'],(_0x5463c1,_0x18850d)=>{const _0x2f9b9a=De(this['indexSet_'],_0x18850d);if(f(_0x2f9b9a,'Missing\x20index\x20implementation\x20for\x20'+_0x18850d),_0x5463c1===ze){if(_0x2f9b9a['isDefinedOn'](_0x104129['node'])){const _0x383bfb=[],_0xe09fb9=_0x506d32['getIterator'](E['Wrap']);let _0x58182b=_0xe09fb9['getNext']();for(;_0x58182b;)_0x58182b['name']!==_0x104129['name']&&_0x383bfb['push'](_0x58182b),_0x58182b=_0xe09fb9['getNext']();return _0x383bfb['push'](_0x104129),fn(_0x383bfb,_0x2f9b9a['getCompare']());}else return ze;}else{const _0x4c621e=_0x506d32['get'](_0x104129['name']);let _0x4fbfba=_0x5463c1;return _0x4c621e&&(_0x4fbfba=_0x4fbfba['remove'](new E(_0x104129['name'],_0x4c621e))),_0x4fbfba['insert'](_0x104129,_0x104129['node']);}});return new te(_0x156056,this['indexSet_']);}['removeFromIndexes'](_0x5bbbaf,_0x51d655){const _0x8f153a=hn(this['indexes_'],_0x8aa8c8=>{if(_0x8aa8c8===ze)return _0x8aa8c8;{const _0x1554de=_0x51d655['get'](_0x5bbbaf['name']);return _0x1554de?_0x8aa8c8['remove'](new E(_0x5bbbaf['name'],_0x1554de)):_0x8aa8c8;}});return new te(_0x8f153a,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0xc9db98,_0x56605d,_0x365a0a){this['children_']=_0xc9db98,this['priorityNode_']=_0x56605d,this['indexMap_']=_0x365a0a,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x124dc2){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x124dc2,this['indexMap_']);}['getImmediateChild'](_0x2c796f){if(_0x2c796f==='.priority')return this['getPriority']();{const _0x5da544=this['children_']['get'](_0x2c796f);return _0x5da544===null?mt:_0x5da544;}}['getChild'](_0x2768cf){const _0x534251=y(_0x2768cf);return _0x534251===null?this:this['getImmediateChild'](_0x534251)['getChild'](b(_0x2768cf));}['hasChild'](_0x17d15c){return this['children_']['get'](_0x17d15c)!==null;}['updateImmediateChild'](_0x25263b,_0x2b3482){if(f(_0x2b3482,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x25263b==='.priority')return this['updatePriority'](_0x2b3482);{const _0x400e6e=new E(_0x25263b,_0x2b3482);let _0x23db07,_0x1c481b;_0x2b3482['isEmpty']()?(_0x23db07=this['children_']['remove'](_0x25263b),_0x1c481b=this['indexMap_']['removeFromIndexes'](_0x400e6e,this['children_'])):(_0x23db07=this['children_']['insert'](_0x25263b,_0x2b3482),_0x1c481b=this['indexMap_']['addToIndexes'](_0x400e6e,this['children_']));const _0x2cbe3b=_0x23db07['isEmpty']()?mt:this['priorityNode_'];return new g(_0x23db07,_0x2cbe3b,_0x1c481b);}}['updateChild'](_0x55050c,_0x1716d5){const _0x264d73=y(_0x55050c);if(_0x264d73===null)return _0x1716d5;{f(y(_0x55050c)!=='.priority'||we(_0x55050c)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x437648=this['getImmediateChild'](_0x264d73)['updateChild'](b(_0x55050c),_0x1716d5);return this['updateImmediateChild'](_0x264d73,_0x437648);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x258808){if(this['isEmpty']())return null;const _0x3b0608={};let _0x2414b8=0x0,_0x2f922a=0x0,_0x11d7c7=!0x0;if(this['forEachChild'](R,(_0x44a8d9,_0x5e9070)=>{_0x3b0608[_0x44a8d9]=_0x5e9070['val'](_0x258808),_0x2414b8++,_0x11d7c7&&g['INTEGER_REGEXP_']['test'](_0x44a8d9)?_0x2f922a=Math['max'](_0x2f922a,Number(_0x44a8d9)):_0x11d7c7=!0x1;}),!_0x258808&&_0x11d7c7&&_0x2f922a<0x2*_0x2414b8){const _0x4789fd=[];for(const _0x1b9c71 in _0x3b0608)_0x4789fd[_0x1b9c71]=_0x3b0608[_0x1b9c71];return _0x4789fd;}else return _0x258808&&!this['getPriority']()['isEmpty']()&&(_0x3b0608['.priority']=this['getPriority']()['val']()),_0x3b0608;}['hash'](){if(this['lazyHash_']===null){let _0x22a513='';this['getPriority']()['isEmpty']()||(_0x22a513+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x3cde49,_0x4f95a7)=>{const _0x2c7b0a=_0x4f95a7['hash']();_0x2c7b0a!==''&&(_0x22a513+=':'+_0x3cde49+':'+_0x2c7b0a);}),this['lazyHash_']=_0x22a513===''?'':ro(_0x22a513);}return this['lazyHash_'];}['getPredecessorChildName'](_0x93fcec,_0x45b655,_0x24c540){const _0x28f4d1=this['resolveIndex_'](_0x24c540);if(_0x28f4d1){const _0x5a04d2=_0x28f4d1['getPredecessorKey'](new E(_0x93fcec,_0x45b655));return _0x5a04d2?_0x5a04d2['name']:null;}else return this['children_']['getPredecessorKey'](_0x93fcec);}['getFirstChildName'](_0x26f01e){const _0xb8eb6c=this['resolveIndex_'](_0x26f01e);if(_0xb8eb6c){const _0x5acd00=_0xb8eb6c['minKey']();return _0x5acd00&&_0x5acd00['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x114b40){const _0x441ac1=this['getFirstChildName'](_0x114b40);return _0x441ac1?new E(_0x441ac1,this['children_']['get'](_0x441ac1)):null;}['getLastChildName'](_0x197ba0){const _0x507d44=this['resolveIndex_'](_0x197ba0);if(_0x507d44){const _0x3fcb26=_0x507d44['maxKey']();return _0x3fcb26&&_0x3fcb26['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x11676a){const _0x4093ad=this['getLastChildName'](_0x11676a);return _0x4093ad?new E(_0x4093ad,this['children_']['get'](_0x4093ad)):null;}['forEachChild'](_0xe9b8fe,_0x3e428e){const _0x4d0c00=this['resolveIndex_'](_0xe9b8fe);return _0x4d0c00?_0x4d0c00['inorderTraversal'](_0x53272e=>_0x3e428e(_0x53272e['name'],_0x53272e['node'])):this['children_']['inorderTraversal'](_0x3e428e);}['getIterator'](_0x30d45b){return this['getIteratorFrom'](_0x30d45b['minPost'](),_0x30d45b);}['getIteratorFrom'](_0x183476,_0x45bb96){const _0x86bf53=this['resolveIndex_'](_0x45bb96);if(_0x86bf53)return _0x86bf53['getIteratorFrom'](_0x183476,_0x447164=>_0x447164);{const _0x1cf249=this['children_']['getIteratorFrom'](_0x183476['name'],E['Wrap']);let _0x36ef83=_0x1cf249['peek']();for(;_0x36ef83!=null&&_0x45bb96['compare'](_0x36ef83,_0x183476)<0x0;)_0x1cf249['getNext'](),_0x36ef83=_0x1cf249['peek']();return _0x1cf249;}}['getReverseIterator'](_0x4d8f5d){return this['getReverseIteratorFrom'](_0x4d8f5d['maxPost'](),_0x4d8f5d);}['getReverseIteratorFrom'](_0xd6c2cd,_0x2ec63e){const _0x2e6540=this['resolveIndex_'](_0x2ec63e);if(_0x2e6540)return _0x2e6540['getReverseIteratorFrom'](_0xd6c2cd,_0x53250b=>_0x53250b);{const _0x2bacf9=this['children_']['getReverseIteratorFrom'](_0xd6c2cd['name'],E['Wrap']);let _0x2de7f1=_0x2bacf9['peek']();for(;_0x2de7f1!=null&&_0x2ec63e['compare'](_0x2de7f1,_0xd6c2cd)>0x0;)_0x2bacf9['getNext'](),_0x2de7f1=_0x2bacf9['peek']();return _0x2bacf9;}}['compareTo'](_0x544174){return this['isEmpty']()?_0x544174['isEmpty']()?0x0:-0x1:_0x544174['isLeafNode']()||_0x544174['isEmpty']()?0x1:_0x544174===$t?-0x1:0x0;}['withIndex'](_0x139df2){if(_0x139df2===ye||this['indexMap_']['hasIndex'](_0x139df2))return this;{const _0x582eee=this['indexMap_']['addIndex'](_0x139df2,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x582eee);}}['isIndexed'](_0x315269){return _0x315269===ye||this['indexMap_']['hasIndex'](_0x315269);}['equals'](_0x10c83f){if(_0x10c83f===this)return!0x0;if(_0x10c83f['isLeafNode']())return!0x1;{const _0x4f0df4=_0x10c83f;if(this['getPriority']()['equals'](_0x4f0df4['getPriority']())){if(this['children_']['count']()===_0x4f0df4['children_']['count']()){const _0x5f1853=this['getIterator'](R),_0x510428=_0x4f0df4['getIterator'](R);let _0x5c6cdb=_0x5f1853['getNext'](),_0x5932e2=_0x510428['getNext']();for(;_0x5c6cdb&&_0x5932e2;){if(_0x5c6cdb['name']!==_0x5932e2['name']||!_0x5c6cdb['node']['equals'](_0x5932e2['node']))return!0x1;_0x5c6cdb=_0x5f1853['getNext'](),_0x5932e2=_0x510428['getNext']();}return _0x5c6cdb===null&&_0x5932e2===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x172e0b){return _0x172e0b===ye?null:this['indexMap_']['get'](_0x172e0b['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x2076d5){return _0x2076d5===this?0x0:0x1;}['equals'](_0x2ca8ff){return _0x2ca8ff===this;}['getPriority'](){return this;}['getImmediateChild'](_0x15991d){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x3feeb3,_0x121e5c=null){if(_0x3feeb3===null)return g['EMPTY_NODE'];if(typeof _0x3feeb3=='object'&&'.priority'in _0x3feeb3&&(_0x121e5c=_0x3feeb3['.priority']),f(_0x121e5c===null||typeof _0x121e5c=='string'||typeof _0x121e5c=='number'||typeof _0x121e5c=='object'&&'.sv'in _0x121e5c,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x121e5c),typeof _0x3feeb3=='object'&&'.value'in _0x3feeb3&&_0x3feeb3['.value']!==null&&(_0x3feeb3=_0x3feeb3['.value']),typeof _0x3feeb3!='object'||'.sv'in _0x3feeb3){const _0x31b1ce=_0x3feeb3;return new D(_0x31b1ce,P(_0x121e5c));}if(!(_0x3feeb3 instanceof Array)&&Gh){const _0x9bad03=[];let _0x3a6bdc=!0x1;if(x(_0x3feeb3,(_0x382162,_0xa482aa)=>{if(_0x382162['substring'](0x0,0x1)!=='.'){const _0xc5c594=P(_0xa482aa);_0xc5c594['isEmpty']()||(_0x3a6bdc=_0x3a6bdc||!_0xc5c594['getPriority']()['isEmpty'](),_0x9bad03['push'](new E(_0x382162,_0xc5c594)));}}),_0x9bad03['length']===0x0)return g['EMPTY_NODE'];const _0x16cafd=fn(_0x9bad03,xh,_0x478e55=>_0x478e55['name'],Yi);if(_0x3a6bdc){const _0x53c79e=fn(_0x9bad03,R['getCompare']());return new g(_0x16cafd,P(_0x121e5c),new te({'.priority':_0x53c79e},{'.priority':R}));}else return new g(_0x16cafd,P(_0x121e5c),te['Default']);}else{let _0x225aba=g['EMPTY_NODE'];return x(_0x3feeb3,(_0x3544cf,_0x41b0ba)=>{if(J(_0x3feeb3,_0x3544cf)&&_0x3544cf['substring'](0x0,0x1)!=='.'){const _0x25f540=P(_0x41b0ba);(_0x25f540['isLeafNode']()||!_0x25f540['isEmpty']())&&(_0x225aba=_0x225aba['updateImmediateChild'](_0x3544cf,_0x25f540));}}),_0x225aba['updatePriority'](P(_0x121e5c));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x1ff40b){super(),this['indexPath_']=_0x1ff40b,f(!v(_0x1ff40b)&&y(_0x1ff40b)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x19aacd){return _0x19aacd['getChild'](this['indexPath_']);}['isDefinedOn'](_0x4b5c60){return!_0x4b5c60['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x9a6b,_0x30477f){const _0x468123=this['extractChild'](_0x9a6b['node']),_0x503412=this['extractChild'](_0x30477f['node']),_0x11c716=_0x468123['compareTo'](_0x503412);return _0x11c716===0x0?He(_0x9a6b['name'],_0x30477f['name']):_0x11c716;}['makePost'](_0x18ab48,_0x47dfd0){const _0x355e5c=P(_0x18ab48),_0xee94=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x355e5c);return new E(_0x47dfd0,_0xee94);}['maxPost'](){const _0x5346ef=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x5346ef);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x17c82e,_0x5ab013){const _0x497b26=_0x17c82e['node']['compareTo'](_0x5ab013['node']);return _0x497b26===0x0?He(_0x17c82e['name'],_0x5ab013['name']):_0x497b26;}['isDefinedOn'](_0x5d15ab){return!0x0;}['indexedValueChanged'](_0x2b3bc5,_0x2038e9){return!_0x2b3bc5['equals'](_0x2038e9);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x171922,_0x479046){const _0x5ddc85=P(_0x171922);return new E(_0x479046,_0x5ddc85);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x2f81a5){return{'type':'value','snapshotNode':_0x2f81a5};}function et(_0xfb9d7d,_0x151535){return{'type':'child_added','snapshotNode':_0x151535,'childName':_0xfb9d7d};}function Ot(_0x2919cb,_0x22a868){return{'type':'child_removed','snapshotNode':_0x22a868,'childName':_0x2919cb};}function Dt(_0x3c6045,_0x5a07d2,_0x4d52e7){return{'type':'child_changed','snapshotNode':_0x5a07d2,'childName':_0x3c6045,'oldSnap':_0x4d52e7};}function zh(_0x15b17b,_0x51c5f7){return{'type':'child_moved','snapshotNode':_0x51c5f7,'childName':_0x15b17b};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x191390){this['index_']=_0x191390;}['updateChild'](_0x1f29c9,_0x4dd746,_0x14882,_0x2af4db,_0x5e021,_0x20cf92){f(_0x1f29c9['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x35a1d7=_0x1f29c9['getImmediateChild'](_0x4dd746);return _0x35a1d7['getChild'](_0x2af4db)['equals'](_0x14882['getChild'](_0x2af4db))&&_0x35a1d7['isEmpty']()===_0x14882['isEmpty']()||(_0x20cf92!=null&&(_0x14882['isEmpty']()?_0x1f29c9['hasChild'](_0x4dd746)?_0x20cf92['trackChildChange'](Ot(_0x4dd746,_0x35a1d7)):f(_0x1f29c9['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x35a1d7['isEmpty']()?_0x20cf92['trackChildChange'](et(_0x4dd746,_0x14882)):_0x20cf92['trackChildChange'](Dt(_0x4dd746,_0x14882,_0x35a1d7))),_0x1f29c9['isLeafNode']()&&_0x14882['isEmpty']())?_0x1f29c9:_0x1f29c9['updateImmediateChild'](_0x4dd746,_0x14882)['withIndex'](this['index_']);}['updateFullNode'](_0x586a26,_0x1f010c,_0x4a3bb7){return _0x4a3bb7!=null&&(_0x586a26['isLeafNode']()||_0x586a26['forEachChild'](R,(_0x3fc9fe,_0x3b2be2)=>{_0x1f010c['hasChild'](_0x3fc9fe)||_0x4a3bb7['trackChildChange'](Ot(_0x3fc9fe,_0x3b2be2));}),_0x1f010c['isLeafNode']()||_0x1f010c['forEachChild'](R,(_0x4deb9c,_0x3ce1c8)=>{if(_0x586a26['hasChild'](_0x4deb9c)){const _0x41cb97=_0x586a26['getImmediateChild'](_0x4deb9c);_0x41cb97['equals'](_0x3ce1c8)||_0x4a3bb7['trackChildChange'](Dt(_0x4deb9c,_0x3ce1c8,_0x41cb97));}else _0x4a3bb7['trackChildChange'](et(_0x4deb9c,_0x3ce1c8));})),_0x1f010c['withIndex'](this['index_']);}['updatePriority'](_0x484652,_0x348892){return _0x484652['isEmpty']()?g['EMPTY_NODE']:_0x484652['updatePriority'](_0x348892);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0xd7333e){this['indexedFilter_']=new Ji(_0xd7333e['getIndex']()),this['index_']=_0xd7333e['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0xd7333e),this['endPost_']=Mt['getEndPost_'](_0xd7333e),this['startIsInclusive_']=!_0xd7333e['startAfterSet_'],this['endIsInclusive_']=!_0xd7333e['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x4daed6){const _0x3ae161=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x4daed6)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x4daed6)<0x0,_0x4ec015=this['endIsInclusive_']?this['index_']['compare'](_0x4daed6,this['getEndPost']())<=0x0:this['index_']['compare'](_0x4daed6,this['getEndPost']())<0x0;return _0x3ae161&&_0x4ec015;}['updateChild'](_0x5d057d,_0x5ced4f,_0x5b72e5,_0x142c85,_0x7e0050,_0x1bf684){return this['matches'](new E(_0x5ced4f,_0x5b72e5))||(_0x5b72e5=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x5d057d,_0x5ced4f,_0x5b72e5,_0x142c85,_0x7e0050,_0x1bf684);}['updateFullNode'](_0x1dccb2,_0x36f1b8,_0x34b46b){_0x36f1b8['isLeafNode']()&&(_0x36f1b8=g['EMPTY_NODE']);let _0x1b8392=_0x36f1b8['withIndex'](this['index_']);_0x1b8392=_0x1b8392['updatePriority'](g['EMPTY_NODE']);const _0x501463=this;return _0x36f1b8['forEachChild'](R,(_0x4538b8,_0x140d54)=>{_0x501463['matches'](new E(_0x4538b8,_0x140d54))||(_0x1b8392=_0x1b8392['updateImmediateChild'](_0x4538b8,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1dccb2,_0x1b8392,_0x34b46b);}['updatePriority'](_0x512b8e,_0x1ce816){return _0x512b8e;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x977abf){if(_0x977abf['hasStart']()){const _0x4ce3d0=_0x977abf['getIndexStartName']();return _0x977abf['getIndex']()['makePost'](_0x977abf['getIndexStartValue'](),_0x4ce3d0);}else return _0x977abf['getIndex']()['minPost']();}static['getEndPost_'](_0x5c06a0){if(_0x5c06a0['hasEnd']()){const _0x4fe72d=_0x5c06a0['getIndexEndName']();return _0x5c06a0['getIndex']()['makePost'](_0x5c06a0['getIndexEndValue'](),_0x4fe72d);}else return _0x5c06a0['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x97a4a4){this['withinDirectionalStart']=_0x170bc0=>this['reverse_']?this['withinEndPost'](_0x170bc0):this['withinStartPost'](_0x170bc0),this['withinDirectionalEnd']=_0x4cca75=>this['reverse_']?this['withinStartPost'](_0x4cca75):this['withinEndPost'](_0x4cca75),this['withinStartPost']=_0x135c6f=>{const _0x2a97a3=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x135c6f);return this['startIsInclusive_']?_0x2a97a3<=0x0:_0x2a97a3<0x0;},this['withinEndPost']=_0x1af884=>{const _0x570dbc=this['index_']['compare'](_0x1af884,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x570dbc<=0x0:_0x570dbc<0x0;},this['rangedFilter_']=new Mt(_0x97a4a4),this['index_']=_0x97a4a4['getIndex'](),this['limit_']=_0x97a4a4['getLimit'](),this['reverse_']=!_0x97a4a4['isViewFromLeft'](),this['startIsInclusive_']=!_0x97a4a4['startAfterSet_'],this['endIsInclusive_']=!_0x97a4a4['endBeforeSet_'];}['updateChild'](_0x1701e2,_0x2f24d5,_0x742d1d,_0x4490f0,_0x566241,_0x3e7360){return this['rangedFilter_']['matches'](new E(_0x2f24d5,_0x742d1d))||(_0x742d1d=g['EMPTY_NODE']),_0x1701e2['getImmediateChild'](_0x2f24d5)['equals'](_0x742d1d)?_0x1701e2:_0x1701e2['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x1701e2,_0x2f24d5,_0x742d1d,_0x4490f0,_0x566241,_0x3e7360):this['fullLimitUpdateChild_'](_0x1701e2,_0x2f24d5,_0x742d1d,_0x566241,_0x3e7360);}['updateFullNode'](_0x312cab,_0x22e951,_0x2936dd){let _0x25676b;if(_0x22e951['isLeafNode']()||_0x22e951['isEmpty']())_0x25676b=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x22e951['numChildren']()&&_0x22e951['isIndexed'](this['index_'])){_0x25676b=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x20c516;this['reverse_']?_0x20c516=_0x22e951['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x20c516=_0x22e951['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x52998e=0x0;for(;_0x20c516['hasNext']()&&_0x52998e<this['limit_'];){const _0x57e5e6=_0x20c516['getNext']();if(this['withinDirectionalStart'](_0x57e5e6)){if(this['withinDirectionalEnd'](_0x57e5e6))_0x25676b=_0x25676b['updateImmediateChild'](_0x57e5e6['name'],_0x57e5e6['node']),_0x52998e++;else break;}else continue;}}else{_0x25676b=_0x22e951['withIndex'](this['index_']),_0x25676b=_0x25676b['updatePriority'](g['EMPTY_NODE']);let _0x599f39;this['reverse_']?_0x599f39=_0x25676b['getReverseIterator'](this['index_']):_0x599f39=_0x25676b['getIterator'](this['index_']);let _0x2af7af=0x0;for(;_0x599f39['hasNext']();){const _0x5dedd1=_0x599f39['getNext']();_0x2af7af<this['limit_']&&this['withinDirectionalStart'](_0x5dedd1)&&this['withinDirectionalEnd'](_0x5dedd1)?_0x2af7af++:_0x25676b=_0x25676b['updateImmediateChild'](_0x5dedd1['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x312cab,_0x25676b,_0x2936dd);}['updatePriority'](_0x1a6582,_0x41d39a){return _0x1a6582;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x47de9a,_0x582152,_0x13b39d,_0x49aa3a,_0x56d791){let _0x576219;if(this['reverse_']){const _0x5ba274=this['index_']['getCompare']();_0x576219=(_0x247f61,_0x1310f2)=>_0x5ba274(_0x1310f2,_0x247f61);}else _0x576219=this['index_']['getCompare']();const _0x5bc710=_0x47de9a;f(_0x5bc710['numChildren']()===this['limit_'],'');const _0x4090cf=new E(_0x582152,_0x13b39d),_0x5d2306=this['reverse_']?_0x5bc710['getFirstChild'](this['index_']):_0x5bc710['getLastChild'](this['index_']),_0x554703=this['rangedFilter_']['matches'](_0x4090cf);if(_0x5bc710['hasChild'](_0x582152)){const _0x1fc89b=_0x5bc710['getImmediateChild'](_0x582152);let _0x5d324d=_0x49aa3a['getChildAfterChild'](this['index_'],_0x5d2306,this['reverse_']);for(;_0x5d324d!=null&&(_0x5d324d['name']===_0x582152||_0x5bc710['hasChild'](_0x5d324d['name']));)_0x5d324d=_0x49aa3a['getChildAfterChild'](this['index_'],_0x5d324d,this['reverse_']);const _0xb58c21=_0x5d324d==null?0x1:_0x576219(_0x5d324d,_0x4090cf);if(_0x554703&&!_0x13b39d['isEmpty']()&&_0xb58c21>=0x0)return _0x56d791!=null&&_0x56d791['trackChildChange'](Dt(_0x582152,_0x13b39d,_0x1fc89b)),_0x5bc710['updateImmediateChild'](_0x582152,_0x13b39d);{_0x56d791!=null&&_0x56d791['trackChildChange'](Ot(_0x582152,_0x1fc89b));const _0x2e606e=_0x5bc710['updateImmediateChild'](_0x582152,g['EMPTY_NODE']);return _0x5d324d!=null&&this['rangedFilter_']['matches'](_0x5d324d)?(_0x56d791!=null&&_0x56d791['trackChildChange'](et(_0x5d324d['name'],_0x5d324d['node'])),_0x2e606e['updateImmediateChild'](_0x5d324d['name'],_0x5d324d['node'])):_0x2e606e;}}else return _0x13b39d['isEmpty']()?_0x47de9a:_0x554703&&_0x576219(_0x5d2306,_0x4090cf)>=0x0?(_0x56d791!=null&&(_0x56d791['trackChildChange'](Ot(_0x5d2306['name'],_0x5d2306['node'])),_0x56d791['trackChildChange'](et(_0x582152,_0x13b39d))),_0x5bc710['updateImmediateChild'](_0x582152,_0x13b39d)['updateImmediateChild'](_0x5d2306['name'],g['EMPTY_NODE'])):_0x47de9a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x4ebad1=new Xi();return _0x4ebad1['limitSet_']=this['limitSet_'],_0x4ebad1['limit_']=this['limit_'],_0x4ebad1['startSet_']=this['startSet_'],_0x4ebad1['startAfterSet_']=this['startAfterSet_'],_0x4ebad1['indexStartValue_']=this['indexStartValue_'],_0x4ebad1['startNameSet_']=this['startNameSet_'],_0x4ebad1['indexStartName_']=this['indexStartName_'],_0x4ebad1['endSet_']=this['endSet_'],_0x4ebad1['endBeforeSet_']=this['endBeforeSet_'],_0x4ebad1['indexEndValue_']=this['indexEndValue_'],_0x4ebad1['endNameSet_']=this['endNameSet_'],_0x4ebad1['indexEndName_']=this['indexEndName_'],_0x4ebad1['index_']=this['index_'],_0x4ebad1['viewFrom_']=this['viewFrom_'],_0x4ebad1;}}function Kh(_0x5f4341){return _0x5f4341['loadsAllData']()?new Ji(_0x5f4341['getIndex']()):_0x5f4341['hasLimit']()?new jh(_0x5f4341):new Mt(_0x5f4341);}function Yh(_0x5ae280,_0xe8ca24){const _0xac1754=_0x5ae280['copy']();return _0xac1754['limitSet_']=!0x0,_0xac1754['limit_']=_0xe8ca24,_0xac1754['viewFrom_']='l',_0xac1754;}function Qh(_0x484889,_0x5706b2,_0x3a2752){const _0x12997f=_0x484889['copy']();return _0x12997f['startSet_']=!0x0,_0x5706b2===void 0x0&&(_0x5706b2=null),_0x12997f['indexStartValue_']=_0x5706b2,_0x3a2752!=null?(_0x12997f['startNameSet_']=!0x0,_0x12997f['indexStartName_']=_0x3a2752):(_0x12997f['startNameSet_']=!0x1,_0x12997f['indexStartName_']=''),_0x12997f;}function Jh(_0x55b0f9,_0x3ee01d,_0x50c97c){const _0x3ff4f9=_0x55b0f9['copy']();return _0x3ff4f9['endSet_']=!0x0,_0x3ee01d===void 0x0&&(_0x3ee01d=null),_0x3ff4f9['indexEndValue_']=_0x3ee01d,_0x50c97c!==void 0x0?(_0x3ff4f9['endNameSet_']=!0x0,_0x3ff4f9['indexEndName_']=_0x50c97c):(_0x3ff4f9['endNameSet_']=!0x1,_0x3ff4f9['indexEndName_']=''),_0x3ff4f9;}function xo(_0x3e3c22,_0x6c7b06){const _0x3885a8=_0x3e3c22['copy']();return _0x3885a8['index_']=_0x6c7b06,_0x3885a8;}function sr(_0x45f2eb){const _0x3ebea2={};if(_0x45f2eb['isDefault']())return _0x3ebea2;let _0x5ab2ea;if(_0x45f2eb['index_']===R?_0x5ab2ea='$priority':_0x45f2eb['index_']===Mo?_0x5ab2ea='$value':_0x45f2eb['index_']===ye?_0x5ab2ea='$key':(f(_0x45f2eb['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x5ab2ea=_0x45f2eb['index_']['toString']()),_0x3ebea2['orderBy']=O(_0x5ab2ea),_0x45f2eb['startSet_']){const _0xc4d678=_0x45f2eb['startAfterSet_']?'startAfter':'startAt';_0x3ebea2[_0xc4d678]=O(_0x45f2eb['indexStartValue_']),_0x45f2eb['startNameSet_']&&(_0x3ebea2[_0xc4d678]+=','+O(_0x45f2eb['indexStartName_']));}if(_0x45f2eb['endSet_']){const _0x3f55b6=_0x45f2eb['endBeforeSet_']?'endBefore':'endAt';_0x3ebea2[_0x3f55b6]=O(_0x45f2eb['indexEndValue_']),_0x45f2eb['endNameSet_']&&(_0x3ebea2[_0x3f55b6]+=','+O(_0x45f2eb['indexEndName_']));}return _0x45f2eb['limitSet_']&&(_0x45f2eb['isViewFromLeft']()?_0x3ebea2['limitToFirst']=_0x45f2eb['limit_']:_0x3ebea2['limitToLast']=_0x45f2eb['limit_']),_0x3ebea2;}function rr(_0x3ec8b2){const _0x3550b3={};if(_0x3ec8b2['startSet_']&&(_0x3550b3['sp']=_0x3ec8b2['indexStartValue_'],_0x3ec8b2['startNameSet_']&&(_0x3550b3['sn']=_0x3ec8b2['indexStartName_']),_0x3550b3['sin']=!_0x3ec8b2['startAfterSet_']),_0x3ec8b2['endSet_']&&(_0x3550b3['ep']=_0x3ec8b2['indexEndValue_'],_0x3ec8b2['endNameSet_']&&(_0x3550b3['en']=_0x3ec8b2['indexEndName_']),_0x3550b3['ein']=!_0x3ec8b2['endBeforeSet_']),_0x3ec8b2['limitSet_']){_0x3550b3['l']=_0x3ec8b2['limit_'];let _0x36c456=_0x3ec8b2['viewFrom_'];_0x36c456===''&&(_0x3ec8b2['isViewFromLeft']()?_0x36c456='l':_0x36c456='r'),_0x3550b3['vf']=_0x36c456;}return _0x3ec8b2['index_']!==R&&(_0x3550b3['i']=_0x3ec8b2['index_']['toString']()),_0x3550b3;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x4da007){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x3eec4f,_0xbc993d){return _0xbc993d!==void 0x0?'tag$'+_0xbc993d:(f(_0x3eec4f['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x3eec4f['_path']['toString']());}constructor(_0x476679,_0x3d100c,_0x20e125,_0xd2310){super(),this['repoInfo_']=_0x476679,this['onDataUpdate_']=_0x3d100c,this['authTokenProvider_']=_0x20e125,this['appCheckTokenProvider_']=_0xd2310,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x4ad93f,_0xf23d00,_0x231280,_0x1a1c25){const _0x2b6d45=_0x4ad93f['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2b6d45+'\x20'+_0x4ad93f['_queryIdentifier']);const _0x30b891=pn['getListenId_'](_0x4ad93f,_0x231280),_0x18b8af={};this['listens_'][_0x30b891]=_0x18b8af;const _0x1f4398=sr(_0x4ad93f['_queryParams']);this['restRequest_'](_0x2b6d45+'.json',_0x1f4398,(_0x52105a,_0x410525)=>{let _0x47dde9=_0x410525;if(_0x52105a===0x194&&(_0x47dde9=null,_0x52105a=null),_0x52105a===null&&this['onDataUpdate_'](_0x2b6d45,_0x47dde9,!0x1,_0x231280),De(this['listens_'],_0x30b891)===_0x18b8af){let _0x591371;_0x52105a?_0x52105a===0x191?_0x591371='permission_denied':_0x591371='rest_error:'+_0x52105a:_0x591371='ok',_0x1a1c25(_0x591371,null);}});}['unlisten'](_0x26b5a4,_0x320200){const _0x49a1ae=pn['getListenId_'](_0x26b5a4,_0x320200);delete this['listens_'][_0x49a1ae];}['get'](_0x99cf8){const _0x5c53f9=sr(_0x99cf8['_queryParams']),_0x4b067a=_0x99cf8['_path']['toString'](),_0x2165dc=new ot();return this['restRequest_'](_0x4b067a+'.json',_0x5c53f9,(_0x46a6ce,_0x4f43b5)=>{let _0x3451f1=_0x4f43b5;_0x46a6ce===0x194&&(_0x3451f1=null,_0x46a6ce=null),_0x46a6ce===null?(this['onDataUpdate_'](_0x4b067a,_0x3451f1,!0x1,null),_0x2165dc['resolve'](_0x3451f1)):_0x2165dc['reject'](new Error(_0x3451f1));}),_0x2165dc['promise'];}['refreshAuthToken'](_0x307d46){}['restRequest_'](_0xbb1273,_0x3db2a8={},_0x236a56){return _0x3db2a8['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x4c8e57,_0x44fd33])=>{_0x4c8e57&&_0x4c8e57['accessToken']&&(_0x3db2a8['auth']=_0x4c8e57['accessToken']),_0x44fd33&&_0x44fd33['token']&&(_0x3db2a8['ac']=_0x44fd33['token']);const _0x5e5b91=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0xbb1273+'?ns='+this['repoInfo_']['namespace']+ct(_0x3db2a8);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x5e5b91);const _0x2ae79e=new XMLHttpRequest();_0x2ae79e['onreadystatechange']=()=>{if(_0x236a56&&_0x2ae79e['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x5e5b91+'\x20received.\x20status:',_0x2ae79e['status'],'response:',_0x2ae79e['responseText']);let _0x3c974c=null;if(_0x2ae79e['status']>=0xc8&&_0x2ae79e['status']<0x12c){try{_0x3c974c=At(_0x2ae79e['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x5e5b91+':\x20'+_0x2ae79e['responseText']);}_0x236a56(null,_0x3c974c);}else _0x2ae79e['status']!==0x191&&_0x2ae79e['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x5e5b91+'\x20Status:\x20'+_0x2ae79e['status']),_0x236a56(_0x2ae79e['status']);_0x236a56=null;}},_0x2ae79e['open']('GET',_0x5e5b91,!0x0),_0x2ae79e['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x4eaf6c){return this['rootNode_']['getChild'](_0x4eaf6c);}['updateSnapshot'](_0x14aaa2,_0x3d0d62){this['rootNode_']=this['rootNode_']['updateChild'](_0x14aaa2,_0x3d0d62);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x545115,_0x9b3054,_0x11c750){if(v(_0x9b3054))_0x545115['value']=_0x11c750,_0x545115['children']['clear']();else{if(_0x545115['value']!==null)_0x545115['value']=_0x545115['value']['updateChild'](_0x9b3054,_0x11c750);else{const _0x34c4d2=y(_0x9b3054);_0x545115['children']['has'](_0x34c4d2)||_0x545115['children']['set'](_0x34c4d2,_n());const _0x12dd05=_0x545115['children']['get'](_0x34c4d2);_0x9b3054=b(_0x9b3054),Fo(_0x12dd05,_0x9b3054,_0x11c750);}}}function Ii(_0x274b67,_0x3207ee,_0x2d7032){_0x274b67['value']!==null?_0x2d7032(_0x3207ee,_0x274b67['value']):Zh(_0x274b67,(_0x4c9023,_0x3f7a9c)=>{const _0x4a354a=new C(_0x3207ee['toString']()+'/'+_0x4c9023);Ii(_0x3f7a9c,_0x4a354a,_0x2d7032);});}function Zh(_0x264b42,_0x503b8f){_0x264b42['children']['forEach']((_0xe1e678,_0xc753d9)=>{_0x503b8f(_0xc753d9,_0xe1e678);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x4e49f3){this['collection_']=_0x4e49f3,this['last_']=null;}['get'](){const _0x46e1a7=this['collection_']['get'](),_0x49f150={..._0x46e1a7};return this['last_']&&x(this['last_'],(_0x1b8402,_0x2e359e)=>{_0x49f150[_0x1b8402]=_0x49f150[_0x1b8402]-_0x2e359e;}),this['last_']=_0x46e1a7,_0x49f150;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x227ebd,_0xb7fba0){this['server_']=_0xb7fba0,this['statsToReport_']={},this['statsListener_']=new eu(_0x227ebd);const _0x36a624=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x36a624));}['reportStats_'](){const _0xf3f253=this['statsListener_']['get'](),_0x20ebe5={};let _0x369280=!0x1;x(_0xf3f253,(_0x20240f,_0x1b521c)=>{_0x1b521c>0x0&&J(this['statsToReport_'],_0x20240f)&&(_0x20ebe5[_0x20240f]=_0x1b521c,_0x369280=!0x0);}),_0x369280&&this['server_']['reportStats'](_0x20ebe5),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x5ec39c){_0x5ec39c[_0x5ec39c['OVERWRITE']=0x0]='OVERWRITE',_0x5ec39c[_0x5ec39c['MERGE']=0x1]='MERGE',_0x5ec39c[_0x5ec39c['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x5ec39c[_0x5ec39c['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x1e552a){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x1e552a,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x1ae325,_0x15295f,_0x3790bf){this['path']=_0x1ae325,this['affectedTree']=_0x15295f,this['revert']=_0x3790bf,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x4ba02f){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x150ddc=this['affectedTree']['subtree'](new C(_0x4ba02f));return new gn(w(),_0x150ddc,this['revert']);}}else return f(y(this['path'])===_0x4ba02f,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x29abab,_0x3b57ae){this['source']=_0x29abab,this['path']=_0x3b57ae,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x1edbb2){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x1559a7,_0x53dab2,_0x52a98e){this['source']=_0x1559a7,this['path']=_0x53dab2,this['snap']=_0x52a98e,this['type']=j['OVERWRITE'];}['operationForChild'](_0x25c450){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x25c450)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x56ec57,_0x39818c,_0x23705a){this['source']=_0x56ec57,this['path']=_0x39818c,this['children']=_0x23705a,this['type']=j['MERGE'];}['operationForChild'](_0x2b3035){if(v(this['path'])){const _0x35d3ca=this['children']['subtree'](new C(_0x2b3035));return _0x35d3ca['isEmpty']()?null:_0x35d3ca['value']?new Ue(this['source'],w(),_0x35d3ca['value']):new tt(this['source'],w(),_0x35d3ca);}else return f(y(this['path'])===_0x2b3035,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x12cce9,_0x4ccd36,_0x331c3f){this['node_']=_0x12cce9,this['fullyInitialized_']=_0x4ccd36,this['filtered_']=_0x331c3f;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x19e646){if(v(_0x19e646))return this['isFullyInitialized']()&&!this['filtered_'];const _0x3d1b2d=y(_0x19e646);return this['isCompleteForChild'](_0x3d1b2d);}['isCompleteForChild'](_0x56c5a0){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x56c5a0);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x775314){this['query_']=_0x775314,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x45f939,_0x3acb45,_0x51c468,_0xfe3f77){const _0x417f0b=[],_0x48a96d=[];return _0x3acb45['forEach'](_0xc80650=>{_0xc80650['type']==='child_changed'&&_0x45f939['index_']['indexedValueChanged'](_0xc80650['oldSnap'],_0xc80650['snapshotNode'])&&_0x48a96d['push'](zh(_0xc80650['childName'],_0xc80650['snapshotNode']));}),yt(_0x45f939,_0x417f0b,'child_removed',_0x3acb45,_0xfe3f77,_0x51c468),yt(_0x45f939,_0x417f0b,'child_added',_0x3acb45,_0xfe3f77,_0x51c468),yt(_0x45f939,_0x417f0b,'child_moved',_0x48a96d,_0xfe3f77,_0x51c468),yt(_0x45f939,_0x417f0b,'child_changed',_0x3acb45,_0xfe3f77,_0x51c468),yt(_0x45f939,_0x417f0b,'value',_0x3acb45,_0xfe3f77,_0x51c468),_0x417f0b;}function yt(_0x3fc427,_0x1b7810,_0x4df69e,_0x338003,_0xe635e7,_0x41e9b7){const _0x36c18e=_0x338003['filter'](_0x441341=>_0x441341['type']===_0x4df69e);_0x36c18e['sort']((_0x5cafbe,_0x19e217)=>au(_0x3fc427,_0x5cafbe,_0x19e217)),_0x36c18e['forEach'](_0x20fe9a=>{const _0x103818=ou(_0x3fc427,_0x20fe9a,_0x41e9b7);_0xe635e7['forEach'](_0x30456f=>{_0x30456f['respondsTo'](_0x20fe9a['type'])&&_0x1b7810['push'](_0x30456f['createEvent'](_0x103818,_0x3fc427['query_']));});});}function ou(_0x26c55c,_0x5f17b8,_0x4e2ee0){return _0x5f17b8['type']==='value'||_0x5f17b8['type']==='child_removed'||(_0x5f17b8['prevName']=_0x4e2ee0['getPredecessorChildName'](_0x5f17b8['childName'],_0x5f17b8['snapshotNode'],_0x26c55c['index_'])),_0x5f17b8;}function au(_0x4b3680,_0x309120,_0x46aedb){if(_0x309120['childName']==null||_0x46aedb['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x34c373=new E(_0x309120['childName'],_0x309120['snapshotNode']),_0x29f6b9=new E(_0x46aedb['childName'],_0x46aedb['snapshotNode']);return _0x4b3680['index_']['compare'](_0x34c373,_0x29f6b9);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x47f794,_0x1e8dfa){return{'eventCache':_0x47f794,'serverCache':_0x1e8dfa};}function Tt(_0x5c5e97,_0x298390,_0x5d10c7,_0xab19ac){return Mn(new Ce(_0x298390,_0x5d10c7,_0xab19ac),_0x5c5e97['serverCache']);}function Uo(_0xe938bc,_0x34982a,_0x414d9a,_0x4537ed){return Mn(_0xe938bc['eventCache'],new Ce(_0x34982a,_0x414d9a,_0x4537ed));}function mn(_0xac7d93){return _0xac7d93['eventCache']['isFullyInitialized']()?_0xac7d93['eventCache']['getNode']():null;}function We(_0x3f221d){return _0x3f221d['serverCache']['isFullyInitialized']()?_0x3f221d['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x5a73b8){let _0x43e44e=new S(null);return x(_0x5a73b8,(_0x32b2f2,_0x2d6261)=>{_0x43e44e=_0x43e44e['set'](new C(_0x32b2f2),_0x2d6261);}),_0x43e44e;}constructor(_0x43f2b2,_0x20da35=cu()){this['value']=_0x43f2b2,this['children']=_0x20da35;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x261d01,_0x346182){if(this['value']!=null&&_0x346182(this['value']))return{'path':w(),'value':this['value']};if(v(_0x261d01))return null;{const _0x1e68b5=y(_0x261d01),_0x1f4e44=this['children']['get'](_0x1e68b5);if(_0x1f4e44!==null){const _0x48c689=_0x1f4e44['findRootMostMatchingPathAndValue'](b(_0x261d01),_0x346182);return _0x48c689!=null?{'path':k(new C(_0x1e68b5),_0x48c689['path']),'value':_0x48c689['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x26ec95){return this['findRootMostMatchingPathAndValue'](_0x26ec95,()=>!0x0);}['subtree'](_0x1b411c){if(v(_0x1b411c))return this;{const _0x16c158=y(_0x1b411c),_0x7e5686=this['children']['get'](_0x16c158);return _0x7e5686!==null?_0x7e5686['subtree'](b(_0x1b411c)):new S(null);}}['set'](_0x3dc945,_0x38d782){if(v(_0x3dc945))return new S(_0x38d782,this['children']);{const _0x155837=y(_0x3dc945),_0x7a4d5d=(this['children']['get'](_0x155837)||new S(null))['set'](b(_0x3dc945),_0x38d782),_0x176f85=this['children']['insert'](_0x155837,_0x7a4d5d);return new S(this['value'],_0x176f85);}}['remove'](_0x2f71cd){if(v(_0x2f71cd))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x322a6e=y(_0x2f71cd),_0x1e4884=this['children']['get'](_0x322a6e);if(_0x1e4884){const _0x4f7309=_0x1e4884['remove'](b(_0x2f71cd));let _0x1e613e;return _0x4f7309['isEmpty']()?_0x1e613e=this['children']['remove'](_0x322a6e):_0x1e613e=this['children']['insert'](_0x322a6e,_0x4f7309),this['value']===null&&_0x1e613e['isEmpty']()?new S(null):new S(this['value'],_0x1e613e);}else return this;}}['get'](_0x1b71c9){if(v(_0x1b71c9))return this['value'];{const _0x523a5e=y(_0x1b71c9),_0x5e3486=this['children']['get'](_0x523a5e);return _0x5e3486?_0x5e3486['get'](b(_0x1b71c9)):null;}}['setTree'](_0x2180c4,_0x4683ef){if(v(_0x2180c4))return _0x4683ef;{const _0x2e58a2=y(_0x2180c4),_0x267119=(this['children']['get'](_0x2e58a2)||new S(null))['setTree'](b(_0x2180c4),_0x4683ef);let _0x5db3fe;return _0x267119['isEmpty']()?_0x5db3fe=this['children']['remove'](_0x2e58a2):_0x5db3fe=this['children']['insert'](_0x2e58a2,_0x267119),new S(this['value'],_0x5db3fe);}}['fold'](_0xd47fb){return this['fold_'](w(),_0xd47fb);}['fold_'](_0x185deb,_0x2aedde){const _0x217e25={};return this['children']['inorderTraversal']((_0x3badf,_0x1e55d2)=>{_0x217e25[_0x3badf]=_0x1e55d2['fold_'](k(_0x185deb,_0x3badf),_0x2aedde);}),_0x2aedde(_0x185deb,this['value'],_0x217e25);}['findOnPath'](_0x40b408,_0x51293b){return this['findOnPath_'](_0x40b408,w(),_0x51293b);}['findOnPath_'](_0x3cfec8,_0x4a5d92,_0x176daf){const _0x23c13c=this['value']?_0x176daf(_0x4a5d92,this['value']):!0x1;if(_0x23c13c)return _0x23c13c;if(v(_0x3cfec8))return null;{const _0x4d9c54=y(_0x3cfec8),_0xe2fd6=this['children']['get'](_0x4d9c54);return _0xe2fd6?_0xe2fd6['findOnPath_'](b(_0x3cfec8),k(_0x4a5d92,_0x4d9c54),_0x176daf):null;}}['foreachOnPath'](_0x12d88d,_0x4ce3f2){return this['foreachOnPath_'](_0x12d88d,w(),_0x4ce3f2);}['foreachOnPath_'](_0x120d3a,_0x9e660c,_0x3f76dd){if(v(_0x120d3a))return this;{this['value']&&_0x3f76dd(_0x9e660c,this['value']);const _0x214c33=y(_0x120d3a),_0x17b1a4=this['children']['get'](_0x214c33);return _0x17b1a4?_0x17b1a4['foreachOnPath_'](b(_0x120d3a),k(_0x9e660c,_0x214c33),_0x3f76dd):new S(null);}}['foreach'](_0x356c8c){this['foreach_'](w(),_0x356c8c);}['foreach_'](_0x1bf801,_0x388beb){this['children']['inorderTraversal']((_0x5b9d2f,_0x58cb17)=>{_0x58cb17['foreach_'](k(_0x1bf801,_0x5b9d2f),_0x388beb);}),this['value']&&_0x388beb(_0x1bf801,this['value']);}['foreachChild'](_0xbbf9ed){this['children']['inorderTraversal']((_0x1a11dc,_0x1b76c2)=>{_0x1b76c2['value']&&_0xbbf9ed(_0x1a11dc,_0x1b76c2['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x285fad){this['writeTree_']=_0x285fad;}static['empty'](){return new Y(new S(null));}}function St(_0x2d2496,_0x273936,_0x1b3625){if(v(_0x273936))return new Y(new S(_0x1b3625));{const _0x4e35e9=_0x2d2496['writeTree_']['findRootMostValueAndPath'](_0x273936);if(_0x4e35e9!=null){const _0x37da6e=_0x4e35e9['path'];let _0x412f3e=_0x4e35e9['value'];const _0x3f7fde=F(_0x37da6e,_0x273936);return _0x412f3e=_0x412f3e['updateChild'](_0x3f7fde,_0x1b3625),new Y(_0x2d2496['writeTree_']['set'](_0x37da6e,_0x412f3e));}else{const _0x345e85=new S(_0x1b3625),_0x20addd=_0x2d2496['writeTree_']['setTree'](_0x273936,_0x345e85);return new Y(_0x20addd);}}}function wi(_0x50690e,_0x5f5bde,_0xea9c){let _0x886e34=_0x50690e;return x(_0xea9c,(_0x19e537,_0x3d216a)=>{_0x886e34=St(_0x886e34,k(_0x5f5bde,_0x19e537),_0x3d216a);}),_0x886e34;}function ar(_0x26c7a8,_0x7440fd){if(v(_0x7440fd))return Y['empty']();{const _0x487975=_0x26c7a8['writeTree_']['setTree'](_0x7440fd,new S(null));return new Y(_0x487975);}}function Ci(_0xa8aacb,_0x12e08e){return $e(_0xa8aacb,_0x12e08e)!=null;}function $e(_0x547447,_0x508003){const _0x88772f=_0x547447['writeTree_']['findRootMostValueAndPath'](_0x508003);return _0x88772f!=null?_0x547447['writeTree_']['get'](_0x88772f['path'])['getChild'](F(_0x88772f['path'],_0x508003)):null;}function cr(_0x7848f2){const _0x3f4e1f=[],_0x5b064c=_0x7848f2['writeTree_']['value'];return _0x5b064c!=null?_0x5b064c['isLeafNode']()||_0x5b064c['forEachChild'](R,(_0xd89cab,_0x2c68b5)=>{_0x3f4e1f['push'](new E(_0xd89cab,_0x2c68b5));}):_0x7848f2['writeTree_']['children']['inorderTraversal']((_0x21d31d,_0x35ac66)=>{_0x35ac66['value']!=null&&_0x3f4e1f['push'](new E(_0x21d31d,_0x35ac66['value']));}),_0x3f4e1f;}function ve(_0x329fc9,_0x12970a){if(v(_0x12970a))return _0x329fc9;{const _0x16a4a0=$e(_0x329fc9,_0x12970a);return _0x16a4a0!=null?new Y(new S(_0x16a4a0)):new Y(_0x329fc9['writeTree_']['subtree'](_0x12970a));}}function Ti(_0x5dfe29){return _0x5dfe29['writeTree_']['isEmpty']();}function nt(_0x210aa1,_0x403d21){return Wo(w(),_0x210aa1['writeTree_'],_0x403d21);}function Wo(_0x1e5fb7,_0x1e9e77,_0x5b16e3){if(_0x1e9e77['value']!=null)return _0x5b16e3['updateChild'](_0x1e5fb7,_0x1e9e77['value']);{let _0x294761=null;return _0x1e9e77['children']['inorderTraversal']((_0x52e2d9,_0x4388fe)=>{_0x52e2d9==='.priority'?(f(_0x4388fe['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x294761=_0x4388fe['value']):_0x5b16e3=Wo(k(_0x1e5fb7,_0x52e2d9),_0x4388fe,_0x5b16e3);}),!_0x5b16e3['getChild'](_0x1e5fb7)['isEmpty']()&&_0x294761!==null&&(_0x5b16e3=_0x5b16e3['updateChild'](k(_0x1e5fb7,'.priority'),_0x294761)),_0x5b16e3;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x36e797,_0x26d261){return $o(_0x26d261,_0x36e797);}function lu(_0x188632,_0x397d55,_0x2ef006,_0x40c020,_0x3e4041){f(_0x40c020>_0x188632['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x3e4041===void 0x0&&(_0x3e4041=!0x0),_0x188632['allWrites']['push']({'path':_0x397d55,'snap':_0x2ef006,'writeId':_0x40c020,'visible':_0x3e4041}),_0x3e4041&&(_0x188632['visibleWrites']=St(_0x188632['visibleWrites'],_0x397d55,_0x2ef006)),_0x188632['lastWriteId']=_0x40c020;}function hu(_0x5efabf,_0x2867ff,_0x41b808,_0x5f5bf9){f(_0x5f5bf9>_0x5efabf['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x5efabf['allWrites']['push']({'path':_0x2867ff,'children':_0x41b808,'writeId':_0x5f5bf9,'visible':!0x0}),_0x5efabf['visibleWrites']=wi(_0x5efabf['visibleWrites'],_0x2867ff,_0x41b808),_0x5efabf['lastWriteId']=_0x5f5bf9;}function uu(_0x2a9921,_0x3f1c7b){for(let _0x2b6d77=0x0;_0x2b6d77<_0x2a9921['allWrites']['length'];_0x2b6d77++){const _0x2b6abf=_0x2a9921['allWrites'][_0x2b6d77];if(_0x2b6abf['writeId']===_0x3f1c7b)return _0x2b6abf;}return null;}function du(_0x1531b5,_0x4d8d3b){const _0x50934c=_0x1531b5['allWrites']['findIndex'](_0x305490=>_0x305490['writeId']===_0x4d8d3b);f(_0x50934c>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x27bb4d=_0x1531b5['allWrites'][_0x50934c];_0x1531b5['allWrites']['splice'](_0x50934c,0x1);let _0x5733c5=_0x27bb4d['visible'],_0x5ae288=!0x1,_0x339697=_0x1531b5['allWrites']['length']-0x1;for(;_0x5733c5&&_0x339697>=0x0;){const _0x22288a=_0x1531b5['allWrites'][_0x339697];_0x22288a['visible']&&(_0x339697>=_0x50934c&&fu(_0x22288a,_0x27bb4d['path'])?_0x5733c5=!0x1:G(_0x27bb4d['path'],_0x22288a['path'])&&(_0x5ae288=!0x0)),_0x339697--;}if(_0x5733c5){if(_0x5ae288)return pu(_0x1531b5),!0x0;if(_0x27bb4d['snap'])_0x1531b5['visibleWrites']=ar(_0x1531b5['visibleWrites'],_0x27bb4d['path']);else{const _0x17ddcd=_0x27bb4d['children'];x(_0x17ddcd,_0x3bb29f=>{_0x1531b5['visibleWrites']=ar(_0x1531b5['visibleWrites'],k(_0x27bb4d['path'],_0x3bb29f));});}return!0x0;}else return!0x1;}function fu(_0x3fcf1e,_0x4044ea){if(_0x3fcf1e['snap'])return G(_0x3fcf1e['path'],_0x4044ea);for(const _0x167332 in _0x3fcf1e['children'])if(_0x3fcf1e['children']['hasOwnProperty'](_0x167332)&&G(k(_0x3fcf1e['path'],_0x167332),_0x4044ea))return!0x0;return!0x1;}function pu(_0x4f90b8){_0x4f90b8['visibleWrites']=Bo(_0x4f90b8['allWrites'],_u,w()),_0x4f90b8['allWrites']['length']>0x0?_0x4f90b8['lastWriteId']=_0x4f90b8['allWrites'][_0x4f90b8['allWrites']['length']-0x1]['writeId']:_0x4f90b8['lastWriteId']=-0x1;}function _u(_0x458aaf){return _0x458aaf['visible'];}function Bo(_0x12e950,_0xeae8eb,_0x2cf6f3){let _0x5aeba5=Y['empty']();for(let _0x5b4866=0x0;_0x5b4866<_0x12e950['length'];++_0x5b4866){const _0x5c2056=_0x12e950[_0x5b4866];if(_0xeae8eb(_0x5c2056)){const _0x42a6a2=_0x5c2056['path'];let _0x1aeeb8;if(_0x5c2056['snap'])G(_0x2cf6f3,_0x42a6a2)?(_0x1aeeb8=F(_0x2cf6f3,_0x42a6a2),_0x5aeba5=St(_0x5aeba5,_0x1aeeb8,_0x5c2056['snap'])):G(_0x42a6a2,_0x2cf6f3)&&(_0x1aeeb8=F(_0x42a6a2,_0x2cf6f3),_0x5aeba5=St(_0x5aeba5,w(),_0x5c2056['snap']['getChild'](_0x1aeeb8)));else{if(_0x5c2056['children']){if(G(_0x2cf6f3,_0x42a6a2))_0x1aeeb8=F(_0x2cf6f3,_0x42a6a2),_0x5aeba5=wi(_0x5aeba5,_0x1aeeb8,_0x5c2056['children']);else{if(G(_0x42a6a2,_0x2cf6f3)){if(_0x1aeeb8=F(_0x42a6a2,_0x2cf6f3),v(_0x1aeeb8))_0x5aeba5=wi(_0x5aeba5,w(),_0x5c2056['children']);else{const _0x4c4a2f=De(_0x5c2056['children'],y(_0x1aeeb8));if(_0x4c4a2f){const _0x17e3df=_0x4c4a2f['getChild'](b(_0x1aeeb8));_0x5aeba5=St(_0x5aeba5,w(),_0x17e3df);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x5aeba5;}function Vo(_0x12542e,_0x1f6ada,_0x5b5faa,_0x27d43a,_0x5a92f1){if(!_0x27d43a&&!_0x5a92f1){const _0x172973=$e(_0x12542e['visibleWrites'],_0x1f6ada);if(_0x172973!=null)return _0x172973;{const _0x24b661=ve(_0x12542e['visibleWrites'],_0x1f6ada);if(Ti(_0x24b661))return _0x5b5faa;if(_0x5b5faa==null&&!Ci(_0x24b661,w()))return null;{const _0x59fb40=_0x5b5faa||g['EMPTY_NODE'];return nt(_0x24b661,_0x59fb40);}}}else{const _0x1d4798=ve(_0x12542e['visibleWrites'],_0x1f6ada);if(!_0x5a92f1&&Ti(_0x1d4798))return _0x5b5faa;if(!_0x5a92f1&&_0x5b5faa==null&&!Ci(_0x1d4798,w()))return null;{const _0x208dd7=function(_0x3b86d5){return(_0x3b86d5['visible']||_0x5a92f1)&&(!_0x27d43a||!~_0x27d43a['indexOf'](_0x3b86d5['writeId']))&&(G(_0x3b86d5['path'],_0x1f6ada)||G(_0x1f6ada,_0x3b86d5['path']));},_0x441364=Bo(_0x12542e['allWrites'],_0x208dd7,_0x1f6ada),_0x4724fc=_0x5b5faa||g['EMPTY_NODE'];return nt(_0x441364,_0x4724fc);}}}function gu(_0x25507e,_0x11ae96,_0x21007d){let _0x41ddb1=g['EMPTY_NODE'];const _0x3529a7=$e(_0x25507e['visibleWrites'],_0x11ae96);if(_0x3529a7)return _0x3529a7['isLeafNode']()||_0x3529a7['forEachChild'](R,(_0x194da9,_0x23186d)=>{_0x41ddb1=_0x41ddb1['updateImmediateChild'](_0x194da9,_0x23186d);}),_0x41ddb1;if(_0x21007d){const _0x2aa80d=ve(_0x25507e['visibleWrites'],_0x11ae96);return _0x21007d['forEachChild'](R,(_0x474235,_0x5c78c2)=>{const _0x210add=nt(ve(_0x2aa80d,new C(_0x474235)),_0x5c78c2);_0x41ddb1=_0x41ddb1['updateImmediateChild'](_0x474235,_0x210add);}),cr(_0x2aa80d)['forEach'](_0x207080=>{_0x41ddb1=_0x41ddb1['updateImmediateChild'](_0x207080['name'],_0x207080['node']);}),_0x41ddb1;}else{const _0x2d6b1b=ve(_0x25507e['visibleWrites'],_0x11ae96);return cr(_0x2d6b1b)['forEach'](_0x5a9f6b=>{_0x41ddb1=_0x41ddb1['updateImmediateChild'](_0x5a9f6b['name'],_0x5a9f6b['node']);}),_0x41ddb1;}}function mu(_0x1d82dc,_0x158067,_0xa1d58f,_0x402b65,_0x454726){f(_0x402b65||_0x454726,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x2e6850=k(_0x158067,_0xa1d58f);if(Ci(_0x1d82dc['visibleWrites'],_0x2e6850))return null;{const _0x4fcdb7=ve(_0x1d82dc['visibleWrites'],_0x2e6850);return Ti(_0x4fcdb7)?_0x454726['getChild'](_0xa1d58f):nt(_0x4fcdb7,_0x454726['getChild'](_0xa1d58f));}}function yu(_0x3d445a,_0x13355e,_0x41bef4,_0x415b24){const _0x22a660=k(_0x13355e,_0x41bef4),_0x1db5e2=$e(_0x3d445a['visibleWrites'],_0x22a660);if(_0x1db5e2!=null)return _0x1db5e2;if(_0x415b24['isCompleteForChild'](_0x41bef4)){const _0x5d166e=ve(_0x3d445a['visibleWrites'],_0x22a660);return nt(_0x5d166e,_0x415b24['getNode']()['getImmediateChild'](_0x41bef4));}else return null;}function vu(_0x421f10,_0x3e59ec){return $e(_0x421f10['visibleWrites'],_0x3e59ec);}function Eu(_0x4b8ab2,_0x2b800a,_0x1d750b,_0x4a8d64,_0x5d4000,_0x122176,_0x2017ad){let _0x359992;const _0x433c14=ve(_0x4b8ab2['visibleWrites'],_0x2b800a),_0x4858ca=$e(_0x433c14,w());if(_0x4858ca!=null)_0x359992=_0x4858ca;else{if(_0x1d750b!=null)_0x359992=nt(_0x433c14,_0x1d750b);else return[];}if(_0x359992=_0x359992['withIndex'](_0x2017ad),!_0x359992['isEmpty']()&&!_0x359992['isLeafNode']()){const _0x4720b5=[],_0x5d5549=_0x2017ad['getCompare'](),_0x2bc06d=_0x122176?_0x359992['getReverseIteratorFrom'](_0x4a8d64,_0x2017ad):_0x359992['getIteratorFrom'](_0x4a8d64,_0x2017ad);let _0x1a9546=_0x2bc06d['getNext']();for(;_0x1a9546&&_0x4720b5['length']<_0x5d4000;)_0x5d5549(_0x1a9546,_0x4a8d64)!==0x0&&_0x4720b5['push'](_0x1a9546),_0x1a9546=_0x2bc06d['getNext']();return _0x4720b5;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x1957c0,_0x3de64a,_0x17c5e6,_0x47ef79){return Vo(_0x1957c0['writeTree'],_0x1957c0['treePath'],_0x3de64a,_0x17c5e6,_0x47ef79);}function ns(_0x5f58ee,_0x53499d){return gu(_0x5f58ee['writeTree'],_0x5f58ee['treePath'],_0x53499d);}function lr(_0x3e7274,_0x8c12f3,_0x10f9f7,_0x2c36f8){return mu(_0x3e7274['writeTree'],_0x3e7274['treePath'],_0x8c12f3,_0x10f9f7,_0x2c36f8);}function vn(_0x4ae43e,_0x1a48bc){return vu(_0x4ae43e['writeTree'],k(_0x4ae43e['treePath'],_0x1a48bc));}function wu(_0x514ed3,_0x3cbe92,_0x1ebdb6,_0x2d682c,_0x35036f,_0x3c794a){return Eu(_0x514ed3['writeTree'],_0x514ed3['treePath'],_0x3cbe92,_0x1ebdb6,_0x2d682c,_0x35036f,_0x3c794a);}function is(_0x2c239e,_0xdf9421,_0x4b1128){return yu(_0x2c239e['writeTree'],_0x2c239e['treePath'],_0xdf9421,_0x4b1128);}function Ho(_0x1f4fef,_0x1aa8a8){return $o(k(_0x1f4fef['treePath'],_0x1aa8a8),_0x1f4fef['writeTree']);}function $o(_0x211ac0,_0x16cc62){return{'treePath':_0x211ac0,'writeTree':_0x16cc62};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x40da0b){const _0x5454af=_0x40da0b['type'],_0x354a5f=_0x40da0b['childName'];f(_0x5454af==='child_added'||_0x5454af==='child_changed'||_0x5454af==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x354a5f!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x437158=this['changeMap']['get'](_0x354a5f);if(_0x437158){const _0x221ed0=_0x437158['type'];if(_0x5454af==='child_added'&&_0x221ed0==='child_removed')this['changeMap']['set'](_0x354a5f,Dt(_0x354a5f,_0x40da0b['snapshotNode'],_0x437158['snapshotNode']));else{if(_0x5454af==='child_removed'&&_0x221ed0==='child_added')this['changeMap']['delete'](_0x354a5f);else{if(_0x5454af==='child_removed'&&_0x221ed0==='child_changed')this['changeMap']['set'](_0x354a5f,Ot(_0x354a5f,_0x437158['oldSnap']));else{if(_0x5454af==='child_changed'&&_0x221ed0==='child_added')this['changeMap']['set'](_0x354a5f,et(_0x354a5f,_0x40da0b['snapshotNode']));else{if(_0x5454af==='child_changed'&&_0x221ed0==='child_changed')this['changeMap']['set'](_0x354a5f,Dt(_0x354a5f,_0x40da0b['snapshotNode'],_0x437158['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x40da0b+'\x20occurred\x20after\x20'+_0x437158);}}}}}else this['changeMap']['set'](_0x354a5f,_0x40da0b);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x1f69b5){return null;}['getChildAfterChild'](_0x4f4a4e,_0x25d8a8,_0x137db0){return null;}}const Go=new Tu();class ss{constructor(_0x327e0c,_0x51d801,_0x2b20b8=null){this['writes_']=_0x327e0c,this['viewCache_']=_0x51d801,this['optCompleteServerCache_']=_0x2b20b8;}['getCompleteChild'](_0x5087a3){const _0x54c89e=this['viewCache_']['eventCache'];if(_0x54c89e['isCompleteForChild'](_0x5087a3))return _0x54c89e['getNode']()['getImmediateChild'](_0x5087a3);{const _0x1f26ce=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x5087a3,_0x1f26ce);}}['getChildAfterChild'](_0x1b474d,_0xaa05b3,_0x566deb){const _0x5bbd80=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x580912=wu(this['writes_'],_0x5bbd80,_0xaa05b3,0x1,_0x566deb,_0x1b474d);return _0x580912['length']===0x0?null:_0x580912[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x3944c5){return{'filter':_0x3944c5};}function bu(_0x3a3ad9,_0x5949e1){f(_0x5949e1['eventCache']['getNode']()['isIndexed'](_0x3a3ad9['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x5949e1['serverCache']['getNode']()['isIndexed'](_0x3a3ad9['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x43f47c,_0x5955a4,_0x2b1848,_0x334a68,_0x4149bc){const _0x124004=new Cu();let _0x4040c2,_0x5af914;if(_0x2b1848['type']===j['OVERWRITE']){const _0x390d02=_0x2b1848;_0x390d02['source']['fromUser']?_0x4040c2=Si(_0x43f47c,_0x5955a4,_0x390d02['path'],_0x390d02['snap'],_0x334a68,_0x4149bc,_0x124004):(f(_0x390d02['source']['fromServer'],'Unknown\x20source.'),_0x5af914=_0x390d02['source']['tagged']||_0x5955a4['serverCache']['isFiltered']()&&!v(_0x390d02['path']),_0x4040c2=En(_0x43f47c,_0x5955a4,_0x390d02['path'],_0x390d02['snap'],_0x334a68,_0x4149bc,_0x5af914,_0x124004));}else{if(_0x2b1848['type']===j['MERGE']){const _0x1c368a=_0x2b1848;_0x1c368a['source']['fromUser']?_0x4040c2=ku(_0x43f47c,_0x5955a4,_0x1c368a['path'],_0x1c368a['children'],_0x334a68,_0x4149bc,_0x124004):(f(_0x1c368a['source']['fromServer'],'Unknown\x20source.'),_0x5af914=_0x1c368a['source']['tagged']||_0x5955a4['serverCache']['isFiltered'](),_0x4040c2=bi(_0x43f47c,_0x5955a4,_0x1c368a['path'],_0x1c368a['children'],_0x334a68,_0x4149bc,_0x5af914,_0x124004));}else{if(_0x2b1848['type']===j['ACK_USER_WRITE']){const _0x501547=_0x2b1848;_0x501547['revert']?_0x4040c2=Ou(_0x43f47c,_0x5955a4,_0x501547['path'],_0x334a68,_0x4149bc,_0x124004):_0x4040c2=Nu(_0x43f47c,_0x5955a4,_0x501547['path'],_0x501547['affectedTree'],_0x334a68,_0x4149bc,_0x124004);}else{if(_0x2b1848['type']===j['LISTEN_COMPLETE'])_0x4040c2=Pu(_0x43f47c,_0x5955a4,_0x2b1848['path'],_0x334a68,_0x124004);else throw rt('Unknown\x20operation\x20type:\x20'+_0x2b1848['type']);}}}const _0xd37aef=_0x124004['getChanges']();return Au(_0x5955a4,_0x4040c2,_0xd37aef),{'viewCache':_0x4040c2,'changes':_0xd37aef};}function Au(_0x5d040c,_0x3abe85,_0x247e34){const _0x4109c7=_0x3abe85['eventCache'];if(_0x4109c7['isFullyInitialized']()){const _0x180e65=_0x4109c7['getNode']()['isLeafNode']()||_0x4109c7['getNode']()['isEmpty'](),_0x345df2=mn(_0x5d040c);(_0x247e34['length']>0x0||!_0x5d040c['eventCache']['isFullyInitialized']()||_0x180e65&&!_0x4109c7['getNode']()['equals'](_0x345df2)||!_0x4109c7['getNode']()['getPriority']()['equals'](_0x345df2['getPriority']()))&&_0x247e34['push'](Lo(mn(_0x3abe85)));}}function qo(_0xb7ddcc,_0x29789b,_0x5a2aaf,_0x49c543,_0x32f841,_0xcf76f3){const _0x40b313=_0x29789b['eventCache'];if(vn(_0x49c543,_0x5a2aaf)!=null)return _0x29789b;{let _0x3c4da5,_0x4e5de7;if(v(_0x5a2aaf)){if(f(_0x29789b['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x29789b['serverCache']['isFiltered']()){const _0x44612c=We(_0x29789b),_0x47bbce=_0x44612c instanceof g?_0x44612c:g['EMPTY_NODE'],_0x418573=ns(_0x49c543,_0x47bbce);_0x3c4da5=_0xb7ddcc['filter']['updateFullNode'](_0x29789b['eventCache']['getNode'](),_0x418573,_0xcf76f3);}else{const _0xc82e75=yn(_0x49c543,We(_0x29789b));_0x3c4da5=_0xb7ddcc['filter']['updateFullNode'](_0x29789b['eventCache']['getNode'](),_0xc82e75,_0xcf76f3);}}else{const _0x15446a=y(_0x5a2aaf);if(_0x15446a==='.priority'){f(we(_0x5a2aaf)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x19d0b5=_0x40b313['getNode']();_0x4e5de7=_0x29789b['serverCache']['getNode']();const _0xe8451f=lr(_0x49c543,_0x5a2aaf,_0x19d0b5,_0x4e5de7);_0xe8451f!=null?_0x3c4da5=_0xb7ddcc['filter']['updatePriority'](_0x19d0b5,_0xe8451f):_0x3c4da5=_0x40b313['getNode']();}else{const _0x4c3294=b(_0x5a2aaf);let _0x29f465;if(_0x40b313['isCompleteForChild'](_0x15446a)){_0x4e5de7=_0x29789b['serverCache']['getNode']();const _0x3e4ed0=lr(_0x49c543,_0x5a2aaf,_0x40b313['getNode'](),_0x4e5de7);_0x3e4ed0!=null?_0x29f465=_0x40b313['getNode']()['getImmediateChild'](_0x15446a)['updateChild'](_0x4c3294,_0x3e4ed0):_0x29f465=_0x40b313['getNode']()['getImmediateChild'](_0x15446a);}else _0x29f465=is(_0x49c543,_0x15446a,_0x29789b['serverCache']);_0x29f465!=null?_0x3c4da5=_0xb7ddcc['filter']['updateChild'](_0x40b313['getNode'](),_0x15446a,_0x29f465,_0x4c3294,_0x32f841,_0xcf76f3):_0x3c4da5=_0x40b313['getNode']();}}return Tt(_0x29789b,_0x3c4da5,_0x40b313['isFullyInitialized']()||v(_0x5a2aaf),_0xb7ddcc['filter']['filtersNodes']());}}function En(_0x48adf5,_0x50461e,_0x3ba025,_0xd2b1f9,_0x1514cf,_0xa86eda,_0x3406c6,_0x3cde24){const _0x55fec2=_0x50461e['serverCache'];let _0x4635e1;const _0x196d46=_0x3406c6?_0x48adf5['filter']:_0x48adf5['filter']['getIndexedFilter']();if(v(_0x3ba025))_0x4635e1=_0x196d46['updateFullNode'](_0x55fec2['getNode'](),_0xd2b1f9,null);else{if(_0x196d46['filtersNodes']()&&!_0x55fec2['isFiltered']()){const _0x385805=_0x55fec2['getNode']()['updateChild'](_0x3ba025,_0xd2b1f9);_0x4635e1=_0x196d46['updateFullNode'](_0x55fec2['getNode'](),_0x385805,null);}else{const _0x3169cb=y(_0x3ba025);if(!_0x55fec2['isCompleteForPath'](_0x3ba025)&&we(_0x3ba025)>0x1)return _0x50461e;const _0x282b6c=b(_0x3ba025),_0x286082=_0x55fec2['getNode']()['getImmediateChild'](_0x3169cb)['updateChild'](_0x282b6c,_0xd2b1f9);_0x3169cb==='.priority'?_0x4635e1=_0x196d46['updatePriority'](_0x55fec2['getNode'](),_0x286082):_0x4635e1=_0x196d46['updateChild'](_0x55fec2['getNode'](),_0x3169cb,_0x286082,_0x282b6c,Go,null);}}const _0x53acd0=Uo(_0x50461e,_0x4635e1,_0x55fec2['isFullyInitialized']()||v(_0x3ba025),_0x196d46['filtersNodes']()),_0x38ea19=new ss(_0x1514cf,_0x53acd0,_0xa86eda);return qo(_0x48adf5,_0x53acd0,_0x3ba025,_0x1514cf,_0x38ea19,_0x3cde24);}function Si(_0x1c3237,_0x50af7,_0x1939db,_0x3df619,_0x80d8f,_0x42499c,_0x5570c1){const _0x2c9dc2=_0x50af7['eventCache'];let _0x567f59,_0x1d448a;const _0xf693b3=new ss(_0x80d8f,_0x50af7,_0x42499c);if(v(_0x1939db))_0x1d448a=_0x1c3237['filter']['updateFullNode'](_0x50af7['eventCache']['getNode'](),_0x3df619,_0x5570c1),_0x567f59=Tt(_0x50af7,_0x1d448a,!0x0,_0x1c3237['filter']['filtersNodes']());else{const _0x545dd6=y(_0x1939db);if(_0x545dd6==='.priority')_0x1d448a=_0x1c3237['filter']['updatePriority'](_0x50af7['eventCache']['getNode'](),_0x3df619),_0x567f59=Tt(_0x50af7,_0x1d448a,_0x2c9dc2['isFullyInitialized'](),_0x2c9dc2['isFiltered']());else{const _0x53b670=b(_0x1939db),_0x272f36=_0x2c9dc2['getNode']()['getImmediateChild'](_0x545dd6);let _0x84d5cc;if(v(_0x53b670))_0x84d5cc=_0x3df619;else{const _0x3ca347=_0xf693b3['getCompleteChild'](_0x545dd6);_0x3ca347!=null?zi(_0x53b670)==='.priority'&&_0x3ca347['getChild'](Ro(_0x53b670))['isEmpty']()?_0x84d5cc=_0x3ca347:_0x84d5cc=_0x3ca347['updateChild'](_0x53b670,_0x3df619):_0x84d5cc=g['EMPTY_NODE'];}if(_0x272f36['equals'](_0x84d5cc))_0x567f59=_0x50af7;else{const _0x25f7e3=_0x1c3237['filter']['updateChild'](_0x2c9dc2['getNode'](),_0x545dd6,_0x84d5cc,_0x53b670,_0xf693b3,_0x5570c1);_0x567f59=Tt(_0x50af7,_0x25f7e3,_0x2c9dc2['isFullyInitialized'](),_0x1c3237['filter']['filtersNodes']());}}}return _0x567f59;}function hr(_0x5e969d,_0x4cae41){return _0x5e969d['eventCache']['isCompleteForChild'](_0x4cae41);}function ku(_0xb49731,_0x1a0cc4,_0xc51044,_0xbea19d,_0x5824d2,_0x424caf,_0x10b334){let _0x2c10c2=_0x1a0cc4;return _0xbea19d['foreach']((_0x4b2e81,_0x6fc172)=>{const _0x310c1b=k(_0xc51044,_0x4b2e81);hr(_0x1a0cc4,y(_0x310c1b))&&(_0x2c10c2=Si(_0xb49731,_0x2c10c2,_0x310c1b,_0x6fc172,_0x5824d2,_0x424caf,_0x10b334));}),_0xbea19d['foreach']((_0x52749c,_0x534014)=>{const _0x4960be=k(_0xc51044,_0x52749c);hr(_0x1a0cc4,y(_0x4960be))||(_0x2c10c2=Si(_0xb49731,_0x2c10c2,_0x4960be,_0x534014,_0x5824d2,_0x424caf,_0x10b334));}),_0x2c10c2;}function ur(_0x3f2a5b,_0x557084,_0xc3d0c6){return _0xc3d0c6['foreach']((_0x4c0f88,_0x3fb309)=>{_0x557084=_0x557084['updateChild'](_0x4c0f88,_0x3fb309);}),_0x557084;}function bi(_0x157cf8,_0x17bcf7,_0x5e4654,_0x58f6e0,_0x4e1e97,_0x35a983,_0x4a9fbd,_0x5f01eb){if(_0x17bcf7['serverCache']['getNode']()['isEmpty']()&&!_0x17bcf7['serverCache']['isFullyInitialized']())return _0x17bcf7;let _0x416528=_0x17bcf7,_0x5cbf5c;v(_0x5e4654)?_0x5cbf5c=_0x58f6e0:_0x5cbf5c=new S(null)['setTree'](_0x5e4654,_0x58f6e0);const _0x1b0e39=_0x17bcf7['serverCache']['getNode']();return _0x5cbf5c['children']['inorderTraversal']((_0x4749b9,_0x179a08)=>{if(_0x1b0e39['hasChild'](_0x4749b9)){const _0x32b430=_0x17bcf7['serverCache']['getNode']()['getImmediateChild'](_0x4749b9),_0x4612e3=ur(_0x157cf8,_0x32b430,_0x179a08);_0x416528=En(_0x157cf8,_0x416528,new C(_0x4749b9),_0x4612e3,_0x4e1e97,_0x35a983,_0x4a9fbd,_0x5f01eb);}}),_0x5cbf5c['children']['inorderTraversal']((_0x1a49ad,_0x418806)=>{const _0x5381f3=!_0x17bcf7['serverCache']['isCompleteForChild'](_0x1a49ad)&&_0x418806['value']===null;if(!_0x1b0e39['hasChild'](_0x1a49ad)&&!_0x5381f3){const _0x34c975=_0x17bcf7['serverCache']['getNode']()['getImmediateChild'](_0x1a49ad),_0x56b88f=ur(_0x157cf8,_0x34c975,_0x418806);_0x416528=En(_0x157cf8,_0x416528,new C(_0x1a49ad),_0x56b88f,_0x4e1e97,_0x35a983,_0x4a9fbd,_0x5f01eb);}}),_0x416528;}function Nu(_0x43053,_0x4962f4,_0x534aa7,_0x29f8a1,_0x4b7a4b,_0x3bbba4,_0x5b1658){if(vn(_0x4b7a4b,_0x534aa7)!=null)return _0x4962f4;const _0x4ae674=_0x4962f4['serverCache']['isFiltered'](),_0x3696e1=_0x4962f4['serverCache'];if(_0x29f8a1['value']!=null){if(v(_0x534aa7)&&_0x3696e1['isFullyInitialized']()||_0x3696e1['isCompleteForPath'](_0x534aa7))return En(_0x43053,_0x4962f4,_0x534aa7,_0x3696e1['getNode']()['getChild'](_0x534aa7),_0x4b7a4b,_0x3bbba4,_0x4ae674,_0x5b1658);if(v(_0x534aa7)){let _0x341e3a=new S(null);return _0x3696e1['getNode']()['forEachChild'](ye,(_0x270571,_0x4d7074)=>{_0x341e3a=_0x341e3a['set'](new C(_0x270571),_0x4d7074);}),bi(_0x43053,_0x4962f4,_0x534aa7,_0x341e3a,_0x4b7a4b,_0x3bbba4,_0x4ae674,_0x5b1658);}else return _0x4962f4;}else{let _0x59f140=new S(null);return _0x29f8a1['foreach']((_0x450dcc,_0x39af89)=>{const _0x12471b=k(_0x534aa7,_0x450dcc);_0x3696e1['isCompleteForPath'](_0x12471b)&&(_0x59f140=_0x59f140['set'](_0x450dcc,_0x3696e1['getNode']()['getChild'](_0x12471b)));}),bi(_0x43053,_0x4962f4,_0x534aa7,_0x59f140,_0x4b7a4b,_0x3bbba4,_0x4ae674,_0x5b1658);}}function Pu(_0x254190,_0x1dfebf,_0x1295de,_0x343985,_0x56f241){const _0x3a2cc0=_0x1dfebf['serverCache'],_0x4b4ff4=Uo(_0x1dfebf,_0x3a2cc0['getNode'](),_0x3a2cc0['isFullyInitialized']()||v(_0x1295de),_0x3a2cc0['isFiltered']());return qo(_0x254190,_0x4b4ff4,_0x1295de,_0x343985,Go,_0x56f241);}function Ou(_0x113b71,_0x3efc89,_0x4dd1b0,_0x25701c,_0x17ae32,_0x390552){let _0x2a5692;if(vn(_0x25701c,_0x4dd1b0)!=null)return _0x3efc89;{const _0x3e4841=new ss(_0x25701c,_0x3efc89,_0x17ae32),_0x20ceaf=_0x3efc89['eventCache']['getNode']();let _0x429fd2;if(v(_0x4dd1b0)||y(_0x4dd1b0)==='.priority'){let _0x5e7661;if(_0x3efc89['serverCache']['isFullyInitialized']())_0x5e7661=yn(_0x25701c,We(_0x3efc89));else{const _0x443489=_0x3efc89['serverCache']['getNode']();f(_0x443489 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x5e7661=ns(_0x25701c,_0x443489);}_0x5e7661=_0x5e7661,_0x429fd2=_0x113b71['filter']['updateFullNode'](_0x20ceaf,_0x5e7661,_0x390552);}else{const _0x4ecbaa=y(_0x4dd1b0);let _0x5eb6a8=is(_0x25701c,_0x4ecbaa,_0x3efc89['serverCache']);_0x5eb6a8==null&&_0x3efc89['serverCache']['isCompleteForChild'](_0x4ecbaa)&&(_0x5eb6a8=_0x20ceaf['getImmediateChild'](_0x4ecbaa)),_0x5eb6a8!=null?_0x429fd2=_0x113b71['filter']['updateChild'](_0x20ceaf,_0x4ecbaa,_0x5eb6a8,b(_0x4dd1b0),_0x3e4841,_0x390552):_0x3efc89['eventCache']['getNode']()['hasChild'](_0x4ecbaa)?_0x429fd2=_0x113b71['filter']['updateChild'](_0x20ceaf,_0x4ecbaa,g['EMPTY_NODE'],b(_0x4dd1b0),_0x3e4841,_0x390552):_0x429fd2=_0x20ceaf,_0x429fd2['isEmpty']()&&_0x3efc89['serverCache']['isFullyInitialized']()&&(_0x2a5692=yn(_0x25701c,We(_0x3efc89)),_0x2a5692['isLeafNode']()&&(_0x429fd2=_0x113b71['filter']['updateFullNode'](_0x429fd2,_0x2a5692,_0x390552)));}return _0x2a5692=_0x3efc89['serverCache']['isFullyInitialized']()||vn(_0x25701c,w())!=null,Tt(_0x3efc89,_0x429fd2,_0x2a5692,_0x113b71['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x257f0a,_0x2e2462){this['query_']=_0x257f0a,this['eventRegistrations_']=[];const _0xd81589=this['query_']['_queryParams'],_0x6b6618=new Ji(_0xd81589['getIndex']()),_0x5ed7cd=Kh(_0xd81589);this['processor_']=Su(_0x5ed7cd);const _0x7bb8bb=_0x2e2462['serverCache'],_0x54f037=_0x2e2462['eventCache'],_0x40fff1=_0x6b6618['updateFullNode'](g['EMPTY_NODE'],_0x7bb8bb['getNode'](),null),_0xebc3d3=_0x5ed7cd['updateFullNode'](g['EMPTY_NODE'],_0x54f037['getNode'](),null),_0x2ea3c2=new Ce(_0x40fff1,_0x7bb8bb['isFullyInitialized'](),_0x6b6618['filtersNodes']()),_0x541489=new Ce(_0xebc3d3,_0x54f037['isFullyInitialized'](),_0x5ed7cd['filtersNodes']());this['viewCache_']=Mn(_0x541489,_0x2ea3c2),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x1c390a){return _0x1c390a['viewCache_']['serverCache']['getNode']();}function Lu(_0x39b66d){return mn(_0x39b66d['viewCache_']);}function xu(_0x4f8369,_0x229f1b){const _0x51865e=We(_0x4f8369['viewCache_']);return _0x51865e&&(_0x4f8369['query']['_queryParams']['loadsAllData']()||!v(_0x229f1b)&&!_0x51865e['getImmediateChild'](y(_0x229f1b))['isEmpty']())?_0x51865e['getChild'](_0x229f1b):null;}function dr(_0x2e488b){return _0x2e488b['eventRegistrations_']['length']===0x0;}function Fu(_0x35f86e,_0x45a050){_0x35f86e['eventRegistrations_']['push'](_0x45a050);}function fr(_0x60d20a,_0x2dedef,_0x2b0e4d){const _0x565136=[];if(_0x2b0e4d){f(_0x2dedef==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x30f30a=_0x60d20a['query']['_path'];_0x60d20a['eventRegistrations_']['forEach'](_0x9257fe=>{const _0x5e3dae=_0x9257fe['createCancelEvent'](_0x2b0e4d,_0x30f30a);_0x5e3dae&&_0x565136['push'](_0x5e3dae);});}if(_0x2dedef){let _0x390b9f=[];for(let _0x85689e=0x0;_0x85689e<_0x60d20a['eventRegistrations_']['length'];++_0x85689e){const _0x39a22c=_0x60d20a['eventRegistrations_'][_0x85689e];if(!_0x39a22c['matches'](_0x2dedef))_0x390b9f['push'](_0x39a22c);else{if(_0x2dedef['hasAnyCallback']()){_0x390b9f=_0x390b9f['concat'](_0x60d20a['eventRegistrations_']['slice'](_0x85689e+0x1));break;}}}_0x60d20a['eventRegistrations_']=_0x390b9f;}else _0x60d20a['eventRegistrations_']=[];return _0x565136;}function pr(_0x327268,_0x3c0127,_0x1dc96d,_0xcb4e83){_0x3c0127['type']===j['MERGE']&&_0x3c0127['source']['queryId']!==null&&(f(We(_0x327268['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x327268['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x14b8cd=_0x327268['viewCache_'],_0x2600ac=Ru(_0x327268['processor_'],_0x14b8cd,_0x3c0127,_0x1dc96d,_0xcb4e83);return bu(_0x327268['processor_'],_0x2600ac['viewCache']),f(_0x2600ac['viewCache']['serverCache']['isFullyInitialized']()||!_0x14b8cd['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x327268['viewCache_']=_0x2600ac['viewCache'],zo(_0x327268,_0x2600ac['changes'],_0x2600ac['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x433550,_0x2853b8){const _0x3a3e92=_0x433550['viewCache_']['eventCache'],_0xf1222a=[];return _0x3a3e92['getNode']()['isLeafNode']()||_0x3a3e92['getNode']()['forEachChild'](R,(_0x4ab806,_0x3cb55f)=>{_0xf1222a['push'](et(_0x4ab806,_0x3cb55f));}),_0x3a3e92['isFullyInitialized']()&&_0xf1222a['push'](Lo(_0x3a3e92['getNode']())),zo(_0x433550,_0xf1222a,_0x3a3e92['getNode'](),_0x2853b8);}function zo(_0x380347,_0x13dbce,_0x26473f,_0x2dcf7c){const _0x1756c2=_0x2dcf7c?[_0x2dcf7c]:_0x380347['eventRegistrations_'];return ru(_0x380347['eventGenerator_'],_0x13dbce,_0x26473f,_0x1756c2);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x5eb01e){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x5eb01e;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x3ea714){return _0x3ea714['views']['size']===0x0;}function rs(_0x168d02,_0x3ac46d,_0x525986,_0x12f3c1){const _0x51995d=_0x3ac46d['source']['queryId'];if(_0x51995d!==null){const _0x3b5808=_0x168d02['views']['get'](_0x51995d);return f(_0x3b5808!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x3b5808,_0x3ac46d,_0x525986,_0x12f3c1);}else{let _0x479618=[];for(const _0x2e0899 of _0x168d02['views']['values']())_0x479618=_0x479618['concat'](pr(_0x2e0899,_0x3ac46d,_0x525986,_0x12f3c1));return _0x479618;}}function Ko(_0x126782,_0x3c9950,_0x47ba39,_0x47885d,_0x25a68c){const _0xf8e6e1=_0x3c9950['_queryIdentifier'],_0x5acd6e=_0x126782['views']['get'](_0xf8e6e1);if(!_0x5acd6e){let _0x225673=yn(_0x47ba39,_0x25a68c?_0x47885d:null),_0x3cc97b=!0x1;_0x225673?_0x3cc97b=!0x0:_0x47885d instanceof g?(_0x225673=ns(_0x47ba39,_0x47885d),_0x3cc97b=!0x1):(_0x225673=g['EMPTY_NODE'],_0x3cc97b=!0x1);const _0x32b7c3=Mn(new Ce(_0x225673,_0x3cc97b,!0x1),new Ce(_0x47885d,_0x25a68c,!0x1));return new Du(_0x3c9950,_0x32b7c3);}return _0x5acd6e;}function Hu(_0x3adeb9,_0x23000b,_0x361c27,_0x5bff47,_0xe74291,_0x3378bc){const _0x21c6a4=Ko(_0x3adeb9,_0x23000b,_0x5bff47,_0xe74291,_0x3378bc);return _0x3adeb9['views']['has'](_0x23000b['_queryIdentifier'])||_0x3adeb9['views']['set'](_0x23000b['_queryIdentifier'],_0x21c6a4),Fu(_0x21c6a4,_0x361c27),Uu(_0x21c6a4,_0x361c27);}function $u(_0x2aaad7,_0x2abece,_0x4b2b72,_0x2dbbff){const _0x2e41ef=_0x2abece['_queryIdentifier'],_0x58e976=[];let _0x4d6ebf=[];const _0x76763d=Te(_0x2aaad7);if(_0x2e41ef==='default'){for(const [_0x37b31f,_0x835dbe]of _0x2aaad7['views']['entries']())_0x4d6ebf=_0x4d6ebf['concat'](fr(_0x835dbe,_0x4b2b72,_0x2dbbff)),dr(_0x835dbe)&&(_0x2aaad7['views']['delete'](_0x37b31f),_0x835dbe['query']['_queryParams']['loadsAllData']()||_0x58e976['push'](_0x835dbe['query']));}else{const _0x26bfb9=_0x2aaad7['views']['get'](_0x2e41ef);_0x26bfb9&&(_0x4d6ebf=_0x4d6ebf['concat'](fr(_0x26bfb9,_0x4b2b72,_0x2dbbff)),dr(_0x26bfb9)&&(_0x2aaad7['views']['delete'](_0x2e41ef),_0x26bfb9['query']['_queryParams']['loadsAllData']()||_0x58e976['push'](_0x26bfb9['query'])));}return _0x76763d&&!Te(_0x2aaad7)&&_0x58e976['push'](new(Bu())(_0x2abece['_repo'],_0x2abece['_path'])),{'removed':_0x58e976,'events':_0x4d6ebf};}function Yo(_0x4ff45a){const _0x2a7dca=[];for(const _0x37a5ac of _0x4ff45a['views']['values']())_0x37a5ac['query']['_queryParams']['loadsAllData']()||_0x2a7dca['push'](_0x37a5ac);return _0x2a7dca;}function Ee(_0x28b01b,_0x4f5c9c){let _0x48b284=null;for(const _0x1e6174 of _0x28b01b['views']['values']())_0x48b284=_0x48b284||xu(_0x1e6174,_0x4f5c9c);return _0x48b284;}function Qo(_0x354315,_0x5e30dc){if(_0x5e30dc['_queryParams']['loadsAllData']())return xn(_0x354315);{const _0x2c961c=_0x5e30dc['_queryIdentifier'];return _0x354315['views']['get'](_0x2c961c);}}function Jo(_0x48622f,_0x514cd1){return Qo(_0x48622f,_0x514cd1)!=null;}function Te(_0x20d068){return xn(_0x20d068)!=null;}function xn(_0x1869e4){for(const _0x526ea3 of _0x1869e4['views']['values']())if(_0x526ea3['query']['_queryParams']['loadsAllData']())return _0x526ea3;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x386eed){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x386eed;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x8868ce){this['listenProvider_']=_0x8868ce,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x33452e,_0x4d2a40,_0x36638a,_0x899154,_0x3ac5fe){return lu(_0x33452e['pendingWriteTree_'],_0x4d2a40,_0x36638a,_0x899154,_0x3ac5fe),_0x3ac5fe?ut(_0x33452e,new Ue(Zi(),_0x4d2a40,_0x36638a)):[];}function ju(_0x55e8cb,_0x402a6d,_0x1e8f5d,_0x540b07){hu(_0x55e8cb['pendingWriteTree_'],_0x402a6d,_0x1e8f5d,_0x540b07);const _0x3cbca7=S['fromObject'](_0x1e8f5d);return ut(_0x55e8cb,new tt(Zi(),_0x402a6d,_0x3cbca7));}function pe(_0x128878,_0x121055,_0x1ac6da=!0x1){const _0x189585=uu(_0x128878['pendingWriteTree_'],_0x121055);if(du(_0x128878['pendingWriteTree_'],_0x121055)){let _0x52c88d=new S(null);return _0x189585['snap']!=null?_0x52c88d=_0x52c88d['set'](w(),!0x0):x(_0x189585['children'],_0x1b252a=>{_0x52c88d=_0x52c88d['set'](new C(_0x1b252a),!0x0);}),ut(_0x128878,new gn(_0x189585['path'],_0x52c88d,_0x1ac6da));}else return[];}function Gt(_0x5344fc,_0x44e428,_0x39906c){return ut(_0x5344fc,new Ue(es(),_0x44e428,_0x39906c));}function Ku(_0x44925c,_0x5d0929,_0x37975a){const _0x330f72=S['fromObject'](_0x37975a);return ut(_0x44925c,new tt(es(),_0x5d0929,_0x330f72));}function Yu(_0x2bb065,_0x35db2f){return ut(_0x2bb065,new Lt(es(),_0x35db2f));}function Qu(_0x1f4c2a,_0x52e090,_0x4e5b4a){const _0x3055d6=as(_0x1f4c2a,_0x4e5b4a);if(_0x3055d6){const _0x559ef3=cs(_0x3055d6),_0x59f501=_0x559ef3['path'],_0x42a3a1=_0x559ef3['queryId'],_0x1b0d84=F(_0x59f501,_0x52e090),_0x1e46b7=new Lt(ts(_0x42a3a1),_0x1b0d84);return ls(_0x1f4c2a,_0x59f501,_0x1e46b7);}else return[];}function Cn(_0x2c7e3c,_0x2907cb,_0x6125d6,_0x43d2a5,_0x5cf022=!0x1){const _0x1ccdf3=_0x2907cb['_path'],_0x2c2fc0=_0x2c7e3c['syncPointTree_']['get'](_0x1ccdf3);let _0x3d7edc=[];if(_0x2c2fc0&&(_0x2907cb['_queryIdentifier']==='default'||Jo(_0x2c2fc0,_0x2907cb))){const _0x534f95=$u(_0x2c2fc0,_0x2907cb,_0x6125d6,_0x43d2a5);Vu(_0x2c2fc0)&&(_0x2c7e3c['syncPointTree_']=_0x2c7e3c['syncPointTree_']['remove'](_0x1ccdf3));const _0x231c2f=_0x534f95['removed'];if(_0x3d7edc=_0x534f95['events'],!_0x5cf022){const _0x3f9cb1=_0x231c2f['findIndex'](_0x5dbec2=>_0x5dbec2['_queryParams']['loadsAllData']())!==-0x1,_0x1c3ca2=_0x2c7e3c['syncPointTree_']['findOnPath'](_0x1ccdf3,(_0x2244b9,_0x147073)=>Te(_0x147073));if(_0x3f9cb1&&!_0x1c3ca2){const _0x4f1b6d=_0x2c7e3c['syncPointTree_']['subtree'](_0x1ccdf3);if(!_0x4f1b6d['isEmpty']()){const _0x2b94c0=Zu(_0x4f1b6d);for(let _0x2a4464=0x0;_0x2a4464<_0x2b94c0['length'];++_0x2a4464){const _0x50d7dc=_0x2b94c0[_0x2a4464],_0xc0ea87=_0x50d7dc['query'],_0x3de973=ta(_0x2c7e3c,_0x50d7dc);_0x2c7e3c['listenProvider_']['startListening'](bt(_0xc0ea87),xt(_0x2c7e3c,_0xc0ea87),_0x3de973['hashFn'],_0x3de973['onComplete']);}}}!_0x1c3ca2&&_0x231c2f['length']>0x0&&!_0x43d2a5&&(_0x3f9cb1?_0x2c7e3c['listenProvider_']['stopListening'](bt(_0x2907cb),null):_0x231c2f['forEach'](_0x76c8cf=>{const _0xc9ff62=_0x2c7e3c['queryToTagMap']['get'](Un(_0x76c8cf));_0x2c7e3c['listenProvider_']['stopListening'](bt(_0x76c8cf),_0xc9ff62);}));}ed(_0x2c7e3c,_0x231c2f);}return _0x3d7edc;}function Xo(_0x3d5fa9,_0x3bcd4c,_0x181870,_0x47004f){const _0x5c2889=as(_0x3d5fa9,_0x47004f);if(_0x5c2889!=null){const _0x3cd5c4=cs(_0x5c2889),_0x5ad022=_0x3cd5c4['path'],_0x53fa55=_0x3cd5c4['queryId'],_0x348865=F(_0x5ad022,_0x3bcd4c),_0x313c1e=new Ue(ts(_0x53fa55),_0x348865,_0x181870);return ls(_0x3d5fa9,_0x5ad022,_0x313c1e);}else return[];}function Ju(_0x1000c7,_0x403c30,_0x5877f1,_0x235a1f){const _0x238715=as(_0x1000c7,_0x235a1f);if(_0x238715){const _0x39faff=cs(_0x238715),_0x5db5a2=_0x39faff['path'],_0x40d7ea=_0x39faff['queryId'],_0x47324b=F(_0x5db5a2,_0x403c30),_0x1b71c8=S['fromObject'](_0x5877f1),_0x5d0dbe=new tt(ts(_0x40d7ea),_0x47324b,_0x1b71c8);return ls(_0x1000c7,_0x5db5a2,_0x5d0dbe);}else return[];}function Ri(_0x160d97,_0x257c7e,_0x3721d7,_0x58d78c=!0x1){const _0x1b9bc3=_0x257c7e['_path'];let _0x539adb=null,_0x1ad6cc=!0x1;_0x160d97['syncPointTree_']['foreachOnPath'](_0x1b9bc3,(_0x37c7f6,_0x2a8fc2)=>{const _0xebd245=F(_0x37c7f6,_0x1b9bc3);_0x539adb=_0x539adb||Ee(_0x2a8fc2,_0xebd245),_0x1ad6cc=_0x1ad6cc||Te(_0x2a8fc2);});let _0x8b39fc=_0x160d97['syncPointTree_']['get'](_0x1b9bc3);_0x8b39fc?(_0x1ad6cc=_0x1ad6cc||Te(_0x8b39fc),_0x539adb=_0x539adb||Ee(_0x8b39fc,w())):(_0x8b39fc=new jo(),_0x160d97['syncPointTree_']=_0x160d97['syncPointTree_']['set'](_0x1b9bc3,_0x8b39fc));let _0x368177;_0x539adb!=null?_0x368177=!0x0:(_0x368177=!0x1,_0x539adb=g['EMPTY_NODE'],_0x160d97['syncPointTree_']['subtree'](_0x1b9bc3)['foreachChild']((_0x26e33c,_0xf93fd4)=>{const _0x3f2948=Ee(_0xf93fd4,w());_0x3f2948&&(_0x539adb=_0x539adb['updateImmediateChild'](_0x26e33c,_0x3f2948));}));const _0x12ee10=Jo(_0x8b39fc,_0x257c7e);if(!_0x12ee10&&!_0x257c7e['_queryParams']['loadsAllData']()){const _0xb5a3a6=Un(_0x257c7e);f(!_0x160d97['queryToTagMap']['has'](_0xb5a3a6),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x3ba11f=td();_0x160d97['queryToTagMap']['set'](_0xb5a3a6,_0x3ba11f),_0x160d97['tagToQueryMap']['set'](_0x3ba11f,_0xb5a3a6);}const _0x5bb969=Ln(_0x160d97['pendingWriteTree_'],_0x1b9bc3);let _0x9b5651=Hu(_0x8b39fc,_0x257c7e,_0x3721d7,_0x5bb969,_0x539adb,_0x368177);if(!_0x12ee10&&!_0x1ad6cc&&!_0x58d78c){const _0x8bc88e=Qo(_0x8b39fc,_0x257c7e);_0x9b5651=_0x9b5651['concat'](nd(_0x160d97,_0x257c7e,_0x8bc88e));}return _0x9b5651;}function Fn(_0xc14474,_0x12b53f,_0x33f4cd){const _0x45de9f=_0xc14474['pendingWriteTree_'],_0x2192b2=_0xc14474['syncPointTree_']['findOnPath'](_0x12b53f,(_0x32b073,_0x4072d8)=>{const _0x5f2fa6=F(_0x32b073,_0x12b53f),_0x1d11d6=Ee(_0x4072d8,_0x5f2fa6);if(_0x1d11d6)return _0x1d11d6;});return Vo(_0x45de9f,_0x12b53f,_0x2192b2,_0x33f4cd,!0x0);}function Xu(_0x4fa9ec,_0x15a37a){const _0x373f43=_0x15a37a['_path'];let _0x48002b=null;_0x4fa9ec['syncPointTree_']['foreachOnPath'](_0x373f43,(_0x27fd93,_0x56e3a4)=>{const _0x503c7=F(_0x27fd93,_0x373f43);_0x48002b=_0x48002b||Ee(_0x56e3a4,_0x503c7);});let _0x247069=_0x4fa9ec['syncPointTree_']['get'](_0x373f43);_0x247069?_0x48002b=_0x48002b||Ee(_0x247069,w()):(_0x247069=new jo(),_0x4fa9ec['syncPointTree_']=_0x4fa9ec['syncPointTree_']['set'](_0x373f43,_0x247069));const _0x4fd80e=_0x48002b!=null,_0xf1b3c4=_0x4fd80e?new Ce(_0x48002b,!0x0,!0x1):null,_0x4fd0ba=Ln(_0x4fa9ec['pendingWriteTree_'],_0x15a37a['_path']),_0x2ab811=Ko(_0x247069,_0x15a37a,_0x4fd0ba,_0x4fd80e?_0xf1b3c4['getNode']():g['EMPTY_NODE'],_0x4fd80e);return Lu(_0x2ab811);}function ut(_0x1b2600,_0x57f082){return Zo(_0x57f082,_0x1b2600['syncPointTree_'],null,Ln(_0x1b2600['pendingWriteTree_'],w()));}function Zo(_0x5cdd67,_0x267ab4,_0x2fb4b7,_0x57663a){if(v(_0x5cdd67['path']))return ea(_0x5cdd67,_0x267ab4,_0x2fb4b7,_0x57663a);{const _0x48f869=_0x267ab4['get'](w());_0x2fb4b7==null&&_0x48f869!=null&&(_0x2fb4b7=Ee(_0x48f869,w()));let _0x4658bb=[];const _0x2d39bd=y(_0x5cdd67['path']),_0x3ecde9=_0x5cdd67['operationForChild'](_0x2d39bd),_0x4c1c69=_0x267ab4['children']['get'](_0x2d39bd);if(_0x4c1c69&&_0x3ecde9){const _0x43f467=_0x2fb4b7?_0x2fb4b7['getImmediateChild'](_0x2d39bd):null,_0x340c2f=Ho(_0x57663a,_0x2d39bd);_0x4658bb=_0x4658bb['concat'](Zo(_0x3ecde9,_0x4c1c69,_0x43f467,_0x340c2f));}return _0x48f869&&(_0x4658bb=_0x4658bb['concat'](rs(_0x48f869,_0x5cdd67,_0x57663a,_0x2fb4b7))),_0x4658bb;}}function ea(_0x2d48b7,_0x52a920,_0x249a80,_0x5a90a7){const _0x18b67a=_0x52a920['get'](w());_0x249a80==null&&_0x18b67a!=null&&(_0x249a80=Ee(_0x18b67a,w()));let _0x2ddb62=[];return _0x52a920['children']['inorderTraversal']((_0x2d3831,_0x2da8a9)=>{const _0x3cd809=_0x249a80?_0x249a80['getImmediateChild'](_0x2d3831):null,_0x15224d=Ho(_0x5a90a7,_0x2d3831),_0x1bb29f=_0x2d48b7['operationForChild'](_0x2d3831);_0x1bb29f&&(_0x2ddb62=_0x2ddb62['concat'](ea(_0x1bb29f,_0x2da8a9,_0x3cd809,_0x15224d)));}),_0x18b67a&&(_0x2ddb62=_0x2ddb62['concat'](rs(_0x18b67a,_0x2d48b7,_0x5a90a7,_0x249a80))),_0x2ddb62;}function ta(_0x6d3028,_0x4044e4){const _0x3a96d0=_0x4044e4['query'],_0x407c08=xt(_0x6d3028,_0x3a96d0);return{'hashFn':()=>(Mu(_0x4044e4)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x18ea02=>{if(_0x18ea02==='ok')return _0x407c08?Qu(_0x6d3028,_0x3a96d0['_path'],_0x407c08):Yu(_0x6d3028,_0x3a96d0['_path']);{const _0xe418c6=Kl(_0x18ea02,_0x3a96d0);return Cn(_0x6d3028,_0x3a96d0,null,_0xe418c6);}}};}function xt(_0x2b1264,_0x53fd15){const _0x2c5864=Un(_0x53fd15);return _0x2b1264['queryToTagMap']['get'](_0x2c5864);}function Un(_0xe04891){return _0xe04891['_path']['toString']()+'$'+_0xe04891['_queryIdentifier'];}function as(_0x4a9658,_0x3ac982){return _0x4a9658['tagToQueryMap']['get'](_0x3ac982);}function cs(_0x1adb80){const _0x29301f=_0x1adb80['indexOf']('$');return f(_0x29301f!==-0x1&&_0x29301f<_0x1adb80['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x1adb80['substr'](_0x29301f+0x1),'path':new C(_0x1adb80['substr'](0x0,_0x29301f))};}function ls(_0x5f10e6,_0x4388ed,_0x1dc35d){const _0x38c37d=_0x5f10e6['syncPointTree_']['get'](_0x4388ed);f(_0x38c37d,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x29254d=Ln(_0x5f10e6['pendingWriteTree_'],_0x4388ed);return rs(_0x38c37d,_0x1dc35d,_0x29254d,null);}function Zu(_0x85a90a){return _0x85a90a['fold']((_0x3782d4,_0x1542ab,_0x4312b5)=>{if(_0x1542ab&&Te(_0x1542ab))return[xn(_0x1542ab)];{let _0xf0b330=[];return _0x1542ab&&(_0xf0b330=Yo(_0x1542ab)),x(_0x4312b5,(_0x550922,_0x213c80)=>{_0xf0b330=_0xf0b330['concat'](_0x213c80);}),_0xf0b330;}});}function bt(_0x55b9fe){return _0x55b9fe['_queryParams']['loadsAllData']()&&!_0x55b9fe['_queryParams']['isDefault']()?new(qu())(_0x55b9fe['_repo'],_0x55b9fe['_path']):_0x55b9fe;}function ed(_0x2295b4,_0x2e292a){for(let _0x299563=0x0;_0x299563<_0x2e292a['length'];++_0x299563){const _0x12dddd=_0x2e292a[_0x299563];if(!_0x12dddd['_queryParams']['loadsAllData']()){const _0x3ddb2d=Un(_0x12dddd),_0x2d4d47=_0x2295b4['queryToTagMap']['get'](_0x3ddb2d);_0x2295b4['queryToTagMap']['delete'](_0x3ddb2d),_0x2295b4['tagToQueryMap']['delete'](_0x2d4d47);}}}function td(){return zu++;}function nd(_0x3b9f7e,_0x547c10,_0x2e807a){const _0x3cd247=_0x547c10['_path'],_0x3b06e8=xt(_0x3b9f7e,_0x547c10),_0x4693b5=ta(_0x3b9f7e,_0x2e807a),_0x1ebdfe=_0x3b9f7e['listenProvider_']['startListening'](bt(_0x547c10),_0x3b06e8,_0x4693b5['hashFn'],_0x4693b5['onComplete']),_0x508d8b=_0x3b9f7e['syncPointTree_']['subtree'](_0x3cd247);if(_0x3b06e8)f(!Te(_0x508d8b['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x382c86=_0x508d8b['fold']((_0xdc60a2,_0x1db359,_0x271339)=>{if(!v(_0xdc60a2)&&_0x1db359&&Te(_0x1db359))return[xn(_0x1db359)['query']];{let _0x115062=[];return _0x1db359&&(_0x115062=_0x115062['concat'](Yo(_0x1db359)['map'](_0x4df410=>_0x4df410['query']))),x(_0x271339,(_0x2ec4b5,_0x215bb9)=>{_0x115062=_0x115062['concat'](_0x215bb9);}),_0x115062;}});for(let _0x2193c5=0x0;_0x2193c5<_0x382c86['length'];++_0x2193c5){const _0x4da86e=_0x382c86[_0x2193c5];_0x3b9f7e['listenProvider_']['stopListening'](bt(_0x4da86e),xt(_0x3b9f7e,_0x4da86e));}}return _0x1ebdfe;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0xdafb28){this['node_']=_0xdafb28;}['getImmediateChild'](_0x187205){const _0x14cbe1=this['node_']['getImmediateChild'](_0x187205);return new hs(_0x14cbe1);}['node'](){return this['node_'];}}class us{constructor(_0x252679,_0x35da7a){this['syncTree_']=_0x252679,this['path_']=_0x35da7a;}['getImmediateChild'](_0x3d0c90){const _0x22e95d=k(this['path_'],_0x3d0c90);return new us(this['syncTree_'],_0x22e95d);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0xcebac5){return _0xcebac5=_0xcebac5||{},_0xcebac5['timestamp']=_0xcebac5['timestamp']||new Date()['getTime'](),_0xcebac5;},gr=function(_0x4d01e0,_0x3bb571,_0x2487f8){if(!_0x4d01e0||typeof _0x4d01e0!='object')return _0x4d01e0;if(f('.sv'in _0x4d01e0,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x4d01e0['.sv']=='string')return sd(_0x4d01e0['.sv'],_0x3bb571,_0x2487f8);if(typeof _0x4d01e0['.sv']=='object')return rd(_0x4d01e0['.sv'],_0x3bb571);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4d01e0,null,0x2));},sd=function(_0x523b99,_0x1e6cee,_0x3cecc2){switch(_0x523b99){case'timestamp':return _0x3cecc2['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x523b99);}},rd=function(_0x48b04a,_0x206e83,_0x4ae370){_0x48b04a['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x48b04a,null,0x2));const _0xb7d2ac=_0x48b04a['increment'];typeof _0xb7d2ac!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0xb7d2ac);const _0x54f47b=_0x206e83['node']();if(f(_0x54f47b!==null&&typeof _0x54f47b<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x54f47b['isLeafNode']())return _0xb7d2ac;const _0x14b708=_0x54f47b['getValue']();return typeof _0x14b708!='number'?_0xb7d2ac:_0x14b708+_0xb7d2ac;},na=function(_0x28062f,_0x137a84,_0x3dd4d8,_0x212edd){return fs(_0x137a84,new us(_0x3dd4d8,_0x28062f),_0x212edd);},ds=function(_0x1e827e,_0x6f9a37,_0x608ec6){return fs(_0x1e827e,new hs(_0x6f9a37),_0x608ec6);};function fs(_0xf7e002,_0x2759fd,_0x546359){const _0x25b22a=_0xf7e002['getPriority']()['val'](),_0x2db4b5=gr(_0x25b22a,_0x2759fd['getImmediateChild']('.priority'),_0x546359);let _0x22f2c0;if(_0xf7e002['isLeafNode']()){const _0x305fdb=_0xf7e002,_0x459d13=gr(_0x305fdb['getValue'](),_0x2759fd,_0x546359);return _0x459d13!==_0x305fdb['getValue']()||_0x2db4b5!==_0x305fdb['getPriority']()['val']()?new D(_0x459d13,P(_0x2db4b5)):_0xf7e002;}else{const _0x1e760c=_0xf7e002;return _0x22f2c0=_0x1e760c,_0x2db4b5!==_0x1e760c['getPriority']()['val']()&&(_0x22f2c0=_0x22f2c0['updatePriority'](new D(_0x2db4b5))),_0x1e760c['forEachChild'](R,(_0x382167,_0x3c5d1f)=>{const _0x157215=fs(_0x3c5d1f,_0x2759fd['getImmediateChild'](_0x382167),_0x546359);_0x157215!==_0x3c5d1f&&(_0x22f2c0=_0x22f2c0['updateImmediateChild'](_0x382167,_0x157215));}),_0x22f2c0;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x558036='',_0x40a9e4=null,_0xfb26be={'children':{},'childCount':0x0}){this['name']=_0x558036,this['parent']=_0x40a9e4,this['node']=_0xfb26be;}}function Wn(_0x41d4cc,_0x17ad06){let _0x1246bf=_0x17ad06 instanceof C?_0x17ad06:new C(_0x17ad06),_0x541cb8=_0x41d4cc,_0x5d51f0=y(_0x1246bf);for(;_0x5d51f0!==null;){const _0xf2dc11=De(_0x541cb8['node']['children'],_0x5d51f0)||{'children':{},'childCount':0x0};_0x541cb8=new ps(_0x5d51f0,_0x541cb8,_0xf2dc11),_0x1246bf=b(_0x1246bf),_0x5d51f0=y(_0x1246bf);}return _0x541cb8;}function Ge(_0x57b2d2){return _0x57b2d2['node']['value'];}function _s(_0x23020a,_0x303dad){_0x23020a['node']['value']=_0x303dad,Ai(_0x23020a);}function ia(_0x5d1aaf){return _0x5d1aaf['node']['childCount']>0x0;}function od(_0x4ffb03){return Ge(_0x4ffb03)===void 0x0&&!ia(_0x4ffb03);}function Bn(_0x3c5beb,_0x3b7c08){x(_0x3c5beb['node']['children'],(_0x2af523,_0x3045ef)=>{_0x3b7c08(new ps(_0x2af523,_0x3c5beb,_0x3045ef));});}function sa(_0x442b42,_0x314844,_0x1ebc03,_0x179af7){_0x1ebc03&&_0x314844(_0x442b42),Bn(_0x442b42,_0x2bdb8b=>{sa(_0x2bdb8b,_0x314844,!0x0);});}function ad(_0x50840f,_0x1835f5,_0x5b6f8f){let _0x3c155c=_0x50840f['parent'];for(;_0x3c155c!==null;){if(_0x1835f5(_0x3c155c))return!0x0;_0x3c155c=_0x3c155c['parent'];}return!0x1;}function qt(_0x5300a1){return new C(_0x5300a1['parent']===null?_0x5300a1['name']:qt(_0x5300a1['parent'])+'/'+_0x5300a1['name']);}function Ai(_0x39698a){_0x39698a['parent']!==null&&cd(_0x39698a['parent'],_0x39698a['name'],_0x39698a);}function cd(_0x503e97,_0x1999f6,_0x5a220a){const _0x5ac8d3=od(_0x5a220a),_0x153e91=J(_0x503e97['node']['children'],_0x1999f6);_0x5ac8d3&&_0x153e91?(delete _0x503e97['node']['children'][_0x1999f6],_0x503e97['node']['childCount']--,Ai(_0x503e97)):!_0x5ac8d3&&!_0x153e91&&(_0x503e97['node']['children'][_0x1999f6]=_0x5a220a['node'],_0x503e97['node']['childCount']++,Ai(_0x503e97));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x325d5b){return typeof _0x325d5b=='string'&&_0x325d5b['length']!==0x0&&!ld['test'](_0x325d5b);},ra=function(_0x5c756a){return typeof _0x5c756a=='string'&&_0x5c756a['length']!==0x0&&!hd['test'](_0x5c756a);},ud=function(_0x17baa1){return _0x17baa1&&(_0x17baa1=_0x17baa1['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x17baa1);},Tn=function(_0x1e8313){return _0x1e8313===null||typeof _0x1e8313=='string'||typeof _0x1e8313=='number'&&!Vi(_0x1e8313)||_0x1e8313&&typeof _0x1e8313=='object'&&J(_0x1e8313,'.sv');},zt=function(_0x119f43,_0x30b6df,_0xb11ca,_0x561204){_0x561204&&_0x30b6df===void 0x0||jt(Pn(_0x119f43,'value'),_0x30b6df,_0xb11ca);},jt=function(_0xc4b903,_0x422afb,_0x1be4db){const _0x29a725=_0x1be4db instanceof C?new Ah(_0x1be4db,_0xc4b903):_0x1be4db;if(_0x422afb===void 0x0)throw new Error(_0xc4b903+'contains\x20undefined\x20'+Pe(_0x29a725));if(typeof _0x422afb=='function')throw new Error(_0xc4b903+'contains\x20a\x20function\x20'+Pe(_0x29a725)+'\x20with\x20contents\x20=\x20'+_0x422afb['toString']());if(Vi(_0x422afb))throw new Error(_0xc4b903+'contains\x20'+_0x422afb['toString']()+'\x20'+Pe(_0x29a725));if(typeof _0x422afb=='string'&&_0x422afb['length']>ai/0x3&&On(_0x422afb)>ai)throw new Error(_0xc4b903+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x29a725)+'\x20(\x27'+_0x422afb['substring'](0x0,0x32)+'...\x27)');if(_0x422afb&&typeof _0x422afb=='object'){let _0x4fad17=!0x1,_0x574557=!0x1;if(x(_0x422afb,(_0x2716b7,_0x28663e)=>{if(_0x2716b7==='.value')_0x4fad17=!0x0;else{if(_0x2716b7!=='.priority'&&_0x2716b7!=='.sv'&&(_0x574557=!0x0,!gs(_0x2716b7)))throw new Error(_0xc4b903+'\x20contains\x20an\x20invalid\x20key\x20('+_0x2716b7+')\x20'+Pe(_0x29a725)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x29a725,_0x2716b7),jt(_0xc4b903,_0x28663e,_0x29a725),Nh(_0x29a725);}),_0x4fad17&&_0x574557)throw new Error(_0xc4b903+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x29a725)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x20fad4,_0x227a51){let _0x395931,_0x19fd92;for(_0x395931=0x0;_0x395931<_0x227a51['length'];_0x395931++){_0x19fd92=_0x227a51[_0x395931];const _0x45ec45=Pt(_0x19fd92);for(let _0x32e312=0x0;_0x32e312<_0x45ec45['length'];_0x32e312++)if(!(_0x45ec45[_0x32e312]==='.priority'&&_0x32e312===_0x45ec45['length']-0x1)){if(!gs(_0x45ec45[_0x32e312]))throw new Error(_0x20fad4+'contains\x20an\x20invalid\x20key\x20('+_0x45ec45[_0x32e312]+')\x20in\x20path\x20'+_0x19fd92['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x227a51['sort'](Rh);let _0x53cbda=null;for(_0x395931=0x0;_0x395931<_0x227a51['length'];_0x395931++){if(_0x19fd92=_0x227a51[_0x395931],_0x53cbda!==null&&G(_0x53cbda,_0x19fd92))throw new Error(_0x20fad4+'contains\x20a\x20path\x20'+_0x53cbda['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x19fd92['toString']());_0x53cbda=_0x19fd92;}},fd=function(_0x9f2aca,_0x5b576a,_0x391001,_0x954f99){const _0x5ad183=Pn(_0x9f2aca,'values');if(!(_0x5b576a&&typeof _0x5b576a=='object')||Array['isArray'](_0x5b576a))throw new Error(_0x5ad183+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x34a9be=[];x(_0x5b576a,(_0x3dba72,_0x507347)=>{const _0x2839d9=new C(_0x3dba72);if(jt(_0x5ad183,_0x507347,k(_0x391001,_0x2839d9)),zi(_0x2839d9)==='.priority'&&!Tn(_0x507347))throw new Error(_0x5ad183+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x2839d9['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x34a9be['push'](_0x2839d9);}),dd(_0x5ad183,_0x34a9be);},ms=function(_0x26950c,_0x3441be,_0x3363c9,_0x1bae79){if(!ra(_0x3363c9))throw new Error(Pn(_0x26950c,_0x3441be)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x3363c9+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x33ecc9,_0x85cd65,_0x26c6f0,_0x946824){_0x26c6f0&&(_0x26c6f0=_0x26c6f0['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x33ecc9,_0x85cd65,_0x26c6f0);},ys=function(_0x193292,_0x4ec5d2){if(y(_0x4ec5d2)==='.info')throw new Error(_0x193292+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x200c13,_0x3c5f55){const _0xb8947d=_0x3c5f55['path']['toString']();if(typeof _0x3c5f55['repoInfo']['host']!='string'||_0x3c5f55['repoInfo']['host']['length']===0x0||!gs(_0x3c5f55['repoInfo']['namespace'])&&_0x3c5f55['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0xb8947d['length']!==0x0&&!ud(_0xb8947d))throw new Error(Pn(_0x200c13,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x504c76,_0x44b097){let _0x530808=null;for(let _0x333ef1=0x0;_0x333ef1<_0x44b097['length'];_0x333ef1++){const _0x4dcaca=_0x44b097[_0x333ef1],_0x13b696=_0x4dcaca['getPath']();_0x530808!==null&&!ji(_0x13b696,_0x530808['path'])&&(_0x504c76['eventLists_']['push'](_0x530808),_0x530808=null),_0x530808===null&&(_0x530808={'events':[],'path':_0x13b696}),_0x530808['events']['push'](_0x4dcaca);}_0x530808&&_0x504c76['eventLists_']['push'](_0x530808);}function oa(_0x563098,_0xb84696,_0x11e2e7){Vn(_0x563098,_0x11e2e7),aa(_0x563098,_0x3692bd=>ji(_0x3692bd,_0xb84696));}function H(_0x4f442c,_0xec5493,_0x3edc2f){Vn(_0x4f442c,_0x3edc2f),aa(_0x4f442c,_0x596e9d=>G(_0x596e9d,_0xec5493)||G(_0xec5493,_0x596e9d));}function aa(_0x126487,_0x1106c3){_0x126487['recursionDepth_']++;let _0x4cedfd=!0x0;for(let _0x14483f=0x0;_0x14483f<_0x126487['eventLists_']['length'];_0x14483f++){const _0x163acc=_0x126487['eventLists_'][_0x14483f];if(_0x163acc){const _0x4c3eb5=_0x163acc['path'];_0x1106c3(_0x4c3eb5)?(md(_0x126487['eventLists_'][_0x14483f]),_0x126487['eventLists_'][_0x14483f]=null):_0x4cedfd=!0x1;}}_0x4cedfd&&(_0x126487['eventLists_']=[]),_0x126487['recursionDepth_']--;}function md(_0x16bccf){for(let _0x40b79a=0x0;_0x40b79a<_0x16bccf['events']['length'];_0x40b79a++){const _0x134374=_0x16bccf['events'][_0x40b79a];if(_0x134374!==null){_0x16bccf['events'][_0x40b79a]=null;const _0x2e46a9=_0x134374['getEventRunner']();wt&&L('event:\x20'+_0x134374['toString']()),ht(_0x2e46a9);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x509ca8,_0x3544a9,_0x5df762,_0x31a653){this['repoInfo_']=_0x509ca8,this['forceRestClient_']=_0x3544a9,this['authTokenProvider_']=_0x5df762,this['appCheckProvider_']=_0x31a653,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x40c484,_0x1bf686,_0x33f2a8){if(_0x40c484['stats_']=Gi(_0x40c484['repoInfo_']),_0x40c484['forceRestClient_']||Xl())_0x40c484['server_']=new pn(_0x40c484['repoInfo_'],(_0x20ddc0,_0x23e9f4,_0x153c7a,_0xfd6448)=>{mr(_0x40c484,_0x20ddc0,_0x23e9f4,_0x153c7a,_0xfd6448);},_0x40c484['authTokenProvider_'],_0x40c484['appCheckProvider_']),setTimeout(()=>yr(_0x40c484,!0x0),0x0);else{if(typeof _0x33f2a8<'u'&&_0x33f2a8!==null){if(typeof _0x33f2a8!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x33f2a8);}catch(_0x22db2f){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x22db2f);}}_0x40c484['persistentConnection_']=new se(_0x40c484['repoInfo_'],_0x1bf686,(_0x3ce643,_0x4b1254,_0x279a08,_0x3c9410)=>{mr(_0x40c484,_0x3ce643,_0x4b1254,_0x279a08,_0x3c9410);},_0x45f8d5=>{yr(_0x40c484,_0x45f8d5);},_0x2aef0a=>{Id(_0x40c484,_0x2aef0a);},_0x40c484['authTokenProvider_'],_0x40c484['appCheckProvider_'],_0x33f2a8),_0x40c484['server_']=_0x40c484['persistentConnection_'];}_0x40c484['authTokenProvider_']['addTokenChangeListener'](_0x52dd26=>{_0x40c484['server_']['refreshAuthToken'](_0x52dd26);}),_0x40c484['appCheckProvider_']['addTokenChangeListener'](_0x1640ba=>{_0x40c484['server_']['refreshAppCheckToken'](_0x1640ba['token']);}),_0x40c484['statsReporter_']=ih(_0x40c484['repoInfo_'],()=>new iu(_0x40c484['stats_'],_0x40c484['server_'])),_0x40c484['infoData_']=new Xh(),_0x40c484['infoSyncTree_']=new _r({'startListening':(_0x1b0489,_0x25db46,_0x38354a,_0x1c3e86)=>{let _0x1a7f21=[];const _0x1eecb2=_0x40c484['infoData_']['getNode'](_0x1b0489['_path']);return _0x1eecb2['isEmpty']()||(_0x1a7f21=Gt(_0x40c484['infoSyncTree_'],_0x1b0489['_path'],_0x1eecb2),setTimeout(()=>{_0x1c3e86('ok');},0x0)),_0x1a7f21;},'stopListening':()=>{}}),vs(_0x40c484,'connected',!0x1),_0x40c484['serverSyncTree_']=new _r({'startListening':(_0x4c1ef7,_0x1f04e3,_0x4b36bc,_0x3a5606)=>(_0x40c484['server_']['listen'](_0x4c1ef7,_0x4b36bc,_0x1f04e3,(_0x425645,_0x3e9c53)=>{const _0x57d0e4=_0x3a5606(_0x425645,_0x3e9c53);H(_0x40c484['eventQueue_'],_0x4c1ef7['_path'],_0x57d0e4);}),[]),'stopListening':(_0x163ba5,_0x1897cd)=>{_0x40c484['server_']['unlisten'](_0x163ba5,_0x1897cd);}});}function la(_0x225bcd){const _0x4cf317=_0x225bcd['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x4cf317;}function Kt(_0x2151fc){return id({'timestamp':la(_0x2151fc)});}function mr(_0x2de322,_0xdeff5,_0x3816e0,_0x5a3ee0,_0x428089){_0x2de322['dataUpdateCount']++;const _0x3ccfc8=new C(_0xdeff5);_0x3816e0=_0x2de322['interceptServerDataCallback_']?_0x2de322['interceptServerDataCallback_'](_0xdeff5,_0x3816e0):_0x3816e0;let _0x4c9a74=[];if(_0x428089){if(_0x5a3ee0){const _0x291dc7=hn(_0x3816e0,_0x5af1d9=>P(_0x5af1d9));_0x4c9a74=Ju(_0x2de322['serverSyncTree_'],_0x3ccfc8,_0x291dc7,_0x428089);}else{const _0x4df47e=P(_0x3816e0);_0x4c9a74=Xo(_0x2de322['serverSyncTree_'],_0x3ccfc8,_0x4df47e,_0x428089);}}else{if(_0x5a3ee0){const _0x58232a=hn(_0x3816e0,_0x379da0=>P(_0x379da0));_0x4c9a74=Ku(_0x2de322['serverSyncTree_'],_0x3ccfc8,_0x58232a);}else{const _0x4eba64=P(_0x3816e0);_0x4c9a74=Gt(_0x2de322['serverSyncTree_'],_0x3ccfc8,_0x4eba64);}}let _0x33b2aa=_0x3ccfc8;_0x4c9a74['length']>0x0&&(_0x33b2aa=it(_0x2de322,_0x3ccfc8)),H(_0x2de322['eventQueue_'],_0x33b2aa,_0x4c9a74);}function yr(_0x3555de,_0x5c101c){vs(_0x3555de,'connected',_0x5c101c),_0x5c101c===!0x1&&Sd(_0x3555de);}function Id(_0x8a2a95,_0x6dac8a){x(_0x6dac8a,(_0x39ae5f,_0x70dd21)=>{vs(_0x8a2a95,_0x39ae5f,_0x70dd21);});}function vs(_0x2d6945,_0x2024e2,_0x2c704a){const _0x1ba61c=new C('/.info/'+_0x2024e2),_0x57636a=P(_0x2c704a);_0x2d6945['infoData_']['updateSnapshot'](_0x1ba61c,_0x57636a);const _0x4cd4b8=Gt(_0x2d6945['infoSyncTree_'],_0x1ba61c,_0x57636a);H(_0x2d6945['eventQueue_'],_0x1ba61c,_0x4cd4b8);}function Hn(_0x25d2d5){return _0x25d2d5['nextWriteId_']++;}function wd(_0x1100d6,_0x4a1fba,_0x340081){const _0xf860e2=Xu(_0x1100d6['serverSyncTree_'],_0x4a1fba);return _0xf860e2!=null?Promise['resolve'](_0xf860e2):_0x1100d6['server_']['get'](_0x4a1fba)['then'](_0x12a3ff=>{const _0x3b972b=P(_0x12a3ff)['withIndex'](_0x4a1fba['_queryParams']['getIndex']());Ri(_0x1100d6['serverSyncTree_'],_0x4a1fba,_0x340081,!0x0);let _0x49e820;if(_0x4a1fba['_queryParams']['loadsAllData']())_0x49e820=Gt(_0x1100d6['serverSyncTree_'],_0x4a1fba['_path'],_0x3b972b);else{const _0x340003=xt(_0x1100d6['serverSyncTree_'],_0x4a1fba);_0x49e820=Xo(_0x1100d6['serverSyncTree_'],_0x4a1fba['_path'],_0x3b972b,_0x340003);}return H(_0x1100d6['eventQueue_'],_0x4a1fba['_path'],_0x49e820),Cn(_0x1100d6['serverSyncTree_'],_0x4a1fba,_0x340081,null,!0x0),_0x3b972b;},_0x399b5d=>(dt(_0x1100d6,'get\x20for\x20query\x20'+O(_0x4a1fba)+'\x20failed:\x20'+_0x399b5d),Promise['reject'](new Error(_0x399b5d))));}function Cd(_0x552da8,_0x28550a,_0x1458db,_0x2ccfa8,_0x27466d){dt(_0x552da8,'set',{'path':_0x28550a['toString'](),'value':_0x1458db,'priority':_0x2ccfa8});const _0xff8b4f=Kt(_0x552da8),_0xf5d488=P(_0x1458db,_0x2ccfa8),_0x50ee87=Fn(_0x552da8['serverSyncTree_'],_0x28550a),_0x254d37=ds(_0xf5d488,_0x50ee87,_0xff8b4f),_0x4f6cdc=Hn(_0x552da8),_0x5e92cd=os(_0x552da8['serverSyncTree_'],_0x28550a,_0x254d37,_0x4f6cdc,!0x0);Vn(_0x552da8['eventQueue_'],_0x5e92cd),_0x552da8['server_']['put'](_0x28550a['toString'](),_0xf5d488['val'](!0x0),(_0x32dddc,_0xc11a99)=>{const _0x16dcfa=_0x32dddc==='ok';_0x16dcfa||U('set\x20at\x20'+_0x28550a+'\x20failed:\x20'+_0x32dddc);const _0xc6892b=pe(_0x552da8['serverSyncTree_'],_0x4f6cdc,!_0x16dcfa);H(_0x552da8['eventQueue_'],_0x28550a,_0xc6892b),ki(_0x552da8,_0x27466d,_0x32dddc,_0xc11a99);});const _0xa0c140=Is(_0x552da8,_0x28550a);it(_0x552da8,_0xa0c140),H(_0x552da8['eventQueue_'],_0xa0c140,[]);}function Td(_0x402c3a,_0x1516c2,_0x5dc878,_0x5de6d3){dt(_0x402c3a,'update',{'path':_0x1516c2['toString'](),'value':_0x5dc878});let _0x339d1d=!0x0;const _0x1b4f59=Kt(_0x402c3a),_0x553622={};if(x(_0x5dc878,(_0x1bd78e,_0x4a4918)=>{_0x339d1d=!0x1,_0x553622[_0x1bd78e]=na(k(_0x1516c2,_0x1bd78e),P(_0x4a4918),_0x402c3a['serverSyncTree_'],_0x1b4f59);}),_0x339d1d)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x402c3a,_0x5de6d3,'ok',void 0x0);else{const _0x1b7547=Hn(_0x402c3a),_0x42e7fa=ju(_0x402c3a['serverSyncTree_'],_0x1516c2,_0x553622,_0x1b7547);Vn(_0x402c3a['eventQueue_'],_0x42e7fa),_0x402c3a['server_']['merge'](_0x1516c2['toString'](),_0x5dc878,(_0x2a0118,_0x516acd)=>{const _0x40fc0c=_0x2a0118==='ok';_0x40fc0c||U('update\x20at\x20'+_0x1516c2+'\x20failed:\x20'+_0x2a0118);const _0x89ec29=pe(_0x402c3a['serverSyncTree_'],_0x1b7547,!_0x40fc0c),_0x3c62f8=_0x89ec29['length']>0x0?it(_0x402c3a,_0x1516c2):_0x1516c2;H(_0x402c3a['eventQueue_'],_0x3c62f8,_0x89ec29),ki(_0x402c3a,_0x5de6d3,_0x2a0118,_0x516acd);}),x(_0x5dc878,_0xad5a97=>{const _0x757d68=Is(_0x402c3a,k(_0x1516c2,_0xad5a97));it(_0x402c3a,_0x757d68);}),H(_0x402c3a['eventQueue_'],_0x1516c2,[]);}}function Sd(_0x43c1c9){dt(_0x43c1c9,'onDisconnectEvents');const _0x3686f0=Kt(_0x43c1c9),_0x38c3eb=_n();Ii(_0x43c1c9['onDisconnect_'],w(),(_0x21f7e5,_0x3bd814)=>{const _0x2cb4ff=na(_0x21f7e5,_0x3bd814,_0x43c1c9['serverSyncTree_'],_0x3686f0);Fo(_0x38c3eb,_0x21f7e5,_0x2cb4ff);});let _0x3a747a=[];Ii(_0x38c3eb,w(),(_0x4c4d88,_0x1052fa)=>{_0x3a747a=_0x3a747a['concat'](Gt(_0x43c1c9['serverSyncTree_'],_0x4c4d88,_0x1052fa));const _0x26596f=Is(_0x43c1c9,_0x4c4d88);it(_0x43c1c9,_0x26596f);}),_0x43c1c9['onDisconnect_']=_n(),H(_0x43c1c9['eventQueue_'],w(),_0x3a747a);}function bd(_0x269043,_0x14915d,_0x33871b){let _0xa082e7;y(_0x14915d['_path'])==='.info'?_0xa082e7=Ri(_0x269043['infoSyncTree_'],_0x14915d,_0x33871b):_0xa082e7=Ri(_0x269043['serverSyncTree_'],_0x14915d,_0x33871b),oa(_0x269043['eventQueue_'],_0x14915d['_path'],_0xa082e7);}function Rd(_0x306acb,_0x2aae72,_0x45acfb){let _0x5b0974;y(_0x2aae72['_path'])==='.info'?_0x5b0974=Cn(_0x306acb['infoSyncTree_'],_0x2aae72,_0x45acfb):_0x5b0974=Cn(_0x306acb['serverSyncTree_'],_0x2aae72,_0x45acfb),oa(_0x306acb['eventQueue_'],_0x2aae72['_path'],_0x5b0974);}function ha(_0xf7e70){_0xf7e70['persistentConnection_']&&_0xf7e70['persistentConnection_']['interrupt'](ca);}function Ad(_0x7856de){_0x7856de['persistentConnection_']&&_0x7856de['persistentConnection_']['resume'](ca);}function dt(_0x51ea89,..._0xb7181){let _0xe63538='';_0x51ea89['persistentConnection_']&&(_0xe63538=_0x51ea89['persistentConnection_']['id']+':'),L(_0xe63538,..._0xb7181);}function ki(_0x17d7b3,_0xc91893,_0x261cd1,_0x174b9a){_0xc91893&&ht(()=>{if(_0x261cd1==='ok')_0xc91893(null);else{const _0x41862b=(_0x261cd1||'error')['toUpperCase']();let _0x3b39a5=_0x41862b;_0x174b9a&&(_0x3b39a5+=':\x20'+_0x174b9a);const _0x807c5e=new Error(_0x3b39a5);_0x807c5e['code']=_0x41862b,_0xc91893(_0x807c5e);}});}function kd(_0xbc2f20,_0x5602a2,_0x30d02e,_0x2c911e,_0x63b1f5,_0xc7d9b1){dt(_0xbc2f20,'transaction\x20on\x20'+_0x5602a2);const _0x312ce7={'path':_0x5602a2,'update':_0x30d02e,'onComplete':_0x2c911e,'status':null,'order':so(),'applyLocally':_0xc7d9b1,'retryCount':0x0,'unwatcher':_0x63b1f5,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x9faa02=Es(_0xbc2f20,_0x5602a2,void 0x0);_0x312ce7['currentInputSnapshot']=_0x9faa02;const _0x448cd3=_0x312ce7['update'](_0x9faa02['val']());if(_0x448cd3===void 0x0)_0x312ce7['unwatcher'](),_0x312ce7['currentOutputSnapshotRaw']=null,_0x312ce7['currentOutputSnapshotResolved']=null,_0x312ce7['onComplete']&&_0x312ce7['onComplete'](null,!0x1,_0x312ce7['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x448cd3,_0x312ce7['path']),_0x312ce7['status']=0x0;const _0x5bcdc3=Wn(_0xbc2f20['transactionQueueTree_'],_0x5602a2),_0x4b28eb=Ge(_0x5bcdc3)||[];_0x4b28eb['push'](_0x312ce7),_s(_0x5bcdc3,_0x4b28eb);let _0x420973;typeof _0x448cd3=='object'&&_0x448cd3!==null&&J(_0x448cd3,'.priority')?(_0x420973=De(_0x448cd3,'.priority'),f(Tn(_0x420973),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x420973=(Fn(_0xbc2f20['serverSyncTree_'],_0x5602a2)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x36404b=Kt(_0xbc2f20),_0x384ad6=P(_0x448cd3,_0x420973),_0x491b17=ds(_0x384ad6,_0x9faa02,_0x36404b);_0x312ce7['currentOutputSnapshotRaw']=_0x384ad6,_0x312ce7['currentOutputSnapshotResolved']=_0x491b17,_0x312ce7['currentWriteId']=Hn(_0xbc2f20);const _0x59bb9d=os(_0xbc2f20['serverSyncTree_'],_0x5602a2,_0x491b17,_0x312ce7['currentWriteId'],_0x312ce7['applyLocally']);H(_0xbc2f20['eventQueue_'],_0x5602a2,_0x59bb9d),$n(_0xbc2f20,_0xbc2f20['transactionQueueTree_']);}}function Es(_0x549fb1,_0x5858dd,_0x5b47d2){return Fn(_0x549fb1['serverSyncTree_'],_0x5858dd,_0x5b47d2)||g['EMPTY_NODE'];}function $n(_0x55bd09,_0x2f1f72=_0x55bd09['transactionQueueTree_']){if(_0x2f1f72||Gn(_0x55bd09,_0x2f1f72),Ge(_0x2f1f72)){const _0xd53988=da(_0x55bd09,_0x2f1f72);f(_0xd53988['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0xd53988['every'](_0x28b0ce=>_0x28b0ce['status']===0x0)&&Nd(_0x55bd09,qt(_0x2f1f72),_0xd53988);}else ia(_0x2f1f72)&&Bn(_0x2f1f72,_0x3801eb=>{$n(_0x55bd09,_0x3801eb);});}function Nd(_0x35a564,_0x4922c3,_0x578048){const _0x39181b=_0x578048['map'](_0x37f382=>_0x37f382['currentWriteId']),_0x2ea38f=Es(_0x35a564,_0x4922c3,_0x39181b);let _0x4ce371=_0x2ea38f;const _0x172a3d=_0x2ea38f['hash']();for(let _0x2c1bb6=0x0;_0x2c1bb6<_0x578048['length'];_0x2c1bb6++){const _0x7d23b9=_0x578048[_0x2c1bb6];f(_0x7d23b9['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x7d23b9['status']=0x1,_0x7d23b9['retryCount']++;const _0x48818a=F(_0x4922c3,_0x7d23b9['path']);_0x4ce371=_0x4ce371['updateChild'](_0x48818a,_0x7d23b9['currentOutputSnapshotRaw']);}const _0x18dd1c=_0x4ce371['val'](!0x0),_0x2c41c5=_0x4922c3;_0x35a564['server_']['put'](_0x2c41c5['toString'](),_0x18dd1c,_0x4f835b=>{dt(_0x35a564,'transaction\x20put\x20response',{'path':_0x2c41c5['toString'](),'status':_0x4f835b});let _0x4515df=[];if(_0x4f835b==='ok'){const _0xec1a79=[];for(let _0x590537=0x0;_0x590537<_0x578048['length'];_0x590537++)_0x578048[_0x590537]['status']=0x2,_0x4515df=_0x4515df['concat'](pe(_0x35a564['serverSyncTree_'],_0x578048[_0x590537]['currentWriteId'])),_0x578048[_0x590537]['onComplete']&&_0xec1a79['push'](()=>_0x578048[_0x590537]['onComplete'](null,!0x0,_0x578048[_0x590537]['currentOutputSnapshotResolved'])),_0x578048[_0x590537]['unwatcher']();Gn(_0x35a564,Wn(_0x35a564['transactionQueueTree_'],_0x4922c3)),$n(_0x35a564,_0x35a564['transactionQueueTree_']),H(_0x35a564['eventQueue_'],_0x4922c3,_0x4515df);for(let _0x55bfaf=0x0;_0x55bfaf<_0xec1a79['length'];_0x55bfaf++)ht(_0xec1a79[_0x55bfaf]);}else{if(_0x4f835b==='datastale'){for(let _0x2136d5=0x0;_0x2136d5<_0x578048['length'];_0x2136d5++)_0x578048[_0x2136d5]['status']===0x3?_0x578048[_0x2136d5]['status']=0x4:_0x578048[_0x2136d5]['status']=0x0;}else{U('transaction\x20at\x20'+_0x2c41c5['toString']()+'\x20failed:\x20'+_0x4f835b);for(let _0x312997=0x0;_0x312997<_0x578048['length'];_0x312997++)_0x578048[_0x312997]['status']=0x4,_0x578048[_0x312997]['abortReason']=_0x4f835b;}it(_0x35a564,_0x4922c3);}},_0x172a3d);}function it(_0x21b9cc,_0x4be193){const _0x2c2929=ua(_0x21b9cc,_0x4be193),_0x5a491b=qt(_0x2c2929),_0x2c1f3c=da(_0x21b9cc,_0x2c2929);return Pd(_0x21b9cc,_0x2c1f3c,_0x5a491b),_0x5a491b;}function Pd(_0x3eae9e,_0xdd2bd5,_0x39201a){if(_0xdd2bd5['length']===0x0)return;const _0x4dc6df=[];let _0x5904f4=[];const _0x1d5450=_0xdd2bd5['filter'](_0x2a177b=>_0x2a177b['status']===0x0)['map'](_0x3bc63e=>_0x3bc63e['currentWriteId']);for(let _0x341fc6=0x0;_0x341fc6<_0xdd2bd5['length'];_0x341fc6++){const _0x54be64=_0xdd2bd5[_0x341fc6],_0x491a48=F(_0x39201a,_0x54be64['path']);let _0x2520e4=!0x1,_0x5671bf;if(f(_0x491a48!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x54be64['status']===0x4)_0x2520e4=!0x0,_0x5671bf=_0x54be64['abortReason'],_0x5904f4=_0x5904f4['concat'](pe(_0x3eae9e['serverSyncTree_'],_0x54be64['currentWriteId'],!0x0));else{if(_0x54be64['status']===0x0){if(_0x54be64['retryCount']>=yd)_0x2520e4=!0x0,_0x5671bf='maxretry',_0x5904f4=_0x5904f4['concat'](pe(_0x3eae9e['serverSyncTree_'],_0x54be64['currentWriteId'],!0x0));else{const _0x47b37b=Es(_0x3eae9e,_0x54be64['path'],_0x1d5450);_0x54be64['currentInputSnapshot']=_0x47b37b;const _0x5ba0ee=_0xdd2bd5[_0x341fc6]['update'](_0x47b37b['val']());if(_0x5ba0ee!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x5ba0ee,_0x54be64['path']);let _0x590ec3=P(_0x5ba0ee);typeof _0x5ba0ee=='object'&&_0x5ba0ee!=null&&J(_0x5ba0ee,'.priority')||(_0x590ec3=_0x590ec3['updatePriority'](_0x47b37b['getPriority']()));const _0x1c7d26=_0x54be64['currentWriteId'],_0x489041=Kt(_0x3eae9e),_0x5530a4=ds(_0x590ec3,_0x47b37b,_0x489041);_0x54be64['currentOutputSnapshotRaw']=_0x590ec3,_0x54be64['currentOutputSnapshotResolved']=_0x5530a4,_0x54be64['currentWriteId']=Hn(_0x3eae9e),_0x1d5450['splice'](_0x1d5450['indexOf'](_0x1c7d26),0x1),_0x5904f4=_0x5904f4['concat'](os(_0x3eae9e['serverSyncTree_'],_0x54be64['path'],_0x5530a4,_0x54be64['currentWriteId'],_0x54be64['applyLocally'])),_0x5904f4=_0x5904f4['concat'](pe(_0x3eae9e['serverSyncTree_'],_0x1c7d26,!0x0));}else _0x2520e4=!0x0,_0x5671bf='nodata',_0x5904f4=_0x5904f4['concat'](pe(_0x3eae9e['serverSyncTree_'],_0x54be64['currentWriteId'],!0x0));}}}H(_0x3eae9e['eventQueue_'],_0x39201a,_0x5904f4),_0x5904f4=[],_0x2520e4&&(_0xdd2bd5[_0x341fc6]['status']=0x2,function(_0x16bb9f){setTimeout(_0x16bb9f,Math['floor'](0x0));}(_0xdd2bd5[_0x341fc6]['unwatcher']),_0xdd2bd5[_0x341fc6]['onComplete']&&(_0x5671bf==='nodata'?_0x4dc6df['push'](()=>_0xdd2bd5[_0x341fc6]['onComplete'](null,!0x1,_0xdd2bd5[_0x341fc6]['currentInputSnapshot'])):_0x4dc6df['push'](()=>_0xdd2bd5[_0x341fc6]['onComplete'](new Error(_0x5671bf),!0x1,null))));}Gn(_0x3eae9e,_0x3eae9e['transactionQueueTree_']);for(let _0x8a915f=0x0;_0x8a915f<_0x4dc6df['length'];_0x8a915f++)ht(_0x4dc6df[_0x8a915f]);$n(_0x3eae9e,_0x3eae9e['transactionQueueTree_']);}function ua(_0x139287,_0x2c946b){let _0x7a4e4b,_0x1f4262=_0x139287['transactionQueueTree_'];for(_0x7a4e4b=y(_0x2c946b);_0x7a4e4b!==null&&Ge(_0x1f4262)===void 0x0;)_0x1f4262=Wn(_0x1f4262,_0x7a4e4b),_0x2c946b=b(_0x2c946b),_0x7a4e4b=y(_0x2c946b);return _0x1f4262;}function da(_0x43b562,_0x171b80){const _0x1aae12=[];return fa(_0x43b562,_0x171b80,_0x1aae12),_0x1aae12['sort']((_0x3b9156,_0x19f6d5)=>_0x3b9156['order']-_0x19f6d5['order']),_0x1aae12;}function fa(_0xf47642,_0x2341b6,_0x360682){const _0x35cd09=Ge(_0x2341b6);if(_0x35cd09){for(let _0x3105fa=0x0;_0x3105fa<_0x35cd09['length'];_0x3105fa++)_0x360682['push'](_0x35cd09[_0x3105fa]);}Bn(_0x2341b6,_0x4e075a=>{fa(_0xf47642,_0x4e075a,_0x360682);});}function Gn(_0x167ae7,_0x309d95){const _0x25058b=Ge(_0x309d95);if(_0x25058b){let _0x350246=0x0;for(let _0x3a8594=0x0;_0x3a8594<_0x25058b['length'];_0x3a8594++)_0x25058b[_0x3a8594]['status']!==0x2&&(_0x25058b[_0x350246]=_0x25058b[_0x3a8594],_0x350246++);_0x25058b['length']=_0x350246,_s(_0x309d95,_0x25058b['length']>0x0?_0x25058b:void 0x0);}Bn(_0x309d95,_0x10c675=>{Gn(_0x167ae7,_0x10c675);});}function Is(_0x2e842e,_0x235144){const _0x34cb17=qt(ua(_0x2e842e,_0x235144)),_0x488949=Wn(_0x2e842e['transactionQueueTree_'],_0x235144);return ad(_0x488949,_0x1922b2=>{ci(_0x2e842e,_0x1922b2);}),ci(_0x2e842e,_0x488949),sa(_0x488949,_0x207e58=>{ci(_0x2e842e,_0x207e58);}),_0x34cb17;}function ci(_0x38e57f,_0x4e4806){const _0x548053=Ge(_0x4e4806);if(_0x548053){const _0x2b7428=[];let _0xa8e6fb=[],_0x35e9e3=-0x1;for(let _0x3647fd=0x0;_0x3647fd<_0x548053['length'];_0x3647fd++)_0x548053[_0x3647fd]['status']===0x3||(_0x548053[_0x3647fd]['status']===0x1?(f(_0x35e9e3===_0x3647fd-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x35e9e3=_0x3647fd,_0x548053[_0x3647fd]['status']=0x3,_0x548053[_0x3647fd]['abortReason']='set'):(f(_0x548053[_0x3647fd]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x548053[_0x3647fd]['unwatcher'](),_0xa8e6fb=_0xa8e6fb['concat'](pe(_0x38e57f['serverSyncTree_'],_0x548053[_0x3647fd]['currentWriteId'],!0x0)),_0x548053[_0x3647fd]['onComplete']&&_0x2b7428['push'](_0x548053[_0x3647fd]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x35e9e3===-0x1?_s(_0x4e4806,void 0x0):_0x548053['length']=_0x35e9e3+0x1,H(_0x38e57f['eventQueue_'],qt(_0x4e4806),_0xa8e6fb);for(let _0x46ee84=0x0;_0x46ee84<_0x2b7428['length'];_0x46ee84++)ht(_0x2b7428[_0x46ee84]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x59ef81){let _0x41f55a='';const _0x15565d=_0x59ef81['split']('/');for(let _0x10d3d0=0x0;_0x10d3d0<_0x15565d['length'];_0x10d3d0++)if(_0x15565d[_0x10d3d0]['length']>0x0){let _0x37c841=_0x15565d[_0x10d3d0];try{_0x37c841=decodeURIComponent(_0x37c841['replace'](/\+/g,'\x20'));}catch{}_0x41f55a+='/'+_0x37c841;}return _0x41f55a;}function Dd(_0x111da8){const _0x5b61b1={};_0x111da8['charAt'](0x0)==='?'&&(_0x111da8=_0x111da8['substring'](0x1));for(const _0x3dc06e of _0x111da8['split']('&')){if(_0x3dc06e['length']===0x0)continue;const _0x309842=_0x3dc06e['split']('=');_0x309842['length']===0x2?_0x5b61b1[decodeURIComponent(_0x309842[0x0])]=decodeURIComponent(_0x309842[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x3dc06e+'\x27\x20in\x20query\x20\x27'+_0x111da8+'\x27');}return _0x5b61b1;}const vr=function(_0x349a23,_0x5b73fe){const _0x60fe7e=Md(_0x349a23),_0x3d8172=_0x60fe7e['namespace'];_0x60fe7e['domain']==='firebase.com'&&ae(_0x60fe7e['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x3d8172||_0x3d8172==='undefined')&&_0x60fe7e['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x60fe7e['secure']||$l();const _0xde3740=_0x60fe7e['scheme']==='ws'||_0x60fe7e['scheme']==='wss';return{'repoInfo':new yo(_0x60fe7e['host'],_0x60fe7e['secure'],_0x3d8172,_0xde3740,_0x5b73fe,'',_0x3d8172!==_0x60fe7e['subdomain']),'path':new C(_0x60fe7e['pathString'])};},Md=function(_0x3d4bda){let _0x311717='',_0x189b83='',_0x1a3b24='',_0x46c179='',_0x51c154='',_0x1434e7=!0x0,_0x2ba467='https',_0x91494d=0x1bb;if(typeof _0x3d4bda=='string'){let _0x173885=_0x3d4bda['indexOf']('//');_0x173885>=0x0&&(_0x2ba467=_0x3d4bda['substring'](0x0,_0x173885-0x1),_0x3d4bda=_0x3d4bda['substring'](_0x173885+0x2));let _0x187a29=_0x3d4bda['indexOf']('/');_0x187a29===-0x1&&(_0x187a29=_0x3d4bda['length']);let _0x163e33=_0x3d4bda['indexOf']('?');_0x163e33===-0x1&&(_0x163e33=_0x3d4bda['length']),_0x311717=_0x3d4bda['substring'](0x0,Math['min'](_0x187a29,_0x163e33)),_0x187a29<_0x163e33&&(_0x46c179=Od(_0x3d4bda['substring'](_0x187a29,_0x163e33)));const _0x7c4e07=Dd(_0x3d4bda['substring'](Math['min'](_0x3d4bda['length'],_0x163e33)));_0x173885=_0x311717['indexOf'](':'),_0x173885>=0x0?(_0x1434e7=_0x2ba467==='https'||_0x2ba467==='wss',_0x91494d=parseInt(_0x311717['substring'](_0x173885+0x1),0xa)):_0x173885=_0x311717['length'];const _0x1744a0=_0x311717['slice'](0x0,_0x173885);if(_0x1744a0['toLowerCase']()==='localhost')_0x189b83='localhost';else{if(_0x1744a0['split']('.')['length']<=0x2)_0x189b83=_0x1744a0;else{const _0x590601=_0x311717['indexOf']('.');_0x1a3b24=_0x311717['substring'](0x0,_0x590601)['toLowerCase'](),_0x189b83=_0x311717['substring'](_0x590601+0x1),_0x51c154=_0x1a3b24;}}'ns'in _0x7c4e07&&(_0x51c154=_0x7c4e07['ns']);}return{'host':_0x311717,'port':_0x91494d,'domain':_0x189b83,'subdomain':_0x1a3b24,'secure':_0x1434e7,'scheme':_0x2ba467,'pathString':_0x46c179,'namespace':_0x51c154};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0xd8327d=0x0;const _0x26298e=[];return function(_0x3a99c1){const _0x5af385=_0x3a99c1===_0xd8327d;_0xd8327d=_0x3a99c1;let _0x184f77;const _0x2cc9ee=new Array(0x8);for(_0x184f77=0x7;_0x184f77>=0x0;_0x184f77--)_0x2cc9ee[_0x184f77]=Er['charAt'](_0x3a99c1%0x40),_0x3a99c1=Math['floor'](_0x3a99c1/0x40);f(_0x3a99c1===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x254ee0=_0x2cc9ee['join']('');if(_0x5af385){for(_0x184f77=0xb;_0x184f77>=0x0&&_0x26298e[_0x184f77]===0x3f;_0x184f77--)_0x26298e[_0x184f77]=0x0;_0x26298e[_0x184f77]++;}else{for(_0x184f77=0x0;_0x184f77<0xc;_0x184f77++)_0x26298e[_0x184f77]=Math['floor'](Math['random']()*0x40);}for(_0x184f77=0x0;_0x184f77<0xc;_0x184f77++)_0x254ee0+=Er['charAt'](_0x26298e[_0x184f77]);return f(_0x254ee0['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x254ee0;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x329e24,_0x334da2,_0x37674f,_0xc1a918){this['eventType']=_0x329e24,this['eventRegistration']=_0x334da2,this['snapshot']=_0x37674f,this['prevName']=_0xc1a918;}['getPath'](){const _0x31a5be=this['snapshot']['ref'];return this['eventType']==='value'?_0x31a5be['_path']:_0x31a5be['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x4af2d3,_0x6bc99b,_0x2e5396){this['eventRegistration']=_0x4af2d3,this['error']=_0x6bc99b,this['path']=_0x2e5396;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x393f92,_0x19580e){this['snapshotCallback']=_0x393f92,this['cancelCallback']=_0x19580e;}['onValue'](_0xeabe52,_0x4ca3e9){this['snapshotCallback']['call'](null,_0xeabe52,_0x4ca3e9);}['onCancel'](_0x4832ac){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x4832ac);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x72b32b){return this['snapshotCallback']===_0x72b32b['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x72b32b['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x72b32b['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x5436be,_0x1cdddd,_0x1accf7,_0x190977){this['_repo']=_0x5436be,this['_path']=_0x1cdddd,this['_queryParams']=_0x1accf7,this['_orderByCalled']=_0x190977;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x47aa90=rr(this['_queryParams']),_0x2e22b8=Hi(_0x47aa90);return _0x2e22b8==='{}'?'default':_0x2e22b8;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x130b8a){if(_0x130b8a=N(_0x130b8a),!(_0x130b8a instanceof be))return!0x1;const _0x4a6dd6=this['_repo']===_0x130b8a['_repo'],_0x6d002d=ji(this['_path'],_0x130b8a['_path']),_0x215855=this['_queryIdentifier']===_0x130b8a['_queryIdentifier'];return _0x4a6dd6&&_0x6d002d&&_0x215855;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x432390,_0x341de7){if(_0x432390['_orderByCalled']===!0x0)throw new Error(_0x341de7+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x2d7598){let _0x55aefd=null,_0x1c4c49=null;if(_0x2d7598['hasStart']()&&(_0x55aefd=_0x2d7598['getIndexStartValue']()),_0x2d7598['hasEnd']()&&(_0x1c4c49=_0x2d7598['getIndexEndValue']()),_0x2d7598['getIndex']()===ye){const _0x56d2fa='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x13cf28='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x2d7598['hasStart']()){if(_0x2d7598['getIndexStartName']()!==Fe)throw new Error(_0x56d2fa);if(typeof _0x55aefd!='string')throw new Error(_0x13cf28);}if(_0x2d7598['hasEnd']()){if(_0x2d7598['getIndexEndName']()!==Ie)throw new Error(_0x56d2fa);if(typeof _0x1c4c49!='string')throw new Error(_0x13cf28);}}else{if(_0x2d7598['getIndex']()===R){if(_0x55aefd!=null&&!Tn(_0x55aefd)||_0x1c4c49!=null&&!Tn(_0x1c4c49))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x2d7598['getIndex']()instanceof Qi||_0x2d7598['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x55aefd!=null&&typeof _0x55aefd=='object'||_0x1c4c49!=null&&typeof _0x1c4c49=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x56c6ce){if(_0x56c6ce['hasStart']()&&_0x56c6ce['hasEnd']()&&_0x56c6ce['hasLimit']()&&!_0x56c6ce['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x861e97,_0x2deab6){super(_0x861e97,_0x2deab6,new Xi(),!0x1);}get['parent'](){const _0x5357bd=Ro(this['_path']);return _0x5357bd===null?null:new ee(this['_repo'],_0x5357bd);}get['root'](){let _0x165cf7=this;for(;_0x165cf7['parent']!==null;)_0x165cf7=_0x165cf7['parent'];return _0x165cf7;}}class st{constructor(_0x41e1d1,_0x1fabb6,_0x262e76){this['_node']=_0x41e1d1,this['ref']=_0x1fabb6,this['_index']=_0x262e76;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x5549b7){const _0x33ac5f=new C(_0x5549b7),_0x254539=Ft(this['ref'],_0x5549b7);return new st(this['_node']['getChild'](_0x33ac5f),_0x254539,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x1a114e){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x5aab68,_0x3347db)=>_0x1a114e(new st(_0x3347db,Ft(this['ref'],_0x5aab68),R)));}['hasChild'](_0x122e3d){const _0x4cef3c=new C(_0x122e3d);return!this['_node']['getChild'](_0x4cef3c)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x4d83a3,_0x25100b){return _0x4d83a3=N(_0x4d83a3),_0x4d83a3['_checkNotDeleted']('ref'),_0x25100b!==void 0x0?Ft(_0x4d83a3['_root'],_0x25100b):_0x4d83a3['_root'];}function Ft(_0x2e21dd,_0x747045){return _0x2e21dd=N(_0x2e21dd),y(_0x2e21dd['_path'])===null?pd('child','path',_0x747045):ms('child','path',_0x747045),new ee(_0x2e21dd['_repo'],k(_0x2e21dd['_path'],_0x747045));}function g_(_0x489af4,_0x4ff491){_0x489af4=N(_0x489af4),ys('push',_0x489af4['_path']),zt('push',_0x4ff491,_0x489af4['_path'],!0x0);const _0x35e0ef=la(_0x489af4['_repo']),_0x3a2c78=Ld(_0x35e0ef),_0x3b3566=Ft(_0x489af4,_0x3a2c78),_0x1536f1=Ft(_0x489af4,_0x3a2c78);let _0x3b7419;return _0x4ff491!=null?_0x3b7419=Ud(_0x1536f1,_0x4ff491)['then'](()=>_0x1536f1):_0x3b7419=Promise['resolve'](_0x1536f1),_0x3b3566['then']=_0x3b7419['then']['bind'](_0x3b7419),_0x3b3566['catch']=_0x3b7419['then']['bind'](_0x3b7419,void 0x0),_0x3b3566;}function Ud(_0x516f6b,_0x360a63){_0x516f6b=N(_0x516f6b),ys('set',_0x516f6b['_path']),zt('set',_0x360a63,_0x516f6b['_path'],!0x1);const _0x4b835f=new ot();return Cd(_0x516f6b['_repo'],_0x516f6b['_path'],_0x360a63,null,_0x4b835f['wrapCallback'](()=>{})),_0x4b835f['promise'];}function m_(_0x5d0837,_0x57f21c){fd('update',_0x57f21c,_0x5d0837['_path']);const _0x293878=new ot();return Td(_0x5d0837['_repo'],_0x5d0837['_path'],_0x57f21c,_0x293878['wrapCallback'](()=>{})),_0x293878['promise'];}function y_(_0x3c33fc){_0x3c33fc=N(_0x3c33fc);const _0x61885a=new pa(()=>{}),_0x23df0f=new zn(_0x61885a);return wd(_0x3c33fc['_repo'],_0x3c33fc,_0x23df0f)['then'](_0x33cff5=>new st(_0x33cff5,new ee(_0x3c33fc['_repo'],_0x3c33fc['_path']),_0x3c33fc['_queryParams']['getIndex']()));}class zn{constructor(_0x3b166b){this['callbackContext']=_0x3b166b;}['respondsTo'](_0x4cb69b){return _0x4cb69b==='value';}['createEvent'](_0x2c25ad,_0x2b3335){const _0x5ce23f=_0x2b3335['_queryParams']['getIndex']();return new xd('value',this,new st(_0x2c25ad['snapshotNode'],new ee(_0x2b3335['_repo'],_0x2b3335['_path']),_0x5ce23f));}['getEventRunner'](_0x380d18){return _0x380d18['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x380d18['error']):()=>this['callbackContext']['onValue'](_0x380d18['snapshot'],null);}['createCancelEvent'](_0x4c8d2c,_0xaf4c0a){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x4c8d2c,_0xaf4c0a):null;}['matches'](_0x11bcea){return _0x11bcea instanceof zn?!_0x11bcea['callbackContext']||!this['callbackContext']?!0x0:_0x11bcea['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x436d7e,_0x15d4e7,_0x28c4b4,_0x5813f9,_0x3ffcc1){const _0x3ef7e3=new pa(_0x28c4b4,void 0x0),_0x597d70=new zn(_0x3ef7e3);return bd(_0x436d7e['_repo'],_0x436d7e,_0x597d70),()=>Rd(_0x436d7e['_repo'],_0x436d7e,_0x597d70);}function Bd(_0x279bd5,_0x2531f1,_0x314bf7,_0x434172){return Wd(_0x279bd5,'value',_0x2531f1);}class ft{}class ma extends ft{constructor(_0x1034fb,_0x54f0d7){super(),this['_value']=_0x1034fb,this['_key']=_0x54f0d7,this['type']='endAt';}['_apply'](_0x54fb99){zt('endAt',this['_value'],_0x54fb99['_path'],!0x0);const _0x58a8a5=Jh(_0x54fb99['_queryParams'],this['_value'],this['_key']);if(ga(_0x58a8a5),qn(_0x58a8a5),_0x54fb99['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x54fb99['_repo'],_0x54fb99['_path'],_0x58a8a5,_0x54fb99['_orderByCalled']);}}function v_(_0x573efd,_0x2da7ab){return new ma(_0x573efd,_0x2da7ab);}class ya extends ft{constructor(_0x44c0cd,_0x5861f1){super(),this['_value']=_0x44c0cd,this['_key']=_0x5861f1,this['type']='startAt';}['_apply'](_0x58f394){zt('startAt',this['_value'],_0x58f394['_path'],!0x0);const _0x5e6741=Qh(_0x58f394['_queryParams'],this['_value'],this['_key']);if(ga(_0x5e6741),qn(_0x5e6741),_0x58f394['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x58f394['_repo'],_0x58f394['_path'],_0x5e6741,_0x58f394['_orderByCalled']);}}function E_(_0x15e898=null,_0x1741c2){return new ya(_0x15e898,_0x1741c2);}class Vd extends ft{constructor(_0x26ba45){super(),this['_limit']=_0x26ba45,this['type']='limitToFirst';}['_apply'](_0x49bdbe){if(_0x49bdbe['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x49bdbe['_repo'],_0x49bdbe['_path'],Yh(_0x49bdbe['_queryParams'],this['_limit']),_0x49bdbe['_orderByCalled']);}}function I_(_0x1f46d3){if(Math['floor'](_0x1f46d3)!==_0x1f46d3||_0x1f46d3<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x1f46d3);}class Hd extends ft{constructor(_0x4e9359){super(),this['_path']=_0x4e9359,this['type']='orderByChild';}['_apply'](_0x4fca63){_a(_0x4fca63,'orderByChild');const _0x40e0e3=new C(this['_path']);if(v(_0x40e0e3))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x475f9f=new Qi(_0x40e0e3),_0x18681b=xo(_0x4fca63['_queryParams'],_0x475f9f);return qn(_0x18681b),new be(_0x4fca63['_repo'],_0x4fca63['_path'],_0x18681b,!0x0);}}function w_(_0xd17651){if(_0xd17651==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0xd17651==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0xd17651==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0xd17651),new Hd(_0xd17651);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x5f0fa7){_a(_0x5f0fa7,'orderByKey');const _0x1246c0=xo(_0x5f0fa7['_queryParams'],ye);return qn(_0x1246c0),new be(_0x5f0fa7['_repo'],_0x5f0fa7['_path'],_0x1246c0,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x2ac495,_0x5d83c0){super(),this['_value']=_0x2ac495,this['_key']=_0x5d83c0,this['type']='equalTo';}['_apply'](_0xc7cfee){if(zt('equalTo',this['_value'],_0xc7cfee['_path'],!0x1),_0xc7cfee['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0xc7cfee['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0xc7cfee));}}function T_(_0x329363,_0x1007da){return new Gd(_0x329363,_0x1007da);}function S_(_0x4a4cbd,..._0x7dcce6){let _0x3d44eb=N(_0x4a4cbd);for(const _0x2bd874 of _0x7dcce6)_0x3d44eb=_0x2bd874['_apply'](_0x3d44eb);return _0x3d44eb;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x520cc1,_0x461617,_0x407701,_0xbbacd3){const _0x3706a6=_0x461617['lastIndexOf'](':'),_0x2caa63=_0x461617['substring'](0x0,_0x3706a6),_0x15c3fa=at(_0x2caa63);_0x520cc1['repoInfo_']=new yo(_0x461617,_0x15c3fa,_0x520cc1['repoInfo_']['namespace'],_0x520cc1['repoInfo_']['webSocketOnly'],_0x520cc1['repoInfo_']['nodeAdmin'],_0x520cc1['repoInfo_']['persistenceKey'],_0x520cc1['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x407701),_0xbbacd3&&(_0x520cc1['authTokenProvider_']=_0xbbacd3);}function Kd(_0x3fa66e,_0xf05987,_0x2961f2,_0x55e31a,_0x42d308){let _0x401f2d=_0x55e31a||_0x3fa66e['options']['databaseURL'];_0x401f2d===void 0x0&&(_0x3fa66e['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x3fa66e['options']['projectId']),_0x401f2d=_0x3fa66e['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x129327=vr(_0x401f2d,_0x42d308),_0x22b27b=_0x129327['repoInfo'],_0x328c6c;typeof process<'u'&&Vs&&(_0x328c6c=Vs[qd]),_0x328c6c?(_0x401f2d='http://'+_0x328c6c+'?ns='+_0x22b27b['namespace'],_0x129327=vr(_0x401f2d,_0x42d308),_0x22b27b=_0x129327['repoInfo']):_0x129327['repoInfo']['secure'];const _0x527b84=new eh(_0x3fa66e['name'],_0x3fa66e['options'],_0xf05987);_d('Invalid\x20Firebase\x20Database\x20URL',_0x129327),v(_0x129327['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x26c79a=Qd(_0x22b27b,_0x3fa66e,_0x527b84,new Zl(_0x3fa66e,_0x2961f2));return new Jd(_0x26c79a,_0x3fa66e);}function Yd(_0x2410c9,_0x4cb7ba){const _0x40e669=Ni[_0x4cb7ba];(!_0x40e669||_0x40e669[_0x2410c9['key']]!==_0x2410c9)&&ae('Database\x20'+_0x4cb7ba+'('+_0x2410c9['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x2410c9),delete _0x40e669[_0x2410c9['key']];}function Qd(_0x18cfa7,_0x8403b6,_0x4577c5,_0x156449){let _0x3853dc=Ni[_0x8403b6['name']];_0x3853dc||(_0x3853dc={},Ni[_0x8403b6['name']]=_0x3853dc);let _0x402b19=_0x3853dc[_0x18cfa7['toURLString']()];return _0x402b19&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x402b19=new vd(_0x18cfa7,zd,_0x4577c5,_0x156449),_0x3853dc[_0x18cfa7['toURLString']()]=_0x402b19,_0x402b19;}class Jd{constructor(_0x456675,_0x471e86){this['_repoInternal']=_0x456675,this['app']=_0x471e86,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x5a2642){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x5a2642+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x37104a=Zr(),_0x317896){const _0x221045=Bi(_0x37104a,'database')['getImmediate']({'identifier':_0x317896});if(!_0x221045['_instanceStarted']){const _0x1d428d=cc('database');_0x1d428d&&Xd(_0x221045,..._0x1d428d);}return _0x221045;}function Xd(_0x2a00e4,_0xb8f110,_0x279d69,_0x12197b={}){_0x2a00e4=N(_0x2a00e4),_0x2a00e4['_checkNotDeleted']('useEmulator');const _0x2791c7=_0xb8f110+':'+_0x279d69,_0xe12e19=_0x2a00e4['_repoInternal'];if(_0x2a00e4['_instanceStarted']){if(_0x2791c7===_0x2a00e4['_repoInternal']['repoInfo_']['host']&&Me(_0x12197b,_0xe12e19['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4efbf0;if(_0xe12e19['repoInfo_']['nodeAdmin'])_0x12197b['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4efbf0=new nn(nn['OWNER']);else{if(_0x12197b['mockUserToken']){const _0x136992=typeof _0x12197b['mockUserToken']=='string'?_0x12197b['mockUserToken']:lc(_0x12197b['mockUserToken'],_0x2a00e4['app']['options']['projectId']);_0x4efbf0=new nn(_0x136992);}}at(_0xb8f110)&&(jr(_0xb8f110),Kr('Database',!0x0)),jd(_0xe12e19,_0x2791c7,_0x12197b,_0x4efbf0);}function R_(_0x5a13b2){_0x5a13b2=N(_0x5a13b2),_0x5a13b2['_checkNotDeleted']('goOffline'),ha(_0x5a13b2['_repo']);}function A_(_0x4936e0){_0x4936e0=N(_0x4936e0),_0x4936e0['_checkNotDeleted']('goOnline'),Ad(_0x4936e0['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x6a46a8){Ul(lt),Ze(new Le('database',(_0x5a3d10,{instanceIdentifier:_0x10eef7})=>{const _0x1c6298=_0x5a3d10['getProvider']('app')['getImmediate'](),_0x1508f8=_0x5a3d10['getProvider']('auth-internal'),_0x3be003=_0x5a3d10['getProvider']('app-check-internal');return Kd(_0x1c6298,_0x1508f8,_0x3be003,_0x10eef7);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x6a46a8),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x59ee71,_0x5829f0){this['committed']=_0x59ee71,this['snapshot']=_0x5829f0;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x18ab07,_0x2eae9a,_0x1ccf07){if(_0x18ab07=N(_0x18ab07),ys('Reference.transaction',_0x18ab07['_path']),_0x18ab07['key']==='.length'||_0x18ab07['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x18ab07['key']+'\x20is\x20a\x20read-only\x20object.';const _0x445a86=!0x0,_0x5a8d6a=new ot(),_0x3aabf1=(_0x5969ca,_0x4d7dd7,_0x2ed391)=>{let _0x16772d=null;_0x5969ca?_0x5a8d6a['reject'](_0x5969ca):(_0x16772d=new st(_0x2ed391,new ee(_0x18ab07['_repo'],_0x18ab07['_path']),R),_0x5a8d6a['resolve'](new tf(_0x4d7dd7,_0x16772d)));},_0x2609e0=Bd(_0x18ab07,()=>{});return kd(_0x18ab07['_repo'],_0x18ab07['_path'],_0x2eae9a,_0x3aabf1,_0x2609e0,_0x445a86),_0x5a8d6a['promise'];}se['prototype']['simpleListen']=function(_0x594f3d,_0x18b3f1){this['sendRequest']('q',{'p':_0x594f3d},_0x18b3f1);},se['prototype']['echo']=function(_0xaf14b3,_0x43c6dd){this['sendRequest']('echo',{'d':_0xaf14b3},_0x43c6dd);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x65915b,..._0x595e03){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x65915b,..._0x595e03);}function sn(_0x44f01f,..._0x2f2e6b){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x44f01f,..._0x2f2e6b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x8aa752,..._0x420ccc){throw ws(_0x8aa752,..._0x420ccc);}function X(_0x209ad0,..._0x4d34a6){return ws(_0x209ad0,..._0x4d34a6);}function Ia(_0x49b22b,_0x2f18c5,_0x546a6e){const _0x236154={...nf(),[_0x2f18c5]:_0x546a6e};return new Bt('auth','Firebase',_0x236154)['create'](_0x2f18c5,{'appName':_0x49b22b['name']});}function re(_0x3c3fa5){return Ia(_0x3c3fa5,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x43b3bc,..._0x4aa194){if(typeof _0x43b3bc!='string'){const _0x4dd542=_0x4aa194[0x0],_0x3bd545=[..._0x4aa194['slice'](0x1)];return _0x3bd545[0x0]&&(_0x3bd545[0x0]['appName']=_0x43b3bc['name']),_0x43b3bc['_errorFactory']['create'](_0x4dd542,..._0x3bd545);}return Ea['create'](_0x43b3bc,..._0x4aa194);}function m(_0x3b805d,_0x233742,..._0xb2c994){if(!_0x3b805d)throw ws(_0x233742,..._0xb2c994);}function ne(_0x4f3c36){const _0x57d42d='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x4f3c36;throw sn(_0x57d42d),new Error(_0x57d42d);}function ce(_0x3591ba,_0x4cdfd9){_0x3591ba||ne(_0x4cdfd9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x132792;return typeof self<'u'&&((_0x132792=self['location'])==null?void 0x0:_0x132792['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x361528;return typeof self<'u'&&((_0x361528=self['location'])==null?void 0x0:_0x361528['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x1a4e36=navigator;return _0x1a4e36['languages']&&_0x1a4e36['languages'][0x0]||_0x1a4e36['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x589595,_0x40b96b){this['shortDelay']=_0x589595,this['longDelay']=_0x40b96b,ce(_0x40b96b>_0x589595,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x34feae,_0x48988d){ce(_0x34feae['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x44567b}=_0x34feae['emulator'];return _0x48988d?''+_0x44567b+(_0x48988d['startsWith']('/')?_0x48988d['slice'](0x1):_0x48988d):_0x44567b;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x5c2087,_0x16fc2e,_0x4f8112){this['fetchImpl']=_0x5c2087,_0x16fc2e&&(this['headersImpl']=_0x16fc2e),_0x4f8112&&(this['responseImpl']=_0x4f8112);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x2e6991,_0x219760){return _0x2e6991['tenantId']&&!_0x219760['tenantId']?{..._0x219760,'tenantId':_0x2e6991['tenantId']}:_0x219760;}async function Ae(_0x1b88a3,_0x459eb5,_0x48363b,_0x203285,_0x4ec194={}){return Ca(_0x1b88a3,_0x4ec194,async()=>{let _0x597e8b={},_0xf70920={};_0x203285&&(_0x459eb5==='GET'?_0xf70920=_0x203285:_0x597e8b={'body':JSON['stringify'](_0x203285)});const _0x714c7b=ct({'key':_0x1b88a3['config']['apiKey'],..._0xf70920})['slice'](0x1),_0x73a8a7=await _0x1b88a3['_getAdditionalHeaders']();_0x73a8a7['Content-Type']='application/json',_0x1b88a3['languageCode']&&(_0x73a8a7['X-Firebase-Locale']=_0x1b88a3['languageCode']);const _0x115309={'method':_0x459eb5,'headers':_0x73a8a7,..._0x597e8b};return dc()||(_0x115309['referrerPolicy']='no-referrer'),_0x1b88a3['emulatorConfig']&&at(_0x1b88a3['emulatorConfig']['host'])&&(_0x115309['credentials']='include'),wa['fetch']()(await Ta(_0x1b88a3,_0x1b88a3['config']['apiHost'],_0x48363b,_0x714c7b),_0x115309);});}async function Ca(_0x29b58f,_0x6cd427,_0x40f2d3){_0x29b58f['_canInitEmulator']=!0x1;const _0x2940a2={...cf,..._0x6cd427};try{const _0x259ba1=new df(_0x29b58f),_0x4b96e3=await Promise['race']([_0x40f2d3(),_0x259ba1['promise']]);_0x259ba1['clearNetworkTimeout']();const _0x175403=await _0x4b96e3['json']();if('needConfirmation'in _0x175403)throw tn(_0x29b58f,'account-exists-with-different-credential',_0x175403);if(_0x4b96e3['ok']&&!('errorMessage'in _0x175403))return _0x175403;{const _0x25508b=_0x4b96e3['ok']?_0x175403['errorMessage']:_0x175403['error']['message'],[_0x6d5f7a,_0x41b69e]=_0x25508b['split']('\x20:\x20');if(_0x6d5f7a==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x29b58f,'credential-already-in-use',_0x175403);if(_0x6d5f7a==='EMAIL_EXISTS')throw tn(_0x29b58f,'email-already-in-use',_0x175403);if(_0x6d5f7a==='USER_DISABLED')throw tn(_0x29b58f,'user-disabled',_0x175403);const _0x140e9e=_0x2940a2[_0x6d5f7a]||_0x6d5f7a['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x41b69e)throw Ia(_0x29b58f,_0x140e9e,_0x41b69e);Q(_0x29b58f,_0x140e9e);}}catch(_0x5d5d8a){if(_0x5d5d8a instanceof Se)throw _0x5d5d8a;Q(_0x29b58f,'network-request-failed',{'message':String(_0x5d5d8a)});}}async function Qt(_0x37c4f9,_0x3a4534,_0x1d8ecc,_0x363f9d,_0x263a4a={}){const _0x49dafe=await Ae(_0x37c4f9,_0x3a4534,_0x1d8ecc,_0x363f9d,_0x263a4a);return'mfaPendingCredential'in _0x49dafe&&Q(_0x37c4f9,'multi-factor-auth-required',{'_serverResponse':_0x49dafe}),_0x49dafe;}async function Ta(_0x4aa1a4,_0x308c73,_0x555a03,_0x59828e){const _0x328770=''+_0x308c73+_0x555a03+'?'+_0x59828e,_0x4917c1=_0x4aa1a4,_0x5e67ff=_0x4917c1['config']['emulator']?Cs(_0x4aa1a4['config'],_0x328770):_0x4aa1a4['config']['apiScheme']+'://'+_0x328770;return lf['includes'](_0x555a03)&&(await _0x4917c1['_persistenceManagerAvailable'],_0x4917c1['_getPersistenceType']()==='COOKIE')?_0x4917c1['_getPersistence']()['_getFinalTarget'](_0x5e67ff)['toString']():_0x5e67ff;}function uf(_0x3b5855){switch(_0x3b5855){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x5b3546){this['auth']=_0x5b3546,this['timer']=null,this['promise']=new Promise((_0x125de4,_0x389066)=>{this['timer']=setTimeout(()=>_0x389066(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x23d67e,_0x323a03,_0x4d3c9a){const _0x45f334={'appName':_0x23d67e['name']};_0x4d3c9a['email']&&(_0x45f334['email']=_0x4d3c9a['email']),_0x4d3c9a['phoneNumber']&&(_0x45f334['phoneNumber']=_0x4d3c9a['phoneNumber']);const _0x548f85=X(_0x23d67e,_0x323a03,_0x45f334);return _0x548f85['customData']['_tokenResponse']=_0x4d3c9a,_0x548f85;}function wr(_0x37dec8){return _0x37dec8!==void 0x0&&_0x37dec8['enterprise']!==void 0x0;}class ff{constructor(_0x288e12){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x288e12['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x288e12['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x288e12['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x266dcf){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3b437a of this['recaptchaEnforcementState'])if(_0x3b437a['provider']&&_0x3b437a['provider']===_0x266dcf)return uf(_0x3b437a['enforcementState']);return null;}['isProviderEnabled'](_0x2019f9){return this['getProviderEnforcementState'](_0x2019f9)==='ENFORCE'||this['getProviderEnforcementState'](_0x2019f9)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x315e63,_0xb3a853){return Ae(_0x315e63,'GET','/v2/recaptchaConfig',Re(_0x315e63,_0xb3a853));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0xc6bfc8,_0x1324a9){return Ae(_0xc6bfc8,'POST','/v1/accounts:delete',_0x1324a9);}async function bn(_0x250cc2,_0x5e66c8){return Ae(_0x250cc2,'POST','/v1/accounts:lookup',_0x5e66c8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x1aec02){if(_0x1aec02)try{const _0x3a590e=new Date(Number(_0x1aec02));if(!isNaN(_0x3a590e['getTime']()))return _0x3a590e['toUTCString']();}catch{}}async function gf(_0x357d8e,_0x472383=!0x1){const _0x5bd920=N(_0x357d8e),_0x23a8ba=await _0x5bd920['getIdToken'](_0x472383),_0xc01a4d=Ts(_0x23a8ba);m(_0xc01a4d&&_0xc01a4d['exp']&&_0xc01a4d['auth_time']&&_0xc01a4d['iat'],_0x5bd920['auth'],'internal-error');const _0x24064f=typeof _0xc01a4d['firebase']=='object'?_0xc01a4d['firebase']:void 0x0,_0x4cdd67=_0x24064f==null?void 0x0:_0x24064f['sign_in_provider'];return{'claims':_0xc01a4d,'token':_0x23a8ba,'authTime':Rt(li(_0xc01a4d['auth_time'])),'issuedAtTime':Rt(li(_0xc01a4d['iat'])),'expirationTime':Rt(li(_0xc01a4d['exp'])),'signInProvider':_0x4cdd67||null,'signInSecondFactor':(_0x24064f==null?void 0x0:_0x24064f['sign_in_second_factor'])||null};}function li(_0x23184c){return Number(_0x23184c)*0x3e8;}function Ts(_0x5a9717){const [_0x4d115a,_0x1499f7,_0x4a943e]=_0x5a9717['split']('.');if(_0x4d115a===void 0x0||_0x1499f7===void 0x0||_0x4a943e===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x78461e=ln(_0x1499f7);return _0x78461e?JSON['parse'](_0x78461e):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x5e2f40){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x5e2f40==null?void 0x0:_0x5e2f40['toString']()),null;}}function Cr(_0x1e91b8){const _0x362a1f=Ts(_0x1e91b8);return m(_0x362a1f,'internal-error'),m(typeof _0x362a1f['exp']<'u','internal-error'),m(typeof _0x362a1f['iat']<'u','internal-error'),Number(_0x362a1f['exp'])-Number(_0x362a1f['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x2fe2b9,_0x4f95fe,_0x3a4fdc=!0x1){if(_0x3a4fdc)return _0x4f95fe;try{return await _0x4f95fe;}catch(_0x1f2b4b){throw _0x1f2b4b instanceof Se&&mf(_0x1f2b4b)&&_0x2fe2b9['auth']['currentUser']===_0x2fe2b9&&await _0x2fe2b9['auth']['signOut'](),_0x1f2b4b;}}function mf({code:_0x49d136}){return _0x49d136==='auth/user-disabled'||_0x49d136==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x430636){this['user']=_0x430636,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x2dd839){if(_0x2dd839){const _0x20f039=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x20f039;}else{this['errorBackoff']=0x7530;const _0x23713e=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x23713e);}}['schedule'](_0x257867=!0x1){if(!this['isRunning'])return;const _0x760fb8=this['getInterval'](_0x257867);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x760fb8);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x38ffad){(_0x38ffad==null?void 0x0:_0x38ffad['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x3aa861,_0x4e5022){this['createdAt']=_0x3aa861,this['lastLoginAt']=_0x4e5022,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x9fcb11){this['createdAt']=_0x9fcb11['createdAt'],this['lastLoginAt']=_0x9fcb11['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x43b02c){var _0x377ef4;const _0x2ce354=_0x43b02c['auth'],_0x2fe7d7=await _0x43b02c['getIdToken'](),_0x185309=await Ut(_0x43b02c,bn(_0x2ce354,{'idToken':_0x2fe7d7}));m(_0x185309==null?void 0x0:_0x185309['users']['length'],_0x2ce354,'internal-error');const _0x3f526f=_0x185309['users'][0x0];_0x43b02c['_notifyReloadListener'](_0x3f526f);const _0x4fb04d=(_0x377ef4=_0x3f526f['providerUserInfo'])!=null&&_0x377ef4['length']?Sa(_0x3f526f['providerUserInfo']):[],_0xe13bff=Ef(_0x43b02c['providerData'],_0x4fb04d),_0x1cf157=_0x43b02c['isAnonymous'],_0x4b229b=!(_0x43b02c['email']&&_0x3f526f['passwordHash'])&&!(_0xe13bff!=null&&_0xe13bff['length']),_0x50b709=_0x1cf157?_0x4b229b:!0x1,_0x5975b2={'uid':_0x3f526f['localId'],'displayName':_0x3f526f['displayName']||null,'photoURL':_0x3f526f['photoUrl']||null,'email':_0x3f526f['email']||null,'emailVerified':_0x3f526f['emailVerified']||!0x1,'phoneNumber':_0x3f526f['phoneNumber']||null,'tenantId':_0x3f526f['tenantId']||null,'providerData':_0xe13bff,'metadata':new Oi(_0x3f526f['createdAt'],_0x3f526f['lastLoginAt']),'isAnonymous':_0x50b709};Object['assign'](_0x43b02c,_0x5975b2);}async function vf(_0x1a3335){const _0x8a9048=N(_0x1a3335);await Rn(_0x8a9048),await _0x8a9048['auth']['_persistUserIfCurrent'](_0x8a9048),_0x8a9048['auth']['_notifyListenersIfCurrent'](_0x8a9048);}function Ef(_0x7c17b9,_0x38c919){return[..._0x7c17b9['filter'](_0x11fcf3=>!_0x38c919['some'](_0x1c61ae=>_0x1c61ae['providerId']===_0x11fcf3['providerId'])),..._0x38c919];}function Sa(_0x5de79d){return _0x5de79d['map'](({providerId:_0x3fd63e,..._0x4b6ed4})=>({'providerId':_0x3fd63e,'uid':_0x4b6ed4['rawId']||'','displayName':_0x4b6ed4['displayName']||null,'email':_0x4b6ed4['email']||null,'phoneNumber':_0x4b6ed4['phoneNumber']||null,'photoURL':_0x4b6ed4['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x57f92d,_0x4466de){const _0x519025=await Ca(_0x57f92d,{},async()=>{const _0x15e306=ct({'grant_type':'refresh_token','refresh_token':_0x4466de})['slice'](0x1),{tokenApiHost:_0x4f9991,apiKey:_0x3ec485}=_0x57f92d['config'],_0x5e5898=await Ta(_0x57f92d,_0x4f9991,'/v1/token','key='+_0x3ec485),_0x3bc21b=await _0x57f92d['_getAdditionalHeaders']();_0x3bc21b['Content-Type']='application/x-www-form-urlencoded';const _0x34eee3={'method':'POST','headers':_0x3bc21b,'body':_0x15e306};return _0x57f92d['emulatorConfig']&&at(_0x57f92d['emulatorConfig']['host'])&&(_0x34eee3['credentials']='include'),wa['fetch']()(_0x5e5898,_0x34eee3);});return{'accessToken':_0x519025['access_token'],'expiresIn':_0x519025['expires_in'],'refreshToken':_0x519025['refresh_token']};}async function wf(_0x8b4d97,_0x2f6d55){return Ae(_0x8b4d97,'POST','/v2/accounts:revokeToken',Re(_0x8b4d97,_0x2f6d55));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x2aa893){m(_0x2aa893['idToken'],'internal-error'),m(typeof _0x2aa893['idToken']<'u','internal-error'),m(typeof _0x2aa893['refreshToken']<'u','internal-error');const _0x576041='expiresIn'in _0x2aa893&&typeof _0x2aa893['expiresIn']<'u'?Number(_0x2aa893['expiresIn']):Cr(_0x2aa893['idToken']);this['updateTokensAndExpiration'](_0x2aa893['idToken'],_0x2aa893['refreshToken'],_0x576041);}['updateFromIdToken'](_0x56064d){m(_0x56064d['length']!==0x0,'internal-error');const _0x133be8=Cr(_0x56064d);this['updateTokensAndExpiration'](_0x56064d,null,_0x133be8);}async['getToken'](_0x185984,_0x4ee088=!0x1){return!_0x4ee088&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x185984,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x185984,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x464b20,_0x5f3acb){const {accessToken:_0x9ce480,refreshToken:_0x42fb63,expiresIn:_0x3038eb}=await If(_0x464b20,_0x5f3acb);this['updateTokensAndExpiration'](_0x9ce480,_0x42fb63,Number(_0x3038eb));}['updateTokensAndExpiration'](_0x4f1cce,_0x4e85de,_0x1dd86){this['refreshToken']=_0x4e85de||null,this['accessToken']=_0x4f1cce||null,this['expirationTime']=Date['now']()+_0x1dd86*0x3e8;}static['fromJSON'](_0x2fa69e,_0x337424){const {refreshToken:_0x247bd1,accessToken:_0x4a3444,expirationTime:_0x5a90c7}=_0x337424,_0x56b915=new Qe();return _0x247bd1&&(m(typeof _0x247bd1=='string','internal-error',{'appName':_0x2fa69e}),_0x56b915['refreshToken']=_0x247bd1),_0x4a3444&&(m(typeof _0x4a3444=='string','internal-error',{'appName':_0x2fa69e}),_0x56b915['accessToken']=_0x4a3444),_0x5a90c7&&(m(typeof _0x5a90c7=='number','internal-error',{'appName':_0x2fa69e}),_0x56b915['expirationTime']=_0x5a90c7),_0x56b915;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x1d7fa1){this['accessToken']=_0x1d7fa1['accessToken'],this['refreshToken']=_0x1d7fa1['refreshToken'],this['expirationTime']=_0x1d7fa1['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x48670c,_0x36e9ba){m(typeof _0x48670c=='string'||typeof _0x48670c>'u','internal-error',{'appName':_0x36e9ba});}class K{constructor({uid:_0x276d2e,auth:_0x49c532,stsTokenManager:_0x66ce92,..._0xb51eb0}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x276d2e,this['auth']=_0x49c532,this['stsTokenManager']=_0x66ce92,this['accessToken']=_0x66ce92['accessToken'],this['displayName']=_0xb51eb0['displayName']||null,this['email']=_0xb51eb0['email']||null,this['emailVerified']=_0xb51eb0['emailVerified']||!0x1,this['phoneNumber']=_0xb51eb0['phoneNumber']||null,this['photoURL']=_0xb51eb0['photoURL']||null,this['isAnonymous']=_0xb51eb0['isAnonymous']||!0x1,this['tenantId']=_0xb51eb0['tenantId']||null,this['providerData']=_0xb51eb0['providerData']?[..._0xb51eb0['providerData']]:[],this['metadata']=new Oi(_0xb51eb0['createdAt']||void 0x0,_0xb51eb0['lastLoginAt']||void 0x0);}async['getIdToken'](_0x39fdf8){const _0x539dee=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x39fdf8));return m(_0x539dee,this['auth'],'internal-error'),this['accessToken']!==_0x539dee&&(this['accessToken']=_0x539dee,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x539dee;}['getIdTokenResult'](_0x425f01){return gf(this,_0x425f01);}['reload'](){return vf(this);}['_assign'](_0x2c6ece){this!==_0x2c6ece&&(m(this['uid']===_0x2c6ece['uid'],this['auth'],'internal-error'),this['displayName']=_0x2c6ece['displayName'],this['photoURL']=_0x2c6ece['photoURL'],this['email']=_0x2c6ece['email'],this['emailVerified']=_0x2c6ece['emailVerified'],this['phoneNumber']=_0x2c6ece['phoneNumber'],this['isAnonymous']=_0x2c6ece['isAnonymous'],this['tenantId']=_0x2c6ece['tenantId'],this['providerData']=_0x2c6ece['providerData']['map'](_0x4a1b62=>({..._0x4a1b62})),this['metadata']['_copy'](_0x2c6ece['metadata']),this['stsTokenManager']['_assign'](_0x2c6ece['stsTokenManager']));}['_clone'](_0x7f670){const _0x450576=new K({...this,'auth':_0x7f670,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x450576['metadata']['_copy'](this['metadata']),_0x450576;}['_onReload'](_0x7f9ffa){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x7f9ffa,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x5ba090){this['reloadListener']?this['reloadListener'](_0x5ba090):this['reloadUserInfo']=_0x5ba090;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x2eb934,_0x2ca180=!0x1){let _0x195c68=!0x1;_0x2eb934['idToken']&&_0x2eb934['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x2eb934),_0x195c68=!0x0),_0x2ca180&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x195c68&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x26c911=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x26c911})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x403bd6=>({..._0x403bd6})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x5affe2,_0x3fcf6f){const _0x1e4478=_0x3fcf6f['displayName']??void 0x0,_0x1c50d0=_0x3fcf6f['email']??void 0x0,_0x477153=_0x3fcf6f['phoneNumber']??void 0x0,_0x163dc4=_0x3fcf6f['photoURL']??void 0x0,_0x316bf6=_0x3fcf6f['tenantId']??void 0x0,_0x5ae016=_0x3fcf6f['_redirectEventId']??void 0x0,_0x5c7ee8=_0x3fcf6f['createdAt']??void 0x0,_0x220c3b=_0x3fcf6f['lastLoginAt']??void 0x0,{uid:_0x25e69a,emailVerified:_0x774c69,isAnonymous:_0xccf730,providerData:_0x2a35e5,stsTokenManager:_0x5b7543}=_0x3fcf6f;m(_0x25e69a&&_0x5b7543,_0x5affe2,'internal-error');const _0x33a43b=Qe['fromJSON'](this['name'],_0x5b7543);m(typeof _0x25e69a=='string',_0x5affe2,'internal-error'),le(_0x1e4478,_0x5affe2['name']),le(_0x1c50d0,_0x5affe2['name']),m(typeof _0x774c69=='boolean',_0x5affe2,'internal-error'),m(typeof _0xccf730=='boolean',_0x5affe2,'internal-error'),le(_0x477153,_0x5affe2['name']),le(_0x163dc4,_0x5affe2['name']),le(_0x316bf6,_0x5affe2['name']),le(_0x5ae016,_0x5affe2['name']),le(_0x5c7ee8,_0x5affe2['name']),le(_0x220c3b,_0x5affe2['name']);const _0x2cf3ef=new K({'uid':_0x25e69a,'auth':_0x5affe2,'email':_0x1c50d0,'emailVerified':_0x774c69,'displayName':_0x1e4478,'isAnonymous':_0xccf730,'photoURL':_0x163dc4,'phoneNumber':_0x477153,'tenantId':_0x316bf6,'stsTokenManager':_0x33a43b,'createdAt':_0x5c7ee8,'lastLoginAt':_0x220c3b});return _0x2a35e5&&Array['isArray'](_0x2a35e5)&&(_0x2cf3ef['providerData']=_0x2a35e5['map'](_0xe74e57=>({..._0xe74e57}))),_0x5ae016&&(_0x2cf3ef['_redirectEventId']=_0x5ae016),_0x2cf3ef;}static async['_fromIdTokenResponse'](_0x4783fb,_0x189e8c,_0x43b9f1=!0x1){const _0xe5b4d6=new Qe();_0xe5b4d6['updateFromServerResponse'](_0x189e8c);const _0xb418d9=new K({'uid':_0x189e8c['localId'],'auth':_0x4783fb,'stsTokenManager':_0xe5b4d6,'isAnonymous':_0x43b9f1});return await Rn(_0xb418d9),_0xb418d9;}static async['_fromGetAccountInfoResponse'](_0x5a32ea,_0x5851d3,_0x417031){const _0x27761a=_0x5851d3['users'][0x0];m(_0x27761a['localId']!==void 0x0,'internal-error');const _0x4315c3=_0x27761a['providerUserInfo']!==void 0x0?Sa(_0x27761a['providerUserInfo']):[],_0x58dca0=!(_0x27761a['email']&&_0x27761a['passwordHash'])&&!(_0x4315c3!=null&&_0x4315c3['length']),_0x5e0025=new Qe();_0x5e0025['updateFromIdToken'](_0x417031);const _0xdfdac8=new K({'uid':_0x27761a['localId'],'auth':_0x5a32ea,'stsTokenManager':_0x5e0025,'isAnonymous':_0x58dca0}),_0x19f443={'uid':_0x27761a['localId'],'displayName':_0x27761a['displayName']||null,'photoURL':_0x27761a['photoUrl']||null,'email':_0x27761a['email']||null,'emailVerified':_0x27761a['emailVerified']||!0x1,'phoneNumber':_0x27761a['phoneNumber']||null,'tenantId':_0x27761a['tenantId']||null,'providerData':_0x4315c3,'metadata':new Oi(_0x27761a['createdAt'],_0x27761a['lastLoginAt']),'isAnonymous':!(_0x27761a['email']&&_0x27761a['passwordHash'])&&!(_0x4315c3!=null&&_0x4315c3['length'])};return Object['assign'](_0xdfdac8,_0x19f443),_0xdfdac8;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x1d685e){ce(_0x1d685e instanceof Function,'Expected\x20a\x20class\x20definition');let _0x3faeb4=Tr['get'](_0x1d685e);return _0x3faeb4?(ce(_0x3faeb4 instanceof _0x1d685e,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x3faeb4):(_0x3faeb4=new _0x1d685e(),Tr['set'](_0x1d685e,_0x3faeb4),_0x3faeb4);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0xcc10b3,_0x48e4d5){this['storage'][_0xcc10b3]=_0x48e4d5;}async['_get'](_0x17c8bf){const _0x5dd903=this['storage'][_0x17c8bf];return _0x5dd903===void 0x0?null:_0x5dd903;}async['_remove'](_0x32ebfd){delete this['storage'][_0x32ebfd];}['_addListener'](_0x517eb,_0x23da1e){}['_removeListener'](_0xaa2912,_0x3c5f81){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x544e38,_0x3fda6f,_0x46e16c){return'firebase:'+_0x544e38+':'+_0x3fda6f+':'+_0x46e16c;}class Je{constructor(_0x388b11,_0x330d45,_0xdafa3c){this['persistence']=_0x388b11,this['auth']=_0x330d45,this['userKey']=_0xdafa3c;const {config:_0x546ecd,name:_0x216e68}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x546ecd['apiKey'],_0x216e68),this['fullPersistenceKey']=rn('persistence',_0x546ecd['apiKey'],_0x216e68),this['boundEventHandler']=_0x330d45['_onStorageEvent']['bind'](_0x330d45),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x4b7fc8){return this['persistence']['_set'](this['fullUserKey'],_0x4b7fc8['toJSON']());}async['getCurrentUser'](){const _0x95ff14=await this['persistence']['_get'](this['fullUserKey']);if(!_0x95ff14)return null;if(typeof _0x95ff14=='string'){const _0x56440c=await bn(this['auth'],{'idToken':_0x95ff14})['catch'](()=>{});return _0x56440c?K['_fromGetAccountInfoResponse'](this['auth'],_0x56440c,_0x95ff14):null;}return K['_fromJSON'](this['auth'],_0x95ff14);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x55c63b){if(this['persistence']===_0x55c63b)return;const _0xe33e4b=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x55c63b,_0xe33e4b)return this['setCurrentUser'](_0xe33e4b);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x57463f,_0x2978b0,_0x4dd08b='authUser'){if(!_0x2978b0['length'])return new Je(ie(Sr),_0x57463f,_0x4dd08b);const _0x3ace96=(await Promise['all'](_0x2978b0['map'](async _0x5f511b=>{if(await _0x5f511b['_isAvailable']())return _0x5f511b;})))['filter'](_0x25b4a3=>_0x25b4a3);let _0x4f480a=_0x3ace96[0x0]||ie(Sr);const _0x2f5f18=rn(_0x4dd08b,_0x57463f['config']['apiKey'],_0x57463f['name']);let _0x3e6b66=null;for(const _0xcde0bd of _0x2978b0)try{const _0x29297f=await _0xcde0bd['_get'](_0x2f5f18);if(_0x29297f){let _0x5a9475;if(typeof _0x29297f=='string'){const _0x44a4ff=await bn(_0x57463f,{'idToken':_0x29297f})['catch'](()=>{});if(!_0x44a4ff)break;_0x5a9475=await K['_fromGetAccountInfoResponse'](_0x57463f,_0x44a4ff,_0x29297f);}else _0x5a9475=K['_fromJSON'](_0x57463f,_0x29297f);_0xcde0bd!==_0x4f480a&&(_0x3e6b66=_0x5a9475),_0x4f480a=_0xcde0bd;break;}}catch{}const _0x1f29af=_0x3ace96['filter'](_0x575d9f=>_0x575d9f['_shouldAllowMigration']);return!_0x4f480a['_shouldAllowMigration']||!_0x1f29af['length']?new Je(_0x4f480a,_0x57463f,_0x4dd08b):(_0x4f480a=_0x1f29af[0x0],_0x3e6b66&&await _0x4f480a['_set'](_0x2f5f18,_0x3e6b66['toJSON']()),await Promise['all'](_0x2978b0['map'](async _0x338325=>{if(_0x338325!==_0x4f480a)try{await _0x338325['_remove'](_0x2f5f18);}catch{}})),new Je(_0x4f480a,_0x57463f,_0x4dd08b));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x4eaa72){const _0x7c6917=_0x4eaa72['toLowerCase']();if(_0x7c6917['includes']('opera/')||_0x7c6917['includes']('opr/')||_0x7c6917['includes']('opios/'))return'Opera';if(Na(_0x7c6917))return'IEMobile';if(_0x7c6917['includes']('msie')||_0x7c6917['includes']('trident/'))return'IE';if(_0x7c6917['includes']('edge/'))return'Edge';if(Ra(_0x7c6917))return'Firefox';if(_0x7c6917['includes']('silk/'))return'Silk';if(Oa(_0x7c6917))return'Blackberry';if(Da(_0x7c6917))return'Webos';if(Aa(_0x7c6917))return'Safari';if((_0x7c6917['includes']('chrome/')||ka(_0x7c6917))&&!_0x7c6917['includes']('edge/'))return'Chrome';if(Pa(_0x7c6917))return'Android';{const _0x500cff=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x22820b=_0x4eaa72['match'](_0x500cff);if((_0x22820b==null?void 0x0:_0x22820b['length'])===0x2)return _0x22820b[0x1];}return'Other';}function Ra(_0x4c7e02=W()){return/firefox\//i['test'](_0x4c7e02);}function Aa(_0x267ed2=W()){const _0x5665ed=_0x267ed2['toLowerCase']();return _0x5665ed['includes']('safari/')&&!_0x5665ed['includes']('chrome/')&&!_0x5665ed['includes']('crios/')&&!_0x5665ed['includes']('android');}function ka(_0x44438a=W()){return/crios\//i['test'](_0x44438a);}function Na(_0xe8ca07=W()){return/iemobile/i['test'](_0xe8ca07);}function Pa(_0x5fd623=W()){return/android/i['test'](_0x5fd623);}function Oa(_0x21d9d0=W()){return/blackberry/i['test'](_0x21d9d0);}function Da(_0x8011b0=W()){return/webos/i['test'](_0x8011b0);}function Ss(_0x3c94bc=W()){return/iphone|ipad|ipod/i['test'](_0x3c94bc)||/macintosh/i['test'](_0x3c94bc)&&/mobile/i['test'](_0x3c94bc);}function Cf(_0x434f29=W()){var _0x8c5379;return Ss(_0x434f29)&&!!((_0x8c5379=window['navigator'])!=null&&_0x8c5379['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x14e0ff=W()){return Ss(_0x14e0ff)||Pa(_0x14e0ff)||Da(_0x14e0ff)||Oa(_0x14e0ff)||/windows phone/i['test'](_0x14e0ff)||Na(_0x14e0ff);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x57700d,_0x27b97d=[]){let _0x3b48de;switch(_0x57700d){case'Browser':_0x3b48de=br(W());break;case'Worker':_0x3b48de=br(W())+'-'+_0x57700d;break;default:_0x3b48de=_0x57700d;}const _0x4964cc=_0x27b97d['length']?_0x27b97d['join'](','):'FirebaseCore-web';return _0x3b48de+'/JsCore/'+lt+'/'+_0x4964cc;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x43134c){this['auth']=_0x43134c,this['queue']=[];}['pushCallback'](_0x2e64db,_0x56e276){const _0x3a4dba=_0x37ff7a=>new Promise((_0x1da01d,_0x5007b5)=>{try{const _0x3d77bd=_0x2e64db(_0x37ff7a);_0x1da01d(_0x3d77bd);}catch(_0x84ffb6){_0x5007b5(_0x84ffb6);}});_0x3a4dba['onAbort']=_0x56e276,this['queue']['push'](_0x3a4dba);const _0x265cb0=this['queue']['length']-0x1;return()=>{this['queue'][_0x265cb0]=()=>Promise['resolve']();};}async['runMiddleware'](_0xdcb24){if(this['auth']['currentUser']===_0xdcb24)return;const _0x381937=[];try{for(const _0x421573 of this['queue'])await _0x421573(_0xdcb24),_0x421573['onAbort']&&_0x381937['push'](_0x421573['onAbort']);}catch(_0x1aab2f){_0x381937['reverse']();for(const _0x38e4f2 of _0x381937)try{_0x38e4f2();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x1aab2f==null?void 0x0:_0x1aab2f['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x5367d2,_0x9b717b={}){return Ae(_0x5367d2,'GET','/v2/passwordPolicy',Re(_0x5367d2,_0x9b717b));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x51ea32){var _0x51de1f;const _0x11d9a5=_0x51ea32['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x11d9a5['minPasswordLength']??Rf,_0x11d9a5['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x11d9a5['maxPasswordLength']),_0x11d9a5['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x11d9a5['containsLowercaseCharacter']),_0x11d9a5['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x11d9a5['containsUppercaseCharacter']),_0x11d9a5['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x11d9a5['containsNumericCharacter']),_0x11d9a5['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x11d9a5['containsNonAlphanumericCharacter']),this['enforcementState']=_0x51ea32['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x51de1f=_0x51ea32['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x51de1f['join'](''))??'',this['forceUpgradeOnSignin']=_0x51ea32['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x51ea32['schemaVersion'];}['validatePassword'](_0x1cf1a0){const _0x3b774f={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x1cf1a0,_0x3b774f),this['validatePasswordCharacterOptions'](_0x1cf1a0,_0x3b774f),_0x3b774f['isValid']&&(_0x3b774f['isValid']=_0x3b774f['meetsMinPasswordLength']??!0x0),_0x3b774f['isValid']&&(_0x3b774f['isValid']=_0x3b774f['meetsMaxPasswordLength']??!0x0),_0x3b774f['isValid']&&(_0x3b774f['isValid']=_0x3b774f['containsLowercaseLetter']??!0x0),_0x3b774f['isValid']&&(_0x3b774f['isValid']=_0x3b774f['containsUppercaseLetter']??!0x0),_0x3b774f['isValid']&&(_0x3b774f['isValid']=_0x3b774f['containsNumericCharacter']??!0x0),_0x3b774f['isValid']&&(_0x3b774f['isValid']=_0x3b774f['containsNonAlphanumericCharacter']??!0x0),_0x3b774f;}['validatePasswordLengthOptions'](_0x11ff9f,_0x341e23){const _0x47376f=this['customStrengthOptions']['minPasswordLength'],_0x5179e9=this['customStrengthOptions']['maxPasswordLength'];_0x47376f&&(_0x341e23['meetsMinPasswordLength']=_0x11ff9f['length']>=_0x47376f),_0x5179e9&&(_0x341e23['meetsMaxPasswordLength']=_0x11ff9f['length']<=_0x5179e9);}['validatePasswordCharacterOptions'](_0x413dcb,_0x142634){this['updatePasswordCharacterOptionsStatuses'](_0x142634,!0x1,!0x1,!0x1,!0x1);let _0x491d54;for(let _0x3e3fa7=0x0;_0x3e3fa7<_0x413dcb['length'];_0x3e3fa7++)_0x491d54=_0x413dcb['charAt'](_0x3e3fa7),this['updatePasswordCharacterOptionsStatuses'](_0x142634,_0x491d54>='a'&&_0x491d54<='z',_0x491d54>='A'&&_0x491d54<='Z',_0x491d54>='0'&&_0x491d54<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x491d54));}['updatePasswordCharacterOptionsStatuses'](_0x2b0071,_0x3b146e,_0x31ad2a,_0x3da669,_0x585247){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x2b0071['containsLowercaseLetter']||(_0x2b0071['containsLowercaseLetter']=_0x3b146e)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x2b0071['containsUppercaseLetter']||(_0x2b0071['containsUppercaseLetter']=_0x31ad2a)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x2b0071['containsNumericCharacter']||(_0x2b0071['containsNumericCharacter']=_0x3da669)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x2b0071['containsNonAlphanumericCharacter']||(_0x2b0071['containsNonAlphanumericCharacter']=_0x585247));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x2acc69,_0x5236e5,_0x2fec26,_0x41e0bf){this['app']=_0x2acc69,this['heartbeatServiceProvider']=_0x5236e5,this['appCheckServiceProvider']=_0x2fec26,this['config']=_0x41e0bf,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x2acc69['name'],this['clientVersion']=_0x41e0bf['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0xe56308=>this['_resolvePersistenceManagerAvailable']=_0xe56308);}['_initializeWithPersistence'](_0x34c85f,_0x3f4474){return _0x3f4474&&(this['_popupRedirectResolver']=ie(_0x3f4474)),this['_initializationPromise']=this['queue'](async()=>{var _0x5d2053,_0xff7572,_0x102d9e;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x34c85f),(_0x5d2053=this['_resolvePersistenceManagerAvailable'])==null||_0x5d2053['call'](this),!this['_deleted'])){if((_0xff7572=this['_popupRedirectResolver'])!=null&&_0xff7572['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x3f4474),this['lastNotifiedUid']=((_0x102d9e=this['currentUser'])==null?void 0x0:_0x102d9e['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x232f26=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x232f26)){if(this['currentUser']&&_0x232f26&&this['currentUser']['uid']===_0x232f26['uid']){this['_currentUser']['_assign'](_0x232f26),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x232f26,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x5616cd){try{const _0x1092a2=await bn(this,{'idToken':_0x5616cd}),_0x35cdf8=await K['_fromGetAccountInfoResponse'](this,_0x1092a2,_0x5616cd);await this['directlySetCurrentUser'](_0x35cdf8);}catch(_0x11b2cf){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x11b2cf),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x579cd3){var _0x32aba5;if($(this['app'])){const _0x2a31f6=this['app']['settings']['authIdToken'];return _0x2a31f6?new Promise(_0x12377e=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2a31f6)['then'](_0x12377e,_0x12377e));}):this['directlySetCurrentUser'](null);}const _0xd863c4=await this['assertedPersistence']['getCurrentUser']();let _0xbda28b=_0xd863c4,_0x425548=!0x1;if(_0x579cd3&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x3075ee=(_0x32aba5=this['redirectUser'])==null?void 0x0:_0x32aba5['_redirectEventId'],_0x423c68=_0xbda28b==null?void 0x0:_0xbda28b['_redirectEventId'],_0x2dff96=await this['tryRedirectSignIn'](_0x579cd3);(!_0x3075ee||_0x3075ee===_0x423c68)&&(_0x2dff96!=null&&_0x2dff96['user'])&&(_0xbda28b=_0x2dff96['user'],_0x425548=!0x0);}if(!_0xbda28b)return this['directlySetCurrentUser'](null);if(!_0xbda28b['_redirectEventId']){if(_0x425548)try{await this['beforeStateQueue']['runMiddleware'](_0xbda28b);}catch(_0x33c723){_0xbda28b=_0xd863c4,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x33c723));}return _0xbda28b?this['reloadAndSetCurrentUserOrClear'](_0xbda28b):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0xbda28b['_redirectEventId']?this['directlySetCurrentUser'](_0xbda28b):this['reloadAndSetCurrentUserOrClear'](_0xbda28b);}async['tryRedirectSignIn'](_0x1048b4){let _0x29bd96=null;try{_0x29bd96=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x1048b4,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x29bd96;}async['reloadAndSetCurrentUserOrClear'](_0x57b137){try{await Rn(_0x57b137);}catch(_0x1598c7){if((_0x1598c7==null?void 0x0:_0x1598c7['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x57b137);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x5ee20c){if($(this['app']))return Promise['reject'](re(this));const _0x507fda=_0x5ee20c?N(_0x5ee20c):null;return _0x507fda&&m(_0x507fda['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x507fda&&_0x507fda['_clone'](this));}async['_updateCurrentUser'](_0x41f746,_0x4c91d5=!0x1){if(!this['_deleted'])return _0x41f746&&m(this['tenantId']===_0x41f746['tenantId'],this,'tenant-id-mismatch'),_0x4c91d5||await this['beforeStateQueue']['runMiddleware'](_0x41f746),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x41f746),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x351da0){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x351da0));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x3cd57a){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x10a4e1=this['_getPasswordPolicyInternal']();return _0x10a4e1['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x10a4e1['validatePassword'](_0x3cd57a);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x2709f0=await bf(this),_0xa24a08=new Af(_0x2709f0);this['tenantId']===null?this['_projectPasswordPolicy']=_0xa24a08:this['_tenantPasswordPolicies'][this['tenantId']]=_0xa24a08;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x58eb9d){this['_errorFactory']=new Bt('auth','Firebase',_0x58eb9d());}['onAuthStateChanged'](_0x682156,_0x211191,_0x3afe34){return this['registerStateListener'](this['authStateSubscription'],_0x682156,_0x211191,_0x3afe34);}['beforeAuthStateChanged'](_0x17fa01,_0x2992fb){return this['beforeStateQueue']['pushCallback'](_0x17fa01,_0x2992fb);}['onIdTokenChanged'](_0x1c4d77,_0x2a02ad,_0x3028f3){return this['registerStateListener'](this['idTokenSubscription'],_0x1c4d77,_0x2a02ad,_0x3028f3);}['authStateReady'](){return new Promise((_0x42e602,_0x46382e)=>{if(this['currentUser'])_0x42e602();else{const _0x2b3bcc=this['onAuthStateChanged'](()=>{_0x2b3bcc(),_0x42e602();},_0x46382e);}});}async['revokeAccessToken'](_0x57c3be){if(this['currentUser']){const _0x5cc6ac=await this['currentUser']['getIdToken'](),_0x19a89c={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x57c3be,'idToken':_0x5cc6ac};this['tenantId']!=null&&(_0x19a89c['tenantId']=this['tenantId']),await wf(this,_0x19a89c);}}['toJSON'](){var _0x260784;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x260784=this['_currentUser'])==null?void 0x0:_0x260784['toJSON']()};}async['_setRedirectUser'](_0x51ec89,_0x2e8527){const _0x4aaf99=await this['getOrInitRedirectPersistenceManager'](_0x2e8527);return _0x51ec89===null?_0x4aaf99['removeCurrentUser']():_0x4aaf99['setCurrentUser'](_0x51ec89);}async['getOrInitRedirectPersistenceManager'](_0xe71068){if(!this['redirectPersistenceManager']){const _0x4a1709=_0xe71068&&ie(_0xe71068)||this['_popupRedirectResolver'];m(_0x4a1709,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x4a1709['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x41ac07){var _0x3fa200,_0x36d9b3;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3fa200=this['_currentUser'])==null?void 0x0:_0x3fa200['_redirectEventId'])===_0x41ac07?this['_currentUser']:((_0x36d9b3=this['redirectUser'])==null?void 0x0:_0x36d9b3['_redirectEventId'])===_0x41ac07?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2be0d3){if(_0x2be0d3===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2be0d3));}['_notifyListenersIfCurrent'](_0x3dc0fb){_0x3dc0fb===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x2a8f33;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x562d43=((_0x2a8f33=this['currentUser'])==null?void 0x0:_0x2a8f33['uid'])??null;this['lastNotifiedUid']!==_0x562d43&&(this['lastNotifiedUid']=_0x562d43,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x302927,_0x1923a7,_0x191216,_0x409a31){if(this['_deleted'])return()=>{};const _0x42cae7=typeof _0x1923a7=='function'?_0x1923a7:_0x1923a7['next']['bind'](_0x1923a7);let _0x47f3f4=!0x1;const _0x273375=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x273375,this,'internal-error'),_0x273375['then'](()=>{_0x47f3f4||_0x42cae7(this['currentUser']);}),typeof _0x1923a7=='function'){const _0x1f6225=_0x302927['addObserver'](_0x1923a7,_0x191216,_0x409a31);return()=>{_0x47f3f4=!0x0,_0x1f6225();};}else{const _0x2121ec=_0x302927['addObserver'](_0x1923a7);return()=>{_0x47f3f4=!0x0,_0x2121ec();};}}async['directlySetCurrentUser'](_0x300ff0){this['currentUser']&&this['currentUser']!==_0x300ff0&&this['_currentUser']['_stopProactiveRefresh'](),_0x300ff0&&this['isProactiveRefreshEnabled']&&_0x300ff0['_startProactiveRefresh'](),this['currentUser']=_0x300ff0,_0x300ff0?await this['assertedPersistence']['setCurrentUser'](_0x300ff0):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x2e33d6){return this['operations']=this['operations']['then'](_0x2e33d6,_0x2e33d6),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x3e230b){!_0x3e230b||this['frameworks']['includes'](_0x3e230b)||(this['frameworks']['push'](_0x3e230b),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x2d4834;const _0x4bca7c={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x4bca7c['X-Firebase-gmpid']=this['app']['options']['appId']);const _0xdb3576=await((_0x2d4834=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x2d4834['getHeartbeatsHeader']());_0xdb3576&&(_0x4bca7c['X-Firebase-Client']=_0xdb3576);const _0x23bf7d=await this['_getAppCheckToken']();return _0x23bf7d&&(_0x4bca7c['X-Firebase-AppCheck']=_0x23bf7d),_0x4bca7c;}async['_getAppCheckToken'](){var _0x4b8869;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x50735a=await((_0x4b8869=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x4b8869['getToken']());return _0x50735a!=null&&_0x50735a['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x50735a['error']),_0x50735a==null?void 0x0:_0x50735a['token'];}}function qe(_0x57b96c){return N(_0x57b96c);}class Rr{constructor(_0x61212f){this['auth']=_0x61212f,this['observer']=null,this['addObserver']=Tc(_0x956d5=>this['observer']=_0x956d5);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x376c6e){jn=_0x376c6e;}function xa(_0x1c6f00){return jn['loadJS'](_0x1c6f00);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x5131e6){return'__'+_0x5131e6+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x57654d){_0x57654d();}['execute'](_0x131dd9,_0x371470){return Promise['resolve']('token');}['render'](_0x37f5a0,_0x1cba9e){return'';}}class Lf{['ready'](_0x3413b4){_0x3413b4();}['execute'](_0x55daae,_0x2ae6ab){return Promise['resolve']('token');}['render'](_0x528770,_0x438c48){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x428358){this['type']=xf,this['auth']=qe(_0x428358);}async['verify'](_0x4a9f03='verify',_0xff18b0=!0x1){async function _0xb02945(_0x11ae61){if(!_0xff18b0){if(_0x11ae61['tenantId']==null&&_0x11ae61['_agentRecaptchaConfig']!=null)return _0x11ae61['_agentRecaptchaConfig']['siteKey'];if(_0x11ae61['tenantId']!=null&&_0x11ae61['_tenantRecaptchaConfigs'][_0x11ae61['tenantId']]!==void 0x0)return _0x11ae61['_tenantRecaptchaConfigs'][_0x11ae61['tenantId']]['siteKey'];}return new Promise(async(_0x12ddd9,_0x227012)=>{pf(_0x11ae61,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x560571=>{if(_0x560571['recaptchaKey']===void 0x0)_0x227012(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x3a57c5=new ff(_0x560571);return _0x11ae61['tenantId']==null?_0x11ae61['_agentRecaptchaConfig']=_0x3a57c5:_0x11ae61['_tenantRecaptchaConfigs'][_0x11ae61['tenantId']]=_0x3a57c5,_0x12ddd9(_0x3a57c5['siteKey']);}})['catch'](_0x1a3668=>{_0x227012(_0x1a3668);});});}function _0x1d8df6(_0x7fe13f,_0x2673e0,_0x2c90b0){const _0x7a08da=window['grecaptcha'];wr(_0x7a08da)?_0x7a08da['enterprise']['ready'](()=>{_0x7a08da['enterprise']['execute'](_0x7fe13f,{'action':_0x4a9f03})['then'](_0x2d93dd=>{_0x2673e0(_0x2d93dd);})['catch'](()=>{_0x2673e0(Fa);});}):_0x2c90b0(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x1ba062,_0x5d610a)=>{_0xb02945(this['auth'])['then'](_0x1efc39=>{if(!_0xff18b0&&wr(window['grecaptcha']))_0x1d8df6(_0x1efc39,_0x1ba062,_0x5d610a);else{if(typeof window>'u'){_0x5d610a(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x2833c9=Pf();_0x2833c9['length']!==0x0&&(_0x2833c9+=_0x1efc39),xa(_0x2833c9)['then'](()=>{_0x1d8df6(_0x1efc39,_0x1ba062,_0x5d610a);})['catch'](_0x38f17f=>{_0x5d610a(_0x38f17f);});}})['catch'](_0x29e393=>{_0x5d610a(_0x29e393);});});}}async function Ar(_0x222ebe,_0x30915b,_0x307b1a,_0x3735a1=!0x1,_0x539674=!0x1){const _0x1d7ef3=new Ff(_0x222ebe);let _0x540bfe;if(_0x539674)_0x540bfe=Fa;else try{_0x540bfe=await _0x1d7ef3['verify'](_0x307b1a);}catch{_0x540bfe=await _0x1d7ef3['verify'](_0x307b1a,!0x0);}const _0x47bd8f={..._0x30915b};if(_0x307b1a==='mfaSmsEnrollment'||_0x307b1a==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x47bd8f){const _0x3f1360=_0x47bd8f['phoneEnrollmentInfo']['phoneNumber'],_0x9a89bb=_0x47bd8f['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x47bd8f,{'phoneEnrollmentInfo':{'phoneNumber':_0x3f1360,'recaptchaToken':_0x9a89bb,'captchaResponse':_0x540bfe,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x47bd8f){const _0x379554=_0x47bd8f['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x47bd8f,{'phoneSignInInfo':{'recaptchaToken':_0x379554,'captchaResponse':_0x540bfe,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x47bd8f;}return _0x3735a1?Object['assign'](_0x47bd8f,{'captchaResp':_0x540bfe}):Object['assign'](_0x47bd8f,{'captchaResponse':_0x540bfe}),Object['assign'](_0x47bd8f,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x47bd8f,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x47bd8f;}async function Di(_0xb5bdd3,_0x2d1a6f,_0x2f1514,_0x222a3c,_0x39f7e9){var _0x1cc269;if((_0x1cc269=_0xb5bdd3['_getRecaptchaConfig']())!=null&&_0x1cc269['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x78533c=await Ar(_0xb5bdd3,_0x2d1a6f,_0x2f1514,_0x2f1514==='getOobCode');return _0x222a3c(_0xb5bdd3,_0x78533c);}else return _0x222a3c(_0xb5bdd3,_0x2d1a6f)['catch'](async _0x47dbd6=>{if(_0x47dbd6['code']==='auth/missing-recaptcha-token'){console['log'](_0x2f1514+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x3385aa=await Ar(_0xb5bdd3,_0x2d1a6f,_0x2f1514,_0x2f1514==='getOobCode');return _0x222a3c(_0xb5bdd3,_0x3385aa);}else return Promise['reject'](_0x47dbd6);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x5bda00,_0x264ba6){const _0x7f739c=Bi(_0x5bda00,'auth');if(_0x7f739c['isInitialized']()){const _0x5bef09=_0x7f739c['getImmediate'](),_0x10160d=_0x7f739c['getOptions']();if(Me(_0x10160d,_0x264ba6??{}))return _0x5bef09;Q(_0x5bef09,'already-initialized');}return _0x7f739c['initialize']({'options':_0x264ba6});}function Wf(_0x4c61a2,_0x5ef1a7){const _0x5b8760=(_0x5ef1a7==null?void 0x0:_0x5ef1a7['persistence'])||[],_0x4df2c1=(Array['isArray'](_0x5b8760)?_0x5b8760:[_0x5b8760])['map'](ie);_0x5ef1a7!=null&&_0x5ef1a7['errorMap']&&_0x4c61a2['_updateErrorMap'](_0x5ef1a7['errorMap']),_0x4c61a2['_initializeWithPersistence'](_0x4df2c1,_0x5ef1a7==null?void 0x0:_0x5ef1a7['popupRedirectResolver']);}function Bf(_0x396469,_0x33ce98,_0x52776b){const _0x13b551=qe(_0x396469);m(/^https?:\/\//['test'](_0x33ce98),_0x13b551,'invalid-emulator-scheme');const _0x38db06=!0x1,_0x457a7d=Ua(_0x33ce98),{host:_0x342c32,port:_0x266c44}=Vf(_0x33ce98),_0x5dd25a=_0x266c44===null?'':':'+_0x266c44,_0x5cb5d6={'url':_0x457a7d+'//'+_0x342c32+_0x5dd25a+'/'},_0x2cfa60=Object['freeze']({'host':_0x342c32,'port':_0x266c44,'protocol':_0x457a7d['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x38db06})});if(!_0x13b551['_canInitEmulator']){m(_0x13b551['config']['emulator']&&_0x13b551['emulatorConfig'],_0x13b551,'emulator-config-failed'),m(Me(_0x5cb5d6,_0x13b551['config']['emulator'])&&Me(_0x2cfa60,_0x13b551['emulatorConfig']),_0x13b551,'emulator-config-failed');return;}_0x13b551['config']['emulator']=_0x5cb5d6,_0x13b551['emulatorConfig']=_0x2cfa60,_0x13b551['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x342c32)?(jr(_0x457a7d+'//'+_0x342c32+_0x5dd25a),Kr('Auth',!0x0)):Hf();}function Ua(_0x5710f3){const _0x1c6bde=_0x5710f3['indexOf'](':');return _0x1c6bde<0x0?'':_0x5710f3['substr'](0x0,_0x1c6bde+0x1);}function Vf(_0x2bacd2){const _0x4341f5=Ua(_0x2bacd2),_0x404f1d=/(\/\/)?([^?#/]+)/['exec'](_0x2bacd2['substr'](_0x4341f5['length']));if(!_0x404f1d)return{'host':'','port':null};const _0x4d1a94=_0x404f1d[0x2]['split']('@')['pop']()||'',_0x40a719=/^(\[[^\]]+\])(:|$)/['exec'](_0x4d1a94);if(_0x40a719){const _0x407f2d=_0x40a719[0x1];return{'host':_0x407f2d,'port':kr(_0x4d1a94['substr'](_0x407f2d['length']+0x1))};}else{const [_0x4ca937,_0x2c76e0]=_0x4d1a94['split'](':');return{'host':_0x4ca937,'port':kr(_0x2c76e0)};}}function kr(_0x2e3508){if(!_0x2e3508)return null;const _0x350b1e=Number(_0x2e3508);return isNaN(_0x350b1e)?null:_0x350b1e;}function Hf(){function _0x682a79(){const _0x472845=document['createElement']('p'),_0x5a30e5=_0x472845['style'];_0x472845['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x5a30e5['position']='fixed',_0x5a30e5['width']='100%',_0x5a30e5['backgroundColor']='#ffffff',_0x5a30e5['border']='.1em\x20solid\x20#000000',_0x5a30e5['color']='#b50000',_0x5a30e5['bottom']='0px',_0x5a30e5['left']='0px',_0x5a30e5['margin']='0px',_0x5a30e5['zIndex']='10000',_0x5a30e5['textAlign']='center',_0x472845['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x472845);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x682a79):_0x682a79());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x14fa67,_0x2945d1){this['providerId']=_0x14fa67,this['signInMethod']=_0x2945d1;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x149a51){return ne('not\x20implemented');}['_linkToIdToken'](_0x2fbec4,_0x3766e7){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x56ef53){return ne('not\x20implemented');}}async function $f(_0x48707b,_0x2e164f){return Ae(_0x48707b,'POST','/v1/accounts:signUp',_0x2e164f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x7234f3,_0xd19ea8){return Qt(_0x7234f3,'POST','/v1/accounts:signInWithPassword',Re(_0x7234f3,_0xd19ea8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x4f10cc,_0x5646de){return Qt(_0x4f10cc,'POST','/v1/accounts:signInWithEmailLink',Re(_0x4f10cc,_0x5646de));}async function zf(_0x16aca3,_0x4e3ec9){return Qt(_0x16aca3,'POST','/v1/accounts:signInWithEmailLink',Re(_0x16aca3,_0x4e3ec9));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x21b602,_0x4e312e,_0x612644,_0x3082ec=null){super('password',_0x612644),this['_email']=_0x21b602,this['_password']=_0x4e312e,this['_tenantId']=_0x3082ec;}static['_fromEmailAndPassword'](_0x733782,_0x3d835a){return new Wt(_0x733782,_0x3d835a,'password');}static['_fromEmailAndCode'](_0x3b9771,_0x23888e,_0x515b49=null){return new Wt(_0x3b9771,_0x23888e,'emailLink',_0x515b49);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x49ac1a){const _0x274735=typeof _0x49ac1a=='string'?JSON['parse'](_0x49ac1a):_0x49ac1a;if(_0x274735!=null&&_0x274735['email']&&(_0x274735!=null&&_0x274735['password'])){if(_0x274735['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x274735['email'],_0x274735['password']);if(_0x274735['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x274735['email'],_0x274735['password'],_0x274735['tenantId']);}return null;}async['_getIdTokenResponse'](_0x39df2b){switch(this['signInMethod']){case'password':const _0x18ce9a={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x39df2b,_0x18ce9a,'signInWithPassword',Gf);case'emailLink':return qf(_0x39df2b,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x39df2b,'internal-error');}}async['_linkToIdToken'](_0x18f504,_0x4a98a9){switch(this['signInMethod']){case'password':const _0x17ca0f={'idToken':_0x4a98a9,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x18f504,_0x17ca0f,'signUpPassword',$f);case'emailLink':return zf(_0x18f504,{'idToken':_0x4a98a9,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x18f504,'internal-error');}}['_getReauthenticationResolver'](_0x14d284){return this['_getIdTokenResponse'](_0x14d284);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x18eedd,_0x50567d){return Qt(_0x18eedd,'POST','/v1/accounts:signInWithIdp',Re(_0x18eedd,_0x50567d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x2abfab){const _0x2d2d04=new Be(_0x2abfab['providerId'],_0x2abfab['signInMethod']);return _0x2abfab['idToken']||_0x2abfab['accessToken']?(_0x2abfab['idToken']&&(_0x2d2d04['idToken']=_0x2abfab['idToken']),_0x2abfab['accessToken']&&(_0x2d2d04['accessToken']=_0x2abfab['accessToken']),_0x2abfab['nonce']&&!_0x2abfab['pendingToken']&&(_0x2d2d04['nonce']=_0x2abfab['nonce']),_0x2abfab['pendingToken']&&(_0x2d2d04['pendingToken']=_0x2abfab['pendingToken'])):_0x2abfab['oauthToken']&&_0x2abfab['oauthTokenSecret']?(_0x2d2d04['accessToken']=_0x2abfab['oauthToken'],_0x2d2d04['secret']=_0x2abfab['oauthTokenSecret']):Q('argument-error'),_0x2d2d04;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x3225da){const _0x313e34=typeof _0x3225da=='string'?JSON['parse'](_0x3225da):_0x3225da,{providerId:_0x50faeb,signInMethod:_0x10c401,..._0x256751}=_0x313e34;if(!_0x50faeb||!_0x10c401)return null;const _0x3c6870=new Be(_0x50faeb,_0x10c401);return _0x3c6870['idToken']=_0x256751['idToken']||void 0x0,_0x3c6870['accessToken']=_0x256751['accessToken']||void 0x0,_0x3c6870['secret']=_0x256751['secret'],_0x3c6870['nonce']=_0x256751['nonce'],_0x3c6870['pendingToken']=_0x256751['pendingToken']||null,_0x3c6870;}['_getIdTokenResponse'](_0xc867b2){const _0x20cee3=this['buildRequest']();return Xe(_0xc867b2,_0x20cee3);}['_linkToIdToken'](_0x4e787a,_0x4bce0a){const _0x46319a=this['buildRequest']();return _0x46319a['idToken']=_0x4bce0a,Xe(_0x4e787a,_0x46319a);}['_getReauthenticationResolver'](_0xa5a30){const _0x3730e4=this['buildRequest']();return _0x3730e4['autoCreate']=!0x1,Xe(_0xa5a30,_0x3730e4);}['buildRequest'](){const _0x5b57b3={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x5b57b3['pendingToken']=this['pendingToken'];else{const _0x258bf0={};this['idToken']&&(_0x258bf0['id_token']=this['idToken']),this['accessToken']&&(_0x258bf0['access_token']=this['accessToken']),this['secret']&&(_0x258bf0['oauth_token_secret']=this['secret']),_0x258bf0['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x258bf0['nonce']=this['nonce']),_0x5b57b3['postBody']=ct(_0x258bf0);}return _0x5b57b3;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x358ba3){switch(_0x358ba3){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x3db4fe){const _0x438c29=vt(Et(_0x3db4fe))['link'],_0x1e31a6=_0x438c29?vt(Et(_0x438c29))['deep_link_id']:null,_0x2106de=vt(Et(_0x3db4fe))['deep_link_id'];return(_0x2106de?vt(Et(_0x2106de))['link']:null)||_0x2106de||_0x1e31a6||_0x438c29||_0x3db4fe;}class Rs{constructor(_0x4f9716){const _0x386159=vt(Et(_0x4f9716)),_0x26ef66=_0x386159['apiKey']??null,_0x5a4856=_0x386159['oobCode']??null,_0x13557a=Kf(_0x386159['mode']??null);m(_0x26ef66&&_0x5a4856&&_0x13557a,'argument-error'),this['apiKey']=_0x26ef66,this['operation']=_0x13557a,this['code']=_0x5a4856,this['continueUrl']=_0x386159['continueUrl']??null,this['languageCode']=_0x386159['lang']??null,this['tenantId']=_0x386159['tenantId']??null;}static['parseLink'](_0x1057b2){const _0x1a3fce=Yf(_0x1057b2);try{return new Rs(_0x1a3fce);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x24f9b3,_0x5de7a1){return Wt['_fromEmailAndPassword'](_0x24f9b3,_0x5de7a1);}static['credentialWithLink'](_0x4c2b9e,_0xd2ab96){const _0x1c2b0f=Rs['parseLink'](_0xd2ab96);return m(_0x1c2b0f,'argument-error'),Wt['_fromEmailAndCode'](_0x4c2b9e,_0x1c2b0f['code'],_0x1c2b0f['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x232446){this['providerId']=_0x232446,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0xaaf8cc){this['defaultLanguageCode']=_0xaaf8cc;}['setCustomParameters'](_0x44d58e){return this['customParameters']=_0x44d58e,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x4ccc60){return this['scopes']['includes'](_0x4ccc60)||this['scopes']['push'](_0x4ccc60),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x11f75c){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x11f75c});}static['credentialFromResult'](_0x494c45){return he['credentialFromTaggedObject'](_0x494c45);}static['credentialFromError'](_0x440970){return he['credentialFromTaggedObject'](_0x440970['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x24ffb0}){if(!_0x24ffb0||!('oauthAccessToken'in _0x24ffb0)||!_0x24ffb0['oauthAccessToken'])return null;try{return he['credential'](_0x24ffb0['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3ce613,_0x2580b5){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3ce613,'accessToken':_0x2580b5});}static['credentialFromResult'](_0x4df1d2){return ue['credentialFromTaggedObject'](_0x4df1d2);}static['credentialFromError'](_0x315c34){return ue['credentialFromTaggedObject'](_0x315c34['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5e61f5}){if(!_0x5e61f5)return null;const {oauthIdToken:_0x257153,oauthAccessToken:_0x4ef8a3}=_0x5e61f5;if(!_0x257153&&!_0x4ef8a3)return null;try{return ue['credential'](_0x257153,_0x4ef8a3);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x44ec0e){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x44ec0e});}static['credentialFromResult'](_0x2f96bc){return de['credentialFromTaggedObject'](_0x2f96bc);}static['credentialFromError'](_0xd2ad1d){return de['credentialFromTaggedObject'](_0xd2ad1d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x23ecbd}){if(!_0x23ecbd||!('oauthAccessToken'in _0x23ecbd)||!_0x23ecbd['oauthAccessToken'])return null;try{return de['credential'](_0x23ecbd['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x19fd2b,_0x2591d7){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x19fd2b,'oauthTokenSecret':_0x2591d7});}static['credentialFromResult'](_0x57e679){return fe['credentialFromTaggedObject'](_0x57e679);}static['credentialFromError'](_0x9afb94){return fe['credentialFromTaggedObject'](_0x9afb94['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5e0572}){if(!_0x5e0572)return null;const {oauthAccessToken:_0x3b136f,oauthTokenSecret:_0x39a961}=_0x5e0572;if(!_0x3b136f||!_0x39a961)return null;try{return fe['credential'](_0x3b136f,_0x39a961);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x3ae6a7,_0x4be3eb){return Qt(_0x3ae6a7,'POST','/v1/accounts:signUp',Re(_0x3ae6a7,_0x4be3eb));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x590502){this['user']=_0x590502['user'],this['providerId']=_0x590502['providerId'],this['_tokenResponse']=_0x590502['_tokenResponse'],this['operationType']=_0x590502['operationType'];}static async['_fromIdTokenResponse'](_0x5b2552,_0x5e87d7,_0x526a0b,_0x599382=!0x1){const _0x368ccf=await K['_fromIdTokenResponse'](_0x5b2552,_0x526a0b,_0x599382),_0x5ee0ee=Nr(_0x526a0b);return new Ve({'user':_0x368ccf,'providerId':_0x5ee0ee,'_tokenResponse':_0x526a0b,'operationType':_0x5e87d7});}static async['_forOperation'](_0x40eceb,_0x181b1e,_0x1b7a04){await _0x40eceb['_updateTokensIfNecessary'](_0x1b7a04,!0x0);const _0x581b26=Nr(_0x1b7a04);return new Ve({'user':_0x40eceb,'providerId':_0x581b26,'_tokenResponse':_0x1b7a04,'operationType':_0x181b1e});}}function Nr(_0x1f9d6a){return _0x1f9d6a['providerId']?_0x1f9d6a['providerId']:'phoneNumber'in _0x1f9d6a?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x403681,_0x4402b4,_0x7096d5,_0x4fb7ef){super(_0x4402b4['code'],_0x4402b4['message']),this['operationType']=_0x7096d5,this['user']=_0x4fb7ef,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x403681['name'],'tenantId':_0x403681['tenantId']??void 0x0,'_serverResponse':_0x4402b4['customData']['_serverResponse'],'operationType':_0x7096d5};}static['_fromErrorAndOperation'](_0x570c22,_0x2719ec,_0x321191,_0x43ba32){return new An(_0x570c22,_0x2719ec,_0x321191,_0x43ba32);}}function Ba(_0x32e354,_0x11be53,_0x168f41,_0x216e85){return(_0x11be53==='reauthenticate'?_0x168f41['_getReauthenticationResolver'](_0x32e354):_0x168f41['_getIdTokenResponse'](_0x32e354))['catch'](_0x3ee564=>{throw _0x3ee564['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x32e354,_0x3ee564,_0x11be53,_0x216e85):_0x3ee564;});}async function Jf(_0x2c68b7,_0x28c9c1,_0x3dadaf=!0x1){const _0x1e83a6=await Ut(_0x2c68b7,_0x28c9c1['_linkToIdToken'](_0x2c68b7['auth'],await _0x2c68b7['getIdToken']()),_0x3dadaf);return Ve['_forOperation'](_0x2c68b7,'link',_0x1e83a6);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x310e0b,_0xc7346d,_0xd7b9f5=!0x1){const {auth:_0x1870ed}=_0x310e0b;if($(_0x1870ed['app']))return Promise['reject'](re(_0x1870ed));const _0x5d212d='reauthenticate';try{const _0x5c6bf2=await Ut(_0x310e0b,Ba(_0x1870ed,_0x5d212d,_0xc7346d,_0x310e0b),_0xd7b9f5);m(_0x5c6bf2['idToken'],_0x1870ed,'internal-error');const _0x1dbf21=Ts(_0x5c6bf2['idToken']);m(_0x1dbf21,_0x1870ed,'internal-error');const {sub:_0x5894b0}=_0x1dbf21;return m(_0x310e0b['uid']===_0x5894b0,_0x1870ed,'user-mismatch'),Ve['_forOperation'](_0x310e0b,_0x5d212d,_0x5c6bf2);}catch(_0x40a9c7){throw(_0x40a9c7==null?void 0x0:_0x40a9c7['code'])==='auth/user-not-found'&&Q(_0x1870ed,'user-mismatch'),_0x40a9c7;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x1b05e0,_0x16964c,_0x38b57b=!0x1){if($(_0x1b05e0['app']))return Promise['reject'](re(_0x1b05e0));const _0x3b62af='signIn',_0x512c33=await Ba(_0x1b05e0,_0x3b62af,_0x16964c),_0x1067fb=await Ve['_fromIdTokenResponse'](_0x1b05e0,_0x3b62af,_0x512c33);return _0x38b57b||await _0x1b05e0['_updateCurrentUser'](_0x1067fb['user']),_0x1067fb;}async function Zf(_0x2d645b,_0x3a76f4){return Va(qe(_0x2d645b),_0x3a76f4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x16e05a){const _0x417c84=qe(_0x16e05a);_0x417c84['_getPasswordPolicyInternal']()&&await _0x417c84['_updatePasswordPolicy']();}async function P_(_0x3561bd,_0x3a4950,_0x107fa6){if($(_0x3561bd['app']))return Promise['reject'](re(_0x3561bd));const _0xc2d3e2=qe(_0x3561bd),_0x621adc=await Di(_0xc2d3e2,{'returnSecureToken':!0x0,'email':_0x3a4950,'password':_0x107fa6,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x1995eb=>{throw _0x1995eb['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x3561bd),_0x1995eb;}),_0x5aaad8=await Ve['_fromIdTokenResponse'](_0xc2d3e2,'signIn',_0x621adc);return await _0xc2d3e2['_updateCurrentUser'](_0x5aaad8['user']),_0x5aaad8;}function O_(_0x301d77,_0x1b9c4c,_0x549d6a){return $(_0x301d77['app'])?Promise['reject'](re(_0x301d77)):Zf(N(_0x301d77),pt['credential'](_0x1b9c4c,_0x549d6a))['catch'](async _0x3fc009=>{throw _0x3fc009['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x301d77),_0x3fc009;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x5e5654,_0x157df8){return N(_0x5e5654)['setPersistence'](_0x157df8);}function ep(_0x4dade1,_0x439d11,_0x51459c,_0x59ad15){return N(_0x4dade1)['onIdTokenChanged'](_0x439d11,_0x51459c,_0x59ad15);}function tp(_0x206575,_0x1c245f,_0x247dd6){return N(_0x206575)['beforeAuthStateChanged'](_0x1c245f,_0x247dd6);}function M_(_0x83ff6f,_0x242d8d,_0x1aa994,_0x182c06){return N(_0x83ff6f)['onAuthStateChanged'](_0x242d8d,_0x1aa994,_0x182c06);}function L_(_0x17fe0b){return N(_0x17fe0b)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x480586,_0x983eca){this['storageRetriever']=_0x480586,this['type']=_0x983eca;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x5597f6,_0x167e5c){return this['storage']['setItem'](_0x5597f6,JSON['stringify'](_0x167e5c)),Promise['resolve']();}['_get'](_0x50d56f){const _0x1f9f77=this['storage']['getItem'](_0x50d56f);return Promise['resolve'](_0x1f9f77?JSON['parse'](_0x1f9f77):null);}['_remove'](_0x550846){return this['storage']['removeItem'](_0x550846),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x38f2f0,_0x3e206c)=>this['onStorageEvent'](_0x38f2f0,_0x3e206c),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x173d3d){for(const _0x4b1609 of Object['keys'](this['listeners'])){const _0x43b204=this['storage']['getItem'](_0x4b1609),_0x1c9ae9=this['localCache'][_0x4b1609];_0x43b204!==_0x1c9ae9&&_0x173d3d(_0x4b1609,_0x1c9ae9,_0x43b204);}}['onStorageEvent'](_0x548630,_0x5dee6b=!0x1){if(!_0x548630['key']){this['forAllChangedKeys']((_0xd62f3a,_0x46c93d,_0x45bc45)=>{this['notifyListeners'](_0xd62f3a,_0x45bc45);});return;}const _0x4b77d4=_0x548630['key'];_0x5dee6b?this['detachListener']():this['stopPolling']();const _0x4e905d=()=>{const _0x2e8a2d=this['storage']['getItem'](_0x4b77d4);!_0x5dee6b&&this['localCache'][_0x4b77d4]===_0x2e8a2d||this['notifyListeners'](_0x4b77d4,_0x2e8a2d);},_0x1e3c3c=this['storage']['getItem'](_0x4b77d4);Tf()&&_0x1e3c3c!==_0x548630['newValue']&&_0x548630['newValue']!==_0x548630['oldValue']?setTimeout(_0x4e905d,ip):_0x4e905d();}['notifyListeners'](_0x702efc,_0x4d0068){this['localCache'][_0x702efc]=_0x4d0068;const _0x49cb7f=this['listeners'][_0x702efc];if(_0x49cb7f){for(const _0x251695 of Array['from'](_0x49cb7f))_0x251695(_0x4d0068&&JSON['parse'](_0x4d0068));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x53d57f,_0x38701c,_0x4f5377)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x53d57f,'oldValue':_0x38701c,'newValue':_0x4f5377}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x2bf19c,_0x379f70){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x2bf19c]||(this['listeners'][_0x2bf19c]=new Set(),this['localCache'][_0x2bf19c]=this['storage']['getItem'](_0x2bf19c)),this['listeners'][_0x2bf19c]['add'](_0x379f70);}['_removeListener'](_0x1ae139,_0x132107){this['listeners'][_0x1ae139]&&(this['listeners'][_0x1ae139]['delete'](_0x132107),this['listeners'][_0x1ae139]['size']===0x0&&delete this['listeners'][_0x1ae139]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x56b872,_0x386bbe){await super['_set'](_0x56b872,_0x386bbe),this['localCache'][_0x56b872]=JSON['stringify'](_0x386bbe);}async['_get'](_0x5d564f){const _0x1c9c18=await super['_get'](_0x5d564f);return this['localCache'][_0x5d564f]=JSON['stringify'](_0x1c9c18),_0x1c9c18;}async['_remove'](_0x39e935){await super['_remove'](_0x39e935),delete this['localCache'][_0x39e935];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x1e4b0b,_0x5abd6d){}['_removeListener'](_0x31d81d,_0x4201b0){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x5da192){return Promise['all'](_0x5da192['map'](async _0x1e8291=>{try{return{'fulfilled':!0x0,'value':await _0x1e8291};}catch(_0x366491){return{'fulfilled':!0x1,'reason':_0x366491};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x3fbf68){this['eventTarget']=_0x3fbf68,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0xf7151){const _0x3133f5=this['receivers']['find'](_0x61b64a=>_0x61b64a['isListeningto'](_0xf7151));if(_0x3133f5)return _0x3133f5;const _0x1b57f0=new Kn(_0xf7151);return this['receivers']['push'](_0x1b57f0),_0x1b57f0;}['isListeningto'](_0x3e9bc1){return this['eventTarget']===_0x3e9bc1;}async['handleEvent'](_0x52deb0){const _0x265eb4=_0x52deb0,{eventId:_0x11cbfe,eventType:_0xd77c68,data:_0x4d2ce3}=_0x265eb4['data'],_0x1ddb17=this['handlersMap'][_0xd77c68];if(!(_0x1ddb17!=null&&_0x1ddb17['size']))return;_0x265eb4['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x11cbfe,'eventType':_0xd77c68});const _0x1be27b=Array['from'](_0x1ddb17)['map'](async _0x5b8533=>_0x5b8533(_0x265eb4['origin'],_0x4d2ce3)),_0x6196a8=await rp(_0x1be27b);_0x265eb4['ports'][0x0]['postMessage']({'status':'done','eventId':_0x11cbfe,'eventType':_0xd77c68,'response':_0x6196a8});}['_subscribe'](_0xf2291d,_0x54a494){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0xf2291d]||(this['handlersMap'][_0xf2291d]=new Set()),this['handlersMap'][_0xf2291d]['add'](_0x54a494);}['_unsubscribe'](_0x3e250c,_0x75dd26){this['handlersMap'][_0x3e250c]&&_0x75dd26&&this['handlersMap'][_0x3e250c]['delete'](_0x75dd26),(!_0x75dd26||this['handlersMap'][_0x3e250c]['size']===0x0)&&delete this['handlersMap'][_0x3e250c],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x3c069d='',_0x1f52a3=0xa){let _0x409ea0='';for(let _0x50ac5d=0x0;_0x50ac5d<_0x1f52a3;_0x50ac5d++)_0x409ea0+=Math['floor'](Math['random']()*0xa);return _0x3c069d+_0x409ea0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x7f3615){this['target']=_0x7f3615,this['handlers']=new Set();}['removeMessageHandler'](_0x93ab05){_0x93ab05['messageChannel']&&(_0x93ab05['messageChannel']['port1']['removeEventListener']('message',_0x93ab05['onMessage']),_0x93ab05['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x93ab05);}async['_send'](_0x5aafdf,_0xbf2550,_0x4a1480=0x32){const _0x49df3e=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x49df3e)throw new Error('connection_unavailable');let _0x35e97e,_0x2a351c;return new Promise((_0x2411e3,_0x42f55d)=>{const _0x5b6116=As('',0x14);_0x49df3e['port1']['start']();const _0x53b8d5=setTimeout(()=>{_0x42f55d(new Error('unsupported_event'));},_0x4a1480);_0x2a351c={'messageChannel':_0x49df3e,'onMessage'(_0x58bb55){const _0x1ef6c2=_0x58bb55;if(_0x1ef6c2['data']['eventId']===_0x5b6116)switch(_0x1ef6c2['data']['status']){case'ack':clearTimeout(_0x53b8d5),_0x35e97e=setTimeout(()=>{_0x42f55d(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x35e97e),_0x2411e3(_0x1ef6c2['data']['response']);break;default:clearTimeout(_0x53b8d5),clearTimeout(_0x35e97e),_0x42f55d(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x2a351c),_0x49df3e['port1']['addEventListener']('message',_0x2a351c['onMessage']),this['target']['postMessage']({'eventType':_0x5aafdf,'eventId':_0x5b6116,'data':_0xbf2550},[_0x49df3e['port2']]);})['finally'](()=>{_0x2a351c&&this['removeMessageHandler'](_0x2a351c);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x2d8abe){Z()['location']['href']=_0x2d8abe;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x2d7742;return((_0x2d7742=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x2d7742['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x279ad2){this['request']=_0x279ad2;}['toPromise'](){return new Promise((_0x9f87e7,_0x4d3fca)=>{this['request']['addEventListener']('success',()=>{_0x9f87e7(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x4d3fca(this['request']['error']);});});}}function Yn(_0x440cc9,_0x142126){return _0x440cc9['transaction']([Nn],_0x142126?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x7de4fb=indexedDB['deleteDatabase'](Ka);return new Xt(_0x7de4fb)['toPromise']();}function Mi(){const _0x4c09bf=indexedDB['open'](Ka,up);return new Promise((_0x565d54,_0x47fbb9)=>{_0x4c09bf['addEventListener']('error',()=>{_0x47fbb9(_0x4c09bf['error']);}),_0x4c09bf['addEventListener']('upgradeneeded',()=>{const _0x1d8c32=_0x4c09bf['result'];try{_0x1d8c32['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0xc449cd){_0x47fbb9(_0xc449cd);}}),_0x4c09bf['addEventListener']('success',async()=>{const _0x328bef=_0x4c09bf['result'];_0x328bef['objectStoreNames']['contains'](Nn)?_0x565d54(_0x328bef):(_0x328bef['close'](),await dp(),_0x565d54(await Mi()));});});}async function Pr(_0xd1d966,_0x1a0f6e,_0x2b89d8){const _0x1cd4c8=Yn(_0xd1d966,!0x0)['put']({[Ya]:_0x1a0f6e,'value':_0x2b89d8});return new Xt(_0x1cd4c8)['toPromise']();}async function fp(_0x480b8c,_0x2298e2){const _0xa3afcb=Yn(_0x480b8c,!0x1)['get'](_0x2298e2),_0x5f2297=await new Xt(_0xa3afcb)['toPromise']();return _0x5f2297===void 0x0?null:_0x5f2297['value'];}function Or(_0x3fc94d,_0xb1f8ba){const _0x2e35ee=Yn(_0x3fc94d,!0x0)['delete'](_0xb1f8ba);return new Xt(_0x2e35ee)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x4d4da8){let _0xd04e6d=0x0;for(;;)try{const _0x203eaa=await this['_openDb']();return await _0x4d4da8(_0x203eaa);}catch(_0x19b839){if(_0xd04e6d++>_p)throw _0x19b839;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x3e6c5a,_0xf9c4a2)=>({'keyProcessed':(await this['_poll']())['includes'](_0xf9c4a2['key'])})),this['receiver']['_subscribe']('ping',async(_0x2f868f,_0x2e9212)=>['keyChanged']);}async['initializeSender'](){var _0x3d70f3,_0x172f14;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x2295e9=await this['sender']['_send']('ping',{},0x320);_0x2295e9&&(_0x3d70f3=_0x2295e9[0x0])!=null&&_0x3d70f3['fulfilled']&&(_0x172f14=_0x2295e9[0x0])!=null&&_0x172f14['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x160382){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x160382},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x30584f=await Mi();return await Pr(_0x30584f,kn,'1'),await Or(_0x30584f,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x5cb664){this['pendingWrites']++;try{await _0x5cb664();}finally{this['pendingWrites']--;}}async['_set'](_0x245152,_0x5603e9){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1468ca=>Pr(_0x1468ca,_0x245152,_0x5603e9)),this['localCache'][_0x245152]=_0x5603e9,this['notifyServiceWorker'](_0x245152)));}async['_get'](_0x122ccb){const _0x42f3a4=await this['_withRetries'](_0x10a9a5=>fp(_0x10a9a5,_0x122ccb));return this['localCache'][_0x122ccb]=_0x42f3a4,_0x42f3a4;}async['_remove'](_0x1fdf91){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4cb37e=>Or(_0x4cb37e,_0x1fdf91)),delete this['localCache'][_0x1fdf91],this['notifyServiceWorker'](_0x1fdf91)));}async['_poll'](){const _0xd4d123=await this['_withRetries'](_0x1714de=>{const _0x3bdbcb=Yn(_0x1714de,!0x1)['getAll']();return new Xt(_0x3bdbcb)['toPromise']();});if(!_0xd4d123)return[];if(this['pendingWrites']!==0x0)return[];const _0xc42b58=[],_0x2a089b=new Set();if(_0xd4d123['length']!==0x0){for(const {fbase_key:_0x2aa04f,value:_0x1de7f9}of _0xd4d123)_0x2a089b['add'](_0x2aa04f),JSON['stringify'](this['localCache'][_0x2aa04f])!==JSON['stringify'](_0x1de7f9)&&(this['notifyListeners'](_0x2aa04f,_0x1de7f9),_0xc42b58['push'](_0x2aa04f));}for(const _0x1188ff of Object['keys'](this['localCache']))this['localCache'][_0x1188ff]&&!_0x2a089b['has'](_0x1188ff)&&(this['notifyListeners'](_0x1188ff,null),_0xc42b58['push'](_0x1188ff));return _0xc42b58;}['notifyListeners'](_0x4dd236,_0x5071b0){this['localCache'][_0x4dd236]=_0x5071b0;const _0x143f97=this['listeners'][_0x4dd236];if(_0x143f97){for(const _0x3d33a9 of Array['from'](_0x143f97))_0x3d33a9(_0x5071b0);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x921867,_0x22308c){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x921867]||(this['listeners'][_0x921867]=new Set(),this['_get'](_0x921867)),this['listeners'][_0x921867]['add'](_0x22308c);}['_removeListener'](_0x2048f3,_0x23d5d2){this['listeners'][_0x2048f3]&&(this['listeners'][_0x2048f3]['delete'](_0x23d5d2),this['listeners'][_0x2048f3]['size']===0x0&&delete this['listeners'][_0x2048f3]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x566a3b,_0x8af45){return _0x8af45?ie(_0x8af45):(m(_0x566a3b['_popupRedirectResolver'],_0x566a3b,'argument-error'),_0x566a3b['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x2d8c42){super('custom','custom'),this['params']=_0x2d8c42;}['_getIdTokenResponse'](_0x371f76){return Xe(_0x371f76,this['_buildIdpRequest']());}['_linkToIdToken'](_0x26d9d0,_0xabd812){return Xe(_0x26d9d0,this['_buildIdpRequest'](_0xabd812));}['_getReauthenticationResolver'](_0x3995c2){return Xe(_0x3995c2,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x2e980e){const _0x2d976f={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x2e980e&&(_0x2d976f['idToken']=_0x2e980e),_0x2d976f;}}function yp(_0x4d7ea5){return Va(_0x4d7ea5['auth'],new ks(_0x4d7ea5),_0x4d7ea5['bypassAuthState']);}function vp(_0x48435e){const {auth:_0x2b5703,user:_0x5e0dd8}=_0x48435e;return m(_0x5e0dd8,_0x2b5703,'internal-error'),Xf(_0x5e0dd8,new ks(_0x48435e),_0x48435e['bypassAuthState']);}async function Ep(_0x1d384f){const {auth:_0x46ea32,user:_0x5d8ea0}=_0x1d384f;return m(_0x5d8ea0,_0x46ea32,'internal-error'),Jf(_0x5d8ea0,new ks(_0x1d384f),_0x1d384f['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x5edbf2,_0x293ee1,_0x388712,_0x7b2287,_0x574cd9=!0x1){this['auth']=_0x5edbf2,this['resolver']=_0x388712,this['user']=_0x7b2287,this['bypassAuthState']=_0x574cd9,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x293ee1)?_0x293ee1:[_0x293ee1];}['execute'](){return new Promise(async(_0xc0d606,_0x1a2888)=>{this['pendingPromise']={'resolve':_0xc0d606,'reject':_0x1a2888};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x7851d0){this['reject'](_0x7851d0);}});}async['onAuthEvent'](_0x5846c0){const {urlResponse:_0x3f910e,sessionId:_0x26382f,postBody:_0x3d7c4a,tenantId:_0x980a80,error:_0xaa0e5f,type:_0x1f379f}=_0x5846c0;if(_0xaa0e5f){this['reject'](_0xaa0e5f);return;}const _0x386b40={'auth':this['auth'],'requestUri':_0x3f910e,'sessionId':_0x26382f,'tenantId':_0x980a80||void 0x0,'postBody':_0x3d7c4a||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x1f379f)(_0x386b40));}catch(_0x3f11a8){this['reject'](_0x3f11a8);}}['onError'](_0x425f70){this['reject'](_0x425f70);}['getIdpTask'](_0x2b4566){switch(_0x2b4566){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x2c39b5){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x2c39b5),this['unregisterAndCleanUp']();}['reject'](_0x2ddb66){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x2ddb66),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x1e59b1,_0x2f339d,_0x32356f,_0x1f66d7,_0x570169){super(_0x1e59b1,_0x2f339d,_0x1f66d7,_0x570169),this['provider']=_0x32356f,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0xacae45=await this['execute']();return m(_0xacae45,this['auth'],'internal-error'),_0xacae45;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x1abbb0=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x1abbb0),this['authWindow']['associatedEvent']=_0x1abbb0,this['resolver']['_originValidation'](this['auth'])['catch'](_0x30bf78=>{this['reject'](_0x30bf78);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x52836e=>{_0x52836e||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x159cf1;return((_0x159cf1=this['authWindow'])==null?void 0x0:_0x159cf1['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x43cc68=()=>{var _0x2680ed,_0x406741;if((_0x406741=(_0x2680ed=this['authWindow'])==null?void 0x0:_0x2680ed['window'])!=null&&_0x406741['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x43cc68,Ip['get']());};_0x43cc68();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x18f077,_0x58da82,_0x791433=!0x1){super(_0x18f077,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x58da82,void 0x0,_0x791433),this['eventId']=null;}async['execute'](){let _0x27ecb6=on['get'](this['auth']['_key']());if(!_0x27ecb6){try{const _0x59b7e8=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x27ecb6=()=>Promise['resolve'](_0x59b7e8);}catch(_0x154e15){_0x27ecb6=()=>Promise['reject'](_0x154e15);}on['set'](this['auth']['_key'](),_0x27ecb6);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x27ecb6();}async['onAuthEvent'](_0x2112ac){if(_0x2112ac['type']==='signInViaRedirect')return super['onAuthEvent'](_0x2112ac);if(_0x2112ac['type']==='unknown'){this['resolve'](null);return;}if(_0x2112ac['eventId']){const _0x4bf972=await this['auth']['_redirectUserForId'](_0x2112ac['eventId']);if(_0x4bf972)return this['user']=_0x4bf972,super['onAuthEvent'](_0x2112ac);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x474a90,_0x31ac4e){const _0x2ee87c=Rp(_0x31ac4e),_0x5e9c64=bp(_0x474a90);if(!await _0x5e9c64['_isAvailable']())return!0x1;const _0x537d1f=await _0x5e9c64['_get'](_0x2ee87c)==='true';return await _0x5e9c64['_remove'](_0x2ee87c),_0x537d1f;}function Sp(_0x2578ef,_0x36ea7c){on['set'](_0x2578ef['_key'](),_0x36ea7c);}function bp(_0x455231){return ie(_0x455231['_redirectPersistence']);}function Rp(_0x4dfc5e){return rn(wp,_0x4dfc5e['config']['apiKey'],_0x4dfc5e['name']);}async function Ap(_0x2465fd,_0xe9837d,_0x36a81f=!0x1){if($(_0x2465fd['app']))return Promise['reject'](re(_0x2465fd));const _0x526d6e=qe(_0x2465fd),_0x16686c=mp(_0x526d6e,_0xe9837d),_0x575433=await new Cp(_0x526d6e,_0x16686c,_0x36a81f)['execute']();return _0x575433&&!_0x36a81f&&(delete _0x575433['user']['_redirectEventId'],await _0x526d6e['_persistUserIfCurrent'](_0x575433['user']),await _0x526d6e['_setRedirectUser'](null,_0xe9837d)),_0x575433;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x35dd04){this['auth']=_0x35dd04,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x45b60d){this['consumers']['add'](_0x45b60d),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x45b60d)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x45b60d),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x2d2a6f){this['consumers']['delete'](_0x2d2a6f);}['onEvent'](_0x265266){if(this['hasEventBeenHandled'](_0x265266))return!0x1;let _0x3ee26d=!0x1;return this['consumers']['forEach'](_0x5891ce=>{this['isEventForConsumer'](_0x265266,_0x5891ce)&&(_0x3ee26d=!0x0,this['sendToConsumer'](_0x265266,_0x5891ce),this['saveEventToCache'](_0x265266));}),this['hasHandledPotentialRedirect']||!Pp(_0x265266)||(this['hasHandledPotentialRedirect']=!0x0,_0x3ee26d||(this['queuedRedirectEvent']=_0x265266,_0x3ee26d=!0x0)),_0x3ee26d;}['sendToConsumer'](_0x3125fa,_0x35c710){var _0x42a5c1;if(_0x3125fa['error']&&!Xa(_0x3125fa)){const _0xc54bee=((_0x42a5c1=_0x3125fa['error']['code'])==null?void 0x0:_0x42a5c1['split']('auth/')[0x1])||'internal-error';_0x35c710['onError'](X(this['auth'],_0xc54bee));}else _0x35c710['onAuthEvent'](_0x3125fa);}['isEventForConsumer'](_0x39c190,_0x3a6e86){const _0x23b4ee=_0x3a6e86['eventId']===null||!!_0x39c190['eventId']&&_0x39c190['eventId']===_0x3a6e86['eventId'];return _0x3a6e86['filter']['includes'](_0x39c190['type'])&&_0x23b4ee;}['hasEventBeenHandled'](_0x2d5019){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x2d5019));}['saveEventToCache'](_0x36f105){this['cachedEventUids']['add'](Dr(_0x36f105)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x229e08){return[_0x229e08['type'],_0x229e08['eventId'],_0x229e08['sessionId'],_0x229e08['tenantId']]['filter'](_0x37c90b=>_0x37c90b)['join']('-');}function Xa({type:_0x11bc07,error:_0x121ba6}){return _0x11bc07==='unknown'&&(_0x121ba6==null?void 0x0:_0x121ba6['code'])==='auth/no-auth-event';}function Pp(_0x513af0){switch(_0x513af0['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x513af0);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x443428,_0x44b7d7={}){return Ae(_0x443428,'GET','/v1/projects',_0x44b7d7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x59d52a){if(_0x59d52a['config']['emulator'])return;const {authorizedDomains:_0x539a96}=await Op(_0x59d52a);for(const _0x3744a1 of _0x539a96)try{if(xp(_0x3744a1))return;}catch{}Q(_0x59d52a,'unauthorized-domain');}function xp(_0x5546e3){const _0x38f61f=Pi(),{protocol:_0x475da5,hostname:_0x22d4cf}=new URL(_0x38f61f);if(_0x5546e3['startsWith']('chrome-extension://')){const _0x3c1c9a=new URL(_0x5546e3);return _0x3c1c9a['hostname']===''&&_0x22d4cf===''?_0x475da5==='chrome-extension:'&&_0x5546e3['replace']('chrome-extension://','')===_0x38f61f['replace']('chrome-extension://',''):_0x475da5==='chrome-extension:'&&_0x3c1c9a['hostname']===_0x22d4cf;}if(!Mp['test'](_0x475da5))return!0x1;if(Dp['test'](_0x5546e3))return _0x22d4cf===_0x5546e3;const _0x39570c=_0x5546e3['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x39570c+'|'+_0x39570c+')$','i')['test'](_0x22d4cf);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x1e0ac6=Z()['___jsl'];if(_0x1e0ac6!=null&&_0x1e0ac6['H']){for(const _0x2693da of Object['keys'](_0x1e0ac6['H']))if(_0x1e0ac6['H'][_0x2693da]['r']=_0x1e0ac6['H'][_0x2693da]['r']||[],_0x1e0ac6['H'][_0x2693da]['L']=_0x1e0ac6['H'][_0x2693da]['L']||[],_0x1e0ac6['H'][_0x2693da]['r']=[..._0x1e0ac6['H'][_0x2693da]['L']],_0x1e0ac6['CP']){for(let _0x1af647=0x0;_0x1af647<_0x1e0ac6['CP']['length'];_0x1af647++)_0x1e0ac6['CP'][_0x1af647]=null;}}}function Up(_0x4c6b32){return new Promise((_0x41ed6a,_0x3d5aa4)=>{var _0x5d923b,_0x23198e,_0x2d7b49;function _0x1a4647(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x41ed6a(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x3d5aa4(X(_0x4c6b32,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x23198e=(_0x5d923b=Z()['gapi'])==null?void 0x0:_0x5d923b['iframes'])!=null&&_0x23198e['Iframe'])_0x41ed6a(gapi['iframes']['getContext']());else{if((_0x2d7b49=Z()['gapi'])!=null&&_0x2d7b49['load'])_0x1a4647();else{const _0x8bf627=Df('iframefcb');return Z()[_0x8bf627]=()=>{gapi['load']?_0x1a4647():_0x3d5aa4(X(_0x4c6b32,'network-request-failed'));},xa(Of()+'?onload='+_0x8bf627)['catch'](_0x17b960=>_0x3d5aa4(_0x17b960));}}})['catch'](_0x258821=>{throw an=null,_0x258821;});}let an=null;function Wp(_0x4db5d1){return an=an||Up(_0x4db5d1),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x5cb085){const _0x410fba=_0x5cb085['config'];m(_0x410fba['authDomain'],_0x5cb085,'auth-domain-config-required');const _0x53b947=_0x410fba['emulator']?Cs(_0x410fba,Hp):'https://'+_0x5cb085['config']['authDomain']+'/'+Vp,_0x26de60={'apiKey':_0x410fba['apiKey'],'appName':_0x5cb085['name'],'v':lt},_0x2c14ad=Gp['get'](_0x5cb085['config']['apiHost']);_0x2c14ad&&(_0x26de60['eid']=_0x2c14ad);const _0x110675=_0x5cb085['_getFrameworks']();return _0x110675['length']&&(_0x26de60['fw']=_0x110675['join'](',')),_0x53b947+'?'+ct(_0x26de60)['slice'](0x1);}async function zp(_0xbe5a42){const _0x4bda3f=await Wp(_0xbe5a42),_0x45ee0b=Z()['gapi'];return m(_0x45ee0b,_0xbe5a42,'internal-error'),_0x4bda3f['open']({'where':document['body'],'url':qp(_0xbe5a42),'messageHandlersFilter':_0x45ee0b['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0xcc10ee=>new Promise(async(_0x2c11f5,_0x100619)=>{await _0xcc10ee['restyle']({'setHideOnLeave':!0x1});const _0x2665fb=X(_0xbe5a42,'network-request-failed'),_0x31e5bb=Z()['setTimeout'](()=>{_0x100619(_0x2665fb);},Bp['get']());function _0xb14e9b(){Z()['clearTimeout'](_0x31e5bb),_0x2c11f5(_0xcc10ee);}_0xcc10ee['ping'](_0xb14e9b)['then'](_0xb14e9b,()=>{_0x100619(_0x2665fb);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x1fc73e){this['window']=_0x1fc73e,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x3613ed,_0x153122,_0x16371b,_0x146fc9=Kp,_0x366258=Yp){const _0x3e4c09=Math['max']((window['screen']['availHeight']-_0x366258)/0x2,0x0)['toString'](),_0x38dc3f=Math['max']((window['screen']['availWidth']-_0x146fc9)/0x2,0x0)['toString']();let _0x5da4b4='';const _0x3cae97={...jp,'width':_0x146fc9['toString'](),'height':_0x366258['toString'](),'top':_0x3e4c09,'left':_0x38dc3f},_0x49d705=W()['toLowerCase']();_0x16371b&&(_0x5da4b4=ka(_0x49d705)?Qp:_0x16371b),Ra(_0x49d705)&&(_0x153122=_0x153122||Jp,_0x3cae97['scrollbars']='yes');const _0x47de1b=Object['entries'](_0x3cae97)['reduce']((_0xa4bfea,[_0x1c1af2,_0x2f8b73])=>''+_0xa4bfea+_0x1c1af2+'='+_0x2f8b73+',','');if(Cf(_0x49d705)&&_0x5da4b4!=='_self')return Zp(_0x153122||'',_0x5da4b4),new Lr(null);const _0x227091=window['open'](_0x153122||'',_0x5da4b4,_0x47de1b);m(_0x227091,_0x3613ed,'popup-blocked');try{_0x227091['focus']();}catch{}return new Lr(_0x227091);}function Zp(_0x29ff7a,_0x108e84){const _0x391e6e=document['createElement']('a');_0x391e6e['href']=_0x29ff7a,_0x391e6e['target']=_0x108e84;const _0x2dcdbb=document['createEvent']('MouseEvent');_0x2dcdbb['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x391e6e['dispatchEvent'](_0x2dcdbb);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0xcbae62,_0x15a3d6,_0x9ee7e3,_0xa34be5,_0x3f6177,_0x1c9695){m(_0xcbae62['config']['authDomain'],_0xcbae62,'auth-domain-config-required'),m(_0xcbae62['config']['apiKey'],_0xcbae62,'invalid-api-key');const _0x4072ea={'apiKey':_0xcbae62['config']['apiKey'],'appName':_0xcbae62['name'],'authType':_0x9ee7e3,'redirectUrl':_0xa34be5,'v':lt,'eventId':_0x3f6177};if(_0x15a3d6 instanceof Wa){_0x15a3d6['setDefaultLanguage'](_0xcbae62['languageCode']),_0x4072ea['providerId']=_0x15a3d6['providerId']||'',ui(_0x15a3d6['getCustomParameters']())||(_0x4072ea['customParameters']=JSON['stringify'](_0x15a3d6['getCustomParameters']()));for(const [_0x6e9aa,_0x1f2aa7]of Object['entries']({}))_0x4072ea[_0x6e9aa]=_0x1f2aa7;}if(_0x15a3d6 instanceof Jt){const _0x3ede6=_0x15a3d6['getScopes']()['filter'](_0x524aff=>_0x524aff!=='');_0x3ede6['length']>0x0&&(_0x4072ea['scopes']=_0x3ede6['join'](','));}_0xcbae62['tenantId']&&(_0x4072ea['tid']=_0xcbae62['tenantId']);const _0x1af439=_0x4072ea;for(const _0x2a8351 of Object['keys'](_0x1af439))_0x1af439[_0x2a8351]===void 0x0&&delete _0x1af439[_0x2a8351];const _0x2602b4=await _0xcbae62['_getAppCheckToken'](),_0x5d5f8c=_0x2602b4?'#'+n_+'='+encodeURIComponent(_0x2602b4):'';return i_(_0xcbae62)+'?'+ct(_0x1af439)['slice'](0x1)+_0x5d5f8c;}function i_({config:_0x1257bb}){return _0x1257bb['emulator']?Cs(_0x1257bb,t_):'https://'+_0x1257bb['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x2aedfb,_0x28f0bb,_0x26c459,_0x321428){var _0x53e53c;ce((_0x53e53c=this['eventManagers'][_0x2aedfb['_key']()])==null?void 0x0:_0x53e53c['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x5ec384=await xr(_0x2aedfb,_0x28f0bb,_0x26c459,Pi(),_0x321428);return Xp(_0x2aedfb,_0x5ec384,As());}async['_openRedirect'](_0x1f4b1e,_0x2e7810,_0x32dc3a,_0x4ca77a){await this['_originValidation'](_0x1f4b1e);const _0x4629be=await xr(_0x1f4b1e,_0x2e7810,_0x32dc3a,Pi(),_0x4ca77a);return ap(_0x4629be),new Promise(()=>{});}['_initialize'](_0x73a3f0){const _0x1b1c67=_0x73a3f0['_key']();if(this['eventManagers'][_0x1b1c67]){const {manager:_0x413f28,promise:_0x4672ae}=this['eventManagers'][_0x1b1c67];return _0x413f28?Promise['resolve'](_0x413f28):(ce(_0x4672ae,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x4672ae);}const _0x240749=this['initAndGetManager'](_0x73a3f0);return this['eventManagers'][_0x1b1c67]={'promise':_0x240749},_0x240749['catch'](()=>{delete this['eventManagers'][_0x1b1c67];}),_0x240749;}async['initAndGetManager'](_0x221fdf){const _0x3a72e6=await zp(_0x221fdf),_0x218400=new Np(_0x221fdf);return _0x3a72e6['register']('authEvent',_0x3b98b4=>(m(_0x3b98b4==null?void 0x0:_0x3b98b4['authEvent'],_0x221fdf,'invalid-auth-event'),{'status':_0x218400['onEvent'](_0x3b98b4['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x221fdf['_key']()]={'manager':_0x218400},this['iframes'][_0x221fdf['_key']()]=_0x3a72e6,_0x218400;}['_isIframeWebStorageSupported'](_0x544276,_0xe75916){this['iframes'][_0x544276['_key']()]['send'](hi,{'type':hi},_0x49a10f=>{var _0x460092;const _0x40f3da=(_0x460092=_0x49a10f==null?void 0x0:_0x49a10f[0x0])==null?void 0x0:_0x460092[hi];_0x40f3da!==void 0x0&&_0xe75916(!!_0x40f3da),Q(_0x544276,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x6e7896){const _0x3200c3=_0x6e7896['_key']();return this['originValidationPromises'][_0x3200c3]||(this['originValidationPromises'][_0x3200c3]=Lp(_0x6e7896)),this['originValidationPromises'][_0x3200c3];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x2695d9){this['auth']=_0x2695d9,this['internalListeners']=new Map();}['getUid'](){var _0x35f62c;return this['assertAuthConfigured'](),((_0x35f62c=this['auth']['currentUser'])==null?void 0x0:_0x35f62c['uid'])||null;}async['getToken'](_0x99d1ee){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x99d1ee)}:null;}['addAuthTokenListener'](_0x3aa1f7){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3aa1f7))return;const _0x3d1ef4=this['auth']['onIdTokenChanged'](_0x451c6f=>{_0x3aa1f7((_0x451c6f==null?void 0x0:_0x451c6f['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3aa1f7,_0x3d1ef4),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x21e60d){this['assertAuthConfigured']();const _0x16ee3a=this['internalListeners']['get'](_0x21e60d);_0x16ee3a&&(this['internalListeners']['delete'](_0x21e60d),_0x16ee3a(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x5dac21){switch(_0x5dac21){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x834fc2){Ze(new Le('auth',(_0x4193b9,{options:_0x378e1e})=>{const _0x353149=_0x4193b9['getProvider']('app')['getImmediate'](),_0x53a253=_0x4193b9['getProvider']('heartbeat'),_0x149896=_0x4193b9['getProvider']('app-check-internal'),{apiKey:_0x7139eb,authDomain:_0x610821}=_0x353149['options'];m(_0x7139eb&&!_0x7139eb['includes'](':'),'invalid-api-key',{'appName':_0x353149['name']});const _0x5abff9={'apiKey':_0x7139eb,'authDomain':_0x610821,'clientPlatform':_0x834fc2,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x834fc2)},_0x50f152=new kf(_0x353149,_0x53a253,_0x149896,_0x5abff9);return Wf(_0x50f152,_0x378e1e),_0x50f152;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x21f2b1,_0x1e9ecc,_0x3a8eca)=>{_0x21f2b1['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x5cc789=>{const _0x53d1b0=qe(_0x5cc789['getProvider']('auth')['getImmediate']());return(_0x38f9bf=>new o_(_0x38f9bf))(_0x53d1b0);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x834fc2)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0xfa44d1=>async _0xe86d6f=>{const _0x1ab70b=_0xe86d6f&&await _0xe86d6f['getIdTokenResult'](),_0x39d49e=_0x1ab70b&&(new Date()['getTime']()-Date['parse'](_0x1ab70b['issuedAtTime']))/0x3e8;if(_0x39d49e&&_0x39d49e>h_)return;const _0x2c2baf=_0x1ab70b==null?void 0x0:_0x1ab70b['token'];Wr!==_0x2c2baf&&(Wr=_0x2c2baf,await fetch(_0xfa44d1,{'method':_0x2c2baf?'POST':'DELETE','headers':_0x2c2baf?{'Authorization':'Bearer\x20'+_0x2c2baf}:{}}));};function x_(_0x18f905=Zr()){const _0x59e09c=Bi(_0x18f905,'auth');if(_0x59e09c['isInitialized']())return _0x59e09c['getImmediate']();const _0xd4a9f0=Uf(_0x18f905,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x44db8c=zr('authTokenSyncURL');if(_0x44db8c&&typeof isSecureContext=='boolean'&&isSecureContext){const _0xecfcf0=new URL(_0x44db8c,location['origin']);if(location['origin']===_0xecfcf0['origin']){const _0x4ff8c2=u_(_0xecfcf0['toString']());tp(_0xd4a9f0,_0x4ff8c2,()=>_0x4ff8c2(_0xd4a9f0['currentUser'])),ep(_0xd4a9f0,_0x4ff44d=>_0x4ff8c2(_0x4ff44d));}}const _0x4daf8a=Gr('auth');return _0x4daf8a&&Bf(_0xd4a9f0,'http://'+_0x4daf8a),_0xd4a9f0;}function d_(){var _0x3577a3;return((_0x3577a3=document['getElementsByTagName']('head'))==null?void 0x0:_0x3577a3[0x0])??document;}Nf({'loadJS'(_0x2a3d52){return new Promise((_0x1a8c56,_0x593e5d)=>{const _0x51f949=document['createElement']('script');_0x51f949['setAttribute']('src',_0x2a3d52),_0x51f949['onload']=_0x1a8c56,_0x51f949['onerror']=_0x498595=>{const _0x19781f=X('internal-error');_0x19781f['customData']=_0x498595,_0x593e5d(_0x19781f);},_0x51f949['type']='text/javascript',_0x51f949['charset']='UTF-8',d_()['appendChild'](_0x51f949);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};