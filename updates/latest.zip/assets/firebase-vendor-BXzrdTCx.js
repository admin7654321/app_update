const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x5f1519,_0x53b5b4){if(!_0x5f1519)throw rt(_0x53b5b4);},rt=function(_0xb76d1a){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0xb76d1a);},Vr=function(_0x4fa829){const _0x5ac6ca=[];let _0x33628f=0x0;for(let _0x1af5ed=0x0;_0x1af5ed<_0x4fa829['length'];_0x1af5ed++){let _0x58018f=_0x4fa829['charCodeAt'](_0x1af5ed);_0x58018f<0x80?_0x5ac6ca[_0x33628f++]=_0x58018f:_0x58018f<0x800?(_0x5ac6ca[_0x33628f++]=_0x58018f>>0x6|0xc0,_0x5ac6ca[_0x33628f++]=_0x58018f&0x3f|0x80):(_0x58018f&0xfc00)===0xd800&&_0x1af5ed+0x1<_0x4fa829['length']&&(_0x4fa829['charCodeAt'](_0x1af5ed+0x1)&0xfc00)===0xdc00?(_0x58018f=0x10000+((_0x58018f&0x3ff)<<0xa)+(_0x4fa829['charCodeAt'](++_0x1af5ed)&0x3ff),_0x5ac6ca[_0x33628f++]=_0x58018f>>0x12|0xf0,_0x5ac6ca[_0x33628f++]=_0x58018f>>0xc&0x3f|0x80,_0x5ac6ca[_0x33628f++]=_0x58018f>>0x6&0x3f|0x80,_0x5ac6ca[_0x33628f++]=_0x58018f&0x3f|0x80):(_0x5ac6ca[_0x33628f++]=_0x58018f>>0xc|0xe0,_0x5ac6ca[_0x33628f++]=_0x58018f>>0x6&0x3f|0x80,_0x5ac6ca[_0x33628f++]=_0x58018f&0x3f|0x80);}return _0x5ac6ca;},ec=function(_0x2e55b6){const _0x53eb1d=[];let _0x31d48d=0x0,_0x483ffd=0x0;for(;_0x31d48d<_0x2e55b6['length'];){const _0x2b6a77=_0x2e55b6[_0x31d48d++];if(_0x2b6a77<0x80)_0x53eb1d[_0x483ffd++]=String['fromCharCode'](_0x2b6a77);else{if(_0x2b6a77>0xbf&&_0x2b6a77<0xe0){const _0x5c95d4=_0x2e55b6[_0x31d48d++];_0x53eb1d[_0x483ffd++]=String['fromCharCode']((_0x2b6a77&0x1f)<<0x6|_0x5c95d4&0x3f);}else{if(_0x2b6a77>0xef&&_0x2b6a77<0x16d){const _0x3a6507=_0x2e55b6[_0x31d48d++],_0x1bb649=_0x2e55b6[_0x31d48d++],_0x19b0fa=_0x2e55b6[_0x31d48d++],_0x3f5155=((_0x2b6a77&0x7)<<0x12|(_0x3a6507&0x3f)<<0xc|(_0x1bb649&0x3f)<<0x6|_0x19b0fa&0x3f)-0x10000;_0x53eb1d[_0x483ffd++]=String['fromCharCode'](0xd800+(_0x3f5155>>0xa)),_0x53eb1d[_0x483ffd++]=String['fromCharCode'](0xdc00+(_0x3f5155&0x3ff));}else{const _0x31147a=_0x2e55b6[_0x31d48d++],_0x1b54d2=_0x2e55b6[_0x31d48d++];_0x53eb1d[_0x483ffd++]=String['fromCharCode']((_0x2b6a77&0xf)<<0xc|(_0x31147a&0x3f)<<0x6|_0x1b54d2&0x3f);}}}}return _0x53eb1d['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x30ae1d,_0x5b5cca){if(!Array['isArray'](_0x30ae1d))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x54b7c0=_0x5b5cca?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0xa84336=[];for(let _0x35fddd=0x0;_0x35fddd<_0x30ae1d['length'];_0x35fddd+=0x3){const _0x5f1f51=_0x30ae1d[_0x35fddd],_0x44fc96=_0x35fddd+0x1<_0x30ae1d['length'],_0x365454=_0x44fc96?_0x30ae1d[_0x35fddd+0x1]:0x0,_0xeb40d1=_0x35fddd+0x2<_0x30ae1d['length'],_0x21ba42=_0xeb40d1?_0x30ae1d[_0x35fddd+0x2]:0x0,_0x490bfe=_0x5f1f51>>0x2,_0x5b4274=(_0x5f1f51&0x3)<<0x4|_0x365454>>0x4;let _0x5add03=(_0x365454&0xf)<<0x2|_0x21ba42>>0x6,_0x4c0736=_0x21ba42&0x3f;_0xeb40d1||(_0x4c0736=0x40,_0x44fc96||(_0x5add03=0x40)),_0xa84336['push'](_0x54b7c0[_0x490bfe],_0x54b7c0[_0x5b4274],_0x54b7c0[_0x5add03],_0x54b7c0[_0x4c0736]);}return _0xa84336['join']('');},'encodeString'(_0x1a5cb2,_0x43ca0c){return this['HAS_NATIVE_SUPPORT']&&!_0x43ca0c?btoa(_0x1a5cb2):this['encodeByteArray'](Vr(_0x1a5cb2),_0x43ca0c);},'decodeString'(_0x1e8c84,_0xf58417){return this['HAS_NATIVE_SUPPORT']&&!_0xf58417?atob(_0x1e8c84):ec(this['decodeStringToByteArray'](_0x1e8c84,_0xf58417));},'decodeStringToByteArray'(_0x22762e,_0x22fe8b){this['init_']();const _0x356378=_0x22fe8b?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x5ebd95=[];for(let _0x12754f=0x0;_0x12754f<_0x22762e['length'];){const _0x4d632b=_0x356378[_0x22762e['charAt'](_0x12754f++)],_0xc11ebd=_0x12754f<_0x22762e['length']?_0x356378[_0x22762e['charAt'](_0x12754f)]:0x0;++_0x12754f;const _0x2181a7=_0x12754f<_0x22762e['length']?_0x356378[_0x22762e['charAt'](_0x12754f)]:0x40;++_0x12754f;const _0x12472b=_0x12754f<_0x22762e['length']?_0x356378[_0x22762e['charAt'](_0x12754f)]:0x40;if(++_0x12754f,_0x4d632b==null||_0xc11ebd==null||_0x2181a7==null||_0x12472b==null)throw new tc();const _0x46f9de=_0x4d632b<<0x2|_0xc11ebd>>0x4;if(_0x5ebd95['push'](_0x46f9de),_0x2181a7!==0x40){const _0x5e38e2=_0xc11ebd<<0x4&0xf0|_0x2181a7>>0x2;if(_0x5ebd95['push'](_0x5e38e2),_0x12472b!==0x40){const _0x5df453=_0x2181a7<<0x6&0xc0|_0x12472b;_0x5ebd95['push'](_0x5df453);}}}return _0x5ebd95;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x32854c=0x0;_0x32854c<this['ENCODED_VALS']['length'];_0x32854c++)this['byteToCharMap_'][_0x32854c]=this['ENCODED_VALS']['charAt'](_0x32854c),this['charToByteMap_'][this['byteToCharMap_'][_0x32854c]]=_0x32854c,this['byteToCharMapWebSafe_'][_0x32854c]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x32854c),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x32854c]]=_0x32854c,_0x32854c>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x32854c)]=_0x32854c,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x32854c)]=_0x32854c);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x48a0a9){const _0x376de1=Vr(_0x48a0a9);return Li['encodeByteArray'](_0x376de1,!0x0);},cn=function(_0x235d2d){return Hr(_0x235d2d)['replace'](/\./g,'');},ln=function(_0x5b1ddb){try{return Li['decodeString'](_0x5b1ddb,!0x0);}catch(_0x2d8973){console['error']('base64Decode\x20failed:\x20',_0x2d8973);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x357c71){return $r(void 0x0,_0x357c71);}function $r(_0x10cb2e,_0x128444){if(!(_0x128444 instanceof Object))return _0x128444;switch(_0x128444['constructor']){case Date:const _0x86a74d=_0x128444;return new Date(_0x86a74d['getTime']());case Object:_0x10cb2e===void 0x0&&(_0x10cb2e={});break;case Array:_0x10cb2e=[];break;default:return _0x128444;}for(const _0x53d9ca in _0x128444)!_0x128444['hasOwnProperty'](_0x53d9ca)||!ic(_0x53d9ca)||(_0x10cb2e[_0x53d9ca]=$r(_0x10cb2e[_0x53d9ca],_0x128444[_0x53d9ca]));return _0x10cb2e;}function ic(_0x51a54e){return _0x51a54e!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x51db98=Ns['__FIREBASE_DEFAULTS__'];if(_0x51db98)return JSON['parse'](_0x51db98);},ac=()=>{if(typeof document>'u')return;let _0x42c8b4;try{_0x42c8b4=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x5408f4=_0x42c8b4&&ln(_0x42c8b4[0x1]);return _0x5408f4&&JSON['parse'](_0x5408f4);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x3c1805){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x3c1805);return;}},Gr=_0x45e193=>{var _0x162700,_0xdd4977;return(_0xdd4977=(_0x162700=xi())==null?void 0x0:_0x162700['emulatorHosts'])==null?void 0x0:_0xdd4977[_0x45e193];},cc=_0x258b72=>{const _0xf0b40=Gr(_0x258b72);if(!_0xf0b40)return;const _0x360d89=_0xf0b40['lastIndexOf'](':');if(_0x360d89<=0x0||_0x360d89+0x1===_0xf0b40['length'])throw new Error('Invalid\x20host\x20'+_0xf0b40+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x4a49f4=parseInt(_0xf0b40['substring'](_0x360d89+0x1),0xa);return _0xf0b40[0x0]==='['?[_0xf0b40['substring'](0x1,_0x360d89-0x1),_0x4a49f4]:[_0xf0b40['substring'](0x0,_0x360d89),_0x4a49f4];},qr=()=>{var _0x138541;return(_0x138541=xi())==null?void 0x0:_0x138541['config'];},zr=_0x37bb66=>{var _0x2df12c;return(_0x2df12c=xi())==null?void 0x0:_0x2df12c['_'+_0x37bb66];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x3b5551,_0x1adb57)=>{this['resolve']=_0x3b5551,this['reject']=_0x1adb57;});}['wrapCallback'](_0x391b15){return(_0x350a55,_0x12ee36)=>{_0x350a55?this['reject'](_0x350a55):this['resolve'](_0x12ee36),typeof _0x391b15=='function'&&(this['promise']['catch'](()=>{}),_0x391b15['length']===0x1?_0x391b15(_0x350a55):_0x391b15(_0x350a55,_0x12ee36));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x18feaf){try{return(_0x18feaf['startsWith']('http://')||_0x18feaf['startsWith']('https://')?new URL(_0x18feaf)['hostname']:_0x18feaf)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x5bb412){return(await fetch(_0x5bb412,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x361ebf,_0x1247c3){if(_0x361ebf['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x1b7e5f={'alg':'none','type':'JWT'},_0x436e2f=_0x1247c3||'demo-project',_0x5c394e=_0x361ebf['iat']||0x0,_0x4a3854=_0x361ebf['sub']||_0x361ebf['user_id'];if(!_0x4a3854)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x1e25e1={'iss':'https://securetoken.google.com/'+_0x436e2f,'aud':_0x436e2f,'iat':_0x5c394e,'exp':_0x5c394e+0xe10,'auth_time':_0x5c394e,'sub':_0x4a3854,'user_id':_0x4a3854,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x361ebf};return[cn(JSON['stringify'](_0x1b7e5f)),cn(JSON['stringify'](_0x1e25e1)),'']['join']('.');}const It={};function hc(){const _0x3afdfd={'prod':[],'emulator':[]};for(const _0x3e4b09 of Object['keys'](It))It[_0x3e4b09]?_0x3afdfd['emulator']['push'](_0x3e4b09):_0x3afdfd['prod']['push'](_0x3e4b09);return _0x3afdfd;}function uc(_0x3e67c1){let _0x1c1942=document['getElementById'](_0x3e67c1),_0x35f081=!0x1;return _0x1c1942||(_0x1c1942=document['createElement']('div'),_0x1c1942['setAttribute']('id',_0x3e67c1),_0x35f081=!0x0),{'created':_0x35f081,'element':_0x1c1942};}let Ps=!0x1;function Kr(_0x4fa2ce,_0x3946a2){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x4fa2ce]===_0x3946a2||It[_0x4fa2ce]||Ps)return;It[_0x4fa2ce]=_0x3946a2;function _0x686074(_0x20b570){return'__firebase__banner__'+_0x20b570;}const _0x1c2ee1='__firebase__banner',_0x59cd79=hc()['prod']['length']>0x0;function _0x45d166(){const _0x57a7e1=document['getElementById'](_0x1c2ee1);_0x57a7e1&&_0x57a7e1['remove']();}function _0xc274f3(_0xaa56df){_0xaa56df['style']['display']='flex',_0xaa56df['style']['background']='#7faaf0',_0xaa56df['style']['position']='fixed',_0xaa56df['style']['bottom']='5px',_0xaa56df['style']['left']='5px',_0xaa56df['style']['padding']='.5em',_0xaa56df['style']['borderRadius']='5px',_0xaa56df['style']['alignItems']='center';}function _0x316025(_0x18bc75,_0x1ebf8c){_0x18bc75['setAttribute']('width','24'),_0x18bc75['setAttribute']('id',_0x1ebf8c),_0x18bc75['setAttribute']('height','24'),_0x18bc75['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x18bc75['setAttribute']('fill','none'),_0x18bc75['style']['marginLeft']='-6px';}function _0x5592ab(){const _0x5bd01c=document['createElement']('span');return _0x5bd01c['style']['cursor']='pointer',_0x5bd01c['style']['marginLeft']='16px',_0x5bd01c['style']['fontSize']='24px',_0x5bd01c['innerHTML']='\x20&times;',_0x5bd01c['onclick']=()=>{Ps=!0x0,_0x45d166();},_0x5bd01c;}function _0x26b601(_0x1a28b2,_0x3a8672){_0x1a28b2['setAttribute']('id',_0x3a8672),_0x1a28b2['innerText']='Learn\x20more',_0x1a28b2['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x1a28b2['setAttribute']('target','__blank'),_0x1a28b2['style']['paddingLeft']='5px',_0x1a28b2['style']['textDecoration']='underline';}function _0x2502ba(){const _0x441223=uc(_0x1c2ee1),_0x3c441a=_0x686074('text'),_0x35077e=document['getElementById'](_0x3c441a)||document['createElement']('span'),_0x72daca=_0x686074('learnmore'),_0x4fff0b=document['getElementById'](_0x72daca)||document['createElement']('a'),_0x29ef8d=_0x686074('preprendIcon'),_0x1823c4=document['getElementById'](_0x29ef8d)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x441223['created']){const _0x78de2d=_0x441223['element'];_0xc274f3(_0x78de2d),_0x26b601(_0x4fff0b,_0x72daca);const _0x4736ef=_0x5592ab();_0x316025(_0x1823c4,_0x29ef8d),_0x78de2d['append'](_0x1823c4,_0x35077e,_0x4fff0b,_0x4736ef),document['body']['appendChild'](_0x78de2d);}_0x59cd79?(_0x35077e['innerText']='Preview\x20backend\x20disconnected.',_0x1823c4['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x1823c4['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x35077e['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x35077e['setAttribute']('id',_0x3c441a);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x2502ba):_0x2502ba();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x1ee803=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x1ee803=='object'&&_0x1ee803['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x1ee8f7=W();return _0x1ee8f7['indexOf']('MSIE\x20')>=0x0||_0x1ee8f7['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x20ba2b,_0x46bbe5)=>{try{let _0xc20f59=!0x0;const _0x1ee1df='validate-browser-context-for-indexeddb-analytics-module',_0x217f1c=self['indexedDB']['open'](_0x1ee1df);_0x217f1c['onsuccess']=()=>{_0x217f1c['result']['close'](),_0xc20f59||self['indexedDB']['deleteDatabase'](_0x1ee1df),_0x20ba2b(!0x0);},_0x217f1c['onupgradeneeded']=()=>{_0xc20f59=!0x1;},_0x217f1c['onerror']=()=>{var _0x4b7545;_0x46bbe5(((_0x4b7545=_0x217f1c['error'])==null?void 0x0:_0x4b7545['message'])||'');};}catch(_0x2e7051){_0x46bbe5(_0x2e7051);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x237153,_0x3563ed,_0x22469b){super(_0x3563ed),this['code']=_0x237153,this['customData']=_0x22469b,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x3f6069,_0x543dc2,_0x41ae95){this['service']=_0x3f6069,this['serviceName']=_0x543dc2,this['errors']=_0x41ae95;}['create'](_0xf707db,..._0x3e07a9){const _0x50e74e=_0x3e07a9[0x0]||{},_0x36efbe=this['service']+'/'+_0xf707db,_0x6aae30=this['errors'][_0xf707db],_0xb48df1=_0x6aae30?vc(_0x6aae30,_0x50e74e):'Error',_0x1d2aed=this['serviceName']+':\x20'+_0xb48df1+'\x20('+_0x36efbe+').';return new Se(_0x36efbe,_0x1d2aed,_0x50e74e);}}function vc(_0x450fac,_0x2471c1){return _0x450fac['replace'](Ec,(_0x3f47eb,_0x25d355)=>{const _0x6e882f=_0x2471c1[_0x25d355];return _0x6e882f!=null?String(_0x6e882f):'<'+_0x25d355+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x54ec63){return JSON['parse'](_0x54ec63);}function O(_0xd8cc09){return JSON['stringify'](_0xd8cc09);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0xac500c){let _0x2ff6de={},_0x3d1ea5={},_0x4d5b0a={},_0xb89f73='';try{const _0x4d09f1=_0xac500c['split']('.');_0x2ff6de=At(ln(_0x4d09f1[0x0])||''),_0x3d1ea5=At(ln(_0x4d09f1[0x1])||''),_0xb89f73=_0x4d09f1[0x2],_0x4d5b0a=_0x3d1ea5['d']||{},delete _0x3d1ea5['d'];}catch{}return{'header':_0x2ff6de,'claims':_0x3d1ea5,'data':_0x4d5b0a,'signature':_0xb89f73};},Ic=function(_0x4a1ae5){const _0x2bf2d6=Qr(_0x4a1ae5),_0x14bdca=_0x2bf2d6['claims'];return!!_0x14bdca&&typeof _0x14bdca=='object'&&_0x14bdca['hasOwnProperty']('iat');},wc=function(_0x4426e5){const _0x4c4b50=Qr(_0x4426e5)['claims'];return typeof _0x4c4b50=='object'&&_0x4c4b50['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x213adb,_0x47d342){return Object['prototype']['hasOwnProperty']['call'](_0x213adb,_0x47d342);}function De(_0x11354f,_0x28b4f4){if(Object['prototype']['hasOwnProperty']['call'](_0x11354f,_0x28b4f4))return _0x11354f[_0x28b4f4];}function ui(_0x56c065){for(const _0x29959d in _0x56c065)if(Object['prototype']['hasOwnProperty']['call'](_0x56c065,_0x29959d))return!0x1;return!0x0;}function hn(_0x305bd2,_0x4ffc3a,_0x51de44){const _0x5681a3={};for(const _0x151e50 in _0x305bd2)Object['prototype']['hasOwnProperty']['call'](_0x305bd2,_0x151e50)&&(_0x5681a3[_0x151e50]=_0x4ffc3a['call'](_0x51de44,_0x305bd2[_0x151e50],_0x151e50,_0x305bd2));return _0x5681a3;}function Me(_0x5e119f,_0x14684d){if(_0x5e119f===_0x14684d)return!0x0;const _0x41a2f0=Object['keys'](_0x5e119f),_0x50a4a0=Object['keys'](_0x14684d);for(const _0x3dd827 of _0x41a2f0){if(!_0x50a4a0['includes'](_0x3dd827))return!0x1;const _0x385e7b=_0x5e119f[_0x3dd827],_0x47b5f3=_0x14684d[_0x3dd827];if(Os(_0x385e7b)&&Os(_0x47b5f3)){if(!Me(_0x385e7b,_0x47b5f3))return!0x1;}else{if(_0x385e7b!==_0x47b5f3)return!0x1;}}for(const _0x4ca5f6 of _0x50a4a0)if(!_0x41a2f0['includes'](_0x4ca5f6))return!0x1;return!0x0;}function Os(_0x28d0d4){return _0x28d0d4!==null&&typeof _0x28d0d4=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x3df7bb){const _0x4be586=[];for(const [_0x3f5415,_0x2b4090]of Object['entries'](_0x3df7bb))Array['isArray'](_0x2b4090)?_0x2b4090['forEach'](_0x2fe80c=>{_0x4be586['push'](encodeURIComponent(_0x3f5415)+'='+encodeURIComponent(_0x2fe80c));}):_0x4be586['push'](encodeURIComponent(_0x3f5415)+'='+encodeURIComponent(_0x2b4090));return _0x4be586['length']?'&'+_0x4be586['join']('&'):'';}function vt(_0x393f22){const _0x5887f3={};return _0x393f22['replace'](/^\?/,'')['split']('&')['forEach'](_0x5258d7=>{if(_0x5258d7){const [_0x348fc8,_0xaa5263]=_0x5258d7['split']('=');_0x5887f3[decodeURIComponent(_0x348fc8)]=decodeURIComponent(_0xaa5263);}}),_0x5887f3;}function Et(_0xd3d6d9){const _0x2f59f8=_0xd3d6d9['indexOf']('?');if(!_0x2f59f8)return'';const _0x55d182=_0xd3d6d9['indexOf']('#',_0x2f59f8);return _0xd3d6d9['substring'](_0x2f59f8,_0x55d182>0x0?_0x55d182:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x555a5e=0x1;_0x555a5e<this['blockSize'];++_0x555a5e)this['pad_'][_0x555a5e]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x260bbf,_0x155542){_0x155542||(_0x155542=0x0);const _0xf0bbac=this['W_'];if(typeof _0x260bbf=='string'){for(let _0x34adb4=0x0;_0x34adb4<0x10;_0x34adb4++)_0xf0bbac[_0x34adb4]=_0x260bbf['charCodeAt'](_0x155542)<<0x18|_0x260bbf['charCodeAt'](_0x155542+0x1)<<0x10|_0x260bbf['charCodeAt'](_0x155542+0x2)<<0x8|_0x260bbf['charCodeAt'](_0x155542+0x3),_0x155542+=0x4;}else{for(let _0x3e4fbe=0x0;_0x3e4fbe<0x10;_0x3e4fbe++)_0xf0bbac[_0x3e4fbe]=_0x260bbf[_0x155542]<<0x18|_0x260bbf[_0x155542+0x1]<<0x10|_0x260bbf[_0x155542+0x2]<<0x8|_0x260bbf[_0x155542+0x3],_0x155542+=0x4;}for(let _0x28cdcb=0x10;_0x28cdcb<0x50;_0x28cdcb++){const _0x3a0874=_0xf0bbac[_0x28cdcb-0x3]^_0xf0bbac[_0x28cdcb-0x8]^_0xf0bbac[_0x28cdcb-0xe]^_0xf0bbac[_0x28cdcb-0x10];_0xf0bbac[_0x28cdcb]=(_0x3a0874<<0x1|_0x3a0874>>>0x1f)&0xffffffff;}let _0x4994d3=this['chain_'][0x0],_0x40d343=this['chain_'][0x1],_0x4ec83b=this['chain_'][0x2],_0x312d1f=this['chain_'][0x3],_0xfe7db6=this['chain_'][0x4],_0x43d911,_0xa9e04a;for(let _0x211654=0x0;_0x211654<0x50;_0x211654++){_0x211654<0x28?_0x211654<0x14?(_0x43d911=_0x312d1f^_0x40d343&(_0x4ec83b^_0x312d1f),_0xa9e04a=0x5a827999):(_0x43d911=_0x40d343^_0x4ec83b^_0x312d1f,_0xa9e04a=0x6ed9eba1):_0x211654<0x3c?(_0x43d911=_0x40d343&_0x4ec83b|_0x312d1f&(_0x40d343|_0x4ec83b),_0xa9e04a=0x8f1bbcdc):(_0x43d911=_0x40d343^_0x4ec83b^_0x312d1f,_0xa9e04a=0xca62c1d6);const _0x5ce871=(_0x4994d3<<0x5|_0x4994d3>>>0x1b)+_0x43d911+_0xfe7db6+_0xa9e04a+_0xf0bbac[_0x211654]&0xffffffff;_0xfe7db6=_0x312d1f,_0x312d1f=_0x4ec83b,_0x4ec83b=(_0x40d343<<0x1e|_0x40d343>>>0x2)&0xffffffff,_0x40d343=_0x4994d3,_0x4994d3=_0x5ce871;}this['chain_'][0x0]=this['chain_'][0x0]+_0x4994d3&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x40d343&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x4ec83b&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x312d1f&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0xfe7db6&0xffffffff;}['update'](_0x2151a2,_0x3e1881){if(_0x2151a2==null)return;_0x3e1881===void 0x0&&(_0x3e1881=_0x2151a2['length']);const _0x341c11=_0x3e1881-this['blockSize'];let _0x3aea72=0x0;const _0x575542=this['buf_'];let _0x1644a8=this['inbuf_'];for(;_0x3aea72<_0x3e1881;){if(_0x1644a8===0x0){for(;_0x3aea72<=_0x341c11;)this['compress_'](_0x2151a2,_0x3aea72),_0x3aea72+=this['blockSize'];}if(typeof _0x2151a2=='string'){for(;_0x3aea72<_0x3e1881;)if(_0x575542[_0x1644a8]=_0x2151a2['charCodeAt'](_0x3aea72),++_0x1644a8,++_0x3aea72,_0x1644a8===this['blockSize']){this['compress_'](_0x575542),_0x1644a8=0x0;break;}}else{for(;_0x3aea72<_0x3e1881;)if(_0x575542[_0x1644a8]=_0x2151a2[_0x3aea72],++_0x1644a8,++_0x3aea72,_0x1644a8===this['blockSize']){this['compress_'](_0x575542),_0x1644a8=0x0;break;}}}this['inbuf_']=_0x1644a8,this['total_']+=_0x3e1881;}['digest'](){const _0x266acd=[];let _0x4080=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x448b3b=this['blockSize']-0x1;_0x448b3b>=0x38;_0x448b3b--)this['buf_'][_0x448b3b]=_0x4080&0xff,_0x4080/=0x100;this['compress_'](this['buf_']);let _0x4adff5=0x0;for(let _0xcfba2a=0x0;_0xcfba2a<0x5;_0xcfba2a++)for(let _0x3a3bc8=0x18;_0x3a3bc8>=0x0;_0x3a3bc8-=0x8)_0x266acd[_0x4adff5]=this['chain_'][_0xcfba2a]>>_0x3a3bc8&0xff,++_0x4adff5;return _0x266acd;}}function Tc(_0x216198,_0x2b81a9){const _0x2ff4c0=new Sc(_0x216198,_0x2b81a9);return _0x2ff4c0['subscribe']['bind'](_0x2ff4c0);}class Sc{constructor(_0x58ffae,_0xd9345d){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0xd9345d,this['task']['then'](()=>{_0x58ffae(this);})['catch'](_0x580a8d=>{this['error'](_0x580a8d);});}['next'](_0x9201a9){this['forEachObserver'](_0x3d4456=>{_0x3d4456['next'](_0x9201a9);});}['error'](_0x3899db){this['forEachObserver'](_0x43e12e=>{_0x43e12e['error'](_0x3899db);}),this['close'](_0x3899db);}['complete'](){this['forEachObserver'](_0x124052=>{_0x124052['complete']();}),this['close']();}['subscribe'](_0x2a204a,_0x62832f,_0x5d1eca){let _0x5acf11;if(_0x2a204a===void 0x0&&_0x62832f===void 0x0&&_0x5d1eca===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x2a204a,['next','error','complete'])?_0x5acf11=_0x2a204a:_0x5acf11={'next':_0x2a204a,'error':_0x62832f,'complete':_0x5d1eca},_0x5acf11['next']===void 0x0&&(_0x5acf11['next']=Jn),_0x5acf11['error']===void 0x0&&(_0x5acf11['error']=Jn),_0x5acf11['complete']===void 0x0&&(_0x5acf11['complete']=Jn);const _0x394d06=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x5acf11['error'](this['finalError']):_0x5acf11['complete']();}catch{}}),this['observers']['push'](_0x5acf11),_0x394d06;}['unsubscribeOne'](_0x1f5254){this['observers']===void 0x0||this['observers'][_0x1f5254]===void 0x0||(delete this['observers'][_0x1f5254],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x778e9e){if(!this['finalized']){for(let _0xbd35b9=0x0;_0xbd35b9<this['observers']['length'];_0xbd35b9++)this['sendOne'](_0xbd35b9,_0x778e9e);}}['sendOne'](_0x446bb1,_0x3939f8){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x446bb1]!==void 0x0)try{_0x3939f8(this['observers'][_0x446bb1]);}catch(_0x12e98e){typeof console<'u'&&console['error']&&console['error'](_0x12e98e);}});}['close'](_0x5ef3b7){this['finalized']||(this['finalized']=!0x0,_0x5ef3b7!==void 0x0&&(this['finalError']=_0x5ef3b7),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x509147,_0x45ab3d){if(typeof _0x509147!='object'||_0x509147===null)return!0x1;for(const _0x1b3b63 of _0x45ab3d)if(_0x1b3b63 in _0x509147&&typeof _0x509147[_0x1b3b63]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x3cc01b,_0x3bf594){return _0x3cc01b+'\x20failed:\x20'+_0x3bf594+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x86dfd){const _0x37da9f=[];let _0x4c7910=0x0;for(let _0x55b952=0x0;_0x55b952<_0x86dfd['length'];_0x55b952++){let _0x1b9d02=_0x86dfd['charCodeAt'](_0x55b952);if(_0x1b9d02>=0xd800&&_0x1b9d02<=0xdbff){const _0x684b3f=_0x1b9d02-0xd800;_0x55b952++,f(_0x55b952<_0x86dfd['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x37c378=_0x86dfd['charCodeAt'](_0x55b952)-0xdc00;_0x1b9d02=0x10000+(_0x684b3f<<0xa)+_0x37c378;}_0x1b9d02<0x80?_0x37da9f[_0x4c7910++]=_0x1b9d02:_0x1b9d02<0x800?(_0x37da9f[_0x4c7910++]=_0x1b9d02>>0x6|0xc0,_0x37da9f[_0x4c7910++]=_0x1b9d02&0x3f|0x80):_0x1b9d02<0x10000?(_0x37da9f[_0x4c7910++]=_0x1b9d02>>0xc|0xe0,_0x37da9f[_0x4c7910++]=_0x1b9d02>>0x6&0x3f|0x80,_0x37da9f[_0x4c7910++]=_0x1b9d02&0x3f|0x80):(_0x37da9f[_0x4c7910++]=_0x1b9d02>>0x12|0xf0,_0x37da9f[_0x4c7910++]=_0x1b9d02>>0xc&0x3f|0x80,_0x37da9f[_0x4c7910++]=_0x1b9d02>>0x6&0x3f|0x80,_0x37da9f[_0x4c7910++]=_0x1b9d02&0x3f|0x80);}return _0x37da9f;},On=function(_0x3b42a2){let _0x4102bf=0x0;for(let _0x4438e0=0x0;_0x4438e0<_0x3b42a2['length'];_0x4438e0++){const _0x262d5a=_0x3b42a2['charCodeAt'](_0x4438e0);_0x262d5a<0x80?_0x4102bf++:_0x262d5a<0x800?_0x4102bf+=0x2:_0x262d5a>=0xd800&&_0x262d5a<=0xdbff?(_0x4102bf+=0x4,_0x4438e0++):_0x4102bf+=0x3;}return _0x4102bf;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x5d13e3){return _0x5d13e3&&_0x5d13e3['_delegate']?_0x5d13e3['_delegate']:_0x5d13e3;}class Le{constructor(_0x305803,_0x187d26,_0x3b0f6e){this['name']=_0x305803,this['instanceFactory']=_0x187d26,this['type']=_0x3b0f6e,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x155e36){return this['instantiationMode']=_0x155e36,this;}['setMultipleInstances'](_0x2064b5){return this['multipleInstances']=_0x2064b5,this;}['setServiceProps'](_0x17c3da){return this['serviceProps']=_0x17c3da,this;}['setInstanceCreatedCallback'](_0xeed508){return this['onInstanceCreated']=_0xeed508,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x155263,_0x26a760){this['name']=_0x155263,this['container']=_0x26a760,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x86f443){const _0xed0c22=this['normalizeInstanceIdentifier'](_0x86f443);if(!this['instancesDeferred']['has'](_0xed0c22)){const _0x42158f=new ot();if(this['instancesDeferred']['set'](_0xed0c22,_0x42158f),this['isInitialized'](_0xed0c22)||this['shouldAutoInitialize']())try{const _0x5cfa26=this['getOrInitializeService']({'instanceIdentifier':_0xed0c22});_0x5cfa26&&_0x42158f['resolve'](_0x5cfa26);}catch{}}return this['instancesDeferred']['get'](_0xed0c22)['promise'];}['getImmediate'](_0x3df319){const _0x3593c8=this['normalizeInstanceIdentifier'](_0x3df319==null?void 0x0:_0x3df319['identifier']),_0x426dc1=(_0x3df319==null?void 0x0:_0x3df319['optional'])??!0x1;if(this['isInitialized'](_0x3593c8)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x3593c8});}catch(_0xf84434){if(_0x426dc1)return null;throw _0xf84434;}else{if(_0x426dc1)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x832fba){if(_0x832fba['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x832fba['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x832fba,!!this['shouldAutoInitialize']()){if(Nc(_0x832fba))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x5acc4c,_0x2f5037]of this['instancesDeferred']['entries']()){const _0x488caf=this['normalizeInstanceIdentifier'](_0x5acc4c);try{const _0x461ccc=this['getOrInitializeService']({'instanceIdentifier':_0x488caf});_0x2f5037['resolve'](_0x461ccc);}catch{}}}}['clearInstance'](_0x362dbb=Ne){this['instancesDeferred']['delete'](_0x362dbb),this['instancesOptions']['delete'](_0x362dbb),this['instances']['delete'](_0x362dbb);}async['delete'](){const _0x3c700f=Array['from'](this['instances']['values']());await Promise['all']([..._0x3c700f['filter'](_0x3f3269=>'INTERNAL'in _0x3f3269)['map'](_0x1625e1=>_0x1625e1['INTERNAL']['delete']()),..._0x3c700f['filter'](_0x2abd4f=>'_delete'in _0x2abd4f)['map'](_0x378e22=>_0x378e22['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x47d0c8=Ne){return this['instances']['has'](_0x47d0c8);}['getOptions'](_0x3d5f0e=Ne){return this['instancesOptions']['get'](_0x3d5f0e)||{};}['initialize'](_0x2d6e9c={}){const {options:_0x5db963={}}=_0x2d6e9c,_0x3645b4=this['normalizeInstanceIdentifier'](_0x2d6e9c['instanceIdentifier']);if(this['isInitialized'](_0x3645b4))throw Error(this['name']+'('+_0x3645b4+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x18c486=this['getOrInitializeService']({'instanceIdentifier':_0x3645b4,'options':_0x5db963});for(const [_0x74c3b9,_0x480c33]of this['instancesDeferred']['entries']()){const _0x12f79d=this['normalizeInstanceIdentifier'](_0x74c3b9);_0x3645b4===_0x12f79d&&_0x480c33['resolve'](_0x18c486);}return _0x18c486;}['onInit'](_0x19f99f,_0x4d05ba){const _0x3e4306=this['normalizeInstanceIdentifier'](_0x4d05ba),_0x59d274=this['onInitCallbacks']['get'](_0x3e4306)??new Set();_0x59d274['add'](_0x19f99f),this['onInitCallbacks']['set'](_0x3e4306,_0x59d274);const _0x291a52=this['instances']['get'](_0x3e4306);return _0x291a52&&_0x19f99f(_0x291a52,_0x3e4306),()=>{_0x59d274['delete'](_0x19f99f);};}['invokeOnInitCallbacks'](_0x16c0b8,_0x2584f3){const _0xd4a146=this['onInitCallbacks']['get'](_0x2584f3);if(_0xd4a146){for(const _0x4362fc of _0xd4a146)try{_0x4362fc(_0x16c0b8,_0x2584f3);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x464103,options:_0x57702b={}}){let _0x362d93=this['instances']['get'](_0x464103);if(!_0x362d93&&this['component']&&(_0x362d93=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x464103),'options':_0x57702b}),this['instances']['set'](_0x464103,_0x362d93),this['instancesOptions']['set'](_0x464103,_0x57702b),this['invokeOnInitCallbacks'](_0x362d93,_0x464103),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x464103,_0x362d93);}catch{}return _0x362d93||null;}['normalizeInstanceIdentifier'](_0x257c10=Ne){return this['component']?this['component']['multipleInstances']?_0x257c10:Ne:_0x257c10;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x869eb1){return _0x869eb1===Ne?void 0x0:_0x869eb1;}function Nc(_0x52ae36){return _0x52ae36['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0xf4a82f){this['name']=_0xf4a82f,this['providers']=new Map();}['addComponent'](_0x4623d4){const _0x433a8f=this['getProvider'](_0x4623d4['name']);if(_0x433a8f['isComponentSet']())throw new Error('Component\x20'+_0x4623d4['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x433a8f['setComponent'](_0x4623d4);}['addOrOverwriteComponent'](_0x30e68c){this['getProvider'](_0x30e68c['name'])['isComponentSet']()&&this['providers']['delete'](_0x30e68c['name']),this['addComponent'](_0x30e68c);}['getProvider'](_0x543d45){if(this['providers']['has'](_0x543d45))return this['providers']['get'](_0x543d45);const _0x50561c=new Ac(_0x543d45,this);return this['providers']['set'](_0x543d45,_0x50561c),_0x50561c;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x154458){_0x154458[_0x154458['DEBUG']=0x0]='DEBUG',_0x154458[_0x154458['VERBOSE']=0x1]='VERBOSE',_0x154458[_0x154458['INFO']=0x2]='INFO',_0x154458[_0x154458['WARN']=0x3]='WARN',_0x154458[_0x154458['ERROR']=0x4]='ERROR',_0x154458[_0x154458['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x508996,_0x1fc0b4,..._0x15411c)=>{if(_0x1fc0b4<_0x508996['logLevel'])return;const _0x1551ce=new Date()['toISOString'](),_0x6fd799=Mc[_0x1fc0b4];if(_0x6fd799)console[_0x6fd799]('['+_0x1551ce+']\x20\x20'+_0x508996['name']+':',..._0x15411c);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x1fc0b4+')');};class Ui{constructor(_0x41d4c5){this['name']=_0x41d4c5,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x58e291){if(!(_0x58e291 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x58e291+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x58e291;}['setLogLevel'](_0x4d7aee){this['_logLevel']=typeof _0x4d7aee=='string'?Oc[_0x4d7aee]:_0x4d7aee;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x4147e0){if(typeof _0x4147e0!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x4147e0;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x26ed89){this['_userLogHandler']=_0x26ed89;}['debug'](..._0x419006){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x419006),this['_logHandler'](this,T['DEBUG'],..._0x419006);}['log'](..._0x1654bb){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x1654bb),this['_logHandler'](this,T['VERBOSE'],..._0x1654bb);}['info'](..._0x31a503){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x31a503),this['_logHandler'](this,T['INFO'],..._0x31a503);}['warn'](..._0x4b302c){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x4b302c),this['_logHandler'](this,T['WARN'],..._0x4b302c);}['error'](..._0x23a002){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x23a002),this['_logHandler'](this,T['ERROR'],..._0x23a002);}}const xc=(_0x590938,_0x38806d)=>_0x38806d['some'](_0x28511b=>_0x590938 instanceof _0x28511b);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x234d53){const _0x13e35d=new Promise((_0x5d9d5d,_0x4b5ba0)=>{const _0x1d13b2=()=>{_0x234d53['removeEventListener']('success',_0x53a225),_0x234d53['removeEventListener']('error',_0x17ba2b);},_0x53a225=()=>{_0x5d9d5d(_e(_0x234d53['result'])),_0x1d13b2();},_0x17ba2b=()=>{_0x4b5ba0(_0x234d53['error']),_0x1d13b2();};_0x234d53['addEventListener']('success',_0x53a225),_0x234d53['addEventListener']('error',_0x17ba2b);});return _0x13e35d['then'](_0x54aacf=>{_0x54aacf instanceof IDBCursor&&Jr['set'](_0x54aacf,_0x234d53);})['catch'](()=>{}),Wi['set'](_0x13e35d,_0x234d53),_0x13e35d;}function Bc(_0x1b7e87){if(di['has'](_0x1b7e87))return;const _0x26e74e=new Promise((_0x54358c,_0x3cc9c9)=>{const _0x531c79=()=>{_0x1b7e87['removeEventListener']('complete',_0x529656),_0x1b7e87['removeEventListener']('error',_0x48de48),_0x1b7e87['removeEventListener']('abort',_0x48de48);},_0x529656=()=>{_0x54358c(),_0x531c79();},_0x48de48=()=>{_0x3cc9c9(_0x1b7e87['error']||new DOMException('AbortError','AbortError')),_0x531c79();};_0x1b7e87['addEventListener']('complete',_0x529656),_0x1b7e87['addEventListener']('error',_0x48de48),_0x1b7e87['addEventListener']('abort',_0x48de48);});di['set'](_0x1b7e87,_0x26e74e);}let fi={'get'(_0x4ecf16,_0x199e14,_0x339b19){if(_0x4ecf16 instanceof IDBTransaction){if(_0x199e14==='done')return di['get'](_0x4ecf16);if(_0x199e14==='objectStoreNames')return _0x4ecf16['objectStoreNames']||Xr['get'](_0x4ecf16);if(_0x199e14==='store')return _0x339b19['objectStoreNames'][0x1]?void 0x0:_0x339b19['objectStore'](_0x339b19['objectStoreNames'][0x0]);}return _e(_0x4ecf16[_0x199e14]);},'set'(_0x51fdeb,_0x23bc18,_0xbad85f){return _0x51fdeb[_0x23bc18]=_0xbad85f,!0x0;},'has'(_0x1cf6bf,_0x5894b1){return _0x1cf6bf instanceof IDBTransaction&&(_0x5894b1==='done'||_0x5894b1==='store')?!0x0:_0x5894b1 in _0x1cf6bf;}};function Vc(_0x17198c){fi=_0x17198c(fi);}function Hc(_0x5df4e9){return _0x5df4e9===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x20f5c7,..._0x29a1d2){const _0x2383d1=_0x5df4e9['call'](Zn(this),_0x20f5c7,..._0x29a1d2);return Xr['set'](_0x2383d1,_0x20f5c7['sort']?_0x20f5c7['sort']():[_0x20f5c7]),_e(_0x2383d1);}:Uc()['includes'](_0x5df4e9)?function(..._0x495bbf){return _0x5df4e9['apply'](Zn(this),_0x495bbf),_e(Jr['get'](this));}:function(..._0x2fe04f){return _e(_0x5df4e9['apply'](Zn(this),_0x2fe04f));};}function $c(_0x45064c){return typeof _0x45064c=='function'?Hc(_0x45064c):(_0x45064c instanceof IDBTransaction&&Bc(_0x45064c),xc(_0x45064c,Fc())?new Proxy(_0x45064c,fi):_0x45064c);}function _e(_0x511751){if(_0x511751 instanceof IDBRequest)return Wc(_0x511751);if(Xn['has'](_0x511751))return Xn['get'](_0x511751);const _0x1699a5=$c(_0x511751);return _0x1699a5!==_0x511751&&(Xn['set'](_0x511751,_0x1699a5),Wi['set'](_0x1699a5,_0x511751)),_0x1699a5;}const Zn=_0x38e694=>Wi['get'](_0x38e694);function Gc(_0xf9bc90,_0x6a3b50,{blocked:_0x19d859,upgrade:_0x42f942,blocking:_0x424029,terminated:_0x284295}={}){const _0x4cfd4e=indexedDB['open'](_0xf9bc90,_0x6a3b50),_0xc9b506=_e(_0x4cfd4e);return _0x42f942&&_0x4cfd4e['addEventListener']('upgradeneeded',_0x14851d=>{_0x42f942(_e(_0x4cfd4e['result']),_0x14851d['oldVersion'],_0x14851d['newVersion'],_e(_0x4cfd4e['transaction']),_0x14851d);}),_0x19d859&&_0x4cfd4e['addEventListener']('blocked',_0xb15c3c=>_0x19d859(_0xb15c3c['oldVersion'],_0xb15c3c['newVersion'],_0xb15c3c)),_0xc9b506['then'](_0x2d5ace=>{_0x284295&&_0x2d5ace['addEventListener']('close',()=>_0x284295()),_0x424029&&_0x2d5ace['addEventListener']('versionchange',_0x7e1934=>_0x424029(_0x7e1934['oldVersion'],_0x7e1934['newVersion'],_0x7e1934));})['catch'](()=>{}),_0xc9b506;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x452912,_0x3baae2){if(!(_0x452912 instanceof IDBDatabase&&!(_0x3baae2 in _0x452912)&&typeof _0x3baae2=='string'))return;if(ei['get'](_0x3baae2))return ei['get'](_0x3baae2);const _0x17b895=_0x3baae2['replace'](/FromIndex$/,''),_0x467a4f=_0x3baae2!==_0x17b895,_0x2b198d=zc['includes'](_0x17b895);if(!(_0x17b895 in(_0x467a4f?IDBIndex:IDBObjectStore)['prototype'])||!(_0x2b198d||qc['includes'](_0x17b895)))return;const _0x1fdcc1=async function(_0x15044b,..._0x10b51d){const _0x2ee821=this['transaction'](_0x15044b,_0x2b198d?'readwrite':'readonly');let _0x110742=_0x2ee821['store'];return _0x467a4f&&(_0x110742=_0x110742['index'](_0x10b51d['shift']())),(await Promise['all']([_0x110742[_0x17b895](..._0x10b51d),_0x2b198d&&_0x2ee821['done']]))[0x0];};return ei['set'](_0x3baae2,_0x1fdcc1),_0x1fdcc1;}Vc(_0x4ffe99=>({..._0x4ffe99,'get':(_0x467814,_0x22f3c5,_0x510ea1)=>Ls(_0x467814,_0x22f3c5)||_0x4ffe99['get'](_0x467814,_0x22f3c5,_0x510ea1),'has':(_0x61602d,_0x3715a0)=>!!Ls(_0x61602d,_0x3715a0)||_0x4ffe99['has'](_0x61602d,_0x3715a0)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x162813){this['container']=_0x162813;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x2bc8aa=>{if(Kc(_0x2bc8aa)){const _0x2ac4e1=_0x2bc8aa['getImmediate']();return _0x2ac4e1['library']+'/'+_0x2ac4e1['version'];}else return null;})['filter'](_0x4ea2c4=>_0x4ea2c4)['join']('\x20');}}function Kc(_0x3e3473){const _0x4625d9=_0x3e3473['getComponent']();return(_0x4625d9==null?void 0x0:_0x4625d9['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x2f5837,_0x80119d){try{_0x2f5837['container']['addComponent'](_0x80119d);}catch(_0x177742){oe['debug']('Component\x20'+_0x80119d['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x2f5837['name'],_0x177742);}}function Ze(_0x53f983){const _0x4d12fa=_0x53f983['name'];if(mi['has'](_0x4d12fa))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x4d12fa+'.'),!0x1;mi['set'](_0x4d12fa,_0x53f983);for(const _0x522514 of xe['values']())Fs(_0x522514,_0x53f983);for(const _0x178cc2 of gi['values']())Fs(_0x178cc2,_0x53f983);return!0x0;}function Bi(_0x1358be,_0x18d68e){const _0x1707b9=_0x1358be['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x1707b9&&_0x1707b9['triggerHeartbeat'](),_0x1358be['container']['getProvider'](_0x18d68e);}function $(_0x595a94){return _0x595a94==null?!0x1:_0x595a94['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x2d4c97,_0x416c38,_0xf252a6){this['_isDeleted']=!0x1,this['_options']={..._0x2d4c97},this['_config']={..._0x416c38},this['_name']=_0x416c38['name'],this['_automaticDataCollectionEnabled']=_0x416c38['automaticDataCollectionEnabled'],this['_container']=_0xf252a6,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x4966e7){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x4966e7;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x43b450){this['_isDeleted']=_0x43b450;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x2e8e7b,_0x4ba071={}){let _0x1111d9=_0x2e8e7b;typeof _0x4ba071!='object'&&(_0x4ba071={'name':_0x4ba071});const _0x4389d4={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x4ba071},_0x4ff403=_0x4389d4['name'];if(typeof _0x4ff403!='string'||!_0x4ff403)throw ge['create']('bad-app-name',{'appName':String(_0x4ff403)});if(_0x1111d9||(_0x1111d9=qr()),!_0x1111d9)throw ge['create']('no-options');const _0x2a872e=xe['get'](_0x4ff403);if(_0x2a872e){if(Me(_0x1111d9,_0x2a872e['options'])&&Me(_0x4389d4,_0x2a872e['config']))return _0x2a872e;throw ge['create']('duplicate-app',{'appName':_0x4ff403});}const _0x4b0387=new Pc(_0x4ff403);for(const _0x5d3885 of mi['values']())_0x4b0387['addComponent'](_0x5d3885);const _0x13e6ae=new Tl(_0x1111d9,_0x4389d4,_0x4b0387);return xe['set'](_0x4ff403,_0x13e6ae),_0x13e6ae;}function Zr(_0x3c3e1c=_i){const _0x564524=xe['get'](_0x3c3e1c);if(!_0x564524&&_0x3c3e1c===_i&&qr())return Sl();if(!_0x564524)throw ge['create']('no-app',{'appName':_0x3c3e1c});return _0x564524;}function f_(){return Array['from'](xe['values']());}async function p_(_0x4e7c82){let _0x443474=!0x1;const _0x320bfe=_0x4e7c82['name'];xe['has'](_0x320bfe)?(_0x443474=!0x0,xe['delete'](_0x320bfe)):gi['has'](_0x320bfe)&&_0x4e7c82['decRefCount']()<=0x0&&(gi['delete'](_0x320bfe),_0x443474=!0x0),_0x443474&&(await Promise['all'](_0x4e7c82['container']['getProviders']()['map'](_0x45ceea=>_0x45ceea['delete']())),_0x4e7c82['isDeleted']=!0x0);}function me(_0x4830df,_0x21735b,_0x4629a6){let _0x5309b2=wl[_0x4830df]??_0x4830df;_0x4629a6&&(_0x5309b2+='-'+_0x4629a6);const _0x3f1a10=_0x5309b2['match'](/\s|\//),_0x194238=_0x21735b['match'](/\s|\//);if(_0x3f1a10||_0x194238){const _0x29ba8e=['Unable\x20to\x20register\x20library\x20\x22'+_0x5309b2+'\x22\x20with\x20version\x20\x22'+_0x21735b+'\x22:'];_0x3f1a10&&_0x29ba8e['push']('library\x20name\x20\x22'+_0x5309b2+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x3f1a10&&_0x194238&&_0x29ba8e['push']('and'),_0x194238&&_0x29ba8e['push']('version\x20name\x20\x22'+_0x21735b+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x29ba8e['join']('\x20'));return;}Ze(new Le(_0x5309b2+'-version',()=>({'library':_0x5309b2,'version':_0x21735b}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0xf8f3a0,_0x547527)=>{switch(_0x547527){case 0x0:try{_0xf8f3a0['createObjectStore'](kt);}catch(_0x4b839a){console['warn'](_0x4b839a);}}}})['catch'](_0x17579e=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x17579e['message']});})),ti;}async function Al(_0x4ba872){try{const _0x3a9a18=(await eo())['transaction'](kt),_0x522e1f=await _0x3a9a18['objectStore'](kt)['get'](to(_0x4ba872));return await _0x3a9a18['done'],_0x522e1f;}catch(_0x2200a6){if(_0x2200a6 instanceof Se)oe['warn'](_0x2200a6['message']);else{const _0x468a37=ge['create']('idb-get',{'originalErrorMessage':_0x2200a6==null?void 0x0:_0x2200a6['message']});oe['warn'](_0x468a37['message']);}}}async function Us(_0x3e174c,_0x221c78){try{const _0x1c1cd3=(await eo())['transaction'](kt,'readwrite');await _0x1c1cd3['objectStore'](kt)['put'](_0x221c78,to(_0x3e174c)),await _0x1c1cd3['done'];}catch(_0x469cb5){if(_0x469cb5 instanceof Se)oe['warn'](_0x469cb5['message']);else{const _0x4a66f6=ge['create']('idb-set',{'originalErrorMessage':_0x469cb5==null?void 0x0:_0x469cb5['message']});oe['warn'](_0x4a66f6['message']);}}}function to(_0x37eec8){return _0x37eec8['name']+'!'+_0x37eec8['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x26597f){this['container']=_0x26597f,this['_heartbeatsCache']=null;const _0x1c5eae=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x1c5eae),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x494952=>(this['_heartbeatsCache']=_0x494952,_0x494952));}async['triggerHeartbeat'](){var _0x52fb03,_0x570bd7;try{const _0x1f3335=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x1599a9=Ws();if(((_0x52fb03=this['_heartbeatsCache'])==null?void 0x0:_0x52fb03['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x570bd7=this['_heartbeatsCache'])==null?void 0x0:_0x570bd7['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x1599a9||this['_heartbeatsCache']['heartbeats']['some'](_0xfd311d=>_0xfd311d['date']===_0x1599a9))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x1599a9,'agent':_0x1f3335}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x3c813c=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x3c813c,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0xb4cb7c){oe['warn'](_0xb4cb7c);}}async['getHeartbeatsHeader'](){var _0x374087;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x374087=this['_heartbeatsCache'])==null?void 0x0:_0x374087['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x15e69a=Ws(),{heartbeatsToSend:_0x39bc44,unsentEntries:_0x36395d}=Ol(this['_heartbeatsCache']['heartbeats']),_0x5de3c2=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x39bc44}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x15e69a,_0x36395d['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x36395d,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x5de3c2;}catch(_0x57cd4b){return oe['warn'](_0x57cd4b),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x1684c9,_0x2f90cf=kl){const _0x4766c7=[];let _0x5153a9=_0x1684c9['slice']();for(const _0x5bc2be of _0x1684c9){const _0x1b4c4c=_0x4766c7['find'](_0x1427e4=>_0x1427e4['agent']===_0x5bc2be['agent']);if(_0x1b4c4c){if(_0x1b4c4c['dates']['push'](_0x5bc2be['date']),Bs(_0x4766c7)>_0x2f90cf){_0x1b4c4c['dates']['pop']();break;}}else{if(_0x4766c7['push']({'agent':_0x5bc2be['agent'],'dates':[_0x5bc2be['date']]}),Bs(_0x4766c7)>_0x2f90cf){_0x4766c7['pop']();break;}}_0x5153a9=_0x5153a9['slice'](0x1);}return{'heartbeatsToSend':_0x4766c7,'unsentEntries':_0x5153a9};}class Dl{constructor(_0x59d3cf){this['app']=_0x59d3cf,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x24b978=await Al(this['app']);return _0x24b978!=null&&_0x24b978['heartbeats']?_0x24b978:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x5927e9){if(await this['_canUseIndexedDBPromise']){const _0x4e8204=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x5927e9['lastSentHeartbeatDate']??_0x4e8204['lastSentHeartbeatDate'],'heartbeats':_0x5927e9['heartbeats']});}else return;}async['add'](_0x92bfba){if(await this['_canUseIndexedDBPromise']){const _0x404229=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x92bfba['lastSentHeartbeatDate']??_0x404229['lastSentHeartbeatDate'],'heartbeats':[..._0x404229['heartbeats'],..._0x92bfba['heartbeats']]});}else return;}}function Bs(_0x319f7d){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x319f7d}))['length'];}function Ml(_0x5579d6){if(_0x5579d6['length']===0x0)return-0x1;let _0x8242b8=0x0,_0x4dd747=_0x5579d6[0x0]['date'];for(let _0x507563=0x1;_0x507563<_0x5579d6['length'];_0x507563++)_0x5579d6[_0x507563]['date']<_0x4dd747&&(_0x4dd747=_0x5579d6[_0x507563]['date'],_0x8242b8=_0x507563);return _0x8242b8;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x44d278){Ze(new Le('platform-logger',_0x14ef01=>new jc(_0x14ef01),'PRIVATE')),Ze(new Le('heartbeat',_0x2065a4=>new Pl(_0x2065a4),'PRIVATE')),me(pi,xs,_0x44d278),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x43a02e){no=_0x43a02e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x28e1e2){this['domStorage_']=_0x28e1e2,this['prefix_']='firebase:';}['set'](_0x55ca05,_0xd9f225){_0xd9f225==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x55ca05)):this['domStorage_']['setItem'](this['prefixedName_'](_0x55ca05),O(_0xd9f225));}['get'](_0xafee93){const _0x243d33=this['domStorage_']['getItem'](this['prefixedName_'](_0xafee93));return _0x243d33==null?null:At(_0x243d33);}['remove'](_0x3b5375){this['domStorage_']['removeItem'](this['prefixedName_'](_0x3b5375));}['prefixedName_'](_0x5b10f5){return this['prefix_']+_0x5b10f5;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x12b4e5,_0x267c37){_0x267c37==null?delete this['cache_'][_0x12b4e5]:this['cache_'][_0x12b4e5]=_0x267c37;}['get'](_0x9862b6){return J(this['cache_'],_0x9862b6)?this['cache_'][_0x9862b6]:null;}['remove'](_0x4fde37){delete this['cache_'][_0x4fde37];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x8b7a26){try{if(typeof window<'u'&&typeof window[_0x8b7a26]<'u'){const _0x5818e3=window[_0x8b7a26];return _0x5818e3['setItem']('firebase:sentinel','cache'),_0x5818e3['removeItem']('firebase:sentinel'),new Wl(_0x5818e3);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x4bd9f2=0x1;return function(){return _0x4bd9f2++;};}()),ro=function(_0x28aad1){const _0x2b62f6=Rc(_0x28aad1),_0x38310f=new Cc();_0x38310f['update'](_0x2b62f6);const _0x3ed388=_0x38310f['digest']();return Li['encodeByteArray'](_0x3ed388);},Vt=function(..._0xf3519e){let _0xf62b54='';for(let _0x5cfdf0=0x0;_0x5cfdf0<_0xf3519e['length'];_0x5cfdf0++){const _0x41ade8=_0xf3519e[_0x5cfdf0];Array['isArray'](_0x41ade8)||_0x41ade8&&typeof _0x41ade8=='object'&&typeof _0x41ade8['length']=='number'?_0xf62b54+=Vt['apply'](null,_0x41ade8):typeof _0x41ade8=='object'?_0xf62b54+=O(_0x41ade8):_0xf62b54+=_0x41ade8,_0xf62b54+='\x20';}return _0xf62b54;};let wt=null,Gs=!0x0;const Hl=function(_0x51f2ba,_0x1117fe){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x20d39a){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x67e4f9=Vt['apply'](null,_0x20d39a);wt(_0x67e4f9);}},Ht=function(_0x489cb2){return function(..._0x2dc93f){L(_0x489cb2,..._0x2dc93f);};},yi=function(..._0x38dd76){const _0x553241='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x38dd76);Ye['error'](_0x553241);},ae=function(..._0x5b9e21){const _0x10dbc0='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x5b9e21);throw Ye['error'](_0x10dbc0),new Error(_0x10dbc0);},U=function(..._0xbae862){const _0x3935d6='FIREBASE\x20WARNING:\x20'+Vt(..._0xbae862);Ye['warn'](_0x3935d6);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x19450c){return typeof _0x19450c=='number'&&(_0x19450c!==_0x19450c||_0x19450c===Number['POSITIVE_INFINITY']||_0x19450c===Number['NEGATIVE_INFINITY']);},Gl=function(_0x493d1f){if(document['readyState']==='complete')_0x493d1f();else{let _0x28d803=!0x1;const _0x443f89=function(){if(!document['body']){setTimeout(_0x443f89,Math['floor'](0xa));return;}_0x28d803||(_0x28d803=!0x0,_0x493d1f());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x443f89,!0x1),window['addEventListener']('load',_0x443f89,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x443f89();}),window['attachEvent']('onload',_0x443f89));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x2b6816,_0x5c06c2){if(_0x2b6816===_0x5c06c2)return 0x0;if(_0x2b6816===Fe||_0x5c06c2===Ie)return-0x1;if(_0x5c06c2===Fe||_0x2b6816===Ie)return 0x1;{const _0x4de0cb=qs(_0x2b6816),_0xafad8e=qs(_0x5c06c2);return _0x4de0cb!==null?_0xafad8e!==null?_0x4de0cb-_0xafad8e===0x0?_0x2b6816['length']-_0x5c06c2['length']:_0x4de0cb-_0xafad8e:-0x1:_0xafad8e!==null?0x1:_0x2b6816<_0x5c06c2?-0x1:0x1;}},ql=function(_0x51f2f1,_0x456376){return _0x51f2f1===_0x456376?0x0:_0x51f2f1<_0x456376?-0x1:0x1;},_t=function(_0x59aedc,_0x344077){if(_0x344077&&_0x59aedc in _0x344077)return _0x344077[_0x59aedc];throw new Error('Missing\x20required\x20key\x20('+_0x59aedc+')\x20in\x20object:\x20'+O(_0x344077));},Hi=function(_0x3d7678){if(typeof _0x3d7678!='object'||_0x3d7678===null)return O(_0x3d7678);const _0x396739=[];for(const _0x37f14d in _0x3d7678)_0x396739['push'](_0x37f14d);_0x396739['sort']();let _0x261c29='{';for(let _0xf79987=0x0;_0xf79987<_0x396739['length'];_0xf79987++)_0xf79987!==0x0&&(_0x261c29+=','),_0x261c29+=O(_0x396739[_0xf79987]),_0x261c29+=':',_0x261c29+=Hi(_0x3d7678[_0x396739[_0xf79987]]);return _0x261c29+='}',_0x261c29;},oo=function(_0x16a20f,_0x5709b4){const _0x50da2b=_0x16a20f['length'];if(_0x50da2b<=_0x5709b4)return[_0x16a20f];const _0x4484f7=[];for(let _0x47f12f=0x0;_0x47f12f<_0x50da2b;_0x47f12f+=_0x5709b4)_0x47f12f+_0x5709b4>_0x50da2b?_0x4484f7['push'](_0x16a20f['substring'](_0x47f12f,_0x50da2b)):_0x4484f7['push'](_0x16a20f['substring'](_0x47f12f,_0x47f12f+_0x5709b4));return _0x4484f7;};function x(_0x41ea33,_0x4e4cf1){for(const _0x21ce19 in _0x41ea33)_0x41ea33['hasOwnProperty'](_0x21ce19)&&_0x4e4cf1(_0x21ce19,_0x41ea33[_0x21ce19]);}const ao=function(_0x132bdf){f(!Vi(_0x132bdf),'Invalid\x20JSON\x20number');const _0x45c11c=0xb,_0x57f9ae=0x34,_0x11f483=(0x1<<_0x45c11c-0x1)-0x1;let _0x56adca,_0x224b6c,_0x506735,_0xbed6ff,_0x38ab24;_0x132bdf===0x0?(_0x224b6c=0x0,_0x506735=0x0,_0x56adca=0x1/_0x132bdf===-0x1/0x0?0x1:0x0):(_0x56adca=_0x132bdf<0x0,_0x132bdf=Math['abs'](_0x132bdf),_0x132bdf>=Math['pow'](0x2,0x1-_0x11f483)?(_0xbed6ff=Math['min'](Math['floor'](Math['log'](_0x132bdf)/Math['LN2']),_0x11f483),_0x224b6c=_0xbed6ff+_0x11f483,_0x506735=Math['round'](_0x132bdf*Math['pow'](0x2,_0x57f9ae-_0xbed6ff)-Math['pow'](0x2,_0x57f9ae))):(_0x224b6c=0x0,_0x506735=Math['round'](_0x132bdf/Math['pow'](0x2,0x1-_0x11f483-_0x57f9ae))));const _0x111a2d=[];for(_0x38ab24=_0x57f9ae;_0x38ab24;_0x38ab24-=0x1)_0x111a2d['push'](_0x506735%0x2?0x1:0x0),_0x506735=Math['floor'](_0x506735/0x2);for(_0x38ab24=_0x45c11c;_0x38ab24;_0x38ab24-=0x1)_0x111a2d['push'](_0x224b6c%0x2?0x1:0x0),_0x224b6c=Math['floor'](_0x224b6c/0x2);_0x111a2d['push'](_0x56adca?0x1:0x0),_0x111a2d['reverse']();const _0x183708=_0x111a2d['join']('');let _0x18d14d='';for(_0x38ab24=0x0;_0x38ab24<0x40;_0x38ab24+=0x8){let _0x18de66=parseInt(_0x183708['substr'](_0x38ab24,0x8),0x2)['toString'](0x10);_0x18de66['length']===0x1&&(_0x18de66='0'+_0x18de66),_0x18d14d=_0x18d14d+_0x18de66;}return _0x18d14d['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x53d8ed,_0x16df02){let _0x47f9bc='Unknown\x20Error';_0x53d8ed==='too_big'?_0x47f9bc='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x53d8ed==='permission_denied'?_0x47f9bc='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x53d8ed==='unavailable'&&(_0x47f9bc='The\x20service\x20is\x20unavailable');const _0x117392=new Error(_0x53d8ed+'\x20at\x20'+_0x16df02['_path']['toString']()+':\x20'+_0x47f9bc);return _0x117392['code']=_0x53d8ed['toUpperCase'](),_0x117392;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x47b2eb){if(Yl['test'](_0x47b2eb)){const _0x551811=Number(_0x47b2eb);if(_0x551811>=Ql&&_0x551811<=Jl)return _0x551811;}return null;},ht=function(_0x25bea7){try{_0x25bea7();}catch(_0x34a30a){setTimeout(()=>{const _0x5c780d=_0x34a30a['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x5c780d),_0x34a30a;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x2b32dd,_0x3dfc72){const _0x5d9cd5=setTimeout(_0x2b32dd,_0x3dfc72);return typeof _0x5d9cd5=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x5d9cd5):typeof _0x5d9cd5=='object'&&_0x5d9cd5['unref']&&_0x5d9cd5['unref'](),_0x5d9cd5;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x25d9b2,_0x4699d1){this['appCheckProvider']=_0x4699d1,this['appName']=_0x25d9b2['name'],$(_0x25d9b2)&&_0x25d9b2['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x25d9b2['settings']['appCheckToken']),this['appCheck']=_0x4699d1==null?void 0x0:_0x4699d1['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4699d1==null||_0x4699d1['get']()['then'](_0x131c02=>this['appCheck']=_0x131c02);}['getToken'](_0x307256){if(this['serverAppAppCheckToken']){if(_0x307256)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x307256):new Promise((_0x52becd,_0x3751aa)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x307256)['then'](_0x52becd,_0x3751aa):_0x52becd(null);},0x0);});}['addTokenChangeListener'](_0x2797ba){var _0x53cf9b;(_0x53cf9b=this['appCheckProvider'])==null||_0x53cf9b['get']()['then'](_0x4b7949=>_0x4b7949['addTokenListener'](_0x2797ba));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x6ce328,_0x210022,_0x13dd3c){this['appName_']=_0x6ce328,this['firebaseOptions_']=_0x210022,this['authProvider_']=_0x13dd3c,this['auth_']=null,this['auth_']=_0x13dd3c['getImmediate']({'optional':!0x0}),this['auth_']||_0x13dd3c['onInit'](_0x41cb93=>this['auth_']=_0x41cb93);}['getToken'](_0x625ab6){return this['auth_']?this['auth_']['getToken'](_0x625ab6)['catch'](_0x2d6c96=>_0x2d6c96&&_0x2d6c96['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x2d6c96)):new Promise((_0x498356,_0x3f7104)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x625ab6)['then'](_0x498356,_0x3f7104):_0x498356(null);},0x0);});}['addTokenChangeListener'](_0x1b355d){this['auth_']?this['auth_']['addAuthTokenListener'](_0x1b355d):this['authProvider_']['get']()['then'](_0x4ee2b3=>_0x4ee2b3['addAuthTokenListener'](_0x1b355d));}['removeTokenChangeListener'](_0x37ad76){this['authProvider_']['get']()['then'](_0x535dd8=>_0x535dd8['removeAuthTokenListener'](_0x37ad76));}['notifyForInvalidToken'](){let _0x37e542='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x37e542+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x37e542+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x37e542+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x37e542);}}class nn{constructor(_0x3e3090){this['accessToken']=_0x3e3090;}['getToken'](_0x57fd8d){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x1e0746){_0x1e0746(this['accessToken']);}['removeTokenChangeListener'](_0x4c7127){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x47d262,_0x56e6fe,_0x577773,_0x53b027,_0x3b33a2=!0x1,_0x39a3e2='',_0x372e87=!0x1,_0x24a830=!0x1,_0x18e421=null){this['secure']=_0x56e6fe,this['namespace']=_0x577773,this['webSocketOnly']=_0x53b027,this['nodeAdmin']=_0x3b33a2,this['persistenceKey']=_0x39a3e2,this['includeNamespaceInQueryParams']=_0x372e87,this['isUsingEmulator']=_0x24a830,this['emulatorOptions']=_0x18e421,this['_host']=_0x47d262['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x47d262)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x4176fe){_0x4176fe!==this['internalHost']&&(this['internalHost']=_0x4176fe,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x47f62b=this['toURLString']();return this['persistenceKey']&&(_0x47f62b+='<'+this['persistenceKey']+'>'),_0x47f62b;}['toURLString'](){const _0x267da4=this['secure']?'https://':'http://',_0x2cc06b=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x267da4+this['host']+'/'+_0x2cc06b;}}function th(_0x5b85f1){return _0x5b85f1['host']!==_0x5b85f1['internalHost']||_0x5b85f1['isCustomHost']()||_0x5b85f1['includeNamespaceInQueryParams'];}function vo(_0x107105,_0x553e95,_0x1bfb25){f(typeof _0x553e95=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x1bfb25=='object','typeof\x20params\x20must\x20==\x20object');let _0x422c54;if(_0x553e95===go)_0x422c54=(_0x107105['secure']?'wss://':'ws://')+_0x107105['internalHost']+'/.ws?';else{if(_0x553e95===mo)_0x422c54=(_0x107105['secure']?'https://':'http://')+_0x107105['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x553e95);}th(_0x107105)&&(_0x1bfb25['ns']=_0x107105['namespace']);const _0x8997ce=[];return x(_0x1bfb25,(_0x4c9293,_0x4c3ea9)=>{_0x8997ce['push'](_0x4c9293+'='+_0x4c3ea9);}),_0x422c54+_0x8997ce['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x4d8c3e,_0x5ec98b=0x1){J(this['counters_'],_0x4d8c3e)||(this['counters_'][_0x4d8c3e]=0x0),this['counters_'][_0x4d8c3e]+=_0x5ec98b;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x1f3fbc){const _0x346365=_0x1f3fbc['toString']();return ni[_0x346365]||(ni[_0x346365]=new nh()),ni[_0x346365];}function ih(_0x29364b,_0x30d233){const _0x57be1f=_0x29364b['toString']();return ii[_0x57be1f]||(ii[_0x57be1f]=_0x30d233()),ii[_0x57be1f];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x54ae67){this['onMessage_']=_0x54ae67,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x9d7199,_0x1b150c){this['closeAfterResponse']=_0x9d7199,this['onClose']=_0x1b150c,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x3a43fe,_0x530c59){for(this['pendingResponses'][_0x3a43fe]=_0x530c59;this['pendingResponses'][this['currentResponseNum']];){const _0x3d3235=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x249b97=0x0;_0x249b97<_0x3d3235['length'];++_0x249b97)_0x3d3235[_0x249b97]&&ht(()=>{this['onMessage_'](_0x3d3235[_0x249b97]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x3e9536,_0x11f100,_0x154b95,_0x31a82b,_0x306298,_0xc930fd,_0x182593){this['connId']=_0x3e9536,this['repoInfo']=_0x11f100,this['applicationId']=_0x154b95,this['appCheckToken']=_0x31a82b,this['authToken']=_0x306298,this['transportSessionId']=_0xc930fd,this['lastSessionId']=_0x182593,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x3e9536),this['stats_']=Gi(_0x11f100),this['urlFn']=_0x3406cd=>(this['appCheckToken']&&(_0x3406cd[vi]=this['appCheckToken']),vo(_0x11f100,mo,_0x3406cd));}['open'](_0x38f6ee,_0x3be23c){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x3be23c,this['myPacketOrderer']=new sh(_0x38f6ee),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x5929c6)=>{const [_0x2392eb,_0x260757,_0x5d186a,_0x232c35,_0x525e3a]=_0x5929c6;if(this['incrementIncomingBytes_'](_0x5929c6),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x2392eb===zs)this['id']=_0x260757,this['password']=_0x5d186a;else{if(_0x2392eb===rh)_0x260757?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x260757,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x2392eb);}}},(..._0x335066)=>{const [_0x803148,_0x3a466c]=_0x335066;this['incrementIncomingBytes_'](_0x335066),this['myPacketOrderer']['handleResponse'](_0x803148,_0x3a466c);},()=>{this['onClosed_']();},this['urlFn']);const _0x3c11df={};_0x3c11df[zs]='t',_0x3c11df[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x3c11df[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x3c11df[co]=$i,this['transportSessionId']&&(_0x3c11df[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x3c11df[po]=this['lastSessionId']),this['applicationId']&&(_0x3c11df[_o]=this['applicationId']),this['appCheckToken']&&(_0x3c11df[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3c11df[ho]=uo);const _0x33f746=this['urlFn'](_0x3c11df);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x33f746),this['scriptTagHolder']['addTag'](_0x33f746,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x120a18){const _0x4e480c=O(_0x120a18);this['bytesSent']+=_0x4e480c['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4e480c['length']);const _0x5eb0ad=Hr(_0x4e480c),_0x4aef60=oo(_0x5eb0ad,fh);for(let _0x30c9f4=0x0;_0x30c9f4<_0x4aef60['length'];_0x30c9f4++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x4aef60['length'],_0x4aef60[_0x30c9f4]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x215260,_0x27d329){this['myDisconnFrame']=document['createElement']('iframe');const _0x3000aa={};_0x3000aa[dh]='t',_0x3000aa[Eo]=_0x215260,_0x3000aa[Io]=_0x27d329,this['myDisconnFrame']['src']=this['urlFn'](_0x3000aa),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x4d065a){const _0x6eb04e=O(_0x4d065a)['length'];this['bytesReceived']+=_0x6eb04e,this['stats_']['incrementCounter']('bytes_received',_0x6eb04e);}}class qi{constructor(_0x19fdb4,_0x20ceaa,_0x3b8e75,_0x590563){this['onDisconnect']=_0x3b8e75,this['urlFn']=_0x590563,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x19fdb4,window[ah+this['uniqueCallbackIdentifier']]=_0x20ceaa,this['myIFrame']=qi['createIFrame_']();let _0x24e91c='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x24e91c='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x51bba9='<html><body>'+_0x24e91c+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x51bba9),this['myIFrame']['doc']['close']();}catch(_0x55ea30){L('frame\x20writing\x20exception'),_0x55ea30['stack']&&L(_0x55ea30['stack']),L(_0x55ea30);}}}static['createIFrame_'](){const _0x862031=document['createElement']('iframe');if(_0x862031['style']['display']='none',document['body']){document['body']['appendChild'](_0x862031);try{_0x862031['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x3576b5=document['domain'];_0x862031['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x3576b5+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x862031['contentDocument']?_0x862031['doc']=_0x862031['contentDocument']:_0x862031['contentWindow']?_0x862031['doc']=_0x862031['contentWindow']['document']:_0x862031['document']&&(_0x862031['doc']=_0x862031['document']),_0x862031;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x1700f5=this['onDisconnect'];_0x1700f5&&(this['onDisconnect']=null,_0x1700f5());}['startLongPoll'](_0x1fdf6e,_0x52955a){for(this['myID']=_0x1fdf6e,this['myPW']=_0x52955a,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x426453={};_0x426453[Eo]=this['myID'],_0x426453[Io]=this['myPW'],_0x426453[wo]=this['currentSerial'];let _0xd6f8d8=this['urlFn'](_0x426453),_0x49146b='',_0x5ad0de=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x49146b['length']<=Co;){const _0x4547a5=this['pendingSegs']['shift']();_0x49146b=_0x49146b+'&'+lh+_0x5ad0de+'='+_0x4547a5['seg']+'&'+hh+_0x5ad0de+'='+_0x4547a5['ts']+'&'+uh+_0x5ad0de+'='+_0x4547a5['d'],_0x5ad0de++;}return _0xd6f8d8=_0xd6f8d8+_0x49146b,this['addLongPollTag_'](_0xd6f8d8,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x2b20df,_0x35973f,_0x40b23a){this['pendingSegs']['push']({'seg':_0x2b20df,'ts':_0x35973f,'d':_0x40b23a}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x2e634a,_0x3505c2){this['outstandingRequests']['add'](_0x3505c2);const _0x22abdc=()=>{this['outstandingRequests']['delete'](_0x3505c2),this['newRequest_']();},_0x4cdaf3=setTimeout(_0x22abdc,Math['floor'](ph)),_0x1d36d2=()=>{clearTimeout(_0x4cdaf3),_0x22abdc();};this['addTag'](_0x2e634a,_0x1d36d2);}['addTag'](_0x3640b1,_0x478104){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0xe1f021=this['myIFrame']['doc']['createElement']('script');_0xe1f021['type']='text/javascript',_0xe1f021['async']=!0x0,_0xe1f021['src']=_0x3640b1,_0xe1f021['onload']=_0xe1f021['onreadystatechange']=function(){const _0x2b36d8=_0xe1f021['readyState'];(!_0x2b36d8||_0x2b36d8==='loaded'||_0x2b36d8==='complete')&&(_0xe1f021['onload']=_0xe1f021['onreadystatechange']=null,_0xe1f021['parentNode']&&_0xe1f021['parentNode']['removeChild'](_0xe1f021),_0x478104());},_0xe1f021['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x3640b1),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0xe1f021);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x536dc0,_0x32fcc4,_0x582c53,_0x5de955,_0x59437e,_0x429baf,_0x12de8f){this['connId']=_0x536dc0,this['applicationId']=_0x582c53,this['appCheckToken']=_0x5de955,this['authToken']=_0x59437e,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x32fcc4),this['connURL']=z['connectionURL_'](_0x32fcc4,_0x429baf,_0x12de8f,_0x5de955,_0x582c53),this['nodeAdmin']=_0x32fcc4['nodeAdmin'];}static['connectionURL_'](_0x36aa5d,_0x471f2c,_0xe3368a,_0x3320e1,_0x478c80){const _0x734ee2={};return _0x734ee2[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x734ee2[ho]=uo),_0x471f2c&&(_0x734ee2[lo]=_0x471f2c),_0xe3368a&&(_0x734ee2[po]=_0xe3368a),_0x3320e1&&(_0x734ee2[vi]=_0x3320e1),_0x478c80&&(_0x734ee2[_o]=_0x478c80),vo(_0x36aa5d,go,_0x734ee2);}['open'](_0x412dbf,_0x643b35){this['onDisconnect']=_0x643b35,this['onMessage']=_0x412dbf,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x216d4b;_c(),this['mySock']=new un(this['connURL'],[],_0x216d4b);}catch(_0x2ef3ae){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x34f6e6=_0x2ef3ae['message']||_0x2ef3ae['data'];_0x34f6e6&&this['log_'](_0x34f6e6),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x7919b6=>{this['handleIncomingFrame'](_0x7919b6);},this['mySock']['onerror']=_0x4333d8=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x2892e0=_0x4333d8['message']||_0x4333d8['data'];_0x2892e0&&this['log_'](_0x2892e0),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x2e322e=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x4f53cd=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x1938d2=navigator['userAgent']['match'](_0x4f53cd);_0x1938d2&&_0x1938d2['length']>0x1&&parseFloat(_0x1938d2[0x1])<4.4&&(_0x2e322e=!0x0);}return!_0x2e322e&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x13c2c8){if(this['frames']['push'](_0x13c2c8),this['frames']['length']===this['totalFrames']){const _0x1287f0=this['frames']['join']('');this['frames']=null;const _0x573d91=At(_0x1287f0);this['onMessage'](_0x573d91);}}['handleNewFrameCount_'](_0x2bbbfa){this['totalFrames']=_0x2bbbfa,this['frames']=[];}['extractFrameCount_'](_0x346a92){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x346a92['length']<=0x6){const _0x6b57e=Number(_0x346a92);if(!isNaN(_0x6b57e))return this['handleNewFrameCount_'](_0x6b57e),null;}return this['handleNewFrameCount_'](0x1),_0x346a92;}['handleIncomingFrame'](_0x4b8e82){if(this['mySock']===null)return;const _0x22c93b=_0x4b8e82['data'];if(this['bytesReceived']+=_0x22c93b['length'],this['stats_']['incrementCounter']('bytes_received',_0x22c93b['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x22c93b);else{const _0x564ab0=this['extractFrameCount_'](_0x22c93b);_0x564ab0!==null&&this['appendFrame_'](_0x564ab0);}}['send'](_0x2418d2){this['resetKeepAlive']();const _0x4ab3d8=O(_0x2418d2);this['bytesSent']+=_0x4ab3d8['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4ab3d8['length']);const _0x12cedf=oo(_0x4ab3d8,gh);_0x12cedf['length']>0x1&&this['sendString_'](String(_0x12cedf['length']));for(let _0x4fdabe=0x0;_0x4fdabe<_0x12cedf['length'];_0x4fdabe++)this['sendString_'](_0x12cedf[_0x4fdabe]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x10e9da){try{this['mySock']['send'](_0x10e9da);}catch(_0x27b427){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x27b427['message']||_0x27b427['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x258a9d){this['initTransports_'](_0x258a9d);}['initTransports_'](_0x3c7406){const _0x9a54d9=z&&z['isAvailable']();let _0x3d5ad4=_0x9a54d9&&!z['previouslyFailed']();if(_0x3c7406['webSocketOnly']&&(_0x9a54d9||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x3d5ad4=!0x0),_0x3d5ad4)this['transports_']=[z];else{const _0x2f937f=this['transports_']=[];for(const _0x5548e8 of Nt['ALL_TRANSPORTS'])_0x5548e8&&_0x5548e8['isAvailable']()&&_0x2f937f['push'](_0x5548e8);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0xbc3a17,_0x1b96e6,_0x3dde09,_0x1e75ec,_0x9c9c94,_0x3b6338,_0x2b908f,_0x1f872b,_0xbfce80,_0x209f08){this['id']=_0xbc3a17,this['repoInfo_']=_0x1b96e6,this['applicationId_']=_0x3dde09,this['appCheckToken_']=_0x1e75ec,this['authToken_']=_0x9c9c94,this['onMessage_']=_0x3b6338,this['onReady_']=_0x2b908f,this['onDisconnect_']=_0x1f872b,this['onKill_']=_0xbfce80,this['lastSessionId']=_0x209f08,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x1b96e6),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x1919ab=this['transportManager_']['initialTransport']();this['conn_']=new _0x1919ab(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x1919ab['responsesRequiredToBeHealthy']||0x0;const _0x2b14e2=this['connReceiver_'](this['conn_']),_0x11dbe3=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x2b14e2,_0x11dbe3);},Math['floor'](0x0));const _0x415e8d=_0x1919ab['healthyTimeout']||0x0;_0x415e8d>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x415e8d)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x61f6cb){return _0x45f7fc=>{_0x61f6cb===this['conn_']?this['onConnectionLost_'](_0x45f7fc):_0x61f6cb===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x54a097){return _0x2ff733=>{this['state_']!==0x2&&(_0x54a097===this['rx_']?this['onPrimaryMessageReceived_'](_0x2ff733):_0x54a097===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x2ff733):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x5776e6){const _0x23bcd9={'t':'d','d':_0x5776e6};this['sendData_'](_0x23bcd9);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x31e1c6){if(si in _0x31e1c6){const _0x108f50=_0x31e1c6[si];_0x108f50===Qs?this['upgradeIfSecondaryHealthy_']():_0x108f50===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x108f50===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x1cec33){const _0x4ee6a2=_t('t',_0x1cec33),_0x2ba45b=_t('d',_0x1cec33);if(_0x4ee6a2==='c')this['onSecondaryControl_'](_0x2ba45b);else{if(_0x4ee6a2==='d')this['pendingDataMessages']['push'](_0x2ba45b);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x4ee6a2);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x10b3d9){const _0x203568=_t('t',_0x10b3d9),_0x41e099=_t('d',_0x10b3d9);_0x203568==='c'?this['onControl_'](_0x41e099):_0x203568==='d'&&this['onDataMessage_'](_0x41e099);}['onDataMessage_'](_0x19dc69){this['onPrimaryResponse_'](),this['onMessage_'](_0x19dc69);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x3e1f0c){const _0x45da3d=_t(si,_0x3e1f0c);if(js in _0x3e1f0c){const _0x21c0e7=_0x3e1f0c[js];if(_0x45da3d===Th){const _0x269f91={..._0x21c0e7};this['repoInfo_']['isUsingEmulator']&&(_0x269f91['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x269f91);}else{if(_0x45da3d===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x5190ca=0x0;_0x5190ca<this['pendingDataMessages']['length'];++_0x5190ca)this['onDataMessage_'](this['pendingDataMessages'][_0x5190ca]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x45da3d===wh?this['onConnectionShutdown_'](_0x21c0e7):_0x45da3d===Ks?this['onReset_'](_0x21c0e7):_0x45da3d===Ch?yi('Server\x20Error:\x20'+_0x21c0e7):_0x45da3d===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x45da3d);}}}['onHandshake_'](_0x100cba){const _0x3f079d=_0x100cba['ts'],_0xcb8a9d=_0x100cba['v'],_0x4d326e=_0x100cba['h'];this['sessionId']=_0x100cba['s'],this['repoInfo_']['host']=_0x4d326e,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x3f079d),$i!==_0xcb8a9d&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x458c47=this['transportManager_']['upgradeTransport']();_0x458c47&&this['startUpgrade_'](_0x458c47);}['startUpgrade_'](_0x402815){this['secondaryConn_']=new _0x402815(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x402815['responsesRequiredToBeHealthy']||0x0;const _0x46fd60=this['connReceiver_'](this['secondaryConn_']),_0x547d40=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x46fd60,_0x547d40),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x6b3194){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x6b3194),this['repoInfo_']['host']=_0x6b3194,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x405461,_0x424ffd){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x405461,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x424ffd,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x3fd966=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x3fd966||this['rx_']===_0x3fd966)&&this['close']();}['onConnectionLost_'](_0x567c78){this['conn_']=null,!_0x567c78&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x272290){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x272290),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0xee71c5){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0xee71c5);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x27858b,_0xfa8d0e,_0x2797fb,_0x3657a1){}['merge'](_0x5ca712,_0x51a2b1,_0x11a020,_0x149a9c){}['refreshAuthToken'](_0x3b7304){}['refreshAppCheckToken'](_0x39611){}['onDisconnectPut'](_0x3d923b,_0x44cb89,_0x41ded0){}['onDisconnectMerge'](_0x498851,_0x3a8c27,_0x5511f5){}['onDisconnectCancel'](_0x49af46,_0x11b400){}['reportStats'](_0x32b0f5){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x21a67b){this['allowedEvents_']=_0x21a67b,this['listeners_']={},f(Array['isArray'](_0x21a67b)&&_0x21a67b['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x5d875c,..._0x1a9eef){if(Array['isArray'](this['listeners_'][_0x5d875c])){const _0x48abc4=[...this['listeners_'][_0x5d875c]];for(let _0x321732=0x0;_0x321732<_0x48abc4['length'];_0x321732++)_0x48abc4[_0x321732]['callback']['apply'](_0x48abc4[_0x321732]['context'],_0x1a9eef);}}['on'](_0x433541,_0x1df6f0,_0x18b343){this['validateEventType_'](_0x433541),this['listeners_'][_0x433541]=this['listeners_'][_0x433541]||[],this['listeners_'][_0x433541]['push']({'callback':_0x1df6f0,'context':_0x18b343});const _0x48d19d=this['getInitialEvent'](_0x433541);_0x48d19d&&_0x1df6f0['apply'](_0x18b343,_0x48d19d);}['off'](_0x309e3d,_0x5f342d,_0x523da5){this['validateEventType_'](_0x309e3d);const _0x2821fe=this['listeners_'][_0x309e3d]||[];for(let _0x512d66=0x0;_0x512d66<_0x2821fe['length'];_0x512d66++)if(_0x2821fe[_0x512d66]['callback']===_0x5f342d&&(!_0x523da5||_0x523da5===_0x2821fe[_0x512d66]['context'])){_0x2821fe['splice'](_0x512d66,0x1);return;}}['validateEventType_'](_0xb71158){f(this['allowedEvents_']['find'](_0x174592=>_0x174592===_0xb71158),'Unknown\x20event:\x20'+_0xb71158);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x582a6c){return f(_0x582a6c==='online','Unknown\x20event\x20type:\x20'+_0x582a6c),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x2bc216,_0x1309ca){if(_0x1309ca===void 0x0){this['pieces_']=_0x2bc216['split']('/');let _0x16934f=0x0;for(let _0x43e256=0x0;_0x43e256<this['pieces_']['length'];_0x43e256++)this['pieces_'][_0x43e256]['length']>0x0&&(this['pieces_'][_0x16934f]=this['pieces_'][_0x43e256],_0x16934f++);this['pieces_']['length']=_0x16934f,this['pieceNum_']=0x0;}else this['pieces_']=_0x2bc216,this['pieceNum_']=_0x1309ca;}['toString'](){let _0x5bcb05='';for(let _0x24704d=this['pieceNum_'];_0x24704d<this['pieces_']['length'];_0x24704d++)this['pieces_'][_0x24704d]!==''&&(_0x5bcb05+='/'+this['pieces_'][_0x24704d]);return _0x5bcb05||'/';}}function w(){return new C('');}function y(_0x2b3dd1){return _0x2b3dd1['pieceNum_']>=_0x2b3dd1['pieces_']['length']?null:_0x2b3dd1['pieces_'][_0x2b3dd1['pieceNum_']];}function we(_0xbf0b9f){return _0xbf0b9f['pieces_']['length']-_0xbf0b9f['pieceNum_'];}function b(_0x45a661){let _0x36e36d=_0x45a661['pieceNum_'];return _0x36e36d<_0x45a661['pieces_']['length']&&_0x36e36d++,new C(_0x45a661['pieces_'],_0x36e36d);}function zi(_0x5ad2e7){return _0x5ad2e7['pieceNum_']<_0x5ad2e7['pieces_']['length']?_0x5ad2e7['pieces_'][_0x5ad2e7['pieces_']['length']-0x1]:null;}function bh(_0x498f76){let _0x4b1d6d='';for(let _0x321392=_0x498f76['pieceNum_'];_0x321392<_0x498f76['pieces_']['length'];_0x321392++)_0x498f76['pieces_'][_0x321392]!==''&&(_0x4b1d6d+='/'+encodeURIComponent(String(_0x498f76['pieces_'][_0x321392])));return _0x4b1d6d||'/';}function Pt(_0x311108,_0x2ca08d=0x0){return _0x311108['pieces_']['slice'](_0x311108['pieceNum_']+_0x2ca08d);}function Ro(_0x172ec7){if(_0x172ec7['pieceNum_']>=_0x172ec7['pieces_']['length'])return null;const _0x1ab168=[];for(let _0x2c0dd1=_0x172ec7['pieceNum_'];_0x2c0dd1<_0x172ec7['pieces_']['length']-0x1;_0x2c0dd1++)_0x1ab168['push'](_0x172ec7['pieces_'][_0x2c0dd1]);return new C(_0x1ab168,0x0);}function k(_0x25202a,_0x436b67){const _0x1b053f=[];for(let _0x276cb3=_0x25202a['pieceNum_'];_0x276cb3<_0x25202a['pieces_']['length'];_0x276cb3++)_0x1b053f['push'](_0x25202a['pieces_'][_0x276cb3]);if(_0x436b67 instanceof C){for(let _0x20810a=_0x436b67['pieceNum_'];_0x20810a<_0x436b67['pieces_']['length'];_0x20810a++)_0x1b053f['push'](_0x436b67['pieces_'][_0x20810a]);}else{const _0x6ec844=_0x436b67['split']('/');for(let _0x36b47d=0x0;_0x36b47d<_0x6ec844['length'];_0x36b47d++)_0x6ec844[_0x36b47d]['length']>0x0&&_0x1b053f['push'](_0x6ec844[_0x36b47d]);}return new C(_0x1b053f,0x0);}function v(_0xc4c9fb){return _0xc4c9fb['pieceNum_']>=_0xc4c9fb['pieces_']['length'];}function F(_0x6b1ad,_0x428078){const _0x531cb2=y(_0x6b1ad),_0x35e309=y(_0x428078);if(_0x531cb2===null)return _0x428078;if(_0x531cb2===_0x35e309)return F(b(_0x6b1ad),b(_0x428078));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x428078+')\x20is\x20not\x20within\x20outerPath\x20('+_0x6b1ad+')');}function Rh(_0x333132,_0x8599f5){const _0x1e616a=Pt(_0x333132,0x0),_0x4a070c=Pt(_0x8599f5,0x0);for(let _0x3ab199=0x0;_0x3ab199<_0x1e616a['length']&&_0x3ab199<_0x4a070c['length'];_0x3ab199++){const _0x2aa4ab=He(_0x1e616a[_0x3ab199],_0x4a070c[_0x3ab199]);if(_0x2aa4ab!==0x0)return _0x2aa4ab;}return _0x1e616a['length']===_0x4a070c['length']?0x0:_0x1e616a['length']<_0x4a070c['length']?-0x1:0x1;}function ji(_0x364845,_0x57c742){if(we(_0x364845)!==we(_0x57c742))return!0x1;for(let _0x2ab16a=_0x364845['pieceNum_'],_0x36cc45=_0x57c742['pieceNum_'];_0x2ab16a<=_0x364845['pieces_']['length'];_0x2ab16a++,_0x36cc45++)if(_0x364845['pieces_'][_0x2ab16a]!==_0x57c742['pieces_'][_0x36cc45])return!0x1;return!0x0;}function G(_0x2e1586,_0x459fa6){let _0x39462e=_0x2e1586['pieceNum_'],_0x86285=_0x459fa6['pieceNum_'];if(we(_0x2e1586)>we(_0x459fa6))return!0x1;for(;_0x39462e<_0x2e1586['pieces_']['length'];){if(_0x2e1586['pieces_'][_0x39462e]!==_0x459fa6['pieces_'][_0x86285])return!0x1;++_0x39462e,++_0x86285;}return!0x0;}class Ah{constructor(_0x3ee125,_0x31a942){this['errorPrefix_']=_0x31a942,this['parts_']=Pt(_0x3ee125,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x599c75=0x0;_0x599c75<this['parts_']['length'];_0x599c75++)this['byteLength_']+=On(this['parts_'][_0x599c75]);Ao(this);}}function kh(_0x41cc4e,_0x16a37e){_0x41cc4e['parts_']['length']>0x0&&(_0x41cc4e['byteLength_']+=0x1),_0x41cc4e['parts_']['push'](_0x16a37e),_0x41cc4e['byteLength_']+=On(_0x16a37e),Ao(_0x41cc4e);}function Nh(_0x354893){const _0x30c418=_0x354893['parts_']['pop']();_0x354893['byteLength_']-=On(_0x30c418),_0x354893['parts_']['length']>0x0&&(_0x354893['byteLength_']-=0x1);}function Ao(_0x54f044){if(_0x54f044['byteLength_']>er)throw new Error(_0x54f044['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x54f044['byteLength_']+').');if(_0x54f044['parts_']['length']>Zs)throw new Error(_0x54f044['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x54f044));}function Pe(_0x3b25c5){return _0x3b25c5['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x3b25c5['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x170df0,_0x5ac64e;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x5ac64e='visibilitychange',_0x170df0='hidden'):typeof document['mozHidden']<'u'?(_0x5ac64e='mozvisibilitychange',_0x170df0='mozHidden'):typeof document['msHidden']<'u'?(_0x5ac64e='msvisibilitychange',_0x170df0='msHidden'):typeof document['webkitHidden']<'u'&&(_0x5ac64e='webkitvisibilitychange',_0x170df0='webkitHidden')),this['visible_']=!0x0,_0x5ac64e&&document['addEventListener'](_0x5ac64e,()=>{const _0x4a9d75=!document[_0x170df0];_0x4a9d75!==this['visible_']&&(this['visible_']=_0x4a9d75,this['trigger']('visible',_0x4a9d75));},!0x1);}['getInitialEvent'](_0x4b5bdb){return f(_0x4b5bdb==='visible','Unknown\x20event\x20type:\x20'+_0x4b5bdb),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x6aeeef,_0x2c7528,_0x1132e9,_0x5d41b1,_0xe2bd0,_0x45945d,_0x139ff6,_0x1d0d79){if(super(),this['repoInfo_']=_0x6aeeef,this['applicationId_']=_0x2c7528,this['onDataUpdate_']=_0x1132e9,this['onConnectStatus_']=_0x5d41b1,this['onServerInfoUpdate_']=_0xe2bd0,this['authTokenProvider_']=_0x45945d,this['appCheckTokenProvider_']=_0x139ff6,this['authOverride_']=_0x1d0d79,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x1d0d79)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x6aeeef['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x4f567d,_0x4696fe,_0x402f89){const _0xa14ebd=++this['requestNumber_'],_0x51c7b7={'r':_0xa14ebd,'a':_0x4f567d,'b':_0x4696fe};this['log_'](O(_0x51c7b7)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x51c7b7),_0x402f89&&(this['requestCBHash_'][_0xa14ebd]=_0x402f89);}['get'](_0x5b6bbe){this['initConnection_']();const _0x40c5aa=new ot(),_0x4b45c9={'action':'g','request':{'p':_0x5b6bbe['_path']['toString'](),'q':_0x5b6bbe['_queryObject']},'onComplete':_0x73ed95=>{const _0x899d5f=_0x73ed95['d'];_0x73ed95['s']==='ok'?_0x40c5aa['resolve'](_0x899d5f):_0x40c5aa['reject'](_0x899d5f);}};this['outstandingGets_']['push'](_0x4b45c9),this['outstandingGetCount_']++;const _0x31c7e0=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x31c7e0),_0x40c5aa['promise'];}['listen'](_0x3c1750,_0x28b044,_0x4d14ce,_0x4bef28){this['initConnection_']();const _0x176fcb=_0x3c1750['_queryIdentifier'],_0x500ee9=_0x3c1750['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x500ee9+'\x20'+_0x176fcb),this['listens']['has'](_0x500ee9)||this['listens']['set'](_0x500ee9,new Map()),f(_0x3c1750['_queryParams']['isDefault']()||!_0x3c1750['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x500ee9)['has'](_0x176fcb),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x23400f={'onComplete':_0x4bef28,'hashFn':_0x28b044,'query':_0x3c1750,'tag':_0x4d14ce};this['listens']['get'](_0x500ee9)['set'](_0x176fcb,_0x23400f),this['connected_']&&this['sendListen_'](_0x23400f);}['sendGet_'](_0x2a4b7c){const _0x4067f8=this['outstandingGets_'][_0x2a4b7c];this['sendRequest']('g',_0x4067f8['request'],_0x12275a=>{delete this['outstandingGets_'][_0x2a4b7c],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x4067f8['onComplete']&&_0x4067f8['onComplete'](_0x12275a);});}['sendListen_'](_0x444ca4){const _0x541c40=_0x444ca4['query'],_0x478160=_0x541c40['_path']['toString'](),_0xbffb24=_0x541c40['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x478160+'\x20for\x20'+_0xbffb24);const _0x172b03={'p':_0x478160},_0x104f7a='q';_0x444ca4['tag']&&(_0x172b03['q']=_0x541c40['_queryObject'],_0x172b03['t']=_0x444ca4['tag']),_0x172b03['h']=_0x444ca4['hashFn'](),this['sendRequest'](_0x104f7a,_0x172b03,_0xc7bdbe=>{const _0x30610d=_0xc7bdbe['d'],_0x55aa5d=_0xc7bdbe['s'];se['warnOnListenWarnings_'](_0x30610d,_0x541c40),(this['listens']['get'](_0x478160)&&this['listens']['get'](_0x478160)['get'](_0xbffb24))===_0x444ca4&&(this['log_']('listen\x20response',_0xc7bdbe),_0x55aa5d!=='ok'&&this['removeListen_'](_0x478160,_0xbffb24),_0x444ca4['onComplete']&&_0x444ca4['onComplete'](_0x55aa5d,_0x30610d));});}static['warnOnListenWarnings_'](_0x50b727,_0x281fd0){if(_0x50b727&&typeof _0x50b727=='object'&&J(_0x50b727,'w')){const _0x278b5c=De(_0x50b727,'w');if(Array['isArray'](_0x278b5c)&&~_0x278b5c['indexOf']('no_index')){const _0x9ef535='\x22.indexOn\x22:\x20\x22'+_0x281fd0['_queryParams']['getIndex']()['toString']()+'\x22',_0x3ab82f=_0x281fd0['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x9ef535+'\x20at\x20'+_0x3ab82f+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x98c80e){this['authToken_']=_0x98c80e,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x98c80e);}['reduceReconnectDelayIfAdminCredential_'](_0x173919){(_0x173919&&_0x173919['length']===0x28||wc(_0x173919))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0xc9e201){this['appCheckToken_']=_0xc9e201,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x5ac527=this['authToken_'],_0x502eec=Ic(_0x5ac527)?'auth':'gauth',_0x238a3={'cred':_0x5ac527};this['authOverride_']===null?_0x238a3['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x238a3['authvar']=this['authOverride_']),this['sendRequest'](_0x502eec,_0x238a3,_0x86c6a9=>{const _0x362095=_0x86c6a9['s'],_0x415820=_0x86c6a9['d']||'error';this['authToken_']===_0x5ac527&&(_0x362095==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x362095,_0x415820));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x1b6196=>{const _0x2e70df=_0x1b6196['s'],_0x18c791=_0x1b6196['d']||'error';_0x2e70df==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x2e70df,_0x18c791);});}['unlisten'](_0x1dea6c,_0x1db26d){const _0x4057de=_0x1dea6c['_path']['toString'](),_0x36dc11=_0x1dea6c['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x4057de+'\x20'+_0x36dc11),f(_0x1dea6c['_queryParams']['isDefault']()||!_0x1dea6c['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x4057de,_0x36dc11)&&this['connected_']&&this['sendUnlisten_'](_0x4057de,_0x36dc11,_0x1dea6c['_queryObject'],_0x1db26d);}['sendUnlisten_'](_0x53535e,_0x204c6e,_0x1be624,_0x22ada7){this['log_']('Unlisten\x20on\x20'+_0x53535e+'\x20for\x20'+_0x204c6e);const _0x1794ba={'p':_0x53535e},_0x229451='n';_0x22ada7&&(_0x1794ba['q']=_0x1be624,_0x1794ba['t']=_0x22ada7),this['sendRequest'](_0x229451,_0x1794ba);}['onDisconnectPut'](_0x4bb2dc,_0x1afb36,_0x45838f){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x4bb2dc,_0x1afb36,_0x45838f):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4bb2dc,'action':'o','data':_0x1afb36,'onComplete':_0x45838f});}['onDisconnectMerge'](_0x191b90,_0x408c39,_0x32db6d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x191b90,_0x408c39,_0x32db6d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x191b90,'action':'om','data':_0x408c39,'onComplete':_0x32db6d});}['onDisconnectCancel'](_0x8a475d,_0x1ef2a2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x8a475d,null,_0x1ef2a2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x8a475d,'action':'oc','data':null,'onComplete':_0x1ef2a2});}['sendOnDisconnect_'](_0x55bc23,_0x39d0a1,_0x23a47a,_0x36e9b0){const _0x2379fa={'p':_0x39d0a1,'d':_0x23a47a};this['log_']('onDisconnect\x20'+_0x55bc23,_0x2379fa),this['sendRequest'](_0x55bc23,_0x2379fa,_0x295062=>{_0x36e9b0&&setTimeout(()=>{_0x36e9b0(_0x295062['s'],_0x295062['d']);},Math['floor'](0x0));});}['put'](_0x5e2083,_0x22259e,_0x1521e9,_0x1006b8){this['putInternal']('p',_0x5e2083,_0x22259e,_0x1521e9,_0x1006b8);}['merge'](_0x13a30f,_0x21586d,_0x994723,_0x2486e8){this['putInternal']('m',_0x13a30f,_0x21586d,_0x994723,_0x2486e8);}['putInternal'](_0x271d63,_0x4df268,_0x98250e,_0x4bd215,_0x2a0718){this['initConnection_']();const _0x5c344f={'p':_0x4df268,'d':_0x98250e};_0x2a0718!==void 0x0&&(_0x5c344f['h']=_0x2a0718),this['outstandingPuts_']['push']({'action':_0x271d63,'request':_0x5c344f,'onComplete':_0x4bd215}),this['outstandingPutCount_']++;const _0x3bcb42=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x3bcb42):this['log_']('Buffering\x20put:\x20'+_0x4df268);}['sendPut_'](_0x5ecbe7){const _0x484e08=this['outstandingPuts_'][_0x5ecbe7]['action'],_0x59826e=this['outstandingPuts_'][_0x5ecbe7]['request'],_0x425d52=this['outstandingPuts_'][_0x5ecbe7]['onComplete'];this['outstandingPuts_'][_0x5ecbe7]['queued']=this['connected_'],this['sendRequest'](_0x484e08,_0x59826e,_0x2dbca4=>{this['log_'](_0x484e08+'\x20response',_0x2dbca4),delete this['outstandingPuts_'][_0x5ecbe7],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x425d52&&_0x425d52(_0x2dbca4['s'],_0x2dbca4['d']);});}['reportStats'](_0x373a35){if(this['connected_']){const _0x2cb920={'c':_0x373a35};this['log_']('reportStats',_0x2cb920),this['sendRequest']('s',_0x2cb920,_0x29aef0=>{if(_0x29aef0['s']!=='ok'){const _0x25c965=_0x29aef0['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x25c965);}});}}['onDataMessage_'](_0x45a46a){if('r'in _0x45a46a){this['log_']('from\x20server:\x20'+O(_0x45a46a));const _0x3d135b=_0x45a46a['r'],_0x34dc3a=this['requestCBHash_'][_0x3d135b];_0x34dc3a&&(delete this['requestCBHash_'][_0x3d135b],_0x34dc3a(_0x45a46a['b']));}else{if('error'in _0x45a46a)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x45a46a['error'];'a'in _0x45a46a&&this['onDataPush_'](_0x45a46a['a'],_0x45a46a['b']);}}['onDataPush_'](_0x2bd54b,_0x3d5cdf){this['log_']('handleServerMessage',_0x2bd54b,_0x3d5cdf),_0x2bd54b==='d'?this['onDataUpdate_'](_0x3d5cdf['p'],_0x3d5cdf['d'],!0x1,_0x3d5cdf['t']):_0x2bd54b==='m'?this['onDataUpdate_'](_0x3d5cdf['p'],_0x3d5cdf['d'],!0x0,_0x3d5cdf['t']):_0x2bd54b==='c'?this['onListenRevoked_'](_0x3d5cdf['p'],_0x3d5cdf['q']):_0x2bd54b==='ac'?this['onAuthRevoked_'](_0x3d5cdf['s'],_0x3d5cdf['d']):_0x2bd54b==='apc'?this['onAppCheckRevoked_'](_0x3d5cdf['s'],_0x3d5cdf['d']):_0x2bd54b==='sd'?this['onSecurityDebugPacket_'](_0x3d5cdf):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x2bd54b)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x109607,_0x36cc16){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x109607),this['lastSessionId']=_0x36cc16,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x5aedc6){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x5aedc6));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x1c994f){_0x1c994f&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x1c994f;}['onOnline_'](_0xaf9085){_0xaf9085?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x4f6a2b=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x126b2a=Math['max'](0x0,this['reconnectDelay_']-_0x4f6a2b);_0x126b2a=Math['random']()*_0x126b2a,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x126b2a+'ms'),this['scheduleConnect_'](_0x126b2a),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x3e1ca5=this['onDataMessage_']['bind'](this),_0x24b59d=this['onReady_']['bind'](this),_0x29d33d=this['onRealtimeDisconnect_']['bind'](this),_0x2dae44=this['id']+':'+se['nextConnectionId_']++,_0x9d10d=this['lastSessionId'];let _0x5e9ee3=!0x1,_0x3f9f4e=null;const _0x1f3bfb=function(){_0x3f9f4e?_0x3f9f4e['close']():(_0x5e9ee3=!0x0,_0x29d33d());},_0x1b692a=function(_0x170431){f(_0x3f9f4e,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x3f9f4e['sendRequest'](_0x170431);};this['realtime_']={'close':_0x1f3bfb,'sendRequest':_0x1b692a};const _0x50e93b=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x2643a2,_0x4e6387]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x50e93b),this['appCheckTokenProvider_']['getToken'](_0x50e93b)]);_0x5e9ee3?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x2643a2&&_0x2643a2['accessToken'],this['appCheckToken_']=_0x4e6387&&_0x4e6387['token'],_0x3f9f4e=new Sh(_0x2dae44,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x3e1ca5,_0x24b59d,_0x29d33d,_0x4f068e=>{U(_0x4f068e+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x9d10d));}catch(_0x44dd69){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x44dd69),_0x5e9ee3||(this['repoInfo_']['nodeAdmin']&&U(_0x44dd69),_0x1f3bfb());}}}['interrupt'](_0x1b2d38){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x1b2d38),this['interruptReasons_'][_0x1b2d38]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x1819ed){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x1819ed),delete this['interruptReasons_'][_0x1819ed],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x117a32){const _0x5a24b2=_0x117a32-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x5a24b2});}['cancelSentTransactions_'](){for(let _0x23aaa1=0x0;_0x23aaa1<this['outstandingPuts_']['length'];_0x23aaa1++){const _0x50c4dd=this['outstandingPuts_'][_0x23aaa1];_0x50c4dd&&'h'in _0x50c4dd['request']&&_0x50c4dd['queued']&&(_0x50c4dd['onComplete']&&_0x50c4dd['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x23aaa1],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x3fde97,_0x16978d){let _0x1bbc38;_0x16978d?_0x1bbc38=_0x16978d['map'](_0x41c190=>Hi(_0x41c190))['join']('$'):_0x1bbc38='default';const _0x5af2eb=this['removeListen_'](_0x3fde97,_0x1bbc38);_0x5af2eb&&_0x5af2eb['onComplete']&&_0x5af2eb['onComplete']('permission_denied');}['removeListen_'](_0x490300,_0x1bb2dd){const _0x26596d=new C(_0x490300)['toString']();let _0x97e0ec;if(this['listens']['has'](_0x26596d)){const _0x522e21=this['listens']['get'](_0x26596d);_0x97e0ec=_0x522e21['get'](_0x1bb2dd),_0x522e21['delete'](_0x1bb2dd),_0x522e21['size']===0x0&&this['listens']['delete'](_0x26596d);}else _0x97e0ec=void 0x0;return _0x97e0ec;}['onAuthRevoked_'](_0x320f53,_0x4000aa){L('Auth\x20token\x20revoked:\x20'+_0x320f53+'/'+_0x4000aa),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x320f53==='invalid_token'||_0x320f53==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x36ce48,_0x3cd739){L('App\x20check\x20token\x20revoked:\x20'+_0x36ce48+'/'+_0x3cd739),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x36ce48==='invalid_token'||_0x36ce48==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x425a74){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x425a74):'msg'in _0x425a74&&console['log']('FIREBASE:\x20'+_0x425a74['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x140d0d of this['listens']['values']())for(const _0x425431 of _0x140d0d['values']())this['sendListen_'](_0x425431);for(let _0x3b59a3=0x0;_0x3b59a3<this['outstandingPuts_']['length'];_0x3b59a3++)this['outstandingPuts_'][_0x3b59a3]&&this['sendPut_'](_0x3b59a3);for(;this['onDisconnectRequestQueue_']['length'];){const _0x59821b=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x59821b['action'],_0x59821b['pathString'],_0x59821b['data'],_0x59821b['onComplete']);}for(let _0x413641=0x0;_0x413641<this['outstandingGets_']['length'];_0x413641++)this['outstandingGets_'][_0x413641]&&this['sendGet_'](_0x413641);}['sendConnectStats_'](){const _0x381818={};let _0x7c1aa5='js';_0x381818['sdk.'+_0x7c1aa5+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x381818['framework.cordova']=0x1:Yr()&&(_0x381818['framework.reactnative']=0x1),this['reportStats'](_0x381818);}['shouldReconnect_'](){const _0x1b0d67=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x1b0d67;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x5e8c07,_0x303e74){this['name']=_0x5e8c07,this['node']=_0x303e74;}static['Wrap'](_0x44de14,_0x12151c){return new E(_0x44de14,_0x12151c);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x57ee01,_0xafdbc5){const _0xeeca58=new E(Fe,_0x57ee01),_0x36ce5c=new E(Fe,_0xafdbc5);return this['compare'](_0xeeca58,_0x36ce5c)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x1f0008){Zt=_0x1f0008;}['compare'](_0x42c1e,_0x3a282a){return He(_0x42c1e['name'],_0x3a282a['name']);}['isDefinedOn'](_0x4338ff){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x151699,_0x25c00c){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x54e838,_0x2e2d5c){return f(typeof _0x54e838=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x54e838,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x3c659a,_0x5765b4,_0x5bb69c,_0x17e717,_0x4a21fd=null){this['isReverse_']=_0x17e717,this['resultGenerator_']=_0x4a21fd,this['nodeStack_']=[];let _0x392fe1=0x1;for(;!_0x3c659a['isEmpty']();)if(_0x3c659a=_0x3c659a,_0x392fe1=_0x5765b4?_0x5bb69c(_0x3c659a['key'],_0x5765b4):0x1,_0x17e717&&(_0x392fe1*=-0x1),_0x392fe1<0x0)this['isReverse_']?_0x3c659a=_0x3c659a['left']:_0x3c659a=_0x3c659a['right'];else{if(_0x392fe1===0x0){this['nodeStack_']['push'](_0x3c659a);break;}else this['nodeStack_']['push'](_0x3c659a),this['isReverse_']?_0x3c659a=_0x3c659a['right']:_0x3c659a=_0x3c659a['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x38f768=this['nodeStack_']['pop'](),_0x38c298;if(this['resultGenerator_']?_0x38c298=this['resultGenerator_'](_0x38f768['key'],_0x38f768['value']):_0x38c298={'key':_0x38f768['key'],'value':_0x38f768['value']},this['isReverse_']){for(_0x38f768=_0x38f768['left'];!_0x38f768['isEmpty']();)this['nodeStack_']['push'](_0x38f768),_0x38f768=_0x38f768['right'];}else{for(_0x38f768=_0x38f768['right'];!_0x38f768['isEmpty']();)this['nodeStack_']['push'](_0x38f768),_0x38f768=_0x38f768['left'];}return _0x38c298;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x26bcda=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x26bcda['key'],_0x26bcda['value']):{'key':_0x26bcda['key'],'value':_0x26bcda['value']};}}class M{constructor(_0x594aa4,_0x279aa0,_0x2b5614,_0x59e07e,_0x9d9403){this['key']=_0x594aa4,this['value']=_0x279aa0,this['color']=_0x2b5614??M['RED'],this['left']=_0x59e07e??B['EMPTY_NODE'],this['right']=_0x9d9403??B['EMPTY_NODE'];}['copy'](_0x1264c2,_0x4f6f45,_0x56bac3,_0x3fd4e2,_0x370a58){return new M(_0x1264c2??this['key'],_0x4f6f45??this['value'],_0x56bac3??this['color'],_0x3fd4e2??this['left'],_0x370a58??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x32dbc1){return this['left']['inorderTraversal'](_0x32dbc1)||!!_0x32dbc1(this['key'],this['value'])||this['right']['inorderTraversal'](_0x32dbc1);}['reverseTraversal'](_0x10ec0b){return this['right']['reverseTraversal'](_0x10ec0b)||_0x10ec0b(this['key'],this['value'])||this['left']['reverseTraversal'](_0x10ec0b);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x36d454,_0x4a5b4e,_0x2ffcf3){let _0x1dc3ab=this;const _0x2ce3c7=_0x2ffcf3(_0x36d454,_0x1dc3ab['key']);return _0x2ce3c7<0x0?_0x1dc3ab=_0x1dc3ab['copy'](null,null,null,_0x1dc3ab['left']['insert'](_0x36d454,_0x4a5b4e,_0x2ffcf3),null):_0x2ce3c7===0x0?_0x1dc3ab=_0x1dc3ab['copy'](null,_0x4a5b4e,null,null,null):_0x1dc3ab=_0x1dc3ab['copy'](null,null,null,null,_0x1dc3ab['right']['insert'](_0x36d454,_0x4a5b4e,_0x2ffcf3)),_0x1dc3ab['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x494661=this;return!_0x494661['left']['isRed_']()&&!_0x494661['left']['left']['isRed_']()&&(_0x494661=_0x494661['moveRedLeft_']()),_0x494661=_0x494661['copy'](null,null,null,_0x494661['left']['removeMin_'](),null),_0x494661['fixUp_']();}['remove'](_0xc21c0c,_0x22afa6){let _0x3e5809,_0x1a0254;if(_0x3e5809=this,_0x22afa6(_0xc21c0c,_0x3e5809['key'])<0x0)!_0x3e5809['left']['isEmpty']()&&!_0x3e5809['left']['isRed_']()&&!_0x3e5809['left']['left']['isRed_']()&&(_0x3e5809=_0x3e5809['moveRedLeft_']()),_0x3e5809=_0x3e5809['copy'](null,null,null,_0x3e5809['left']['remove'](_0xc21c0c,_0x22afa6),null);else{if(_0x3e5809['left']['isRed_']()&&(_0x3e5809=_0x3e5809['rotateRight_']()),!_0x3e5809['right']['isEmpty']()&&!_0x3e5809['right']['isRed_']()&&!_0x3e5809['right']['left']['isRed_']()&&(_0x3e5809=_0x3e5809['moveRedRight_']()),_0x22afa6(_0xc21c0c,_0x3e5809['key'])===0x0){if(_0x3e5809['right']['isEmpty']())return B['EMPTY_NODE'];_0x1a0254=_0x3e5809['right']['min_'](),_0x3e5809=_0x3e5809['copy'](_0x1a0254['key'],_0x1a0254['value'],null,null,_0x3e5809['right']['removeMin_']());}_0x3e5809=_0x3e5809['copy'](null,null,null,null,_0x3e5809['right']['remove'](_0xc21c0c,_0x22afa6));}return _0x3e5809['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x493af8=this;return _0x493af8['right']['isRed_']()&&!_0x493af8['left']['isRed_']()&&(_0x493af8=_0x493af8['rotateLeft_']()),_0x493af8['left']['isRed_']()&&_0x493af8['left']['left']['isRed_']()&&(_0x493af8=_0x493af8['rotateRight_']()),_0x493af8['left']['isRed_']()&&_0x493af8['right']['isRed_']()&&(_0x493af8=_0x493af8['colorFlip_']()),_0x493af8;}['moveRedLeft_'](){let _0x501f0a=this['colorFlip_']();return _0x501f0a['right']['left']['isRed_']()&&(_0x501f0a=_0x501f0a['copy'](null,null,null,null,_0x501f0a['right']['rotateRight_']()),_0x501f0a=_0x501f0a['rotateLeft_'](),_0x501f0a=_0x501f0a['colorFlip_']()),_0x501f0a;}['moveRedRight_'](){let _0x4f9542=this['colorFlip_']();return _0x4f9542['left']['left']['isRed_']()&&(_0x4f9542=_0x4f9542['rotateRight_'](),_0x4f9542=_0x4f9542['colorFlip_']()),_0x4f9542;}['rotateLeft_'](){const _0x57b8f5=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x57b8f5,null);}['rotateRight_'](){const _0x5bc536=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x5bc536);}['colorFlip_'](){const _0x46e3cb=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x4476ca=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x46e3cb,_0x4476ca);}['checkMaxDepth_'](){const _0x4d1fc2=this['check_']();return Math['pow'](0x2,_0x4d1fc2)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0xf6434a=this['left']['check_']();if(_0xf6434a!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0xf6434a+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x4b8a78,_0x4cea50,_0x21dd09,_0x3b8899,_0x461f23){return this;}['insert'](_0x20a149,_0x21d70a,_0x381c5a){return new M(_0x20a149,_0x21d70a,null);}['remove'](_0x198f84,_0x5d201b){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x1fd5d2){return!0x1;}['reverseTraversal'](_0x44058a){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x56d99c,_0x3e217e=B['EMPTY_NODE']){this['comparator_']=_0x56d99c,this['root_']=_0x3e217e;}['insert'](_0x18b7b1,_0x3271dc){return new B(this['comparator_'],this['root_']['insert'](_0x18b7b1,_0x3271dc,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x9b8710){return new B(this['comparator_'],this['root_']['remove'](_0x9b8710,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x441d47){let _0x1fd0cb,_0x361df7=this['root_'];for(;!_0x361df7['isEmpty']();){if(_0x1fd0cb=this['comparator_'](_0x441d47,_0x361df7['key']),_0x1fd0cb===0x0)return _0x361df7['value'];_0x1fd0cb<0x0?_0x361df7=_0x361df7['left']:_0x1fd0cb>0x0&&(_0x361df7=_0x361df7['right']);}return null;}['getPredecessorKey'](_0x545ba8){let _0x56d520,_0x4672dc=this['root_'],_0x154c2d=null;for(;!_0x4672dc['isEmpty']();)if(_0x56d520=this['comparator_'](_0x545ba8,_0x4672dc['key']),_0x56d520===0x0){if(_0x4672dc['left']['isEmpty']())return _0x154c2d?_0x154c2d['key']:null;for(_0x4672dc=_0x4672dc['left'];!_0x4672dc['right']['isEmpty']();)_0x4672dc=_0x4672dc['right'];return _0x4672dc['key'];}else _0x56d520<0x0?_0x4672dc=_0x4672dc['left']:_0x56d520>0x0&&(_0x154c2d=_0x4672dc,_0x4672dc=_0x4672dc['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x469d4e){return this['root_']['inorderTraversal'](_0x469d4e);}['reverseTraversal'](_0xbe71a7){return this['root_']['reverseTraversal'](_0xbe71a7);}['getIterator'](_0xf1a5b5){return new en(this['root_'],null,this['comparator_'],!0x1,_0xf1a5b5);}['getIteratorFrom'](_0x2c57ca,_0x1ec8a9){return new en(this['root_'],_0x2c57ca,this['comparator_'],!0x1,_0x1ec8a9);}['getReverseIteratorFrom'](_0x2c2c3e,_0x36921f){return new en(this['root_'],_0x2c2c3e,this['comparator_'],!0x0,_0x36921f);}['getReverseIterator'](_0x29a181){return new en(this['root_'],null,this['comparator_'],!0x0,_0x29a181);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x154afc,_0xd98005){return He(_0x154afc['name'],_0xd98005['name']);}function Yi(_0x40fa99,_0x49760d){return He(_0x40fa99,_0x49760d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x3a8400){Ei=_0x3a8400;}const No=function(_0x38cab7){return typeof _0x38cab7=='number'?'number:'+ao(_0x38cab7):'string:'+_0x38cab7;},Po=function(_0x2e2a47){if(_0x2e2a47['isLeafNode']()){const _0x439dab=_0x2e2a47['val']();f(typeof _0x439dab=='string'||typeof _0x439dab=='number'||typeof _0x439dab=='object'&&J(_0x439dab,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x2e2a47===Ei||_0x2e2a47['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x2e2a47===Ei||_0x2e2a47['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x970c98){ir=_0x970c98;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x1ed49c,_0xa5550f=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x1ed49c,this['priorityNode_']=_0xa5550f,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x255843){return new D(this['value_'],_0x255843);}['getImmediateChild'](_0x1633ab){return _0x1633ab==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x32dcab){return v(_0x32dcab)?this:y(_0x32dcab)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x57da22,_0xb82755){return null;}['updateImmediateChild'](_0x474959,_0x5aa517){return _0x474959==='.priority'?this['updatePriority'](_0x5aa517):_0x5aa517['isEmpty']()&&_0x474959!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x474959,_0x5aa517)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x1fe3c1,_0x2e7637){const _0x4379f4=y(_0x1fe3c1);return _0x4379f4===null?_0x2e7637:_0x2e7637['isEmpty']()&&_0x4379f4!=='.priority'?this:(f(_0x4379f4!=='.priority'||we(_0x1fe3c1)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x4379f4,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x1fe3c1),_0x2e7637)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x213d11,_0x53aa11){return!0x1;}['val'](_0x512d1d){return _0x512d1d&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x1fc2d7='';this['priorityNode_']['isEmpty']()||(_0x1fc2d7+='priority:'+No(this['priorityNode_']['val']())+':');const _0x2c61e5=typeof this['value_'];_0x1fc2d7+=_0x2c61e5+':',_0x2c61e5==='number'?_0x1fc2d7+=ao(this['value_']):_0x1fc2d7+=this['value_'],this['lazyHash_']=ro(_0x1fc2d7);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x8e9a66){return _0x8e9a66===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x8e9a66 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x8e9a66['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x8e9a66));}['compareToLeafNode_'](_0x415d4f){const _0x582bcc=typeof _0x415d4f['value_'],_0x4a1081=typeof this['value_'],_0x54369b=D['VALUE_TYPE_ORDER']['indexOf'](_0x582bcc),_0x4455e5=D['VALUE_TYPE_ORDER']['indexOf'](_0x4a1081);return f(_0x54369b>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x582bcc),f(_0x4455e5>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4a1081),_0x54369b===_0x4455e5?_0x4a1081==='object'?0x0:this['value_']<_0x415d4f['value_']?-0x1:this['value_']===_0x415d4f['value_']?0x0:0x1:_0x4455e5-_0x54369b;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x4b63ae){if(_0x4b63ae===this)return!0x0;if(_0x4b63ae['isLeafNode']()){const _0x330631=_0x4b63ae;return this['value_']===_0x330631['value_']&&this['priorityNode_']['equals'](_0x330631['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x2341be){Oo=_0x2341be;}function Wh(_0x383b31){Do=_0x383b31;}class Bh extends Dn{['compare'](_0x8ad249,_0x273339){const _0xb10be9=_0x8ad249['node']['getPriority'](),_0x53599b=_0x273339['node']['getPriority'](),_0x19855a=_0xb10be9['compareTo'](_0x53599b);return _0x19855a===0x0?He(_0x8ad249['name'],_0x273339['name']):_0x19855a;}['isDefinedOn'](_0x1b6b56){return!_0x1b6b56['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x53e78f,_0x230e84){return!_0x53e78f['getPriority']()['equals'](_0x230e84['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x22ae97,_0x529764){const _0x54ce0=Oo(_0x22ae97);return new E(_0x529764,new D('[PRIORITY-POST]',_0x54ce0));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x3addfb){const _0x183e81=_0x2ed446=>parseInt(Math['log'](_0x2ed446)/Vh,0xa),_0x54d370=_0x3b410b=>parseInt(Array(_0x3b410b+0x1)['join']('1'),0x2);this['count']=_0x183e81(_0x3addfb+0x1),this['current_']=this['count']-0x1;const _0x5a6871=_0x54d370(this['count']);this['bits_']=_0x3addfb+0x1&_0x5a6871;}['nextBitIsOne'](){const _0x40f39b=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x40f39b;}}const fn=function(_0x48a871,_0x4f9a20,_0x1ac810,_0x5883bd){_0x48a871['sort'](_0x4f9a20);const _0x21f8ae=function(_0x362063,_0xd23429){const _0x28e046=_0xd23429-_0x362063;let _0x497771,_0x540bee;if(_0x28e046===0x0)return null;if(_0x28e046===0x1)return _0x497771=_0x48a871[_0x362063],_0x540bee=_0x1ac810?_0x1ac810(_0x497771):_0x497771,new M(_0x540bee,_0x497771['node'],M['BLACK'],null,null);{const _0x28faff=parseInt(_0x28e046/0x2,0xa)+_0x362063,_0x2c5dbd=_0x21f8ae(_0x362063,_0x28faff),_0x13ada8=_0x21f8ae(_0x28faff+0x1,_0xd23429);return _0x497771=_0x48a871[_0x28faff],_0x540bee=_0x1ac810?_0x1ac810(_0x497771):_0x497771,new M(_0x540bee,_0x497771['node'],M['BLACK'],_0x2c5dbd,_0x13ada8);}},_0x1e9ccb=function(_0x1924e1){let _0x1a869d=null,_0x6c9761=null,_0x1efc4e=_0x48a871['length'];const _0x13f94d=function(_0x2c51ba,_0x2563c5){const _0x208b1a=_0x1efc4e-_0x2c51ba,_0x1f3baa=_0x1efc4e;_0x1efc4e-=_0x2c51ba;const _0x2797ef=_0x21f8ae(_0x208b1a+0x1,_0x1f3baa),_0x4b6633=_0x48a871[_0x208b1a],_0x4b2db2=_0x1ac810?_0x1ac810(_0x4b6633):_0x4b6633;_0x124808(new M(_0x4b2db2,_0x4b6633['node'],_0x2563c5,null,_0x2797ef));},_0x124808=function(_0x3fc7bd){_0x1a869d?(_0x1a869d['left']=_0x3fc7bd,_0x1a869d=_0x3fc7bd):(_0x6c9761=_0x3fc7bd,_0x1a869d=_0x3fc7bd);};for(let _0x3d061e=0x0;_0x3d061e<_0x1924e1['count'];++_0x3d061e){const _0x1a6be4=_0x1924e1['nextBitIsOne'](),_0x3c9f58=Math['pow'](0x2,_0x1924e1['count']-(_0x3d061e+0x1));_0x1a6be4?_0x13f94d(_0x3c9f58,M['BLACK']):(_0x13f94d(_0x3c9f58,M['BLACK']),_0x13f94d(_0x3c9f58,M['RED']));}return _0x6c9761;},_0x47a1dd=new Hh(_0x48a871['length']),_0x189d53=_0x1e9ccb(_0x47a1dd);return new B(_0x5883bd||_0x4f9a20,_0x189d53);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x1f9ad9,_0x1be954){this['indexes_']=_0x1f9ad9,this['indexSet_']=_0x1be954;}['get'](_0x1ad091){const _0x5469e6=De(this['indexes_'],_0x1ad091);if(!_0x5469e6)throw new Error('No\x20index\x20defined\x20for\x20'+_0x1ad091);return _0x5469e6 instanceof B?_0x5469e6:null;}['hasIndex'](_0x27426e){return J(this['indexSet_'],_0x27426e['toString']());}['addIndex'](_0x5aeb2e,_0x19f590){f(_0x5aeb2e!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x3f2048=[];let _0x1025ec=!0x1;const _0xb8125b=_0x19f590['getIterator'](E['Wrap']);let _0x52a7e9=_0xb8125b['getNext']();for(;_0x52a7e9;)_0x1025ec=_0x1025ec||_0x5aeb2e['isDefinedOn'](_0x52a7e9['node']),_0x3f2048['push'](_0x52a7e9),_0x52a7e9=_0xb8125b['getNext']();let _0x519e5b;_0x1025ec?_0x519e5b=fn(_0x3f2048,_0x5aeb2e['getCompare']()):_0x519e5b=ze;const _0x11af8b=_0x5aeb2e['toString'](),_0x1f4001={...this['indexSet_']};_0x1f4001[_0x11af8b]=_0x5aeb2e;const _0x36606c={...this['indexes_']};return _0x36606c[_0x11af8b]=_0x519e5b,new te(_0x36606c,_0x1f4001);}['addToIndexes'](_0x45832d,_0x3a6857){const _0x29460a=hn(this['indexes_'],(_0x5e06ec,_0x351618)=>{const _0x5a555a=De(this['indexSet_'],_0x351618);if(f(_0x5a555a,'Missing\x20index\x20implementation\x20for\x20'+_0x351618),_0x5e06ec===ze){if(_0x5a555a['isDefinedOn'](_0x45832d['node'])){const _0x16689e=[],_0x1e251d=_0x3a6857['getIterator'](E['Wrap']);let _0x3da4bd=_0x1e251d['getNext']();for(;_0x3da4bd;)_0x3da4bd['name']!==_0x45832d['name']&&_0x16689e['push'](_0x3da4bd),_0x3da4bd=_0x1e251d['getNext']();return _0x16689e['push'](_0x45832d),fn(_0x16689e,_0x5a555a['getCompare']());}else return ze;}else{const _0x498ed0=_0x3a6857['get'](_0x45832d['name']);let _0x506436=_0x5e06ec;return _0x498ed0&&(_0x506436=_0x506436['remove'](new E(_0x45832d['name'],_0x498ed0))),_0x506436['insert'](_0x45832d,_0x45832d['node']);}});return new te(_0x29460a,this['indexSet_']);}['removeFromIndexes'](_0x5c2d62,_0x585f52){const _0x248af9=hn(this['indexes_'],_0x329c5e=>{if(_0x329c5e===ze)return _0x329c5e;{const _0x54d892=_0x585f52['get'](_0x5c2d62['name']);return _0x54d892?_0x329c5e['remove'](new E(_0x5c2d62['name'],_0x54d892)):_0x329c5e;}});return new te(_0x248af9,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x38db32,_0x2dd401,_0x8353e9){this['children_']=_0x38db32,this['priorityNode_']=_0x2dd401,this['indexMap_']=_0x8353e9,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x3b5e19){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x3b5e19,this['indexMap_']);}['getImmediateChild'](_0x268826){if(_0x268826==='.priority')return this['getPriority']();{const _0x5d1c17=this['children_']['get'](_0x268826);return _0x5d1c17===null?mt:_0x5d1c17;}}['getChild'](_0x1ba15a){const _0x3c6709=y(_0x1ba15a);return _0x3c6709===null?this:this['getImmediateChild'](_0x3c6709)['getChild'](b(_0x1ba15a));}['hasChild'](_0x36c7b1){return this['children_']['get'](_0x36c7b1)!==null;}['updateImmediateChild'](_0x4f9afd,_0x239053){if(f(_0x239053,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x4f9afd==='.priority')return this['updatePriority'](_0x239053);{const _0x23dea5=new E(_0x4f9afd,_0x239053);let _0x1a461c,_0x4e5724;_0x239053['isEmpty']()?(_0x1a461c=this['children_']['remove'](_0x4f9afd),_0x4e5724=this['indexMap_']['removeFromIndexes'](_0x23dea5,this['children_'])):(_0x1a461c=this['children_']['insert'](_0x4f9afd,_0x239053),_0x4e5724=this['indexMap_']['addToIndexes'](_0x23dea5,this['children_']));const _0xb95e74=_0x1a461c['isEmpty']()?mt:this['priorityNode_'];return new g(_0x1a461c,_0xb95e74,_0x4e5724);}}['updateChild'](_0x223c0c,_0x20988a){const _0x4a1dcc=y(_0x223c0c);if(_0x4a1dcc===null)return _0x20988a;{f(y(_0x223c0c)!=='.priority'||we(_0x223c0c)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x117e62=this['getImmediateChild'](_0x4a1dcc)['updateChild'](b(_0x223c0c),_0x20988a);return this['updateImmediateChild'](_0x4a1dcc,_0x117e62);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x3b10c1){if(this['isEmpty']())return null;const _0x53a2f7={};let _0x46ad9b=0x0,_0x5c2165=0x0,_0x1fd602=!0x0;if(this['forEachChild'](R,(_0x325d92,_0x2b8977)=>{_0x53a2f7[_0x325d92]=_0x2b8977['val'](_0x3b10c1),_0x46ad9b++,_0x1fd602&&g['INTEGER_REGEXP_']['test'](_0x325d92)?_0x5c2165=Math['max'](_0x5c2165,Number(_0x325d92)):_0x1fd602=!0x1;}),!_0x3b10c1&&_0x1fd602&&_0x5c2165<0x2*_0x46ad9b){const _0x533eb4=[];for(const _0x394b66 in _0x53a2f7)_0x533eb4[_0x394b66]=_0x53a2f7[_0x394b66];return _0x533eb4;}else return _0x3b10c1&&!this['getPriority']()['isEmpty']()&&(_0x53a2f7['.priority']=this['getPriority']()['val']()),_0x53a2f7;}['hash'](){if(this['lazyHash_']===null){let _0x8612b7='';this['getPriority']()['isEmpty']()||(_0x8612b7+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x223037,_0x4e73f2)=>{const _0x2ff0b3=_0x4e73f2['hash']();_0x2ff0b3!==''&&(_0x8612b7+=':'+_0x223037+':'+_0x2ff0b3);}),this['lazyHash_']=_0x8612b7===''?'':ro(_0x8612b7);}return this['lazyHash_'];}['getPredecessorChildName'](_0xf71714,_0x26ae3e,_0x551885){const _0x1e2d77=this['resolveIndex_'](_0x551885);if(_0x1e2d77){const _0x3c0202=_0x1e2d77['getPredecessorKey'](new E(_0xf71714,_0x26ae3e));return _0x3c0202?_0x3c0202['name']:null;}else return this['children_']['getPredecessorKey'](_0xf71714);}['getFirstChildName'](_0xb38a91){const _0x51e71f=this['resolveIndex_'](_0xb38a91);if(_0x51e71f){const _0x3b9c87=_0x51e71f['minKey']();return _0x3b9c87&&_0x3b9c87['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0xbf54ed){const _0x3ecb5c=this['getFirstChildName'](_0xbf54ed);return _0x3ecb5c?new E(_0x3ecb5c,this['children_']['get'](_0x3ecb5c)):null;}['getLastChildName'](_0x19e824){const _0x3a3b7f=this['resolveIndex_'](_0x19e824);if(_0x3a3b7f){const _0x8bbb66=_0x3a3b7f['maxKey']();return _0x8bbb66&&_0x8bbb66['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x46e9b6){const _0x4c67a4=this['getLastChildName'](_0x46e9b6);return _0x4c67a4?new E(_0x4c67a4,this['children_']['get'](_0x4c67a4)):null;}['forEachChild'](_0x3e102c,_0x4fd277){const _0x3de0a0=this['resolveIndex_'](_0x3e102c);return _0x3de0a0?_0x3de0a0['inorderTraversal'](_0x4aedde=>_0x4fd277(_0x4aedde['name'],_0x4aedde['node'])):this['children_']['inorderTraversal'](_0x4fd277);}['getIterator'](_0x49fef1){return this['getIteratorFrom'](_0x49fef1['minPost'](),_0x49fef1);}['getIteratorFrom'](_0x2077d1,_0x1defe6){const _0x4f16e9=this['resolveIndex_'](_0x1defe6);if(_0x4f16e9)return _0x4f16e9['getIteratorFrom'](_0x2077d1,_0x172009=>_0x172009);{const _0x27c161=this['children_']['getIteratorFrom'](_0x2077d1['name'],E['Wrap']);let _0x189332=_0x27c161['peek']();for(;_0x189332!=null&&_0x1defe6['compare'](_0x189332,_0x2077d1)<0x0;)_0x27c161['getNext'](),_0x189332=_0x27c161['peek']();return _0x27c161;}}['getReverseIterator'](_0x357729){return this['getReverseIteratorFrom'](_0x357729['maxPost'](),_0x357729);}['getReverseIteratorFrom'](_0x1058b8,_0x28ad30){const _0x4ba8bb=this['resolveIndex_'](_0x28ad30);if(_0x4ba8bb)return _0x4ba8bb['getReverseIteratorFrom'](_0x1058b8,_0x261b33=>_0x261b33);{const _0x57c298=this['children_']['getReverseIteratorFrom'](_0x1058b8['name'],E['Wrap']);let _0xde6bf6=_0x57c298['peek']();for(;_0xde6bf6!=null&&_0x28ad30['compare'](_0xde6bf6,_0x1058b8)>0x0;)_0x57c298['getNext'](),_0xde6bf6=_0x57c298['peek']();return _0x57c298;}}['compareTo'](_0x253438){return this['isEmpty']()?_0x253438['isEmpty']()?0x0:-0x1:_0x253438['isLeafNode']()||_0x253438['isEmpty']()?0x1:_0x253438===$t?-0x1:0x0;}['withIndex'](_0x2594fb){if(_0x2594fb===ye||this['indexMap_']['hasIndex'](_0x2594fb))return this;{const _0x173c6d=this['indexMap_']['addIndex'](_0x2594fb,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x173c6d);}}['isIndexed'](_0x20c812){return _0x20c812===ye||this['indexMap_']['hasIndex'](_0x20c812);}['equals'](_0x45ff67){if(_0x45ff67===this)return!0x0;if(_0x45ff67['isLeafNode']())return!0x1;{const _0x2d21a4=_0x45ff67;if(this['getPriority']()['equals'](_0x2d21a4['getPriority']())){if(this['children_']['count']()===_0x2d21a4['children_']['count']()){const _0x1df42c=this['getIterator'](R),_0x2e01fd=_0x2d21a4['getIterator'](R);let _0x15169e=_0x1df42c['getNext'](),_0x28552e=_0x2e01fd['getNext']();for(;_0x15169e&&_0x28552e;){if(_0x15169e['name']!==_0x28552e['name']||!_0x15169e['node']['equals'](_0x28552e['node']))return!0x1;_0x15169e=_0x1df42c['getNext'](),_0x28552e=_0x2e01fd['getNext']();}return _0x15169e===null&&_0x28552e===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x269c3a){return _0x269c3a===ye?null:this['indexMap_']['get'](_0x269c3a['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x53cf72){return _0x53cf72===this?0x0:0x1;}['equals'](_0x564bd8){return _0x564bd8===this;}['getPriority'](){return this;}['getImmediateChild'](_0x20f572){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x1b8d07,_0x25109e=null){if(_0x1b8d07===null)return g['EMPTY_NODE'];if(typeof _0x1b8d07=='object'&&'.priority'in _0x1b8d07&&(_0x25109e=_0x1b8d07['.priority']),f(_0x25109e===null||typeof _0x25109e=='string'||typeof _0x25109e=='number'||typeof _0x25109e=='object'&&'.sv'in _0x25109e,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x25109e),typeof _0x1b8d07=='object'&&'.value'in _0x1b8d07&&_0x1b8d07['.value']!==null&&(_0x1b8d07=_0x1b8d07['.value']),typeof _0x1b8d07!='object'||'.sv'in _0x1b8d07){const _0x59daec=_0x1b8d07;return new D(_0x59daec,P(_0x25109e));}if(!(_0x1b8d07 instanceof Array)&&Gh){const _0xbaf7a1=[];let _0x24032c=!0x1;if(x(_0x1b8d07,(_0xdd499c,_0x4f93bd)=>{if(_0xdd499c['substring'](0x0,0x1)!=='.'){const _0x47ebd4=P(_0x4f93bd);_0x47ebd4['isEmpty']()||(_0x24032c=_0x24032c||!_0x47ebd4['getPriority']()['isEmpty'](),_0xbaf7a1['push'](new E(_0xdd499c,_0x47ebd4)));}}),_0xbaf7a1['length']===0x0)return g['EMPTY_NODE'];const _0x2cc8e2=fn(_0xbaf7a1,xh,_0x4e4002=>_0x4e4002['name'],Yi);if(_0x24032c){const _0x5dfd95=fn(_0xbaf7a1,R['getCompare']());return new g(_0x2cc8e2,P(_0x25109e),new te({'.priority':_0x5dfd95},{'.priority':R}));}else return new g(_0x2cc8e2,P(_0x25109e),te['Default']);}else{let _0x1c344c=g['EMPTY_NODE'];return x(_0x1b8d07,(_0x51bfc6,_0x1462c1)=>{if(J(_0x1b8d07,_0x51bfc6)&&_0x51bfc6['substring'](0x0,0x1)!=='.'){const _0xeb4298=P(_0x1462c1);(_0xeb4298['isLeafNode']()||!_0xeb4298['isEmpty']())&&(_0x1c344c=_0x1c344c['updateImmediateChild'](_0x51bfc6,_0xeb4298));}}),_0x1c344c['updatePriority'](P(_0x25109e));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x120bf4){super(),this['indexPath_']=_0x120bf4,f(!v(_0x120bf4)&&y(_0x120bf4)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x2c7f2e){return _0x2c7f2e['getChild'](this['indexPath_']);}['isDefinedOn'](_0x9076ab){return!_0x9076ab['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x171f68,_0x5db305){const _0x223eae=this['extractChild'](_0x171f68['node']),_0x544f4e=this['extractChild'](_0x5db305['node']),_0x415b47=_0x223eae['compareTo'](_0x544f4e);return _0x415b47===0x0?He(_0x171f68['name'],_0x5db305['name']):_0x415b47;}['makePost'](_0xedbee8,_0xb752d7){const _0x321704=P(_0xedbee8),_0xf1cfe9=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x321704);return new E(_0xb752d7,_0xf1cfe9);}['maxPost'](){const _0x4c68b5=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x4c68b5);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x1e713f,_0x2b0a00){const _0x267380=_0x1e713f['node']['compareTo'](_0x2b0a00['node']);return _0x267380===0x0?He(_0x1e713f['name'],_0x2b0a00['name']):_0x267380;}['isDefinedOn'](_0x21e05d){return!0x0;}['indexedValueChanged'](_0x31cd63,_0x202c39){return!_0x31cd63['equals'](_0x202c39);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x36fda3,_0x108b4f){const _0x332c46=P(_0x36fda3);return new E(_0x108b4f,_0x332c46);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x232e25){return{'type':'value','snapshotNode':_0x232e25};}function et(_0x404acd,_0x5071a1){return{'type':'child_added','snapshotNode':_0x5071a1,'childName':_0x404acd};}function Ot(_0xb46fc2,_0x5aec84){return{'type':'child_removed','snapshotNode':_0x5aec84,'childName':_0xb46fc2};}function Dt(_0x30b980,_0x386802,_0x16c44e){return{'type':'child_changed','snapshotNode':_0x386802,'childName':_0x30b980,'oldSnap':_0x16c44e};}function zh(_0x382307,_0x29494a){return{'type':'child_moved','snapshotNode':_0x29494a,'childName':_0x382307};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x5504ff){this['index_']=_0x5504ff;}['updateChild'](_0x182c48,_0x4831ca,_0x33e35b,_0x3b920f,_0x450e12,_0x19486b){f(_0x182c48['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0xbbc3f3=_0x182c48['getImmediateChild'](_0x4831ca);return _0xbbc3f3['getChild'](_0x3b920f)['equals'](_0x33e35b['getChild'](_0x3b920f))&&_0xbbc3f3['isEmpty']()===_0x33e35b['isEmpty']()||(_0x19486b!=null&&(_0x33e35b['isEmpty']()?_0x182c48['hasChild'](_0x4831ca)?_0x19486b['trackChildChange'](Ot(_0x4831ca,_0xbbc3f3)):f(_0x182c48['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0xbbc3f3['isEmpty']()?_0x19486b['trackChildChange'](et(_0x4831ca,_0x33e35b)):_0x19486b['trackChildChange'](Dt(_0x4831ca,_0x33e35b,_0xbbc3f3))),_0x182c48['isLeafNode']()&&_0x33e35b['isEmpty']())?_0x182c48:_0x182c48['updateImmediateChild'](_0x4831ca,_0x33e35b)['withIndex'](this['index_']);}['updateFullNode'](_0x10ac52,_0x353cac,_0x72dabb){return _0x72dabb!=null&&(_0x10ac52['isLeafNode']()||_0x10ac52['forEachChild'](R,(_0x68c8a0,_0x24cfde)=>{_0x353cac['hasChild'](_0x68c8a0)||_0x72dabb['trackChildChange'](Ot(_0x68c8a0,_0x24cfde));}),_0x353cac['isLeafNode']()||_0x353cac['forEachChild'](R,(_0x4e9b8b,_0x4b7e98)=>{if(_0x10ac52['hasChild'](_0x4e9b8b)){const _0x1b3f8e=_0x10ac52['getImmediateChild'](_0x4e9b8b);_0x1b3f8e['equals'](_0x4b7e98)||_0x72dabb['trackChildChange'](Dt(_0x4e9b8b,_0x4b7e98,_0x1b3f8e));}else _0x72dabb['trackChildChange'](et(_0x4e9b8b,_0x4b7e98));})),_0x353cac['withIndex'](this['index_']);}['updatePriority'](_0x1a047a,_0x247707){return _0x1a047a['isEmpty']()?g['EMPTY_NODE']:_0x1a047a['updatePriority'](_0x247707);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x5ade6d){this['indexedFilter_']=new Ji(_0x5ade6d['getIndex']()),this['index_']=_0x5ade6d['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x5ade6d),this['endPost_']=Mt['getEndPost_'](_0x5ade6d),this['startIsInclusive_']=!_0x5ade6d['startAfterSet_'],this['endIsInclusive_']=!_0x5ade6d['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x3ff718){const _0x26a6b0=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x3ff718)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x3ff718)<0x0,_0x3800a8=this['endIsInclusive_']?this['index_']['compare'](_0x3ff718,this['getEndPost']())<=0x0:this['index_']['compare'](_0x3ff718,this['getEndPost']())<0x0;return _0x26a6b0&&_0x3800a8;}['updateChild'](_0x233d5a,_0x412cde,_0x58184b,_0x4c5291,_0x19be7e,_0x12467d){return this['matches'](new E(_0x412cde,_0x58184b))||(_0x58184b=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x233d5a,_0x412cde,_0x58184b,_0x4c5291,_0x19be7e,_0x12467d);}['updateFullNode'](_0x44439,_0x1d235c,_0x5e4a09){_0x1d235c['isLeafNode']()&&(_0x1d235c=g['EMPTY_NODE']);let _0x52b116=_0x1d235c['withIndex'](this['index_']);_0x52b116=_0x52b116['updatePriority'](g['EMPTY_NODE']);const _0x33d6d2=this;return _0x1d235c['forEachChild'](R,(_0x154719,_0x383bb0)=>{_0x33d6d2['matches'](new E(_0x154719,_0x383bb0))||(_0x52b116=_0x52b116['updateImmediateChild'](_0x154719,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x44439,_0x52b116,_0x5e4a09);}['updatePriority'](_0x3bedb6,_0x33166a){return _0x3bedb6;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x34e317){if(_0x34e317['hasStart']()){const _0x60637=_0x34e317['getIndexStartName']();return _0x34e317['getIndex']()['makePost'](_0x34e317['getIndexStartValue'](),_0x60637);}else return _0x34e317['getIndex']()['minPost']();}static['getEndPost_'](_0x54ef15){if(_0x54ef15['hasEnd']()){const _0x1e0b12=_0x54ef15['getIndexEndName']();return _0x54ef15['getIndex']()['makePost'](_0x54ef15['getIndexEndValue'](),_0x1e0b12);}else return _0x54ef15['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x180f39){this['withinDirectionalStart']=_0x4d9d6f=>this['reverse_']?this['withinEndPost'](_0x4d9d6f):this['withinStartPost'](_0x4d9d6f),this['withinDirectionalEnd']=_0x3ceed8=>this['reverse_']?this['withinStartPost'](_0x3ceed8):this['withinEndPost'](_0x3ceed8),this['withinStartPost']=_0x431926=>{const _0x7ee492=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x431926);return this['startIsInclusive_']?_0x7ee492<=0x0:_0x7ee492<0x0;},this['withinEndPost']=_0x874c8b=>{const _0x23ce50=this['index_']['compare'](_0x874c8b,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x23ce50<=0x0:_0x23ce50<0x0;},this['rangedFilter_']=new Mt(_0x180f39),this['index_']=_0x180f39['getIndex'](),this['limit_']=_0x180f39['getLimit'](),this['reverse_']=!_0x180f39['isViewFromLeft'](),this['startIsInclusive_']=!_0x180f39['startAfterSet_'],this['endIsInclusive_']=!_0x180f39['endBeforeSet_'];}['updateChild'](_0x10e8d4,_0x8670e3,_0x57cbd0,_0x4a59f7,_0x2b8920,_0x4317e1){return this['rangedFilter_']['matches'](new E(_0x8670e3,_0x57cbd0))||(_0x57cbd0=g['EMPTY_NODE']),_0x10e8d4['getImmediateChild'](_0x8670e3)['equals'](_0x57cbd0)?_0x10e8d4:_0x10e8d4['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x10e8d4,_0x8670e3,_0x57cbd0,_0x4a59f7,_0x2b8920,_0x4317e1):this['fullLimitUpdateChild_'](_0x10e8d4,_0x8670e3,_0x57cbd0,_0x2b8920,_0x4317e1);}['updateFullNode'](_0x592fed,_0x18b6bf,_0x2fb3f2){let _0x107f52;if(_0x18b6bf['isLeafNode']()||_0x18b6bf['isEmpty']())_0x107f52=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x18b6bf['numChildren']()&&_0x18b6bf['isIndexed'](this['index_'])){_0x107f52=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x4ee8aa;this['reverse_']?_0x4ee8aa=_0x18b6bf['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x4ee8aa=_0x18b6bf['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x254c6d=0x0;for(;_0x4ee8aa['hasNext']()&&_0x254c6d<this['limit_'];){const _0x375b8a=_0x4ee8aa['getNext']();if(this['withinDirectionalStart'](_0x375b8a)){if(this['withinDirectionalEnd'](_0x375b8a))_0x107f52=_0x107f52['updateImmediateChild'](_0x375b8a['name'],_0x375b8a['node']),_0x254c6d++;else break;}else continue;}}else{_0x107f52=_0x18b6bf['withIndex'](this['index_']),_0x107f52=_0x107f52['updatePriority'](g['EMPTY_NODE']);let _0x32c7a4;this['reverse_']?_0x32c7a4=_0x107f52['getReverseIterator'](this['index_']):_0x32c7a4=_0x107f52['getIterator'](this['index_']);let _0x4a6e87=0x0;for(;_0x32c7a4['hasNext']();){const _0x333d89=_0x32c7a4['getNext']();_0x4a6e87<this['limit_']&&this['withinDirectionalStart'](_0x333d89)&&this['withinDirectionalEnd'](_0x333d89)?_0x4a6e87++:_0x107f52=_0x107f52['updateImmediateChild'](_0x333d89['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x592fed,_0x107f52,_0x2fb3f2);}['updatePriority'](_0x122692,_0x781026){return _0x122692;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0xc48741,_0x3f29e1,_0x3b1209,_0x1015dc,_0x485360){let _0x2cefd7;if(this['reverse_']){const _0x1c391f=this['index_']['getCompare']();_0x2cefd7=(_0x38a77f,_0x53bc14)=>_0x1c391f(_0x53bc14,_0x38a77f);}else _0x2cefd7=this['index_']['getCompare']();const _0x2bc2b0=_0xc48741;f(_0x2bc2b0['numChildren']()===this['limit_'],'');const _0x5cb315=new E(_0x3f29e1,_0x3b1209),_0x2a82a5=this['reverse_']?_0x2bc2b0['getFirstChild'](this['index_']):_0x2bc2b0['getLastChild'](this['index_']),_0x2fcaf2=this['rangedFilter_']['matches'](_0x5cb315);if(_0x2bc2b0['hasChild'](_0x3f29e1)){const _0x487bcb=_0x2bc2b0['getImmediateChild'](_0x3f29e1);let _0x194950=_0x1015dc['getChildAfterChild'](this['index_'],_0x2a82a5,this['reverse_']);for(;_0x194950!=null&&(_0x194950['name']===_0x3f29e1||_0x2bc2b0['hasChild'](_0x194950['name']));)_0x194950=_0x1015dc['getChildAfterChild'](this['index_'],_0x194950,this['reverse_']);const _0x2ab919=_0x194950==null?0x1:_0x2cefd7(_0x194950,_0x5cb315);if(_0x2fcaf2&&!_0x3b1209['isEmpty']()&&_0x2ab919>=0x0)return _0x485360!=null&&_0x485360['trackChildChange'](Dt(_0x3f29e1,_0x3b1209,_0x487bcb)),_0x2bc2b0['updateImmediateChild'](_0x3f29e1,_0x3b1209);{_0x485360!=null&&_0x485360['trackChildChange'](Ot(_0x3f29e1,_0x487bcb));const _0x5e20ca=_0x2bc2b0['updateImmediateChild'](_0x3f29e1,g['EMPTY_NODE']);return _0x194950!=null&&this['rangedFilter_']['matches'](_0x194950)?(_0x485360!=null&&_0x485360['trackChildChange'](et(_0x194950['name'],_0x194950['node'])),_0x5e20ca['updateImmediateChild'](_0x194950['name'],_0x194950['node'])):_0x5e20ca;}}else return _0x3b1209['isEmpty']()?_0xc48741:_0x2fcaf2&&_0x2cefd7(_0x2a82a5,_0x5cb315)>=0x0?(_0x485360!=null&&(_0x485360['trackChildChange'](Ot(_0x2a82a5['name'],_0x2a82a5['node'])),_0x485360['trackChildChange'](et(_0x3f29e1,_0x3b1209))),_0x2bc2b0['updateImmediateChild'](_0x3f29e1,_0x3b1209)['updateImmediateChild'](_0x2a82a5['name'],g['EMPTY_NODE'])):_0xc48741;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x29c445=new Xi();return _0x29c445['limitSet_']=this['limitSet_'],_0x29c445['limit_']=this['limit_'],_0x29c445['startSet_']=this['startSet_'],_0x29c445['startAfterSet_']=this['startAfterSet_'],_0x29c445['indexStartValue_']=this['indexStartValue_'],_0x29c445['startNameSet_']=this['startNameSet_'],_0x29c445['indexStartName_']=this['indexStartName_'],_0x29c445['endSet_']=this['endSet_'],_0x29c445['endBeforeSet_']=this['endBeforeSet_'],_0x29c445['indexEndValue_']=this['indexEndValue_'],_0x29c445['endNameSet_']=this['endNameSet_'],_0x29c445['indexEndName_']=this['indexEndName_'],_0x29c445['index_']=this['index_'],_0x29c445['viewFrom_']=this['viewFrom_'],_0x29c445;}}function Kh(_0x52ed3f){return _0x52ed3f['loadsAllData']()?new Ji(_0x52ed3f['getIndex']()):_0x52ed3f['hasLimit']()?new jh(_0x52ed3f):new Mt(_0x52ed3f);}function Yh(_0x5136ad,_0x3bb1c9){const _0x481460=_0x5136ad['copy']();return _0x481460['limitSet_']=!0x0,_0x481460['limit_']=_0x3bb1c9,_0x481460['viewFrom_']='l',_0x481460;}function Qh(_0x1dfcf9,_0x5e4547,_0x5d1388){const _0x562547=_0x1dfcf9['copy']();return _0x562547['startSet_']=!0x0,_0x5e4547===void 0x0&&(_0x5e4547=null),_0x562547['indexStartValue_']=_0x5e4547,_0x5d1388!=null?(_0x562547['startNameSet_']=!0x0,_0x562547['indexStartName_']=_0x5d1388):(_0x562547['startNameSet_']=!0x1,_0x562547['indexStartName_']=''),_0x562547;}function Jh(_0x3ee308,_0x12323b,_0x71b8a3){const _0xec8a70=_0x3ee308['copy']();return _0xec8a70['endSet_']=!0x0,_0x12323b===void 0x0&&(_0x12323b=null),_0xec8a70['indexEndValue_']=_0x12323b,_0x71b8a3!==void 0x0?(_0xec8a70['endNameSet_']=!0x0,_0xec8a70['indexEndName_']=_0x71b8a3):(_0xec8a70['endNameSet_']=!0x1,_0xec8a70['indexEndName_']=''),_0xec8a70;}function xo(_0x40e49d,_0x21c8fe){const _0x253286=_0x40e49d['copy']();return _0x253286['index_']=_0x21c8fe,_0x253286;}function sr(_0x4e2abf){const _0x30acdc={};if(_0x4e2abf['isDefault']())return _0x30acdc;let _0x262ef3;if(_0x4e2abf['index_']===R?_0x262ef3='$priority':_0x4e2abf['index_']===Mo?_0x262ef3='$value':_0x4e2abf['index_']===ye?_0x262ef3='$key':(f(_0x4e2abf['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x262ef3=_0x4e2abf['index_']['toString']()),_0x30acdc['orderBy']=O(_0x262ef3),_0x4e2abf['startSet_']){const _0xe75a85=_0x4e2abf['startAfterSet_']?'startAfter':'startAt';_0x30acdc[_0xe75a85]=O(_0x4e2abf['indexStartValue_']),_0x4e2abf['startNameSet_']&&(_0x30acdc[_0xe75a85]+=','+O(_0x4e2abf['indexStartName_']));}if(_0x4e2abf['endSet_']){const _0x505493=_0x4e2abf['endBeforeSet_']?'endBefore':'endAt';_0x30acdc[_0x505493]=O(_0x4e2abf['indexEndValue_']),_0x4e2abf['endNameSet_']&&(_0x30acdc[_0x505493]+=','+O(_0x4e2abf['indexEndName_']));}return _0x4e2abf['limitSet_']&&(_0x4e2abf['isViewFromLeft']()?_0x30acdc['limitToFirst']=_0x4e2abf['limit_']:_0x30acdc['limitToLast']=_0x4e2abf['limit_']),_0x30acdc;}function rr(_0x4c3fa6){const _0x321932={};if(_0x4c3fa6['startSet_']&&(_0x321932['sp']=_0x4c3fa6['indexStartValue_'],_0x4c3fa6['startNameSet_']&&(_0x321932['sn']=_0x4c3fa6['indexStartName_']),_0x321932['sin']=!_0x4c3fa6['startAfterSet_']),_0x4c3fa6['endSet_']&&(_0x321932['ep']=_0x4c3fa6['indexEndValue_'],_0x4c3fa6['endNameSet_']&&(_0x321932['en']=_0x4c3fa6['indexEndName_']),_0x321932['ein']=!_0x4c3fa6['endBeforeSet_']),_0x4c3fa6['limitSet_']){_0x321932['l']=_0x4c3fa6['limit_'];let _0x3cc6ca=_0x4c3fa6['viewFrom_'];_0x3cc6ca===''&&(_0x4c3fa6['isViewFromLeft']()?_0x3cc6ca='l':_0x3cc6ca='r'),_0x321932['vf']=_0x3cc6ca;}return _0x4c3fa6['index_']!==R&&(_0x321932['i']=_0x4c3fa6['index_']['toString']()),_0x321932;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x3582cf){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x41f742,_0x38afbf){return _0x38afbf!==void 0x0?'tag$'+_0x38afbf:(f(_0x41f742['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x41f742['_path']['toString']());}constructor(_0x6b8002,_0x3f6582,_0x497775,_0x5762bc){super(),this['repoInfo_']=_0x6b8002,this['onDataUpdate_']=_0x3f6582,this['authTokenProvider_']=_0x497775,this['appCheckTokenProvider_']=_0x5762bc,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x145fea,_0x16cdd6,_0xab0609,_0x385639){const _0x41353c=_0x145fea['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x41353c+'\x20'+_0x145fea['_queryIdentifier']);const _0x362675=pn['getListenId_'](_0x145fea,_0xab0609),_0x49a3ca={};this['listens_'][_0x362675]=_0x49a3ca;const _0xa85dcf=sr(_0x145fea['_queryParams']);this['restRequest_'](_0x41353c+'.json',_0xa85dcf,(_0x10fc15,_0x1c96d2)=>{let _0x58ab9b=_0x1c96d2;if(_0x10fc15===0x194&&(_0x58ab9b=null,_0x10fc15=null),_0x10fc15===null&&this['onDataUpdate_'](_0x41353c,_0x58ab9b,!0x1,_0xab0609),De(this['listens_'],_0x362675)===_0x49a3ca){let _0x1c4cf6;_0x10fc15?_0x10fc15===0x191?_0x1c4cf6='permission_denied':_0x1c4cf6='rest_error:'+_0x10fc15:_0x1c4cf6='ok',_0x385639(_0x1c4cf6,null);}});}['unlisten'](_0x3c02fb,_0x291ab4){const _0x9caf44=pn['getListenId_'](_0x3c02fb,_0x291ab4);delete this['listens_'][_0x9caf44];}['get'](_0x36ecf5){const _0x4a92ba=sr(_0x36ecf5['_queryParams']),_0x20758a=_0x36ecf5['_path']['toString'](),_0x4e9a51=new ot();return this['restRequest_'](_0x20758a+'.json',_0x4a92ba,(_0x23d0dd,_0x2d778d)=>{let _0x5dc909=_0x2d778d;_0x23d0dd===0x194&&(_0x5dc909=null,_0x23d0dd=null),_0x23d0dd===null?(this['onDataUpdate_'](_0x20758a,_0x5dc909,!0x1,null),_0x4e9a51['resolve'](_0x5dc909)):_0x4e9a51['reject'](new Error(_0x5dc909));}),_0x4e9a51['promise'];}['refreshAuthToken'](_0x166b33){}['restRequest_'](_0x3cf224,_0x597696={},_0x29b064){return _0x597696['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x4b4be9,_0x5b6a1c])=>{_0x4b4be9&&_0x4b4be9['accessToken']&&(_0x597696['auth']=_0x4b4be9['accessToken']),_0x5b6a1c&&_0x5b6a1c['token']&&(_0x597696['ac']=_0x5b6a1c['token']);const _0x36af41=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x3cf224+'?ns='+this['repoInfo_']['namespace']+ct(_0x597696);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x36af41);const _0x1984d4=new XMLHttpRequest();_0x1984d4['onreadystatechange']=()=>{if(_0x29b064&&_0x1984d4['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x36af41+'\x20received.\x20status:',_0x1984d4['status'],'response:',_0x1984d4['responseText']);let _0x3b8ef7=null;if(_0x1984d4['status']>=0xc8&&_0x1984d4['status']<0x12c){try{_0x3b8ef7=At(_0x1984d4['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x36af41+':\x20'+_0x1984d4['responseText']);}_0x29b064(null,_0x3b8ef7);}else _0x1984d4['status']!==0x191&&_0x1984d4['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x36af41+'\x20Status:\x20'+_0x1984d4['status']),_0x29b064(_0x1984d4['status']);_0x29b064=null;}},_0x1984d4['open']('GET',_0x36af41,!0x0),_0x1984d4['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0xf01283){return this['rootNode_']['getChild'](_0xf01283);}['updateSnapshot'](_0x4e385e,_0x2d797c){this['rootNode_']=this['rootNode_']['updateChild'](_0x4e385e,_0x2d797c);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x5e160f,_0x1f81b5,_0x533828){if(v(_0x1f81b5))_0x5e160f['value']=_0x533828,_0x5e160f['children']['clear']();else{if(_0x5e160f['value']!==null)_0x5e160f['value']=_0x5e160f['value']['updateChild'](_0x1f81b5,_0x533828);else{const _0x462262=y(_0x1f81b5);_0x5e160f['children']['has'](_0x462262)||_0x5e160f['children']['set'](_0x462262,_n());const _0x4d8da1=_0x5e160f['children']['get'](_0x462262);_0x1f81b5=b(_0x1f81b5),Fo(_0x4d8da1,_0x1f81b5,_0x533828);}}}function Ii(_0x36043e,_0x43f009,_0x3d4fac){_0x36043e['value']!==null?_0x3d4fac(_0x43f009,_0x36043e['value']):Zh(_0x36043e,(_0x33b86a,_0x16e762)=>{const _0xccdebe=new C(_0x43f009['toString']()+'/'+_0x33b86a);Ii(_0x16e762,_0xccdebe,_0x3d4fac);});}function Zh(_0x5086c0,_0x4abfbc){_0x5086c0['children']['forEach']((_0x276f3b,_0x112e69)=>{_0x4abfbc(_0x112e69,_0x276f3b);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x56f6e8){this['collection_']=_0x56f6e8,this['last_']=null;}['get'](){const _0x43749a=this['collection_']['get'](),_0x3fd10a={..._0x43749a};return this['last_']&&x(this['last_'],(_0x4f945b,_0x45a823)=>{_0x3fd10a[_0x4f945b]=_0x3fd10a[_0x4f945b]-_0x45a823;}),this['last_']=_0x43749a,_0x3fd10a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x27d1f9,_0x12242c){this['server_']=_0x12242c,this['statsToReport_']={},this['statsListener_']=new eu(_0x27d1f9);const _0x55b174=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x55b174));}['reportStats_'](){const _0xcc411e=this['statsListener_']['get'](),_0x3aed78={};let _0x26ebbe=!0x1;x(_0xcc411e,(_0x81aee6,_0x587b49)=>{_0x587b49>0x0&&J(this['statsToReport_'],_0x81aee6)&&(_0x3aed78[_0x81aee6]=_0x587b49,_0x26ebbe=!0x0);}),_0x26ebbe&&this['server_']['reportStats'](_0x3aed78),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x5defe9){_0x5defe9[_0x5defe9['OVERWRITE']=0x0]='OVERWRITE',_0x5defe9[_0x5defe9['MERGE']=0x1]='MERGE',_0x5defe9[_0x5defe9['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x5defe9[_0x5defe9['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x2ceaaa){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x2ceaaa,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x351555,_0x43473c,_0xc8e14e){this['path']=_0x351555,this['affectedTree']=_0x43473c,this['revert']=_0xc8e14e,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x28abc2){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x5e12f1=this['affectedTree']['subtree'](new C(_0x28abc2));return new gn(w(),_0x5e12f1,this['revert']);}}else return f(y(this['path'])===_0x28abc2,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x4eebb3,_0x55c4e7){this['source']=_0x4eebb3,this['path']=_0x55c4e7,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0xc2ff1b){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x57903d,_0x10382d,_0x3d793b){this['source']=_0x57903d,this['path']=_0x10382d,this['snap']=_0x3d793b,this['type']=j['OVERWRITE'];}['operationForChild'](_0x560bf5){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x560bf5)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x503e40,_0x5691fd,_0x472127){this['source']=_0x503e40,this['path']=_0x5691fd,this['children']=_0x472127,this['type']=j['MERGE'];}['operationForChild'](_0x3d45ec){if(v(this['path'])){const _0x112895=this['children']['subtree'](new C(_0x3d45ec));return _0x112895['isEmpty']()?null:_0x112895['value']?new Ue(this['source'],w(),_0x112895['value']):new tt(this['source'],w(),_0x112895);}else return f(y(this['path'])===_0x3d45ec,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x25686c,_0x3dd3ee,_0x119bf5){this['node_']=_0x25686c,this['fullyInitialized_']=_0x3dd3ee,this['filtered_']=_0x119bf5;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x455a3b){if(v(_0x455a3b))return this['isFullyInitialized']()&&!this['filtered_'];const _0x560e94=y(_0x455a3b);return this['isCompleteForChild'](_0x560e94);}['isCompleteForChild'](_0x4e6632){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x4e6632);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0xbe425e){this['query_']=_0xbe425e,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x21481b,_0x46d9a8,_0x5e12c8,_0x37e030){const _0x2e054e=[],_0x58d91d=[];return _0x46d9a8['forEach'](_0x47a307=>{_0x47a307['type']==='child_changed'&&_0x21481b['index_']['indexedValueChanged'](_0x47a307['oldSnap'],_0x47a307['snapshotNode'])&&_0x58d91d['push'](zh(_0x47a307['childName'],_0x47a307['snapshotNode']));}),yt(_0x21481b,_0x2e054e,'child_removed',_0x46d9a8,_0x37e030,_0x5e12c8),yt(_0x21481b,_0x2e054e,'child_added',_0x46d9a8,_0x37e030,_0x5e12c8),yt(_0x21481b,_0x2e054e,'child_moved',_0x58d91d,_0x37e030,_0x5e12c8),yt(_0x21481b,_0x2e054e,'child_changed',_0x46d9a8,_0x37e030,_0x5e12c8),yt(_0x21481b,_0x2e054e,'value',_0x46d9a8,_0x37e030,_0x5e12c8),_0x2e054e;}function yt(_0x4265b6,_0x50dd54,_0x21d098,_0x3e3855,_0x2ec088,_0x333c5b){const _0x5a102b=_0x3e3855['filter'](_0x39a004=>_0x39a004['type']===_0x21d098);_0x5a102b['sort']((_0x29174e,_0x3fb01a)=>au(_0x4265b6,_0x29174e,_0x3fb01a)),_0x5a102b['forEach'](_0x2ec429=>{const _0x3c47ab=ou(_0x4265b6,_0x2ec429,_0x333c5b);_0x2ec088['forEach'](_0x2730b3=>{_0x2730b3['respondsTo'](_0x2ec429['type'])&&_0x50dd54['push'](_0x2730b3['createEvent'](_0x3c47ab,_0x4265b6['query_']));});});}function ou(_0xe9a5f6,_0x3cdb27,_0x5cb31b){return _0x3cdb27['type']==='value'||_0x3cdb27['type']==='child_removed'||(_0x3cdb27['prevName']=_0x5cb31b['getPredecessorChildName'](_0x3cdb27['childName'],_0x3cdb27['snapshotNode'],_0xe9a5f6['index_'])),_0x3cdb27;}function au(_0x57a39b,_0x11fb5b,_0x1687a9){if(_0x11fb5b['childName']==null||_0x1687a9['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x4b8df4=new E(_0x11fb5b['childName'],_0x11fb5b['snapshotNode']),_0x34a11a=new E(_0x1687a9['childName'],_0x1687a9['snapshotNode']);return _0x57a39b['index_']['compare'](_0x4b8df4,_0x34a11a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x7b981e,_0x95186d){return{'eventCache':_0x7b981e,'serverCache':_0x95186d};}function Tt(_0x1a4fba,_0x2db646,_0x4b66ea,_0x54fc44){return Mn(new Ce(_0x2db646,_0x4b66ea,_0x54fc44),_0x1a4fba['serverCache']);}function Uo(_0x5e5e2f,_0x5c9f38,_0x8c21ad,_0x9fbb0){return Mn(_0x5e5e2f['eventCache'],new Ce(_0x5c9f38,_0x8c21ad,_0x9fbb0));}function mn(_0x3475a1){return _0x3475a1['eventCache']['isFullyInitialized']()?_0x3475a1['eventCache']['getNode']():null;}function We(_0x44d4a4){return _0x44d4a4['serverCache']['isFullyInitialized']()?_0x44d4a4['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x4f7ab1){let _0x4ed5e4=new S(null);return x(_0x4f7ab1,(_0x2896e7,_0x2af7f5)=>{_0x4ed5e4=_0x4ed5e4['set'](new C(_0x2896e7),_0x2af7f5);}),_0x4ed5e4;}constructor(_0x16de51,_0x3e3d2c=cu()){this['value']=_0x16de51,this['children']=_0x3e3d2c;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x451e7f,_0x20ad75){if(this['value']!=null&&_0x20ad75(this['value']))return{'path':w(),'value':this['value']};if(v(_0x451e7f))return null;{const _0x3d8515=y(_0x451e7f),_0x104f6c=this['children']['get'](_0x3d8515);if(_0x104f6c!==null){const _0x5160d3=_0x104f6c['findRootMostMatchingPathAndValue'](b(_0x451e7f),_0x20ad75);return _0x5160d3!=null?{'path':k(new C(_0x3d8515),_0x5160d3['path']),'value':_0x5160d3['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x3e129c){return this['findRootMostMatchingPathAndValue'](_0x3e129c,()=>!0x0);}['subtree'](_0x4bc183){if(v(_0x4bc183))return this;{const _0x3a8cb9=y(_0x4bc183),_0x2124e5=this['children']['get'](_0x3a8cb9);return _0x2124e5!==null?_0x2124e5['subtree'](b(_0x4bc183)):new S(null);}}['set'](_0x4a3f1c,_0x311d5e){if(v(_0x4a3f1c))return new S(_0x311d5e,this['children']);{const _0x3a1ec4=y(_0x4a3f1c),_0x3f25b3=(this['children']['get'](_0x3a1ec4)||new S(null))['set'](b(_0x4a3f1c),_0x311d5e),_0x1958bc=this['children']['insert'](_0x3a1ec4,_0x3f25b3);return new S(this['value'],_0x1958bc);}}['remove'](_0x21d081){if(v(_0x21d081))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x306628=y(_0x21d081),_0x387e6b=this['children']['get'](_0x306628);if(_0x387e6b){const _0x444b73=_0x387e6b['remove'](b(_0x21d081));let _0x225a9e;return _0x444b73['isEmpty']()?_0x225a9e=this['children']['remove'](_0x306628):_0x225a9e=this['children']['insert'](_0x306628,_0x444b73),this['value']===null&&_0x225a9e['isEmpty']()?new S(null):new S(this['value'],_0x225a9e);}else return this;}}['get'](_0x2352fd){if(v(_0x2352fd))return this['value'];{const _0x226f93=y(_0x2352fd),_0x40c705=this['children']['get'](_0x226f93);return _0x40c705?_0x40c705['get'](b(_0x2352fd)):null;}}['setTree'](_0x468f30,_0x49ce56){if(v(_0x468f30))return _0x49ce56;{const _0x5373c0=y(_0x468f30),_0x5bb823=(this['children']['get'](_0x5373c0)||new S(null))['setTree'](b(_0x468f30),_0x49ce56);let _0x1fcd1b;return _0x5bb823['isEmpty']()?_0x1fcd1b=this['children']['remove'](_0x5373c0):_0x1fcd1b=this['children']['insert'](_0x5373c0,_0x5bb823),new S(this['value'],_0x1fcd1b);}}['fold'](_0x51f81e){return this['fold_'](w(),_0x51f81e);}['fold_'](_0x1405ce,_0x398d1b){const _0x4d70d6={};return this['children']['inorderTraversal']((_0x23e0a8,_0x1430d7)=>{_0x4d70d6[_0x23e0a8]=_0x1430d7['fold_'](k(_0x1405ce,_0x23e0a8),_0x398d1b);}),_0x398d1b(_0x1405ce,this['value'],_0x4d70d6);}['findOnPath'](_0x2ff396,_0x26fb3a){return this['findOnPath_'](_0x2ff396,w(),_0x26fb3a);}['findOnPath_'](_0xcaba95,_0x33d14b,_0x145f10){const _0x3036a9=this['value']?_0x145f10(_0x33d14b,this['value']):!0x1;if(_0x3036a9)return _0x3036a9;if(v(_0xcaba95))return null;{const _0x54b9e5=y(_0xcaba95),_0xa73fc=this['children']['get'](_0x54b9e5);return _0xa73fc?_0xa73fc['findOnPath_'](b(_0xcaba95),k(_0x33d14b,_0x54b9e5),_0x145f10):null;}}['foreachOnPath'](_0x535561,_0x2daca6){return this['foreachOnPath_'](_0x535561,w(),_0x2daca6);}['foreachOnPath_'](_0x130d92,_0x47ffd6,_0x2ddb36){if(v(_0x130d92))return this;{this['value']&&_0x2ddb36(_0x47ffd6,this['value']);const _0x441fef=y(_0x130d92),_0x34dfe1=this['children']['get'](_0x441fef);return _0x34dfe1?_0x34dfe1['foreachOnPath_'](b(_0x130d92),k(_0x47ffd6,_0x441fef),_0x2ddb36):new S(null);}}['foreach'](_0x1b92a3){this['foreach_'](w(),_0x1b92a3);}['foreach_'](_0x40173b,_0x28ab9e){this['children']['inorderTraversal']((_0x7f03a9,_0x2c3de3)=>{_0x2c3de3['foreach_'](k(_0x40173b,_0x7f03a9),_0x28ab9e);}),this['value']&&_0x28ab9e(_0x40173b,this['value']);}['foreachChild'](_0x22263d){this['children']['inorderTraversal']((_0x5a2052,_0x43c6bb)=>{_0x43c6bb['value']&&_0x22263d(_0x5a2052,_0x43c6bb['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x500146){this['writeTree_']=_0x500146;}static['empty'](){return new Y(new S(null));}}function St(_0x58edbf,_0x1b8853,_0x240e35){if(v(_0x1b8853))return new Y(new S(_0x240e35));{const _0x4b5fd2=_0x58edbf['writeTree_']['findRootMostValueAndPath'](_0x1b8853);if(_0x4b5fd2!=null){const _0x2cdbdf=_0x4b5fd2['path'];let _0x595be4=_0x4b5fd2['value'];const _0x6997f8=F(_0x2cdbdf,_0x1b8853);return _0x595be4=_0x595be4['updateChild'](_0x6997f8,_0x240e35),new Y(_0x58edbf['writeTree_']['set'](_0x2cdbdf,_0x595be4));}else{const _0x3be4ce=new S(_0x240e35),_0x2e58fc=_0x58edbf['writeTree_']['setTree'](_0x1b8853,_0x3be4ce);return new Y(_0x2e58fc);}}}function wi(_0x32538d,_0x53acca,_0x1848f2){let _0x188f28=_0x32538d;return x(_0x1848f2,(_0x52097a,_0x1a21ff)=>{_0x188f28=St(_0x188f28,k(_0x53acca,_0x52097a),_0x1a21ff);}),_0x188f28;}function ar(_0x491944,_0x558492){if(v(_0x558492))return Y['empty']();{const _0x3a62ff=_0x491944['writeTree_']['setTree'](_0x558492,new S(null));return new Y(_0x3a62ff);}}function Ci(_0x5913f3,_0x5a0a9d){return $e(_0x5913f3,_0x5a0a9d)!=null;}function $e(_0x96fbaf,_0x368863){const _0x413d60=_0x96fbaf['writeTree_']['findRootMostValueAndPath'](_0x368863);return _0x413d60!=null?_0x96fbaf['writeTree_']['get'](_0x413d60['path'])['getChild'](F(_0x413d60['path'],_0x368863)):null;}function cr(_0x21f68c){const _0x1b1189=[],_0x3da384=_0x21f68c['writeTree_']['value'];return _0x3da384!=null?_0x3da384['isLeafNode']()||_0x3da384['forEachChild'](R,(_0x2b071f,_0x47bef0)=>{_0x1b1189['push'](new E(_0x2b071f,_0x47bef0));}):_0x21f68c['writeTree_']['children']['inorderTraversal']((_0x23557a,_0x5515d5)=>{_0x5515d5['value']!=null&&_0x1b1189['push'](new E(_0x23557a,_0x5515d5['value']));}),_0x1b1189;}function ve(_0x11c2ff,_0xc060b2){if(v(_0xc060b2))return _0x11c2ff;{const _0x78f6b4=$e(_0x11c2ff,_0xc060b2);return _0x78f6b4!=null?new Y(new S(_0x78f6b4)):new Y(_0x11c2ff['writeTree_']['subtree'](_0xc060b2));}}function Ti(_0x4683ec){return _0x4683ec['writeTree_']['isEmpty']();}function nt(_0x6f2052,_0x1c3efb){return Wo(w(),_0x6f2052['writeTree_'],_0x1c3efb);}function Wo(_0x8b52f5,_0x1edf03,_0x33b404){if(_0x1edf03['value']!=null)return _0x33b404['updateChild'](_0x8b52f5,_0x1edf03['value']);{let _0x3bff1b=null;return _0x1edf03['children']['inorderTraversal']((_0x56fe55,_0x443470)=>{_0x56fe55==='.priority'?(f(_0x443470['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x3bff1b=_0x443470['value']):_0x33b404=Wo(k(_0x8b52f5,_0x56fe55),_0x443470,_0x33b404);}),!_0x33b404['getChild'](_0x8b52f5)['isEmpty']()&&_0x3bff1b!==null&&(_0x33b404=_0x33b404['updateChild'](k(_0x8b52f5,'.priority'),_0x3bff1b)),_0x33b404;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x3c5cb1,_0x43a4a7){return $o(_0x43a4a7,_0x3c5cb1);}function lu(_0xf90b3c,_0x5b8e8a,_0x39e351,_0x1e057e,_0x31a9dc){f(_0x1e057e>_0xf90b3c['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x31a9dc===void 0x0&&(_0x31a9dc=!0x0),_0xf90b3c['allWrites']['push']({'path':_0x5b8e8a,'snap':_0x39e351,'writeId':_0x1e057e,'visible':_0x31a9dc}),_0x31a9dc&&(_0xf90b3c['visibleWrites']=St(_0xf90b3c['visibleWrites'],_0x5b8e8a,_0x39e351)),_0xf90b3c['lastWriteId']=_0x1e057e;}function hu(_0x3ad6b0,_0x2f7e3d,_0x714f08,_0x4b0777){f(_0x4b0777>_0x3ad6b0['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x3ad6b0['allWrites']['push']({'path':_0x2f7e3d,'children':_0x714f08,'writeId':_0x4b0777,'visible':!0x0}),_0x3ad6b0['visibleWrites']=wi(_0x3ad6b0['visibleWrites'],_0x2f7e3d,_0x714f08),_0x3ad6b0['lastWriteId']=_0x4b0777;}function uu(_0x33dd48,_0x57bfd0){for(let _0x45433f=0x0;_0x45433f<_0x33dd48['allWrites']['length'];_0x45433f++){const _0x2e50c7=_0x33dd48['allWrites'][_0x45433f];if(_0x2e50c7['writeId']===_0x57bfd0)return _0x2e50c7;}return null;}function du(_0x13b932,_0x26400f){const _0x4476f0=_0x13b932['allWrites']['findIndex'](_0x55194e=>_0x55194e['writeId']===_0x26400f);f(_0x4476f0>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x4944c9=_0x13b932['allWrites'][_0x4476f0];_0x13b932['allWrites']['splice'](_0x4476f0,0x1);let _0x5b7b0f=_0x4944c9['visible'],_0x49b9b5=!0x1,_0x3f74a3=_0x13b932['allWrites']['length']-0x1;for(;_0x5b7b0f&&_0x3f74a3>=0x0;){const _0x43ed35=_0x13b932['allWrites'][_0x3f74a3];_0x43ed35['visible']&&(_0x3f74a3>=_0x4476f0&&fu(_0x43ed35,_0x4944c9['path'])?_0x5b7b0f=!0x1:G(_0x4944c9['path'],_0x43ed35['path'])&&(_0x49b9b5=!0x0)),_0x3f74a3--;}if(_0x5b7b0f){if(_0x49b9b5)return pu(_0x13b932),!0x0;if(_0x4944c9['snap'])_0x13b932['visibleWrites']=ar(_0x13b932['visibleWrites'],_0x4944c9['path']);else{const _0x5da9c1=_0x4944c9['children'];x(_0x5da9c1,_0x452e80=>{_0x13b932['visibleWrites']=ar(_0x13b932['visibleWrites'],k(_0x4944c9['path'],_0x452e80));});}return!0x0;}else return!0x1;}function fu(_0x5acef0,_0x179ecd){if(_0x5acef0['snap'])return G(_0x5acef0['path'],_0x179ecd);for(const _0x8da5be in _0x5acef0['children'])if(_0x5acef0['children']['hasOwnProperty'](_0x8da5be)&&G(k(_0x5acef0['path'],_0x8da5be),_0x179ecd))return!0x0;return!0x1;}function pu(_0x1cb4d9){_0x1cb4d9['visibleWrites']=Bo(_0x1cb4d9['allWrites'],_u,w()),_0x1cb4d9['allWrites']['length']>0x0?_0x1cb4d9['lastWriteId']=_0x1cb4d9['allWrites'][_0x1cb4d9['allWrites']['length']-0x1]['writeId']:_0x1cb4d9['lastWriteId']=-0x1;}function _u(_0x4d3c5a){return _0x4d3c5a['visible'];}function Bo(_0xee9662,_0x2997be,_0x200aa2){let _0x1f054f=Y['empty']();for(let _0x5a2eff=0x0;_0x5a2eff<_0xee9662['length'];++_0x5a2eff){const _0x59b2b6=_0xee9662[_0x5a2eff];if(_0x2997be(_0x59b2b6)){const _0x34bee2=_0x59b2b6['path'];let _0x240341;if(_0x59b2b6['snap'])G(_0x200aa2,_0x34bee2)?(_0x240341=F(_0x200aa2,_0x34bee2),_0x1f054f=St(_0x1f054f,_0x240341,_0x59b2b6['snap'])):G(_0x34bee2,_0x200aa2)&&(_0x240341=F(_0x34bee2,_0x200aa2),_0x1f054f=St(_0x1f054f,w(),_0x59b2b6['snap']['getChild'](_0x240341)));else{if(_0x59b2b6['children']){if(G(_0x200aa2,_0x34bee2))_0x240341=F(_0x200aa2,_0x34bee2),_0x1f054f=wi(_0x1f054f,_0x240341,_0x59b2b6['children']);else{if(G(_0x34bee2,_0x200aa2)){if(_0x240341=F(_0x34bee2,_0x200aa2),v(_0x240341))_0x1f054f=wi(_0x1f054f,w(),_0x59b2b6['children']);else{const _0x54ca1c=De(_0x59b2b6['children'],y(_0x240341));if(_0x54ca1c){const _0xdced35=_0x54ca1c['getChild'](b(_0x240341));_0x1f054f=St(_0x1f054f,w(),_0xdced35);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x1f054f;}function Vo(_0x3fae28,_0x6698da,_0x32c0ae,_0x2baf13,_0x6cdf04){if(!_0x2baf13&&!_0x6cdf04){const _0xf7784c=$e(_0x3fae28['visibleWrites'],_0x6698da);if(_0xf7784c!=null)return _0xf7784c;{const _0x16003b=ve(_0x3fae28['visibleWrites'],_0x6698da);if(Ti(_0x16003b))return _0x32c0ae;if(_0x32c0ae==null&&!Ci(_0x16003b,w()))return null;{const _0x37e5bf=_0x32c0ae||g['EMPTY_NODE'];return nt(_0x16003b,_0x37e5bf);}}}else{const _0x51ecc7=ve(_0x3fae28['visibleWrites'],_0x6698da);if(!_0x6cdf04&&Ti(_0x51ecc7))return _0x32c0ae;if(!_0x6cdf04&&_0x32c0ae==null&&!Ci(_0x51ecc7,w()))return null;{const _0x5ad49a=function(_0x56866f){return(_0x56866f['visible']||_0x6cdf04)&&(!_0x2baf13||!~_0x2baf13['indexOf'](_0x56866f['writeId']))&&(G(_0x56866f['path'],_0x6698da)||G(_0x6698da,_0x56866f['path']));},_0x5c9d07=Bo(_0x3fae28['allWrites'],_0x5ad49a,_0x6698da),_0x5393f8=_0x32c0ae||g['EMPTY_NODE'];return nt(_0x5c9d07,_0x5393f8);}}}function gu(_0x2528bb,_0x4e1ffc,_0x44c45c){let _0x197775=g['EMPTY_NODE'];const _0x517640=$e(_0x2528bb['visibleWrites'],_0x4e1ffc);if(_0x517640)return _0x517640['isLeafNode']()||_0x517640['forEachChild'](R,(_0x28dbb4,_0x24fd7f)=>{_0x197775=_0x197775['updateImmediateChild'](_0x28dbb4,_0x24fd7f);}),_0x197775;if(_0x44c45c){const _0x4de119=ve(_0x2528bb['visibleWrites'],_0x4e1ffc);return _0x44c45c['forEachChild'](R,(_0x5211f1,_0x5c3de3)=>{const _0x3fc9db=nt(ve(_0x4de119,new C(_0x5211f1)),_0x5c3de3);_0x197775=_0x197775['updateImmediateChild'](_0x5211f1,_0x3fc9db);}),cr(_0x4de119)['forEach'](_0x4c5c1b=>{_0x197775=_0x197775['updateImmediateChild'](_0x4c5c1b['name'],_0x4c5c1b['node']);}),_0x197775;}else{const _0x4e64d7=ve(_0x2528bb['visibleWrites'],_0x4e1ffc);return cr(_0x4e64d7)['forEach'](_0x4c5d0a=>{_0x197775=_0x197775['updateImmediateChild'](_0x4c5d0a['name'],_0x4c5d0a['node']);}),_0x197775;}}function mu(_0x437c1e,_0x7a19f4,_0x3aa02a,_0x30c05e,_0x509596){f(_0x30c05e||_0x509596,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x1b4536=k(_0x7a19f4,_0x3aa02a);if(Ci(_0x437c1e['visibleWrites'],_0x1b4536))return null;{const _0x533f17=ve(_0x437c1e['visibleWrites'],_0x1b4536);return Ti(_0x533f17)?_0x509596['getChild'](_0x3aa02a):nt(_0x533f17,_0x509596['getChild'](_0x3aa02a));}}function yu(_0x1713c6,_0x175b7b,_0x164823,_0x2fccf1){const _0x5b376b=k(_0x175b7b,_0x164823),_0x3e7221=$e(_0x1713c6['visibleWrites'],_0x5b376b);if(_0x3e7221!=null)return _0x3e7221;if(_0x2fccf1['isCompleteForChild'](_0x164823)){const _0x2718d6=ve(_0x1713c6['visibleWrites'],_0x5b376b);return nt(_0x2718d6,_0x2fccf1['getNode']()['getImmediateChild'](_0x164823));}else return null;}function vu(_0x3d6fa6,_0x2ed706){return $e(_0x3d6fa6['visibleWrites'],_0x2ed706);}function Eu(_0x4760f1,_0xe04ac9,_0x4b5936,_0xc4b867,_0x2e6c70,_0x24018b,_0x297c6b){let _0x2637c3;const _0x482d49=ve(_0x4760f1['visibleWrites'],_0xe04ac9),_0x14cac8=$e(_0x482d49,w());if(_0x14cac8!=null)_0x2637c3=_0x14cac8;else{if(_0x4b5936!=null)_0x2637c3=nt(_0x482d49,_0x4b5936);else return[];}if(_0x2637c3=_0x2637c3['withIndex'](_0x297c6b),!_0x2637c3['isEmpty']()&&!_0x2637c3['isLeafNode']()){const _0x122669=[],_0x2ddd60=_0x297c6b['getCompare'](),_0x5708e2=_0x24018b?_0x2637c3['getReverseIteratorFrom'](_0xc4b867,_0x297c6b):_0x2637c3['getIteratorFrom'](_0xc4b867,_0x297c6b);let _0x1e9e49=_0x5708e2['getNext']();for(;_0x1e9e49&&_0x122669['length']<_0x2e6c70;)_0x2ddd60(_0x1e9e49,_0xc4b867)!==0x0&&_0x122669['push'](_0x1e9e49),_0x1e9e49=_0x5708e2['getNext']();return _0x122669;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x33c878,_0x573900,_0x5535c2,_0x419c7c){return Vo(_0x33c878['writeTree'],_0x33c878['treePath'],_0x573900,_0x5535c2,_0x419c7c);}function ns(_0x17772a,_0x22be8f){return gu(_0x17772a['writeTree'],_0x17772a['treePath'],_0x22be8f);}function lr(_0x14a86b,_0x2c8263,_0x3768e1,_0x2a8cd2){return mu(_0x14a86b['writeTree'],_0x14a86b['treePath'],_0x2c8263,_0x3768e1,_0x2a8cd2);}function vn(_0x28e7d5,_0x5d508c){return vu(_0x28e7d5['writeTree'],k(_0x28e7d5['treePath'],_0x5d508c));}function wu(_0x1084e2,_0x3177d6,_0x1fc582,_0x2f8a73,_0x49a144,_0xa33136){return Eu(_0x1084e2['writeTree'],_0x1084e2['treePath'],_0x3177d6,_0x1fc582,_0x2f8a73,_0x49a144,_0xa33136);}function is(_0x34b91e,_0x4d8fdc,_0x59cc49){return yu(_0x34b91e['writeTree'],_0x34b91e['treePath'],_0x4d8fdc,_0x59cc49);}function Ho(_0x5666b0,_0x458499){return $o(k(_0x5666b0['treePath'],_0x458499),_0x5666b0['writeTree']);}function $o(_0x579719,_0x5ea83c){return{'treePath':_0x579719,'writeTree':_0x5ea83c};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x538483){const _0x4a8e0c=_0x538483['type'],_0x5b705b=_0x538483['childName'];f(_0x4a8e0c==='child_added'||_0x4a8e0c==='child_changed'||_0x4a8e0c==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x5b705b!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0xa5c354=this['changeMap']['get'](_0x5b705b);if(_0xa5c354){const _0x5659f2=_0xa5c354['type'];if(_0x4a8e0c==='child_added'&&_0x5659f2==='child_removed')this['changeMap']['set'](_0x5b705b,Dt(_0x5b705b,_0x538483['snapshotNode'],_0xa5c354['snapshotNode']));else{if(_0x4a8e0c==='child_removed'&&_0x5659f2==='child_added')this['changeMap']['delete'](_0x5b705b);else{if(_0x4a8e0c==='child_removed'&&_0x5659f2==='child_changed')this['changeMap']['set'](_0x5b705b,Ot(_0x5b705b,_0xa5c354['oldSnap']));else{if(_0x4a8e0c==='child_changed'&&_0x5659f2==='child_added')this['changeMap']['set'](_0x5b705b,et(_0x5b705b,_0x538483['snapshotNode']));else{if(_0x4a8e0c==='child_changed'&&_0x5659f2==='child_changed')this['changeMap']['set'](_0x5b705b,Dt(_0x5b705b,_0x538483['snapshotNode'],_0xa5c354['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x538483+'\x20occurred\x20after\x20'+_0xa5c354);}}}}}else this['changeMap']['set'](_0x5b705b,_0x538483);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0xd83eed){return null;}['getChildAfterChild'](_0x4bf09b,_0x27275e,_0x5d63a6){return null;}}const Go=new Tu();class ss{constructor(_0x2a9c7a,_0x4e830a,_0x2879af=null){this['writes_']=_0x2a9c7a,this['viewCache_']=_0x4e830a,this['optCompleteServerCache_']=_0x2879af;}['getCompleteChild'](_0x309e61){const _0x38546d=this['viewCache_']['eventCache'];if(_0x38546d['isCompleteForChild'](_0x309e61))return _0x38546d['getNode']()['getImmediateChild'](_0x309e61);{const _0x4fa97e=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x309e61,_0x4fa97e);}}['getChildAfterChild'](_0x233a8d,_0x3eadc1,_0x17ee46){const _0x229fca=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x529a62=wu(this['writes_'],_0x229fca,_0x3eadc1,0x1,_0x17ee46,_0x233a8d);return _0x529a62['length']===0x0?null:_0x529a62[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0xb7b5ac){return{'filter':_0xb7b5ac};}function bu(_0x39b138,_0x1614dc){f(_0x1614dc['eventCache']['getNode']()['isIndexed'](_0x39b138['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x1614dc['serverCache']['getNode']()['isIndexed'](_0x39b138['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x1660e2,_0xd5bd21,_0x38942c,_0x113ee1,_0x13637d){const _0x3e857a=new Cu();let _0x408dab,_0x24385c;if(_0x38942c['type']===j['OVERWRITE']){const _0x1752ca=_0x38942c;_0x1752ca['source']['fromUser']?_0x408dab=Si(_0x1660e2,_0xd5bd21,_0x1752ca['path'],_0x1752ca['snap'],_0x113ee1,_0x13637d,_0x3e857a):(f(_0x1752ca['source']['fromServer'],'Unknown\x20source.'),_0x24385c=_0x1752ca['source']['tagged']||_0xd5bd21['serverCache']['isFiltered']()&&!v(_0x1752ca['path']),_0x408dab=En(_0x1660e2,_0xd5bd21,_0x1752ca['path'],_0x1752ca['snap'],_0x113ee1,_0x13637d,_0x24385c,_0x3e857a));}else{if(_0x38942c['type']===j['MERGE']){const _0x593805=_0x38942c;_0x593805['source']['fromUser']?_0x408dab=ku(_0x1660e2,_0xd5bd21,_0x593805['path'],_0x593805['children'],_0x113ee1,_0x13637d,_0x3e857a):(f(_0x593805['source']['fromServer'],'Unknown\x20source.'),_0x24385c=_0x593805['source']['tagged']||_0xd5bd21['serverCache']['isFiltered'](),_0x408dab=bi(_0x1660e2,_0xd5bd21,_0x593805['path'],_0x593805['children'],_0x113ee1,_0x13637d,_0x24385c,_0x3e857a));}else{if(_0x38942c['type']===j['ACK_USER_WRITE']){const _0x43c7be=_0x38942c;_0x43c7be['revert']?_0x408dab=Ou(_0x1660e2,_0xd5bd21,_0x43c7be['path'],_0x113ee1,_0x13637d,_0x3e857a):_0x408dab=Nu(_0x1660e2,_0xd5bd21,_0x43c7be['path'],_0x43c7be['affectedTree'],_0x113ee1,_0x13637d,_0x3e857a);}else{if(_0x38942c['type']===j['LISTEN_COMPLETE'])_0x408dab=Pu(_0x1660e2,_0xd5bd21,_0x38942c['path'],_0x113ee1,_0x3e857a);else throw rt('Unknown\x20operation\x20type:\x20'+_0x38942c['type']);}}}const _0x51bd1b=_0x3e857a['getChanges']();return Au(_0xd5bd21,_0x408dab,_0x51bd1b),{'viewCache':_0x408dab,'changes':_0x51bd1b};}function Au(_0x18796f,_0x51fc0a,_0x25987c){const _0x5b91aa=_0x51fc0a['eventCache'];if(_0x5b91aa['isFullyInitialized']()){const _0xa0b8ec=_0x5b91aa['getNode']()['isLeafNode']()||_0x5b91aa['getNode']()['isEmpty'](),_0x40d00e=mn(_0x18796f);(_0x25987c['length']>0x0||!_0x18796f['eventCache']['isFullyInitialized']()||_0xa0b8ec&&!_0x5b91aa['getNode']()['equals'](_0x40d00e)||!_0x5b91aa['getNode']()['getPriority']()['equals'](_0x40d00e['getPriority']()))&&_0x25987c['push'](Lo(mn(_0x51fc0a)));}}function qo(_0x4f2598,_0x4bf316,_0x137314,_0x54efeb,_0x130cc1,_0x57a6ce){const _0x2e538e=_0x4bf316['eventCache'];if(vn(_0x54efeb,_0x137314)!=null)return _0x4bf316;{let _0x2e053b,_0x643ad5;if(v(_0x137314)){if(f(_0x4bf316['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x4bf316['serverCache']['isFiltered']()){const _0x37f6fa=We(_0x4bf316),_0x33c437=_0x37f6fa instanceof g?_0x37f6fa:g['EMPTY_NODE'],_0x4aa3ed=ns(_0x54efeb,_0x33c437);_0x2e053b=_0x4f2598['filter']['updateFullNode'](_0x4bf316['eventCache']['getNode'](),_0x4aa3ed,_0x57a6ce);}else{const _0x453681=yn(_0x54efeb,We(_0x4bf316));_0x2e053b=_0x4f2598['filter']['updateFullNode'](_0x4bf316['eventCache']['getNode'](),_0x453681,_0x57a6ce);}}else{const _0x261272=y(_0x137314);if(_0x261272==='.priority'){f(we(_0x137314)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x12603a=_0x2e538e['getNode']();_0x643ad5=_0x4bf316['serverCache']['getNode']();const _0x7697fe=lr(_0x54efeb,_0x137314,_0x12603a,_0x643ad5);_0x7697fe!=null?_0x2e053b=_0x4f2598['filter']['updatePriority'](_0x12603a,_0x7697fe):_0x2e053b=_0x2e538e['getNode']();}else{const _0x564a48=b(_0x137314);let _0x2749ab;if(_0x2e538e['isCompleteForChild'](_0x261272)){_0x643ad5=_0x4bf316['serverCache']['getNode']();const _0x496834=lr(_0x54efeb,_0x137314,_0x2e538e['getNode'](),_0x643ad5);_0x496834!=null?_0x2749ab=_0x2e538e['getNode']()['getImmediateChild'](_0x261272)['updateChild'](_0x564a48,_0x496834):_0x2749ab=_0x2e538e['getNode']()['getImmediateChild'](_0x261272);}else _0x2749ab=is(_0x54efeb,_0x261272,_0x4bf316['serverCache']);_0x2749ab!=null?_0x2e053b=_0x4f2598['filter']['updateChild'](_0x2e538e['getNode'](),_0x261272,_0x2749ab,_0x564a48,_0x130cc1,_0x57a6ce):_0x2e053b=_0x2e538e['getNode']();}}return Tt(_0x4bf316,_0x2e053b,_0x2e538e['isFullyInitialized']()||v(_0x137314),_0x4f2598['filter']['filtersNodes']());}}function En(_0x202908,_0x52074d,_0x2eb032,_0x252929,_0x9eab1c,_0xa77951,_0x2803c5,_0x124110){const _0x1580b5=_0x52074d['serverCache'];let _0x3d5f66;const _0xb1be20=_0x2803c5?_0x202908['filter']:_0x202908['filter']['getIndexedFilter']();if(v(_0x2eb032))_0x3d5f66=_0xb1be20['updateFullNode'](_0x1580b5['getNode'](),_0x252929,null);else{if(_0xb1be20['filtersNodes']()&&!_0x1580b5['isFiltered']()){const _0xb6cdfa=_0x1580b5['getNode']()['updateChild'](_0x2eb032,_0x252929);_0x3d5f66=_0xb1be20['updateFullNode'](_0x1580b5['getNode'](),_0xb6cdfa,null);}else{const _0xafbae2=y(_0x2eb032);if(!_0x1580b5['isCompleteForPath'](_0x2eb032)&&we(_0x2eb032)>0x1)return _0x52074d;const _0x51f5f0=b(_0x2eb032),_0x338378=_0x1580b5['getNode']()['getImmediateChild'](_0xafbae2)['updateChild'](_0x51f5f0,_0x252929);_0xafbae2==='.priority'?_0x3d5f66=_0xb1be20['updatePriority'](_0x1580b5['getNode'](),_0x338378):_0x3d5f66=_0xb1be20['updateChild'](_0x1580b5['getNode'](),_0xafbae2,_0x338378,_0x51f5f0,Go,null);}}const _0x4c8b46=Uo(_0x52074d,_0x3d5f66,_0x1580b5['isFullyInitialized']()||v(_0x2eb032),_0xb1be20['filtersNodes']()),_0x373ce8=new ss(_0x9eab1c,_0x4c8b46,_0xa77951);return qo(_0x202908,_0x4c8b46,_0x2eb032,_0x9eab1c,_0x373ce8,_0x124110);}function Si(_0x55858e,_0x5b9db8,_0x4190db,_0x4e2ede,_0x402a04,_0x185867,_0x4eb55c){const _0x4a6a06=_0x5b9db8['eventCache'];let _0x1539b2,_0x288cd2;const _0x758779=new ss(_0x402a04,_0x5b9db8,_0x185867);if(v(_0x4190db))_0x288cd2=_0x55858e['filter']['updateFullNode'](_0x5b9db8['eventCache']['getNode'](),_0x4e2ede,_0x4eb55c),_0x1539b2=Tt(_0x5b9db8,_0x288cd2,!0x0,_0x55858e['filter']['filtersNodes']());else{const _0x52c99e=y(_0x4190db);if(_0x52c99e==='.priority')_0x288cd2=_0x55858e['filter']['updatePriority'](_0x5b9db8['eventCache']['getNode'](),_0x4e2ede),_0x1539b2=Tt(_0x5b9db8,_0x288cd2,_0x4a6a06['isFullyInitialized'](),_0x4a6a06['isFiltered']());else{const _0x7671ba=b(_0x4190db),_0x1fae30=_0x4a6a06['getNode']()['getImmediateChild'](_0x52c99e);let _0xd52879;if(v(_0x7671ba))_0xd52879=_0x4e2ede;else{const _0x860422=_0x758779['getCompleteChild'](_0x52c99e);_0x860422!=null?zi(_0x7671ba)==='.priority'&&_0x860422['getChild'](Ro(_0x7671ba))['isEmpty']()?_0xd52879=_0x860422:_0xd52879=_0x860422['updateChild'](_0x7671ba,_0x4e2ede):_0xd52879=g['EMPTY_NODE'];}if(_0x1fae30['equals'](_0xd52879))_0x1539b2=_0x5b9db8;else{const _0x5ec561=_0x55858e['filter']['updateChild'](_0x4a6a06['getNode'](),_0x52c99e,_0xd52879,_0x7671ba,_0x758779,_0x4eb55c);_0x1539b2=Tt(_0x5b9db8,_0x5ec561,_0x4a6a06['isFullyInitialized'](),_0x55858e['filter']['filtersNodes']());}}}return _0x1539b2;}function hr(_0x4f8646,_0x49974b){return _0x4f8646['eventCache']['isCompleteForChild'](_0x49974b);}function ku(_0x30df72,_0x17c0a3,_0xebcde0,_0x140faa,_0x4d1966,_0x3db205,_0x208788){let _0xf66a3b=_0x17c0a3;return _0x140faa['foreach']((_0x9bb875,_0x21bcf0)=>{const _0x3cfc16=k(_0xebcde0,_0x9bb875);hr(_0x17c0a3,y(_0x3cfc16))&&(_0xf66a3b=Si(_0x30df72,_0xf66a3b,_0x3cfc16,_0x21bcf0,_0x4d1966,_0x3db205,_0x208788));}),_0x140faa['foreach']((_0x2b51ec,_0x2234c1)=>{const _0x347cf8=k(_0xebcde0,_0x2b51ec);hr(_0x17c0a3,y(_0x347cf8))||(_0xf66a3b=Si(_0x30df72,_0xf66a3b,_0x347cf8,_0x2234c1,_0x4d1966,_0x3db205,_0x208788));}),_0xf66a3b;}function ur(_0x2873e6,_0x5b52e2,_0x43e568){return _0x43e568['foreach']((_0x509215,_0xdd0bd3)=>{_0x5b52e2=_0x5b52e2['updateChild'](_0x509215,_0xdd0bd3);}),_0x5b52e2;}function bi(_0x50c25e,_0x4b9c7e,_0x1069e2,_0x33bab9,_0x1f33c1,_0x25f400,_0x4feb3a,_0x35dde4){if(_0x4b9c7e['serverCache']['getNode']()['isEmpty']()&&!_0x4b9c7e['serverCache']['isFullyInitialized']())return _0x4b9c7e;let _0x23b3d3=_0x4b9c7e,_0x1d211e;v(_0x1069e2)?_0x1d211e=_0x33bab9:_0x1d211e=new S(null)['setTree'](_0x1069e2,_0x33bab9);const _0x5aaddb=_0x4b9c7e['serverCache']['getNode']();return _0x1d211e['children']['inorderTraversal']((_0x3fec73,_0x5400cb)=>{if(_0x5aaddb['hasChild'](_0x3fec73)){const _0x542fe3=_0x4b9c7e['serverCache']['getNode']()['getImmediateChild'](_0x3fec73),_0x5dae94=ur(_0x50c25e,_0x542fe3,_0x5400cb);_0x23b3d3=En(_0x50c25e,_0x23b3d3,new C(_0x3fec73),_0x5dae94,_0x1f33c1,_0x25f400,_0x4feb3a,_0x35dde4);}}),_0x1d211e['children']['inorderTraversal']((_0x26ecde,_0x28a225)=>{const _0x573407=!_0x4b9c7e['serverCache']['isCompleteForChild'](_0x26ecde)&&_0x28a225['value']===null;if(!_0x5aaddb['hasChild'](_0x26ecde)&&!_0x573407){const _0xe12d4e=_0x4b9c7e['serverCache']['getNode']()['getImmediateChild'](_0x26ecde),_0x3521f3=ur(_0x50c25e,_0xe12d4e,_0x28a225);_0x23b3d3=En(_0x50c25e,_0x23b3d3,new C(_0x26ecde),_0x3521f3,_0x1f33c1,_0x25f400,_0x4feb3a,_0x35dde4);}}),_0x23b3d3;}function Nu(_0x25b91a,_0x329138,_0x161aa9,_0x3af5a7,_0x39fe8b,_0x3c4dad,_0x24eb1d){if(vn(_0x39fe8b,_0x161aa9)!=null)return _0x329138;const _0x232034=_0x329138['serverCache']['isFiltered'](),_0x506d14=_0x329138['serverCache'];if(_0x3af5a7['value']!=null){if(v(_0x161aa9)&&_0x506d14['isFullyInitialized']()||_0x506d14['isCompleteForPath'](_0x161aa9))return En(_0x25b91a,_0x329138,_0x161aa9,_0x506d14['getNode']()['getChild'](_0x161aa9),_0x39fe8b,_0x3c4dad,_0x232034,_0x24eb1d);if(v(_0x161aa9)){let _0x496769=new S(null);return _0x506d14['getNode']()['forEachChild'](ye,(_0x55d376,_0x36db7)=>{_0x496769=_0x496769['set'](new C(_0x55d376),_0x36db7);}),bi(_0x25b91a,_0x329138,_0x161aa9,_0x496769,_0x39fe8b,_0x3c4dad,_0x232034,_0x24eb1d);}else return _0x329138;}else{let _0x125bde=new S(null);return _0x3af5a7['foreach']((_0x31a5da,_0xc7b7bb)=>{const _0xef44b4=k(_0x161aa9,_0x31a5da);_0x506d14['isCompleteForPath'](_0xef44b4)&&(_0x125bde=_0x125bde['set'](_0x31a5da,_0x506d14['getNode']()['getChild'](_0xef44b4)));}),bi(_0x25b91a,_0x329138,_0x161aa9,_0x125bde,_0x39fe8b,_0x3c4dad,_0x232034,_0x24eb1d);}}function Pu(_0x5b0acd,_0x5f0ea0,_0x38037f,_0x16a3e8,_0x3688bd){const _0x129cc9=_0x5f0ea0['serverCache'],_0x37719d=Uo(_0x5f0ea0,_0x129cc9['getNode'](),_0x129cc9['isFullyInitialized']()||v(_0x38037f),_0x129cc9['isFiltered']());return qo(_0x5b0acd,_0x37719d,_0x38037f,_0x16a3e8,Go,_0x3688bd);}function Ou(_0x373dc4,_0x250cc1,_0x2f4bf9,_0x2b3fd6,_0x1a0f7c,_0x552ff5){let _0x5e747c;if(vn(_0x2b3fd6,_0x2f4bf9)!=null)return _0x250cc1;{const _0x32eb6e=new ss(_0x2b3fd6,_0x250cc1,_0x1a0f7c),_0x5add8f=_0x250cc1['eventCache']['getNode']();let _0x1dd2c8;if(v(_0x2f4bf9)||y(_0x2f4bf9)==='.priority'){let _0x6e3b19;if(_0x250cc1['serverCache']['isFullyInitialized']())_0x6e3b19=yn(_0x2b3fd6,We(_0x250cc1));else{const _0xa8f85d=_0x250cc1['serverCache']['getNode']();f(_0xa8f85d instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x6e3b19=ns(_0x2b3fd6,_0xa8f85d);}_0x6e3b19=_0x6e3b19,_0x1dd2c8=_0x373dc4['filter']['updateFullNode'](_0x5add8f,_0x6e3b19,_0x552ff5);}else{const _0x1c0ac8=y(_0x2f4bf9);let _0x4e341a=is(_0x2b3fd6,_0x1c0ac8,_0x250cc1['serverCache']);_0x4e341a==null&&_0x250cc1['serverCache']['isCompleteForChild'](_0x1c0ac8)&&(_0x4e341a=_0x5add8f['getImmediateChild'](_0x1c0ac8)),_0x4e341a!=null?_0x1dd2c8=_0x373dc4['filter']['updateChild'](_0x5add8f,_0x1c0ac8,_0x4e341a,b(_0x2f4bf9),_0x32eb6e,_0x552ff5):_0x250cc1['eventCache']['getNode']()['hasChild'](_0x1c0ac8)?_0x1dd2c8=_0x373dc4['filter']['updateChild'](_0x5add8f,_0x1c0ac8,g['EMPTY_NODE'],b(_0x2f4bf9),_0x32eb6e,_0x552ff5):_0x1dd2c8=_0x5add8f,_0x1dd2c8['isEmpty']()&&_0x250cc1['serverCache']['isFullyInitialized']()&&(_0x5e747c=yn(_0x2b3fd6,We(_0x250cc1)),_0x5e747c['isLeafNode']()&&(_0x1dd2c8=_0x373dc4['filter']['updateFullNode'](_0x1dd2c8,_0x5e747c,_0x552ff5)));}return _0x5e747c=_0x250cc1['serverCache']['isFullyInitialized']()||vn(_0x2b3fd6,w())!=null,Tt(_0x250cc1,_0x1dd2c8,_0x5e747c,_0x373dc4['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x3d3b20,_0x15ea1a){this['query_']=_0x3d3b20,this['eventRegistrations_']=[];const _0x241640=this['query_']['_queryParams'],_0x5d319a=new Ji(_0x241640['getIndex']()),_0x2c4b5f=Kh(_0x241640);this['processor_']=Su(_0x2c4b5f);const _0xa86bc3=_0x15ea1a['serverCache'],_0x37c413=_0x15ea1a['eventCache'],_0x4b46c0=_0x5d319a['updateFullNode'](g['EMPTY_NODE'],_0xa86bc3['getNode'](),null),_0x536148=_0x2c4b5f['updateFullNode'](g['EMPTY_NODE'],_0x37c413['getNode'](),null),_0x19aa2c=new Ce(_0x4b46c0,_0xa86bc3['isFullyInitialized'](),_0x5d319a['filtersNodes']()),_0x3f30a0=new Ce(_0x536148,_0x37c413['isFullyInitialized'](),_0x2c4b5f['filtersNodes']());this['viewCache_']=Mn(_0x3f30a0,_0x19aa2c),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0xa729ef){return _0xa729ef['viewCache_']['serverCache']['getNode']();}function Lu(_0x1e88c7){return mn(_0x1e88c7['viewCache_']);}function xu(_0x3e187e,_0x267f98){const _0x55b479=We(_0x3e187e['viewCache_']);return _0x55b479&&(_0x3e187e['query']['_queryParams']['loadsAllData']()||!v(_0x267f98)&&!_0x55b479['getImmediateChild'](y(_0x267f98))['isEmpty']())?_0x55b479['getChild'](_0x267f98):null;}function dr(_0x2add5a){return _0x2add5a['eventRegistrations_']['length']===0x0;}function Fu(_0x1b9aaa,_0xdb37bf){_0x1b9aaa['eventRegistrations_']['push'](_0xdb37bf);}function fr(_0x270165,_0x17f7a6,_0x44b7fc){const _0x23c1b0=[];if(_0x44b7fc){f(_0x17f7a6==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x432ed1=_0x270165['query']['_path'];_0x270165['eventRegistrations_']['forEach'](_0x989d65=>{const _0x2decb3=_0x989d65['createCancelEvent'](_0x44b7fc,_0x432ed1);_0x2decb3&&_0x23c1b0['push'](_0x2decb3);});}if(_0x17f7a6){let _0x42eb54=[];for(let _0x2299b9=0x0;_0x2299b9<_0x270165['eventRegistrations_']['length'];++_0x2299b9){const _0x5f251c=_0x270165['eventRegistrations_'][_0x2299b9];if(!_0x5f251c['matches'](_0x17f7a6))_0x42eb54['push'](_0x5f251c);else{if(_0x17f7a6['hasAnyCallback']()){_0x42eb54=_0x42eb54['concat'](_0x270165['eventRegistrations_']['slice'](_0x2299b9+0x1));break;}}}_0x270165['eventRegistrations_']=_0x42eb54;}else _0x270165['eventRegistrations_']=[];return _0x23c1b0;}function pr(_0x4fb2f0,_0x5cf6e2,_0x4d775b,_0x6c5dc9){_0x5cf6e2['type']===j['MERGE']&&_0x5cf6e2['source']['queryId']!==null&&(f(We(_0x4fb2f0['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x4fb2f0['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x2094c8=_0x4fb2f0['viewCache_'],_0x148ce1=Ru(_0x4fb2f0['processor_'],_0x2094c8,_0x5cf6e2,_0x4d775b,_0x6c5dc9);return bu(_0x4fb2f0['processor_'],_0x148ce1['viewCache']),f(_0x148ce1['viewCache']['serverCache']['isFullyInitialized']()||!_0x2094c8['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x4fb2f0['viewCache_']=_0x148ce1['viewCache'],zo(_0x4fb2f0,_0x148ce1['changes'],_0x148ce1['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x5c88ac,_0x474b91){const _0x6cdcfa=_0x5c88ac['viewCache_']['eventCache'],_0x3bba59=[];return _0x6cdcfa['getNode']()['isLeafNode']()||_0x6cdcfa['getNode']()['forEachChild'](R,(_0x17faa8,_0x24dd4c)=>{_0x3bba59['push'](et(_0x17faa8,_0x24dd4c));}),_0x6cdcfa['isFullyInitialized']()&&_0x3bba59['push'](Lo(_0x6cdcfa['getNode']())),zo(_0x5c88ac,_0x3bba59,_0x6cdcfa['getNode'](),_0x474b91);}function zo(_0x5ae093,_0xa65fe0,_0x524043,_0x583e68){const _0x199e88=_0x583e68?[_0x583e68]:_0x5ae093['eventRegistrations_'];return ru(_0x5ae093['eventGenerator_'],_0xa65fe0,_0x524043,_0x199e88);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x3a2b9b){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x3a2b9b;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0xa55202){return _0xa55202['views']['size']===0x0;}function rs(_0x1805af,_0x1fd61b,_0x244017,_0x2a9180){const _0x1541ff=_0x1fd61b['source']['queryId'];if(_0x1541ff!==null){const _0x3f8eca=_0x1805af['views']['get'](_0x1541ff);return f(_0x3f8eca!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x3f8eca,_0x1fd61b,_0x244017,_0x2a9180);}else{let _0x561300=[];for(const _0x2393e8 of _0x1805af['views']['values']())_0x561300=_0x561300['concat'](pr(_0x2393e8,_0x1fd61b,_0x244017,_0x2a9180));return _0x561300;}}function Ko(_0x176ece,_0x1b915a,_0x1394dd,_0x14f1d7,_0x4150a5){const _0x6f7f28=_0x1b915a['_queryIdentifier'],_0x1e7462=_0x176ece['views']['get'](_0x6f7f28);if(!_0x1e7462){let _0x2678c6=yn(_0x1394dd,_0x4150a5?_0x14f1d7:null),_0xf839ff=!0x1;_0x2678c6?_0xf839ff=!0x0:_0x14f1d7 instanceof g?(_0x2678c6=ns(_0x1394dd,_0x14f1d7),_0xf839ff=!0x1):(_0x2678c6=g['EMPTY_NODE'],_0xf839ff=!0x1);const _0x1be20b=Mn(new Ce(_0x2678c6,_0xf839ff,!0x1),new Ce(_0x14f1d7,_0x4150a5,!0x1));return new Du(_0x1b915a,_0x1be20b);}return _0x1e7462;}function Hu(_0x95ecd,_0x2c08a4,_0x4e04db,_0x492be8,_0x333683,_0x544b70){const _0x30308a=Ko(_0x95ecd,_0x2c08a4,_0x492be8,_0x333683,_0x544b70);return _0x95ecd['views']['has'](_0x2c08a4['_queryIdentifier'])||_0x95ecd['views']['set'](_0x2c08a4['_queryIdentifier'],_0x30308a),Fu(_0x30308a,_0x4e04db),Uu(_0x30308a,_0x4e04db);}function $u(_0x5c7f93,_0x5bf8d5,_0x12db49,_0x594af8){const _0x5e3223=_0x5bf8d5['_queryIdentifier'],_0x59ed0b=[];let _0x570185=[];const _0x3d3aab=Te(_0x5c7f93);if(_0x5e3223==='default'){for(const [_0x31b384,_0x3b8736]of _0x5c7f93['views']['entries']())_0x570185=_0x570185['concat'](fr(_0x3b8736,_0x12db49,_0x594af8)),dr(_0x3b8736)&&(_0x5c7f93['views']['delete'](_0x31b384),_0x3b8736['query']['_queryParams']['loadsAllData']()||_0x59ed0b['push'](_0x3b8736['query']));}else{const _0x404dcd=_0x5c7f93['views']['get'](_0x5e3223);_0x404dcd&&(_0x570185=_0x570185['concat'](fr(_0x404dcd,_0x12db49,_0x594af8)),dr(_0x404dcd)&&(_0x5c7f93['views']['delete'](_0x5e3223),_0x404dcd['query']['_queryParams']['loadsAllData']()||_0x59ed0b['push'](_0x404dcd['query'])));}return _0x3d3aab&&!Te(_0x5c7f93)&&_0x59ed0b['push'](new(Bu())(_0x5bf8d5['_repo'],_0x5bf8d5['_path'])),{'removed':_0x59ed0b,'events':_0x570185};}function Yo(_0x57f5e9){const _0x5b2e06=[];for(const _0x98e95 of _0x57f5e9['views']['values']())_0x98e95['query']['_queryParams']['loadsAllData']()||_0x5b2e06['push'](_0x98e95);return _0x5b2e06;}function Ee(_0x71f4cb,_0xb0e620){let _0x19115a=null;for(const _0x4fd46c of _0x71f4cb['views']['values']())_0x19115a=_0x19115a||xu(_0x4fd46c,_0xb0e620);return _0x19115a;}function Qo(_0x1e414d,_0x4c519a){if(_0x4c519a['_queryParams']['loadsAllData']())return xn(_0x1e414d);{const _0x17c4b3=_0x4c519a['_queryIdentifier'];return _0x1e414d['views']['get'](_0x17c4b3);}}function Jo(_0xfe467b,_0x29d936){return Qo(_0xfe467b,_0x29d936)!=null;}function Te(_0x3d97d0){return xn(_0x3d97d0)!=null;}function xn(_0x274414){for(const _0x56e1f7 of _0x274414['views']['values']())if(_0x56e1f7['query']['_queryParams']['loadsAllData']())return _0x56e1f7;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x549f66){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x549f66;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x367519){this['listenProvider_']=_0x367519,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x269433,_0x4b3b60,_0x1c4de8,_0x1b7e1a,_0x297e51){return lu(_0x269433['pendingWriteTree_'],_0x4b3b60,_0x1c4de8,_0x1b7e1a,_0x297e51),_0x297e51?ut(_0x269433,new Ue(Zi(),_0x4b3b60,_0x1c4de8)):[];}function ju(_0x5961d0,_0x10fc49,_0x58697a,_0x3ede1b){hu(_0x5961d0['pendingWriteTree_'],_0x10fc49,_0x58697a,_0x3ede1b);const _0x2757c5=S['fromObject'](_0x58697a);return ut(_0x5961d0,new tt(Zi(),_0x10fc49,_0x2757c5));}function pe(_0x209e93,_0x2da530,_0x4259a6=!0x1){const _0x565411=uu(_0x209e93['pendingWriteTree_'],_0x2da530);if(du(_0x209e93['pendingWriteTree_'],_0x2da530)){let _0x85327b=new S(null);return _0x565411['snap']!=null?_0x85327b=_0x85327b['set'](w(),!0x0):x(_0x565411['children'],_0x541cc0=>{_0x85327b=_0x85327b['set'](new C(_0x541cc0),!0x0);}),ut(_0x209e93,new gn(_0x565411['path'],_0x85327b,_0x4259a6));}else return[];}function Gt(_0x5435e1,_0x1750bb,_0x2e9461){return ut(_0x5435e1,new Ue(es(),_0x1750bb,_0x2e9461));}function Ku(_0x2b174e,_0x1fa690,_0x4eee0b){const _0x4a562d=S['fromObject'](_0x4eee0b);return ut(_0x2b174e,new tt(es(),_0x1fa690,_0x4a562d));}function Yu(_0x1e0627,_0x5bc580){return ut(_0x1e0627,new Lt(es(),_0x5bc580));}function Qu(_0x1e2937,_0x46b70d,_0x7fde5a){const _0x51dad9=as(_0x1e2937,_0x7fde5a);if(_0x51dad9){const _0xb1f2df=cs(_0x51dad9),_0x4dc559=_0xb1f2df['path'],_0xd87dd0=_0xb1f2df['queryId'],_0x111291=F(_0x4dc559,_0x46b70d),_0xa46fa6=new Lt(ts(_0xd87dd0),_0x111291);return ls(_0x1e2937,_0x4dc559,_0xa46fa6);}else return[];}function Cn(_0x46f36d,_0x443ae9,_0x1653cc,_0x31a23d,_0x127dfb=!0x1){const _0x511df1=_0x443ae9['_path'],_0xcac7d7=_0x46f36d['syncPointTree_']['get'](_0x511df1);let _0x10d32c=[];if(_0xcac7d7&&(_0x443ae9['_queryIdentifier']==='default'||Jo(_0xcac7d7,_0x443ae9))){const _0x316e88=$u(_0xcac7d7,_0x443ae9,_0x1653cc,_0x31a23d);Vu(_0xcac7d7)&&(_0x46f36d['syncPointTree_']=_0x46f36d['syncPointTree_']['remove'](_0x511df1));const _0x398d64=_0x316e88['removed'];if(_0x10d32c=_0x316e88['events'],!_0x127dfb){const _0x4fb4cb=_0x398d64['findIndex'](_0xbef423=>_0xbef423['_queryParams']['loadsAllData']())!==-0x1,_0x131350=_0x46f36d['syncPointTree_']['findOnPath'](_0x511df1,(_0x12ba02,_0x252188)=>Te(_0x252188));if(_0x4fb4cb&&!_0x131350){const _0x1491bb=_0x46f36d['syncPointTree_']['subtree'](_0x511df1);if(!_0x1491bb['isEmpty']()){const _0x3357a2=Zu(_0x1491bb);for(let _0x44ce55=0x0;_0x44ce55<_0x3357a2['length'];++_0x44ce55){const _0x6397ce=_0x3357a2[_0x44ce55],_0x232251=_0x6397ce['query'],_0xf9c689=ta(_0x46f36d,_0x6397ce);_0x46f36d['listenProvider_']['startListening'](bt(_0x232251),xt(_0x46f36d,_0x232251),_0xf9c689['hashFn'],_0xf9c689['onComplete']);}}}!_0x131350&&_0x398d64['length']>0x0&&!_0x31a23d&&(_0x4fb4cb?_0x46f36d['listenProvider_']['stopListening'](bt(_0x443ae9),null):_0x398d64['forEach'](_0x1d53ac=>{const _0x56aac7=_0x46f36d['queryToTagMap']['get'](Un(_0x1d53ac));_0x46f36d['listenProvider_']['stopListening'](bt(_0x1d53ac),_0x56aac7);}));}ed(_0x46f36d,_0x398d64);}return _0x10d32c;}function Xo(_0x2a6641,_0x1bb8fe,_0x34bbcd,_0x22faad){const _0x1f8a5e=as(_0x2a6641,_0x22faad);if(_0x1f8a5e!=null){const _0x2e898d=cs(_0x1f8a5e),_0x379ef2=_0x2e898d['path'],_0x15d0ba=_0x2e898d['queryId'],_0x4d4097=F(_0x379ef2,_0x1bb8fe),_0x5ae31d=new Ue(ts(_0x15d0ba),_0x4d4097,_0x34bbcd);return ls(_0x2a6641,_0x379ef2,_0x5ae31d);}else return[];}function Ju(_0x246d2c,_0x3b3ce1,_0x3f8a6b,_0x13f6d9){const _0x7fb9e=as(_0x246d2c,_0x13f6d9);if(_0x7fb9e){const _0x2d37eb=cs(_0x7fb9e),_0xbc8e1f=_0x2d37eb['path'],_0x4c69ad=_0x2d37eb['queryId'],_0x5edbbb=F(_0xbc8e1f,_0x3b3ce1),_0x2b9118=S['fromObject'](_0x3f8a6b),_0x5db498=new tt(ts(_0x4c69ad),_0x5edbbb,_0x2b9118);return ls(_0x246d2c,_0xbc8e1f,_0x5db498);}else return[];}function Ri(_0x5ad1c8,_0x4fa81f,_0x39a196,_0x858b66=!0x1){const _0x5ae047=_0x4fa81f['_path'];let _0x687e2c=null,_0x134b37=!0x1;_0x5ad1c8['syncPointTree_']['foreachOnPath'](_0x5ae047,(_0x50a3dc,_0x149be6)=>{const _0x5e2f61=F(_0x50a3dc,_0x5ae047);_0x687e2c=_0x687e2c||Ee(_0x149be6,_0x5e2f61),_0x134b37=_0x134b37||Te(_0x149be6);});let _0x29e32f=_0x5ad1c8['syncPointTree_']['get'](_0x5ae047);_0x29e32f?(_0x134b37=_0x134b37||Te(_0x29e32f),_0x687e2c=_0x687e2c||Ee(_0x29e32f,w())):(_0x29e32f=new jo(),_0x5ad1c8['syncPointTree_']=_0x5ad1c8['syncPointTree_']['set'](_0x5ae047,_0x29e32f));let _0x6ece4f;_0x687e2c!=null?_0x6ece4f=!0x0:(_0x6ece4f=!0x1,_0x687e2c=g['EMPTY_NODE'],_0x5ad1c8['syncPointTree_']['subtree'](_0x5ae047)['foreachChild']((_0xf5d9cb,_0x3d23f5)=>{const _0x5b35ac=Ee(_0x3d23f5,w());_0x5b35ac&&(_0x687e2c=_0x687e2c['updateImmediateChild'](_0xf5d9cb,_0x5b35ac));}));const _0x381ab8=Jo(_0x29e32f,_0x4fa81f);if(!_0x381ab8&&!_0x4fa81f['_queryParams']['loadsAllData']()){const _0x180970=Un(_0x4fa81f);f(!_0x5ad1c8['queryToTagMap']['has'](_0x180970),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x49c0b0=td();_0x5ad1c8['queryToTagMap']['set'](_0x180970,_0x49c0b0),_0x5ad1c8['tagToQueryMap']['set'](_0x49c0b0,_0x180970);}const _0x469374=Ln(_0x5ad1c8['pendingWriteTree_'],_0x5ae047);let _0x40d7e0=Hu(_0x29e32f,_0x4fa81f,_0x39a196,_0x469374,_0x687e2c,_0x6ece4f);if(!_0x381ab8&&!_0x134b37&&!_0x858b66){const _0xb602be=Qo(_0x29e32f,_0x4fa81f);_0x40d7e0=_0x40d7e0['concat'](nd(_0x5ad1c8,_0x4fa81f,_0xb602be));}return _0x40d7e0;}function Fn(_0x21bdeb,_0xcce2e3,_0x2d5872){const _0x1bc37c=_0x21bdeb['pendingWriteTree_'],_0x3731a4=_0x21bdeb['syncPointTree_']['findOnPath'](_0xcce2e3,(_0x76b28,_0x456a83)=>{const _0x35c694=F(_0x76b28,_0xcce2e3),_0x3efb6c=Ee(_0x456a83,_0x35c694);if(_0x3efb6c)return _0x3efb6c;});return Vo(_0x1bc37c,_0xcce2e3,_0x3731a4,_0x2d5872,!0x0);}function Xu(_0x4d62f8,_0x2b9573){const _0x373e64=_0x2b9573['_path'];let _0x5495e7=null;_0x4d62f8['syncPointTree_']['foreachOnPath'](_0x373e64,(_0x17b613,_0x3222e2)=>{const _0x337a45=F(_0x17b613,_0x373e64);_0x5495e7=_0x5495e7||Ee(_0x3222e2,_0x337a45);});let _0x520a46=_0x4d62f8['syncPointTree_']['get'](_0x373e64);_0x520a46?_0x5495e7=_0x5495e7||Ee(_0x520a46,w()):(_0x520a46=new jo(),_0x4d62f8['syncPointTree_']=_0x4d62f8['syncPointTree_']['set'](_0x373e64,_0x520a46));const _0x5ec139=_0x5495e7!=null,_0x430b48=_0x5ec139?new Ce(_0x5495e7,!0x0,!0x1):null,_0x5ab657=Ln(_0x4d62f8['pendingWriteTree_'],_0x2b9573['_path']),_0x194ed2=Ko(_0x520a46,_0x2b9573,_0x5ab657,_0x5ec139?_0x430b48['getNode']():g['EMPTY_NODE'],_0x5ec139);return Lu(_0x194ed2);}function ut(_0x5f333b,_0x3beb4f){return Zo(_0x3beb4f,_0x5f333b['syncPointTree_'],null,Ln(_0x5f333b['pendingWriteTree_'],w()));}function Zo(_0x33a5e7,_0xd934c3,_0x85fc7,_0x49362d){if(v(_0x33a5e7['path']))return ea(_0x33a5e7,_0xd934c3,_0x85fc7,_0x49362d);{const _0x48f7ca=_0xd934c3['get'](w());_0x85fc7==null&&_0x48f7ca!=null&&(_0x85fc7=Ee(_0x48f7ca,w()));let _0x57aaff=[];const _0x3346d9=y(_0x33a5e7['path']),_0x2c96ef=_0x33a5e7['operationForChild'](_0x3346d9),_0x103b07=_0xd934c3['children']['get'](_0x3346d9);if(_0x103b07&&_0x2c96ef){const _0x151c6d=_0x85fc7?_0x85fc7['getImmediateChild'](_0x3346d9):null,_0x1030bf=Ho(_0x49362d,_0x3346d9);_0x57aaff=_0x57aaff['concat'](Zo(_0x2c96ef,_0x103b07,_0x151c6d,_0x1030bf));}return _0x48f7ca&&(_0x57aaff=_0x57aaff['concat'](rs(_0x48f7ca,_0x33a5e7,_0x49362d,_0x85fc7))),_0x57aaff;}}function ea(_0x227f33,_0x24201b,_0x21c919,_0x159ba2){const _0x3a6304=_0x24201b['get'](w());_0x21c919==null&&_0x3a6304!=null&&(_0x21c919=Ee(_0x3a6304,w()));let _0x21b9d4=[];return _0x24201b['children']['inorderTraversal']((_0x124187,_0x4b3321)=>{const _0x3ea915=_0x21c919?_0x21c919['getImmediateChild'](_0x124187):null,_0x4f9a83=Ho(_0x159ba2,_0x124187),_0x2587c8=_0x227f33['operationForChild'](_0x124187);_0x2587c8&&(_0x21b9d4=_0x21b9d4['concat'](ea(_0x2587c8,_0x4b3321,_0x3ea915,_0x4f9a83)));}),_0x3a6304&&(_0x21b9d4=_0x21b9d4['concat'](rs(_0x3a6304,_0x227f33,_0x159ba2,_0x21c919))),_0x21b9d4;}function ta(_0x27015d,_0x2f1b82){const _0xb6940b=_0x2f1b82['query'],_0x3f7357=xt(_0x27015d,_0xb6940b);return{'hashFn':()=>(Mu(_0x2f1b82)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x34a3da=>{if(_0x34a3da==='ok')return _0x3f7357?Qu(_0x27015d,_0xb6940b['_path'],_0x3f7357):Yu(_0x27015d,_0xb6940b['_path']);{const _0x1d3208=Kl(_0x34a3da,_0xb6940b);return Cn(_0x27015d,_0xb6940b,null,_0x1d3208);}}};}function xt(_0x26c316,_0x247fbc){const _0x5082fe=Un(_0x247fbc);return _0x26c316['queryToTagMap']['get'](_0x5082fe);}function Un(_0x373c37){return _0x373c37['_path']['toString']()+'$'+_0x373c37['_queryIdentifier'];}function as(_0x534859,_0x248b24){return _0x534859['tagToQueryMap']['get'](_0x248b24);}function cs(_0x55eef6){const _0x22dac3=_0x55eef6['indexOf']('$');return f(_0x22dac3!==-0x1&&_0x22dac3<_0x55eef6['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x55eef6['substr'](_0x22dac3+0x1),'path':new C(_0x55eef6['substr'](0x0,_0x22dac3))};}function ls(_0x5eb77f,_0x4d6240,_0x583ae3){const _0xf4c1f2=_0x5eb77f['syncPointTree_']['get'](_0x4d6240);f(_0xf4c1f2,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x13d2bf=Ln(_0x5eb77f['pendingWriteTree_'],_0x4d6240);return rs(_0xf4c1f2,_0x583ae3,_0x13d2bf,null);}function Zu(_0x1bca1d){return _0x1bca1d['fold']((_0x3d4de7,_0x686cf6,_0xd1805b)=>{if(_0x686cf6&&Te(_0x686cf6))return[xn(_0x686cf6)];{let _0x3f1ce6=[];return _0x686cf6&&(_0x3f1ce6=Yo(_0x686cf6)),x(_0xd1805b,(_0x495a97,_0x20f711)=>{_0x3f1ce6=_0x3f1ce6['concat'](_0x20f711);}),_0x3f1ce6;}});}function bt(_0x4c7f88){return _0x4c7f88['_queryParams']['loadsAllData']()&&!_0x4c7f88['_queryParams']['isDefault']()?new(qu())(_0x4c7f88['_repo'],_0x4c7f88['_path']):_0x4c7f88;}function ed(_0x4a9fcb,_0x3fbf1f){for(let _0x274ff0=0x0;_0x274ff0<_0x3fbf1f['length'];++_0x274ff0){const _0x5bb237=_0x3fbf1f[_0x274ff0];if(!_0x5bb237['_queryParams']['loadsAllData']()){const _0x4fba7d=Un(_0x5bb237),_0x2786a2=_0x4a9fcb['queryToTagMap']['get'](_0x4fba7d);_0x4a9fcb['queryToTagMap']['delete'](_0x4fba7d),_0x4a9fcb['tagToQueryMap']['delete'](_0x2786a2);}}}function td(){return zu++;}function nd(_0x5d999f,_0x292290,_0x12d57a){const _0x162b38=_0x292290['_path'],_0x17a9e3=xt(_0x5d999f,_0x292290),_0x4bb73b=ta(_0x5d999f,_0x12d57a),_0x1fb53d=_0x5d999f['listenProvider_']['startListening'](bt(_0x292290),_0x17a9e3,_0x4bb73b['hashFn'],_0x4bb73b['onComplete']),_0x1faeb4=_0x5d999f['syncPointTree_']['subtree'](_0x162b38);if(_0x17a9e3)f(!Te(_0x1faeb4['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x356986=_0x1faeb4['fold']((_0x3b3455,_0x533758,_0x4e8055)=>{if(!v(_0x3b3455)&&_0x533758&&Te(_0x533758))return[xn(_0x533758)['query']];{let _0x3de533=[];return _0x533758&&(_0x3de533=_0x3de533['concat'](Yo(_0x533758)['map'](_0x23b924=>_0x23b924['query']))),x(_0x4e8055,(_0x5477bd,_0x5b9599)=>{_0x3de533=_0x3de533['concat'](_0x5b9599);}),_0x3de533;}});for(let _0x35b1c0=0x0;_0x35b1c0<_0x356986['length'];++_0x35b1c0){const _0x44effc=_0x356986[_0x35b1c0];_0x5d999f['listenProvider_']['stopListening'](bt(_0x44effc),xt(_0x5d999f,_0x44effc));}}return _0x1fb53d;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x1caee8){this['node_']=_0x1caee8;}['getImmediateChild'](_0x16e505){const _0x3861c2=this['node_']['getImmediateChild'](_0x16e505);return new hs(_0x3861c2);}['node'](){return this['node_'];}}class us{constructor(_0x15e005,_0x39d5ff){this['syncTree_']=_0x15e005,this['path_']=_0x39d5ff;}['getImmediateChild'](_0x210fa6){const _0x1b77f7=k(this['path_'],_0x210fa6);return new us(this['syncTree_'],_0x1b77f7);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0xc161e7){return _0xc161e7=_0xc161e7||{},_0xc161e7['timestamp']=_0xc161e7['timestamp']||new Date()['getTime'](),_0xc161e7;},gr=function(_0xb1502e,_0x48e25a,_0x5dfc07){if(!_0xb1502e||typeof _0xb1502e!='object')return _0xb1502e;if(f('.sv'in _0xb1502e,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0xb1502e['.sv']=='string')return sd(_0xb1502e['.sv'],_0x48e25a,_0x5dfc07);if(typeof _0xb1502e['.sv']=='object')return rd(_0xb1502e['.sv'],_0x48e25a);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xb1502e,null,0x2));},sd=function(_0x196c65,_0x514318,_0x439b9d){switch(_0x196c65){case'timestamp':return _0x439b9d['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x196c65);}},rd=function(_0x20eeca,_0x1743c8,_0x226d43){_0x20eeca['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x20eeca,null,0x2));const _0x38428b=_0x20eeca['increment'];typeof _0x38428b!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x38428b);const _0x1a3c1e=_0x1743c8['node']();if(f(_0x1a3c1e!==null&&typeof _0x1a3c1e<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x1a3c1e['isLeafNode']())return _0x38428b;const _0x15f7a=_0x1a3c1e['getValue']();return typeof _0x15f7a!='number'?_0x38428b:_0x15f7a+_0x38428b;},na=function(_0x52a888,_0x5cda8a,_0x3b46cf,_0x54c5ac){return fs(_0x5cda8a,new us(_0x3b46cf,_0x52a888),_0x54c5ac);},ds=function(_0x14e9fc,_0x4e901a,_0x4981e9){return fs(_0x14e9fc,new hs(_0x4e901a),_0x4981e9);};function fs(_0x9356a2,_0x4c58b5,_0x1f590a){const _0x511839=_0x9356a2['getPriority']()['val'](),_0x40958d=gr(_0x511839,_0x4c58b5['getImmediateChild']('.priority'),_0x1f590a);let _0xf1e023;if(_0x9356a2['isLeafNode']()){const _0x3cec09=_0x9356a2,_0x499d24=gr(_0x3cec09['getValue'](),_0x4c58b5,_0x1f590a);return _0x499d24!==_0x3cec09['getValue']()||_0x40958d!==_0x3cec09['getPriority']()['val']()?new D(_0x499d24,P(_0x40958d)):_0x9356a2;}else{const _0x5a870b=_0x9356a2;return _0xf1e023=_0x5a870b,_0x40958d!==_0x5a870b['getPriority']()['val']()&&(_0xf1e023=_0xf1e023['updatePriority'](new D(_0x40958d))),_0x5a870b['forEachChild'](R,(_0x1ab0c5,_0x4c8900)=>{const _0x506e90=fs(_0x4c8900,_0x4c58b5['getImmediateChild'](_0x1ab0c5),_0x1f590a);_0x506e90!==_0x4c8900&&(_0xf1e023=_0xf1e023['updateImmediateChild'](_0x1ab0c5,_0x506e90));}),_0xf1e023;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x543c47='',_0x32bd4a=null,_0x5afcc1={'children':{},'childCount':0x0}){this['name']=_0x543c47,this['parent']=_0x32bd4a,this['node']=_0x5afcc1;}}function Wn(_0x3c7187,_0x218bca){let _0x49a738=_0x218bca instanceof C?_0x218bca:new C(_0x218bca),_0x3745df=_0x3c7187,_0x6fb7f3=y(_0x49a738);for(;_0x6fb7f3!==null;){const _0x3516bc=De(_0x3745df['node']['children'],_0x6fb7f3)||{'children':{},'childCount':0x0};_0x3745df=new ps(_0x6fb7f3,_0x3745df,_0x3516bc),_0x49a738=b(_0x49a738),_0x6fb7f3=y(_0x49a738);}return _0x3745df;}function Ge(_0x34247b){return _0x34247b['node']['value'];}function _s(_0x241af2,_0x25f51d){_0x241af2['node']['value']=_0x25f51d,Ai(_0x241af2);}function ia(_0x341c22){return _0x341c22['node']['childCount']>0x0;}function od(_0x1ecc8e){return Ge(_0x1ecc8e)===void 0x0&&!ia(_0x1ecc8e);}function Bn(_0x14bc56,_0x1674ba){x(_0x14bc56['node']['children'],(_0x1cea34,_0x223b09)=>{_0x1674ba(new ps(_0x1cea34,_0x14bc56,_0x223b09));});}function sa(_0x27f311,_0x34c3f1,_0x1438ab,_0x44dd43){_0x1438ab&&_0x34c3f1(_0x27f311),Bn(_0x27f311,_0x48b715=>{sa(_0x48b715,_0x34c3f1,!0x0);});}function ad(_0x5263e3,_0xd059e7,_0xd7ee02){let _0x5a3123=_0x5263e3['parent'];for(;_0x5a3123!==null;){if(_0xd059e7(_0x5a3123))return!0x0;_0x5a3123=_0x5a3123['parent'];}return!0x1;}function qt(_0x258d48){return new C(_0x258d48['parent']===null?_0x258d48['name']:qt(_0x258d48['parent'])+'/'+_0x258d48['name']);}function Ai(_0x145556){_0x145556['parent']!==null&&cd(_0x145556['parent'],_0x145556['name'],_0x145556);}function cd(_0x81698,_0x3d568d,_0x7f0034){const _0x187f9d=od(_0x7f0034),_0x34c1c3=J(_0x81698['node']['children'],_0x3d568d);_0x187f9d&&_0x34c1c3?(delete _0x81698['node']['children'][_0x3d568d],_0x81698['node']['childCount']--,Ai(_0x81698)):!_0x187f9d&&!_0x34c1c3&&(_0x81698['node']['children'][_0x3d568d]=_0x7f0034['node'],_0x81698['node']['childCount']++,Ai(_0x81698));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x50a0e1){return typeof _0x50a0e1=='string'&&_0x50a0e1['length']!==0x0&&!ld['test'](_0x50a0e1);},ra=function(_0x4fed65){return typeof _0x4fed65=='string'&&_0x4fed65['length']!==0x0&&!hd['test'](_0x4fed65);},ud=function(_0x22bb89){return _0x22bb89&&(_0x22bb89=_0x22bb89['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x22bb89);},Tn=function(_0x1a37f9){return _0x1a37f9===null||typeof _0x1a37f9=='string'||typeof _0x1a37f9=='number'&&!Vi(_0x1a37f9)||_0x1a37f9&&typeof _0x1a37f9=='object'&&J(_0x1a37f9,'.sv');},zt=function(_0x28b907,_0x537370,_0x2f023e,_0x282dc1){_0x282dc1&&_0x537370===void 0x0||jt(Pn(_0x28b907,'value'),_0x537370,_0x2f023e);},jt=function(_0x19a5d3,_0x3da0ad,_0x3d17b5){const _0x5baadf=_0x3d17b5 instanceof C?new Ah(_0x3d17b5,_0x19a5d3):_0x3d17b5;if(_0x3da0ad===void 0x0)throw new Error(_0x19a5d3+'contains\x20undefined\x20'+Pe(_0x5baadf));if(typeof _0x3da0ad=='function')throw new Error(_0x19a5d3+'contains\x20a\x20function\x20'+Pe(_0x5baadf)+'\x20with\x20contents\x20=\x20'+_0x3da0ad['toString']());if(Vi(_0x3da0ad))throw new Error(_0x19a5d3+'contains\x20'+_0x3da0ad['toString']()+'\x20'+Pe(_0x5baadf));if(typeof _0x3da0ad=='string'&&_0x3da0ad['length']>ai/0x3&&On(_0x3da0ad)>ai)throw new Error(_0x19a5d3+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x5baadf)+'\x20(\x27'+_0x3da0ad['substring'](0x0,0x32)+'...\x27)');if(_0x3da0ad&&typeof _0x3da0ad=='object'){let _0x2321e5=!0x1,_0x26223f=!0x1;if(x(_0x3da0ad,(_0x1907e1,_0x5d418c)=>{if(_0x1907e1==='.value')_0x2321e5=!0x0;else{if(_0x1907e1!=='.priority'&&_0x1907e1!=='.sv'&&(_0x26223f=!0x0,!gs(_0x1907e1)))throw new Error(_0x19a5d3+'\x20contains\x20an\x20invalid\x20key\x20('+_0x1907e1+')\x20'+Pe(_0x5baadf)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x5baadf,_0x1907e1),jt(_0x19a5d3,_0x5d418c,_0x5baadf),Nh(_0x5baadf);}),_0x2321e5&&_0x26223f)throw new Error(_0x19a5d3+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x5baadf)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x275aa8,_0x191e55){let _0x3fa86d,_0x82ae2d;for(_0x3fa86d=0x0;_0x3fa86d<_0x191e55['length'];_0x3fa86d++){_0x82ae2d=_0x191e55[_0x3fa86d];const _0x2086e2=Pt(_0x82ae2d);for(let _0xe836d8=0x0;_0xe836d8<_0x2086e2['length'];_0xe836d8++)if(!(_0x2086e2[_0xe836d8]==='.priority'&&_0xe836d8===_0x2086e2['length']-0x1)){if(!gs(_0x2086e2[_0xe836d8]))throw new Error(_0x275aa8+'contains\x20an\x20invalid\x20key\x20('+_0x2086e2[_0xe836d8]+')\x20in\x20path\x20'+_0x82ae2d['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x191e55['sort'](Rh);let _0x1b52da=null;for(_0x3fa86d=0x0;_0x3fa86d<_0x191e55['length'];_0x3fa86d++){if(_0x82ae2d=_0x191e55[_0x3fa86d],_0x1b52da!==null&&G(_0x1b52da,_0x82ae2d))throw new Error(_0x275aa8+'contains\x20a\x20path\x20'+_0x1b52da['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x82ae2d['toString']());_0x1b52da=_0x82ae2d;}},fd=function(_0x102924,_0x12ba49,_0xad1e8e,_0x5f3f0c){const _0x5cde33=Pn(_0x102924,'values');if(!(_0x12ba49&&typeof _0x12ba49=='object')||Array['isArray'](_0x12ba49))throw new Error(_0x5cde33+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x5f5bea=[];x(_0x12ba49,(_0x13aca9,_0x4a7cdf)=>{const _0x5f597e=new C(_0x13aca9);if(jt(_0x5cde33,_0x4a7cdf,k(_0xad1e8e,_0x5f597e)),zi(_0x5f597e)==='.priority'&&!Tn(_0x4a7cdf))throw new Error(_0x5cde33+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x5f597e['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x5f5bea['push'](_0x5f597e);}),dd(_0x5cde33,_0x5f5bea);},ms=function(_0x2db026,_0x45c13c,_0x4bfc88,_0x55861a){if(!ra(_0x4bfc88))throw new Error(Pn(_0x2db026,_0x45c13c)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x4bfc88+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x506c7c,_0x23e383,_0x4d0136,_0x39ead5){_0x4d0136&&(_0x4d0136=_0x4d0136['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x506c7c,_0x23e383,_0x4d0136);},ys=function(_0x2a5878,_0x384808){if(y(_0x384808)==='.info')throw new Error(_0x2a5878+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x14d11f,_0x23044b){const _0x3d0ffe=_0x23044b['path']['toString']();if(typeof _0x23044b['repoInfo']['host']!='string'||_0x23044b['repoInfo']['host']['length']===0x0||!gs(_0x23044b['repoInfo']['namespace'])&&_0x23044b['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x3d0ffe['length']!==0x0&&!ud(_0x3d0ffe))throw new Error(Pn(_0x14d11f,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x547ac5,_0x7b4e7c){let _0x382223=null;for(let _0x1f11a6=0x0;_0x1f11a6<_0x7b4e7c['length'];_0x1f11a6++){const _0x3a5e8f=_0x7b4e7c[_0x1f11a6],_0x78e38d=_0x3a5e8f['getPath']();_0x382223!==null&&!ji(_0x78e38d,_0x382223['path'])&&(_0x547ac5['eventLists_']['push'](_0x382223),_0x382223=null),_0x382223===null&&(_0x382223={'events':[],'path':_0x78e38d}),_0x382223['events']['push'](_0x3a5e8f);}_0x382223&&_0x547ac5['eventLists_']['push'](_0x382223);}function oa(_0x477cdc,_0x30051c,_0x43b365){Vn(_0x477cdc,_0x43b365),aa(_0x477cdc,_0x36a112=>ji(_0x36a112,_0x30051c));}function H(_0x3eabb1,_0x2689cc,_0xf7a231){Vn(_0x3eabb1,_0xf7a231),aa(_0x3eabb1,_0x3571fe=>G(_0x3571fe,_0x2689cc)||G(_0x2689cc,_0x3571fe));}function aa(_0x590009,_0x3d0b16){_0x590009['recursionDepth_']++;let _0x38b351=!0x0;for(let _0xe65897=0x0;_0xe65897<_0x590009['eventLists_']['length'];_0xe65897++){const _0x786d8d=_0x590009['eventLists_'][_0xe65897];if(_0x786d8d){const _0x59b2b1=_0x786d8d['path'];_0x3d0b16(_0x59b2b1)?(md(_0x590009['eventLists_'][_0xe65897]),_0x590009['eventLists_'][_0xe65897]=null):_0x38b351=!0x1;}}_0x38b351&&(_0x590009['eventLists_']=[]),_0x590009['recursionDepth_']--;}function md(_0x145cbe){for(let _0x19d824=0x0;_0x19d824<_0x145cbe['events']['length'];_0x19d824++){const _0x34298f=_0x145cbe['events'][_0x19d824];if(_0x34298f!==null){_0x145cbe['events'][_0x19d824]=null;const _0x4d7236=_0x34298f['getEventRunner']();wt&&L('event:\x20'+_0x34298f['toString']()),ht(_0x4d7236);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0xdd54cf,_0xe0dd84,_0x1af8bf,_0x41630e){this['repoInfo_']=_0xdd54cf,this['forceRestClient_']=_0xe0dd84,this['authTokenProvider_']=_0x1af8bf,this['appCheckProvider_']=_0x41630e,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x42f90c,_0x52ec9c,_0x57b2f8){if(_0x42f90c['stats_']=Gi(_0x42f90c['repoInfo_']),_0x42f90c['forceRestClient_']||Xl())_0x42f90c['server_']=new pn(_0x42f90c['repoInfo_'],(_0x4a777a,_0x2038b6,_0xb4b57,_0x1a3dca)=>{mr(_0x42f90c,_0x4a777a,_0x2038b6,_0xb4b57,_0x1a3dca);},_0x42f90c['authTokenProvider_'],_0x42f90c['appCheckProvider_']),setTimeout(()=>yr(_0x42f90c,!0x0),0x0);else{if(typeof _0x57b2f8<'u'&&_0x57b2f8!==null){if(typeof _0x57b2f8!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x57b2f8);}catch(_0x253b50){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x253b50);}}_0x42f90c['persistentConnection_']=new se(_0x42f90c['repoInfo_'],_0x52ec9c,(_0x57ce9c,_0x20dad9,_0x296546,_0x35ef65)=>{mr(_0x42f90c,_0x57ce9c,_0x20dad9,_0x296546,_0x35ef65);},_0x45c8fe=>{yr(_0x42f90c,_0x45c8fe);},_0x37b86d=>{Id(_0x42f90c,_0x37b86d);},_0x42f90c['authTokenProvider_'],_0x42f90c['appCheckProvider_'],_0x57b2f8),_0x42f90c['server_']=_0x42f90c['persistentConnection_'];}_0x42f90c['authTokenProvider_']['addTokenChangeListener'](_0x554d1a=>{_0x42f90c['server_']['refreshAuthToken'](_0x554d1a);}),_0x42f90c['appCheckProvider_']['addTokenChangeListener'](_0x2fb8e2=>{_0x42f90c['server_']['refreshAppCheckToken'](_0x2fb8e2['token']);}),_0x42f90c['statsReporter_']=ih(_0x42f90c['repoInfo_'],()=>new iu(_0x42f90c['stats_'],_0x42f90c['server_'])),_0x42f90c['infoData_']=new Xh(),_0x42f90c['infoSyncTree_']=new _r({'startListening':(_0x40a0b7,_0xf6c15a,_0x49941c,_0x53f8b6)=>{let _0x50d8b8=[];const _0x4709ce=_0x42f90c['infoData_']['getNode'](_0x40a0b7['_path']);return _0x4709ce['isEmpty']()||(_0x50d8b8=Gt(_0x42f90c['infoSyncTree_'],_0x40a0b7['_path'],_0x4709ce),setTimeout(()=>{_0x53f8b6('ok');},0x0)),_0x50d8b8;},'stopListening':()=>{}}),vs(_0x42f90c,'connected',!0x1),_0x42f90c['serverSyncTree_']=new _r({'startListening':(_0xf54dbb,_0x2a299c,_0x273baa,_0x33c02c)=>(_0x42f90c['server_']['listen'](_0xf54dbb,_0x273baa,_0x2a299c,(_0x59c003,_0x1a169f)=>{const _0x4e73ab=_0x33c02c(_0x59c003,_0x1a169f);H(_0x42f90c['eventQueue_'],_0xf54dbb['_path'],_0x4e73ab);}),[]),'stopListening':(_0x553b3f,_0x2db745)=>{_0x42f90c['server_']['unlisten'](_0x553b3f,_0x2db745);}});}function la(_0x5cbace){const _0x5e795a=_0x5cbace['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x5e795a;}function Kt(_0x265f46){return id({'timestamp':la(_0x265f46)});}function mr(_0x39671f,_0x1388ad,_0xdfb5fb,_0x27536,_0x3ad74f){_0x39671f['dataUpdateCount']++;const _0x20f580=new C(_0x1388ad);_0xdfb5fb=_0x39671f['interceptServerDataCallback_']?_0x39671f['interceptServerDataCallback_'](_0x1388ad,_0xdfb5fb):_0xdfb5fb;let _0x46a24f=[];if(_0x3ad74f){if(_0x27536){const _0x55f2f3=hn(_0xdfb5fb,_0x5dda06=>P(_0x5dda06));_0x46a24f=Ju(_0x39671f['serverSyncTree_'],_0x20f580,_0x55f2f3,_0x3ad74f);}else{const _0x2c9fe6=P(_0xdfb5fb);_0x46a24f=Xo(_0x39671f['serverSyncTree_'],_0x20f580,_0x2c9fe6,_0x3ad74f);}}else{if(_0x27536){const _0x1314cd=hn(_0xdfb5fb,_0x32449e=>P(_0x32449e));_0x46a24f=Ku(_0x39671f['serverSyncTree_'],_0x20f580,_0x1314cd);}else{const _0x838617=P(_0xdfb5fb);_0x46a24f=Gt(_0x39671f['serverSyncTree_'],_0x20f580,_0x838617);}}let _0x54b0f5=_0x20f580;_0x46a24f['length']>0x0&&(_0x54b0f5=it(_0x39671f,_0x20f580)),H(_0x39671f['eventQueue_'],_0x54b0f5,_0x46a24f);}function yr(_0x4770e4,_0x3f7912){vs(_0x4770e4,'connected',_0x3f7912),_0x3f7912===!0x1&&Sd(_0x4770e4);}function Id(_0xa7f1ef,_0x449992){x(_0x449992,(_0x4d8883,_0x933c21)=>{vs(_0xa7f1ef,_0x4d8883,_0x933c21);});}function vs(_0x1d85bf,_0x457f6a,_0x4860ff){const _0x4bcff3=new C('/.info/'+_0x457f6a),_0x3bda62=P(_0x4860ff);_0x1d85bf['infoData_']['updateSnapshot'](_0x4bcff3,_0x3bda62);const _0x4b4826=Gt(_0x1d85bf['infoSyncTree_'],_0x4bcff3,_0x3bda62);H(_0x1d85bf['eventQueue_'],_0x4bcff3,_0x4b4826);}function Hn(_0xbb3970){return _0xbb3970['nextWriteId_']++;}function wd(_0x552da5,_0x81e030,_0xc216fe){const _0x55f5a4=Xu(_0x552da5['serverSyncTree_'],_0x81e030);return _0x55f5a4!=null?Promise['resolve'](_0x55f5a4):_0x552da5['server_']['get'](_0x81e030)['then'](_0x2e3255=>{const _0x19dab2=P(_0x2e3255)['withIndex'](_0x81e030['_queryParams']['getIndex']());Ri(_0x552da5['serverSyncTree_'],_0x81e030,_0xc216fe,!0x0);let _0x424081;if(_0x81e030['_queryParams']['loadsAllData']())_0x424081=Gt(_0x552da5['serverSyncTree_'],_0x81e030['_path'],_0x19dab2);else{const _0x458350=xt(_0x552da5['serverSyncTree_'],_0x81e030);_0x424081=Xo(_0x552da5['serverSyncTree_'],_0x81e030['_path'],_0x19dab2,_0x458350);}return H(_0x552da5['eventQueue_'],_0x81e030['_path'],_0x424081),Cn(_0x552da5['serverSyncTree_'],_0x81e030,_0xc216fe,null,!0x0),_0x19dab2;},_0x43c959=>(dt(_0x552da5,'get\x20for\x20query\x20'+O(_0x81e030)+'\x20failed:\x20'+_0x43c959),Promise['reject'](new Error(_0x43c959))));}function Cd(_0x13adef,_0x12a78b,_0x35588e,_0x3aac04,_0xb588de){dt(_0x13adef,'set',{'path':_0x12a78b['toString'](),'value':_0x35588e,'priority':_0x3aac04});const _0x4706be=Kt(_0x13adef),_0x320369=P(_0x35588e,_0x3aac04),_0x1956a0=Fn(_0x13adef['serverSyncTree_'],_0x12a78b),_0x3a4d66=ds(_0x320369,_0x1956a0,_0x4706be),_0x48066e=Hn(_0x13adef),_0x1a8f5a=os(_0x13adef['serverSyncTree_'],_0x12a78b,_0x3a4d66,_0x48066e,!0x0);Vn(_0x13adef['eventQueue_'],_0x1a8f5a),_0x13adef['server_']['put'](_0x12a78b['toString'](),_0x320369['val'](!0x0),(_0x1ee5c0,_0x2e37ee)=>{const _0x5c607e=_0x1ee5c0==='ok';_0x5c607e||U('set\x20at\x20'+_0x12a78b+'\x20failed:\x20'+_0x1ee5c0);const _0x4ac6f0=pe(_0x13adef['serverSyncTree_'],_0x48066e,!_0x5c607e);H(_0x13adef['eventQueue_'],_0x12a78b,_0x4ac6f0),ki(_0x13adef,_0xb588de,_0x1ee5c0,_0x2e37ee);});const _0x12fecd=Is(_0x13adef,_0x12a78b);it(_0x13adef,_0x12fecd),H(_0x13adef['eventQueue_'],_0x12fecd,[]);}function Td(_0x579333,_0x365307,_0x252de7,_0x51e86c){dt(_0x579333,'update',{'path':_0x365307['toString'](),'value':_0x252de7});let _0xb21101=!0x0;const _0x81c85b=Kt(_0x579333),_0x1ba94b={};if(x(_0x252de7,(_0x3264af,_0x34721b)=>{_0xb21101=!0x1,_0x1ba94b[_0x3264af]=na(k(_0x365307,_0x3264af),P(_0x34721b),_0x579333['serverSyncTree_'],_0x81c85b);}),_0xb21101)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x579333,_0x51e86c,'ok',void 0x0);else{const _0x1e5a71=Hn(_0x579333),_0x795c57=ju(_0x579333['serverSyncTree_'],_0x365307,_0x1ba94b,_0x1e5a71);Vn(_0x579333['eventQueue_'],_0x795c57),_0x579333['server_']['merge'](_0x365307['toString'](),_0x252de7,(_0x25df46,_0x19350c)=>{const _0x5297b4=_0x25df46==='ok';_0x5297b4||U('update\x20at\x20'+_0x365307+'\x20failed:\x20'+_0x25df46);const _0x44a30b=pe(_0x579333['serverSyncTree_'],_0x1e5a71,!_0x5297b4),_0x2d6b32=_0x44a30b['length']>0x0?it(_0x579333,_0x365307):_0x365307;H(_0x579333['eventQueue_'],_0x2d6b32,_0x44a30b),ki(_0x579333,_0x51e86c,_0x25df46,_0x19350c);}),x(_0x252de7,_0x58f3c9=>{const _0x48e61c=Is(_0x579333,k(_0x365307,_0x58f3c9));it(_0x579333,_0x48e61c);}),H(_0x579333['eventQueue_'],_0x365307,[]);}}function Sd(_0x489d1a){dt(_0x489d1a,'onDisconnectEvents');const _0x3b9250=Kt(_0x489d1a),_0x5164b1=_n();Ii(_0x489d1a['onDisconnect_'],w(),(_0x2bee0e,_0x689a92)=>{const _0x7a1ead=na(_0x2bee0e,_0x689a92,_0x489d1a['serverSyncTree_'],_0x3b9250);Fo(_0x5164b1,_0x2bee0e,_0x7a1ead);});let _0x249a43=[];Ii(_0x5164b1,w(),(_0x1c8675,_0x1aeea7)=>{_0x249a43=_0x249a43['concat'](Gt(_0x489d1a['serverSyncTree_'],_0x1c8675,_0x1aeea7));const _0x4a7201=Is(_0x489d1a,_0x1c8675);it(_0x489d1a,_0x4a7201);}),_0x489d1a['onDisconnect_']=_n(),H(_0x489d1a['eventQueue_'],w(),_0x249a43);}function bd(_0x586fe,_0x967b02,_0x1e1037){let _0x4ace93;y(_0x967b02['_path'])==='.info'?_0x4ace93=Ri(_0x586fe['infoSyncTree_'],_0x967b02,_0x1e1037):_0x4ace93=Ri(_0x586fe['serverSyncTree_'],_0x967b02,_0x1e1037),oa(_0x586fe['eventQueue_'],_0x967b02['_path'],_0x4ace93);}function Rd(_0x3705a8,_0x1ce26c,_0x19d3d4){let _0x45ecd8;y(_0x1ce26c['_path'])==='.info'?_0x45ecd8=Cn(_0x3705a8['infoSyncTree_'],_0x1ce26c,_0x19d3d4):_0x45ecd8=Cn(_0x3705a8['serverSyncTree_'],_0x1ce26c,_0x19d3d4),oa(_0x3705a8['eventQueue_'],_0x1ce26c['_path'],_0x45ecd8);}function ha(_0x25f77f){_0x25f77f['persistentConnection_']&&_0x25f77f['persistentConnection_']['interrupt'](ca);}function Ad(_0x5b8084){_0x5b8084['persistentConnection_']&&_0x5b8084['persistentConnection_']['resume'](ca);}function dt(_0x3f6f18,..._0x5caac7){let _0x2230fe='';_0x3f6f18['persistentConnection_']&&(_0x2230fe=_0x3f6f18['persistentConnection_']['id']+':'),L(_0x2230fe,..._0x5caac7);}function ki(_0x3d6aa6,_0xe3dd24,_0x3a68e5,_0x3ccebe){_0xe3dd24&&ht(()=>{if(_0x3a68e5==='ok')_0xe3dd24(null);else{const _0x2ef10d=(_0x3a68e5||'error')['toUpperCase']();let _0x13f1d1=_0x2ef10d;_0x3ccebe&&(_0x13f1d1+=':\x20'+_0x3ccebe);const _0x4ab15d=new Error(_0x13f1d1);_0x4ab15d['code']=_0x2ef10d,_0xe3dd24(_0x4ab15d);}});}function kd(_0x461210,_0x200071,_0x427473,_0x5cc3f4,_0x109c8f,_0x15758a){dt(_0x461210,'transaction\x20on\x20'+_0x200071);const _0x4d3164={'path':_0x200071,'update':_0x427473,'onComplete':_0x5cc3f4,'status':null,'order':so(),'applyLocally':_0x15758a,'retryCount':0x0,'unwatcher':_0x109c8f,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x5be880=Es(_0x461210,_0x200071,void 0x0);_0x4d3164['currentInputSnapshot']=_0x5be880;const _0x1fc8e1=_0x4d3164['update'](_0x5be880['val']());if(_0x1fc8e1===void 0x0)_0x4d3164['unwatcher'](),_0x4d3164['currentOutputSnapshotRaw']=null,_0x4d3164['currentOutputSnapshotResolved']=null,_0x4d3164['onComplete']&&_0x4d3164['onComplete'](null,!0x1,_0x4d3164['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x1fc8e1,_0x4d3164['path']),_0x4d3164['status']=0x0;const _0x3334db=Wn(_0x461210['transactionQueueTree_'],_0x200071),_0x50d7c9=Ge(_0x3334db)||[];_0x50d7c9['push'](_0x4d3164),_s(_0x3334db,_0x50d7c9);let _0x786d1f;typeof _0x1fc8e1=='object'&&_0x1fc8e1!==null&&J(_0x1fc8e1,'.priority')?(_0x786d1f=De(_0x1fc8e1,'.priority'),f(Tn(_0x786d1f),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x786d1f=(Fn(_0x461210['serverSyncTree_'],_0x200071)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x41f6ad=Kt(_0x461210),_0x21050e=P(_0x1fc8e1,_0x786d1f),_0x31e51d=ds(_0x21050e,_0x5be880,_0x41f6ad);_0x4d3164['currentOutputSnapshotRaw']=_0x21050e,_0x4d3164['currentOutputSnapshotResolved']=_0x31e51d,_0x4d3164['currentWriteId']=Hn(_0x461210);const _0x2b6e73=os(_0x461210['serverSyncTree_'],_0x200071,_0x31e51d,_0x4d3164['currentWriteId'],_0x4d3164['applyLocally']);H(_0x461210['eventQueue_'],_0x200071,_0x2b6e73),$n(_0x461210,_0x461210['transactionQueueTree_']);}}function Es(_0x48ca9a,_0x3aecc7,_0x4bf0c4){return Fn(_0x48ca9a['serverSyncTree_'],_0x3aecc7,_0x4bf0c4)||g['EMPTY_NODE'];}function $n(_0x5c82c9,_0x3020b2=_0x5c82c9['transactionQueueTree_']){if(_0x3020b2||Gn(_0x5c82c9,_0x3020b2),Ge(_0x3020b2)){const _0x1e3189=da(_0x5c82c9,_0x3020b2);f(_0x1e3189['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x1e3189['every'](_0x4ab55=>_0x4ab55['status']===0x0)&&Nd(_0x5c82c9,qt(_0x3020b2),_0x1e3189);}else ia(_0x3020b2)&&Bn(_0x3020b2,_0x4a3725=>{$n(_0x5c82c9,_0x4a3725);});}function Nd(_0x1a53fc,_0x2b6fa1,_0x3d522d){const _0x14f85a=_0x3d522d['map'](_0x450e91=>_0x450e91['currentWriteId']),_0x141062=Es(_0x1a53fc,_0x2b6fa1,_0x14f85a);let _0x5a46d3=_0x141062;const _0x65ca9=_0x141062['hash']();for(let _0x4fc545=0x0;_0x4fc545<_0x3d522d['length'];_0x4fc545++){const _0x5d1b34=_0x3d522d[_0x4fc545];f(_0x5d1b34['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x5d1b34['status']=0x1,_0x5d1b34['retryCount']++;const _0x59e847=F(_0x2b6fa1,_0x5d1b34['path']);_0x5a46d3=_0x5a46d3['updateChild'](_0x59e847,_0x5d1b34['currentOutputSnapshotRaw']);}const _0x5756b4=_0x5a46d3['val'](!0x0),_0x333dda=_0x2b6fa1;_0x1a53fc['server_']['put'](_0x333dda['toString'](),_0x5756b4,_0x524c73=>{dt(_0x1a53fc,'transaction\x20put\x20response',{'path':_0x333dda['toString'](),'status':_0x524c73});let _0x88306e=[];if(_0x524c73==='ok'){const _0x335e39=[];for(let _0x372075=0x0;_0x372075<_0x3d522d['length'];_0x372075++)_0x3d522d[_0x372075]['status']=0x2,_0x88306e=_0x88306e['concat'](pe(_0x1a53fc['serverSyncTree_'],_0x3d522d[_0x372075]['currentWriteId'])),_0x3d522d[_0x372075]['onComplete']&&_0x335e39['push'](()=>_0x3d522d[_0x372075]['onComplete'](null,!0x0,_0x3d522d[_0x372075]['currentOutputSnapshotResolved'])),_0x3d522d[_0x372075]['unwatcher']();Gn(_0x1a53fc,Wn(_0x1a53fc['transactionQueueTree_'],_0x2b6fa1)),$n(_0x1a53fc,_0x1a53fc['transactionQueueTree_']),H(_0x1a53fc['eventQueue_'],_0x2b6fa1,_0x88306e);for(let _0x95377b=0x0;_0x95377b<_0x335e39['length'];_0x95377b++)ht(_0x335e39[_0x95377b]);}else{if(_0x524c73==='datastale'){for(let _0x4cb904=0x0;_0x4cb904<_0x3d522d['length'];_0x4cb904++)_0x3d522d[_0x4cb904]['status']===0x3?_0x3d522d[_0x4cb904]['status']=0x4:_0x3d522d[_0x4cb904]['status']=0x0;}else{U('transaction\x20at\x20'+_0x333dda['toString']()+'\x20failed:\x20'+_0x524c73);for(let _0x18e635=0x0;_0x18e635<_0x3d522d['length'];_0x18e635++)_0x3d522d[_0x18e635]['status']=0x4,_0x3d522d[_0x18e635]['abortReason']=_0x524c73;}it(_0x1a53fc,_0x2b6fa1);}},_0x65ca9);}function it(_0x1822ed,_0x188c8b){const _0x4df8eb=ua(_0x1822ed,_0x188c8b),_0x2e6c16=qt(_0x4df8eb),_0x4363a4=da(_0x1822ed,_0x4df8eb);return Pd(_0x1822ed,_0x4363a4,_0x2e6c16),_0x2e6c16;}function Pd(_0x4f609d,_0x226ef4,_0x247985){if(_0x226ef4['length']===0x0)return;const _0x1f822f=[];let _0x529b01=[];const _0x35b8e3=_0x226ef4['filter'](_0x40f68b=>_0x40f68b['status']===0x0)['map'](_0x3b2833=>_0x3b2833['currentWriteId']);for(let _0x54551f=0x0;_0x54551f<_0x226ef4['length'];_0x54551f++){const _0x3b1373=_0x226ef4[_0x54551f],_0x193f1d=F(_0x247985,_0x3b1373['path']);let _0x2e75d0=!0x1,_0x33def4;if(f(_0x193f1d!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x3b1373['status']===0x4)_0x2e75d0=!0x0,_0x33def4=_0x3b1373['abortReason'],_0x529b01=_0x529b01['concat'](pe(_0x4f609d['serverSyncTree_'],_0x3b1373['currentWriteId'],!0x0));else{if(_0x3b1373['status']===0x0){if(_0x3b1373['retryCount']>=yd)_0x2e75d0=!0x0,_0x33def4='maxretry',_0x529b01=_0x529b01['concat'](pe(_0x4f609d['serverSyncTree_'],_0x3b1373['currentWriteId'],!0x0));else{const _0xc76e1a=Es(_0x4f609d,_0x3b1373['path'],_0x35b8e3);_0x3b1373['currentInputSnapshot']=_0xc76e1a;const _0x190ef5=_0x226ef4[_0x54551f]['update'](_0xc76e1a['val']());if(_0x190ef5!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x190ef5,_0x3b1373['path']);let _0x3acff3=P(_0x190ef5);typeof _0x190ef5=='object'&&_0x190ef5!=null&&J(_0x190ef5,'.priority')||(_0x3acff3=_0x3acff3['updatePriority'](_0xc76e1a['getPriority']()));const _0x59eb3c=_0x3b1373['currentWriteId'],_0x3b9302=Kt(_0x4f609d),_0x31f6ae=ds(_0x3acff3,_0xc76e1a,_0x3b9302);_0x3b1373['currentOutputSnapshotRaw']=_0x3acff3,_0x3b1373['currentOutputSnapshotResolved']=_0x31f6ae,_0x3b1373['currentWriteId']=Hn(_0x4f609d),_0x35b8e3['splice'](_0x35b8e3['indexOf'](_0x59eb3c),0x1),_0x529b01=_0x529b01['concat'](os(_0x4f609d['serverSyncTree_'],_0x3b1373['path'],_0x31f6ae,_0x3b1373['currentWriteId'],_0x3b1373['applyLocally'])),_0x529b01=_0x529b01['concat'](pe(_0x4f609d['serverSyncTree_'],_0x59eb3c,!0x0));}else _0x2e75d0=!0x0,_0x33def4='nodata',_0x529b01=_0x529b01['concat'](pe(_0x4f609d['serverSyncTree_'],_0x3b1373['currentWriteId'],!0x0));}}}H(_0x4f609d['eventQueue_'],_0x247985,_0x529b01),_0x529b01=[],_0x2e75d0&&(_0x226ef4[_0x54551f]['status']=0x2,function(_0x1fc081){setTimeout(_0x1fc081,Math['floor'](0x0));}(_0x226ef4[_0x54551f]['unwatcher']),_0x226ef4[_0x54551f]['onComplete']&&(_0x33def4==='nodata'?_0x1f822f['push'](()=>_0x226ef4[_0x54551f]['onComplete'](null,!0x1,_0x226ef4[_0x54551f]['currentInputSnapshot'])):_0x1f822f['push'](()=>_0x226ef4[_0x54551f]['onComplete'](new Error(_0x33def4),!0x1,null))));}Gn(_0x4f609d,_0x4f609d['transactionQueueTree_']);for(let _0x19d2b1=0x0;_0x19d2b1<_0x1f822f['length'];_0x19d2b1++)ht(_0x1f822f[_0x19d2b1]);$n(_0x4f609d,_0x4f609d['transactionQueueTree_']);}function ua(_0x1f954d,_0x1119ee){let _0x25da40,_0x22b5d5=_0x1f954d['transactionQueueTree_'];for(_0x25da40=y(_0x1119ee);_0x25da40!==null&&Ge(_0x22b5d5)===void 0x0;)_0x22b5d5=Wn(_0x22b5d5,_0x25da40),_0x1119ee=b(_0x1119ee),_0x25da40=y(_0x1119ee);return _0x22b5d5;}function da(_0x276bff,_0x248bdc){const _0x56ab67=[];return fa(_0x276bff,_0x248bdc,_0x56ab67),_0x56ab67['sort']((_0x44060f,_0x1efaa4)=>_0x44060f['order']-_0x1efaa4['order']),_0x56ab67;}function fa(_0x18966b,_0x18aa3d,_0x453d1a){const _0x53871f=Ge(_0x18aa3d);if(_0x53871f){for(let _0x381c68=0x0;_0x381c68<_0x53871f['length'];_0x381c68++)_0x453d1a['push'](_0x53871f[_0x381c68]);}Bn(_0x18aa3d,_0x49f3c9=>{fa(_0x18966b,_0x49f3c9,_0x453d1a);});}function Gn(_0x217930,_0x43563e){const _0x2c82c7=Ge(_0x43563e);if(_0x2c82c7){let _0x16d554=0x0;for(let _0x328854=0x0;_0x328854<_0x2c82c7['length'];_0x328854++)_0x2c82c7[_0x328854]['status']!==0x2&&(_0x2c82c7[_0x16d554]=_0x2c82c7[_0x328854],_0x16d554++);_0x2c82c7['length']=_0x16d554,_s(_0x43563e,_0x2c82c7['length']>0x0?_0x2c82c7:void 0x0);}Bn(_0x43563e,_0x46834e=>{Gn(_0x217930,_0x46834e);});}function Is(_0x2ac44e,_0x30c980){const _0x4bb82e=qt(ua(_0x2ac44e,_0x30c980)),_0x546bb=Wn(_0x2ac44e['transactionQueueTree_'],_0x30c980);return ad(_0x546bb,_0x232d8e=>{ci(_0x2ac44e,_0x232d8e);}),ci(_0x2ac44e,_0x546bb),sa(_0x546bb,_0x46b60f=>{ci(_0x2ac44e,_0x46b60f);}),_0x4bb82e;}function ci(_0x5c81dd,_0x5abf7c){const _0x574cee=Ge(_0x5abf7c);if(_0x574cee){const _0x59bc7e=[];let _0x5c761c=[],_0xd8a155=-0x1;for(let _0x4468b8=0x0;_0x4468b8<_0x574cee['length'];_0x4468b8++)_0x574cee[_0x4468b8]['status']===0x3||(_0x574cee[_0x4468b8]['status']===0x1?(f(_0xd8a155===_0x4468b8-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0xd8a155=_0x4468b8,_0x574cee[_0x4468b8]['status']=0x3,_0x574cee[_0x4468b8]['abortReason']='set'):(f(_0x574cee[_0x4468b8]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x574cee[_0x4468b8]['unwatcher'](),_0x5c761c=_0x5c761c['concat'](pe(_0x5c81dd['serverSyncTree_'],_0x574cee[_0x4468b8]['currentWriteId'],!0x0)),_0x574cee[_0x4468b8]['onComplete']&&_0x59bc7e['push'](_0x574cee[_0x4468b8]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0xd8a155===-0x1?_s(_0x5abf7c,void 0x0):_0x574cee['length']=_0xd8a155+0x1,H(_0x5c81dd['eventQueue_'],qt(_0x5abf7c),_0x5c761c);for(let _0x27410e=0x0;_0x27410e<_0x59bc7e['length'];_0x27410e++)ht(_0x59bc7e[_0x27410e]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x4dfa85){let _0x37ad3a='';const _0x24f7da=_0x4dfa85['split']('/');for(let _0x1029ae=0x0;_0x1029ae<_0x24f7da['length'];_0x1029ae++)if(_0x24f7da[_0x1029ae]['length']>0x0){let _0x13daa5=_0x24f7da[_0x1029ae];try{_0x13daa5=decodeURIComponent(_0x13daa5['replace'](/\+/g,'\x20'));}catch{}_0x37ad3a+='/'+_0x13daa5;}return _0x37ad3a;}function Dd(_0xc46ecb){const _0x1f3962={};_0xc46ecb['charAt'](0x0)==='?'&&(_0xc46ecb=_0xc46ecb['substring'](0x1));for(const _0x1a6980 of _0xc46ecb['split']('&')){if(_0x1a6980['length']===0x0)continue;const _0xd39ea=_0x1a6980['split']('=');_0xd39ea['length']===0x2?_0x1f3962[decodeURIComponent(_0xd39ea[0x0])]=decodeURIComponent(_0xd39ea[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x1a6980+'\x27\x20in\x20query\x20\x27'+_0xc46ecb+'\x27');}return _0x1f3962;}const vr=function(_0x1bed8f,_0x162b39){const _0x500cf6=Md(_0x1bed8f),_0x3713d2=_0x500cf6['namespace'];_0x500cf6['domain']==='firebase.com'&&ae(_0x500cf6['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x3713d2||_0x3713d2==='undefined')&&_0x500cf6['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x500cf6['secure']||$l();const _0x354e52=_0x500cf6['scheme']==='ws'||_0x500cf6['scheme']==='wss';return{'repoInfo':new yo(_0x500cf6['host'],_0x500cf6['secure'],_0x3713d2,_0x354e52,_0x162b39,'',_0x3713d2!==_0x500cf6['subdomain']),'path':new C(_0x500cf6['pathString'])};},Md=function(_0x2a5f72){let _0xb22d7='',_0xbd1627='',_0x3f719e='',_0x3af9a0='',_0x267420='',_0x975c68=!0x0,_0xe55f7b='https',_0x3c863d=0x1bb;if(typeof _0x2a5f72=='string'){let _0x368161=_0x2a5f72['indexOf']('//');_0x368161>=0x0&&(_0xe55f7b=_0x2a5f72['substring'](0x0,_0x368161-0x1),_0x2a5f72=_0x2a5f72['substring'](_0x368161+0x2));let _0x1adf35=_0x2a5f72['indexOf']('/');_0x1adf35===-0x1&&(_0x1adf35=_0x2a5f72['length']);let _0x5056dd=_0x2a5f72['indexOf']('?');_0x5056dd===-0x1&&(_0x5056dd=_0x2a5f72['length']),_0xb22d7=_0x2a5f72['substring'](0x0,Math['min'](_0x1adf35,_0x5056dd)),_0x1adf35<_0x5056dd&&(_0x3af9a0=Od(_0x2a5f72['substring'](_0x1adf35,_0x5056dd)));const _0x45efab=Dd(_0x2a5f72['substring'](Math['min'](_0x2a5f72['length'],_0x5056dd)));_0x368161=_0xb22d7['indexOf'](':'),_0x368161>=0x0?(_0x975c68=_0xe55f7b==='https'||_0xe55f7b==='wss',_0x3c863d=parseInt(_0xb22d7['substring'](_0x368161+0x1),0xa)):_0x368161=_0xb22d7['length'];const _0xb94ac5=_0xb22d7['slice'](0x0,_0x368161);if(_0xb94ac5['toLowerCase']()==='localhost')_0xbd1627='localhost';else{if(_0xb94ac5['split']('.')['length']<=0x2)_0xbd1627=_0xb94ac5;else{const _0x2e0827=_0xb22d7['indexOf']('.');_0x3f719e=_0xb22d7['substring'](0x0,_0x2e0827)['toLowerCase'](),_0xbd1627=_0xb22d7['substring'](_0x2e0827+0x1),_0x267420=_0x3f719e;}}'ns'in _0x45efab&&(_0x267420=_0x45efab['ns']);}return{'host':_0xb22d7,'port':_0x3c863d,'domain':_0xbd1627,'subdomain':_0x3f719e,'secure':_0x975c68,'scheme':_0xe55f7b,'pathString':_0x3af9a0,'namespace':_0x267420};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x14a4c2=0x0;const _0x5e7ad3=[];return function(_0x596c5e){const _0x21ed7e=_0x596c5e===_0x14a4c2;_0x14a4c2=_0x596c5e;let _0x33dcf1;const _0x333c4c=new Array(0x8);for(_0x33dcf1=0x7;_0x33dcf1>=0x0;_0x33dcf1--)_0x333c4c[_0x33dcf1]=Er['charAt'](_0x596c5e%0x40),_0x596c5e=Math['floor'](_0x596c5e/0x40);f(_0x596c5e===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x3b4c6a=_0x333c4c['join']('');if(_0x21ed7e){for(_0x33dcf1=0xb;_0x33dcf1>=0x0&&_0x5e7ad3[_0x33dcf1]===0x3f;_0x33dcf1--)_0x5e7ad3[_0x33dcf1]=0x0;_0x5e7ad3[_0x33dcf1]++;}else{for(_0x33dcf1=0x0;_0x33dcf1<0xc;_0x33dcf1++)_0x5e7ad3[_0x33dcf1]=Math['floor'](Math['random']()*0x40);}for(_0x33dcf1=0x0;_0x33dcf1<0xc;_0x33dcf1++)_0x3b4c6a+=Er['charAt'](_0x5e7ad3[_0x33dcf1]);return f(_0x3b4c6a['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x3b4c6a;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x4430f1,_0x29ce3b,_0x4b45df,_0x3078b9){this['eventType']=_0x4430f1,this['eventRegistration']=_0x29ce3b,this['snapshot']=_0x4b45df,this['prevName']=_0x3078b9;}['getPath'](){const _0x24a08f=this['snapshot']['ref'];return this['eventType']==='value'?_0x24a08f['_path']:_0x24a08f['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x30e033,_0x1cff20,_0x484aef){this['eventRegistration']=_0x30e033,this['error']=_0x1cff20,this['path']=_0x484aef;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x2f414d,_0x2c87f6){this['snapshotCallback']=_0x2f414d,this['cancelCallback']=_0x2c87f6;}['onValue'](_0xe96818,_0x3b0757){this['snapshotCallback']['call'](null,_0xe96818,_0x3b0757);}['onCancel'](_0x33d227){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x33d227);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x3ec88c){return this['snapshotCallback']===_0x3ec88c['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x3ec88c['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x3ec88c['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x17cf93,_0x144a2a,_0x4dbbc0,_0x1e9ad2){this['_repo']=_0x17cf93,this['_path']=_0x144a2a,this['_queryParams']=_0x4dbbc0,this['_orderByCalled']=_0x1e9ad2;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x3020d0=rr(this['_queryParams']),_0x58c1bb=Hi(_0x3020d0);return _0x58c1bb==='{}'?'default':_0x58c1bb;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x4f9f40){if(_0x4f9f40=N(_0x4f9f40),!(_0x4f9f40 instanceof be))return!0x1;const _0x23c63e=this['_repo']===_0x4f9f40['_repo'],_0x37ac89=ji(this['_path'],_0x4f9f40['_path']),_0xea3bfb=this['_queryIdentifier']===_0x4f9f40['_queryIdentifier'];return _0x23c63e&&_0x37ac89&&_0xea3bfb;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x14d5f5,_0x322c2a){if(_0x14d5f5['_orderByCalled']===!0x0)throw new Error(_0x322c2a+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x39266e){let _0x52a162=null,_0x1f0fda=null;if(_0x39266e['hasStart']()&&(_0x52a162=_0x39266e['getIndexStartValue']()),_0x39266e['hasEnd']()&&(_0x1f0fda=_0x39266e['getIndexEndValue']()),_0x39266e['getIndex']()===ye){const _0x1f18a1='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x26173e='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x39266e['hasStart']()){if(_0x39266e['getIndexStartName']()!==Fe)throw new Error(_0x1f18a1);if(typeof _0x52a162!='string')throw new Error(_0x26173e);}if(_0x39266e['hasEnd']()){if(_0x39266e['getIndexEndName']()!==Ie)throw new Error(_0x1f18a1);if(typeof _0x1f0fda!='string')throw new Error(_0x26173e);}}else{if(_0x39266e['getIndex']()===R){if(_0x52a162!=null&&!Tn(_0x52a162)||_0x1f0fda!=null&&!Tn(_0x1f0fda))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x39266e['getIndex']()instanceof Qi||_0x39266e['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x52a162!=null&&typeof _0x52a162=='object'||_0x1f0fda!=null&&typeof _0x1f0fda=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x4cb39f){if(_0x4cb39f['hasStart']()&&_0x4cb39f['hasEnd']()&&_0x4cb39f['hasLimit']()&&!_0x4cb39f['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x1a6f04,_0x2362bc){super(_0x1a6f04,_0x2362bc,new Xi(),!0x1);}get['parent'](){const _0x108318=Ro(this['_path']);return _0x108318===null?null:new ee(this['_repo'],_0x108318);}get['root'](){let _0x205f0e=this;for(;_0x205f0e['parent']!==null;)_0x205f0e=_0x205f0e['parent'];return _0x205f0e;}}class st{constructor(_0x59057a,_0x33647a,_0x4d8ea7){this['_node']=_0x59057a,this['ref']=_0x33647a,this['_index']=_0x4d8ea7;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x18e2d8){const _0x4f1248=new C(_0x18e2d8),_0x322554=Ft(this['ref'],_0x18e2d8);return new st(this['_node']['getChild'](_0x4f1248),_0x322554,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x2ae2e5){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x89bb65,_0x259674)=>_0x2ae2e5(new st(_0x259674,Ft(this['ref'],_0x89bb65),R)));}['hasChild'](_0x518293){const _0x280d94=new C(_0x518293);return!this['_node']['getChild'](_0x280d94)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x3ba36d,_0x67283e){return _0x3ba36d=N(_0x3ba36d),_0x3ba36d['_checkNotDeleted']('ref'),_0x67283e!==void 0x0?Ft(_0x3ba36d['_root'],_0x67283e):_0x3ba36d['_root'];}function Ft(_0x311839,_0x82ffb9){return _0x311839=N(_0x311839),y(_0x311839['_path'])===null?pd('child','path',_0x82ffb9):ms('child','path',_0x82ffb9),new ee(_0x311839['_repo'],k(_0x311839['_path'],_0x82ffb9));}function g_(_0x540834,_0x4754f2){_0x540834=N(_0x540834),ys('push',_0x540834['_path']),zt('push',_0x4754f2,_0x540834['_path'],!0x0);const _0x231238=la(_0x540834['_repo']),_0xfea457=Ld(_0x231238),_0x2d9b4e=Ft(_0x540834,_0xfea457),_0xaeb86f=Ft(_0x540834,_0xfea457);let _0x2ec4b9;return _0x4754f2!=null?_0x2ec4b9=Ud(_0xaeb86f,_0x4754f2)['then'](()=>_0xaeb86f):_0x2ec4b9=Promise['resolve'](_0xaeb86f),_0x2d9b4e['then']=_0x2ec4b9['then']['bind'](_0x2ec4b9),_0x2d9b4e['catch']=_0x2ec4b9['then']['bind'](_0x2ec4b9,void 0x0),_0x2d9b4e;}function Ud(_0x4f27a7,_0x5edb37){_0x4f27a7=N(_0x4f27a7),ys('set',_0x4f27a7['_path']),zt('set',_0x5edb37,_0x4f27a7['_path'],!0x1);const _0x3c04de=new ot();return Cd(_0x4f27a7['_repo'],_0x4f27a7['_path'],_0x5edb37,null,_0x3c04de['wrapCallback'](()=>{})),_0x3c04de['promise'];}function m_(_0x14ba4a,_0x3ec8ae){fd('update',_0x3ec8ae,_0x14ba4a['_path']);const _0x305ac4=new ot();return Td(_0x14ba4a['_repo'],_0x14ba4a['_path'],_0x3ec8ae,_0x305ac4['wrapCallback'](()=>{})),_0x305ac4['promise'];}function y_(_0x2c82b9){_0x2c82b9=N(_0x2c82b9);const _0x207f2a=new pa(()=>{}),_0x4ebc6f=new zn(_0x207f2a);return wd(_0x2c82b9['_repo'],_0x2c82b9,_0x4ebc6f)['then'](_0x1452ab=>new st(_0x1452ab,new ee(_0x2c82b9['_repo'],_0x2c82b9['_path']),_0x2c82b9['_queryParams']['getIndex']()));}class zn{constructor(_0x3056d3){this['callbackContext']=_0x3056d3;}['respondsTo'](_0x25f78c){return _0x25f78c==='value';}['createEvent'](_0x4da308,_0x5a9cdf){const _0x219f4c=_0x5a9cdf['_queryParams']['getIndex']();return new xd('value',this,new st(_0x4da308['snapshotNode'],new ee(_0x5a9cdf['_repo'],_0x5a9cdf['_path']),_0x219f4c));}['getEventRunner'](_0x39692){return _0x39692['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x39692['error']):()=>this['callbackContext']['onValue'](_0x39692['snapshot'],null);}['createCancelEvent'](_0x2d97b3,_0x2a5839){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x2d97b3,_0x2a5839):null;}['matches'](_0x71ecb9){return _0x71ecb9 instanceof zn?!_0x71ecb9['callbackContext']||!this['callbackContext']?!0x0:_0x71ecb9['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x1e515a,_0x5376ee,_0x395e5f,_0x42929b,_0x1922dc){const _0xac40c6=new pa(_0x395e5f,void 0x0),_0x492aa9=new zn(_0xac40c6);return bd(_0x1e515a['_repo'],_0x1e515a,_0x492aa9),()=>Rd(_0x1e515a['_repo'],_0x1e515a,_0x492aa9);}function Bd(_0x2a6cd0,_0x142806,_0x4fe62d,_0x1b4e6b){return Wd(_0x2a6cd0,'value',_0x142806);}class ft{}class ma extends ft{constructor(_0x327449,_0x1e6011){super(),this['_value']=_0x327449,this['_key']=_0x1e6011,this['type']='endAt';}['_apply'](_0x154e9f){zt('endAt',this['_value'],_0x154e9f['_path'],!0x0);const _0x561e87=Jh(_0x154e9f['_queryParams'],this['_value'],this['_key']);if(ga(_0x561e87),qn(_0x561e87),_0x154e9f['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x154e9f['_repo'],_0x154e9f['_path'],_0x561e87,_0x154e9f['_orderByCalled']);}}function v_(_0x37345f,_0x4212dc){return new ma(_0x37345f,_0x4212dc);}class ya extends ft{constructor(_0x2013c9,_0x24f57b){super(),this['_value']=_0x2013c9,this['_key']=_0x24f57b,this['type']='startAt';}['_apply'](_0x1917d6){zt('startAt',this['_value'],_0x1917d6['_path'],!0x0);const _0x45345e=Qh(_0x1917d6['_queryParams'],this['_value'],this['_key']);if(ga(_0x45345e),qn(_0x45345e),_0x1917d6['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x1917d6['_repo'],_0x1917d6['_path'],_0x45345e,_0x1917d6['_orderByCalled']);}}function E_(_0x3c2a49=null,_0x503b87){return new ya(_0x3c2a49,_0x503b87);}class Vd extends ft{constructor(_0x3fe7d5){super(),this['_limit']=_0x3fe7d5,this['type']='limitToFirst';}['_apply'](_0x5b4bee){if(_0x5b4bee['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x5b4bee['_repo'],_0x5b4bee['_path'],Yh(_0x5b4bee['_queryParams'],this['_limit']),_0x5b4bee['_orderByCalled']);}}function I_(_0x1be868){if(Math['floor'](_0x1be868)!==_0x1be868||_0x1be868<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x1be868);}class Hd extends ft{constructor(_0x585561){super(),this['_path']=_0x585561,this['type']='orderByChild';}['_apply'](_0x33655f){_a(_0x33655f,'orderByChild');const _0x207193=new C(this['_path']);if(v(_0x207193))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x2b834e=new Qi(_0x207193),_0xed64b=xo(_0x33655f['_queryParams'],_0x2b834e);return qn(_0xed64b),new be(_0x33655f['_repo'],_0x33655f['_path'],_0xed64b,!0x0);}}function w_(_0x4f70a4){if(_0x4f70a4==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x4f70a4==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x4f70a4==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x4f70a4),new Hd(_0x4f70a4);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x1c6928){_a(_0x1c6928,'orderByKey');const _0x2193c0=xo(_0x1c6928['_queryParams'],ye);return qn(_0x2193c0),new be(_0x1c6928['_repo'],_0x1c6928['_path'],_0x2193c0,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x1f33cf,_0x4bcbc8){super(),this['_value']=_0x1f33cf,this['_key']=_0x4bcbc8,this['type']='equalTo';}['_apply'](_0x41fb3e){if(zt('equalTo',this['_value'],_0x41fb3e['_path'],!0x1),_0x41fb3e['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x41fb3e['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x41fb3e));}}function T_(_0x4fb75d,_0x46dbdc){return new Gd(_0x4fb75d,_0x46dbdc);}function S_(_0x105349,..._0x529d2b){let _0x11b46b=N(_0x105349);for(const _0x453569 of _0x529d2b)_0x11b46b=_0x453569['_apply'](_0x11b46b);return _0x11b46b;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x80c09a,_0x4fb22a,_0x56ec70,_0x238b68){const _0x2a16ea=_0x4fb22a['lastIndexOf'](':'),_0x178f70=_0x4fb22a['substring'](0x0,_0x2a16ea),_0x5ac33e=at(_0x178f70);_0x80c09a['repoInfo_']=new yo(_0x4fb22a,_0x5ac33e,_0x80c09a['repoInfo_']['namespace'],_0x80c09a['repoInfo_']['webSocketOnly'],_0x80c09a['repoInfo_']['nodeAdmin'],_0x80c09a['repoInfo_']['persistenceKey'],_0x80c09a['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x56ec70),_0x238b68&&(_0x80c09a['authTokenProvider_']=_0x238b68);}function Kd(_0x2f4c29,_0x132cf3,_0x479c4e,_0x3a916b,_0x1ecd26){let _0x36804e=_0x3a916b||_0x2f4c29['options']['databaseURL'];_0x36804e===void 0x0&&(_0x2f4c29['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x2f4c29['options']['projectId']),_0x36804e=_0x2f4c29['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x35b2ce=vr(_0x36804e,_0x1ecd26),_0x9bf65c=_0x35b2ce['repoInfo'],_0x177f7e;typeof process<'u'&&Vs&&(_0x177f7e=Vs[qd]),_0x177f7e?(_0x36804e='http://'+_0x177f7e+'?ns='+_0x9bf65c['namespace'],_0x35b2ce=vr(_0x36804e,_0x1ecd26),_0x9bf65c=_0x35b2ce['repoInfo']):_0x35b2ce['repoInfo']['secure'];const _0x48dbcf=new eh(_0x2f4c29['name'],_0x2f4c29['options'],_0x132cf3);_d('Invalid\x20Firebase\x20Database\x20URL',_0x35b2ce),v(_0x35b2ce['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x332347=Qd(_0x9bf65c,_0x2f4c29,_0x48dbcf,new Zl(_0x2f4c29,_0x479c4e));return new Jd(_0x332347,_0x2f4c29);}function Yd(_0x2d59f7,_0x5e3e82){const _0x7a83ca=Ni[_0x5e3e82];(!_0x7a83ca||_0x7a83ca[_0x2d59f7['key']]!==_0x2d59f7)&&ae('Database\x20'+_0x5e3e82+'('+_0x2d59f7['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x2d59f7),delete _0x7a83ca[_0x2d59f7['key']];}function Qd(_0x1fd628,_0x4d61be,_0x1915d4,_0x2e997b){let _0x1aa6e4=Ni[_0x4d61be['name']];_0x1aa6e4||(_0x1aa6e4={},Ni[_0x4d61be['name']]=_0x1aa6e4);let _0x31c3fa=_0x1aa6e4[_0x1fd628['toURLString']()];return _0x31c3fa&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x31c3fa=new vd(_0x1fd628,zd,_0x1915d4,_0x2e997b),_0x1aa6e4[_0x1fd628['toURLString']()]=_0x31c3fa,_0x31c3fa;}class Jd{constructor(_0x3dd829,_0xba98a5){this['_repoInternal']=_0x3dd829,this['app']=_0xba98a5,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0xaed7f){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0xaed7f+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x81183a=Zr(),_0xd58f55){const _0x527204=Bi(_0x81183a,'database')['getImmediate']({'identifier':_0xd58f55});if(!_0x527204['_instanceStarted']){const _0x3559f8=cc('database');_0x3559f8&&Xd(_0x527204,..._0x3559f8);}return _0x527204;}function Xd(_0x38b49a,_0x281e1b,_0x4e8ee4,_0x595874={}){_0x38b49a=N(_0x38b49a),_0x38b49a['_checkNotDeleted']('useEmulator');const _0x54ba4d=_0x281e1b+':'+_0x4e8ee4,_0x552234=_0x38b49a['_repoInternal'];if(_0x38b49a['_instanceStarted']){if(_0x54ba4d===_0x38b49a['_repoInternal']['repoInfo_']['host']&&Me(_0x595874,_0x552234['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x206cb1;if(_0x552234['repoInfo_']['nodeAdmin'])_0x595874['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x206cb1=new nn(nn['OWNER']);else{if(_0x595874['mockUserToken']){const _0x20107a=typeof _0x595874['mockUserToken']=='string'?_0x595874['mockUserToken']:lc(_0x595874['mockUserToken'],_0x38b49a['app']['options']['projectId']);_0x206cb1=new nn(_0x20107a);}}at(_0x281e1b)&&(jr(_0x281e1b),Kr('Database',!0x0)),jd(_0x552234,_0x54ba4d,_0x595874,_0x206cb1);}function R_(_0x5ed863){_0x5ed863=N(_0x5ed863),_0x5ed863['_checkNotDeleted']('goOffline'),ha(_0x5ed863['_repo']);}function A_(_0x3b6bba){_0x3b6bba=N(_0x3b6bba),_0x3b6bba['_checkNotDeleted']('goOnline'),Ad(_0x3b6bba['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x442669){Ul(lt),Ze(new Le('database',(_0x9f090e,{instanceIdentifier:_0x2ab8dc})=>{const _0x5dcb30=_0x9f090e['getProvider']('app')['getImmediate'](),_0x25e8ab=_0x9f090e['getProvider']('auth-internal'),_0xbd9f63=_0x9f090e['getProvider']('app-check-internal');return Kd(_0x5dcb30,_0x25e8ab,_0xbd9f63,_0x2ab8dc);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x442669),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x54e0c7,_0x1bf903){this['committed']=_0x54e0c7,this['snapshot']=_0x1bf903;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0xed19a3,_0x4d6232,_0x1d1b43){if(_0xed19a3=N(_0xed19a3),ys('Reference.transaction',_0xed19a3['_path']),_0xed19a3['key']==='.length'||_0xed19a3['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0xed19a3['key']+'\x20is\x20a\x20read-only\x20object.';const _0x14c4e9=!0x0,_0x3d6c33=new ot(),_0x28213b=(_0x5430c0,_0x31098b,_0x19e778)=>{let _0x42b406=null;_0x5430c0?_0x3d6c33['reject'](_0x5430c0):(_0x42b406=new st(_0x19e778,new ee(_0xed19a3['_repo'],_0xed19a3['_path']),R),_0x3d6c33['resolve'](new tf(_0x31098b,_0x42b406)));},_0x42ecb5=Bd(_0xed19a3,()=>{});return kd(_0xed19a3['_repo'],_0xed19a3['_path'],_0x4d6232,_0x28213b,_0x42ecb5,_0x14c4e9),_0x3d6c33['promise'];}se['prototype']['simpleListen']=function(_0x3e125d,_0x4cb186){this['sendRequest']('q',{'p':_0x3e125d},_0x4cb186);},se['prototype']['echo']=function(_0x5014be,_0x4cafa6){this['sendRequest']('echo',{'d':_0x5014be},_0x4cafa6);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x5a8d0b,..._0x3ce873){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x5a8d0b,..._0x3ce873);}function sn(_0x5318d4,..._0x14e41d){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x5318d4,..._0x14e41d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x5796ec,..._0x5d97fa){throw ws(_0x5796ec,..._0x5d97fa);}function X(_0x1a27f0,..._0x7551b0){return ws(_0x1a27f0,..._0x7551b0);}function Ia(_0x391450,_0x51bfc8,_0x520450){const _0x3b5ace={...nf(),[_0x51bfc8]:_0x520450};return new Bt('auth','Firebase',_0x3b5ace)['create'](_0x51bfc8,{'appName':_0x391450['name']});}function re(_0x2fa78c){return Ia(_0x2fa78c,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x2657dd,..._0x23b008){if(typeof _0x2657dd!='string'){const _0x2db62=_0x23b008[0x0],_0x515c2b=[..._0x23b008['slice'](0x1)];return _0x515c2b[0x0]&&(_0x515c2b[0x0]['appName']=_0x2657dd['name']),_0x2657dd['_errorFactory']['create'](_0x2db62,..._0x515c2b);}return Ea['create'](_0x2657dd,..._0x23b008);}function m(_0x45b02f,_0x31f0f3,..._0x2d431a){if(!_0x45b02f)throw ws(_0x31f0f3,..._0x2d431a);}function ne(_0x1f1a0a){const _0x2ca9d8='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1f1a0a;throw sn(_0x2ca9d8),new Error(_0x2ca9d8);}function ce(_0x3a2a07,_0x22968c){_0x3a2a07||ne(_0x22968c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x17c4e1;return typeof self<'u'&&((_0x17c4e1=self['location'])==null?void 0x0:_0x17c4e1['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x107295;return typeof self<'u'&&((_0x107295=self['location'])==null?void 0x0:_0x107295['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x1cb9f1=navigator;return _0x1cb9f1['languages']&&_0x1cb9f1['languages'][0x0]||_0x1cb9f1['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x40489b,_0x1e3d4a){this['shortDelay']=_0x40489b,this['longDelay']=_0x1e3d4a,ce(_0x1e3d4a>_0x40489b,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x2e6a80,_0x21145d){ce(_0x2e6a80['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x346806}=_0x2e6a80['emulator'];return _0x21145d?''+_0x346806+(_0x21145d['startsWith']('/')?_0x21145d['slice'](0x1):_0x21145d):_0x346806;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x48fc85,_0x2375ee,_0x592df9){this['fetchImpl']=_0x48fc85,_0x2375ee&&(this['headersImpl']=_0x2375ee),_0x592df9&&(this['responseImpl']=_0x592df9);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x200fed,_0x2035da){return _0x200fed['tenantId']&&!_0x2035da['tenantId']?{..._0x2035da,'tenantId':_0x200fed['tenantId']}:_0x2035da;}async function Ae(_0x53d84a,_0x404872,_0xcead1f,_0x3501b7,_0x4f1072={}){return Ca(_0x53d84a,_0x4f1072,async()=>{let _0x4fc4bd={},_0x39eff6={};_0x3501b7&&(_0x404872==='GET'?_0x39eff6=_0x3501b7:_0x4fc4bd={'body':JSON['stringify'](_0x3501b7)});const _0x1c0797=ct({'key':_0x53d84a['config']['apiKey'],..._0x39eff6})['slice'](0x1),_0x37282a=await _0x53d84a['_getAdditionalHeaders']();_0x37282a['Content-Type']='application/json',_0x53d84a['languageCode']&&(_0x37282a['X-Firebase-Locale']=_0x53d84a['languageCode']);const _0x50517e={'method':_0x404872,'headers':_0x37282a,..._0x4fc4bd};return dc()||(_0x50517e['referrerPolicy']='no-referrer'),_0x53d84a['emulatorConfig']&&at(_0x53d84a['emulatorConfig']['host'])&&(_0x50517e['credentials']='include'),wa['fetch']()(await Ta(_0x53d84a,_0x53d84a['config']['apiHost'],_0xcead1f,_0x1c0797),_0x50517e);});}async function Ca(_0x13993b,_0x46e1b7,_0xb5b1a7){_0x13993b['_canInitEmulator']=!0x1;const _0x8a9d1c={...cf,..._0x46e1b7};try{const _0x36df43=new df(_0x13993b),_0x5c94ed=await Promise['race']([_0xb5b1a7(),_0x36df43['promise']]);_0x36df43['clearNetworkTimeout']();const _0x4298b1=await _0x5c94ed['json']();if('needConfirmation'in _0x4298b1)throw tn(_0x13993b,'account-exists-with-different-credential',_0x4298b1);if(_0x5c94ed['ok']&&!('errorMessage'in _0x4298b1))return _0x4298b1;{const _0x24b396=_0x5c94ed['ok']?_0x4298b1['errorMessage']:_0x4298b1['error']['message'],[_0x2a4011,_0x58f2ae]=_0x24b396['split']('\x20:\x20');if(_0x2a4011==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x13993b,'credential-already-in-use',_0x4298b1);if(_0x2a4011==='EMAIL_EXISTS')throw tn(_0x13993b,'email-already-in-use',_0x4298b1);if(_0x2a4011==='USER_DISABLED')throw tn(_0x13993b,'user-disabled',_0x4298b1);const _0x59692d=_0x8a9d1c[_0x2a4011]||_0x2a4011['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x58f2ae)throw Ia(_0x13993b,_0x59692d,_0x58f2ae);Q(_0x13993b,_0x59692d);}}catch(_0x14a469){if(_0x14a469 instanceof Se)throw _0x14a469;Q(_0x13993b,'network-request-failed',{'message':String(_0x14a469)});}}async function Qt(_0x1ced52,_0x1c9249,_0x471a8f,_0x986060,_0x3cad26={}){const _0x537344=await Ae(_0x1ced52,_0x1c9249,_0x471a8f,_0x986060,_0x3cad26);return'mfaPendingCredential'in _0x537344&&Q(_0x1ced52,'multi-factor-auth-required',{'_serverResponse':_0x537344}),_0x537344;}async function Ta(_0x1dddc4,_0x40db93,_0x3ff1a4,_0x2c4157){const _0x30349c=''+_0x40db93+_0x3ff1a4+'?'+_0x2c4157,_0x6b20b7=_0x1dddc4,_0x5b2da7=_0x6b20b7['config']['emulator']?Cs(_0x1dddc4['config'],_0x30349c):_0x1dddc4['config']['apiScheme']+'://'+_0x30349c;return lf['includes'](_0x3ff1a4)&&(await _0x6b20b7['_persistenceManagerAvailable'],_0x6b20b7['_getPersistenceType']()==='COOKIE')?_0x6b20b7['_getPersistence']()['_getFinalTarget'](_0x5b2da7)['toString']():_0x5b2da7;}function uf(_0x1a14d7){switch(_0x1a14d7){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x13637c){this['auth']=_0x13637c,this['timer']=null,this['promise']=new Promise((_0x465195,_0x5d7732)=>{this['timer']=setTimeout(()=>_0x5d7732(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x35ed18,_0x442d5e,_0x2f5fce){const _0x35a7a7={'appName':_0x35ed18['name']};_0x2f5fce['email']&&(_0x35a7a7['email']=_0x2f5fce['email']),_0x2f5fce['phoneNumber']&&(_0x35a7a7['phoneNumber']=_0x2f5fce['phoneNumber']);const _0x3fe173=X(_0x35ed18,_0x442d5e,_0x35a7a7);return _0x3fe173['customData']['_tokenResponse']=_0x2f5fce,_0x3fe173;}function wr(_0x42faf8){return _0x42faf8!==void 0x0&&_0x42faf8['enterprise']!==void 0x0;}class ff{constructor(_0x59e8d5){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x59e8d5['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x59e8d5['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x59e8d5['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x2858b2){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x44adc0 of this['recaptchaEnforcementState'])if(_0x44adc0['provider']&&_0x44adc0['provider']===_0x2858b2)return uf(_0x44adc0['enforcementState']);return null;}['isProviderEnabled'](_0x2059b5){return this['getProviderEnforcementState'](_0x2059b5)==='ENFORCE'||this['getProviderEnforcementState'](_0x2059b5)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x2727ce,_0x17e56a){return Ae(_0x2727ce,'GET','/v2/recaptchaConfig',Re(_0x2727ce,_0x17e56a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x19dde0,_0x3c536f){return Ae(_0x19dde0,'POST','/v1/accounts:delete',_0x3c536f);}async function bn(_0x48186a,_0x111d4c){return Ae(_0x48186a,'POST','/v1/accounts:lookup',_0x111d4c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x11d5ab){if(_0x11d5ab)try{const _0x64001f=new Date(Number(_0x11d5ab));if(!isNaN(_0x64001f['getTime']()))return _0x64001f['toUTCString']();}catch{}}async function gf(_0x387b37,_0x2873bd=!0x1){const _0x5e461d=N(_0x387b37),_0x4a935e=await _0x5e461d['getIdToken'](_0x2873bd),_0x428b47=Ts(_0x4a935e);m(_0x428b47&&_0x428b47['exp']&&_0x428b47['auth_time']&&_0x428b47['iat'],_0x5e461d['auth'],'internal-error');const _0x151686=typeof _0x428b47['firebase']=='object'?_0x428b47['firebase']:void 0x0,_0x4203c1=_0x151686==null?void 0x0:_0x151686['sign_in_provider'];return{'claims':_0x428b47,'token':_0x4a935e,'authTime':Rt(li(_0x428b47['auth_time'])),'issuedAtTime':Rt(li(_0x428b47['iat'])),'expirationTime':Rt(li(_0x428b47['exp'])),'signInProvider':_0x4203c1||null,'signInSecondFactor':(_0x151686==null?void 0x0:_0x151686['sign_in_second_factor'])||null};}function li(_0x352359){return Number(_0x352359)*0x3e8;}function Ts(_0x313534){const [_0x1996ce,_0x1cf0a8,_0xbb45e]=_0x313534['split']('.');if(_0x1996ce===void 0x0||_0x1cf0a8===void 0x0||_0xbb45e===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x26732e=ln(_0x1cf0a8);return _0x26732e?JSON['parse'](_0x26732e):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x122709){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x122709==null?void 0x0:_0x122709['toString']()),null;}}function Cr(_0x4a021c){const _0xe70969=Ts(_0x4a021c);return m(_0xe70969,'internal-error'),m(typeof _0xe70969['exp']<'u','internal-error'),m(typeof _0xe70969['iat']<'u','internal-error'),Number(_0xe70969['exp'])-Number(_0xe70969['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x30c658,_0x5998eb,_0x2e5cc1=!0x1){if(_0x2e5cc1)return _0x5998eb;try{return await _0x5998eb;}catch(_0x3c228e){throw _0x3c228e instanceof Se&&mf(_0x3c228e)&&_0x30c658['auth']['currentUser']===_0x30c658&&await _0x30c658['auth']['signOut'](),_0x3c228e;}}function mf({code:_0x73de1e}){return _0x73de1e==='auth/user-disabled'||_0x73de1e==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x2f3dee){this['user']=_0x2f3dee,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x479ee7){if(_0x479ee7){const _0x11eef1=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x11eef1;}else{this['errorBackoff']=0x7530;const _0x560c6f=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x560c6f);}}['schedule'](_0x1367c4=!0x1){if(!this['isRunning'])return;const _0x55b5e6=this['getInterval'](_0x1367c4);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x55b5e6);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0xf83d00){(_0xf83d00==null?void 0x0:_0xf83d00['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0xbdf92c,_0x3c0bb){this['createdAt']=_0xbdf92c,this['lastLoginAt']=_0x3c0bb,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x27c972){this['createdAt']=_0x27c972['createdAt'],this['lastLoginAt']=_0x27c972['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x13c559){var _0xb880b7;const _0x257daa=_0x13c559['auth'],_0x393e44=await _0x13c559['getIdToken'](),_0x36f7d9=await Ut(_0x13c559,bn(_0x257daa,{'idToken':_0x393e44}));m(_0x36f7d9==null?void 0x0:_0x36f7d9['users']['length'],_0x257daa,'internal-error');const _0x34c3ac=_0x36f7d9['users'][0x0];_0x13c559['_notifyReloadListener'](_0x34c3ac);const _0x56966e=(_0xb880b7=_0x34c3ac['providerUserInfo'])!=null&&_0xb880b7['length']?Sa(_0x34c3ac['providerUserInfo']):[],_0x46905e=Ef(_0x13c559['providerData'],_0x56966e),_0x5122e2=_0x13c559['isAnonymous'],_0xed91b8=!(_0x13c559['email']&&_0x34c3ac['passwordHash'])&&!(_0x46905e!=null&&_0x46905e['length']),_0x54f4c2=_0x5122e2?_0xed91b8:!0x1,_0x345ec8={'uid':_0x34c3ac['localId'],'displayName':_0x34c3ac['displayName']||null,'photoURL':_0x34c3ac['photoUrl']||null,'email':_0x34c3ac['email']||null,'emailVerified':_0x34c3ac['emailVerified']||!0x1,'phoneNumber':_0x34c3ac['phoneNumber']||null,'tenantId':_0x34c3ac['tenantId']||null,'providerData':_0x46905e,'metadata':new Oi(_0x34c3ac['createdAt'],_0x34c3ac['lastLoginAt']),'isAnonymous':_0x54f4c2};Object['assign'](_0x13c559,_0x345ec8);}async function vf(_0x26ad26){const _0x3657e2=N(_0x26ad26);await Rn(_0x3657e2),await _0x3657e2['auth']['_persistUserIfCurrent'](_0x3657e2),_0x3657e2['auth']['_notifyListenersIfCurrent'](_0x3657e2);}function Ef(_0x35b65c,_0x12847b){return[..._0x35b65c['filter'](_0x510d14=>!_0x12847b['some'](_0x10a145=>_0x10a145['providerId']===_0x510d14['providerId'])),..._0x12847b];}function Sa(_0x5df505){return _0x5df505['map'](({providerId:_0x354eec,..._0x836296})=>({'providerId':_0x354eec,'uid':_0x836296['rawId']||'','displayName':_0x836296['displayName']||null,'email':_0x836296['email']||null,'phoneNumber':_0x836296['phoneNumber']||null,'photoURL':_0x836296['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0xeac2e1,_0x5e35ff){const _0x45326=await Ca(_0xeac2e1,{},async()=>{const _0x55b49b=ct({'grant_type':'refresh_token','refresh_token':_0x5e35ff})['slice'](0x1),{tokenApiHost:_0x106f7d,apiKey:_0x246fdf}=_0xeac2e1['config'],_0x1a0a9e=await Ta(_0xeac2e1,_0x106f7d,'/v1/token','key='+_0x246fdf),_0x1ffec5=await _0xeac2e1['_getAdditionalHeaders']();_0x1ffec5['Content-Type']='application/x-www-form-urlencoded';const _0x10feba={'method':'POST','headers':_0x1ffec5,'body':_0x55b49b};return _0xeac2e1['emulatorConfig']&&at(_0xeac2e1['emulatorConfig']['host'])&&(_0x10feba['credentials']='include'),wa['fetch']()(_0x1a0a9e,_0x10feba);});return{'accessToken':_0x45326['access_token'],'expiresIn':_0x45326['expires_in'],'refreshToken':_0x45326['refresh_token']};}async function wf(_0x37e38c,_0xedd07){return Ae(_0x37e38c,'POST','/v2/accounts:revokeToken',Re(_0x37e38c,_0xedd07));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x4a10d7){m(_0x4a10d7['idToken'],'internal-error'),m(typeof _0x4a10d7['idToken']<'u','internal-error'),m(typeof _0x4a10d7['refreshToken']<'u','internal-error');const _0x1b70de='expiresIn'in _0x4a10d7&&typeof _0x4a10d7['expiresIn']<'u'?Number(_0x4a10d7['expiresIn']):Cr(_0x4a10d7['idToken']);this['updateTokensAndExpiration'](_0x4a10d7['idToken'],_0x4a10d7['refreshToken'],_0x1b70de);}['updateFromIdToken'](_0x1ba83f){m(_0x1ba83f['length']!==0x0,'internal-error');const _0x449b72=Cr(_0x1ba83f);this['updateTokensAndExpiration'](_0x1ba83f,null,_0x449b72);}async['getToken'](_0x3c6c7,_0x46c8b3=!0x1){return!_0x46c8b3&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x3c6c7,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x3c6c7,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x3b64e5,_0x205ddf){const {accessToken:_0x4c39c5,refreshToken:_0x475efb,expiresIn:_0x47d117}=await If(_0x3b64e5,_0x205ddf);this['updateTokensAndExpiration'](_0x4c39c5,_0x475efb,Number(_0x47d117));}['updateTokensAndExpiration'](_0x1ae19f,_0x6c3a2e,_0x161500){this['refreshToken']=_0x6c3a2e||null,this['accessToken']=_0x1ae19f||null,this['expirationTime']=Date['now']()+_0x161500*0x3e8;}static['fromJSON'](_0x2f8035,_0x17eaad){const {refreshToken:_0x260e65,accessToken:_0x42354c,expirationTime:_0xe8360b}=_0x17eaad,_0x414b2f=new Qe();return _0x260e65&&(m(typeof _0x260e65=='string','internal-error',{'appName':_0x2f8035}),_0x414b2f['refreshToken']=_0x260e65),_0x42354c&&(m(typeof _0x42354c=='string','internal-error',{'appName':_0x2f8035}),_0x414b2f['accessToken']=_0x42354c),_0xe8360b&&(m(typeof _0xe8360b=='number','internal-error',{'appName':_0x2f8035}),_0x414b2f['expirationTime']=_0xe8360b),_0x414b2f;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4eacca){this['accessToken']=_0x4eacca['accessToken'],this['refreshToken']=_0x4eacca['refreshToken'],this['expirationTime']=_0x4eacca['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x5491ae,_0x202a08){m(typeof _0x5491ae=='string'||typeof _0x5491ae>'u','internal-error',{'appName':_0x202a08});}class K{constructor({uid:_0xe85ccf,auth:_0x2a4dec,stsTokenManager:_0x26b01c,..._0x28c8b9}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0xe85ccf,this['auth']=_0x2a4dec,this['stsTokenManager']=_0x26b01c,this['accessToken']=_0x26b01c['accessToken'],this['displayName']=_0x28c8b9['displayName']||null,this['email']=_0x28c8b9['email']||null,this['emailVerified']=_0x28c8b9['emailVerified']||!0x1,this['phoneNumber']=_0x28c8b9['phoneNumber']||null,this['photoURL']=_0x28c8b9['photoURL']||null,this['isAnonymous']=_0x28c8b9['isAnonymous']||!0x1,this['tenantId']=_0x28c8b9['tenantId']||null,this['providerData']=_0x28c8b9['providerData']?[..._0x28c8b9['providerData']]:[],this['metadata']=new Oi(_0x28c8b9['createdAt']||void 0x0,_0x28c8b9['lastLoginAt']||void 0x0);}async['getIdToken'](_0x386b11){const _0x23631d=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x386b11));return m(_0x23631d,this['auth'],'internal-error'),this['accessToken']!==_0x23631d&&(this['accessToken']=_0x23631d,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x23631d;}['getIdTokenResult'](_0x1fc9c7){return gf(this,_0x1fc9c7);}['reload'](){return vf(this);}['_assign'](_0x4dbcbf){this!==_0x4dbcbf&&(m(this['uid']===_0x4dbcbf['uid'],this['auth'],'internal-error'),this['displayName']=_0x4dbcbf['displayName'],this['photoURL']=_0x4dbcbf['photoURL'],this['email']=_0x4dbcbf['email'],this['emailVerified']=_0x4dbcbf['emailVerified'],this['phoneNumber']=_0x4dbcbf['phoneNumber'],this['isAnonymous']=_0x4dbcbf['isAnonymous'],this['tenantId']=_0x4dbcbf['tenantId'],this['providerData']=_0x4dbcbf['providerData']['map'](_0x4761d0=>({..._0x4761d0})),this['metadata']['_copy'](_0x4dbcbf['metadata']),this['stsTokenManager']['_assign'](_0x4dbcbf['stsTokenManager']));}['_clone'](_0x16d3b4){const _0x51abaf=new K({...this,'auth':_0x16d3b4,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x51abaf['metadata']['_copy'](this['metadata']),_0x51abaf;}['_onReload'](_0x4f7aea){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x4f7aea,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x57dac6){this['reloadListener']?this['reloadListener'](_0x57dac6):this['reloadUserInfo']=_0x57dac6;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0xe4595d,_0x26f6e1=!0x1){let _0x52d21d=!0x1;_0xe4595d['idToken']&&_0xe4595d['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0xe4595d),_0x52d21d=!0x0),_0x26f6e1&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x52d21d&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x5cea46=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x5cea46})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x2f4a97=>({..._0x2f4a97})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x53ea15,_0x58a425){const _0x3f6b35=_0x58a425['displayName']??void 0x0,_0x3d5f5f=_0x58a425['email']??void 0x0,_0x4524bb=_0x58a425['phoneNumber']??void 0x0,_0x46da69=_0x58a425['photoURL']??void 0x0,_0x5f3e07=_0x58a425['tenantId']??void 0x0,_0x40a6fb=_0x58a425['_redirectEventId']??void 0x0,_0x274370=_0x58a425['createdAt']??void 0x0,_0x3078f9=_0x58a425['lastLoginAt']??void 0x0,{uid:_0x44eb4c,emailVerified:_0x48094d,isAnonymous:_0x3b8577,providerData:_0x4845ea,stsTokenManager:_0x26c3d2}=_0x58a425;m(_0x44eb4c&&_0x26c3d2,_0x53ea15,'internal-error');const _0x2b9a9c=Qe['fromJSON'](this['name'],_0x26c3d2);m(typeof _0x44eb4c=='string',_0x53ea15,'internal-error'),le(_0x3f6b35,_0x53ea15['name']),le(_0x3d5f5f,_0x53ea15['name']),m(typeof _0x48094d=='boolean',_0x53ea15,'internal-error'),m(typeof _0x3b8577=='boolean',_0x53ea15,'internal-error'),le(_0x4524bb,_0x53ea15['name']),le(_0x46da69,_0x53ea15['name']),le(_0x5f3e07,_0x53ea15['name']),le(_0x40a6fb,_0x53ea15['name']),le(_0x274370,_0x53ea15['name']),le(_0x3078f9,_0x53ea15['name']);const _0x5f50d6=new K({'uid':_0x44eb4c,'auth':_0x53ea15,'email':_0x3d5f5f,'emailVerified':_0x48094d,'displayName':_0x3f6b35,'isAnonymous':_0x3b8577,'photoURL':_0x46da69,'phoneNumber':_0x4524bb,'tenantId':_0x5f3e07,'stsTokenManager':_0x2b9a9c,'createdAt':_0x274370,'lastLoginAt':_0x3078f9});return _0x4845ea&&Array['isArray'](_0x4845ea)&&(_0x5f50d6['providerData']=_0x4845ea['map'](_0x2990a9=>({..._0x2990a9}))),_0x40a6fb&&(_0x5f50d6['_redirectEventId']=_0x40a6fb),_0x5f50d6;}static async['_fromIdTokenResponse'](_0x6ad3ea,_0x428aa6,_0x305c51=!0x1){const _0x47ec09=new Qe();_0x47ec09['updateFromServerResponse'](_0x428aa6);const _0x4e2c9c=new K({'uid':_0x428aa6['localId'],'auth':_0x6ad3ea,'stsTokenManager':_0x47ec09,'isAnonymous':_0x305c51});return await Rn(_0x4e2c9c),_0x4e2c9c;}static async['_fromGetAccountInfoResponse'](_0x4b1e72,_0x55797d,_0x68fb39){const _0x32a149=_0x55797d['users'][0x0];m(_0x32a149['localId']!==void 0x0,'internal-error');const _0x461c02=_0x32a149['providerUserInfo']!==void 0x0?Sa(_0x32a149['providerUserInfo']):[],_0x383775=!(_0x32a149['email']&&_0x32a149['passwordHash'])&&!(_0x461c02!=null&&_0x461c02['length']),_0x18ad96=new Qe();_0x18ad96['updateFromIdToken'](_0x68fb39);const _0x4eb311=new K({'uid':_0x32a149['localId'],'auth':_0x4b1e72,'stsTokenManager':_0x18ad96,'isAnonymous':_0x383775}),_0x19e94c={'uid':_0x32a149['localId'],'displayName':_0x32a149['displayName']||null,'photoURL':_0x32a149['photoUrl']||null,'email':_0x32a149['email']||null,'emailVerified':_0x32a149['emailVerified']||!0x1,'phoneNumber':_0x32a149['phoneNumber']||null,'tenantId':_0x32a149['tenantId']||null,'providerData':_0x461c02,'metadata':new Oi(_0x32a149['createdAt'],_0x32a149['lastLoginAt']),'isAnonymous':!(_0x32a149['email']&&_0x32a149['passwordHash'])&&!(_0x461c02!=null&&_0x461c02['length'])};return Object['assign'](_0x4eb311,_0x19e94c),_0x4eb311;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x3ab591){ce(_0x3ab591 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x26f22c=Tr['get'](_0x3ab591);return _0x26f22c?(ce(_0x26f22c instanceof _0x3ab591,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x26f22c):(_0x26f22c=new _0x3ab591(),Tr['set'](_0x3ab591,_0x26f22c),_0x26f22c);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0xcbdccc,_0x3fe06b){this['storage'][_0xcbdccc]=_0x3fe06b;}async['_get'](_0x1a999b){const _0x355b21=this['storage'][_0x1a999b];return _0x355b21===void 0x0?null:_0x355b21;}async['_remove'](_0xe720f3){delete this['storage'][_0xe720f3];}['_addListener'](_0x59dcff,_0x2ab21b){}['_removeListener'](_0x2c963e,_0x5a2d02){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x579681,_0x3acc0c,_0x97be88){return'firebase:'+_0x579681+':'+_0x3acc0c+':'+_0x97be88;}class Je{constructor(_0x366651,_0x382e37,_0x4b5be0){this['persistence']=_0x366651,this['auth']=_0x382e37,this['userKey']=_0x4b5be0;const {config:_0x562374,name:_0x4ef141}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x562374['apiKey'],_0x4ef141),this['fullPersistenceKey']=rn('persistence',_0x562374['apiKey'],_0x4ef141),this['boundEventHandler']=_0x382e37['_onStorageEvent']['bind'](_0x382e37),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x514c10){return this['persistence']['_set'](this['fullUserKey'],_0x514c10['toJSON']());}async['getCurrentUser'](){const _0x12661a=await this['persistence']['_get'](this['fullUserKey']);if(!_0x12661a)return null;if(typeof _0x12661a=='string'){const _0x2716d6=await bn(this['auth'],{'idToken':_0x12661a})['catch'](()=>{});return _0x2716d6?K['_fromGetAccountInfoResponse'](this['auth'],_0x2716d6,_0x12661a):null;}return K['_fromJSON'](this['auth'],_0x12661a);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x648ad3){if(this['persistence']===_0x648ad3)return;const _0x53d9d2=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x648ad3,_0x53d9d2)return this['setCurrentUser'](_0x53d9d2);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x4c29c6,_0x3048e9,_0x559642='authUser'){if(!_0x3048e9['length'])return new Je(ie(Sr),_0x4c29c6,_0x559642);const _0x5127bf=(await Promise['all'](_0x3048e9['map'](async _0x53360b=>{if(await _0x53360b['_isAvailable']())return _0x53360b;})))['filter'](_0x1267a2=>_0x1267a2);let _0x4bd818=_0x5127bf[0x0]||ie(Sr);const _0x51c99e=rn(_0x559642,_0x4c29c6['config']['apiKey'],_0x4c29c6['name']);let _0x1a2f64=null;for(const _0x3485d6 of _0x3048e9)try{const _0x3832c0=await _0x3485d6['_get'](_0x51c99e);if(_0x3832c0){let _0xe28cd9;if(typeof _0x3832c0=='string'){const _0x146f4f=await bn(_0x4c29c6,{'idToken':_0x3832c0})['catch'](()=>{});if(!_0x146f4f)break;_0xe28cd9=await K['_fromGetAccountInfoResponse'](_0x4c29c6,_0x146f4f,_0x3832c0);}else _0xe28cd9=K['_fromJSON'](_0x4c29c6,_0x3832c0);_0x3485d6!==_0x4bd818&&(_0x1a2f64=_0xe28cd9),_0x4bd818=_0x3485d6;break;}}catch{}const _0x38b23f=_0x5127bf['filter'](_0x1c058b=>_0x1c058b['_shouldAllowMigration']);return!_0x4bd818['_shouldAllowMigration']||!_0x38b23f['length']?new Je(_0x4bd818,_0x4c29c6,_0x559642):(_0x4bd818=_0x38b23f[0x0],_0x1a2f64&&await _0x4bd818['_set'](_0x51c99e,_0x1a2f64['toJSON']()),await Promise['all'](_0x3048e9['map'](async _0x5dfc06=>{if(_0x5dfc06!==_0x4bd818)try{await _0x5dfc06['_remove'](_0x51c99e);}catch{}})),new Je(_0x4bd818,_0x4c29c6,_0x559642));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x3a96b6){const _0x3ff9a0=_0x3a96b6['toLowerCase']();if(_0x3ff9a0['includes']('opera/')||_0x3ff9a0['includes']('opr/')||_0x3ff9a0['includes']('opios/'))return'Opera';if(Na(_0x3ff9a0))return'IEMobile';if(_0x3ff9a0['includes']('msie')||_0x3ff9a0['includes']('trident/'))return'IE';if(_0x3ff9a0['includes']('edge/'))return'Edge';if(Ra(_0x3ff9a0))return'Firefox';if(_0x3ff9a0['includes']('silk/'))return'Silk';if(Oa(_0x3ff9a0))return'Blackberry';if(Da(_0x3ff9a0))return'Webos';if(Aa(_0x3ff9a0))return'Safari';if((_0x3ff9a0['includes']('chrome/')||ka(_0x3ff9a0))&&!_0x3ff9a0['includes']('edge/'))return'Chrome';if(Pa(_0x3ff9a0))return'Android';{const _0x2aa06f=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x22642f=_0x3a96b6['match'](_0x2aa06f);if((_0x22642f==null?void 0x0:_0x22642f['length'])===0x2)return _0x22642f[0x1];}return'Other';}function Ra(_0x3ad7a2=W()){return/firefox\//i['test'](_0x3ad7a2);}function Aa(_0x4394f8=W()){const _0x4e3b06=_0x4394f8['toLowerCase']();return _0x4e3b06['includes']('safari/')&&!_0x4e3b06['includes']('chrome/')&&!_0x4e3b06['includes']('crios/')&&!_0x4e3b06['includes']('android');}function ka(_0x1a0834=W()){return/crios\//i['test'](_0x1a0834);}function Na(_0x4658d1=W()){return/iemobile/i['test'](_0x4658d1);}function Pa(_0x472482=W()){return/android/i['test'](_0x472482);}function Oa(_0x1c7dc9=W()){return/blackberry/i['test'](_0x1c7dc9);}function Da(_0x35b2c3=W()){return/webos/i['test'](_0x35b2c3);}function Ss(_0x3faf75=W()){return/iphone|ipad|ipod/i['test'](_0x3faf75)||/macintosh/i['test'](_0x3faf75)&&/mobile/i['test'](_0x3faf75);}function Cf(_0x117743=W()){var _0x121ae8;return Ss(_0x117743)&&!!((_0x121ae8=window['navigator'])!=null&&_0x121ae8['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x3e518f=W()){return Ss(_0x3e518f)||Pa(_0x3e518f)||Da(_0x3e518f)||Oa(_0x3e518f)||/windows phone/i['test'](_0x3e518f)||Na(_0x3e518f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x5ae503,_0x3eb68e=[]){let _0x4eab1a;switch(_0x5ae503){case'Browser':_0x4eab1a=br(W());break;case'Worker':_0x4eab1a=br(W())+'-'+_0x5ae503;break;default:_0x4eab1a=_0x5ae503;}const _0x196e85=_0x3eb68e['length']?_0x3eb68e['join'](','):'FirebaseCore-web';return _0x4eab1a+'/JsCore/'+lt+'/'+_0x196e85;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x3d77c4){this['auth']=_0x3d77c4,this['queue']=[];}['pushCallback'](_0x4970a0,_0x51cf2c){const _0x70fd41=_0x15a0b3=>new Promise((_0x2a34a7,_0x28ea4a)=>{try{const _0x278aa6=_0x4970a0(_0x15a0b3);_0x2a34a7(_0x278aa6);}catch(_0x52995e){_0x28ea4a(_0x52995e);}});_0x70fd41['onAbort']=_0x51cf2c,this['queue']['push'](_0x70fd41);const _0x3a6504=this['queue']['length']-0x1;return()=>{this['queue'][_0x3a6504]=()=>Promise['resolve']();};}async['runMiddleware'](_0x4bb8e3){if(this['auth']['currentUser']===_0x4bb8e3)return;const _0xba628=[];try{for(const _0x36d6ee of this['queue'])await _0x36d6ee(_0x4bb8e3),_0x36d6ee['onAbort']&&_0xba628['push'](_0x36d6ee['onAbort']);}catch(_0x4c8450){_0xba628['reverse']();for(const _0x189023 of _0xba628)try{_0x189023();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x4c8450==null?void 0x0:_0x4c8450['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x443419,_0x3d1ef8={}){return Ae(_0x443419,'GET','/v2/passwordPolicy',Re(_0x443419,_0x3d1ef8));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x4e14a8){var _0x1abe3a;const _0x333e23=_0x4e14a8['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x333e23['minPasswordLength']??Rf,_0x333e23['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x333e23['maxPasswordLength']),_0x333e23['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x333e23['containsLowercaseCharacter']),_0x333e23['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x333e23['containsUppercaseCharacter']),_0x333e23['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x333e23['containsNumericCharacter']),_0x333e23['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x333e23['containsNonAlphanumericCharacter']),this['enforcementState']=_0x4e14a8['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x1abe3a=_0x4e14a8['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x1abe3a['join'](''))??'',this['forceUpgradeOnSignin']=_0x4e14a8['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x4e14a8['schemaVersion'];}['validatePassword'](_0x165bb5){const _0x1d1e3f={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x165bb5,_0x1d1e3f),this['validatePasswordCharacterOptions'](_0x165bb5,_0x1d1e3f),_0x1d1e3f['isValid']&&(_0x1d1e3f['isValid']=_0x1d1e3f['meetsMinPasswordLength']??!0x0),_0x1d1e3f['isValid']&&(_0x1d1e3f['isValid']=_0x1d1e3f['meetsMaxPasswordLength']??!0x0),_0x1d1e3f['isValid']&&(_0x1d1e3f['isValid']=_0x1d1e3f['containsLowercaseLetter']??!0x0),_0x1d1e3f['isValid']&&(_0x1d1e3f['isValid']=_0x1d1e3f['containsUppercaseLetter']??!0x0),_0x1d1e3f['isValid']&&(_0x1d1e3f['isValid']=_0x1d1e3f['containsNumericCharacter']??!0x0),_0x1d1e3f['isValid']&&(_0x1d1e3f['isValid']=_0x1d1e3f['containsNonAlphanumericCharacter']??!0x0),_0x1d1e3f;}['validatePasswordLengthOptions'](_0xca8adb,_0x4b35df){const _0x4574c1=this['customStrengthOptions']['minPasswordLength'],_0x3f93a8=this['customStrengthOptions']['maxPasswordLength'];_0x4574c1&&(_0x4b35df['meetsMinPasswordLength']=_0xca8adb['length']>=_0x4574c1),_0x3f93a8&&(_0x4b35df['meetsMaxPasswordLength']=_0xca8adb['length']<=_0x3f93a8);}['validatePasswordCharacterOptions'](_0x2e0050,_0xa9f00d){this['updatePasswordCharacterOptionsStatuses'](_0xa9f00d,!0x1,!0x1,!0x1,!0x1);let _0x35f902;for(let _0x25fece=0x0;_0x25fece<_0x2e0050['length'];_0x25fece++)_0x35f902=_0x2e0050['charAt'](_0x25fece),this['updatePasswordCharacterOptionsStatuses'](_0xa9f00d,_0x35f902>='a'&&_0x35f902<='z',_0x35f902>='A'&&_0x35f902<='Z',_0x35f902>='0'&&_0x35f902<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x35f902));}['updatePasswordCharacterOptionsStatuses'](_0x4f20e8,_0x2953a7,_0x24cdab,_0x2af66e,_0x436e9a){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x4f20e8['containsLowercaseLetter']||(_0x4f20e8['containsLowercaseLetter']=_0x2953a7)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x4f20e8['containsUppercaseLetter']||(_0x4f20e8['containsUppercaseLetter']=_0x24cdab)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x4f20e8['containsNumericCharacter']||(_0x4f20e8['containsNumericCharacter']=_0x2af66e)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x4f20e8['containsNonAlphanumericCharacter']||(_0x4f20e8['containsNonAlphanumericCharacter']=_0x436e9a));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x49b2dd,_0x30aba8,_0x49529b,_0x3db018){this['app']=_0x49b2dd,this['heartbeatServiceProvider']=_0x30aba8,this['appCheckServiceProvider']=_0x49529b,this['config']=_0x3db018,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x49b2dd['name'],this['clientVersion']=_0x3db018['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x4e0131=>this['_resolvePersistenceManagerAvailable']=_0x4e0131);}['_initializeWithPersistence'](_0x4ff43c,_0x3db43a){return _0x3db43a&&(this['_popupRedirectResolver']=ie(_0x3db43a)),this['_initializationPromise']=this['queue'](async()=>{var _0x2be50d,_0x368208,_0x5eca75;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x4ff43c),(_0x2be50d=this['_resolvePersistenceManagerAvailable'])==null||_0x2be50d['call'](this),!this['_deleted'])){if((_0x368208=this['_popupRedirectResolver'])!=null&&_0x368208['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x3db43a),this['lastNotifiedUid']=((_0x5eca75=this['currentUser'])==null?void 0x0:_0x5eca75['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x10aefa=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x10aefa)){if(this['currentUser']&&_0x10aefa&&this['currentUser']['uid']===_0x10aefa['uid']){this['_currentUser']['_assign'](_0x10aefa),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x10aefa,!0x0);}}async['initializeCurrentUserFromIdToken'](_0xfc0ade){try{const _0x522e7a=await bn(this,{'idToken':_0xfc0ade}),_0x43bdde=await K['_fromGetAccountInfoResponse'](this,_0x522e7a,_0xfc0ade);await this['directlySetCurrentUser'](_0x43bdde);}catch(_0x292592){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x292592),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x4c7883){var _0x2dd9ae;if($(this['app'])){const _0x57c7bb=this['app']['settings']['authIdToken'];return _0x57c7bb?new Promise(_0x2cf1d0=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x57c7bb)['then'](_0x2cf1d0,_0x2cf1d0));}):this['directlySetCurrentUser'](null);}const _0x5dcc03=await this['assertedPersistence']['getCurrentUser']();let _0xeef751=_0x5dcc03,_0x5e0b95=!0x1;if(_0x4c7883&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x91b58b=(_0x2dd9ae=this['redirectUser'])==null?void 0x0:_0x2dd9ae['_redirectEventId'],_0x2750f1=_0xeef751==null?void 0x0:_0xeef751['_redirectEventId'],_0x380335=await this['tryRedirectSignIn'](_0x4c7883);(!_0x91b58b||_0x91b58b===_0x2750f1)&&(_0x380335!=null&&_0x380335['user'])&&(_0xeef751=_0x380335['user'],_0x5e0b95=!0x0);}if(!_0xeef751)return this['directlySetCurrentUser'](null);if(!_0xeef751['_redirectEventId']){if(_0x5e0b95)try{await this['beforeStateQueue']['runMiddleware'](_0xeef751);}catch(_0x2bac57){_0xeef751=_0x5dcc03,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x2bac57));}return _0xeef751?this['reloadAndSetCurrentUserOrClear'](_0xeef751):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0xeef751['_redirectEventId']?this['directlySetCurrentUser'](_0xeef751):this['reloadAndSetCurrentUserOrClear'](_0xeef751);}async['tryRedirectSignIn'](_0x563b24){let _0x36213b=null;try{_0x36213b=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x563b24,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x36213b;}async['reloadAndSetCurrentUserOrClear'](_0x45da29){try{await Rn(_0x45da29);}catch(_0x46e0f7){if((_0x46e0f7==null?void 0x0:_0x46e0f7['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x45da29);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x51164c){if($(this['app']))return Promise['reject'](re(this));const _0x3c6dbf=_0x51164c?N(_0x51164c):null;return _0x3c6dbf&&m(_0x3c6dbf['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x3c6dbf&&_0x3c6dbf['_clone'](this));}async['_updateCurrentUser'](_0x26854e,_0x1f0f26=!0x1){if(!this['_deleted'])return _0x26854e&&m(this['tenantId']===_0x26854e['tenantId'],this,'tenant-id-mismatch'),_0x1f0f26||await this['beforeStateQueue']['runMiddleware'](_0x26854e),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x26854e),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x279539){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x279539));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0xd876a2){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x41abb5=this['_getPasswordPolicyInternal']();return _0x41abb5['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x41abb5['validatePassword'](_0xd876a2);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x3e7b82=await bf(this),_0x4da1b7=new Af(_0x3e7b82);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4da1b7:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4da1b7;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x50005e){this['_errorFactory']=new Bt('auth','Firebase',_0x50005e());}['onAuthStateChanged'](_0x5c9b52,_0x35234c,_0x5f12f2){return this['registerStateListener'](this['authStateSubscription'],_0x5c9b52,_0x35234c,_0x5f12f2);}['beforeAuthStateChanged'](_0x5db9fb,_0x4a4e01){return this['beforeStateQueue']['pushCallback'](_0x5db9fb,_0x4a4e01);}['onIdTokenChanged'](_0x1db8fd,_0x4f7637,_0x22817a){return this['registerStateListener'](this['idTokenSubscription'],_0x1db8fd,_0x4f7637,_0x22817a);}['authStateReady'](){return new Promise((_0x2972d6,_0xf01bdb)=>{if(this['currentUser'])_0x2972d6();else{const _0x2797a4=this['onAuthStateChanged'](()=>{_0x2797a4(),_0x2972d6();},_0xf01bdb);}});}async['revokeAccessToken'](_0x4badf1){if(this['currentUser']){const _0x29cee8=await this['currentUser']['getIdToken'](),_0x433761={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x4badf1,'idToken':_0x29cee8};this['tenantId']!=null&&(_0x433761['tenantId']=this['tenantId']),await wf(this,_0x433761);}}['toJSON'](){var _0xddc1f0;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0xddc1f0=this['_currentUser'])==null?void 0x0:_0xddc1f0['toJSON']()};}async['_setRedirectUser'](_0x2c4f8f,_0x5390ea){const _0x1d597e=await this['getOrInitRedirectPersistenceManager'](_0x5390ea);return _0x2c4f8f===null?_0x1d597e['removeCurrentUser']():_0x1d597e['setCurrentUser'](_0x2c4f8f);}async['getOrInitRedirectPersistenceManager'](_0x2baf7d){if(!this['redirectPersistenceManager']){const _0x2584f6=_0x2baf7d&&ie(_0x2baf7d)||this['_popupRedirectResolver'];m(_0x2584f6,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x2584f6['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x3290de){var _0x40e785,_0x55051b;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x40e785=this['_currentUser'])==null?void 0x0:_0x40e785['_redirectEventId'])===_0x3290de?this['_currentUser']:((_0x55051b=this['redirectUser'])==null?void 0x0:_0x55051b['_redirectEventId'])===_0x3290de?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x56f398){if(_0x56f398===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x56f398));}['_notifyListenersIfCurrent'](_0x15e343){_0x15e343===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x22f1f3;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x2fd1d6=((_0x22f1f3=this['currentUser'])==null?void 0x0:_0x22f1f3['uid'])??null;this['lastNotifiedUid']!==_0x2fd1d6&&(this['lastNotifiedUid']=_0x2fd1d6,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x33002a,_0x2b86b9,_0x4ef489,_0x45f911){if(this['_deleted'])return()=>{};const _0x547361=typeof _0x2b86b9=='function'?_0x2b86b9:_0x2b86b9['next']['bind'](_0x2b86b9);let _0x4260a6=!0x1;const _0x430d07=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x430d07,this,'internal-error'),_0x430d07['then'](()=>{_0x4260a6||_0x547361(this['currentUser']);}),typeof _0x2b86b9=='function'){const _0xc212ff=_0x33002a['addObserver'](_0x2b86b9,_0x4ef489,_0x45f911);return()=>{_0x4260a6=!0x0,_0xc212ff();};}else{const _0x4fd9df=_0x33002a['addObserver'](_0x2b86b9);return()=>{_0x4260a6=!0x0,_0x4fd9df();};}}async['directlySetCurrentUser'](_0x50c833){this['currentUser']&&this['currentUser']!==_0x50c833&&this['_currentUser']['_stopProactiveRefresh'](),_0x50c833&&this['isProactiveRefreshEnabled']&&_0x50c833['_startProactiveRefresh'](),this['currentUser']=_0x50c833,_0x50c833?await this['assertedPersistence']['setCurrentUser'](_0x50c833):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x16668c){return this['operations']=this['operations']['then'](_0x16668c,_0x16668c),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x1dd75f){!_0x1dd75f||this['frameworks']['includes'](_0x1dd75f)||(this['frameworks']['push'](_0x1dd75f),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x471250;const _0x5a9b78={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x5a9b78['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x18c6a5=await((_0x471250=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x471250['getHeartbeatsHeader']());_0x18c6a5&&(_0x5a9b78['X-Firebase-Client']=_0x18c6a5);const _0x3b392f=await this['_getAppCheckToken']();return _0x3b392f&&(_0x5a9b78['X-Firebase-AppCheck']=_0x3b392f),_0x5a9b78;}async['_getAppCheckToken'](){var _0x2bf61a;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x42d2e9=await((_0x2bf61a=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x2bf61a['getToken']());return _0x42d2e9!=null&&_0x42d2e9['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x42d2e9['error']),_0x42d2e9==null?void 0x0:_0x42d2e9['token'];}}function qe(_0x371543){return N(_0x371543);}class Rr{constructor(_0x4603f7){this['auth']=_0x4603f7,this['observer']=null,this['addObserver']=Tc(_0x3cde00=>this['observer']=_0x3cde00);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0xef914e){jn=_0xef914e;}function xa(_0x100fa5){return jn['loadJS'](_0x100fa5);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x55a51d){return'__'+_0x55a51d+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x2f8484){_0x2f8484();}['execute'](_0x1710d1,_0x55e7f0){return Promise['resolve']('token');}['render'](_0x30ba11,_0x5bbaa0){return'';}}class Lf{['ready'](_0x22f0bf){_0x22f0bf();}['execute'](_0x1f09c6,_0x2aa601){return Promise['resolve']('token');}['render'](_0x58c782,_0x518dfb){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0xb6b377){this['type']=xf,this['auth']=qe(_0xb6b377);}async['verify'](_0x1f3c26='verify',_0x214a1f=!0x1){async function _0xc5251f(_0x2ae804){if(!_0x214a1f){if(_0x2ae804['tenantId']==null&&_0x2ae804['_agentRecaptchaConfig']!=null)return _0x2ae804['_agentRecaptchaConfig']['siteKey'];if(_0x2ae804['tenantId']!=null&&_0x2ae804['_tenantRecaptchaConfigs'][_0x2ae804['tenantId']]!==void 0x0)return _0x2ae804['_tenantRecaptchaConfigs'][_0x2ae804['tenantId']]['siteKey'];}return new Promise(async(_0x47a808,_0x48fd8e)=>{pf(_0x2ae804,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x472ab4=>{if(_0x472ab4['recaptchaKey']===void 0x0)_0x48fd8e(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x25d544=new ff(_0x472ab4);return _0x2ae804['tenantId']==null?_0x2ae804['_agentRecaptchaConfig']=_0x25d544:_0x2ae804['_tenantRecaptchaConfigs'][_0x2ae804['tenantId']]=_0x25d544,_0x47a808(_0x25d544['siteKey']);}})['catch'](_0x509b31=>{_0x48fd8e(_0x509b31);});});}function _0x508ef8(_0x50d141,_0x44d816,_0x1c17d0){const _0x2f1803=window['grecaptcha'];wr(_0x2f1803)?_0x2f1803['enterprise']['ready'](()=>{_0x2f1803['enterprise']['execute'](_0x50d141,{'action':_0x1f3c26})['then'](_0x350469=>{_0x44d816(_0x350469);})['catch'](()=>{_0x44d816(Fa);});}):_0x1c17d0(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x4b502e,_0x1a2f9f)=>{_0xc5251f(this['auth'])['then'](_0x584565=>{if(!_0x214a1f&&wr(window['grecaptcha']))_0x508ef8(_0x584565,_0x4b502e,_0x1a2f9f);else{if(typeof window>'u'){_0x1a2f9f(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x241e20=Pf();_0x241e20['length']!==0x0&&(_0x241e20+=_0x584565),xa(_0x241e20)['then'](()=>{_0x508ef8(_0x584565,_0x4b502e,_0x1a2f9f);})['catch'](_0x959328=>{_0x1a2f9f(_0x959328);});}})['catch'](_0x23055a=>{_0x1a2f9f(_0x23055a);});});}}async function Ar(_0x56ff88,_0x2fc57d,_0x1c3767,_0x3fc5a0=!0x1,_0x3374c9=!0x1){const _0x21bede=new Ff(_0x56ff88);let _0x234b80;if(_0x3374c9)_0x234b80=Fa;else try{_0x234b80=await _0x21bede['verify'](_0x1c3767);}catch{_0x234b80=await _0x21bede['verify'](_0x1c3767,!0x0);}const _0x5dc536={..._0x2fc57d};if(_0x1c3767==='mfaSmsEnrollment'||_0x1c3767==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x5dc536){const _0x5ea765=_0x5dc536['phoneEnrollmentInfo']['phoneNumber'],_0x35f734=_0x5dc536['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x5dc536,{'phoneEnrollmentInfo':{'phoneNumber':_0x5ea765,'recaptchaToken':_0x35f734,'captchaResponse':_0x234b80,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x5dc536){const _0x3b4b37=_0x5dc536['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x5dc536,{'phoneSignInInfo':{'recaptchaToken':_0x3b4b37,'captchaResponse':_0x234b80,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x5dc536;}return _0x3fc5a0?Object['assign'](_0x5dc536,{'captchaResp':_0x234b80}):Object['assign'](_0x5dc536,{'captchaResponse':_0x234b80}),Object['assign'](_0x5dc536,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x5dc536,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x5dc536;}async function Di(_0x12c337,_0x58770e,_0x178b75,_0x4c6de7,_0x1e9dc4){var _0x566064;if((_0x566064=_0x12c337['_getRecaptchaConfig']())!=null&&_0x566064['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x3d1c4d=await Ar(_0x12c337,_0x58770e,_0x178b75,_0x178b75==='getOobCode');return _0x4c6de7(_0x12c337,_0x3d1c4d);}else return _0x4c6de7(_0x12c337,_0x58770e)['catch'](async _0x4cced0=>{if(_0x4cced0['code']==='auth/missing-recaptcha-token'){console['log'](_0x178b75+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x4f2c49=await Ar(_0x12c337,_0x58770e,_0x178b75,_0x178b75==='getOobCode');return _0x4c6de7(_0x12c337,_0x4f2c49);}else return Promise['reject'](_0x4cced0);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x336edb,_0x54ae35){const _0x3bf5f4=Bi(_0x336edb,'auth');if(_0x3bf5f4['isInitialized']()){const _0x28e6ba=_0x3bf5f4['getImmediate'](),_0x3c7623=_0x3bf5f4['getOptions']();if(Me(_0x3c7623,_0x54ae35??{}))return _0x28e6ba;Q(_0x28e6ba,'already-initialized');}return _0x3bf5f4['initialize']({'options':_0x54ae35});}function Wf(_0x3dcd97,_0x93f27){const _0xdfb6a2=(_0x93f27==null?void 0x0:_0x93f27['persistence'])||[],_0x198b52=(Array['isArray'](_0xdfb6a2)?_0xdfb6a2:[_0xdfb6a2])['map'](ie);_0x93f27!=null&&_0x93f27['errorMap']&&_0x3dcd97['_updateErrorMap'](_0x93f27['errorMap']),_0x3dcd97['_initializeWithPersistence'](_0x198b52,_0x93f27==null?void 0x0:_0x93f27['popupRedirectResolver']);}function Bf(_0x2344f5,_0x39b050,_0x44c4f5){const _0x5e103a=qe(_0x2344f5);m(/^https?:\/\//['test'](_0x39b050),_0x5e103a,'invalid-emulator-scheme');const _0x5c90e9=!0x1,_0x118d2d=Ua(_0x39b050),{host:_0x2540dd,port:_0x4279ec}=Vf(_0x39b050),_0x5994e5=_0x4279ec===null?'':':'+_0x4279ec,_0x203f9f={'url':_0x118d2d+'//'+_0x2540dd+_0x5994e5+'/'},_0x2e96a1=Object['freeze']({'host':_0x2540dd,'port':_0x4279ec,'protocol':_0x118d2d['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x5c90e9})});if(!_0x5e103a['_canInitEmulator']){m(_0x5e103a['config']['emulator']&&_0x5e103a['emulatorConfig'],_0x5e103a,'emulator-config-failed'),m(Me(_0x203f9f,_0x5e103a['config']['emulator'])&&Me(_0x2e96a1,_0x5e103a['emulatorConfig']),_0x5e103a,'emulator-config-failed');return;}_0x5e103a['config']['emulator']=_0x203f9f,_0x5e103a['emulatorConfig']=_0x2e96a1,_0x5e103a['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x2540dd)?(jr(_0x118d2d+'//'+_0x2540dd+_0x5994e5),Kr('Auth',!0x0)):Hf();}function Ua(_0x3288d9){const _0x4a8234=_0x3288d9['indexOf'](':');return _0x4a8234<0x0?'':_0x3288d9['substr'](0x0,_0x4a8234+0x1);}function Vf(_0x20ecf6){const _0x273282=Ua(_0x20ecf6),_0x4a70b2=/(\/\/)?([^?#/]+)/['exec'](_0x20ecf6['substr'](_0x273282['length']));if(!_0x4a70b2)return{'host':'','port':null};const _0x3811fb=_0x4a70b2[0x2]['split']('@')['pop']()||'',_0x5c08df=/^(\[[^\]]+\])(:|$)/['exec'](_0x3811fb);if(_0x5c08df){const _0x5ef2ed=_0x5c08df[0x1];return{'host':_0x5ef2ed,'port':kr(_0x3811fb['substr'](_0x5ef2ed['length']+0x1))};}else{const [_0x3ae168,_0x128e29]=_0x3811fb['split'](':');return{'host':_0x3ae168,'port':kr(_0x128e29)};}}function kr(_0x3c37a6){if(!_0x3c37a6)return null;const _0x3efb50=Number(_0x3c37a6);return isNaN(_0x3efb50)?null:_0x3efb50;}function Hf(){function _0x22819f(){const _0x4b3bb0=document['createElement']('p'),_0x4179cc=_0x4b3bb0['style'];_0x4b3bb0['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x4179cc['position']='fixed',_0x4179cc['width']='100%',_0x4179cc['backgroundColor']='#ffffff',_0x4179cc['border']='.1em\x20solid\x20#000000',_0x4179cc['color']='#b50000',_0x4179cc['bottom']='0px',_0x4179cc['left']='0px',_0x4179cc['margin']='0px',_0x4179cc['zIndex']='10000',_0x4179cc['textAlign']='center',_0x4b3bb0['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x4b3bb0);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x22819f):_0x22819f());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x6ab09d,_0x2ad4c4){this['providerId']=_0x6ab09d,this['signInMethod']=_0x2ad4c4;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x505ee0){return ne('not\x20implemented');}['_linkToIdToken'](_0x2005d8,_0x59b8fd){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0xfeb1eb){return ne('not\x20implemented');}}async function $f(_0x539475,_0x47f148){return Ae(_0x539475,'POST','/v1/accounts:signUp',_0x47f148);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x38d96c,_0x5af9d1){return Qt(_0x38d96c,'POST','/v1/accounts:signInWithPassword',Re(_0x38d96c,_0x5af9d1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x34cca3,_0x4953ff){return Qt(_0x34cca3,'POST','/v1/accounts:signInWithEmailLink',Re(_0x34cca3,_0x4953ff));}async function zf(_0x4d86cf,_0x597dae){return Qt(_0x4d86cf,'POST','/v1/accounts:signInWithEmailLink',Re(_0x4d86cf,_0x597dae));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x100b04,_0x379860,_0x4f701e,_0x171184=null){super('password',_0x4f701e),this['_email']=_0x100b04,this['_password']=_0x379860,this['_tenantId']=_0x171184;}static['_fromEmailAndPassword'](_0x5723e8,_0x3d401f){return new Wt(_0x5723e8,_0x3d401f,'password');}static['_fromEmailAndCode'](_0x4b28d0,_0x2526b8,_0x304aa0=null){return new Wt(_0x4b28d0,_0x2526b8,'emailLink',_0x304aa0);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x4708bf){const _0x15cdd1=typeof _0x4708bf=='string'?JSON['parse'](_0x4708bf):_0x4708bf;if(_0x15cdd1!=null&&_0x15cdd1['email']&&(_0x15cdd1!=null&&_0x15cdd1['password'])){if(_0x15cdd1['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x15cdd1['email'],_0x15cdd1['password']);if(_0x15cdd1['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x15cdd1['email'],_0x15cdd1['password'],_0x15cdd1['tenantId']);}return null;}async['_getIdTokenResponse'](_0x438bfb){switch(this['signInMethod']){case'password':const _0x2c8bff={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x438bfb,_0x2c8bff,'signInWithPassword',Gf);case'emailLink':return qf(_0x438bfb,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x438bfb,'internal-error');}}async['_linkToIdToken'](_0x40183a,_0x24a17f){switch(this['signInMethod']){case'password':const _0x109c57={'idToken':_0x24a17f,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x40183a,_0x109c57,'signUpPassword',$f);case'emailLink':return zf(_0x40183a,{'idToken':_0x24a17f,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x40183a,'internal-error');}}['_getReauthenticationResolver'](_0x1d0226){return this['_getIdTokenResponse'](_0x1d0226);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x2def5f,_0x2ab32f){return Qt(_0x2def5f,'POST','/v1/accounts:signInWithIdp',Re(_0x2def5f,_0x2ab32f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x4fa977){const _0x26eaba=new Be(_0x4fa977['providerId'],_0x4fa977['signInMethod']);return _0x4fa977['idToken']||_0x4fa977['accessToken']?(_0x4fa977['idToken']&&(_0x26eaba['idToken']=_0x4fa977['idToken']),_0x4fa977['accessToken']&&(_0x26eaba['accessToken']=_0x4fa977['accessToken']),_0x4fa977['nonce']&&!_0x4fa977['pendingToken']&&(_0x26eaba['nonce']=_0x4fa977['nonce']),_0x4fa977['pendingToken']&&(_0x26eaba['pendingToken']=_0x4fa977['pendingToken'])):_0x4fa977['oauthToken']&&_0x4fa977['oauthTokenSecret']?(_0x26eaba['accessToken']=_0x4fa977['oauthToken'],_0x26eaba['secret']=_0x4fa977['oauthTokenSecret']):Q('argument-error'),_0x26eaba;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x475868){const _0xbbea46=typeof _0x475868=='string'?JSON['parse'](_0x475868):_0x475868,{providerId:_0x5d4526,signInMethod:_0x1f8034,..._0x296dfa}=_0xbbea46;if(!_0x5d4526||!_0x1f8034)return null;const _0x28c3c1=new Be(_0x5d4526,_0x1f8034);return _0x28c3c1['idToken']=_0x296dfa['idToken']||void 0x0,_0x28c3c1['accessToken']=_0x296dfa['accessToken']||void 0x0,_0x28c3c1['secret']=_0x296dfa['secret'],_0x28c3c1['nonce']=_0x296dfa['nonce'],_0x28c3c1['pendingToken']=_0x296dfa['pendingToken']||null,_0x28c3c1;}['_getIdTokenResponse'](_0x12b598){const _0x59180a=this['buildRequest']();return Xe(_0x12b598,_0x59180a);}['_linkToIdToken'](_0x44ddf4,_0x45c1cd){const _0x2a4e39=this['buildRequest']();return _0x2a4e39['idToken']=_0x45c1cd,Xe(_0x44ddf4,_0x2a4e39);}['_getReauthenticationResolver'](_0x4666b7){const _0x207fc4=this['buildRequest']();return _0x207fc4['autoCreate']=!0x1,Xe(_0x4666b7,_0x207fc4);}['buildRequest'](){const _0x2939ea={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x2939ea['pendingToken']=this['pendingToken'];else{const _0x44f495={};this['idToken']&&(_0x44f495['id_token']=this['idToken']),this['accessToken']&&(_0x44f495['access_token']=this['accessToken']),this['secret']&&(_0x44f495['oauth_token_secret']=this['secret']),_0x44f495['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x44f495['nonce']=this['nonce']),_0x2939ea['postBody']=ct(_0x44f495);}return _0x2939ea;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x27c095){switch(_0x27c095){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x43a5bd){const _0x3df840=vt(Et(_0x43a5bd))['link'],_0x489d81=_0x3df840?vt(Et(_0x3df840))['deep_link_id']:null,_0x433a7d=vt(Et(_0x43a5bd))['deep_link_id'];return(_0x433a7d?vt(Et(_0x433a7d))['link']:null)||_0x433a7d||_0x489d81||_0x3df840||_0x43a5bd;}class Rs{constructor(_0x564d67){const _0x563963=vt(Et(_0x564d67)),_0x3c2997=_0x563963['apiKey']??null,_0x7730f2=_0x563963['oobCode']??null,_0x379c94=Kf(_0x563963['mode']??null);m(_0x3c2997&&_0x7730f2&&_0x379c94,'argument-error'),this['apiKey']=_0x3c2997,this['operation']=_0x379c94,this['code']=_0x7730f2,this['continueUrl']=_0x563963['continueUrl']??null,this['languageCode']=_0x563963['lang']??null,this['tenantId']=_0x563963['tenantId']??null;}static['parseLink'](_0x15e426){const _0x2f9c24=Yf(_0x15e426);try{return new Rs(_0x2f9c24);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x5b76ff,_0x2294c6){return Wt['_fromEmailAndPassword'](_0x5b76ff,_0x2294c6);}static['credentialWithLink'](_0x1fc40b,_0x562718){const _0x10e218=Rs['parseLink'](_0x562718);return m(_0x10e218,'argument-error'),Wt['_fromEmailAndCode'](_0x1fc40b,_0x10e218['code'],_0x10e218['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x4a3473){this['providerId']=_0x4a3473,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x5715ab){this['defaultLanguageCode']=_0x5715ab;}['setCustomParameters'](_0x260f1f){return this['customParameters']=_0x260f1f,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x26de2f){return this['scopes']['includes'](_0x26de2f)||this['scopes']['push'](_0x26de2f),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x3d9d5d){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x3d9d5d});}static['credentialFromResult'](_0x132bc8){return he['credentialFromTaggedObject'](_0x132bc8);}static['credentialFromError'](_0x42005e){return he['credentialFromTaggedObject'](_0x42005e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2b8504}){if(!_0x2b8504||!('oauthAccessToken'in _0x2b8504)||!_0x2b8504['oauthAccessToken'])return null;try{return he['credential'](_0x2b8504['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3f79d8,_0x2fdbcc){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3f79d8,'accessToken':_0x2fdbcc});}static['credentialFromResult'](_0x339890){return ue['credentialFromTaggedObject'](_0x339890);}static['credentialFromError'](_0x4d16f9){return ue['credentialFromTaggedObject'](_0x4d16f9['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4118b9}){if(!_0x4118b9)return null;const {oauthIdToken:_0x45a7dd,oauthAccessToken:_0xc1939f}=_0x4118b9;if(!_0x45a7dd&&!_0xc1939f)return null;try{return ue['credential'](_0x45a7dd,_0xc1939f);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0xe6b1bf){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0xe6b1bf});}static['credentialFromResult'](_0x1e6166){return de['credentialFromTaggedObject'](_0x1e6166);}static['credentialFromError'](_0x101aad){return de['credentialFromTaggedObject'](_0x101aad['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4cc440}){if(!_0x4cc440||!('oauthAccessToken'in _0x4cc440)||!_0x4cc440['oauthAccessToken'])return null;try{return de['credential'](_0x4cc440['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x20febf,_0x30c156){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x20febf,'oauthTokenSecret':_0x30c156});}static['credentialFromResult'](_0x47e138){return fe['credentialFromTaggedObject'](_0x47e138);}static['credentialFromError'](_0x1c77f1){return fe['credentialFromTaggedObject'](_0x1c77f1['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1b1b11}){if(!_0x1b1b11)return null;const {oauthAccessToken:_0x45b2a0,oauthTokenSecret:_0x25ca9c}=_0x1b1b11;if(!_0x45b2a0||!_0x25ca9c)return null;try{return fe['credential'](_0x45b2a0,_0x25ca9c);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x44dc09,_0x380e2d){return Qt(_0x44dc09,'POST','/v1/accounts:signUp',Re(_0x44dc09,_0x380e2d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0xcf41e9){this['user']=_0xcf41e9['user'],this['providerId']=_0xcf41e9['providerId'],this['_tokenResponse']=_0xcf41e9['_tokenResponse'],this['operationType']=_0xcf41e9['operationType'];}static async['_fromIdTokenResponse'](_0x56cf7b,_0x57c655,_0x2f3efc,_0x2cad11=!0x1){const _0x44cad7=await K['_fromIdTokenResponse'](_0x56cf7b,_0x2f3efc,_0x2cad11),_0x243a0d=Nr(_0x2f3efc);return new Ve({'user':_0x44cad7,'providerId':_0x243a0d,'_tokenResponse':_0x2f3efc,'operationType':_0x57c655});}static async['_forOperation'](_0x195a99,_0x258e2c,_0x3d9530){await _0x195a99['_updateTokensIfNecessary'](_0x3d9530,!0x0);const _0x3bd682=Nr(_0x3d9530);return new Ve({'user':_0x195a99,'providerId':_0x3bd682,'_tokenResponse':_0x3d9530,'operationType':_0x258e2c});}}function Nr(_0x1d7989){return _0x1d7989['providerId']?_0x1d7989['providerId']:'phoneNumber'in _0x1d7989?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x3794bf,_0x30c9b8,_0x39bb5b,_0x24a45f){super(_0x30c9b8['code'],_0x30c9b8['message']),this['operationType']=_0x39bb5b,this['user']=_0x24a45f,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x3794bf['name'],'tenantId':_0x3794bf['tenantId']??void 0x0,'_serverResponse':_0x30c9b8['customData']['_serverResponse'],'operationType':_0x39bb5b};}static['_fromErrorAndOperation'](_0x5537dd,_0x518fec,_0x33116e,_0x355eb2){return new An(_0x5537dd,_0x518fec,_0x33116e,_0x355eb2);}}function Ba(_0x9143c,_0xfe379c,_0x22de12,_0x207072){return(_0xfe379c==='reauthenticate'?_0x22de12['_getReauthenticationResolver'](_0x9143c):_0x22de12['_getIdTokenResponse'](_0x9143c))['catch'](_0x451f2a=>{throw _0x451f2a['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x9143c,_0x451f2a,_0xfe379c,_0x207072):_0x451f2a;});}async function Jf(_0x23c330,_0x1b48ba,_0x4480a0=!0x1){const _0x27b759=await Ut(_0x23c330,_0x1b48ba['_linkToIdToken'](_0x23c330['auth'],await _0x23c330['getIdToken']()),_0x4480a0);return Ve['_forOperation'](_0x23c330,'link',_0x27b759);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x535f56,_0x37327a,_0x1f3bd2=!0x1){const {auth:_0xb66ce5}=_0x535f56;if($(_0xb66ce5['app']))return Promise['reject'](re(_0xb66ce5));const _0xeac76e='reauthenticate';try{const _0x3f58cf=await Ut(_0x535f56,Ba(_0xb66ce5,_0xeac76e,_0x37327a,_0x535f56),_0x1f3bd2);m(_0x3f58cf['idToken'],_0xb66ce5,'internal-error');const _0x5f50e3=Ts(_0x3f58cf['idToken']);m(_0x5f50e3,_0xb66ce5,'internal-error');const {sub:_0x2372eb}=_0x5f50e3;return m(_0x535f56['uid']===_0x2372eb,_0xb66ce5,'user-mismatch'),Ve['_forOperation'](_0x535f56,_0xeac76e,_0x3f58cf);}catch(_0xcfa702){throw(_0xcfa702==null?void 0x0:_0xcfa702['code'])==='auth/user-not-found'&&Q(_0xb66ce5,'user-mismatch'),_0xcfa702;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x20988b,_0xe3b93e,_0x557b59=!0x1){if($(_0x20988b['app']))return Promise['reject'](re(_0x20988b));const _0x459fc4='signIn',_0x2b6d6f=await Ba(_0x20988b,_0x459fc4,_0xe3b93e),_0x41ea07=await Ve['_fromIdTokenResponse'](_0x20988b,_0x459fc4,_0x2b6d6f);return _0x557b59||await _0x20988b['_updateCurrentUser'](_0x41ea07['user']),_0x41ea07;}async function Zf(_0x287c11,_0x11974f){return Va(qe(_0x287c11),_0x11974f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x634c23){const _0x2dff30=qe(_0x634c23);_0x2dff30['_getPasswordPolicyInternal']()&&await _0x2dff30['_updatePasswordPolicy']();}async function P_(_0x310ae2,_0x1e6893,_0x43a313){if($(_0x310ae2['app']))return Promise['reject'](re(_0x310ae2));const _0x41f992=qe(_0x310ae2),_0x290738=await Di(_0x41f992,{'returnSecureToken':!0x0,'email':_0x1e6893,'password':_0x43a313,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x1397f6=>{throw _0x1397f6['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x310ae2),_0x1397f6;}),_0x4b2f3b=await Ve['_fromIdTokenResponse'](_0x41f992,'signIn',_0x290738);return await _0x41f992['_updateCurrentUser'](_0x4b2f3b['user']),_0x4b2f3b;}function O_(_0x755391,_0xbf4fd2,_0x49595c){return $(_0x755391['app'])?Promise['reject'](re(_0x755391)):Zf(N(_0x755391),pt['credential'](_0xbf4fd2,_0x49595c))['catch'](async _0x160eba=>{throw _0x160eba['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x755391),_0x160eba;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x596121,_0xc41d8e){return N(_0x596121)['setPersistence'](_0xc41d8e);}function ep(_0x55115b,_0x3ff6f6,_0x44a96c,_0x33aa8b){return N(_0x55115b)['onIdTokenChanged'](_0x3ff6f6,_0x44a96c,_0x33aa8b);}function tp(_0x391c55,_0xe67930,_0x548e08){return N(_0x391c55)['beforeAuthStateChanged'](_0xe67930,_0x548e08);}function M_(_0x3fc68c,_0x16aadd,_0x31b548,_0x3e858e){return N(_0x3fc68c)['onAuthStateChanged'](_0x16aadd,_0x31b548,_0x3e858e);}function L_(_0x5cd6c2){return N(_0x5cd6c2)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x760255,_0x44bb75){this['storageRetriever']=_0x760255,this['type']=_0x44bb75;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x313568,_0x32821c){return this['storage']['setItem'](_0x313568,JSON['stringify'](_0x32821c)),Promise['resolve']();}['_get'](_0x44ee3b){const _0x28d27d=this['storage']['getItem'](_0x44ee3b);return Promise['resolve'](_0x28d27d?JSON['parse'](_0x28d27d):null);}['_remove'](_0x5d68c6){return this['storage']['removeItem'](_0x5d68c6),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x36cd74,_0x2e53ff)=>this['onStorageEvent'](_0x36cd74,_0x2e53ff),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x1e7581){for(const _0x5d5125 of Object['keys'](this['listeners'])){const _0x4719d9=this['storage']['getItem'](_0x5d5125),_0x306735=this['localCache'][_0x5d5125];_0x4719d9!==_0x306735&&_0x1e7581(_0x5d5125,_0x306735,_0x4719d9);}}['onStorageEvent'](_0xd7d87e,_0x3837ce=!0x1){if(!_0xd7d87e['key']){this['forAllChangedKeys']((_0x4a9450,_0x24eed2,_0x27d143)=>{this['notifyListeners'](_0x4a9450,_0x27d143);});return;}const _0x4986ba=_0xd7d87e['key'];_0x3837ce?this['detachListener']():this['stopPolling']();const _0x2de35a=()=>{const _0x2bed4c=this['storage']['getItem'](_0x4986ba);!_0x3837ce&&this['localCache'][_0x4986ba]===_0x2bed4c||this['notifyListeners'](_0x4986ba,_0x2bed4c);},_0x452e67=this['storage']['getItem'](_0x4986ba);Tf()&&_0x452e67!==_0xd7d87e['newValue']&&_0xd7d87e['newValue']!==_0xd7d87e['oldValue']?setTimeout(_0x2de35a,ip):_0x2de35a();}['notifyListeners'](_0xd1c277,_0x2502ab){this['localCache'][_0xd1c277]=_0x2502ab;const _0x2cae66=this['listeners'][_0xd1c277];if(_0x2cae66){for(const _0x1cc7a8 of Array['from'](_0x2cae66))_0x1cc7a8(_0x2502ab&&JSON['parse'](_0x2502ab));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x5d477c,_0x2cd223,_0x293d24)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x5d477c,'oldValue':_0x2cd223,'newValue':_0x293d24}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x52ae7a,_0xf9c9bf){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x52ae7a]||(this['listeners'][_0x52ae7a]=new Set(),this['localCache'][_0x52ae7a]=this['storage']['getItem'](_0x52ae7a)),this['listeners'][_0x52ae7a]['add'](_0xf9c9bf);}['_removeListener'](_0x18ff49,_0x354388){this['listeners'][_0x18ff49]&&(this['listeners'][_0x18ff49]['delete'](_0x354388),this['listeners'][_0x18ff49]['size']===0x0&&delete this['listeners'][_0x18ff49]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0xe66107,_0x418695){await super['_set'](_0xe66107,_0x418695),this['localCache'][_0xe66107]=JSON['stringify'](_0x418695);}async['_get'](_0xe5683){const _0xc8e503=await super['_get'](_0xe5683);return this['localCache'][_0xe5683]=JSON['stringify'](_0xc8e503),_0xc8e503;}async['_remove'](_0x510bda){await super['_remove'](_0x510bda),delete this['localCache'][_0x510bda];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x2a99db,_0x44e6b7){}['_removeListener'](_0x2f7eeb,_0x4d83a6){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x3f7f61){return Promise['all'](_0x3f7f61['map'](async _0x38b6c5=>{try{return{'fulfilled':!0x0,'value':await _0x38b6c5};}catch(_0x55aaa7){return{'fulfilled':!0x1,'reason':_0x55aaa7};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x2151d2){this['eventTarget']=_0x2151d2,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x295206){const _0x5b6fbc=this['receivers']['find'](_0x6123f2=>_0x6123f2['isListeningto'](_0x295206));if(_0x5b6fbc)return _0x5b6fbc;const _0x2ebe28=new Kn(_0x295206);return this['receivers']['push'](_0x2ebe28),_0x2ebe28;}['isListeningto'](_0x1ced99){return this['eventTarget']===_0x1ced99;}async['handleEvent'](_0x52dd7f){const _0x113a79=_0x52dd7f,{eventId:_0x1e781d,eventType:_0xa12a2d,data:_0x5727c6}=_0x113a79['data'],_0x214afc=this['handlersMap'][_0xa12a2d];if(!(_0x214afc!=null&&_0x214afc['size']))return;_0x113a79['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x1e781d,'eventType':_0xa12a2d});const _0x5528de=Array['from'](_0x214afc)['map'](async _0x55cf91=>_0x55cf91(_0x113a79['origin'],_0x5727c6)),_0x578f18=await rp(_0x5528de);_0x113a79['ports'][0x0]['postMessage']({'status':'done','eventId':_0x1e781d,'eventType':_0xa12a2d,'response':_0x578f18});}['_subscribe'](_0x258a10,_0x557e2e){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x258a10]||(this['handlersMap'][_0x258a10]=new Set()),this['handlersMap'][_0x258a10]['add'](_0x557e2e);}['_unsubscribe'](_0x57f8a9,_0x10c77a){this['handlersMap'][_0x57f8a9]&&_0x10c77a&&this['handlersMap'][_0x57f8a9]['delete'](_0x10c77a),(!_0x10c77a||this['handlersMap'][_0x57f8a9]['size']===0x0)&&delete this['handlersMap'][_0x57f8a9],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x76a700='',_0x53fe22=0xa){let _0x34b4d2='';for(let _0x57dec4=0x0;_0x57dec4<_0x53fe22;_0x57dec4++)_0x34b4d2+=Math['floor'](Math['random']()*0xa);return _0x76a700+_0x34b4d2;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x331c91){this['target']=_0x331c91,this['handlers']=new Set();}['removeMessageHandler'](_0x560ebd){_0x560ebd['messageChannel']&&(_0x560ebd['messageChannel']['port1']['removeEventListener']('message',_0x560ebd['onMessage']),_0x560ebd['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x560ebd);}async['_send'](_0x2ead39,_0xac143b,_0x228de8=0x32){const _0x346f3c=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x346f3c)throw new Error('connection_unavailable');let _0x5bf3ed,_0x4125c8;return new Promise((_0x502c68,_0x26e864)=>{const _0x24cfc7=As('',0x14);_0x346f3c['port1']['start']();const _0x56c8e5=setTimeout(()=>{_0x26e864(new Error('unsupported_event'));},_0x228de8);_0x4125c8={'messageChannel':_0x346f3c,'onMessage'(_0x46e173){const _0x10725a=_0x46e173;if(_0x10725a['data']['eventId']===_0x24cfc7)switch(_0x10725a['data']['status']){case'ack':clearTimeout(_0x56c8e5),_0x5bf3ed=setTimeout(()=>{_0x26e864(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x5bf3ed),_0x502c68(_0x10725a['data']['response']);break;default:clearTimeout(_0x56c8e5),clearTimeout(_0x5bf3ed),_0x26e864(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x4125c8),_0x346f3c['port1']['addEventListener']('message',_0x4125c8['onMessage']),this['target']['postMessage']({'eventType':_0x2ead39,'eventId':_0x24cfc7,'data':_0xac143b},[_0x346f3c['port2']]);})['finally'](()=>{_0x4125c8&&this['removeMessageHandler'](_0x4125c8);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0xa68cd8){Z()['location']['href']=_0xa68cd8;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x4fef77;return((_0x4fef77=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x4fef77['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x3fc907){this['request']=_0x3fc907;}['toPromise'](){return new Promise((_0x3b6cb6,_0xfec513)=>{this['request']['addEventListener']('success',()=>{_0x3b6cb6(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0xfec513(this['request']['error']);});});}}function Yn(_0x2796aa,_0x26aa96){return _0x2796aa['transaction']([Nn],_0x26aa96?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x26e87e=indexedDB['deleteDatabase'](Ka);return new Xt(_0x26e87e)['toPromise']();}function Mi(){const _0x55fc2c=indexedDB['open'](Ka,up);return new Promise((_0x656f04,_0x4dc170)=>{_0x55fc2c['addEventListener']('error',()=>{_0x4dc170(_0x55fc2c['error']);}),_0x55fc2c['addEventListener']('upgradeneeded',()=>{const _0x26e7e4=_0x55fc2c['result'];try{_0x26e7e4['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x3a6196){_0x4dc170(_0x3a6196);}}),_0x55fc2c['addEventListener']('success',async()=>{const _0x2ea98b=_0x55fc2c['result'];_0x2ea98b['objectStoreNames']['contains'](Nn)?_0x656f04(_0x2ea98b):(_0x2ea98b['close'](),await dp(),_0x656f04(await Mi()));});});}async function Pr(_0x3f76f9,_0x373977,_0xf2506b){const _0x287094=Yn(_0x3f76f9,!0x0)['put']({[Ya]:_0x373977,'value':_0xf2506b});return new Xt(_0x287094)['toPromise']();}async function fp(_0x246ae9,_0x3d851d){const _0x48bf09=Yn(_0x246ae9,!0x1)['get'](_0x3d851d),_0x43a05c=await new Xt(_0x48bf09)['toPromise']();return _0x43a05c===void 0x0?null:_0x43a05c['value'];}function Or(_0x34dfbf,_0x16d373){const _0xf97720=Yn(_0x34dfbf,!0x0)['delete'](_0x16d373);return new Xt(_0xf97720)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x44b104){let _0x19b424=0x0;for(;;)try{const _0x1ed71e=await this['_openDb']();return await _0x44b104(_0x1ed71e);}catch(_0x197697){if(_0x19b424++>_p)throw _0x197697;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0xe0a71,_0xbdb79b)=>({'keyProcessed':(await this['_poll']())['includes'](_0xbdb79b['key'])})),this['receiver']['_subscribe']('ping',async(_0x57708d,_0x4c2199)=>['keyChanged']);}async['initializeSender'](){var _0x50c9f0,_0x5d97f4;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x41ec69=await this['sender']['_send']('ping',{},0x320);_0x41ec69&&(_0x50c9f0=_0x41ec69[0x0])!=null&&_0x50c9f0['fulfilled']&&(_0x5d97f4=_0x41ec69[0x0])!=null&&_0x5d97f4['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0xf7ce4c){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0xf7ce4c},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x185782=await Mi();return await Pr(_0x185782,kn,'1'),await Or(_0x185782,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x5a4173){this['pendingWrites']++;try{await _0x5a4173();}finally{this['pendingWrites']--;}}async['_set'](_0x3fa673,_0x2f1d46){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x210311=>Pr(_0x210311,_0x3fa673,_0x2f1d46)),this['localCache'][_0x3fa673]=_0x2f1d46,this['notifyServiceWorker'](_0x3fa673)));}async['_get'](_0x937976){const _0x8077e7=await this['_withRetries'](_0x2e36a5=>fp(_0x2e36a5,_0x937976));return this['localCache'][_0x937976]=_0x8077e7,_0x8077e7;}async['_remove'](_0x22fdb2){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x37b6cc=>Or(_0x37b6cc,_0x22fdb2)),delete this['localCache'][_0x22fdb2],this['notifyServiceWorker'](_0x22fdb2)));}async['_poll'](){const _0x5c91ec=await this['_withRetries'](_0x4f84ba=>{const _0x4d5549=Yn(_0x4f84ba,!0x1)['getAll']();return new Xt(_0x4d5549)['toPromise']();});if(!_0x5c91ec)return[];if(this['pendingWrites']!==0x0)return[];const _0xa5ab2f=[],_0x5a9f76=new Set();if(_0x5c91ec['length']!==0x0){for(const {fbase_key:_0x521d5f,value:_0x4f7528}of _0x5c91ec)_0x5a9f76['add'](_0x521d5f),JSON['stringify'](this['localCache'][_0x521d5f])!==JSON['stringify'](_0x4f7528)&&(this['notifyListeners'](_0x521d5f,_0x4f7528),_0xa5ab2f['push'](_0x521d5f));}for(const _0x412d17 of Object['keys'](this['localCache']))this['localCache'][_0x412d17]&&!_0x5a9f76['has'](_0x412d17)&&(this['notifyListeners'](_0x412d17,null),_0xa5ab2f['push'](_0x412d17));return _0xa5ab2f;}['notifyListeners'](_0x54ed14,_0x5e6ad0){this['localCache'][_0x54ed14]=_0x5e6ad0;const _0x116824=this['listeners'][_0x54ed14];if(_0x116824){for(const _0x4fce61 of Array['from'](_0x116824))_0x4fce61(_0x5e6ad0);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x3167ba,_0x3abcca){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x3167ba]||(this['listeners'][_0x3167ba]=new Set(),this['_get'](_0x3167ba)),this['listeners'][_0x3167ba]['add'](_0x3abcca);}['_removeListener'](_0x5556c5,_0xed116f){this['listeners'][_0x5556c5]&&(this['listeners'][_0x5556c5]['delete'](_0xed116f),this['listeners'][_0x5556c5]['size']===0x0&&delete this['listeners'][_0x5556c5]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x5ca33e,_0xe1a464){return _0xe1a464?ie(_0xe1a464):(m(_0x5ca33e['_popupRedirectResolver'],_0x5ca33e,'argument-error'),_0x5ca33e['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0xd4be9a){super('custom','custom'),this['params']=_0xd4be9a;}['_getIdTokenResponse'](_0x2eb0b1){return Xe(_0x2eb0b1,this['_buildIdpRequest']());}['_linkToIdToken'](_0xe7544f,_0x361620){return Xe(_0xe7544f,this['_buildIdpRequest'](_0x361620));}['_getReauthenticationResolver'](_0xaacd06){return Xe(_0xaacd06,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x51cd03){const _0x4a69b8={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x51cd03&&(_0x4a69b8['idToken']=_0x51cd03),_0x4a69b8;}}function yp(_0x2260b4){return Va(_0x2260b4['auth'],new ks(_0x2260b4),_0x2260b4['bypassAuthState']);}function vp(_0x1d9677){const {auth:_0x4087e6,user:_0x1387e7}=_0x1d9677;return m(_0x1387e7,_0x4087e6,'internal-error'),Xf(_0x1387e7,new ks(_0x1d9677),_0x1d9677['bypassAuthState']);}async function Ep(_0xcf0925){const {auth:_0x5e377f,user:_0x4d9bba}=_0xcf0925;return m(_0x4d9bba,_0x5e377f,'internal-error'),Jf(_0x4d9bba,new ks(_0xcf0925),_0xcf0925['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x31aca9,_0x1798f7,_0x6db654,_0x5bea56,_0x458fba=!0x1){this['auth']=_0x31aca9,this['resolver']=_0x6db654,this['user']=_0x5bea56,this['bypassAuthState']=_0x458fba,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x1798f7)?_0x1798f7:[_0x1798f7];}['execute'](){return new Promise(async(_0x1f1856,_0xe8300b)=>{this['pendingPromise']={'resolve':_0x1f1856,'reject':_0xe8300b};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x5550f2){this['reject'](_0x5550f2);}});}async['onAuthEvent'](_0x3ae0c0){const {urlResponse:_0x2772d7,sessionId:_0x345721,postBody:_0x5ab572,tenantId:_0x5903bd,error:_0xd36f9b,type:_0x5de8a0}=_0x3ae0c0;if(_0xd36f9b){this['reject'](_0xd36f9b);return;}const _0x507e51={'auth':this['auth'],'requestUri':_0x2772d7,'sessionId':_0x345721,'tenantId':_0x5903bd||void 0x0,'postBody':_0x5ab572||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x5de8a0)(_0x507e51));}catch(_0x28d00b){this['reject'](_0x28d00b);}}['onError'](_0x306c93){this['reject'](_0x306c93);}['getIdpTask'](_0x1d8539){switch(_0x1d8539){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x1d2578){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x1d2578),this['unregisterAndCleanUp']();}['reject'](_0x2c5cbd){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x2c5cbd),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x411975,_0x2773d4,_0x507e7a,_0x56b98e,_0x2ec5c6){super(_0x411975,_0x2773d4,_0x56b98e,_0x2ec5c6),this['provider']=_0x507e7a,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x1f9969=await this['execute']();return m(_0x1f9969,this['auth'],'internal-error'),_0x1f9969;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x10a327=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x10a327),this['authWindow']['associatedEvent']=_0x10a327,this['resolver']['_originValidation'](this['auth'])['catch'](_0x106541=>{this['reject'](_0x106541);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x1a433e=>{_0x1a433e||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x46cadc;return((_0x46cadc=this['authWindow'])==null?void 0x0:_0x46cadc['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x333255=()=>{var _0x30ee5e,_0x5bcaff;if((_0x5bcaff=(_0x30ee5e=this['authWindow'])==null?void 0x0:_0x30ee5e['window'])!=null&&_0x5bcaff['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x333255,Ip['get']());};_0x333255();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x3770cc,_0x43901a,_0x34b203=!0x1){super(_0x3770cc,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x43901a,void 0x0,_0x34b203),this['eventId']=null;}async['execute'](){let _0x4f5d41=on['get'](this['auth']['_key']());if(!_0x4f5d41){try{const _0x1cee32=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x4f5d41=()=>Promise['resolve'](_0x1cee32);}catch(_0x3a7aab){_0x4f5d41=()=>Promise['reject'](_0x3a7aab);}on['set'](this['auth']['_key'](),_0x4f5d41);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x4f5d41();}async['onAuthEvent'](_0x2f873a){if(_0x2f873a['type']==='signInViaRedirect')return super['onAuthEvent'](_0x2f873a);if(_0x2f873a['type']==='unknown'){this['resolve'](null);return;}if(_0x2f873a['eventId']){const _0x336f62=await this['auth']['_redirectUserForId'](_0x2f873a['eventId']);if(_0x336f62)return this['user']=_0x336f62,super['onAuthEvent'](_0x2f873a);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x4b59e1,_0x5e7819){const _0x248eb1=Rp(_0x5e7819),_0xc399b3=bp(_0x4b59e1);if(!await _0xc399b3['_isAvailable']())return!0x1;const _0x338680=await _0xc399b3['_get'](_0x248eb1)==='true';return await _0xc399b3['_remove'](_0x248eb1),_0x338680;}function Sp(_0x27147e,_0x21798b){on['set'](_0x27147e['_key'](),_0x21798b);}function bp(_0x1e5567){return ie(_0x1e5567['_redirectPersistence']);}function Rp(_0x5a2a65){return rn(wp,_0x5a2a65['config']['apiKey'],_0x5a2a65['name']);}async function Ap(_0x19b55e,_0x26fd1a,_0x45f855=!0x1){if($(_0x19b55e['app']))return Promise['reject'](re(_0x19b55e));const _0x537708=qe(_0x19b55e),_0x818e88=mp(_0x537708,_0x26fd1a),_0x181801=await new Cp(_0x537708,_0x818e88,_0x45f855)['execute']();return _0x181801&&!_0x45f855&&(delete _0x181801['user']['_redirectEventId'],await _0x537708['_persistUserIfCurrent'](_0x181801['user']),await _0x537708['_setRedirectUser'](null,_0x26fd1a)),_0x181801;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x46bc32){this['auth']=_0x46bc32,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x8be3ad){this['consumers']['add'](_0x8be3ad),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x8be3ad)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x8be3ad),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x3a91e0){this['consumers']['delete'](_0x3a91e0);}['onEvent'](_0x722098){if(this['hasEventBeenHandled'](_0x722098))return!0x1;let _0x36251d=!0x1;return this['consumers']['forEach'](_0x111d38=>{this['isEventForConsumer'](_0x722098,_0x111d38)&&(_0x36251d=!0x0,this['sendToConsumer'](_0x722098,_0x111d38),this['saveEventToCache'](_0x722098));}),this['hasHandledPotentialRedirect']||!Pp(_0x722098)||(this['hasHandledPotentialRedirect']=!0x0,_0x36251d||(this['queuedRedirectEvent']=_0x722098,_0x36251d=!0x0)),_0x36251d;}['sendToConsumer'](_0x4f9324,_0x3e44cf){var _0x189c87;if(_0x4f9324['error']&&!Xa(_0x4f9324)){const _0x39e10f=((_0x189c87=_0x4f9324['error']['code'])==null?void 0x0:_0x189c87['split']('auth/')[0x1])||'internal-error';_0x3e44cf['onError'](X(this['auth'],_0x39e10f));}else _0x3e44cf['onAuthEvent'](_0x4f9324);}['isEventForConsumer'](_0x512941,_0x42c02e){const _0x14fa18=_0x42c02e['eventId']===null||!!_0x512941['eventId']&&_0x512941['eventId']===_0x42c02e['eventId'];return _0x42c02e['filter']['includes'](_0x512941['type'])&&_0x14fa18;}['hasEventBeenHandled'](_0x573a00){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x573a00));}['saveEventToCache'](_0x178304){this['cachedEventUids']['add'](Dr(_0x178304)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x547cc4){return[_0x547cc4['type'],_0x547cc4['eventId'],_0x547cc4['sessionId'],_0x547cc4['tenantId']]['filter'](_0x41fb73=>_0x41fb73)['join']('-');}function Xa({type:_0x254394,error:_0x507be6}){return _0x254394==='unknown'&&(_0x507be6==null?void 0x0:_0x507be6['code'])==='auth/no-auth-event';}function Pp(_0x3bd570){switch(_0x3bd570['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x3bd570);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x30b74f,_0x340107={}){return Ae(_0x30b74f,'GET','/v1/projects',_0x340107);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x2ddadb){if(_0x2ddadb['config']['emulator'])return;const {authorizedDomains:_0x286274}=await Op(_0x2ddadb);for(const _0x445c64 of _0x286274)try{if(xp(_0x445c64))return;}catch{}Q(_0x2ddadb,'unauthorized-domain');}function xp(_0x18c153){const _0x352aee=Pi(),{protocol:_0x2bf870,hostname:_0x1d46de}=new URL(_0x352aee);if(_0x18c153['startsWith']('chrome-extension://')){const _0x197cfb=new URL(_0x18c153);return _0x197cfb['hostname']===''&&_0x1d46de===''?_0x2bf870==='chrome-extension:'&&_0x18c153['replace']('chrome-extension://','')===_0x352aee['replace']('chrome-extension://',''):_0x2bf870==='chrome-extension:'&&_0x197cfb['hostname']===_0x1d46de;}if(!Mp['test'](_0x2bf870))return!0x1;if(Dp['test'](_0x18c153))return _0x1d46de===_0x18c153;const _0xf0788f=_0x18c153['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0xf0788f+'|'+_0xf0788f+')$','i')['test'](_0x1d46de);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x2d4ced=Z()['___jsl'];if(_0x2d4ced!=null&&_0x2d4ced['H']){for(const _0x1362e7 of Object['keys'](_0x2d4ced['H']))if(_0x2d4ced['H'][_0x1362e7]['r']=_0x2d4ced['H'][_0x1362e7]['r']||[],_0x2d4ced['H'][_0x1362e7]['L']=_0x2d4ced['H'][_0x1362e7]['L']||[],_0x2d4ced['H'][_0x1362e7]['r']=[..._0x2d4ced['H'][_0x1362e7]['L']],_0x2d4ced['CP']){for(let _0x55f53d=0x0;_0x55f53d<_0x2d4ced['CP']['length'];_0x55f53d++)_0x2d4ced['CP'][_0x55f53d]=null;}}}function Up(_0x32c501){return new Promise((_0x19daf2,_0x4fd42a)=>{var _0x17d6eb,_0x16f2a0,_0x303564;function _0x5c65a7(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x19daf2(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x4fd42a(X(_0x32c501,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x16f2a0=(_0x17d6eb=Z()['gapi'])==null?void 0x0:_0x17d6eb['iframes'])!=null&&_0x16f2a0['Iframe'])_0x19daf2(gapi['iframes']['getContext']());else{if((_0x303564=Z()['gapi'])!=null&&_0x303564['load'])_0x5c65a7();else{const _0x529086=Df('iframefcb');return Z()[_0x529086]=()=>{gapi['load']?_0x5c65a7():_0x4fd42a(X(_0x32c501,'network-request-failed'));},xa(Of()+'?onload='+_0x529086)['catch'](_0x3bd051=>_0x4fd42a(_0x3bd051));}}})['catch'](_0x291749=>{throw an=null,_0x291749;});}let an=null;function Wp(_0x5dca74){return an=an||Up(_0x5dca74),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x5a8c12){const _0x473d8b=_0x5a8c12['config'];m(_0x473d8b['authDomain'],_0x5a8c12,'auth-domain-config-required');const _0x48c252=_0x473d8b['emulator']?Cs(_0x473d8b,Hp):'https://'+_0x5a8c12['config']['authDomain']+'/'+Vp,_0x121983={'apiKey':_0x473d8b['apiKey'],'appName':_0x5a8c12['name'],'v':lt},_0x5774c8=Gp['get'](_0x5a8c12['config']['apiHost']);_0x5774c8&&(_0x121983['eid']=_0x5774c8);const _0x2a136f=_0x5a8c12['_getFrameworks']();return _0x2a136f['length']&&(_0x121983['fw']=_0x2a136f['join'](',')),_0x48c252+'?'+ct(_0x121983)['slice'](0x1);}async function zp(_0x17aa29){const _0x29a6e=await Wp(_0x17aa29),_0x5b0b2a=Z()['gapi'];return m(_0x5b0b2a,_0x17aa29,'internal-error'),_0x29a6e['open']({'where':document['body'],'url':qp(_0x17aa29),'messageHandlersFilter':_0x5b0b2a['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x20efd8=>new Promise(async(_0x152add,_0x15b018)=>{await _0x20efd8['restyle']({'setHideOnLeave':!0x1});const _0x45cf54=X(_0x17aa29,'network-request-failed'),_0x45f153=Z()['setTimeout'](()=>{_0x15b018(_0x45cf54);},Bp['get']());function _0x23c42e(){Z()['clearTimeout'](_0x45f153),_0x152add(_0x20efd8);}_0x20efd8['ping'](_0x23c42e)['then'](_0x23c42e,()=>{_0x15b018(_0x45cf54);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x3696eb){this['window']=_0x3696eb,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x2b1161,_0x43b5dc,_0x39f045,_0xe53d30=Kp,_0x34ab45=Yp){const _0x1fdb70=Math['max']((window['screen']['availHeight']-_0x34ab45)/0x2,0x0)['toString'](),_0x199ec8=Math['max']((window['screen']['availWidth']-_0xe53d30)/0x2,0x0)['toString']();let _0x5c61ee='';const _0x35d14b={...jp,'width':_0xe53d30['toString'](),'height':_0x34ab45['toString'](),'top':_0x1fdb70,'left':_0x199ec8},_0x1af9f3=W()['toLowerCase']();_0x39f045&&(_0x5c61ee=ka(_0x1af9f3)?Qp:_0x39f045),Ra(_0x1af9f3)&&(_0x43b5dc=_0x43b5dc||Jp,_0x35d14b['scrollbars']='yes');const _0x25b93e=Object['entries'](_0x35d14b)['reduce']((_0x1a9480,[_0x4cd85e,_0x54ee76])=>''+_0x1a9480+_0x4cd85e+'='+_0x54ee76+',','');if(Cf(_0x1af9f3)&&_0x5c61ee!=='_self')return Zp(_0x43b5dc||'',_0x5c61ee),new Lr(null);const _0xcdf447=window['open'](_0x43b5dc||'',_0x5c61ee,_0x25b93e);m(_0xcdf447,_0x2b1161,'popup-blocked');try{_0xcdf447['focus']();}catch{}return new Lr(_0xcdf447);}function Zp(_0xc49ec,_0x17b065){const _0x403c7b=document['createElement']('a');_0x403c7b['href']=_0xc49ec,_0x403c7b['target']=_0x17b065;const _0x1c5d91=document['createEvent']('MouseEvent');_0x1c5d91['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x403c7b['dispatchEvent'](_0x1c5d91);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x2dbc3f,_0x5c885b,_0x473239,_0x2bf7dc,_0x2a6145,_0x1a5ccc){m(_0x2dbc3f['config']['authDomain'],_0x2dbc3f,'auth-domain-config-required'),m(_0x2dbc3f['config']['apiKey'],_0x2dbc3f,'invalid-api-key');const _0x44ba75={'apiKey':_0x2dbc3f['config']['apiKey'],'appName':_0x2dbc3f['name'],'authType':_0x473239,'redirectUrl':_0x2bf7dc,'v':lt,'eventId':_0x2a6145};if(_0x5c885b instanceof Wa){_0x5c885b['setDefaultLanguage'](_0x2dbc3f['languageCode']),_0x44ba75['providerId']=_0x5c885b['providerId']||'',ui(_0x5c885b['getCustomParameters']())||(_0x44ba75['customParameters']=JSON['stringify'](_0x5c885b['getCustomParameters']()));for(const [_0x1fec2b,_0x53cc5f]of Object['entries']({}))_0x44ba75[_0x1fec2b]=_0x53cc5f;}if(_0x5c885b instanceof Jt){const _0x13950c=_0x5c885b['getScopes']()['filter'](_0x463824=>_0x463824!=='');_0x13950c['length']>0x0&&(_0x44ba75['scopes']=_0x13950c['join'](','));}_0x2dbc3f['tenantId']&&(_0x44ba75['tid']=_0x2dbc3f['tenantId']);const _0x44b64b=_0x44ba75;for(const _0xe40566 of Object['keys'](_0x44b64b))_0x44b64b[_0xe40566]===void 0x0&&delete _0x44b64b[_0xe40566];const _0x571fb3=await _0x2dbc3f['_getAppCheckToken'](),_0x36c2d3=_0x571fb3?'#'+n_+'='+encodeURIComponent(_0x571fb3):'';return i_(_0x2dbc3f)+'?'+ct(_0x44b64b)['slice'](0x1)+_0x36c2d3;}function i_({config:_0x37358a}){return _0x37358a['emulator']?Cs(_0x37358a,t_):'https://'+_0x37358a['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x334516,_0x33f31f,_0x3bf2ae,_0x208743){var _0x3d9047;ce((_0x3d9047=this['eventManagers'][_0x334516['_key']()])==null?void 0x0:_0x3d9047['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x12af5b=await xr(_0x334516,_0x33f31f,_0x3bf2ae,Pi(),_0x208743);return Xp(_0x334516,_0x12af5b,As());}async['_openRedirect'](_0x2b900a,_0x588419,_0x338408,_0x387a0d){await this['_originValidation'](_0x2b900a);const _0x5c4f31=await xr(_0x2b900a,_0x588419,_0x338408,Pi(),_0x387a0d);return ap(_0x5c4f31),new Promise(()=>{});}['_initialize'](_0x39f340){const _0x196951=_0x39f340['_key']();if(this['eventManagers'][_0x196951]){const {manager:_0x5b166b,promise:_0x41a9ca}=this['eventManagers'][_0x196951];return _0x5b166b?Promise['resolve'](_0x5b166b):(ce(_0x41a9ca,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x41a9ca);}const _0x1a0515=this['initAndGetManager'](_0x39f340);return this['eventManagers'][_0x196951]={'promise':_0x1a0515},_0x1a0515['catch'](()=>{delete this['eventManagers'][_0x196951];}),_0x1a0515;}async['initAndGetManager'](_0x579d97){const _0x4b79e6=await zp(_0x579d97),_0x4e1949=new Np(_0x579d97);return _0x4b79e6['register']('authEvent',_0x1ec8ff=>(m(_0x1ec8ff==null?void 0x0:_0x1ec8ff['authEvent'],_0x579d97,'invalid-auth-event'),{'status':_0x4e1949['onEvent'](_0x1ec8ff['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x579d97['_key']()]={'manager':_0x4e1949},this['iframes'][_0x579d97['_key']()]=_0x4b79e6,_0x4e1949;}['_isIframeWebStorageSupported'](_0x24eb80,_0x5d94b6){this['iframes'][_0x24eb80['_key']()]['send'](hi,{'type':hi},_0x318dcb=>{var _0x285c8f;const _0x19ab69=(_0x285c8f=_0x318dcb==null?void 0x0:_0x318dcb[0x0])==null?void 0x0:_0x285c8f[hi];_0x19ab69!==void 0x0&&_0x5d94b6(!!_0x19ab69),Q(_0x24eb80,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x4704bf){const _0x36c851=_0x4704bf['_key']();return this['originValidationPromises'][_0x36c851]||(this['originValidationPromises'][_0x36c851]=Lp(_0x4704bf)),this['originValidationPromises'][_0x36c851];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x47993b){this['auth']=_0x47993b,this['internalListeners']=new Map();}['getUid'](){var _0x1a8b0b;return this['assertAuthConfigured'](),((_0x1a8b0b=this['auth']['currentUser'])==null?void 0x0:_0x1a8b0b['uid'])||null;}async['getToken'](_0x26a979){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x26a979)}:null;}['addAuthTokenListener'](_0x475116){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x475116))return;const _0x3f046a=this['auth']['onIdTokenChanged'](_0x3ea0bc=>{_0x475116((_0x3ea0bc==null?void 0x0:_0x3ea0bc['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x475116,_0x3f046a),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x2a3824){this['assertAuthConfigured']();const _0x4abb93=this['internalListeners']['get'](_0x2a3824);_0x4abb93&&(this['internalListeners']['delete'](_0x2a3824),_0x4abb93(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x4e8de7){switch(_0x4e8de7){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x5ce6cc){Ze(new Le('auth',(_0x485871,{options:_0x4b6e43})=>{const _0x64d12f=_0x485871['getProvider']('app')['getImmediate'](),_0x146384=_0x485871['getProvider']('heartbeat'),_0x5b66c7=_0x485871['getProvider']('app-check-internal'),{apiKey:_0x4d66f5,authDomain:_0x32a9c6}=_0x64d12f['options'];m(_0x4d66f5&&!_0x4d66f5['includes'](':'),'invalid-api-key',{'appName':_0x64d12f['name']});const _0x4e943f={'apiKey':_0x4d66f5,'authDomain':_0x32a9c6,'clientPlatform':_0x5ce6cc,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x5ce6cc)},_0x2dc489=new kf(_0x64d12f,_0x146384,_0x5b66c7,_0x4e943f);return Wf(_0x2dc489,_0x4b6e43),_0x2dc489;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x46485d,_0x4b86f2,_0x5c8ca8)=>{_0x46485d['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x488941=>{const _0x19b8fc=qe(_0x488941['getProvider']('auth')['getImmediate']());return(_0x137475=>new o_(_0x137475))(_0x19b8fc);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x5ce6cc)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x5da0be=>async _0x17a1d9=>{const _0x3406c0=_0x17a1d9&&await _0x17a1d9['getIdTokenResult'](),_0x3fc72c=_0x3406c0&&(new Date()['getTime']()-Date['parse'](_0x3406c0['issuedAtTime']))/0x3e8;if(_0x3fc72c&&_0x3fc72c>h_)return;const _0xc83dbe=_0x3406c0==null?void 0x0:_0x3406c0['token'];Wr!==_0xc83dbe&&(Wr=_0xc83dbe,await fetch(_0x5da0be,{'method':_0xc83dbe?'POST':'DELETE','headers':_0xc83dbe?{'Authorization':'Bearer\x20'+_0xc83dbe}:{}}));};function x_(_0x5106b3=Zr()){const _0x3bfcaf=Bi(_0x5106b3,'auth');if(_0x3bfcaf['isInitialized']())return _0x3bfcaf['getImmediate']();const _0x31a839=Uf(_0x5106b3,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x1791fa=zr('authTokenSyncURL');if(_0x1791fa&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x33680a=new URL(_0x1791fa,location['origin']);if(location['origin']===_0x33680a['origin']){const _0xf0381d=u_(_0x33680a['toString']());tp(_0x31a839,_0xf0381d,()=>_0xf0381d(_0x31a839['currentUser'])),ep(_0x31a839,_0xe16a80=>_0xf0381d(_0xe16a80));}}const _0x4b7a22=Gr('auth');return _0x4b7a22&&Bf(_0x31a839,'http://'+_0x4b7a22),_0x31a839;}function d_(){var _0x2ef55a;return((_0x2ef55a=document['getElementsByTagName']('head'))==null?void 0x0:_0x2ef55a[0x0])??document;}Nf({'loadJS'(_0x15a827){return new Promise((_0x21862d,_0x5a8b3d)=>{const _0x40f4c2=document['createElement']('script');_0x40f4c2['setAttribute']('src',_0x15a827),_0x40f4c2['onload']=_0x21862d,_0x40f4c2['onerror']=_0x59d344=>{const _0x4accda=X('internal-error');_0x4accda['customData']=_0x59d344,_0x5a8b3d(_0x4accda);},_0x40f4c2['type']='text/javascript',_0x40f4c2['charset']='UTF-8',d_()['appendChild'](_0x40f4c2);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};