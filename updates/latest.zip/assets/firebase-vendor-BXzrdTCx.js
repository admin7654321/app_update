const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3a66ef,_0x17fd4e){if(!_0x3a66ef)throw rt(_0x17fd4e);},rt=function(_0x5e3e25){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x5e3e25);},Vr=function(_0x3c3998){const _0x98ebcf=[];let _0x4f63f3=0x0;for(let _0x13d00d=0x0;_0x13d00d<_0x3c3998['length'];_0x13d00d++){let _0xf48bbe=_0x3c3998['charCodeAt'](_0x13d00d);_0xf48bbe<0x80?_0x98ebcf[_0x4f63f3++]=_0xf48bbe:_0xf48bbe<0x800?(_0x98ebcf[_0x4f63f3++]=_0xf48bbe>>0x6|0xc0,_0x98ebcf[_0x4f63f3++]=_0xf48bbe&0x3f|0x80):(_0xf48bbe&0xfc00)===0xd800&&_0x13d00d+0x1<_0x3c3998['length']&&(_0x3c3998['charCodeAt'](_0x13d00d+0x1)&0xfc00)===0xdc00?(_0xf48bbe=0x10000+((_0xf48bbe&0x3ff)<<0xa)+(_0x3c3998['charCodeAt'](++_0x13d00d)&0x3ff),_0x98ebcf[_0x4f63f3++]=_0xf48bbe>>0x12|0xf0,_0x98ebcf[_0x4f63f3++]=_0xf48bbe>>0xc&0x3f|0x80,_0x98ebcf[_0x4f63f3++]=_0xf48bbe>>0x6&0x3f|0x80,_0x98ebcf[_0x4f63f3++]=_0xf48bbe&0x3f|0x80):(_0x98ebcf[_0x4f63f3++]=_0xf48bbe>>0xc|0xe0,_0x98ebcf[_0x4f63f3++]=_0xf48bbe>>0x6&0x3f|0x80,_0x98ebcf[_0x4f63f3++]=_0xf48bbe&0x3f|0x80);}return _0x98ebcf;},ec=function(_0x2ae9d4){const _0x1dc852=[];let _0x5a55af=0x0,_0x82ae9d=0x0;for(;_0x5a55af<_0x2ae9d4['length'];){const _0x36f5bc=_0x2ae9d4[_0x5a55af++];if(_0x36f5bc<0x80)_0x1dc852[_0x82ae9d++]=String['fromCharCode'](_0x36f5bc);else{if(_0x36f5bc>0xbf&&_0x36f5bc<0xe0){const _0x5d5d62=_0x2ae9d4[_0x5a55af++];_0x1dc852[_0x82ae9d++]=String['fromCharCode']((_0x36f5bc&0x1f)<<0x6|_0x5d5d62&0x3f);}else{if(_0x36f5bc>0xef&&_0x36f5bc<0x16d){const _0x490553=_0x2ae9d4[_0x5a55af++],_0x811145=_0x2ae9d4[_0x5a55af++],_0x356d14=_0x2ae9d4[_0x5a55af++],_0x477677=((_0x36f5bc&0x7)<<0x12|(_0x490553&0x3f)<<0xc|(_0x811145&0x3f)<<0x6|_0x356d14&0x3f)-0x10000;_0x1dc852[_0x82ae9d++]=String['fromCharCode'](0xd800+(_0x477677>>0xa)),_0x1dc852[_0x82ae9d++]=String['fromCharCode'](0xdc00+(_0x477677&0x3ff));}else{const _0x56a88d=_0x2ae9d4[_0x5a55af++],_0x1ca5ff=_0x2ae9d4[_0x5a55af++];_0x1dc852[_0x82ae9d++]=String['fromCharCode']((_0x36f5bc&0xf)<<0xc|(_0x56a88d&0x3f)<<0x6|_0x1ca5ff&0x3f);}}}}return _0x1dc852['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x54563f,_0x4b9710){if(!Array['isArray'](_0x54563f))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x5e0d28=_0x4b9710?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x58f0ad=[];for(let _0x1ab760=0x0;_0x1ab760<_0x54563f['length'];_0x1ab760+=0x3){const _0x32ebe6=_0x54563f[_0x1ab760],_0x1eebfb=_0x1ab760+0x1<_0x54563f['length'],_0x5aa1fb=_0x1eebfb?_0x54563f[_0x1ab760+0x1]:0x0,_0x55ad1c=_0x1ab760+0x2<_0x54563f['length'],_0x4f9929=_0x55ad1c?_0x54563f[_0x1ab760+0x2]:0x0,_0x30a762=_0x32ebe6>>0x2,_0x2b99ea=(_0x32ebe6&0x3)<<0x4|_0x5aa1fb>>0x4;let _0x4678bc=(_0x5aa1fb&0xf)<<0x2|_0x4f9929>>0x6,_0x44fe47=_0x4f9929&0x3f;_0x55ad1c||(_0x44fe47=0x40,_0x1eebfb||(_0x4678bc=0x40)),_0x58f0ad['push'](_0x5e0d28[_0x30a762],_0x5e0d28[_0x2b99ea],_0x5e0d28[_0x4678bc],_0x5e0d28[_0x44fe47]);}return _0x58f0ad['join']('');},'encodeString'(_0x4902a5,_0x5bbb96){return this['HAS_NATIVE_SUPPORT']&&!_0x5bbb96?btoa(_0x4902a5):this['encodeByteArray'](Vr(_0x4902a5),_0x5bbb96);},'decodeString'(_0x3a7bac,_0x21a4fa){return this['HAS_NATIVE_SUPPORT']&&!_0x21a4fa?atob(_0x3a7bac):ec(this['decodeStringToByteArray'](_0x3a7bac,_0x21a4fa));},'decodeStringToByteArray'(_0x3cf987,_0x1a84be){this['init_']();const _0x2df7cd=_0x1a84be?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x53e53b=[];for(let _0x32ca32=0x0;_0x32ca32<_0x3cf987['length'];){const _0x4db7c4=_0x2df7cd[_0x3cf987['charAt'](_0x32ca32++)],_0x3562ff=_0x32ca32<_0x3cf987['length']?_0x2df7cd[_0x3cf987['charAt'](_0x32ca32)]:0x0;++_0x32ca32;const _0x8975b1=_0x32ca32<_0x3cf987['length']?_0x2df7cd[_0x3cf987['charAt'](_0x32ca32)]:0x40;++_0x32ca32;const _0x18a35f=_0x32ca32<_0x3cf987['length']?_0x2df7cd[_0x3cf987['charAt'](_0x32ca32)]:0x40;if(++_0x32ca32,_0x4db7c4==null||_0x3562ff==null||_0x8975b1==null||_0x18a35f==null)throw new tc();const _0x453632=_0x4db7c4<<0x2|_0x3562ff>>0x4;if(_0x53e53b['push'](_0x453632),_0x8975b1!==0x40){const _0x7d75b7=_0x3562ff<<0x4&0xf0|_0x8975b1>>0x2;if(_0x53e53b['push'](_0x7d75b7),_0x18a35f!==0x40){const _0x4c5303=_0x8975b1<<0x6&0xc0|_0x18a35f;_0x53e53b['push'](_0x4c5303);}}}return _0x53e53b;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0xa7a061=0x0;_0xa7a061<this['ENCODED_VALS']['length'];_0xa7a061++)this['byteToCharMap_'][_0xa7a061]=this['ENCODED_VALS']['charAt'](_0xa7a061),this['charToByteMap_'][this['byteToCharMap_'][_0xa7a061]]=_0xa7a061,this['byteToCharMapWebSafe_'][_0xa7a061]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0xa7a061),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0xa7a061]]=_0xa7a061,_0xa7a061>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0xa7a061)]=_0xa7a061,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0xa7a061)]=_0xa7a061);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x47b659){const _0x49149c=Vr(_0x47b659);return Li['encodeByteArray'](_0x49149c,!0x0);},cn=function(_0x5f4d32){return Hr(_0x5f4d32)['replace'](/\./g,'');},ln=function(_0x2deed4){try{return Li['decodeString'](_0x2deed4,!0x0);}catch(_0x21e351){console['error']('base64Decode\x20failed:\x20',_0x21e351);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x32b662){return $r(void 0x0,_0x32b662);}function $r(_0x2de7da,_0x2e1926){if(!(_0x2e1926 instanceof Object))return _0x2e1926;switch(_0x2e1926['constructor']){case Date:const _0x4d8343=_0x2e1926;return new Date(_0x4d8343['getTime']());case Object:_0x2de7da===void 0x0&&(_0x2de7da={});break;case Array:_0x2de7da=[];break;default:return _0x2e1926;}for(const _0x153061 in _0x2e1926)!_0x2e1926['hasOwnProperty'](_0x153061)||!ic(_0x153061)||(_0x2de7da[_0x153061]=$r(_0x2de7da[_0x153061],_0x2e1926[_0x153061]));return _0x2de7da;}function ic(_0x6dc16e){return _0x6dc16e!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x4793f2=Ns['__FIREBASE_DEFAULTS__'];if(_0x4793f2)return JSON['parse'](_0x4793f2);},ac=()=>{if(typeof document>'u')return;let _0x5ccd45;try{_0x5ccd45=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x1daf7e=_0x5ccd45&&ln(_0x5ccd45[0x1]);return _0x1daf7e&&JSON['parse'](_0x1daf7e);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x5d047e){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x5d047e);return;}},Gr=_0x5b674a=>{var _0x2148b5,_0x5132cc;return(_0x5132cc=(_0x2148b5=xi())==null?void 0x0:_0x2148b5['emulatorHosts'])==null?void 0x0:_0x5132cc[_0x5b674a];},cc=_0x299cb8=>{const _0x569f68=Gr(_0x299cb8);if(!_0x569f68)return;const _0x1d40fe=_0x569f68['lastIndexOf'](':');if(_0x1d40fe<=0x0||_0x1d40fe+0x1===_0x569f68['length'])throw new Error('Invalid\x20host\x20'+_0x569f68+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x3645b1=parseInt(_0x569f68['substring'](_0x1d40fe+0x1),0xa);return _0x569f68[0x0]==='['?[_0x569f68['substring'](0x1,_0x1d40fe-0x1),_0x3645b1]:[_0x569f68['substring'](0x0,_0x1d40fe),_0x3645b1];},qr=()=>{var _0x3040fd;return(_0x3040fd=xi())==null?void 0x0:_0x3040fd['config'];},zr=_0x4fe849=>{var _0x5363e4;return(_0x5363e4=xi())==null?void 0x0:_0x5363e4['_'+_0x4fe849];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x2cb3db,_0x174f04)=>{this['resolve']=_0x2cb3db,this['reject']=_0x174f04;});}['wrapCallback'](_0x17fe75){return(_0x567c1c,_0x1f1083)=>{_0x567c1c?this['reject'](_0x567c1c):this['resolve'](_0x1f1083),typeof _0x17fe75=='function'&&(this['promise']['catch'](()=>{}),_0x17fe75['length']===0x1?_0x17fe75(_0x567c1c):_0x17fe75(_0x567c1c,_0x1f1083));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x4cac99){try{return(_0x4cac99['startsWith']('http://')||_0x4cac99['startsWith']('https://')?new URL(_0x4cac99)['hostname']:_0x4cac99)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x3d4dfa){return(await fetch(_0x3d4dfa,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x168edd,_0x4af316){if(_0x168edd['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x1b01e2={'alg':'none','type':'JWT'},_0x17688e=_0x4af316||'demo-project',_0x3be7e8=_0x168edd['iat']||0x0,_0x29a077=_0x168edd['sub']||_0x168edd['user_id'];if(!_0x29a077)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x46cb53={'iss':'https://securetoken.google.com/'+_0x17688e,'aud':_0x17688e,'iat':_0x3be7e8,'exp':_0x3be7e8+0xe10,'auth_time':_0x3be7e8,'sub':_0x29a077,'user_id':_0x29a077,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x168edd};return[cn(JSON['stringify'](_0x1b01e2)),cn(JSON['stringify'](_0x46cb53)),'']['join']('.');}const It={};function hc(){const _0x493cff={'prod':[],'emulator':[]};for(const _0x57ed4f of Object['keys'](It))It[_0x57ed4f]?_0x493cff['emulator']['push'](_0x57ed4f):_0x493cff['prod']['push'](_0x57ed4f);return _0x493cff;}function uc(_0x29aa8f){let _0xef32b9=document['getElementById'](_0x29aa8f),_0x6eab6a=!0x1;return _0xef32b9||(_0xef32b9=document['createElement']('div'),_0xef32b9['setAttribute']('id',_0x29aa8f),_0x6eab6a=!0x0),{'created':_0x6eab6a,'element':_0xef32b9};}let Ps=!0x1;function Kr(_0x50df74,_0x1eadbf){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x50df74]===_0x1eadbf||It[_0x50df74]||Ps)return;It[_0x50df74]=_0x1eadbf;function _0x56c976(_0xeff926){return'__firebase__banner__'+_0xeff926;}const _0x1e2d95='__firebase__banner',_0x28eba2=hc()['prod']['length']>0x0;function _0x388b07(){const _0xa6fe64=document['getElementById'](_0x1e2d95);_0xa6fe64&&_0xa6fe64['remove']();}function _0x519a34(_0x5d0a3d){_0x5d0a3d['style']['display']='flex',_0x5d0a3d['style']['background']='#7faaf0',_0x5d0a3d['style']['position']='fixed',_0x5d0a3d['style']['bottom']='5px',_0x5d0a3d['style']['left']='5px',_0x5d0a3d['style']['padding']='.5em',_0x5d0a3d['style']['borderRadius']='5px',_0x5d0a3d['style']['alignItems']='center';}function _0x357ab2(_0x76f198,_0x42b5f9){_0x76f198['setAttribute']('width','24'),_0x76f198['setAttribute']('id',_0x42b5f9),_0x76f198['setAttribute']('height','24'),_0x76f198['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x76f198['setAttribute']('fill','none'),_0x76f198['style']['marginLeft']='-6px';}function _0x471ea0(){const _0x5281cd=document['createElement']('span');return _0x5281cd['style']['cursor']='pointer',_0x5281cd['style']['marginLeft']='16px',_0x5281cd['style']['fontSize']='24px',_0x5281cd['innerHTML']='\x20&times;',_0x5281cd['onclick']=()=>{Ps=!0x0,_0x388b07();},_0x5281cd;}function _0x52e525(_0x18edf5,_0x443a00){_0x18edf5['setAttribute']('id',_0x443a00),_0x18edf5['innerText']='Learn\x20more',_0x18edf5['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x18edf5['setAttribute']('target','__blank'),_0x18edf5['style']['paddingLeft']='5px',_0x18edf5['style']['textDecoration']='underline';}function _0x320dd3(){const _0x17e943=uc(_0x1e2d95),_0x1eb28a=_0x56c976('text'),_0x159f14=document['getElementById'](_0x1eb28a)||document['createElement']('span'),_0x4a764d=_0x56c976('learnmore'),_0x503659=document['getElementById'](_0x4a764d)||document['createElement']('a'),_0x57b0b2=_0x56c976('preprendIcon'),_0x2014db=document['getElementById'](_0x57b0b2)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x17e943['created']){const _0x435ef9=_0x17e943['element'];_0x519a34(_0x435ef9),_0x52e525(_0x503659,_0x4a764d);const _0x3b3e1f=_0x471ea0();_0x357ab2(_0x2014db,_0x57b0b2),_0x435ef9['append'](_0x2014db,_0x159f14,_0x503659,_0x3b3e1f),document['body']['appendChild'](_0x435ef9);}_0x28eba2?(_0x159f14['innerText']='Preview\x20backend\x20disconnected.',_0x2014db['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x2014db['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x159f14['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x159f14['setAttribute']('id',_0x1eb28a);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x320dd3):_0x320dd3();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x17da2c=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x17da2c=='object'&&_0x17da2c['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x47eb74=W();return _0x47eb74['indexOf']('MSIE\x20')>=0x0||_0x47eb74['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x58b18f,_0x40df56)=>{try{let _0x578ce6=!0x0;const _0x19dada='validate-browser-context-for-indexeddb-analytics-module',_0x43b3b1=self['indexedDB']['open'](_0x19dada);_0x43b3b1['onsuccess']=()=>{_0x43b3b1['result']['close'](),_0x578ce6||self['indexedDB']['deleteDatabase'](_0x19dada),_0x58b18f(!0x0);},_0x43b3b1['onupgradeneeded']=()=>{_0x578ce6=!0x1;},_0x43b3b1['onerror']=()=>{var _0x56ac02;_0x40df56(((_0x56ac02=_0x43b3b1['error'])==null?void 0x0:_0x56ac02['message'])||'');};}catch(_0x51fe77){_0x40df56(_0x51fe77);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x1ba9ea,_0x370f94,_0x4b8699){super(_0x370f94),this['code']=_0x1ba9ea,this['customData']=_0x4b8699,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x3df266,_0x112d8d,_0x204c1d){this['service']=_0x3df266,this['serviceName']=_0x112d8d,this['errors']=_0x204c1d;}['create'](_0x4ab3c1,..._0xbc97e4){const _0x3e5be5=_0xbc97e4[0x0]||{},_0x4e804d=this['service']+'/'+_0x4ab3c1,_0x1b6f0b=this['errors'][_0x4ab3c1],_0x444ebb=_0x1b6f0b?vc(_0x1b6f0b,_0x3e5be5):'Error',_0x46f553=this['serviceName']+':\x20'+_0x444ebb+'\x20('+_0x4e804d+').';return new Se(_0x4e804d,_0x46f553,_0x3e5be5);}}function vc(_0x1e733b,_0x4fd3da){return _0x1e733b['replace'](Ec,(_0x134c57,_0x4c83be)=>{const _0xefde88=_0x4fd3da[_0x4c83be];return _0xefde88!=null?String(_0xefde88):'<'+_0x4c83be+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x4fc787){return JSON['parse'](_0x4fc787);}function O(_0x4e50e3){return JSON['stringify'](_0x4e50e3);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x9183d3){let _0x3a817e={},_0x2c0fb1={},_0x4ad528={},_0x35de2f='';try{const _0x3d19fa=_0x9183d3['split']('.');_0x3a817e=At(ln(_0x3d19fa[0x0])||''),_0x2c0fb1=At(ln(_0x3d19fa[0x1])||''),_0x35de2f=_0x3d19fa[0x2],_0x4ad528=_0x2c0fb1['d']||{},delete _0x2c0fb1['d'];}catch{}return{'header':_0x3a817e,'claims':_0x2c0fb1,'data':_0x4ad528,'signature':_0x35de2f};},Ic=function(_0x584050){const _0x29ea55=Qr(_0x584050),_0x1ff82b=_0x29ea55['claims'];return!!_0x1ff82b&&typeof _0x1ff82b=='object'&&_0x1ff82b['hasOwnProperty']('iat');},wc=function(_0x27b754){const _0x5ec138=Qr(_0x27b754)['claims'];return typeof _0x5ec138=='object'&&_0x5ec138['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x42ae4e,_0x2d1668){return Object['prototype']['hasOwnProperty']['call'](_0x42ae4e,_0x2d1668);}function De(_0x30e11d,_0x5a3370){if(Object['prototype']['hasOwnProperty']['call'](_0x30e11d,_0x5a3370))return _0x30e11d[_0x5a3370];}function ui(_0x5ec995){for(const _0x1ae3f9 in _0x5ec995)if(Object['prototype']['hasOwnProperty']['call'](_0x5ec995,_0x1ae3f9))return!0x1;return!0x0;}function hn(_0x26ed0e,_0x341237,_0x260434){const _0x4ad349={};for(const _0x400133 in _0x26ed0e)Object['prototype']['hasOwnProperty']['call'](_0x26ed0e,_0x400133)&&(_0x4ad349[_0x400133]=_0x341237['call'](_0x260434,_0x26ed0e[_0x400133],_0x400133,_0x26ed0e));return _0x4ad349;}function Me(_0x328e53,_0x164e02){if(_0x328e53===_0x164e02)return!0x0;const _0x8b7b5b=Object['keys'](_0x328e53),_0x581195=Object['keys'](_0x164e02);for(const _0x3a8d3c of _0x8b7b5b){if(!_0x581195['includes'](_0x3a8d3c))return!0x1;const _0x1f03e4=_0x328e53[_0x3a8d3c],_0x5ce7e9=_0x164e02[_0x3a8d3c];if(Os(_0x1f03e4)&&Os(_0x5ce7e9)){if(!Me(_0x1f03e4,_0x5ce7e9))return!0x1;}else{if(_0x1f03e4!==_0x5ce7e9)return!0x1;}}for(const _0x15f032 of _0x581195)if(!_0x8b7b5b['includes'](_0x15f032))return!0x1;return!0x0;}function Os(_0xa86d3a){return _0xa86d3a!==null&&typeof _0xa86d3a=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x49d133){const _0x3d2da5=[];for(const [_0x5c7043,_0x54ccf4]of Object['entries'](_0x49d133))Array['isArray'](_0x54ccf4)?_0x54ccf4['forEach'](_0x16ed68=>{_0x3d2da5['push'](encodeURIComponent(_0x5c7043)+'='+encodeURIComponent(_0x16ed68));}):_0x3d2da5['push'](encodeURIComponent(_0x5c7043)+'='+encodeURIComponent(_0x54ccf4));return _0x3d2da5['length']?'&'+_0x3d2da5['join']('&'):'';}function vt(_0x1593f0){const _0x2c383b={};return _0x1593f0['replace'](/^\?/,'')['split']('&')['forEach'](_0x33f478=>{if(_0x33f478){const [_0x457edf,_0x5b00d2]=_0x33f478['split']('=');_0x2c383b[decodeURIComponent(_0x457edf)]=decodeURIComponent(_0x5b00d2);}}),_0x2c383b;}function Et(_0x3ac2b9){const _0x32f3a0=_0x3ac2b9['indexOf']('?');if(!_0x32f3a0)return'';const _0x36f82e=_0x3ac2b9['indexOf']('#',_0x32f3a0);return _0x3ac2b9['substring'](_0x32f3a0,_0x36f82e>0x0?_0x36f82e:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x3d5a30=0x1;_0x3d5a30<this['blockSize'];++_0x3d5a30)this['pad_'][_0x3d5a30]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1421fb,_0x842a9a){_0x842a9a||(_0x842a9a=0x0);const _0x2d04b7=this['W_'];if(typeof _0x1421fb=='string'){for(let _0xeb3717=0x0;_0xeb3717<0x10;_0xeb3717++)_0x2d04b7[_0xeb3717]=_0x1421fb['charCodeAt'](_0x842a9a)<<0x18|_0x1421fb['charCodeAt'](_0x842a9a+0x1)<<0x10|_0x1421fb['charCodeAt'](_0x842a9a+0x2)<<0x8|_0x1421fb['charCodeAt'](_0x842a9a+0x3),_0x842a9a+=0x4;}else{for(let _0x10a192=0x0;_0x10a192<0x10;_0x10a192++)_0x2d04b7[_0x10a192]=_0x1421fb[_0x842a9a]<<0x18|_0x1421fb[_0x842a9a+0x1]<<0x10|_0x1421fb[_0x842a9a+0x2]<<0x8|_0x1421fb[_0x842a9a+0x3],_0x842a9a+=0x4;}for(let _0x45aed3=0x10;_0x45aed3<0x50;_0x45aed3++){const _0x3a5180=_0x2d04b7[_0x45aed3-0x3]^_0x2d04b7[_0x45aed3-0x8]^_0x2d04b7[_0x45aed3-0xe]^_0x2d04b7[_0x45aed3-0x10];_0x2d04b7[_0x45aed3]=(_0x3a5180<<0x1|_0x3a5180>>>0x1f)&0xffffffff;}let _0x1c2cbc=this['chain_'][0x0],_0x1b8b10=this['chain_'][0x1],_0x1c5094=this['chain_'][0x2],_0x29d993=this['chain_'][0x3],_0x553c93=this['chain_'][0x4],_0x121bae,_0x82b5e9;for(let _0x580632=0x0;_0x580632<0x50;_0x580632++){_0x580632<0x28?_0x580632<0x14?(_0x121bae=_0x29d993^_0x1b8b10&(_0x1c5094^_0x29d993),_0x82b5e9=0x5a827999):(_0x121bae=_0x1b8b10^_0x1c5094^_0x29d993,_0x82b5e9=0x6ed9eba1):_0x580632<0x3c?(_0x121bae=_0x1b8b10&_0x1c5094|_0x29d993&(_0x1b8b10|_0x1c5094),_0x82b5e9=0x8f1bbcdc):(_0x121bae=_0x1b8b10^_0x1c5094^_0x29d993,_0x82b5e9=0xca62c1d6);const _0x2987a5=(_0x1c2cbc<<0x5|_0x1c2cbc>>>0x1b)+_0x121bae+_0x553c93+_0x82b5e9+_0x2d04b7[_0x580632]&0xffffffff;_0x553c93=_0x29d993,_0x29d993=_0x1c5094,_0x1c5094=(_0x1b8b10<<0x1e|_0x1b8b10>>>0x2)&0xffffffff,_0x1b8b10=_0x1c2cbc,_0x1c2cbc=_0x2987a5;}this['chain_'][0x0]=this['chain_'][0x0]+_0x1c2cbc&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x1b8b10&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x1c5094&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x29d993&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x553c93&0xffffffff;}['update'](_0x6be6fa,_0xba9d6c){if(_0x6be6fa==null)return;_0xba9d6c===void 0x0&&(_0xba9d6c=_0x6be6fa['length']);const _0x339214=_0xba9d6c-this['blockSize'];let _0x58739e=0x0;const _0x1b9ec3=this['buf_'];let _0x26dafb=this['inbuf_'];for(;_0x58739e<_0xba9d6c;){if(_0x26dafb===0x0){for(;_0x58739e<=_0x339214;)this['compress_'](_0x6be6fa,_0x58739e),_0x58739e+=this['blockSize'];}if(typeof _0x6be6fa=='string'){for(;_0x58739e<_0xba9d6c;)if(_0x1b9ec3[_0x26dafb]=_0x6be6fa['charCodeAt'](_0x58739e),++_0x26dafb,++_0x58739e,_0x26dafb===this['blockSize']){this['compress_'](_0x1b9ec3),_0x26dafb=0x0;break;}}else{for(;_0x58739e<_0xba9d6c;)if(_0x1b9ec3[_0x26dafb]=_0x6be6fa[_0x58739e],++_0x26dafb,++_0x58739e,_0x26dafb===this['blockSize']){this['compress_'](_0x1b9ec3),_0x26dafb=0x0;break;}}}this['inbuf_']=_0x26dafb,this['total_']+=_0xba9d6c;}['digest'](){const _0x1883c8=[];let _0x2d3488=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0xc91274=this['blockSize']-0x1;_0xc91274>=0x38;_0xc91274--)this['buf_'][_0xc91274]=_0x2d3488&0xff,_0x2d3488/=0x100;this['compress_'](this['buf_']);let _0x9428a7=0x0;for(let _0x989a29=0x0;_0x989a29<0x5;_0x989a29++)for(let _0x4132ec=0x18;_0x4132ec>=0x0;_0x4132ec-=0x8)_0x1883c8[_0x9428a7]=this['chain_'][_0x989a29]>>_0x4132ec&0xff,++_0x9428a7;return _0x1883c8;}}function Tc(_0x7c9797,_0x4aba49){const _0x1d04c3=new Sc(_0x7c9797,_0x4aba49);return _0x1d04c3['subscribe']['bind'](_0x1d04c3);}class Sc{constructor(_0x24cb6c,_0x52eb8e){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x52eb8e,this['task']['then'](()=>{_0x24cb6c(this);})['catch'](_0x2273b6=>{this['error'](_0x2273b6);});}['next'](_0x1a3d17){this['forEachObserver'](_0x5f27c0=>{_0x5f27c0['next'](_0x1a3d17);});}['error'](_0xfdacd1){this['forEachObserver'](_0x16a1ae=>{_0x16a1ae['error'](_0xfdacd1);}),this['close'](_0xfdacd1);}['complete'](){this['forEachObserver'](_0x35c624=>{_0x35c624['complete']();}),this['close']();}['subscribe'](_0x441259,_0x63afcc,_0x418d46){let _0x5eb5ad;if(_0x441259===void 0x0&&_0x63afcc===void 0x0&&_0x418d46===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x441259,['next','error','complete'])?_0x5eb5ad=_0x441259:_0x5eb5ad={'next':_0x441259,'error':_0x63afcc,'complete':_0x418d46},_0x5eb5ad['next']===void 0x0&&(_0x5eb5ad['next']=Jn),_0x5eb5ad['error']===void 0x0&&(_0x5eb5ad['error']=Jn),_0x5eb5ad['complete']===void 0x0&&(_0x5eb5ad['complete']=Jn);const _0x101421=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x5eb5ad['error'](this['finalError']):_0x5eb5ad['complete']();}catch{}}),this['observers']['push'](_0x5eb5ad),_0x101421;}['unsubscribeOne'](_0x3a112a){this['observers']===void 0x0||this['observers'][_0x3a112a]===void 0x0||(delete this['observers'][_0x3a112a],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x1e00f5){if(!this['finalized']){for(let _0x4bb1d7=0x0;_0x4bb1d7<this['observers']['length'];_0x4bb1d7++)this['sendOne'](_0x4bb1d7,_0x1e00f5);}}['sendOne'](_0x586e79,_0x34ed72){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x586e79]!==void 0x0)try{_0x34ed72(this['observers'][_0x586e79]);}catch(_0x364deb){typeof console<'u'&&console['error']&&console['error'](_0x364deb);}});}['close'](_0x43c7df){this['finalized']||(this['finalized']=!0x0,_0x43c7df!==void 0x0&&(this['finalError']=_0x43c7df),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x4c56ce,_0x46a340){if(typeof _0x4c56ce!='object'||_0x4c56ce===null)return!0x1;for(const _0x16e1b2 of _0x46a340)if(_0x16e1b2 in _0x4c56ce&&typeof _0x4c56ce[_0x16e1b2]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x2e06b4,_0x1d084b){return _0x2e06b4+'\x20failed:\x20'+_0x1d084b+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x4bea92){const _0x2b6983=[];let _0x17d2d5=0x0;for(let _0x1ee9b5=0x0;_0x1ee9b5<_0x4bea92['length'];_0x1ee9b5++){let _0x881895=_0x4bea92['charCodeAt'](_0x1ee9b5);if(_0x881895>=0xd800&&_0x881895<=0xdbff){const _0x82b665=_0x881895-0xd800;_0x1ee9b5++,f(_0x1ee9b5<_0x4bea92['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x3c970a=_0x4bea92['charCodeAt'](_0x1ee9b5)-0xdc00;_0x881895=0x10000+(_0x82b665<<0xa)+_0x3c970a;}_0x881895<0x80?_0x2b6983[_0x17d2d5++]=_0x881895:_0x881895<0x800?(_0x2b6983[_0x17d2d5++]=_0x881895>>0x6|0xc0,_0x2b6983[_0x17d2d5++]=_0x881895&0x3f|0x80):_0x881895<0x10000?(_0x2b6983[_0x17d2d5++]=_0x881895>>0xc|0xe0,_0x2b6983[_0x17d2d5++]=_0x881895>>0x6&0x3f|0x80,_0x2b6983[_0x17d2d5++]=_0x881895&0x3f|0x80):(_0x2b6983[_0x17d2d5++]=_0x881895>>0x12|0xf0,_0x2b6983[_0x17d2d5++]=_0x881895>>0xc&0x3f|0x80,_0x2b6983[_0x17d2d5++]=_0x881895>>0x6&0x3f|0x80,_0x2b6983[_0x17d2d5++]=_0x881895&0x3f|0x80);}return _0x2b6983;},On=function(_0x2161b6){let _0x4dfcc5=0x0;for(let _0x4a8453=0x0;_0x4a8453<_0x2161b6['length'];_0x4a8453++){const _0x32c96b=_0x2161b6['charCodeAt'](_0x4a8453);_0x32c96b<0x80?_0x4dfcc5++:_0x32c96b<0x800?_0x4dfcc5+=0x2:_0x32c96b>=0xd800&&_0x32c96b<=0xdbff?(_0x4dfcc5+=0x4,_0x4a8453++):_0x4dfcc5+=0x3;}return _0x4dfcc5;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x4dd024){return _0x4dd024&&_0x4dd024['_delegate']?_0x4dd024['_delegate']:_0x4dd024;}class Le{constructor(_0x3ca32d,_0x416e8e,_0x1f19e7){this['name']=_0x3ca32d,this['instanceFactory']=_0x416e8e,this['type']=_0x1f19e7,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x49fd88){return this['instantiationMode']=_0x49fd88,this;}['setMultipleInstances'](_0x31c5dc){return this['multipleInstances']=_0x31c5dc,this;}['setServiceProps'](_0x45d502){return this['serviceProps']=_0x45d502,this;}['setInstanceCreatedCallback'](_0x4d50f7){return this['onInstanceCreated']=_0x4d50f7,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x264863,_0x315c8d){this['name']=_0x264863,this['container']=_0x315c8d,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0xdd088e){const _0x1d134=this['normalizeInstanceIdentifier'](_0xdd088e);if(!this['instancesDeferred']['has'](_0x1d134)){const _0x401bf=new ot();if(this['instancesDeferred']['set'](_0x1d134,_0x401bf),this['isInitialized'](_0x1d134)||this['shouldAutoInitialize']())try{const _0x4cd005=this['getOrInitializeService']({'instanceIdentifier':_0x1d134});_0x4cd005&&_0x401bf['resolve'](_0x4cd005);}catch{}}return this['instancesDeferred']['get'](_0x1d134)['promise'];}['getImmediate'](_0x28e20b){const _0x50b6d=this['normalizeInstanceIdentifier'](_0x28e20b==null?void 0x0:_0x28e20b['identifier']),_0x4f2992=(_0x28e20b==null?void 0x0:_0x28e20b['optional'])??!0x1;if(this['isInitialized'](_0x50b6d)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x50b6d});}catch(_0x300856){if(_0x4f2992)return null;throw _0x300856;}else{if(_0x4f2992)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0xa902c6){if(_0xa902c6['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0xa902c6['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0xa902c6,!!this['shouldAutoInitialize']()){if(Nc(_0xa902c6))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x100b0b,_0x22e7fd]of this['instancesDeferred']['entries']()){const _0x96d481=this['normalizeInstanceIdentifier'](_0x100b0b);try{const _0x529dca=this['getOrInitializeService']({'instanceIdentifier':_0x96d481});_0x22e7fd['resolve'](_0x529dca);}catch{}}}}['clearInstance'](_0x1c8117=Ne){this['instancesDeferred']['delete'](_0x1c8117),this['instancesOptions']['delete'](_0x1c8117),this['instances']['delete'](_0x1c8117);}async['delete'](){const _0x336932=Array['from'](this['instances']['values']());await Promise['all']([..._0x336932['filter'](_0x13d2db=>'INTERNAL'in _0x13d2db)['map'](_0x4dd844=>_0x4dd844['INTERNAL']['delete']()),..._0x336932['filter'](_0x1d519b=>'_delete'in _0x1d519b)['map'](_0x545362=>_0x545362['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x9508ad=Ne){return this['instances']['has'](_0x9508ad);}['getOptions'](_0x2c6ce3=Ne){return this['instancesOptions']['get'](_0x2c6ce3)||{};}['initialize'](_0x23c89c={}){const {options:_0x3dd87c={}}=_0x23c89c,_0x2716c4=this['normalizeInstanceIdentifier'](_0x23c89c['instanceIdentifier']);if(this['isInitialized'](_0x2716c4))throw Error(this['name']+'('+_0x2716c4+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x1a47b9=this['getOrInitializeService']({'instanceIdentifier':_0x2716c4,'options':_0x3dd87c});for(const [_0x38546f,_0x3a2477]of this['instancesDeferred']['entries']()){const _0xee526d=this['normalizeInstanceIdentifier'](_0x38546f);_0x2716c4===_0xee526d&&_0x3a2477['resolve'](_0x1a47b9);}return _0x1a47b9;}['onInit'](_0x16ce27,_0x2ec3f2){const _0x4b3e4e=this['normalizeInstanceIdentifier'](_0x2ec3f2),_0x56609f=this['onInitCallbacks']['get'](_0x4b3e4e)??new Set();_0x56609f['add'](_0x16ce27),this['onInitCallbacks']['set'](_0x4b3e4e,_0x56609f);const _0x28d4b4=this['instances']['get'](_0x4b3e4e);return _0x28d4b4&&_0x16ce27(_0x28d4b4,_0x4b3e4e),()=>{_0x56609f['delete'](_0x16ce27);};}['invokeOnInitCallbacks'](_0x35b7a7,_0x36ae7e){const _0x5c1066=this['onInitCallbacks']['get'](_0x36ae7e);if(_0x5c1066){for(const _0x338213 of _0x5c1066)try{_0x338213(_0x35b7a7,_0x36ae7e);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x4f79b8,options:_0x29665e={}}){let _0x5e2195=this['instances']['get'](_0x4f79b8);if(!_0x5e2195&&this['component']&&(_0x5e2195=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x4f79b8),'options':_0x29665e}),this['instances']['set'](_0x4f79b8,_0x5e2195),this['instancesOptions']['set'](_0x4f79b8,_0x29665e),this['invokeOnInitCallbacks'](_0x5e2195,_0x4f79b8),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x4f79b8,_0x5e2195);}catch{}return _0x5e2195||null;}['normalizeInstanceIdentifier'](_0xb455b2=Ne){return this['component']?this['component']['multipleInstances']?_0xb455b2:Ne:_0xb455b2;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x322b61){return _0x322b61===Ne?void 0x0:_0x322b61;}function Nc(_0x5f1b70){return _0x5f1b70['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x5dc8ff){this['name']=_0x5dc8ff,this['providers']=new Map();}['addComponent'](_0x25ad1e){const _0x28a6bd=this['getProvider'](_0x25ad1e['name']);if(_0x28a6bd['isComponentSet']())throw new Error('Component\x20'+_0x25ad1e['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x28a6bd['setComponent'](_0x25ad1e);}['addOrOverwriteComponent'](_0x2c5cdf){this['getProvider'](_0x2c5cdf['name'])['isComponentSet']()&&this['providers']['delete'](_0x2c5cdf['name']),this['addComponent'](_0x2c5cdf);}['getProvider'](_0x530c77){if(this['providers']['has'](_0x530c77))return this['providers']['get'](_0x530c77);const _0x3ca1ca=new Ac(_0x530c77,this);return this['providers']['set'](_0x530c77,_0x3ca1ca),_0x3ca1ca;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x3062cf){_0x3062cf[_0x3062cf['DEBUG']=0x0]='DEBUG',_0x3062cf[_0x3062cf['VERBOSE']=0x1]='VERBOSE',_0x3062cf[_0x3062cf['INFO']=0x2]='INFO',_0x3062cf[_0x3062cf['WARN']=0x3]='WARN',_0x3062cf[_0x3062cf['ERROR']=0x4]='ERROR',_0x3062cf[_0x3062cf['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x33a64e,_0x22efcd,..._0x2a78e0)=>{if(_0x22efcd<_0x33a64e['logLevel'])return;const _0x544db4=new Date()['toISOString'](),_0x47df65=Mc[_0x22efcd];if(_0x47df65)console[_0x47df65]('['+_0x544db4+']\x20\x20'+_0x33a64e['name']+':',..._0x2a78e0);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x22efcd+')');};class Ui{constructor(_0x2456c0){this['name']=_0x2456c0,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x25704d){if(!(_0x25704d in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x25704d+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x25704d;}['setLogLevel'](_0x2a3e3d){this['_logLevel']=typeof _0x2a3e3d=='string'?Oc[_0x2a3e3d]:_0x2a3e3d;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x109a7c){if(typeof _0x109a7c!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x109a7c;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x54feaa){this['_userLogHandler']=_0x54feaa;}['debug'](..._0x2e0c2a){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x2e0c2a),this['_logHandler'](this,T['DEBUG'],..._0x2e0c2a);}['log'](..._0x37afd1){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x37afd1),this['_logHandler'](this,T['VERBOSE'],..._0x37afd1);}['info'](..._0x22093d){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x22093d),this['_logHandler'](this,T['INFO'],..._0x22093d);}['warn'](..._0x41dbe0){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x41dbe0),this['_logHandler'](this,T['WARN'],..._0x41dbe0);}['error'](..._0x4db4e0){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x4db4e0),this['_logHandler'](this,T['ERROR'],..._0x4db4e0);}}const xc=(_0x49a3bc,_0x4911e5)=>_0x4911e5['some'](_0x19ca72=>_0x49a3bc instanceof _0x19ca72);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x47d70c){const _0x5ff582=new Promise((_0x3ae80a,_0x1a29a3)=>{const _0x396a1f=()=>{_0x47d70c['removeEventListener']('success',_0x1564b7),_0x47d70c['removeEventListener']('error',_0x1075b7);},_0x1564b7=()=>{_0x3ae80a(_e(_0x47d70c['result'])),_0x396a1f();},_0x1075b7=()=>{_0x1a29a3(_0x47d70c['error']),_0x396a1f();};_0x47d70c['addEventListener']('success',_0x1564b7),_0x47d70c['addEventListener']('error',_0x1075b7);});return _0x5ff582['then'](_0x40ee70=>{_0x40ee70 instanceof IDBCursor&&Jr['set'](_0x40ee70,_0x47d70c);})['catch'](()=>{}),Wi['set'](_0x5ff582,_0x47d70c),_0x5ff582;}function Bc(_0x2c3587){if(di['has'](_0x2c3587))return;const _0x27ab42=new Promise((_0x422c2a,_0x1d1e79)=>{const _0x572f15=()=>{_0x2c3587['removeEventListener']('complete',_0x4d9709),_0x2c3587['removeEventListener']('error',_0x9f164a),_0x2c3587['removeEventListener']('abort',_0x9f164a);},_0x4d9709=()=>{_0x422c2a(),_0x572f15();},_0x9f164a=()=>{_0x1d1e79(_0x2c3587['error']||new DOMException('AbortError','AbortError')),_0x572f15();};_0x2c3587['addEventListener']('complete',_0x4d9709),_0x2c3587['addEventListener']('error',_0x9f164a),_0x2c3587['addEventListener']('abort',_0x9f164a);});di['set'](_0x2c3587,_0x27ab42);}let fi={'get'(_0x100827,_0x2929fe,_0x241f53){if(_0x100827 instanceof IDBTransaction){if(_0x2929fe==='done')return di['get'](_0x100827);if(_0x2929fe==='objectStoreNames')return _0x100827['objectStoreNames']||Xr['get'](_0x100827);if(_0x2929fe==='store')return _0x241f53['objectStoreNames'][0x1]?void 0x0:_0x241f53['objectStore'](_0x241f53['objectStoreNames'][0x0]);}return _e(_0x100827[_0x2929fe]);},'set'(_0x177d27,_0x2cf0b1,_0x2c3ea3){return _0x177d27[_0x2cf0b1]=_0x2c3ea3,!0x0;},'has'(_0x5039d2,_0x2a866d){return _0x5039d2 instanceof IDBTransaction&&(_0x2a866d==='done'||_0x2a866d==='store')?!0x0:_0x2a866d in _0x5039d2;}};function Vc(_0x20ad9f){fi=_0x20ad9f(fi);}function Hc(_0x527690){return _0x527690===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x15f03f,..._0x180e95){const _0x3a1b28=_0x527690['call'](Zn(this),_0x15f03f,..._0x180e95);return Xr['set'](_0x3a1b28,_0x15f03f['sort']?_0x15f03f['sort']():[_0x15f03f]),_e(_0x3a1b28);}:Uc()['includes'](_0x527690)?function(..._0x5ef760){return _0x527690['apply'](Zn(this),_0x5ef760),_e(Jr['get'](this));}:function(..._0x336d87){return _e(_0x527690['apply'](Zn(this),_0x336d87));};}function $c(_0x5048ba){return typeof _0x5048ba=='function'?Hc(_0x5048ba):(_0x5048ba instanceof IDBTransaction&&Bc(_0x5048ba),xc(_0x5048ba,Fc())?new Proxy(_0x5048ba,fi):_0x5048ba);}function _e(_0x5c9c17){if(_0x5c9c17 instanceof IDBRequest)return Wc(_0x5c9c17);if(Xn['has'](_0x5c9c17))return Xn['get'](_0x5c9c17);const _0x230e9a=$c(_0x5c9c17);return _0x230e9a!==_0x5c9c17&&(Xn['set'](_0x5c9c17,_0x230e9a),Wi['set'](_0x230e9a,_0x5c9c17)),_0x230e9a;}const Zn=_0x566824=>Wi['get'](_0x566824);function Gc(_0x31badd,_0x507e2c,{blocked:_0x1800a3,upgrade:_0x5ed9d2,blocking:_0x26c857,terminated:_0x3a94e4}={}){const _0x4b2a49=indexedDB['open'](_0x31badd,_0x507e2c),_0x48b872=_e(_0x4b2a49);return _0x5ed9d2&&_0x4b2a49['addEventListener']('upgradeneeded',_0x53a6d8=>{_0x5ed9d2(_e(_0x4b2a49['result']),_0x53a6d8['oldVersion'],_0x53a6d8['newVersion'],_e(_0x4b2a49['transaction']),_0x53a6d8);}),_0x1800a3&&_0x4b2a49['addEventListener']('blocked',_0x388d98=>_0x1800a3(_0x388d98['oldVersion'],_0x388d98['newVersion'],_0x388d98)),_0x48b872['then'](_0x20ca82=>{_0x3a94e4&&_0x20ca82['addEventListener']('close',()=>_0x3a94e4()),_0x26c857&&_0x20ca82['addEventListener']('versionchange',_0x5e92e8=>_0x26c857(_0x5e92e8['oldVersion'],_0x5e92e8['newVersion'],_0x5e92e8));})['catch'](()=>{}),_0x48b872;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x371bc5,_0xbd0d7){if(!(_0x371bc5 instanceof IDBDatabase&&!(_0xbd0d7 in _0x371bc5)&&typeof _0xbd0d7=='string'))return;if(ei['get'](_0xbd0d7))return ei['get'](_0xbd0d7);const _0x5cb97b=_0xbd0d7['replace'](/FromIndex$/,''),_0x305611=_0xbd0d7!==_0x5cb97b,_0x44cea3=zc['includes'](_0x5cb97b);if(!(_0x5cb97b in(_0x305611?IDBIndex:IDBObjectStore)['prototype'])||!(_0x44cea3||qc['includes'](_0x5cb97b)))return;const _0x1ac16c=async function(_0x4795fc,..._0x10291d){const _0x40209c=this['transaction'](_0x4795fc,_0x44cea3?'readwrite':'readonly');let _0x176618=_0x40209c['store'];return _0x305611&&(_0x176618=_0x176618['index'](_0x10291d['shift']())),(await Promise['all']([_0x176618[_0x5cb97b](..._0x10291d),_0x44cea3&&_0x40209c['done']]))[0x0];};return ei['set'](_0xbd0d7,_0x1ac16c),_0x1ac16c;}Vc(_0x23f639=>({..._0x23f639,'get':(_0x45a1bc,_0x180796,_0x5f49c)=>Ls(_0x45a1bc,_0x180796)||_0x23f639['get'](_0x45a1bc,_0x180796,_0x5f49c),'has':(_0x50f8fd,_0x7624fe)=>!!Ls(_0x50f8fd,_0x7624fe)||_0x23f639['has'](_0x50f8fd,_0x7624fe)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x5034a5){this['container']=_0x5034a5;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x489e97=>{if(Kc(_0x489e97)){const _0x13bff4=_0x489e97['getImmediate']();return _0x13bff4['library']+'/'+_0x13bff4['version'];}else return null;})['filter'](_0x2cdb13=>_0x2cdb13)['join']('\x20');}}function Kc(_0x345dce){const _0x1f2f34=_0x345dce['getComponent']();return(_0x1f2f34==null?void 0x0:_0x1f2f34['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x3112dd,_0x133699){try{_0x3112dd['container']['addComponent'](_0x133699);}catch(_0x4d5ba4){oe['debug']('Component\x20'+_0x133699['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x3112dd['name'],_0x4d5ba4);}}function Ze(_0x7d123f){const _0x1b3e1b=_0x7d123f['name'];if(mi['has'](_0x1b3e1b))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x1b3e1b+'.'),!0x1;mi['set'](_0x1b3e1b,_0x7d123f);for(const _0x3f1195 of xe['values']())Fs(_0x3f1195,_0x7d123f);for(const _0x5b76ee of gi['values']())Fs(_0x5b76ee,_0x7d123f);return!0x0;}function Bi(_0x56a45a,_0x1c6a38){const _0x4cd860=_0x56a45a['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x4cd860&&_0x4cd860['triggerHeartbeat'](),_0x56a45a['container']['getProvider'](_0x1c6a38);}function $(_0x40b595){return _0x40b595==null?!0x1:_0x40b595['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x4db7f5,_0x71d41,_0x492f28){this['_isDeleted']=!0x1,this['_options']={..._0x4db7f5},this['_config']={..._0x71d41},this['_name']=_0x71d41['name'],this['_automaticDataCollectionEnabled']=_0x71d41['automaticDataCollectionEnabled'],this['_container']=_0x492f28,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x47ec39){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x47ec39;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x22236a){this['_isDeleted']=_0x22236a;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x1348cb,_0x3be203={}){let _0x40ce04=_0x1348cb;typeof _0x3be203!='object'&&(_0x3be203={'name':_0x3be203});const _0x4f63b8={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x3be203},_0x35c257=_0x4f63b8['name'];if(typeof _0x35c257!='string'||!_0x35c257)throw ge['create']('bad-app-name',{'appName':String(_0x35c257)});if(_0x40ce04||(_0x40ce04=qr()),!_0x40ce04)throw ge['create']('no-options');const _0x4d9277=xe['get'](_0x35c257);if(_0x4d9277){if(Me(_0x40ce04,_0x4d9277['options'])&&Me(_0x4f63b8,_0x4d9277['config']))return _0x4d9277;throw ge['create']('duplicate-app',{'appName':_0x35c257});}const _0x340f6d=new Pc(_0x35c257);for(const _0x14cca5 of mi['values']())_0x340f6d['addComponent'](_0x14cca5);const _0x4a0a27=new Tl(_0x40ce04,_0x4f63b8,_0x340f6d);return xe['set'](_0x35c257,_0x4a0a27),_0x4a0a27;}function Zr(_0x32abe5=_i){const _0x550ac2=xe['get'](_0x32abe5);if(!_0x550ac2&&_0x32abe5===_i&&qr())return Sl();if(!_0x550ac2)throw ge['create']('no-app',{'appName':_0x32abe5});return _0x550ac2;}function f_(){return Array['from'](xe['values']());}async function p_(_0x1210a3){let _0x51e5da=!0x1;const _0xd98518=_0x1210a3['name'];xe['has'](_0xd98518)?(_0x51e5da=!0x0,xe['delete'](_0xd98518)):gi['has'](_0xd98518)&&_0x1210a3['decRefCount']()<=0x0&&(gi['delete'](_0xd98518),_0x51e5da=!0x0),_0x51e5da&&(await Promise['all'](_0x1210a3['container']['getProviders']()['map'](_0x4ebe89=>_0x4ebe89['delete']())),_0x1210a3['isDeleted']=!0x0);}function me(_0x105826,_0x5c1e67,_0xfc6d3b){let _0x3fac2e=wl[_0x105826]??_0x105826;_0xfc6d3b&&(_0x3fac2e+='-'+_0xfc6d3b);const _0xb44742=_0x3fac2e['match'](/\s|\//),_0x30ce41=_0x5c1e67['match'](/\s|\//);if(_0xb44742||_0x30ce41){const _0x111c24=['Unable\x20to\x20register\x20library\x20\x22'+_0x3fac2e+'\x22\x20with\x20version\x20\x22'+_0x5c1e67+'\x22:'];_0xb44742&&_0x111c24['push']('library\x20name\x20\x22'+_0x3fac2e+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0xb44742&&_0x30ce41&&_0x111c24['push']('and'),_0x30ce41&&_0x111c24['push']('version\x20name\x20\x22'+_0x5c1e67+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x111c24['join']('\x20'));return;}Ze(new Le(_0x3fac2e+'-version',()=>({'library':_0x3fac2e,'version':_0x5c1e67}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0xf57fa3,_0x541a58)=>{switch(_0x541a58){case 0x0:try{_0xf57fa3['createObjectStore'](kt);}catch(_0xd0b4fc){console['warn'](_0xd0b4fc);}}}})['catch'](_0x3b6d22=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x3b6d22['message']});})),ti;}async function Al(_0x537fa3){try{const _0x953c80=(await eo())['transaction'](kt),_0x481c6e=await _0x953c80['objectStore'](kt)['get'](to(_0x537fa3));return await _0x953c80['done'],_0x481c6e;}catch(_0x31afb2){if(_0x31afb2 instanceof Se)oe['warn'](_0x31afb2['message']);else{const _0x542ee4=ge['create']('idb-get',{'originalErrorMessage':_0x31afb2==null?void 0x0:_0x31afb2['message']});oe['warn'](_0x542ee4['message']);}}}async function Us(_0x54fc6d,_0x5d83bb){try{const _0x3c5c68=(await eo())['transaction'](kt,'readwrite');await _0x3c5c68['objectStore'](kt)['put'](_0x5d83bb,to(_0x54fc6d)),await _0x3c5c68['done'];}catch(_0x223027){if(_0x223027 instanceof Se)oe['warn'](_0x223027['message']);else{const _0x152124=ge['create']('idb-set',{'originalErrorMessage':_0x223027==null?void 0x0:_0x223027['message']});oe['warn'](_0x152124['message']);}}}function to(_0x4efe41){return _0x4efe41['name']+'!'+_0x4efe41['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x1b37ec){this['container']=_0x1b37ec,this['_heartbeatsCache']=null;const _0x3c392b=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x3c392b),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x2d63eb=>(this['_heartbeatsCache']=_0x2d63eb,_0x2d63eb));}async['triggerHeartbeat'](){var _0x3a1b05,_0x428251;try{const _0x205e6e=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x22dc22=Ws();if(((_0x3a1b05=this['_heartbeatsCache'])==null?void 0x0:_0x3a1b05['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x428251=this['_heartbeatsCache'])==null?void 0x0:_0x428251['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x22dc22||this['_heartbeatsCache']['heartbeats']['some'](_0x1408cb=>_0x1408cb['date']===_0x22dc22))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x22dc22,'agent':_0x205e6e}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x34b017=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x34b017,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x5c25ae){oe['warn'](_0x5c25ae);}}async['getHeartbeatsHeader'](){var _0x313999;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x313999=this['_heartbeatsCache'])==null?void 0x0:_0x313999['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x576a54=Ws(),{heartbeatsToSend:_0x285afe,unsentEntries:_0x518066}=Ol(this['_heartbeatsCache']['heartbeats']),_0x377139=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x285afe}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x576a54,_0x518066['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x518066,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x377139;}catch(_0x17f414){return oe['warn'](_0x17f414),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x1357b8,_0x51a0fe=kl){const _0x1d5ae1=[];let _0x298b77=_0x1357b8['slice']();for(const _0xcaa228 of _0x1357b8){const _0x29f613=_0x1d5ae1['find'](_0x341b62=>_0x341b62['agent']===_0xcaa228['agent']);if(_0x29f613){if(_0x29f613['dates']['push'](_0xcaa228['date']),Bs(_0x1d5ae1)>_0x51a0fe){_0x29f613['dates']['pop']();break;}}else{if(_0x1d5ae1['push']({'agent':_0xcaa228['agent'],'dates':[_0xcaa228['date']]}),Bs(_0x1d5ae1)>_0x51a0fe){_0x1d5ae1['pop']();break;}}_0x298b77=_0x298b77['slice'](0x1);}return{'heartbeatsToSend':_0x1d5ae1,'unsentEntries':_0x298b77};}class Dl{constructor(_0x1d055f){this['app']=_0x1d055f,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0xf3bcd8=await Al(this['app']);return _0xf3bcd8!=null&&_0xf3bcd8['heartbeats']?_0xf3bcd8:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x5f3250){if(await this['_canUseIndexedDBPromise']){const _0x4bba99=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x5f3250['lastSentHeartbeatDate']??_0x4bba99['lastSentHeartbeatDate'],'heartbeats':_0x5f3250['heartbeats']});}else return;}async['add'](_0x3df14a){if(await this['_canUseIndexedDBPromise']){const _0x1bd9ad=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x3df14a['lastSentHeartbeatDate']??_0x1bd9ad['lastSentHeartbeatDate'],'heartbeats':[..._0x1bd9ad['heartbeats'],..._0x3df14a['heartbeats']]});}else return;}}function Bs(_0x3eaf34){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x3eaf34}))['length'];}function Ml(_0x342f8b){if(_0x342f8b['length']===0x0)return-0x1;let _0x371260=0x0,_0x49c7ad=_0x342f8b[0x0]['date'];for(let _0x40c212=0x1;_0x40c212<_0x342f8b['length'];_0x40c212++)_0x342f8b[_0x40c212]['date']<_0x49c7ad&&(_0x49c7ad=_0x342f8b[_0x40c212]['date'],_0x371260=_0x40c212);return _0x371260;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x222e93){Ze(new Le('platform-logger',_0x45d0c1=>new jc(_0x45d0c1),'PRIVATE')),Ze(new Le('heartbeat',_0x4f8233=>new Pl(_0x4f8233),'PRIVATE')),me(pi,xs,_0x222e93),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x3d0000){no=_0x3d0000;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x3f5ebe){this['domStorage_']=_0x3f5ebe,this['prefix_']='firebase:';}['set'](_0x356aeb,_0x40378c){_0x40378c==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x356aeb)):this['domStorage_']['setItem'](this['prefixedName_'](_0x356aeb),O(_0x40378c));}['get'](_0x538ae8){const _0x439971=this['domStorage_']['getItem'](this['prefixedName_'](_0x538ae8));return _0x439971==null?null:At(_0x439971);}['remove'](_0x18ce6d){this['domStorage_']['removeItem'](this['prefixedName_'](_0x18ce6d));}['prefixedName_'](_0x15271a){return this['prefix_']+_0x15271a;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x278be6,_0xb344c3){_0xb344c3==null?delete this['cache_'][_0x278be6]:this['cache_'][_0x278be6]=_0xb344c3;}['get'](_0x5bc121){return J(this['cache_'],_0x5bc121)?this['cache_'][_0x5bc121]:null;}['remove'](_0x588d96){delete this['cache_'][_0x588d96];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x4444df){try{if(typeof window<'u'&&typeof window[_0x4444df]<'u'){const _0x36867a=window[_0x4444df];return _0x36867a['setItem']('firebase:sentinel','cache'),_0x36867a['removeItem']('firebase:sentinel'),new Wl(_0x36867a);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x518e70=0x1;return function(){return _0x518e70++;};}()),ro=function(_0x1fb0a2){const _0x501cce=Rc(_0x1fb0a2),_0x2ba377=new Cc();_0x2ba377['update'](_0x501cce);const _0x14bb59=_0x2ba377['digest']();return Li['encodeByteArray'](_0x14bb59);},Vt=function(..._0x15259c){let _0x39612b='';for(let _0x2e7e71=0x0;_0x2e7e71<_0x15259c['length'];_0x2e7e71++){const _0x384b50=_0x15259c[_0x2e7e71];Array['isArray'](_0x384b50)||_0x384b50&&typeof _0x384b50=='object'&&typeof _0x384b50['length']=='number'?_0x39612b+=Vt['apply'](null,_0x384b50):typeof _0x384b50=='object'?_0x39612b+=O(_0x384b50):_0x39612b+=_0x384b50,_0x39612b+='\x20';}return _0x39612b;};let wt=null,Gs=!0x0;const Hl=function(_0x1b76a4,_0x3c159e){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x2c56fa){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x56488a=Vt['apply'](null,_0x2c56fa);wt(_0x56488a);}},Ht=function(_0x54670d){return function(..._0x13c0ad){L(_0x54670d,..._0x13c0ad);};},yi=function(..._0x320027){const _0x2a1270='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x320027);Ye['error'](_0x2a1270);},ae=function(..._0x222fc4){const _0x4695ee='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x222fc4);throw Ye['error'](_0x4695ee),new Error(_0x4695ee);},U=function(..._0x451a3d){const _0x1b2144='FIREBASE\x20WARNING:\x20'+Vt(..._0x451a3d);Ye['warn'](_0x1b2144);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x588a9d){return typeof _0x588a9d=='number'&&(_0x588a9d!==_0x588a9d||_0x588a9d===Number['POSITIVE_INFINITY']||_0x588a9d===Number['NEGATIVE_INFINITY']);},Gl=function(_0x2a32a9){if(document['readyState']==='complete')_0x2a32a9();else{let _0x35eec3=!0x1;const _0x1ee14d=function(){if(!document['body']){setTimeout(_0x1ee14d,Math['floor'](0xa));return;}_0x35eec3||(_0x35eec3=!0x0,_0x2a32a9());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x1ee14d,!0x1),window['addEventListener']('load',_0x1ee14d,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x1ee14d();}),window['attachEvent']('onload',_0x1ee14d));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x2053c1,_0x2e3637){if(_0x2053c1===_0x2e3637)return 0x0;if(_0x2053c1===Fe||_0x2e3637===Ie)return-0x1;if(_0x2e3637===Fe||_0x2053c1===Ie)return 0x1;{const _0x16eeb0=qs(_0x2053c1),_0x1134e6=qs(_0x2e3637);return _0x16eeb0!==null?_0x1134e6!==null?_0x16eeb0-_0x1134e6===0x0?_0x2053c1['length']-_0x2e3637['length']:_0x16eeb0-_0x1134e6:-0x1:_0x1134e6!==null?0x1:_0x2053c1<_0x2e3637?-0x1:0x1;}},ql=function(_0x3f233a,_0x1d0152){return _0x3f233a===_0x1d0152?0x0:_0x3f233a<_0x1d0152?-0x1:0x1;},_t=function(_0x48f5e3,_0x30271c){if(_0x30271c&&_0x48f5e3 in _0x30271c)return _0x30271c[_0x48f5e3];throw new Error('Missing\x20required\x20key\x20('+_0x48f5e3+')\x20in\x20object:\x20'+O(_0x30271c));},Hi=function(_0xc6065f){if(typeof _0xc6065f!='object'||_0xc6065f===null)return O(_0xc6065f);const _0x415e6b=[];for(const _0x2aa4d8 in _0xc6065f)_0x415e6b['push'](_0x2aa4d8);_0x415e6b['sort']();let _0x5e880f='{';for(let _0x576419=0x0;_0x576419<_0x415e6b['length'];_0x576419++)_0x576419!==0x0&&(_0x5e880f+=','),_0x5e880f+=O(_0x415e6b[_0x576419]),_0x5e880f+=':',_0x5e880f+=Hi(_0xc6065f[_0x415e6b[_0x576419]]);return _0x5e880f+='}',_0x5e880f;},oo=function(_0x263808,_0x1a499d){const _0x1f1eee=_0x263808['length'];if(_0x1f1eee<=_0x1a499d)return[_0x263808];const _0x5e7080=[];for(let _0x3bccf2=0x0;_0x3bccf2<_0x1f1eee;_0x3bccf2+=_0x1a499d)_0x3bccf2+_0x1a499d>_0x1f1eee?_0x5e7080['push'](_0x263808['substring'](_0x3bccf2,_0x1f1eee)):_0x5e7080['push'](_0x263808['substring'](_0x3bccf2,_0x3bccf2+_0x1a499d));return _0x5e7080;};function x(_0x181cf4,_0x547927){for(const _0x2123ec in _0x181cf4)_0x181cf4['hasOwnProperty'](_0x2123ec)&&_0x547927(_0x2123ec,_0x181cf4[_0x2123ec]);}const ao=function(_0x305fa0){f(!Vi(_0x305fa0),'Invalid\x20JSON\x20number');const _0x11aa6a=0xb,_0x1a89b8=0x34,_0x5025d2=(0x1<<_0x11aa6a-0x1)-0x1;let _0x2477f6,_0x10dd54,_0x343493,_0x10de8f,_0x2b7ef2;_0x305fa0===0x0?(_0x10dd54=0x0,_0x343493=0x0,_0x2477f6=0x1/_0x305fa0===-0x1/0x0?0x1:0x0):(_0x2477f6=_0x305fa0<0x0,_0x305fa0=Math['abs'](_0x305fa0),_0x305fa0>=Math['pow'](0x2,0x1-_0x5025d2)?(_0x10de8f=Math['min'](Math['floor'](Math['log'](_0x305fa0)/Math['LN2']),_0x5025d2),_0x10dd54=_0x10de8f+_0x5025d2,_0x343493=Math['round'](_0x305fa0*Math['pow'](0x2,_0x1a89b8-_0x10de8f)-Math['pow'](0x2,_0x1a89b8))):(_0x10dd54=0x0,_0x343493=Math['round'](_0x305fa0/Math['pow'](0x2,0x1-_0x5025d2-_0x1a89b8))));const _0x372207=[];for(_0x2b7ef2=_0x1a89b8;_0x2b7ef2;_0x2b7ef2-=0x1)_0x372207['push'](_0x343493%0x2?0x1:0x0),_0x343493=Math['floor'](_0x343493/0x2);for(_0x2b7ef2=_0x11aa6a;_0x2b7ef2;_0x2b7ef2-=0x1)_0x372207['push'](_0x10dd54%0x2?0x1:0x0),_0x10dd54=Math['floor'](_0x10dd54/0x2);_0x372207['push'](_0x2477f6?0x1:0x0),_0x372207['reverse']();const _0xa22c33=_0x372207['join']('');let _0x152381='';for(_0x2b7ef2=0x0;_0x2b7ef2<0x40;_0x2b7ef2+=0x8){let _0x2c2d48=parseInt(_0xa22c33['substr'](_0x2b7ef2,0x8),0x2)['toString'](0x10);_0x2c2d48['length']===0x1&&(_0x2c2d48='0'+_0x2c2d48),_0x152381=_0x152381+_0x2c2d48;}return _0x152381['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x782c7a,_0x118412){let _0x5e898e='Unknown\x20Error';_0x782c7a==='too_big'?_0x5e898e='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x782c7a==='permission_denied'?_0x5e898e='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x782c7a==='unavailable'&&(_0x5e898e='The\x20service\x20is\x20unavailable');const _0x256f3e=new Error(_0x782c7a+'\x20at\x20'+_0x118412['_path']['toString']()+':\x20'+_0x5e898e);return _0x256f3e['code']=_0x782c7a['toUpperCase'](),_0x256f3e;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x18bbf5){if(Yl['test'](_0x18bbf5)){const _0x56b40d=Number(_0x18bbf5);if(_0x56b40d>=Ql&&_0x56b40d<=Jl)return _0x56b40d;}return null;},ht=function(_0x328846){try{_0x328846();}catch(_0x2ef46e){setTimeout(()=>{const _0x16e9dd=_0x2ef46e['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x16e9dd),_0x2ef46e;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x32fc8b,_0x18124f){const _0x449699=setTimeout(_0x32fc8b,_0x18124f);return typeof _0x449699=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x449699):typeof _0x449699=='object'&&_0x449699['unref']&&_0x449699['unref'](),_0x449699;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x18e727,_0x24a16a){this['appCheckProvider']=_0x24a16a,this['appName']=_0x18e727['name'],$(_0x18e727)&&_0x18e727['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x18e727['settings']['appCheckToken']),this['appCheck']=_0x24a16a==null?void 0x0:_0x24a16a['getImmediate']({'optional':!0x0}),this['appCheck']||_0x24a16a==null||_0x24a16a['get']()['then'](_0x2e064c=>this['appCheck']=_0x2e064c);}['getToken'](_0x2d1a73){if(this['serverAppAppCheckToken']){if(_0x2d1a73)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x2d1a73):new Promise((_0x4ff464,_0x13d27b)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x2d1a73)['then'](_0x4ff464,_0x13d27b):_0x4ff464(null);},0x0);});}['addTokenChangeListener'](_0x31f37a){var _0x2cc9ac;(_0x2cc9ac=this['appCheckProvider'])==null||_0x2cc9ac['get']()['then'](_0x258227=>_0x258227['addTokenListener'](_0x31f37a));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x480692,_0x3e79e2,_0x1dd239){this['appName_']=_0x480692,this['firebaseOptions_']=_0x3e79e2,this['authProvider_']=_0x1dd239,this['auth_']=null,this['auth_']=_0x1dd239['getImmediate']({'optional':!0x0}),this['auth_']||_0x1dd239['onInit'](_0x376bde=>this['auth_']=_0x376bde);}['getToken'](_0x2eb2ee){return this['auth_']?this['auth_']['getToken'](_0x2eb2ee)['catch'](_0x297189=>_0x297189&&_0x297189['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x297189)):new Promise((_0xefeaff,_0x2907bf)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x2eb2ee)['then'](_0xefeaff,_0x2907bf):_0xefeaff(null);},0x0);});}['addTokenChangeListener'](_0x2089b7){this['auth_']?this['auth_']['addAuthTokenListener'](_0x2089b7):this['authProvider_']['get']()['then'](_0x5ce974=>_0x5ce974['addAuthTokenListener'](_0x2089b7));}['removeTokenChangeListener'](_0x1b3776){this['authProvider_']['get']()['then'](_0x41caa2=>_0x41caa2['removeAuthTokenListener'](_0x1b3776));}['notifyForInvalidToken'](){let _0x1a9f77='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x1a9f77+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x1a9f77+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x1a9f77+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x1a9f77);}}class nn{constructor(_0x4008d7){this['accessToken']=_0x4008d7;}['getToken'](_0x36b3cb){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x4fae32){_0x4fae32(this['accessToken']);}['removeTokenChangeListener'](_0x2ab34b){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x59514a,_0x4b1044,_0x119a26,_0x1bd4e6,_0x587f88=!0x1,_0x5491a8='',_0x4b1caf=!0x1,_0x4ef7af=!0x1,_0x1f8969=null){this['secure']=_0x4b1044,this['namespace']=_0x119a26,this['webSocketOnly']=_0x1bd4e6,this['nodeAdmin']=_0x587f88,this['persistenceKey']=_0x5491a8,this['includeNamespaceInQueryParams']=_0x4b1caf,this['isUsingEmulator']=_0x4ef7af,this['emulatorOptions']=_0x1f8969,this['_host']=_0x59514a['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x59514a)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x4ace5e){_0x4ace5e!==this['internalHost']&&(this['internalHost']=_0x4ace5e,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x21812e=this['toURLString']();return this['persistenceKey']&&(_0x21812e+='<'+this['persistenceKey']+'>'),_0x21812e;}['toURLString'](){const _0x5de27b=this['secure']?'https://':'http://',_0x2883a1=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x5de27b+this['host']+'/'+_0x2883a1;}}function th(_0x5d40d5){return _0x5d40d5['host']!==_0x5d40d5['internalHost']||_0x5d40d5['isCustomHost']()||_0x5d40d5['includeNamespaceInQueryParams'];}function vo(_0x18491a,_0x2312c5,_0x2ffd38){f(typeof _0x2312c5=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x2ffd38=='object','typeof\x20params\x20must\x20==\x20object');let _0xe96d73;if(_0x2312c5===go)_0xe96d73=(_0x18491a['secure']?'wss://':'ws://')+_0x18491a['internalHost']+'/.ws?';else{if(_0x2312c5===mo)_0xe96d73=(_0x18491a['secure']?'https://':'http://')+_0x18491a['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x2312c5);}th(_0x18491a)&&(_0x2ffd38['ns']=_0x18491a['namespace']);const _0x4f4d90=[];return x(_0x2ffd38,(_0x4ed950,_0x20c578)=>{_0x4f4d90['push'](_0x4ed950+'='+_0x20c578);}),_0xe96d73+_0x4f4d90['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x493e56,_0x471120=0x1){J(this['counters_'],_0x493e56)||(this['counters_'][_0x493e56]=0x0),this['counters_'][_0x493e56]+=_0x471120;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x30410d){const _0x1b0fc0=_0x30410d['toString']();return ni[_0x1b0fc0]||(ni[_0x1b0fc0]=new nh()),ni[_0x1b0fc0];}function ih(_0x3c9bb0,_0x3e949e){const _0x4261dd=_0x3c9bb0['toString']();return ii[_0x4261dd]||(ii[_0x4261dd]=_0x3e949e()),ii[_0x4261dd];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x24387e){this['onMessage_']=_0x24387e,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x50a346,_0x391e4e){this['closeAfterResponse']=_0x50a346,this['onClose']=_0x391e4e,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x2a6cb6,_0x4452ab){for(this['pendingResponses'][_0x2a6cb6]=_0x4452ab;this['pendingResponses'][this['currentResponseNum']];){const _0x196f3e=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0xf7d09e=0x0;_0xf7d09e<_0x196f3e['length'];++_0xf7d09e)_0x196f3e[_0xf7d09e]&&ht(()=>{this['onMessage_'](_0x196f3e[_0xf7d09e]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x550e18,_0x43d355,_0x29b260,_0x458bc8,_0x3e1f54,_0x40367c,_0xa1bcb4){this['connId']=_0x550e18,this['repoInfo']=_0x43d355,this['applicationId']=_0x29b260,this['appCheckToken']=_0x458bc8,this['authToken']=_0x3e1f54,this['transportSessionId']=_0x40367c,this['lastSessionId']=_0xa1bcb4,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x550e18),this['stats_']=Gi(_0x43d355),this['urlFn']=_0xff3142=>(this['appCheckToken']&&(_0xff3142[vi]=this['appCheckToken']),vo(_0x43d355,mo,_0xff3142));}['open'](_0x472b42,_0x46b76b){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x46b76b,this['myPacketOrderer']=new sh(_0x472b42),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x6c8c9a)=>{const [_0x4ebfc8,_0x38ef35,_0x3d2b76,_0x56a306,_0x46490c]=_0x6c8c9a;if(this['incrementIncomingBytes_'](_0x6c8c9a),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x4ebfc8===zs)this['id']=_0x38ef35,this['password']=_0x3d2b76;else{if(_0x4ebfc8===rh)_0x38ef35?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x38ef35,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x4ebfc8);}}},(..._0x576e1a)=>{const [_0x116709,_0x3cffb2]=_0x576e1a;this['incrementIncomingBytes_'](_0x576e1a),this['myPacketOrderer']['handleResponse'](_0x116709,_0x3cffb2);},()=>{this['onClosed_']();},this['urlFn']);const _0x4b8c68={};_0x4b8c68[zs]='t',_0x4b8c68[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x4b8c68[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x4b8c68[co]=$i,this['transportSessionId']&&(_0x4b8c68[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x4b8c68[po]=this['lastSessionId']),this['applicationId']&&(_0x4b8c68[_o]=this['applicationId']),this['appCheckToken']&&(_0x4b8c68[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x4b8c68[ho]=uo);const _0x503249=this['urlFn'](_0x4b8c68);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x503249),this['scriptTagHolder']['addTag'](_0x503249,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x2e8165){const _0x5344fa=O(_0x2e8165);this['bytesSent']+=_0x5344fa['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5344fa['length']);const _0x4d67bd=Hr(_0x5344fa),_0x31486c=oo(_0x4d67bd,fh);for(let _0x18630e=0x0;_0x18630e<_0x31486c['length'];_0x18630e++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x31486c['length'],_0x31486c[_0x18630e]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x7ee618,_0x1a470a){this['myDisconnFrame']=document['createElement']('iframe');const _0x18f836={};_0x18f836[dh]='t',_0x18f836[Eo]=_0x7ee618,_0x18f836[Io]=_0x1a470a,this['myDisconnFrame']['src']=this['urlFn'](_0x18f836),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x1167b3){const _0x3d40ba=O(_0x1167b3)['length'];this['bytesReceived']+=_0x3d40ba,this['stats_']['incrementCounter']('bytes_received',_0x3d40ba);}}class qi{constructor(_0x5aca04,_0x2d0635,_0x59ad31,_0x54a33b){this['onDisconnect']=_0x59ad31,this['urlFn']=_0x54a33b,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x5aca04,window[ah+this['uniqueCallbackIdentifier']]=_0x2d0635,this['myIFrame']=qi['createIFrame_']();let _0x3eff7a='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x3eff7a='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x2059ec='<html><body>'+_0x3eff7a+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x2059ec),this['myIFrame']['doc']['close']();}catch(_0x16f68f){L('frame\x20writing\x20exception'),_0x16f68f['stack']&&L(_0x16f68f['stack']),L(_0x16f68f);}}}static['createIFrame_'](){const _0x18a349=document['createElement']('iframe');if(_0x18a349['style']['display']='none',document['body']){document['body']['appendChild'](_0x18a349);try{_0x18a349['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0xa3902f=document['domain'];_0x18a349['src']='javascript:void((function(){document.open();document.domain=\x27'+_0xa3902f+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x18a349['contentDocument']?_0x18a349['doc']=_0x18a349['contentDocument']:_0x18a349['contentWindow']?_0x18a349['doc']=_0x18a349['contentWindow']['document']:_0x18a349['document']&&(_0x18a349['doc']=_0x18a349['document']),_0x18a349;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x48fa93=this['onDisconnect'];_0x48fa93&&(this['onDisconnect']=null,_0x48fa93());}['startLongPoll'](_0x402c6c,_0x39a283){for(this['myID']=_0x402c6c,this['myPW']=_0x39a283,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x4198ad={};_0x4198ad[Eo]=this['myID'],_0x4198ad[Io]=this['myPW'],_0x4198ad[wo]=this['currentSerial'];let _0x342c70=this['urlFn'](_0x4198ad),_0x12687f='',_0x3479e0=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x12687f['length']<=Co;){const _0x582321=this['pendingSegs']['shift']();_0x12687f=_0x12687f+'&'+lh+_0x3479e0+'='+_0x582321['seg']+'&'+hh+_0x3479e0+'='+_0x582321['ts']+'&'+uh+_0x3479e0+'='+_0x582321['d'],_0x3479e0++;}return _0x342c70=_0x342c70+_0x12687f,this['addLongPollTag_'](_0x342c70,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x3f020d,_0x4a711b,_0x4b226f){this['pendingSegs']['push']({'seg':_0x3f020d,'ts':_0x4a711b,'d':_0x4b226f}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x2166f6,_0x173163){this['outstandingRequests']['add'](_0x173163);const _0x80ef40=()=>{this['outstandingRequests']['delete'](_0x173163),this['newRequest_']();},_0x5780e1=setTimeout(_0x80ef40,Math['floor'](ph)),_0x3f0ea9=()=>{clearTimeout(_0x5780e1),_0x80ef40();};this['addTag'](_0x2166f6,_0x3f0ea9);}['addTag'](_0x4686f6,_0x29c8f3){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x5acc1c=this['myIFrame']['doc']['createElement']('script');_0x5acc1c['type']='text/javascript',_0x5acc1c['async']=!0x0,_0x5acc1c['src']=_0x4686f6,_0x5acc1c['onload']=_0x5acc1c['onreadystatechange']=function(){const _0x406706=_0x5acc1c['readyState'];(!_0x406706||_0x406706==='loaded'||_0x406706==='complete')&&(_0x5acc1c['onload']=_0x5acc1c['onreadystatechange']=null,_0x5acc1c['parentNode']&&_0x5acc1c['parentNode']['removeChild'](_0x5acc1c),_0x29c8f3());},_0x5acc1c['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x4686f6),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x5acc1c);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x45c0c3,_0x512616,_0x3cf2b6,_0x318ee5,_0x10ce5a,_0x639470,_0x4c09a8){this['connId']=_0x45c0c3,this['applicationId']=_0x3cf2b6,this['appCheckToken']=_0x318ee5,this['authToken']=_0x10ce5a,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x512616),this['connURL']=z['connectionURL_'](_0x512616,_0x639470,_0x4c09a8,_0x318ee5,_0x3cf2b6),this['nodeAdmin']=_0x512616['nodeAdmin'];}static['connectionURL_'](_0x5f3a2a,_0x4d0160,_0x59f12a,_0x4f43ad,_0x4efff6){const _0x2eb549={};return _0x2eb549[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x2eb549[ho]=uo),_0x4d0160&&(_0x2eb549[lo]=_0x4d0160),_0x59f12a&&(_0x2eb549[po]=_0x59f12a),_0x4f43ad&&(_0x2eb549[vi]=_0x4f43ad),_0x4efff6&&(_0x2eb549[_o]=_0x4efff6),vo(_0x5f3a2a,go,_0x2eb549);}['open'](_0x47f25d,_0x4761c9){this['onDisconnect']=_0x4761c9,this['onMessage']=_0x47f25d,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x4e9071;_c(),this['mySock']=new un(this['connURL'],[],_0x4e9071);}catch(_0x37e401){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x4b41a7=_0x37e401['message']||_0x37e401['data'];_0x4b41a7&&this['log_'](_0x4b41a7),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x5dd6d3=>{this['handleIncomingFrame'](_0x5dd6d3);},this['mySock']['onerror']=_0x4ecfe8=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x53a557=_0x4ecfe8['message']||_0x4ecfe8['data'];_0x53a557&&this['log_'](_0x53a557),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x173fa6=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x1229bd=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x233f37=navigator['userAgent']['match'](_0x1229bd);_0x233f37&&_0x233f37['length']>0x1&&parseFloat(_0x233f37[0x1])<4.4&&(_0x173fa6=!0x0);}return!_0x173fa6&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x721de8){if(this['frames']['push'](_0x721de8),this['frames']['length']===this['totalFrames']){const _0x51dca0=this['frames']['join']('');this['frames']=null;const _0xf1c70c=At(_0x51dca0);this['onMessage'](_0xf1c70c);}}['handleNewFrameCount_'](_0x1ca630){this['totalFrames']=_0x1ca630,this['frames']=[];}['extractFrameCount_'](_0x4b5e3c){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x4b5e3c['length']<=0x6){const _0x97d1d=Number(_0x4b5e3c);if(!isNaN(_0x97d1d))return this['handleNewFrameCount_'](_0x97d1d),null;}return this['handleNewFrameCount_'](0x1),_0x4b5e3c;}['handleIncomingFrame'](_0x18ed3b){if(this['mySock']===null)return;const _0x44e243=_0x18ed3b['data'];if(this['bytesReceived']+=_0x44e243['length'],this['stats_']['incrementCounter']('bytes_received',_0x44e243['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x44e243);else{const _0xeea184=this['extractFrameCount_'](_0x44e243);_0xeea184!==null&&this['appendFrame_'](_0xeea184);}}['send'](_0x17c617){this['resetKeepAlive']();const _0x4c4c16=O(_0x17c617);this['bytesSent']+=_0x4c4c16['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4c4c16['length']);const _0x3cad04=oo(_0x4c4c16,gh);_0x3cad04['length']>0x1&&this['sendString_'](String(_0x3cad04['length']));for(let _0x3ee099=0x0;_0x3ee099<_0x3cad04['length'];_0x3ee099++)this['sendString_'](_0x3cad04[_0x3ee099]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x57dc9a){try{this['mySock']['send'](_0x57dc9a);}catch(_0x3b3917){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x3b3917['message']||_0x3b3917['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x3b2adc){this['initTransports_'](_0x3b2adc);}['initTransports_'](_0x46de42){const _0x1b9ccc=z&&z['isAvailable']();let _0x57840e=_0x1b9ccc&&!z['previouslyFailed']();if(_0x46de42['webSocketOnly']&&(_0x1b9ccc||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x57840e=!0x0),_0x57840e)this['transports_']=[z];else{const _0x47dbbd=this['transports_']=[];for(const _0x1cb463 of Nt['ALL_TRANSPORTS'])_0x1cb463&&_0x1cb463['isAvailable']()&&_0x47dbbd['push'](_0x1cb463);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x381fc8,_0x40976e,_0x43c405,_0x1dd314,_0x95ecb4,_0x572cef,_0x3de996,_0x19efc3,_0x43243a,_0x4e5f30){this['id']=_0x381fc8,this['repoInfo_']=_0x40976e,this['applicationId_']=_0x43c405,this['appCheckToken_']=_0x1dd314,this['authToken_']=_0x95ecb4,this['onMessage_']=_0x572cef,this['onReady_']=_0x3de996,this['onDisconnect_']=_0x19efc3,this['onKill_']=_0x43243a,this['lastSessionId']=_0x4e5f30,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x40976e),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x15abf8=this['transportManager_']['initialTransport']();this['conn_']=new _0x15abf8(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x15abf8['responsesRequiredToBeHealthy']||0x0;const _0x1f6ed2=this['connReceiver_'](this['conn_']),_0x424d95=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x1f6ed2,_0x424d95);},Math['floor'](0x0));const _0x460bec=_0x15abf8['healthyTimeout']||0x0;_0x460bec>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x460bec)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x2215d3){return _0x1150eb=>{_0x2215d3===this['conn_']?this['onConnectionLost_'](_0x1150eb):_0x2215d3===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0xa90e58){return _0x11f644=>{this['state_']!==0x2&&(_0xa90e58===this['rx_']?this['onPrimaryMessageReceived_'](_0x11f644):_0xa90e58===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x11f644):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x42a9f4){const _0x12cb06={'t':'d','d':_0x42a9f4};this['sendData_'](_0x12cb06);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x2edc23){if(si in _0x2edc23){const _0x1c4dd9=_0x2edc23[si];_0x1c4dd9===Qs?this['upgradeIfSecondaryHealthy_']():_0x1c4dd9===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x1c4dd9===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0xe7e5ee){const _0x970dae=_t('t',_0xe7e5ee),_0x4e888a=_t('d',_0xe7e5ee);if(_0x970dae==='c')this['onSecondaryControl_'](_0x4e888a);else{if(_0x970dae==='d')this['pendingDataMessages']['push'](_0x4e888a);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x970dae);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x3961a4){const _0x4e26f6=_t('t',_0x3961a4),_0x48becd=_t('d',_0x3961a4);_0x4e26f6==='c'?this['onControl_'](_0x48becd):_0x4e26f6==='d'&&this['onDataMessage_'](_0x48becd);}['onDataMessage_'](_0x12d62b){this['onPrimaryResponse_'](),this['onMessage_'](_0x12d62b);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x304c21){const _0x4e0946=_t(si,_0x304c21);if(js in _0x304c21){const _0xeef090=_0x304c21[js];if(_0x4e0946===Th){const _0x166f60={..._0xeef090};this['repoInfo_']['isUsingEmulator']&&(_0x166f60['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x166f60);}else{if(_0x4e0946===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x5dc867=0x0;_0x5dc867<this['pendingDataMessages']['length'];++_0x5dc867)this['onDataMessage_'](this['pendingDataMessages'][_0x5dc867]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x4e0946===wh?this['onConnectionShutdown_'](_0xeef090):_0x4e0946===Ks?this['onReset_'](_0xeef090):_0x4e0946===Ch?yi('Server\x20Error:\x20'+_0xeef090):_0x4e0946===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x4e0946);}}}['onHandshake_'](_0x4ee102){const _0x225e92=_0x4ee102['ts'],_0x332c39=_0x4ee102['v'],_0x307443=_0x4ee102['h'];this['sessionId']=_0x4ee102['s'],this['repoInfo_']['host']=_0x307443,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x225e92),$i!==_0x332c39&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x131eef=this['transportManager_']['upgradeTransport']();_0x131eef&&this['startUpgrade_'](_0x131eef);}['startUpgrade_'](_0x45f541){this['secondaryConn_']=new _0x45f541(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x45f541['responsesRequiredToBeHealthy']||0x0;const _0x2aab3c=this['connReceiver_'](this['secondaryConn_']),_0x1ec0b5=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x2aab3c,_0x1ec0b5),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x2d82d9){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x2d82d9),this['repoInfo_']['host']=_0x2d82d9,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x18b5a3,_0x534b82){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x18b5a3,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x534b82,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x409176=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x409176||this['rx_']===_0x409176)&&this['close']();}['onConnectionLost_'](_0x3029ad){this['conn_']=null,!_0x3029ad&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x3332af){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x3332af),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x30ce98){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x30ce98);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x4e20b6,_0x3000d9,_0x209c56,_0x463a63){}['merge'](_0x2f596a,_0x488bed,_0x770fc2,_0x448b55){}['refreshAuthToken'](_0x36b7f9){}['refreshAppCheckToken'](_0x51628e){}['onDisconnectPut'](_0x55d6bb,_0x20f9f2,_0x516251){}['onDisconnectMerge'](_0x437901,_0x50479f,_0x14de9c){}['onDisconnectCancel'](_0x302821,_0x4a249a){}['reportStats'](_0x4d599f){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x38fb23){this['allowedEvents_']=_0x38fb23,this['listeners_']={},f(Array['isArray'](_0x38fb23)&&_0x38fb23['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0xc8c08a,..._0x504095){if(Array['isArray'](this['listeners_'][_0xc8c08a])){const _0x405c90=[...this['listeners_'][_0xc8c08a]];for(let _0x150338=0x0;_0x150338<_0x405c90['length'];_0x150338++)_0x405c90[_0x150338]['callback']['apply'](_0x405c90[_0x150338]['context'],_0x504095);}}['on'](_0x26a2f7,_0x231ae8,_0x58b54d){this['validateEventType_'](_0x26a2f7),this['listeners_'][_0x26a2f7]=this['listeners_'][_0x26a2f7]||[],this['listeners_'][_0x26a2f7]['push']({'callback':_0x231ae8,'context':_0x58b54d});const _0x5b80fc=this['getInitialEvent'](_0x26a2f7);_0x5b80fc&&_0x231ae8['apply'](_0x58b54d,_0x5b80fc);}['off'](_0x367913,_0x2e39fa,_0x2b2979){this['validateEventType_'](_0x367913);const _0x48f369=this['listeners_'][_0x367913]||[];for(let _0x7f0c5a=0x0;_0x7f0c5a<_0x48f369['length'];_0x7f0c5a++)if(_0x48f369[_0x7f0c5a]['callback']===_0x2e39fa&&(!_0x2b2979||_0x2b2979===_0x48f369[_0x7f0c5a]['context'])){_0x48f369['splice'](_0x7f0c5a,0x1);return;}}['validateEventType_'](_0x5b1513){f(this['allowedEvents_']['find'](_0x1ffb7f=>_0x1ffb7f===_0x5b1513),'Unknown\x20event:\x20'+_0x5b1513);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x1c335c){return f(_0x1c335c==='online','Unknown\x20event\x20type:\x20'+_0x1c335c),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x352980,_0x32c355){if(_0x32c355===void 0x0){this['pieces_']=_0x352980['split']('/');let _0x363981=0x0;for(let _0x379617=0x0;_0x379617<this['pieces_']['length'];_0x379617++)this['pieces_'][_0x379617]['length']>0x0&&(this['pieces_'][_0x363981]=this['pieces_'][_0x379617],_0x363981++);this['pieces_']['length']=_0x363981,this['pieceNum_']=0x0;}else this['pieces_']=_0x352980,this['pieceNum_']=_0x32c355;}['toString'](){let _0x56e7a1='';for(let _0x576f83=this['pieceNum_'];_0x576f83<this['pieces_']['length'];_0x576f83++)this['pieces_'][_0x576f83]!==''&&(_0x56e7a1+='/'+this['pieces_'][_0x576f83]);return _0x56e7a1||'/';}}function w(){return new C('');}function y(_0xb6f00a){return _0xb6f00a['pieceNum_']>=_0xb6f00a['pieces_']['length']?null:_0xb6f00a['pieces_'][_0xb6f00a['pieceNum_']];}function we(_0x51f484){return _0x51f484['pieces_']['length']-_0x51f484['pieceNum_'];}function b(_0x2ce076){let _0x94f657=_0x2ce076['pieceNum_'];return _0x94f657<_0x2ce076['pieces_']['length']&&_0x94f657++,new C(_0x2ce076['pieces_'],_0x94f657);}function zi(_0x259096){return _0x259096['pieceNum_']<_0x259096['pieces_']['length']?_0x259096['pieces_'][_0x259096['pieces_']['length']-0x1]:null;}function bh(_0x20ccb4){let _0x554207='';for(let _0x39f801=_0x20ccb4['pieceNum_'];_0x39f801<_0x20ccb4['pieces_']['length'];_0x39f801++)_0x20ccb4['pieces_'][_0x39f801]!==''&&(_0x554207+='/'+encodeURIComponent(String(_0x20ccb4['pieces_'][_0x39f801])));return _0x554207||'/';}function Pt(_0x1941ca,_0x1c0e0d=0x0){return _0x1941ca['pieces_']['slice'](_0x1941ca['pieceNum_']+_0x1c0e0d);}function Ro(_0x16e11d){if(_0x16e11d['pieceNum_']>=_0x16e11d['pieces_']['length'])return null;const _0x52061c=[];for(let _0x5d3cec=_0x16e11d['pieceNum_'];_0x5d3cec<_0x16e11d['pieces_']['length']-0x1;_0x5d3cec++)_0x52061c['push'](_0x16e11d['pieces_'][_0x5d3cec]);return new C(_0x52061c,0x0);}function k(_0x1dfbce,_0x1757b5){const _0x1d8bff=[];for(let _0x192872=_0x1dfbce['pieceNum_'];_0x192872<_0x1dfbce['pieces_']['length'];_0x192872++)_0x1d8bff['push'](_0x1dfbce['pieces_'][_0x192872]);if(_0x1757b5 instanceof C){for(let _0x5e403a=_0x1757b5['pieceNum_'];_0x5e403a<_0x1757b5['pieces_']['length'];_0x5e403a++)_0x1d8bff['push'](_0x1757b5['pieces_'][_0x5e403a]);}else{const _0x353c5b=_0x1757b5['split']('/');for(let _0x1a7fa1=0x0;_0x1a7fa1<_0x353c5b['length'];_0x1a7fa1++)_0x353c5b[_0x1a7fa1]['length']>0x0&&_0x1d8bff['push'](_0x353c5b[_0x1a7fa1]);}return new C(_0x1d8bff,0x0);}function v(_0x2cb8be){return _0x2cb8be['pieceNum_']>=_0x2cb8be['pieces_']['length'];}function F(_0x246018,_0x79177e){const _0x2e9f43=y(_0x246018),_0x3f112f=y(_0x79177e);if(_0x2e9f43===null)return _0x79177e;if(_0x2e9f43===_0x3f112f)return F(b(_0x246018),b(_0x79177e));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x79177e+')\x20is\x20not\x20within\x20outerPath\x20('+_0x246018+')');}function Rh(_0xc7100c,_0x33cf0d){const _0xb63daa=Pt(_0xc7100c,0x0),_0x1c6026=Pt(_0x33cf0d,0x0);for(let _0x5d4985=0x0;_0x5d4985<_0xb63daa['length']&&_0x5d4985<_0x1c6026['length'];_0x5d4985++){const _0x53871e=He(_0xb63daa[_0x5d4985],_0x1c6026[_0x5d4985]);if(_0x53871e!==0x0)return _0x53871e;}return _0xb63daa['length']===_0x1c6026['length']?0x0:_0xb63daa['length']<_0x1c6026['length']?-0x1:0x1;}function ji(_0x4ebb7f,_0x2160a8){if(we(_0x4ebb7f)!==we(_0x2160a8))return!0x1;for(let _0x5a4350=_0x4ebb7f['pieceNum_'],_0x13febe=_0x2160a8['pieceNum_'];_0x5a4350<=_0x4ebb7f['pieces_']['length'];_0x5a4350++,_0x13febe++)if(_0x4ebb7f['pieces_'][_0x5a4350]!==_0x2160a8['pieces_'][_0x13febe])return!0x1;return!0x0;}function G(_0x43bf04,_0x1c0a61){let _0x3f4d62=_0x43bf04['pieceNum_'],_0x3ce469=_0x1c0a61['pieceNum_'];if(we(_0x43bf04)>we(_0x1c0a61))return!0x1;for(;_0x3f4d62<_0x43bf04['pieces_']['length'];){if(_0x43bf04['pieces_'][_0x3f4d62]!==_0x1c0a61['pieces_'][_0x3ce469])return!0x1;++_0x3f4d62,++_0x3ce469;}return!0x0;}class Ah{constructor(_0x35f087,_0x26a9e3){this['errorPrefix_']=_0x26a9e3,this['parts_']=Pt(_0x35f087,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x4d3c9c=0x0;_0x4d3c9c<this['parts_']['length'];_0x4d3c9c++)this['byteLength_']+=On(this['parts_'][_0x4d3c9c]);Ao(this);}}function kh(_0x58a180,_0x1486d6){_0x58a180['parts_']['length']>0x0&&(_0x58a180['byteLength_']+=0x1),_0x58a180['parts_']['push'](_0x1486d6),_0x58a180['byteLength_']+=On(_0x1486d6),Ao(_0x58a180);}function Nh(_0x4d85fc){const _0x4572a6=_0x4d85fc['parts_']['pop']();_0x4d85fc['byteLength_']-=On(_0x4572a6),_0x4d85fc['parts_']['length']>0x0&&(_0x4d85fc['byteLength_']-=0x1);}function Ao(_0x1f1282){if(_0x1f1282['byteLength_']>er)throw new Error(_0x1f1282['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x1f1282['byteLength_']+').');if(_0x1f1282['parts_']['length']>Zs)throw new Error(_0x1f1282['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x1f1282));}function Pe(_0x54db2a){return _0x54db2a['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x54db2a['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x209a86,_0x1dd0a9;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x1dd0a9='visibilitychange',_0x209a86='hidden'):typeof document['mozHidden']<'u'?(_0x1dd0a9='mozvisibilitychange',_0x209a86='mozHidden'):typeof document['msHidden']<'u'?(_0x1dd0a9='msvisibilitychange',_0x209a86='msHidden'):typeof document['webkitHidden']<'u'&&(_0x1dd0a9='webkitvisibilitychange',_0x209a86='webkitHidden')),this['visible_']=!0x0,_0x1dd0a9&&document['addEventListener'](_0x1dd0a9,()=>{const _0x580845=!document[_0x209a86];_0x580845!==this['visible_']&&(this['visible_']=_0x580845,this['trigger']('visible',_0x580845));},!0x1);}['getInitialEvent'](_0x1850b7){return f(_0x1850b7==='visible','Unknown\x20event\x20type:\x20'+_0x1850b7),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x338287,_0x30055c,_0x1a8c75,_0x3aaca4,_0x1929d5,_0x61c8c7,_0x5161f0,_0x4f5924){if(super(),this['repoInfo_']=_0x338287,this['applicationId_']=_0x30055c,this['onDataUpdate_']=_0x1a8c75,this['onConnectStatus_']=_0x3aaca4,this['onServerInfoUpdate_']=_0x1929d5,this['authTokenProvider_']=_0x61c8c7,this['appCheckTokenProvider_']=_0x5161f0,this['authOverride_']=_0x4f5924,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x4f5924)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x338287['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x3518b2,_0x1d4e9a,_0x2b2abb){const _0x5a57a7=++this['requestNumber_'],_0x261150={'r':_0x5a57a7,'a':_0x3518b2,'b':_0x1d4e9a};this['log_'](O(_0x261150)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x261150),_0x2b2abb&&(this['requestCBHash_'][_0x5a57a7]=_0x2b2abb);}['get'](_0x5cba3c){this['initConnection_']();const _0x16fa7d=new ot(),_0x3388ea={'action':'g','request':{'p':_0x5cba3c['_path']['toString'](),'q':_0x5cba3c['_queryObject']},'onComplete':_0x18ae0f=>{const _0x360929=_0x18ae0f['d'];_0x18ae0f['s']==='ok'?_0x16fa7d['resolve'](_0x360929):_0x16fa7d['reject'](_0x360929);}};this['outstandingGets_']['push'](_0x3388ea),this['outstandingGetCount_']++;const _0x1d666e=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x1d666e),_0x16fa7d['promise'];}['listen'](_0x1323fd,_0x4dd361,_0x492385,_0x347dbd){this['initConnection_']();const _0x5582b7=_0x1323fd['_queryIdentifier'],_0x277cf4=_0x1323fd['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x277cf4+'\x20'+_0x5582b7),this['listens']['has'](_0x277cf4)||this['listens']['set'](_0x277cf4,new Map()),f(_0x1323fd['_queryParams']['isDefault']()||!_0x1323fd['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x277cf4)['has'](_0x5582b7),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x4bb13f={'onComplete':_0x347dbd,'hashFn':_0x4dd361,'query':_0x1323fd,'tag':_0x492385};this['listens']['get'](_0x277cf4)['set'](_0x5582b7,_0x4bb13f),this['connected_']&&this['sendListen_'](_0x4bb13f);}['sendGet_'](_0x24dd10){const _0x3de3cf=this['outstandingGets_'][_0x24dd10];this['sendRequest']('g',_0x3de3cf['request'],_0x284f6a=>{delete this['outstandingGets_'][_0x24dd10],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x3de3cf['onComplete']&&_0x3de3cf['onComplete'](_0x284f6a);});}['sendListen_'](_0x26aa44){const _0x5add86=_0x26aa44['query'],_0x16408e=_0x5add86['_path']['toString'](),_0x6c03ee=_0x5add86['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x16408e+'\x20for\x20'+_0x6c03ee);const _0x414e3b={'p':_0x16408e},_0x403cb2='q';_0x26aa44['tag']&&(_0x414e3b['q']=_0x5add86['_queryObject'],_0x414e3b['t']=_0x26aa44['tag']),_0x414e3b['h']=_0x26aa44['hashFn'](),this['sendRequest'](_0x403cb2,_0x414e3b,_0x20fa5d=>{const _0x2e443a=_0x20fa5d['d'],_0x41a247=_0x20fa5d['s'];se['warnOnListenWarnings_'](_0x2e443a,_0x5add86),(this['listens']['get'](_0x16408e)&&this['listens']['get'](_0x16408e)['get'](_0x6c03ee))===_0x26aa44&&(this['log_']('listen\x20response',_0x20fa5d),_0x41a247!=='ok'&&this['removeListen_'](_0x16408e,_0x6c03ee),_0x26aa44['onComplete']&&_0x26aa44['onComplete'](_0x41a247,_0x2e443a));});}static['warnOnListenWarnings_'](_0x132d0d,_0x3f354a){if(_0x132d0d&&typeof _0x132d0d=='object'&&J(_0x132d0d,'w')){const _0x273dc8=De(_0x132d0d,'w');if(Array['isArray'](_0x273dc8)&&~_0x273dc8['indexOf']('no_index')){const _0x42be11='\x22.indexOn\x22:\x20\x22'+_0x3f354a['_queryParams']['getIndex']()['toString']()+'\x22',_0x42b9ab=_0x3f354a['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x42be11+'\x20at\x20'+_0x42b9ab+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x1130cf){this['authToken_']=_0x1130cf,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x1130cf);}['reduceReconnectDelayIfAdminCredential_'](_0x71e090){(_0x71e090&&_0x71e090['length']===0x28||wc(_0x71e090))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x52caa9){this['appCheckToken_']=_0x52caa9,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x39b4a3=this['authToken_'],_0x15bc02=Ic(_0x39b4a3)?'auth':'gauth',_0x120a53={'cred':_0x39b4a3};this['authOverride_']===null?_0x120a53['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x120a53['authvar']=this['authOverride_']),this['sendRequest'](_0x15bc02,_0x120a53,_0x3a3151=>{const _0x55d56f=_0x3a3151['s'],_0x44b251=_0x3a3151['d']||'error';this['authToken_']===_0x39b4a3&&(_0x55d56f==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x55d56f,_0x44b251));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x23be11=>{const _0x2bcca4=_0x23be11['s'],_0x517fe6=_0x23be11['d']||'error';_0x2bcca4==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x2bcca4,_0x517fe6);});}['unlisten'](_0x28434f,_0x2ef6d2){const _0x505c88=_0x28434f['_path']['toString'](),_0x55769e=_0x28434f['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x505c88+'\x20'+_0x55769e),f(_0x28434f['_queryParams']['isDefault']()||!_0x28434f['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x505c88,_0x55769e)&&this['connected_']&&this['sendUnlisten_'](_0x505c88,_0x55769e,_0x28434f['_queryObject'],_0x2ef6d2);}['sendUnlisten_'](_0x1ff9e1,_0x206c25,_0x38057e,_0x4142c9){this['log_']('Unlisten\x20on\x20'+_0x1ff9e1+'\x20for\x20'+_0x206c25);const _0x21e64f={'p':_0x1ff9e1},_0x5e8c98='n';_0x4142c9&&(_0x21e64f['q']=_0x38057e,_0x21e64f['t']=_0x4142c9),this['sendRequest'](_0x5e8c98,_0x21e64f);}['onDisconnectPut'](_0x3ff679,_0x51473c,_0x1c66de){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x3ff679,_0x51473c,_0x1c66de):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3ff679,'action':'o','data':_0x51473c,'onComplete':_0x1c66de});}['onDisconnectMerge'](_0x232877,_0x5d0f3d,_0x3028fc){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x232877,_0x5d0f3d,_0x3028fc):this['onDisconnectRequestQueue_']['push']({'pathString':_0x232877,'action':'om','data':_0x5d0f3d,'onComplete':_0x3028fc});}['onDisconnectCancel'](_0x10c58b,_0x62e8ea){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x10c58b,null,_0x62e8ea):this['onDisconnectRequestQueue_']['push']({'pathString':_0x10c58b,'action':'oc','data':null,'onComplete':_0x62e8ea});}['sendOnDisconnect_'](_0x30ca58,_0x59fbf2,_0x269fd3,_0x17ad6e){const _0xf3a0d={'p':_0x59fbf2,'d':_0x269fd3};this['log_']('onDisconnect\x20'+_0x30ca58,_0xf3a0d),this['sendRequest'](_0x30ca58,_0xf3a0d,_0x4f7ad6=>{_0x17ad6e&&setTimeout(()=>{_0x17ad6e(_0x4f7ad6['s'],_0x4f7ad6['d']);},Math['floor'](0x0));});}['put'](_0x564e9c,_0x3a7f41,_0x1c7245,_0x5339a3){this['putInternal']('p',_0x564e9c,_0x3a7f41,_0x1c7245,_0x5339a3);}['merge'](_0x172c49,_0x5436f4,_0xc1032a,_0x2692d6){this['putInternal']('m',_0x172c49,_0x5436f4,_0xc1032a,_0x2692d6);}['putInternal'](_0x5a3092,_0x43e171,_0x43c8ce,_0x3f6ad2,_0x129089){this['initConnection_']();const _0x51d972={'p':_0x43e171,'d':_0x43c8ce};_0x129089!==void 0x0&&(_0x51d972['h']=_0x129089),this['outstandingPuts_']['push']({'action':_0x5a3092,'request':_0x51d972,'onComplete':_0x3f6ad2}),this['outstandingPutCount_']++;const _0x7fb9cc=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x7fb9cc):this['log_']('Buffering\x20put:\x20'+_0x43e171);}['sendPut_'](_0x56098c){const _0x41262d=this['outstandingPuts_'][_0x56098c]['action'],_0x581d1a=this['outstandingPuts_'][_0x56098c]['request'],_0x5d0f46=this['outstandingPuts_'][_0x56098c]['onComplete'];this['outstandingPuts_'][_0x56098c]['queued']=this['connected_'],this['sendRequest'](_0x41262d,_0x581d1a,_0x9b573=>{this['log_'](_0x41262d+'\x20response',_0x9b573),delete this['outstandingPuts_'][_0x56098c],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x5d0f46&&_0x5d0f46(_0x9b573['s'],_0x9b573['d']);});}['reportStats'](_0x1ac7ef){if(this['connected_']){const _0x33f341={'c':_0x1ac7ef};this['log_']('reportStats',_0x33f341),this['sendRequest']('s',_0x33f341,_0x2ef667=>{if(_0x2ef667['s']!=='ok'){const _0x310c23=_0x2ef667['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x310c23);}});}}['onDataMessage_'](_0xf34d66){if('r'in _0xf34d66){this['log_']('from\x20server:\x20'+O(_0xf34d66));const _0x73aaa0=_0xf34d66['r'],_0x59936a=this['requestCBHash_'][_0x73aaa0];_0x59936a&&(delete this['requestCBHash_'][_0x73aaa0],_0x59936a(_0xf34d66['b']));}else{if('error'in _0xf34d66)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0xf34d66['error'];'a'in _0xf34d66&&this['onDataPush_'](_0xf34d66['a'],_0xf34d66['b']);}}['onDataPush_'](_0x2009a4,_0x222137){this['log_']('handleServerMessage',_0x2009a4,_0x222137),_0x2009a4==='d'?this['onDataUpdate_'](_0x222137['p'],_0x222137['d'],!0x1,_0x222137['t']):_0x2009a4==='m'?this['onDataUpdate_'](_0x222137['p'],_0x222137['d'],!0x0,_0x222137['t']):_0x2009a4==='c'?this['onListenRevoked_'](_0x222137['p'],_0x222137['q']):_0x2009a4==='ac'?this['onAuthRevoked_'](_0x222137['s'],_0x222137['d']):_0x2009a4==='apc'?this['onAppCheckRevoked_'](_0x222137['s'],_0x222137['d']):_0x2009a4==='sd'?this['onSecurityDebugPacket_'](_0x222137):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x2009a4)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x87af28,_0x576e8e){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x87af28),this['lastSessionId']=_0x576e8e,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x249116){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x249116));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x1b1502){_0x1b1502&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x1b1502;}['onOnline_'](_0x5e4604){_0x5e4604?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x157e05=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x16ad54=Math['max'](0x0,this['reconnectDelay_']-_0x157e05);_0x16ad54=Math['random']()*_0x16ad54,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x16ad54+'ms'),this['scheduleConnect_'](_0x16ad54),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x459ec6=this['onDataMessage_']['bind'](this),_0x431d75=this['onReady_']['bind'](this),_0x76546d=this['onRealtimeDisconnect_']['bind'](this),_0x2b2773=this['id']+':'+se['nextConnectionId_']++,_0x1698d4=this['lastSessionId'];let _0x40d9f5=!0x1,_0x13afc3=null;const _0x410863=function(){_0x13afc3?_0x13afc3['close']():(_0x40d9f5=!0x0,_0x76546d());},_0x200f39=function(_0x116c73){f(_0x13afc3,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x13afc3['sendRequest'](_0x116c73);};this['realtime_']={'close':_0x410863,'sendRequest':_0x200f39};const _0x3b663e=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x27caa8,_0x409370]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x3b663e),this['appCheckTokenProvider_']['getToken'](_0x3b663e)]);_0x40d9f5?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x27caa8&&_0x27caa8['accessToken'],this['appCheckToken_']=_0x409370&&_0x409370['token'],_0x13afc3=new Sh(_0x2b2773,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x459ec6,_0x431d75,_0x76546d,_0x3dc96a=>{U(_0x3dc96a+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x1698d4));}catch(_0x32a83c){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x32a83c),_0x40d9f5||(this['repoInfo_']['nodeAdmin']&&U(_0x32a83c),_0x410863());}}}['interrupt'](_0x1c1d9e){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x1c1d9e),this['interruptReasons_'][_0x1c1d9e]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x58d689){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x58d689),delete this['interruptReasons_'][_0x58d689],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x94a0ad){const _0x1cd934=_0x94a0ad-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x1cd934});}['cancelSentTransactions_'](){for(let _0x1e7a3e=0x0;_0x1e7a3e<this['outstandingPuts_']['length'];_0x1e7a3e++){const _0x7111f0=this['outstandingPuts_'][_0x1e7a3e];_0x7111f0&&'h'in _0x7111f0['request']&&_0x7111f0['queued']&&(_0x7111f0['onComplete']&&_0x7111f0['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x1e7a3e],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x1a3c15,_0x542cb8){let _0x1dad4d;_0x542cb8?_0x1dad4d=_0x542cb8['map'](_0x58b33c=>Hi(_0x58b33c))['join']('$'):_0x1dad4d='default';const _0x1ebf03=this['removeListen_'](_0x1a3c15,_0x1dad4d);_0x1ebf03&&_0x1ebf03['onComplete']&&_0x1ebf03['onComplete']('permission_denied');}['removeListen_'](_0x334f41,_0x37708a){const _0x5c0716=new C(_0x334f41)['toString']();let _0x332034;if(this['listens']['has'](_0x5c0716)){const _0x11365c=this['listens']['get'](_0x5c0716);_0x332034=_0x11365c['get'](_0x37708a),_0x11365c['delete'](_0x37708a),_0x11365c['size']===0x0&&this['listens']['delete'](_0x5c0716);}else _0x332034=void 0x0;return _0x332034;}['onAuthRevoked_'](_0xa9efd9,_0xcad025){L('Auth\x20token\x20revoked:\x20'+_0xa9efd9+'/'+_0xcad025),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0xa9efd9==='invalid_token'||_0xa9efd9==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x38fbdd,_0x1217e7){L('App\x20check\x20token\x20revoked:\x20'+_0x38fbdd+'/'+_0x1217e7),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x38fbdd==='invalid_token'||_0x38fbdd==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x2fd38a){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x2fd38a):'msg'in _0x2fd38a&&console['log']('FIREBASE:\x20'+_0x2fd38a['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x4adb65 of this['listens']['values']())for(const _0x2d1335 of _0x4adb65['values']())this['sendListen_'](_0x2d1335);for(let _0x69ebcd=0x0;_0x69ebcd<this['outstandingPuts_']['length'];_0x69ebcd++)this['outstandingPuts_'][_0x69ebcd]&&this['sendPut_'](_0x69ebcd);for(;this['onDisconnectRequestQueue_']['length'];){const _0xcd314f=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0xcd314f['action'],_0xcd314f['pathString'],_0xcd314f['data'],_0xcd314f['onComplete']);}for(let _0x56b17f=0x0;_0x56b17f<this['outstandingGets_']['length'];_0x56b17f++)this['outstandingGets_'][_0x56b17f]&&this['sendGet_'](_0x56b17f);}['sendConnectStats_'](){const _0x47fe41={};let _0x5ce69e='js';_0x47fe41['sdk.'+_0x5ce69e+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x47fe41['framework.cordova']=0x1:Yr()&&(_0x47fe41['framework.reactnative']=0x1),this['reportStats'](_0x47fe41);}['shouldReconnect_'](){const _0x59cf43=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x59cf43;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x28dd98,_0xe2cd9c){this['name']=_0x28dd98,this['node']=_0xe2cd9c;}static['Wrap'](_0x36ef70,_0x3347f2){return new E(_0x36ef70,_0x3347f2);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x1d757a,_0x3866ab){const _0x34492f=new E(Fe,_0x1d757a),_0x29a7d2=new E(Fe,_0x3866ab);return this['compare'](_0x34492f,_0x29a7d2)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x35478c){Zt=_0x35478c;}['compare'](_0x456ab9,_0x39d889){return He(_0x456ab9['name'],_0x39d889['name']);}['isDefinedOn'](_0x21c06a){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x3f1c3d,_0x53c074){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x322e2f,_0x4daa53){return f(typeof _0x322e2f=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x322e2f,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x5e6940,_0x20d9fa,_0x361c4c,_0x109987,_0x3dc76e=null){this['isReverse_']=_0x109987,this['resultGenerator_']=_0x3dc76e,this['nodeStack_']=[];let _0x531315=0x1;for(;!_0x5e6940['isEmpty']();)if(_0x5e6940=_0x5e6940,_0x531315=_0x20d9fa?_0x361c4c(_0x5e6940['key'],_0x20d9fa):0x1,_0x109987&&(_0x531315*=-0x1),_0x531315<0x0)this['isReverse_']?_0x5e6940=_0x5e6940['left']:_0x5e6940=_0x5e6940['right'];else{if(_0x531315===0x0){this['nodeStack_']['push'](_0x5e6940);break;}else this['nodeStack_']['push'](_0x5e6940),this['isReverse_']?_0x5e6940=_0x5e6940['right']:_0x5e6940=_0x5e6940['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0xce6976=this['nodeStack_']['pop'](),_0x59a863;if(this['resultGenerator_']?_0x59a863=this['resultGenerator_'](_0xce6976['key'],_0xce6976['value']):_0x59a863={'key':_0xce6976['key'],'value':_0xce6976['value']},this['isReverse_']){for(_0xce6976=_0xce6976['left'];!_0xce6976['isEmpty']();)this['nodeStack_']['push'](_0xce6976),_0xce6976=_0xce6976['right'];}else{for(_0xce6976=_0xce6976['right'];!_0xce6976['isEmpty']();)this['nodeStack_']['push'](_0xce6976),_0xce6976=_0xce6976['left'];}return _0x59a863;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x172261=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x172261['key'],_0x172261['value']):{'key':_0x172261['key'],'value':_0x172261['value']};}}class M{constructor(_0x5d2410,_0x185caf,_0x2ad01b,_0x47eb57,_0x53b9df){this['key']=_0x5d2410,this['value']=_0x185caf,this['color']=_0x2ad01b??M['RED'],this['left']=_0x47eb57??B['EMPTY_NODE'],this['right']=_0x53b9df??B['EMPTY_NODE'];}['copy'](_0x430f5d,_0xc11688,_0x2dec5d,_0x3c99f3,_0x1f85e4){return new M(_0x430f5d??this['key'],_0xc11688??this['value'],_0x2dec5d??this['color'],_0x3c99f3??this['left'],_0x1f85e4??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x3c7fad){return this['left']['inorderTraversal'](_0x3c7fad)||!!_0x3c7fad(this['key'],this['value'])||this['right']['inorderTraversal'](_0x3c7fad);}['reverseTraversal'](_0x53b60b){return this['right']['reverseTraversal'](_0x53b60b)||_0x53b60b(this['key'],this['value'])||this['left']['reverseTraversal'](_0x53b60b);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x4e3e35,_0x2f0dd2,_0x4a960a){let _0x518749=this;const _0xf27e87=_0x4a960a(_0x4e3e35,_0x518749['key']);return _0xf27e87<0x0?_0x518749=_0x518749['copy'](null,null,null,_0x518749['left']['insert'](_0x4e3e35,_0x2f0dd2,_0x4a960a),null):_0xf27e87===0x0?_0x518749=_0x518749['copy'](null,_0x2f0dd2,null,null,null):_0x518749=_0x518749['copy'](null,null,null,null,_0x518749['right']['insert'](_0x4e3e35,_0x2f0dd2,_0x4a960a)),_0x518749['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x1cfd12=this;return!_0x1cfd12['left']['isRed_']()&&!_0x1cfd12['left']['left']['isRed_']()&&(_0x1cfd12=_0x1cfd12['moveRedLeft_']()),_0x1cfd12=_0x1cfd12['copy'](null,null,null,_0x1cfd12['left']['removeMin_'](),null),_0x1cfd12['fixUp_']();}['remove'](_0x13b6d8,_0x89b9fc){let _0x27dd9f,_0x1a1d0b;if(_0x27dd9f=this,_0x89b9fc(_0x13b6d8,_0x27dd9f['key'])<0x0)!_0x27dd9f['left']['isEmpty']()&&!_0x27dd9f['left']['isRed_']()&&!_0x27dd9f['left']['left']['isRed_']()&&(_0x27dd9f=_0x27dd9f['moveRedLeft_']()),_0x27dd9f=_0x27dd9f['copy'](null,null,null,_0x27dd9f['left']['remove'](_0x13b6d8,_0x89b9fc),null);else{if(_0x27dd9f['left']['isRed_']()&&(_0x27dd9f=_0x27dd9f['rotateRight_']()),!_0x27dd9f['right']['isEmpty']()&&!_0x27dd9f['right']['isRed_']()&&!_0x27dd9f['right']['left']['isRed_']()&&(_0x27dd9f=_0x27dd9f['moveRedRight_']()),_0x89b9fc(_0x13b6d8,_0x27dd9f['key'])===0x0){if(_0x27dd9f['right']['isEmpty']())return B['EMPTY_NODE'];_0x1a1d0b=_0x27dd9f['right']['min_'](),_0x27dd9f=_0x27dd9f['copy'](_0x1a1d0b['key'],_0x1a1d0b['value'],null,null,_0x27dd9f['right']['removeMin_']());}_0x27dd9f=_0x27dd9f['copy'](null,null,null,null,_0x27dd9f['right']['remove'](_0x13b6d8,_0x89b9fc));}return _0x27dd9f['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x1539a8=this;return _0x1539a8['right']['isRed_']()&&!_0x1539a8['left']['isRed_']()&&(_0x1539a8=_0x1539a8['rotateLeft_']()),_0x1539a8['left']['isRed_']()&&_0x1539a8['left']['left']['isRed_']()&&(_0x1539a8=_0x1539a8['rotateRight_']()),_0x1539a8['left']['isRed_']()&&_0x1539a8['right']['isRed_']()&&(_0x1539a8=_0x1539a8['colorFlip_']()),_0x1539a8;}['moveRedLeft_'](){let _0x4930f2=this['colorFlip_']();return _0x4930f2['right']['left']['isRed_']()&&(_0x4930f2=_0x4930f2['copy'](null,null,null,null,_0x4930f2['right']['rotateRight_']()),_0x4930f2=_0x4930f2['rotateLeft_'](),_0x4930f2=_0x4930f2['colorFlip_']()),_0x4930f2;}['moveRedRight_'](){let _0x40302d=this['colorFlip_']();return _0x40302d['left']['left']['isRed_']()&&(_0x40302d=_0x40302d['rotateRight_'](),_0x40302d=_0x40302d['colorFlip_']()),_0x40302d;}['rotateLeft_'](){const _0x5f02a1=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x5f02a1,null);}['rotateRight_'](){const _0x414e18=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x414e18);}['colorFlip_'](){const _0x4f523d=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x288cbe=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x4f523d,_0x288cbe);}['checkMaxDepth_'](){const _0x1f4da6=this['check_']();return Math['pow'](0x2,_0x1f4da6)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x4db277=this['left']['check_']();if(_0x4db277!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x4db277+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x1a3186,_0x10ddac,_0x12ae7f,_0x3dca0c,_0x501798){return this;}['insert'](_0x46f966,_0x1d2d09,_0x284048){return new M(_0x46f966,_0x1d2d09,null);}['remove'](_0x2b5104,_0x1263cb){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x1d5647){return!0x1;}['reverseTraversal'](_0x1b33a4){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x4aa977,_0x3724fe=B['EMPTY_NODE']){this['comparator_']=_0x4aa977,this['root_']=_0x3724fe;}['insert'](_0x5d97f1,_0x2fd149){return new B(this['comparator_'],this['root_']['insert'](_0x5d97f1,_0x2fd149,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x1f2267){return new B(this['comparator_'],this['root_']['remove'](_0x1f2267,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x55e90b){let _0xb2fb24,_0x5564fa=this['root_'];for(;!_0x5564fa['isEmpty']();){if(_0xb2fb24=this['comparator_'](_0x55e90b,_0x5564fa['key']),_0xb2fb24===0x0)return _0x5564fa['value'];_0xb2fb24<0x0?_0x5564fa=_0x5564fa['left']:_0xb2fb24>0x0&&(_0x5564fa=_0x5564fa['right']);}return null;}['getPredecessorKey'](_0x37a36b){let _0xd0754f,_0x5bbb6e=this['root_'],_0x1248fa=null;for(;!_0x5bbb6e['isEmpty']();)if(_0xd0754f=this['comparator_'](_0x37a36b,_0x5bbb6e['key']),_0xd0754f===0x0){if(_0x5bbb6e['left']['isEmpty']())return _0x1248fa?_0x1248fa['key']:null;for(_0x5bbb6e=_0x5bbb6e['left'];!_0x5bbb6e['right']['isEmpty']();)_0x5bbb6e=_0x5bbb6e['right'];return _0x5bbb6e['key'];}else _0xd0754f<0x0?_0x5bbb6e=_0x5bbb6e['left']:_0xd0754f>0x0&&(_0x1248fa=_0x5bbb6e,_0x5bbb6e=_0x5bbb6e['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x423ec3){return this['root_']['inorderTraversal'](_0x423ec3);}['reverseTraversal'](_0x8a6f34){return this['root_']['reverseTraversal'](_0x8a6f34);}['getIterator'](_0x3ff635){return new en(this['root_'],null,this['comparator_'],!0x1,_0x3ff635);}['getIteratorFrom'](_0x2b805d,_0x4e76fe){return new en(this['root_'],_0x2b805d,this['comparator_'],!0x1,_0x4e76fe);}['getReverseIteratorFrom'](_0x6fe74b,_0x92fdc0){return new en(this['root_'],_0x6fe74b,this['comparator_'],!0x0,_0x92fdc0);}['getReverseIterator'](_0x14b34a){return new en(this['root_'],null,this['comparator_'],!0x0,_0x14b34a);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x4b8683,_0x3b4013){return He(_0x4b8683['name'],_0x3b4013['name']);}function Yi(_0x515300,_0x39040a){return He(_0x515300,_0x39040a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x3c0af0){Ei=_0x3c0af0;}const No=function(_0x3248df){return typeof _0x3248df=='number'?'number:'+ao(_0x3248df):'string:'+_0x3248df;},Po=function(_0x3bf68b){if(_0x3bf68b['isLeafNode']()){const _0x2624c6=_0x3bf68b['val']();f(typeof _0x2624c6=='string'||typeof _0x2624c6=='number'||typeof _0x2624c6=='object'&&J(_0x2624c6,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x3bf68b===Ei||_0x3bf68b['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x3bf68b===Ei||_0x3bf68b['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x3f0260){ir=_0x3f0260;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x152bde,_0x848bdf=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x152bde,this['priorityNode_']=_0x848bdf,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x47f3d9){return new D(this['value_'],_0x47f3d9);}['getImmediateChild'](_0x4cd97c){return _0x4cd97c==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x24c95f){return v(_0x24c95f)?this:y(_0x24c95f)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x416ef9,_0x53b5c1){return null;}['updateImmediateChild'](_0x1e29e1,_0x271919){return _0x1e29e1==='.priority'?this['updatePriority'](_0x271919):_0x271919['isEmpty']()&&_0x1e29e1!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x1e29e1,_0x271919)['updatePriority'](this['priorityNode_']);}['updateChild'](_0xbfe33,_0x31e3a1){const _0x4f11a0=y(_0xbfe33);return _0x4f11a0===null?_0x31e3a1:_0x31e3a1['isEmpty']()&&_0x4f11a0!=='.priority'?this:(f(_0x4f11a0!=='.priority'||we(_0xbfe33)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x4f11a0,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0xbfe33),_0x31e3a1)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x38c7bd,_0x57e9e0){return!0x1;}['val'](_0x1a8c2f){return _0x1a8c2f&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x1e23e3='';this['priorityNode_']['isEmpty']()||(_0x1e23e3+='priority:'+No(this['priorityNode_']['val']())+':');const _0x20ec03=typeof this['value_'];_0x1e23e3+=_0x20ec03+':',_0x20ec03==='number'?_0x1e23e3+=ao(this['value_']):_0x1e23e3+=this['value_'],this['lazyHash_']=ro(_0x1e23e3);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x320ed6){return _0x320ed6===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x320ed6 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x320ed6['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x320ed6));}['compareToLeafNode_'](_0x5ca96b){const _0x5e0c53=typeof _0x5ca96b['value_'],_0x4225cd=typeof this['value_'],_0x749e67=D['VALUE_TYPE_ORDER']['indexOf'](_0x5e0c53),_0x258fad=D['VALUE_TYPE_ORDER']['indexOf'](_0x4225cd);return f(_0x749e67>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5e0c53),f(_0x258fad>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4225cd),_0x749e67===_0x258fad?_0x4225cd==='object'?0x0:this['value_']<_0x5ca96b['value_']?-0x1:this['value_']===_0x5ca96b['value_']?0x0:0x1:_0x258fad-_0x749e67;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0xe453b1){if(_0xe453b1===this)return!0x0;if(_0xe453b1['isLeafNode']()){const _0x1bf556=_0xe453b1;return this['value_']===_0x1bf556['value_']&&this['priorityNode_']['equals'](_0x1bf556['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x4cb243){Oo=_0x4cb243;}function Wh(_0x53fdca){Do=_0x53fdca;}class Bh extends Dn{['compare'](_0x13de42,_0x5bbaed){const _0x4d26ed=_0x13de42['node']['getPriority'](),_0xe746ae=_0x5bbaed['node']['getPriority'](),_0x969859=_0x4d26ed['compareTo'](_0xe746ae);return _0x969859===0x0?He(_0x13de42['name'],_0x5bbaed['name']):_0x969859;}['isDefinedOn'](_0x2355b6){return!_0x2355b6['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x2b55a5,_0x266d90){return!_0x2b55a5['getPriority']()['equals'](_0x266d90['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x119674,_0x5f1926){const _0x46212f=Oo(_0x119674);return new E(_0x5f1926,new D('[PRIORITY-POST]',_0x46212f));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x3a7d24){const _0x56cf7e=_0xee3595=>parseInt(Math['log'](_0xee3595)/Vh,0xa),_0x53de3a=_0x57c478=>parseInt(Array(_0x57c478+0x1)['join']('1'),0x2);this['count']=_0x56cf7e(_0x3a7d24+0x1),this['current_']=this['count']-0x1;const _0xcdcc56=_0x53de3a(this['count']);this['bits_']=_0x3a7d24+0x1&_0xcdcc56;}['nextBitIsOne'](){const _0x1f83eb=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x1f83eb;}}const fn=function(_0x210857,_0x3e8ae2,_0x25dc85,_0x3b9d07){_0x210857['sort'](_0x3e8ae2);const _0x3d5f78=function(_0x523f27,_0x38308c){const _0x12b6a2=_0x38308c-_0x523f27;let _0x5c9911,_0x1ef9e7;if(_0x12b6a2===0x0)return null;if(_0x12b6a2===0x1)return _0x5c9911=_0x210857[_0x523f27],_0x1ef9e7=_0x25dc85?_0x25dc85(_0x5c9911):_0x5c9911,new M(_0x1ef9e7,_0x5c9911['node'],M['BLACK'],null,null);{const _0x4f84b6=parseInt(_0x12b6a2/0x2,0xa)+_0x523f27,_0x1445ca=_0x3d5f78(_0x523f27,_0x4f84b6),_0x451899=_0x3d5f78(_0x4f84b6+0x1,_0x38308c);return _0x5c9911=_0x210857[_0x4f84b6],_0x1ef9e7=_0x25dc85?_0x25dc85(_0x5c9911):_0x5c9911,new M(_0x1ef9e7,_0x5c9911['node'],M['BLACK'],_0x1445ca,_0x451899);}},_0x523e57=function(_0x4ebd52){let _0x1bfd53=null,_0x102603=null,_0x258a8a=_0x210857['length'];const _0x9f060c=function(_0x31c5fd,_0x4740d1){const _0x20ef6d=_0x258a8a-_0x31c5fd,_0x4ce73e=_0x258a8a;_0x258a8a-=_0x31c5fd;const _0x1bf185=_0x3d5f78(_0x20ef6d+0x1,_0x4ce73e),_0x58e4a7=_0x210857[_0x20ef6d],_0x3346de=_0x25dc85?_0x25dc85(_0x58e4a7):_0x58e4a7;_0x2e5a4(new M(_0x3346de,_0x58e4a7['node'],_0x4740d1,null,_0x1bf185));},_0x2e5a4=function(_0x1fd986){_0x1bfd53?(_0x1bfd53['left']=_0x1fd986,_0x1bfd53=_0x1fd986):(_0x102603=_0x1fd986,_0x1bfd53=_0x1fd986);};for(let _0x43c4dc=0x0;_0x43c4dc<_0x4ebd52['count'];++_0x43c4dc){const _0x1301d9=_0x4ebd52['nextBitIsOne'](),_0x859968=Math['pow'](0x2,_0x4ebd52['count']-(_0x43c4dc+0x1));_0x1301d9?_0x9f060c(_0x859968,M['BLACK']):(_0x9f060c(_0x859968,M['BLACK']),_0x9f060c(_0x859968,M['RED']));}return _0x102603;},_0x191e00=new Hh(_0x210857['length']),_0x565d39=_0x523e57(_0x191e00);return new B(_0x3b9d07||_0x3e8ae2,_0x565d39);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x35f035,_0x1a121d){this['indexes_']=_0x35f035,this['indexSet_']=_0x1a121d;}['get'](_0x493b79){const _0x1f84a7=De(this['indexes_'],_0x493b79);if(!_0x1f84a7)throw new Error('No\x20index\x20defined\x20for\x20'+_0x493b79);return _0x1f84a7 instanceof B?_0x1f84a7:null;}['hasIndex'](_0x137969){return J(this['indexSet_'],_0x137969['toString']());}['addIndex'](_0x38a4b4,_0x160c11){f(_0x38a4b4!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x18be5e=[];let _0x522dc7=!0x1;const _0x5af556=_0x160c11['getIterator'](E['Wrap']);let _0x3dfe3c=_0x5af556['getNext']();for(;_0x3dfe3c;)_0x522dc7=_0x522dc7||_0x38a4b4['isDefinedOn'](_0x3dfe3c['node']),_0x18be5e['push'](_0x3dfe3c),_0x3dfe3c=_0x5af556['getNext']();let _0x394eb9;_0x522dc7?_0x394eb9=fn(_0x18be5e,_0x38a4b4['getCompare']()):_0x394eb9=ze;const _0x49db90=_0x38a4b4['toString'](),_0x316c7e={...this['indexSet_']};_0x316c7e[_0x49db90]=_0x38a4b4;const _0x37567c={...this['indexes_']};return _0x37567c[_0x49db90]=_0x394eb9,new te(_0x37567c,_0x316c7e);}['addToIndexes'](_0x374369,_0xa0edad){const _0x5d1822=hn(this['indexes_'],(_0x47baca,_0x583600)=>{const _0x509565=De(this['indexSet_'],_0x583600);if(f(_0x509565,'Missing\x20index\x20implementation\x20for\x20'+_0x583600),_0x47baca===ze){if(_0x509565['isDefinedOn'](_0x374369['node'])){const _0x2379fc=[],_0x269ca3=_0xa0edad['getIterator'](E['Wrap']);let _0x3b3b58=_0x269ca3['getNext']();for(;_0x3b3b58;)_0x3b3b58['name']!==_0x374369['name']&&_0x2379fc['push'](_0x3b3b58),_0x3b3b58=_0x269ca3['getNext']();return _0x2379fc['push'](_0x374369),fn(_0x2379fc,_0x509565['getCompare']());}else return ze;}else{const _0x64ef8b=_0xa0edad['get'](_0x374369['name']);let _0x502e49=_0x47baca;return _0x64ef8b&&(_0x502e49=_0x502e49['remove'](new E(_0x374369['name'],_0x64ef8b))),_0x502e49['insert'](_0x374369,_0x374369['node']);}});return new te(_0x5d1822,this['indexSet_']);}['removeFromIndexes'](_0x242570,_0x5873af){const _0x216bc4=hn(this['indexes_'],_0x26c2c9=>{if(_0x26c2c9===ze)return _0x26c2c9;{const _0x1604c3=_0x5873af['get'](_0x242570['name']);return _0x1604c3?_0x26c2c9['remove'](new E(_0x242570['name'],_0x1604c3)):_0x26c2c9;}});return new te(_0x216bc4,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x2e4727,_0x5ebc3e,_0x360164){this['children_']=_0x2e4727,this['priorityNode_']=_0x5ebc3e,this['indexMap_']=_0x360164,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x578bad){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x578bad,this['indexMap_']);}['getImmediateChild'](_0x40cb10){if(_0x40cb10==='.priority')return this['getPriority']();{const _0x56c322=this['children_']['get'](_0x40cb10);return _0x56c322===null?mt:_0x56c322;}}['getChild'](_0x2b3fec){const _0x60b6d=y(_0x2b3fec);return _0x60b6d===null?this:this['getImmediateChild'](_0x60b6d)['getChild'](b(_0x2b3fec));}['hasChild'](_0x5b4d56){return this['children_']['get'](_0x5b4d56)!==null;}['updateImmediateChild'](_0x1b6a42,_0x48b70e){if(f(_0x48b70e,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x1b6a42==='.priority')return this['updatePriority'](_0x48b70e);{const _0x206acd=new E(_0x1b6a42,_0x48b70e);let _0x1280e5,_0x245da5;_0x48b70e['isEmpty']()?(_0x1280e5=this['children_']['remove'](_0x1b6a42),_0x245da5=this['indexMap_']['removeFromIndexes'](_0x206acd,this['children_'])):(_0x1280e5=this['children_']['insert'](_0x1b6a42,_0x48b70e),_0x245da5=this['indexMap_']['addToIndexes'](_0x206acd,this['children_']));const _0x1bbc68=_0x1280e5['isEmpty']()?mt:this['priorityNode_'];return new g(_0x1280e5,_0x1bbc68,_0x245da5);}}['updateChild'](_0x370b4f,_0x430484){const _0x48c752=y(_0x370b4f);if(_0x48c752===null)return _0x430484;{f(y(_0x370b4f)!=='.priority'||we(_0x370b4f)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x7c269b=this['getImmediateChild'](_0x48c752)['updateChild'](b(_0x370b4f),_0x430484);return this['updateImmediateChild'](_0x48c752,_0x7c269b);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x3e3786){if(this['isEmpty']())return null;const _0x38c9f4={};let _0x2b24e5=0x0,_0x539462=0x0,_0x53dc0e=!0x0;if(this['forEachChild'](R,(_0x4e478e,_0x6d1483)=>{_0x38c9f4[_0x4e478e]=_0x6d1483['val'](_0x3e3786),_0x2b24e5++,_0x53dc0e&&g['INTEGER_REGEXP_']['test'](_0x4e478e)?_0x539462=Math['max'](_0x539462,Number(_0x4e478e)):_0x53dc0e=!0x1;}),!_0x3e3786&&_0x53dc0e&&_0x539462<0x2*_0x2b24e5){const _0x21d174=[];for(const _0x59b921 in _0x38c9f4)_0x21d174[_0x59b921]=_0x38c9f4[_0x59b921];return _0x21d174;}else return _0x3e3786&&!this['getPriority']()['isEmpty']()&&(_0x38c9f4['.priority']=this['getPriority']()['val']()),_0x38c9f4;}['hash'](){if(this['lazyHash_']===null){let _0x3ed99b='';this['getPriority']()['isEmpty']()||(_0x3ed99b+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x248778,_0xcd8ea4)=>{const _0x5e4656=_0xcd8ea4['hash']();_0x5e4656!==''&&(_0x3ed99b+=':'+_0x248778+':'+_0x5e4656);}),this['lazyHash_']=_0x3ed99b===''?'':ro(_0x3ed99b);}return this['lazyHash_'];}['getPredecessorChildName'](_0x5a180d,_0x47ad4a,_0x5a740a){const _0x4e5087=this['resolveIndex_'](_0x5a740a);if(_0x4e5087){const _0x412d18=_0x4e5087['getPredecessorKey'](new E(_0x5a180d,_0x47ad4a));return _0x412d18?_0x412d18['name']:null;}else return this['children_']['getPredecessorKey'](_0x5a180d);}['getFirstChildName'](_0x112858){const _0x50a316=this['resolveIndex_'](_0x112858);if(_0x50a316){const _0x18a917=_0x50a316['minKey']();return _0x18a917&&_0x18a917['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x29a0f9){const _0x223b60=this['getFirstChildName'](_0x29a0f9);return _0x223b60?new E(_0x223b60,this['children_']['get'](_0x223b60)):null;}['getLastChildName'](_0x1e5cfe){const _0x1fd376=this['resolveIndex_'](_0x1e5cfe);if(_0x1fd376){const _0x28e4a0=_0x1fd376['maxKey']();return _0x28e4a0&&_0x28e4a0['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0xb7af21){const _0x4a1389=this['getLastChildName'](_0xb7af21);return _0x4a1389?new E(_0x4a1389,this['children_']['get'](_0x4a1389)):null;}['forEachChild'](_0x55a79b,_0x4a1bda){const _0x51457a=this['resolveIndex_'](_0x55a79b);return _0x51457a?_0x51457a['inorderTraversal'](_0xe9947d=>_0x4a1bda(_0xe9947d['name'],_0xe9947d['node'])):this['children_']['inorderTraversal'](_0x4a1bda);}['getIterator'](_0x325217){return this['getIteratorFrom'](_0x325217['minPost'](),_0x325217);}['getIteratorFrom'](_0x1118e0,_0xb9ff20){const _0x207f5f=this['resolveIndex_'](_0xb9ff20);if(_0x207f5f)return _0x207f5f['getIteratorFrom'](_0x1118e0,_0x501f8d=>_0x501f8d);{const _0x791728=this['children_']['getIteratorFrom'](_0x1118e0['name'],E['Wrap']);let _0x354519=_0x791728['peek']();for(;_0x354519!=null&&_0xb9ff20['compare'](_0x354519,_0x1118e0)<0x0;)_0x791728['getNext'](),_0x354519=_0x791728['peek']();return _0x791728;}}['getReverseIterator'](_0x34f08a){return this['getReverseIteratorFrom'](_0x34f08a['maxPost'](),_0x34f08a);}['getReverseIteratorFrom'](_0x5bcd68,_0x4c644b){const _0x4791b8=this['resolveIndex_'](_0x4c644b);if(_0x4791b8)return _0x4791b8['getReverseIteratorFrom'](_0x5bcd68,_0x50a863=>_0x50a863);{const _0x445e4b=this['children_']['getReverseIteratorFrom'](_0x5bcd68['name'],E['Wrap']);let _0x536ef9=_0x445e4b['peek']();for(;_0x536ef9!=null&&_0x4c644b['compare'](_0x536ef9,_0x5bcd68)>0x0;)_0x445e4b['getNext'](),_0x536ef9=_0x445e4b['peek']();return _0x445e4b;}}['compareTo'](_0x3ab9f1){return this['isEmpty']()?_0x3ab9f1['isEmpty']()?0x0:-0x1:_0x3ab9f1['isLeafNode']()||_0x3ab9f1['isEmpty']()?0x1:_0x3ab9f1===$t?-0x1:0x0;}['withIndex'](_0x15c78d){if(_0x15c78d===ye||this['indexMap_']['hasIndex'](_0x15c78d))return this;{const _0x478089=this['indexMap_']['addIndex'](_0x15c78d,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x478089);}}['isIndexed'](_0x3480a3){return _0x3480a3===ye||this['indexMap_']['hasIndex'](_0x3480a3);}['equals'](_0x2d6c4d){if(_0x2d6c4d===this)return!0x0;if(_0x2d6c4d['isLeafNode']())return!0x1;{const _0x3009fd=_0x2d6c4d;if(this['getPriority']()['equals'](_0x3009fd['getPriority']())){if(this['children_']['count']()===_0x3009fd['children_']['count']()){const _0x3bf212=this['getIterator'](R),_0x887726=_0x3009fd['getIterator'](R);let _0x502762=_0x3bf212['getNext'](),_0x4df704=_0x887726['getNext']();for(;_0x502762&&_0x4df704;){if(_0x502762['name']!==_0x4df704['name']||!_0x502762['node']['equals'](_0x4df704['node']))return!0x1;_0x502762=_0x3bf212['getNext'](),_0x4df704=_0x887726['getNext']();}return _0x502762===null&&_0x4df704===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x2d647e){return _0x2d647e===ye?null:this['indexMap_']['get'](_0x2d647e['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x4a0810){return _0x4a0810===this?0x0:0x1;}['equals'](_0x46a048){return _0x46a048===this;}['getPriority'](){return this;}['getImmediateChild'](_0x4fda87){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0xd256f2,_0x46637e=null){if(_0xd256f2===null)return g['EMPTY_NODE'];if(typeof _0xd256f2=='object'&&'.priority'in _0xd256f2&&(_0x46637e=_0xd256f2['.priority']),f(_0x46637e===null||typeof _0x46637e=='string'||typeof _0x46637e=='number'||typeof _0x46637e=='object'&&'.sv'in _0x46637e,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x46637e),typeof _0xd256f2=='object'&&'.value'in _0xd256f2&&_0xd256f2['.value']!==null&&(_0xd256f2=_0xd256f2['.value']),typeof _0xd256f2!='object'||'.sv'in _0xd256f2){const _0x238e13=_0xd256f2;return new D(_0x238e13,P(_0x46637e));}if(!(_0xd256f2 instanceof Array)&&Gh){const _0x427a1c=[];let _0x2102eb=!0x1;if(x(_0xd256f2,(_0x27dd47,_0xb48df2)=>{if(_0x27dd47['substring'](0x0,0x1)!=='.'){const _0x3ce60e=P(_0xb48df2);_0x3ce60e['isEmpty']()||(_0x2102eb=_0x2102eb||!_0x3ce60e['getPriority']()['isEmpty'](),_0x427a1c['push'](new E(_0x27dd47,_0x3ce60e)));}}),_0x427a1c['length']===0x0)return g['EMPTY_NODE'];const _0x4c9eba=fn(_0x427a1c,xh,_0x4dbdf7=>_0x4dbdf7['name'],Yi);if(_0x2102eb){const _0x5d2600=fn(_0x427a1c,R['getCompare']());return new g(_0x4c9eba,P(_0x46637e),new te({'.priority':_0x5d2600},{'.priority':R}));}else return new g(_0x4c9eba,P(_0x46637e),te['Default']);}else{let _0x320f7a=g['EMPTY_NODE'];return x(_0xd256f2,(_0x303c82,_0x25726c)=>{if(J(_0xd256f2,_0x303c82)&&_0x303c82['substring'](0x0,0x1)!=='.'){const _0x1c8d75=P(_0x25726c);(_0x1c8d75['isLeafNode']()||!_0x1c8d75['isEmpty']())&&(_0x320f7a=_0x320f7a['updateImmediateChild'](_0x303c82,_0x1c8d75));}}),_0x320f7a['updatePriority'](P(_0x46637e));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x101a5b){super(),this['indexPath_']=_0x101a5b,f(!v(_0x101a5b)&&y(_0x101a5b)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x19469d){return _0x19469d['getChild'](this['indexPath_']);}['isDefinedOn'](_0x53ab18){return!_0x53ab18['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x90a28e,_0xad161b){const _0x308369=this['extractChild'](_0x90a28e['node']),_0x166d93=this['extractChild'](_0xad161b['node']),_0x3874d9=_0x308369['compareTo'](_0x166d93);return _0x3874d9===0x0?He(_0x90a28e['name'],_0xad161b['name']):_0x3874d9;}['makePost'](_0x3f2618,_0x2e3e0e){const _0x3ca2fe=P(_0x3f2618),_0x2389f7=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x3ca2fe);return new E(_0x2e3e0e,_0x2389f7);}['maxPost'](){const _0x27cf74=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x27cf74);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x1db165,_0x24c104){const _0x3ab68e=_0x1db165['node']['compareTo'](_0x24c104['node']);return _0x3ab68e===0x0?He(_0x1db165['name'],_0x24c104['name']):_0x3ab68e;}['isDefinedOn'](_0x2e2c7a){return!0x0;}['indexedValueChanged'](_0x44279c,_0x46ce12){return!_0x44279c['equals'](_0x46ce12);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x227953,_0x491183){const _0x1b4260=P(_0x227953);return new E(_0x491183,_0x1b4260);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x43ee4f){return{'type':'value','snapshotNode':_0x43ee4f};}function et(_0x17d2f2,_0x51b4f0){return{'type':'child_added','snapshotNode':_0x51b4f0,'childName':_0x17d2f2};}function Ot(_0x2aabee,_0x51402e){return{'type':'child_removed','snapshotNode':_0x51402e,'childName':_0x2aabee};}function Dt(_0x3c26d0,_0x1c7e83,_0x80723e){return{'type':'child_changed','snapshotNode':_0x1c7e83,'childName':_0x3c26d0,'oldSnap':_0x80723e};}function zh(_0x1c28e4,_0x232a37){return{'type':'child_moved','snapshotNode':_0x232a37,'childName':_0x1c28e4};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x1445ad){this['index_']=_0x1445ad;}['updateChild'](_0x50a356,_0x5d8695,_0x3b0c3a,_0x1c0bec,_0x428d48,_0x4eb4bd){f(_0x50a356['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0xaf5b15=_0x50a356['getImmediateChild'](_0x5d8695);return _0xaf5b15['getChild'](_0x1c0bec)['equals'](_0x3b0c3a['getChild'](_0x1c0bec))&&_0xaf5b15['isEmpty']()===_0x3b0c3a['isEmpty']()||(_0x4eb4bd!=null&&(_0x3b0c3a['isEmpty']()?_0x50a356['hasChild'](_0x5d8695)?_0x4eb4bd['trackChildChange'](Ot(_0x5d8695,_0xaf5b15)):f(_0x50a356['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0xaf5b15['isEmpty']()?_0x4eb4bd['trackChildChange'](et(_0x5d8695,_0x3b0c3a)):_0x4eb4bd['trackChildChange'](Dt(_0x5d8695,_0x3b0c3a,_0xaf5b15))),_0x50a356['isLeafNode']()&&_0x3b0c3a['isEmpty']())?_0x50a356:_0x50a356['updateImmediateChild'](_0x5d8695,_0x3b0c3a)['withIndex'](this['index_']);}['updateFullNode'](_0x706c27,_0x48d1b7,_0x3a5329){return _0x3a5329!=null&&(_0x706c27['isLeafNode']()||_0x706c27['forEachChild'](R,(_0x523ae3,_0x5e498c)=>{_0x48d1b7['hasChild'](_0x523ae3)||_0x3a5329['trackChildChange'](Ot(_0x523ae3,_0x5e498c));}),_0x48d1b7['isLeafNode']()||_0x48d1b7['forEachChild'](R,(_0x5d3902,_0x19bcd4)=>{if(_0x706c27['hasChild'](_0x5d3902)){const _0x37b4df=_0x706c27['getImmediateChild'](_0x5d3902);_0x37b4df['equals'](_0x19bcd4)||_0x3a5329['trackChildChange'](Dt(_0x5d3902,_0x19bcd4,_0x37b4df));}else _0x3a5329['trackChildChange'](et(_0x5d3902,_0x19bcd4));})),_0x48d1b7['withIndex'](this['index_']);}['updatePriority'](_0x3f5ee3,_0x19b03c){return _0x3f5ee3['isEmpty']()?g['EMPTY_NODE']:_0x3f5ee3['updatePriority'](_0x19b03c);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x2ede3f){this['indexedFilter_']=new Ji(_0x2ede3f['getIndex']()),this['index_']=_0x2ede3f['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x2ede3f),this['endPost_']=Mt['getEndPost_'](_0x2ede3f),this['startIsInclusive_']=!_0x2ede3f['startAfterSet_'],this['endIsInclusive_']=!_0x2ede3f['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0xd04982){const _0x24336e=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0xd04982)<=0x0:this['index_']['compare'](this['getStartPost'](),_0xd04982)<0x0,_0x319b9d=this['endIsInclusive_']?this['index_']['compare'](_0xd04982,this['getEndPost']())<=0x0:this['index_']['compare'](_0xd04982,this['getEndPost']())<0x0;return _0x24336e&&_0x319b9d;}['updateChild'](_0x23181a,_0x431691,_0x4353e,_0x47a0b7,_0x23c5fe,_0x286883){return this['matches'](new E(_0x431691,_0x4353e))||(_0x4353e=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x23181a,_0x431691,_0x4353e,_0x47a0b7,_0x23c5fe,_0x286883);}['updateFullNode'](_0x1265e7,_0xd76f6b,_0x44dfb4){_0xd76f6b['isLeafNode']()&&(_0xd76f6b=g['EMPTY_NODE']);let _0x72e952=_0xd76f6b['withIndex'](this['index_']);_0x72e952=_0x72e952['updatePriority'](g['EMPTY_NODE']);const _0x4a0bba=this;return _0xd76f6b['forEachChild'](R,(_0x3de5ae,_0x300049)=>{_0x4a0bba['matches'](new E(_0x3de5ae,_0x300049))||(_0x72e952=_0x72e952['updateImmediateChild'](_0x3de5ae,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1265e7,_0x72e952,_0x44dfb4);}['updatePriority'](_0x38afe2,_0x310b81){return _0x38afe2;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x16ba8e){if(_0x16ba8e['hasStart']()){const _0x55547b=_0x16ba8e['getIndexStartName']();return _0x16ba8e['getIndex']()['makePost'](_0x16ba8e['getIndexStartValue'](),_0x55547b);}else return _0x16ba8e['getIndex']()['minPost']();}static['getEndPost_'](_0x106c0a){if(_0x106c0a['hasEnd']()){const _0x263e7b=_0x106c0a['getIndexEndName']();return _0x106c0a['getIndex']()['makePost'](_0x106c0a['getIndexEndValue'](),_0x263e7b);}else return _0x106c0a['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x50547b){this['withinDirectionalStart']=_0x7eb2be=>this['reverse_']?this['withinEndPost'](_0x7eb2be):this['withinStartPost'](_0x7eb2be),this['withinDirectionalEnd']=_0x4ef59a=>this['reverse_']?this['withinStartPost'](_0x4ef59a):this['withinEndPost'](_0x4ef59a),this['withinStartPost']=_0x5c37e4=>{const _0x2cd7d0=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x5c37e4);return this['startIsInclusive_']?_0x2cd7d0<=0x0:_0x2cd7d0<0x0;},this['withinEndPost']=_0x2aabc6=>{const _0x257deb=this['index_']['compare'](_0x2aabc6,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x257deb<=0x0:_0x257deb<0x0;},this['rangedFilter_']=new Mt(_0x50547b),this['index_']=_0x50547b['getIndex'](),this['limit_']=_0x50547b['getLimit'](),this['reverse_']=!_0x50547b['isViewFromLeft'](),this['startIsInclusive_']=!_0x50547b['startAfterSet_'],this['endIsInclusive_']=!_0x50547b['endBeforeSet_'];}['updateChild'](_0x595a20,_0x328f65,_0x1e4a73,_0x3aa1fa,_0x1dce6f,_0xb46aa){return this['rangedFilter_']['matches'](new E(_0x328f65,_0x1e4a73))||(_0x1e4a73=g['EMPTY_NODE']),_0x595a20['getImmediateChild'](_0x328f65)['equals'](_0x1e4a73)?_0x595a20:_0x595a20['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x595a20,_0x328f65,_0x1e4a73,_0x3aa1fa,_0x1dce6f,_0xb46aa):this['fullLimitUpdateChild_'](_0x595a20,_0x328f65,_0x1e4a73,_0x1dce6f,_0xb46aa);}['updateFullNode'](_0x3d53a0,_0x238609,_0x25523b){let _0x1355d7;if(_0x238609['isLeafNode']()||_0x238609['isEmpty']())_0x1355d7=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x238609['numChildren']()&&_0x238609['isIndexed'](this['index_'])){_0x1355d7=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x57220e;this['reverse_']?_0x57220e=_0x238609['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x57220e=_0x238609['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x202ca8=0x0;for(;_0x57220e['hasNext']()&&_0x202ca8<this['limit_'];){const _0x4bef76=_0x57220e['getNext']();if(this['withinDirectionalStart'](_0x4bef76)){if(this['withinDirectionalEnd'](_0x4bef76))_0x1355d7=_0x1355d7['updateImmediateChild'](_0x4bef76['name'],_0x4bef76['node']),_0x202ca8++;else break;}else continue;}}else{_0x1355d7=_0x238609['withIndex'](this['index_']),_0x1355d7=_0x1355d7['updatePriority'](g['EMPTY_NODE']);let _0x5d7a75;this['reverse_']?_0x5d7a75=_0x1355d7['getReverseIterator'](this['index_']):_0x5d7a75=_0x1355d7['getIterator'](this['index_']);let _0x43253b=0x0;for(;_0x5d7a75['hasNext']();){const _0x145fa9=_0x5d7a75['getNext']();_0x43253b<this['limit_']&&this['withinDirectionalStart'](_0x145fa9)&&this['withinDirectionalEnd'](_0x145fa9)?_0x43253b++:_0x1355d7=_0x1355d7['updateImmediateChild'](_0x145fa9['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x3d53a0,_0x1355d7,_0x25523b);}['updatePriority'](_0x36ad21,_0x4d5309){return _0x36ad21;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x57a9cc,_0x58e10a,_0x3fe395,_0x5c42c1,_0x109a7a){let _0x281a00;if(this['reverse_']){const _0x30832f=this['index_']['getCompare']();_0x281a00=(_0x15cd1b,_0x21c52a)=>_0x30832f(_0x21c52a,_0x15cd1b);}else _0x281a00=this['index_']['getCompare']();const _0x386ad1=_0x57a9cc;f(_0x386ad1['numChildren']()===this['limit_'],'');const _0x5e9591=new E(_0x58e10a,_0x3fe395),_0x54799d=this['reverse_']?_0x386ad1['getFirstChild'](this['index_']):_0x386ad1['getLastChild'](this['index_']),_0x57daf8=this['rangedFilter_']['matches'](_0x5e9591);if(_0x386ad1['hasChild'](_0x58e10a)){const _0x1f9e78=_0x386ad1['getImmediateChild'](_0x58e10a);let _0x13086f=_0x5c42c1['getChildAfterChild'](this['index_'],_0x54799d,this['reverse_']);for(;_0x13086f!=null&&(_0x13086f['name']===_0x58e10a||_0x386ad1['hasChild'](_0x13086f['name']));)_0x13086f=_0x5c42c1['getChildAfterChild'](this['index_'],_0x13086f,this['reverse_']);const _0x101175=_0x13086f==null?0x1:_0x281a00(_0x13086f,_0x5e9591);if(_0x57daf8&&!_0x3fe395['isEmpty']()&&_0x101175>=0x0)return _0x109a7a!=null&&_0x109a7a['trackChildChange'](Dt(_0x58e10a,_0x3fe395,_0x1f9e78)),_0x386ad1['updateImmediateChild'](_0x58e10a,_0x3fe395);{_0x109a7a!=null&&_0x109a7a['trackChildChange'](Ot(_0x58e10a,_0x1f9e78));const _0x3d5159=_0x386ad1['updateImmediateChild'](_0x58e10a,g['EMPTY_NODE']);return _0x13086f!=null&&this['rangedFilter_']['matches'](_0x13086f)?(_0x109a7a!=null&&_0x109a7a['trackChildChange'](et(_0x13086f['name'],_0x13086f['node'])),_0x3d5159['updateImmediateChild'](_0x13086f['name'],_0x13086f['node'])):_0x3d5159;}}else return _0x3fe395['isEmpty']()?_0x57a9cc:_0x57daf8&&_0x281a00(_0x54799d,_0x5e9591)>=0x0?(_0x109a7a!=null&&(_0x109a7a['trackChildChange'](Ot(_0x54799d['name'],_0x54799d['node'])),_0x109a7a['trackChildChange'](et(_0x58e10a,_0x3fe395))),_0x386ad1['updateImmediateChild'](_0x58e10a,_0x3fe395)['updateImmediateChild'](_0x54799d['name'],g['EMPTY_NODE'])):_0x57a9cc;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x37e0f8=new Xi();return _0x37e0f8['limitSet_']=this['limitSet_'],_0x37e0f8['limit_']=this['limit_'],_0x37e0f8['startSet_']=this['startSet_'],_0x37e0f8['startAfterSet_']=this['startAfterSet_'],_0x37e0f8['indexStartValue_']=this['indexStartValue_'],_0x37e0f8['startNameSet_']=this['startNameSet_'],_0x37e0f8['indexStartName_']=this['indexStartName_'],_0x37e0f8['endSet_']=this['endSet_'],_0x37e0f8['endBeforeSet_']=this['endBeforeSet_'],_0x37e0f8['indexEndValue_']=this['indexEndValue_'],_0x37e0f8['endNameSet_']=this['endNameSet_'],_0x37e0f8['indexEndName_']=this['indexEndName_'],_0x37e0f8['index_']=this['index_'],_0x37e0f8['viewFrom_']=this['viewFrom_'],_0x37e0f8;}}function Kh(_0x56b77d){return _0x56b77d['loadsAllData']()?new Ji(_0x56b77d['getIndex']()):_0x56b77d['hasLimit']()?new jh(_0x56b77d):new Mt(_0x56b77d);}function Yh(_0x5e2c3f,_0x1d8b9b){const _0x5d64d8=_0x5e2c3f['copy']();return _0x5d64d8['limitSet_']=!0x0,_0x5d64d8['limit_']=_0x1d8b9b,_0x5d64d8['viewFrom_']='l',_0x5d64d8;}function Qh(_0x2c6dda,_0x1a1716,_0x4a88b3){const _0x1bf826=_0x2c6dda['copy']();return _0x1bf826['startSet_']=!0x0,_0x1a1716===void 0x0&&(_0x1a1716=null),_0x1bf826['indexStartValue_']=_0x1a1716,_0x4a88b3!=null?(_0x1bf826['startNameSet_']=!0x0,_0x1bf826['indexStartName_']=_0x4a88b3):(_0x1bf826['startNameSet_']=!0x1,_0x1bf826['indexStartName_']=''),_0x1bf826;}function Jh(_0x4ad7e8,_0x1f928e,_0x4f1e0a){const _0x4ebedb=_0x4ad7e8['copy']();return _0x4ebedb['endSet_']=!0x0,_0x1f928e===void 0x0&&(_0x1f928e=null),_0x4ebedb['indexEndValue_']=_0x1f928e,_0x4f1e0a!==void 0x0?(_0x4ebedb['endNameSet_']=!0x0,_0x4ebedb['indexEndName_']=_0x4f1e0a):(_0x4ebedb['endNameSet_']=!0x1,_0x4ebedb['indexEndName_']=''),_0x4ebedb;}function xo(_0x38276a,_0x20a4df){const _0x10c85c=_0x38276a['copy']();return _0x10c85c['index_']=_0x20a4df,_0x10c85c;}function sr(_0x4ab393){const _0x2fc84c={};if(_0x4ab393['isDefault']())return _0x2fc84c;let _0x38dc5e;if(_0x4ab393['index_']===R?_0x38dc5e='$priority':_0x4ab393['index_']===Mo?_0x38dc5e='$value':_0x4ab393['index_']===ye?_0x38dc5e='$key':(f(_0x4ab393['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x38dc5e=_0x4ab393['index_']['toString']()),_0x2fc84c['orderBy']=O(_0x38dc5e),_0x4ab393['startSet_']){const _0x48bde6=_0x4ab393['startAfterSet_']?'startAfter':'startAt';_0x2fc84c[_0x48bde6]=O(_0x4ab393['indexStartValue_']),_0x4ab393['startNameSet_']&&(_0x2fc84c[_0x48bde6]+=','+O(_0x4ab393['indexStartName_']));}if(_0x4ab393['endSet_']){const _0x9691e7=_0x4ab393['endBeforeSet_']?'endBefore':'endAt';_0x2fc84c[_0x9691e7]=O(_0x4ab393['indexEndValue_']),_0x4ab393['endNameSet_']&&(_0x2fc84c[_0x9691e7]+=','+O(_0x4ab393['indexEndName_']));}return _0x4ab393['limitSet_']&&(_0x4ab393['isViewFromLeft']()?_0x2fc84c['limitToFirst']=_0x4ab393['limit_']:_0x2fc84c['limitToLast']=_0x4ab393['limit_']),_0x2fc84c;}function rr(_0x3db525){const _0x381585={};if(_0x3db525['startSet_']&&(_0x381585['sp']=_0x3db525['indexStartValue_'],_0x3db525['startNameSet_']&&(_0x381585['sn']=_0x3db525['indexStartName_']),_0x381585['sin']=!_0x3db525['startAfterSet_']),_0x3db525['endSet_']&&(_0x381585['ep']=_0x3db525['indexEndValue_'],_0x3db525['endNameSet_']&&(_0x381585['en']=_0x3db525['indexEndName_']),_0x381585['ein']=!_0x3db525['endBeforeSet_']),_0x3db525['limitSet_']){_0x381585['l']=_0x3db525['limit_'];let _0x59585c=_0x3db525['viewFrom_'];_0x59585c===''&&(_0x3db525['isViewFromLeft']()?_0x59585c='l':_0x59585c='r'),_0x381585['vf']=_0x59585c;}return _0x3db525['index_']!==R&&(_0x381585['i']=_0x3db525['index_']['toString']()),_0x381585;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x417904){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x4af588,_0x3b178f){return _0x3b178f!==void 0x0?'tag$'+_0x3b178f:(f(_0x4af588['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x4af588['_path']['toString']());}constructor(_0x1c6272,_0x24e09b,_0x955caf,_0x4b8867){super(),this['repoInfo_']=_0x1c6272,this['onDataUpdate_']=_0x24e09b,this['authTokenProvider_']=_0x955caf,this['appCheckTokenProvider_']=_0x4b8867,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x27658c,_0x377c80,_0xe50697,_0x1c15ed){const _0x3febf6=_0x27658c['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3febf6+'\x20'+_0x27658c['_queryIdentifier']);const _0xe0d15d=pn['getListenId_'](_0x27658c,_0xe50697),_0x3ed191={};this['listens_'][_0xe0d15d]=_0x3ed191;const _0x280768=sr(_0x27658c['_queryParams']);this['restRequest_'](_0x3febf6+'.json',_0x280768,(_0x5b0514,_0x898283)=>{let _0x2203fa=_0x898283;if(_0x5b0514===0x194&&(_0x2203fa=null,_0x5b0514=null),_0x5b0514===null&&this['onDataUpdate_'](_0x3febf6,_0x2203fa,!0x1,_0xe50697),De(this['listens_'],_0xe0d15d)===_0x3ed191){let _0x1981cd;_0x5b0514?_0x5b0514===0x191?_0x1981cd='permission_denied':_0x1981cd='rest_error:'+_0x5b0514:_0x1981cd='ok',_0x1c15ed(_0x1981cd,null);}});}['unlisten'](_0x16bd43,_0x366c46){const _0x5cfde0=pn['getListenId_'](_0x16bd43,_0x366c46);delete this['listens_'][_0x5cfde0];}['get'](_0x27a46a){const _0x4053a5=sr(_0x27a46a['_queryParams']),_0x3bc9fa=_0x27a46a['_path']['toString'](),_0x1b444d=new ot();return this['restRequest_'](_0x3bc9fa+'.json',_0x4053a5,(_0x492e7d,_0x57a41a)=>{let _0x324323=_0x57a41a;_0x492e7d===0x194&&(_0x324323=null,_0x492e7d=null),_0x492e7d===null?(this['onDataUpdate_'](_0x3bc9fa,_0x324323,!0x1,null),_0x1b444d['resolve'](_0x324323)):_0x1b444d['reject'](new Error(_0x324323));}),_0x1b444d['promise'];}['refreshAuthToken'](_0x1b653f){}['restRequest_'](_0x59164d,_0x4e1ee3={},_0x47533a){return _0x4e1ee3['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x3fa8ce,_0x1717d3])=>{_0x3fa8ce&&_0x3fa8ce['accessToken']&&(_0x4e1ee3['auth']=_0x3fa8ce['accessToken']),_0x1717d3&&_0x1717d3['token']&&(_0x4e1ee3['ac']=_0x1717d3['token']);const _0xd7b25=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x59164d+'?ns='+this['repoInfo_']['namespace']+ct(_0x4e1ee3);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0xd7b25);const _0x305bb3=new XMLHttpRequest();_0x305bb3['onreadystatechange']=()=>{if(_0x47533a&&_0x305bb3['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0xd7b25+'\x20received.\x20status:',_0x305bb3['status'],'response:',_0x305bb3['responseText']);let _0x328b67=null;if(_0x305bb3['status']>=0xc8&&_0x305bb3['status']<0x12c){try{_0x328b67=At(_0x305bb3['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0xd7b25+':\x20'+_0x305bb3['responseText']);}_0x47533a(null,_0x328b67);}else _0x305bb3['status']!==0x191&&_0x305bb3['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0xd7b25+'\x20Status:\x20'+_0x305bb3['status']),_0x47533a(_0x305bb3['status']);_0x47533a=null;}},_0x305bb3['open']('GET',_0xd7b25,!0x0),_0x305bb3['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x43eb5d){return this['rootNode_']['getChild'](_0x43eb5d);}['updateSnapshot'](_0x59e2dd,_0x2bb7e8){this['rootNode_']=this['rootNode_']['updateChild'](_0x59e2dd,_0x2bb7e8);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x42cd03,_0x137cae,_0x59aadb){if(v(_0x137cae))_0x42cd03['value']=_0x59aadb,_0x42cd03['children']['clear']();else{if(_0x42cd03['value']!==null)_0x42cd03['value']=_0x42cd03['value']['updateChild'](_0x137cae,_0x59aadb);else{const _0x2f48f7=y(_0x137cae);_0x42cd03['children']['has'](_0x2f48f7)||_0x42cd03['children']['set'](_0x2f48f7,_n());const _0x53ba9f=_0x42cd03['children']['get'](_0x2f48f7);_0x137cae=b(_0x137cae),Fo(_0x53ba9f,_0x137cae,_0x59aadb);}}}function Ii(_0x2ee409,_0x1b4321,_0x307653){_0x2ee409['value']!==null?_0x307653(_0x1b4321,_0x2ee409['value']):Zh(_0x2ee409,(_0xb398f6,_0x33b348)=>{const _0x40db6f=new C(_0x1b4321['toString']()+'/'+_0xb398f6);Ii(_0x33b348,_0x40db6f,_0x307653);});}function Zh(_0x54c5f5,_0x28c3f0){_0x54c5f5['children']['forEach']((_0xf51c31,_0x1125a8)=>{_0x28c3f0(_0x1125a8,_0xf51c31);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x17afe4){this['collection_']=_0x17afe4,this['last_']=null;}['get'](){const _0x37336b=this['collection_']['get'](),_0xd32bbf={..._0x37336b};return this['last_']&&x(this['last_'],(_0x381e3a,_0x38851d)=>{_0xd32bbf[_0x381e3a]=_0xd32bbf[_0x381e3a]-_0x38851d;}),this['last_']=_0x37336b,_0xd32bbf;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x1492e6,_0x2771ec){this['server_']=_0x2771ec,this['statsToReport_']={},this['statsListener_']=new eu(_0x1492e6);const _0x2de526=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x2de526));}['reportStats_'](){const _0x4602e9=this['statsListener_']['get'](),_0x99c02b={};let _0x492929=!0x1;x(_0x4602e9,(_0x364048,_0x1a3e3d)=>{_0x1a3e3d>0x0&&J(this['statsToReport_'],_0x364048)&&(_0x99c02b[_0x364048]=_0x1a3e3d,_0x492929=!0x0);}),_0x492929&&this['server_']['reportStats'](_0x99c02b),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x46109d){_0x46109d[_0x46109d['OVERWRITE']=0x0]='OVERWRITE',_0x46109d[_0x46109d['MERGE']=0x1]='MERGE',_0x46109d[_0x46109d['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x46109d[_0x46109d['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x30ef0a){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x30ef0a,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x147b1d,_0x32b595,_0x265ea7){this['path']=_0x147b1d,this['affectedTree']=_0x32b595,this['revert']=_0x265ea7,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x1f13e5){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x232df8=this['affectedTree']['subtree'](new C(_0x1f13e5));return new gn(w(),_0x232df8,this['revert']);}}else return f(y(this['path'])===_0x1f13e5,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x301376,_0xe0329d){this['source']=_0x301376,this['path']=_0xe0329d,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x35581b){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x195b2b,_0xa346e5,_0x4a566b){this['source']=_0x195b2b,this['path']=_0xa346e5,this['snap']=_0x4a566b,this['type']=j['OVERWRITE'];}['operationForChild'](_0x1d383d){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x1d383d)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x2f7fb8,_0x324863,_0x18a11b){this['source']=_0x2f7fb8,this['path']=_0x324863,this['children']=_0x18a11b,this['type']=j['MERGE'];}['operationForChild'](_0x5a6f33){if(v(this['path'])){const _0x43b7b0=this['children']['subtree'](new C(_0x5a6f33));return _0x43b7b0['isEmpty']()?null:_0x43b7b0['value']?new Ue(this['source'],w(),_0x43b7b0['value']):new tt(this['source'],w(),_0x43b7b0);}else return f(y(this['path'])===_0x5a6f33,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0xf3c09f,_0x56ade6,_0x150348){this['node_']=_0xf3c09f,this['fullyInitialized_']=_0x56ade6,this['filtered_']=_0x150348;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x2905c5){if(v(_0x2905c5))return this['isFullyInitialized']()&&!this['filtered_'];const _0x1a6fac=y(_0x2905c5);return this['isCompleteForChild'](_0x1a6fac);}['isCompleteForChild'](_0x1b3496){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x1b3496);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x1db1ac){this['query_']=_0x1db1ac,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x448e0e,_0x4413ac,_0x346c71,_0x1d8f15){const _0x303bec=[],_0x3be841=[];return _0x4413ac['forEach'](_0x394548=>{_0x394548['type']==='child_changed'&&_0x448e0e['index_']['indexedValueChanged'](_0x394548['oldSnap'],_0x394548['snapshotNode'])&&_0x3be841['push'](zh(_0x394548['childName'],_0x394548['snapshotNode']));}),yt(_0x448e0e,_0x303bec,'child_removed',_0x4413ac,_0x1d8f15,_0x346c71),yt(_0x448e0e,_0x303bec,'child_added',_0x4413ac,_0x1d8f15,_0x346c71),yt(_0x448e0e,_0x303bec,'child_moved',_0x3be841,_0x1d8f15,_0x346c71),yt(_0x448e0e,_0x303bec,'child_changed',_0x4413ac,_0x1d8f15,_0x346c71),yt(_0x448e0e,_0x303bec,'value',_0x4413ac,_0x1d8f15,_0x346c71),_0x303bec;}function yt(_0x131127,_0x538a2f,_0x24ce14,_0x43cd38,_0x8297ca,_0x1c3839){const _0x5e9040=_0x43cd38['filter'](_0x360d75=>_0x360d75['type']===_0x24ce14);_0x5e9040['sort']((_0x35090b,_0x443272)=>au(_0x131127,_0x35090b,_0x443272)),_0x5e9040['forEach'](_0x1c6638=>{const _0x4b234d=ou(_0x131127,_0x1c6638,_0x1c3839);_0x8297ca['forEach'](_0x154d1a=>{_0x154d1a['respondsTo'](_0x1c6638['type'])&&_0x538a2f['push'](_0x154d1a['createEvent'](_0x4b234d,_0x131127['query_']));});});}function ou(_0x5606af,_0x11965b,_0x5d69b7){return _0x11965b['type']==='value'||_0x11965b['type']==='child_removed'||(_0x11965b['prevName']=_0x5d69b7['getPredecessorChildName'](_0x11965b['childName'],_0x11965b['snapshotNode'],_0x5606af['index_'])),_0x11965b;}function au(_0x1ddf3e,_0x569c7d,_0x21f35f){if(_0x569c7d['childName']==null||_0x21f35f['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0xb05e92=new E(_0x569c7d['childName'],_0x569c7d['snapshotNode']),_0x286759=new E(_0x21f35f['childName'],_0x21f35f['snapshotNode']);return _0x1ddf3e['index_']['compare'](_0xb05e92,_0x286759);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x122650,_0x29505b){return{'eventCache':_0x122650,'serverCache':_0x29505b};}function Tt(_0x393ba3,_0x8cd273,_0x4253b6,_0x2b1910){return Mn(new Ce(_0x8cd273,_0x4253b6,_0x2b1910),_0x393ba3['serverCache']);}function Uo(_0x368875,_0x23bf34,_0x8393f8,_0x218fb9){return Mn(_0x368875['eventCache'],new Ce(_0x23bf34,_0x8393f8,_0x218fb9));}function mn(_0x559de2){return _0x559de2['eventCache']['isFullyInitialized']()?_0x559de2['eventCache']['getNode']():null;}function We(_0x1c3119){return _0x1c3119['serverCache']['isFullyInitialized']()?_0x1c3119['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x2ba46c){let _0x4bc497=new S(null);return x(_0x2ba46c,(_0x4a7d89,_0x1f08d8)=>{_0x4bc497=_0x4bc497['set'](new C(_0x4a7d89),_0x1f08d8);}),_0x4bc497;}constructor(_0x3a7e68,_0x35261a=cu()){this['value']=_0x3a7e68,this['children']=_0x35261a;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x281063,_0x3fcbf6){if(this['value']!=null&&_0x3fcbf6(this['value']))return{'path':w(),'value':this['value']};if(v(_0x281063))return null;{const _0xbfb5bd=y(_0x281063),_0x36cc88=this['children']['get'](_0xbfb5bd);if(_0x36cc88!==null){const _0x5ce33f=_0x36cc88['findRootMostMatchingPathAndValue'](b(_0x281063),_0x3fcbf6);return _0x5ce33f!=null?{'path':k(new C(_0xbfb5bd),_0x5ce33f['path']),'value':_0x5ce33f['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x560ad9){return this['findRootMostMatchingPathAndValue'](_0x560ad9,()=>!0x0);}['subtree'](_0xe44611){if(v(_0xe44611))return this;{const _0x588927=y(_0xe44611),_0x1ee03c=this['children']['get'](_0x588927);return _0x1ee03c!==null?_0x1ee03c['subtree'](b(_0xe44611)):new S(null);}}['set'](_0x19e287,_0xedd188){if(v(_0x19e287))return new S(_0xedd188,this['children']);{const _0x4bb9bf=y(_0x19e287),_0x35afca=(this['children']['get'](_0x4bb9bf)||new S(null))['set'](b(_0x19e287),_0xedd188),_0x2c23ff=this['children']['insert'](_0x4bb9bf,_0x35afca);return new S(this['value'],_0x2c23ff);}}['remove'](_0xfc8f60){if(v(_0xfc8f60))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x5615dd=y(_0xfc8f60),_0x3c0192=this['children']['get'](_0x5615dd);if(_0x3c0192){const _0x57d963=_0x3c0192['remove'](b(_0xfc8f60));let _0xb4ba13;return _0x57d963['isEmpty']()?_0xb4ba13=this['children']['remove'](_0x5615dd):_0xb4ba13=this['children']['insert'](_0x5615dd,_0x57d963),this['value']===null&&_0xb4ba13['isEmpty']()?new S(null):new S(this['value'],_0xb4ba13);}else return this;}}['get'](_0x5473e1){if(v(_0x5473e1))return this['value'];{const _0x450b29=y(_0x5473e1),_0x3fd0d8=this['children']['get'](_0x450b29);return _0x3fd0d8?_0x3fd0d8['get'](b(_0x5473e1)):null;}}['setTree'](_0x51b8b6,_0x28f091){if(v(_0x51b8b6))return _0x28f091;{const _0xa86b29=y(_0x51b8b6),_0x279866=(this['children']['get'](_0xa86b29)||new S(null))['setTree'](b(_0x51b8b6),_0x28f091);let _0x25cf98;return _0x279866['isEmpty']()?_0x25cf98=this['children']['remove'](_0xa86b29):_0x25cf98=this['children']['insert'](_0xa86b29,_0x279866),new S(this['value'],_0x25cf98);}}['fold'](_0x558f97){return this['fold_'](w(),_0x558f97);}['fold_'](_0x315b28,_0x5b3c46){const _0x91a716={};return this['children']['inorderTraversal']((_0x4993f0,_0x3714d5)=>{_0x91a716[_0x4993f0]=_0x3714d5['fold_'](k(_0x315b28,_0x4993f0),_0x5b3c46);}),_0x5b3c46(_0x315b28,this['value'],_0x91a716);}['findOnPath'](_0x17b655,_0x115d01){return this['findOnPath_'](_0x17b655,w(),_0x115d01);}['findOnPath_'](_0x2f0476,_0x30f811,_0x58c6fb){const _0x51e31a=this['value']?_0x58c6fb(_0x30f811,this['value']):!0x1;if(_0x51e31a)return _0x51e31a;if(v(_0x2f0476))return null;{const _0x437f79=y(_0x2f0476),_0x597837=this['children']['get'](_0x437f79);return _0x597837?_0x597837['findOnPath_'](b(_0x2f0476),k(_0x30f811,_0x437f79),_0x58c6fb):null;}}['foreachOnPath'](_0x5960e8,_0x427565){return this['foreachOnPath_'](_0x5960e8,w(),_0x427565);}['foreachOnPath_'](_0x28ef8b,_0x2f172d,_0x2ab36f){if(v(_0x28ef8b))return this;{this['value']&&_0x2ab36f(_0x2f172d,this['value']);const _0x5187db=y(_0x28ef8b),_0x398ffe=this['children']['get'](_0x5187db);return _0x398ffe?_0x398ffe['foreachOnPath_'](b(_0x28ef8b),k(_0x2f172d,_0x5187db),_0x2ab36f):new S(null);}}['foreach'](_0x5e3d10){this['foreach_'](w(),_0x5e3d10);}['foreach_'](_0x351956,_0x4da1d4){this['children']['inorderTraversal']((_0x2d1851,_0x13863f)=>{_0x13863f['foreach_'](k(_0x351956,_0x2d1851),_0x4da1d4);}),this['value']&&_0x4da1d4(_0x351956,this['value']);}['foreachChild'](_0x28609a){this['children']['inorderTraversal']((_0x416dc9,_0x3fd116)=>{_0x3fd116['value']&&_0x28609a(_0x416dc9,_0x3fd116['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x1110a0){this['writeTree_']=_0x1110a0;}static['empty'](){return new Y(new S(null));}}function St(_0x4d132a,_0x478c78,_0x46417e){if(v(_0x478c78))return new Y(new S(_0x46417e));{const _0x49f138=_0x4d132a['writeTree_']['findRootMostValueAndPath'](_0x478c78);if(_0x49f138!=null){const _0x9f1c6e=_0x49f138['path'];let _0x3c1c24=_0x49f138['value'];const _0x5da6d3=F(_0x9f1c6e,_0x478c78);return _0x3c1c24=_0x3c1c24['updateChild'](_0x5da6d3,_0x46417e),new Y(_0x4d132a['writeTree_']['set'](_0x9f1c6e,_0x3c1c24));}else{const _0x1dfd38=new S(_0x46417e),_0x3b4041=_0x4d132a['writeTree_']['setTree'](_0x478c78,_0x1dfd38);return new Y(_0x3b4041);}}}function wi(_0xbcfb0d,_0x196775,_0x468a5f){let _0x945b55=_0xbcfb0d;return x(_0x468a5f,(_0x54df31,_0xa0eeb6)=>{_0x945b55=St(_0x945b55,k(_0x196775,_0x54df31),_0xa0eeb6);}),_0x945b55;}function ar(_0x1104f1,_0x4fb9e7){if(v(_0x4fb9e7))return Y['empty']();{const _0x32be45=_0x1104f1['writeTree_']['setTree'](_0x4fb9e7,new S(null));return new Y(_0x32be45);}}function Ci(_0x4c81b5,_0x573d0e){return $e(_0x4c81b5,_0x573d0e)!=null;}function $e(_0x5776a8,_0x457aad){const _0x34b79e=_0x5776a8['writeTree_']['findRootMostValueAndPath'](_0x457aad);return _0x34b79e!=null?_0x5776a8['writeTree_']['get'](_0x34b79e['path'])['getChild'](F(_0x34b79e['path'],_0x457aad)):null;}function cr(_0x510b18){const _0x4a8270=[],_0x2c9b6d=_0x510b18['writeTree_']['value'];return _0x2c9b6d!=null?_0x2c9b6d['isLeafNode']()||_0x2c9b6d['forEachChild'](R,(_0x1adb59,_0x136c92)=>{_0x4a8270['push'](new E(_0x1adb59,_0x136c92));}):_0x510b18['writeTree_']['children']['inorderTraversal']((_0x4ce0da,_0x24d5c1)=>{_0x24d5c1['value']!=null&&_0x4a8270['push'](new E(_0x4ce0da,_0x24d5c1['value']));}),_0x4a8270;}function ve(_0x45909c,_0x4485b0){if(v(_0x4485b0))return _0x45909c;{const _0x15162f=$e(_0x45909c,_0x4485b0);return _0x15162f!=null?new Y(new S(_0x15162f)):new Y(_0x45909c['writeTree_']['subtree'](_0x4485b0));}}function Ti(_0x5d7e89){return _0x5d7e89['writeTree_']['isEmpty']();}function nt(_0x54ad5e,_0x297705){return Wo(w(),_0x54ad5e['writeTree_'],_0x297705);}function Wo(_0x1a8c5c,_0x42622f,_0x5ce1a6){if(_0x42622f['value']!=null)return _0x5ce1a6['updateChild'](_0x1a8c5c,_0x42622f['value']);{let _0x11adb5=null;return _0x42622f['children']['inorderTraversal']((_0x4ab9ae,_0x3ec15c)=>{_0x4ab9ae==='.priority'?(f(_0x3ec15c['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x11adb5=_0x3ec15c['value']):_0x5ce1a6=Wo(k(_0x1a8c5c,_0x4ab9ae),_0x3ec15c,_0x5ce1a6);}),!_0x5ce1a6['getChild'](_0x1a8c5c)['isEmpty']()&&_0x11adb5!==null&&(_0x5ce1a6=_0x5ce1a6['updateChild'](k(_0x1a8c5c,'.priority'),_0x11adb5)),_0x5ce1a6;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x1b5e5a,_0x452f55){return $o(_0x452f55,_0x1b5e5a);}function lu(_0x31c4c3,_0x14b4f4,_0x59e271,_0x24fc83,_0x55419b){f(_0x24fc83>_0x31c4c3['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x55419b===void 0x0&&(_0x55419b=!0x0),_0x31c4c3['allWrites']['push']({'path':_0x14b4f4,'snap':_0x59e271,'writeId':_0x24fc83,'visible':_0x55419b}),_0x55419b&&(_0x31c4c3['visibleWrites']=St(_0x31c4c3['visibleWrites'],_0x14b4f4,_0x59e271)),_0x31c4c3['lastWriteId']=_0x24fc83;}function hu(_0x24bd12,_0x2e4dd9,_0x1040a5,_0x4ac54f){f(_0x4ac54f>_0x24bd12['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x24bd12['allWrites']['push']({'path':_0x2e4dd9,'children':_0x1040a5,'writeId':_0x4ac54f,'visible':!0x0}),_0x24bd12['visibleWrites']=wi(_0x24bd12['visibleWrites'],_0x2e4dd9,_0x1040a5),_0x24bd12['lastWriteId']=_0x4ac54f;}function uu(_0x4a2b0f,_0xdde792){for(let _0x1789ae=0x0;_0x1789ae<_0x4a2b0f['allWrites']['length'];_0x1789ae++){const _0x2d3bfb=_0x4a2b0f['allWrites'][_0x1789ae];if(_0x2d3bfb['writeId']===_0xdde792)return _0x2d3bfb;}return null;}function du(_0x4aa7b9,_0x55e6c5){const _0x7458f=_0x4aa7b9['allWrites']['findIndex'](_0x4c6e89=>_0x4c6e89['writeId']===_0x55e6c5);f(_0x7458f>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x128e49=_0x4aa7b9['allWrites'][_0x7458f];_0x4aa7b9['allWrites']['splice'](_0x7458f,0x1);let _0x3092a5=_0x128e49['visible'],_0x547e07=!0x1,_0x201f2f=_0x4aa7b9['allWrites']['length']-0x1;for(;_0x3092a5&&_0x201f2f>=0x0;){const _0x1791e5=_0x4aa7b9['allWrites'][_0x201f2f];_0x1791e5['visible']&&(_0x201f2f>=_0x7458f&&fu(_0x1791e5,_0x128e49['path'])?_0x3092a5=!0x1:G(_0x128e49['path'],_0x1791e5['path'])&&(_0x547e07=!0x0)),_0x201f2f--;}if(_0x3092a5){if(_0x547e07)return pu(_0x4aa7b9),!0x0;if(_0x128e49['snap'])_0x4aa7b9['visibleWrites']=ar(_0x4aa7b9['visibleWrites'],_0x128e49['path']);else{const _0x1cde2a=_0x128e49['children'];x(_0x1cde2a,_0x49d07a=>{_0x4aa7b9['visibleWrites']=ar(_0x4aa7b9['visibleWrites'],k(_0x128e49['path'],_0x49d07a));});}return!0x0;}else return!0x1;}function fu(_0x1ac23b,_0x28dcdc){if(_0x1ac23b['snap'])return G(_0x1ac23b['path'],_0x28dcdc);for(const _0x2dcfb6 in _0x1ac23b['children'])if(_0x1ac23b['children']['hasOwnProperty'](_0x2dcfb6)&&G(k(_0x1ac23b['path'],_0x2dcfb6),_0x28dcdc))return!0x0;return!0x1;}function pu(_0x583b96){_0x583b96['visibleWrites']=Bo(_0x583b96['allWrites'],_u,w()),_0x583b96['allWrites']['length']>0x0?_0x583b96['lastWriteId']=_0x583b96['allWrites'][_0x583b96['allWrites']['length']-0x1]['writeId']:_0x583b96['lastWriteId']=-0x1;}function _u(_0x15dd18){return _0x15dd18['visible'];}function Bo(_0x3ee242,_0xeaf36b,_0x3bb2f3){let _0x4bdf0b=Y['empty']();for(let _0x4a4780=0x0;_0x4a4780<_0x3ee242['length'];++_0x4a4780){const _0x173506=_0x3ee242[_0x4a4780];if(_0xeaf36b(_0x173506)){const _0x47609a=_0x173506['path'];let _0x465537;if(_0x173506['snap'])G(_0x3bb2f3,_0x47609a)?(_0x465537=F(_0x3bb2f3,_0x47609a),_0x4bdf0b=St(_0x4bdf0b,_0x465537,_0x173506['snap'])):G(_0x47609a,_0x3bb2f3)&&(_0x465537=F(_0x47609a,_0x3bb2f3),_0x4bdf0b=St(_0x4bdf0b,w(),_0x173506['snap']['getChild'](_0x465537)));else{if(_0x173506['children']){if(G(_0x3bb2f3,_0x47609a))_0x465537=F(_0x3bb2f3,_0x47609a),_0x4bdf0b=wi(_0x4bdf0b,_0x465537,_0x173506['children']);else{if(G(_0x47609a,_0x3bb2f3)){if(_0x465537=F(_0x47609a,_0x3bb2f3),v(_0x465537))_0x4bdf0b=wi(_0x4bdf0b,w(),_0x173506['children']);else{const _0x55ad5d=De(_0x173506['children'],y(_0x465537));if(_0x55ad5d){const _0xde467f=_0x55ad5d['getChild'](b(_0x465537));_0x4bdf0b=St(_0x4bdf0b,w(),_0xde467f);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x4bdf0b;}function Vo(_0x2b21a4,_0xbffb18,_0x471537,_0x58d99a,_0x526747){if(!_0x58d99a&&!_0x526747){const _0x64ee6c=$e(_0x2b21a4['visibleWrites'],_0xbffb18);if(_0x64ee6c!=null)return _0x64ee6c;{const _0x15dc04=ve(_0x2b21a4['visibleWrites'],_0xbffb18);if(Ti(_0x15dc04))return _0x471537;if(_0x471537==null&&!Ci(_0x15dc04,w()))return null;{const _0xc85610=_0x471537||g['EMPTY_NODE'];return nt(_0x15dc04,_0xc85610);}}}else{const _0x1c4e2c=ve(_0x2b21a4['visibleWrites'],_0xbffb18);if(!_0x526747&&Ti(_0x1c4e2c))return _0x471537;if(!_0x526747&&_0x471537==null&&!Ci(_0x1c4e2c,w()))return null;{const _0x131211=function(_0x9173ea){return(_0x9173ea['visible']||_0x526747)&&(!_0x58d99a||!~_0x58d99a['indexOf'](_0x9173ea['writeId']))&&(G(_0x9173ea['path'],_0xbffb18)||G(_0xbffb18,_0x9173ea['path']));},_0x1df088=Bo(_0x2b21a4['allWrites'],_0x131211,_0xbffb18),_0x28bd31=_0x471537||g['EMPTY_NODE'];return nt(_0x1df088,_0x28bd31);}}}function gu(_0x181f18,_0x4eeb76,_0xe65444){let _0x13a8ae=g['EMPTY_NODE'];const _0x1caf4f=$e(_0x181f18['visibleWrites'],_0x4eeb76);if(_0x1caf4f)return _0x1caf4f['isLeafNode']()||_0x1caf4f['forEachChild'](R,(_0x1397cd,_0x316c58)=>{_0x13a8ae=_0x13a8ae['updateImmediateChild'](_0x1397cd,_0x316c58);}),_0x13a8ae;if(_0xe65444){const _0x51bc9d=ve(_0x181f18['visibleWrites'],_0x4eeb76);return _0xe65444['forEachChild'](R,(_0x23c2da,_0x302b5a)=>{const _0x48425e=nt(ve(_0x51bc9d,new C(_0x23c2da)),_0x302b5a);_0x13a8ae=_0x13a8ae['updateImmediateChild'](_0x23c2da,_0x48425e);}),cr(_0x51bc9d)['forEach'](_0x196eb0=>{_0x13a8ae=_0x13a8ae['updateImmediateChild'](_0x196eb0['name'],_0x196eb0['node']);}),_0x13a8ae;}else{const _0x7813d5=ve(_0x181f18['visibleWrites'],_0x4eeb76);return cr(_0x7813d5)['forEach'](_0x5d8a28=>{_0x13a8ae=_0x13a8ae['updateImmediateChild'](_0x5d8a28['name'],_0x5d8a28['node']);}),_0x13a8ae;}}function mu(_0x52b918,_0x2bb646,_0x23f72e,_0x16d3a1,_0x112344){f(_0x16d3a1||_0x112344,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x1a6d22=k(_0x2bb646,_0x23f72e);if(Ci(_0x52b918['visibleWrites'],_0x1a6d22))return null;{const _0x292fa3=ve(_0x52b918['visibleWrites'],_0x1a6d22);return Ti(_0x292fa3)?_0x112344['getChild'](_0x23f72e):nt(_0x292fa3,_0x112344['getChild'](_0x23f72e));}}function yu(_0x21a3ce,_0x369104,_0x4aaa7c,_0x3c62ba){const _0x3f39f8=k(_0x369104,_0x4aaa7c),_0x2bb937=$e(_0x21a3ce['visibleWrites'],_0x3f39f8);if(_0x2bb937!=null)return _0x2bb937;if(_0x3c62ba['isCompleteForChild'](_0x4aaa7c)){const _0x10117d=ve(_0x21a3ce['visibleWrites'],_0x3f39f8);return nt(_0x10117d,_0x3c62ba['getNode']()['getImmediateChild'](_0x4aaa7c));}else return null;}function vu(_0x1ae349,_0x47435e){return $e(_0x1ae349['visibleWrites'],_0x47435e);}function Eu(_0x102928,_0x505289,_0x1d4861,_0x3b6a02,_0x20d8a6,_0x27a632,_0x38ea91){let _0x4a397b;const _0x98b54f=ve(_0x102928['visibleWrites'],_0x505289),_0x127aa1=$e(_0x98b54f,w());if(_0x127aa1!=null)_0x4a397b=_0x127aa1;else{if(_0x1d4861!=null)_0x4a397b=nt(_0x98b54f,_0x1d4861);else return[];}if(_0x4a397b=_0x4a397b['withIndex'](_0x38ea91),!_0x4a397b['isEmpty']()&&!_0x4a397b['isLeafNode']()){const _0x3952a2=[],_0x1257d9=_0x38ea91['getCompare'](),_0x28a97d=_0x27a632?_0x4a397b['getReverseIteratorFrom'](_0x3b6a02,_0x38ea91):_0x4a397b['getIteratorFrom'](_0x3b6a02,_0x38ea91);let _0x12f4d2=_0x28a97d['getNext']();for(;_0x12f4d2&&_0x3952a2['length']<_0x20d8a6;)_0x1257d9(_0x12f4d2,_0x3b6a02)!==0x0&&_0x3952a2['push'](_0x12f4d2),_0x12f4d2=_0x28a97d['getNext']();return _0x3952a2;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x8d031c,_0x1e52d5,_0x91bf3d,_0x190618){return Vo(_0x8d031c['writeTree'],_0x8d031c['treePath'],_0x1e52d5,_0x91bf3d,_0x190618);}function ns(_0x42fa54,_0x414785){return gu(_0x42fa54['writeTree'],_0x42fa54['treePath'],_0x414785);}function lr(_0x29b612,_0xdc7145,_0x5683a0,_0x2ed03f){return mu(_0x29b612['writeTree'],_0x29b612['treePath'],_0xdc7145,_0x5683a0,_0x2ed03f);}function vn(_0x127fed,_0x14a50a){return vu(_0x127fed['writeTree'],k(_0x127fed['treePath'],_0x14a50a));}function wu(_0x16a9d5,_0x60ee3a,_0x405017,_0x53692f,_0x22ec20,_0x1f9489){return Eu(_0x16a9d5['writeTree'],_0x16a9d5['treePath'],_0x60ee3a,_0x405017,_0x53692f,_0x22ec20,_0x1f9489);}function is(_0x5093fd,_0x2a2901,_0x419253){return yu(_0x5093fd['writeTree'],_0x5093fd['treePath'],_0x2a2901,_0x419253);}function Ho(_0x499b96,_0x3a85a1){return $o(k(_0x499b96['treePath'],_0x3a85a1),_0x499b96['writeTree']);}function $o(_0x125deb,_0x4139ba){return{'treePath':_0x125deb,'writeTree':_0x4139ba};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x5e25c8){const _0xee1b7c=_0x5e25c8['type'],_0x4ee427=_0x5e25c8['childName'];f(_0xee1b7c==='child_added'||_0xee1b7c==='child_changed'||_0xee1b7c==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x4ee427!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x98c58b=this['changeMap']['get'](_0x4ee427);if(_0x98c58b){const _0x2bfde5=_0x98c58b['type'];if(_0xee1b7c==='child_added'&&_0x2bfde5==='child_removed')this['changeMap']['set'](_0x4ee427,Dt(_0x4ee427,_0x5e25c8['snapshotNode'],_0x98c58b['snapshotNode']));else{if(_0xee1b7c==='child_removed'&&_0x2bfde5==='child_added')this['changeMap']['delete'](_0x4ee427);else{if(_0xee1b7c==='child_removed'&&_0x2bfde5==='child_changed')this['changeMap']['set'](_0x4ee427,Ot(_0x4ee427,_0x98c58b['oldSnap']));else{if(_0xee1b7c==='child_changed'&&_0x2bfde5==='child_added')this['changeMap']['set'](_0x4ee427,et(_0x4ee427,_0x5e25c8['snapshotNode']));else{if(_0xee1b7c==='child_changed'&&_0x2bfde5==='child_changed')this['changeMap']['set'](_0x4ee427,Dt(_0x4ee427,_0x5e25c8['snapshotNode'],_0x98c58b['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x5e25c8+'\x20occurred\x20after\x20'+_0x98c58b);}}}}}else this['changeMap']['set'](_0x4ee427,_0x5e25c8);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x7aa803){return null;}['getChildAfterChild'](_0x5be7fb,_0x1bcd4b,_0x65cbf1){return null;}}const Go=new Tu();class ss{constructor(_0x1b567e,_0x3f2d23,_0x4642a8=null){this['writes_']=_0x1b567e,this['viewCache_']=_0x3f2d23,this['optCompleteServerCache_']=_0x4642a8;}['getCompleteChild'](_0x29c9da){const _0x270f07=this['viewCache_']['eventCache'];if(_0x270f07['isCompleteForChild'](_0x29c9da))return _0x270f07['getNode']()['getImmediateChild'](_0x29c9da);{const _0x40804b=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x29c9da,_0x40804b);}}['getChildAfterChild'](_0x1396b7,_0x191050,_0x5e224d){const _0x2442f2=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x57a0f0=wu(this['writes_'],_0x2442f2,_0x191050,0x1,_0x5e224d,_0x1396b7);return _0x57a0f0['length']===0x0?null:_0x57a0f0[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x25f6d3){return{'filter':_0x25f6d3};}function bu(_0xe42bb5,_0x3b0b0c){f(_0x3b0b0c['eventCache']['getNode']()['isIndexed'](_0xe42bb5['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x3b0b0c['serverCache']['getNode']()['isIndexed'](_0xe42bb5['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x2666f9,_0x8d694f,_0x232956,_0x675b8d,_0x3998c0){const _0x1d7231=new Cu();let _0x43326a,_0x380435;if(_0x232956['type']===j['OVERWRITE']){const _0x53bf52=_0x232956;_0x53bf52['source']['fromUser']?_0x43326a=Si(_0x2666f9,_0x8d694f,_0x53bf52['path'],_0x53bf52['snap'],_0x675b8d,_0x3998c0,_0x1d7231):(f(_0x53bf52['source']['fromServer'],'Unknown\x20source.'),_0x380435=_0x53bf52['source']['tagged']||_0x8d694f['serverCache']['isFiltered']()&&!v(_0x53bf52['path']),_0x43326a=En(_0x2666f9,_0x8d694f,_0x53bf52['path'],_0x53bf52['snap'],_0x675b8d,_0x3998c0,_0x380435,_0x1d7231));}else{if(_0x232956['type']===j['MERGE']){const _0x472f1b=_0x232956;_0x472f1b['source']['fromUser']?_0x43326a=ku(_0x2666f9,_0x8d694f,_0x472f1b['path'],_0x472f1b['children'],_0x675b8d,_0x3998c0,_0x1d7231):(f(_0x472f1b['source']['fromServer'],'Unknown\x20source.'),_0x380435=_0x472f1b['source']['tagged']||_0x8d694f['serverCache']['isFiltered'](),_0x43326a=bi(_0x2666f9,_0x8d694f,_0x472f1b['path'],_0x472f1b['children'],_0x675b8d,_0x3998c0,_0x380435,_0x1d7231));}else{if(_0x232956['type']===j['ACK_USER_WRITE']){const _0xf314c4=_0x232956;_0xf314c4['revert']?_0x43326a=Ou(_0x2666f9,_0x8d694f,_0xf314c4['path'],_0x675b8d,_0x3998c0,_0x1d7231):_0x43326a=Nu(_0x2666f9,_0x8d694f,_0xf314c4['path'],_0xf314c4['affectedTree'],_0x675b8d,_0x3998c0,_0x1d7231);}else{if(_0x232956['type']===j['LISTEN_COMPLETE'])_0x43326a=Pu(_0x2666f9,_0x8d694f,_0x232956['path'],_0x675b8d,_0x1d7231);else throw rt('Unknown\x20operation\x20type:\x20'+_0x232956['type']);}}}const _0x2f936a=_0x1d7231['getChanges']();return Au(_0x8d694f,_0x43326a,_0x2f936a),{'viewCache':_0x43326a,'changes':_0x2f936a};}function Au(_0x38bb2f,_0x37819b,_0x3e155b){const _0x525afa=_0x37819b['eventCache'];if(_0x525afa['isFullyInitialized']()){const _0x4b204f=_0x525afa['getNode']()['isLeafNode']()||_0x525afa['getNode']()['isEmpty'](),_0xc0f3c2=mn(_0x38bb2f);(_0x3e155b['length']>0x0||!_0x38bb2f['eventCache']['isFullyInitialized']()||_0x4b204f&&!_0x525afa['getNode']()['equals'](_0xc0f3c2)||!_0x525afa['getNode']()['getPriority']()['equals'](_0xc0f3c2['getPriority']()))&&_0x3e155b['push'](Lo(mn(_0x37819b)));}}function qo(_0x30028f,_0x230053,_0x414ec9,_0x13c94a,_0x9150db,_0x5dd327){const _0x5a9756=_0x230053['eventCache'];if(vn(_0x13c94a,_0x414ec9)!=null)return _0x230053;{let _0x26eeef,_0x5bc3a9;if(v(_0x414ec9)){if(f(_0x230053['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x230053['serverCache']['isFiltered']()){const _0x2b5354=We(_0x230053),_0xa3d954=_0x2b5354 instanceof g?_0x2b5354:g['EMPTY_NODE'],_0x26af8d=ns(_0x13c94a,_0xa3d954);_0x26eeef=_0x30028f['filter']['updateFullNode'](_0x230053['eventCache']['getNode'](),_0x26af8d,_0x5dd327);}else{const _0x5467d1=yn(_0x13c94a,We(_0x230053));_0x26eeef=_0x30028f['filter']['updateFullNode'](_0x230053['eventCache']['getNode'](),_0x5467d1,_0x5dd327);}}else{const _0x9a1e5a=y(_0x414ec9);if(_0x9a1e5a==='.priority'){f(we(_0x414ec9)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x48875c=_0x5a9756['getNode']();_0x5bc3a9=_0x230053['serverCache']['getNode']();const _0x26e4b8=lr(_0x13c94a,_0x414ec9,_0x48875c,_0x5bc3a9);_0x26e4b8!=null?_0x26eeef=_0x30028f['filter']['updatePriority'](_0x48875c,_0x26e4b8):_0x26eeef=_0x5a9756['getNode']();}else{const _0x14468a=b(_0x414ec9);let _0x30b379;if(_0x5a9756['isCompleteForChild'](_0x9a1e5a)){_0x5bc3a9=_0x230053['serverCache']['getNode']();const _0x49c7bf=lr(_0x13c94a,_0x414ec9,_0x5a9756['getNode'](),_0x5bc3a9);_0x49c7bf!=null?_0x30b379=_0x5a9756['getNode']()['getImmediateChild'](_0x9a1e5a)['updateChild'](_0x14468a,_0x49c7bf):_0x30b379=_0x5a9756['getNode']()['getImmediateChild'](_0x9a1e5a);}else _0x30b379=is(_0x13c94a,_0x9a1e5a,_0x230053['serverCache']);_0x30b379!=null?_0x26eeef=_0x30028f['filter']['updateChild'](_0x5a9756['getNode'](),_0x9a1e5a,_0x30b379,_0x14468a,_0x9150db,_0x5dd327):_0x26eeef=_0x5a9756['getNode']();}}return Tt(_0x230053,_0x26eeef,_0x5a9756['isFullyInitialized']()||v(_0x414ec9),_0x30028f['filter']['filtersNodes']());}}function En(_0x39e892,_0x4abffb,_0x5ec3b6,_0x2fa9ec,_0x37de2c,_0xb0a8f1,_0x10cfcd,_0x55a793){const _0x42df85=_0x4abffb['serverCache'];let _0x3f4570;const _0x15ac77=_0x10cfcd?_0x39e892['filter']:_0x39e892['filter']['getIndexedFilter']();if(v(_0x5ec3b6))_0x3f4570=_0x15ac77['updateFullNode'](_0x42df85['getNode'](),_0x2fa9ec,null);else{if(_0x15ac77['filtersNodes']()&&!_0x42df85['isFiltered']()){const _0x186b04=_0x42df85['getNode']()['updateChild'](_0x5ec3b6,_0x2fa9ec);_0x3f4570=_0x15ac77['updateFullNode'](_0x42df85['getNode'](),_0x186b04,null);}else{const _0x359a9b=y(_0x5ec3b6);if(!_0x42df85['isCompleteForPath'](_0x5ec3b6)&&we(_0x5ec3b6)>0x1)return _0x4abffb;const _0x504e15=b(_0x5ec3b6),_0xe31bb9=_0x42df85['getNode']()['getImmediateChild'](_0x359a9b)['updateChild'](_0x504e15,_0x2fa9ec);_0x359a9b==='.priority'?_0x3f4570=_0x15ac77['updatePriority'](_0x42df85['getNode'](),_0xe31bb9):_0x3f4570=_0x15ac77['updateChild'](_0x42df85['getNode'](),_0x359a9b,_0xe31bb9,_0x504e15,Go,null);}}const _0x652a99=Uo(_0x4abffb,_0x3f4570,_0x42df85['isFullyInitialized']()||v(_0x5ec3b6),_0x15ac77['filtersNodes']()),_0x4ec4b6=new ss(_0x37de2c,_0x652a99,_0xb0a8f1);return qo(_0x39e892,_0x652a99,_0x5ec3b6,_0x37de2c,_0x4ec4b6,_0x55a793);}function Si(_0x239583,_0x496961,_0x51f23c,_0x591e08,_0xb82aec,_0x7dbfcb,_0x5b4b16){const _0x49619a=_0x496961['eventCache'];let _0x25dacc,_0x531e9e;const _0x3d55fb=new ss(_0xb82aec,_0x496961,_0x7dbfcb);if(v(_0x51f23c))_0x531e9e=_0x239583['filter']['updateFullNode'](_0x496961['eventCache']['getNode'](),_0x591e08,_0x5b4b16),_0x25dacc=Tt(_0x496961,_0x531e9e,!0x0,_0x239583['filter']['filtersNodes']());else{const _0x40e49e=y(_0x51f23c);if(_0x40e49e==='.priority')_0x531e9e=_0x239583['filter']['updatePriority'](_0x496961['eventCache']['getNode'](),_0x591e08),_0x25dacc=Tt(_0x496961,_0x531e9e,_0x49619a['isFullyInitialized'](),_0x49619a['isFiltered']());else{const _0x41afc4=b(_0x51f23c),_0x3645ef=_0x49619a['getNode']()['getImmediateChild'](_0x40e49e);let _0x1f2aec;if(v(_0x41afc4))_0x1f2aec=_0x591e08;else{const _0x5d4792=_0x3d55fb['getCompleteChild'](_0x40e49e);_0x5d4792!=null?zi(_0x41afc4)==='.priority'&&_0x5d4792['getChild'](Ro(_0x41afc4))['isEmpty']()?_0x1f2aec=_0x5d4792:_0x1f2aec=_0x5d4792['updateChild'](_0x41afc4,_0x591e08):_0x1f2aec=g['EMPTY_NODE'];}if(_0x3645ef['equals'](_0x1f2aec))_0x25dacc=_0x496961;else{const _0x4fd996=_0x239583['filter']['updateChild'](_0x49619a['getNode'](),_0x40e49e,_0x1f2aec,_0x41afc4,_0x3d55fb,_0x5b4b16);_0x25dacc=Tt(_0x496961,_0x4fd996,_0x49619a['isFullyInitialized'](),_0x239583['filter']['filtersNodes']());}}}return _0x25dacc;}function hr(_0x9f644d,_0x27624e){return _0x9f644d['eventCache']['isCompleteForChild'](_0x27624e);}function ku(_0x5ba835,_0x1a0eed,_0x2f532d,_0x308677,_0x175e7f,_0x52b77d,_0x4c594c){let _0x226c74=_0x1a0eed;return _0x308677['foreach']((_0x38dcfd,_0x1d45ce)=>{const _0x3c76e4=k(_0x2f532d,_0x38dcfd);hr(_0x1a0eed,y(_0x3c76e4))&&(_0x226c74=Si(_0x5ba835,_0x226c74,_0x3c76e4,_0x1d45ce,_0x175e7f,_0x52b77d,_0x4c594c));}),_0x308677['foreach']((_0x366a51,_0x535deb)=>{const _0x1d3115=k(_0x2f532d,_0x366a51);hr(_0x1a0eed,y(_0x1d3115))||(_0x226c74=Si(_0x5ba835,_0x226c74,_0x1d3115,_0x535deb,_0x175e7f,_0x52b77d,_0x4c594c));}),_0x226c74;}function ur(_0x208da4,_0x3975dd,_0x3096fe){return _0x3096fe['foreach']((_0x518c37,_0x1cd9bf)=>{_0x3975dd=_0x3975dd['updateChild'](_0x518c37,_0x1cd9bf);}),_0x3975dd;}function bi(_0x59ed95,_0x3d5463,_0x3cdfa8,_0x3b8db2,_0x452a9c,_0x51aeb9,_0x35f77a,_0x340528){if(_0x3d5463['serverCache']['getNode']()['isEmpty']()&&!_0x3d5463['serverCache']['isFullyInitialized']())return _0x3d5463;let _0x5e4306=_0x3d5463,_0x3d004b;v(_0x3cdfa8)?_0x3d004b=_0x3b8db2:_0x3d004b=new S(null)['setTree'](_0x3cdfa8,_0x3b8db2);const _0x24f667=_0x3d5463['serverCache']['getNode']();return _0x3d004b['children']['inorderTraversal']((_0x53ef74,_0x47dfdb)=>{if(_0x24f667['hasChild'](_0x53ef74)){const _0x178b38=_0x3d5463['serverCache']['getNode']()['getImmediateChild'](_0x53ef74),_0x50c16c=ur(_0x59ed95,_0x178b38,_0x47dfdb);_0x5e4306=En(_0x59ed95,_0x5e4306,new C(_0x53ef74),_0x50c16c,_0x452a9c,_0x51aeb9,_0x35f77a,_0x340528);}}),_0x3d004b['children']['inorderTraversal']((_0x38e22f,_0xca6b2a)=>{const _0x1b6755=!_0x3d5463['serverCache']['isCompleteForChild'](_0x38e22f)&&_0xca6b2a['value']===null;if(!_0x24f667['hasChild'](_0x38e22f)&&!_0x1b6755){const _0x286e4a=_0x3d5463['serverCache']['getNode']()['getImmediateChild'](_0x38e22f),_0x2458c5=ur(_0x59ed95,_0x286e4a,_0xca6b2a);_0x5e4306=En(_0x59ed95,_0x5e4306,new C(_0x38e22f),_0x2458c5,_0x452a9c,_0x51aeb9,_0x35f77a,_0x340528);}}),_0x5e4306;}function Nu(_0x2a48ff,_0x528dbc,_0x289200,_0x648401,_0x1c8ff6,_0x3f00cb,_0x2fdb49){if(vn(_0x1c8ff6,_0x289200)!=null)return _0x528dbc;const _0x3e17f4=_0x528dbc['serverCache']['isFiltered'](),_0x4ae4b3=_0x528dbc['serverCache'];if(_0x648401['value']!=null){if(v(_0x289200)&&_0x4ae4b3['isFullyInitialized']()||_0x4ae4b3['isCompleteForPath'](_0x289200))return En(_0x2a48ff,_0x528dbc,_0x289200,_0x4ae4b3['getNode']()['getChild'](_0x289200),_0x1c8ff6,_0x3f00cb,_0x3e17f4,_0x2fdb49);if(v(_0x289200)){let _0x188604=new S(null);return _0x4ae4b3['getNode']()['forEachChild'](ye,(_0x2454c4,_0x129434)=>{_0x188604=_0x188604['set'](new C(_0x2454c4),_0x129434);}),bi(_0x2a48ff,_0x528dbc,_0x289200,_0x188604,_0x1c8ff6,_0x3f00cb,_0x3e17f4,_0x2fdb49);}else return _0x528dbc;}else{let _0x56f352=new S(null);return _0x648401['foreach']((_0x4ca037,_0x2084b6)=>{const _0xca75d4=k(_0x289200,_0x4ca037);_0x4ae4b3['isCompleteForPath'](_0xca75d4)&&(_0x56f352=_0x56f352['set'](_0x4ca037,_0x4ae4b3['getNode']()['getChild'](_0xca75d4)));}),bi(_0x2a48ff,_0x528dbc,_0x289200,_0x56f352,_0x1c8ff6,_0x3f00cb,_0x3e17f4,_0x2fdb49);}}function Pu(_0x42fdff,_0x3b445c,_0x15e45e,_0x14ef45,_0x2e329f){const _0x14df9b=_0x3b445c['serverCache'],_0x5751c4=Uo(_0x3b445c,_0x14df9b['getNode'](),_0x14df9b['isFullyInitialized']()||v(_0x15e45e),_0x14df9b['isFiltered']());return qo(_0x42fdff,_0x5751c4,_0x15e45e,_0x14ef45,Go,_0x2e329f);}function Ou(_0x3bc5ba,_0x1ae139,_0x10f6ef,_0xba2535,_0x50392b,_0x4a89cc){let _0x3515cd;if(vn(_0xba2535,_0x10f6ef)!=null)return _0x1ae139;{const _0x598461=new ss(_0xba2535,_0x1ae139,_0x50392b),_0x4db59b=_0x1ae139['eventCache']['getNode']();let _0x493795;if(v(_0x10f6ef)||y(_0x10f6ef)==='.priority'){let _0x2cd60f;if(_0x1ae139['serverCache']['isFullyInitialized']())_0x2cd60f=yn(_0xba2535,We(_0x1ae139));else{const _0x20b068=_0x1ae139['serverCache']['getNode']();f(_0x20b068 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x2cd60f=ns(_0xba2535,_0x20b068);}_0x2cd60f=_0x2cd60f,_0x493795=_0x3bc5ba['filter']['updateFullNode'](_0x4db59b,_0x2cd60f,_0x4a89cc);}else{const _0x333b3c=y(_0x10f6ef);let _0x8bd0ec=is(_0xba2535,_0x333b3c,_0x1ae139['serverCache']);_0x8bd0ec==null&&_0x1ae139['serverCache']['isCompleteForChild'](_0x333b3c)&&(_0x8bd0ec=_0x4db59b['getImmediateChild'](_0x333b3c)),_0x8bd0ec!=null?_0x493795=_0x3bc5ba['filter']['updateChild'](_0x4db59b,_0x333b3c,_0x8bd0ec,b(_0x10f6ef),_0x598461,_0x4a89cc):_0x1ae139['eventCache']['getNode']()['hasChild'](_0x333b3c)?_0x493795=_0x3bc5ba['filter']['updateChild'](_0x4db59b,_0x333b3c,g['EMPTY_NODE'],b(_0x10f6ef),_0x598461,_0x4a89cc):_0x493795=_0x4db59b,_0x493795['isEmpty']()&&_0x1ae139['serverCache']['isFullyInitialized']()&&(_0x3515cd=yn(_0xba2535,We(_0x1ae139)),_0x3515cd['isLeafNode']()&&(_0x493795=_0x3bc5ba['filter']['updateFullNode'](_0x493795,_0x3515cd,_0x4a89cc)));}return _0x3515cd=_0x1ae139['serverCache']['isFullyInitialized']()||vn(_0xba2535,w())!=null,Tt(_0x1ae139,_0x493795,_0x3515cd,_0x3bc5ba['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x283c6e,_0x476e25){this['query_']=_0x283c6e,this['eventRegistrations_']=[];const _0x3c2725=this['query_']['_queryParams'],_0x1bb49b=new Ji(_0x3c2725['getIndex']()),_0x469056=Kh(_0x3c2725);this['processor_']=Su(_0x469056);const _0x4b52c7=_0x476e25['serverCache'],_0x18ef68=_0x476e25['eventCache'],_0x1dc14d=_0x1bb49b['updateFullNode'](g['EMPTY_NODE'],_0x4b52c7['getNode'](),null),_0x1a6976=_0x469056['updateFullNode'](g['EMPTY_NODE'],_0x18ef68['getNode'](),null),_0x34b48f=new Ce(_0x1dc14d,_0x4b52c7['isFullyInitialized'](),_0x1bb49b['filtersNodes']()),_0x3772f2=new Ce(_0x1a6976,_0x18ef68['isFullyInitialized'](),_0x469056['filtersNodes']());this['viewCache_']=Mn(_0x3772f2,_0x34b48f),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x2b12b3){return _0x2b12b3['viewCache_']['serverCache']['getNode']();}function Lu(_0x140c0){return mn(_0x140c0['viewCache_']);}function xu(_0x22f3b2,_0x58fefb){const _0x1b5db=We(_0x22f3b2['viewCache_']);return _0x1b5db&&(_0x22f3b2['query']['_queryParams']['loadsAllData']()||!v(_0x58fefb)&&!_0x1b5db['getImmediateChild'](y(_0x58fefb))['isEmpty']())?_0x1b5db['getChild'](_0x58fefb):null;}function dr(_0x4a66f4){return _0x4a66f4['eventRegistrations_']['length']===0x0;}function Fu(_0x1b6a94,_0x2d2ee7){_0x1b6a94['eventRegistrations_']['push'](_0x2d2ee7);}function fr(_0x14d663,_0x456af1,_0x8bd206){const _0x18ee55=[];if(_0x8bd206){f(_0x456af1==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x34ea75=_0x14d663['query']['_path'];_0x14d663['eventRegistrations_']['forEach'](_0x5075e3=>{const _0x3b095f=_0x5075e3['createCancelEvent'](_0x8bd206,_0x34ea75);_0x3b095f&&_0x18ee55['push'](_0x3b095f);});}if(_0x456af1){let _0x19d426=[];for(let _0x1b459d=0x0;_0x1b459d<_0x14d663['eventRegistrations_']['length'];++_0x1b459d){const _0x84aa52=_0x14d663['eventRegistrations_'][_0x1b459d];if(!_0x84aa52['matches'](_0x456af1))_0x19d426['push'](_0x84aa52);else{if(_0x456af1['hasAnyCallback']()){_0x19d426=_0x19d426['concat'](_0x14d663['eventRegistrations_']['slice'](_0x1b459d+0x1));break;}}}_0x14d663['eventRegistrations_']=_0x19d426;}else _0x14d663['eventRegistrations_']=[];return _0x18ee55;}function pr(_0x4e73e6,_0x32fb40,_0x4883ac,_0x46f83b){_0x32fb40['type']===j['MERGE']&&_0x32fb40['source']['queryId']!==null&&(f(We(_0x4e73e6['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x4e73e6['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x44b5cb=_0x4e73e6['viewCache_'],_0x3080f5=Ru(_0x4e73e6['processor_'],_0x44b5cb,_0x32fb40,_0x4883ac,_0x46f83b);return bu(_0x4e73e6['processor_'],_0x3080f5['viewCache']),f(_0x3080f5['viewCache']['serverCache']['isFullyInitialized']()||!_0x44b5cb['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x4e73e6['viewCache_']=_0x3080f5['viewCache'],zo(_0x4e73e6,_0x3080f5['changes'],_0x3080f5['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x1accbe,_0x2db0b8){const _0x2be4c4=_0x1accbe['viewCache_']['eventCache'],_0x51533c=[];return _0x2be4c4['getNode']()['isLeafNode']()||_0x2be4c4['getNode']()['forEachChild'](R,(_0x35af34,_0x2a1e8a)=>{_0x51533c['push'](et(_0x35af34,_0x2a1e8a));}),_0x2be4c4['isFullyInitialized']()&&_0x51533c['push'](Lo(_0x2be4c4['getNode']())),zo(_0x1accbe,_0x51533c,_0x2be4c4['getNode'](),_0x2db0b8);}function zo(_0x539f94,_0x5bf111,_0x2d2363,_0x23a95a){const _0x2fbd86=_0x23a95a?[_0x23a95a]:_0x539f94['eventRegistrations_'];return ru(_0x539f94['eventGenerator_'],_0x5bf111,_0x2d2363,_0x2fbd86);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x336cf5){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x336cf5;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x24406f){return _0x24406f['views']['size']===0x0;}function rs(_0x44b5d7,_0x48e093,_0x4b2f52,_0x57ffa4){const _0x113ae8=_0x48e093['source']['queryId'];if(_0x113ae8!==null){const _0x387821=_0x44b5d7['views']['get'](_0x113ae8);return f(_0x387821!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x387821,_0x48e093,_0x4b2f52,_0x57ffa4);}else{let _0x2e6cf3=[];for(const _0x146651 of _0x44b5d7['views']['values']())_0x2e6cf3=_0x2e6cf3['concat'](pr(_0x146651,_0x48e093,_0x4b2f52,_0x57ffa4));return _0x2e6cf3;}}function Ko(_0x553696,_0x4a3b7e,_0x24a45d,_0x33e036,_0x3cb208){const _0x2f20bb=_0x4a3b7e['_queryIdentifier'],_0x266ca4=_0x553696['views']['get'](_0x2f20bb);if(!_0x266ca4){let _0x345837=yn(_0x24a45d,_0x3cb208?_0x33e036:null),_0x1826a8=!0x1;_0x345837?_0x1826a8=!0x0:_0x33e036 instanceof g?(_0x345837=ns(_0x24a45d,_0x33e036),_0x1826a8=!0x1):(_0x345837=g['EMPTY_NODE'],_0x1826a8=!0x1);const _0x4cc4a3=Mn(new Ce(_0x345837,_0x1826a8,!0x1),new Ce(_0x33e036,_0x3cb208,!0x1));return new Du(_0x4a3b7e,_0x4cc4a3);}return _0x266ca4;}function Hu(_0xba14e0,_0x20308a,_0x4017a1,_0x554cc4,_0x56370f,_0x5c0fd7){const _0x177219=Ko(_0xba14e0,_0x20308a,_0x554cc4,_0x56370f,_0x5c0fd7);return _0xba14e0['views']['has'](_0x20308a['_queryIdentifier'])||_0xba14e0['views']['set'](_0x20308a['_queryIdentifier'],_0x177219),Fu(_0x177219,_0x4017a1),Uu(_0x177219,_0x4017a1);}function $u(_0x352928,_0x42eb52,_0x28d67e,_0x4804fb){const _0x634b3a=_0x42eb52['_queryIdentifier'],_0x57ac05=[];let _0x55dcd6=[];const _0x426da2=Te(_0x352928);if(_0x634b3a==='default'){for(const [_0x278998,_0x3e62cf]of _0x352928['views']['entries']())_0x55dcd6=_0x55dcd6['concat'](fr(_0x3e62cf,_0x28d67e,_0x4804fb)),dr(_0x3e62cf)&&(_0x352928['views']['delete'](_0x278998),_0x3e62cf['query']['_queryParams']['loadsAllData']()||_0x57ac05['push'](_0x3e62cf['query']));}else{const _0x4cbff1=_0x352928['views']['get'](_0x634b3a);_0x4cbff1&&(_0x55dcd6=_0x55dcd6['concat'](fr(_0x4cbff1,_0x28d67e,_0x4804fb)),dr(_0x4cbff1)&&(_0x352928['views']['delete'](_0x634b3a),_0x4cbff1['query']['_queryParams']['loadsAllData']()||_0x57ac05['push'](_0x4cbff1['query'])));}return _0x426da2&&!Te(_0x352928)&&_0x57ac05['push'](new(Bu())(_0x42eb52['_repo'],_0x42eb52['_path'])),{'removed':_0x57ac05,'events':_0x55dcd6};}function Yo(_0x16e2ef){const _0x1efc0c=[];for(const _0x58495c of _0x16e2ef['views']['values']())_0x58495c['query']['_queryParams']['loadsAllData']()||_0x1efc0c['push'](_0x58495c);return _0x1efc0c;}function Ee(_0x5838ff,_0x4ccff7){let _0x41f55a=null;for(const _0x16fe9d of _0x5838ff['views']['values']())_0x41f55a=_0x41f55a||xu(_0x16fe9d,_0x4ccff7);return _0x41f55a;}function Qo(_0x3cacda,_0x122a49){if(_0x122a49['_queryParams']['loadsAllData']())return xn(_0x3cacda);{const _0xd52a0a=_0x122a49['_queryIdentifier'];return _0x3cacda['views']['get'](_0xd52a0a);}}function Jo(_0x4023c0,_0x4fc1ac){return Qo(_0x4023c0,_0x4fc1ac)!=null;}function Te(_0x3d788e){return xn(_0x3d788e)!=null;}function xn(_0x171f9c){for(const _0x1be26b of _0x171f9c['views']['values']())if(_0x1be26b['query']['_queryParams']['loadsAllData']())return _0x1be26b;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x16e25a){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x16e25a;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x49d0e3){this['listenProvider_']=_0x49d0e3,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x5941c4,_0x252ba4,_0x983c05,_0x5bd877,_0xc83b99){return lu(_0x5941c4['pendingWriteTree_'],_0x252ba4,_0x983c05,_0x5bd877,_0xc83b99),_0xc83b99?ut(_0x5941c4,new Ue(Zi(),_0x252ba4,_0x983c05)):[];}function ju(_0x3194a1,_0x15cd81,_0x14cde0,_0x369f66){hu(_0x3194a1['pendingWriteTree_'],_0x15cd81,_0x14cde0,_0x369f66);const _0x183d66=S['fromObject'](_0x14cde0);return ut(_0x3194a1,new tt(Zi(),_0x15cd81,_0x183d66));}function pe(_0x36c4bb,_0x326f3,_0x266f0a=!0x1){const _0x14bbf9=uu(_0x36c4bb['pendingWriteTree_'],_0x326f3);if(du(_0x36c4bb['pendingWriteTree_'],_0x326f3)){let _0x4d15d0=new S(null);return _0x14bbf9['snap']!=null?_0x4d15d0=_0x4d15d0['set'](w(),!0x0):x(_0x14bbf9['children'],_0x4cf9d9=>{_0x4d15d0=_0x4d15d0['set'](new C(_0x4cf9d9),!0x0);}),ut(_0x36c4bb,new gn(_0x14bbf9['path'],_0x4d15d0,_0x266f0a));}else return[];}function Gt(_0x51202d,_0x216413,_0x5a3f77){return ut(_0x51202d,new Ue(es(),_0x216413,_0x5a3f77));}function Ku(_0x32f6e0,_0x377d5b,_0x235328){const _0x1c7ffa=S['fromObject'](_0x235328);return ut(_0x32f6e0,new tt(es(),_0x377d5b,_0x1c7ffa));}function Yu(_0x2dbad9,_0x3cec2b){return ut(_0x2dbad9,new Lt(es(),_0x3cec2b));}function Qu(_0x2c5747,_0x404918,_0x45c727){const _0x3ac096=as(_0x2c5747,_0x45c727);if(_0x3ac096){const _0x154ec6=cs(_0x3ac096),_0x45b3b1=_0x154ec6['path'],_0x38fad2=_0x154ec6['queryId'],_0x34287e=F(_0x45b3b1,_0x404918),_0x3d592b=new Lt(ts(_0x38fad2),_0x34287e);return ls(_0x2c5747,_0x45b3b1,_0x3d592b);}else return[];}function Cn(_0xae5c8c,_0x3f186f,_0x528a3a,_0x2c126f,_0x2e290c=!0x1){const _0x5da61e=_0x3f186f['_path'],_0x47a0cc=_0xae5c8c['syncPointTree_']['get'](_0x5da61e);let _0xe8e84c=[];if(_0x47a0cc&&(_0x3f186f['_queryIdentifier']==='default'||Jo(_0x47a0cc,_0x3f186f))){const _0x4ace89=$u(_0x47a0cc,_0x3f186f,_0x528a3a,_0x2c126f);Vu(_0x47a0cc)&&(_0xae5c8c['syncPointTree_']=_0xae5c8c['syncPointTree_']['remove'](_0x5da61e));const _0x491fc2=_0x4ace89['removed'];if(_0xe8e84c=_0x4ace89['events'],!_0x2e290c){const _0xa0451f=_0x491fc2['findIndex'](_0x59729a=>_0x59729a['_queryParams']['loadsAllData']())!==-0x1,_0x593f01=_0xae5c8c['syncPointTree_']['findOnPath'](_0x5da61e,(_0x35c36b,_0x13bdb2)=>Te(_0x13bdb2));if(_0xa0451f&&!_0x593f01){const _0x126d74=_0xae5c8c['syncPointTree_']['subtree'](_0x5da61e);if(!_0x126d74['isEmpty']()){const _0x353b6a=Zu(_0x126d74);for(let _0x45cdb8=0x0;_0x45cdb8<_0x353b6a['length'];++_0x45cdb8){const _0x298a46=_0x353b6a[_0x45cdb8],_0x48a94a=_0x298a46['query'],_0x5d7dd9=ta(_0xae5c8c,_0x298a46);_0xae5c8c['listenProvider_']['startListening'](bt(_0x48a94a),xt(_0xae5c8c,_0x48a94a),_0x5d7dd9['hashFn'],_0x5d7dd9['onComplete']);}}}!_0x593f01&&_0x491fc2['length']>0x0&&!_0x2c126f&&(_0xa0451f?_0xae5c8c['listenProvider_']['stopListening'](bt(_0x3f186f),null):_0x491fc2['forEach'](_0x23eedc=>{const _0x44483c=_0xae5c8c['queryToTagMap']['get'](Un(_0x23eedc));_0xae5c8c['listenProvider_']['stopListening'](bt(_0x23eedc),_0x44483c);}));}ed(_0xae5c8c,_0x491fc2);}return _0xe8e84c;}function Xo(_0x59d883,_0x2b09c5,_0x3e0347,_0x1a3a91){const _0x5228bd=as(_0x59d883,_0x1a3a91);if(_0x5228bd!=null){const _0x40006c=cs(_0x5228bd),_0x51eb4b=_0x40006c['path'],_0x4beb16=_0x40006c['queryId'],_0x1db26e=F(_0x51eb4b,_0x2b09c5),_0x451bf4=new Ue(ts(_0x4beb16),_0x1db26e,_0x3e0347);return ls(_0x59d883,_0x51eb4b,_0x451bf4);}else return[];}function Ju(_0x21c458,_0x1f2b5f,_0x269b03,_0x782f9e){const _0x23e2c2=as(_0x21c458,_0x782f9e);if(_0x23e2c2){const _0x23fd84=cs(_0x23e2c2),_0x22a05b=_0x23fd84['path'],_0x22b939=_0x23fd84['queryId'],_0x24d150=F(_0x22a05b,_0x1f2b5f),_0x540cb5=S['fromObject'](_0x269b03),_0x416129=new tt(ts(_0x22b939),_0x24d150,_0x540cb5);return ls(_0x21c458,_0x22a05b,_0x416129);}else return[];}function Ri(_0x2d0fd0,_0x2138e1,_0x3d4f99,_0x4e49b6=!0x1){const _0x3c742c=_0x2138e1['_path'];let _0x557c27=null,_0x4eb465=!0x1;_0x2d0fd0['syncPointTree_']['foreachOnPath'](_0x3c742c,(_0x2e5168,_0x330492)=>{const _0x3e64db=F(_0x2e5168,_0x3c742c);_0x557c27=_0x557c27||Ee(_0x330492,_0x3e64db),_0x4eb465=_0x4eb465||Te(_0x330492);});let _0x520ecc=_0x2d0fd0['syncPointTree_']['get'](_0x3c742c);_0x520ecc?(_0x4eb465=_0x4eb465||Te(_0x520ecc),_0x557c27=_0x557c27||Ee(_0x520ecc,w())):(_0x520ecc=new jo(),_0x2d0fd0['syncPointTree_']=_0x2d0fd0['syncPointTree_']['set'](_0x3c742c,_0x520ecc));let _0x4021e4;_0x557c27!=null?_0x4021e4=!0x0:(_0x4021e4=!0x1,_0x557c27=g['EMPTY_NODE'],_0x2d0fd0['syncPointTree_']['subtree'](_0x3c742c)['foreachChild']((_0x54c493,_0x4f4bac)=>{const _0x2855e3=Ee(_0x4f4bac,w());_0x2855e3&&(_0x557c27=_0x557c27['updateImmediateChild'](_0x54c493,_0x2855e3));}));const _0x3f294d=Jo(_0x520ecc,_0x2138e1);if(!_0x3f294d&&!_0x2138e1['_queryParams']['loadsAllData']()){const _0xb1c25d=Un(_0x2138e1);f(!_0x2d0fd0['queryToTagMap']['has'](_0xb1c25d),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x2e096e=td();_0x2d0fd0['queryToTagMap']['set'](_0xb1c25d,_0x2e096e),_0x2d0fd0['tagToQueryMap']['set'](_0x2e096e,_0xb1c25d);}const _0x493810=Ln(_0x2d0fd0['pendingWriteTree_'],_0x3c742c);let _0x253389=Hu(_0x520ecc,_0x2138e1,_0x3d4f99,_0x493810,_0x557c27,_0x4021e4);if(!_0x3f294d&&!_0x4eb465&&!_0x4e49b6){const _0x55f08c=Qo(_0x520ecc,_0x2138e1);_0x253389=_0x253389['concat'](nd(_0x2d0fd0,_0x2138e1,_0x55f08c));}return _0x253389;}function Fn(_0x34a379,_0x4c6ae7,_0x4a3060){const _0x200293=_0x34a379['pendingWriteTree_'],_0x2eba4e=_0x34a379['syncPointTree_']['findOnPath'](_0x4c6ae7,(_0x3cc8cd,_0x10e1fc)=>{const _0x11f1d2=F(_0x3cc8cd,_0x4c6ae7),_0x1ea599=Ee(_0x10e1fc,_0x11f1d2);if(_0x1ea599)return _0x1ea599;});return Vo(_0x200293,_0x4c6ae7,_0x2eba4e,_0x4a3060,!0x0);}function Xu(_0x3abe07,_0x115442){const _0x5335a2=_0x115442['_path'];let _0x267792=null;_0x3abe07['syncPointTree_']['foreachOnPath'](_0x5335a2,(_0x4745a7,_0x5c1f0b)=>{const _0x347d84=F(_0x4745a7,_0x5335a2);_0x267792=_0x267792||Ee(_0x5c1f0b,_0x347d84);});let _0x1f86ec=_0x3abe07['syncPointTree_']['get'](_0x5335a2);_0x1f86ec?_0x267792=_0x267792||Ee(_0x1f86ec,w()):(_0x1f86ec=new jo(),_0x3abe07['syncPointTree_']=_0x3abe07['syncPointTree_']['set'](_0x5335a2,_0x1f86ec));const _0x26c812=_0x267792!=null,_0x48d409=_0x26c812?new Ce(_0x267792,!0x0,!0x1):null,_0x14b84f=Ln(_0x3abe07['pendingWriteTree_'],_0x115442['_path']),_0x533179=Ko(_0x1f86ec,_0x115442,_0x14b84f,_0x26c812?_0x48d409['getNode']():g['EMPTY_NODE'],_0x26c812);return Lu(_0x533179);}function ut(_0x4c46bc,_0x378def){return Zo(_0x378def,_0x4c46bc['syncPointTree_'],null,Ln(_0x4c46bc['pendingWriteTree_'],w()));}function Zo(_0x514be2,_0x57ac8f,_0x8d3ea5,_0xa70089){if(v(_0x514be2['path']))return ea(_0x514be2,_0x57ac8f,_0x8d3ea5,_0xa70089);{const _0x3ab8fb=_0x57ac8f['get'](w());_0x8d3ea5==null&&_0x3ab8fb!=null&&(_0x8d3ea5=Ee(_0x3ab8fb,w()));let _0x36f880=[];const _0x4d1f49=y(_0x514be2['path']),_0x40d2d4=_0x514be2['operationForChild'](_0x4d1f49),_0xad0424=_0x57ac8f['children']['get'](_0x4d1f49);if(_0xad0424&&_0x40d2d4){const _0x1b599d=_0x8d3ea5?_0x8d3ea5['getImmediateChild'](_0x4d1f49):null,_0x4813af=Ho(_0xa70089,_0x4d1f49);_0x36f880=_0x36f880['concat'](Zo(_0x40d2d4,_0xad0424,_0x1b599d,_0x4813af));}return _0x3ab8fb&&(_0x36f880=_0x36f880['concat'](rs(_0x3ab8fb,_0x514be2,_0xa70089,_0x8d3ea5))),_0x36f880;}}function ea(_0xfa3ba4,_0x252ec9,_0x16bf6f,_0x8f157c){const _0x396c36=_0x252ec9['get'](w());_0x16bf6f==null&&_0x396c36!=null&&(_0x16bf6f=Ee(_0x396c36,w()));let _0x5d36b2=[];return _0x252ec9['children']['inorderTraversal']((_0x2c765e,_0x75e7f0)=>{const _0x578c07=_0x16bf6f?_0x16bf6f['getImmediateChild'](_0x2c765e):null,_0x3e5312=Ho(_0x8f157c,_0x2c765e),_0x1e3381=_0xfa3ba4['operationForChild'](_0x2c765e);_0x1e3381&&(_0x5d36b2=_0x5d36b2['concat'](ea(_0x1e3381,_0x75e7f0,_0x578c07,_0x3e5312)));}),_0x396c36&&(_0x5d36b2=_0x5d36b2['concat'](rs(_0x396c36,_0xfa3ba4,_0x8f157c,_0x16bf6f))),_0x5d36b2;}function ta(_0x2e8142,_0x34ab15){const _0x482d03=_0x34ab15['query'],_0x1ef3d6=xt(_0x2e8142,_0x482d03);return{'hashFn':()=>(Mu(_0x34ab15)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x464554=>{if(_0x464554==='ok')return _0x1ef3d6?Qu(_0x2e8142,_0x482d03['_path'],_0x1ef3d6):Yu(_0x2e8142,_0x482d03['_path']);{const _0x5733b2=Kl(_0x464554,_0x482d03);return Cn(_0x2e8142,_0x482d03,null,_0x5733b2);}}};}function xt(_0x454831,_0x505015){const _0x3fb132=Un(_0x505015);return _0x454831['queryToTagMap']['get'](_0x3fb132);}function Un(_0x55cf5d){return _0x55cf5d['_path']['toString']()+'$'+_0x55cf5d['_queryIdentifier'];}function as(_0x16e0f2,_0x3038bf){return _0x16e0f2['tagToQueryMap']['get'](_0x3038bf);}function cs(_0x2d2965){const _0x5efff7=_0x2d2965['indexOf']('$');return f(_0x5efff7!==-0x1&&_0x5efff7<_0x2d2965['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x2d2965['substr'](_0x5efff7+0x1),'path':new C(_0x2d2965['substr'](0x0,_0x5efff7))};}function ls(_0x232a5d,_0x3a1f94,_0x18d5e5){const _0x51b185=_0x232a5d['syncPointTree_']['get'](_0x3a1f94);f(_0x51b185,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x312e46=Ln(_0x232a5d['pendingWriteTree_'],_0x3a1f94);return rs(_0x51b185,_0x18d5e5,_0x312e46,null);}function Zu(_0x3b88bd){return _0x3b88bd['fold']((_0x2d3cda,_0xf10af2,_0xcb2b67)=>{if(_0xf10af2&&Te(_0xf10af2))return[xn(_0xf10af2)];{let _0x4bd57f=[];return _0xf10af2&&(_0x4bd57f=Yo(_0xf10af2)),x(_0xcb2b67,(_0x5bc04a,_0x38c1b2)=>{_0x4bd57f=_0x4bd57f['concat'](_0x38c1b2);}),_0x4bd57f;}});}function bt(_0x288066){return _0x288066['_queryParams']['loadsAllData']()&&!_0x288066['_queryParams']['isDefault']()?new(qu())(_0x288066['_repo'],_0x288066['_path']):_0x288066;}function ed(_0x5bf0af,_0x3f671b){for(let _0x73341a=0x0;_0x73341a<_0x3f671b['length'];++_0x73341a){const _0x42048d=_0x3f671b[_0x73341a];if(!_0x42048d['_queryParams']['loadsAllData']()){const _0x3d590e=Un(_0x42048d),_0x503fd0=_0x5bf0af['queryToTagMap']['get'](_0x3d590e);_0x5bf0af['queryToTagMap']['delete'](_0x3d590e),_0x5bf0af['tagToQueryMap']['delete'](_0x503fd0);}}}function td(){return zu++;}function nd(_0x322380,_0x827ebb,_0x325aa8){const _0x4c3d52=_0x827ebb['_path'],_0x54ce8e=xt(_0x322380,_0x827ebb),_0x1b0383=ta(_0x322380,_0x325aa8),_0x2ed2ee=_0x322380['listenProvider_']['startListening'](bt(_0x827ebb),_0x54ce8e,_0x1b0383['hashFn'],_0x1b0383['onComplete']),_0x31e054=_0x322380['syncPointTree_']['subtree'](_0x4c3d52);if(_0x54ce8e)f(!Te(_0x31e054['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0xe4051b=_0x31e054['fold']((_0x2e39e3,_0x43a306,_0x3f3053)=>{if(!v(_0x2e39e3)&&_0x43a306&&Te(_0x43a306))return[xn(_0x43a306)['query']];{let _0x45239f=[];return _0x43a306&&(_0x45239f=_0x45239f['concat'](Yo(_0x43a306)['map'](_0x5cb888=>_0x5cb888['query']))),x(_0x3f3053,(_0x2c48ac,_0x37e6c0)=>{_0x45239f=_0x45239f['concat'](_0x37e6c0);}),_0x45239f;}});for(let _0x206234=0x0;_0x206234<_0xe4051b['length'];++_0x206234){const _0x2ab2c2=_0xe4051b[_0x206234];_0x322380['listenProvider_']['stopListening'](bt(_0x2ab2c2),xt(_0x322380,_0x2ab2c2));}}return _0x2ed2ee;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x1fb8fa){this['node_']=_0x1fb8fa;}['getImmediateChild'](_0x20535d){const _0x24026b=this['node_']['getImmediateChild'](_0x20535d);return new hs(_0x24026b);}['node'](){return this['node_'];}}class us{constructor(_0xdc80aa,_0x5acbc3){this['syncTree_']=_0xdc80aa,this['path_']=_0x5acbc3;}['getImmediateChild'](_0x4d5d33){const _0x1b6651=k(this['path_'],_0x4d5d33);return new us(this['syncTree_'],_0x1b6651);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x5e4c2a){return _0x5e4c2a=_0x5e4c2a||{},_0x5e4c2a['timestamp']=_0x5e4c2a['timestamp']||new Date()['getTime'](),_0x5e4c2a;},gr=function(_0x7f2d31,_0xc08422,_0x302286){if(!_0x7f2d31||typeof _0x7f2d31!='object')return _0x7f2d31;if(f('.sv'in _0x7f2d31,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x7f2d31['.sv']=='string')return sd(_0x7f2d31['.sv'],_0xc08422,_0x302286);if(typeof _0x7f2d31['.sv']=='object')return rd(_0x7f2d31['.sv'],_0xc08422);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x7f2d31,null,0x2));},sd=function(_0x31588d,_0x19f2dc,_0x3565f4){switch(_0x31588d){case'timestamp':return _0x3565f4['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x31588d);}},rd=function(_0x4b0352,_0x3f3633,_0x8d655a){_0x4b0352['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4b0352,null,0x2));const _0x2f8235=_0x4b0352['increment'];typeof _0x2f8235!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x2f8235);const _0x44d161=_0x3f3633['node']();if(f(_0x44d161!==null&&typeof _0x44d161<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x44d161['isLeafNode']())return _0x2f8235;const _0x9c1620=_0x44d161['getValue']();return typeof _0x9c1620!='number'?_0x2f8235:_0x9c1620+_0x2f8235;},na=function(_0x513bfd,_0x340208,_0xdf64be,_0x28e371){return fs(_0x340208,new us(_0xdf64be,_0x513bfd),_0x28e371);},ds=function(_0x21fe73,_0x11c747,_0x3d37cb){return fs(_0x21fe73,new hs(_0x11c747),_0x3d37cb);};function fs(_0x5a120e,_0x2fd4bd,_0x56bfa8){const _0x333b3a=_0x5a120e['getPriority']()['val'](),_0x5b996e=gr(_0x333b3a,_0x2fd4bd['getImmediateChild']('.priority'),_0x56bfa8);let _0xacf225;if(_0x5a120e['isLeafNode']()){const _0xb587fd=_0x5a120e,_0x2c236d=gr(_0xb587fd['getValue'](),_0x2fd4bd,_0x56bfa8);return _0x2c236d!==_0xb587fd['getValue']()||_0x5b996e!==_0xb587fd['getPriority']()['val']()?new D(_0x2c236d,P(_0x5b996e)):_0x5a120e;}else{const _0x29968b=_0x5a120e;return _0xacf225=_0x29968b,_0x5b996e!==_0x29968b['getPriority']()['val']()&&(_0xacf225=_0xacf225['updatePriority'](new D(_0x5b996e))),_0x29968b['forEachChild'](R,(_0x1ff949,_0x4c5fde)=>{const _0x287cd5=fs(_0x4c5fde,_0x2fd4bd['getImmediateChild'](_0x1ff949),_0x56bfa8);_0x287cd5!==_0x4c5fde&&(_0xacf225=_0xacf225['updateImmediateChild'](_0x1ff949,_0x287cd5));}),_0xacf225;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x7d852f='',_0x422a73=null,_0xd8116f={'children':{},'childCount':0x0}){this['name']=_0x7d852f,this['parent']=_0x422a73,this['node']=_0xd8116f;}}function Wn(_0x25ffda,_0x5207fb){let _0x524674=_0x5207fb instanceof C?_0x5207fb:new C(_0x5207fb),_0x5c1557=_0x25ffda,_0x425261=y(_0x524674);for(;_0x425261!==null;){const _0x265de4=De(_0x5c1557['node']['children'],_0x425261)||{'children':{},'childCount':0x0};_0x5c1557=new ps(_0x425261,_0x5c1557,_0x265de4),_0x524674=b(_0x524674),_0x425261=y(_0x524674);}return _0x5c1557;}function Ge(_0x417c69){return _0x417c69['node']['value'];}function _s(_0x5b6258,_0x5992b1){_0x5b6258['node']['value']=_0x5992b1,Ai(_0x5b6258);}function ia(_0x154b88){return _0x154b88['node']['childCount']>0x0;}function od(_0xba26ec){return Ge(_0xba26ec)===void 0x0&&!ia(_0xba26ec);}function Bn(_0x1d35f5,_0x3ccd7){x(_0x1d35f5['node']['children'],(_0x26cbe4,_0x2134cc)=>{_0x3ccd7(new ps(_0x26cbe4,_0x1d35f5,_0x2134cc));});}function sa(_0x87affc,_0x46d915,_0x1d5a25,_0x58c271){_0x1d5a25&&_0x46d915(_0x87affc),Bn(_0x87affc,_0x5c15e7=>{sa(_0x5c15e7,_0x46d915,!0x0);});}function ad(_0x21d069,_0x2f9620,_0x54a0d2){let _0x13d896=_0x21d069['parent'];for(;_0x13d896!==null;){if(_0x2f9620(_0x13d896))return!0x0;_0x13d896=_0x13d896['parent'];}return!0x1;}function qt(_0x14979e){return new C(_0x14979e['parent']===null?_0x14979e['name']:qt(_0x14979e['parent'])+'/'+_0x14979e['name']);}function Ai(_0x59602d){_0x59602d['parent']!==null&&cd(_0x59602d['parent'],_0x59602d['name'],_0x59602d);}function cd(_0x358bd0,_0x42a30a,_0x22ba75){const _0x2fd428=od(_0x22ba75),_0x1ea009=J(_0x358bd0['node']['children'],_0x42a30a);_0x2fd428&&_0x1ea009?(delete _0x358bd0['node']['children'][_0x42a30a],_0x358bd0['node']['childCount']--,Ai(_0x358bd0)):!_0x2fd428&&!_0x1ea009&&(_0x358bd0['node']['children'][_0x42a30a]=_0x22ba75['node'],_0x358bd0['node']['childCount']++,Ai(_0x358bd0));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x20f16c){return typeof _0x20f16c=='string'&&_0x20f16c['length']!==0x0&&!ld['test'](_0x20f16c);},ra=function(_0x36677d){return typeof _0x36677d=='string'&&_0x36677d['length']!==0x0&&!hd['test'](_0x36677d);},ud=function(_0x4463ea){return _0x4463ea&&(_0x4463ea=_0x4463ea['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x4463ea);},Tn=function(_0x473141){return _0x473141===null||typeof _0x473141=='string'||typeof _0x473141=='number'&&!Vi(_0x473141)||_0x473141&&typeof _0x473141=='object'&&J(_0x473141,'.sv');},zt=function(_0x13746b,_0xa6bab2,_0x561ef1,_0x226a09){_0x226a09&&_0xa6bab2===void 0x0||jt(Pn(_0x13746b,'value'),_0xa6bab2,_0x561ef1);},jt=function(_0x89d232,_0x404a1f,_0x1c6624){const _0x421277=_0x1c6624 instanceof C?new Ah(_0x1c6624,_0x89d232):_0x1c6624;if(_0x404a1f===void 0x0)throw new Error(_0x89d232+'contains\x20undefined\x20'+Pe(_0x421277));if(typeof _0x404a1f=='function')throw new Error(_0x89d232+'contains\x20a\x20function\x20'+Pe(_0x421277)+'\x20with\x20contents\x20=\x20'+_0x404a1f['toString']());if(Vi(_0x404a1f))throw new Error(_0x89d232+'contains\x20'+_0x404a1f['toString']()+'\x20'+Pe(_0x421277));if(typeof _0x404a1f=='string'&&_0x404a1f['length']>ai/0x3&&On(_0x404a1f)>ai)throw new Error(_0x89d232+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x421277)+'\x20(\x27'+_0x404a1f['substring'](0x0,0x32)+'...\x27)');if(_0x404a1f&&typeof _0x404a1f=='object'){let _0x55aba2=!0x1,_0x52b834=!0x1;if(x(_0x404a1f,(_0x48752f,_0x238396)=>{if(_0x48752f==='.value')_0x55aba2=!0x0;else{if(_0x48752f!=='.priority'&&_0x48752f!=='.sv'&&(_0x52b834=!0x0,!gs(_0x48752f)))throw new Error(_0x89d232+'\x20contains\x20an\x20invalid\x20key\x20('+_0x48752f+')\x20'+Pe(_0x421277)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x421277,_0x48752f),jt(_0x89d232,_0x238396,_0x421277),Nh(_0x421277);}),_0x55aba2&&_0x52b834)throw new Error(_0x89d232+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x421277)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x401414,_0x15abb2){let _0x41cf39,_0x1b5c70;for(_0x41cf39=0x0;_0x41cf39<_0x15abb2['length'];_0x41cf39++){_0x1b5c70=_0x15abb2[_0x41cf39];const _0xe577b1=Pt(_0x1b5c70);for(let _0x53d01b=0x0;_0x53d01b<_0xe577b1['length'];_0x53d01b++)if(!(_0xe577b1[_0x53d01b]==='.priority'&&_0x53d01b===_0xe577b1['length']-0x1)){if(!gs(_0xe577b1[_0x53d01b]))throw new Error(_0x401414+'contains\x20an\x20invalid\x20key\x20('+_0xe577b1[_0x53d01b]+')\x20in\x20path\x20'+_0x1b5c70['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x15abb2['sort'](Rh);let _0x33f10c=null;for(_0x41cf39=0x0;_0x41cf39<_0x15abb2['length'];_0x41cf39++){if(_0x1b5c70=_0x15abb2[_0x41cf39],_0x33f10c!==null&&G(_0x33f10c,_0x1b5c70))throw new Error(_0x401414+'contains\x20a\x20path\x20'+_0x33f10c['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x1b5c70['toString']());_0x33f10c=_0x1b5c70;}},fd=function(_0x304c22,_0x3d35b8,_0x3b22ff,_0xa3b5ee){const _0x3e6067=Pn(_0x304c22,'values');if(!(_0x3d35b8&&typeof _0x3d35b8=='object')||Array['isArray'](_0x3d35b8))throw new Error(_0x3e6067+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x3ab050=[];x(_0x3d35b8,(_0x10b1f8,_0x5eff30)=>{const _0x345506=new C(_0x10b1f8);if(jt(_0x3e6067,_0x5eff30,k(_0x3b22ff,_0x345506)),zi(_0x345506)==='.priority'&&!Tn(_0x5eff30))throw new Error(_0x3e6067+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x345506['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x3ab050['push'](_0x345506);}),dd(_0x3e6067,_0x3ab050);},ms=function(_0x38244f,_0x4e4b2f,_0x2dd12b,_0x291a55){if(!ra(_0x2dd12b))throw new Error(Pn(_0x38244f,_0x4e4b2f)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x2dd12b+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x367887,_0xe67f8a,_0x2b4b3c,_0x293e08){_0x2b4b3c&&(_0x2b4b3c=_0x2b4b3c['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x367887,_0xe67f8a,_0x2b4b3c);},ys=function(_0x5679e7,_0x3b4696){if(y(_0x3b4696)==='.info')throw new Error(_0x5679e7+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x39158a,_0x246d9a){const _0x1a591e=_0x246d9a['path']['toString']();if(typeof _0x246d9a['repoInfo']['host']!='string'||_0x246d9a['repoInfo']['host']['length']===0x0||!gs(_0x246d9a['repoInfo']['namespace'])&&_0x246d9a['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x1a591e['length']!==0x0&&!ud(_0x1a591e))throw new Error(Pn(_0x39158a,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x69b755,_0x4341b6){let _0x120632=null;for(let _0x416827=0x0;_0x416827<_0x4341b6['length'];_0x416827++){const _0x570005=_0x4341b6[_0x416827],_0x858b6=_0x570005['getPath']();_0x120632!==null&&!ji(_0x858b6,_0x120632['path'])&&(_0x69b755['eventLists_']['push'](_0x120632),_0x120632=null),_0x120632===null&&(_0x120632={'events':[],'path':_0x858b6}),_0x120632['events']['push'](_0x570005);}_0x120632&&_0x69b755['eventLists_']['push'](_0x120632);}function oa(_0x1e5c44,_0x33007d,_0xc501bf){Vn(_0x1e5c44,_0xc501bf),aa(_0x1e5c44,_0x1dfc52=>ji(_0x1dfc52,_0x33007d));}function H(_0x9cada7,_0x6dba92,_0x5a2a15){Vn(_0x9cada7,_0x5a2a15),aa(_0x9cada7,_0x3b8be7=>G(_0x3b8be7,_0x6dba92)||G(_0x6dba92,_0x3b8be7));}function aa(_0x3100ad,_0x1914e0){_0x3100ad['recursionDepth_']++;let _0x736864=!0x0;for(let _0xc38e43=0x0;_0xc38e43<_0x3100ad['eventLists_']['length'];_0xc38e43++){const _0x2739ca=_0x3100ad['eventLists_'][_0xc38e43];if(_0x2739ca){const _0x319a50=_0x2739ca['path'];_0x1914e0(_0x319a50)?(md(_0x3100ad['eventLists_'][_0xc38e43]),_0x3100ad['eventLists_'][_0xc38e43]=null):_0x736864=!0x1;}}_0x736864&&(_0x3100ad['eventLists_']=[]),_0x3100ad['recursionDepth_']--;}function md(_0x31632b){for(let _0x1b1a65=0x0;_0x1b1a65<_0x31632b['events']['length'];_0x1b1a65++){const _0x235a50=_0x31632b['events'][_0x1b1a65];if(_0x235a50!==null){_0x31632b['events'][_0x1b1a65]=null;const _0x593a71=_0x235a50['getEventRunner']();wt&&L('event:\x20'+_0x235a50['toString']()),ht(_0x593a71);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x3fd59a,_0x5e970d,_0x27d76d,_0x1b4746){this['repoInfo_']=_0x3fd59a,this['forceRestClient_']=_0x5e970d,this['authTokenProvider_']=_0x27d76d,this['appCheckProvider_']=_0x1b4746,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x36fa98,_0x22a247,_0x5f2c4c){if(_0x36fa98['stats_']=Gi(_0x36fa98['repoInfo_']),_0x36fa98['forceRestClient_']||Xl())_0x36fa98['server_']=new pn(_0x36fa98['repoInfo_'],(_0x1be975,_0x2daa20,_0x651f6,_0x53b43e)=>{mr(_0x36fa98,_0x1be975,_0x2daa20,_0x651f6,_0x53b43e);},_0x36fa98['authTokenProvider_'],_0x36fa98['appCheckProvider_']),setTimeout(()=>yr(_0x36fa98,!0x0),0x0);else{if(typeof _0x5f2c4c<'u'&&_0x5f2c4c!==null){if(typeof _0x5f2c4c!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x5f2c4c);}catch(_0x240244){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x240244);}}_0x36fa98['persistentConnection_']=new se(_0x36fa98['repoInfo_'],_0x22a247,(_0x2bdcde,_0x9c6630,_0x27edf9,_0x3b3ffd)=>{mr(_0x36fa98,_0x2bdcde,_0x9c6630,_0x27edf9,_0x3b3ffd);},_0x54fcce=>{yr(_0x36fa98,_0x54fcce);},_0x1e2313=>{Id(_0x36fa98,_0x1e2313);},_0x36fa98['authTokenProvider_'],_0x36fa98['appCheckProvider_'],_0x5f2c4c),_0x36fa98['server_']=_0x36fa98['persistentConnection_'];}_0x36fa98['authTokenProvider_']['addTokenChangeListener'](_0x186e32=>{_0x36fa98['server_']['refreshAuthToken'](_0x186e32);}),_0x36fa98['appCheckProvider_']['addTokenChangeListener'](_0x5d00ce=>{_0x36fa98['server_']['refreshAppCheckToken'](_0x5d00ce['token']);}),_0x36fa98['statsReporter_']=ih(_0x36fa98['repoInfo_'],()=>new iu(_0x36fa98['stats_'],_0x36fa98['server_'])),_0x36fa98['infoData_']=new Xh(),_0x36fa98['infoSyncTree_']=new _r({'startListening':(_0x16cb0f,_0x2a5aff,_0x2f1cc9,_0x4ac69c)=>{let _0x108700=[];const _0x1e76a9=_0x36fa98['infoData_']['getNode'](_0x16cb0f['_path']);return _0x1e76a9['isEmpty']()||(_0x108700=Gt(_0x36fa98['infoSyncTree_'],_0x16cb0f['_path'],_0x1e76a9),setTimeout(()=>{_0x4ac69c('ok');},0x0)),_0x108700;},'stopListening':()=>{}}),vs(_0x36fa98,'connected',!0x1),_0x36fa98['serverSyncTree_']=new _r({'startListening':(_0x1c5afe,_0x2ac6c0,_0x351c2c,_0x2c7840)=>(_0x36fa98['server_']['listen'](_0x1c5afe,_0x351c2c,_0x2ac6c0,(_0x5e7180,_0x4a7c68)=>{const _0x2a0f1d=_0x2c7840(_0x5e7180,_0x4a7c68);H(_0x36fa98['eventQueue_'],_0x1c5afe['_path'],_0x2a0f1d);}),[]),'stopListening':(_0x198b30,_0x4a4d78)=>{_0x36fa98['server_']['unlisten'](_0x198b30,_0x4a4d78);}});}function la(_0x7a3d34){const _0x220df0=_0x7a3d34['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x220df0;}function Kt(_0x506260){return id({'timestamp':la(_0x506260)});}function mr(_0x3ce62b,_0xdfd99f,_0x2b8e46,_0x499ae8,_0x59c2f0){_0x3ce62b['dataUpdateCount']++;const _0x150520=new C(_0xdfd99f);_0x2b8e46=_0x3ce62b['interceptServerDataCallback_']?_0x3ce62b['interceptServerDataCallback_'](_0xdfd99f,_0x2b8e46):_0x2b8e46;let _0x55ef6b=[];if(_0x59c2f0){if(_0x499ae8){const _0x31cf20=hn(_0x2b8e46,_0x21404f=>P(_0x21404f));_0x55ef6b=Ju(_0x3ce62b['serverSyncTree_'],_0x150520,_0x31cf20,_0x59c2f0);}else{const _0x30ac77=P(_0x2b8e46);_0x55ef6b=Xo(_0x3ce62b['serverSyncTree_'],_0x150520,_0x30ac77,_0x59c2f0);}}else{if(_0x499ae8){const _0x1a8a70=hn(_0x2b8e46,_0x2639dd=>P(_0x2639dd));_0x55ef6b=Ku(_0x3ce62b['serverSyncTree_'],_0x150520,_0x1a8a70);}else{const _0x3c8211=P(_0x2b8e46);_0x55ef6b=Gt(_0x3ce62b['serverSyncTree_'],_0x150520,_0x3c8211);}}let _0x5e0cd1=_0x150520;_0x55ef6b['length']>0x0&&(_0x5e0cd1=it(_0x3ce62b,_0x150520)),H(_0x3ce62b['eventQueue_'],_0x5e0cd1,_0x55ef6b);}function yr(_0x2084ad,_0x211582){vs(_0x2084ad,'connected',_0x211582),_0x211582===!0x1&&Sd(_0x2084ad);}function Id(_0x113e99,_0x5b3f2e){x(_0x5b3f2e,(_0x1a97e8,_0x1b8c78)=>{vs(_0x113e99,_0x1a97e8,_0x1b8c78);});}function vs(_0x1dd2c7,_0x413319,_0x334cea){const _0x47142c=new C('/.info/'+_0x413319),_0x257e58=P(_0x334cea);_0x1dd2c7['infoData_']['updateSnapshot'](_0x47142c,_0x257e58);const _0x51adb1=Gt(_0x1dd2c7['infoSyncTree_'],_0x47142c,_0x257e58);H(_0x1dd2c7['eventQueue_'],_0x47142c,_0x51adb1);}function Hn(_0x21a410){return _0x21a410['nextWriteId_']++;}function wd(_0x49172e,_0x51353a,_0x6b5601){const _0x4e203d=Xu(_0x49172e['serverSyncTree_'],_0x51353a);return _0x4e203d!=null?Promise['resolve'](_0x4e203d):_0x49172e['server_']['get'](_0x51353a)['then'](_0x43a46d=>{const _0x300293=P(_0x43a46d)['withIndex'](_0x51353a['_queryParams']['getIndex']());Ri(_0x49172e['serverSyncTree_'],_0x51353a,_0x6b5601,!0x0);let _0x16da2f;if(_0x51353a['_queryParams']['loadsAllData']())_0x16da2f=Gt(_0x49172e['serverSyncTree_'],_0x51353a['_path'],_0x300293);else{const _0x21d947=xt(_0x49172e['serverSyncTree_'],_0x51353a);_0x16da2f=Xo(_0x49172e['serverSyncTree_'],_0x51353a['_path'],_0x300293,_0x21d947);}return H(_0x49172e['eventQueue_'],_0x51353a['_path'],_0x16da2f),Cn(_0x49172e['serverSyncTree_'],_0x51353a,_0x6b5601,null,!0x0),_0x300293;},_0x593fc9=>(dt(_0x49172e,'get\x20for\x20query\x20'+O(_0x51353a)+'\x20failed:\x20'+_0x593fc9),Promise['reject'](new Error(_0x593fc9))));}function Cd(_0x1ba580,_0x5c5b4a,_0x2cc697,_0x2aa43c,_0x52be10){dt(_0x1ba580,'set',{'path':_0x5c5b4a['toString'](),'value':_0x2cc697,'priority':_0x2aa43c});const _0x30ebe3=Kt(_0x1ba580),_0x2f620d=P(_0x2cc697,_0x2aa43c),_0x1830c9=Fn(_0x1ba580['serverSyncTree_'],_0x5c5b4a),_0xa5eeff=ds(_0x2f620d,_0x1830c9,_0x30ebe3),_0x29f704=Hn(_0x1ba580),_0x47aec6=os(_0x1ba580['serverSyncTree_'],_0x5c5b4a,_0xa5eeff,_0x29f704,!0x0);Vn(_0x1ba580['eventQueue_'],_0x47aec6),_0x1ba580['server_']['put'](_0x5c5b4a['toString'](),_0x2f620d['val'](!0x0),(_0xc07d11,_0x1179fd)=>{const _0x18c6f8=_0xc07d11==='ok';_0x18c6f8||U('set\x20at\x20'+_0x5c5b4a+'\x20failed:\x20'+_0xc07d11);const _0x3d285d=pe(_0x1ba580['serverSyncTree_'],_0x29f704,!_0x18c6f8);H(_0x1ba580['eventQueue_'],_0x5c5b4a,_0x3d285d),ki(_0x1ba580,_0x52be10,_0xc07d11,_0x1179fd);});const _0x30fafe=Is(_0x1ba580,_0x5c5b4a);it(_0x1ba580,_0x30fafe),H(_0x1ba580['eventQueue_'],_0x30fafe,[]);}function Td(_0x19ecbd,_0x18f9a5,_0x359995,_0x1b3b45){dt(_0x19ecbd,'update',{'path':_0x18f9a5['toString'](),'value':_0x359995});let _0x4bfebe=!0x0;const _0x553fea=Kt(_0x19ecbd),_0x130489={};if(x(_0x359995,(_0x47bb22,_0x4507d7)=>{_0x4bfebe=!0x1,_0x130489[_0x47bb22]=na(k(_0x18f9a5,_0x47bb22),P(_0x4507d7),_0x19ecbd['serverSyncTree_'],_0x553fea);}),_0x4bfebe)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x19ecbd,_0x1b3b45,'ok',void 0x0);else{const _0x179c5c=Hn(_0x19ecbd),_0x391b2b=ju(_0x19ecbd['serverSyncTree_'],_0x18f9a5,_0x130489,_0x179c5c);Vn(_0x19ecbd['eventQueue_'],_0x391b2b),_0x19ecbd['server_']['merge'](_0x18f9a5['toString'](),_0x359995,(_0x31da68,_0x51cf98)=>{const _0x2f91e3=_0x31da68==='ok';_0x2f91e3||U('update\x20at\x20'+_0x18f9a5+'\x20failed:\x20'+_0x31da68);const _0xd438f5=pe(_0x19ecbd['serverSyncTree_'],_0x179c5c,!_0x2f91e3),_0xc4f369=_0xd438f5['length']>0x0?it(_0x19ecbd,_0x18f9a5):_0x18f9a5;H(_0x19ecbd['eventQueue_'],_0xc4f369,_0xd438f5),ki(_0x19ecbd,_0x1b3b45,_0x31da68,_0x51cf98);}),x(_0x359995,_0x4601ba=>{const _0x4703fc=Is(_0x19ecbd,k(_0x18f9a5,_0x4601ba));it(_0x19ecbd,_0x4703fc);}),H(_0x19ecbd['eventQueue_'],_0x18f9a5,[]);}}function Sd(_0x3cbfee){dt(_0x3cbfee,'onDisconnectEvents');const _0x194023=Kt(_0x3cbfee),_0x1e7285=_n();Ii(_0x3cbfee['onDisconnect_'],w(),(_0x4c2cb2,_0x28ac19)=>{const _0x299e3f=na(_0x4c2cb2,_0x28ac19,_0x3cbfee['serverSyncTree_'],_0x194023);Fo(_0x1e7285,_0x4c2cb2,_0x299e3f);});let _0x3befa7=[];Ii(_0x1e7285,w(),(_0x5be44b,_0x1a618a)=>{_0x3befa7=_0x3befa7['concat'](Gt(_0x3cbfee['serverSyncTree_'],_0x5be44b,_0x1a618a));const _0x9f15e4=Is(_0x3cbfee,_0x5be44b);it(_0x3cbfee,_0x9f15e4);}),_0x3cbfee['onDisconnect_']=_n(),H(_0x3cbfee['eventQueue_'],w(),_0x3befa7);}function bd(_0x49b882,_0x118c60,_0x580554){let _0x4c3c91;y(_0x118c60['_path'])==='.info'?_0x4c3c91=Ri(_0x49b882['infoSyncTree_'],_0x118c60,_0x580554):_0x4c3c91=Ri(_0x49b882['serverSyncTree_'],_0x118c60,_0x580554),oa(_0x49b882['eventQueue_'],_0x118c60['_path'],_0x4c3c91);}function Rd(_0x46c6a2,_0x12b5a2,_0x1c0b5b){let _0x5428c1;y(_0x12b5a2['_path'])==='.info'?_0x5428c1=Cn(_0x46c6a2['infoSyncTree_'],_0x12b5a2,_0x1c0b5b):_0x5428c1=Cn(_0x46c6a2['serverSyncTree_'],_0x12b5a2,_0x1c0b5b),oa(_0x46c6a2['eventQueue_'],_0x12b5a2['_path'],_0x5428c1);}function ha(_0x1acaac){_0x1acaac['persistentConnection_']&&_0x1acaac['persistentConnection_']['interrupt'](ca);}function Ad(_0x3fba92){_0x3fba92['persistentConnection_']&&_0x3fba92['persistentConnection_']['resume'](ca);}function dt(_0x20d21f,..._0x546b77){let _0xa0c04d='';_0x20d21f['persistentConnection_']&&(_0xa0c04d=_0x20d21f['persistentConnection_']['id']+':'),L(_0xa0c04d,..._0x546b77);}function ki(_0x1ccde0,_0x10a9d2,_0x40f6e1,_0x549921){_0x10a9d2&&ht(()=>{if(_0x40f6e1==='ok')_0x10a9d2(null);else{const _0x4db9de=(_0x40f6e1||'error')['toUpperCase']();let _0x11973a=_0x4db9de;_0x549921&&(_0x11973a+=':\x20'+_0x549921);const _0x5c6136=new Error(_0x11973a);_0x5c6136['code']=_0x4db9de,_0x10a9d2(_0x5c6136);}});}function kd(_0x214ea2,_0x4013b3,_0x2aa000,_0x35e33e,_0x2d8fe1,_0x3a342e){dt(_0x214ea2,'transaction\x20on\x20'+_0x4013b3);const _0x575675={'path':_0x4013b3,'update':_0x2aa000,'onComplete':_0x35e33e,'status':null,'order':so(),'applyLocally':_0x3a342e,'retryCount':0x0,'unwatcher':_0x2d8fe1,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0xec7aab=Es(_0x214ea2,_0x4013b3,void 0x0);_0x575675['currentInputSnapshot']=_0xec7aab;const _0x25185d=_0x575675['update'](_0xec7aab['val']());if(_0x25185d===void 0x0)_0x575675['unwatcher'](),_0x575675['currentOutputSnapshotRaw']=null,_0x575675['currentOutputSnapshotResolved']=null,_0x575675['onComplete']&&_0x575675['onComplete'](null,!0x1,_0x575675['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x25185d,_0x575675['path']),_0x575675['status']=0x0;const _0x131b12=Wn(_0x214ea2['transactionQueueTree_'],_0x4013b3),_0x3a7f3e=Ge(_0x131b12)||[];_0x3a7f3e['push'](_0x575675),_s(_0x131b12,_0x3a7f3e);let _0x2fbdbb;typeof _0x25185d=='object'&&_0x25185d!==null&&J(_0x25185d,'.priority')?(_0x2fbdbb=De(_0x25185d,'.priority'),f(Tn(_0x2fbdbb),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x2fbdbb=(Fn(_0x214ea2['serverSyncTree_'],_0x4013b3)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x30afb7=Kt(_0x214ea2),_0x445bf3=P(_0x25185d,_0x2fbdbb),_0x5b4353=ds(_0x445bf3,_0xec7aab,_0x30afb7);_0x575675['currentOutputSnapshotRaw']=_0x445bf3,_0x575675['currentOutputSnapshotResolved']=_0x5b4353,_0x575675['currentWriteId']=Hn(_0x214ea2);const _0x39aedf=os(_0x214ea2['serverSyncTree_'],_0x4013b3,_0x5b4353,_0x575675['currentWriteId'],_0x575675['applyLocally']);H(_0x214ea2['eventQueue_'],_0x4013b3,_0x39aedf),$n(_0x214ea2,_0x214ea2['transactionQueueTree_']);}}function Es(_0x222361,_0x26cff1,_0x1fd058){return Fn(_0x222361['serverSyncTree_'],_0x26cff1,_0x1fd058)||g['EMPTY_NODE'];}function $n(_0x55e860,_0x21d714=_0x55e860['transactionQueueTree_']){if(_0x21d714||Gn(_0x55e860,_0x21d714),Ge(_0x21d714)){const _0x2aae9d=da(_0x55e860,_0x21d714);f(_0x2aae9d['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x2aae9d['every'](_0x570f4c=>_0x570f4c['status']===0x0)&&Nd(_0x55e860,qt(_0x21d714),_0x2aae9d);}else ia(_0x21d714)&&Bn(_0x21d714,_0xea7909=>{$n(_0x55e860,_0xea7909);});}function Nd(_0x508aaa,_0x3f2a22,_0x45ca28){const _0x443761=_0x45ca28['map'](_0x386a73=>_0x386a73['currentWriteId']),_0x291061=Es(_0x508aaa,_0x3f2a22,_0x443761);let _0x2099f6=_0x291061;const _0x154166=_0x291061['hash']();for(let _0x6449c6=0x0;_0x6449c6<_0x45ca28['length'];_0x6449c6++){const _0x3a3217=_0x45ca28[_0x6449c6];f(_0x3a3217['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x3a3217['status']=0x1,_0x3a3217['retryCount']++;const _0x236265=F(_0x3f2a22,_0x3a3217['path']);_0x2099f6=_0x2099f6['updateChild'](_0x236265,_0x3a3217['currentOutputSnapshotRaw']);}const _0x227680=_0x2099f6['val'](!0x0),_0x5de698=_0x3f2a22;_0x508aaa['server_']['put'](_0x5de698['toString'](),_0x227680,_0x3f316b=>{dt(_0x508aaa,'transaction\x20put\x20response',{'path':_0x5de698['toString'](),'status':_0x3f316b});let _0x132412=[];if(_0x3f316b==='ok'){const _0x1b82a8=[];for(let _0x3bdcb8=0x0;_0x3bdcb8<_0x45ca28['length'];_0x3bdcb8++)_0x45ca28[_0x3bdcb8]['status']=0x2,_0x132412=_0x132412['concat'](pe(_0x508aaa['serverSyncTree_'],_0x45ca28[_0x3bdcb8]['currentWriteId'])),_0x45ca28[_0x3bdcb8]['onComplete']&&_0x1b82a8['push'](()=>_0x45ca28[_0x3bdcb8]['onComplete'](null,!0x0,_0x45ca28[_0x3bdcb8]['currentOutputSnapshotResolved'])),_0x45ca28[_0x3bdcb8]['unwatcher']();Gn(_0x508aaa,Wn(_0x508aaa['transactionQueueTree_'],_0x3f2a22)),$n(_0x508aaa,_0x508aaa['transactionQueueTree_']),H(_0x508aaa['eventQueue_'],_0x3f2a22,_0x132412);for(let _0x49ca12=0x0;_0x49ca12<_0x1b82a8['length'];_0x49ca12++)ht(_0x1b82a8[_0x49ca12]);}else{if(_0x3f316b==='datastale'){for(let _0x9bfdda=0x0;_0x9bfdda<_0x45ca28['length'];_0x9bfdda++)_0x45ca28[_0x9bfdda]['status']===0x3?_0x45ca28[_0x9bfdda]['status']=0x4:_0x45ca28[_0x9bfdda]['status']=0x0;}else{U('transaction\x20at\x20'+_0x5de698['toString']()+'\x20failed:\x20'+_0x3f316b);for(let _0x42ae49=0x0;_0x42ae49<_0x45ca28['length'];_0x42ae49++)_0x45ca28[_0x42ae49]['status']=0x4,_0x45ca28[_0x42ae49]['abortReason']=_0x3f316b;}it(_0x508aaa,_0x3f2a22);}},_0x154166);}function it(_0x4a13fd,_0x25f0e1){const _0x31e462=ua(_0x4a13fd,_0x25f0e1),_0x598fc7=qt(_0x31e462),_0x24e880=da(_0x4a13fd,_0x31e462);return Pd(_0x4a13fd,_0x24e880,_0x598fc7),_0x598fc7;}function Pd(_0x28d718,_0x2a2199,_0x393a9f){if(_0x2a2199['length']===0x0)return;const _0x74f949=[];let _0x26b64b=[];const _0x4d7f75=_0x2a2199['filter'](_0x5f58b2=>_0x5f58b2['status']===0x0)['map'](_0x34416c=>_0x34416c['currentWriteId']);for(let _0x18af41=0x0;_0x18af41<_0x2a2199['length'];_0x18af41++){const _0x208432=_0x2a2199[_0x18af41],_0x4301ca=F(_0x393a9f,_0x208432['path']);let _0x56d88a=!0x1,_0x422a4d;if(f(_0x4301ca!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x208432['status']===0x4)_0x56d88a=!0x0,_0x422a4d=_0x208432['abortReason'],_0x26b64b=_0x26b64b['concat'](pe(_0x28d718['serverSyncTree_'],_0x208432['currentWriteId'],!0x0));else{if(_0x208432['status']===0x0){if(_0x208432['retryCount']>=yd)_0x56d88a=!0x0,_0x422a4d='maxretry',_0x26b64b=_0x26b64b['concat'](pe(_0x28d718['serverSyncTree_'],_0x208432['currentWriteId'],!0x0));else{const _0x3f9f8f=Es(_0x28d718,_0x208432['path'],_0x4d7f75);_0x208432['currentInputSnapshot']=_0x3f9f8f;const _0x4c238e=_0x2a2199[_0x18af41]['update'](_0x3f9f8f['val']());if(_0x4c238e!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4c238e,_0x208432['path']);let _0x171415=P(_0x4c238e);typeof _0x4c238e=='object'&&_0x4c238e!=null&&J(_0x4c238e,'.priority')||(_0x171415=_0x171415['updatePriority'](_0x3f9f8f['getPriority']()));const _0x552bc6=_0x208432['currentWriteId'],_0x2092f3=Kt(_0x28d718),_0x513c25=ds(_0x171415,_0x3f9f8f,_0x2092f3);_0x208432['currentOutputSnapshotRaw']=_0x171415,_0x208432['currentOutputSnapshotResolved']=_0x513c25,_0x208432['currentWriteId']=Hn(_0x28d718),_0x4d7f75['splice'](_0x4d7f75['indexOf'](_0x552bc6),0x1),_0x26b64b=_0x26b64b['concat'](os(_0x28d718['serverSyncTree_'],_0x208432['path'],_0x513c25,_0x208432['currentWriteId'],_0x208432['applyLocally'])),_0x26b64b=_0x26b64b['concat'](pe(_0x28d718['serverSyncTree_'],_0x552bc6,!0x0));}else _0x56d88a=!0x0,_0x422a4d='nodata',_0x26b64b=_0x26b64b['concat'](pe(_0x28d718['serverSyncTree_'],_0x208432['currentWriteId'],!0x0));}}}H(_0x28d718['eventQueue_'],_0x393a9f,_0x26b64b),_0x26b64b=[],_0x56d88a&&(_0x2a2199[_0x18af41]['status']=0x2,function(_0x1bfc14){setTimeout(_0x1bfc14,Math['floor'](0x0));}(_0x2a2199[_0x18af41]['unwatcher']),_0x2a2199[_0x18af41]['onComplete']&&(_0x422a4d==='nodata'?_0x74f949['push'](()=>_0x2a2199[_0x18af41]['onComplete'](null,!0x1,_0x2a2199[_0x18af41]['currentInputSnapshot'])):_0x74f949['push'](()=>_0x2a2199[_0x18af41]['onComplete'](new Error(_0x422a4d),!0x1,null))));}Gn(_0x28d718,_0x28d718['transactionQueueTree_']);for(let _0x101ddf=0x0;_0x101ddf<_0x74f949['length'];_0x101ddf++)ht(_0x74f949[_0x101ddf]);$n(_0x28d718,_0x28d718['transactionQueueTree_']);}function ua(_0xbadb39,_0x3cd884){let _0x4213c9,_0x270403=_0xbadb39['transactionQueueTree_'];for(_0x4213c9=y(_0x3cd884);_0x4213c9!==null&&Ge(_0x270403)===void 0x0;)_0x270403=Wn(_0x270403,_0x4213c9),_0x3cd884=b(_0x3cd884),_0x4213c9=y(_0x3cd884);return _0x270403;}function da(_0x31f1a9,_0x784ec4){const _0x532c2c=[];return fa(_0x31f1a9,_0x784ec4,_0x532c2c),_0x532c2c['sort']((_0x2b4a3a,_0x5cf258)=>_0x2b4a3a['order']-_0x5cf258['order']),_0x532c2c;}function fa(_0x140344,_0x450da9,_0x55b3e7){const _0x16dd54=Ge(_0x450da9);if(_0x16dd54){for(let _0x221413=0x0;_0x221413<_0x16dd54['length'];_0x221413++)_0x55b3e7['push'](_0x16dd54[_0x221413]);}Bn(_0x450da9,_0x1876c5=>{fa(_0x140344,_0x1876c5,_0x55b3e7);});}function Gn(_0x2edb41,_0x5c505d){const _0xdc86e8=Ge(_0x5c505d);if(_0xdc86e8){let _0x2a347e=0x0;for(let _0x54eed1=0x0;_0x54eed1<_0xdc86e8['length'];_0x54eed1++)_0xdc86e8[_0x54eed1]['status']!==0x2&&(_0xdc86e8[_0x2a347e]=_0xdc86e8[_0x54eed1],_0x2a347e++);_0xdc86e8['length']=_0x2a347e,_s(_0x5c505d,_0xdc86e8['length']>0x0?_0xdc86e8:void 0x0);}Bn(_0x5c505d,_0x1fe9d8=>{Gn(_0x2edb41,_0x1fe9d8);});}function Is(_0x2bee41,_0x32755a){const _0x5ce3e7=qt(ua(_0x2bee41,_0x32755a)),_0x57e728=Wn(_0x2bee41['transactionQueueTree_'],_0x32755a);return ad(_0x57e728,_0x250ee5=>{ci(_0x2bee41,_0x250ee5);}),ci(_0x2bee41,_0x57e728),sa(_0x57e728,_0xdf9585=>{ci(_0x2bee41,_0xdf9585);}),_0x5ce3e7;}function ci(_0x563c4b,_0x45a52d){const _0x17e7a1=Ge(_0x45a52d);if(_0x17e7a1){const _0x5212cc=[];let _0x54b438=[],_0x44d8b9=-0x1;for(let _0x31dc3d=0x0;_0x31dc3d<_0x17e7a1['length'];_0x31dc3d++)_0x17e7a1[_0x31dc3d]['status']===0x3||(_0x17e7a1[_0x31dc3d]['status']===0x1?(f(_0x44d8b9===_0x31dc3d-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x44d8b9=_0x31dc3d,_0x17e7a1[_0x31dc3d]['status']=0x3,_0x17e7a1[_0x31dc3d]['abortReason']='set'):(f(_0x17e7a1[_0x31dc3d]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x17e7a1[_0x31dc3d]['unwatcher'](),_0x54b438=_0x54b438['concat'](pe(_0x563c4b['serverSyncTree_'],_0x17e7a1[_0x31dc3d]['currentWriteId'],!0x0)),_0x17e7a1[_0x31dc3d]['onComplete']&&_0x5212cc['push'](_0x17e7a1[_0x31dc3d]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x44d8b9===-0x1?_s(_0x45a52d,void 0x0):_0x17e7a1['length']=_0x44d8b9+0x1,H(_0x563c4b['eventQueue_'],qt(_0x45a52d),_0x54b438);for(let _0x3e2fd7=0x0;_0x3e2fd7<_0x5212cc['length'];_0x3e2fd7++)ht(_0x5212cc[_0x3e2fd7]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0xdec9b4){let _0x6c6b45='';const _0x551e67=_0xdec9b4['split']('/');for(let _0x5422f3=0x0;_0x5422f3<_0x551e67['length'];_0x5422f3++)if(_0x551e67[_0x5422f3]['length']>0x0){let _0x11198e=_0x551e67[_0x5422f3];try{_0x11198e=decodeURIComponent(_0x11198e['replace'](/\+/g,'\x20'));}catch{}_0x6c6b45+='/'+_0x11198e;}return _0x6c6b45;}function Dd(_0x12d23a){const _0x1fe522={};_0x12d23a['charAt'](0x0)==='?'&&(_0x12d23a=_0x12d23a['substring'](0x1));for(const _0x2d7658 of _0x12d23a['split']('&')){if(_0x2d7658['length']===0x0)continue;const _0x24758c=_0x2d7658['split']('=');_0x24758c['length']===0x2?_0x1fe522[decodeURIComponent(_0x24758c[0x0])]=decodeURIComponent(_0x24758c[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x2d7658+'\x27\x20in\x20query\x20\x27'+_0x12d23a+'\x27');}return _0x1fe522;}const vr=function(_0x4bde2a,_0x580959){const _0x595a92=Md(_0x4bde2a),_0x5e0099=_0x595a92['namespace'];_0x595a92['domain']==='firebase.com'&&ae(_0x595a92['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5e0099||_0x5e0099==='undefined')&&_0x595a92['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x595a92['secure']||$l();const _0x1cd9c8=_0x595a92['scheme']==='ws'||_0x595a92['scheme']==='wss';return{'repoInfo':new yo(_0x595a92['host'],_0x595a92['secure'],_0x5e0099,_0x1cd9c8,_0x580959,'',_0x5e0099!==_0x595a92['subdomain']),'path':new C(_0x595a92['pathString'])};},Md=function(_0x203b60){let _0x1510b1='',_0x53d271='',_0x1ed79c='',_0x308965='',_0x49a433='',_0x24b2f9=!0x0,_0x5158d0='https',_0x1772c9=0x1bb;if(typeof _0x203b60=='string'){let _0x3270d9=_0x203b60['indexOf']('//');_0x3270d9>=0x0&&(_0x5158d0=_0x203b60['substring'](0x0,_0x3270d9-0x1),_0x203b60=_0x203b60['substring'](_0x3270d9+0x2));let _0x2ca304=_0x203b60['indexOf']('/');_0x2ca304===-0x1&&(_0x2ca304=_0x203b60['length']);let _0x332efd=_0x203b60['indexOf']('?');_0x332efd===-0x1&&(_0x332efd=_0x203b60['length']),_0x1510b1=_0x203b60['substring'](0x0,Math['min'](_0x2ca304,_0x332efd)),_0x2ca304<_0x332efd&&(_0x308965=Od(_0x203b60['substring'](_0x2ca304,_0x332efd)));const _0x3ec70a=Dd(_0x203b60['substring'](Math['min'](_0x203b60['length'],_0x332efd)));_0x3270d9=_0x1510b1['indexOf'](':'),_0x3270d9>=0x0?(_0x24b2f9=_0x5158d0==='https'||_0x5158d0==='wss',_0x1772c9=parseInt(_0x1510b1['substring'](_0x3270d9+0x1),0xa)):_0x3270d9=_0x1510b1['length'];const _0x59345b=_0x1510b1['slice'](0x0,_0x3270d9);if(_0x59345b['toLowerCase']()==='localhost')_0x53d271='localhost';else{if(_0x59345b['split']('.')['length']<=0x2)_0x53d271=_0x59345b;else{const _0x318a88=_0x1510b1['indexOf']('.');_0x1ed79c=_0x1510b1['substring'](0x0,_0x318a88)['toLowerCase'](),_0x53d271=_0x1510b1['substring'](_0x318a88+0x1),_0x49a433=_0x1ed79c;}}'ns'in _0x3ec70a&&(_0x49a433=_0x3ec70a['ns']);}return{'host':_0x1510b1,'port':_0x1772c9,'domain':_0x53d271,'subdomain':_0x1ed79c,'secure':_0x24b2f9,'scheme':_0x5158d0,'pathString':_0x308965,'namespace':_0x49a433};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x4ed683=0x0;const _0x24ae3d=[];return function(_0x7d3c97){const _0x2d01fe=_0x7d3c97===_0x4ed683;_0x4ed683=_0x7d3c97;let _0xec241;const _0x55886c=new Array(0x8);for(_0xec241=0x7;_0xec241>=0x0;_0xec241--)_0x55886c[_0xec241]=Er['charAt'](_0x7d3c97%0x40),_0x7d3c97=Math['floor'](_0x7d3c97/0x40);f(_0x7d3c97===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x3b706d=_0x55886c['join']('');if(_0x2d01fe){for(_0xec241=0xb;_0xec241>=0x0&&_0x24ae3d[_0xec241]===0x3f;_0xec241--)_0x24ae3d[_0xec241]=0x0;_0x24ae3d[_0xec241]++;}else{for(_0xec241=0x0;_0xec241<0xc;_0xec241++)_0x24ae3d[_0xec241]=Math['floor'](Math['random']()*0x40);}for(_0xec241=0x0;_0xec241<0xc;_0xec241++)_0x3b706d+=Er['charAt'](_0x24ae3d[_0xec241]);return f(_0x3b706d['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x3b706d;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x142d88,_0x3a1536,_0x22909e,_0x24c28b){this['eventType']=_0x142d88,this['eventRegistration']=_0x3a1536,this['snapshot']=_0x22909e,this['prevName']=_0x24c28b;}['getPath'](){const _0xbe3f95=this['snapshot']['ref'];return this['eventType']==='value'?_0xbe3f95['_path']:_0xbe3f95['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x18bbcc,_0x24220b,_0x3557e9){this['eventRegistration']=_0x18bbcc,this['error']=_0x24220b,this['path']=_0x3557e9;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x12da87,_0x508427){this['snapshotCallback']=_0x12da87,this['cancelCallback']=_0x508427;}['onValue'](_0x114d7f,_0x255d31){this['snapshotCallback']['call'](null,_0x114d7f,_0x255d31);}['onCancel'](_0x44273c){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x44273c);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x53a94c){return this['snapshotCallback']===_0x53a94c['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x53a94c['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x53a94c['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x355970,_0x2478d9,_0x5c3f89,_0x3f037e){this['_repo']=_0x355970,this['_path']=_0x2478d9,this['_queryParams']=_0x5c3f89,this['_orderByCalled']=_0x3f037e;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x4f5c38=rr(this['_queryParams']),_0xf13b76=Hi(_0x4f5c38);return _0xf13b76==='{}'?'default':_0xf13b76;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0xafad3a){if(_0xafad3a=N(_0xafad3a),!(_0xafad3a instanceof be))return!0x1;const _0x3f812c=this['_repo']===_0xafad3a['_repo'],_0x5bfe69=ji(this['_path'],_0xafad3a['_path']),_0x1cefad=this['_queryIdentifier']===_0xafad3a['_queryIdentifier'];return _0x3f812c&&_0x5bfe69&&_0x1cefad;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x500f26,_0x12c783){if(_0x500f26['_orderByCalled']===!0x0)throw new Error(_0x12c783+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x36e678){let _0x298d84=null,_0x15a082=null;if(_0x36e678['hasStart']()&&(_0x298d84=_0x36e678['getIndexStartValue']()),_0x36e678['hasEnd']()&&(_0x15a082=_0x36e678['getIndexEndValue']()),_0x36e678['getIndex']()===ye){const _0xc1bb8f='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x536f10='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x36e678['hasStart']()){if(_0x36e678['getIndexStartName']()!==Fe)throw new Error(_0xc1bb8f);if(typeof _0x298d84!='string')throw new Error(_0x536f10);}if(_0x36e678['hasEnd']()){if(_0x36e678['getIndexEndName']()!==Ie)throw new Error(_0xc1bb8f);if(typeof _0x15a082!='string')throw new Error(_0x536f10);}}else{if(_0x36e678['getIndex']()===R){if(_0x298d84!=null&&!Tn(_0x298d84)||_0x15a082!=null&&!Tn(_0x15a082))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x36e678['getIndex']()instanceof Qi||_0x36e678['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x298d84!=null&&typeof _0x298d84=='object'||_0x15a082!=null&&typeof _0x15a082=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x58d8ae){if(_0x58d8ae['hasStart']()&&_0x58d8ae['hasEnd']()&&_0x58d8ae['hasLimit']()&&!_0x58d8ae['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x46ebcc,_0x32a742){super(_0x46ebcc,_0x32a742,new Xi(),!0x1);}get['parent'](){const _0x17b83d=Ro(this['_path']);return _0x17b83d===null?null:new ee(this['_repo'],_0x17b83d);}get['root'](){let _0x3327a5=this;for(;_0x3327a5['parent']!==null;)_0x3327a5=_0x3327a5['parent'];return _0x3327a5;}}class st{constructor(_0x4f8c77,_0x2fd4fb,_0x3615aa){this['_node']=_0x4f8c77,this['ref']=_0x2fd4fb,this['_index']=_0x3615aa;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x14a2fd){const _0x134140=new C(_0x14a2fd),_0x1de5b5=Ft(this['ref'],_0x14a2fd);return new st(this['_node']['getChild'](_0x134140),_0x1de5b5,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x468c7e){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x5498f8,_0x86010e)=>_0x468c7e(new st(_0x86010e,Ft(this['ref'],_0x5498f8),R)));}['hasChild'](_0x4c6b89){const _0x4dab75=new C(_0x4c6b89);return!this['_node']['getChild'](_0x4dab75)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x3e4cff,_0x140c55){return _0x3e4cff=N(_0x3e4cff),_0x3e4cff['_checkNotDeleted']('ref'),_0x140c55!==void 0x0?Ft(_0x3e4cff['_root'],_0x140c55):_0x3e4cff['_root'];}function Ft(_0x28974f,_0x5d5ba2){return _0x28974f=N(_0x28974f),y(_0x28974f['_path'])===null?pd('child','path',_0x5d5ba2):ms('child','path',_0x5d5ba2),new ee(_0x28974f['_repo'],k(_0x28974f['_path'],_0x5d5ba2));}function g_(_0x322c06,_0x5ec0d2){_0x322c06=N(_0x322c06),ys('push',_0x322c06['_path']),zt('push',_0x5ec0d2,_0x322c06['_path'],!0x0);const _0x3e11e6=la(_0x322c06['_repo']),_0x122b53=Ld(_0x3e11e6),_0x2a3fe3=Ft(_0x322c06,_0x122b53),_0x3463e1=Ft(_0x322c06,_0x122b53);let _0x599192;return _0x5ec0d2!=null?_0x599192=Ud(_0x3463e1,_0x5ec0d2)['then'](()=>_0x3463e1):_0x599192=Promise['resolve'](_0x3463e1),_0x2a3fe3['then']=_0x599192['then']['bind'](_0x599192),_0x2a3fe3['catch']=_0x599192['then']['bind'](_0x599192,void 0x0),_0x2a3fe3;}function Ud(_0x12345e,_0x1a6d81){_0x12345e=N(_0x12345e),ys('set',_0x12345e['_path']),zt('set',_0x1a6d81,_0x12345e['_path'],!0x1);const _0x75461c=new ot();return Cd(_0x12345e['_repo'],_0x12345e['_path'],_0x1a6d81,null,_0x75461c['wrapCallback'](()=>{})),_0x75461c['promise'];}function m_(_0x26570a,_0x1bfa5d){fd('update',_0x1bfa5d,_0x26570a['_path']);const _0x24c0bb=new ot();return Td(_0x26570a['_repo'],_0x26570a['_path'],_0x1bfa5d,_0x24c0bb['wrapCallback'](()=>{})),_0x24c0bb['promise'];}function y_(_0x313a4e){_0x313a4e=N(_0x313a4e);const _0x4fc1d0=new pa(()=>{}),_0x4ed64a=new zn(_0x4fc1d0);return wd(_0x313a4e['_repo'],_0x313a4e,_0x4ed64a)['then'](_0x4aecd0=>new st(_0x4aecd0,new ee(_0x313a4e['_repo'],_0x313a4e['_path']),_0x313a4e['_queryParams']['getIndex']()));}class zn{constructor(_0x420251){this['callbackContext']=_0x420251;}['respondsTo'](_0x1cf501){return _0x1cf501==='value';}['createEvent'](_0x798db7,_0x5eb16d){const _0x3d9402=_0x5eb16d['_queryParams']['getIndex']();return new xd('value',this,new st(_0x798db7['snapshotNode'],new ee(_0x5eb16d['_repo'],_0x5eb16d['_path']),_0x3d9402));}['getEventRunner'](_0x428e29){return _0x428e29['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x428e29['error']):()=>this['callbackContext']['onValue'](_0x428e29['snapshot'],null);}['createCancelEvent'](_0x38f874,_0x4ec809){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x38f874,_0x4ec809):null;}['matches'](_0x5bbbed){return _0x5bbbed instanceof zn?!_0x5bbbed['callbackContext']||!this['callbackContext']?!0x0:_0x5bbbed['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x1be7c4,_0x5d9f5b,_0x19bc09,_0x756dcd,_0x1f0701){const _0x4f572b=new pa(_0x19bc09,void 0x0),_0x58b248=new zn(_0x4f572b);return bd(_0x1be7c4['_repo'],_0x1be7c4,_0x58b248),()=>Rd(_0x1be7c4['_repo'],_0x1be7c4,_0x58b248);}function Bd(_0x37e554,_0x3d67c7,_0x275994,_0x2230f1){return Wd(_0x37e554,'value',_0x3d67c7);}class ft{}class ma extends ft{constructor(_0x10de64,_0x1702fe){super(),this['_value']=_0x10de64,this['_key']=_0x1702fe,this['type']='endAt';}['_apply'](_0xbea005){zt('endAt',this['_value'],_0xbea005['_path'],!0x0);const _0x2d61c8=Jh(_0xbea005['_queryParams'],this['_value'],this['_key']);if(ga(_0x2d61c8),qn(_0x2d61c8),_0xbea005['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0xbea005['_repo'],_0xbea005['_path'],_0x2d61c8,_0xbea005['_orderByCalled']);}}function v_(_0x395921,_0x3aa6ba){return new ma(_0x395921,_0x3aa6ba);}class ya extends ft{constructor(_0xf77390,_0x117b7f){super(),this['_value']=_0xf77390,this['_key']=_0x117b7f,this['type']='startAt';}['_apply'](_0x326d90){zt('startAt',this['_value'],_0x326d90['_path'],!0x0);const _0x24d2f0=Qh(_0x326d90['_queryParams'],this['_value'],this['_key']);if(ga(_0x24d2f0),qn(_0x24d2f0),_0x326d90['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x326d90['_repo'],_0x326d90['_path'],_0x24d2f0,_0x326d90['_orderByCalled']);}}function E_(_0x4f39a9=null,_0x53b4e0){return new ya(_0x4f39a9,_0x53b4e0);}class Vd extends ft{constructor(_0x502585){super(),this['_limit']=_0x502585,this['type']='limitToFirst';}['_apply'](_0x269c07){if(_0x269c07['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x269c07['_repo'],_0x269c07['_path'],Yh(_0x269c07['_queryParams'],this['_limit']),_0x269c07['_orderByCalled']);}}function I_(_0x45c834){if(Math['floor'](_0x45c834)!==_0x45c834||_0x45c834<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x45c834);}class Hd extends ft{constructor(_0xa9a40d){super(),this['_path']=_0xa9a40d,this['type']='orderByChild';}['_apply'](_0x5bee70){_a(_0x5bee70,'orderByChild');const _0x19e8bb=new C(this['_path']);if(v(_0x19e8bb))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x4c76b7=new Qi(_0x19e8bb),_0x5e0ee8=xo(_0x5bee70['_queryParams'],_0x4c76b7);return qn(_0x5e0ee8),new be(_0x5bee70['_repo'],_0x5bee70['_path'],_0x5e0ee8,!0x0);}}function w_(_0x39a6f0){if(_0x39a6f0==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x39a6f0==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x39a6f0==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x39a6f0),new Hd(_0x39a6f0);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0xe7d098){_a(_0xe7d098,'orderByKey');const _0x4c0b2e=xo(_0xe7d098['_queryParams'],ye);return qn(_0x4c0b2e),new be(_0xe7d098['_repo'],_0xe7d098['_path'],_0x4c0b2e,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x4eb0b4,_0x2ea751){super(),this['_value']=_0x4eb0b4,this['_key']=_0x2ea751,this['type']='equalTo';}['_apply'](_0x4f9a98){if(zt('equalTo',this['_value'],_0x4f9a98['_path'],!0x1),_0x4f9a98['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x4f9a98['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x4f9a98));}}function T_(_0x3f720c,_0x3729b6){return new Gd(_0x3f720c,_0x3729b6);}function S_(_0x4e214f,..._0x120ac3){let _0x569877=N(_0x4e214f);for(const _0x5549e7 of _0x120ac3)_0x569877=_0x5549e7['_apply'](_0x569877);return _0x569877;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x505cc0,_0x20fa31,_0x700d84,_0x515e5b){const _0x38c1d2=_0x20fa31['lastIndexOf'](':'),_0x3c9b0a=_0x20fa31['substring'](0x0,_0x38c1d2),_0x4325a2=at(_0x3c9b0a);_0x505cc0['repoInfo_']=new yo(_0x20fa31,_0x4325a2,_0x505cc0['repoInfo_']['namespace'],_0x505cc0['repoInfo_']['webSocketOnly'],_0x505cc0['repoInfo_']['nodeAdmin'],_0x505cc0['repoInfo_']['persistenceKey'],_0x505cc0['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x700d84),_0x515e5b&&(_0x505cc0['authTokenProvider_']=_0x515e5b);}function Kd(_0x368d29,_0x40f7f5,_0xf9ef33,_0x91dc27,_0x462890){let _0x41db4c=_0x91dc27||_0x368d29['options']['databaseURL'];_0x41db4c===void 0x0&&(_0x368d29['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x368d29['options']['projectId']),_0x41db4c=_0x368d29['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x14fd35=vr(_0x41db4c,_0x462890),_0x416304=_0x14fd35['repoInfo'],_0x6bb5c5;typeof process<'u'&&Vs&&(_0x6bb5c5=Vs[qd]),_0x6bb5c5?(_0x41db4c='http://'+_0x6bb5c5+'?ns='+_0x416304['namespace'],_0x14fd35=vr(_0x41db4c,_0x462890),_0x416304=_0x14fd35['repoInfo']):_0x14fd35['repoInfo']['secure'];const _0x5d7e58=new eh(_0x368d29['name'],_0x368d29['options'],_0x40f7f5);_d('Invalid\x20Firebase\x20Database\x20URL',_0x14fd35),v(_0x14fd35['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x90f124=Qd(_0x416304,_0x368d29,_0x5d7e58,new Zl(_0x368d29,_0xf9ef33));return new Jd(_0x90f124,_0x368d29);}function Yd(_0x1f186d,_0x42662e){const _0x31b40b=Ni[_0x42662e];(!_0x31b40b||_0x31b40b[_0x1f186d['key']]!==_0x1f186d)&&ae('Database\x20'+_0x42662e+'('+_0x1f186d['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x1f186d),delete _0x31b40b[_0x1f186d['key']];}function Qd(_0x1f1964,_0x466244,_0xc70bb,_0xe1bea7){let _0x59f3bf=Ni[_0x466244['name']];_0x59f3bf||(_0x59f3bf={},Ni[_0x466244['name']]=_0x59f3bf);let _0x524dbc=_0x59f3bf[_0x1f1964['toURLString']()];return _0x524dbc&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x524dbc=new vd(_0x1f1964,zd,_0xc70bb,_0xe1bea7),_0x59f3bf[_0x1f1964['toURLString']()]=_0x524dbc,_0x524dbc;}class Jd{constructor(_0x814c84,_0x4489f3){this['_repoInternal']=_0x814c84,this['app']=_0x4489f3,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x443787){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x443787+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x353524=Zr(),_0x494c5a){const _0x2fe224=Bi(_0x353524,'database')['getImmediate']({'identifier':_0x494c5a});if(!_0x2fe224['_instanceStarted']){const _0x45a227=cc('database');_0x45a227&&Xd(_0x2fe224,..._0x45a227);}return _0x2fe224;}function Xd(_0x3517fb,_0x5df511,_0x1d8bf7,_0x85485d={}){_0x3517fb=N(_0x3517fb),_0x3517fb['_checkNotDeleted']('useEmulator');const _0x95a7a5=_0x5df511+':'+_0x1d8bf7,_0x5c6338=_0x3517fb['_repoInternal'];if(_0x3517fb['_instanceStarted']){if(_0x95a7a5===_0x3517fb['_repoInternal']['repoInfo_']['host']&&Me(_0x85485d,_0x5c6338['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x5583b7;if(_0x5c6338['repoInfo_']['nodeAdmin'])_0x85485d['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x5583b7=new nn(nn['OWNER']);else{if(_0x85485d['mockUserToken']){const _0x391757=typeof _0x85485d['mockUserToken']=='string'?_0x85485d['mockUserToken']:lc(_0x85485d['mockUserToken'],_0x3517fb['app']['options']['projectId']);_0x5583b7=new nn(_0x391757);}}at(_0x5df511)&&(jr(_0x5df511),Kr('Database',!0x0)),jd(_0x5c6338,_0x95a7a5,_0x85485d,_0x5583b7);}function R_(_0x1a74a7){_0x1a74a7=N(_0x1a74a7),_0x1a74a7['_checkNotDeleted']('goOffline'),ha(_0x1a74a7['_repo']);}function A_(_0x6c47d6){_0x6c47d6=N(_0x6c47d6),_0x6c47d6['_checkNotDeleted']('goOnline'),Ad(_0x6c47d6['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x3fae81){Ul(lt),Ze(new Le('database',(_0x6423fc,{instanceIdentifier:_0x2ed696})=>{const _0x3cceb3=_0x6423fc['getProvider']('app')['getImmediate'](),_0x976461=_0x6423fc['getProvider']('auth-internal'),_0x559e7c=_0x6423fc['getProvider']('app-check-internal');return Kd(_0x3cceb3,_0x976461,_0x559e7c,_0x2ed696);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x3fae81),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x63f8f9,_0x421a2b){this['committed']=_0x63f8f9,this['snapshot']=_0x421a2b;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x2aa3fd,_0x5a6115,_0x1ddf73){if(_0x2aa3fd=N(_0x2aa3fd),ys('Reference.transaction',_0x2aa3fd['_path']),_0x2aa3fd['key']==='.length'||_0x2aa3fd['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x2aa3fd['key']+'\x20is\x20a\x20read-only\x20object.';const _0x398345=!0x0,_0x169e3f=new ot(),_0x20d1d7=(_0x30357b,_0x202bc2,_0x147379)=>{let _0x4bf55c=null;_0x30357b?_0x169e3f['reject'](_0x30357b):(_0x4bf55c=new st(_0x147379,new ee(_0x2aa3fd['_repo'],_0x2aa3fd['_path']),R),_0x169e3f['resolve'](new tf(_0x202bc2,_0x4bf55c)));},_0x5235a8=Bd(_0x2aa3fd,()=>{});return kd(_0x2aa3fd['_repo'],_0x2aa3fd['_path'],_0x5a6115,_0x20d1d7,_0x5235a8,_0x398345),_0x169e3f['promise'];}se['prototype']['simpleListen']=function(_0x54f8f2,_0x1d77cb){this['sendRequest']('q',{'p':_0x54f8f2},_0x1d77cb);},se['prototype']['echo']=function(_0x48f73d,_0x306b73){this['sendRequest']('echo',{'d':_0x48f73d},_0x306b73);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x568178,..._0xe58f3b){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x568178,..._0xe58f3b);}function sn(_0x2ca8e0,..._0x4b26c7){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x2ca8e0,..._0x4b26c7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x89afb0,..._0x5a7303){throw ws(_0x89afb0,..._0x5a7303);}function X(_0x434af5,..._0xb5d63c){return ws(_0x434af5,..._0xb5d63c);}function Ia(_0x863e30,_0x3087a8,_0x472a5a){const _0x1daef1={...nf(),[_0x3087a8]:_0x472a5a};return new Bt('auth','Firebase',_0x1daef1)['create'](_0x3087a8,{'appName':_0x863e30['name']});}function re(_0x114448){return Ia(_0x114448,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x48917d,..._0x5a664f){if(typeof _0x48917d!='string'){const _0x1d4289=_0x5a664f[0x0],_0x1f776c=[..._0x5a664f['slice'](0x1)];return _0x1f776c[0x0]&&(_0x1f776c[0x0]['appName']=_0x48917d['name']),_0x48917d['_errorFactory']['create'](_0x1d4289,..._0x1f776c);}return Ea['create'](_0x48917d,..._0x5a664f);}function m(_0x57bd39,_0xbb22bb,..._0xf10441){if(!_0x57bd39)throw ws(_0xbb22bb,..._0xf10441);}function ne(_0x15ab16){const _0x51e86e='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x15ab16;throw sn(_0x51e86e),new Error(_0x51e86e);}function ce(_0x5798a5,_0x3b1a60){_0x5798a5||ne(_0x3b1a60);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x3764c6;return typeof self<'u'&&((_0x3764c6=self['location'])==null?void 0x0:_0x3764c6['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x437495;return typeof self<'u'&&((_0x437495=self['location'])==null?void 0x0:_0x437495['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x31e18a=navigator;return _0x31e18a['languages']&&_0x31e18a['languages'][0x0]||_0x31e18a['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x2361a7,_0x12bb32){this['shortDelay']=_0x2361a7,this['longDelay']=_0x12bb32,ce(_0x12bb32>_0x2361a7,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x3ca96e,_0x532a10){ce(_0x3ca96e['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x26b719}=_0x3ca96e['emulator'];return _0x532a10?''+_0x26b719+(_0x532a10['startsWith']('/')?_0x532a10['slice'](0x1):_0x532a10):_0x26b719;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x1eec9b,_0x4b9df9,_0xe957e3){this['fetchImpl']=_0x1eec9b,_0x4b9df9&&(this['headersImpl']=_0x4b9df9),_0xe957e3&&(this['responseImpl']=_0xe957e3);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x508633,_0x26bb5e){return _0x508633['tenantId']&&!_0x26bb5e['tenantId']?{..._0x26bb5e,'tenantId':_0x508633['tenantId']}:_0x26bb5e;}async function Ae(_0xddb157,_0x3b83b6,_0x238318,_0x391b29,_0x5009f4={}){return Ca(_0xddb157,_0x5009f4,async()=>{let _0x59fa75={},_0x2ddd1f={};_0x391b29&&(_0x3b83b6==='GET'?_0x2ddd1f=_0x391b29:_0x59fa75={'body':JSON['stringify'](_0x391b29)});const _0x48ee69=ct({'key':_0xddb157['config']['apiKey'],..._0x2ddd1f})['slice'](0x1),_0x359d0a=await _0xddb157['_getAdditionalHeaders']();_0x359d0a['Content-Type']='application/json',_0xddb157['languageCode']&&(_0x359d0a['X-Firebase-Locale']=_0xddb157['languageCode']);const _0x13d63d={'method':_0x3b83b6,'headers':_0x359d0a,..._0x59fa75};return dc()||(_0x13d63d['referrerPolicy']='no-referrer'),_0xddb157['emulatorConfig']&&at(_0xddb157['emulatorConfig']['host'])&&(_0x13d63d['credentials']='include'),wa['fetch']()(await Ta(_0xddb157,_0xddb157['config']['apiHost'],_0x238318,_0x48ee69),_0x13d63d);});}async function Ca(_0x2a0d3e,_0x1f5868,_0x2c3be6){_0x2a0d3e['_canInitEmulator']=!0x1;const _0x5a45b0={...cf,..._0x1f5868};try{const _0x5ecc61=new df(_0x2a0d3e),_0xd92d70=await Promise['race']([_0x2c3be6(),_0x5ecc61['promise']]);_0x5ecc61['clearNetworkTimeout']();const _0x55001a=await _0xd92d70['json']();if('needConfirmation'in _0x55001a)throw tn(_0x2a0d3e,'account-exists-with-different-credential',_0x55001a);if(_0xd92d70['ok']&&!('errorMessage'in _0x55001a))return _0x55001a;{const _0x40ebfb=_0xd92d70['ok']?_0x55001a['errorMessage']:_0x55001a['error']['message'],[_0xefe311,_0x1ff5da]=_0x40ebfb['split']('\x20:\x20');if(_0xefe311==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x2a0d3e,'credential-already-in-use',_0x55001a);if(_0xefe311==='EMAIL_EXISTS')throw tn(_0x2a0d3e,'email-already-in-use',_0x55001a);if(_0xefe311==='USER_DISABLED')throw tn(_0x2a0d3e,'user-disabled',_0x55001a);const _0x573d09=_0x5a45b0[_0xefe311]||_0xefe311['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x1ff5da)throw Ia(_0x2a0d3e,_0x573d09,_0x1ff5da);Q(_0x2a0d3e,_0x573d09);}}catch(_0x24f779){if(_0x24f779 instanceof Se)throw _0x24f779;Q(_0x2a0d3e,'network-request-failed',{'message':String(_0x24f779)});}}async function Qt(_0x1d115a,_0x16e027,_0x264c79,_0x342dca,_0x5beba0={}){const _0x469fbf=await Ae(_0x1d115a,_0x16e027,_0x264c79,_0x342dca,_0x5beba0);return'mfaPendingCredential'in _0x469fbf&&Q(_0x1d115a,'multi-factor-auth-required',{'_serverResponse':_0x469fbf}),_0x469fbf;}async function Ta(_0x1a617d,_0x430bf9,_0x4649d5,_0x17dd25){const _0x1c0fb3=''+_0x430bf9+_0x4649d5+'?'+_0x17dd25,_0x3619b=_0x1a617d,_0x521490=_0x3619b['config']['emulator']?Cs(_0x1a617d['config'],_0x1c0fb3):_0x1a617d['config']['apiScheme']+'://'+_0x1c0fb3;return lf['includes'](_0x4649d5)&&(await _0x3619b['_persistenceManagerAvailable'],_0x3619b['_getPersistenceType']()==='COOKIE')?_0x3619b['_getPersistence']()['_getFinalTarget'](_0x521490)['toString']():_0x521490;}function uf(_0x4ae183){switch(_0x4ae183){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x584081){this['auth']=_0x584081,this['timer']=null,this['promise']=new Promise((_0x2612ae,_0x48b311)=>{this['timer']=setTimeout(()=>_0x48b311(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x2b27bc,_0x3f45f,_0x3e577a){const _0x12aa16={'appName':_0x2b27bc['name']};_0x3e577a['email']&&(_0x12aa16['email']=_0x3e577a['email']),_0x3e577a['phoneNumber']&&(_0x12aa16['phoneNumber']=_0x3e577a['phoneNumber']);const _0x867c97=X(_0x2b27bc,_0x3f45f,_0x12aa16);return _0x867c97['customData']['_tokenResponse']=_0x3e577a,_0x867c97;}function wr(_0x413d68){return _0x413d68!==void 0x0&&_0x413d68['enterprise']!==void 0x0;}class ff{constructor(_0x299659){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x299659['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x299659['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x299659['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x4b67ac){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3833ca of this['recaptchaEnforcementState'])if(_0x3833ca['provider']&&_0x3833ca['provider']===_0x4b67ac)return uf(_0x3833ca['enforcementState']);return null;}['isProviderEnabled'](_0x37d737){return this['getProviderEnforcementState'](_0x37d737)==='ENFORCE'||this['getProviderEnforcementState'](_0x37d737)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x4bac6f,_0x206046){return Ae(_0x4bac6f,'GET','/v2/recaptchaConfig',Re(_0x4bac6f,_0x206046));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x4daba8,_0x1acf7c){return Ae(_0x4daba8,'POST','/v1/accounts:delete',_0x1acf7c);}async function bn(_0x2d1a9b,_0xc189b8){return Ae(_0x2d1a9b,'POST','/v1/accounts:lookup',_0xc189b8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x172272){if(_0x172272)try{const _0x4578ff=new Date(Number(_0x172272));if(!isNaN(_0x4578ff['getTime']()))return _0x4578ff['toUTCString']();}catch{}}async function gf(_0x5a013c,_0x3706de=!0x1){const _0x37bd96=N(_0x5a013c),_0x3801e4=await _0x37bd96['getIdToken'](_0x3706de),_0x28e565=Ts(_0x3801e4);m(_0x28e565&&_0x28e565['exp']&&_0x28e565['auth_time']&&_0x28e565['iat'],_0x37bd96['auth'],'internal-error');const _0x3258c5=typeof _0x28e565['firebase']=='object'?_0x28e565['firebase']:void 0x0,_0x26f409=_0x3258c5==null?void 0x0:_0x3258c5['sign_in_provider'];return{'claims':_0x28e565,'token':_0x3801e4,'authTime':Rt(li(_0x28e565['auth_time'])),'issuedAtTime':Rt(li(_0x28e565['iat'])),'expirationTime':Rt(li(_0x28e565['exp'])),'signInProvider':_0x26f409||null,'signInSecondFactor':(_0x3258c5==null?void 0x0:_0x3258c5['sign_in_second_factor'])||null};}function li(_0x535796){return Number(_0x535796)*0x3e8;}function Ts(_0x2b9382){const [_0x2c09f0,_0x3e0fa0,_0x5077ce]=_0x2b9382['split']('.');if(_0x2c09f0===void 0x0||_0x3e0fa0===void 0x0||_0x5077ce===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x181a89=ln(_0x3e0fa0);return _0x181a89?JSON['parse'](_0x181a89):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x22cee1){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x22cee1==null?void 0x0:_0x22cee1['toString']()),null;}}function Cr(_0x5cbc4b){const _0x384470=Ts(_0x5cbc4b);return m(_0x384470,'internal-error'),m(typeof _0x384470['exp']<'u','internal-error'),m(typeof _0x384470['iat']<'u','internal-error'),Number(_0x384470['exp'])-Number(_0x384470['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x3cd85d,_0x2a5545,_0x4e02ae=!0x1){if(_0x4e02ae)return _0x2a5545;try{return await _0x2a5545;}catch(_0x480c57){throw _0x480c57 instanceof Se&&mf(_0x480c57)&&_0x3cd85d['auth']['currentUser']===_0x3cd85d&&await _0x3cd85d['auth']['signOut'](),_0x480c57;}}function mf({code:_0x3b4a39}){return _0x3b4a39==='auth/user-disabled'||_0x3b4a39==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x50b5e1){this['user']=_0x50b5e1,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x3a2887){if(_0x3a2887){const _0x47713c=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x47713c;}else{this['errorBackoff']=0x7530;const _0x47dff1=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x47dff1);}}['schedule'](_0x20b48c=!0x1){if(!this['isRunning'])return;const _0x15c0d9=this['getInterval'](_0x20b48c);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x15c0d9);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x412cef){(_0x412cef==null?void 0x0:_0x412cef['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x4231b2,_0x1cae0d){this['createdAt']=_0x4231b2,this['lastLoginAt']=_0x1cae0d,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x85dc2d){this['createdAt']=_0x85dc2d['createdAt'],this['lastLoginAt']=_0x85dc2d['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x1f2b2d){var _0x430d6c;const _0xaa3c4b=_0x1f2b2d['auth'],_0x2513b6=await _0x1f2b2d['getIdToken'](),_0x3a9828=await Ut(_0x1f2b2d,bn(_0xaa3c4b,{'idToken':_0x2513b6}));m(_0x3a9828==null?void 0x0:_0x3a9828['users']['length'],_0xaa3c4b,'internal-error');const _0x53dcc7=_0x3a9828['users'][0x0];_0x1f2b2d['_notifyReloadListener'](_0x53dcc7);const _0x41b586=(_0x430d6c=_0x53dcc7['providerUserInfo'])!=null&&_0x430d6c['length']?Sa(_0x53dcc7['providerUserInfo']):[],_0x462847=Ef(_0x1f2b2d['providerData'],_0x41b586),_0x25d23f=_0x1f2b2d['isAnonymous'],_0x3a7c4c=!(_0x1f2b2d['email']&&_0x53dcc7['passwordHash'])&&!(_0x462847!=null&&_0x462847['length']),_0x5d5059=_0x25d23f?_0x3a7c4c:!0x1,_0x554931={'uid':_0x53dcc7['localId'],'displayName':_0x53dcc7['displayName']||null,'photoURL':_0x53dcc7['photoUrl']||null,'email':_0x53dcc7['email']||null,'emailVerified':_0x53dcc7['emailVerified']||!0x1,'phoneNumber':_0x53dcc7['phoneNumber']||null,'tenantId':_0x53dcc7['tenantId']||null,'providerData':_0x462847,'metadata':new Oi(_0x53dcc7['createdAt'],_0x53dcc7['lastLoginAt']),'isAnonymous':_0x5d5059};Object['assign'](_0x1f2b2d,_0x554931);}async function vf(_0x5290cb){const _0x5d4ab6=N(_0x5290cb);await Rn(_0x5d4ab6),await _0x5d4ab6['auth']['_persistUserIfCurrent'](_0x5d4ab6),_0x5d4ab6['auth']['_notifyListenersIfCurrent'](_0x5d4ab6);}function Ef(_0xd3da5b,_0x1830d2){return[..._0xd3da5b['filter'](_0x48894f=>!_0x1830d2['some'](_0x27888e=>_0x27888e['providerId']===_0x48894f['providerId'])),..._0x1830d2];}function Sa(_0x30916c){return _0x30916c['map'](({providerId:_0x4f878e,..._0x9a1501})=>({'providerId':_0x4f878e,'uid':_0x9a1501['rawId']||'','displayName':_0x9a1501['displayName']||null,'email':_0x9a1501['email']||null,'phoneNumber':_0x9a1501['phoneNumber']||null,'photoURL':_0x9a1501['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x4332d6,_0x243167){const _0x340daf=await Ca(_0x4332d6,{},async()=>{const _0x15ea51=ct({'grant_type':'refresh_token','refresh_token':_0x243167})['slice'](0x1),{tokenApiHost:_0xfa2478,apiKey:_0x1b68cd}=_0x4332d6['config'],_0xcd3b79=await Ta(_0x4332d6,_0xfa2478,'/v1/token','key='+_0x1b68cd),_0x24f9b9=await _0x4332d6['_getAdditionalHeaders']();_0x24f9b9['Content-Type']='application/x-www-form-urlencoded';const _0x583263={'method':'POST','headers':_0x24f9b9,'body':_0x15ea51};return _0x4332d6['emulatorConfig']&&at(_0x4332d6['emulatorConfig']['host'])&&(_0x583263['credentials']='include'),wa['fetch']()(_0xcd3b79,_0x583263);});return{'accessToken':_0x340daf['access_token'],'expiresIn':_0x340daf['expires_in'],'refreshToken':_0x340daf['refresh_token']};}async function wf(_0x254f54,_0xaded49){return Ae(_0x254f54,'POST','/v2/accounts:revokeToken',Re(_0x254f54,_0xaded49));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x344669){m(_0x344669['idToken'],'internal-error'),m(typeof _0x344669['idToken']<'u','internal-error'),m(typeof _0x344669['refreshToken']<'u','internal-error');const _0x375c74='expiresIn'in _0x344669&&typeof _0x344669['expiresIn']<'u'?Number(_0x344669['expiresIn']):Cr(_0x344669['idToken']);this['updateTokensAndExpiration'](_0x344669['idToken'],_0x344669['refreshToken'],_0x375c74);}['updateFromIdToken'](_0x50eac0){m(_0x50eac0['length']!==0x0,'internal-error');const _0x1e6df4=Cr(_0x50eac0);this['updateTokensAndExpiration'](_0x50eac0,null,_0x1e6df4);}async['getToken'](_0x4e4b65,_0x54f307=!0x1){return!_0x54f307&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x4e4b65,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x4e4b65,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x1750b4,_0xa5b255){const {accessToken:_0xb509af,refreshToken:_0x143d12,expiresIn:_0x4090d3}=await If(_0x1750b4,_0xa5b255);this['updateTokensAndExpiration'](_0xb509af,_0x143d12,Number(_0x4090d3));}['updateTokensAndExpiration'](_0x4c7e0b,_0x19b7d3,_0x2ad171){this['refreshToken']=_0x19b7d3||null,this['accessToken']=_0x4c7e0b||null,this['expirationTime']=Date['now']()+_0x2ad171*0x3e8;}static['fromJSON'](_0xa0fc1d,_0x13ad7a){const {refreshToken:_0x33e2f6,accessToken:_0x2ebc9b,expirationTime:_0x14a666}=_0x13ad7a,_0x3ec0bb=new Qe();return _0x33e2f6&&(m(typeof _0x33e2f6=='string','internal-error',{'appName':_0xa0fc1d}),_0x3ec0bb['refreshToken']=_0x33e2f6),_0x2ebc9b&&(m(typeof _0x2ebc9b=='string','internal-error',{'appName':_0xa0fc1d}),_0x3ec0bb['accessToken']=_0x2ebc9b),_0x14a666&&(m(typeof _0x14a666=='number','internal-error',{'appName':_0xa0fc1d}),_0x3ec0bb['expirationTime']=_0x14a666),_0x3ec0bb;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x147e01){this['accessToken']=_0x147e01['accessToken'],this['refreshToken']=_0x147e01['refreshToken'],this['expirationTime']=_0x147e01['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x51b820,_0x42ba94){m(typeof _0x51b820=='string'||typeof _0x51b820>'u','internal-error',{'appName':_0x42ba94});}class K{constructor({uid:_0x4bd4c8,auth:_0x2307a,stsTokenManager:_0x50b03d,..._0x3973e5}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x4bd4c8,this['auth']=_0x2307a,this['stsTokenManager']=_0x50b03d,this['accessToken']=_0x50b03d['accessToken'],this['displayName']=_0x3973e5['displayName']||null,this['email']=_0x3973e5['email']||null,this['emailVerified']=_0x3973e5['emailVerified']||!0x1,this['phoneNumber']=_0x3973e5['phoneNumber']||null,this['photoURL']=_0x3973e5['photoURL']||null,this['isAnonymous']=_0x3973e5['isAnonymous']||!0x1,this['tenantId']=_0x3973e5['tenantId']||null,this['providerData']=_0x3973e5['providerData']?[..._0x3973e5['providerData']]:[],this['metadata']=new Oi(_0x3973e5['createdAt']||void 0x0,_0x3973e5['lastLoginAt']||void 0x0);}async['getIdToken'](_0x3bccab){const _0x4f08af=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x3bccab));return m(_0x4f08af,this['auth'],'internal-error'),this['accessToken']!==_0x4f08af&&(this['accessToken']=_0x4f08af,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x4f08af;}['getIdTokenResult'](_0x513194){return gf(this,_0x513194);}['reload'](){return vf(this);}['_assign'](_0x2273ae){this!==_0x2273ae&&(m(this['uid']===_0x2273ae['uid'],this['auth'],'internal-error'),this['displayName']=_0x2273ae['displayName'],this['photoURL']=_0x2273ae['photoURL'],this['email']=_0x2273ae['email'],this['emailVerified']=_0x2273ae['emailVerified'],this['phoneNumber']=_0x2273ae['phoneNumber'],this['isAnonymous']=_0x2273ae['isAnonymous'],this['tenantId']=_0x2273ae['tenantId'],this['providerData']=_0x2273ae['providerData']['map'](_0x1cbd73=>({..._0x1cbd73})),this['metadata']['_copy'](_0x2273ae['metadata']),this['stsTokenManager']['_assign'](_0x2273ae['stsTokenManager']));}['_clone'](_0x2271a7){const _0x3fe738=new K({...this,'auth':_0x2271a7,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x3fe738['metadata']['_copy'](this['metadata']),_0x3fe738;}['_onReload'](_0x34d73c){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x34d73c,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x332a91){this['reloadListener']?this['reloadListener'](_0x332a91):this['reloadUserInfo']=_0x332a91;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x2963c9,_0x270e3d=!0x1){let _0x44ce23=!0x1;_0x2963c9['idToken']&&_0x2963c9['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x2963c9),_0x44ce23=!0x0),_0x270e3d&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x44ce23&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0xecb06=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0xecb06})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x1c2f9c=>({..._0x1c2f9c})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x26155c,_0x5a4d41){const _0x49c1e1=_0x5a4d41['displayName']??void 0x0,_0x40f6e2=_0x5a4d41['email']??void 0x0,_0x15c749=_0x5a4d41['phoneNumber']??void 0x0,_0x582544=_0x5a4d41['photoURL']??void 0x0,_0x293b87=_0x5a4d41['tenantId']??void 0x0,_0xbba9cc=_0x5a4d41['_redirectEventId']??void 0x0,_0x16684b=_0x5a4d41['createdAt']??void 0x0,_0x1baa58=_0x5a4d41['lastLoginAt']??void 0x0,{uid:_0x3717de,emailVerified:_0x5c5653,isAnonymous:_0xbcceef,providerData:_0x9d104a,stsTokenManager:_0x104c59}=_0x5a4d41;m(_0x3717de&&_0x104c59,_0x26155c,'internal-error');const _0x436cc7=Qe['fromJSON'](this['name'],_0x104c59);m(typeof _0x3717de=='string',_0x26155c,'internal-error'),le(_0x49c1e1,_0x26155c['name']),le(_0x40f6e2,_0x26155c['name']),m(typeof _0x5c5653=='boolean',_0x26155c,'internal-error'),m(typeof _0xbcceef=='boolean',_0x26155c,'internal-error'),le(_0x15c749,_0x26155c['name']),le(_0x582544,_0x26155c['name']),le(_0x293b87,_0x26155c['name']),le(_0xbba9cc,_0x26155c['name']),le(_0x16684b,_0x26155c['name']),le(_0x1baa58,_0x26155c['name']);const _0x50b6a7=new K({'uid':_0x3717de,'auth':_0x26155c,'email':_0x40f6e2,'emailVerified':_0x5c5653,'displayName':_0x49c1e1,'isAnonymous':_0xbcceef,'photoURL':_0x582544,'phoneNumber':_0x15c749,'tenantId':_0x293b87,'stsTokenManager':_0x436cc7,'createdAt':_0x16684b,'lastLoginAt':_0x1baa58});return _0x9d104a&&Array['isArray'](_0x9d104a)&&(_0x50b6a7['providerData']=_0x9d104a['map'](_0x300e2e=>({..._0x300e2e}))),_0xbba9cc&&(_0x50b6a7['_redirectEventId']=_0xbba9cc),_0x50b6a7;}static async['_fromIdTokenResponse'](_0x3c5585,_0x45e84d,_0x95db09=!0x1){const _0x2254fd=new Qe();_0x2254fd['updateFromServerResponse'](_0x45e84d);const _0x2bc5ed=new K({'uid':_0x45e84d['localId'],'auth':_0x3c5585,'stsTokenManager':_0x2254fd,'isAnonymous':_0x95db09});return await Rn(_0x2bc5ed),_0x2bc5ed;}static async['_fromGetAccountInfoResponse'](_0x303fd9,_0x4a0346,_0x12afd3){const _0x4e8c16=_0x4a0346['users'][0x0];m(_0x4e8c16['localId']!==void 0x0,'internal-error');const _0x35e59e=_0x4e8c16['providerUserInfo']!==void 0x0?Sa(_0x4e8c16['providerUserInfo']):[],_0x2cdf1b=!(_0x4e8c16['email']&&_0x4e8c16['passwordHash'])&&!(_0x35e59e!=null&&_0x35e59e['length']),_0x25bfff=new Qe();_0x25bfff['updateFromIdToken'](_0x12afd3);const _0x7958ee=new K({'uid':_0x4e8c16['localId'],'auth':_0x303fd9,'stsTokenManager':_0x25bfff,'isAnonymous':_0x2cdf1b}),_0x372607={'uid':_0x4e8c16['localId'],'displayName':_0x4e8c16['displayName']||null,'photoURL':_0x4e8c16['photoUrl']||null,'email':_0x4e8c16['email']||null,'emailVerified':_0x4e8c16['emailVerified']||!0x1,'phoneNumber':_0x4e8c16['phoneNumber']||null,'tenantId':_0x4e8c16['tenantId']||null,'providerData':_0x35e59e,'metadata':new Oi(_0x4e8c16['createdAt'],_0x4e8c16['lastLoginAt']),'isAnonymous':!(_0x4e8c16['email']&&_0x4e8c16['passwordHash'])&&!(_0x35e59e!=null&&_0x35e59e['length'])};return Object['assign'](_0x7958ee,_0x372607),_0x7958ee;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x456480){ce(_0x456480 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x33ef42=Tr['get'](_0x456480);return _0x33ef42?(ce(_0x33ef42 instanceof _0x456480,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x33ef42):(_0x33ef42=new _0x456480(),Tr['set'](_0x456480,_0x33ef42),_0x33ef42);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x2757d6,_0x35c322){this['storage'][_0x2757d6]=_0x35c322;}async['_get'](_0x1f9a29){const _0x24bb1b=this['storage'][_0x1f9a29];return _0x24bb1b===void 0x0?null:_0x24bb1b;}async['_remove'](_0x59fbdb){delete this['storage'][_0x59fbdb];}['_addListener'](_0x332996,_0x46129f){}['_removeListener'](_0x547446,_0x553913){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x563e98,_0xf5390e,_0x436d9a){return'firebase:'+_0x563e98+':'+_0xf5390e+':'+_0x436d9a;}class Je{constructor(_0x3d381a,_0x47605c,_0x1fa564){this['persistence']=_0x3d381a,this['auth']=_0x47605c,this['userKey']=_0x1fa564;const {config:_0x2e32a6,name:_0x35b431}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x2e32a6['apiKey'],_0x35b431),this['fullPersistenceKey']=rn('persistence',_0x2e32a6['apiKey'],_0x35b431),this['boundEventHandler']=_0x47605c['_onStorageEvent']['bind'](_0x47605c),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x1827b9){return this['persistence']['_set'](this['fullUserKey'],_0x1827b9['toJSON']());}async['getCurrentUser'](){const _0x192639=await this['persistence']['_get'](this['fullUserKey']);if(!_0x192639)return null;if(typeof _0x192639=='string'){const _0x3ed8fa=await bn(this['auth'],{'idToken':_0x192639})['catch'](()=>{});return _0x3ed8fa?K['_fromGetAccountInfoResponse'](this['auth'],_0x3ed8fa,_0x192639):null;}return K['_fromJSON'](this['auth'],_0x192639);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x5c76de){if(this['persistence']===_0x5c76de)return;const _0x5419bd=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x5c76de,_0x5419bd)return this['setCurrentUser'](_0x5419bd);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x3ff480,_0xb548f0,_0x4c0cb5='authUser'){if(!_0xb548f0['length'])return new Je(ie(Sr),_0x3ff480,_0x4c0cb5);const _0x4e0bf4=(await Promise['all'](_0xb548f0['map'](async _0x5047fa=>{if(await _0x5047fa['_isAvailable']())return _0x5047fa;})))['filter'](_0x49eef2=>_0x49eef2);let _0x40b7e8=_0x4e0bf4[0x0]||ie(Sr);const _0x387911=rn(_0x4c0cb5,_0x3ff480['config']['apiKey'],_0x3ff480['name']);let _0x4c6cad=null;for(const _0x604602 of _0xb548f0)try{const _0x4e5870=await _0x604602['_get'](_0x387911);if(_0x4e5870){let _0x4c975a;if(typeof _0x4e5870=='string'){const _0x1e536a=await bn(_0x3ff480,{'idToken':_0x4e5870})['catch'](()=>{});if(!_0x1e536a)break;_0x4c975a=await K['_fromGetAccountInfoResponse'](_0x3ff480,_0x1e536a,_0x4e5870);}else _0x4c975a=K['_fromJSON'](_0x3ff480,_0x4e5870);_0x604602!==_0x40b7e8&&(_0x4c6cad=_0x4c975a),_0x40b7e8=_0x604602;break;}}catch{}const _0x5f8d47=_0x4e0bf4['filter'](_0xe77c81=>_0xe77c81['_shouldAllowMigration']);return!_0x40b7e8['_shouldAllowMigration']||!_0x5f8d47['length']?new Je(_0x40b7e8,_0x3ff480,_0x4c0cb5):(_0x40b7e8=_0x5f8d47[0x0],_0x4c6cad&&await _0x40b7e8['_set'](_0x387911,_0x4c6cad['toJSON']()),await Promise['all'](_0xb548f0['map'](async _0x3c58f0=>{if(_0x3c58f0!==_0x40b7e8)try{await _0x3c58f0['_remove'](_0x387911);}catch{}})),new Je(_0x40b7e8,_0x3ff480,_0x4c0cb5));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x1cd9aa){const _0x103755=_0x1cd9aa['toLowerCase']();if(_0x103755['includes']('opera/')||_0x103755['includes']('opr/')||_0x103755['includes']('opios/'))return'Opera';if(Na(_0x103755))return'IEMobile';if(_0x103755['includes']('msie')||_0x103755['includes']('trident/'))return'IE';if(_0x103755['includes']('edge/'))return'Edge';if(Ra(_0x103755))return'Firefox';if(_0x103755['includes']('silk/'))return'Silk';if(Oa(_0x103755))return'Blackberry';if(Da(_0x103755))return'Webos';if(Aa(_0x103755))return'Safari';if((_0x103755['includes']('chrome/')||ka(_0x103755))&&!_0x103755['includes']('edge/'))return'Chrome';if(Pa(_0x103755))return'Android';{const _0x32c503=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0xa08073=_0x1cd9aa['match'](_0x32c503);if((_0xa08073==null?void 0x0:_0xa08073['length'])===0x2)return _0xa08073[0x1];}return'Other';}function Ra(_0x19e221=W()){return/firefox\//i['test'](_0x19e221);}function Aa(_0xac4343=W()){const _0x3fe518=_0xac4343['toLowerCase']();return _0x3fe518['includes']('safari/')&&!_0x3fe518['includes']('chrome/')&&!_0x3fe518['includes']('crios/')&&!_0x3fe518['includes']('android');}function ka(_0x5b31ca=W()){return/crios\//i['test'](_0x5b31ca);}function Na(_0x36fde5=W()){return/iemobile/i['test'](_0x36fde5);}function Pa(_0x108bf3=W()){return/android/i['test'](_0x108bf3);}function Oa(_0x49f35a=W()){return/blackberry/i['test'](_0x49f35a);}function Da(_0x18dfe2=W()){return/webos/i['test'](_0x18dfe2);}function Ss(_0x576269=W()){return/iphone|ipad|ipod/i['test'](_0x576269)||/macintosh/i['test'](_0x576269)&&/mobile/i['test'](_0x576269);}function Cf(_0x3e93c0=W()){var _0xf7def3;return Ss(_0x3e93c0)&&!!((_0xf7def3=window['navigator'])!=null&&_0xf7def3['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x366f19=W()){return Ss(_0x366f19)||Pa(_0x366f19)||Da(_0x366f19)||Oa(_0x366f19)||/windows phone/i['test'](_0x366f19)||Na(_0x366f19);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x31fe9c,_0x35297e=[]){let _0x307e99;switch(_0x31fe9c){case'Browser':_0x307e99=br(W());break;case'Worker':_0x307e99=br(W())+'-'+_0x31fe9c;break;default:_0x307e99=_0x31fe9c;}const _0x30c03c=_0x35297e['length']?_0x35297e['join'](','):'FirebaseCore-web';return _0x307e99+'/JsCore/'+lt+'/'+_0x30c03c;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x2a9852){this['auth']=_0x2a9852,this['queue']=[];}['pushCallback'](_0x28813c,_0x5eaf44){const _0x2f95db=_0x83b457=>new Promise((_0x492ad9,_0x5476e7)=>{try{const _0x157625=_0x28813c(_0x83b457);_0x492ad9(_0x157625);}catch(_0x3ffcb3){_0x5476e7(_0x3ffcb3);}});_0x2f95db['onAbort']=_0x5eaf44,this['queue']['push'](_0x2f95db);const _0x16e582=this['queue']['length']-0x1;return()=>{this['queue'][_0x16e582]=()=>Promise['resolve']();};}async['runMiddleware'](_0xa83c88){if(this['auth']['currentUser']===_0xa83c88)return;const _0x303266=[];try{for(const _0x34cf6f of this['queue'])await _0x34cf6f(_0xa83c88),_0x34cf6f['onAbort']&&_0x303266['push'](_0x34cf6f['onAbort']);}catch(_0x6cd515){_0x303266['reverse']();for(const _0x5a99cd of _0x303266)try{_0x5a99cd();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x6cd515==null?void 0x0:_0x6cd515['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x259b57,_0x329314={}){return Ae(_0x259b57,'GET','/v2/passwordPolicy',Re(_0x259b57,_0x329314));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x155843){var _0xf2cd1b;const _0x42ed99=_0x155843['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x42ed99['minPasswordLength']??Rf,_0x42ed99['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x42ed99['maxPasswordLength']),_0x42ed99['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x42ed99['containsLowercaseCharacter']),_0x42ed99['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x42ed99['containsUppercaseCharacter']),_0x42ed99['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x42ed99['containsNumericCharacter']),_0x42ed99['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x42ed99['containsNonAlphanumericCharacter']),this['enforcementState']=_0x155843['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0xf2cd1b=_0x155843['allowedNonAlphanumericCharacters'])==null?void 0x0:_0xf2cd1b['join'](''))??'',this['forceUpgradeOnSignin']=_0x155843['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x155843['schemaVersion'];}['validatePassword'](_0x2ff519){const _0x236517={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x2ff519,_0x236517),this['validatePasswordCharacterOptions'](_0x2ff519,_0x236517),_0x236517['isValid']&&(_0x236517['isValid']=_0x236517['meetsMinPasswordLength']??!0x0),_0x236517['isValid']&&(_0x236517['isValid']=_0x236517['meetsMaxPasswordLength']??!0x0),_0x236517['isValid']&&(_0x236517['isValid']=_0x236517['containsLowercaseLetter']??!0x0),_0x236517['isValid']&&(_0x236517['isValid']=_0x236517['containsUppercaseLetter']??!0x0),_0x236517['isValid']&&(_0x236517['isValid']=_0x236517['containsNumericCharacter']??!0x0),_0x236517['isValid']&&(_0x236517['isValid']=_0x236517['containsNonAlphanumericCharacter']??!0x0),_0x236517;}['validatePasswordLengthOptions'](_0x25c4bd,_0x18f2a9){const _0x4b12db=this['customStrengthOptions']['minPasswordLength'],_0x1b444f=this['customStrengthOptions']['maxPasswordLength'];_0x4b12db&&(_0x18f2a9['meetsMinPasswordLength']=_0x25c4bd['length']>=_0x4b12db),_0x1b444f&&(_0x18f2a9['meetsMaxPasswordLength']=_0x25c4bd['length']<=_0x1b444f);}['validatePasswordCharacterOptions'](_0x5c9782,_0x837245){this['updatePasswordCharacterOptionsStatuses'](_0x837245,!0x1,!0x1,!0x1,!0x1);let _0x2a667c;for(let _0x27327d=0x0;_0x27327d<_0x5c9782['length'];_0x27327d++)_0x2a667c=_0x5c9782['charAt'](_0x27327d),this['updatePasswordCharacterOptionsStatuses'](_0x837245,_0x2a667c>='a'&&_0x2a667c<='z',_0x2a667c>='A'&&_0x2a667c<='Z',_0x2a667c>='0'&&_0x2a667c<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x2a667c));}['updatePasswordCharacterOptionsStatuses'](_0xd8296d,_0xf451c1,_0x5e2010,_0x369324,_0x3f60f9){this['customStrengthOptions']['containsLowercaseLetter']&&(_0xd8296d['containsLowercaseLetter']||(_0xd8296d['containsLowercaseLetter']=_0xf451c1)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0xd8296d['containsUppercaseLetter']||(_0xd8296d['containsUppercaseLetter']=_0x5e2010)),this['customStrengthOptions']['containsNumericCharacter']&&(_0xd8296d['containsNumericCharacter']||(_0xd8296d['containsNumericCharacter']=_0x369324)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0xd8296d['containsNonAlphanumericCharacter']||(_0xd8296d['containsNonAlphanumericCharacter']=_0x3f60f9));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x11ed9b,_0x18b623,_0x5e6737,_0x22ee2a){this['app']=_0x11ed9b,this['heartbeatServiceProvider']=_0x18b623,this['appCheckServiceProvider']=_0x5e6737,this['config']=_0x22ee2a,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x11ed9b['name'],this['clientVersion']=_0x22ee2a['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x8f4ca5=>this['_resolvePersistenceManagerAvailable']=_0x8f4ca5);}['_initializeWithPersistence'](_0x49d0af,_0x18aa31){return _0x18aa31&&(this['_popupRedirectResolver']=ie(_0x18aa31)),this['_initializationPromise']=this['queue'](async()=>{var _0x4cb78a,_0x37117b,_0x2af92d;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x49d0af),(_0x4cb78a=this['_resolvePersistenceManagerAvailable'])==null||_0x4cb78a['call'](this),!this['_deleted'])){if((_0x37117b=this['_popupRedirectResolver'])!=null&&_0x37117b['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x18aa31),this['lastNotifiedUid']=((_0x2af92d=this['currentUser'])==null?void 0x0:_0x2af92d['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x2118c3=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x2118c3)){if(this['currentUser']&&_0x2118c3&&this['currentUser']['uid']===_0x2118c3['uid']){this['_currentUser']['_assign'](_0x2118c3),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x2118c3,!0x0);}}async['initializeCurrentUserFromIdToken'](_0xb278e1){try{const _0x506cf2=await bn(this,{'idToken':_0xb278e1}),_0x1b0ac2=await K['_fromGetAccountInfoResponse'](this,_0x506cf2,_0xb278e1);await this['directlySetCurrentUser'](_0x1b0ac2);}catch(_0xa80bf2){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0xa80bf2),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x28565d){var _0x43c621;if($(this['app'])){const _0x5624a0=this['app']['settings']['authIdToken'];return _0x5624a0?new Promise(_0x499628=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x5624a0)['then'](_0x499628,_0x499628));}):this['directlySetCurrentUser'](null);}const _0x234f23=await this['assertedPersistence']['getCurrentUser']();let _0x105aa5=_0x234f23,_0x2a561d=!0x1;if(_0x28565d&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x443de5=(_0x43c621=this['redirectUser'])==null?void 0x0:_0x43c621['_redirectEventId'],_0x5030a7=_0x105aa5==null?void 0x0:_0x105aa5['_redirectEventId'],_0x3288e4=await this['tryRedirectSignIn'](_0x28565d);(!_0x443de5||_0x443de5===_0x5030a7)&&(_0x3288e4!=null&&_0x3288e4['user'])&&(_0x105aa5=_0x3288e4['user'],_0x2a561d=!0x0);}if(!_0x105aa5)return this['directlySetCurrentUser'](null);if(!_0x105aa5['_redirectEventId']){if(_0x2a561d)try{await this['beforeStateQueue']['runMiddleware'](_0x105aa5);}catch(_0x1f8b61){_0x105aa5=_0x234f23,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x1f8b61));}return _0x105aa5?this['reloadAndSetCurrentUserOrClear'](_0x105aa5):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x105aa5['_redirectEventId']?this['directlySetCurrentUser'](_0x105aa5):this['reloadAndSetCurrentUserOrClear'](_0x105aa5);}async['tryRedirectSignIn'](_0x11d7de){let _0x11e7da=null;try{_0x11e7da=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x11d7de,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x11e7da;}async['reloadAndSetCurrentUserOrClear'](_0x136860){try{await Rn(_0x136860);}catch(_0x7b08d5){if((_0x7b08d5==null?void 0x0:_0x7b08d5['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x136860);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x49f79b){if($(this['app']))return Promise['reject'](re(this));const _0x2f4315=_0x49f79b?N(_0x49f79b):null;return _0x2f4315&&m(_0x2f4315['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x2f4315&&_0x2f4315['_clone'](this));}async['_updateCurrentUser'](_0xb49441,_0x25fe80=!0x1){if(!this['_deleted'])return _0xb49441&&m(this['tenantId']===_0xb49441['tenantId'],this,'tenant-id-mismatch'),_0x25fe80||await this['beforeStateQueue']['runMiddleware'](_0xb49441),this['queue'](async()=>{await this['directlySetCurrentUser'](_0xb49441),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x21103c){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x21103c));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x18abb1){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x4dba0d=this['_getPasswordPolicyInternal']();return _0x4dba0d['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x4dba0d['validatePassword'](_0x18abb1);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x54de47=await bf(this),_0x5ce6f0=new Af(_0x54de47);this['tenantId']===null?this['_projectPasswordPolicy']=_0x5ce6f0:this['_tenantPasswordPolicies'][this['tenantId']]=_0x5ce6f0;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x7e4144){this['_errorFactory']=new Bt('auth','Firebase',_0x7e4144());}['onAuthStateChanged'](_0xfe62e9,_0x3601c4,_0x5b003d){return this['registerStateListener'](this['authStateSubscription'],_0xfe62e9,_0x3601c4,_0x5b003d);}['beforeAuthStateChanged'](_0x451a9b,_0x3d33ed){return this['beforeStateQueue']['pushCallback'](_0x451a9b,_0x3d33ed);}['onIdTokenChanged'](_0x548956,_0x44491d,_0x569391){return this['registerStateListener'](this['idTokenSubscription'],_0x548956,_0x44491d,_0x569391);}['authStateReady'](){return new Promise((_0x2f18a8,_0x278b6a)=>{if(this['currentUser'])_0x2f18a8();else{const _0x435437=this['onAuthStateChanged'](()=>{_0x435437(),_0x2f18a8();},_0x278b6a);}});}async['revokeAccessToken'](_0x598c1e){if(this['currentUser']){const _0x46affa=await this['currentUser']['getIdToken'](),_0x2ab21e={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x598c1e,'idToken':_0x46affa};this['tenantId']!=null&&(_0x2ab21e['tenantId']=this['tenantId']),await wf(this,_0x2ab21e);}}['toJSON'](){var _0x3a3c91;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x3a3c91=this['_currentUser'])==null?void 0x0:_0x3a3c91['toJSON']()};}async['_setRedirectUser'](_0x4443ae,_0x3c7046){const _0x3ee788=await this['getOrInitRedirectPersistenceManager'](_0x3c7046);return _0x4443ae===null?_0x3ee788['removeCurrentUser']():_0x3ee788['setCurrentUser'](_0x4443ae);}async['getOrInitRedirectPersistenceManager'](_0x3d2dd9){if(!this['redirectPersistenceManager']){const _0x159951=_0x3d2dd9&&ie(_0x3d2dd9)||this['_popupRedirectResolver'];m(_0x159951,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x159951['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x3766fe){var _0x474429,_0xc11977;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x474429=this['_currentUser'])==null?void 0x0:_0x474429['_redirectEventId'])===_0x3766fe?this['_currentUser']:((_0xc11977=this['redirectUser'])==null?void 0x0:_0xc11977['_redirectEventId'])===_0x3766fe?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x3b12cf){if(_0x3b12cf===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x3b12cf));}['_notifyListenersIfCurrent'](_0x44d0cd){_0x44d0cd===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x58fb3a;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x202cb5=((_0x58fb3a=this['currentUser'])==null?void 0x0:_0x58fb3a['uid'])??null;this['lastNotifiedUid']!==_0x202cb5&&(this['lastNotifiedUid']=_0x202cb5,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x192877,_0x499014,_0x13175f,_0x5bb327){if(this['_deleted'])return()=>{};const _0x58f3aa=typeof _0x499014=='function'?_0x499014:_0x499014['next']['bind'](_0x499014);let _0x44dd16=!0x1;const _0x5d74af=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x5d74af,this,'internal-error'),_0x5d74af['then'](()=>{_0x44dd16||_0x58f3aa(this['currentUser']);}),typeof _0x499014=='function'){const _0x39fe8f=_0x192877['addObserver'](_0x499014,_0x13175f,_0x5bb327);return()=>{_0x44dd16=!0x0,_0x39fe8f();};}else{const _0x1ea460=_0x192877['addObserver'](_0x499014);return()=>{_0x44dd16=!0x0,_0x1ea460();};}}async['directlySetCurrentUser'](_0x1f172b){this['currentUser']&&this['currentUser']!==_0x1f172b&&this['_currentUser']['_stopProactiveRefresh'](),_0x1f172b&&this['isProactiveRefreshEnabled']&&_0x1f172b['_startProactiveRefresh'](),this['currentUser']=_0x1f172b,_0x1f172b?await this['assertedPersistence']['setCurrentUser'](_0x1f172b):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x1eb78e){return this['operations']=this['operations']['then'](_0x1eb78e,_0x1eb78e),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x33e830){!_0x33e830||this['frameworks']['includes'](_0x33e830)||(this['frameworks']['push'](_0x33e830),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x40615e;const _0x509e22={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x509e22['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x1f091f=await((_0x40615e=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x40615e['getHeartbeatsHeader']());_0x1f091f&&(_0x509e22['X-Firebase-Client']=_0x1f091f);const _0x2cf341=await this['_getAppCheckToken']();return _0x2cf341&&(_0x509e22['X-Firebase-AppCheck']=_0x2cf341),_0x509e22;}async['_getAppCheckToken'](){var _0x58df2a;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x2f2692=await((_0x58df2a=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x58df2a['getToken']());return _0x2f2692!=null&&_0x2f2692['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x2f2692['error']),_0x2f2692==null?void 0x0:_0x2f2692['token'];}}function qe(_0x4a5308){return N(_0x4a5308);}class Rr{constructor(_0x5929e8){this['auth']=_0x5929e8,this['observer']=null,this['addObserver']=Tc(_0xe67e48=>this['observer']=_0xe67e48);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x43fb58){jn=_0x43fb58;}function xa(_0x3aa526){return jn['loadJS'](_0x3aa526);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x542856){return'__'+_0x542856+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x54755b){_0x54755b();}['execute'](_0x48a587,_0x381ed7){return Promise['resolve']('token');}['render'](_0x30a25c,_0x3a5723){return'';}}class Lf{['ready'](_0x676378){_0x676378();}['execute'](_0x47011e,_0x5ba86b){return Promise['resolve']('token');}['render'](_0x3bef7b,_0x3f1df0){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x63695f){this['type']=xf,this['auth']=qe(_0x63695f);}async['verify'](_0x567d3e='verify',_0x4e1aff=!0x1){async function _0x4a0da7(_0x16ef3d){if(!_0x4e1aff){if(_0x16ef3d['tenantId']==null&&_0x16ef3d['_agentRecaptchaConfig']!=null)return _0x16ef3d['_agentRecaptchaConfig']['siteKey'];if(_0x16ef3d['tenantId']!=null&&_0x16ef3d['_tenantRecaptchaConfigs'][_0x16ef3d['tenantId']]!==void 0x0)return _0x16ef3d['_tenantRecaptchaConfigs'][_0x16ef3d['tenantId']]['siteKey'];}return new Promise(async(_0x20da7c,_0xb5a794)=>{pf(_0x16ef3d,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x264d44=>{if(_0x264d44['recaptchaKey']===void 0x0)_0xb5a794(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x57e7f2=new ff(_0x264d44);return _0x16ef3d['tenantId']==null?_0x16ef3d['_agentRecaptchaConfig']=_0x57e7f2:_0x16ef3d['_tenantRecaptchaConfigs'][_0x16ef3d['tenantId']]=_0x57e7f2,_0x20da7c(_0x57e7f2['siteKey']);}})['catch'](_0x338ff2=>{_0xb5a794(_0x338ff2);});});}function _0x46c622(_0x369a86,_0x175eb0,_0x3d743a){const _0x4cfda5=window['grecaptcha'];wr(_0x4cfda5)?_0x4cfda5['enterprise']['ready'](()=>{_0x4cfda5['enterprise']['execute'](_0x369a86,{'action':_0x567d3e})['then'](_0x2b08c4=>{_0x175eb0(_0x2b08c4);})['catch'](()=>{_0x175eb0(Fa);});}):_0x3d743a(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x5718f9,_0xb1d1a7)=>{_0x4a0da7(this['auth'])['then'](_0x436b81=>{if(!_0x4e1aff&&wr(window['grecaptcha']))_0x46c622(_0x436b81,_0x5718f9,_0xb1d1a7);else{if(typeof window>'u'){_0xb1d1a7(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x174d48=Pf();_0x174d48['length']!==0x0&&(_0x174d48+=_0x436b81),xa(_0x174d48)['then'](()=>{_0x46c622(_0x436b81,_0x5718f9,_0xb1d1a7);})['catch'](_0x2ceb12=>{_0xb1d1a7(_0x2ceb12);});}})['catch'](_0x26023f=>{_0xb1d1a7(_0x26023f);});});}}async function Ar(_0xa4b348,_0x33bd44,_0x29419a,_0x2dd924=!0x1,_0x1bae0e=!0x1){const _0x294a47=new Ff(_0xa4b348);let _0x4607ec;if(_0x1bae0e)_0x4607ec=Fa;else try{_0x4607ec=await _0x294a47['verify'](_0x29419a);}catch{_0x4607ec=await _0x294a47['verify'](_0x29419a,!0x0);}const _0x70160d={..._0x33bd44};if(_0x29419a==='mfaSmsEnrollment'||_0x29419a==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x70160d){const _0x12d68d=_0x70160d['phoneEnrollmentInfo']['phoneNumber'],_0x3d301a=_0x70160d['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x70160d,{'phoneEnrollmentInfo':{'phoneNumber':_0x12d68d,'recaptchaToken':_0x3d301a,'captchaResponse':_0x4607ec,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x70160d){const _0xbfa01e=_0x70160d['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x70160d,{'phoneSignInInfo':{'recaptchaToken':_0xbfa01e,'captchaResponse':_0x4607ec,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x70160d;}return _0x2dd924?Object['assign'](_0x70160d,{'captchaResp':_0x4607ec}):Object['assign'](_0x70160d,{'captchaResponse':_0x4607ec}),Object['assign'](_0x70160d,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x70160d,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x70160d;}async function Di(_0x2e8f95,_0x13bd0d,_0x1f62a4,_0x5f335d,_0x567d00){var _0x5b70fc;if((_0x5b70fc=_0x2e8f95['_getRecaptchaConfig']())!=null&&_0x5b70fc['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x548ca9=await Ar(_0x2e8f95,_0x13bd0d,_0x1f62a4,_0x1f62a4==='getOobCode');return _0x5f335d(_0x2e8f95,_0x548ca9);}else return _0x5f335d(_0x2e8f95,_0x13bd0d)['catch'](async _0x66172e=>{if(_0x66172e['code']==='auth/missing-recaptcha-token'){console['log'](_0x1f62a4+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x520e2e=await Ar(_0x2e8f95,_0x13bd0d,_0x1f62a4,_0x1f62a4==='getOobCode');return _0x5f335d(_0x2e8f95,_0x520e2e);}else return Promise['reject'](_0x66172e);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x87290f,_0x2c57f4){const _0x37529b=Bi(_0x87290f,'auth');if(_0x37529b['isInitialized']()){const _0x268fe3=_0x37529b['getImmediate'](),_0x305093=_0x37529b['getOptions']();if(Me(_0x305093,_0x2c57f4??{}))return _0x268fe3;Q(_0x268fe3,'already-initialized');}return _0x37529b['initialize']({'options':_0x2c57f4});}function Wf(_0x1148f0,_0x7fd237){const _0x54344f=(_0x7fd237==null?void 0x0:_0x7fd237['persistence'])||[],_0x7d0963=(Array['isArray'](_0x54344f)?_0x54344f:[_0x54344f])['map'](ie);_0x7fd237!=null&&_0x7fd237['errorMap']&&_0x1148f0['_updateErrorMap'](_0x7fd237['errorMap']),_0x1148f0['_initializeWithPersistence'](_0x7d0963,_0x7fd237==null?void 0x0:_0x7fd237['popupRedirectResolver']);}function Bf(_0x2ec589,_0x2fff5b,_0x453fcd){const _0xff013c=qe(_0x2ec589);m(/^https?:\/\//['test'](_0x2fff5b),_0xff013c,'invalid-emulator-scheme');const _0x3cb945=!0x1,_0x34e14a=Ua(_0x2fff5b),{host:_0x3a0003,port:_0x4265c1}=Vf(_0x2fff5b),_0x367ac9=_0x4265c1===null?'':':'+_0x4265c1,_0x1eaaf0={'url':_0x34e14a+'//'+_0x3a0003+_0x367ac9+'/'},_0x3a0736=Object['freeze']({'host':_0x3a0003,'port':_0x4265c1,'protocol':_0x34e14a['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x3cb945})});if(!_0xff013c['_canInitEmulator']){m(_0xff013c['config']['emulator']&&_0xff013c['emulatorConfig'],_0xff013c,'emulator-config-failed'),m(Me(_0x1eaaf0,_0xff013c['config']['emulator'])&&Me(_0x3a0736,_0xff013c['emulatorConfig']),_0xff013c,'emulator-config-failed');return;}_0xff013c['config']['emulator']=_0x1eaaf0,_0xff013c['emulatorConfig']=_0x3a0736,_0xff013c['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x3a0003)?(jr(_0x34e14a+'//'+_0x3a0003+_0x367ac9),Kr('Auth',!0x0)):Hf();}function Ua(_0x37614a){const _0x20dab=_0x37614a['indexOf'](':');return _0x20dab<0x0?'':_0x37614a['substr'](0x0,_0x20dab+0x1);}function Vf(_0x25c390){const _0x2783d5=Ua(_0x25c390),_0x367af5=/(\/\/)?([^?#/]+)/['exec'](_0x25c390['substr'](_0x2783d5['length']));if(!_0x367af5)return{'host':'','port':null};const _0x1c39b0=_0x367af5[0x2]['split']('@')['pop']()||'',_0x4f7424=/^(\[[^\]]+\])(:|$)/['exec'](_0x1c39b0);if(_0x4f7424){const _0x4531ab=_0x4f7424[0x1];return{'host':_0x4531ab,'port':kr(_0x1c39b0['substr'](_0x4531ab['length']+0x1))};}else{const [_0x34b4eb,_0x2ab8ec]=_0x1c39b0['split'](':');return{'host':_0x34b4eb,'port':kr(_0x2ab8ec)};}}function kr(_0x367ef7){if(!_0x367ef7)return null;const _0x7e3fb4=Number(_0x367ef7);return isNaN(_0x7e3fb4)?null:_0x7e3fb4;}function Hf(){function _0x3dc46f(){const _0x1b99f1=document['createElement']('p'),_0x414a4e=_0x1b99f1['style'];_0x1b99f1['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x414a4e['position']='fixed',_0x414a4e['width']='100%',_0x414a4e['backgroundColor']='#ffffff',_0x414a4e['border']='.1em\x20solid\x20#000000',_0x414a4e['color']='#b50000',_0x414a4e['bottom']='0px',_0x414a4e['left']='0px',_0x414a4e['margin']='0px',_0x414a4e['zIndex']='10000',_0x414a4e['textAlign']='center',_0x1b99f1['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x1b99f1);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x3dc46f):_0x3dc46f());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0xe34205,_0x302352){this['providerId']=_0xe34205,this['signInMethod']=_0x302352;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x37a6fc){return ne('not\x20implemented');}['_linkToIdToken'](_0x5e4a88,_0x280ffb){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0xbac4c1){return ne('not\x20implemented');}}async function $f(_0x522f32,_0x241489){return Ae(_0x522f32,'POST','/v1/accounts:signUp',_0x241489);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x37ce1e,_0x9b4ad8){return Qt(_0x37ce1e,'POST','/v1/accounts:signInWithPassword',Re(_0x37ce1e,_0x9b4ad8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x48f0c2,_0x18f133){return Qt(_0x48f0c2,'POST','/v1/accounts:signInWithEmailLink',Re(_0x48f0c2,_0x18f133));}async function zf(_0x1c7c73,_0x5cb9b4){return Qt(_0x1c7c73,'POST','/v1/accounts:signInWithEmailLink',Re(_0x1c7c73,_0x5cb9b4));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x326627,_0x48f60e,_0x5be874,_0x4d31f1=null){super('password',_0x5be874),this['_email']=_0x326627,this['_password']=_0x48f60e,this['_tenantId']=_0x4d31f1;}static['_fromEmailAndPassword'](_0x57aeca,_0x109b69){return new Wt(_0x57aeca,_0x109b69,'password');}static['_fromEmailAndCode'](_0x39da18,_0x4d50a9,_0x356442=null){return new Wt(_0x39da18,_0x4d50a9,'emailLink',_0x356442);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x59b5ed){const _0x567bff=typeof _0x59b5ed=='string'?JSON['parse'](_0x59b5ed):_0x59b5ed;if(_0x567bff!=null&&_0x567bff['email']&&(_0x567bff!=null&&_0x567bff['password'])){if(_0x567bff['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x567bff['email'],_0x567bff['password']);if(_0x567bff['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x567bff['email'],_0x567bff['password'],_0x567bff['tenantId']);}return null;}async['_getIdTokenResponse'](_0x1cd89c){switch(this['signInMethod']){case'password':const _0x4c0faf={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x1cd89c,_0x4c0faf,'signInWithPassword',Gf);case'emailLink':return qf(_0x1cd89c,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x1cd89c,'internal-error');}}async['_linkToIdToken'](_0x13b05f,_0x427a60){switch(this['signInMethod']){case'password':const _0x4abb44={'idToken':_0x427a60,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x13b05f,_0x4abb44,'signUpPassword',$f);case'emailLink':return zf(_0x13b05f,{'idToken':_0x427a60,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x13b05f,'internal-error');}}['_getReauthenticationResolver'](_0x585a0f){return this['_getIdTokenResponse'](_0x585a0f);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x80eec7,_0x4b1134){return Qt(_0x80eec7,'POST','/v1/accounts:signInWithIdp',Re(_0x80eec7,_0x4b1134));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x27c2b9){const _0x12aed2=new Be(_0x27c2b9['providerId'],_0x27c2b9['signInMethod']);return _0x27c2b9['idToken']||_0x27c2b9['accessToken']?(_0x27c2b9['idToken']&&(_0x12aed2['idToken']=_0x27c2b9['idToken']),_0x27c2b9['accessToken']&&(_0x12aed2['accessToken']=_0x27c2b9['accessToken']),_0x27c2b9['nonce']&&!_0x27c2b9['pendingToken']&&(_0x12aed2['nonce']=_0x27c2b9['nonce']),_0x27c2b9['pendingToken']&&(_0x12aed2['pendingToken']=_0x27c2b9['pendingToken'])):_0x27c2b9['oauthToken']&&_0x27c2b9['oauthTokenSecret']?(_0x12aed2['accessToken']=_0x27c2b9['oauthToken'],_0x12aed2['secret']=_0x27c2b9['oauthTokenSecret']):Q('argument-error'),_0x12aed2;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x30c20d){const _0xf34e42=typeof _0x30c20d=='string'?JSON['parse'](_0x30c20d):_0x30c20d,{providerId:_0x250018,signInMethod:_0x181675,..._0x535f9d}=_0xf34e42;if(!_0x250018||!_0x181675)return null;const _0x25ffe6=new Be(_0x250018,_0x181675);return _0x25ffe6['idToken']=_0x535f9d['idToken']||void 0x0,_0x25ffe6['accessToken']=_0x535f9d['accessToken']||void 0x0,_0x25ffe6['secret']=_0x535f9d['secret'],_0x25ffe6['nonce']=_0x535f9d['nonce'],_0x25ffe6['pendingToken']=_0x535f9d['pendingToken']||null,_0x25ffe6;}['_getIdTokenResponse'](_0x41ae85){const _0x31e4da=this['buildRequest']();return Xe(_0x41ae85,_0x31e4da);}['_linkToIdToken'](_0x2b6632,_0x56f626){const _0x70cbf=this['buildRequest']();return _0x70cbf['idToken']=_0x56f626,Xe(_0x2b6632,_0x70cbf);}['_getReauthenticationResolver'](_0x35bbf6){const _0x3525f2=this['buildRequest']();return _0x3525f2['autoCreate']=!0x1,Xe(_0x35bbf6,_0x3525f2);}['buildRequest'](){const _0x26199f={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x26199f['pendingToken']=this['pendingToken'];else{const _0x402dd8={};this['idToken']&&(_0x402dd8['id_token']=this['idToken']),this['accessToken']&&(_0x402dd8['access_token']=this['accessToken']),this['secret']&&(_0x402dd8['oauth_token_secret']=this['secret']),_0x402dd8['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x402dd8['nonce']=this['nonce']),_0x26199f['postBody']=ct(_0x402dd8);}return _0x26199f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x2dd464){switch(_0x2dd464){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x992444){const _0x1cb515=vt(Et(_0x992444))['link'],_0x104778=_0x1cb515?vt(Et(_0x1cb515))['deep_link_id']:null,_0x4ff5a6=vt(Et(_0x992444))['deep_link_id'];return(_0x4ff5a6?vt(Et(_0x4ff5a6))['link']:null)||_0x4ff5a6||_0x104778||_0x1cb515||_0x992444;}class Rs{constructor(_0x52dcd3){const _0x5b3b27=vt(Et(_0x52dcd3)),_0xd964a2=_0x5b3b27['apiKey']??null,_0x54f8ef=_0x5b3b27['oobCode']??null,_0x126481=Kf(_0x5b3b27['mode']??null);m(_0xd964a2&&_0x54f8ef&&_0x126481,'argument-error'),this['apiKey']=_0xd964a2,this['operation']=_0x126481,this['code']=_0x54f8ef,this['continueUrl']=_0x5b3b27['continueUrl']??null,this['languageCode']=_0x5b3b27['lang']??null,this['tenantId']=_0x5b3b27['tenantId']??null;}static['parseLink'](_0x583b98){const _0x1afdc5=Yf(_0x583b98);try{return new Rs(_0x1afdc5);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0xb8a53b,_0x478aaa){return Wt['_fromEmailAndPassword'](_0xb8a53b,_0x478aaa);}static['credentialWithLink'](_0x1feb09,_0x44f910){const _0x113ce1=Rs['parseLink'](_0x44f910);return m(_0x113ce1,'argument-error'),Wt['_fromEmailAndCode'](_0x1feb09,_0x113ce1['code'],_0x113ce1['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x504c57){this['providerId']=_0x504c57,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x332856){this['defaultLanguageCode']=_0x332856;}['setCustomParameters'](_0x44aaf8){return this['customParameters']=_0x44aaf8,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5bcd14){return this['scopes']['includes'](_0x5bcd14)||this['scopes']['push'](_0x5bcd14),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x261de1){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x261de1});}static['credentialFromResult'](_0x8d0fd2){return he['credentialFromTaggedObject'](_0x8d0fd2);}static['credentialFromError'](_0x1c2e43){return he['credentialFromTaggedObject'](_0x1c2e43['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1419eb}){if(!_0x1419eb||!('oauthAccessToken'in _0x1419eb)||!_0x1419eb['oauthAccessToken'])return null;try{return he['credential'](_0x1419eb['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x5bfc19,_0x258362){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x5bfc19,'accessToken':_0x258362});}static['credentialFromResult'](_0x4d4b6f){return ue['credentialFromTaggedObject'](_0x4d4b6f);}static['credentialFromError'](_0xd58ec6){return ue['credentialFromTaggedObject'](_0xd58ec6['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x96769d}){if(!_0x96769d)return null;const {oauthIdToken:_0x231e7a,oauthAccessToken:_0x48e502}=_0x96769d;if(!_0x231e7a&&!_0x48e502)return null;try{return ue['credential'](_0x231e7a,_0x48e502);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x3bb8e3){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x3bb8e3});}static['credentialFromResult'](_0x5b73d8){return de['credentialFromTaggedObject'](_0x5b73d8);}static['credentialFromError'](_0x3e6bef){return de['credentialFromTaggedObject'](_0x3e6bef['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4fc990}){if(!_0x4fc990||!('oauthAccessToken'in _0x4fc990)||!_0x4fc990['oauthAccessToken'])return null;try{return de['credential'](_0x4fc990['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0xb46d3a,_0xbbf4a4){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0xb46d3a,'oauthTokenSecret':_0xbbf4a4});}static['credentialFromResult'](_0x423ff0){return fe['credentialFromTaggedObject'](_0x423ff0);}static['credentialFromError'](_0x1a5333){return fe['credentialFromTaggedObject'](_0x1a5333['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1ca349}){if(!_0x1ca349)return null;const {oauthAccessToken:_0x146c69,oauthTokenSecret:_0x5eaa25}=_0x1ca349;if(!_0x146c69||!_0x5eaa25)return null;try{return fe['credential'](_0x146c69,_0x5eaa25);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x11f62e,_0x23e86b){return Qt(_0x11f62e,'POST','/v1/accounts:signUp',Re(_0x11f62e,_0x23e86b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x1af592){this['user']=_0x1af592['user'],this['providerId']=_0x1af592['providerId'],this['_tokenResponse']=_0x1af592['_tokenResponse'],this['operationType']=_0x1af592['operationType'];}static async['_fromIdTokenResponse'](_0xc6b4e6,_0x41951b,_0x510a20,_0x545a5a=!0x1){const _0x31abf4=await K['_fromIdTokenResponse'](_0xc6b4e6,_0x510a20,_0x545a5a),_0x48999e=Nr(_0x510a20);return new Ve({'user':_0x31abf4,'providerId':_0x48999e,'_tokenResponse':_0x510a20,'operationType':_0x41951b});}static async['_forOperation'](_0x4228f9,_0x4eca38,_0x477af1){await _0x4228f9['_updateTokensIfNecessary'](_0x477af1,!0x0);const _0x278d81=Nr(_0x477af1);return new Ve({'user':_0x4228f9,'providerId':_0x278d81,'_tokenResponse':_0x477af1,'operationType':_0x4eca38});}}function Nr(_0x4b9b49){return _0x4b9b49['providerId']?_0x4b9b49['providerId']:'phoneNumber'in _0x4b9b49?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x419070,_0x94ce9e,_0x32bc52,_0x3498e4){super(_0x94ce9e['code'],_0x94ce9e['message']),this['operationType']=_0x32bc52,this['user']=_0x3498e4,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x419070['name'],'tenantId':_0x419070['tenantId']??void 0x0,'_serverResponse':_0x94ce9e['customData']['_serverResponse'],'operationType':_0x32bc52};}static['_fromErrorAndOperation'](_0x336ef4,_0x40d1e9,_0x6b2015,_0x375285){return new An(_0x336ef4,_0x40d1e9,_0x6b2015,_0x375285);}}function Ba(_0x257aea,_0xefbd93,_0x4b8674,_0x3b54f4){return(_0xefbd93==='reauthenticate'?_0x4b8674['_getReauthenticationResolver'](_0x257aea):_0x4b8674['_getIdTokenResponse'](_0x257aea))['catch'](_0x48637f=>{throw _0x48637f['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x257aea,_0x48637f,_0xefbd93,_0x3b54f4):_0x48637f;});}async function Jf(_0x31abec,_0x4fb01e,_0x2d5372=!0x1){const _0x58ed37=await Ut(_0x31abec,_0x4fb01e['_linkToIdToken'](_0x31abec['auth'],await _0x31abec['getIdToken']()),_0x2d5372);return Ve['_forOperation'](_0x31abec,'link',_0x58ed37);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x17b4a6,_0x407605,_0x596079=!0x1){const {auth:_0xe6f3b3}=_0x17b4a6;if($(_0xe6f3b3['app']))return Promise['reject'](re(_0xe6f3b3));const _0x550860='reauthenticate';try{const _0x5529f9=await Ut(_0x17b4a6,Ba(_0xe6f3b3,_0x550860,_0x407605,_0x17b4a6),_0x596079);m(_0x5529f9['idToken'],_0xe6f3b3,'internal-error');const _0x3153ba=Ts(_0x5529f9['idToken']);m(_0x3153ba,_0xe6f3b3,'internal-error');const {sub:_0x54f75c}=_0x3153ba;return m(_0x17b4a6['uid']===_0x54f75c,_0xe6f3b3,'user-mismatch'),Ve['_forOperation'](_0x17b4a6,_0x550860,_0x5529f9);}catch(_0xc90fa1){throw(_0xc90fa1==null?void 0x0:_0xc90fa1['code'])==='auth/user-not-found'&&Q(_0xe6f3b3,'user-mismatch'),_0xc90fa1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x4376f7,_0x136685,_0x5f9d33=!0x1){if($(_0x4376f7['app']))return Promise['reject'](re(_0x4376f7));const _0x479c9a='signIn',_0x1f6b97=await Ba(_0x4376f7,_0x479c9a,_0x136685),_0x181b5e=await Ve['_fromIdTokenResponse'](_0x4376f7,_0x479c9a,_0x1f6b97);return _0x5f9d33||await _0x4376f7['_updateCurrentUser'](_0x181b5e['user']),_0x181b5e;}async function Zf(_0x3faabc,_0x247a0b){return Va(qe(_0x3faabc),_0x247a0b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x1da654){const _0x513fc6=qe(_0x1da654);_0x513fc6['_getPasswordPolicyInternal']()&&await _0x513fc6['_updatePasswordPolicy']();}async function P_(_0x77591a,_0x3bdaa0,_0x1d634c){if($(_0x77591a['app']))return Promise['reject'](re(_0x77591a));const _0x308745=qe(_0x77591a),_0x24ca94=await Di(_0x308745,{'returnSecureToken':!0x0,'email':_0x3bdaa0,'password':_0x1d634c,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x30ad18=>{throw _0x30ad18['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x77591a),_0x30ad18;}),_0x48f3ad=await Ve['_fromIdTokenResponse'](_0x308745,'signIn',_0x24ca94);return await _0x308745['_updateCurrentUser'](_0x48f3ad['user']),_0x48f3ad;}function O_(_0x43ddc4,_0x5c7395,_0x3964d0){return $(_0x43ddc4['app'])?Promise['reject'](re(_0x43ddc4)):Zf(N(_0x43ddc4),pt['credential'](_0x5c7395,_0x3964d0))['catch'](async _0x5f506d=>{throw _0x5f506d['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x43ddc4),_0x5f506d;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x5c136b,_0x55893f){return N(_0x5c136b)['setPersistence'](_0x55893f);}function ep(_0x1dc51f,_0x4b750d,_0x376c6e,_0x1e699a){return N(_0x1dc51f)['onIdTokenChanged'](_0x4b750d,_0x376c6e,_0x1e699a);}function tp(_0x4f4c76,_0x4cebeb,_0x2222fd){return N(_0x4f4c76)['beforeAuthStateChanged'](_0x4cebeb,_0x2222fd);}function M_(_0x3a45a8,_0x45091f,_0x57e861,_0x581396){return N(_0x3a45a8)['onAuthStateChanged'](_0x45091f,_0x57e861,_0x581396);}function L_(_0x13c98f){return N(_0x13c98f)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x3c4117,_0x85f19c){this['storageRetriever']=_0x3c4117,this['type']=_0x85f19c;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0xe78b34,_0x3d2503){return this['storage']['setItem'](_0xe78b34,JSON['stringify'](_0x3d2503)),Promise['resolve']();}['_get'](_0x3b01e5){const _0x1f8c0a=this['storage']['getItem'](_0x3b01e5);return Promise['resolve'](_0x1f8c0a?JSON['parse'](_0x1f8c0a):null);}['_remove'](_0xa5e819){return this['storage']['removeItem'](_0xa5e819),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x1dcd2c,_0x181411)=>this['onStorageEvent'](_0x1dcd2c,_0x181411),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x4120be){for(const _0x1d3921 of Object['keys'](this['listeners'])){const _0x32a264=this['storage']['getItem'](_0x1d3921),_0x5564af=this['localCache'][_0x1d3921];_0x32a264!==_0x5564af&&_0x4120be(_0x1d3921,_0x5564af,_0x32a264);}}['onStorageEvent'](_0x29fa7e,_0x7e1665=!0x1){if(!_0x29fa7e['key']){this['forAllChangedKeys']((_0x494a9e,_0x28a830,_0x52bb26)=>{this['notifyListeners'](_0x494a9e,_0x52bb26);});return;}const _0x51b94=_0x29fa7e['key'];_0x7e1665?this['detachListener']():this['stopPolling']();const _0x254dd0=()=>{const _0x270029=this['storage']['getItem'](_0x51b94);!_0x7e1665&&this['localCache'][_0x51b94]===_0x270029||this['notifyListeners'](_0x51b94,_0x270029);},_0xe2a897=this['storage']['getItem'](_0x51b94);Tf()&&_0xe2a897!==_0x29fa7e['newValue']&&_0x29fa7e['newValue']!==_0x29fa7e['oldValue']?setTimeout(_0x254dd0,ip):_0x254dd0();}['notifyListeners'](_0x1afc37,_0x47dd33){this['localCache'][_0x1afc37]=_0x47dd33;const _0x34a5f8=this['listeners'][_0x1afc37];if(_0x34a5f8){for(const _0x4cc70e of Array['from'](_0x34a5f8))_0x4cc70e(_0x47dd33&&JSON['parse'](_0x47dd33));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x4f96d3,_0x32b09b,_0xab237b)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x4f96d3,'oldValue':_0x32b09b,'newValue':_0xab237b}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x43198a,_0x2f5ddd){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x43198a]||(this['listeners'][_0x43198a]=new Set(),this['localCache'][_0x43198a]=this['storage']['getItem'](_0x43198a)),this['listeners'][_0x43198a]['add'](_0x2f5ddd);}['_removeListener'](_0xf0d130,_0x30aaef){this['listeners'][_0xf0d130]&&(this['listeners'][_0xf0d130]['delete'](_0x30aaef),this['listeners'][_0xf0d130]['size']===0x0&&delete this['listeners'][_0xf0d130]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x3aa8e1,_0x2da340){await super['_set'](_0x3aa8e1,_0x2da340),this['localCache'][_0x3aa8e1]=JSON['stringify'](_0x2da340);}async['_get'](_0x2b86d8){const _0x2b5dbe=await super['_get'](_0x2b86d8);return this['localCache'][_0x2b86d8]=JSON['stringify'](_0x2b5dbe),_0x2b5dbe;}async['_remove'](_0x3158fa){await super['_remove'](_0x3158fa),delete this['localCache'][_0x3158fa];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x1225e4,_0x489bd1){}['_removeListener'](_0x5216ae,_0x3305fa){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x52b010){return Promise['all'](_0x52b010['map'](async _0x488f33=>{try{return{'fulfilled':!0x0,'value':await _0x488f33};}catch(_0x1bfaca){return{'fulfilled':!0x1,'reason':_0x1bfaca};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x34b52b){this['eventTarget']=_0x34b52b,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x220c8b){const _0x126011=this['receivers']['find'](_0x327136=>_0x327136['isListeningto'](_0x220c8b));if(_0x126011)return _0x126011;const _0xb0ced9=new Kn(_0x220c8b);return this['receivers']['push'](_0xb0ced9),_0xb0ced9;}['isListeningto'](_0x1d0b39){return this['eventTarget']===_0x1d0b39;}async['handleEvent'](_0x58c004){const _0x4a1153=_0x58c004,{eventId:_0x46304b,eventType:_0x18dc0e,data:_0x38bc45}=_0x4a1153['data'],_0x264bd7=this['handlersMap'][_0x18dc0e];if(!(_0x264bd7!=null&&_0x264bd7['size']))return;_0x4a1153['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x46304b,'eventType':_0x18dc0e});const _0x35b510=Array['from'](_0x264bd7)['map'](async _0x48c651=>_0x48c651(_0x4a1153['origin'],_0x38bc45)),_0x2a75e0=await rp(_0x35b510);_0x4a1153['ports'][0x0]['postMessage']({'status':'done','eventId':_0x46304b,'eventType':_0x18dc0e,'response':_0x2a75e0});}['_subscribe'](_0x581c9d,_0x30c343){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x581c9d]||(this['handlersMap'][_0x581c9d]=new Set()),this['handlersMap'][_0x581c9d]['add'](_0x30c343);}['_unsubscribe'](_0x275b0b,_0x49d580){this['handlersMap'][_0x275b0b]&&_0x49d580&&this['handlersMap'][_0x275b0b]['delete'](_0x49d580),(!_0x49d580||this['handlersMap'][_0x275b0b]['size']===0x0)&&delete this['handlersMap'][_0x275b0b],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x47bb26='',_0x1e531b=0xa){let _0x2850bb='';for(let _0x349aa2=0x0;_0x349aa2<_0x1e531b;_0x349aa2++)_0x2850bb+=Math['floor'](Math['random']()*0xa);return _0x47bb26+_0x2850bb;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x15c083){this['target']=_0x15c083,this['handlers']=new Set();}['removeMessageHandler'](_0x6f2c7b){_0x6f2c7b['messageChannel']&&(_0x6f2c7b['messageChannel']['port1']['removeEventListener']('message',_0x6f2c7b['onMessage']),_0x6f2c7b['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x6f2c7b);}async['_send'](_0x562b45,_0x55a399,_0x400a73=0x32){const _0x385225=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x385225)throw new Error('connection_unavailable');let _0x2fa60d,_0x8b3427;return new Promise((_0x2f8c90,_0x3496fa)=>{const _0x33b7c5=As('',0x14);_0x385225['port1']['start']();const _0x1f872e=setTimeout(()=>{_0x3496fa(new Error('unsupported_event'));},_0x400a73);_0x8b3427={'messageChannel':_0x385225,'onMessage'(_0xaa068b){const _0x1d6f3d=_0xaa068b;if(_0x1d6f3d['data']['eventId']===_0x33b7c5)switch(_0x1d6f3d['data']['status']){case'ack':clearTimeout(_0x1f872e),_0x2fa60d=setTimeout(()=>{_0x3496fa(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x2fa60d),_0x2f8c90(_0x1d6f3d['data']['response']);break;default:clearTimeout(_0x1f872e),clearTimeout(_0x2fa60d),_0x3496fa(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x8b3427),_0x385225['port1']['addEventListener']('message',_0x8b3427['onMessage']),this['target']['postMessage']({'eventType':_0x562b45,'eventId':_0x33b7c5,'data':_0x55a399},[_0x385225['port2']]);})['finally'](()=>{_0x8b3427&&this['removeMessageHandler'](_0x8b3427);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x5c29b5){Z()['location']['href']=_0x5c29b5;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x37f14e;return((_0x37f14e=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x37f14e['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x1bc5ae){this['request']=_0x1bc5ae;}['toPromise'](){return new Promise((_0x1bbcdb,_0x351f0a)=>{this['request']['addEventListener']('success',()=>{_0x1bbcdb(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x351f0a(this['request']['error']);});});}}function Yn(_0x17091a,_0x30d466){return _0x17091a['transaction']([Nn],_0x30d466?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x463bee=indexedDB['deleteDatabase'](Ka);return new Xt(_0x463bee)['toPromise']();}function Mi(){const _0x413739=indexedDB['open'](Ka,up);return new Promise((_0x4aa259,_0x501a05)=>{_0x413739['addEventListener']('error',()=>{_0x501a05(_0x413739['error']);}),_0x413739['addEventListener']('upgradeneeded',()=>{const _0x1bac4f=_0x413739['result'];try{_0x1bac4f['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x57bdf5){_0x501a05(_0x57bdf5);}}),_0x413739['addEventListener']('success',async()=>{const _0x5c30bb=_0x413739['result'];_0x5c30bb['objectStoreNames']['contains'](Nn)?_0x4aa259(_0x5c30bb):(_0x5c30bb['close'](),await dp(),_0x4aa259(await Mi()));});});}async function Pr(_0xf06ce4,_0x457def,_0xe8740c){const _0x509fc9=Yn(_0xf06ce4,!0x0)['put']({[Ya]:_0x457def,'value':_0xe8740c});return new Xt(_0x509fc9)['toPromise']();}async function fp(_0x41d140,_0x380f34){const _0x10dc44=Yn(_0x41d140,!0x1)['get'](_0x380f34),_0x575107=await new Xt(_0x10dc44)['toPromise']();return _0x575107===void 0x0?null:_0x575107['value'];}function Or(_0x415366,_0x2438b7){const _0x1e0591=Yn(_0x415366,!0x0)['delete'](_0x2438b7);return new Xt(_0x1e0591)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x19564a){let _0x26baf2=0x0;for(;;)try{const _0x43e5ab=await this['_openDb']();return await _0x19564a(_0x43e5ab);}catch(_0x4f5345){if(_0x26baf2++>_p)throw _0x4f5345;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x555448,_0x55c0c2)=>({'keyProcessed':(await this['_poll']())['includes'](_0x55c0c2['key'])})),this['receiver']['_subscribe']('ping',async(_0x4b5770,_0x4a5860)=>['keyChanged']);}async['initializeSender'](){var _0x2da6fb,_0x2b3303;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x3cd02c=await this['sender']['_send']('ping',{},0x320);_0x3cd02c&&(_0x2da6fb=_0x3cd02c[0x0])!=null&&_0x2da6fb['fulfilled']&&(_0x2b3303=_0x3cd02c[0x0])!=null&&_0x2b3303['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x3b021e){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x3b021e},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x4e85e1=await Mi();return await Pr(_0x4e85e1,kn,'1'),await Or(_0x4e85e1,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x15bf43){this['pendingWrites']++;try{await _0x15bf43();}finally{this['pendingWrites']--;}}async['_set'](_0x43ac89,_0x4a851b){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x490d8b=>Pr(_0x490d8b,_0x43ac89,_0x4a851b)),this['localCache'][_0x43ac89]=_0x4a851b,this['notifyServiceWorker'](_0x43ac89)));}async['_get'](_0x193094){const _0x1f0fd4=await this['_withRetries'](_0x2480f7=>fp(_0x2480f7,_0x193094));return this['localCache'][_0x193094]=_0x1f0fd4,_0x1f0fd4;}async['_remove'](_0x499f06){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x423daa=>Or(_0x423daa,_0x499f06)),delete this['localCache'][_0x499f06],this['notifyServiceWorker'](_0x499f06)));}async['_poll'](){const _0x23f3f0=await this['_withRetries'](_0x504389=>{const _0x3bbfc3=Yn(_0x504389,!0x1)['getAll']();return new Xt(_0x3bbfc3)['toPromise']();});if(!_0x23f3f0)return[];if(this['pendingWrites']!==0x0)return[];const _0x5d1946=[],_0x162dfb=new Set();if(_0x23f3f0['length']!==0x0){for(const {fbase_key:_0x481144,value:_0x3a8b09}of _0x23f3f0)_0x162dfb['add'](_0x481144),JSON['stringify'](this['localCache'][_0x481144])!==JSON['stringify'](_0x3a8b09)&&(this['notifyListeners'](_0x481144,_0x3a8b09),_0x5d1946['push'](_0x481144));}for(const _0x1a35a9 of Object['keys'](this['localCache']))this['localCache'][_0x1a35a9]&&!_0x162dfb['has'](_0x1a35a9)&&(this['notifyListeners'](_0x1a35a9,null),_0x5d1946['push'](_0x1a35a9));return _0x5d1946;}['notifyListeners'](_0x10a000,_0x33cac6){this['localCache'][_0x10a000]=_0x33cac6;const _0xb5c8f9=this['listeners'][_0x10a000];if(_0xb5c8f9){for(const _0x1bfbe2 of Array['from'](_0xb5c8f9))_0x1bfbe2(_0x33cac6);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x280466,_0x4ff941){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x280466]||(this['listeners'][_0x280466]=new Set(),this['_get'](_0x280466)),this['listeners'][_0x280466]['add'](_0x4ff941);}['_removeListener'](_0x3d783c,_0x387534){this['listeners'][_0x3d783c]&&(this['listeners'][_0x3d783c]['delete'](_0x387534),this['listeners'][_0x3d783c]['size']===0x0&&delete this['listeners'][_0x3d783c]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x356d40,_0x112ceb){return _0x112ceb?ie(_0x112ceb):(m(_0x356d40['_popupRedirectResolver'],_0x356d40,'argument-error'),_0x356d40['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x10d1ec){super('custom','custom'),this['params']=_0x10d1ec;}['_getIdTokenResponse'](_0x289596){return Xe(_0x289596,this['_buildIdpRequest']());}['_linkToIdToken'](_0x5270e2,_0x295e1f){return Xe(_0x5270e2,this['_buildIdpRequest'](_0x295e1f));}['_getReauthenticationResolver'](_0x4a43e6){return Xe(_0x4a43e6,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x1d397f){const _0x11cffa={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x1d397f&&(_0x11cffa['idToken']=_0x1d397f),_0x11cffa;}}function yp(_0x1847e9){return Va(_0x1847e9['auth'],new ks(_0x1847e9),_0x1847e9['bypassAuthState']);}function vp(_0x59fee7){const {auth:_0x20748b,user:_0x2da8b0}=_0x59fee7;return m(_0x2da8b0,_0x20748b,'internal-error'),Xf(_0x2da8b0,new ks(_0x59fee7),_0x59fee7['bypassAuthState']);}async function Ep(_0x35bb9e){const {auth:_0x147c6c,user:_0x3162e2}=_0x35bb9e;return m(_0x3162e2,_0x147c6c,'internal-error'),Jf(_0x3162e2,new ks(_0x35bb9e),_0x35bb9e['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x2a5f62,_0x1d96d5,_0x294c74,_0x4ab63d,_0x49e752=!0x1){this['auth']=_0x2a5f62,this['resolver']=_0x294c74,this['user']=_0x4ab63d,this['bypassAuthState']=_0x49e752,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x1d96d5)?_0x1d96d5:[_0x1d96d5];}['execute'](){return new Promise(async(_0x300e32,_0x5199db)=>{this['pendingPromise']={'resolve':_0x300e32,'reject':_0x5199db};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x42c6a8){this['reject'](_0x42c6a8);}});}async['onAuthEvent'](_0x4222a8){const {urlResponse:_0x1d8718,sessionId:_0x522f93,postBody:_0x5583e4,tenantId:_0x381659,error:_0x254e02,type:_0x58eee0}=_0x4222a8;if(_0x254e02){this['reject'](_0x254e02);return;}const _0x293d15={'auth':this['auth'],'requestUri':_0x1d8718,'sessionId':_0x522f93,'tenantId':_0x381659||void 0x0,'postBody':_0x5583e4||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x58eee0)(_0x293d15));}catch(_0x5f2cc2){this['reject'](_0x5f2cc2);}}['onError'](_0x426bca){this['reject'](_0x426bca);}['getIdpTask'](_0x582510){switch(_0x582510){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x1aae49){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x1aae49),this['unregisterAndCleanUp']();}['reject'](_0x3bf601){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x3bf601),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x442069,_0x1634ef,_0x9ba983,_0x3d6d72,_0xe5f3c0){super(_0x442069,_0x1634ef,_0x3d6d72,_0xe5f3c0),this['provider']=_0x9ba983,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x3832d4=await this['execute']();return m(_0x3832d4,this['auth'],'internal-error'),_0x3832d4;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x51fcd1=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x51fcd1),this['authWindow']['associatedEvent']=_0x51fcd1,this['resolver']['_originValidation'](this['auth'])['catch'](_0x1c74fb=>{this['reject'](_0x1c74fb);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x2fb7e8=>{_0x2fb7e8||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x25519e;return((_0x25519e=this['authWindow'])==null?void 0x0:_0x25519e['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x560bb4=()=>{var _0x32cb0e,_0x5c670b;if((_0x5c670b=(_0x32cb0e=this['authWindow'])==null?void 0x0:_0x32cb0e['window'])!=null&&_0x5c670b['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x560bb4,Ip['get']());};_0x560bb4();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x5b581a,_0x3c56f0,_0x4f36fc=!0x1){super(_0x5b581a,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3c56f0,void 0x0,_0x4f36fc),this['eventId']=null;}async['execute'](){let _0x644bc4=on['get'](this['auth']['_key']());if(!_0x644bc4){try{const _0x530060=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x644bc4=()=>Promise['resolve'](_0x530060);}catch(_0x52ec93){_0x644bc4=()=>Promise['reject'](_0x52ec93);}on['set'](this['auth']['_key'](),_0x644bc4);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x644bc4();}async['onAuthEvent'](_0x42c903){if(_0x42c903['type']==='signInViaRedirect')return super['onAuthEvent'](_0x42c903);if(_0x42c903['type']==='unknown'){this['resolve'](null);return;}if(_0x42c903['eventId']){const _0xaf11ae=await this['auth']['_redirectUserForId'](_0x42c903['eventId']);if(_0xaf11ae)return this['user']=_0xaf11ae,super['onAuthEvent'](_0x42c903);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x104f95,_0x233bef){const _0x3afd57=Rp(_0x233bef),_0x178da6=bp(_0x104f95);if(!await _0x178da6['_isAvailable']())return!0x1;const _0x29f60d=await _0x178da6['_get'](_0x3afd57)==='true';return await _0x178da6['_remove'](_0x3afd57),_0x29f60d;}function Sp(_0x35d3f1,_0x5ef8be){on['set'](_0x35d3f1['_key'](),_0x5ef8be);}function bp(_0x27c929){return ie(_0x27c929['_redirectPersistence']);}function Rp(_0x30b306){return rn(wp,_0x30b306['config']['apiKey'],_0x30b306['name']);}async function Ap(_0x1aa12b,_0x5bf344,_0x25753e=!0x1){if($(_0x1aa12b['app']))return Promise['reject'](re(_0x1aa12b));const _0x5e304c=qe(_0x1aa12b),_0x409b36=mp(_0x5e304c,_0x5bf344),_0x107c39=await new Cp(_0x5e304c,_0x409b36,_0x25753e)['execute']();return _0x107c39&&!_0x25753e&&(delete _0x107c39['user']['_redirectEventId'],await _0x5e304c['_persistUserIfCurrent'](_0x107c39['user']),await _0x5e304c['_setRedirectUser'](null,_0x5bf344)),_0x107c39;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x4b9b04){this['auth']=_0x4b9b04,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x3779bd){this['consumers']['add'](_0x3779bd),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x3779bd)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x3779bd),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x2bfed7){this['consumers']['delete'](_0x2bfed7);}['onEvent'](_0x1140da){if(this['hasEventBeenHandled'](_0x1140da))return!0x1;let _0x593523=!0x1;return this['consumers']['forEach'](_0x23198f=>{this['isEventForConsumer'](_0x1140da,_0x23198f)&&(_0x593523=!0x0,this['sendToConsumer'](_0x1140da,_0x23198f),this['saveEventToCache'](_0x1140da));}),this['hasHandledPotentialRedirect']||!Pp(_0x1140da)||(this['hasHandledPotentialRedirect']=!0x0,_0x593523||(this['queuedRedirectEvent']=_0x1140da,_0x593523=!0x0)),_0x593523;}['sendToConsumer'](_0x3155fd,_0x11572b){var _0x21e1bf;if(_0x3155fd['error']&&!Xa(_0x3155fd)){const _0x1a0e18=((_0x21e1bf=_0x3155fd['error']['code'])==null?void 0x0:_0x21e1bf['split']('auth/')[0x1])||'internal-error';_0x11572b['onError'](X(this['auth'],_0x1a0e18));}else _0x11572b['onAuthEvent'](_0x3155fd);}['isEventForConsumer'](_0x3882d7,_0x5bd92a){const _0x5be770=_0x5bd92a['eventId']===null||!!_0x3882d7['eventId']&&_0x3882d7['eventId']===_0x5bd92a['eventId'];return _0x5bd92a['filter']['includes'](_0x3882d7['type'])&&_0x5be770;}['hasEventBeenHandled'](_0x5c738e){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x5c738e));}['saveEventToCache'](_0x2acd00){this['cachedEventUids']['add'](Dr(_0x2acd00)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x1f2677){return[_0x1f2677['type'],_0x1f2677['eventId'],_0x1f2677['sessionId'],_0x1f2677['tenantId']]['filter'](_0xb9d6cd=>_0xb9d6cd)['join']('-');}function Xa({type:_0x3ef4e9,error:_0x37b7e5}){return _0x3ef4e9==='unknown'&&(_0x37b7e5==null?void 0x0:_0x37b7e5['code'])==='auth/no-auth-event';}function Pp(_0x52c041){switch(_0x52c041['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x52c041);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x2a42e9,_0x262a36={}){return Ae(_0x2a42e9,'GET','/v1/projects',_0x262a36);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x131a3d){if(_0x131a3d['config']['emulator'])return;const {authorizedDomains:_0x5d2228}=await Op(_0x131a3d);for(const _0x10de4e of _0x5d2228)try{if(xp(_0x10de4e))return;}catch{}Q(_0x131a3d,'unauthorized-domain');}function xp(_0x25c058){const _0x347976=Pi(),{protocol:_0x5ab2a3,hostname:_0x5b4df1}=new URL(_0x347976);if(_0x25c058['startsWith']('chrome-extension://')){const _0x4a3ec7=new URL(_0x25c058);return _0x4a3ec7['hostname']===''&&_0x5b4df1===''?_0x5ab2a3==='chrome-extension:'&&_0x25c058['replace']('chrome-extension://','')===_0x347976['replace']('chrome-extension://',''):_0x5ab2a3==='chrome-extension:'&&_0x4a3ec7['hostname']===_0x5b4df1;}if(!Mp['test'](_0x5ab2a3))return!0x1;if(Dp['test'](_0x25c058))return _0x5b4df1===_0x25c058;const _0x12e2ea=_0x25c058['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x12e2ea+'|'+_0x12e2ea+')$','i')['test'](_0x5b4df1);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x16bb8d=Z()['___jsl'];if(_0x16bb8d!=null&&_0x16bb8d['H']){for(const _0x19e76b of Object['keys'](_0x16bb8d['H']))if(_0x16bb8d['H'][_0x19e76b]['r']=_0x16bb8d['H'][_0x19e76b]['r']||[],_0x16bb8d['H'][_0x19e76b]['L']=_0x16bb8d['H'][_0x19e76b]['L']||[],_0x16bb8d['H'][_0x19e76b]['r']=[..._0x16bb8d['H'][_0x19e76b]['L']],_0x16bb8d['CP']){for(let _0x235803=0x0;_0x235803<_0x16bb8d['CP']['length'];_0x235803++)_0x16bb8d['CP'][_0x235803]=null;}}}function Up(_0x5ede65){return new Promise((_0x2b9cd1,_0x474a9a)=>{var _0x2bb5ff,_0x520d6e,_0x130e97;function _0x354655(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x2b9cd1(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x474a9a(X(_0x5ede65,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x520d6e=(_0x2bb5ff=Z()['gapi'])==null?void 0x0:_0x2bb5ff['iframes'])!=null&&_0x520d6e['Iframe'])_0x2b9cd1(gapi['iframes']['getContext']());else{if((_0x130e97=Z()['gapi'])!=null&&_0x130e97['load'])_0x354655();else{const _0x3041c4=Df('iframefcb');return Z()[_0x3041c4]=()=>{gapi['load']?_0x354655():_0x474a9a(X(_0x5ede65,'network-request-failed'));},xa(Of()+'?onload='+_0x3041c4)['catch'](_0x1e6fcb=>_0x474a9a(_0x1e6fcb));}}})['catch'](_0x3d730e=>{throw an=null,_0x3d730e;});}let an=null;function Wp(_0x1a1d0c){return an=an||Up(_0x1a1d0c),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x240f20){const _0x1a4e70=_0x240f20['config'];m(_0x1a4e70['authDomain'],_0x240f20,'auth-domain-config-required');const _0x1e5795=_0x1a4e70['emulator']?Cs(_0x1a4e70,Hp):'https://'+_0x240f20['config']['authDomain']+'/'+Vp,_0x5a0d25={'apiKey':_0x1a4e70['apiKey'],'appName':_0x240f20['name'],'v':lt},_0x3a0f47=Gp['get'](_0x240f20['config']['apiHost']);_0x3a0f47&&(_0x5a0d25['eid']=_0x3a0f47);const _0x1b6d7c=_0x240f20['_getFrameworks']();return _0x1b6d7c['length']&&(_0x5a0d25['fw']=_0x1b6d7c['join'](',')),_0x1e5795+'?'+ct(_0x5a0d25)['slice'](0x1);}async function zp(_0x317fec){const _0x27bfc9=await Wp(_0x317fec),_0x276973=Z()['gapi'];return m(_0x276973,_0x317fec,'internal-error'),_0x27bfc9['open']({'where':document['body'],'url':qp(_0x317fec),'messageHandlersFilter':_0x276973['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x54e767=>new Promise(async(_0x108527,_0x253a94)=>{await _0x54e767['restyle']({'setHideOnLeave':!0x1});const _0x4ba39c=X(_0x317fec,'network-request-failed'),_0x917c38=Z()['setTimeout'](()=>{_0x253a94(_0x4ba39c);},Bp['get']());function _0x36d2bd(){Z()['clearTimeout'](_0x917c38),_0x108527(_0x54e767);}_0x54e767['ping'](_0x36d2bd)['then'](_0x36d2bd,()=>{_0x253a94(_0x4ba39c);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x260c86){this['window']=_0x260c86,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x3df06a,_0xae5f7b,_0x3c2ea8,_0x3c9990=Kp,_0xf9c637=Yp){const _0xf04882=Math['max']((window['screen']['availHeight']-_0xf9c637)/0x2,0x0)['toString'](),_0x50d768=Math['max']((window['screen']['availWidth']-_0x3c9990)/0x2,0x0)['toString']();let _0x35d9fa='';const _0x1157bb={...jp,'width':_0x3c9990['toString'](),'height':_0xf9c637['toString'](),'top':_0xf04882,'left':_0x50d768},_0x10b400=W()['toLowerCase']();_0x3c2ea8&&(_0x35d9fa=ka(_0x10b400)?Qp:_0x3c2ea8),Ra(_0x10b400)&&(_0xae5f7b=_0xae5f7b||Jp,_0x1157bb['scrollbars']='yes');const _0x1dc6bc=Object['entries'](_0x1157bb)['reduce']((_0x57031a,[_0x1d91c2,_0x13ff9b])=>''+_0x57031a+_0x1d91c2+'='+_0x13ff9b+',','');if(Cf(_0x10b400)&&_0x35d9fa!=='_self')return Zp(_0xae5f7b||'',_0x35d9fa),new Lr(null);const _0x417ceb=window['open'](_0xae5f7b||'',_0x35d9fa,_0x1dc6bc);m(_0x417ceb,_0x3df06a,'popup-blocked');try{_0x417ceb['focus']();}catch{}return new Lr(_0x417ceb);}function Zp(_0x410372,_0x240ccc){const _0x26fed7=document['createElement']('a');_0x26fed7['href']=_0x410372,_0x26fed7['target']=_0x240ccc;const _0x243172=document['createEvent']('MouseEvent');_0x243172['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x26fed7['dispatchEvent'](_0x243172);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x5c117c,_0x1c07df,_0xd79b21,_0x24853e,_0x3abcae,_0x2f39d9){m(_0x5c117c['config']['authDomain'],_0x5c117c,'auth-domain-config-required'),m(_0x5c117c['config']['apiKey'],_0x5c117c,'invalid-api-key');const _0x48adf2={'apiKey':_0x5c117c['config']['apiKey'],'appName':_0x5c117c['name'],'authType':_0xd79b21,'redirectUrl':_0x24853e,'v':lt,'eventId':_0x3abcae};if(_0x1c07df instanceof Wa){_0x1c07df['setDefaultLanguage'](_0x5c117c['languageCode']),_0x48adf2['providerId']=_0x1c07df['providerId']||'',ui(_0x1c07df['getCustomParameters']())||(_0x48adf2['customParameters']=JSON['stringify'](_0x1c07df['getCustomParameters']()));for(const [_0x3976dd,_0x169c36]of Object['entries']({}))_0x48adf2[_0x3976dd]=_0x169c36;}if(_0x1c07df instanceof Jt){const _0x38a82e=_0x1c07df['getScopes']()['filter'](_0x48c11f=>_0x48c11f!=='');_0x38a82e['length']>0x0&&(_0x48adf2['scopes']=_0x38a82e['join'](','));}_0x5c117c['tenantId']&&(_0x48adf2['tid']=_0x5c117c['tenantId']);const _0x23f647=_0x48adf2;for(const _0x596102 of Object['keys'](_0x23f647))_0x23f647[_0x596102]===void 0x0&&delete _0x23f647[_0x596102];const _0x4ee58c=await _0x5c117c['_getAppCheckToken'](),_0x3c2de8=_0x4ee58c?'#'+n_+'='+encodeURIComponent(_0x4ee58c):'';return i_(_0x5c117c)+'?'+ct(_0x23f647)['slice'](0x1)+_0x3c2de8;}function i_({config:_0x3e8664}){return _0x3e8664['emulator']?Cs(_0x3e8664,t_):'https://'+_0x3e8664['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x58ddc7,_0x18c5aa,_0x5d5732,_0x145234){var _0x343376;ce((_0x343376=this['eventManagers'][_0x58ddc7['_key']()])==null?void 0x0:_0x343376['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x3f1b42=await xr(_0x58ddc7,_0x18c5aa,_0x5d5732,Pi(),_0x145234);return Xp(_0x58ddc7,_0x3f1b42,As());}async['_openRedirect'](_0x3057b8,_0x17c933,_0x242dc4,_0x35d371){await this['_originValidation'](_0x3057b8);const _0x1f5ee3=await xr(_0x3057b8,_0x17c933,_0x242dc4,Pi(),_0x35d371);return ap(_0x1f5ee3),new Promise(()=>{});}['_initialize'](_0x241182){const _0x12d736=_0x241182['_key']();if(this['eventManagers'][_0x12d736]){const {manager:_0x408ac1,promise:_0x1c2785}=this['eventManagers'][_0x12d736];return _0x408ac1?Promise['resolve'](_0x408ac1):(ce(_0x1c2785,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x1c2785);}const _0x101638=this['initAndGetManager'](_0x241182);return this['eventManagers'][_0x12d736]={'promise':_0x101638},_0x101638['catch'](()=>{delete this['eventManagers'][_0x12d736];}),_0x101638;}async['initAndGetManager'](_0x1f5317){const _0x2a82d9=await zp(_0x1f5317),_0x20e848=new Np(_0x1f5317);return _0x2a82d9['register']('authEvent',_0x54b9cc=>(m(_0x54b9cc==null?void 0x0:_0x54b9cc['authEvent'],_0x1f5317,'invalid-auth-event'),{'status':_0x20e848['onEvent'](_0x54b9cc['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x1f5317['_key']()]={'manager':_0x20e848},this['iframes'][_0x1f5317['_key']()]=_0x2a82d9,_0x20e848;}['_isIframeWebStorageSupported'](_0x12ddb7,_0x1fa13a){this['iframes'][_0x12ddb7['_key']()]['send'](hi,{'type':hi},_0x4a65c5=>{var _0x308cb0;const _0x37a61d=(_0x308cb0=_0x4a65c5==null?void 0x0:_0x4a65c5[0x0])==null?void 0x0:_0x308cb0[hi];_0x37a61d!==void 0x0&&_0x1fa13a(!!_0x37a61d),Q(_0x12ddb7,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x5e411e){const _0x288764=_0x5e411e['_key']();return this['originValidationPromises'][_0x288764]||(this['originValidationPromises'][_0x288764]=Lp(_0x5e411e)),this['originValidationPromises'][_0x288764];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x3f4555){this['auth']=_0x3f4555,this['internalListeners']=new Map();}['getUid'](){var _0x3be467;return this['assertAuthConfigured'](),((_0x3be467=this['auth']['currentUser'])==null?void 0x0:_0x3be467['uid'])||null;}async['getToken'](_0x2eecc8){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x2eecc8)}:null;}['addAuthTokenListener'](_0x55ea70){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x55ea70))return;const _0x339a07=this['auth']['onIdTokenChanged'](_0x13c2d8=>{_0x55ea70((_0x13c2d8==null?void 0x0:_0x13c2d8['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x55ea70,_0x339a07),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x5374ee){this['assertAuthConfigured']();const _0x237db6=this['internalListeners']['get'](_0x5374ee);_0x237db6&&(this['internalListeners']['delete'](_0x5374ee),_0x237db6(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x3ab368){switch(_0x3ab368){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x1258c7){Ze(new Le('auth',(_0x434b53,{options:_0xf4d719})=>{const _0x1b7f7c=_0x434b53['getProvider']('app')['getImmediate'](),_0x1c8a34=_0x434b53['getProvider']('heartbeat'),_0x3f33bd=_0x434b53['getProvider']('app-check-internal'),{apiKey:_0x2fb66c,authDomain:_0x590702}=_0x1b7f7c['options'];m(_0x2fb66c&&!_0x2fb66c['includes'](':'),'invalid-api-key',{'appName':_0x1b7f7c['name']});const _0x2e4387={'apiKey':_0x2fb66c,'authDomain':_0x590702,'clientPlatform':_0x1258c7,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x1258c7)},_0x3f5eb6=new kf(_0x1b7f7c,_0x1c8a34,_0x3f33bd,_0x2e4387);return Wf(_0x3f5eb6,_0xf4d719),_0x3f5eb6;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x475cd0,_0x1f25ac,_0x2f565d)=>{_0x475cd0['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x4b4f80=>{const _0x5a08c5=qe(_0x4b4f80['getProvider']('auth')['getImmediate']());return(_0x405907=>new o_(_0x405907))(_0x5a08c5);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x1258c7)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x2b01c5=>async _0x45640d=>{const _0x3c177b=_0x45640d&&await _0x45640d['getIdTokenResult'](),_0x5c9497=_0x3c177b&&(new Date()['getTime']()-Date['parse'](_0x3c177b['issuedAtTime']))/0x3e8;if(_0x5c9497&&_0x5c9497>h_)return;const _0x5faac1=_0x3c177b==null?void 0x0:_0x3c177b['token'];Wr!==_0x5faac1&&(Wr=_0x5faac1,await fetch(_0x2b01c5,{'method':_0x5faac1?'POST':'DELETE','headers':_0x5faac1?{'Authorization':'Bearer\x20'+_0x5faac1}:{}}));};function x_(_0x227091=Zr()){const _0x5d4ed8=Bi(_0x227091,'auth');if(_0x5d4ed8['isInitialized']())return _0x5d4ed8['getImmediate']();const _0x2d1cc4=Uf(_0x227091,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x2da015=zr('authTokenSyncURL');if(_0x2da015&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x51a7d6=new URL(_0x2da015,location['origin']);if(location['origin']===_0x51a7d6['origin']){const _0xd524a9=u_(_0x51a7d6['toString']());tp(_0x2d1cc4,_0xd524a9,()=>_0xd524a9(_0x2d1cc4['currentUser'])),ep(_0x2d1cc4,_0x469cbb=>_0xd524a9(_0x469cbb));}}const _0xc9b1d0=Gr('auth');return _0xc9b1d0&&Bf(_0x2d1cc4,'http://'+_0xc9b1d0),_0x2d1cc4;}function d_(){var _0x2a83c3;return((_0x2a83c3=document['getElementsByTagName']('head'))==null?void 0x0:_0x2a83c3[0x0])??document;}Nf({'loadJS'(_0x545b7e){return new Promise((_0x212abf,_0x449b89)=>{const _0x39fe82=document['createElement']('script');_0x39fe82['setAttribute']('src',_0x545b7e),_0x39fe82['onload']=_0x212abf,_0x39fe82['onerror']=_0xa56154=>{const _0x2d39d6=X('internal-error');_0x2d39d6['customData']=_0xa56154,_0x449b89(_0x2d39d6);},_0x39fe82['type']='text/javascript',_0x39fe82['charset']='UTF-8',d_()['appendChild'](_0x39fe82);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};