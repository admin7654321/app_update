const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x419c01,_0x28e234){if(!_0x419c01)throw rt(_0x28e234);},rt=function(_0x45a498){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x45a498);},Vr=function(_0x4d04e7){const _0x36365a=[];let _0x2b8927=0x0;for(let _0x3560ce=0x0;_0x3560ce<_0x4d04e7['length'];_0x3560ce++){let _0x1e3aac=_0x4d04e7['charCodeAt'](_0x3560ce);_0x1e3aac<0x80?_0x36365a[_0x2b8927++]=_0x1e3aac:_0x1e3aac<0x800?(_0x36365a[_0x2b8927++]=_0x1e3aac>>0x6|0xc0,_0x36365a[_0x2b8927++]=_0x1e3aac&0x3f|0x80):(_0x1e3aac&0xfc00)===0xd800&&_0x3560ce+0x1<_0x4d04e7['length']&&(_0x4d04e7['charCodeAt'](_0x3560ce+0x1)&0xfc00)===0xdc00?(_0x1e3aac=0x10000+((_0x1e3aac&0x3ff)<<0xa)+(_0x4d04e7['charCodeAt'](++_0x3560ce)&0x3ff),_0x36365a[_0x2b8927++]=_0x1e3aac>>0x12|0xf0,_0x36365a[_0x2b8927++]=_0x1e3aac>>0xc&0x3f|0x80,_0x36365a[_0x2b8927++]=_0x1e3aac>>0x6&0x3f|0x80,_0x36365a[_0x2b8927++]=_0x1e3aac&0x3f|0x80):(_0x36365a[_0x2b8927++]=_0x1e3aac>>0xc|0xe0,_0x36365a[_0x2b8927++]=_0x1e3aac>>0x6&0x3f|0x80,_0x36365a[_0x2b8927++]=_0x1e3aac&0x3f|0x80);}return _0x36365a;},ec=function(_0xfd56c0){const _0x5e6fd0=[];let _0x260b2b=0x0,_0x2473c0=0x0;for(;_0x260b2b<_0xfd56c0['length'];){const _0x18a308=_0xfd56c0[_0x260b2b++];if(_0x18a308<0x80)_0x5e6fd0[_0x2473c0++]=String['fromCharCode'](_0x18a308);else{if(_0x18a308>0xbf&&_0x18a308<0xe0){const _0x3d568a=_0xfd56c0[_0x260b2b++];_0x5e6fd0[_0x2473c0++]=String['fromCharCode']((_0x18a308&0x1f)<<0x6|_0x3d568a&0x3f);}else{if(_0x18a308>0xef&&_0x18a308<0x16d){const _0x4e9e67=_0xfd56c0[_0x260b2b++],_0x5cc7a4=_0xfd56c0[_0x260b2b++],_0x404ca0=_0xfd56c0[_0x260b2b++],_0x13384d=((_0x18a308&0x7)<<0x12|(_0x4e9e67&0x3f)<<0xc|(_0x5cc7a4&0x3f)<<0x6|_0x404ca0&0x3f)-0x10000;_0x5e6fd0[_0x2473c0++]=String['fromCharCode'](0xd800+(_0x13384d>>0xa)),_0x5e6fd0[_0x2473c0++]=String['fromCharCode'](0xdc00+(_0x13384d&0x3ff));}else{const _0x3c593c=_0xfd56c0[_0x260b2b++],_0xfbff6=_0xfd56c0[_0x260b2b++];_0x5e6fd0[_0x2473c0++]=String['fromCharCode']((_0x18a308&0xf)<<0xc|(_0x3c593c&0x3f)<<0x6|_0xfbff6&0x3f);}}}}return _0x5e6fd0['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0xdd6b51,_0x2bd14d){if(!Array['isArray'](_0xdd6b51))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x5b0fc8=_0x2bd14d?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x43ca3b=[];for(let _0x1ee67d=0x0;_0x1ee67d<_0xdd6b51['length'];_0x1ee67d+=0x3){const _0xf429ed=_0xdd6b51[_0x1ee67d],_0x4a2741=_0x1ee67d+0x1<_0xdd6b51['length'],_0x20e7f3=_0x4a2741?_0xdd6b51[_0x1ee67d+0x1]:0x0,_0x10b97e=_0x1ee67d+0x2<_0xdd6b51['length'],_0x3bae3e=_0x10b97e?_0xdd6b51[_0x1ee67d+0x2]:0x0,_0x7583d2=_0xf429ed>>0x2,_0x332fb1=(_0xf429ed&0x3)<<0x4|_0x20e7f3>>0x4;let _0x39abd4=(_0x20e7f3&0xf)<<0x2|_0x3bae3e>>0x6,_0xbc11d7=_0x3bae3e&0x3f;_0x10b97e||(_0xbc11d7=0x40,_0x4a2741||(_0x39abd4=0x40)),_0x43ca3b['push'](_0x5b0fc8[_0x7583d2],_0x5b0fc8[_0x332fb1],_0x5b0fc8[_0x39abd4],_0x5b0fc8[_0xbc11d7]);}return _0x43ca3b['join']('');},'encodeString'(_0x26e02c,_0x44fc43){return this['HAS_NATIVE_SUPPORT']&&!_0x44fc43?btoa(_0x26e02c):this['encodeByteArray'](Vr(_0x26e02c),_0x44fc43);},'decodeString'(_0x1bc9c0,_0xf9c1c2){return this['HAS_NATIVE_SUPPORT']&&!_0xf9c1c2?atob(_0x1bc9c0):ec(this['decodeStringToByteArray'](_0x1bc9c0,_0xf9c1c2));},'decodeStringToByteArray'(_0x3ac9c1,_0x3ec717){this['init_']();const _0x25f2bb=_0x3ec717?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x13d95e=[];for(let _0x1c3fe3=0x0;_0x1c3fe3<_0x3ac9c1['length'];){const _0x296093=_0x25f2bb[_0x3ac9c1['charAt'](_0x1c3fe3++)],_0x52b068=_0x1c3fe3<_0x3ac9c1['length']?_0x25f2bb[_0x3ac9c1['charAt'](_0x1c3fe3)]:0x0;++_0x1c3fe3;const _0x49aca2=_0x1c3fe3<_0x3ac9c1['length']?_0x25f2bb[_0x3ac9c1['charAt'](_0x1c3fe3)]:0x40;++_0x1c3fe3;const _0x56a413=_0x1c3fe3<_0x3ac9c1['length']?_0x25f2bb[_0x3ac9c1['charAt'](_0x1c3fe3)]:0x40;if(++_0x1c3fe3,_0x296093==null||_0x52b068==null||_0x49aca2==null||_0x56a413==null)throw new tc();const _0x30296a=_0x296093<<0x2|_0x52b068>>0x4;if(_0x13d95e['push'](_0x30296a),_0x49aca2!==0x40){const _0x1ba5d2=_0x52b068<<0x4&0xf0|_0x49aca2>>0x2;if(_0x13d95e['push'](_0x1ba5d2),_0x56a413!==0x40){const _0x265c25=_0x49aca2<<0x6&0xc0|_0x56a413;_0x13d95e['push'](_0x265c25);}}}return _0x13d95e;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x4741a8=0x0;_0x4741a8<this['ENCODED_VALS']['length'];_0x4741a8++)this['byteToCharMap_'][_0x4741a8]=this['ENCODED_VALS']['charAt'](_0x4741a8),this['charToByteMap_'][this['byteToCharMap_'][_0x4741a8]]=_0x4741a8,this['byteToCharMapWebSafe_'][_0x4741a8]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x4741a8),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x4741a8]]=_0x4741a8,_0x4741a8>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x4741a8)]=_0x4741a8,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x4741a8)]=_0x4741a8);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x2cc0d0){const _0x323d36=Vr(_0x2cc0d0);return Li['encodeByteArray'](_0x323d36,!0x0);},cn=function(_0x33551a){return Hr(_0x33551a)['replace'](/\./g,'');},ln=function(_0x530b25){try{return Li['decodeString'](_0x530b25,!0x0);}catch(_0x92329d){console['error']('base64Decode\x20failed:\x20',_0x92329d);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x22c8ef){return $r(void 0x0,_0x22c8ef);}function $r(_0x4f2c13,_0x1a6e46){if(!(_0x1a6e46 instanceof Object))return _0x1a6e46;switch(_0x1a6e46['constructor']){case Date:const _0x105e61=_0x1a6e46;return new Date(_0x105e61['getTime']());case Object:_0x4f2c13===void 0x0&&(_0x4f2c13={});break;case Array:_0x4f2c13=[];break;default:return _0x1a6e46;}for(const _0x10dd61 in _0x1a6e46)!_0x1a6e46['hasOwnProperty'](_0x10dd61)||!ic(_0x10dd61)||(_0x4f2c13[_0x10dd61]=$r(_0x4f2c13[_0x10dd61],_0x1a6e46[_0x10dd61]));return _0x4f2c13;}function ic(_0x1d155a){return _0x1d155a!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x57721c=Ns['__FIREBASE_DEFAULTS__'];if(_0x57721c)return JSON['parse'](_0x57721c);},ac=()=>{if(typeof document>'u')return;let _0x1aeb3e;try{_0x1aeb3e=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x3e0439=_0x1aeb3e&&ln(_0x1aeb3e[0x1]);return _0x3e0439&&JSON['parse'](_0x3e0439);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x3a8947){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x3a8947);return;}},Gr=_0x3a7ad5=>{var _0x4ede88,_0x4050d0;return(_0x4050d0=(_0x4ede88=xi())==null?void 0x0:_0x4ede88['emulatorHosts'])==null?void 0x0:_0x4050d0[_0x3a7ad5];},cc=_0x1aa9f3=>{const _0x155e29=Gr(_0x1aa9f3);if(!_0x155e29)return;const _0x2adac1=_0x155e29['lastIndexOf'](':');if(_0x2adac1<=0x0||_0x2adac1+0x1===_0x155e29['length'])throw new Error('Invalid\x20host\x20'+_0x155e29+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x3c6b1f=parseInt(_0x155e29['substring'](_0x2adac1+0x1),0xa);return _0x155e29[0x0]==='['?[_0x155e29['substring'](0x1,_0x2adac1-0x1),_0x3c6b1f]:[_0x155e29['substring'](0x0,_0x2adac1),_0x3c6b1f];},qr=()=>{var _0x4c5aad;return(_0x4c5aad=xi())==null?void 0x0:_0x4c5aad['config'];},zr=_0x595261=>{var _0x4fe093;return(_0x4fe093=xi())==null?void 0x0:_0x4fe093['_'+_0x595261];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x2cffff,_0x46e199)=>{this['resolve']=_0x2cffff,this['reject']=_0x46e199;});}['wrapCallback'](_0x589053){return(_0x440322,_0x35ce82)=>{_0x440322?this['reject'](_0x440322):this['resolve'](_0x35ce82),typeof _0x589053=='function'&&(this['promise']['catch'](()=>{}),_0x589053['length']===0x1?_0x589053(_0x440322):_0x589053(_0x440322,_0x35ce82));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x821e91){try{return(_0x821e91['startsWith']('http://')||_0x821e91['startsWith']('https://')?new URL(_0x821e91)['hostname']:_0x821e91)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x88c890){return(await fetch(_0x88c890,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x27ebd1,_0x11f1eb){if(_0x27ebd1['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x75fc9d={'alg':'none','type':'JWT'},_0x3c0487=_0x11f1eb||'demo-project',_0x587d87=_0x27ebd1['iat']||0x0,_0x1a1bf1=_0x27ebd1['sub']||_0x27ebd1['user_id'];if(!_0x1a1bf1)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x8a6b7b={'iss':'https://securetoken.google.com/'+_0x3c0487,'aud':_0x3c0487,'iat':_0x587d87,'exp':_0x587d87+0xe10,'auth_time':_0x587d87,'sub':_0x1a1bf1,'user_id':_0x1a1bf1,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x27ebd1};return[cn(JSON['stringify'](_0x75fc9d)),cn(JSON['stringify'](_0x8a6b7b)),'']['join']('.');}const It={};function hc(){const _0x2e7851={'prod':[],'emulator':[]};for(const _0x1cbdac of Object['keys'](It))It[_0x1cbdac]?_0x2e7851['emulator']['push'](_0x1cbdac):_0x2e7851['prod']['push'](_0x1cbdac);return _0x2e7851;}function uc(_0x5a13af){let _0x34c5bb=document['getElementById'](_0x5a13af),_0x206754=!0x1;return _0x34c5bb||(_0x34c5bb=document['createElement']('div'),_0x34c5bb['setAttribute']('id',_0x5a13af),_0x206754=!0x0),{'created':_0x206754,'element':_0x34c5bb};}let Ps=!0x1;function Kr(_0x316351,_0x36b3a8){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x316351]===_0x36b3a8||It[_0x316351]||Ps)return;It[_0x316351]=_0x36b3a8;function _0x3786b0(_0x342c54){return'__firebase__banner__'+_0x342c54;}const _0x258609='__firebase__banner',_0x1bfaff=hc()['prod']['length']>0x0;function _0x35967d(){const _0x491476=document['getElementById'](_0x258609);_0x491476&&_0x491476['remove']();}function _0x12af92(_0x378438){_0x378438['style']['display']='flex',_0x378438['style']['background']='#7faaf0',_0x378438['style']['position']='fixed',_0x378438['style']['bottom']='5px',_0x378438['style']['left']='5px',_0x378438['style']['padding']='.5em',_0x378438['style']['borderRadius']='5px',_0x378438['style']['alignItems']='center';}function _0x160f31(_0x1daea5,_0x384e60){_0x1daea5['setAttribute']('width','24'),_0x1daea5['setAttribute']('id',_0x384e60),_0x1daea5['setAttribute']('height','24'),_0x1daea5['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x1daea5['setAttribute']('fill','none'),_0x1daea5['style']['marginLeft']='-6px';}function _0x311534(){const _0x4112ca=document['createElement']('span');return _0x4112ca['style']['cursor']='pointer',_0x4112ca['style']['marginLeft']='16px',_0x4112ca['style']['fontSize']='24px',_0x4112ca['innerHTML']='\x20&times;',_0x4112ca['onclick']=()=>{Ps=!0x0,_0x35967d();},_0x4112ca;}function _0x25f049(_0x3bca26,_0x2ecb33){_0x3bca26['setAttribute']('id',_0x2ecb33),_0x3bca26['innerText']='Learn\x20more',_0x3bca26['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x3bca26['setAttribute']('target','__blank'),_0x3bca26['style']['paddingLeft']='5px',_0x3bca26['style']['textDecoration']='underline';}function _0x2762fc(){const _0x2d93d5=uc(_0x258609),_0x292b93=_0x3786b0('text'),_0xc1053=document['getElementById'](_0x292b93)||document['createElement']('span'),_0x3557c0=_0x3786b0('learnmore'),_0x103d2d=document['getElementById'](_0x3557c0)||document['createElement']('a'),_0x302584=_0x3786b0('preprendIcon'),_0x3af420=document['getElementById'](_0x302584)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x2d93d5['created']){const _0x3f5354=_0x2d93d5['element'];_0x12af92(_0x3f5354),_0x25f049(_0x103d2d,_0x3557c0);const _0x384fd1=_0x311534();_0x160f31(_0x3af420,_0x302584),_0x3f5354['append'](_0x3af420,_0xc1053,_0x103d2d,_0x384fd1),document['body']['appendChild'](_0x3f5354);}_0x1bfaff?(_0xc1053['innerText']='Preview\x20backend\x20disconnected.',_0x3af420['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x3af420['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0xc1053['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0xc1053['setAttribute']('id',_0x292b93);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x2762fc):_0x2762fc();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x2c8b0d=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x2c8b0d=='object'&&_0x2c8b0d['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0xb28090=W();return _0xb28090['indexOf']('MSIE\x20')>=0x0||_0xb28090['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x49aa64,_0xe65f90)=>{try{let _0x180e7f=!0x0;const _0x1ffc92='validate-browser-context-for-indexeddb-analytics-module',_0xfa64f9=self['indexedDB']['open'](_0x1ffc92);_0xfa64f9['onsuccess']=()=>{_0xfa64f9['result']['close'](),_0x180e7f||self['indexedDB']['deleteDatabase'](_0x1ffc92),_0x49aa64(!0x0);},_0xfa64f9['onupgradeneeded']=()=>{_0x180e7f=!0x1;},_0xfa64f9['onerror']=()=>{var _0x1ba7a2;_0xe65f90(((_0x1ba7a2=_0xfa64f9['error'])==null?void 0x0:_0x1ba7a2['message'])||'');};}catch(_0x5c4ca6){_0xe65f90(_0x5c4ca6);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x3135d4,_0x33745a,_0x22e914){super(_0x33745a),this['code']=_0x3135d4,this['customData']=_0x22e914,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x200a65,_0x5c2e6e,_0x27aa85){this['service']=_0x200a65,this['serviceName']=_0x5c2e6e,this['errors']=_0x27aa85;}['create'](_0xd9c9a8,..._0x4db91c){const _0x2ba231=_0x4db91c[0x0]||{},_0x3a00a3=this['service']+'/'+_0xd9c9a8,_0x461844=this['errors'][_0xd9c9a8],_0x395975=_0x461844?vc(_0x461844,_0x2ba231):'Error',_0x5a2643=this['serviceName']+':\x20'+_0x395975+'\x20('+_0x3a00a3+').';return new Se(_0x3a00a3,_0x5a2643,_0x2ba231);}}function vc(_0x3cfbdc,_0x5525d6){return _0x3cfbdc['replace'](Ec,(_0x159af1,_0x48d734)=>{const _0x296b2d=_0x5525d6[_0x48d734];return _0x296b2d!=null?String(_0x296b2d):'<'+_0x48d734+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x5a2da8){return JSON['parse'](_0x5a2da8);}function O(_0x18e5a3){return JSON['stringify'](_0x18e5a3);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x5b0429){let _0x8c35ae={},_0x49731f={},_0x23295b={},_0x30137c='';try{const _0x398975=_0x5b0429['split']('.');_0x8c35ae=At(ln(_0x398975[0x0])||''),_0x49731f=At(ln(_0x398975[0x1])||''),_0x30137c=_0x398975[0x2],_0x23295b=_0x49731f['d']||{},delete _0x49731f['d'];}catch{}return{'header':_0x8c35ae,'claims':_0x49731f,'data':_0x23295b,'signature':_0x30137c};},Ic=function(_0x23d5c5){const _0x36a822=Qr(_0x23d5c5),_0x27f79e=_0x36a822['claims'];return!!_0x27f79e&&typeof _0x27f79e=='object'&&_0x27f79e['hasOwnProperty']('iat');},wc=function(_0x556244){const _0x3d9d88=Qr(_0x556244)['claims'];return typeof _0x3d9d88=='object'&&_0x3d9d88['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x59e971,_0x2c3516){return Object['prototype']['hasOwnProperty']['call'](_0x59e971,_0x2c3516);}function De(_0x28010d,_0x2cd295){if(Object['prototype']['hasOwnProperty']['call'](_0x28010d,_0x2cd295))return _0x28010d[_0x2cd295];}function ui(_0x4c9793){for(const _0x5dffc3 in _0x4c9793)if(Object['prototype']['hasOwnProperty']['call'](_0x4c9793,_0x5dffc3))return!0x1;return!0x0;}function hn(_0x3692f7,_0x557420,_0x2bc54e){const _0x8c21df={};for(const _0x571c6d in _0x3692f7)Object['prototype']['hasOwnProperty']['call'](_0x3692f7,_0x571c6d)&&(_0x8c21df[_0x571c6d]=_0x557420['call'](_0x2bc54e,_0x3692f7[_0x571c6d],_0x571c6d,_0x3692f7));return _0x8c21df;}function Me(_0xf72130,_0x585db2){if(_0xf72130===_0x585db2)return!0x0;const _0x563eb9=Object['keys'](_0xf72130),_0x8fd832=Object['keys'](_0x585db2);for(const _0x4f1412 of _0x563eb9){if(!_0x8fd832['includes'](_0x4f1412))return!0x1;const _0x4a6569=_0xf72130[_0x4f1412],_0x3ee021=_0x585db2[_0x4f1412];if(Os(_0x4a6569)&&Os(_0x3ee021)){if(!Me(_0x4a6569,_0x3ee021))return!0x1;}else{if(_0x4a6569!==_0x3ee021)return!0x1;}}for(const _0x432cd3 of _0x8fd832)if(!_0x563eb9['includes'](_0x432cd3))return!0x1;return!0x0;}function Os(_0x292f1c){return _0x292f1c!==null&&typeof _0x292f1c=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x556746){const _0x26602f=[];for(const [_0x5317e1,_0x42f0]of Object['entries'](_0x556746))Array['isArray'](_0x42f0)?_0x42f0['forEach'](_0x4eed1c=>{_0x26602f['push'](encodeURIComponent(_0x5317e1)+'='+encodeURIComponent(_0x4eed1c));}):_0x26602f['push'](encodeURIComponent(_0x5317e1)+'='+encodeURIComponent(_0x42f0));return _0x26602f['length']?'&'+_0x26602f['join']('&'):'';}function vt(_0x5cae8d){const _0xc6a8ff={};return _0x5cae8d['replace'](/^\?/,'')['split']('&')['forEach'](_0x58cf4b=>{if(_0x58cf4b){const [_0x4f0068,_0x203363]=_0x58cf4b['split']('=');_0xc6a8ff[decodeURIComponent(_0x4f0068)]=decodeURIComponent(_0x203363);}}),_0xc6a8ff;}function Et(_0x4bd09b){const _0x182a9a=_0x4bd09b['indexOf']('?');if(!_0x182a9a)return'';const _0x4e93f5=_0x4bd09b['indexOf']('#',_0x182a9a);return _0x4bd09b['substring'](_0x182a9a,_0x4e93f5>0x0?_0x4e93f5:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x53d901=0x1;_0x53d901<this['blockSize'];++_0x53d901)this['pad_'][_0x53d901]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x3fa3ec,_0xef38c5){_0xef38c5||(_0xef38c5=0x0);const _0x54b268=this['W_'];if(typeof _0x3fa3ec=='string'){for(let _0x2c4c0a=0x0;_0x2c4c0a<0x10;_0x2c4c0a++)_0x54b268[_0x2c4c0a]=_0x3fa3ec['charCodeAt'](_0xef38c5)<<0x18|_0x3fa3ec['charCodeAt'](_0xef38c5+0x1)<<0x10|_0x3fa3ec['charCodeAt'](_0xef38c5+0x2)<<0x8|_0x3fa3ec['charCodeAt'](_0xef38c5+0x3),_0xef38c5+=0x4;}else{for(let _0x57be99=0x0;_0x57be99<0x10;_0x57be99++)_0x54b268[_0x57be99]=_0x3fa3ec[_0xef38c5]<<0x18|_0x3fa3ec[_0xef38c5+0x1]<<0x10|_0x3fa3ec[_0xef38c5+0x2]<<0x8|_0x3fa3ec[_0xef38c5+0x3],_0xef38c5+=0x4;}for(let _0x3bc258=0x10;_0x3bc258<0x50;_0x3bc258++){const _0x519638=_0x54b268[_0x3bc258-0x3]^_0x54b268[_0x3bc258-0x8]^_0x54b268[_0x3bc258-0xe]^_0x54b268[_0x3bc258-0x10];_0x54b268[_0x3bc258]=(_0x519638<<0x1|_0x519638>>>0x1f)&0xffffffff;}let _0x226549=this['chain_'][0x0],_0xf76a1c=this['chain_'][0x1],_0x58ccb5=this['chain_'][0x2],_0x2e440a=this['chain_'][0x3],_0xc09d3e=this['chain_'][0x4],_0x432790,_0x33179e;for(let _0x5bb965=0x0;_0x5bb965<0x50;_0x5bb965++){_0x5bb965<0x28?_0x5bb965<0x14?(_0x432790=_0x2e440a^_0xf76a1c&(_0x58ccb5^_0x2e440a),_0x33179e=0x5a827999):(_0x432790=_0xf76a1c^_0x58ccb5^_0x2e440a,_0x33179e=0x6ed9eba1):_0x5bb965<0x3c?(_0x432790=_0xf76a1c&_0x58ccb5|_0x2e440a&(_0xf76a1c|_0x58ccb5),_0x33179e=0x8f1bbcdc):(_0x432790=_0xf76a1c^_0x58ccb5^_0x2e440a,_0x33179e=0xca62c1d6);const _0x2ed4b7=(_0x226549<<0x5|_0x226549>>>0x1b)+_0x432790+_0xc09d3e+_0x33179e+_0x54b268[_0x5bb965]&0xffffffff;_0xc09d3e=_0x2e440a,_0x2e440a=_0x58ccb5,_0x58ccb5=(_0xf76a1c<<0x1e|_0xf76a1c>>>0x2)&0xffffffff,_0xf76a1c=_0x226549,_0x226549=_0x2ed4b7;}this['chain_'][0x0]=this['chain_'][0x0]+_0x226549&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0xf76a1c&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x58ccb5&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x2e440a&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0xc09d3e&0xffffffff;}['update'](_0x562b56,_0x1d5a21){if(_0x562b56==null)return;_0x1d5a21===void 0x0&&(_0x1d5a21=_0x562b56['length']);const _0x3fe2e3=_0x1d5a21-this['blockSize'];let _0x26e6cf=0x0;const _0x116689=this['buf_'];let _0x1f6a0c=this['inbuf_'];for(;_0x26e6cf<_0x1d5a21;){if(_0x1f6a0c===0x0){for(;_0x26e6cf<=_0x3fe2e3;)this['compress_'](_0x562b56,_0x26e6cf),_0x26e6cf+=this['blockSize'];}if(typeof _0x562b56=='string'){for(;_0x26e6cf<_0x1d5a21;)if(_0x116689[_0x1f6a0c]=_0x562b56['charCodeAt'](_0x26e6cf),++_0x1f6a0c,++_0x26e6cf,_0x1f6a0c===this['blockSize']){this['compress_'](_0x116689),_0x1f6a0c=0x0;break;}}else{for(;_0x26e6cf<_0x1d5a21;)if(_0x116689[_0x1f6a0c]=_0x562b56[_0x26e6cf],++_0x1f6a0c,++_0x26e6cf,_0x1f6a0c===this['blockSize']){this['compress_'](_0x116689),_0x1f6a0c=0x0;break;}}}this['inbuf_']=_0x1f6a0c,this['total_']+=_0x1d5a21;}['digest'](){const _0x2b12ab=[];let _0x530eaf=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x47add9=this['blockSize']-0x1;_0x47add9>=0x38;_0x47add9--)this['buf_'][_0x47add9]=_0x530eaf&0xff,_0x530eaf/=0x100;this['compress_'](this['buf_']);let _0x51146c=0x0;for(let _0x280f4a=0x0;_0x280f4a<0x5;_0x280f4a++)for(let _0x16344a=0x18;_0x16344a>=0x0;_0x16344a-=0x8)_0x2b12ab[_0x51146c]=this['chain_'][_0x280f4a]>>_0x16344a&0xff,++_0x51146c;return _0x2b12ab;}}function Tc(_0x4c1fe7,_0x1cf3f8){const _0x33da6b=new Sc(_0x4c1fe7,_0x1cf3f8);return _0x33da6b['subscribe']['bind'](_0x33da6b);}class Sc{constructor(_0x4f9fe2,_0x4629fb){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x4629fb,this['task']['then'](()=>{_0x4f9fe2(this);})['catch'](_0x20afe9=>{this['error'](_0x20afe9);});}['next'](_0xcacd2a){this['forEachObserver'](_0x4f5bff=>{_0x4f5bff['next'](_0xcacd2a);});}['error'](_0x3d32d9){this['forEachObserver'](_0xea13b1=>{_0xea13b1['error'](_0x3d32d9);}),this['close'](_0x3d32d9);}['complete'](){this['forEachObserver'](_0x750334=>{_0x750334['complete']();}),this['close']();}['subscribe'](_0x16e3cc,_0x22636d,_0x49252c){let _0x1f93bc;if(_0x16e3cc===void 0x0&&_0x22636d===void 0x0&&_0x49252c===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x16e3cc,['next','error','complete'])?_0x1f93bc=_0x16e3cc:_0x1f93bc={'next':_0x16e3cc,'error':_0x22636d,'complete':_0x49252c},_0x1f93bc['next']===void 0x0&&(_0x1f93bc['next']=Jn),_0x1f93bc['error']===void 0x0&&(_0x1f93bc['error']=Jn),_0x1f93bc['complete']===void 0x0&&(_0x1f93bc['complete']=Jn);const _0x2af4ab=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x1f93bc['error'](this['finalError']):_0x1f93bc['complete']();}catch{}}),this['observers']['push'](_0x1f93bc),_0x2af4ab;}['unsubscribeOne'](_0xb3e221){this['observers']===void 0x0||this['observers'][_0xb3e221]===void 0x0||(delete this['observers'][_0xb3e221],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x81b106){if(!this['finalized']){for(let _0xa438d9=0x0;_0xa438d9<this['observers']['length'];_0xa438d9++)this['sendOne'](_0xa438d9,_0x81b106);}}['sendOne'](_0x1a0a66,_0x5a697a){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x1a0a66]!==void 0x0)try{_0x5a697a(this['observers'][_0x1a0a66]);}catch(_0x4b9594){typeof console<'u'&&console['error']&&console['error'](_0x4b9594);}});}['close'](_0x5e45cf){this['finalized']||(this['finalized']=!0x0,_0x5e45cf!==void 0x0&&(this['finalError']=_0x5e45cf),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0xb702db,_0x3704af){if(typeof _0xb702db!='object'||_0xb702db===null)return!0x1;for(const _0x3b2f6e of _0x3704af)if(_0x3b2f6e in _0xb702db&&typeof _0xb702db[_0x3b2f6e]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x21b0a8,_0x561388){return _0x21b0a8+'\x20failed:\x20'+_0x561388+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x5db201){const _0x3d1f09=[];let _0x22ec6d=0x0;for(let _0x43061d=0x0;_0x43061d<_0x5db201['length'];_0x43061d++){let _0x129ca3=_0x5db201['charCodeAt'](_0x43061d);if(_0x129ca3>=0xd800&&_0x129ca3<=0xdbff){const _0x54eba0=_0x129ca3-0xd800;_0x43061d++,f(_0x43061d<_0x5db201['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x18c8ef=_0x5db201['charCodeAt'](_0x43061d)-0xdc00;_0x129ca3=0x10000+(_0x54eba0<<0xa)+_0x18c8ef;}_0x129ca3<0x80?_0x3d1f09[_0x22ec6d++]=_0x129ca3:_0x129ca3<0x800?(_0x3d1f09[_0x22ec6d++]=_0x129ca3>>0x6|0xc0,_0x3d1f09[_0x22ec6d++]=_0x129ca3&0x3f|0x80):_0x129ca3<0x10000?(_0x3d1f09[_0x22ec6d++]=_0x129ca3>>0xc|0xe0,_0x3d1f09[_0x22ec6d++]=_0x129ca3>>0x6&0x3f|0x80,_0x3d1f09[_0x22ec6d++]=_0x129ca3&0x3f|0x80):(_0x3d1f09[_0x22ec6d++]=_0x129ca3>>0x12|0xf0,_0x3d1f09[_0x22ec6d++]=_0x129ca3>>0xc&0x3f|0x80,_0x3d1f09[_0x22ec6d++]=_0x129ca3>>0x6&0x3f|0x80,_0x3d1f09[_0x22ec6d++]=_0x129ca3&0x3f|0x80);}return _0x3d1f09;},On=function(_0x2d5185){let _0x3d6aee=0x0;for(let _0xb321cd=0x0;_0xb321cd<_0x2d5185['length'];_0xb321cd++){const _0x2420ae=_0x2d5185['charCodeAt'](_0xb321cd);_0x2420ae<0x80?_0x3d6aee++:_0x2420ae<0x800?_0x3d6aee+=0x2:_0x2420ae>=0xd800&&_0x2420ae<=0xdbff?(_0x3d6aee+=0x4,_0xb321cd++):_0x3d6aee+=0x3;}return _0x3d6aee;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0xc52c25){return _0xc52c25&&_0xc52c25['_delegate']?_0xc52c25['_delegate']:_0xc52c25;}class Le{constructor(_0x4fc14c,_0xbb2f15,_0x27955e){this['name']=_0x4fc14c,this['instanceFactory']=_0xbb2f15,this['type']=_0x27955e,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x4252a8){return this['instantiationMode']=_0x4252a8,this;}['setMultipleInstances'](_0xcb3f76){return this['multipleInstances']=_0xcb3f76,this;}['setServiceProps'](_0x39afa1){return this['serviceProps']=_0x39afa1,this;}['setInstanceCreatedCallback'](_0x3199a0){return this['onInstanceCreated']=_0x3199a0,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x55ac06,_0x4747c2){this['name']=_0x55ac06,this['container']=_0x4747c2,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x4d43d4){const _0x2128e4=this['normalizeInstanceIdentifier'](_0x4d43d4);if(!this['instancesDeferred']['has'](_0x2128e4)){const _0x446723=new ot();if(this['instancesDeferred']['set'](_0x2128e4,_0x446723),this['isInitialized'](_0x2128e4)||this['shouldAutoInitialize']())try{const _0x54bb2c=this['getOrInitializeService']({'instanceIdentifier':_0x2128e4});_0x54bb2c&&_0x446723['resolve'](_0x54bb2c);}catch{}}return this['instancesDeferred']['get'](_0x2128e4)['promise'];}['getImmediate'](_0x7fb98b){const _0x32fe6c=this['normalizeInstanceIdentifier'](_0x7fb98b==null?void 0x0:_0x7fb98b['identifier']),_0xe453f5=(_0x7fb98b==null?void 0x0:_0x7fb98b['optional'])??!0x1;if(this['isInitialized'](_0x32fe6c)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x32fe6c});}catch(_0x3dc87a){if(_0xe453f5)return null;throw _0x3dc87a;}else{if(_0xe453f5)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x17aab6){if(_0x17aab6['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x17aab6['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x17aab6,!!this['shouldAutoInitialize']()){if(Nc(_0x17aab6))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x3d9302,_0x354be9]of this['instancesDeferred']['entries']()){const _0x210bcf=this['normalizeInstanceIdentifier'](_0x3d9302);try{const _0x1ea089=this['getOrInitializeService']({'instanceIdentifier':_0x210bcf});_0x354be9['resolve'](_0x1ea089);}catch{}}}}['clearInstance'](_0x13841f=Ne){this['instancesDeferred']['delete'](_0x13841f),this['instancesOptions']['delete'](_0x13841f),this['instances']['delete'](_0x13841f);}async['delete'](){const _0x5d7dfd=Array['from'](this['instances']['values']());await Promise['all']([..._0x5d7dfd['filter'](_0x3c364a=>'INTERNAL'in _0x3c364a)['map'](_0xdc3349=>_0xdc3349['INTERNAL']['delete']()),..._0x5d7dfd['filter'](_0x2a3600=>'_delete'in _0x2a3600)['map'](_0x12680a=>_0x12680a['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x3e75ea=Ne){return this['instances']['has'](_0x3e75ea);}['getOptions'](_0x342055=Ne){return this['instancesOptions']['get'](_0x342055)||{};}['initialize'](_0x26a173={}){const {options:_0x1c804f={}}=_0x26a173,_0xea9c1e=this['normalizeInstanceIdentifier'](_0x26a173['instanceIdentifier']);if(this['isInitialized'](_0xea9c1e))throw Error(this['name']+'('+_0xea9c1e+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x29cea7=this['getOrInitializeService']({'instanceIdentifier':_0xea9c1e,'options':_0x1c804f});for(const [_0x510f6a,_0x5c58f1]of this['instancesDeferred']['entries']()){const _0x16b26a=this['normalizeInstanceIdentifier'](_0x510f6a);_0xea9c1e===_0x16b26a&&_0x5c58f1['resolve'](_0x29cea7);}return _0x29cea7;}['onInit'](_0xa6eab4,_0xa77f18){const _0x4fe09e=this['normalizeInstanceIdentifier'](_0xa77f18),_0x1f8317=this['onInitCallbacks']['get'](_0x4fe09e)??new Set();_0x1f8317['add'](_0xa6eab4),this['onInitCallbacks']['set'](_0x4fe09e,_0x1f8317);const _0x986b1a=this['instances']['get'](_0x4fe09e);return _0x986b1a&&_0xa6eab4(_0x986b1a,_0x4fe09e),()=>{_0x1f8317['delete'](_0xa6eab4);};}['invokeOnInitCallbacks'](_0x2251fd,_0x47402a){const _0xd6f968=this['onInitCallbacks']['get'](_0x47402a);if(_0xd6f968){for(const _0x68bf92 of _0xd6f968)try{_0x68bf92(_0x2251fd,_0x47402a);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x5731cc,options:_0xc2b872={}}){let _0x2cc616=this['instances']['get'](_0x5731cc);if(!_0x2cc616&&this['component']&&(_0x2cc616=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x5731cc),'options':_0xc2b872}),this['instances']['set'](_0x5731cc,_0x2cc616),this['instancesOptions']['set'](_0x5731cc,_0xc2b872),this['invokeOnInitCallbacks'](_0x2cc616,_0x5731cc),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x5731cc,_0x2cc616);}catch{}return _0x2cc616||null;}['normalizeInstanceIdentifier'](_0x256b94=Ne){return this['component']?this['component']['multipleInstances']?_0x256b94:Ne:_0x256b94;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x13e363){return _0x13e363===Ne?void 0x0:_0x13e363;}function Nc(_0x58b2f6){return _0x58b2f6['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x1dfa6b){this['name']=_0x1dfa6b,this['providers']=new Map();}['addComponent'](_0x1e6275){const _0x1de243=this['getProvider'](_0x1e6275['name']);if(_0x1de243['isComponentSet']())throw new Error('Component\x20'+_0x1e6275['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x1de243['setComponent'](_0x1e6275);}['addOrOverwriteComponent'](_0x2c7bb8){this['getProvider'](_0x2c7bb8['name'])['isComponentSet']()&&this['providers']['delete'](_0x2c7bb8['name']),this['addComponent'](_0x2c7bb8);}['getProvider'](_0x371cb7){if(this['providers']['has'](_0x371cb7))return this['providers']['get'](_0x371cb7);const _0x5e9c32=new Ac(_0x371cb7,this);return this['providers']['set'](_0x371cb7,_0x5e9c32),_0x5e9c32;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x348f55){_0x348f55[_0x348f55['DEBUG']=0x0]='DEBUG',_0x348f55[_0x348f55['VERBOSE']=0x1]='VERBOSE',_0x348f55[_0x348f55['INFO']=0x2]='INFO',_0x348f55[_0x348f55['WARN']=0x3]='WARN',_0x348f55[_0x348f55['ERROR']=0x4]='ERROR',_0x348f55[_0x348f55['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x29876a,_0x4ca04a,..._0x4910b1)=>{if(_0x4ca04a<_0x29876a['logLevel'])return;const _0x3b3f61=new Date()['toISOString'](),_0x55ce34=Mc[_0x4ca04a];if(_0x55ce34)console[_0x55ce34]('['+_0x3b3f61+']\x20\x20'+_0x29876a['name']+':',..._0x4910b1);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x4ca04a+')');};class Ui{constructor(_0x53b832){this['name']=_0x53b832,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x32d810){if(!(_0x32d810 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x32d810+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x32d810;}['setLogLevel'](_0x4e625d){this['_logLevel']=typeof _0x4e625d=='string'?Oc[_0x4e625d]:_0x4e625d;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x537e28){if(typeof _0x537e28!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x537e28;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0xd79318){this['_userLogHandler']=_0xd79318;}['debug'](..._0x1d6af9){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x1d6af9),this['_logHandler'](this,T['DEBUG'],..._0x1d6af9);}['log'](..._0x1c5742){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x1c5742),this['_logHandler'](this,T['VERBOSE'],..._0x1c5742);}['info'](..._0xea0e19){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0xea0e19),this['_logHandler'](this,T['INFO'],..._0xea0e19);}['warn'](..._0x2b9278){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x2b9278),this['_logHandler'](this,T['WARN'],..._0x2b9278);}['error'](..._0x393ed4){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x393ed4),this['_logHandler'](this,T['ERROR'],..._0x393ed4);}}const xc=(_0x4e5496,_0x6106fa)=>_0x6106fa['some'](_0x5d5851=>_0x4e5496 instanceof _0x5d5851);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x2a3c60){const _0x2dbda2=new Promise((_0x2acffd,_0x13cb91)=>{const _0x4426f8=()=>{_0x2a3c60['removeEventListener']('success',_0x1f72e7),_0x2a3c60['removeEventListener']('error',_0x2025ac);},_0x1f72e7=()=>{_0x2acffd(_e(_0x2a3c60['result'])),_0x4426f8();},_0x2025ac=()=>{_0x13cb91(_0x2a3c60['error']),_0x4426f8();};_0x2a3c60['addEventListener']('success',_0x1f72e7),_0x2a3c60['addEventListener']('error',_0x2025ac);});return _0x2dbda2['then'](_0xbcbe47=>{_0xbcbe47 instanceof IDBCursor&&Jr['set'](_0xbcbe47,_0x2a3c60);})['catch'](()=>{}),Wi['set'](_0x2dbda2,_0x2a3c60),_0x2dbda2;}function Bc(_0x4d63d3){if(di['has'](_0x4d63d3))return;const _0x119c03=new Promise((_0x1a252a,_0x5122b1)=>{const _0x3a115f=()=>{_0x4d63d3['removeEventListener']('complete',_0x4156e4),_0x4d63d3['removeEventListener']('error',_0x37a6a0),_0x4d63d3['removeEventListener']('abort',_0x37a6a0);},_0x4156e4=()=>{_0x1a252a(),_0x3a115f();},_0x37a6a0=()=>{_0x5122b1(_0x4d63d3['error']||new DOMException('AbortError','AbortError')),_0x3a115f();};_0x4d63d3['addEventListener']('complete',_0x4156e4),_0x4d63d3['addEventListener']('error',_0x37a6a0),_0x4d63d3['addEventListener']('abort',_0x37a6a0);});di['set'](_0x4d63d3,_0x119c03);}let fi={'get'(_0x42fb92,_0x1f9b0e,_0x380bcf){if(_0x42fb92 instanceof IDBTransaction){if(_0x1f9b0e==='done')return di['get'](_0x42fb92);if(_0x1f9b0e==='objectStoreNames')return _0x42fb92['objectStoreNames']||Xr['get'](_0x42fb92);if(_0x1f9b0e==='store')return _0x380bcf['objectStoreNames'][0x1]?void 0x0:_0x380bcf['objectStore'](_0x380bcf['objectStoreNames'][0x0]);}return _e(_0x42fb92[_0x1f9b0e]);},'set'(_0x17ace3,_0x392e79,_0x29c739){return _0x17ace3[_0x392e79]=_0x29c739,!0x0;},'has'(_0x37fae8,_0x2962f0){return _0x37fae8 instanceof IDBTransaction&&(_0x2962f0==='done'||_0x2962f0==='store')?!0x0:_0x2962f0 in _0x37fae8;}};function Vc(_0x3db38a){fi=_0x3db38a(fi);}function Hc(_0x375da5){return _0x375da5===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x3f450c,..._0x491f96){const _0x585d78=_0x375da5['call'](Zn(this),_0x3f450c,..._0x491f96);return Xr['set'](_0x585d78,_0x3f450c['sort']?_0x3f450c['sort']():[_0x3f450c]),_e(_0x585d78);}:Uc()['includes'](_0x375da5)?function(..._0xc92975){return _0x375da5['apply'](Zn(this),_0xc92975),_e(Jr['get'](this));}:function(..._0x1b5bea){return _e(_0x375da5['apply'](Zn(this),_0x1b5bea));};}function $c(_0x50fb94){return typeof _0x50fb94=='function'?Hc(_0x50fb94):(_0x50fb94 instanceof IDBTransaction&&Bc(_0x50fb94),xc(_0x50fb94,Fc())?new Proxy(_0x50fb94,fi):_0x50fb94);}function _e(_0x30b61b){if(_0x30b61b instanceof IDBRequest)return Wc(_0x30b61b);if(Xn['has'](_0x30b61b))return Xn['get'](_0x30b61b);const _0x350dfc=$c(_0x30b61b);return _0x350dfc!==_0x30b61b&&(Xn['set'](_0x30b61b,_0x350dfc),Wi['set'](_0x350dfc,_0x30b61b)),_0x350dfc;}const Zn=_0x331d41=>Wi['get'](_0x331d41);function Gc(_0x4430b2,_0x1327d7,{blocked:_0x3241de,upgrade:_0x4e088a,blocking:_0x4380fb,terminated:_0x31d5bc}={}){const _0x23e191=indexedDB['open'](_0x4430b2,_0x1327d7),_0x3c95a3=_e(_0x23e191);return _0x4e088a&&_0x23e191['addEventListener']('upgradeneeded',_0x2e2076=>{_0x4e088a(_e(_0x23e191['result']),_0x2e2076['oldVersion'],_0x2e2076['newVersion'],_e(_0x23e191['transaction']),_0x2e2076);}),_0x3241de&&_0x23e191['addEventListener']('blocked',_0x5ebb03=>_0x3241de(_0x5ebb03['oldVersion'],_0x5ebb03['newVersion'],_0x5ebb03)),_0x3c95a3['then'](_0xfa2b00=>{_0x31d5bc&&_0xfa2b00['addEventListener']('close',()=>_0x31d5bc()),_0x4380fb&&_0xfa2b00['addEventListener']('versionchange',_0x2d5a8c=>_0x4380fb(_0x2d5a8c['oldVersion'],_0x2d5a8c['newVersion'],_0x2d5a8c));})['catch'](()=>{}),_0x3c95a3;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x1ed89e,_0x5dd8cb){if(!(_0x1ed89e instanceof IDBDatabase&&!(_0x5dd8cb in _0x1ed89e)&&typeof _0x5dd8cb=='string'))return;if(ei['get'](_0x5dd8cb))return ei['get'](_0x5dd8cb);const _0x2dfb3c=_0x5dd8cb['replace'](/FromIndex$/,''),_0x54b3bd=_0x5dd8cb!==_0x2dfb3c,_0x59f267=zc['includes'](_0x2dfb3c);if(!(_0x2dfb3c in(_0x54b3bd?IDBIndex:IDBObjectStore)['prototype'])||!(_0x59f267||qc['includes'](_0x2dfb3c)))return;const _0x3f7933=async function(_0x2edc7e,..._0x2d092e){const _0x210340=this['transaction'](_0x2edc7e,_0x59f267?'readwrite':'readonly');let _0x5414fd=_0x210340['store'];return _0x54b3bd&&(_0x5414fd=_0x5414fd['index'](_0x2d092e['shift']())),(await Promise['all']([_0x5414fd[_0x2dfb3c](..._0x2d092e),_0x59f267&&_0x210340['done']]))[0x0];};return ei['set'](_0x5dd8cb,_0x3f7933),_0x3f7933;}Vc(_0x4545bb=>({..._0x4545bb,'get':(_0x1754e9,_0x38e23e,_0x19c350)=>Ls(_0x1754e9,_0x38e23e)||_0x4545bb['get'](_0x1754e9,_0x38e23e,_0x19c350),'has':(_0x1945b0,_0x17290a)=>!!Ls(_0x1945b0,_0x17290a)||_0x4545bb['has'](_0x1945b0,_0x17290a)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x6c03d4){this['container']=_0x6c03d4;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x284742=>{if(Kc(_0x284742)){const _0x18dd2b=_0x284742['getImmediate']();return _0x18dd2b['library']+'/'+_0x18dd2b['version'];}else return null;})['filter'](_0x260151=>_0x260151)['join']('\x20');}}function Kc(_0x402ab3){const _0x55bb12=_0x402ab3['getComponent']();return(_0x55bb12==null?void 0x0:_0x55bb12['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x419ff4,_0x326c22){try{_0x419ff4['container']['addComponent'](_0x326c22);}catch(_0x3f09de){oe['debug']('Component\x20'+_0x326c22['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x419ff4['name'],_0x3f09de);}}function Ze(_0x3867c0){const _0x230a02=_0x3867c0['name'];if(mi['has'](_0x230a02))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x230a02+'.'),!0x1;mi['set'](_0x230a02,_0x3867c0);for(const _0xd6f3e5 of xe['values']())Fs(_0xd6f3e5,_0x3867c0);for(const _0x415c25 of gi['values']())Fs(_0x415c25,_0x3867c0);return!0x0;}function Bi(_0x550905,_0xf0c9bb){const _0xa07558=_0x550905['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0xa07558&&_0xa07558['triggerHeartbeat'](),_0x550905['container']['getProvider'](_0xf0c9bb);}function $(_0x2e0b3e){return _0x2e0b3e==null?!0x1:_0x2e0b3e['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x56b3fc,_0x3bab0b,_0xcef7f7){this['_isDeleted']=!0x1,this['_options']={..._0x56b3fc},this['_config']={..._0x3bab0b},this['_name']=_0x3bab0b['name'],this['_automaticDataCollectionEnabled']=_0x3bab0b['automaticDataCollectionEnabled'],this['_container']=_0xcef7f7,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x4a314e){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x4a314e;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x412bb3){this['_isDeleted']=_0x412bb3;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x27b980,_0x5260d7={}){let _0x2a0ca2=_0x27b980;typeof _0x5260d7!='object'&&(_0x5260d7={'name':_0x5260d7});const _0x574ab7={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x5260d7},_0x1ab73e=_0x574ab7['name'];if(typeof _0x1ab73e!='string'||!_0x1ab73e)throw ge['create']('bad-app-name',{'appName':String(_0x1ab73e)});if(_0x2a0ca2||(_0x2a0ca2=qr()),!_0x2a0ca2)throw ge['create']('no-options');const _0x1dae31=xe['get'](_0x1ab73e);if(_0x1dae31){if(Me(_0x2a0ca2,_0x1dae31['options'])&&Me(_0x574ab7,_0x1dae31['config']))return _0x1dae31;throw ge['create']('duplicate-app',{'appName':_0x1ab73e});}const _0x4e3586=new Pc(_0x1ab73e);for(const _0x5d02b9 of mi['values']())_0x4e3586['addComponent'](_0x5d02b9);const _0x1d914b=new Tl(_0x2a0ca2,_0x574ab7,_0x4e3586);return xe['set'](_0x1ab73e,_0x1d914b),_0x1d914b;}function Zr(_0x5a8de9=_i){const _0xa6bfb1=xe['get'](_0x5a8de9);if(!_0xa6bfb1&&_0x5a8de9===_i&&qr())return Sl();if(!_0xa6bfb1)throw ge['create']('no-app',{'appName':_0x5a8de9});return _0xa6bfb1;}function f_(){return Array['from'](xe['values']());}async function p_(_0x16ad43){let _0x2cc980=!0x1;const _0x1ec89e=_0x16ad43['name'];xe['has'](_0x1ec89e)?(_0x2cc980=!0x0,xe['delete'](_0x1ec89e)):gi['has'](_0x1ec89e)&&_0x16ad43['decRefCount']()<=0x0&&(gi['delete'](_0x1ec89e),_0x2cc980=!0x0),_0x2cc980&&(await Promise['all'](_0x16ad43['container']['getProviders']()['map'](_0x2224d7=>_0x2224d7['delete']())),_0x16ad43['isDeleted']=!0x0);}function me(_0x432002,_0x5d3966,_0x338138){let _0x5c7bb7=wl[_0x432002]??_0x432002;_0x338138&&(_0x5c7bb7+='-'+_0x338138);const _0x56fb02=_0x5c7bb7['match'](/\s|\//),_0x47fda6=_0x5d3966['match'](/\s|\//);if(_0x56fb02||_0x47fda6){const _0x2e91a7=['Unable\x20to\x20register\x20library\x20\x22'+_0x5c7bb7+'\x22\x20with\x20version\x20\x22'+_0x5d3966+'\x22:'];_0x56fb02&&_0x2e91a7['push']('library\x20name\x20\x22'+_0x5c7bb7+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x56fb02&&_0x47fda6&&_0x2e91a7['push']('and'),_0x47fda6&&_0x2e91a7['push']('version\x20name\x20\x22'+_0x5d3966+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x2e91a7['join']('\x20'));return;}Ze(new Le(_0x5c7bb7+'-version',()=>({'library':_0x5c7bb7,'version':_0x5d3966}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x4951d8,_0x177ec5)=>{switch(_0x177ec5){case 0x0:try{_0x4951d8['createObjectStore'](kt);}catch(_0x60d76f){console['warn'](_0x60d76f);}}}})['catch'](_0x1b80e3=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x1b80e3['message']});})),ti;}async function Al(_0x10338f){try{const _0x41a082=(await eo())['transaction'](kt),_0x181508=await _0x41a082['objectStore'](kt)['get'](to(_0x10338f));return await _0x41a082['done'],_0x181508;}catch(_0x2707b4){if(_0x2707b4 instanceof Se)oe['warn'](_0x2707b4['message']);else{const _0xb4059e=ge['create']('idb-get',{'originalErrorMessage':_0x2707b4==null?void 0x0:_0x2707b4['message']});oe['warn'](_0xb4059e['message']);}}}async function Us(_0x460b1a,_0xee2494){try{const _0x35732a=(await eo())['transaction'](kt,'readwrite');await _0x35732a['objectStore'](kt)['put'](_0xee2494,to(_0x460b1a)),await _0x35732a['done'];}catch(_0x8dd0e0){if(_0x8dd0e0 instanceof Se)oe['warn'](_0x8dd0e0['message']);else{const _0x50cb0c=ge['create']('idb-set',{'originalErrorMessage':_0x8dd0e0==null?void 0x0:_0x8dd0e0['message']});oe['warn'](_0x50cb0c['message']);}}}function to(_0x37ab36){return _0x37ab36['name']+'!'+_0x37ab36['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x1dd5ae){this['container']=_0x1dd5ae,this['_heartbeatsCache']=null;const _0x3620ad=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x3620ad),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0xf9ee8f=>(this['_heartbeatsCache']=_0xf9ee8f,_0xf9ee8f));}async['triggerHeartbeat'](){var _0x13ef4b,_0x2819b6;try{const _0x413189=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x2c5c24=Ws();if(((_0x13ef4b=this['_heartbeatsCache'])==null?void 0x0:_0x13ef4b['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x2819b6=this['_heartbeatsCache'])==null?void 0x0:_0x2819b6['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x2c5c24||this['_heartbeatsCache']['heartbeats']['some'](_0x3f2d45=>_0x3f2d45['date']===_0x2c5c24))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x2c5c24,'agent':_0x413189}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x435e57=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x435e57,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0xabb451){oe['warn'](_0xabb451);}}async['getHeartbeatsHeader'](){var _0x40d636;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x40d636=this['_heartbeatsCache'])==null?void 0x0:_0x40d636['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x16e47c=Ws(),{heartbeatsToSend:_0x5e1daa,unsentEntries:_0x312cd3}=Ol(this['_heartbeatsCache']['heartbeats']),_0x3aedc8=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x5e1daa}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x16e47c,_0x312cd3['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x312cd3,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x3aedc8;}catch(_0xd55d58){return oe['warn'](_0xd55d58),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x61ea8e,_0x29b0ea=kl){const _0x1555bf=[];let _0x529a4a=_0x61ea8e['slice']();for(const _0xd090c0 of _0x61ea8e){const _0x22dfeb=_0x1555bf['find'](_0x16d89d=>_0x16d89d['agent']===_0xd090c0['agent']);if(_0x22dfeb){if(_0x22dfeb['dates']['push'](_0xd090c0['date']),Bs(_0x1555bf)>_0x29b0ea){_0x22dfeb['dates']['pop']();break;}}else{if(_0x1555bf['push']({'agent':_0xd090c0['agent'],'dates':[_0xd090c0['date']]}),Bs(_0x1555bf)>_0x29b0ea){_0x1555bf['pop']();break;}}_0x529a4a=_0x529a4a['slice'](0x1);}return{'heartbeatsToSend':_0x1555bf,'unsentEntries':_0x529a4a};}class Dl{constructor(_0x3b50d7){this['app']=_0x3b50d7,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x3ccecd=await Al(this['app']);return _0x3ccecd!=null&&_0x3ccecd['heartbeats']?_0x3ccecd:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x179228){if(await this['_canUseIndexedDBPromise']){const _0x853f77=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x179228['lastSentHeartbeatDate']??_0x853f77['lastSentHeartbeatDate'],'heartbeats':_0x179228['heartbeats']});}else return;}async['add'](_0x35c1c4){if(await this['_canUseIndexedDBPromise']){const _0x28169a=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x35c1c4['lastSentHeartbeatDate']??_0x28169a['lastSentHeartbeatDate'],'heartbeats':[..._0x28169a['heartbeats'],..._0x35c1c4['heartbeats']]});}else return;}}function Bs(_0x1acb5c){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x1acb5c}))['length'];}function Ml(_0x2ee162){if(_0x2ee162['length']===0x0)return-0x1;let _0x124359=0x0,_0x19e844=_0x2ee162[0x0]['date'];for(let _0x228068=0x1;_0x228068<_0x2ee162['length'];_0x228068++)_0x2ee162[_0x228068]['date']<_0x19e844&&(_0x19e844=_0x2ee162[_0x228068]['date'],_0x124359=_0x228068);return _0x124359;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x97fe96){Ze(new Le('platform-logger',_0x1c994c=>new jc(_0x1c994c),'PRIVATE')),Ze(new Le('heartbeat',_0x2336a1=>new Pl(_0x2336a1),'PRIVATE')),me(pi,xs,_0x97fe96),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0xa374d2){no=_0xa374d2;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x5ce026){this['domStorage_']=_0x5ce026,this['prefix_']='firebase:';}['set'](_0x1a7a88,_0x2db428){_0x2db428==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x1a7a88)):this['domStorage_']['setItem'](this['prefixedName_'](_0x1a7a88),O(_0x2db428));}['get'](_0x2c6ecb){const _0x340d07=this['domStorage_']['getItem'](this['prefixedName_'](_0x2c6ecb));return _0x340d07==null?null:At(_0x340d07);}['remove'](_0xccac73){this['domStorage_']['removeItem'](this['prefixedName_'](_0xccac73));}['prefixedName_'](_0xa07bfa){return this['prefix_']+_0xa07bfa;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x4edcb2,_0x3c374c){_0x3c374c==null?delete this['cache_'][_0x4edcb2]:this['cache_'][_0x4edcb2]=_0x3c374c;}['get'](_0x28ea4c){return J(this['cache_'],_0x28ea4c)?this['cache_'][_0x28ea4c]:null;}['remove'](_0x5e1258){delete this['cache_'][_0x5e1258];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x2031de){try{if(typeof window<'u'&&typeof window[_0x2031de]<'u'){const _0x39cda1=window[_0x2031de];return _0x39cda1['setItem']('firebase:sentinel','cache'),_0x39cda1['removeItem']('firebase:sentinel'),new Wl(_0x39cda1);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x162286=0x1;return function(){return _0x162286++;};}()),ro=function(_0x3dfccd){const _0x945a60=Rc(_0x3dfccd),_0x4b4ecc=new Cc();_0x4b4ecc['update'](_0x945a60);const _0x2da1a2=_0x4b4ecc['digest']();return Li['encodeByteArray'](_0x2da1a2);},Vt=function(..._0x59effd){let _0x26953a='';for(let _0x104a7c=0x0;_0x104a7c<_0x59effd['length'];_0x104a7c++){const _0x3195d4=_0x59effd[_0x104a7c];Array['isArray'](_0x3195d4)||_0x3195d4&&typeof _0x3195d4=='object'&&typeof _0x3195d4['length']=='number'?_0x26953a+=Vt['apply'](null,_0x3195d4):typeof _0x3195d4=='object'?_0x26953a+=O(_0x3195d4):_0x26953a+=_0x3195d4,_0x26953a+='\x20';}return _0x26953a;};let wt=null,Gs=!0x0;const Hl=function(_0x3d3a42,_0xd14d88){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x477e44){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x2752b3=Vt['apply'](null,_0x477e44);wt(_0x2752b3);}},Ht=function(_0x244a51){return function(..._0x5bdaf7){L(_0x244a51,..._0x5bdaf7);};},yi=function(..._0x3d191e){const _0x365414='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x3d191e);Ye['error'](_0x365414);},ae=function(..._0x43cca5){const _0x1a042f='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x43cca5);throw Ye['error'](_0x1a042f),new Error(_0x1a042f);},U=function(..._0xe63a9d){const _0x4f87fe='FIREBASE\x20WARNING:\x20'+Vt(..._0xe63a9d);Ye['warn'](_0x4f87fe);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x498c98){return typeof _0x498c98=='number'&&(_0x498c98!==_0x498c98||_0x498c98===Number['POSITIVE_INFINITY']||_0x498c98===Number['NEGATIVE_INFINITY']);},Gl=function(_0x2e370d){if(document['readyState']==='complete')_0x2e370d();else{let _0x12284e=!0x1;const _0x3b01e4=function(){if(!document['body']){setTimeout(_0x3b01e4,Math['floor'](0xa));return;}_0x12284e||(_0x12284e=!0x0,_0x2e370d());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x3b01e4,!0x1),window['addEventListener']('load',_0x3b01e4,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x3b01e4();}),window['attachEvent']('onload',_0x3b01e4));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x48e2a1,_0x5074c5){if(_0x48e2a1===_0x5074c5)return 0x0;if(_0x48e2a1===Fe||_0x5074c5===Ie)return-0x1;if(_0x5074c5===Fe||_0x48e2a1===Ie)return 0x1;{const _0x49ad85=qs(_0x48e2a1),_0x3a3784=qs(_0x5074c5);return _0x49ad85!==null?_0x3a3784!==null?_0x49ad85-_0x3a3784===0x0?_0x48e2a1['length']-_0x5074c5['length']:_0x49ad85-_0x3a3784:-0x1:_0x3a3784!==null?0x1:_0x48e2a1<_0x5074c5?-0x1:0x1;}},ql=function(_0x131f7b,_0x4dbf9a){return _0x131f7b===_0x4dbf9a?0x0:_0x131f7b<_0x4dbf9a?-0x1:0x1;},_t=function(_0x2d9a3e,_0xbf9e25){if(_0xbf9e25&&_0x2d9a3e in _0xbf9e25)return _0xbf9e25[_0x2d9a3e];throw new Error('Missing\x20required\x20key\x20('+_0x2d9a3e+')\x20in\x20object:\x20'+O(_0xbf9e25));},Hi=function(_0x352299){if(typeof _0x352299!='object'||_0x352299===null)return O(_0x352299);const _0x27a422=[];for(const _0x5be8ee in _0x352299)_0x27a422['push'](_0x5be8ee);_0x27a422['sort']();let _0x29e4c0='{';for(let _0x1e10a4=0x0;_0x1e10a4<_0x27a422['length'];_0x1e10a4++)_0x1e10a4!==0x0&&(_0x29e4c0+=','),_0x29e4c0+=O(_0x27a422[_0x1e10a4]),_0x29e4c0+=':',_0x29e4c0+=Hi(_0x352299[_0x27a422[_0x1e10a4]]);return _0x29e4c0+='}',_0x29e4c0;},oo=function(_0x351613,_0x4b1596){const _0x30ed8b=_0x351613['length'];if(_0x30ed8b<=_0x4b1596)return[_0x351613];const _0x11f544=[];for(let _0x1ef0f2=0x0;_0x1ef0f2<_0x30ed8b;_0x1ef0f2+=_0x4b1596)_0x1ef0f2+_0x4b1596>_0x30ed8b?_0x11f544['push'](_0x351613['substring'](_0x1ef0f2,_0x30ed8b)):_0x11f544['push'](_0x351613['substring'](_0x1ef0f2,_0x1ef0f2+_0x4b1596));return _0x11f544;};function x(_0x4b5c31,_0x2356fa){for(const _0x245799 in _0x4b5c31)_0x4b5c31['hasOwnProperty'](_0x245799)&&_0x2356fa(_0x245799,_0x4b5c31[_0x245799]);}const ao=function(_0x5c9254){f(!Vi(_0x5c9254),'Invalid\x20JSON\x20number');const _0x562637=0xb,_0xcb2f09=0x34,_0x3fa21d=(0x1<<_0x562637-0x1)-0x1;let _0x4cc057,_0x9919d9,_0x1dfd58,_0x217aae,_0x3ae386;_0x5c9254===0x0?(_0x9919d9=0x0,_0x1dfd58=0x0,_0x4cc057=0x1/_0x5c9254===-0x1/0x0?0x1:0x0):(_0x4cc057=_0x5c9254<0x0,_0x5c9254=Math['abs'](_0x5c9254),_0x5c9254>=Math['pow'](0x2,0x1-_0x3fa21d)?(_0x217aae=Math['min'](Math['floor'](Math['log'](_0x5c9254)/Math['LN2']),_0x3fa21d),_0x9919d9=_0x217aae+_0x3fa21d,_0x1dfd58=Math['round'](_0x5c9254*Math['pow'](0x2,_0xcb2f09-_0x217aae)-Math['pow'](0x2,_0xcb2f09))):(_0x9919d9=0x0,_0x1dfd58=Math['round'](_0x5c9254/Math['pow'](0x2,0x1-_0x3fa21d-_0xcb2f09))));const _0x430ed6=[];for(_0x3ae386=_0xcb2f09;_0x3ae386;_0x3ae386-=0x1)_0x430ed6['push'](_0x1dfd58%0x2?0x1:0x0),_0x1dfd58=Math['floor'](_0x1dfd58/0x2);for(_0x3ae386=_0x562637;_0x3ae386;_0x3ae386-=0x1)_0x430ed6['push'](_0x9919d9%0x2?0x1:0x0),_0x9919d9=Math['floor'](_0x9919d9/0x2);_0x430ed6['push'](_0x4cc057?0x1:0x0),_0x430ed6['reverse']();const _0x33c9de=_0x430ed6['join']('');let _0x36d7c7='';for(_0x3ae386=0x0;_0x3ae386<0x40;_0x3ae386+=0x8){let _0x4d6438=parseInt(_0x33c9de['substr'](_0x3ae386,0x8),0x2)['toString'](0x10);_0x4d6438['length']===0x1&&(_0x4d6438='0'+_0x4d6438),_0x36d7c7=_0x36d7c7+_0x4d6438;}return _0x36d7c7['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x560392,_0x30f8b7){let _0x3f9238='Unknown\x20Error';_0x560392==='too_big'?_0x3f9238='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x560392==='permission_denied'?_0x3f9238='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x560392==='unavailable'&&(_0x3f9238='The\x20service\x20is\x20unavailable');const _0x12a392=new Error(_0x560392+'\x20at\x20'+_0x30f8b7['_path']['toString']()+':\x20'+_0x3f9238);return _0x12a392['code']=_0x560392['toUpperCase'](),_0x12a392;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x12eb62){if(Yl['test'](_0x12eb62)){const _0x92dafc=Number(_0x12eb62);if(_0x92dafc>=Ql&&_0x92dafc<=Jl)return _0x92dafc;}return null;},ht=function(_0x1009fe){try{_0x1009fe();}catch(_0x11e920){setTimeout(()=>{const _0xceb453=_0x11e920['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0xceb453),_0x11e920;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x27d934,_0x3acf1a){const _0x4cd808=setTimeout(_0x27d934,_0x3acf1a);return typeof _0x4cd808=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x4cd808):typeof _0x4cd808=='object'&&_0x4cd808['unref']&&_0x4cd808['unref'](),_0x4cd808;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x4ac5b8,_0x2869e0){this['appCheckProvider']=_0x2869e0,this['appName']=_0x4ac5b8['name'],$(_0x4ac5b8)&&_0x4ac5b8['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x4ac5b8['settings']['appCheckToken']),this['appCheck']=_0x2869e0==null?void 0x0:_0x2869e0['getImmediate']({'optional':!0x0}),this['appCheck']||_0x2869e0==null||_0x2869e0['get']()['then'](_0x49d76c=>this['appCheck']=_0x49d76c);}['getToken'](_0x1938b3){if(this['serverAppAppCheckToken']){if(_0x1938b3)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x1938b3):new Promise((_0x5587cf,_0x354537)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x1938b3)['then'](_0x5587cf,_0x354537):_0x5587cf(null);},0x0);});}['addTokenChangeListener'](_0x126e76){var _0x522f91;(_0x522f91=this['appCheckProvider'])==null||_0x522f91['get']()['then'](_0x19d649=>_0x19d649['addTokenListener'](_0x126e76));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x1b5908,_0xfd7f41,_0x1a69f2){this['appName_']=_0x1b5908,this['firebaseOptions_']=_0xfd7f41,this['authProvider_']=_0x1a69f2,this['auth_']=null,this['auth_']=_0x1a69f2['getImmediate']({'optional':!0x0}),this['auth_']||_0x1a69f2['onInit'](_0x3febaf=>this['auth_']=_0x3febaf);}['getToken'](_0x30072e){return this['auth_']?this['auth_']['getToken'](_0x30072e)['catch'](_0x471171=>_0x471171&&_0x471171['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x471171)):new Promise((_0x5c62d4,_0x557503)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x30072e)['then'](_0x5c62d4,_0x557503):_0x5c62d4(null);},0x0);});}['addTokenChangeListener'](_0x2523f2){this['auth_']?this['auth_']['addAuthTokenListener'](_0x2523f2):this['authProvider_']['get']()['then'](_0xebeba8=>_0xebeba8['addAuthTokenListener'](_0x2523f2));}['removeTokenChangeListener'](_0x40aa48){this['authProvider_']['get']()['then'](_0x470508=>_0x470508['removeAuthTokenListener'](_0x40aa48));}['notifyForInvalidToken'](){let _0x563fd9='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x563fd9+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x563fd9+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x563fd9+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x563fd9);}}class nn{constructor(_0x4aa7d9){this['accessToken']=_0x4aa7d9;}['getToken'](_0x4af60c){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0xa6f4ce){_0xa6f4ce(this['accessToken']);}['removeTokenChangeListener'](_0x5ae45e){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0xb9a296,_0x20d0e9,_0x41b53e,_0x5829b3,_0x3c7d59=!0x1,_0x2fd046='',_0x4d20cc=!0x1,_0x2aa624=!0x1,_0x5c823d=null){this['secure']=_0x20d0e9,this['namespace']=_0x41b53e,this['webSocketOnly']=_0x5829b3,this['nodeAdmin']=_0x3c7d59,this['persistenceKey']=_0x2fd046,this['includeNamespaceInQueryParams']=_0x4d20cc,this['isUsingEmulator']=_0x2aa624,this['emulatorOptions']=_0x5c823d,this['_host']=_0xb9a296['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0xb9a296)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x728685){_0x728685!==this['internalHost']&&(this['internalHost']=_0x728685,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x295337=this['toURLString']();return this['persistenceKey']&&(_0x295337+='<'+this['persistenceKey']+'>'),_0x295337;}['toURLString'](){const _0x2344b0=this['secure']?'https://':'http://',_0x5c7754=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x2344b0+this['host']+'/'+_0x5c7754;}}function th(_0x4b1d13){return _0x4b1d13['host']!==_0x4b1d13['internalHost']||_0x4b1d13['isCustomHost']()||_0x4b1d13['includeNamespaceInQueryParams'];}function vo(_0x5bc138,_0x4115be,_0x2741fa){f(typeof _0x4115be=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x2741fa=='object','typeof\x20params\x20must\x20==\x20object');let _0x4736a2;if(_0x4115be===go)_0x4736a2=(_0x5bc138['secure']?'wss://':'ws://')+_0x5bc138['internalHost']+'/.ws?';else{if(_0x4115be===mo)_0x4736a2=(_0x5bc138['secure']?'https://':'http://')+_0x5bc138['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x4115be);}th(_0x5bc138)&&(_0x2741fa['ns']=_0x5bc138['namespace']);const _0x4f69fa=[];return x(_0x2741fa,(_0x52bf95,_0x1275f4)=>{_0x4f69fa['push'](_0x52bf95+'='+_0x1275f4);}),_0x4736a2+_0x4f69fa['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0xd21d98,_0x2cf737=0x1){J(this['counters_'],_0xd21d98)||(this['counters_'][_0xd21d98]=0x0),this['counters_'][_0xd21d98]+=_0x2cf737;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x3ade95){const _0x7c67c=_0x3ade95['toString']();return ni[_0x7c67c]||(ni[_0x7c67c]=new nh()),ni[_0x7c67c];}function ih(_0x5d9c19,_0x30fafe){const _0x217f82=_0x5d9c19['toString']();return ii[_0x217f82]||(ii[_0x217f82]=_0x30fafe()),ii[_0x217f82];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x12c76c){this['onMessage_']=_0x12c76c,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0xdd07a3,_0x2b182e){this['closeAfterResponse']=_0xdd07a3,this['onClose']=_0x2b182e,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x593ce5,_0x1e90be){for(this['pendingResponses'][_0x593ce5]=_0x1e90be;this['pendingResponses'][this['currentResponseNum']];){const _0x341b86=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x6f20f5=0x0;_0x6f20f5<_0x341b86['length'];++_0x6f20f5)_0x341b86[_0x6f20f5]&&ht(()=>{this['onMessage_'](_0x341b86[_0x6f20f5]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x558b83,_0x3b3968,_0x57fd9f,_0x4e9a40,_0x53f5cf,_0x1878ad,_0x2d6e2b){this['connId']=_0x558b83,this['repoInfo']=_0x3b3968,this['applicationId']=_0x57fd9f,this['appCheckToken']=_0x4e9a40,this['authToken']=_0x53f5cf,this['transportSessionId']=_0x1878ad,this['lastSessionId']=_0x2d6e2b,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x558b83),this['stats_']=Gi(_0x3b3968),this['urlFn']=_0x46ba84=>(this['appCheckToken']&&(_0x46ba84[vi]=this['appCheckToken']),vo(_0x3b3968,mo,_0x46ba84));}['open'](_0x2dfb86,_0x199c3d){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x199c3d,this['myPacketOrderer']=new sh(_0x2dfb86),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x126105)=>{const [_0x14ee87,_0x339bf7,_0x255615,_0x37a196,_0x52aade]=_0x126105;if(this['incrementIncomingBytes_'](_0x126105),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x14ee87===zs)this['id']=_0x339bf7,this['password']=_0x255615;else{if(_0x14ee87===rh)_0x339bf7?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x339bf7,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x14ee87);}}},(..._0x86b26d)=>{const [_0x215442,_0x595cae]=_0x86b26d;this['incrementIncomingBytes_'](_0x86b26d),this['myPacketOrderer']['handleResponse'](_0x215442,_0x595cae);},()=>{this['onClosed_']();},this['urlFn']);const _0x3715e9={};_0x3715e9[zs]='t',_0x3715e9[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x3715e9[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x3715e9[co]=$i,this['transportSessionId']&&(_0x3715e9[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x3715e9[po]=this['lastSessionId']),this['applicationId']&&(_0x3715e9[_o]=this['applicationId']),this['appCheckToken']&&(_0x3715e9[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3715e9[ho]=uo);const _0x3a4adc=this['urlFn'](_0x3715e9);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x3a4adc),this['scriptTagHolder']['addTag'](_0x3a4adc,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x526481){const _0x1ee550=O(_0x526481);this['bytesSent']+=_0x1ee550['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1ee550['length']);const _0x30b81f=Hr(_0x1ee550),_0x43cf47=oo(_0x30b81f,fh);for(let _0x1ce205=0x0;_0x1ce205<_0x43cf47['length'];_0x1ce205++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x43cf47['length'],_0x43cf47[_0x1ce205]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x145589,_0x21b326){this['myDisconnFrame']=document['createElement']('iframe');const _0x36ee79={};_0x36ee79[dh]='t',_0x36ee79[Eo]=_0x145589,_0x36ee79[Io]=_0x21b326,this['myDisconnFrame']['src']=this['urlFn'](_0x36ee79),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x28279f){const _0x3c3515=O(_0x28279f)['length'];this['bytesReceived']+=_0x3c3515,this['stats_']['incrementCounter']('bytes_received',_0x3c3515);}}class qi{constructor(_0x3c8051,_0x4b4fd5,_0x41460d,_0x18c9b0){this['onDisconnect']=_0x41460d,this['urlFn']=_0x18c9b0,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x3c8051,window[ah+this['uniqueCallbackIdentifier']]=_0x4b4fd5,this['myIFrame']=qi['createIFrame_']();let _0x16df71='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x16df71='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x340a8b='<html><body>'+_0x16df71+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x340a8b),this['myIFrame']['doc']['close']();}catch(_0x32bab3){L('frame\x20writing\x20exception'),_0x32bab3['stack']&&L(_0x32bab3['stack']),L(_0x32bab3);}}}static['createIFrame_'](){const _0x3d1a0a=document['createElement']('iframe');if(_0x3d1a0a['style']['display']='none',document['body']){document['body']['appendChild'](_0x3d1a0a);try{_0x3d1a0a['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x41d4b9=document['domain'];_0x3d1a0a['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x41d4b9+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x3d1a0a['contentDocument']?_0x3d1a0a['doc']=_0x3d1a0a['contentDocument']:_0x3d1a0a['contentWindow']?_0x3d1a0a['doc']=_0x3d1a0a['contentWindow']['document']:_0x3d1a0a['document']&&(_0x3d1a0a['doc']=_0x3d1a0a['document']),_0x3d1a0a;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x147f19=this['onDisconnect'];_0x147f19&&(this['onDisconnect']=null,_0x147f19());}['startLongPoll'](_0x611a7,_0xb6ad70){for(this['myID']=_0x611a7,this['myPW']=_0xb6ad70,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x4fbd06={};_0x4fbd06[Eo]=this['myID'],_0x4fbd06[Io]=this['myPW'],_0x4fbd06[wo]=this['currentSerial'];let _0x1d7e8e=this['urlFn'](_0x4fbd06),_0x58c948='',_0x15bdce=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x58c948['length']<=Co;){const _0x208515=this['pendingSegs']['shift']();_0x58c948=_0x58c948+'&'+lh+_0x15bdce+'='+_0x208515['seg']+'&'+hh+_0x15bdce+'='+_0x208515['ts']+'&'+uh+_0x15bdce+'='+_0x208515['d'],_0x15bdce++;}return _0x1d7e8e=_0x1d7e8e+_0x58c948,this['addLongPollTag_'](_0x1d7e8e,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x5bbbc7,_0x18c297,_0x48540b){this['pendingSegs']['push']({'seg':_0x5bbbc7,'ts':_0x18c297,'d':_0x48540b}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1013ff,_0x3ade3c){this['outstandingRequests']['add'](_0x3ade3c);const _0x195c6c=()=>{this['outstandingRequests']['delete'](_0x3ade3c),this['newRequest_']();},_0x2b33bf=setTimeout(_0x195c6c,Math['floor'](ph)),_0x244749=()=>{clearTimeout(_0x2b33bf),_0x195c6c();};this['addTag'](_0x1013ff,_0x244749);}['addTag'](_0x2090f6,_0x3b9bb8){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x424dc2=this['myIFrame']['doc']['createElement']('script');_0x424dc2['type']='text/javascript',_0x424dc2['async']=!0x0,_0x424dc2['src']=_0x2090f6,_0x424dc2['onload']=_0x424dc2['onreadystatechange']=function(){const _0x4c36bf=_0x424dc2['readyState'];(!_0x4c36bf||_0x4c36bf==='loaded'||_0x4c36bf==='complete')&&(_0x424dc2['onload']=_0x424dc2['onreadystatechange']=null,_0x424dc2['parentNode']&&_0x424dc2['parentNode']['removeChild'](_0x424dc2),_0x3b9bb8());},_0x424dc2['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x2090f6),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x424dc2);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x4ec295,_0x5891cf,_0x3e8009,_0x16c829,_0x40be44,_0x56f36f,_0x103cd6){this['connId']=_0x4ec295,this['applicationId']=_0x3e8009,this['appCheckToken']=_0x16c829,this['authToken']=_0x40be44,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x5891cf),this['connURL']=z['connectionURL_'](_0x5891cf,_0x56f36f,_0x103cd6,_0x16c829,_0x3e8009),this['nodeAdmin']=_0x5891cf['nodeAdmin'];}static['connectionURL_'](_0x456a3f,_0x2bd6e1,_0x5091fb,_0x5c2a8d,_0x491c6b){const _0x4a075d={};return _0x4a075d[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x4a075d[ho]=uo),_0x2bd6e1&&(_0x4a075d[lo]=_0x2bd6e1),_0x5091fb&&(_0x4a075d[po]=_0x5091fb),_0x5c2a8d&&(_0x4a075d[vi]=_0x5c2a8d),_0x491c6b&&(_0x4a075d[_o]=_0x491c6b),vo(_0x456a3f,go,_0x4a075d);}['open'](_0x2326cb,_0x1cdb7f){this['onDisconnect']=_0x1cdb7f,this['onMessage']=_0x2326cb,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x833ec8;_c(),this['mySock']=new un(this['connURL'],[],_0x833ec8);}catch(_0x1fd6a6){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x3eddcb=_0x1fd6a6['message']||_0x1fd6a6['data'];_0x3eddcb&&this['log_'](_0x3eddcb),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x4ab619=>{this['handleIncomingFrame'](_0x4ab619);},this['mySock']['onerror']=_0x4f42b9=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x541a84=_0x4f42b9['message']||_0x4f42b9['data'];_0x541a84&&this['log_'](_0x541a84),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x3fbf15=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x47300f=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x9d0f26=navigator['userAgent']['match'](_0x47300f);_0x9d0f26&&_0x9d0f26['length']>0x1&&parseFloat(_0x9d0f26[0x1])<4.4&&(_0x3fbf15=!0x0);}return!_0x3fbf15&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x20c04f){if(this['frames']['push'](_0x20c04f),this['frames']['length']===this['totalFrames']){const _0x521471=this['frames']['join']('');this['frames']=null;const _0x39a4b1=At(_0x521471);this['onMessage'](_0x39a4b1);}}['handleNewFrameCount_'](_0x2cc120){this['totalFrames']=_0x2cc120,this['frames']=[];}['extractFrameCount_'](_0x3791ea){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x3791ea['length']<=0x6){const _0x2bfc9f=Number(_0x3791ea);if(!isNaN(_0x2bfc9f))return this['handleNewFrameCount_'](_0x2bfc9f),null;}return this['handleNewFrameCount_'](0x1),_0x3791ea;}['handleIncomingFrame'](_0x55f10b){if(this['mySock']===null)return;const _0x1df80b=_0x55f10b['data'];if(this['bytesReceived']+=_0x1df80b['length'],this['stats_']['incrementCounter']('bytes_received',_0x1df80b['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x1df80b);else{const _0x49e878=this['extractFrameCount_'](_0x1df80b);_0x49e878!==null&&this['appendFrame_'](_0x49e878);}}['send'](_0x5dd8ca){this['resetKeepAlive']();const _0x3fa3e4=O(_0x5dd8ca);this['bytesSent']+=_0x3fa3e4['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3fa3e4['length']);const _0x363761=oo(_0x3fa3e4,gh);_0x363761['length']>0x1&&this['sendString_'](String(_0x363761['length']));for(let _0x35e235=0x0;_0x35e235<_0x363761['length'];_0x35e235++)this['sendString_'](_0x363761[_0x35e235]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x2437cc){try{this['mySock']['send'](_0x2437cc);}catch(_0x4e653d){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x4e653d['message']||_0x4e653d['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x54dcf2){this['initTransports_'](_0x54dcf2);}['initTransports_'](_0x6a6f5){const _0x3c59fb=z&&z['isAvailable']();let _0xedc747=_0x3c59fb&&!z['previouslyFailed']();if(_0x6a6f5['webSocketOnly']&&(_0x3c59fb||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0xedc747=!0x0),_0xedc747)this['transports_']=[z];else{const _0x29244f=this['transports_']=[];for(const _0x45d731 of Nt['ALL_TRANSPORTS'])_0x45d731&&_0x45d731['isAvailable']()&&_0x29244f['push'](_0x45d731);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0xd51291,_0x48ca7c,_0x10dbf2,_0x998347,_0x9eb727,_0x247d28,_0x28b686,_0x3771ae,_0x59afb2,_0x5d7e05){this['id']=_0xd51291,this['repoInfo_']=_0x48ca7c,this['applicationId_']=_0x10dbf2,this['appCheckToken_']=_0x998347,this['authToken_']=_0x9eb727,this['onMessage_']=_0x247d28,this['onReady_']=_0x28b686,this['onDisconnect_']=_0x3771ae,this['onKill_']=_0x59afb2,this['lastSessionId']=_0x5d7e05,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x48ca7c),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x56861b=this['transportManager_']['initialTransport']();this['conn_']=new _0x56861b(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x56861b['responsesRequiredToBeHealthy']||0x0;const _0x16a808=this['connReceiver_'](this['conn_']),_0x52f9d6=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x16a808,_0x52f9d6);},Math['floor'](0x0));const _0x335c3f=_0x56861b['healthyTimeout']||0x0;_0x335c3f>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x335c3f)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x5f3627){return _0x391efc=>{_0x5f3627===this['conn_']?this['onConnectionLost_'](_0x391efc):_0x5f3627===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x303b6c){return _0x84221f=>{this['state_']!==0x2&&(_0x303b6c===this['rx_']?this['onPrimaryMessageReceived_'](_0x84221f):_0x303b6c===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x84221f):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x4f6219){const _0x264b78={'t':'d','d':_0x4f6219};this['sendData_'](_0x264b78);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1add87){if(si in _0x1add87){const _0x54c22a=_0x1add87[si];_0x54c22a===Qs?this['upgradeIfSecondaryHealthy_']():_0x54c22a===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x54c22a===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x58b8b9){const _0x1dd73e=_t('t',_0x58b8b9),_0x4161e2=_t('d',_0x58b8b9);if(_0x1dd73e==='c')this['onSecondaryControl_'](_0x4161e2);else{if(_0x1dd73e==='d')this['pendingDataMessages']['push'](_0x4161e2);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x1dd73e);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x2fc1eb){const _0xd47604=_t('t',_0x2fc1eb),_0xdf250d=_t('d',_0x2fc1eb);_0xd47604==='c'?this['onControl_'](_0xdf250d):_0xd47604==='d'&&this['onDataMessage_'](_0xdf250d);}['onDataMessage_'](_0x2bd194){this['onPrimaryResponse_'](),this['onMessage_'](_0x2bd194);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x16e24f){const _0x5bc496=_t(si,_0x16e24f);if(js in _0x16e24f){const _0xbbfbdc=_0x16e24f[js];if(_0x5bc496===Th){const _0x1dff1d={..._0xbbfbdc};this['repoInfo_']['isUsingEmulator']&&(_0x1dff1d['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x1dff1d);}else{if(_0x5bc496===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x535adc=0x0;_0x535adc<this['pendingDataMessages']['length'];++_0x535adc)this['onDataMessage_'](this['pendingDataMessages'][_0x535adc]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x5bc496===wh?this['onConnectionShutdown_'](_0xbbfbdc):_0x5bc496===Ks?this['onReset_'](_0xbbfbdc):_0x5bc496===Ch?yi('Server\x20Error:\x20'+_0xbbfbdc):_0x5bc496===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x5bc496);}}}['onHandshake_'](_0x5c53e9){const _0xaf1413=_0x5c53e9['ts'],_0x23249c=_0x5c53e9['v'],_0x5e235f=_0x5c53e9['h'];this['sessionId']=_0x5c53e9['s'],this['repoInfo_']['host']=_0x5e235f,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0xaf1413),$i!==_0x23249c&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x5635a4=this['transportManager_']['upgradeTransport']();_0x5635a4&&this['startUpgrade_'](_0x5635a4);}['startUpgrade_'](_0x349b0d){this['secondaryConn_']=new _0x349b0d(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x349b0d['responsesRequiredToBeHealthy']||0x0;const _0x377c89=this['connReceiver_'](this['secondaryConn_']),_0x53c359=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x377c89,_0x53c359),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x492454){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x492454),this['repoInfo_']['host']=_0x492454,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x496b0c,_0x52a845){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x496b0c,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x52a845,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x35bc03=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x35bc03||this['rx_']===_0x35bc03)&&this['close']();}['onConnectionLost_'](_0x416d3b){this['conn_']=null,!_0x416d3b&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x4b90f3){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x4b90f3),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x174c1e){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x174c1e);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x40eb4f,_0x53176b,_0x3ba3b0,_0x14f105){}['merge'](_0x3ef23e,_0x2f08a3,_0x1f1c6f,_0x2ff0b3){}['refreshAuthToken'](_0x3e1485){}['refreshAppCheckToken'](_0x1bdd09){}['onDisconnectPut'](_0x3172a3,_0x453fa4,_0x120e2c){}['onDisconnectMerge'](_0x105c9a,_0x58cc45,_0x3b368){}['onDisconnectCancel'](_0x3a69c8,_0x2bed95){}['reportStats'](_0x1ffcf7){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x36cc09){this['allowedEvents_']=_0x36cc09,this['listeners_']={},f(Array['isArray'](_0x36cc09)&&_0x36cc09['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0xee253c,..._0x5f4ca3){if(Array['isArray'](this['listeners_'][_0xee253c])){const _0x2b20b5=[...this['listeners_'][_0xee253c]];for(let _0x24914d=0x0;_0x24914d<_0x2b20b5['length'];_0x24914d++)_0x2b20b5[_0x24914d]['callback']['apply'](_0x2b20b5[_0x24914d]['context'],_0x5f4ca3);}}['on'](_0x294add,_0x348968,_0x5e31df){this['validateEventType_'](_0x294add),this['listeners_'][_0x294add]=this['listeners_'][_0x294add]||[],this['listeners_'][_0x294add]['push']({'callback':_0x348968,'context':_0x5e31df});const _0x3feaa0=this['getInitialEvent'](_0x294add);_0x3feaa0&&_0x348968['apply'](_0x5e31df,_0x3feaa0);}['off'](_0xca225,_0x5336f9,_0x312266){this['validateEventType_'](_0xca225);const _0x333a23=this['listeners_'][_0xca225]||[];for(let _0x301120=0x0;_0x301120<_0x333a23['length'];_0x301120++)if(_0x333a23[_0x301120]['callback']===_0x5336f9&&(!_0x312266||_0x312266===_0x333a23[_0x301120]['context'])){_0x333a23['splice'](_0x301120,0x1);return;}}['validateEventType_'](_0x9fd34c){f(this['allowedEvents_']['find'](_0x522972=>_0x522972===_0x9fd34c),'Unknown\x20event:\x20'+_0x9fd34c);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x6bedd1){return f(_0x6bedd1==='online','Unknown\x20event\x20type:\x20'+_0x6bedd1),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x361f70,_0x4d8eda){if(_0x4d8eda===void 0x0){this['pieces_']=_0x361f70['split']('/');let _0x1eea36=0x0;for(let _0x45bd6e=0x0;_0x45bd6e<this['pieces_']['length'];_0x45bd6e++)this['pieces_'][_0x45bd6e]['length']>0x0&&(this['pieces_'][_0x1eea36]=this['pieces_'][_0x45bd6e],_0x1eea36++);this['pieces_']['length']=_0x1eea36,this['pieceNum_']=0x0;}else this['pieces_']=_0x361f70,this['pieceNum_']=_0x4d8eda;}['toString'](){let _0x24705b='';for(let _0x4f6d22=this['pieceNum_'];_0x4f6d22<this['pieces_']['length'];_0x4f6d22++)this['pieces_'][_0x4f6d22]!==''&&(_0x24705b+='/'+this['pieces_'][_0x4f6d22]);return _0x24705b||'/';}}function w(){return new C('');}function y(_0x497811){return _0x497811['pieceNum_']>=_0x497811['pieces_']['length']?null:_0x497811['pieces_'][_0x497811['pieceNum_']];}function we(_0x537453){return _0x537453['pieces_']['length']-_0x537453['pieceNum_'];}function b(_0x3563c5){let _0xd92527=_0x3563c5['pieceNum_'];return _0xd92527<_0x3563c5['pieces_']['length']&&_0xd92527++,new C(_0x3563c5['pieces_'],_0xd92527);}function zi(_0x16081a){return _0x16081a['pieceNum_']<_0x16081a['pieces_']['length']?_0x16081a['pieces_'][_0x16081a['pieces_']['length']-0x1]:null;}function bh(_0x204b5b){let _0x5cf182='';for(let _0x4785a1=_0x204b5b['pieceNum_'];_0x4785a1<_0x204b5b['pieces_']['length'];_0x4785a1++)_0x204b5b['pieces_'][_0x4785a1]!==''&&(_0x5cf182+='/'+encodeURIComponent(String(_0x204b5b['pieces_'][_0x4785a1])));return _0x5cf182||'/';}function Pt(_0x456dbb,_0x161072=0x0){return _0x456dbb['pieces_']['slice'](_0x456dbb['pieceNum_']+_0x161072);}function Ro(_0x3509ca){if(_0x3509ca['pieceNum_']>=_0x3509ca['pieces_']['length'])return null;const _0x5da9e8=[];for(let _0xd6c544=_0x3509ca['pieceNum_'];_0xd6c544<_0x3509ca['pieces_']['length']-0x1;_0xd6c544++)_0x5da9e8['push'](_0x3509ca['pieces_'][_0xd6c544]);return new C(_0x5da9e8,0x0);}function k(_0x40ceb8,_0x420a44){const _0x3b166d=[];for(let _0x2d32be=_0x40ceb8['pieceNum_'];_0x2d32be<_0x40ceb8['pieces_']['length'];_0x2d32be++)_0x3b166d['push'](_0x40ceb8['pieces_'][_0x2d32be]);if(_0x420a44 instanceof C){for(let _0x3c6799=_0x420a44['pieceNum_'];_0x3c6799<_0x420a44['pieces_']['length'];_0x3c6799++)_0x3b166d['push'](_0x420a44['pieces_'][_0x3c6799]);}else{const _0x2faeb0=_0x420a44['split']('/');for(let _0x519f8a=0x0;_0x519f8a<_0x2faeb0['length'];_0x519f8a++)_0x2faeb0[_0x519f8a]['length']>0x0&&_0x3b166d['push'](_0x2faeb0[_0x519f8a]);}return new C(_0x3b166d,0x0);}function v(_0x9476b0){return _0x9476b0['pieceNum_']>=_0x9476b0['pieces_']['length'];}function F(_0x9698e7,_0x5c1fa5){const _0x2acb09=y(_0x9698e7),_0x42ed2a=y(_0x5c1fa5);if(_0x2acb09===null)return _0x5c1fa5;if(_0x2acb09===_0x42ed2a)return F(b(_0x9698e7),b(_0x5c1fa5));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x5c1fa5+')\x20is\x20not\x20within\x20outerPath\x20('+_0x9698e7+')');}function Rh(_0x599565,_0x2e2247){const _0x2810bc=Pt(_0x599565,0x0),_0x3e0e0e=Pt(_0x2e2247,0x0);for(let _0x5ebb4a=0x0;_0x5ebb4a<_0x2810bc['length']&&_0x5ebb4a<_0x3e0e0e['length'];_0x5ebb4a++){const _0x5eeae4=He(_0x2810bc[_0x5ebb4a],_0x3e0e0e[_0x5ebb4a]);if(_0x5eeae4!==0x0)return _0x5eeae4;}return _0x2810bc['length']===_0x3e0e0e['length']?0x0:_0x2810bc['length']<_0x3e0e0e['length']?-0x1:0x1;}function ji(_0x4f6436,_0x56ff30){if(we(_0x4f6436)!==we(_0x56ff30))return!0x1;for(let _0x34b385=_0x4f6436['pieceNum_'],_0x1b1936=_0x56ff30['pieceNum_'];_0x34b385<=_0x4f6436['pieces_']['length'];_0x34b385++,_0x1b1936++)if(_0x4f6436['pieces_'][_0x34b385]!==_0x56ff30['pieces_'][_0x1b1936])return!0x1;return!0x0;}function G(_0x481852,_0x3f360a){let _0x27bc2b=_0x481852['pieceNum_'],_0x3259c0=_0x3f360a['pieceNum_'];if(we(_0x481852)>we(_0x3f360a))return!0x1;for(;_0x27bc2b<_0x481852['pieces_']['length'];){if(_0x481852['pieces_'][_0x27bc2b]!==_0x3f360a['pieces_'][_0x3259c0])return!0x1;++_0x27bc2b,++_0x3259c0;}return!0x0;}class Ah{constructor(_0x37157d,_0x55c235){this['errorPrefix_']=_0x55c235,this['parts_']=Pt(_0x37157d,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x1e9156=0x0;_0x1e9156<this['parts_']['length'];_0x1e9156++)this['byteLength_']+=On(this['parts_'][_0x1e9156]);Ao(this);}}function kh(_0x3457cc,_0x304f60){_0x3457cc['parts_']['length']>0x0&&(_0x3457cc['byteLength_']+=0x1),_0x3457cc['parts_']['push'](_0x304f60),_0x3457cc['byteLength_']+=On(_0x304f60),Ao(_0x3457cc);}function Nh(_0x218158){const _0x536110=_0x218158['parts_']['pop']();_0x218158['byteLength_']-=On(_0x536110),_0x218158['parts_']['length']>0x0&&(_0x218158['byteLength_']-=0x1);}function Ao(_0x59121b){if(_0x59121b['byteLength_']>er)throw new Error(_0x59121b['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x59121b['byteLength_']+').');if(_0x59121b['parts_']['length']>Zs)throw new Error(_0x59121b['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x59121b));}function Pe(_0x231f01){return _0x231f01['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x231f01['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0xf38304,_0x17752;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x17752='visibilitychange',_0xf38304='hidden'):typeof document['mozHidden']<'u'?(_0x17752='mozvisibilitychange',_0xf38304='mozHidden'):typeof document['msHidden']<'u'?(_0x17752='msvisibilitychange',_0xf38304='msHidden'):typeof document['webkitHidden']<'u'&&(_0x17752='webkitvisibilitychange',_0xf38304='webkitHidden')),this['visible_']=!0x0,_0x17752&&document['addEventListener'](_0x17752,()=>{const _0x59590b=!document[_0xf38304];_0x59590b!==this['visible_']&&(this['visible_']=_0x59590b,this['trigger']('visible',_0x59590b));},!0x1);}['getInitialEvent'](_0xdf9947){return f(_0xdf9947==='visible','Unknown\x20event\x20type:\x20'+_0xdf9947),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x149fdc,_0x12c70b,_0x216675,_0x27ac74,_0x139566,_0x5afd06,_0x49efb6,_0x2fa74e){if(super(),this['repoInfo_']=_0x149fdc,this['applicationId_']=_0x12c70b,this['onDataUpdate_']=_0x216675,this['onConnectStatus_']=_0x27ac74,this['onServerInfoUpdate_']=_0x139566,this['authTokenProvider_']=_0x5afd06,this['appCheckTokenProvider_']=_0x49efb6,this['authOverride_']=_0x2fa74e,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x2fa74e)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x149fdc['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x5cbee7,_0x3cf7c5,_0x4ab81d){const _0xa9bf8d=++this['requestNumber_'],_0x195cd5={'r':_0xa9bf8d,'a':_0x5cbee7,'b':_0x3cf7c5};this['log_'](O(_0x195cd5)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x195cd5),_0x4ab81d&&(this['requestCBHash_'][_0xa9bf8d]=_0x4ab81d);}['get'](_0x1c3f72){this['initConnection_']();const _0x1cbc4f=new ot(),_0x3a52aa={'action':'g','request':{'p':_0x1c3f72['_path']['toString'](),'q':_0x1c3f72['_queryObject']},'onComplete':_0x152ec1=>{const _0x61d577=_0x152ec1['d'];_0x152ec1['s']==='ok'?_0x1cbc4f['resolve'](_0x61d577):_0x1cbc4f['reject'](_0x61d577);}};this['outstandingGets_']['push'](_0x3a52aa),this['outstandingGetCount_']++;const _0x42ed2e=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x42ed2e),_0x1cbc4f['promise'];}['listen'](_0xed4189,_0xe6f984,_0x4146bc,_0x45e1da){this['initConnection_']();const _0x40f546=_0xed4189['_queryIdentifier'],_0x2202fc=_0xed4189['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2202fc+'\x20'+_0x40f546),this['listens']['has'](_0x2202fc)||this['listens']['set'](_0x2202fc,new Map()),f(_0xed4189['_queryParams']['isDefault']()||!_0xed4189['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x2202fc)['has'](_0x40f546),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x18444e={'onComplete':_0x45e1da,'hashFn':_0xe6f984,'query':_0xed4189,'tag':_0x4146bc};this['listens']['get'](_0x2202fc)['set'](_0x40f546,_0x18444e),this['connected_']&&this['sendListen_'](_0x18444e);}['sendGet_'](_0x35d9be){const _0x1890e3=this['outstandingGets_'][_0x35d9be];this['sendRequest']('g',_0x1890e3['request'],_0x477d23=>{delete this['outstandingGets_'][_0x35d9be],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1890e3['onComplete']&&_0x1890e3['onComplete'](_0x477d23);});}['sendListen_'](_0x4dbf2c){const _0x58ea6c=_0x4dbf2c['query'],_0xb4ff9=_0x58ea6c['_path']['toString'](),_0xd96c5=_0x58ea6c['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0xb4ff9+'\x20for\x20'+_0xd96c5);const _0x403f2e={'p':_0xb4ff9},_0x251f03='q';_0x4dbf2c['tag']&&(_0x403f2e['q']=_0x58ea6c['_queryObject'],_0x403f2e['t']=_0x4dbf2c['tag']),_0x403f2e['h']=_0x4dbf2c['hashFn'](),this['sendRequest'](_0x251f03,_0x403f2e,_0x1c1efb=>{const _0x40bb1d=_0x1c1efb['d'],_0x4e619d=_0x1c1efb['s'];se['warnOnListenWarnings_'](_0x40bb1d,_0x58ea6c),(this['listens']['get'](_0xb4ff9)&&this['listens']['get'](_0xb4ff9)['get'](_0xd96c5))===_0x4dbf2c&&(this['log_']('listen\x20response',_0x1c1efb),_0x4e619d!=='ok'&&this['removeListen_'](_0xb4ff9,_0xd96c5),_0x4dbf2c['onComplete']&&_0x4dbf2c['onComplete'](_0x4e619d,_0x40bb1d));});}static['warnOnListenWarnings_'](_0x2c4492,_0xf7909a){if(_0x2c4492&&typeof _0x2c4492=='object'&&J(_0x2c4492,'w')){const _0x2fe913=De(_0x2c4492,'w');if(Array['isArray'](_0x2fe913)&&~_0x2fe913['indexOf']('no_index')){const _0x3115d9='\x22.indexOn\x22:\x20\x22'+_0xf7909a['_queryParams']['getIndex']()['toString']()+'\x22',_0x4e45ff=_0xf7909a['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x3115d9+'\x20at\x20'+_0x4e45ff+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x115ce7){this['authToken_']=_0x115ce7,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x115ce7);}['reduceReconnectDelayIfAdminCredential_'](_0x5ba13e){(_0x5ba13e&&_0x5ba13e['length']===0x28||wc(_0x5ba13e))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x3933c4){this['appCheckToken_']=_0x3933c4,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x3dfb80=this['authToken_'],_0xb3ff1b=Ic(_0x3dfb80)?'auth':'gauth',_0xece7b={'cred':_0x3dfb80};this['authOverride_']===null?_0xece7b['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0xece7b['authvar']=this['authOverride_']),this['sendRequest'](_0xb3ff1b,_0xece7b,_0x37562c=>{const _0x32e49e=_0x37562c['s'],_0x518753=_0x37562c['d']||'error';this['authToken_']===_0x3dfb80&&(_0x32e49e==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x32e49e,_0x518753));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x45afad=>{const _0x4774d3=_0x45afad['s'],_0xd78f45=_0x45afad['d']||'error';_0x4774d3==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x4774d3,_0xd78f45);});}['unlisten'](_0x33b697,_0x3e87e5){const _0x4704b6=_0x33b697['_path']['toString'](),_0x1c36cc=_0x33b697['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x4704b6+'\x20'+_0x1c36cc),f(_0x33b697['_queryParams']['isDefault']()||!_0x33b697['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x4704b6,_0x1c36cc)&&this['connected_']&&this['sendUnlisten_'](_0x4704b6,_0x1c36cc,_0x33b697['_queryObject'],_0x3e87e5);}['sendUnlisten_'](_0x43a76d,_0x3c3f24,_0x5019ef,_0x1950c5){this['log_']('Unlisten\x20on\x20'+_0x43a76d+'\x20for\x20'+_0x3c3f24);const _0x9c0c0={'p':_0x43a76d},_0xe1ecdf='n';_0x1950c5&&(_0x9c0c0['q']=_0x5019ef,_0x9c0c0['t']=_0x1950c5),this['sendRequest'](_0xe1ecdf,_0x9c0c0);}['onDisconnectPut'](_0x2eddf1,_0x305b37,_0x5b3f30){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x2eddf1,_0x305b37,_0x5b3f30):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2eddf1,'action':'o','data':_0x305b37,'onComplete':_0x5b3f30});}['onDisconnectMerge'](_0x1234dd,_0xa374b1,_0x548868){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x1234dd,_0xa374b1,_0x548868):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1234dd,'action':'om','data':_0xa374b1,'onComplete':_0x548868});}['onDisconnectCancel'](_0x463733,_0x14c476){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x463733,null,_0x14c476):this['onDisconnectRequestQueue_']['push']({'pathString':_0x463733,'action':'oc','data':null,'onComplete':_0x14c476});}['sendOnDisconnect_'](_0x252478,_0x4359e1,_0x571d79,_0x4a2522){const _0x2a83a7={'p':_0x4359e1,'d':_0x571d79};this['log_']('onDisconnect\x20'+_0x252478,_0x2a83a7),this['sendRequest'](_0x252478,_0x2a83a7,_0xa6c0e2=>{_0x4a2522&&setTimeout(()=>{_0x4a2522(_0xa6c0e2['s'],_0xa6c0e2['d']);},Math['floor'](0x0));});}['put'](_0x562db6,_0x1ae073,_0x2c1d46,_0x569d04){this['putInternal']('p',_0x562db6,_0x1ae073,_0x2c1d46,_0x569d04);}['merge'](_0x168094,_0x54d532,_0x58bdb6,_0x444eb1){this['putInternal']('m',_0x168094,_0x54d532,_0x58bdb6,_0x444eb1);}['putInternal'](_0x5dac1e,_0x4005c6,_0x17d494,_0x2e155d,_0x3cff52){this['initConnection_']();const _0x3bd84={'p':_0x4005c6,'d':_0x17d494};_0x3cff52!==void 0x0&&(_0x3bd84['h']=_0x3cff52),this['outstandingPuts_']['push']({'action':_0x5dac1e,'request':_0x3bd84,'onComplete':_0x2e155d}),this['outstandingPutCount_']++;const _0x203633=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x203633):this['log_']('Buffering\x20put:\x20'+_0x4005c6);}['sendPut_'](_0x2838ec){const _0x65d624=this['outstandingPuts_'][_0x2838ec]['action'],_0x4a0aa1=this['outstandingPuts_'][_0x2838ec]['request'],_0x9fb693=this['outstandingPuts_'][_0x2838ec]['onComplete'];this['outstandingPuts_'][_0x2838ec]['queued']=this['connected_'],this['sendRequest'](_0x65d624,_0x4a0aa1,_0x102852=>{this['log_'](_0x65d624+'\x20response',_0x102852),delete this['outstandingPuts_'][_0x2838ec],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x9fb693&&_0x9fb693(_0x102852['s'],_0x102852['d']);});}['reportStats'](_0x5e1791){if(this['connected_']){const _0x5aa31d={'c':_0x5e1791};this['log_']('reportStats',_0x5aa31d),this['sendRequest']('s',_0x5aa31d,_0x13ba6c=>{if(_0x13ba6c['s']!=='ok'){const _0x433780=_0x13ba6c['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x433780);}});}}['onDataMessage_'](_0x319758){if('r'in _0x319758){this['log_']('from\x20server:\x20'+O(_0x319758));const _0x2f6b12=_0x319758['r'],_0x1a5336=this['requestCBHash_'][_0x2f6b12];_0x1a5336&&(delete this['requestCBHash_'][_0x2f6b12],_0x1a5336(_0x319758['b']));}else{if('error'in _0x319758)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x319758['error'];'a'in _0x319758&&this['onDataPush_'](_0x319758['a'],_0x319758['b']);}}['onDataPush_'](_0xb3b10c,_0x3892c3){this['log_']('handleServerMessage',_0xb3b10c,_0x3892c3),_0xb3b10c==='d'?this['onDataUpdate_'](_0x3892c3['p'],_0x3892c3['d'],!0x1,_0x3892c3['t']):_0xb3b10c==='m'?this['onDataUpdate_'](_0x3892c3['p'],_0x3892c3['d'],!0x0,_0x3892c3['t']):_0xb3b10c==='c'?this['onListenRevoked_'](_0x3892c3['p'],_0x3892c3['q']):_0xb3b10c==='ac'?this['onAuthRevoked_'](_0x3892c3['s'],_0x3892c3['d']):_0xb3b10c==='apc'?this['onAppCheckRevoked_'](_0x3892c3['s'],_0x3892c3['d']):_0xb3b10c==='sd'?this['onSecurityDebugPacket_'](_0x3892c3):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0xb3b10c)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x442f7a,_0x385c87){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x442f7a),this['lastSessionId']=_0x385c87,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x5dd0fb){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x5dd0fb));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x344409){_0x344409&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x344409;}['onOnline_'](_0x4fe8fe){_0x4fe8fe?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x10a314=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x155827=Math['max'](0x0,this['reconnectDelay_']-_0x10a314);_0x155827=Math['random']()*_0x155827,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x155827+'ms'),this['scheduleConnect_'](_0x155827),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x14c218=this['onDataMessage_']['bind'](this),_0x239be6=this['onReady_']['bind'](this),_0x2c18e8=this['onRealtimeDisconnect_']['bind'](this),_0x2a8b4e=this['id']+':'+se['nextConnectionId_']++,_0xf2d575=this['lastSessionId'];let _0x2bc781=!0x1,_0x58773c=null;const _0x5cbfcf=function(){_0x58773c?_0x58773c['close']():(_0x2bc781=!0x0,_0x2c18e8());},_0x3c25c3=function(_0x7d02e1){f(_0x58773c,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x58773c['sendRequest'](_0x7d02e1);};this['realtime_']={'close':_0x5cbfcf,'sendRequest':_0x3c25c3};const _0x3733bf=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x2ca04a,_0x3cc3dd]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x3733bf),this['appCheckTokenProvider_']['getToken'](_0x3733bf)]);_0x2bc781?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x2ca04a&&_0x2ca04a['accessToken'],this['appCheckToken_']=_0x3cc3dd&&_0x3cc3dd['token'],_0x58773c=new Sh(_0x2a8b4e,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x14c218,_0x239be6,_0x2c18e8,_0x3212ed=>{U(_0x3212ed+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0xf2d575));}catch(_0x2dee1c){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x2dee1c),_0x2bc781||(this['repoInfo_']['nodeAdmin']&&U(_0x2dee1c),_0x5cbfcf());}}}['interrupt'](_0x3b8cbc){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x3b8cbc),this['interruptReasons_'][_0x3b8cbc]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x4f7bd2){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x4f7bd2),delete this['interruptReasons_'][_0x4f7bd2],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x478431){const _0x424a44=_0x478431-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x424a44});}['cancelSentTransactions_'](){for(let _0x149109=0x0;_0x149109<this['outstandingPuts_']['length'];_0x149109++){const _0x56f534=this['outstandingPuts_'][_0x149109];_0x56f534&&'h'in _0x56f534['request']&&_0x56f534['queued']&&(_0x56f534['onComplete']&&_0x56f534['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x149109],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x5c80a8,_0x5d7633){let _0x1c290d;_0x5d7633?_0x1c290d=_0x5d7633['map'](_0x4e1688=>Hi(_0x4e1688))['join']('$'):_0x1c290d='default';const _0x50667b=this['removeListen_'](_0x5c80a8,_0x1c290d);_0x50667b&&_0x50667b['onComplete']&&_0x50667b['onComplete']('permission_denied');}['removeListen_'](_0x416d28,_0x586895){const _0x43422f=new C(_0x416d28)['toString']();let _0xd08107;if(this['listens']['has'](_0x43422f)){const _0x826ca6=this['listens']['get'](_0x43422f);_0xd08107=_0x826ca6['get'](_0x586895),_0x826ca6['delete'](_0x586895),_0x826ca6['size']===0x0&&this['listens']['delete'](_0x43422f);}else _0xd08107=void 0x0;return _0xd08107;}['onAuthRevoked_'](_0x46b999,_0x1aa092){L('Auth\x20token\x20revoked:\x20'+_0x46b999+'/'+_0x1aa092),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x46b999==='invalid_token'||_0x46b999==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x2f2e9f,_0x31fbc0){L('App\x20check\x20token\x20revoked:\x20'+_0x2f2e9f+'/'+_0x31fbc0),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x2f2e9f==='invalid_token'||_0x2f2e9f==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x4b73c6){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x4b73c6):'msg'in _0x4b73c6&&console['log']('FIREBASE:\x20'+_0x4b73c6['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x35e1f6 of this['listens']['values']())for(const _0x53282a of _0x35e1f6['values']())this['sendListen_'](_0x53282a);for(let _0xf4369=0x0;_0xf4369<this['outstandingPuts_']['length'];_0xf4369++)this['outstandingPuts_'][_0xf4369]&&this['sendPut_'](_0xf4369);for(;this['onDisconnectRequestQueue_']['length'];){const _0x4b606c=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x4b606c['action'],_0x4b606c['pathString'],_0x4b606c['data'],_0x4b606c['onComplete']);}for(let _0x4eb1d3=0x0;_0x4eb1d3<this['outstandingGets_']['length'];_0x4eb1d3++)this['outstandingGets_'][_0x4eb1d3]&&this['sendGet_'](_0x4eb1d3);}['sendConnectStats_'](){const _0x21d424={};let _0x5334a8='js';_0x21d424['sdk.'+_0x5334a8+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x21d424['framework.cordova']=0x1:Yr()&&(_0x21d424['framework.reactnative']=0x1),this['reportStats'](_0x21d424);}['shouldReconnect_'](){const _0x59cebe=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x59cebe;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0xb1db06,_0x28e12b){this['name']=_0xb1db06,this['node']=_0x28e12b;}static['Wrap'](_0x29d9ce,_0x482e7b){return new E(_0x29d9ce,_0x482e7b);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x6c079e,_0x353432){const _0x39846b=new E(Fe,_0x6c079e),_0x323e0f=new E(Fe,_0x353432);return this['compare'](_0x39846b,_0x323e0f)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x10770b){Zt=_0x10770b;}['compare'](_0x2d5b90,_0x2c03f0){return He(_0x2d5b90['name'],_0x2c03f0['name']);}['isDefinedOn'](_0x344c4a){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x3115fb,_0x2ff898){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x58caa8,_0x4b4e63){return f(typeof _0x58caa8=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x58caa8,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0xbd3680,_0x49d2b1,_0xd4ae84,_0x5b9d56,_0x3eaa2a=null){this['isReverse_']=_0x5b9d56,this['resultGenerator_']=_0x3eaa2a,this['nodeStack_']=[];let _0x45f94f=0x1;for(;!_0xbd3680['isEmpty']();)if(_0xbd3680=_0xbd3680,_0x45f94f=_0x49d2b1?_0xd4ae84(_0xbd3680['key'],_0x49d2b1):0x1,_0x5b9d56&&(_0x45f94f*=-0x1),_0x45f94f<0x0)this['isReverse_']?_0xbd3680=_0xbd3680['left']:_0xbd3680=_0xbd3680['right'];else{if(_0x45f94f===0x0){this['nodeStack_']['push'](_0xbd3680);break;}else this['nodeStack_']['push'](_0xbd3680),this['isReverse_']?_0xbd3680=_0xbd3680['right']:_0xbd3680=_0xbd3680['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x3b1023=this['nodeStack_']['pop'](),_0x5d2c81;if(this['resultGenerator_']?_0x5d2c81=this['resultGenerator_'](_0x3b1023['key'],_0x3b1023['value']):_0x5d2c81={'key':_0x3b1023['key'],'value':_0x3b1023['value']},this['isReverse_']){for(_0x3b1023=_0x3b1023['left'];!_0x3b1023['isEmpty']();)this['nodeStack_']['push'](_0x3b1023),_0x3b1023=_0x3b1023['right'];}else{for(_0x3b1023=_0x3b1023['right'];!_0x3b1023['isEmpty']();)this['nodeStack_']['push'](_0x3b1023),_0x3b1023=_0x3b1023['left'];}return _0x5d2c81;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x47d664=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x47d664['key'],_0x47d664['value']):{'key':_0x47d664['key'],'value':_0x47d664['value']};}}class M{constructor(_0x13b12e,_0x2f962b,_0xbafc6b,_0x428773,_0x222aa0){this['key']=_0x13b12e,this['value']=_0x2f962b,this['color']=_0xbafc6b??M['RED'],this['left']=_0x428773??B['EMPTY_NODE'],this['right']=_0x222aa0??B['EMPTY_NODE'];}['copy'](_0x45d8b4,_0x3bf3bf,_0x384c5e,_0x4e0980,_0x2bff57){return new M(_0x45d8b4??this['key'],_0x3bf3bf??this['value'],_0x384c5e??this['color'],_0x4e0980??this['left'],_0x2bff57??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x345ce5){return this['left']['inorderTraversal'](_0x345ce5)||!!_0x345ce5(this['key'],this['value'])||this['right']['inorderTraversal'](_0x345ce5);}['reverseTraversal'](_0xcfe0e9){return this['right']['reverseTraversal'](_0xcfe0e9)||_0xcfe0e9(this['key'],this['value'])||this['left']['reverseTraversal'](_0xcfe0e9);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x131937,_0x221ccf,_0x22c63b){let _0x4e6892=this;const _0x1a1323=_0x22c63b(_0x131937,_0x4e6892['key']);return _0x1a1323<0x0?_0x4e6892=_0x4e6892['copy'](null,null,null,_0x4e6892['left']['insert'](_0x131937,_0x221ccf,_0x22c63b),null):_0x1a1323===0x0?_0x4e6892=_0x4e6892['copy'](null,_0x221ccf,null,null,null):_0x4e6892=_0x4e6892['copy'](null,null,null,null,_0x4e6892['right']['insert'](_0x131937,_0x221ccf,_0x22c63b)),_0x4e6892['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x3c5542=this;return!_0x3c5542['left']['isRed_']()&&!_0x3c5542['left']['left']['isRed_']()&&(_0x3c5542=_0x3c5542['moveRedLeft_']()),_0x3c5542=_0x3c5542['copy'](null,null,null,_0x3c5542['left']['removeMin_'](),null),_0x3c5542['fixUp_']();}['remove'](_0x2f6c00,_0x284cdd){let _0x39fe93,_0x1d7150;if(_0x39fe93=this,_0x284cdd(_0x2f6c00,_0x39fe93['key'])<0x0)!_0x39fe93['left']['isEmpty']()&&!_0x39fe93['left']['isRed_']()&&!_0x39fe93['left']['left']['isRed_']()&&(_0x39fe93=_0x39fe93['moveRedLeft_']()),_0x39fe93=_0x39fe93['copy'](null,null,null,_0x39fe93['left']['remove'](_0x2f6c00,_0x284cdd),null);else{if(_0x39fe93['left']['isRed_']()&&(_0x39fe93=_0x39fe93['rotateRight_']()),!_0x39fe93['right']['isEmpty']()&&!_0x39fe93['right']['isRed_']()&&!_0x39fe93['right']['left']['isRed_']()&&(_0x39fe93=_0x39fe93['moveRedRight_']()),_0x284cdd(_0x2f6c00,_0x39fe93['key'])===0x0){if(_0x39fe93['right']['isEmpty']())return B['EMPTY_NODE'];_0x1d7150=_0x39fe93['right']['min_'](),_0x39fe93=_0x39fe93['copy'](_0x1d7150['key'],_0x1d7150['value'],null,null,_0x39fe93['right']['removeMin_']());}_0x39fe93=_0x39fe93['copy'](null,null,null,null,_0x39fe93['right']['remove'](_0x2f6c00,_0x284cdd));}return _0x39fe93['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x3dc1f0=this;return _0x3dc1f0['right']['isRed_']()&&!_0x3dc1f0['left']['isRed_']()&&(_0x3dc1f0=_0x3dc1f0['rotateLeft_']()),_0x3dc1f0['left']['isRed_']()&&_0x3dc1f0['left']['left']['isRed_']()&&(_0x3dc1f0=_0x3dc1f0['rotateRight_']()),_0x3dc1f0['left']['isRed_']()&&_0x3dc1f0['right']['isRed_']()&&(_0x3dc1f0=_0x3dc1f0['colorFlip_']()),_0x3dc1f0;}['moveRedLeft_'](){let _0x383798=this['colorFlip_']();return _0x383798['right']['left']['isRed_']()&&(_0x383798=_0x383798['copy'](null,null,null,null,_0x383798['right']['rotateRight_']()),_0x383798=_0x383798['rotateLeft_'](),_0x383798=_0x383798['colorFlip_']()),_0x383798;}['moveRedRight_'](){let _0x32979b=this['colorFlip_']();return _0x32979b['left']['left']['isRed_']()&&(_0x32979b=_0x32979b['rotateRight_'](),_0x32979b=_0x32979b['colorFlip_']()),_0x32979b;}['rotateLeft_'](){const _0x5edfd3=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x5edfd3,null);}['rotateRight_'](){const _0x571b96=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x571b96);}['colorFlip_'](){const _0x28ccd4=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x3d6455=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x28ccd4,_0x3d6455);}['checkMaxDepth_'](){const _0x378be7=this['check_']();return Math['pow'](0x2,_0x378be7)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2247db=this['left']['check_']();if(_0x2247db!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2247db+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0xc817b8,_0x3eb7d0,_0x2635c1,_0x4177c5,_0x1cd8f0){return this;}['insert'](_0x23aadd,_0x45ad88,_0x54f371){return new M(_0x23aadd,_0x45ad88,null);}['remove'](_0x2dca81,_0x1a7c1a){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0xfff8a2){return!0x1;}['reverseTraversal'](_0x4ab86f){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x68da40,_0x2ff5be=B['EMPTY_NODE']){this['comparator_']=_0x68da40,this['root_']=_0x2ff5be;}['insert'](_0x4aea45,_0x31d6a0){return new B(this['comparator_'],this['root_']['insert'](_0x4aea45,_0x31d6a0,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x2b5aa1){return new B(this['comparator_'],this['root_']['remove'](_0x2b5aa1,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x73c4ee){let _0x53e10d,_0xada2c=this['root_'];for(;!_0xada2c['isEmpty']();){if(_0x53e10d=this['comparator_'](_0x73c4ee,_0xada2c['key']),_0x53e10d===0x0)return _0xada2c['value'];_0x53e10d<0x0?_0xada2c=_0xada2c['left']:_0x53e10d>0x0&&(_0xada2c=_0xada2c['right']);}return null;}['getPredecessorKey'](_0x463833){let _0x2a24b0,_0x5a1b58=this['root_'],_0x4cf612=null;for(;!_0x5a1b58['isEmpty']();)if(_0x2a24b0=this['comparator_'](_0x463833,_0x5a1b58['key']),_0x2a24b0===0x0){if(_0x5a1b58['left']['isEmpty']())return _0x4cf612?_0x4cf612['key']:null;for(_0x5a1b58=_0x5a1b58['left'];!_0x5a1b58['right']['isEmpty']();)_0x5a1b58=_0x5a1b58['right'];return _0x5a1b58['key'];}else _0x2a24b0<0x0?_0x5a1b58=_0x5a1b58['left']:_0x2a24b0>0x0&&(_0x4cf612=_0x5a1b58,_0x5a1b58=_0x5a1b58['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x2e6d56){return this['root_']['inorderTraversal'](_0x2e6d56);}['reverseTraversal'](_0x338f3c){return this['root_']['reverseTraversal'](_0x338f3c);}['getIterator'](_0x5019a1){return new en(this['root_'],null,this['comparator_'],!0x1,_0x5019a1);}['getIteratorFrom'](_0x347b6c,_0x545ee7){return new en(this['root_'],_0x347b6c,this['comparator_'],!0x1,_0x545ee7);}['getReverseIteratorFrom'](_0x1cb122,_0xceedba){return new en(this['root_'],_0x1cb122,this['comparator_'],!0x0,_0xceedba);}['getReverseIterator'](_0x475c59){return new en(this['root_'],null,this['comparator_'],!0x0,_0x475c59);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x201e0f,_0x1fcab1){return He(_0x201e0f['name'],_0x1fcab1['name']);}function Yi(_0x635f92,_0x47d825){return He(_0x635f92,_0x47d825);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x558b2b){Ei=_0x558b2b;}const No=function(_0x343d24){return typeof _0x343d24=='number'?'number:'+ao(_0x343d24):'string:'+_0x343d24;},Po=function(_0x4707e9){if(_0x4707e9['isLeafNode']()){const _0x42404f=_0x4707e9['val']();f(typeof _0x42404f=='string'||typeof _0x42404f=='number'||typeof _0x42404f=='object'&&J(_0x42404f,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x4707e9===Ei||_0x4707e9['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x4707e9===Ei||_0x4707e9['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x5ac686){ir=_0x5ac686;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x4a9bfa,_0x4d4738=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x4a9bfa,this['priorityNode_']=_0x4d4738,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x415300){return new D(this['value_'],_0x415300);}['getImmediateChild'](_0x270b67){return _0x270b67==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x17ae41){return v(_0x17ae41)?this:y(_0x17ae41)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x55b448,_0x36afd6){return null;}['updateImmediateChild'](_0x5e39ce,_0x136242){return _0x5e39ce==='.priority'?this['updatePriority'](_0x136242):_0x136242['isEmpty']()&&_0x5e39ce!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x5e39ce,_0x136242)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x1c01be,_0x585d33){const _0x7ae1f9=y(_0x1c01be);return _0x7ae1f9===null?_0x585d33:_0x585d33['isEmpty']()&&_0x7ae1f9!=='.priority'?this:(f(_0x7ae1f9!=='.priority'||we(_0x1c01be)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x7ae1f9,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x1c01be),_0x585d33)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x2ce0fa,_0x5cd674){return!0x1;}['val'](_0x28648b){return _0x28648b&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x11a60d='';this['priorityNode_']['isEmpty']()||(_0x11a60d+='priority:'+No(this['priorityNode_']['val']())+':');const _0x54c0b0=typeof this['value_'];_0x11a60d+=_0x54c0b0+':',_0x54c0b0==='number'?_0x11a60d+=ao(this['value_']):_0x11a60d+=this['value_'],this['lazyHash_']=ro(_0x11a60d);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x4b9018){return _0x4b9018===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x4b9018 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x4b9018['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x4b9018));}['compareToLeafNode_'](_0x4508f8){const _0x578a49=typeof _0x4508f8['value_'],_0x4f7f3f=typeof this['value_'],_0x545a69=D['VALUE_TYPE_ORDER']['indexOf'](_0x578a49),_0x4dd15a=D['VALUE_TYPE_ORDER']['indexOf'](_0x4f7f3f);return f(_0x545a69>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x578a49),f(_0x4dd15a>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4f7f3f),_0x545a69===_0x4dd15a?_0x4f7f3f==='object'?0x0:this['value_']<_0x4508f8['value_']?-0x1:this['value_']===_0x4508f8['value_']?0x0:0x1:_0x4dd15a-_0x545a69;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0xe199fa){if(_0xe199fa===this)return!0x0;if(_0xe199fa['isLeafNode']()){const _0x1bb5aa=_0xe199fa;return this['value_']===_0x1bb5aa['value_']&&this['priorityNode_']['equals'](_0x1bb5aa['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x3f5bc5){Oo=_0x3f5bc5;}function Wh(_0x554ca5){Do=_0x554ca5;}class Bh extends Dn{['compare'](_0x22fb52,_0x47b867){const _0x334ff8=_0x22fb52['node']['getPriority'](),_0x19c61e=_0x47b867['node']['getPriority'](),_0x15edba=_0x334ff8['compareTo'](_0x19c61e);return _0x15edba===0x0?He(_0x22fb52['name'],_0x47b867['name']):_0x15edba;}['isDefinedOn'](_0x168e6f){return!_0x168e6f['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x5d4523,_0x15cc83){return!_0x5d4523['getPriority']()['equals'](_0x15cc83['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x42ab40,_0x5c2705){const _0x2afc30=Oo(_0x42ab40);return new E(_0x5c2705,new D('[PRIORITY-POST]',_0x2afc30));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x386049){const _0x36d328=_0x6985ef=>parseInt(Math['log'](_0x6985ef)/Vh,0xa),_0x153d20=_0x215ae5=>parseInt(Array(_0x215ae5+0x1)['join']('1'),0x2);this['count']=_0x36d328(_0x386049+0x1),this['current_']=this['count']-0x1;const _0x1ef7f0=_0x153d20(this['count']);this['bits_']=_0x386049+0x1&_0x1ef7f0;}['nextBitIsOne'](){const _0x7141bc=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x7141bc;}}const fn=function(_0x24d3c9,_0x3cbde2,_0x36a06c,_0x479fb8){_0x24d3c9['sort'](_0x3cbde2);const _0x5f08c1=function(_0x2ae330,_0x5c835c){const _0x2a1848=_0x5c835c-_0x2ae330;let _0x45e41b,_0x5ac076;if(_0x2a1848===0x0)return null;if(_0x2a1848===0x1)return _0x45e41b=_0x24d3c9[_0x2ae330],_0x5ac076=_0x36a06c?_0x36a06c(_0x45e41b):_0x45e41b,new M(_0x5ac076,_0x45e41b['node'],M['BLACK'],null,null);{const _0x2a8087=parseInt(_0x2a1848/0x2,0xa)+_0x2ae330,_0x369c8a=_0x5f08c1(_0x2ae330,_0x2a8087),_0x3c399e=_0x5f08c1(_0x2a8087+0x1,_0x5c835c);return _0x45e41b=_0x24d3c9[_0x2a8087],_0x5ac076=_0x36a06c?_0x36a06c(_0x45e41b):_0x45e41b,new M(_0x5ac076,_0x45e41b['node'],M['BLACK'],_0x369c8a,_0x3c399e);}},_0x2eac91=function(_0xa40086){let _0x412faa=null,_0x4d675b=null,_0x5c6a2f=_0x24d3c9['length'];const _0x4f211d=function(_0x14338f,_0x34ee44){const _0x57e1e8=_0x5c6a2f-_0x14338f,_0xa8f264=_0x5c6a2f;_0x5c6a2f-=_0x14338f;const _0x591ea6=_0x5f08c1(_0x57e1e8+0x1,_0xa8f264),_0x411dd4=_0x24d3c9[_0x57e1e8],_0x2732b9=_0x36a06c?_0x36a06c(_0x411dd4):_0x411dd4;_0xe33f45(new M(_0x2732b9,_0x411dd4['node'],_0x34ee44,null,_0x591ea6));},_0xe33f45=function(_0xb40633){_0x412faa?(_0x412faa['left']=_0xb40633,_0x412faa=_0xb40633):(_0x4d675b=_0xb40633,_0x412faa=_0xb40633);};for(let _0x3c68b0=0x0;_0x3c68b0<_0xa40086['count'];++_0x3c68b0){const _0x5c0908=_0xa40086['nextBitIsOne'](),_0x3580b4=Math['pow'](0x2,_0xa40086['count']-(_0x3c68b0+0x1));_0x5c0908?_0x4f211d(_0x3580b4,M['BLACK']):(_0x4f211d(_0x3580b4,M['BLACK']),_0x4f211d(_0x3580b4,M['RED']));}return _0x4d675b;},_0x542958=new Hh(_0x24d3c9['length']),_0x117828=_0x2eac91(_0x542958);return new B(_0x479fb8||_0x3cbde2,_0x117828);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x19c7c5,_0x11dee1){this['indexes_']=_0x19c7c5,this['indexSet_']=_0x11dee1;}['get'](_0x254e05){const _0xeadc9=De(this['indexes_'],_0x254e05);if(!_0xeadc9)throw new Error('No\x20index\x20defined\x20for\x20'+_0x254e05);return _0xeadc9 instanceof B?_0xeadc9:null;}['hasIndex'](_0x5dfd72){return J(this['indexSet_'],_0x5dfd72['toString']());}['addIndex'](_0x518156,_0x4051c0){f(_0x518156!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x2b936f=[];let _0xc09fed=!0x1;const _0x510fcb=_0x4051c0['getIterator'](E['Wrap']);let _0x138a71=_0x510fcb['getNext']();for(;_0x138a71;)_0xc09fed=_0xc09fed||_0x518156['isDefinedOn'](_0x138a71['node']),_0x2b936f['push'](_0x138a71),_0x138a71=_0x510fcb['getNext']();let _0x104803;_0xc09fed?_0x104803=fn(_0x2b936f,_0x518156['getCompare']()):_0x104803=ze;const _0x1ce067=_0x518156['toString'](),_0x433585={...this['indexSet_']};_0x433585[_0x1ce067]=_0x518156;const _0x56060b={...this['indexes_']};return _0x56060b[_0x1ce067]=_0x104803,new te(_0x56060b,_0x433585);}['addToIndexes'](_0xd7323a,_0x390ff8){const _0x14ce35=hn(this['indexes_'],(_0x31fbca,_0x542787)=>{const _0x38e3f8=De(this['indexSet_'],_0x542787);if(f(_0x38e3f8,'Missing\x20index\x20implementation\x20for\x20'+_0x542787),_0x31fbca===ze){if(_0x38e3f8['isDefinedOn'](_0xd7323a['node'])){const _0x3223cd=[],_0x5c6720=_0x390ff8['getIterator'](E['Wrap']);let _0x265a90=_0x5c6720['getNext']();for(;_0x265a90;)_0x265a90['name']!==_0xd7323a['name']&&_0x3223cd['push'](_0x265a90),_0x265a90=_0x5c6720['getNext']();return _0x3223cd['push'](_0xd7323a),fn(_0x3223cd,_0x38e3f8['getCompare']());}else return ze;}else{const _0x49f644=_0x390ff8['get'](_0xd7323a['name']);let _0x11551f=_0x31fbca;return _0x49f644&&(_0x11551f=_0x11551f['remove'](new E(_0xd7323a['name'],_0x49f644))),_0x11551f['insert'](_0xd7323a,_0xd7323a['node']);}});return new te(_0x14ce35,this['indexSet_']);}['removeFromIndexes'](_0x42df7e,_0x260406){const _0x3106c9=hn(this['indexes_'],_0x2598dc=>{if(_0x2598dc===ze)return _0x2598dc;{const _0x585529=_0x260406['get'](_0x42df7e['name']);return _0x585529?_0x2598dc['remove'](new E(_0x42df7e['name'],_0x585529)):_0x2598dc;}});return new te(_0x3106c9,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x1d3f0b,_0x88553a,_0xa4f817){this['children_']=_0x1d3f0b,this['priorityNode_']=_0x88553a,this['indexMap_']=_0xa4f817,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0xa43958){return this['children_']['isEmpty']()?this:new g(this['children_'],_0xa43958,this['indexMap_']);}['getImmediateChild'](_0x574c79){if(_0x574c79==='.priority')return this['getPriority']();{const _0x55a44d=this['children_']['get'](_0x574c79);return _0x55a44d===null?mt:_0x55a44d;}}['getChild'](_0x23e2f5){const _0x5758a1=y(_0x23e2f5);return _0x5758a1===null?this:this['getImmediateChild'](_0x5758a1)['getChild'](b(_0x23e2f5));}['hasChild'](_0x423380){return this['children_']['get'](_0x423380)!==null;}['updateImmediateChild'](_0x123434,_0x55cab1){if(f(_0x55cab1,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x123434==='.priority')return this['updatePriority'](_0x55cab1);{const _0xc0575b=new E(_0x123434,_0x55cab1);let _0x3c9e18,_0x256194;_0x55cab1['isEmpty']()?(_0x3c9e18=this['children_']['remove'](_0x123434),_0x256194=this['indexMap_']['removeFromIndexes'](_0xc0575b,this['children_'])):(_0x3c9e18=this['children_']['insert'](_0x123434,_0x55cab1),_0x256194=this['indexMap_']['addToIndexes'](_0xc0575b,this['children_']));const _0x306a9a=_0x3c9e18['isEmpty']()?mt:this['priorityNode_'];return new g(_0x3c9e18,_0x306a9a,_0x256194);}}['updateChild'](_0x38c509,_0x56c622){const _0x515d95=y(_0x38c509);if(_0x515d95===null)return _0x56c622;{f(y(_0x38c509)!=='.priority'||we(_0x38c509)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x4e5f91=this['getImmediateChild'](_0x515d95)['updateChild'](b(_0x38c509),_0x56c622);return this['updateImmediateChild'](_0x515d95,_0x4e5f91);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x10b351){if(this['isEmpty']())return null;const _0x3c86ce={};let _0x5d9891=0x0,_0x184ff9=0x0,_0x3e717f=!0x0;if(this['forEachChild'](R,(_0x53a943,_0x418048)=>{_0x3c86ce[_0x53a943]=_0x418048['val'](_0x10b351),_0x5d9891++,_0x3e717f&&g['INTEGER_REGEXP_']['test'](_0x53a943)?_0x184ff9=Math['max'](_0x184ff9,Number(_0x53a943)):_0x3e717f=!0x1;}),!_0x10b351&&_0x3e717f&&_0x184ff9<0x2*_0x5d9891){const _0x441845=[];for(const _0x6e11bf in _0x3c86ce)_0x441845[_0x6e11bf]=_0x3c86ce[_0x6e11bf];return _0x441845;}else return _0x10b351&&!this['getPriority']()['isEmpty']()&&(_0x3c86ce['.priority']=this['getPriority']()['val']()),_0x3c86ce;}['hash'](){if(this['lazyHash_']===null){let _0x4e0874='';this['getPriority']()['isEmpty']()||(_0x4e0874+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x4cb5a4,_0x18fa82)=>{const _0x70183a=_0x18fa82['hash']();_0x70183a!==''&&(_0x4e0874+=':'+_0x4cb5a4+':'+_0x70183a);}),this['lazyHash_']=_0x4e0874===''?'':ro(_0x4e0874);}return this['lazyHash_'];}['getPredecessorChildName'](_0x13841a,_0x7a68f3,_0x1b5df2){const _0x2c7207=this['resolveIndex_'](_0x1b5df2);if(_0x2c7207){const _0x566c2e=_0x2c7207['getPredecessorKey'](new E(_0x13841a,_0x7a68f3));return _0x566c2e?_0x566c2e['name']:null;}else return this['children_']['getPredecessorKey'](_0x13841a);}['getFirstChildName'](_0x17cd37){const _0x551397=this['resolveIndex_'](_0x17cd37);if(_0x551397){const _0x41ed3c=_0x551397['minKey']();return _0x41ed3c&&_0x41ed3c['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x1edab0){const _0x48f41d=this['getFirstChildName'](_0x1edab0);return _0x48f41d?new E(_0x48f41d,this['children_']['get'](_0x48f41d)):null;}['getLastChildName'](_0x32716a){const _0x5396bc=this['resolveIndex_'](_0x32716a);if(_0x5396bc){const _0x3c0c05=_0x5396bc['maxKey']();return _0x3c0c05&&_0x3c0c05['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x3b22e5){const _0xf5e18f=this['getLastChildName'](_0x3b22e5);return _0xf5e18f?new E(_0xf5e18f,this['children_']['get'](_0xf5e18f)):null;}['forEachChild'](_0x3da38a,_0xae136d){const _0x1c3332=this['resolveIndex_'](_0x3da38a);return _0x1c3332?_0x1c3332['inorderTraversal'](_0x29d2de=>_0xae136d(_0x29d2de['name'],_0x29d2de['node'])):this['children_']['inorderTraversal'](_0xae136d);}['getIterator'](_0xe3c9bd){return this['getIteratorFrom'](_0xe3c9bd['minPost'](),_0xe3c9bd);}['getIteratorFrom'](_0x7231ac,_0x551784){const _0x2b2483=this['resolveIndex_'](_0x551784);if(_0x2b2483)return _0x2b2483['getIteratorFrom'](_0x7231ac,_0x3d9aa8=>_0x3d9aa8);{const _0x114559=this['children_']['getIteratorFrom'](_0x7231ac['name'],E['Wrap']);let _0x5b4ec5=_0x114559['peek']();for(;_0x5b4ec5!=null&&_0x551784['compare'](_0x5b4ec5,_0x7231ac)<0x0;)_0x114559['getNext'](),_0x5b4ec5=_0x114559['peek']();return _0x114559;}}['getReverseIterator'](_0x4c0f72){return this['getReverseIteratorFrom'](_0x4c0f72['maxPost'](),_0x4c0f72);}['getReverseIteratorFrom'](_0x48d17c,_0xe882c6){const _0x19bdac=this['resolveIndex_'](_0xe882c6);if(_0x19bdac)return _0x19bdac['getReverseIteratorFrom'](_0x48d17c,_0x25fbad=>_0x25fbad);{const _0x14d307=this['children_']['getReverseIteratorFrom'](_0x48d17c['name'],E['Wrap']);let _0x4755ab=_0x14d307['peek']();for(;_0x4755ab!=null&&_0xe882c6['compare'](_0x4755ab,_0x48d17c)>0x0;)_0x14d307['getNext'](),_0x4755ab=_0x14d307['peek']();return _0x14d307;}}['compareTo'](_0x3ca75f){return this['isEmpty']()?_0x3ca75f['isEmpty']()?0x0:-0x1:_0x3ca75f['isLeafNode']()||_0x3ca75f['isEmpty']()?0x1:_0x3ca75f===$t?-0x1:0x0;}['withIndex'](_0x434b4a){if(_0x434b4a===ye||this['indexMap_']['hasIndex'](_0x434b4a))return this;{const _0x5457f8=this['indexMap_']['addIndex'](_0x434b4a,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x5457f8);}}['isIndexed'](_0x545094){return _0x545094===ye||this['indexMap_']['hasIndex'](_0x545094);}['equals'](_0x4227a9){if(_0x4227a9===this)return!0x0;if(_0x4227a9['isLeafNode']())return!0x1;{const _0x41be91=_0x4227a9;if(this['getPriority']()['equals'](_0x41be91['getPriority']())){if(this['children_']['count']()===_0x41be91['children_']['count']()){const _0x12c586=this['getIterator'](R),_0x104003=_0x41be91['getIterator'](R);let _0x34402c=_0x12c586['getNext'](),_0x1d486c=_0x104003['getNext']();for(;_0x34402c&&_0x1d486c;){if(_0x34402c['name']!==_0x1d486c['name']||!_0x34402c['node']['equals'](_0x1d486c['node']))return!0x1;_0x34402c=_0x12c586['getNext'](),_0x1d486c=_0x104003['getNext']();}return _0x34402c===null&&_0x1d486c===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x443180){return _0x443180===ye?null:this['indexMap_']['get'](_0x443180['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x556559){return _0x556559===this?0x0:0x1;}['equals'](_0x4ddcd6){return _0x4ddcd6===this;}['getPriority'](){return this;}['getImmediateChild'](_0x5daf3c){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x596e82,_0x271fd7=null){if(_0x596e82===null)return g['EMPTY_NODE'];if(typeof _0x596e82=='object'&&'.priority'in _0x596e82&&(_0x271fd7=_0x596e82['.priority']),f(_0x271fd7===null||typeof _0x271fd7=='string'||typeof _0x271fd7=='number'||typeof _0x271fd7=='object'&&'.sv'in _0x271fd7,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x271fd7),typeof _0x596e82=='object'&&'.value'in _0x596e82&&_0x596e82['.value']!==null&&(_0x596e82=_0x596e82['.value']),typeof _0x596e82!='object'||'.sv'in _0x596e82){const _0x4ed487=_0x596e82;return new D(_0x4ed487,P(_0x271fd7));}if(!(_0x596e82 instanceof Array)&&Gh){const _0x492d52=[];let _0x6ffc08=!0x1;if(x(_0x596e82,(_0x123d44,_0x254217)=>{if(_0x123d44['substring'](0x0,0x1)!=='.'){const _0x30d192=P(_0x254217);_0x30d192['isEmpty']()||(_0x6ffc08=_0x6ffc08||!_0x30d192['getPriority']()['isEmpty'](),_0x492d52['push'](new E(_0x123d44,_0x30d192)));}}),_0x492d52['length']===0x0)return g['EMPTY_NODE'];const _0x125738=fn(_0x492d52,xh,_0x3e384e=>_0x3e384e['name'],Yi);if(_0x6ffc08){const _0xa4c34b=fn(_0x492d52,R['getCompare']());return new g(_0x125738,P(_0x271fd7),new te({'.priority':_0xa4c34b},{'.priority':R}));}else return new g(_0x125738,P(_0x271fd7),te['Default']);}else{let _0x180262=g['EMPTY_NODE'];return x(_0x596e82,(_0x516107,_0x56c378)=>{if(J(_0x596e82,_0x516107)&&_0x516107['substring'](0x0,0x1)!=='.'){const _0x1d2f5d=P(_0x56c378);(_0x1d2f5d['isLeafNode']()||!_0x1d2f5d['isEmpty']())&&(_0x180262=_0x180262['updateImmediateChild'](_0x516107,_0x1d2f5d));}}),_0x180262['updatePriority'](P(_0x271fd7));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x36f379){super(),this['indexPath_']=_0x36f379,f(!v(_0x36f379)&&y(_0x36f379)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x51bf36){return _0x51bf36['getChild'](this['indexPath_']);}['isDefinedOn'](_0x2f1b17){return!_0x2f1b17['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x4929ae,_0x31c6f2){const _0x2c522e=this['extractChild'](_0x4929ae['node']),_0xfabaf6=this['extractChild'](_0x31c6f2['node']),_0x3b69f5=_0x2c522e['compareTo'](_0xfabaf6);return _0x3b69f5===0x0?He(_0x4929ae['name'],_0x31c6f2['name']):_0x3b69f5;}['makePost'](_0x1568bc,_0x26a15c){const _0x2203eb=P(_0x1568bc),_0x4228a7=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x2203eb);return new E(_0x26a15c,_0x4228a7);}['maxPost'](){const _0x4e3c95=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x4e3c95);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x523206,_0x39b515){const _0x357b18=_0x523206['node']['compareTo'](_0x39b515['node']);return _0x357b18===0x0?He(_0x523206['name'],_0x39b515['name']):_0x357b18;}['isDefinedOn'](_0x5aaf85){return!0x0;}['indexedValueChanged'](_0x5d4eed,_0x189cc0){return!_0x5d4eed['equals'](_0x189cc0);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x1f859d,_0x3f4604){const _0x4f9d0d=P(_0x1f859d);return new E(_0x3f4604,_0x4f9d0d);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x40f98a){return{'type':'value','snapshotNode':_0x40f98a};}function et(_0x4169e0,_0xe0db76){return{'type':'child_added','snapshotNode':_0xe0db76,'childName':_0x4169e0};}function Ot(_0x46ccaf,_0x6f7c6d){return{'type':'child_removed','snapshotNode':_0x6f7c6d,'childName':_0x46ccaf};}function Dt(_0x5c2f6f,_0x4bc411,_0x72be15){return{'type':'child_changed','snapshotNode':_0x4bc411,'childName':_0x5c2f6f,'oldSnap':_0x72be15};}function zh(_0x1499f3,_0x145f4a){return{'type':'child_moved','snapshotNode':_0x145f4a,'childName':_0x1499f3};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x2fef3c){this['index_']=_0x2fef3c;}['updateChild'](_0x4f94db,_0x44194d,_0x256afa,_0x116bf2,_0x3a3927,_0x414428){f(_0x4f94db['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x29f9e5=_0x4f94db['getImmediateChild'](_0x44194d);return _0x29f9e5['getChild'](_0x116bf2)['equals'](_0x256afa['getChild'](_0x116bf2))&&_0x29f9e5['isEmpty']()===_0x256afa['isEmpty']()||(_0x414428!=null&&(_0x256afa['isEmpty']()?_0x4f94db['hasChild'](_0x44194d)?_0x414428['trackChildChange'](Ot(_0x44194d,_0x29f9e5)):f(_0x4f94db['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x29f9e5['isEmpty']()?_0x414428['trackChildChange'](et(_0x44194d,_0x256afa)):_0x414428['trackChildChange'](Dt(_0x44194d,_0x256afa,_0x29f9e5))),_0x4f94db['isLeafNode']()&&_0x256afa['isEmpty']())?_0x4f94db:_0x4f94db['updateImmediateChild'](_0x44194d,_0x256afa)['withIndex'](this['index_']);}['updateFullNode'](_0x4f79df,_0x4d0dca,_0x29e385){return _0x29e385!=null&&(_0x4f79df['isLeafNode']()||_0x4f79df['forEachChild'](R,(_0x11bf8f,_0x545266)=>{_0x4d0dca['hasChild'](_0x11bf8f)||_0x29e385['trackChildChange'](Ot(_0x11bf8f,_0x545266));}),_0x4d0dca['isLeafNode']()||_0x4d0dca['forEachChild'](R,(_0x404055,_0x536b34)=>{if(_0x4f79df['hasChild'](_0x404055)){const _0x2b27c6=_0x4f79df['getImmediateChild'](_0x404055);_0x2b27c6['equals'](_0x536b34)||_0x29e385['trackChildChange'](Dt(_0x404055,_0x536b34,_0x2b27c6));}else _0x29e385['trackChildChange'](et(_0x404055,_0x536b34));})),_0x4d0dca['withIndex'](this['index_']);}['updatePriority'](_0x1303c3,_0x16e2b8){return _0x1303c3['isEmpty']()?g['EMPTY_NODE']:_0x1303c3['updatePriority'](_0x16e2b8);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x2e72d7){this['indexedFilter_']=new Ji(_0x2e72d7['getIndex']()),this['index_']=_0x2e72d7['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x2e72d7),this['endPost_']=Mt['getEndPost_'](_0x2e72d7),this['startIsInclusive_']=!_0x2e72d7['startAfterSet_'],this['endIsInclusive_']=!_0x2e72d7['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0xc3c4bb){const _0x3c599b=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0xc3c4bb)<=0x0:this['index_']['compare'](this['getStartPost'](),_0xc3c4bb)<0x0,_0x2019c7=this['endIsInclusive_']?this['index_']['compare'](_0xc3c4bb,this['getEndPost']())<=0x0:this['index_']['compare'](_0xc3c4bb,this['getEndPost']())<0x0;return _0x3c599b&&_0x2019c7;}['updateChild'](_0x48b237,_0x218972,_0x140528,_0x4e490a,_0x1eded3,_0x29e6d4){return this['matches'](new E(_0x218972,_0x140528))||(_0x140528=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x48b237,_0x218972,_0x140528,_0x4e490a,_0x1eded3,_0x29e6d4);}['updateFullNode'](_0x44a993,_0x3fb964,_0x1d0abd){_0x3fb964['isLeafNode']()&&(_0x3fb964=g['EMPTY_NODE']);let _0xbebdeb=_0x3fb964['withIndex'](this['index_']);_0xbebdeb=_0xbebdeb['updatePriority'](g['EMPTY_NODE']);const _0x3fb424=this;return _0x3fb964['forEachChild'](R,(_0x2aefff,_0x2a7a37)=>{_0x3fb424['matches'](new E(_0x2aefff,_0x2a7a37))||(_0xbebdeb=_0xbebdeb['updateImmediateChild'](_0x2aefff,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x44a993,_0xbebdeb,_0x1d0abd);}['updatePriority'](_0x24ce86,_0x473660){return _0x24ce86;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x41c478){if(_0x41c478['hasStart']()){const _0x29c03e=_0x41c478['getIndexStartName']();return _0x41c478['getIndex']()['makePost'](_0x41c478['getIndexStartValue'](),_0x29c03e);}else return _0x41c478['getIndex']()['minPost']();}static['getEndPost_'](_0x119c2e){if(_0x119c2e['hasEnd']()){const _0x215a6f=_0x119c2e['getIndexEndName']();return _0x119c2e['getIndex']()['makePost'](_0x119c2e['getIndexEndValue'](),_0x215a6f);}else return _0x119c2e['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x53ba69){this['withinDirectionalStart']=_0xe7da68=>this['reverse_']?this['withinEndPost'](_0xe7da68):this['withinStartPost'](_0xe7da68),this['withinDirectionalEnd']=_0x567d7d=>this['reverse_']?this['withinStartPost'](_0x567d7d):this['withinEndPost'](_0x567d7d),this['withinStartPost']=_0x10768b=>{const _0x3ed59a=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x10768b);return this['startIsInclusive_']?_0x3ed59a<=0x0:_0x3ed59a<0x0;},this['withinEndPost']=_0x11a5ae=>{const _0x52a55b=this['index_']['compare'](_0x11a5ae,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x52a55b<=0x0:_0x52a55b<0x0;},this['rangedFilter_']=new Mt(_0x53ba69),this['index_']=_0x53ba69['getIndex'](),this['limit_']=_0x53ba69['getLimit'](),this['reverse_']=!_0x53ba69['isViewFromLeft'](),this['startIsInclusive_']=!_0x53ba69['startAfterSet_'],this['endIsInclusive_']=!_0x53ba69['endBeforeSet_'];}['updateChild'](_0x4e31c8,_0x2a398d,_0x5b974c,_0x3bab2d,_0xb8d8dd,_0x3dba35){return this['rangedFilter_']['matches'](new E(_0x2a398d,_0x5b974c))||(_0x5b974c=g['EMPTY_NODE']),_0x4e31c8['getImmediateChild'](_0x2a398d)['equals'](_0x5b974c)?_0x4e31c8:_0x4e31c8['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x4e31c8,_0x2a398d,_0x5b974c,_0x3bab2d,_0xb8d8dd,_0x3dba35):this['fullLimitUpdateChild_'](_0x4e31c8,_0x2a398d,_0x5b974c,_0xb8d8dd,_0x3dba35);}['updateFullNode'](_0x586f48,_0x41d49b,_0x1ccc9f){let _0x2a2c1c;if(_0x41d49b['isLeafNode']()||_0x41d49b['isEmpty']())_0x2a2c1c=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x41d49b['numChildren']()&&_0x41d49b['isIndexed'](this['index_'])){_0x2a2c1c=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x255fce;this['reverse_']?_0x255fce=_0x41d49b['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x255fce=_0x41d49b['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x23283d=0x0;for(;_0x255fce['hasNext']()&&_0x23283d<this['limit_'];){const _0x5b472d=_0x255fce['getNext']();if(this['withinDirectionalStart'](_0x5b472d)){if(this['withinDirectionalEnd'](_0x5b472d))_0x2a2c1c=_0x2a2c1c['updateImmediateChild'](_0x5b472d['name'],_0x5b472d['node']),_0x23283d++;else break;}else continue;}}else{_0x2a2c1c=_0x41d49b['withIndex'](this['index_']),_0x2a2c1c=_0x2a2c1c['updatePriority'](g['EMPTY_NODE']);let _0x2279eb;this['reverse_']?_0x2279eb=_0x2a2c1c['getReverseIterator'](this['index_']):_0x2279eb=_0x2a2c1c['getIterator'](this['index_']);let _0x2c399b=0x0;for(;_0x2279eb['hasNext']();){const _0x11ebc9=_0x2279eb['getNext']();_0x2c399b<this['limit_']&&this['withinDirectionalStart'](_0x11ebc9)&&this['withinDirectionalEnd'](_0x11ebc9)?_0x2c399b++:_0x2a2c1c=_0x2a2c1c['updateImmediateChild'](_0x11ebc9['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x586f48,_0x2a2c1c,_0x1ccc9f);}['updatePriority'](_0xaac5f9,_0x4739da){return _0xaac5f9;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x2bb804,_0x5e1ca3,_0x38bc99,_0x538b6c,_0x5af451){let _0x499941;if(this['reverse_']){const _0x7871a7=this['index_']['getCompare']();_0x499941=(_0x36c74b,_0x54ed90)=>_0x7871a7(_0x54ed90,_0x36c74b);}else _0x499941=this['index_']['getCompare']();const _0x4a84bc=_0x2bb804;f(_0x4a84bc['numChildren']()===this['limit_'],'');const _0x26539d=new E(_0x5e1ca3,_0x38bc99),_0x608eab=this['reverse_']?_0x4a84bc['getFirstChild'](this['index_']):_0x4a84bc['getLastChild'](this['index_']),_0x1c991d=this['rangedFilter_']['matches'](_0x26539d);if(_0x4a84bc['hasChild'](_0x5e1ca3)){const _0x34aa9b=_0x4a84bc['getImmediateChild'](_0x5e1ca3);let _0x5744ea=_0x538b6c['getChildAfterChild'](this['index_'],_0x608eab,this['reverse_']);for(;_0x5744ea!=null&&(_0x5744ea['name']===_0x5e1ca3||_0x4a84bc['hasChild'](_0x5744ea['name']));)_0x5744ea=_0x538b6c['getChildAfterChild'](this['index_'],_0x5744ea,this['reverse_']);const _0xfa5827=_0x5744ea==null?0x1:_0x499941(_0x5744ea,_0x26539d);if(_0x1c991d&&!_0x38bc99['isEmpty']()&&_0xfa5827>=0x0)return _0x5af451!=null&&_0x5af451['trackChildChange'](Dt(_0x5e1ca3,_0x38bc99,_0x34aa9b)),_0x4a84bc['updateImmediateChild'](_0x5e1ca3,_0x38bc99);{_0x5af451!=null&&_0x5af451['trackChildChange'](Ot(_0x5e1ca3,_0x34aa9b));const _0x157444=_0x4a84bc['updateImmediateChild'](_0x5e1ca3,g['EMPTY_NODE']);return _0x5744ea!=null&&this['rangedFilter_']['matches'](_0x5744ea)?(_0x5af451!=null&&_0x5af451['trackChildChange'](et(_0x5744ea['name'],_0x5744ea['node'])),_0x157444['updateImmediateChild'](_0x5744ea['name'],_0x5744ea['node'])):_0x157444;}}else return _0x38bc99['isEmpty']()?_0x2bb804:_0x1c991d&&_0x499941(_0x608eab,_0x26539d)>=0x0?(_0x5af451!=null&&(_0x5af451['trackChildChange'](Ot(_0x608eab['name'],_0x608eab['node'])),_0x5af451['trackChildChange'](et(_0x5e1ca3,_0x38bc99))),_0x4a84bc['updateImmediateChild'](_0x5e1ca3,_0x38bc99)['updateImmediateChild'](_0x608eab['name'],g['EMPTY_NODE'])):_0x2bb804;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0xce3adf=new Xi();return _0xce3adf['limitSet_']=this['limitSet_'],_0xce3adf['limit_']=this['limit_'],_0xce3adf['startSet_']=this['startSet_'],_0xce3adf['startAfterSet_']=this['startAfterSet_'],_0xce3adf['indexStartValue_']=this['indexStartValue_'],_0xce3adf['startNameSet_']=this['startNameSet_'],_0xce3adf['indexStartName_']=this['indexStartName_'],_0xce3adf['endSet_']=this['endSet_'],_0xce3adf['endBeforeSet_']=this['endBeforeSet_'],_0xce3adf['indexEndValue_']=this['indexEndValue_'],_0xce3adf['endNameSet_']=this['endNameSet_'],_0xce3adf['indexEndName_']=this['indexEndName_'],_0xce3adf['index_']=this['index_'],_0xce3adf['viewFrom_']=this['viewFrom_'],_0xce3adf;}}function Kh(_0x193bc1){return _0x193bc1['loadsAllData']()?new Ji(_0x193bc1['getIndex']()):_0x193bc1['hasLimit']()?new jh(_0x193bc1):new Mt(_0x193bc1);}function Yh(_0x4ce4ff,_0x585c38){const _0x5da837=_0x4ce4ff['copy']();return _0x5da837['limitSet_']=!0x0,_0x5da837['limit_']=_0x585c38,_0x5da837['viewFrom_']='l',_0x5da837;}function Qh(_0x58d7e6,_0x2aa032,_0x24319b){const _0x1d1a76=_0x58d7e6['copy']();return _0x1d1a76['startSet_']=!0x0,_0x2aa032===void 0x0&&(_0x2aa032=null),_0x1d1a76['indexStartValue_']=_0x2aa032,_0x24319b!=null?(_0x1d1a76['startNameSet_']=!0x0,_0x1d1a76['indexStartName_']=_0x24319b):(_0x1d1a76['startNameSet_']=!0x1,_0x1d1a76['indexStartName_']=''),_0x1d1a76;}function Jh(_0x22a22f,_0x26e103,_0x5cad51){const _0x4122f0=_0x22a22f['copy']();return _0x4122f0['endSet_']=!0x0,_0x26e103===void 0x0&&(_0x26e103=null),_0x4122f0['indexEndValue_']=_0x26e103,_0x5cad51!==void 0x0?(_0x4122f0['endNameSet_']=!0x0,_0x4122f0['indexEndName_']=_0x5cad51):(_0x4122f0['endNameSet_']=!0x1,_0x4122f0['indexEndName_']=''),_0x4122f0;}function xo(_0x1c061a,_0x5d8d89){const _0x1e1f05=_0x1c061a['copy']();return _0x1e1f05['index_']=_0x5d8d89,_0x1e1f05;}function sr(_0x162e88){const _0x436757={};if(_0x162e88['isDefault']())return _0x436757;let _0x5a3c8f;if(_0x162e88['index_']===R?_0x5a3c8f='$priority':_0x162e88['index_']===Mo?_0x5a3c8f='$value':_0x162e88['index_']===ye?_0x5a3c8f='$key':(f(_0x162e88['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x5a3c8f=_0x162e88['index_']['toString']()),_0x436757['orderBy']=O(_0x5a3c8f),_0x162e88['startSet_']){const _0x1baac9=_0x162e88['startAfterSet_']?'startAfter':'startAt';_0x436757[_0x1baac9]=O(_0x162e88['indexStartValue_']),_0x162e88['startNameSet_']&&(_0x436757[_0x1baac9]+=','+O(_0x162e88['indexStartName_']));}if(_0x162e88['endSet_']){const _0x1b2324=_0x162e88['endBeforeSet_']?'endBefore':'endAt';_0x436757[_0x1b2324]=O(_0x162e88['indexEndValue_']),_0x162e88['endNameSet_']&&(_0x436757[_0x1b2324]+=','+O(_0x162e88['indexEndName_']));}return _0x162e88['limitSet_']&&(_0x162e88['isViewFromLeft']()?_0x436757['limitToFirst']=_0x162e88['limit_']:_0x436757['limitToLast']=_0x162e88['limit_']),_0x436757;}function rr(_0x1fc4bb){const _0x126f4c={};if(_0x1fc4bb['startSet_']&&(_0x126f4c['sp']=_0x1fc4bb['indexStartValue_'],_0x1fc4bb['startNameSet_']&&(_0x126f4c['sn']=_0x1fc4bb['indexStartName_']),_0x126f4c['sin']=!_0x1fc4bb['startAfterSet_']),_0x1fc4bb['endSet_']&&(_0x126f4c['ep']=_0x1fc4bb['indexEndValue_'],_0x1fc4bb['endNameSet_']&&(_0x126f4c['en']=_0x1fc4bb['indexEndName_']),_0x126f4c['ein']=!_0x1fc4bb['endBeforeSet_']),_0x1fc4bb['limitSet_']){_0x126f4c['l']=_0x1fc4bb['limit_'];let _0xb5423d=_0x1fc4bb['viewFrom_'];_0xb5423d===''&&(_0x1fc4bb['isViewFromLeft']()?_0xb5423d='l':_0xb5423d='r'),_0x126f4c['vf']=_0xb5423d;}return _0x1fc4bb['index_']!==R&&(_0x126f4c['i']=_0x1fc4bb['index_']['toString']()),_0x126f4c;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x260e91){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x15017e,_0x364066){return _0x364066!==void 0x0?'tag$'+_0x364066:(f(_0x15017e['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x15017e['_path']['toString']());}constructor(_0x57e4ad,_0x7005cd,_0x13c069,_0x4eadd2){super(),this['repoInfo_']=_0x57e4ad,this['onDataUpdate_']=_0x7005cd,this['authTokenProvider_']=_0x13c069,this['appCheckTokenProvider_']=_0x4eadd2,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x12d181,_0x560f92,_0x4931d5,_0x1c9922){const _0x153a91=_0x12d181['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x153a91+'\x20'+_0x12d181['_queryIdentifier']);const _0x1dc9b0=pn['getListenId_'](_0x12d181,_0x4931d5),_0x51c51b={};this['listens_'][_0x1dc9b0]=_0x51c51b;const _0x1e37d5=sr(_0x12d181['_queryParams']);this['restRequest_'](_0x153a91+'.json',_0x1e37d5,(_0x13b5fb,_0x2adb26)=>{let _0x1e65b3=_0x2adb26;if(_0x13b5fb===0x194&&(_0x1e65b3=null,_0x13b5fb=null),_0x13b5fb===null&&this['onDataUpdate_'](_0x153a91,_0x1e65b3,!0x1,_0x4931d5),De(this['listens_'],_0x1dc9b0)===_0x51c51b){let _0x4c55ef;_0x13b5fb?_0x13b5fb===0x191?_0x4c55ef='permission_denied':_0x4c55ef='rest_error:'+_0x13b5fb:_0x4c55ef='ok',_0x1c9922(_0x4c55ef,null);}});}['unlisten'](_0x184efb,_0x1f0614){const _0x1b3b68=pn['getListenId_'](_0x184efb,_0x1f0614);delete this['listens_'][_0x1b3b68];}['get'](_0x17199b){const _0x13adc6=sr(_0x17199b['_queryParams']),_0x523bc5=_0x17199b['_path']['toString'](),_0x3d6006=new ot();return this['restRequest_'](_0x523bc5+'.json',_0x13adc6,(_0x2b7c10,_0x4275fa)=>{let _0x5cfa61=_0x4275fa;_0x2b7c10===0x194&&(_0x5cfa61=null,_0x2b7c10=null),_0x2b7c10===null?(this['onDataUpdate_'](_0x523bc5,_0x5cfa61,!0x1,null),_0x3d6006['resolve'](_0x5cfa61)):_0x3d6006['reject'](new Error(_0x5cfa61));}),_0x3d6006['promise'];}['refreshAuthToken'](_0xd26101){}['restRequest_'](_0x59d062,_0x2fd4a9={},_0x3ed8aa){return _0x2fd4a9['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x1125e8,_0x524984])=>{_0x1125e8&&_0x1125e8['accessToken']&&(_0x2fd4a9['auth']=_0x1125e8['accessToken']),_0x524984&&_0x524984['token']&&(_0x2fd4a9['ac']=_0x524984['token']);const _0x2168f3=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x59d062+'?ns='+this['repoInfo_']['namespace']+ct(_0x2fd4a9);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x2168f3);const _0x58b2c2=new XMLHttpRequest();_0x58b2c2['onreadystatechange']=()=>{if(_0x3ed8aa&&_0x58b2c2['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x2168f3+'\x20received.\x20status:',_0x58b2c2['status'],'response:',_0x58b2c2['responseText']);let _0x2cd705=null;if(_0x58b2c2['status']>=0xc8&&_0x58b2c2['status']<0x12c){try{_0x2cd705=At(_0x58b2c2['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x2168f3+':\x20'+_0x58b2c2['responseText']);}_0x3ed8aa(null,_0x2cd705);}else _0x58b2c2['status']!==0x191&&_0x58b2c2['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x2168f3+'\x20Status:\x20'+_0x58b2c2['status']),_0x3ed8aa(_0x58b2c2['status']);_0x3ed8aa=null;}},_0x58b2c2['open']('GET',_0x2168f3,!0x0),_0x58b2c2['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x37993d){return this['rootNode_']['getChild'](_0x37993d);}['updateSnapshot'](_0x27bd3c,_0x3ba1f3){this['rootNode_']=this['rootNode_']['updateChild'](_0x27bd3c,_0x3ba1f3);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0xaad551,_0x12e04e,_0x18f19f){if(v(_0x12e04e))_0xaad551['value']=_0x18f19f,_0xaad551['children']['clear']();else{if(_0xaad551['value']!==null)_0xaad551['value']=_0xaad551['value']['updateChild'](_0x12e04e,_0x18f19f);else{const _0x451bf3=y(_0x12e04e);_0xaad551['children']['has'](_0x451bf3)||_0xaad551['children']['set'](_0x451bf3,_n());const _0x5490d1=_0xaad551['children']['get'](_0x451bf3);_0x12e04e=b(_0x12e04e),Fo(_0x5490d1,_0x12e04e,_0x18f19f);}}}function Ii(_0x3be67a,_0x426e06,_0x564be6){_0x3be67a['value']!==null?_0x564be6(_0x426e06,_0x3be67a['value']):Zh(_0x3be67a,(_0x24c5fc,_0x53901e)=>{const _0x273573=new C(_0x426e06['toString']()+'/'+_0x24c5fc);Ii(_0x53901e,_0x273573,_0x564be6);});}function Zh(_0x59723f,_0x24b9ff){_0x59723f['children']['forEach']((_0x3a9f6d,_0x23a475)=>{_0x24b9ff(_0x23a475,_0x3a9f6d);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x540111){this['collection_']=_0x540111,this['last_']=null;}['get'](){const _0xb3b326=this['collection_']['get'](),_0x2b652b={..._0xb3b326};return this['last_']&&x(this['last_'],(_0x212cc5,_0x2138ce)=>{_0x2b652b[_0x212cc5]=_0x2b652b[_0x212cc5]-_0x2138ce;}),this['last_']=_0xb3b326,_0x2b652b;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x53f5c2,_0x3d8b8e){this['server_']=_0x3d8b8e,this['statsToReport_']={},this['statsListener_']=new eu(_0x53f5c2);const _0x568dbd=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x568dbd));}['reportStats_'](){const _0xc47302=this['statsListener_']['get'](),_0x94857e={};let _0x44dbe4=!0x1;x(_0xc47302,(_0x127696,_0xb29b1f)=>{_0xb29b1f>0x0&&J(this['statsToReport_'],_0x127696)&&(_0x94857e[_0x127696]=_0xb29b1f,_0x44dbe4=!0x0);}),_0x44dbe4&&this['server_']['reportStats'](_0x94857e),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x18167a){_0x18167a[_0x18167a['OVERWRITE']=0x0]='OVERWRITE',_0x18167a[_0x18167a['MERGE']=0x1]='MERGE',_0x18167a[_0x18167a['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x18167a[_0x18167a['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0xe6730c){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0xe6730c,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x4e62f1,_0x255f5e,_0x39f481){this['path']=_0x4e62f1,this['affectedTree']=_0x255f5e,this['revert']=_0x39f481,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x5dc8e8){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x4ea426=this['affectedTree']['subtree'](new C(_0x5dc8e8));return new gn(w(),_0x4ea426,this['revert']);}}else return f(y(this['path'])===_0x5dc8e8,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x40171c,_0x10fb56){this['source']=_0x40171c,this['path']=_0x10fb56,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x63a4d8){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x39fbbb,_0x129d02,_0x472bf0){this['source']=_0x39fbbb,this['path']=_0x129d02,this['snap']=_0x472bf0,this['type']=j['OVERWRITE'];}['operationForChild'](_0x1d91de){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x1d91de)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x19547b,_0x59a925,_0x1d3770){this['source']=_0x19547b,this['path']=_0x59a925,this['children']=_0x1d3770,this['type']=j['MERGE'];}['operationForChild'](_0x3d7254){if(v(this['path'])){const _0x5eef11=this['children']['subtree'](new C(_0x3d7254));return _0x5eef11['isEmpty']()?null:_0x5eef11['value']?new Ue(this['source'],w(),_0x5eef11['value']):new tt(this['source'],w(),_0x5eef11);}else return f(y(this['path'])===_0x3d7254,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x1490b7,_0x1338c4,_0x11e9c9){this['node_']=_0x1490b7,this['fullyInitialized_']=_0x1338c4,this['filtered_']=_0x11e9c9;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x535c52){if(v(_0x535c52))return this['isFullyInitialized']()&&!this['filtered_'];const _0x635070=y(_0x535c52);return this['isCompleteForChild'](_0x635070);}['isCompleteForChild'](_0x4df610){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x4df610);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x423325){this['query_']=_0x423325,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x3121de,_0x3f0717,_0x558619,_0x126a04){const _0x39e8a9=[],_0x4ba05c=[];return _0x3f0717['forEach'](_0x3f038f=>{_0x3f038f['type']==='child_changed'&&_0x3121de['index_']['indexedValueChanged'](_0x3f038f['oldSnap'],_0x3f038f['snapshotNode'])&&_0x4ba05c['push'](zh(_0x3f038f['childName'],_0x3f038f['snapshotNode']));}),yt(_0x3121de,_0x39e8a9,'child_removed',_0x3f0717,_0x126a04,_0x558619),yt(_0x3121de,_0x39e8a9,'child_added',_0x3f0717,_0x126a04,_0x558619),yt(_0x3121de,_0x39e8a9,'child_moved',_0x4ba05c,_0x126a04,_0x558619),yt(_0x3121de,_0x39e8a9,'child_changed',_0x3f0717,_0x126a04,_0x558619),yt(_0x3121de,_0x39e8a9,'value',_0x3f0717,_0x126a04,_0x558619),_0x39e8a9;}function yt(_0x126e8f,_0x2c9e53,_0x1a107e,_0x1c61dc,_0x3cee9f,_0x1f4389){const _0x429d17=_0x1c61dc['filter'](_0x4893e1=>_0x4893e1['type']===_0x1a107e);_0x429d17['sort']((_0x3a945c,_0x572404)=>au(_0x126e8f,_0x3a945c,_0x572404)),_0x429d17['forEach'](_0x5888b1=>{const _0x265d1e=ou(_0x126e8f,_0x5888b1,_0x1f4389);_0x3cee9f['forEach'](_0x46e42b=>{_0x46e42b['respondsTo'](_0x5888b1['type'])&&_0x2c9e53['push'](_0x46e42b['createEvent'](_0x265d1e,_0x126e8f['query_']));});});}function ou(_0x1604c4,_0x10c0fd,_0x95ffa5){return _0x10c0fd['type']==='value'||_0x10c0fd['type']==='child_removed'||(_0x10c0fd['prevName']=_0x95ffa5['getPredecessorChildName'](_0x10c0fd['childName'],_0x10c0fd['snapshotNode'],_0x1604c4['index_'])),_0x10c0fd;}function au(_0x16c5f6,_0x5e3375,_0x50c684){if(_0x5e3375['childName']==null||_0x50c684['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0xef32bc=new E(_0x5e3375['childName'],_0x5e3375['snapshotNode']),_0x4dafba=new E(_0x50c684['childName'],_0x50c684['snapshotNode']);return _0x16c5f6['index_']['compare'](_0xef32bc,_0x4dafba);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x253e58,_0x4adc0f){return{'eventCache':_0x253e58,'serverCache':_0x4adc0f};}function Tt(_0x27a1a4,_0x57f20b,_0x288c3b,_0x4607c7){return Mn(new Ce(_0x57f20b,_0x288c3b,_0x4607c7),_0x27a1a4['serverCache']);}function Uo(_0x277ce8,_0x39d72a,_0x4913c5,_0x28d4b3){return Mn(_0x277ce8['eventCache'],new Ce(_0x39d72a,_0x4913c5,_0x28d4b3));}function mn(_0x2f7519){return _0x2f7519['eventCache']['isFullyInitialized']()?_0x2f7519['eventCache']['getNode']():null;}function We(_0x57d38e){return _0x57d38e['serverCache']['isFullyInitialized']()?_0x57d38e['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0xd0666b){let _0x6c20dd=new S(null);return x(_0xd0666b,(_0x2b2e01,_0x4edb04)=>{_0x6c20dd=_0x6c20dd['set'](new C(_0x2b2e01),_0x4edb04);}),_0x6c20dd;}constructor(_0x51e331,_0x35f41f=cu()){this['value']=_0x51e331,this['children']=_0x35f41f;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x2fb04a,_0x1518e8){if(this['value']!=null&&_0x1518e8(this['value']))return{'path':w(),'value':this['value']};if(v(_0x2fb04a))return null;{const _0xb0a833=y(_0x2fb04a),_0x68dc7b=this['children']['get'](_0xb0a833);if(_0x68dc7b!==null){const _0x910b72=_0x68dc7b['findRootMostMatchingPathAndValue'](b(_0x2fb04a),_0x1518e8);return _0x910b72!=null?{'path':k(new C(_0xb0a833),_0x910b72['path']),'value':_0x910b72['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x12c7bd){return this['findRootMostMatchingPathAndValue'](_0x12c7bd,()=>!0x0);}['subtree'](_0x255bd1){if(v(_0x255bd1))return this;{const _0x176a21=y(_0x255bd1),_0x322742=this['children']['get'](_0x176a21);return _0x322742!==null?_0x322742['subtree'](b(_0x255bd1)):new S(null);}}['set'](_0x4c44c3,_0x522839){if(v(_0x4c44c3))return new S(_0x522839,this['children']);{const _0xc42581=y(_0x4c44c3),_0x203088=(this['children']['get'](_0xc42581)||new S(null))['set'](b(_0x4c44c3),_0x522839),_0x172761=this['children']['insert'](_0xc42581,_0x203088);return new S(this['value'],_0x172761);}}['remove'](_0x5948a8){if(v(_0x5948a8))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x5a7174=y(_0x5948a8),_0x596994=this['children']['get'](_0x5a7174);if(_0x596994){const _0x4c24f5=_0x596994['remove'](b(_0x5948a8));let _0x5faa7e;return _0x4c24f5['isEmpty']()?_0x5faa7e=this['children']['remove'](_0x5a7174):_0x5faa7e=this['children']['insert'](_0x5a7174,_0x4c24f5),this['value']===null&&_0x5faa7e['isEmpty']()?new S(null):new S(this['value'],_0x5faa7e);}else return this;}}['get'](_0xa415a2){if(v(_0xa415a2))return this['value'];{const _0x36afa9=y(_0xa415a2),_0x1e73bf=this['children']['get'](_0x36afa9);return _0x1e73bf?_0x1e73bf['get'](b(_0xa415a2)):null;}}['setTree'](_0x27536e,_0x230b05){if(v(_0x27536e))return _0x230b05;{const _0x3fc43e=y(_0x27536e),_0x1b1f76=(this['children']['get'](_0x3fc43e)||new S(null))['setTree'](b(_0x27536e),_0x230b05);let _0x1481a7;return _0x1b1f76['isEmpty']()?_0x1481a7=this['children']['remove'](_0x3fc43e):_0x1481a7=this['children']['insert'](_0x3fc43e,_0x1b1f76),new S(this['value'],_0x1481a7);}}['fold'](_0x26f553){return this['fold_'](w(),_0x26f553);}['fold_'](_0x402c83,_0x189b57){const _0x34b80b={};return this['children']['inorderTraversal']((_0x28d459,_0x1529a9)=>{_0x34b80b[_0x28d459]=_0x1529a9['fold_'](k(_0x402c83,_0x28d459),_0x189b57);}),_0x189b57(_0x402c83,this['value'],_0x34b80b);}['findOnPath'](_0x13dc29,_0x2b2ddc){return this['findOnPath_'](_0x13dc29,w(),_0x2b2ddc);}['findOnPath_'](_0x1e7140,_0x1820b1,_0x21fd31){const _0x55857b=this['value']?_0x21fd31(_0x1820b1,this['value']):!0x1;if(_0x55857b)return _0x55857b;if(v(_0x1e7140))return null;{const _0x464010=y(_0x1e7140),_0x38ad29=this['children']['get'](_0x464010);return _0x38ad29?_0x38ad29['findOnPath_'](b(_0x1e7140),k(_0x1820b1,_0x464010),_0x21fd31):null;}}['foreachOnPath'](_0x140ac1,_0x445884){return this['foreachOnPath_'](_0x140ac1,w(),_0x445884);}['foreachOnPath_'](_0x644e8b,_0x193aaa,_0x8dc1bd){if(v(_0x644e8b))return this;{this['value']&&_0x8dc1bd(_0x193aaa,this['value']);const _0xc40219=y(_0x644e8b),_0x56dc2c=this['children']['get'](_0xc40219);return _0x56dc2c?_0x56dc2c['foreachOnPath_'](b(_0x644e8b),k(_0x193aaa,_0xc40219),_0x8dc1bd):new S(null);}}['foreach'](_0x15f92d){this['foreach_'](w(),_0x15f92d);}['foreach_'](_0x153efd,_0x5c924b){this['children']['inorderTraversal']((_0x51da3f,_0x3778a3)=>{_0x3778a3['foreach_'](k(_0x153efd,_0x51da3f),_0x5c924b);}),this['value']&&_0x5c924b(_0x153efd,this['value']);}['foreachChild'](_0xb49120){this['children']['inorderTraversal']((_0xec62d3,_0x44ce11)=>{_0x44ce11['value']&&_0xb49120(_0xec62d3,_0x44ce11['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x22c401){this['writeTree_']=_0x22c401;}static['empty'](){return new Y(new S(null));}}function St(_0x498561,_0x225038,_0x5e01a6){if(v(_0x225038))return new Y(new S(_0x5e01a6));{const _0x5ecba6=_0x498561['writeTree_']['findRootMostValueAndPath'](_0x225038);if(_0x5ecba6!=null){const _0x162c11=_0x5ecba6['path'];let _0x2adae6=_0x5ecba6['value'];const _0x4fc0e8=F(_0x162c11,_0x225038);return _0x2adae6=_0x2adae6['updateChild'](_0x4fc0e8,_0x5e01a6),new Y(_0x498561['writeTree_']['set'](_0x162c11,_0x2adae6));}else{const _0x4ae905=new S(_0x5e01a6),_0x192bcd=_0x498561['writeTree_']['setTree'](_0x225038,_0x4ae905);return new Y(_0x192bcd);}}}function wi(_0x56bfd0,_0x5e5adc,_0xd24c8e){let _0x55b044=_0x56bfd0;return x(_0xd24c8e,(_0x2c7d41,_0x123f85)=>{_0x55b044=St(_0x55b044,k(_0x5e5adc,_0x2c7d41),_0x123f85);}),_0x55b044;}function ar(_0x1c4496,_0x157d5c){if(v(_0x157d5c))return Y['empty']();{const _0x78579b=_0x1c4496['writeTree_']['setTree'](_0x157d5c,new S(null));return new Y(_0x78579b);}}function Ci(_0x32be24,_0x11aa80){return $e(_0x32be24,_0x11aa80)!=null;}function $e(_0x52f0fa,_0x40bc54){const _0x353dd7=_0x52f0fa['writeTree_']['findRootMostValueAndPath'](_0x40bc54);return _0x353dd7!=null?_0x52f0fa['writeTree_']['get'](_0x353dd7['path'])['getChild'](F(_0x353dd7['path'],_0x40bc54)):null;}function cr(_0x324fd5){const _0x178da6=[],_0x62a14c=_0x324fd5['writeTree_']['value'];return _0x62a14c!=null?_0x62a14c['isLeafNode']()||_0x62a14c['forEachChild'](R,(_0x36488d,_0x2fc0dc)=>{_0x178da6['push'](new E(_0x36488d,_0x2fc0dc));}):_0x324fd5['writeTree_']['children']['inorderTraversal']((_0x21b4e2,_0x554a8d)=>{_0x554a8d['value']!=null&&_0x178da6['push'](new E(_0x21b4e2,_0x554a8d['value']));}),_0x178da6;}function ve(_0x564f5e,_0x4f0da3){if(v(_0x4f0da3))return _0x564f5e;{const _0x5d5865=$e(_0x564f5e,_0x4f0da3);return _0x5d5865!=null?new Y(new S(_0x5d5865)):new Y(_0x564f5e['writeTree_']['subtree'](_0x4f0da3));}}function Ti(_0xa0dabd){return _0xa0dabd['writeTree_']['isEmpty']();}function nt(_0x413806,_0x434fdc){return Wo(w(),_0x413806['writeTree_'],_0x434fdc);}function Wo(_0x2b6a3d,_0x2e1c9b,_0xc084fc){if(_0x2e1c9b['value']!=null)return _0xc084fc['updateChild'](_0x2b6a3d,_0x2e1c9b['value']);{let _0x11a0db=null;return _0x2e1c9b['children']['inorderTraversal']((_0x353f09,_0x2378a4)=>{_0x353f09==='.priority'?(f(_0x2378a4['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x11a0db=_0x2378a4['value']):_0xc084fc=Wo(k(_0x2b6a3d,_0x353f09),_0x2378a4,_0xc084fc);}),!_0xc084fc['getChild'](_0x2b6a3d)['isEmpty']()&&_0x11a0db!==null&&(_0xc084fc=_0xc084fc['updateChild'](k(_0x2b6a3d,'.priority'),_0x11a0db)),_0xc084fc;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x42e030,_0x2b7051){return $o(_0x2b7051,_0x42e030);}function lu(_0x139b5e,_0x3c4cbb,_0x2eb10f,_0x594194,_0x4cb4c0){f(_0x594194>_0x139b5e['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x4cb4c0===void 0x0&&(_0x4cb4c0=!0x0),_0x139b5e['allWrites']['push']({'path':_0x3c4cbb,'snap':_0x2eb10f,'writeId':_0x594194,'visible':_0x4cb4c0}),_0x4cb4c0&&(_0x139b5e['visibleWrites']=St(_0x139b5e['visibleWrites'],_0x3c4cbb,_0x2eb10f)),_0x139b5e['lastWriteId']=_0x594194;}function hu(_0x3baca7,_0x414471,_0x113602,_0x4f968d){f(_0x4f968d>_0x3baca7['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x3baca7['allWrites']['push']({'path':_0x414471,'children':_0x113602,'writeId':_0x4f968d,'visible':!0x0}),_0x3baca7['visibleWrites']=wi(_0x3baca7['visibleWrites'],_0x414471,_0x113602),_0x3baca7['lastWriteId']=_0x4f968d;}function uu(_0x5396e2,_0x335fc0){for(let _0x4e3ff8=0x0;_0x4e3ff8<_0x5396e2['allWrites']['length'];_0x4e3ff8++){const _0x42132b=_0x5396e2['allWrites'][_0x4e3ff8];if(_0x42132b['writeId']===_0x335fc0)return _0x42132b;}return null;}function du(_0x16b565,_0x1119ee){const _0xccc869=_0x16b565['allWrites']['findIndex'](_0x4bde5d=>_0x4bde5d['writeId']===_0x1119ee);f(_0xccc869>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x8cabd0=_0x16b565['allWrites'][_0xccc869];_0x16b565['allWrites']['splice'](_0xccc869,0x1);let _0x10fe9b=_0x8cabd0['visible'],_0x33af2c=!0x1,_0x343203=_0x16b565['allWrites']['length']-0x1;for(;_0x10fe9b&&_0x343203>=0x0;){const _0x138141=_0x16b565['allWrites'][_0x343203];_0x138141['visible']&&(_0x343203>=_0xccc869&&fu(_0x138141,_0x8cabd0['path'])?_0x10fe9b=!0x1:G(_0x8cabd0['path'],_0x138141['path'])&&(_0x33af2c=!0x0)),_0x343203--;}if(_0x10fe9b){if(_0x33af2c)return pu(_0x16b565),!0x0;if(_0x8cabd0['snap'])_0x16b565['visibleWrites']=ar(_0x16b565['visibleWrites'],_0x8cabd0['path']);else{const _0x262484=_0x8cabd0['children'];x(_0x262484,_0x383b28=>{_0x16b565['visibleWrites']=ar(_0x16b565['visibleWrites'],k(_0x8cabd0['path'],_0x383b28));});}return!0x0;}else return!0x1;}function fu(_0x37f921,_0x202748){if(_0x37f921['snap'])return G(_0x37f921['path'],_0x202748);for(const _0x19d9f1 in _0x37f921['children'])if(_0x37f921['children']['hasOwnProperty'](_0x19d9f1)&&G(k(_0x37f921['path'],_0x19d9f1),_0x202748))return!0x0;return!0x1;}function pu(_0x38d608){_0x38d608['visibleWrites']=Bo(_0x38d608['allWrites'],_u,w()),_0x38d608['allWrites']['length']>0x0?_0x38d608['lastWriteId']=_0x38d608['allWrites'][_0x38d608['allWrites']['length']-0x1]['writeId']:_0x38d608['lastWriteId']=-0x1;}function _u(_0x1273dc){return _0x1273dc['visible'];}function Bo(_0x17908e,_0x3f3598,_0x2412c7){let _0x5c89de=Y['empty']();for(let _0x425a08=0x0;_0x425a08<_0x17908e['length'];++_0x425a08){const _0x40eef9=_0x17908e[_0x425a08];if(_0x3f3598(_0x40eef9)){const _0x238753=_0x40eef9['path'];let _0x455cf7;if(_0x40eef9['snap'])G(_0x2412c7,_0x238753)?(_0x455cf7=F(_0x2412c7,_0x238753),_0x5c89de=St(_0x5c89de,_0x455cf7,_0x40eef9['snap'])):G(_0x238753,_0x2412c7)&&(_0x455cf7=F(_0x238753,_0x2412c7),_0x5c89de=St(_0x5c89de,w(),_0x40eef9['snap']['getChild'](_0x455cf7)));else{if(_0x40eef9['children']){if(G(_0x2412c7,_0x238753))_0x455cf7=F(_0x2412c7,_0x238753),_0x5c89de=wi(_0x5c89de,_0x455cf7,_0x40eef9['children']);else{if(G(_0x238753,_0x2412c7)){if(_0x455cf7=F(_0x238753,_0x2412c7),v(_0x455cf7))_0x5c89de=wi(_0x5c89de,w(),_0x40eef9['children']);else{const _0x1800d6=De(_0x40eef9['children'],y(_0x455cf7));if(_0x1800d6){const _0x1bb2aa=_0x1800d6['getChild'](b(_0x455cf7));_0x5c89de=St(_0x5c89de,w(),_0x1bb2aa);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x5c89de;}function Vo(_0x4cd24b,_0x5127c5,_0x19b9fc,_0x948183,_0x46f636){if(!_0x948183&&!_0x46f636){const _0x162c68=$e(_0x4cd24b['visibleWrites'],_0x5127c5);if(_0x162c68!=null)return _0x162c68;{const _0x44e813=ve(_0x4cd24b['visibleWrites'],_0x5127c5);if(Ti(_0x44e813))return _0x19b9fc;if(_0x19b9fc==null&&!Ci(_0x44e813,w()))return null;{const _0x592d8f=_0x19b9fc||g['EMPTY_NODE'];return nt(_0x44e813,_0x592d8f);}}}else{const _0x549f9e=ve(_0x4cd24b['visibleWrites'],_0x5127c5);if(!_0x46f636&&Ti(_0x549f9e))return _0x19b9fc;if(!_0x46f636&&_0x19b9fc==null&&!Ci(_0x549f9e,w()))return null;{const _0x2ad8d3=function(_0x52c9f5){return(_0x52c9f5['visible']||_0x46f636)&&(!_0x948183||!~_0x948183['indexOf'](_0x52c9f5['writeId']))&&(G(_0x52c9f5['path'],_0x5127c5)||G(_0x5127c5,_0x52c9f5['path']));},_0x3d5f73=Bo(_0x4cd24b['allWrites'],_0x2ad8d3,_0x5127c5),_0x46980c=_0x19b9fc||g['EMPTY_NODE'];return nt(_0x3d5f73,_0x46980c);}}}function gu(_0x41d229,_0xa6e9b7,_0x259add){let _0x2b0d7b=g['EMPTY_NODE'];const _0x1549f9=$e(_0x41d229['visibleWrites'],_0xa6e9b7);if(_0x1549f9)return _0x1549f9['isLeafNode']()||_0x1549f9['forEachChild'](R,(_0x2949b6,_0x91a48)=>{_0x2b0d7b=_0x2b0d7b['updateImmediateChild'](_0x2949b6,_0x91a48);}),_0x2b0d7b;if(_0x259add){const _0x113975=ve(_0x41d229['visibleWrites'],_0xa6e9b7);return _0x259add['forEachChild'](R,(_0x25f732,_0x4b4d4e)=>{const _0x1a9698=nt(ve(_0x113975,new C(_0x25f732)),_0x4b4d4e);_0x2b0d7b=_0x2b0d7b['updateImmediateChild'](_0x25f732,_0x1a9698);}),cr(_0x113975)['forEach'](_0x21e8f3=>{_0x2b0d7b=_0x2b0d7b['updateImmediateChild'](_0x21e8f3['name'],_0x21e8f3['node']);}),_0x2b0d7b;}else{const _0x5cc5c2=ve(_0x41d229['visibleWrites'],_0xa6e9b7);return cr(_0x5cc5c2)['forEach'](_0x92a5d=>{_0x2b0d7b=_0x2b0d7b['updateImmediateChild'](_0x92a5d['name'],_0x92a5d['node']);}),_0x2b0d7b;}}function mu(_0x4e8c3b,_0x3d89d9,_0x42e4a6,_0x217a67,_0x1d9064){f(_0x217a67||_0x1d9064,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x48dd5d=k(_0x3d89d9,_0x42e4a6);if(Ci(_0x4e8c3b['visibleWrites'],_0x48dd5d))return null;{const _0xdc1c62=ve(_0x4e8c3b['visibleWrites'],_0x48dd5d);return Ti(_0xdc1c62)?_0x1d9064['getChild'](_0x42e4a6):nt(_0xdc1c62,_0x1d9064['getChild'](_0x42e4a6));}}function yu(_0x346db8,_0x2fb4e0,_0x25721d,_0x4e9817){const _0x5e97d6=k(_0x2fb4e0,_0x25721d),_0xc796e0=$e(_0x346db8['visibleWrites'],_0x5e97d6);if(_0xc796e0!=null)return _0xc796e0;if(_0x4e9817['isCompleteForChild'](_0x25721d)){const _0x104902=ve(_0x346db8['visibleWrites'],_0x5e97d6);return nt(_0x104902,_0x4e9817['getNode']()['getImmediateChild'](_0x25721d));}else return null;}function vu(_0x1e5e18,_0x33acc2){return $e(_0x1e5e18['visibleWrites'],_0x33acc2);}function Eu(_0x14e408,_0x4aa66f,_0x5dfc85,_0x165979,_0x3d4cc7,_0xfdc8d1,_0xf89b5f){let _0x4862f5;const _0x390ccb=ve(_0x14e408['visibleWrites'],_0x4aa66f),_0x414da5=$e(_0x390ccb,w());if(_0x414da5!=null)_0x4862f5=_0x414da5;else{if(_0x5dfc85!=null)_0x4862f5=nt(_0x390ccb,_0x5dfc85);else return[];}if(_0x4862f5=_0x4862f5['withIndex'](_0xf89b5f),!_0x4862f5['isEmpty']()&&!_0x4862f5['isLeafNode']()){const _0x21a051=[],_0x26543a=_0xf89b5f['getCompare'](),_0x4ad6db=_0xfdc8d1?_0x4862f5['getReverseIteratorFrom'](_0x165979,_0xf89b5f):_0x4862f5['getIteratorFrom'](_0x165979,_0xf89b5f);let _0xd50f9d=_0x4ad6db['getNext']();for(;_0xd50f9d&&_0x21a051['length']<_0x3d4cc7;)_0x26543a(_0xd50f9d,_0x165979)!==0x0&&_0x21a051['push'](_0xd50f9d),_0xd50f9d=_0x4ad6db['getNext']();return _0x21a051;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x579f30,_0x2640d1,_0x204e96,_0xe69a1b){return Vo(_0x579f30['writeTree'],_0x579f30['treePath'],_0x2640d1,_0x204e96,_0xe69a1b);}function ns(_0x39696e,_0x4711a6){return gu(_0x39696e['writeTree'],_0x39696e['treePath'],_0x4711a6);}function lr(_0x387385,_0x1a504d,_0x5ee2aa,_0x339596){return mu(_0x387385['writeTree'],_0x387385['treePath'],_0x1a504d,_0x5ee2aa,_0x339596);}function vn(_0x3e9f7f,_0x5839bb){return vu(_0x3e9f7f['writeTree'],k(_0x3e9f7f['treePath'],_0x5839bb));}function wu(_0x2fd341,_0x3344f9,_0x14ff40,_0x1d706e,_0x1dae7c,_0x4641b1){return Eu(_0x2fd341['writeTree'],_0x2fd341['treePath'],_0x3344f9,_0x14ff40,_0x1d706e,_0x1dae7c,_0x4641b1);}function is(_0x5144ee,_0x16978a,_0x3dd5f7){return yu(_0x5144ee['writeTree'],_0x5144ee['treePath'],_0x16978a,_0x3dd5f7);}function Ho(_0x568e50,_0x77a8f3){return $o(k(_0x568e50['treePath'],_0x77a8f3),_0x568e50['writeTree']);}function $o(_0x2c8bab,_0x1a3536){return{'treePath':_0x2c8bab,'writeTree':_0x1a3536};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x5de422){const _0x5c9556=_0x5de422['type'],_0x5a49e2=_0x5de422['childName'];f(_0x5c9556==='child_added'||_0x5c9556==='child_changed'||_0x5c9556==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x5a49e2!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x137bec=this['changeMap']['get'](_0x5a49e2);if(_0x137bec){const _0x46c7d9=_0x137bec['type'];if(_0x5c9556==='child_added'&&_0x46c7d9==='child_removed')this['changeMap']['set'](_0x5a49e2,Dt(_0x5a49e2,_0x5de422['snapshotNode'],_0x137bec['snapshotNode']));else{if(_0x5c9556==='child_removed'&&_0x46c7d9==='child_added')this['changeMap']['delete'](_0x5a49e2);else{if(_0x5c9556==='child_removed'&&_0x46c7d9==='child_changed')this['changeMap']['set'](_0x5a49e2,Ot(_0x5a49e2,_0x137bec['oldSnap']));else{if(_0x5c9556==='child_changed'&&_0x46c7d9==='child_added')this['changeMap']['set'](_0x5a49e2,et(_0x5a49e2,_0x5de422['snapshotNode']));else{if(_0x5c9556==='child_changed'&&_0x46c7d9==='child_changed')this['changeMap']['set'](_0x5a49e2,Dt(_0x5a49e2,_0x5de422['snapshotNode'],_0x137bec['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x5de422+'\x20occurred\x20after\x20'+_0x137bec);}}}}}else this['changeMap']['set'](_0x5a49e2,_0x5de422);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x566f0f){return null;}['getChildAfterChild'](_0x11962f,_0x5ccb8f,_0x25a3e3){return null;}}const Go=new Tu();class ss{constructor(_0xb3f619,_0x25d77c,_0x202656=null){this['writes_']=_0xb3f619,this['viewCache_']=_0x25d77c,this['optCompleteServerCache_']=_0x202656;}['getCompleteChild'](_0x30e5cf){const _0x450283=this['viewCache_']['eventCache'];if(_0x450283['isCompleteForChild'](_0x30e5cf))return _0x450283['getNode']()['getImmediateChild'](_0x30e5cf);{const _0x24f339=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x30e5cf,_0x24f339);}}['getChildAfterChild'](_0x23cb0b,_0x326282,_0x3702a1){const _0x15d3cc=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0xcc5bfc=wu(this['writes_'],_0x15d3cc,_0x326282,0x1,_0x3702a1,_0x23cb0b);return _0xcc5bfc['length']===0x0?null:_0xcc5bfc[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x3f3615){return{'filter':_0x3f3615};}function bu(_0x3b56c4,_0x4d67c7){f(_0x4d67c7['eventCache']['getNode']()['isIndexed'](_0x3b56c4['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x4d67c7['serverCache']['getNode']()['isIndexed'](_0x3b56c4['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x1ab4de,_0x1a9610,_0x327313,_0xb33824,_0x1ede02){const _0x5bda98=new Cu();let _0xc09da2,_0x495f5e;if(_0x327313['type']===j['OVERWRITE']){const _0x591341=_0x327313;_0x591341['source']['fromUser']?_0xc09da2=Si(_0x1ab4de,_0x1a9610,_0x591341['path'],_0x591341['snap'],_0xb33824,_0x1ede02,_0x5bda98):(f(_0x591341['source']['fromServer'],'Unknown\x20source.'),_0x495f5e=_0x591341['source']['tagged']||_0x1a9610['serverCache']['isFiltered']()&&!v(_0x591341['path']),_0xc09da2=En(_0x1ab4de,_0x1a9610,_0x591341['path'],_0x591341['snap'],_0xb33824,_0x1ede02,_0x495f5e,_0x5bda98));}else{if(_0x327313['type']===j['MERGE']){const _0x4dd901=_0x327313;_0x4dd901['source']['fromUser']?_0xc09da2=ku(_0x1ab4de,_0x1a9610,_0x4dd901['path'],_0x4dd901['children'],_0xb33824,_0x1ede02,_0x5bda98):(f(_0x4dd901['source']['fromServer'],'Unknown\x20source.'),_0x495f5e=_0x4dd901['source']['tagged']||_0x1a9610['serverCache']['isFiltered'](),_0xc09da2=bi(_0x1ab4de,_0x1a9610,_0x4dd901['path'],_0x4dd901['children'],_0xb33824,_0x1ede02,_0x495f5e,_0x5bda98));}else{if(_0x327313['type']===j['ACK_USER_WRITE']){const _0x265448=_0x327313;_0x265448['revert']?_0xc09da2=Ou(_0x1ab4de,_0x1a9610,_0x265448['path'],_0xb33824,_0x1ede02,_0x5bda98):_0xc09da2=Nu(_0x1ab4de,_0x1a9610,_0x265448['path'],_0x265448['affectedTree'],_0xb33824,_0x1ede02,_0x5bda98);}else{if(_0x327313['type']===j['LISTEN_COMPLETE'])_0xc09da2=Pu(_0x1ab4de,_0x1a9610,_0x327313['path'],_0xb33824,_0x5bda98);else throw rt('Unknown\x20operation\x20type:\x20'+_0x327313['type']);}}}const _0x4f31a8=_0x5bda98['getChanges']();return Au(_0x1a9610,_0xc09da2,_0x4f31a8),{'viewCache':_0xc09da2,'changes':_0x4f31a8};}function Au(_0x28689e,_0x341a66,_0x1951fc){const _0x1b6049=_0x341a66['eventCache'];if(_0x1b6049['isFullyInitialized']()){const _0x471090=_0x1b6049['getNode']()['isLeafNode']()||_0x1b6049['getNode']()['isEmpty'](),_0x254fb0=mn(_0x28689e);(_0x1951fc['length']>0x0||!_0x28689e['eventCache']['isFullyInitialized']()||_0x471090&&!_0x1b6049['getNode']()['equals'](_0x254fb0)||!_0x1b6049['getNode']()['getPriority']()['equals'](_0x254fb0['getPriority']()))&&_0x1951fc['push'](Lo(mn(_0x341a66)));}}function qo(_0x39ab9d,_0x457298,_0x77d19,_0x3d3ac0,_0x421163,_0x27bc6e){const _0x338727=_0x457298['eventCache'];if(vn(_0x3d3ac0,_0x77d19)!=null)return _0x457298;{let _0x17998b,_0x3592aa;if(v(_0x77d19)){if(f(_0x457298['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x457298['serverCache']['isFiltered']()){const _0xa11fec=We(_0x457298),_0x42b21e=_0xa11fec instanceof g?_0xa11fec:g['EMPTY_NODE'],_0x10735b=ns(_0x3d3ac0,_0x42b21e);_0x17998b=_0x39ab9d['filter']['updateFullNode'](_0x457298['eventCache']['getNode'](),_0x10735b,_0x27bc6e);}else{const _0x40112f=yn(_0x3d3ac0,We(_0x457298));_0x17998b=_0x39ab9d['filter']['updateFullNode'](_0x457298['eventCache']['getNode'](),_0x40112f,_0x27bc6e);}}else{const _0x1df477=y(_0x77d19);if(_0x1df477==='.priority'){f(we(_0x77d19)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x539787=_0x338727['getNode']();_0x3592aa=_0x457298['serverCache']['getNode']();const _0x26eb77=lr(_0x3d3ac0,_0x77d19,_0x539787,_0x3592aa);_0x26eb77!=null?_0x17998b=_0x39ab9d['filter']['updatePriority'](_0x539787,_0x26eb77):_0x17998b=_0x338727['getNode']();}else{const _0x120245=b(_0x77d19);let _0xaf21f1;if(_0x338727['isCompleteForChild'](_0x1df477)){_0x3592aa=_0x457298['serverCache']['getNode']();const _0x5cb117=lr(_0x3d3ac0,_0x77d19,_0x338727['getNode'](),_0x3592aa);_0x5cb117!=null?_0xaf21f1=_0x338727['getNode']()['getImmediateChild'](_0x1df477)['updateChild'](_0x120245,_0x5cb117):_0xaf21f1=_0x338727['getNode']()['getImmediateChild'](_0x1df477);}else _0xaf21f1=is(_0x3d3ac0,_0x1df477,_0x457298['serverCache']);_0xaf21f1!=null?_0x17998b=_0x39ab9d['filter']['updateChild'](_0x338727['getNode'](),_0x1df477,_0xaf21f1,_0x120245,_0x421163,_0x27bc6e):_0x17998b=_0x338727['getNode']();}}return Tt(_0x457298,_0x17998b,_0x338727['isFullyInitialized']()||v(_0x77d19),_0x39ab9d['filter']['filtersNodes']());}}function En(_0x3d1728,_0x3a32e2,_0x411f35,_0x1809ae,_0x392fe8,_0x17c26d,_0x18f663,_0x16acfa){const _0x3ff38e=_0x3a32e2['serverCache'];let _0x19204c;const _0x364f6a=_0x18f663?_0x3d1728['filter']:_0x3d1728['filter']['getIndexedFilter']();if(v(_0x411f35))_0x19204c=_0x364f6a['updateFullNode'](_0x3ff38e['getNode'](),_0x1809ae,null);else{if(_0x364f6a['filtersNodes']()&&!_0x3ff38e['isFiltered']()){const _0x395377=_0x3ff38e['getNode']()['updateChild'](_0x411f35,_0x1809ae);_0x19204c=_0x364f6a['updateFullNode'](_0x3ff38e['getNode'](),_0x395377,null);}else{const _0x5ba23a=y(_0x411f35);if(!_0x3ff38e['isCompleteForPath'](_0x411f35)&&we(_0x411f35)>0x1)return _0x3a32e2;const _0x1bc645=b(_0x411f35),_0xe63ee9=_0x3ff38e['getNode']()['getImmediateChild'](_0x5ba23a)['updateChild'](_0x1bc645,_0x1809ae);_0x5ba23a==='.priority'?_0x19204c=_0x364f6a['updatePriority'](_0x3ff38e['getNode'](),_0xe63ee9):_0x19204c=_0x364f6a['updateChild'](_0x3ff38e['getNode'](),_0x5ba23a,_0xe63ee9,_0x1bc645,Go,null);}}const _0x111509=Uo(_0x3a32e2,_0x19204c,_0x3ff38e['isFullyInitialized']()||v(_0x411f35),_0x364f6a['filtersNodes']()),_0xc2cd92=new ss(_0x392fe8,_0x111509,_0x17c26d);return qo(_0x3d1728,_0x111509,_0x411f35,_0x392fe8,_0xc2cd92,_0x16acfa);}function Si(_0x1166f1,_0x50fc0b,_0x161b31,_0xabfd0b,_0x4c74de,_0x4b7778,_0x4b71b8){const _0x22e6be=_0x50fc0b['eventCache'];let _0x5cadc4,_0x3eb202;const _0x37c991=new ss(_0x4c74de,_0x50fc0b,_0x4b7778);if(v(_0x161b31))_0x3eb202=_0x1166f1['filter']['updateFullNode'](_0x50fc0b['eventCache']['getNode'](),_0xabfd0b,_0x4b71b8),_0x5cadc4=Tt(_0x50fc0b,_0x3eb202,!0x0,_0x1166f1['filter']['filtersNodes']());else{const _0x4fd2b1=y(_0x161b31);if(_0x4fd2b1==='.priority')_0x3eb202=_0x1166f1['filter']['updatePriority'](_0x50fc0b['eventCache']['getNode'](),_0xabfd0b),_0x5cadc4=Tt(_0x50fc0b,_0x3eb202,_0x22e6be['isFullyInitialized'](),_0x22e6be['isFiltered']());else{const _0x5323d6=b(_0x161b31),_0x1cd3c=_0x22e6be['getNode']()['getImmediateChild'](_0x4fd2b1);let _0x1f6bba;if(v(_0x5323d6))_0x1f6bba=_0xabfd0b;else{const _0x3c0c34=_0x37c991['getCompleteChild'](_0x4fd2b1);_0x3c0c34!=null?zi(_0x5323d6)==='.priority'&&_0x3c0c34['getChild'](Ro(_0x5323d6))['isEmpty']()?_0x1f6bba=_0x3c0c34:_0x1f6bba=_0x3c0c34['updateChild'](_0x5323d6,_0xabfd0b):_0x1f6bba=g['EMPTY_NODE'];}if(_0x1cd3c['equals'](_0x1f6bba))_0x5cadc4=_0x50fc0b;else{const _0x115c1f=_0x1166f1['filter']['updateChild'](_0x22e6be['getNode'](),_0x4fd2b1,_0x1f6bba,_0x5323d6,_0x37c991,_0x4b71b8);_0x5cadc4=Tt(_0x50fc0b,_0x115c1f,_0x22e6be['isFullyInitialized'](),_0x1166f1['filter']['filtersNodes']());}}}return _0x5cadc4;}function hr(_0x2760af,_0x39b91f){return _0x2760af['eventCache']['isCompleteForChild'](_0x39b91f);}function ku(_0x264d3b,_0x265d5f,_0x10d8f3,_0x3e95f0,_0xc6652f,_0x3fffdd,_0x3e02ad){let _0x27bea1=_0x265d5f;return _0x3e95f0['foreach']((_0x517469,_0x1b2c33)=>{const _0x5617bd=k(_0x10d8f3,_0x517469);hr(_0x265d5f,y(_0x5617bd))&&(_0x27bea1=Si(_0x264d3b,_0x27bea1,_0x5617bd,_0x1b2c33,_0xc6652f,_0x3fffdd,_0x3e02ad));}),_0x3e95f0['foreach']((_0x5b69ea,_0x49877f)=>{const _0x3c349f=k(_0x10d8f3,_0x5b69ea);hr(_0x265d5f,y(_0x3c349f))||(_0x27bea1=Si(_0x264d3b,_0x27bea1,_0x3c349f,_0x49877f,_0xc6652f,_0x3fffdd,_0x3e02ad));}),_0x27bea1;}function ur(_0x2c8d19,_0x2629d8,_0x285c37){return _0x285c37['foreach']((_0x3e890c,_0x2be3c7)=>{_0x2629d8=_0x2629d8['updateChild'](_0x3e890c,_0x2be3c7);}),_0x2629d8;}function bi(_0x150b42,_0x33f32b,_0x39a52d,_0x3cdbc8,_0x15d472,_0x14382c,_0x52e775,_0x397ddc){if(_0x33f32b['serverCache']['getNode']()['isEmpty']()&&!_0x33f32b['serverCache']['isFullyInitialized']())return _0x33f32b;let _0x265296=_0x33f32b,_0x2e8bd7;v(_0x39a52d)?_0x2e8bd7=_0x3cdbc8:_0x2e8bd7=new S(null)['setTree'](_0x39a52d,_0x3cdbc8);const _0x3a926f=_0x33f32b['serverCache']['getNode']();return _0x2e8bd7['children']['inorderTraversal']((_0x2faedd,_0xdc3e76)=>{if(_0x3a926f['hasChild'](_0x2faedd)){const _0x1760cf=_0x33f32b['serverCache']['getNode']()['getImmediateChild'](_0x2faedd),_0x5405e8=ur(_0x150b42,_0x1760cf,_0xdc3e76);_0x265296=En(_0x150b42,_0x265296,new C(_0x2faedd),_0x5405e8,_0x15d472,_0x14382c,_0x52e775,_0x397ddc);}}),_0x2e8bd7['children']['inorderTraversal']((_0x130eae,_0x4470a9)=>{const _0x24d2e6=!_0x33f32b['serverCache']['isCompleteForChild'](_0x130eae)&&_0x4470a9['value']===null;if(!_0x3a926f['hasChild'](_0x130eae)&&!_0x24d2e6){const _0x9018dc=_0x33f32b['serverCache']['getNode']()['getImmediateChild'](_0x130eae),_0x4e8d3f=ur(_0x150b42,_0x9018dc,_0x4470a9);_0x265296=En(_0x150b42,_0x265296,new C(_0x130eae),_0x4e8d3f,_0x15d472,_0x14382c,_0x52e775,_0x397ddc);}}),_0x265296;}function Nu(_0x48d931,_0xfd1713,_0x527009,_0x1a6132,_0x18dadc,_0x5cbcd4,_0x551075){if(vn(_0x18dadc,_0x527009)!=null)return _0xfd1713;const _0x476ef2=_0xfd1713['serverCache']['isFiltered'](),_0x267d82=_0xfd1713['serverCache'];if(_0x1a6132['value']!=null){if(v(_0x527009)&&_0x267d82['isFullyInitialized']()||_0x267d82['isCompleteForPath'](_0x527009))return En(_0x48d931,_0xfd1713,_0x527009,_0x267d82['getNode']()['getChild'](_0x527009),_0x18dadc,_0x5cbcd4,_0x476ef2,_0x551075);if(v(_0x527009)){let _0x531ec8=new S(null);return _0x267d82['getNode']()['forEachChild'](ye,(_0x480085,_0x15e08a)=>{_0x531ec8=_0x531ec8['set'](new C(_0x480085),_0x15e08a);}),bi(_0x48d931,_0xfd1713,_0x527009,_0x531ec8,_0x18dadc,_0x5cbcd4,_0x476ef2,_0x551075);}else return _0xfd1713;}else{let _0x179c21=new S(null);return _0x1a6132['foreach']((_0x3752ac,_0x52de11)=>{const _0x266c25=k(_0x527009,_0x3752ac);_0x267d82['isCompleteForPath'](_0x266c25)&&(_0x179c21=_0x179c21['set'](_0x3752ac,_0x267d82['getNode']()['getChild'](_0x266c25)));}),bi(_0x48d931,_0xfd1713,_0x527009,_0x179c21,_0x18dadc,_0x5cbcd4,_0x476ef2,_0x551075);}}function Pu(_0x553b22,_0x2a483f,_0x899fa1,_0x57ff9b,_0x198f37){const _0x2409e1=_0x2a483f['serverCache'],_0xa9de10=Uo(_0x2a483f,_0x2409e1['getNode'](),_0x2409e1['isFullyInitialized']()||v(_0x899fa1),_0x2409e1['isFiltered']());return qo(_0x553b22,_0xa9de10,_0x899fa1,_0x57ff9b,Go,_0x198f37);}function Ou(_0x23214d,_0x4f2a47,_0x510911,_0x76f421,_0x4652f4,_0x3a4422){let _0x686ff1;if(vn(_0x76f421,_0x510911)!=null)return _0x4f2a47;{const _0x22bb06=new ss(_0x76f421,_0x4f2a47,_0x4652f4),_0x1a9729=_0x4f2a47['eventCache']['getNode']();let _0x13719c;if(v(_0x510911)||y(_0x510911)==='.priority'){let _0x1d3d21;if(_0x4f2a47['serverCache']['isFullyInitialized']())_0x1d3d21=yn(_0x76f421,We(_0x4f2a47));else{const _0x306633=_0x4f2a47['serverCache']['getNode']();f(_0x306633 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x1d3d21=ns(_0x76f421,_0x306633);}_0x1d3d21=_0x1d3d21,_0x13719c=_0x23214d['filter']['updateFullNode'](_0x1a9729,_0x1d3d21,_0x3a4422);}else{const _0x20a752=y(_0x510911);let _0x5dbd00=is(_0x76f421,_0x20a752,_0x4f2a47['serverCache']);_0x5dbd00==null&&_0x4f2a47['serverCache']['isCompleteForChild'](_0x20a752)&&(_0x5dbd00=_0x1a9729['getImmediateChild'](_0x20a752)),_0x5dbd00!=null?_0x13719c=_0x23214d['filter']['updateChild'](_0x1a9729,_0x20a752,_0x5dbd00,b(_0x510911),_0x22bb06,_0x3a4422):_0x4f2a47['eventCache']['getNode']()['hasChild'](_0x20a752)?_0x13719c=_0x23214d['filter']['updateChild'](_0x1a9729,_0x20a752,g['EMPTY_NODE'],b(_0x510911),_0x22bb06,_0x3a4422):_0x13719c=_0x1a9729,_0x13719c['isEmpty']()&&_0x4f2a47['serverCache']['isFullyInitialized']()&&(_0x686ff1=yn(_0x76f421,We(_0x4f2a47)),_0x686ff1['isLeafNode']()&&(_0x13719c=_0x23214d['filter']['updateFullNode'](_0x13719c,_0x686ff1,_0x3a4422)));}return _0x686ff1=_0x4f2a47['serverCache']['isFullyInitialized']()||vn(_0x76f421,w())!=null,Tt(_0x4f2a47,_0x13719c,_0x686ff1,_0x23214d['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x265447,_0x146113){this['query_']=_0x265447,this['eventRegistrations_']=[];const _0xdf781d=this['query_']['_queryParams'],_0x3a08df=new Ji(_0xdf781d['getIndex']()),_0x4a4e0c=Kh(_0xdf781d);this['processor_']=Su(_0x4a4e0c);const _0x516558=_0x146113['serverCache'],_0x266701=_0x146113['eventCache'],_0x32017d=_0x3a08df['updateFullNode'](g['EMPTY_NODE'],_0x516558['getNode'](),null),_0x9db00f=_0x4a4e0c['updateFullNode'](g['EMPTY_NODE'],_0x266701['getNode'](),null),_0x1e1f8f=new Ce(_0x32017d,_0x516558['isFullyInitialized'](),_0x3a08df['filtersNodes']()),_0x506d80=new Ce(_0x9db00f,_0x266701['isFullyInitialized'](),_0x4a4e0c['filtersNodes']());this['viewCache_']=Mn(_0x506d80,_0x1e1f8f),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0xd49f96){return _0xd49f96['viewCache_']['serverCache']['getNode']();}function Lu(_0x526c33){return mn(_0x526c33['viewCache_']);}function xu(_0x30bfd4,_0x436787){const _0x1c694f=We(_0x30bfd4['viewCache_']);return _0x1c694f&&(_0x30bfd4['query']['_queryParams']['loadsAllData']()||!v(_0x436787)&&!_0x1c694f['getImmediateChild'](y(_0x436787))['isEmpty']())?_0x1c694f['getChild'](_0x436787):null;}function dr(_0x2eadd5){return _0x2eadd5['eventRegistrations_']['length']===0x0;}function Fu(_0x3ca584,_0x4338b3){_0x3ca584['eventRegistrations_']['push'](_0x4338b3);}function fr(_0x5d30b6,_0xf1b1ed,_0x55610c){const _0x3be45c=[];if(_0x55610c){f(_0xf1b1ed==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x326820=_0x5d30b6['query']['_path'];_0x5d30b6['eventRegistrations_']['forEach'](_0x338540=>{const _0x6db18b=_0x338540['createCancelEvent'](_0x55610c,_0x326820);_0x6db18b&&_0x3be45c['push'](_0x6db18b);});}if(_0xf1b1ed){let _0x487514=[];for(let _0x13abd7=0x0;_0x13abd7<_0x5d30b6['eventRegistrations_']['length'];++_0x13abd7){const _0xd82471=_0x5d30b6['eventRegistrations_'][_0x13abd7];if(!_0xd82471['matches'](_0xf1b1ed))_0x487514['push'](_0xd82471);else{if(_0xf1b1ed['hasAnyCallback']()){_0x487514=_0x487514['concat'](_0x5d30b6['eventRegistrations_']['slice'](_0x13abd7+0x1));break;}}}_0x5d30b6['eventRegistrations_']=_0x487514;}else _0x5d30b6['eventRegistrations_']=[];return _0x3be45c;}function pr(_0x46dcd9,_0x26edd3,_0x16fdea,_0x31b21e){_0x26edd3['type']===j['MERGE']&&_0x26edd3['source']['queryId']!==null&&(f(We(_0x46dcd9['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x46dcd9['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x5e9438=_0x46dcd9['viewCache_'],_0x2f7e22=Ru(_0x46dcd9['processor_'],_0x5e9438,_0x26edd3,_0x16fdea,_0x31b21e);return bu(_0x46dcd9['processor_'],_0x2f7e22['viewCache']),f(_0x2f7e22['viewCache']['serverCache']['isFullyInitialized']()||!_0x5e9438['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x46dcd9['viewCache_']=_0x2f7e22['viewCache'],zo(_0x46dcd9,_0x2f7e22['changes'],_0x2f7e22['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x21ad0a,_0x23e08){const _0x14978f=_0x21ad0a['viewCache_']['eventCache'],_0x4355af=[];return _0x14978f['getNode']()['isLeafNode']()||_0x14978f['getNode']()['forEachChild'](R,(_0x22b541,_0xd1cc22)=>{_0x4355af['push'](et(_0x22b541,_0xd1cc22));}),_0x14978f['isFullyInitialized']()&&_0x4355af['push'](Lo(_0x14978f['getNode']())),zo(_0x21ad0a,_0x4355af,_0x14978f['getNode'](),_0x23e08);}function zo(_0x2da8db,_0x57d2be,_0x3c76b3,_0x1df5c6){const _0x22f0ed=_0x1df5c6?[_0x1df5c6]:_0x2da8db['eventRegistrations_'];return ru(_0x2da8db['eventGenerator_'],_0x57d2be,_0x3c76b3,_0x22f0ed);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x5ef8de){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x5ef8de;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x298a34){return _0x298a34['views']['size']===0x0;}function rs(_0x1ae85f,_0x4e9956,_0x42b0f2,_0x2d5be0){const _0x73451a=_0x4e9956['source']['queryId'];if(_0x73451a!==null){const _0x23c6d2=_0x1ae85f['views']['get'](_0x73451a);return f(_0x23c6d2!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x23c6d2,_0x4e9956,_0x42b0f2,_0x2d5be0);}else{let _0x4c0d7f=[];for(const _0x385c77 of _0x1ae85f['views']['values']())_0x4c0d7f=_0x4c0d7f['concat'](pr(_0x385c77,_0x4e9956,_0x42b0f2,_0x2d5be0));return _0x4c0d7f;}}function Ko(_0x41a95a,_0x473680,_0x3ec954,_0x49c027,_0x4832b7){const _0x281d95=_0x473680['_queryIdentifier'],_0x537ee4=_0x41a95a['views']['get'](_0x281d95);if(!_0x537ee4){let _0x1a5d51=yn(_0x3ec954,_0x4832b7?_0x49c027:null),_0x26b5f8=!0x1;_0x1a5d51?_0x26b5f8=!0x0:_0x49c027 instanceof g?(_0x1a5d51=ns(_0x3ec954,_0x49c027),_0x26b5f8=!0x1):(_0x1a5d51=g['EMPTY_NODE'],_0x26b5f8=!0x1);const _0x1b9c78=Mn(new Ce(_0x1a5d51,_0x26b5f8,!0x1),new Ce(_0x49c027,_0x4832b7,!0x1));return new Du(_0x473680,_0x1b9c78);}return _0x537ee4;}function Hu(_0x2c97c0,_0xd44f59,_0x3b5b16,_0x2da676,_0x39ced1,_0xf78f86){const _0x2ec418=Ko(_0x2c97c0,_0xd44f59,_0x2da676,_0x39ced1,_0xf78f86);return _0x2c97c0['views']['has'](_0xd44f59['_queryIdentifier'])||_0x2c97c0['views']['set'](_0xd44f59['_queryIdentifier'],_0x2ec418),Fu(_0x2ec418,_0x3b5b16),Uu(_0x2ec418,_0x3b5b16);}function $u(_0x2130ea,_0x363f0f,_0x8a2542,_0x3586d5){const _0x3efc8b=_0x363f0f['_queryIdentifier'],_0x156d89=[];let _0x4538eb=[];const _0xce9d3f=Te(_0x2130ea);if(_0x3efc8b==='default'){for(const [_0x315cb9,_0x6a1959]of _0x2130ea['views']['entries']())_0x4538eb=_0x4538eb['concat'](fr(_0x6a1959,_0x8a2542,_0x3586d5)),dr(_0x6a1959)&&(_0x2130ea['views']['delete'](_0x315cb9),_0x6a1959['query']['_queryParams']['loadsAllData']()||_0x156d89['push'](_0x6a1959['query']));}else{const _0x10032a=_0x2130ea['views']['get'](_0x3efc8b);_0x10032a&&(_0x4538eb=_0x4538eb['concat'](fr(_0x10032a,_0x8a2542,_0x3586d5)),dr(_0x10032a)&&(_0x2130ea['views']['delete'](_0x3efc8b),_0x10032a['query']['_queryParams']['loadsAllData']()||_0x156d89['push'](_0x10032a['query'])));}return _0xce9d3f&&!Te(_0x2130ea)&&_0x156d89['push'](new(Bu())(_0x363f0f['_repo'],_0x363f0f['_path'])),{'removed':_0x156d89,'events':_0x4538eb};}function Yo(_0x5515af){const _0x3dd3ad=[];for(const _0x4f5cd0 of _0x5515af['views']['values']())_0x4f5cd0['query']['_queryParams']['loadsAllData']()||_0x3dd3ad['push'](_0x4f5cd0);return _0x3dd3ad;}function Ee(_0x3abe35,_0x3581a4){let _0x47f06f=null;for(const _0x4d897e of _0x3abe35['views']['values']())_0x47f06f=_0x47f06f||xu(_0x4d897e,_0x3581a4);return _0x47f06f;}function Qo(_0x525426,_0x3f5f50){if(_0x3f5f50['_queryParams']['loadsAllData']())return xn(_0x525426);{const _0x48cdb4=_0x3f5f50['_queryIdentifier'];return _0x525426['views']['get'](_0x48cdb4);}}function Jo(_0x2bda9d,_0x386e0d){return Qo(_0x2bda9d,_0x386e0d)!=null;}function Te(_0x10f1a2){return xn(_0x10f1a2)!=null;}function xn(_0x321c05){for(const _0xaf3a06 of _0x321c05['views']['values']())if(_0xaf3a06['query']['_queryParams']['loadsAllData']())return _0xaf3a06;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x1646e7){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x1646e7;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x53bba8){this['listenProvider_']=_0x53bba8,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x508c57,_0x24be0f,_0x49a4ec,_0x5ad526,_0x164019){return lu(_0x508c57['pendingWriteTree_'],_0x24be0f,_0x49a4ec,_0x5ad526,_0x164019),_0x164019?ut(_0x508c57,new Ue(Zi(),_0x24be0f,_0x49a4ec)):[];}function ju(_0x912c84,_0x6525d9,_0x58e676,_0x4a7494){hu(_0x912c84['pendingWriteTree_'],_0x6525d9,_0x58e676,_0x4a7494);const _0x10681d=S['fromObject'](_0x58e676);return ut(_0x912c84,new tt(Zi(),_0x6525d9,_0x10681d));}function pe(_0x488c7f,_0x1f15f2,_0x2298ff=!0x1){const _0x30726c=uu(_0x488c7f['pendingWriteTree_'],_0x1f15f2);if(du(_0x488c7f['pendingWriteTree_'],_0x1f15f2)){let _0x5d961a=new S(null);return _0x30726c['snap']!=null?_0x5d961a=_0x5d961a['set'](w(),!0x0):x(_0x30726c['children'],_0x572ed2=>{_0x5d961a=_0x5d961a['set'](new C(_0x572ed2),!0x0);}),ut(_0x488c7f,new gn(_0x30726c['path'],_0x5d961a,_0x2298ff));}else return[];}function Gt(_0x355029,_0x1fe95e,_0x3c95d8){return ut(_0x355029,new Ue(es(),_0x1fe95e,_0x3c95d8));}function Ku(_0x314f43,_0x256b3c,_0x35b43f){const _0x52fd1b=S['fromObject'](_0x35b43f);return ut(_0x314f43,new tt(es(),_0x256b3c,_0x52fd1b));}function Yu(_0x24f377,_0x48b57d){return ut(_0x24f377,new Lt(es(),_0x48b57d));}function Qu(_0x395d2c,_0x1a8716,_0x541fa6){const _0x450760=as(_0x395d2c,_0x541fa6);if(_0x450760){const _0x7f9cd1=cs(_0x450760),_0x2aa036=_0x7f9cd1['path'],_0x25cb84=_0x7f9cd1['queryId'],_0x3ec0ec=F(_0x2aa036,_0x1a8716),_0x2cbb0d=new Lt(ts(_0x25cb84),_0x3ec0ec);return ls(_0x395d2c,_0x2aa036,_0x2cbb0d);}else return[];}function Cn(_0x42ac50,_0x482133,_0x5ead7c,_0x5ba2d5,_0x4490ae=!0x1){const _0x4158e5=_0x482133['_path'],_0xd32df1=_0x42ac50['syncPointTree_']['get'](_0x4158e5);let _0x502b62=[];if(_0xd32df1&&(_0x482133['_queryIdentifier']==='default'||Jo(_0xd32df1,_0x482133))){const _0x5804f2=$u(_0xd32df1,_0x482133,_0x5ead7c,_0x5ba2d5);Vu(_0xd32df1)&&(_0x42ac50['syncPointTree_']=_0x42ac50['syncPointTree_']['remove'](_0x4158e5));const _0x4fa508=_0x5804f2['removed'];if(_0x502b62=_0x5804f2['events'],!_0x4490ae){const _0x593914=_0x4fa508['findIndex'](_0x2d956c=>_0x2d956c['_queryParams']['loadsAllData']())!==-0x1,_0x1dc2a2=_0x42ac50['syncPointTree_']['findOnPath'](_0x4158e5,(_0x54c602,_0x1a69ac)=>Te(_0x1a69ac));if(_0x593914&&!_0x1dc2a2){const _0x52a0df=_0x42ac50['syncPointTree_']['subtree'](_0x4158e5);if(!_0x52a0df['isEmpty']()){const _0x2602ba=Zu(_0x52a0df);for(let _0x16de93=0x0;_0x16de93<_0x2602ba['length'];++_0x16de93){const _0x124510=_0x2602ba[_0x16de93],_0x11ba1b=_0x124510['query'],_0x153230=ta(_0x42ac50,_0x124510);_0x42ac50['listenProvider_']['startListening'](bt(_0x11ba1b),xt(_0x42ac50,_0x11ba1b),_0x153230['hashFn'],_0x153230['onComplete']);}}}!_0x1dc2a2&&_0x4fa508['length']>0x0&&!_0x5ba2d5&&(_0x593914?_0x42ac50['listenProvider_']['stopListening'](bt(_0x482133),null):_0x4fa508['forEach'](_0x5e5e55=>{const _0x5233c0=_0x42ac50['queryToTagMap']['get'](Un(_0x5e5e55));_0x42ac50['listenProvider_']['stopListening'](bt(_0x5e5e55),_0x5233c0);}));}ed(_0x42ac50,_0x4fa508);}return _0x502b62;}function Xo(_0x2a182b,_0xdff23f,_0x1f02da,_0xe120a0){const _0x41b477=as(_0x2a182b,_0xe120a0);if(_0x41b477!=null){const _0x482535=cs(_0x41b477),_0x5d5e7f=_0x482535['path'],_0x2e78e5=_0x482535['queryId'],_0x51e0aa=F(_0x5d5e7f,_0xdff23f),_0x5460a6=new Ue(ts(_0x2e78e5),_0x51e0aa,_0x1f02da);return ls(_0x2a182b,_0x5d5e7f,_0x5460a6);}else return[];}function Ju(_0x3730e2,_0x4aab5f,_0x48f09c,_0x599021){const _0x37ba01=as(_0x3730e2,_0x599021);if(_0x37ba01){const _0x1feea5=cs(_0x37ba01),_0x44d1c2=_0x1feea5['path'],_0x2e8b0d=_0x1feea5['queryId'],_0x5e850b=F(_0x44d1c2,_0x4aab5f),_0x4da43b=S['fromObject'](_0x48f09c),_0x8fb12c=new tt(ts(_0x2e8b0d),_0x5e850b,_0x4da43b);return ls(_0x3730e2,_0x44d1c2,_0x8fb12c);}else return[];}function Ri(_0x41281a,_0x369fb7,_0x3be995,_0x36203d=!0x1){const _0x1905a1=_0x369fb7['_path'];let _0xaa2d24=null,_0x2677be=!0x1;_0x41281a['syncPointTree_']['foreachOnPath'](_0x1905a1,(_0xef4428,_0x2234ed)=>{const _0x717ee5=F(_0xef4428,_0x1905a1);_0xaa2d24=_0xaa2d24||Ee(_0x2234ed,_0x717ee5),_0x2677be=_0x2677be||Te(_0x2234ed);});let _0x587e18=_0x41281a['syncPointTree_']['get'](_0x1905a1);_0x587e18?(_0x2677be=_0x2677be||Te(_0x587e18),_0xaa2d24=_0xaa2d24||Ee(_0x587e18,w())):(_0x587e18=new jo(),_0x41281a['syncPointTree_']=_0x41281a['syncPointTree_']['set'](_0x1905a1,_0x587e18));let _0x5b38b1;_0xaa2d24!=null?_0x5b38b1=!0x0:(_0x5b38b1=!0x1,_0xaa2d24=g['EMPTY_NODE'],_0x41281a['syncPointTree_']['subtree'](_0x1905a1)['foreachChild']((_0x5edae7,_0x5099ed)=>{const _0x21ce01=Ee(_0x5099ed,w());_0x21ce01&&(_0xaa2d24=_0xaa2d24['updateImmediateChild'](_0x5edae7,_0x21ce01));}));const _0x3c592c=Jo(_0x587e18,_0x369fb7);if(!_0x3c592c&&!_0x369fb7['_queryParams']['loadsAllData']()){const _0x5661e5=Un(_0x369fb7);f(!_0x41281a['queryToTagMap']['has'](_0x5661e5),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x3b89be=td();_0x41281a['queryToTagMap']['set'](_0x5661e5,_0x3b89be),_0x41281a['tagToQueryMap']['set'](_0x3b89be,_0x5661e5);}const _0x10e956=Ln(_0x41281a['pendingWriteTree_'],_0x1905a1);let _0x23a7d9=Hu(_0x587e18,_0x369fb7,_0x3be995,_0x10e956,_0xaa2d24,_0x5b38b1);if(!_0x3c592c&&!_0x2677be&&!_0x36203d){const _0x1db9bc=Qo(_0x587e18,_0x369fb7);_0x23a7d9=_0x23a7d9['concat'](nd(_0x41281a,_0x369fb7,_0x1db9bc));}return _0x23a7d9;}function Fn(_0x3d7329,_0x190260,_0x15066a){const _0x4666db=_0x3d7329['pendingWriteTree_'],_0x5e554c=_0x3d7329['syncPointTree_']['findOnPath'](_0x190260,(_0xf4cc24,_0x23593c)=>{const _0x25db94=F(_0xf4cc24,_0x190260),_0x895cd9=Ee(_0x23593c,_0x25db94);if(_0x895cd9)return _0x895cd9;});return Vo(_0x4666db,_0x190260,_0x5e554c,_0x15066a,!0x0);}function Xu(_0x2d13cc,_0x282158){const _0x9cb583=_0x282158['_path'];let _0x460284=null;_0x2d13cc['syncPointTree_']['foreachOnPath'](_0x9cb583,(_0x5056ae,_0x9eb145)=>{const _0x3cbdb4=F(_0x5056ae,_0x9cb583);_0x460284=_0x460284||Ee(_0x9eb145,_0x3cbdb4);});let _0x13ed87=_0x2d13cc['syncPointTree_']['get'](_0x9cb583);_0x13ed87?_0x460284=_0x460284||Ee(_0x13ed87,w()):(_0x13ed87=new jo(),_0x2d13cc['syncPointTree_']=_0x2d13cc['syncPointTree_']['set'](_0x9cb583,_0x13ed87));const _0x51c801=_0x460284!=null,_0x5eb651=_0x51c801?new Ce(_0x460284,!0x0,!0x1):null,_0x592327=Ln(_0x2d13cc['pendingWriteTree_'],_0x282158['_path']),_0xf3c5ec=Ko(_0x13ed87,_0x282158,_0x592327,_0x51c801?_0x5eb651['getNode']():g['EMPTY_NODE'],_0x51c801);return Lu(_0xf3c5ec);}function ut(_0x2dc173,_0x5d069c){return Zo(_0x5d069c,_0x2dc173['syncPointTree_'],null,Ln(_0x2dc173['pendingWriteTree_'],w()));}function Zo(_0x361c51,_0x5087c9,_0x1574a5,_0x3ce520){if(v(_0x361c51['path']))return ea(_0x361c51,_0x5087c9,_0x1574a5,_0x3ce520);{const _0x284fdd=_0x5087c9['get'](w());_0x1574a5==null&&_0x284fdd!=null&&(_0x1574a5=Ee(_0x284fdd,w()));let _0x52aea2=[];const _0x20e710=y(_0x361c51['path']),_0x39a1d8=_0x361c51['operationForChild'](_0x20e710),_0x326283=_0x5087c9['children']['get'](_0x20e710);if(_0x326283&&_0x39a1d8){const _0x308b0a=_0x1574a5?_0x1574a5['getImmediateChild'](_0x20e710):null,_0x3eb374=Ho(_0x3ce520,_0x20e710);_0x52aea2=_0x52aea2['concat'](Zo(_0x39a1d8,_0x326283,_0x308b0a,_0x3eb374));}return _0x284fdd&&(_0x52aea2=_0x52aea2['concat'](rs(_0x284fdd,_0x361c51,_0x3ce520,_0x1574a5))),_0x52aea2;}}function ea(_0x21a4d6,_0x235241,_0x463687,_0x5a17e5){const _0x1725de=_0x235241['get'](w());_0x463687==null&&_0x1725de!=null&&(_0x463687=Ee(_0x1725de,w()));let _0x49dcca=[];return _0x235241['children']['inorderTraversal']((_0x555320,_0x395ed4)=>{const _0x12fbac=_0x463687?_0x463687['getImmediateChild'](_0x555320):null,_0x631da1=Ho(_0x5a17e5,_0x555320),_0x44b9c2=_0x21a4d6['operationForChild'](_0x555320);_0x44b9c2&&(_0x49dcca=_0x49dcca['concat'](ea(_0x44b9c2,_0x395ed4,_0x12fbac,_0x631da1)));}),_0x1725de&&(_0x49dcca=_0x49dcca['concat'](rs(_0x1725de,_0x21a4d6,_0x5a17e5,_0x463687))),_0x49dcca;}function ta(_0x98e58,_0x4982c8){const _0x1dedfe=_0x4982c8['query'],_0x1fac66=xt(_0x98e58,_0x1dedfe);return{'hashFn':()=>(Mu(_0x4982c8)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x4af9c1=>{if(_0x4af9c1==='ok')return _0x1fac66?Qu(_0x98e58,_0x1dedfe['_path'],_0x1fac66):Yu(_0x98e58,_0x1dedfe['_path']);{const _0x7bf0b=Kl(_0x4af9c1,_0x1dedfe);return Cn(_0x98e58,_0x1dedfe,null,_0x7bf0b);}}};}function xt(_0x19eef9,_0x69c93c){const _0x10d2d9=Un(_0x69c93c);return _0x19eef9['queryToTagMap']['get'](_0x10d2d9);}function Un(_0x51f01e){return _0x51f01e['_path']['toString']()+'$'+_0x51f01e['_queryIdentifier'];}function as(_0x8dd0e4,_0x547c94){return _0x8dd0e4['tagToQueryMap']['get'](_0x547c94);}function cs(_0x24199d){const _0x43cb49=_0x24199d['indexOf']('$');return f(_0x43cb49!==-0x1&&_0x43cb49<_0x24199d['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x24199d['substr'](_0x43cb49+0x1),'path':new C(_0x24199d['substr'](0x0,_0x43cb49))};}function ls(_0x76716b,_0x42d98f,_0x88c5f3){const _0x1786ea=_0x76716b['syncPointTree_']['get'](_0x42d98f);f(_0x1786ea,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x50bf2c=Ln(_0x76716b['pendingWriteTree_'],_0x42d98f);return rs(_0x1786ea,_0x88c5f3,_0x50bf2c,null);}function Zu(_0x5a6fff){return _0x5a6fff['fold']((_0x5876f4,_0x1ce9a7,_0xad7a7b)=>{if(_0x1ce9a7&&Te(_0x1ce9a7))return[xn(_0x1ce9a7)];{let _0x4ac4e9=[];return _0x1ce9a7&&(_0x4ac4e9=Yo(_0x1ce9a7)),x(_0xad7a7b,(_0x1bf74d,_0x861e59)=>{_0x4ac4e9=_0x4ac4e9['concat'](_0x861e59);}),_0x4ac4e9;}});}function bt(_0x33e736){return _0x33e736['_queryParams']['loadsAllData']()&&!_0x33e736['_queryParams']['isDefault']()?new(qu())(_0x33e736['_repo'],_0x33e736['_path']):_0x33e736;}function ed(_0x353734,_0x200c67){for(let _0x5e776c=0x0;_0x5e776c<_0x200c67['length'];++_0x5e776c){const _0x4954dc=_0x200c67[_0x5e776c];if(!_0x4954dc['_queryParams']['loadsAllData']()){const _0xd951e2=Un(_0x4954dc),_0x2c552c=_0x353734['queryToTagMap']['get'](_0xd951e2);_0x353734['queryToTagMap']['delete'](_0xd951e2),_0x353734['tagToQueryMap']['delete'](_0x2c552c);}}}function td(){return zu++;}function nd(_0xe2134f,_0x1aef21,_0x84e64b){const _0x38b503=_0x1aef21['_path'],_0x48a4e2=xt(_0xe2134f,_0x1aef21),_0x20bbec=ta(_0xe2134f,_0x84e64b),_0x59c39e=_0xe2134f['listenProvider_']['startListening'](bt(_0x1aef21),_0x48a4e2,_0x20bbec['hashFn'],_0x20bbec['onComplete']),_0x220fb1=_0xe2134f['syncPointTree_']['subtree'](_0x38b503);if(_0x48a4e2)f(!Te(_0x220fb1['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x557acf=_0x220fb1['fold']((_0x5997ca,_0x41ff4b,_0x3fded6)=>{if(!v(_0x5997ca)&&_0x41ff4b&&Te(_0x41ff4b))return[xn(_0x41ff4b)['query']];{let _0x51b801=[];return _0x41ff4b&&(_0x51b801=_0x51b801['concat'](Yo(_0x41ff4b)['map'](_0x18610a=>_0x18610a['query']))),x(_0x3fded6,(_0x46ba2a,_0x3f453d)=>{_0x51b801=_0x51b801['concat'](_0x3f453d);}),_0x51b801;}});for(let _0xe9a3a8=0x0;_0xe9a3a8<_0x557acf['length'];++_0xe9a3a8){const _0x1df2f1=_0x557acf[_0xe9a3a8];_0xe2134f['listenProvider_']['stopListening'](bt(_0x1df2f1),xt(_0xe2134f,_0x1df2f1));}}return _0x59c39e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x5320aa){this['node_']=_0x5320aa;}['getImmediateChild'](_0x168701){const _0x5dc8ee=this['node_']['getImmediateChild'](_0x168701);return new hs(_0x5dc8ee);}['node'](){return this['node_'];}}class us{constructor(_0x4e1f4c,_0x4500d1){this['syncTree_']=_0x4e1f4c,this['path_']=_0x4500d1;}['getImmediateChild'](_0x3bcac5){const _0x47384f=k(this['path_'],_0x3bcac5);return new us(this['syncTree_'],_0x47384f);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x4711cf){return _0x4711cf=_0x4711cf||{},_0x4711cf['timestamp']=_0x4711cf['timestamp']||new Date()['getTime'](),_0x4711cf;},gr=function(_0x45afea,_0xaddcc4,_0x196ab6){if(!_0x45afea||typeof _0x45afea!='object')return _0x45afea;if(f('.sv'in _0x45afea,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x45afea['.sv']=='string')return sd(_0x45afea['.sv'],_0xaddcc4,_0x196ab6);if(typeof _0x45afea['.sv']=='object')return rd(_0x45afea['.sv'],_0xaddcc4);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x45afea,null,0x2));},sd=function(_0x5cd415,_0x2f2d01,_0x365547){switch(_0x5cd415){case'timestamp':return _0x365547['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x5cd415);}},rd=function(_0x50c3f8,_0x315501,_0x24ee06){_0x50c3f8['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x50c3f8,null,0x2));const _0x5ef07e=_0x50c3f8['increment'];typeof _0x5ef07e!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x5ef07e);const _0x5bea01=_0x315501['node']();if(f(_0x5bea01!==null&&typeof _0x5bea01<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x5bea01['isLeafNode']())return _0x5ef07e;const _0x188211=_0x5bea01['getValue']();return typeof _0x188211!='number'?_0x5ef07e:_0x188211+_0x5ef07e;},na=function(_0x423fd8,_0x509646,_0x37d45c,_0x19261e){return fs(_0x509646,new us(_0x37d45c,_0x423fd8),_0x19261e);},ds=function(_0x21b642,_0x2e26ae,_0x2f3c65){return fs(_0x21b642,new hs(_0x2e26ae),_0x2f3c65);};function fs(_0x38cb9a,_0x3a87c0,_0x190170){const _0x2895ab=_0x38cb9a['getPriority']()['val'](),_0x4e491a=gr(_0x2895ab,_0x3a87c0['getImmediateChild']('.priority'),_0x190170);let _0x35b1f8;if(_0x38cb9a['isLeafNode']()){const _0x5928eb=_0x38cb9a,_0x295ca1=gr(_0x5928eb['getValue'](),_0x3a87c0,_0x190170);return _0x295ca1!==_0x5928eb['getValue']()||_0x4e491a!==_0x5928eb['getPriority']()['val']()?new D(_0x295ca1,P(_0x4e491a)):_0x38cb9a;}else{const _0xbb30d7=_0x38cb9a;return _0x35b1f8=_0xbb30d7,_0x4e491a!==_0xbb30d7['getPriority']()['val']()&&(_0x35b1f8=_0x35b1f8['updatePriority'](new D(_0x4e491a))),_0xbb30d7['forEachChild'](R,(_0x41bc97,_0x361bdf)=>{const _0x1269ff=fs(_0x361bdf,_0x3a87c0['getImmediateChild'](_0x41bc97),_0x190170);_0x1269ff!==_0x361bdf&&(_0x35b1f8=_0x35b1f8['updateImmediateChild'](_0x41bc97,_0x1269ff));}),_0x35b1f8;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x2d8314='',_0x3d423b=null,_0x1dbbc8={'children':{},'childCount':0x0}){this['name']=_0x2d8314,this['parent']=_0x3d423b,this['node']=_0x1dbbc8;}}function Wn(_0x362262,_0x110630){let _0x42697d=_0x110630 instanceof C?_0x110630:new C(_0x110630),_0x1d0e72=_0x362262,_0x3a2102=y(_0x42697d);for(;_0x3a2102!==null;){const _0x477ff0=De(_0x1d0e72['node']['children'],_0x3a2102)||{'children':{},'childCount':0x0};_0x1d0e72=new ps(_0x3a2102,_0x1d0e72,_0x477ff0),_0x42697d=b(_0x42697d),_0x3a2102=y(_0x42697d);}return _0x1d0e72;}function Ge(_0x387855){return _0x387855['node']['value'];}function _s(_0x54ba7b,_0x4c4ac9){_0x54ba7b['node']['value']=_0x4c4ac9,Ai(_0x54ba7b);}function ia(_0xb1fbf1){return _0xb1fbf1['node']['childCount']>0x0;}function od(_0x2bcbe8){return Ge(_0x2bcbe8)===void 0x0&&!ia(_0x2bcbe8);}function Bn(_0x5b059a,_0x4d7416){x(_0x5b059a['node']['children'],(_0x2560eb,_0x5a5ba2)=>{_0x4d7416(new ps(_0x2560eb,_0x5b059a,_0x5a5ba2));});}function sa(_0x2e8224,_0x2b2ec5,_0x5bac6c,_0x107e97){_0x5bac6c&&_0x2b2ec5(_0x2e8224),Bn(_0x2e8224,_0x1e0d25=>{sa(_0x1e0d25,_0x2b2ec5,!0x0);});}function ad(_0x1f8da5,_0x3a6bf2,_0xbf60fa){let _0x442f7c=_0x1f8da5['parent'];for(;_0x442f7c!==null;){if(_0x3a6bf2(_0x442f7c))return!0x0;_0x442f7c=_0x442f7c['parent'];}return!0x1;}function qt(_0x44cf7c){return new C(_0x44cf7c['parent']===null?_0x44cf7c['name']:qt(_0x44cf7c['parent'])+'/'+_0x44cf7c['name']);}function Ai(_0x48e817){_0x48e817['parent']!==null&&cd(_0x48e817['parent'],_0x48e817['name'],_0x48e817);}function cd(_0xedfd7a,_0x7f2313,_0x858a27){const _0x5a9846=od(_0x858a27),_0x8d56ab=J(_0xedfd7a['node']['children'],_0x7f2313);_0x5a9846&&_0x8d56ab?(delete _0xedfd7a['node']['children'][_0x7f2313],_0xedfd7a['node']['childCount']--,Ai(_0xedfd7a)):!_0x5a9846&&!_0x8d56ab&&(_0xedfd7a['node']['children'][_0x7f2313]=_0x858a27['node'],_0xedfd7a['node']['childCount']++,Ai(_0xedfd7a));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x16b483){return typeof _0x16b483=='string'&&_0x16b483['length']!==0x0&&!ld['test'](_0x16b483);},ra=function(_0x50c0a7){return typeof _0x50c0a7=='string'&&_0x50c0a7['length']!==0x0&&!hd['test'](_0x50c0a7);},ud=function(_0x3f087b){return _0x3f087b&&(_0x3f087b=_0x3f087b['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x3f087b);},Tn=function(_0x5d930e){return _0x5d930e===null||typeof _0x5d930e=='string'||typeof _0x5d930e=='number'&&!Vi(_0x5d930e)||_0x5d930e&&typeof _0x5d930e=='object'&&J(_0x5d930e,'.sv');},zt=function(_0x1d240d,_0xf06e04,_0xd6001,_0x29c27b){_0x29c27b&&_0xf06e04===void 0x0||jt(Pn(_0x1d240d,'value'),_0xf06e04,_0xd6001);},jt=function(_0x37a8f8,_0x567eb4,_0xae0210){const _0x3d9806=_0xae0210 instanceof C?new Ah(_0xae0210,_0x37a8f8):_0xae0210;if(_0x567eb4===void 0x0)throw new Error(_0x37a8f8+'contains\x20undefined\x20'+Pe(_0x3d9806));if(typeof _0x567eb4=='function')throw new Error(_0x37a8f8+'contains\x20a\x20function\x20'+Pe(_0x3d9806)+'\x20with\x20contents\x20=\x20'+_0x567eb4['toString']());if(Vi(_0x567eb4))throw new Error(_0x37a8f8+'contains\x20'+_0x567eb4['toString']()+'\x20'+Pe(_0x3d9806));if(typeof _0x567eb4=='string'&&_0x567eb4['length']>ai/0x3&&On(_0x567eb4)>ai)throw new Error(_0x37a8f8+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x3d9806)+'\x20(\x27'+_0x567eb4['substring'](0x0,0x32)+'...\x27)');if(_0x567eb4&&typeof _0x567eb4=='object'){let _0x591444=!0x1,_0x199864=!0x1;if(x(_0x567eb4,(_0x519bf8,_0x7bf864)=>{if(_0x519bf8==='.value')_0x591444=!0x0;else{if(_0x519bf8!=='.priority'&&_0x519bf8!=='.sv'&&(_0x199864=!0x0,!gs(_0x519bf8)))throw new Error(_0x37a8f8+'\x20contains\x20an\x20invalid\x20key\x20('+_0x519bf8+')\x20'+Pe(_0x3d9806)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x3d9806,_0x519bf8),jt(_0x37a8f8,_0x7bf864,_0x3d9806),Nh(_0x3d9806);}),_0x591444&&_0x199864)throw new Error(_0x37a8f8+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x3d9806)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x4c376d,_0x434014){let _0x45c8de,_0x57ca34;for(_0x45c8de=0x0;_0x45c8de<_0x434014['length'];_0x45c8de++){_0x57ca34=_0x434014[_0x45c8de];const _0x27bacb=Pt(_0x57ca34);for(let _0x3bab39=0x0;_0x3bab39<_0x27bacb['length'];_0x3bab39++)if(!(_0x27bacb[_0x3bab39]==='.priority'&&_0x3bab39===_0x27bacb['length']-0x1)){if(!gs(_0x27bacb[_0x3bab39]))throw new Error(_0x4c376d+'contains\x20an\x20invalid\x20key\x20('+_0x27bacb[_0x3bab39]+')\x20in\x20path\x20'+_0x57ca34['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x434014['sort'](Rh);let _0x1038a4=null;for(_0x45c8de=0x0;_0x45c8de<_0x434014['length'];_0x45c8de++){if(_0x57ca34=_0x434014[_0x45c8de],_0x1038a4!==null&&G(_0x1038a4,_0x57ca34))throw new Error(_0x4c376d+'contains\x20a\x20path\x20'+_0x1038a4['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x57ca34['toString']());_0x1038a4=_0x57ca34;}},fd=function(_0x38d28e,_0x345a6e,_0x55f297,_0x284239){const _0x5c7882=Pn(_0x38d28e,'values');if(!(_0x345a6e&&typeof _0x345a6e=='object')||Array['isArray'](_0x345a6e))throw new Error(_0x5c7882+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x4c2ba5=[];x(_0x345a6e,(_0x35cd68,_0x258728)=>{const _0x50e225=new C(_0x35cd68);if(jt(_0x5c7882,_0x258728,k(_0x55f297,_0x50e225)),zi(_0x50e225)==='.priority'&&!Tn(_0x258728))throw new Error(_0x5c7882+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x50e225['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x4c2ba5['push'](_0x50e225);}),dd(_0x5c7882,_0x4c2ba5);},ms=function(_0x326ddb,_0x1a71b0,_0x374804,_0x4d6aa8){if(!ra(_0x374804))throw new Error(Pn(_0x326ddb,_0x1a71b0)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x374804+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x2dd9b3,_0x34f4e9,_0x1cb6a5,_0x63ef86){_0x1cb6a5&&(_0x1cb6a5=_0x1cb6a5['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x2dd9b3,_0x34f4e9,_0x1cb6a5);},ys=function(_0x33e835,_0x44626b){if(y(_0x44626b)==='.info')throw new Error(_0x33e835+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x49c3a9,_0x5d8c23){const _0x2748cb=_0x5d8c23['path']['toString']();if(typeof _0x5d8c23['repoInfo']['host']!='string'||_0x5d8c23['repoInfo']['host']['length']===0x0||!gs(_0x5d8c23['repoInfo']['namespace'])&&_0x5d8c23['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x2748cb['length']!==0x0&&!ud(_0x2748cb))throw new Error(Pn(_0x49c3a9,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x36f979,_0x53a18c){let _0x8e2544=null;for(let _0x105cb7=0x0;_0x105cb7<_0x53a18c['length'];_0x105cb7++){const _0x44b50b=_0x53a18c[_0x105cb7],_0x21f0fa=_0x44b50b['getPath']();_0x8e2544!==null&&!ji(_0x21f0fa,_0x8e2544['path'])&&(_0x36f979['eventLists_']['push'](_0x8e2544),_0x8e2544=null),_0x8e2544===null&&(_0x8e2544={'events':[],'path':_0x21f0fa}),_0x8e2544['events']['push'](_0x44b50b);}_0x8e2544&&_0x36f979['eventLists_']['push'](_0x8e2544);}function oa(_0x1c6c65,_0x5ddfdc,_0x374660){Vn(_0x1c6c65,_0x374660),aa(_0x1c6c65,_0x5711e2=>ji(_0x5711e2,_0x5ddfdc));}function H(_0x13bd6c,_0x3cf369,_0x15cbb9){Vn(_0x13bd6c,_0x15cbb9),aa(_0x13bd6c,_0x294ab2=>G(_0x294ab2,_0x3cf369)||G(_0x3cf369,_0x294ab2));}function aa(_0x1b978b,_0x29f6a1){_0x1b978b['recursionDepth_']++;let _0x2f7173=!0x0;for(let _0xdc08ab=0x0;_0xdc08ab<_0x1b978b['eventLists_']['length'];_0xdc08ab++){const _0x2f97a6=_0x1b978b['eventLists_'][_0xdc08ab];if(_0x2f97a6){const _0x1a770a=_0x2f97a6['path'];_0x29f6a1(_0x1a770a)?(md(_0x1b978b['eventLists_'][_0xdc08ab]),_0x1b978b['eventLists_'][_0xdc08ab]=null):_0x2f7173=!0x1;}}_0x2f7173&&(_0x1b978b['eventLists_']=[]),_0x1b978b['recursionDepth_']--;}function md(_0x4e9d5f){for(let _0x178d21=0x0;_0x178d21<_0x4e9d5f['events']['length'];_0x178d21++){const _0x4674f6=_0x4e9d5f['events'][_0x178d21];if(_0x4674f6!==null){_0x4e9d5f['events'][_0x178d21]=null;const _0x3352cb=_0x4674f6['getEventRunner']();wt&&L('event:\x20'+_0x4674f6['toString']()),ht(_0x3352cb);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x3285c6,_0x2ebd7a,_0x5223c1,_0x21a262){this['repoInfo_']=_0x3285c6,this['forceRestClient_']=_0x2ebd7a,this['authTokenProvider_']=_0x5223c1,this['appCheckProvider_']=_0x21a262,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x1b1196,_0x16b4b7,_0xcbcbf5){if(_0x1b1196['stats_']=Gi(_0x1b1196['repoInfo_']),_0x1b1196['forceRestClient_']||Xl())_0x1b1196['server_']=new pn(_0x1b1196['repoInfo_'],(_0x523e3b,_0x1fb53b,_0x32f3c0,_0x3a77cc)=>{mr(_0x1b1196,_0x523e3b,_0x1fb53b,_0x32f3c0,_0x3a77cc);},_0x1b1196['authTokenProvider_'],_0x1b1196['appCheckProvider_']),setTimeout(()=>yr(_0x1b1196,!0x0),0x0);else{if(typeof _0xcbcbf5<'u'&&_0xcbcbf5!==null){if(typeof _0xcbcbf5!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0xcbcbf5);}catch(_0x194490){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x194490);}}_0x1b1196['persistentConnection_']=new se(_0x1b1196['repoInfo_'],_0x16b4b7,(_0x332387,_0x4a78da,_0x55dd58,_0x101dd5)=>{mr(_0x1b1196,_0x332387,_0x4a78da,_0x55dd58,_0x101dd5);},_0x568d40=>{yr(_0x1b1196,_0x568d40);},_0x37268e=>{Id(_0x1b1196,_0x37268e);},_0x1b1196['authTokenProvider_'],_0x1b1196['appCheckProvider_'],_0xcbcbf5),_0x1b1196['server_']=_0x1b1196['persistentConnection_'];}_0x1b1196['authTokenProvider_']['addTokenChangeListener'](_0x12f8f9=>{_0x1b1196['server_']['refreshAuthToken'](_0x12f8f9);}),_0x1b1196['appCheckProvider_']['addTokenChangeListener'](_0x47f4ab=>{_0x1b1196['server_']['refreshAppCheckToken'](_0x47f4ab['token']);}),_0x1b1196['statsReporter_']=ih(_0x1b1196['repoInfo_'],()=>new iu(_0x1b1196['stats_'],_0x1b1196['server_'])),_0x1b1196['infoData_']=new Xh(),_0x1b1196['infoSyncTree_']=new _r({'startListening':(_0xcefc82,_0x4916d2,_0x464321,_0x4c4142)=>{let _0x6f0ba1=[];const _0x331584=_0x1b1196['infoData_']['getNode'](_0xcefc82['_path']);return _0x331584['isEmpty']()||(_0x6f0ba1=Gt(_0x1b1196['infoSyncTree_'],_0xcefc82['_path'],_0x331584),setTimeout(()=>{_0x4c4142('ok');},0x0)),_0x6f0ba1;},'stopListening':()=>{}}),vs(_0x1b1196,'connected',!0x1),_0x1b1196['serverSyncTree_']=new _r({'startListening':(_0x17bc79,_0x1b7188,_0x506c7b,_0x1e94f9)=>(_0x1b1196['server_']['listen'](_0x17bc79,_0x506c7b,_0x1b7188,(_0x3a678d,_0x5c1653)=>{const _0x130871=_0x1e94f9(_0x3a678d,_0x5c1653);H(_0x1b1196['eventQueue_'],_0x17bc79['_path'],_0x130871);}),[]),'stopListening':(_0x5664e9,_0x4faff9)=>{_0x1b1196['server_']['unlisten'](_0x5664e9,_0x4faff9);}});}function la(_0x5c216c){const _0x5f008d=_0x5c216c['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x5f008d;}function Kt(_0x5948fa){return id({'timestamp':la(_0x5948fa)});}function mr(_0x23cde1,_0x2580cd,_0x26cf04,_0x46728b,_0x14a96){_0x23cde1['dataUpdateCount']++;const _0x3086bb=new C(_0x2580cd);_0x26cf04=_0x23cde1['interceptServerDataCallback_']?_0x23cde1['interceptServerDataCallback_'](_0x2580cd,_0x26cf04):_0x26cf04;let _0x480dd4=[];if(_0x14a96){if(_0x46728b){const _0x4a4552=hn(_0x26cf04,_0x44c0bc=>P(_0x44c0bc));_0x480dd4=Ju(_0x23cde1['serverSyncTree_'],_0x3086bb,_0x4a4552,_0x14a96);}else{const _0x4af1f4=P(_0x26cf04);_0x480dd4=Xo(_0x23cde1['serverSyncTree_'],_0x3086bb,_0x4af1f4,_0x14a96);}}else{if(_0x46728b){const _0x435bbd=hn(_0x26cf04,_0xf0ff2d=>P(_0xf0ff2d));_0x480dd4=Ku(_0x23cde1['serverSyncTree_'],_0x3086bb,_0x435bbd);}else{const _0x173e27=P(_0x26cf04);_0x480dd4=Gt(_0x23cde1['serverSyncTree_'],_0x3086bb,_0x173e27);}}let _0xa8cddf=_0x3086bb;_0x480dd4['length']>0x0&&(_0xa8cddf=it(_0x23cde1,_0x3086bb)),H(_0x23cde1['eventQueue_'],_0xa8cddf,_0x480dd4);}function yr(_0x2695af,_0x2957a){vs(_0x2695af,'connected',_0x2957a),_0x2957a===!0x1&&Sd(_0x2695af);}function Id(_0x514eaa,_0x3a58a3){x(_0x3a58a3,(_0x4c3a06,_0x2cea17)=>{vs(_0x514eaa,_0x4c3a06,_0x2cea17);});}function vs(_0x59766f,_0x16b2b9,_0x4a99f5){const _0x189eaa=new C('/.info/'+_0x16b2b9),_0x151388=P(_0x4a99f5);_0x59766f['infoData_']['updateSnapshot'](_0x189eaa,_0x151388);const _0x382bfa=Gt(_0x59766f['infoSyncTree_'],_0x189eaa,_0x151388);H(_0x59766f['eventQueue_'],_0x189eaa,_0x382bfa);}function Hn(_0x5c45d6){return _0x5c45d6['nextWriteId_']++;}function wd(_0x49de86,_0x1bd79b,_0x175d50){const _0x3fac03=Xu(_0x49de86['serverSyncTree_'],_0x1bd79b);return _0x3fac03!=null?Promise['resolve'](_0x3fac03):_0x49de86['server_']['get'](_0x1bd79b)['then'](_0x59aa06=>{const _0x8d5fb6=P(_0x59aa06)['withIndex'](_0x1bd79b['_queryParams']['getIndex']());Ri(_0x49de86['serverSyncTree_'],_0x1bd79b,_0x175d50,!0x0);let _0x2c972c;if(_0x1bd79b['_queryParams']['loadsAllData']())_0x2c972c=Gt(_0x49de86['serverSyncTree_'],_0x1bd79b['_path'],_0x8d5fb6);else{const _0x311a2e=xt(_0x49de86['serverSyncTree_'],_0x1bd79b);_0x2c972c=Xo(_0x49de86['serverSyncTree_'],_0x1bd79b['_path'],_0x8d5fb6,_0x311a2e);}return H(_0x49de86['eventQueue_'],_0x1bd79b['_path'],_0x2c972c),Cn(_0x49de86['serverSyncTree_'],_0x1bd79b,_0x175d50,null,!0x0),_0x8d5fb6;},_0x4b8903=>(dt(_0x49de86,'get\x20for\x20query\x20'+O(_0x1bd79b)+'\x20failed:\x20'+_0x4b8903),Promise['reject'](new Error(_0x4b8903))));}function Cd(_0x4e6ba7,_0xee5e65,_0x47bb94,_0x436e55,_0x137a1e){dt(_0x4e6ba7,'set',{'path':_0xee5e65['toString'](),'value':_0x47bb94,'priority':_0x436e55});const _0x942dda=Kt(_0x4e6ba7),_0x48d4f0=P(_0x47bb94,_0x436e55),_0x56753a=Fn(_0x4e6ba7['serverSyncTree_'],_0xee5e65),_0x1e4b1d=ds(_0x48d4f0,_0x56753a,_0x942dda),_0xe4eb56=Hn(_0x4e6ba7),_0x450bbc=os(_0x4e6ba7['serverSyncTree_'],_0xee5e65,_0x1e4b1d,_0xe4eb56,!0x0);Vn(_0x4e6ba7['eventQueue_'],_0x450bbc),_0x4e6ba7['server_']['put'](_0xee5e65['toString'](),_0x48d4f0['val'](!0x0),(_0x3321f2,_0x40d5b0)=>{const _0x524a5c=_0x3321f2==='ok';_0x524a5c||U('set\x20at\x20'+_0xee5e65+'\x20failed:\x20'+_0x3321f2);const _0x2cd14c=pe(_0x4e6ba7['serverSyncTree_'],_0xe4eb56,!_0x524a5c);H(_0x4e6ba7['eventQueue_'],_0xee5e65,_0x2cd14c),ki(_0x4e6ba7,_0x137a1e,_0x3321f2,_0x40d5b0);});const _0x422c80=Is(_0x4e6ba7,_0xee5e65);it(_0x4e6ba7,_0x422c80),H(_0x4e6ba7['eventQueue_'],_0x422c80,[]);}function Td(_0x48f615,_0x5795d4,_0x46a43a,_0x1c1849){dt(_0x48f615,'update',{'path':_0x5795d4['toString'](),'value':_0x46a43a});let _0x23c8f6=!0x0;const _0x843fca=Kt(_0x48f615),_0x11723f={};if(x(_0x46a43a,(_0x336f5f,_0x57c33f)=>{_0x23c8f6=!0x1,_0x11723f[_0x336f5f]=na(k(_0x5795d4,_0x336f5f),P(_0x57c33f),_0x48f615['serverSyncTree_'],_0x843fca);}),_0x23c8f6)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x48f615,_0x1c1849,'ok',void 0x0);else{const _0x68ce8=Hn(_0x48f615),_0x161d52=ju(_0x48f615['serverSyncTree_'],_0x5795d4,_0x11723f,_0x68ce8);Vn(_0x48f615['eventQueue_'],_0x161d52),_0x48f615['server_']['merge'](_0x5795d4['toString'](),_0x46a43a,(_0x19faae,_0x2cfd65)=>{const _0x14ada2=_0x19faae==='ok';_0x14ada2||U('update\x20at\x20'+_0x5795d4+'\x20failed:\x20'+_0x19faae);const _0x4a9b7b=pe(_0x48f615['serverSyncTree_'],_0x68ce8,!_0x14ada2),_0x2e39bc=_0x4a9b7b['length']>0x0?it(_0x48f615,_0x5795d4):_0x5795d4;H(_0x48f615['eventQueue_'],_0x2e39bc,_0x4a9b7b),ki(_0x48f615,_0x1c1849,_0x19faae,_0x2cfd65);}),x(_0x46a43a,_0x5301de=>{const _0x42ab98=Is(_0x48f615,k(_0x5795d4,_0x5301de));it(_0x48f615,_0x42ab98);}),H(_0x48f615['eventQueue_'],_0x5795d4,[]);}}function Sd(_0x10208a){dt(_0x10208a,'onDisconnectEvents');const _0x546851=Kt(_0x10208a),_0x5b859a=_n();Ii(_0x10208a['onDisconnect_'],w(),(_0x1c141f,_0x255703)=>{const _0x120bd3=na(_0x1c141f,_0x255703,_0x10208a['serverSyncTree_'],_0x546851);Fo(_0x5b859a,_0x1c141f,_0x120bd3);});let _0x514e25=[];Ii(_0x5b859a,w(),(_0x96786d,_0x36eb9f)=>{_0x514e25=_0x514e25['concat'](Gt(_0x10208a['serverSyncTree_'],_0x96786d,_0x36eb9f));const _0x1c9c39=Is(_0x10208a,_0x96786d);it(_0x10208a,_0x1c9c39);}),_0x10208a['onDisconnect_']=_n(),H(_0x10208a['eventQueue_'],w(),_0x514e25);}function bd(_0x205817,_0x4a19c3,_0x9ce237){let _0x33b8c2;y(_0x4a19c3['_path'])==='.info'?_0x33b8c2=Ri(_0x205817['infoSyncTree_'],_0x4a19c3,_0x9ce237):_0x33b8c2=Ri(_0x205817['serverSyncTree_'],_0x4a19c3,_0x9ce237),oa(_0x205817['eventQueue_'],_0x4a19c3['_path'],_0x33b8c2);}function Rd(_0x4966e9,_0x3d031c,_0x28779e){let _0x3f1433;y(_0x3d031c['_path'])==='.info'?_0x3f1433=Cn(_0x4966e9['infoSyncTree_'],_0x3d031c,_0x28779e):_0x3f1433=Cn(_0x4966e9['serverSyncTree_'],_0x3d031c,_0x28779e),oa(_0x4966e9['eventQueue_'],_0x3d031c['_path'],_0x3f1433);}function ha(_0x5c7ff6){_0x5c7ff6['persistentConnection_']&&_0x5c7ff6['persistentConnection_']['interrupt'](ca);}function Ad(_0x1bb625){_0x1bb625['persistentConnection_']&&_0x1bb625['persistentConnection_']['resume'](ca);}function dt(_0x456bd4,..._0x3dfca3){let _0x436383='';_0x456bd4['persistentConnection_']&&(_0x436383=_0x456bd4['persistentConnection_']['id']+':'),L(_0x436383,..._0x3dfca3);}function ki(_0x51f92e,_0x581f44,_0x1d5589,_0x51cdf3){_0x581f44&&ht(()=>{if(_0x1d5589==='ok')_0x581f44(null);else{const _0x40dc93=(_0x1d5589||'error')['toUpperCase']();let _0xf60c9a=_0x40dc93;_0x51cdf3&&(_0xf60c9a+=':\x20'+_0x51cdf3);const _0x22dd0e=new Error(_0xf60c9a);_0x22dd0e['code']=_0x40dc93,_0x581f44(_0x22dd0e);}});}function kd(_0x225fe2,_0x7d5087,_0x17ea72,_0x3efb09,_0x537c2a,_0x2de117){dt(_0x225fe2,'transaction\x20on\x20'+_0x7d5087);const _0xf3b5={'path':_0x7d5087,'update':_0x17ea72,'onComplete':_0x3efb09,'status':null,'order':so(),'applyLocally':_0x2de117,'retryCount':0x0,'unwatcher':_0x537c2a,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x571c2b=Es(_0x225fe2,_0x7d5087,void 0x0);_0xf3b5['currentInputSnapshot']=_0x571c2b;const _0xa632f1=_0xf3b5['update'](_0x571c2b['val']());if(_0xa632f1===void 0x0)_0xf3b5['unwatcher'](),_0xf3b5['currentOutputSnapshotRaw']=null,_0xf3b5['currentOutputSnapshotResolved']=null,_0xf3b5['onComplete']&&_0xf3b5['onComplete'](null,!0x1,_0xf3b5['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0xa632f1,_0xf3b5['path']),_0xf3b5['status']=0x0;const _0x3b6742=Wn(_0x225fe2['transactionQueueTree_'],_0x7d5087),_0x24b94d=Ge(_0x3b6742)||[];_0x24b94d['push'](_0xf3b5),_s(_0x3b6742,_0x24b94d);let _0x1517ed;typeof _0xa632f1=='object'&&_0xa632f1!==null&&J(_0xa632f1,'.priority')?(_0x1517ed=De(_0xa632f1,'.priority'),f(Tn(_0x1517ed),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x1517ed=(Fn(_0x225fe2['serverSyncTree_'],_0x7d5087)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x1e76c7=Kt(_0x225fe2),_0x59036e=P(_0xa632f1,_0x1517ed),_0x2b85f1=ds(_0x59036e,_0x571c2b,_0x1e76c7);_0xf3b5['currentOutputSnapshotRaw']=_0x59036e,_0xf3b5['currentOutputSnapshotResolved']=_0x2b85f1,_0xf3b5['currentWriteId']=Hn(_0x225fe2);const _0x33879e=os(_0x225fe2['serverSyncTree_'],_0x7d5087,_0x2b85f1,_0xf3b5['currentWriteId'],_0xf3b5['applyLocally']);H(_0x225fe2['eventQueue_'],_0x7d5087,_0x33879e),$n(_0x225fe2,_0x225fe2['transactionQueueTree_']);}}function Es(_0x10a0d7,_0x32fca7,_0xabe0f5){return Fn(_0x10a0d7['serverSyncTree_'],_0x32fca7,_0xabe0f5)||g['EMPTY_NODE'];}function $n(_0x5a0f2e,_0x55eda6=_0x5a0f2e['transactionQueueTree_']){if(_0x55eda6||Gn(_0x5a0f2e,_0x55eda6),Ge(_0x55eda6)){const _0x43873a=da(_0x5a0f2e,_0x55eda6);f(_0x43873a['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x43873a['every'](_0x17263c=>_0x17263c['status']===0x0)&&Nd(_0x5a0f2e,qt(_0x55eda6),_0x43873a);}else ia(_0x55eda6)&&Bn(_0x55eda6,_0x1e2a8c=>{$n(_0x5a0f2e,_0x1e2a8c);});}function Nd(_0x670333,_0x37fdb0,_0x33ef56){const _0x63a043=_0x33ef56['map'](_0x2737a7=>_0x2737a7['currentWriteId']),_0x4b68c2=Es(_0x670333,_0x37fdb0,_0x63a043);let _0xc4f461=_0x4b68c2;const _0x588a67=_0x4b68c2['hash']();for(let _0xff0422=0x0;_0xff0422<_0x33ef56['length'];_0xff0422++){const _0x421314=_0x33ef56[_0xff0422];f(_0x421314['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x421314['status']=0x1,_0x421314['retryCount']++;const _0x28039d=F(_0x37fdb0,_0x421314['path']);_0xc4f461=_0xc4f461['updateChild'](_0x28039d,_0x421314['currentOutputSnapshotRaw']);}const _0x32c424=_0xc4f461['val'](!0x0),_0x57ab1a=_0x37fdb0;_0x670333['server_']['put'](_0x57ab1a['toString'](),_0x32c424,_0x667d03=>{dt(_0x670333,'transaction\x20put\x20response',{'path':_0x57ab1a['toString'](),'status':_0x667d03});let _0x2dc4c3=[];if(_0x667d03==='ok'){const _0x176021=[];for(let _0x28a3a6=0x0;_0x28a3a6<_0x33ef56['length'];_0x28a3a6++)_0x33ef56[_0x28a3a6]['status']=0x2,_0x2dc4c3=_0x2dc4c3['concat'](pe(_0x670333['serverSyncTree_'],_0x33ef56[_0x28a3a6]['currentWriteId'])),_0x33ef56[_0x28a3a6]['onComplete']&&_0x176021['push'](()=>_0x33ef56[_0x28a3a6]['onComplete'](null,!0x0,_0x33ef56[_0x28a3a6]['currentOutputSnapshotResolved'])),_0x33ef56[_0x28a3a6]['unwatcher']();Gn(_0x670333,Wn(_0x670333['transactionQueueTree_'],_0x37fdb0)),$n(_0x670333,_0x670333['transactionQueueTree_']),H(_0x670333['eventQueue_'],_0x37fdb0,_0x2dc4c3);for(let _0x1bb7e0=0x0;_0x1bb7e0<_0x176021['length'];_0x1bb7e0++)ht(_0x176021[_0x1bb7e0]);}else{if(_0x667d03==='datastale'){for(let _0x5a8ffa=0x0;_0x5a8ffa<_0x33ef56['length'];_0x5a8ffa++)_0x33ef56[_0x5a8ffa]['status']===0x3?_0x33ef56[_0x5a8ffa]['status']=0x4:_0x33ef56[_0x5a8ffa]['status']=0x0;}else{U('transaction\x20at\x20'+_0x57ab1a['toString']()+'\x20failed:\x20'+_0x667d03);for(let _0x509c7e=0x0;_0x509c7e<_0x33ef56['length'];_0x509c7e++)_0x33ef56[_0x509c7e]['status']=0x4,_0x33ef56[_0x509c7e]['abortReason']=_0x667d03;}it(_0x670333,_0x37fdb0);}},_0x588a67);}function it(_0x30dbae,_0x5bc9e0){const _0x2dcca8=ua(_0x30dbae,_0x5bc9e0),_0x5ac472=qt(_0x2dcca8),_0x176778=da(_0x30dbae,_0x2dcca8);return Pd(_0x30dbae,_0x176778,_0x5ac472),_0x5ac472;}function Pd(_0x3c7e36,_0x87a5ab,_0x3c0f3b){if(_0x87a5ab['length']===0x0)return;const _0x6f19fd=[];let _0x5d51f5=[];const _0x1a5e63=_0x87a5ab['filter'](_0x47a86d=>_0x47a86d['status']===0x0)['map'](_0x1d8076=>_0x1d8076['currentWriteId']);for(let _0x3cfa27=0x0;_0x3cfa27<_0x87a5ab['length'];_0x3cfa27++){const _0x11eb21=_0x87a5ab[_0x3cfa27],_0x1a33b5=F(_0x3c0f3b,_0x11eb21['path']);let _0x38ea50=!0x1,_0xb403e6;if(f(_0x1a33b5!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x11eb21['status']===0x4)_0x38ea50=!0x0,_0xb403e6=_0x11eb21['abortReason'],_0x5d51f5=_0x5d51f5['concat'](pe(_0x3c7e36['serverSyncTree_'],_0x11eb21['currentWriteId'],!0x0));else{if(_0x11eb21['status']===0x0){if(_0x11eb21['retryCount']>=yd)_0x38ea50=!0x0,_0xb403e6='maxretry',_0x5d51f5=_0x5d51f5['concat'](pe(_0x3c7e36['serverSyncTree_'],_0x11eb21['currentWriteId'],!0x0));else{const _0x131367=Es(_0x3c7e36,_0x11eb21['path'],_0x1a5e63);_0x11eb21['currentInputSnapshot']=_0x131367;const _0x301479=_0x87a5ab[_0x3cfa27]['update'](_0x131367['val']());if(_0x301479!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x301479,_0x11eb21['path']);let _0x2a5db8=P(_0x301479);typeof _0x301479=='object'&&_0x301479!=null&&J(_0x301479,'.priority')||(_0x2a5db8=_0x2a5db8['updatePriority'](_0x131367['getPriority']()));const _0x30288c=_0x11eb21['currentWriteId'],_0x4ec29f=Kt(_0x3c7e36),_0x1f11e1=ds(_0x2a5db8,_0x131367,_0x4ec29f);_0x11eb21['currentOutputSnapshotRaw']=_0x2a5db8,_0x11eb21['currentOutputSnapshotResolved']=_0x1f11e1,_0x11eb21['currentWriteId']=Hn(_0x3c7e36),_0x1a5e63['splice'](_0x1a5e63['indexOf'](_0x30288c),0x1),_0x5d51f5=_0x5d51f5['concat'](os(_0x3c7e36['serverSyncTree_'],_0x11eb21['path'],_0x1f11e1,_0x11eb21['currentWriteId'],_0x11eb21['applyLocally'])),_0x5d51f5=_0x5d51f5['concat'](pe(_0x3c7e36['serverSyncTree_'],_0x30288c,!0x0));}else _0x38ea50=!0x0,_0xb403e6='nodata',_0x5d51f5=_0x5d51f5['concat'](pe(_0x3c7e36['serverSyncTree_'],_0x11eb21['currentWriteId'],!0x0));}}}H(_0x3c7e36['eventQueue_'],_0x3c0f3b,_0x5d51f5),_0x5d51f5=[],_0x38ea50&&(_0x87a5ab[_0x3cfa27]['status']=0x2,function(_0x27284e){setTimeout(_0x27284e,Math['floor'](0x0));}(_0x87a5ab[_0x3cfa27]['unwatcher']),_0x87a5ab[_0x3cfa27]['onComplete']&&(_0xb403e6==='nodata'?_0x6f19fd['push'](()=>_0x87a5ab[_0x3cfa27]['onComplete'](null,!0x1,_0x87a5ab[_0x3cfa27]['currentInputSnapshot'])):_0x6f19fd['push'](()=>_0x87a5ab[_0x3cfa27]['onComplete'](new Error(_0xb403e6),!0x1,null))));}Gn(_0x3c7e36,_0x3c7e36['transactionQueueTree_']);for(let _0xc0cf27=0x0;_0xc0cf27<_0x6f19fd['length'];_0xc0cf27++)ht(_0x6f19fd[_0xc0cf27]);$n(_0x3c7e36,_0x3c7e36['transactionQueueTree_']);}function ua(_0x91e1b6,_0x2d7911){let _0x19a928,_0x7b36ec=_0x91e1b6['transactionQueueTree_'];for(_0x19a928=y(_0x2d7911);_0x19a928!==null&&Ge(_0x7b36ec)===void 0x0;)_0x7b36ec=Wn(_0x7b36ec,_0x19a928),_0x2d7911=b(_0x2d7911),_0x19a928=y(_0x2d7911);return _0x7b36ec;}function da(_0x18734a,_0x47ba49){const _0x5a815d=[];return fa(_0x18734a,_0x47ba49,_0x5a815d),_0x5a815d['sort']((_0x41da92,_0x289a7c)=>_0x41da92['order']-_0x289a7c['order']),_0x5a815d;}function fa(_0x1717c5,_0x862dfc,_0x126de5){const _0x21ed6f=Ge(_0x862dfc);if(_0x21ed6f){for(let _0x2126dd=0x0;_0x2126dd<_0x21ed6f['length'];_0x2126dd++)_0x126de5['push'](_0x21ed6f[_0x2126dd]);}Bn(_0x862dfc,_0x3abff1=>{fa(_0x1717c5,_0x3abff1,_0x126de5);});}function Gn(_0x2685c1,_0x4d212a){const _0x2df1f0=Ge(_0x4d212a);if(_0x2df1f0){let _0x4e3b57=0x0;for(let _0x4300de=0x0;_0x4300de<_0x2df1f0['length'];_0x4300de++)_0x2df1f0[_0x4300de]['status']!==0x2&&(_0x2df1f0[_0x4e3b57]=_0x2df1f0[_0x4300de],_0x4e3b57++);_0x2df1f0['length']=_0x4e3b57,_s(_0x4d212a,_0x2df1f0['length']>0x0?_0x2df1f0:void 0x0);}Bn(_0x4d212a,_0xe2b86a=>{Gn(_0x2685c1,_0xe2b86a);});}function Is(_0x32f0d0,_0x19cdf4){const _0x1b504a=qt(ua(_0x32f0d0,_0x19cdf4)),_0xda0427=Wn(_0x32f0d0['transactionQueueTree_'],_0x19cdf4);return ad(_0xda0427,_0x37d69c=>{ci(_0x32f0d0,_0x37d69c);}),ci(_0x32f0d0,_0xda0427),sa(_0xda0427,_0x5a6fcf=>{ci(_0x32f0d0,_0x5a6fcf);}),_0x1b504a;}function ci(_0x2e5847,_0x4f99ca){const _0x4b092b=Ge(_0x4f99ca);if(_0x4b092b){const _0x2c56b7=[];let _0x519d96=[],_0x4a12c9=-0x1;for(let _0x7867c0=0x0;_0x7867c0<_0x4b092b['length'];_0x7867c0++)_0x4b092b[_0x7867c0]['status']===0x3||(_0x4b092b[_0x7867c0]['status']===0x1?(f(_0x4a12c9===_0x7867c0-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x4a12c9=_0x7867c0,_0x4b092b[_0x7867c0]['status']=0x3,_0x4b092b[_0x7867c0]['abortReason']='set'):(f(_0x4b092b[_0x7867c0]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x4b092b[_0x7867c0]['unwatcher'](),_0x519d96=_0x519d96['concat'](pe(_0x2e5847['serverSyncTree_'],_0x4b092b[_0x7867c0]['currentWriteId'],!0x0)),_0x4b092b[_0x7867c0]['onComplete']&&_0x2c56b7['push'](_0x4b092b[_0x7867c0]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x4a12c9===-0x1?_s(_0x4f99ca,void 0x0):_0x4b092b['length']=_0x4a12c9+0x1,H(_0x2e5847['eventQueue_'],qt(_0x4f99ca),_0x519d96);for(let _0x30fbc9=0x0;_0x30fbc9<_0x2c56b7['length'];_0x30fbc9++)ht(_0x2c56b7[_0x30fbc9]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x4bfcc0){let _0x2d4d14='';const _0x1429ba=_0x4bfcc0['split']('/');for(let _0x583c9c=0x0;_0x583c9c<_0x1429ba['length'];_0x583c9c++)if(_0x1429ba[_0x583c9c]['length']>0x0){let _0x573f8d=_0x1429ba[_0x583c9c];try{_0x573f8d=decodeURIComponent(_0x573f8d['replace'](/\+/g,'\x20'));}catch{}_0x2d4d14+='/'+_0x573f8d;}return _0x2d4d14;}function Dd(_0x2a37e4){const _0xca2f25={};_0x2a37e4['charAt'](0x0)==='?'&&(_0x2a37e4=_0x2a37e4['substring'](0x1));for(const _0x4e5c3c of _0x2a37e4['split']('&')){if(_0x4e5c3c['length']===0x0)continue;const _0x35c965=_0x4e5c3c['split']('=');_0x35c965['length']===0x2?_0xca2f25[decodeURIComponent(_0x35c965[0x0])]=decodeURIComponent(_0x35c965[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x4e5c3c+'\x27\x20in\x20query\x20\x27'+_0x2a37e4+'\x27');}return _0xca2f25;}const vr=function(_0x4ac162,_0x4fa510){const _0x13d7d5=Md(_0x4ac162),_0x4e2a52=_0x13d7d5['namespace'];_0x13d7d5['domain']==='firebase.com'&&ae(_0x13d7d5['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x4e2a52||_0x4e2a52==='undefined')&&_0x13d7d5['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x13d7d5['secure']||$l();const _0x5b34bf=_0x13d7d5['scheme']==='ws'||_0x13d7d5['scheme']==='wss';return{'repoInfo':new yo(_0x13d7d5['host'],_0x13d7d5['secure'],_0x4e2a52,_0x5b34bf,_0x4fa510,'',_0x4e2a52!==_0x13d7d5['subdomain']),'path':new C(_0x13d7d5['pathString'])};},Md=function(_0x577eb8){let _0x374a90='',_0x42005e='',_0x419d0a='',_0x4310ab='',_0x34f87f='',_0x1deab9=!0x0,_0xfeeb66='https',_0x285da2=0x1bb;if(typeof _0x577eb8=='string'){let _0x47bc43=_0x577eb8['indexOf']('//');_0x47bc43>=0x0&&(_0xfeeb66=_0x577eb8['substring'](0x0,_0x47bc43-0x1),_0x577eb8=_0x577eb8['substring'](_0x47bc43+0x2));let _0x6d1013=_0x577eb8['indexOf']('/');_0x6d1013===-0x1&&(_0x6d1013=_0x577eb8['length']);let _0xdbe931=_0x577eb8['indexOf']('?');_0xdbe931===-0x1&&(_0xdbe931=_0x577eb8['length']),_0x374a90=_0x577eb8['substring'](0x0,Math['min'](_0x6d1013,_0xdbe931)),_0x6d1013<_0xdbe931&&(_0x4310ab=Od(_0x577eb8['substring'](_0x6d1013,_0xdbe931)));const _0x1510b4=Dd(_0x577eb8['substring'](Math['min'](_0x577eb8['length'],_0xdbe931)));_0x47bc43=_0x374a90['indexOf'](':'),_0x47bc43>=0x0?(_0x1deab9=_0xfeeb66==='https'||_0xfeeb66==='wss',_0x285da2=parseInt(_0x374a90['substring'](_0x47bc43+0x1),0xa)):_0x47bc43=_0x374a90['length'];const _0x198b48=_0x374a90['slice'](0x0,_0x47bc43);if(_0x198b48['toLowerCase']()==='localhost')_0x42005e='localhost';else{if(_0x198b48['split']('.')['length']<=0x2)_0x42005e=_0x198b48;else{const _0x56bb8e=_0x374a90['indexOf']('.');_0x419d0a=_0x374a90['substring'](0x0,_0x56bb8e)['toLowerCase'](),_0x42005e=_0x374a90['substring'](_0x56bb8e+0x1),_0x34f87f=_0x419d0a;}}'ns'in _0x1510b4&&(_0x34f87f=_0x1510b4['ns']);}return{'host':_0x374a90,'port':_0x285da2,'domain':_0x42005e,'subdomain':_0x419d0a,'secure':_0x1deab9,'scheme':_0xfeeb66,'pathString':_0x4310ab,'namespace':_0x34f87f};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x462ba9=0x0;const _0x957ff4=[];return function(_0x25b333){const _0x1f0bbe=_0x25b333===_0x462ba9;_0x462ba9=_0x25b333;let _0x21f15b;const _0x2192f3=new Array(0x8);for(_0x21f15b=0x7;_0x21f15b>=0x0;_0x21f15b--)_0x2192f3[_0x21f15b]=Er['charAt'](_0x25b333%0x40),_0x25b333=Math['floor'](_0x25b333/0x40);f(_0x25b333===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x5e9980=_0x2192f3['join']('');if(_0x1f0bbe){for(_0x21f15b=0xb;_0x21f15b>=0x0&&_0x957ff4[_0x21f15b]===0x3f;_0x21f15b--)_0x957ff4[_0x21f15b]=0x0;_0x957ff4[_0x21f15b]++;}else{for(_0x21f15b=0x0;_0x21f15b<0xc;_0x21f15b++)_0x957ff4[_0x21f15b]=Math['floor'](Math['random']()*0x40);}for(_0x21f15b=0x0;_0x21f15b<0xc;_0x21f15b++)_0x5e9980+=Er['charAt'](_0x957ff4[_0x21f15b]);return f(_0x5e9980['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x5e9980;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x4ba974,_0x2f6137,_0x1f31d3,_0x21e612){this['eventType']=_0x4ba974,this['eventRegistration']=_0x2f6137,this['snapshot']=_0x1f31d3,this['prevName']=_0x21e612;}['getPath'](){const _0x17a8b6=this['snapshot']['ref'];return this['eventType']==='value'?_0x17a8b6['_path']:_0x17a8b6['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x4f8385,_0x3083cc,_0x43c8d7){this['eventRegistration']=_0x4f8385,this['error']=_0x3083cc,this['path']=_0x43c8d7;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x18c1ac,_0x1618d5){this['snapshotCallback']=_0x18c1ac,this['cancelCallback']=_0x1618d5;}['onValue'](_0x3a90c1,_0x56b078){this['snapshotCallback']['call'](null,_0x3a90c1,_0x56b078);}['onCancel'](_0x4ddb7a){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x4ddb7a);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0xc9e784){return this['snapshotCallback']===_0xc9e784['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0xc9e784['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0xc9e784['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x5775b9,_0xe3b35b,_0x42b153,_0x4e6aef){this['_repo']=_0x5775b9,this['_path']=_0xe3b35b,this['_queryParams']=_0x42b153,this['_orderByCalled']=_0x4e6aef;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x2b2dac=rr(this['_queryParams']),_0xb07515=Hi(_0x2b2dac);return _0xb07515==='{}'?'default':_0xb07515;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x3b0757){if(_0x3b0757=N(_0x3b0757),!(_0x3b0757 instanceof be))return!0x1;const _0x68c458=this['_repo']===_0x3b0757['_repo'],_0x570f28=ji(this['_path'],_0x3b0757['_path']),_0x467949=this['_queryIdentifier']===_0x3b0757['_queryIdentifier'];return _0x68c458&&_0x570f28&&_0x467949;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x8d01e2,_0x29619c){if(_0x8d01e2['_orderByCalled']===!0x0)throw new Error(_0x29619c+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x371721){let _0x2a0442=null,_0x3b43ae=null;if(_0x371721['hasStart']()&&(_0x2a0442=_0x371721['getIndexStartValue']()),_0x371721['hasEnd']()&&(_0x3b43ae=_0x371721['getIndexEndValue']()),_0x371721['getIndex']()===ye){const _0x27f46b='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x3cfbee='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x371721['hasStart']()){if(_0x371721['getIndexStartName']()!==Fe)throw new Error(_0x27f46b);if(typeof _0x2a0442!='string')throw new Error(_0x3cfbee);}if(_0x371721['hasEnd']()){if(_0x371721['getIndexEndName']()!==Ie)throw new Error(_0x27f46b);if(typeof _0x3b43ae!='string')throw new Error(_0x3cfbee);}}else{if(_0x371721['getIndex']()===R){if(_0x2a0442!=null&&!Tn(_0x2a0442)||_0x3b43ae!=null&&!Tn(_0x3b43ae))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x371721['getIndex']()instanceof Qi||_0x371721['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x2a0442!=null&&typeof _0x2a0442=='object'||_0x3b43ae!=null&&typeof _0x3b43ae=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x48c8ce){if(_0x48c8ce['hasStart']()&&_0x48c8ce['hasEnd']()&&_0x48c8ce['hasLimit']()&&!_0x48c8ce['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x21396d,_0x257f0d){super(_0x21396d,_0x257f0d,new Xi(),!0x1);}get['parent'](){const _0x17adde=Ro(this['_path']);return _0x17adde===null?null:new ee(this['_repo'],_0x17adde);}get['root'](){let _0x52e6f6=this;for(;_0x52e6f6['parent']!==null;)_0x52e6f6=_0x52e6f6['parent'];return _0x52e6f6;}}class st{constructor(_0x22acee,_0x5c575f,_0x3cae98){this['_node']=_0x22acee,this['ref']=_0x5c575f,this['_index']=_0x3cae98;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x73eed4){const _0x1995b8=new C(_0x73eed4),_0x110c3c=Ft(this['ref'],_0x73eed4);return new st(this['_node']['getChild'](_0x1995b8),_0x110c3c,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x4d3ecf){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x22ca4f,_0x113c38)=>_0x4d3ecf(new st(_0x113c38,Ft(this['ref'],_0x22ca4f),R)));}['hasChild'](_0x3563e3){const _0x3e66aa=new C(_0x3563e3);return!this['_node']['getChild'](_0x3e66aa)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x9bd6db,_0x3700db){return _0x9bd6db=N(_0x9bd6db),_0x9bd6db['_checkNotDeleted']('ref'),_0x3700db!==void 0x0?Ft(_0x9bd6db['_root'],_0x3700db):_0x9bd6db['_root'];}function Ft(_0x5b4e88,_0xef8a47){return _0x5b4e88=N(_0x5b4e88),y(_0x5b4e88['_path'])===null?pd('child','path',_0xef8a47):ms('child','path',_0xef8a47),new ee(_0x5b4e88['_repo'],k(_0x5b4e88['_path'],_0xef8a47));}function g_(_0x3384fb,_0x2ef19f){_0x3384fb=N(_0x3384fb),ys('push',_0x3384fb['_path']),zt('push',_0x2ef19f,_0x3384fb['_path'],!0x0);const _0x46855f=la(_0x3384fb['_repo']),_0x335a60=Ld(_0x46855f),_0x468bf1=Ft(_0x3384fb,_0x335a60),_0x21f25d=Ft(_0x3384fb,_0x335a60);let _0x4b5c77;return _0x2ef19f!=null?_0x4b5c77=Ud(_0x21f25d,_0x2ef19f)['then'](()=>_0x21f25d):_0x4b5c77=Promise['resolve'](_0x21f25d),_0x468bf1['then']=_0x4b5c77['then']['bind'](_0x4b5c77),_0x468bf1['catch']=_0x4b5c77['then']['bind'](_0x4b5c77,void 0x0),_0x468bf1;}function Ud(_0x2ca39c,_0x3bd15c){_0x2ca39c=N(_0x2ca39c),ys('set',_0x2ca39c['_path']),zt('set',_0x3bd15c,_0x2ca39c['_path'],!0x1);const _0x110ff5=new ot();return Cd(_0x2ca39c['_repo'],_0x2ca39c['_path'],_0x3bd15c,null,_0x110ff5['wrapCallback'](()=>{})),_0x110ff5['promise'];}function m_(_0x2f5ad3,_0x42735c){fd('update',_0x42735c,_0x2f5ad3['_path']);const _0x28c2c0=new ot();return Td(_0x2f5ad3['_repo'],_0x2f5ad3['_path'],_0x42735c,_0x28c2c0['wrapCallback'](()=>{})),_0x28c2c0['promise'];}function y_(_0x27c682){_0x27c682=N(_0x27c682);const _0x37863f=new pa(()=>{}),_0xac68e5=new zn(_0x37863f);return wd(_0x27c682['_repo'],_0x27c682,_0xac68e5)['then'](_0x2edbc4=>new st(_0x2edbc4,new ee(_0x27c682['_repo'],_0x27c682['_path']),_0x27c682['_queryParams']['getIndex']()));}class zn{constructor(_0x50bd7c){this['callbackContext']=_0x50bd7c;}['respondsTo'](_0x2e4fd3){return _0x2e4fd3==='value';}['createEvent'](_0x14bfd5,_0x55b460){const _0x217590=_0x55b460['_queryParams']['getIndex']();return new xd('value',this,new st(_0x14bfd5['snapshotNode'],new ee(_0x55b460['_repo'],_0x55b460['_path']),_0x217590));}['getEventRunner'](_0x21fd6a){return _0x21fd6a['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x21fd6a['error']):()=>this['callbackContext']['onValue'](_0x21fd6a['snapshot'],null);}['createCancelEvent'](_0x7cbf15,_0x36cf92){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x7cbf15,_0x36cf92):null;}['matches'](_0x5e894b){return _0x5e894b instanceof zn?!_0x5e894b['callbackContext']||!this['callbackContext']?!0x0:_0x5e894b['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x3ce9cf,_0x5d9cf6,_0x584f5b,_0x53c84f,_0x3d06cb){const _0x19dcfa=new pa(_0x584f5b,void 0x0),_0x1665ee=new zn(_0x19dcfa);return bd(_0x3ce9cf['_repo'],_0x3ce9cf,_0x1665ee),()=>Rd(_0x3ce9cf['_repo'],_0x3ce9cf,_0x1665ee);}function Bd(_0x338e2b,_0x3eccf8,_0x14261b,_0x271696){return Wd(_0x338e2b,'value',_0x3eccf8);}class ft{}class ma extends ft{constructor(_0x2ca00f,_0x36b017){super(),this['_value']=_0x2ca00f,this['_key']=_0x36b017,this['type']='endAt';}['_apply'](_0x18ada5){zt('endAt',this['_value'],_0x18ada5['_path'],!0x0);const _0x429dda=Jh(_0x18ada5['_queryParams'],this['_value'],this['_key']);if(ga(_0x429dda),qn(_0x429dda),_0x18ada5['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x18ada5['_repo'],_0x18ada5['_path'],_0x429dda,_0x18ada5['_orderByCalled']);}}function v_(_0x5d734c,_0x261f0d){return new ma(_0x5d734c,_0x261f0d);}class ya extends ft{constructor(_0x1801fb,_0x9e1d73){super(),this['_value']=_0x1801fb,this['_key']=_0x9e1d73,this['type']='startAt';}['_apply'](_0x205c2b){zt('startAt',this['_value'],_0x205c2b['_path'],!0x0);const _0x548b75=Qh(_0x205c2b['_queryParams'],this['_value'],this['_key']);if(ga(_0x548b75),qn(_0x548b75),_0x205c2b['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x205c2b['_repo'],_0x205c2b['_path'],_0x548b75,_0x205c2b['_orderByCalled']);}}function E_(_0x39387d=null,_0x3e8d89){return new ya(_0x39387d,_0x3e8d89);}class Vd extends ft{constructor(_0x4ff447){super(),this['_limit']=_0x4ff447,this['type']='limitToFirst';}['_apply'](_0x3ce0bc){if(_0x3ce0bc['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x3ce0bc['_repo'],_0x3ce0bc['_path'],Yh(_0x3ce0bc['_queryParams'],this['_limit']),_0x3ce0bc['_orderByCalled']);}}function I_(_0x330cb1){if(Math['floor'](_0x330cb1)!==_0x330cb1||_0x330cb1<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x330cb1);}class Hd extends ft{constructor(_0xa185fa){super(),this['_path']=_0xa185fa,this['type']='orderByChild';}['_apply'](_0x1ec0ae){_a(_0x1ec0ae,'orderByChild');const _0xba54ff=new C(this['_path']);if(v(_0xba54ff))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x425ee0=new Qi(_0xba54ff),_0x3daac0=xo(_0x1ec0ae['_queryParams'],_0x425ee0);return qn(_0x3daac0),new be(_0x1ec0ae['_repo'],_0x1ec0ae['_path'],_0x3daac0,!0x0);}}function w_(_0x47651c){if(_0x47651c==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x47651c==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x47651c==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x47651c),new Hd(_0x47651c);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x6d012b){_a(_0x6d012b,'orderByKey');const _0x1036b9=xo(_0x6d012b['_queryParams'],ye);return qn(_0x1036b9),new be(_0x6d012b['_repo'],_0x6d012b['_path'],_0x1036b9,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x17f2e3,_0x5c50f2){super(),this['_value']=_0x17f2e3,this['_key']=_0x5c50f2,this['type']='equalTo';}['_apply'](_0xab581a){if(zt('equalTo',this['_value'],_0xab581a['_path'],!0x1),_0xab581a['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0xab581a['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0xab581a));}}function T_(_0x29bbd3,_0x1a7581){return new Gd(_0x29bbd3,_0x1a7581);}function S_(_0x4cf21e,..._0xc3a239){let _0xe7355e=N(_0x4cf21e);for(const _0x2e67ef of _0xc3a239)_0xe7355e=_0x2e67ef['_apply'](_0xe7355e);return _0xe7355e;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x3e406f,_0xe10544,_0x472e18,_0x2a09fa){const _0x526ac6=_0xe10544['lastIndexOf'](':'),_0x35aec4=_0xe10544['substring'](0x0,_0x526ac6),_0x2c7d03=at(_0x35aec4);_0x3e406f['repoInfo_']=new yo(_0xe10544,_0x2c7d03,_0x3e406f['repoInfo_']['namespace'],_0x3e406f['repoInfo_']['webSocketOnly'],_0x3e406f['repoInfo_']['nodeAdmin'],_0x3e406f['repoInfo_']['persistenceKey'],_0x3e406f['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x472e18),_0x2a09fa&&(_0x3e406f['authTokenProvider_']=_0x2a09fa);}function Kd(_0x4485d0,_0x47d88a,_0xb205f6,_0x451252,_0x569899){let _0x27d71e=_0x451252||_0x4485d0['options']['databaseURL'];_0x27d71e===void 0x0&&(_0x4485d0['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x4485d0['options']['projectId']),_0x27d71e=_0x4485d0['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x2847e4=vr(_0x27d71e,_0x569899),_0x5d8c19=_0x2847e4['repoInfo'],_0x4fb21e;typeof process<'u'&&Vs&&(_0x4fb21e=Vs[qd]),_0x4fb21e?(_0x27d71e='http://'+_0x4fb21e+'?ns='+_0x5d8c19['namespace'],_0x2847e4=vr(_0x27d71e,_0x569899),_0x5d8c19=_0x2847e4['repoInfo']):_0x2847e4['repoInfo']['secure'];const _0x32fbdc=new eh(_0x4485d0['name'],_0x4485d0['options'],_0x47d88a);_d('Invalid\x20Firebase\x20Database\x20URL',_0x2847e4),v(_0x2847e4['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x3d7c3a=Qd(_0x5d8c19,_0x4485d0,_0x32fbdc,new Zl(_0x4485d0,_0xb205f6));return new Jd(_0x3d7c3a,_0x4485d0);}function Yd(_0x423fd6,_0x205c92){const _0x4ccb9e=Ni[_0x205c92];(!_0x4ccb9e||_0x4ccb9e[_0x423fd6['key']]!==_0x423fd6)&&ae('Database\x20'+_0x205c92+'('+_0x423fd6['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x423fd6),delete _0x4ccb9e[_0x423fd6['key']];}function Qd(_0x545837,_0x113641,_0x51be64,_0x14fcdb){let _0x27cbae=Ni[_0x113641['name']];_0x27cbae||(_0x27cbae={},Ni[_0x113641['name']]=_0x27cbae);let _0x3c3676=_0x27cbae[_0x545837['toURLString']()];return _0x3c3676&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x3c3676=new vd(_0x545837,zd,_0x51be64,_0x14fcdb),_0x27cbae[_0x545837['toURLString']()]=_0x3c3676,_0x3c3676;}class Jd{constructor(_0x5c999f,_0x526593){this['_repoInternal']=_0x5c999f,this['app']=_0x526593,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x217da1){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x217da1+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x5c017c=Zr(),_0x214d75){const _0x597ebb=Bi(_0x5c017c,'database')['getImmediate']({'identifier':_0x214d75});if(!_0x597ebb['_instanceStarted']){const _0x539c93=cc('database');_0x539c93&&Xd(_0x597ebb,..._0x539c93);}return _0x597ebb;}function Xd(_0x40166f,_0x765272,_0x3304f1,_0x420e87={}){_0x40166f=N(_0x40166f),_0x40166f['_checkNotDeleted']('useEmulator');const _0x1cdf64=_0x765272+':'+_0x3304f1,_0xcf7fb3=_0x40166f['_repoInternal'];if(_0x40166f['_instanceStarted']){if(_0x1cdf64===_0x40166f['_repoInternal']['repoInfo_']['host']&&Me(_0x420e87,_0xcf7fb3['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x1ada5c;if(_0xcf7fb3['repoInfo_']['nodeAdmin'])_0x420e87['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x1ada5c=new nn(nn['OWNER']);else{if(_0x420e87['mockUserToken']){const _0x1cbafa=typeof _0x420e87['mockUserToken']=='string'?_0x420e87['mockUserToken']:lc(_0x420e87['mockUserToken'],_0x40166f['app']['options']['projectId']);_0x1ada5c=new nn(_0x1cbafa);}}at(_0x765272)&&(jr(_0x765272),Kr('Database',!0x0)),jd(_0xcf7fb3,_0x1cdf64,_0x420e87,_0x1ada5c);}function R_(_0x38a877){_0x38a877=N(_0x38a877),_0x38a877['_checkNotDeleted']('goOffline'),ha(_0x38a877['_repo']);}function A_(_0x3e8658){_0x3e8658=N(_0x3e8658),_0x3e8658['_checkNotDeleted']('goOnline'),Ad(_0x3e8658['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x4eaaa1){Ul(lt),Ze(new Le('database',(_0x2a6bfe,{instanceIdentifier:_0xee5b1a})=>{const _0x5e816c=_0x2a6bfe['getProvider']('app')['getImmediate'](),_0x21a54f=_0x2a6bfe['getProvider']('auth-internal'),_0x412c85=_0x2a6bfe['getProvider']('app-check-internal');return Kd(_0x5e816c,_0x21a54f,_0x412c85,_0xee5b1a);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x4eaaa1),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x10df0a,_0x33e7d3){this['committed']=_0x10df0a,this['snapshot']=_0x33e7d3;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x5cf6c2,_0x1140c9,_0x3dc375){if(_0x5cf6c2=N(_0x5cf6c2),ys('Reference.transaction',_0x5cf6c2['_path']),_0x5cf6c2['key']==='.length'||_0x5cf6c2['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x5cf6c2['key']+'\x20is\x20a\x20read-only\x20object.';const _0x5abc77=!0x0,_0x4be0c5=new ot(),_0x31d12a=(_0xc26051,_0x1c25a8,_0x5ad561)=>{let _0x5133df=null;_0xc26051?_0x4be0c5['reject'](_0xc26051):(_0x5133df=new st(_0x5ad561,new ee(_0x5cf6c2['_repo'],_0x5cf6c2['_path']),R),_0x4be0c5['resolve'](new tf(_0x1c25a8,_0x5133df)));},_0x31a374=Bd(_0x5cf6c2,()=>{});return kd(_0x5cf6c2['_repo'],_0x5cf6c2['_path'],_0x1140c9,_0x31d12a,_0x31a374,_0x5abc77),_0x4be0c5['promise'];}se['prototype']['simpleListen']=function(_0x520798,_0x3258cd){this['sendRequest']('q',{'p':_0x520798},_0x3258cd);},se['prototype']['echo']=function(_0x3032bd,_0x1c990d){this['sendRequest']('echo',{'d':_0x3032bd},_0x1c990d);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x39ab1c,..._0x4c0adb){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x39ab1c,..._0x4c0adb);}function sn(_0x186e3f,..._0x53eb20){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x186e3f,..._0x53eb20);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x2fe0eb,..._0xc8b4d4){throw ws(_0x2fe0eb,..._0xc8b4d4);}function X(_0x3675bb,..._0xd89355){return ws(_0x3675bb,..._0xd89355);}function Ia(_0x138fc3,_0x34c538,_0x4cbf49){const _0x2a4d4e={...nf(),[_0x34c538]:_0x4cbf49};return new Bt('auth','Firebase',_0x2a4d4e)['create'](_0x34c538,{'appName':_0x138fc3['name']});}function re(_0x4ef5f6){return Ia(_0x4ef5f6,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x586862,..._0x3399ed){if(typeof _0x586862!='string'){const _0x2430d2=_0x3399ed[0x0],_0x4b2940=[..._0x3399ed['slice'](0x1)];return _0x4b2940[0x0]&&(_0x4b2940[0x0]['appName']=_0x586862['name']),_0x586862['_errorFactory']['create'](_0x2430d2,..._0x4b2940);}return Ea['create'](_0x586862,..._0x3399ed);}function m(_0xbea630,_0x4a0256,..._0x449fef){if(!_0xbea630)throw ws(_0x4a0256,..._0x449fef);}function ne(_0x42f57c){const _0xffea3b='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x42f57c;throw sn(_0xffea3b),new Error(_0xffea3b);}function ce(_0x17ccc5,_0x1a55c8){_0x17ccc5||ne(_0x1a55c8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x45ec7c;return typeof self<'u'&&((_0x45ec7c=self['location'])==null?void 0x0:_0x45ec7c['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0xaaf99d;return typeof self<'u'&&((_0xaaf99d=self['location'])==null?void 0x0:_0xaaf99d['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x5dded8=navigator;return _0x5dded8['languages']&&_0x5dded8['languages'][0x0]||_0x5dded8['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x5deb50,_0x5781c2){this['shortDelay']=_0x5deb50,this['longDelay']=_0x5781c2,ce(_0x5781c2>_0x5deb50,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x2f1661,_0x22ab7a){ce(_0x2f1661['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x4bc3f3}=_0x2f1661['emulator'];return _0x22ab7a?''+_0x4bc3f3+(_0x22ab7a['startsWith']('/')?_0x22ab7a['slice'](0x1):_0x22ab7a):_0x4bc3f3;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0xe2eb8b,_0xc59137,_0x35f08b){this['fetchImpl']=_0xe2eb8b,_0xc59137&&(this['headersImpl']=_0xc59137),_0x35f08b&&(this['responseImpl']=_0x35f08b);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x550600,_0x2a00af){return _0x550600['tenantId']&&!_0x2a00af['tenantId']?{..._0x2a00af,'tenantId':_0x550600['tenantId']}:_0x2a00af;}async function Ae(_0x124bd3,_0x20b05b,_0x1b4007,_0x4841df,_0x165ed7={}){return Ca(_0x124bd3,_0x165ed7,async()=>{let _0xa23c36={},_0x1036f1={};_0x4841df&&(_0x20b05b==='GET'?_0x1036f1=_0x4841df:_0xa23c36={'body':JSON['stringify'](_0x4841df)});const _0x5e2aaf=ct({'key':_0x124bd3['config']['apiKey'],..._0x1036f1})['slice'](0x1),_0x351a19=await _0x124bd3['_getAdditionalHeaders']();_0x351a19['Content-Type']='application/json',_0x124bd3['languageCode']&&(_0x351a19['X-Firebase-Locale']=_0x124bd3['languageCode']);const _0x2fa0b9={'method':_0x20b05b,'headers':_0x351a19,..._0xa23c36};return dc()||(_0x2fa0b9['referrerPolicy']='no-referrer'),_0x124bd3['emulatorConfig']&&at(_0x124bd3['emulatorConfig']['host'])&&(_0x2fa0b9['credentials']='include'),wa['fetch']()(await Ta(_0x124bd3,_0x124bd3['config']['apiHost'],_0x1b4007,_0x5e2aaf),_0x2fa0b9);});}async function Ca(_0x252d27,_0x388221,_0x1c1438){_0x252d27['_canInitEmulator']=!0x1;const _0x2ba34d={...cf,..._0x388221};try{const _0x42e2c5=new df(_0x252d27),_0x3d4d6c=await Promise['race']([_0x1c1438(),_0x42e2c5['promise']]);_0x42e2c5['clearNetworkTimeout']();const _0x2d57bf=await _0x3d4d6c['json']();if('needConfirmation'in _0x2d57bf)throw tn(_0x252d27,'account-exists-with-different-credential',_0x2d57bf);if(_0x3d4d6c['ok']&&!('errorMessage'in _0x2d57bf))return _0x2d57bf;{const _0x57a87f=_0x3d4d6c['ok']?_0x2d57bf['errorMessage']:_0x2d57bf['error']['message'],[_0x5485e3,_0x14f53a]=_0x57a87f['split']('\x20:\x20');if(_0x5485e3==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x252d27,'credential-already-in-use',_0x2d57bf);if(_0x5485e3==='EMAIL_EXISTS')throw tn(_0x252d27,'email-already-in-use',_0x2d57bf);if(_0x5485e3==='USER_DISABLED')throw tn(_0x252d27,'user-disabled',_0x2d57bf);const _0x3919a4=_0x2ba34d[_0x5485e3]||_0x5485e3['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x14f53a)throw Ia(_0x252d27,_0x3919a4,_0x14f53a);Q(_0x252d27,_0x3919a4);}}catch(_0x5db75d){if(_0x5db75d instanceof Se)throw _0x5db75d;Q(_0x252d27,'network-request-failed',{'message':String(_0x5db75d)});}}async function Qt(_0x440d87,_0x3ea092,_0x1b3396,_0x430eca,_0x115f49={}){const _0xbaf573=await Ae(_0x440d87,_0x3ea092,_0x1b3396,_0x430eca,_0x115f49);return'mfaPendingCredential'in _0xbaf573&&Q(_0x440d87,'multi-factor-auth-required',{'_serverResponse':_0xbaf573}),_0xbaf573;}async function Ta(_0x5a08b0,_0x3f2726,_0x3b51ba,_0x1055ab){const _0x448090=''+_0x3f2726+_0x3b51ba+'?'+_0x1055ab,_0x409d0c=_0x5a08b0,_0x1fcccf=_0x409d0c['config']['emulator']?Cs(_0x5a08b0['config'],_0x448090):_0x5a08b0['config']['apiScheme']+'://'+_0x448090;return lf['includes'](_0x3b51ba)&&(await _0x409d0c['_persistenceManagerAvailable'],_0x409d0c['_getPersistenceType']()==='COOKIE')?_0x409d0c['_getPersistence']()['_getFinalTarget'](_0x1fcccf)['toString']():_0x1fcccf;}function uf(_0x3af427){switch(_0x3af427){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x26a17e){this['auth']=_0x26a17e,this['timer']=null,this['promise']=new Promise((_0x368d04,_0x51a543)=>{this['timer']=setTimeout(()=>_0x51a543(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x427182,_0x48272c,_0x33df57){const _0x48132d={'appName':_0x427182['name']};_0x33df57['email']&&(_0x48132d['email']=_0x33df57['email']),_0x33df57['phoneNumber']&&(_0x48132d['phoneNumber']=_0x33df57['phoneNumber']);const _0x563cca=X(_0x427182,_0x48272c,_0x48132d);return _0x563cca['customData']['_tokenResponse']=_0x33df57,_0x563cca;}function wr(_0x207bcb){return _0x207bcb!==void 0x0&&_0x207bcb['enterprise']!==void 0x0;}class ff{constructor(_0x3518dc){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x3518dc['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x3518dc['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x3518dc['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x5d9bd0){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x5f4b24 of this['recaptchaEnforcementState'])if(_0x5f4b24['provider']&&_0x5f4b24['provider']===_0x5d9bd0)return uf(_0x5f4b24['enforcementState']);return null;}['isProviderEnabled'](_0x313efb){return this['getProviderEnforcementState'](_0x313efb)==='ENFORCE'||this['getProviderEnforcementState'](_0x313efb)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x55a720,_0x3b7b74){return Ae(_0x55a720,'GET','/v2/recaptchaConfig',Re(_0x55a720,_0x3b7b74));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x422a0e,_0xd5f5e6){return Ae(_0x422a0e,'POST','/v1/accounts:delete',_0xd5f5e6);}async function bn(_0x616f15,_0xccfa2b){return Ae(_0x616f15,'POST','/v1/accounts:lookup',_0xccfa2b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x35c03c){if(_0x35c03c)try{const _0x56aa6e=new Date(Number(_0x35c03c));if(!isNaN(_0x56aa6e['getTime']()))return _0x56aa6e['toUTCString']();}catch{}}async function gf(_0x594e7d,_0x637608=!0x1){const _0x784587=N(_0x594e7d),_0x292644=await _0x784587['getIdToken'](_0x637608),_0x1d69ae=Ts(_0x292644);m(_0x1d69ae&&_0x1d69ae['exp']&&_0x1d69ae['auth_time']&&_0x1d69ae['iat'],_0x784587['auth'],'internal-error');const _0x4263fc=typeof _0x1d69ae['firebase']=='object'?_0x1d69ae['firebase']:void 0x0,_0x2dbac5=_0x4263fc==null?void 0x0:_0x4263fc['sign_in_provider'];return{'claims':_0x1d69ae,'token':_0x292644,'authTime':Rt(li(_0x1d69ae['auth_time'])),'issuedAtTime':Rt(li(_0x1d69ae['iat'])),'expirationTime':Rt(li(_0x1d69ae['exp'])),'signInProvider':_0x2dbac5||null,'signInSecondFactor':(_0x4263fc==null?void 0x0:_0x4263fc['sign_in_second_factor'])||null};}function li(_0x2b9d42){return Number(_0x2b9d42)*0x3e8;}function Ts(_0x1055a9){const [_0x341158,_0x15ae68,_0x34f05f]=_0x1055a9['split']('.');if(_0x341158===void 0x0||_0x15ae68===void 0x0||_0x34f05f===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x396959=ln(_0x15ae68);return _0x396959?JSON['parse'](_0x396959):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x1a8f91){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x1a8f91==null?void 0x0:_0x1a8f91['toString']()),null;}}function Cr(_0x28e3ad){const _0x33fec1=Ts(_0x28e3ad);return m(_0x33fec1,'internal-error'),m(typeof _0x33fec1['exp']<'u','internal-error'),m(typeof _0x33fec1['iat']<'u','internal-error'),Number(_0x33fec1['exp'])-Number(_0x33fec1['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x29a931,_0x220919,_0x727fdb=!0x1){if(_0x727fdb)return _0x220919;try{return await _0x220919;}catch(_0x2d9a0a){throw _0x2d9a0a instanceof Se&&mf(_0x2d9a0a)&&_0x29a931['auth']['currentUser']===_0x29a931&&await _0x29a931['auth']['signOut'](),_0x2d9a0a;}}function mf({code:_0x1bebaf}){return _0x1bebaf==='auth/user-disabled'||_0x1bebaf==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x1caf5e){this['user']=_0x1caf5e,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x56ce4b){if(_0x56ce4b){const _0x274772=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x274772;}else{this['errorBackoff']=0x7530;const _0x33c4df=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x33c4df);}}['schedule'](_0x2231e6=!0x1){if(!this['isRunning'])return;const _0x40e2ea=this['getInterval'](_0x2231e6);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x40e2ea);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0xac9644){(_0xac9644==null?void 0x0:_0xac9644['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x4c8e65,_0x4e3bc2){this['createdAt']=_0x4c8e65,this['lastLoginAt']=_0x4e3bc2,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x1907d7){this['createdAt']=_0x1907d7['createdAt'],this['lastLoginAt']=_0x1907d7['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x4da49c){var _0x25de19;const _0xc03fb0=_0x4da49c['auth'],_0x278a7e=await _0x4da49c['getIdToken'](),_0x4db553=await Ut(_0x4da49c,bn(_0xc03fb0,{'idToken':_0x278a7e}));m(_0x4db553==null?void 0x0:_0x4db553['users']['length'],_0xc03fb0,'internal-error');const _0x3352db=_0x4db553['users'][0x0];_0x4da49c['_notifyReloadListener'](_0x3352db);const _0x41e6d5=(_0x25de19=_0x3352db['providerUserInfo'])!=null&&_0x25de19['length']?Sa(_0x3352db['providerUserInfo']):[],_0x3caf33=Ef(_0x4da49c['providerData'],_0x41e6d5),_0x31c87f=_0x4da49c['isAnonymous'],_0x26399a=!(_0x4da49c['email']&&_0x3352db['passwordHash'])&&!(_0x3caf33!=null&&_0x3caf33['length']),_0x44f92d=_0x31c87f?_0x26399a:!0x1,_0x3071c7={'uid':_0x3352db['localId'],'displayName':_0x3352db['displayName']||null,'photoURL':_0x3352db['photoUrl']||null,'email':_0x3352db['email']||null,'emailVerified':_0x3352db['emailVerified']||!0x1,'phoneNumber':_0x3352db['phoneNumber']||null,'tenantId':_0x3352db['tenantId']||null,'providerData':_0x3caf33,'metadata':new Oi(_0x3352db['createdAt'],_0x3352db['lastLoginAt']),'isAnonymous':_0x44f92d};Object['assign'](_0x4da49c,_0x3071c7);}async function vf(_0x18dca6){const _0x1dcc54=N(_0x18dca6);await Rn(_0x1dcc54),await _0x1dcc54['auth']['_persistUserIfCurrent'](_0x1dcc54),_0x1dcc54['auth']['_notifyListenersIfCurrent'](_0x1dcc54);}function Ef(_0x1cbae6,_0x145522){return[..._0x1cbae6['filter'](_0x28eec5=>!_0x145522['some'](_0x1b9407=>_0x1b9407['providerId']===_0x28eec5['providerId'])),..._0x145522];}function Sa(_0x4c8519){return _0x4c8519['map'](({providerId:_0x2e57bb,..._0x46c6cd})=>({'providerId':_0x2e57bb,'uid':_0x46c6cd['rawId']||'','displayName':_0x46c6cd['displayName']||null,'email':_0x46c6cd['email']||null,'phoneNumber':_0x46c6cd['phoneNumber']||null,'photoURL':_0x46c6cd['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0xaa2e9a,_0xb670b2){const _0x399b38=await Ca(_0xaa2e9a,{},async()=>{const _0x3baeb6=ct({'grant_type':'refresh_token','refresh_token':_0xb670b2})['slice'](0x1),{tokenApiHost:_0x3a8a61,apiKey:_0xa3d4d4}=_0xaa2e9a['config'],_0x5a455a=await Ta(_0xaa2e9a,_0x3a8a61,'/v1/token','key='+_0xa3d4d4),_0x338d6d=await _0xaa2e9a['_getAdditionalHeaders']();_0x338d6d['Content-Type']='application/x-www-form-urlencoded';const _0x389ead={'method':'POST','headers':_0x338d6d,'body':_0x3baeb6};return _0xaa2e9a['emulatorConfig']&&at(_0xaa2e9a['emulatorConfig']['host'])&&(_0x389ead['credentials']='include'),wa['fetch']()(_0x5a455a,_0x389ead);});return{'accessToken':_0x399b38['access_token'],'expiresIn':_0x399b38['expires_in'],'refreshToken':_0x399b38['refresh_token']};}async function wf(_0x4ffa0d,_0x49137f){return Ae(_0x4ffa0d,'POST','/v2/accounts:revokeToken',Re(_0x4ffa0d,_0x49137f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0xe41dd3){m(_0xe41dd3['idToken'],'internal-error'),m(typeof _0xe41dd3['idToken']<'u','internal-error'),m(typeof _0xe41dd3['refreshToken']<'u','internal-error');const _0x552321='expiresIn'in _0xe41dd3&&typeof _0xe41dd3['expiresIn']<'u'?Number(_0xe41dd3['expiresIn']):Cr(_0xe41dd3['idToken']);this['updateTokensAndExpiration'](_0xe41dd3['idToken'],_0xe41dd3['refreshToken'],_0x552321);}['updateFromIdToken'](_0x50c607){m(_0x50c607['length']!==0x0,'internal-error');const _0x1d8ce4=Cr(_0x50c607);this['updateTokensAndExpiration'](_0x50c607,null,_0x1d8ce4);}async['getToken'](_0x4df05f,_0x518423=!0x1){return!_0x518423&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x4df05f,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x4df05f,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x438909,_0x1f0013){const {accessToken:_0x402e4d,refreshToken:_0x47831e,expiresIn:_0x1d8872}=await If(_0x438909,_0x1f0013);this['updateTokensAndExpiration'](_0x402e4d,_0x47831e,Number(_0x1d8872));}['updateTokensAndExpiration'](_0x2dbb2a,_0x42ad28,_0x24957a){this['refreshToken']=_0x42ad28||null,this['accessToken']=_0x2dbb2a||null,this['expirationTime']=Date['now']()+_0x24957a*0x3e8;}static['fromJSON'](_0x1565c8,_0x3f3c19){const {refreshToken:_0x583fad,accessToken:_0x425c1d,expirationTime:_0x5430f5}=_0x3f3c19,_0x3d70f0=new Qe();return _0x583fad&&(m(typeof _0x583fad=='string','internal-error',{'appName':_0x1565c8}),_0x3d70f0['refreshToken']=_0x583fad),_0x425c1d&&(m(typeof _0x425c1d=='string','internal-error',{'appName':_0x1565c8}),_0x3d70f0['accessToken']=_0x425c1d),_0x5430f5&&(m(typeof _0x5430f5=='number','internal-error',{'appName':_0x1565c8}),_0x3d70f0['expirationTime']=_0x5430f5),_0x3d70f0;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x1f2378){this['accessToken']=_0x1f2378['accessToken'],this['refreshToken']=_0x1f2378['refreshToken'],this['expirationTime']=_0x1f2378['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x10bfa4,_0x1ad18d){m(typeof _0x10bfa4=='string'||typeof _0x10bfa4>'u','internal-error',{'appName':_0x1ad18d});}class K{constructor({uid:_0x3771f5,auth:_0x3abeb3,stsTokenManager:_0x1d7e7d,..._0x4dbec7}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x3771f5,this['auth']=_0x3abeb3,this['stsTokenManager']=_0x1d7e7d,this['accessToken']=_0x1d7e7d['accessToken'],this['displayName']=_0x4dbec7['displayName']||null,this['email']=_0x4dbec7['email']||null,this['emailVerified']=_0x4dbec7['emailVerified']||!0x1,this['phoneNumber']=_0x4dbec7['phoneNumber']||null,this['photoURL']=_0x4dbec7['photoURL']||null,this['isAnonymous']=_0x4dbec7['isAnonymous']||!0x1,this['tenantId']=_0x4dbec7['tenantId']||null,this['providerData']=_0x4dbec7['providerData']?[..._0x4dbec7['providerData']]:[],this['metadata']=new Oi(_0x4dbec7['createdAt']||void 0x0,_0x4dbec7['lastLoginAt']||void 0x0);}async['getIdToken'](_0x3866fe){const _0x276433=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x3866fe));return m(_0x276433,this['auth'],'internal-error'),this['accessToken']!==_0x276433&&(this['accessToken']=_0x276433,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x276433;}['getIdTokenResult'](_0x49534e){return gf(this,_0x49534e);}['reload'](){return vf(this);}['_assign'](_0x1f0e22){this!==_0x1f0e22&&(m(this['uid']===_0x1f0e22['uid'],this['auth'],'internal-error'),this['displayName']=_0x1f0e22['displayName'],this['photoURL']=_0x1f0e22['photoURL'],this['email']=_0x1f0e22['email'],this['emailVerified']=_0x1f0e22['emailVerified'],this['phoneNumber']=_0x1f0e22['phoneNumber'],this['isAnonymous']=_0x1f0e22['isAnonymous'],this['tenantId']=_0x1f0e22['tenantId'],this['providerData']=_0x1f0e22['providerData']['map'](_0x1e951f=>({..._0x1e951f})),this['metadata']['_copy'](_0x1f0e22['metadata']),this['stsTokenManager']['_assign'](_0x1f0e22['stsTokenManager']));}['_clone'](_0x16ef19){const _0x1f503c=new K({...this,'auth':_0x16ef19,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x1f503c['metadata']['_copy'](this['metadata']),_0x1f503c;}['_onReload'](_0x4b1941){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x4b1941,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x1c502e){this['reloadListener']?this['reloadListener'](_0x1c502e):this['reloadUserInfo']=_0x1c502e;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x3eb223,_0x2cad10=!0x1){let _0xe49d3=!0x1;_0x3eb223['idToken']&&_0x3eb223['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x3eb223),_0xe49d3=!0x0),_0x2cad10&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0xe49d3&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x4fd4d5=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x4fd4d5})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x59b7ea=>({..._0x59b7ea})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x37db06,_0x1aa2a0){const _0x1d9789=_0x1aa2a0['displayName']??void 0x0,_0x1ec091=_0x1aa2a0['email']??void 0x0,_0x5e7931=_0x1aa2a0['phoneNumber']??void 0x0,_0x23b437=_0x1aa2a0['photoURL']??void 0x0,_0x36cd88=_0x1aa2a0['tenantId']??void 0x0,_0x295f11=_0x1aa2a0['_redirectEventId']??void 0x0,_0x230779=_0x1aa2a0['createdAt']??void 0x0,_0x37f689=_0x1aa2a0['lastLoginAt']??void 0x0,{uid:_0x963725,emailVerified:_0x2d5d4d,isAnonymous:_0x20f207,providerData:_0x4907c0,stsTokenManager:_0x1d79f0}=_0x1aa2a0;m(_0x963725&&_0x1d79f0,_0x37db06,'internal-error');const _0x10a857=Qe['fromJSON'](this['name'],_0x1d79f0);m(typeof _0x963725=='string',_0x37db06,'internal-error'),le(_0x1d9789,_0x37db06['name']),le(_0x1ec091,_0x37db06['name']),m(typeof _0x2d5d4d=='boolean',_0x37db06,'internal-error'),m(typeof _0x20f207=='boolean',_0x37db06,'internal-error'),le(_0x5e7931,_0x37db06['name']),le(_0x23b437,_0x37db06['name']),le(_0x36cd88,_0x37db06['name']),le(_0x295f11,_0x37db06['name']),le(_0x230779,_0x37db06['name']),le(_0x37f689,_0x37db06['name']);const _0x56bc5c=new K({'uid':_0x963725,'auth':_0x37db06,'email':_0x1ec091,'emailVerified':_0x2d5d4d,'displayName':_0x1d9789,'isAnonymous':_0x20f207,'photoURL':_0x23b437,'phoneNumber':_0x5e7931,'tenantId':_0x36cd88,'stsTokenManager':_0x10a857,'createdAt':_0x230779,'lastLoginAt':_0x37f689});return _0x4907c0&&Array['isArray'](_0x4907c0)&&(_0x56bc5c['providerData']=_0x4907c0['map'](_0x2e9897=>({..._0x2e9897}))),_0x295f11&&(_0x56bc5c['_redirectEventId']=_0x295f11),_0x56bc5c;}static async['_fromIdTokenResponse'](_0x3f7d7b,_0x5e8779,_0x67c534=!0x1){const _0x3f71d3=new Qe();_0x3f71d3['updateFromServerResponse'](_0x5e8779);const _0x56880b=new K({'uid':_0x5e8779['localId'],'auth':_0x3f7d7b,'stsTokenManager':_0x3f71d3,'isAnonymous':_0x67c534});return await Rn(_0x56880b),_0x56880b;}static async['_fromGetAccountInfoResponse'](_0x1c565d,_0x1bdd49,_0x17756e){const _0x5c4145=_0x1bdd49['users'][0x0];m(_0x5c4145['localId']!==void 0x0,'internal-error');const _0x1a2abc=_0x5c4145['providerUserInfo']!==void 0x0?Sa(_0x5c4145['providerUserInfo']):[],_0x41a82b=!(_0x5c4145['email']&&_0x5c4145['passwordHash'])&&!(_0x1a2abc!=null&&_0x1a2abc['length']),_0x633c1d=new Qe();_0x633c1d['updateFromIdToken'](_0x17756e);const _0x5e3437=new K({'uid':_0x5c4145['localId'],'auth':_0x1c565d,'stsTokenManager':_0x633c1d,'isAnonymous':_0x41a82b}),_0x50076e={'uid':_0x5c4145['localId'],'displayName':_0x5c4145['displayName']||null,'photoURL':_0x5c4145['photoUrl']||null,'email':_0x5c4145['email']||null,'emailVerified':_0x5c4145['emailVerified']||!0x1,'phoneNumber':_0x5c4145['phoneNumber']||null,'tenantId':_0x5c4145['tenantId']||null,'providerData':_0x1a2abc,'metadata':new Oi(_0x5c4145['createdAt'],_0x5c4145['lastLoginAt']),'isAnonymous':!(_0x5c4145['email']&&_0x5c4145['passwordHash'])&&!(_0x1a2abc!=null&&_0x1a2abc['length'])};return Object['assign'](_0x5e3437,_0x50076e),_0x5e3437;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x3e5be2){ce(_0x3e5be2 instanceof Function,'Expected\x20a\x20class\x20definition');let _0xcdeef0=Tr['get'](_0x3e5be2);return _0xcdeef0?(ce(_0xcdeef0 instanceof _0x3e5be2,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0xcdeef0):(_0xcdeef0=new _0x3e5be2(),Tr['set'](_0x3e5be2,_0xcdeef0),_0xcdeef0);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x5bce5c,_0x30ee82){this['storage'][_0x5bce5c]=_0x30ee82;}async['_get'](_0x51d1f0){const _0x3a9b53=this['storage'][_0x51d1f0];return _0x3a9b53===void 0x0?null:_0x3a9b53;}async['_remove'](_0x57987d){delete this['storage'][_0x57987d];}['_addListener'](_0x38f701,_0x5b3bdd){}['_removeListener'](_0x2eb6f8,_0x31c70c){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0xba03b5,_0x8c739a,_0x2b1fc2){return'firebase:'+_0xba03b5+':'+_0x8c739a+':'+_0x2b1fc2;}class Je{constructor(_0x371d6c,_0x244d0a,_0x427f1c){this['persistence']=_0x371d6c,this['auth']=_0x244d0a,this['userKey']=_0x427f1c;const {config:_0x201ab8,name:_0x39f483}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x201ab8['apiKey'],_0x39f483),this['fullPersistenceKey']=rn('persistence',_0x201ab8['apiKey'],_0x39f483),this['boundEventHandler']=_0x244d0a['_onStorageEvent']['bind'](_0x244d0a),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x44a6aa){return this['persistence']['_set'](this['fullUserKey'],_0x44a6aa['toJSON']());}async['getCurrentUser'](){const _0x5e73f9=await this['persistence']['_get'](this['fullUserKey']);if(!_0x5e73f9)return null;if(typeof _0x5e73f9=='string'){const _0x2732ef=await bn(this['auth'],{'idToken':_0x5e73f9})['catch'](()=>{});return _0x2732ef?K['_fromGetAccountInfoResponse'](this['auth'],_0x2732ef,_0x5e73f9):null;}return K['_fromJSON'](this['auth'],_0x5e73f9);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x34e68d){if(this['persistence']===_0x34e68d)return;const _0x15191d=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x34e68d,_0x15191d)return this['setCurrentUser'](_0x15191d);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x2ce625,_0x452a6e,_0xe83131='authUser'){if(!_0x452a6e['length'])return new Je(ie(Sr),_0x2ce625,_0xe83131);const _0x2ca4eb=(await Promise['all'](_0x452a6e['map'](async _0x5ce79d=>{if(await _0x5ce79d['_isAvailable']())return _0x5ce79d;})))['filter'](_0x398e97=>_0x398e97);let _0x4ce050=_0x2ca4eb[0x0]||ie(Sr);const _0x46ecc0=rn(_0xe83131,_0x2ce625['config']['apiKey'],_0x2ce625['name']);let _0x47ff2d=null;for(const _0x114cc5 of _0x452a6e)try{const _0x1c8c43=await _0x114cc5['_get'](_0x46ecc0);if(_0x1c8c43){let _0x80d266;if(typeof _0x1c8c43=='string'){const _0x39346e=await bn(_0x2ce625,{'idToken':_0x1c8c43})['catch'](()=>{});if(!_0x39346e)break;_0x80d266=await K['_fromGetAccountInfoResponse'](_0x2ce625,_0x39346e,_0x1c8c43);}else _0x80d266=K['_fromJSON'](_0x2ce625,_0x1c8c43);_0x114cc5!==_0x4ce050&&(_0x47ff2d=_0x80d266),_0x4ce050=_0x114cc5;break;}}catch{}const _0x322525=_0x2ca4eb['filter'](_0x4169b7=>_0x4169b7['_shouldAllowMigration']);return!_0x4ce050['_shouldAllowMigration']||!_0x322525['length']?new Je(_0x4ce050,_0x2ce625,_0xe83131):(_0x4ce050=_0x322525[0x0],_0x47ff2d&&await _0x4ce050['_set'](_0x46ecc0,_0x47ff2d['toJSON']()),await Promise['all'](_0x452a6e['map'](async _0x497bd2=>{if(_0x497bd2!==_0x4ce050)try{await _0x497bd2['_remove'](_0x46ecc0);}catch{}})),new Je(_0x4ce050,_0x2ce625,_0xe83131));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x27edf7){const _0x33852b=_0x27edf7['toLowerCase']();if(_0x33852b['includes']('opera/')||_0x33852b['includes']('opr/')||_0x33852b['includes']('opios/'))return'Opera';if(Na(_0x33852b))return'IEMobile';if(_0x33852b['includes']('msie')||_0x33852b['includes']('trident/'))return'IE';if(_0x33852b['includes']('edge/'))return'Edge';if(Ra(_0x33852b))return'Firefox';if(_0x33852b['includes']('silk/'))return'Silk';if(Oa(_0x33852b))return'Blackberry';if(Da(_0x33852b))return'Webos';if(Aa(_0x33852b))return'Safari';if((_0x33852b['includes']('chrome/')||ka(_0x33852b))&&!_0x33852b['includes']('edge/'))return'Chrome';if(Pa(_0x33852b))return'Android';{const _0x4020c6=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0xe65bf3=_0x27edf7['match'](_0x4020c6);if((_0xe65bf3==null?void 0x0:_0xe65bf3['length'])===0x2)return _0xe65bf3[0x1];}return'Other';}function Ra(_0x3f0b18=W()){return/firefox\//i['test'](_0x3f0b18);}function Aa(_0x7d63d8=W()){const _0x67bc95=_0x7d63d8['toLowerCase']();return _0x67bc95['includes']('safari/')&&!_0x67bc95['includes']('chrome/')&&!_0x67bc95['includes']('crios/')&&!_0x67bc95['includes']('android');}function ka(_0x51e340=W()){return/crios\//i['test'](_0x51e340);}function Na(_0x24cc22=W()){return/iemobile/i['test'](_0x24cc22);}function Pa(_0x51b409=W()){return/android/i['test'](_0x51b409);}function Oa(_0x476d17=W()){return/blackberry/i['test'](_0x476d17);}function Da(_0x26922d=W()){return/webos/i['test'](_0x26922d);}function Ss(_0x2b9288=W()){return/iphone|ipad|ipod/i['test'](_0x2b9288)||/macintosh/i['test'](_0x2b9288)&&/mobile/i['test'](_0x2b9288);}function Cf(_0x1c03ad=W()){var _0x3176d2;return Ss(_0x1c03ad)&&!!((_0x3176d2=window['navigator'])!=null&&_0x3176d2['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x393dcb=W()){return Ss(_0x393dcb)||Pa(_0x393dcb)||Da(_0x393dcb)||Oa(_0x393dcb)||/windows phone/i['test'](_0x393dcb)||Na(_0x393dcb);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x2873fd,_0x56e023=[]){let _0x25b4e1;switch(_0x2873fd){case'Browser':_0x25b4e1=br(W());break;case'Worker':_0x25b4e1=br(W())+'-'+_0x2873fd;break;default:_0x25b4e1=_0x2873fd;}const _0x52548d=_0x56e023['length']?_0x56e023['join'](','):'FirebaseCore-web';return _0x25b4e1+'/JsCore/'+lt+'/'+_0x52548d;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x5eda41){this['auth']=_0x5eda41,this['queue']=[];}['pushCallback'](_0x7fc295,_0x3a4aa3){const _0x2d02f5=_0x528800=>new Promise((_0x238b6e,_0x5159ee)=>{try{const _0x1c4e27=_0x7fc295(_0x528800);_0x238b6e(_0x1c4e27);}catch(_0x5c16cf){_0x5159ee(_0x5c16cf);}});_0x2d02f5['onAbort']=_0x3a4aa3,this['queue']['push'](_0x2d02f5);const _0x4ef871=this['queue']['length']-0x1;return()=>{this['queue'][_0x4ef871]=()=>Promise['resolve']();};}async['runMiddleware'](_0x5c7da8){if(this['auth']['currentUser']===_0x5c7da8)return;const _0x420103=[];try{for(const _0x59ed24 of this['queue'])await _0x59ed24(_0x5c7da8),_0x59ed24['onAbort']&&_0x420103['push'](_0x59ed24['onAbort']);}catch(_0x252f16){_0x420103['reverse']();for(const _0x25a723 of _0x420103)try{_0x25a723();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x252f16==null?void 0x0:_0x252f16['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x17bca5,_0x30a198={}){return Ae(_0x17bca5,'GET','/v2/passwordPolicy',Re(_0x17bca5,_0x30a198));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x4003e2){var _0x37ff87;const _0x36227d=_0x4003e2['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x36227d['minPasswordLength']??Rf,_0x36227d['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x36227d['maxPasswordLength']),_0x36227d['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x36227d['containsLowercaseCharacter']),_0x36227d['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x36227d['containsUppercaseCharacter']),_0x36227d['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x36227d['containsNumericCharacter']),_0x36227d['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x36227d['containsNonAlphanumericCharacter']),this['enforcementState']=_0x4003e2['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x37ff87=_0x4003e2['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x37ff87['join'](''))??'',this['forceUpgradeOnSignin']=_0x4003e2['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x4003e2['schemaVersion'];}['validatePassword'](_0x579e26){const _0x1da6f2={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x579e26,_0x1da6f2),this['validatePasswordCharacterOptions'](_0x579e26,_0x1da6f2),_0x1da6f2['isValid']&&(_0x1da6f2['isValid']=_0x1da6f2['meetsMinPasswordLength']??!0x0),_0x1da6f2['isValid']&&(_0x1da6f2['isValid']=_0x1da6f2['meetsMaxPasswordLength']??!0x0),_0x1da6f2['isValid']&&(_0x1da6f2['isValid']=_0x1da6f2['containsLowercaseLetter']??!0x0),_0x1da6f2['isValid']&&(_0x1da6f2['isValid']=_0x1da6f2['containsUppercaseLetter']??!0x0),_0x1da6f2['isValid']&&(_0x1da6f2['isValid']=_0x1da6f2['containsNumericCharacter']??!0x0),_0x1da6f2['isValid']&&(_0x1da6f2['isValid']=_0x1da6f2['containsNonAlphanumericCharacter']??!0x0),_0x1da6f2;}['validatePasswordLengthOptions'](_0x410964,_0x33f197){const _0xe0c1a4=this['customStrengthOptions']['minPasswordLength'],_0x2f3356=this['customStrengthOptions']['maxPasswordLength'];_0xe0c1a4&&(_0x33f197['meetsMinPasswordLength']=_0x410964['length']>=_0xe0c1a4),_0x2f3356&&(_0x33f197['meetsMaxPasswordLength']=_0x410964['length']<=_0x2f3356);}['validatePasswordCharacterOptions'](_0x579775,_0x400429){this['updatePasswordCharacterOptionsStatuses'](_0x400429,!0x1,!0x1,!0x1,!0x1);let _0x1abcf7;for(let _0x4aedd7=0x0;_0x4aedd7<_0x579775['length'];_0x4aedd7++)_0x1abcf7=_0x579775['charAt'](_0x4aedd7),this['updatePasswordCharacterOptionsStatuses'](_0x400429,_0x1abcf7>='a'&&_0x1abcf7<='z',_0x1abcf7>='A'&&_0x1abcf7<='Z',_0x1abcf7>='0'&&_0x1abcf7<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x1abcf7));}['updatePasswordCharacterOptionsStatuses'](_0x33223c,_0x1345b3,_0xe15c2a,_0x5913ff,_0x24e632){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x33223c['containsLowercaseLetter']||(_0x33223c['containsLowercaseLetter']=_0x1345b3)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x33223c['containsUppercaseLetter']||(_0x33223c['containsUppercaseLetter']=_0xe15c2a)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x33223c['containsNumericCharacter']||(_0x33223c['containsNumericCharacter']=_0x5913ff)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x33223c['containsNonAlphanumericCharacter']||(_0x33223c['containsNonAlphanumericCharacter']=_0x24e632));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x56d255,_0x613ccd,_0x803df0,_0x2a2ae7){this['app']=_0x56d255,this['heartbeatServiceProvider']=_0x613ccd,this['appCheckServiceProvider']=_0x803df0,this['config']=_0x2a2ae7,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x56d255['name'],this['clientVersion']=_0x2a2ae7['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x473546=>this['_resolvePersistenceManagerAvailable']=_0x473546);}['_initializeWithPersistence'](_0x6871e6,_0x29c0e2){return _0x29c0e2&&(this['_popupRedirectResolver']=ie(_0x29c0e2)),this['_initializationPromise']=this['queue'](async()=>{var _0x1a051b,_0x56fd53,_0x15d8fc;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x6871e6),(_0x1a051b=this['_resolvePersistenceManagerAvailable'])==null||_0x1a051b['call'](this),!this['_deleted'])){if((_0x56fd53=this['_popupRedirectResolver'])!=null&&_0x56fd53['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x29c0e2),this['lastNotifiedUid']=((_0x15d8fc=this['currentUser'])==null?void 0x0:_0x15d8fc['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x4aa224=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x4aa224)){if(this['currentUser']&&_0x4aa224&&this['currentUser']['uid']===_0x4aa224['uid']){this['_currentUser']['_assign'](_0x4aa224),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x4aa224,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x5744f4){try{const _0x8a5ca6=await bn(this,{'idToken':_0x5744f4}),_0x4605d6=await K['_fromGetAccountInfoResponse'](this,_0x8a5ca6,_0x5744f4);await this['directlySetCurrentUser'](_0x4605d6);}catch(_0x31d307){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x31d307),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x3bb3bc){var _0x3a2cf1;if($(this['app'])){const _0x9fb9f2=this['app']['settings']['authIdToken'];return _0x9fb9f2?new Promise(_0x50781d=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x9fb9f2)['then'](_0x50781d,_0x50781d));}):this['directlySetCurrentUser'](null);}const _0x1f758e=await this['assertedPersistence']['getCurrentUser']();let _0x2c5810=_0x1f758e,_0x14966d=!0x1;if(_0x3bb3bc&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x2a9ead=(_0x3a2cf1=this['redirectUser'])==null?void 0x0:_0x3a2cf1['_redirectEventId'],_0x5668f6=_0x2c5810==null?void 0x0:_0x2c5810['_redirectEventId'],_0x561ebb=await this['tryRedirectSignIn'](_0x3bb3bc);(!_0x2a9ead||_0x2a9ead===_0x5668f6)&&(_0x561ebb!=null&&_0x561ebb['user'])&&(_0x2c5810=_0x561ebb['user'],_0x14966d=!0x0);}if(!_0x2c5810)return this['directlySetCurrentUser'](null);if(!_0x2c5810['_redirectEventId']){if(_0x14966d)try{await this['beforeStateQueue']['runMiddleware'](_0x2c5810);}catch(_0x49c689){_0x2c5810=_0x1f758e,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x49c689));}return _0x2c5810?this['reloadAndSetCurrentUserOrClear'](_0x2c5810):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x2c5810['_redirectEventId']?this['directlySetCurrentUser'](_0x2c5810):this['reloadAndSetCurrentUserOrClear'](_0x2c5810);}async['tryRedirectSignIn'](_0x2dbe01){let _0x4636cd=null;try{_0x4636cd=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x2dbe01,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x4636cd;}async['reloadAndSetCurrentUserOrClear'](_0x4f757c){try{await Rn(_0x4f757c);}catch(_0x773e09){if((_0x773e09==null?void 0x0:_0x773e09['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x4f757c);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x8202e8){if($(this['app']))return Promise['reject'](re(this));const _0x5bf6e3=_0x8202e8?N(_0x8202e8):null;return _0x5bf6e3&&m(_0x5bf6e3['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x5bf6e3&&_0x5bf6e3['_clone'](this));}async['_updateCurrentUser'](_0x42ce95,_0x2bc0a4=!0x1){if(!this['_deleted'])return _0x42ce95&&m(this['tenantId']===_0x42ce95['tenantId'],this,'tenant-id-mismatch'),_0x2bc0a4||await this['beforeStateQueue']['runMiddleware'](_0x42ce95),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x42ce95),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x5e5f0d){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x5e5f0d));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x1666b8){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x3716c7=this['_getPasswordPolicyInternal']();return _0x3716c7['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x3716c7['validatePassword'](_0x1666b8);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x32fdb3=await bf(this),_0x1574e6=new Af(_0x32fdb3);this['tenantId']===null?this['_projectPasswordPolicy']=_0x1574e6:this['_tenantPasswordPolicies'][this['tenantId']]=_0x1574e6;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x2305bc){this['_errorFactory']=new Bt('auth','Firebase',_0x2305bc());}['onAuthStateChanged'](_0x4ba992,_0x12fb68,_0x28fdbd){return this['registerStateListener'](this['authStateSubscription'],_0x4ba992,_0x12fb68,_0x28fdbd);}['beforeAuthStateChanged'](_0x11fd89,_0x27b413){return this['beforeStateQueue']['pushCallback'](_0x11fd89,_0x27b413);}['onIdTokenChanged'](_0x631668,_0x5d82bb,_0x1a2b95){return this['registerStateListener'](this['idTokenSubscription'],_0x631668,_0x5d82bb,_0x1a2b95);}['authStateReady'](){return new Promise((_0x21ec36,_0x4d6ff8)=>{if(this['currentUser'])_0x21ec36();else{const _0x3da88c=this['onAuthStateChanged'](()=>{_0x3da88c(),_0x21ec36();},_0x4d6ff8);}});}async['revokeAccessToken'](_0x26690f){if(this['currentUser']){const _0x2ecf40=await this['currentUser']['getIdToken'](),_0x11783d={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x26690f,'idToken':_0x2ecf40};this['tenantId']!=null&&(_0x11783d['tenantId']=this['tenantId']),await wf(this,_0x11783d);}}['toJSON'](){var _0x3cde09;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x3cde09=this['_currentUser'])==null?void 0x0:_0x3cde09['toJSON']()};}async['_setRedirectUser'](_0x1f8ea1,_0x5b69ee){const _0x3c296b=await this['getOrInitRedirectPersistenceManager'](_0x5b69ee);return _0x1f8ea1===null?_0x3c296b['removeCurrentUser']():_0x3c296b['setCurrentUser'](_0x1f8ea1);}async['getOrInitRedirectPersistenceManager'](_0xe08eff){if(!this['redirectPersistenceManager']){const _0x8b3f5d=_0xe08eff&&ie(_0xe08eff)||this['_popupRedirectResolver'];m(_0x8b3f5d,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x8b3f5d['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x8fab6d){var _0x55ff01,_0x463288;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x55ff01=this['_currentUser'])==null?void 0x0:_0x55ff01['_redirectEventId'])===_0x8fab6d?this['_currentUser']:((_0x463288=this['redirectUser'])==null?void 0x0:_0x463288['_redirectEventId'])===_0x8fab6d?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x39bb78){if(_0x39bb78===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x39bb78));}['_notifyListenersIfCurrent'](_0x3dd386){_0x3dd386===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x311f23;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x2cae74=((_0x311f23=this['currentUser'])==null?void 0x0:_0x311f23['uid'])??null;this['lastNotifiedUid']!==_0x2cae74&&(this['lastNotifiedUid']=_0x2cae74,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x48aa09,_0x3e629a,_0x4145ff,_0x130b21){if(this['_deleted'])return()=>{};const _0x528e60=typeof _0x3e629a=='function'?_0x3e629a:_0x3e629a['next']['bind'](_0x3e629a);let _0x37f968=!0x1;const _0x3f9f0c=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x3f9f0c,this,'internal-error'),_0x3f9f0c['then'](()=>{_0x37f968||_0x528e60(this['currentUser']);}),typeof _0x3e629a=='function'){const _0x799fdd=_0x48aa09['addObserver'](_0x3e629a,_0x4145ff,_0x130b21);return()=>{_0x37f968=!0x0,_0x799fdd();};}else{const _0x5512e2=_0x48aa09['addObserver'](_0x3e629a);return()=>{_0x37f968=!0x0,_0x5512e2();};}}async['directlySetCurrentUser'](_0x59cd9e){this['currentUser']&&this['currentUser']!==_0x59cd9e&&this['_currentUser']['_stopProactiveRefresh'](),_0x59cd9e&&this['isProactiveRefreshEnabled']&&_0x59cd9e['_startProactiveRefresh'](),this['currentUser']=_0x59cd9e,_0x59cd9e?await this['assertedPersistence']['setCurrentUser'](_0x59cd9e):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x5820df){return this['operations']=this['operations']['then'](_0x5820df,_0x5820df),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4def9d){!_0x4def9d||this['frameworks']['includes'](_0x4def9d)||(this['frameworks']['push'](_0x4def9d),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x300f92;const _0x551d83={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x551d83['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x279222=await((_0x300f92=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x300f92['getHeartbeatsHeader']());_0x279222&&(_0x551d83['X-Firebase-Client']=_0x279222);const _0x1d67b8=await this['_getAppCheckToken']();return _0x1d67b8&&(_0x551d83['X-Firebase-AppCheck']=_0x1d67b8),_0x551d83;}async['_getAppCheckToken'](){var _0x54786d;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x101e3c=await((_0x54786d=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x54786d['getToken']());return _0x101e3c!=null&&_0x101e3c['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x101e3c['error']),_0x101e3c==null?void 0x0:_0x101e3c['token'];}}function qe(_0x513a02){return N(_0x513a02);}class Rr{constructor(_0x6d6777){this['auth']=_0x6d6777,this['observer']=null,this['addObserver']=Tc(_0xd131a0=>this['observer']=_0xd131a0);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x231ca8){jn=_0x231ca8;}function xa(_0x4ee073){return jn['loadJS'](_0x4ee073);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x22fffb){return'__'+_0x22fffb+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x4302b8){_0x4302b8();}['execute'](_0x575c33,_0xf9b92a){return Promise['resolve']('token');}['render'](_0x10ac83,_0x45c1cb){return'';}}class Lf{['ready'](_0xf0998b){_0xf0998b();}['execute'](_0x27957f,_0xbbcd1c){return Promise['resolve']('token');}['render'](_0x2ff9ca,_0x598679){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x3e0218){this['type']=xf,this['auth']=qe(_0x3e0218);}async['verify'](_0x415f6b='verify',_0x9f3884=!0x1){async function _0x7e573e(_0x58e2c8){if(!_0x9f3884){if(_0x58e2c8['tenantId']==null&&_0x58e2c8['_agentRecaptchaConfig']!=null)return _0x58e2c8['_agentRecaptchaConfig']['siteKey'];if(_0x58e2c8['tenantId']!=null&&_0x58e2c8['_tenantRecaptchaConfigs'][_0x58e2c8['tenantId']]!==void 0x0)return _0x58e2c8['_tenantRecaptchaConfigs'][_0x58e2c8['tenantId']]['siteKey'];}return new Promise(async(_0x314f5d,_0x21bc35)=>{pf(_0x58e2c8,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x15d81b=>{if(_0x15d81b['recaptchaKey']===void 0x0)_0x21bc35(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x6551fe=new ff(_0x15d81b);return _0x58e2c8['tenantId']==null?_0x58e2c8['_agentRecaptchaConfig']=_0x6551fe:_0x58e2c8['_tenantRecaptchaConfigs'][_0x58e2c8['tenantId']]=_0x6551fe,_0x314f5d(_0x6551fe['siteKey']);}})['catch'](_0xa762ea=>{_0x21bc35(_0xa762ea);});});}function _0x34c915(_0x4caec7,_0x3993b7,_0x1c649b){const _0x2a5fbb=window['grecaptcha'];wr(_0x2a5fbb)?_0x2a5fbb['enterprise']['ready'](()=>{_0x2a5fbb['enterprise']['execute'](_0x4caec7,{'action':_0x415f6b})['then'](_0x13be9e=>{_0x3993b7(_0x13be9e);})['catch'](()=>{_0x3993b7(Fa);});}):_0x1c649b(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x49a2bb,_0x319fb7)=>{_0x7e573e(this['auth'])['then'](_0x1b84fa=>{if(!_0x9f3884&&wr(window['grecaptcha']))_0x34c915(_0x1b84fa,_0x49a2bb,_0x319fb7);else{if(typeof window>'u'){_0x319fb7(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0xa135ac=Pf();_0xa135ac['length']!==0x0&&(_0xa135ac+=_0x1b84fa),xa(_0xa135ac)['then'](()=>{_0x34c915(_0x1b84fa,_0x49a2bb,_0x319fb7);})['catch'](_0xf7f824=>{_0x319fb7(_0xf7f824);});}})['catch'](_0x4650b7=>{_0x319fb7(_0x4650b7);});});}}async function Ar(_0x486648,_0x5d4d3a,_0x2b945b,_0x49f843=!0x1,_0x409fe9=!0x1){const _0x44eb40=new Ff(_0x486648);let _0x24996d;if(_0x409fe9)_0x24996d=Fa;else try{_0x24996d=await _0x44eb40['verify'](_0x2b945b);}catch{_0x24996d=await _0x44eb40['verify'](_0x2b945b,!0x0);}const _0x62ad39={..._0x5d4d3a};if(_0x2b945b==='mfaSmsEnrollment'||_0x2b945b==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x62ad39){const _0x15211e=_0x62ad39['phoneEnrollmentInfo']['phoneNumber'],_0x4d9b38=_0x62ad39['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x62ad39,{'phoneEnrollmentInfo':{'phoneNumber':_0x15211e,'recaptchaToken':_0x4d9b38,'captchaResponse':_0x24996d,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x62ad39){const _0x38c596=_0x62ad39['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x62ad39,{'phoneSignInInfo':{'recaptchaToken':_0x38c596,'captchaResponse':_0x24996d,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x62ad39;}return _0x49f843?Object['assign'](_0x62ad39,{'captchaResp':_0x24996d}):Object['assign'](_0x62ad39,{'captchaResponse':_0x24996d}),Object['assign'](_0x62ad39,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x62ad39,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x62ad39;}async function Di(_0x4a5707,_0x1bbd8d,_0x55a50f,_0x64bdeb,_0x3a1cff){var _0x1dc5a6;if((_0x1dc5a6=_0x4a5707['_getRecaptchaConfig']())!=null&&_0x1dc5a6['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x56a52f=await Ar(_0x4a5707,_0x1bbd8d,_0x55a50f,_0x55a50f==='getOobCode');return _0x64bdeb(_0x4a5707,_0x56a52f);}else return _0x64bdeb(_0x4a5707,_0x1bbd8d)['catch'](async _0x44a87c=>{if(_0x44a87c['code']==='auth/missing-recaptcha-token'){console['log'](_0x55a50f+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x8b8c38=await Ar(_0x4a5707,_0x1bbd8d,_0x55a50f,_0x55a50f==='getOobCode');return _0x64bdeb(_0x4a5707,_0x8b8c38);}else return Promise['reject'](_0x44a87c);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x42dcaa,_0x1acdab){const _0x4ff72f=Bi(_0x42dcaa,'auth');if(_0x4ff72f['isInitialized']()){const _0x360e2e=_0x4ff72f['getImmediate'](),_0x70fb76=_0x4ff72f['getOptions']();if(Me(_0x70fb76,_0x1acdab??{}))return _0x360e2e;Q(_0x360e2e,'already-initialized');}return _0x4ff72f['initialize']({'options':_0x1acdab});}function Wf(_0x7e0c12,_0x42a8f6){const _0x395ec3=(_0x42a8f6==null?void 0x0:_0x42a8f6['persistence'])||[],_0x192638=(Array['isArray'](_0x395ec3)?_0x395ec3:[_0x395ec3])['map'](ie);_0x42a8f6!=null&&_0x42a8f6['errorMap']&&_0x7e0c12['_updateErrorMap'](_0x42a8f6['errorMap']),_0x7e0c12['_initializeWithPersistence'](_0x192638,_0x42a8f6==null?void 0x0:_0x42a8f6['popupRedirectResolver']);}function Bf(_0x42a0f4,_0x13b5d3,_0x212752){const _0x5f17af=qe(_0x42a0f4);m(/^https?:\/\//['test'](_0x13b5d3),_0x5f17af,'invalid-emulator-scheme');const _0x25b4ad=!0x1,_0x467081=Ua(_0x13b5d3),{host:_0x30c5df,port:_0x5a18a7}=Vf(_0x13b5d3),_0x33a419=_0x5a18a7===null?'':':'+_0x5a18a7,_0x5ae607={'url':_0x467081+'//'+_0x30c5df+_0x33a419+'/'},_0x5c4b94=Object['freeze']({'host':_0x30c5df,'port':_0x5a18a7,'protocol':_0x467081['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x25b4ad})});if(!_0x5f17af['_canInitEmulator']){m(_0x5f17af['config']['emulator']&&_0x5f17af['emulatorConfig'],_0x5f17af,'emulator-config-failed'),m(Me(_0x5ae607,_0x5f17af['config']['emulator'])&&Me(_0x5c4b94,_0x5f17af['emulatorConfig']),_0x5f17af,'emulator-config-failed');return;}_0x5f17af['config']['emulator']=_0x5ae607,_0x5f17af['emulatorConfig']=_0x5c4b94,_0x5f17af['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x30c5df)?(jr(_0x467081+'//'+_0x30c5df+_0x33a419),Kr('Auth',!0x0)):Hf();}function Ua(_0x28e007){const _0x4253f3=_0x28e007['indexOf'](':');return _0x4253f3<0x0?'':_0x28e007['substr'](0x0,_0x4253f3+0x1);}function Vf(_0x12a454){const _0x21997a=Ua(_0x12a454),_0x489641=/(\/\/)?([^?#/]+)/['exec'](_0x12a454['substr'](_0x21997a['length']));if(!_0x489641)return{'host':'','port':null};const _0x2e6270=_0x489641[0x2]['split']('@')['pop']()||'',_0x50d658=/^(\[[^\]]+\])(:|$)/['exec'](_0x2e6270);if(_0x50d658){const _0x354d85=_0x50d658[0x1];return{'host':_0x354d85,'port':kr(_0x2e6270['substr'](_0x354d85['length']+0x1))};}else{const [_0x15fa64,_0x539a5b]=_0x2e6270['split'](':');return{'host':_0x15fa64,'port':kr(_0x539a5b)};}}function kr(_0x32f9bf){if(!_0x32f9bf)return null;const _0x399268=Number(_0x32f9bf);return isNaN(_0x399268)?null:_0x399268;}function Hf(){function _0x5c95d4(){const _0x30f9de=document['createElement']('p'),_0x49df5e=_0x30f9de['style'];_0x30f9de['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x49df5e['position']='fixed',_0x49df5e['width']='100%',_0x49df5e['backgroundColor']='#ffffff',_0x49df5e['border']='.1em\x20solid\x20#000000',_0x49df5e['color']='#b50000',_0x49df5e['bottom']='0px',_0x49df5e['left']='0px',_0x49df5e['margin']='0px',_0x49df5e['zIndex']='10000',_0x49df5e['textAlign']='center',_0x30f9de['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x30f9de);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x5c95d4):_0x5c95d4());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x3601e9,_0x1b5947){this['providerId']=_0x3601e9,this['signInMethod']=_0x1b5947;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x44522e){return ne('not\x20implemented');}['_linkToIdToken'](_0x55335d,_0x5930d4){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x3b0395){return ne('not\x20implemented');}}async function $f(_0x305ef8,_0x2a4ed0){return Ae(_0x305ef8,'POST','/v1/accounts:signUp',_0x2a4ed0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x27c60b,_0x559a83){return Qt(_0x27c60b,'POST','/v1/accounts:signInWithPassword',Re(_0x27c60b,_0x559a83));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x1c260c,_0x1f2e84){return Qt(_0x1c260c,'POST','/v1/accounts:signInWithEmailLink',Re(_0x1c260c,_0x1f2e84));}async function zf(_0x5b7cc9,_0x4cbbeb){return Qt(_0x5b7cc9,'POST','/v1/accounts:signInWithEmailLink',Re(_0x5b7cc9,_0x4cbbeb));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x1c1938,_0x5af902,_0x4c429f,_0x4ca928=null){super('password',_0x4c429f),this['_email']=_0x1c1938,this['_password']=_0x5af902,this['_tenantId']=_0x4ca928;}static['_fromEmailAndPassword'](_0x5b04f3,_0x544b6b){return new Wt(_0x5b04f3,_0x544b6b,'password');}static['_fromEmailAndCode'](_0xdd3c94,_0x27c8cd,_0x4cfc66=null){return new Wt(_0xdd3c94,_0x27c8cd,'emailLink',_0x4cfc66);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x17b168){const _0x51ed8d=typeof _0x17b168=='string'?JSON['parse'](_0x17b168):_0x17b168;if(_0x51ed8d!=null&&_0x51ed8d['email']&&(_0x51ed8d!=null&&_0x51ed8d['password'])){if(_0x51ed8d['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x51ed8d['email'],_0x51ed8d['password']);if(_0x51ed8d['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x51ed8d['email'],_0x51ed8d['password'],_0x51ed8d['tenantId']);}return null;}async['_getIdTokenResponse'](_0x2f3136){switch(this['signInMethod']){case'password':const _0x15201a={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x2f3136,_0x15201a,'signInWithPassword',Gf);case'emailLink':return qf(_0x2f3136,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x2f3136,'internal-error');}}async['_linkToIdToken'](_0xeadcfa,_0x548d46){switch(this['signInMethod']){case'password':const _0x1d1820={'idToken':_0x548d46,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0xeadcfa,_0x1d1820,'signUpPassword',$f);case'emailLink':return zf(_0xeadcfa,{'idToken':_0x548d46,'email':this['_email'],'oobCode':this['_password']});default:Q(_0xeadcfa,'internal-error');}}['_getReauthenticationResolver'](_0x346bb7){return this['_getIdTokenResponse'](_0x346bb7);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x1dfaa6,_0x1d7fd7){return Qt(_0x1dfaa6,'POST','/v1/accounts:signInWithIdp',Re(_0x1dfaa6,_0x1d7fd7));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x4d26df){const _0x69c144=new Be(_0x4d26df['providerId'],_0x4d26df['signInMethod']);return _0x4d26df['idToken']||_0x4d26df['accessToken']?(_0x4d26df['idToken']&&(_0x69c144['idToken']=_0x4d26df['idToken']),_0x4d26df['accessToken']&&(_0x69c144['accessToken']=_0x4d26df['accessToken']),_0x4d26df['nonce']&&!_0x4d26df['pendingToken']&&(_0x69c144['nonce']=_0x4d26df['nonce']),_0x4d26df['pendingToken']&&(_0x69c144['pendingToken']=_0x4d26df['pendingToken'])):_0x4d26df['oauthToken']&&_0x4d26df['oauthTokenSecret']?(_0x69c144['accessToken']=_0x4d26df['oauthToken'],_0x69c144['secret']=_0x4d26df['oauthTokenSecret']):Q('argument-error'),_0x69c144;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x3414f4){const _0x31896a=typeof _0x3414f4=='string'?JSON['parse'](_0x3414f4):_0x3414f4,{providerId:_0x12524a,signInMethod:_0x41b29c,..._0x17048f}=_0x31896a;if(!_0x12524a||!_0x41b29c)return null;const _0x5f1724=new Be(_0x12524a,_0x41b29c);return _0x5f1724['idToken']=_0x17048f['idToken']||void 0x0,_0x5f1724['accessToken']=_0x17048f['accessToken']||void 0x0,_0x5f1724['secret']=_0x17048f['secret'],_0x5f1724['nonce']=_0x17048f['nonce'],_0x5f1724['pendingToken']=_0x17048f['pendingToken']||null,_0x5f1724;}['_getIdTokenResponse'](_0x5a967d){const _0x4c8aa0=this['buildRequest']();return Xe(_0x5a967d,_0x4c8aa0);}['_linkToIdToken'](_0x4e5119,_0x202f48){const _0x5268c2=this['buildRequest']();return _0x5268c2['idToken']=_0x202f48,Xe(_0x4e5119,_0x5268c2);}['_getReauthenticationResolver'](_0x5bdfc4){const _0x3d9f29=this['buildRequest']();return _0x3d9f29['autoCreate']=!0x1,Xe(_0x5bdfc4,_0x3d9f29);}['buildRequest'](){const _0xcd7cca={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0xcd7cca['pendingToken']=this['pendingToken'];else{const _0x2f1871={};this['idToken']&&(_0x2f1871['id_token']=this['idToken']),this['accessToken']&&(_0x2f1871['access_token']=this['accessToken']),this['secret']&&(_0x2f1871['oauth_token_secret']=this['secret']),_0x2f1871['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x2f1871['nonce']=this['nonce']),_0xcd7cca['postBody']=ct(_0x2f1871);}return _0xcd7cca;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x40be7b){switch(_0x40be7b){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x155ad0){const _0xd963c2=vt(Et(_0x155ad0))['link'],_0x2be12e=_0xd963c2?vt(Et(_0xd963c2))['deep_link_id']:null,_0x57ff4e=vt(Et(_0x155ad0))['deep_link_id'];return(_0x57ff4e?vt(Et(_0x57ff4e))['link']:null)||_0x57ff4e||_0x2be12e||_0xd963c2||_0x155ad0;}class Rs{constructor(_0x4492ed){const _0x564526=vt(Et(_0x4492ed)),_0x1d1b4c=_0x564526['apiKey']??null,_0x3ac4ac=_0x564526['oobCode']??null,_0x27ad38=Kf(_0x564526['mode']??null);m(_0x1d1b4c&&_0x3ac4ac&&_0x27ad38,'argument-error'),this['apiKey']=_0x1d1b4c,this['operation']=_0x27ad38,this['code']=_0x3ac4ac,this['continueUrl']=_0x564526['continueUrl']??null,this['languageCode']=_0x564526['lang']??null,this['tenantId']=_0x564526['tenantId']??null;}static['parseLink'](_0x215d59){const _0x29b167=Yf(_0x215d59);try{return new Rs(_0x29b167);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x312df9,_0x1da809){return Wt['_fromEmailAndPassword'](_0x312df9,_0x1da809);}static['credentialWithLink'](_0x566738,_0x41b7cb){const _0x2afb5f=Rs['parseLink'](_0x41b7cb);return m(_0x2afb5f,'argument-error'),Wt['_fromEmailAndCode'](_0x566738,_0x2afb5f['code'],_0x2afb5f['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x1f1437){this['providerId']=_0x1f1437,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x463101){this['defaultLanguageCode']=_0x463101;}['setCustomParameters'](_0x4393c2){return this['customParameters']=_0x4393c2,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x258844){return this['scopes']['includes'](_0x258844)||this['scopes']['push'](_0x258844),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x28b517){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x28b517});}static['credentialFromResult'](_0x5f296c){return he['credentialFromTaggedObject'](_0x5f296c);}static['credentialFromError'](_0x2433bb){return he['credentialFromTaggedObject'](_0x2433bb['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x44b6a4}){if(!_0x44b6a4||!('oauthAccessToken'in _0x44b6a4)||!_0x44b6a4['oauthAccessToken'])return null;try{return he['credential'](_0x44b6a4['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x5d8271,_0x376819){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x5d8271,'accessToken':_0x376819});}static['credentialFromResult'](_0x3e072a){return ue['credentialFromTaggedObject'](_0x3e072a);}static['credentialFromError'](_0x258432){return ue['credentialFromTaggedObject'](_0x258432['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x368e65}){if(!_0x368e65)return null;const {oauthIdToken:_0x5be001,oauthAccessToken:_0x26e97c}=_0x368e65;if(!_0x5be001&&!_0x26e97c)return null;try{return ue['credential'](_0x5be001,_0x26e97c);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x6ba8da){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x6ba8da});}static['credentialFromResult'](_0x3d2f11){return de['credentialFromTaggedObject'](_0x3d2f11);}static['credentialFromError'](_0x2a6858){return de['credentialFromTaggedObject'](_0x2a6858['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1b1f3d}){if(!_0x1b1f3d||!('oauthAccessToken'in _0x1b1f3d)||!_0x1b1f3d['oauthAccessToken'])return null;try{return de['credential'](_0x1b1f3d['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x481cbf,_0x32fdef){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x481cbf,'oauthTokenSecret':_0x32fdef});}static['credentialFromResult'](_0x5773ea){return fe['credentialFromTaggedObject'](_0x5773ea);}static['credentialFromError'](_0x2de8f9){return fe['credentialFromTaggedObject'](_0x2de8f9['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x21bfa7}){if(!_0x21bfa7)return null;const {oauthAccessToken:_0x368261,oauthTokenSecret:_0x146bfd}=_0x21bfa7;if(!_0x368261||!_0x146bfd)return null;try{return fe['credential'](_0x368261,_0x146bfd);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x53dacf,_0x12064a){return Qt(_0x53dacf,'POST','/v1/accounts:signUp',Re(_0x53dacf,_0x12064a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0xe43510){this['user']=_0xe43510['user'],this['providerId']=_0xe43510['providerId'],this['_tokenResponse']=_0xe43510['_tokenResponse'],this['operationType']=_0xe43510['operationType'];}static async['_fromIdTokenResponse'](_0x3f0fe1,_0x4b6b49,_0x291bfe,_0x55afff=!0x1){const _0x239930=await K['_fromIdTokenResponse'](_0x3f0fe1,_0x291bfe,_0x55afff),_0x27a840=Nr(_0x291bfe);return new Ve({'user':_0x239930,'providerId':_0x27a840,'_tokenResponse':_0x291bfe,'operationType':_0x4b6b49});}static async['_forOperation'](_0x1cb059,_0x4190d7,_0x38cd2e){await _0x1cb059['_updateTokensIfNecessary'](_0x38cd2e,!0x0);const _0x563b10=Nr(_0x38cd2e);return new Ve({'user':_0x1cb059,'providerId':_0x563b10,'_tokenResponse':_0x38cd2e,'operationType':_0x4190d7});}}function Nr(_0x525eea){return _0x525eea['providerId']?_0x525eea['providerId']:'phoneNumber'in _0x525eea?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x2de945,_0x817cf8,_0x53e2b2,_0x4bedae){super(_0x817cf8['code'],_0x817cf8['message']),this['operationType']=_0x53e2b2,this['user']=_0x4bedae,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x2de945['name'],'tenantId':_0x2de945['tenantId']??void 0x0,'_serverResponse':_0x817cf8['customData']['_serverResponse'],'operationType':_0x53e2b2};}static['_fromErrorAndOperation'](_0xef5dcb,_0x256359,_0x551b3e,_0x5deb68){return new An(_0xef5dcb,_0x256359,_0x551b3e,_0x5deb68);}}function Ba(_0x9ebfd2,_0x9566b,_0x52cefa,_0x4a7fa4){return(_0x9566b==='reauthenticate'?_0x52cefa['_getReauthenticationResolver'](_0x9ebfd2):_0x52cefa['_getIdTokenResponse'](_0x9ebfd2))['catch'](_0xcded47=>{throw _0xcded47['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x9ebfd2,_0xcded47,_0x9566b,_0x4a7fa4):_0xcded47;});}async function Jf(_0x4486af,_0x27fa31,_0x1316a5=!0x1){const _0x1e5b81=await Ut(_0x4486af,_0x27fa31['_linkToIdToken'](_0x4486af['auth'],await _0x4486af['getIdToken']()),_0x1316a5);return Ve['_forOperation'](_0x4486af,'link',_0x1e5b81);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x3d8259,_0x30574b,_0x4d6b7a=!0x1){const {auth:_0x2829b4}=_0x3d8259;if($(_0x2829b4['app']))return Promise['reject'](re(_0x2829b4));const _0x370bd0='reauthenticate';try{const _0x57c3f3=await Ut(_0x3d8259,Ba(_0x2829b4,_0x370bd0,_0x30574b,_0x3d8259),_0x4d6b7a);m(_0x57c3f3['idToken'],_0x2829b4,'internal-error');const _0x23bd02=Ts(_0x57c3f3['idToken']);m(_0x23bd02,_0x2829b4,'internal-error');const {sub:_0x3c7e95}=_0x23bd02;return m(_0x3d8259['uid']===_0x3c7e95,_0x2829b4,'user-mismatch'),Ve['_forOperation'](_0x3d8259,_0x370bd0,_0x57c3f3);}catch(_0x1010c9){throw(_0x1010c9==null?void 0x0:_0x1010c9['code'])==='auth/user-not-found'&&Q(_0x2829b4,'user-mismatch'),_0x1010c9;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x2368b5,_0x8f1cb0,_0x5dba6b=!0x1){if($(_0x2368b5['app']))return Promise['reject'](re(_0x2368b5));const _0x42730a='signIn',_0x1c67f3=await Ba(_0x2368b5,_0x42730a,_0x8f1cb0),_0x48a4ff=await Ve['_fromIdTokenResponse'](_0x2368b5,_0x42730a,_0x1c67f3);return _0x5dba6b||await _0x2368b5['_updateCurrentUser'](_0x48a4ff['user']),_0x48a4ff;}async function Zf(_0x38e31f,_0x32e641){return Va(qe(_0x38e31f),_0x32e641);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x443458){const _0x3badd2=qe(_0x443458);_0x3badd2['_getPasswordPolicyInternal']()&&await _0x3badd2['_updatePasswordPolicy']();}async function P_(_0xef6505,_0x38acc7,_0x3d03ac){if($(_0xef6505['app']))return Promise['reject'](re(_0xef6505));const _0x5f0df1=qe(_0xef6505),_0x20bb64=await Di(_0x5f0df1,{'returnSecureToken':!0x0,'email':_0x38acc7,'password':_0x3d03ac,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x5580ef=>{throw _0x5580ef['code']==='auth/password-does-not-meet-requirements'&&Ha(_0xef6505),_0x5580ef;}),_0xf36214=await Ve['_fromIdTokenResponse'](_0x5f0df1,'signIn',_0x20bb64);return await _0x5f0df1['_updateCurrentUser'](_0xf36214['user']),_0xf36214;}function O_(_0x47505f,_0x8123d4,_0x109afb){return $(_0x47505f['app'])?Promise['reject'](re(_0x47505f)):Zf(N(_0x47505f),pt['credential'](_0x8123d4,_0x109afb))['catch'](async _0x34ecbb=>{throw _0x34ecbb['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x47505f),_0x34ecbb;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x3eb7c7,_0x308030){return N(_0x3eb7c7)['setPersistence'](_0x308030);}function ep(_0x53b59e,_0x9aa2b3,_0x25101c,_0x383cfa){return N(_0x53b59e)['onIdTokenChanged'](_0x9aa2b3,_0x25101c,_0x383cfa);}function tp(_0x5118e8,_0x389660,_0x2e6a19){return N(_0x5118e8)['beforeAuthStateChanged'](_0x389660,_0x2e6a19);}function M_(_0x1cec60,_0x4bd812,_0x380d52,_0x5b7e81){return N(_0x1cec60)['onAuthStateChanged'](_0x4bd812,_0x380d52,_0x5b7e81);}function L_(_0x48d427){return N(_0x48d427)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x55c437,_0x4afc72){this['storageRetriever']=_0x55c437,this['type']=_0x4afc72;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x5e94b7,_0x21d30a){return this['storage']['setItem'](_0x5e94b7,JSON['stringify'](_0x21d30a)),Promise['resolve']();}['_get'](_0x21f8cf){const _0x16db37=this['storage']['getItem'](_0x21f8cf);return Promise['resolve'](_0x16db37?JSON['parse'](_0x16db37):null);}['_remove'](_0xbd688d){return this['storage']['removeItem'](_0xbd688d),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x2fdab6,_0x20214c)=>this['onStorageEvent'](_0x2fdab6,_0x20214c),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x593a4b){for(const _0x1e32d0 of Object['keys'](this['listeners'])){const _0x148295=this['storage']['getItem'](_0x1e32d0),_0x5cba06=this['localCache'][_0x1e32d0];_0x148295!==_0x5cba06&&_0x593a4b(_0x1e32d0,_0x5cba06,_0x148295);}}['onStorageEvent'](_0x554fc3,_0x5a0d92=!0x1){if(!_0x554fc3['key']){this['forAllChangedKeys']((_0x1d00b0,_0x4160c7,_0x8db5e6)=>{this['notifyListeners'](_0x1d00b0,_0x8db5e6);});return;}const _0x23bcef=_0x554fc3['key'];_0x5a0d92?this['detachListener']():this['stopPolling']();const _0x49a0d5=()=>{const _0x15d9f3=this['storage']['getItem'](_0x23bcef);!_0x5a0d92&&this['localCache'][_0x23bcef]===_0x15d9f3||this['notifyListeners'](_0x23bcef,_0x15d9f3);},_0x4a840f=this['storage']['getItem'](_0x23bcef);Tf()&&_0x4a840f!==_0x554fc3['newValue']&&_0x554fc3['newValue']!==_0x554fc3['oldValue']?setTimeout(_0x49a0d5,ip):_0x49a0d5();}['notifyListeners'](_0x4f84b7,_0x2f5c75){this['localCache'][_0x4f84b7]=_0x2f5c75;const _0x5ca7c2=this['listeners'][_0x4f84b7];if(_0x5ca7c2){for(const _0x50da19 of Array['from'](_0x5ca7c2))_0x50da19(_0x2f5c75&&JSON['parse'](_0x2f5c75));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x1025c2,_0x3caa27,_0x31018b)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x1025c2,'oldValue':_0x3caa27,'newValue':_0x31018b}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x519730,_0x441bcc){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x519730]||(this['listeners'][_0x519730]=new Set(),this['localCache'][_0x519730]=this['storage']['getItem'](_0x519730)),this['listeners'][_0x519730]['add'](_0x441bcc);}['_removeListener'](_0x387df0,_0x38063d){this['listeners'][_0x387df0]&&(this['listeners'][_0x387df0]['delete'](_0x38063d),this['listeners'][_0x387df0]['size']===0x0&&delete this['listeners'][_0x387df0]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x25bdf2,_0x29d3bb){await super['_set'](_0x25bdf2,_0x29d3bb),this['localCache'][_0x25bdf2]=JSON['stringify'](_0x29d3bb);}async['_get'](_0x414190){const _0x1b2656=await super['_get'](_0x414190);return this['localCache'][_0x414190]=JSON['stringify'](_0x1b2656),_0x1b2656;}async['_remove'](_0x20ae21){await super['_remove'](_0x20ae21),delete this['localCache'][_0x20ae21];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x1ea723,_0x210308){}['_removeListener'](_0x385eec,_0x2334f4){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x307de5){return Promise['all'](_0x307de5['map'](async _0x5260be=>{try{return{'fulfilled':!0x0,'value':await _0x5260be};}catch(_0x3bc661){return{'fulfilled':!0x1,'reason':_0x3bc661};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x121391){this['eventTarget']=_0x121391,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x34b329){const _0x4caf11=this['receivers']['find'](_0x4e5917=>_0x4e5917['isListeningto'](_0x34b329));if(_0x4caf11)return _0x4caf11;const _0x4a0f32=new Kn(_0x34b329);return this['receivers']['push'](_0x4a0f32),_0x4a0f32;}['isListeningto'](_0x19615d){return this['eventTarget']===_0x19615d;}async['handleEvent'](_0x3fb700){const _0x47f87f=_0x3fb700,{eventId:_0x16e029,eventType:_0x2b371a,data:_0x554a61}=_0x47f87f['data'],_0x3e2d50=this['handlersMap'][_0x2b371a];if(!(_0x3e2d50!=null&&_0x3e2d50['size']))return;_0x47f87f['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x16e029,'eventType':_0x2b371a});const _0x5c2c49=Array['from'](_0x3e2d50)['map'](async _0x3ba245=>_0x3ba245(_0x47f87f['origin'],_0x554a61)),_0x38f533=await rp(_0x5c2c49);_0x47f87f['ports'][0x0]['postMessage']({'status':'done','eventId':_0x16e029,'eventType':_0x2b371a,'response':_0x38f533});}['_subscribe'](_0x520c95,_0xf3defc){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x520c95]||(this['handlersMap'][_0x520c95]=new Set()),this['handlersMap'][_0x520c95]['add'](_0xf3defc);}['_unsubscribe'](_0x48d262,_0xe467dd){this['handlersMap'][_0x48d262]&&_0xe467dd&&this['handlersMap'][_0x48d262]['delete'](_0xe467dd),(!_0xe467dd||this['handlersMap'][_0x48d262]['size']===0x0)&&delete this['handlersMap'][_0x48d262],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x27cd32='',_0x59b145=0xa){let _0x174837='';for(let _0x4d8847=0x0;_0x4d8847<_0x59b145;_0x4d8847++)_0x174837+=Math['floor'](Math['random']()*0xa);return _0x27cd32+_0x174837;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0xde9d11){this['target']=_0xde9d11,this['handlers']=new Set();}['removeMessageHandler'](_0x20f999){_0x20f999['messageChannel']&&(_0x20f999['messageChannel']['port1']['removeEventListener']('message',_0x20f999['onMessage']),_0x20f999['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x20f999);}async['_send'](_0x46d4f5,_0x2871ae,_0x3676ea=0x32){const _0x44f5b9=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x44f5b9)throw new Error('connection_unavailable');let _0xc8cd52,_0x2f36f9;return new Promise((_0x253d04,_0x2d919e)=>{const _0xf8e0f0=As('',0x14);_0x44f5b9['port1']['start']();const _0x1442f3=setTimeout(()=>{_0x2d919e(new Error('unsupported_event'));},_0x3676ea);_0x2f36f9={'messageChannel':_0x44f5b9,'onMessage'(_0x561dee){const _0x59014d=_0x561dee;if(_0x59014d['data']['eventId']===_0xf8e0f0)switch(_0x59014d['data']['status']){case'ack':clearTimeout(_0x1442f3),_0xc8cd52=setTimeout(()=>{_0x2d919e(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0xc8cd52),_0x253d04(_0x59014d['data']['response']);break;default:clearTimeout(_0x1442f3),clearTimeout(_0xc8cd52),_0x2d919e(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x2f36f9),_0x44f5b9['port1']['addEventListener']('message',_0x2f36f9['onMessage']),this['target']['postMessage']({'eventType':_0x46d4f5,'eventId':_0xf8e0f0,'data':_0x2871ae},[_0x44f5b9['port2']]);})['finally'](()=>{_0x2f36f9&&this['removeMessageHandler'](_0x2f36f9);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x43ee1b){Z()['location']['href']=_0x43ee1b;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x480f4d;return((_0x480f4d=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x480f4d['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0xa42fb6){this['request']=_0xa42fb6;}['toPromise'](){return new Promise((_0x24403e,_0x354bd3)=>{this['request']['addEventListener']('success',()=>{_0x24403e(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x354bd3(this['request']['error']);});});}}function Yn(_0x17bfca,_0x1aee7f){return _0x17bfca['transaction']([Nn],_0x1aee7f?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x73c71d=indexedDB['deleteDatabase'](Ka);return new Xt(_0x73c71d)['toPromise']();}function Mi(){const _0xf42be9=indexedDB['open'](Ka,up);return new Promise((_0x1744cf,_0x29c455)=>{_0xf42be9['addEventListener']('error',()=>{_0x29c455(_0xf42be9['error']);}),_0xf42be9['addEventListener']('upgradeneeded',()=>{const _0x268a9b=_0xf42be9['result'];try{_0x268a9b['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x9430b7){_0x29c455(_0x9430b7);}}),_0xf42be9['addEventListener']('success',async()=>{const _0x1f9e33=_0xf42be9['result'];_0x1f9e33['objectStoreNames']['contains'](Nn)?_0x1744cf(_0x1f9e33):(_0x1f9e33['close'](),await dp(),_0x1744cf(await Mi()));});});}async function Pr(_0x21b44a,_0x2a24ff,_0xd52a78){const _0x24cf10=Yn(_0x21b44a,!0x0)['put']({[Ya]:_0x2a24ff,'value':_0xd52a78});return new Xt(_0x24cf10)['toPromise']();}async function fp(_0x211752,_0x281621){const _0x2e0b14=Yn(_0x211752,!0x1)['get'](_0x281621),_0x46648b=await new Xt(_0x2e0b14)['toPromise']();return _0x46648b===void 0x0?null:_0x46648b['value'];}function Or(_0x2bada1,_0x38b711){const _0x1bc5ad=Yn(_0x2bada1,!0x0)['delete'](_0x38b711);return new Xt(_0x1bc5ad)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x4b4ef3){let _0x326a8d=0x0;for(;;)try{const _0x5214e7=await this['_openDb']();return await _0x4b4ef3(_0x5214e7);}catch(_0x2ca1e5){if(_0x326a8d++>_p)throw _0x2ca1e5;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x21c152,_0x3ec6ad)=>({'keyProcessed':(await this['_poll']())['includes'](_0x3ec6ad['key'])})),this['receiver']['_subscribe']('ping',async(_0x49540a,_0x17d9ee)=>['keyChanged']);}async['initializeSender'](){var _0x28999b,_0x25606b;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x50a8b3=await this['sender']['_send']('ping',{},0x320);_0x50a8b3&&(_0x28999b=_0x50a8b3[0x0])!=null&&_0x28999b['fulfilled']&&(_0x25606b=_0x50a8b3[0x0])!=null&&_0x25606b['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x3dabb3){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x3dabb3},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x34758a=await Mi();return await Pr(_0x34758a,kn,'1'),await Or(_0x34758a,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0xe28a2b){this['pendingWrites']++;try{await _0xe28a2b();}finally{this['pendingWrites']--;}}async['_set'](_0x55740a,_0x41d270){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x411e2a=>Pr(_0x411e2a,_0x55740a,_0x41d270)),this['localCache'][_0x55740a]=_0x41d270,this['notifyServiceWorker'](_0x55740a)));}async['_get'](_0x3a9e6d){const _0x1608a7=await this['_withRetries'](_0x35297a=>fp(_0x35297a,_0x3a9e6d));return this['localCache'][_0x3a9e6d]=_0x1608a7,_0x1608a7;}async['_remove'](_0x2e2f24){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x560300=>Or(_0x560300,_0x2e2f24)),delete this['localCache'][_0x2e2f24],this['notifyServiceWorker'](_0x2e2f24)));}async['_poll'](){const _0x4a0d3a=await this['_withRetries'](_0x24aac2=>{const _0x479714=Yn(_0x24aac2,!0x1)['getAll']();return new Xt(_0x479714)['toPromise']();});if(!_0x4a0d3a)return[];if(this['pendingWrites']!==0x0)return[];const _0x51545f=[],_0x392069=new Set();if(_0x4a0d3a['length']!==0x0){for(const {fbase_key:_0x22f034,value:_0x14bab1}of _0x4a0d3a)_0x392069['add'](_0x22f034),JSON['stringify'](this['localCache'][_0x22f034])!==JSON['stringify'](_0x14bab1)&&(this['notifyListeners'](_0x22f034,_0x14bab1),_0x51545f['push'](_0x22f034));}for(const _0x3b36d4 of Object['keys'](this['localCache']))this['localCache'][_0x3b36d4]&&!_0x392069['has'](_0x3b36d4)&&(this['notifyListeners'](_0x3b36d4,null),_0x51545f['push'](_0x3b36d4));return _0x51545f;}['notifyListeners'](_0x22a8de,_0x5bca06){this['localCache'][_0x22a8de]=_0x5bca06;const _0x46b297=this['listeners'][_0x22a8de];if(_0x46b297){for(const _0x22ad83 of Array['from'](_0x46b297))_0x22ad83(_0x5bca06);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x562e8b,_0x26817f){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x562e8b]||(this['listeners'][_0x562e8b]=new Set(),this['_get'](_0x562e8b)),this['listeners'][_0x562e8b]['add'](_0x26817f);}['_removeListener'](_0x4ac49b,_0x31ca53){this['listeners'][_0x4ac49b]&&(this['listeners'][_0x4ac49b]['delete'](_0x31ca53),this['listeners'][_0x4ac49b]['size']===0x0&&delete this['listeners'][_0x4ac49b]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x316414,_0x5ded22){return _0x5ded22?ie(_0x5ded22):(m(_0x316414['_popupRedirectResolver'],_0x316414,'argument-error'),_0x316414['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x3e562f){super('custom','custom'),this['params']=_0x3e562f;}['_getIdTokenResponse'](_0x5beca1){return Xe(_0x5beca1,this['_buildIdpRequest']());}['_linkToIdToken'](_0x8c2129,_0xbbd8e2){return Xe(_0x8c2129,this['_buildIdpRequest'](_0xbbd8e2));}['_getReauthenticationResolver'](_0xa9b165){return Xe(_0xa9b165,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x39f74d){const _0x276a7b={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x39f74d&&(_0x276a7b['idToken']=_0x39f74d),_0x276a7b;}}function yp(_0x24ae48){return Va(_0x24ae48['auth'],new ks(_0x24ae48),_0x24ae48['bypassAuthState']);}function vp(_0x499bb8){const {auth:_0x4f4f15,user:_0x2a26f4}=_0x499bb8;return m(_0x2a26f4,_0x4f4f15,'internal-error'),Xf(_0x2a26f4,new ks(_0x499bb8),_0x499bb8['bypassAuthState']);}async function Ep(_0x3ba287){const {auth:_0x3ee78c,user:_0x761791}=_0x3ba287;return m(_0x761791,_0x3ee78c,'internal-error'),Jf(_0x761791,new ks(_0x3ba287),_0x3ba287['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x493013,_0x237b4b,_0x5972c8,_0x2c86be,_0x34b830=!0x1){this['auth']=_0x493013,this['resolver']=_0x5972c8,this['user']=_0x2c86be,this['bypassAuthState']=_0x34b830,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x237b4b)?_0x237b4b:[_0x237b4b];}['execute'](){return new Promise(async(_0x3138c6,_0x8af11f)=>{this['pendingPromise']={'resolve':_0x3138c6,'reject':_0x8af11f};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x190be2){this['reject'](_0x190be2);}});}async['onAuthEvent'](_0x4f35de){const {urlResponse:_0x4c85f8,sessionId:_0x5571dc,postBody:_0x518e9e,tenantId:_0x440301,error:_0x374b31,type:_0x36a5dd}=_0x4f35de;if(_0x374b31){this['reject'](_0x374b31);return;}const _0x4ddc52={'auth':this['auth'],'requestUri':_0x4c85f8,'sessionId':_0x5571dc,'tenantId':_0x440301||void 0x0,'postBody':_0x518e9e||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x36a5dd)(_0x4ddc52));}catch(_0xbdab39){this['reject'](_0xbdab39);}}['onError'](_0x334c1e){this['reject'](_0x334c1e);}['getIdpTask'](_0x29a22f){switch(_0x29a22f){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x53eafe){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x53eafe),this['unregisterAndCleanUp']();}['reject'](_0x50c4eb){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x50c4eb),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x2d8749,_0x242b02,_0x314bf0,_0x16f1ba,_0x5524c7){super(_0x2d8749,_0x242b02,_0x16f1ba,_0x5524c7),this['provider']=_0x314bf0,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x547c3e=await this['execute']();return m(_0x547c3e,this['auth'],'internal-error'),_0x547c3e;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x5d3b2b=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x5d3b2b),this['authWindow']['associatedEvent']=_0x5d3b2b,this['resolver']['_originValidation'](this['auth'])['catch'](_0x36ed1d=>{this['reject'](_0x36ed1d);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x28d6e8=>{_0x28d6e8||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x202c4b;return((_0x202c4b=this['authWindow'])==null?void 0x0:_0x202c4b['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x305f30=()=>{var _0x6a4701,_0x4fbb7f;if((_0x4fbb7f=(_0x6a4701=this['authWindow'])==null?void 0x0:_0x6a4701['window'])!=null&&_0x4fbb7f['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x305f30,Ip['get']());};_0x305f30();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x5f338a,_0x48f7be,_0x44f11f=!0x1){super(_0x5f338a,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x48f7be,void 0x0,_0x44f11f),this['eventId']=null;}async['execute'](){let _0x19a10f=on['get'](this['auth']['_key']());if(!_0x19a10f){try{const _0x4a72e3=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x19a10f=()=>Promise['resolve'](_0x4a72e3);}catch(_0x31f9ef){_0x19a10f=()=>Promise['reject'](_0x31f9ef);}on['set'](this['auth']['_key'](),_0x19a10f);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x19a10f();}async['onAuthEvent'](_0x154572){if(_0x154572['type']==='signInViaRedirect')return super['onAuthEvent'](_0x154572);if(_0x154572['type']==='unknown'){this['resolve'](null);return;}if(_0x154572['eventId']){const _0x134120=await this['auth']['_redirectUserForId'](_0x154572['eventId']);if(_0x134120)return this['user']=_0x134120,super['onAuthEvent'](_0x154572);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x4b229d,_0xd3bcac){const _0x4203e8=Rp(_0xd3bcac),_0xbb9558=bp(_0x4b229d);if(!await _0xbb9558['_isAvailable']())return!0x1;const _0x2bc39b=await _0xbb9558['_get'](_0x4203e8)==='true';return await _0xbb9558['_remove'](_0x4203e8),_0x2bc39b;}function Sp(_0x306280,_0x76e032){on['set'](_0x306280['_key'](),_0x76e032);}function bp(_0x8b28f){return ie(_0x8b28f['_redirectPersistence']);}function Rp(_0x208cc5){return rn(wp,_0x208cc5['config']['apiKey'],_0x208cc5['name']);}async function Ap(_0x248bfa,_0x124b95,_0x5ba309=!0x1){if($(_0x248bfa['app']))return Promise['reject'](re(_0x248bfa));const _0x356099=qe(_0x248bfa),_0x2817ca=mp(_0x356099,_0x124b95),_0x3b51bb=await new Cp(_0x356099,_0x2817ca,_0x5ba309)['execute']();return _0x3b51bb&&!_0x5ba309&&(delete _0x3b51bb['user']['_redirectEventId'],await _0x356099['_persistUserIfCurrent'](_0x3b51bb['user']),await _0x356099['_setRedirectUser'](null,_0x124b95)),_0x3b51bb;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x472ddb){this['auth']=_0x472ddb,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x3c974d){this['consumers']['add'](_0x3c974d),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x3c974d)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x3c974d),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x35edcb){this['consumers']['delete'](_0x35edcb);}['onEvent'](_0x200a0d){if(this['hasEventBeenHandled'](_0x200a0d))return!0x1;let _0x2c9c45=!0x1;return this['consumers']['forEach'](_0x5964cf=>{this['isEventForConsumer'](_0x200a0d,_0x5964cf)&&(_0x2c9c45=!0x0,this['sendToConsumer'](_0x200a0d,_0x5964cf),this['saveEventToCache'](_0x200a0d));}),this['hasHandledPotentialRedirect']||!Pp(_0x200a0d)||(this['hasHandledPotentialRedirect']=!0x0,_0x2c9c45||(this['queuedRedirectEvent']=_0x200a0d,_0x2c9c45=!0x0)),_0x2c9c45;}['sendToConsumer'](_0x437621,_0x2778a8){var _0x3d1c35;if(_0x437621['error']&&!Xa(_0x437621)){const _0x3a7f7b=((_0x3d1c35=_0x437621['error']['code'])==null?void 0x0:_0x3d1c35['split']('auth/')[0x1])||'internal-error';_0x2778a8['onError'](X(this['auth'],_0x3a7f7b));}else _0x2778a8['onAuthEvent'](_0x437621);}['isEventForConsumer'](_0x250908,_0x52df5c){const _0x530d44=_0x52df5c['eventId']===null||!!_0x250908['eventId']&&_0x250908['eventId']===_0x52df5c['eventId'];return _0x52df5c['filter']['includes'](_0x250908['type'])&&_0x530d44;}['hasEventBeenHandled'](_0x3775c8){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x3775c8));}['saveEventToCache'](_0x49dcfa){this['cachedEventUids']['add'](Dr(_0x49dcfa)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x539eea){return[_0x539eea['type'],_0x539eea['eventId'],_0x539eea['sessionId'],_0x539eea['tenantId']]['filter'](_0x56a2f7=>_0x56a2f7)['join']('-');}function Xa({type:_0x23b7d0,error:_0x404d74}){return _0x23b7d0==='unknown'&&(_0x404d74==null?void 0x0:_0x404d74['code'])==='auth/no-auth-event';}function Pp(_0x2aee51){switch(_0x2aee51['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x2aee51);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x1953c4,_0x8f7f1f={}){return Ae(_0x1953c4,'GET','/v1/projects',_0x8f7f1f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x1335a7){if(_0x1335a7['config']['emulator'])return;const {authorizedDomains:_0x5aefeb}=await Op(_0x1335a7);for(const _0x3511b0 of _0x5aefeb)try{if(xp(_0x3511b0))return;}catch{}Q(_0x1335a7,'unauthorized-domain');}function xp(_0x48dcba){const _0x178689=Pi(),{protocol:_0x3ee942,hostname:_0x2fe84c}=new URL(_0x178689);if(_0x48dcba['startsWith']('chrome-extension://')){const _0x250f44=new URL(_0x48dcba);return _0x250f44['hostname']===''&&_0x2fe84c===''?_0x3ee942==='chrome-extension:'&&_0x48dcba['replace']('chrome-extension://','')===_0x178689['replace']('chrome-extension://',''):_0x3ee942==='chrome-extension:'&&_0x250f44['hostname']===_0x2fe84c;}if(!Mp['test'](_0x3ee942))return!0x1;if(Dp['test'](_0x48dcba))return _0x2fe84c===_0x48dcba;const _0x49d0e6=_0x48dcba['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x49d0e6+'|'+_0x49d0e6+')$','i')['test'](_0x2fe84c);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x40a3a1=Z()['___jsl'];if(_0x40a3a1!=null&&_0x40a3a1['H']){for(const _0x592b19 of Object['keys'](_0x40a3a1['H']))if(_0x40a3a1['H'][_0x592b19]['r']=_0x40a3a1['H'][_0x592b19]['r']||[],_0x40a3a1['H'][_0x592b19]['L']=_0x40a3a1['H'][_0x592b19]['L']||[],_0x40a3a1['H'][_0x592b19]['r']=[..._0x40a3a1['H'][_0x592b19]['L']],_0x40a3a1['CP']){for(let _0x3e6e3d=0x0;_0x3e6e3d<_0x40a3a1['CP']['length'];_0x3e6e3d++)_0x40a3a1['CP'][_0x3e6e3d]=null;}}}function Up(_0x44778b){return new Promise((_0x577391,_0x2e80d0)=>{var _0x20fb87,_0x32f88f,_0x13c848;function _0x424d1e(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x577391(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x2e80d0(X(_0x44778b,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x32f88f=(_0x20fb87=Z()['gapi'])==null?void 0x0:_0x20fb87['iframes'])!=null&&_0x32f88f['Iframe'])_0x577391(gapi['iframes']['getContext']());else{if((_0x13c848=Z()['gapi'])!=null&&_0x13c848['load'])_0x424d1e();else{const _0x171824=Df('iframefcb');return Z()[_0x171824]=()=>{gapi['load']?_0x424d1e():_0x2e80d0(X(_0x44778b,'network-request-failed'));},xa(Of()+'?onload='+_0x171824)['catch'](_0x5db39f=>_0x2e80d0(_0x5db39f));}}})['catch'](_0x5f412a=>{throw an=null,_0x5f412a;});}let an=null;function Wp(_0x3d7579){return an=an||Up(_0x3d7579),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x1c853b){const _0x1b81d4=_0x1c853b['config'];m(_0x1b81d4['authDomain'],_0x1c853b,'auth-domain-config-required');const _0x1de690=_0x1b81d4['emulator']?Cs(_0x1b81d4,Hp):'https://'+_0x1c853b['config']['authDomain']+'/'+Vp,_0x1903bb={'apiKey':_0x1b81d4['apiKey'],'appName':_0x1c853b['name'],'v':lt},_0x5ae113=Gp['get'](_0x1c853b['config']['apiHost']);_0x5ae113&&(_0x1903bb['eid']=_0x5ae113);const _0x1b4fe8=_0x1c853b['_getFrameworks']();return _0x1b4fe8['length']&&(_0x1903bb['fw']=_0x1b4fe8['join'](',')),_0x1de690+'?'+ct(_0x1903bb)['slice'](0x1);}async function zp(_0x534dfa){const _0x464b7d=await Wp(_0x534dfa),_0x965933=Z()['gapi'];return m(_0x965933,_0x534dfa,'internal-error'),_0x464b7d['open']({'where':document['body'],'url':qp(_0x534dfa),'messageHandlersFilter':_0x965933['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x1dc192=>new Promise(async(_0x582828,_0x386f4d)=>{await _0x1dc192['restyle']({'setHideOnLeave':!0x1});const _0x426fca=X(_0x534dfa,'network-request-failed'),_0xc3fb2f=Z()['setTimeout'](()=>{_0x386f4d(_0x426fca);},Bp['get']());function _0x258a43(){Z()['clearTimeout'](_0xc3fb2f),_0x582828(_0x1dc192);}_0x1dc192['ping'](_0x258a43)['then'](_0x258a43,()=>{_0x386f4d(_0x426fca);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x231382){this['window']=_0x231382,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x448fbb,_0x236809,_0x44b422,_0x40ab75=Kp,_0x124976=Yp){const _0x502b47=Math['max']((window['screen']['availHeight']-_0x124976)/0x2,0x0)['toString'](),_0x1cf594=Math['max']((window['screen']['availWidth']-_0x40ab75)/0x2,0x0)['toString']();let _0x32fb64='';const _0x1b0b59={...jp,'width':_0x40ab75['toString'](),'height':_0x124976['toString'](),'top':_0x502b47,'left':_0x1cf594},_0x2b99cc=W()['toLowerCase']();_0x44b422&&(_0x32fb64=ka(_0x2b99cc)?Qp:_0x44b422),Ra(_0x2b99cc)&&(_0x236809=_0x236809||Jp,_0x1b0b59['scrollbars']='yes');const _0x5be69f=Object['entries'](_0x1b0b59)['reduce']((_0x3c385d,[_0x521a16,_0x5f4c72])=>''+_0x3c385d+_0x521a16+'='+_0x5f4c72+',','');if(Cf(_0x2b99cc)&&_0x32fb64!=='_self')return Zp(_0x236809||'',_0x32fb64),new Lr(null);const _0x71fc77=window['open'](_0x236809||'',_0x32fb64,_0x5be69f);m(_0x71fc77,_0x448fbb,'popup-blocked');try{_0x71fc77['focus']();}catch{}return new Lr(_0x71fc77);}function Zp(_0x5c3b66,_0x30d1e1){const _0x36f6a7=document['createElement']('a');_0x36f6a7['href']=_0x5c3b66,_0x36f6a7['target']=_0x30d1e1;const _0x35c128=document['createEvent']('MouseEvent');_0x35c128['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x36f6a7['dispatchEvent'](_0x35c128);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x3c5c2f,_0xaab753,_0x4a4e26,_0x59d982,_0x28128d,_0x297c33){m(_0x3c5c2f['config']['authDomain'],_0x3c5c2f,'auth-domain-config-required'),m(_0x3c5c2f['config']['apiKey'],_0x3c5c2f,'invalid-api-key');const _0x1adbf5={'apiKey':_0x3c5c2f['config']['apiKey'],'appName':_0x3c5c2f['name'],'authType':_0x4a4e26,'redirectUrl':_0x59d982,'v':lt,'eventId':_0x28128d};if(_0xaab753 instanceof Wa){_0xaab753['setDefaultLanguage'](_0x3c5c2f['languageCode']),_0x1adbf5['providerId']=_0xaab753['providerId']||'',ui(_0xaab753['getCustomParameters']())||(_0x1adbf5['customParameters']=JSON['stringify'](_0xaab753['getCustomParameters']()));for(const [_0x27b1ef,_0x517ebc]of Object['entries']({}))_0x1adbf5[_0x27b1ef]=_0x517ebc;}if(_0xaab753 instanceof Jt){const _0x50a325=_0xaab753['getScopes']()['filter'](_0x456d42=>_0x456d42!=='');_0x50a325['length']>0x0&&(_0x1adbf5['scopes']=_0x50a325['join'](','));}_0x3c5c2f['tenantId']&&(_0x1adbf5['tid']=_0x3c5c2f['tenantId']);const _0x166a6e=_0x1adbf5;for(const _0x502684 of Object['keys'](_0x166a6e))_0x166a6e[_0x502684]===void 0x0&&delete _0x166a6e[_0x502684];const _0xfe6ff3=await _0x3c5c2f['_getAppCheckToken'](),_0xd7f7b6=_0xfe6ff3?'#'+n_+'='+encodeURIComponent(_0xfe6ff3):'';return i_(_0x3c5c2f)+'?'+ct(_0x166a6e)['slice'](0x1)+_0xd7f7b6;}function i_({config:_0x2717c9}){return _0x2717c9['emulator']?Cs(_0x2717c9,t_):'https://'+_0x2717c9['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x1170ca,_0xf61dfa,_0x39909d,_0x36b81e){var _0x2765d8;ce((_0x2765d8=this['eventManagers'][_0x1170ca['_key']()])==null?void 0x0:_0x2765d8['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0xfacc0=await xr(_0x1170ca,_0xf61dfa,_0x39909d,Pi(),_0x36b81e);return Xp(_0x1170ca,_0xfacc0,As());}async['_openRedirect'](_0xf8242,_0x1e98a3,_0x10d519,_0x367e52){await this['_originValidation'](_0xf8242);const _0x2e52c0=await xr(_0xf8242,_0x1e98a3,_0x10d519,Pi(),_0x367e52);return ap(_0x2e52c0),new Promise(()=>{});}['_initialize'](_0x4edc77){const _0x33ea1a=_0x4edc77['_key']();if(this['eventManagers'][_0x33ea1a]){const {manager:_0x4e971c,promise:_0x2820c9}=this['eventManagers'][_0x33ea1a];return _0x4e971c?Promise['resolve'](_0x4e971c):(ce(_0x2820c9,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x2820c9);}const _0x1d43f7=this['initAndGetManager'](_0x4edc77);return this['eventManagers'][_0x33ea1a]={'promise':_0x1d43f7},_0x1d43f7['catch'](()=>{delete this['eventManagers'][_0x33ea1a];}),_0x1d43f7;}async['initAndGetManager'](_0x52d423){const _0x35fb7b=await zp(_0x52d423),_0x100f55=new Np(_0x52d423);return _0x35fb7b['register']('authEvent',_0xe2c2f4=>(m(_0xe2c2f4==null?void 0x0:_0xe2c2f4['authEvent'],_0x52d423,'invalid-auth-event'),{'status':_0x100f55['onEvent'](_0xe2c2f4['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x52d423['_key']()]={'manager':_0x100f55},this['iframes'][_0x52d423['_key']()]=_0x35fb7b,_0x100f55;}['_isIframeWebStorageSupported'](_0x1034d3,_0x55938b){this['iframes'][_0x1034d3['_key']()]['send'](hi,{'type':hi},_0x3ced1a=>{var _0x56d684;const _0x5c5a33=(_0x56d684=_0x3ced1a==null?void 0x0:_0x3ced1a[0x0])==null?void 0x0:_0x56d684[hi];_0x5c5a33!==void 0x0&&_0x55938b(!!_0x5c5a33),Q(_0x1034d3,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x12691e){const _0x38cfe1=_0x12691e['_key']();return this['originValidationPromises'][_0x38cfe1]||(this['originValidationPromises'][_0x38cfe1]=Lp(_0x12691e)),this['originValidationPromises'][_0x38cfe1];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0xc27e70){this['auth']=_0xc27e70,this['internalListeners']=new Map();}['getUid'](){var _0x48f46c;return this['assertAuthConfigured'](),((_0x48f46c=this['auth']['currentUser'])==null?void 0x0:_0x48f46c['uid'])||null;}async['getToken'](_0x1968d7){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x1968d7)}:null;}['addAuthTokenListener'](_0x1d0da5){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x1d0da5))return;const _0xf637d7=this['auth']['onIdTokenChanged'](_0x5874ec=>{_0x1d0da5((_0x5874ec==null?void 0x0:_0x5874ec['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x1d0da5,_0xf637d7),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x38d01a){this['assertAuthConfigured']();const _0xf52ba0=this['internalListeners']['get'](_0x38d01a);_0xf52ba0&&(this['internalListeners']['delete'](_0x38d01a),_0xf52ba0(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x552147){switch(_0x552147){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x1c6fb9){Ze(new Le('auth',(_0x14b962,{options:_0x3f1d44})=>{const _0x335100=_0x14b962['getProvider']('app')['getImmediate'](),_0x10121c=_0x14b962['getProvider']('heartbeat'),_0x588d0d=_0x14b962['getProvider']('app-check-internal'),{apiKey:_0x2433bc,authDomain:_0x5c8c20}=_0x335100['options'];m(_0x2433bc&&!_0x2433bc['includes'](':'),'invalid-api-key',{'appName':_0x335100['name']});const _0xf12d8e={'apiKey':_0x2433bc,'authDomain':_0x5c8c20,'clientPlatform':_0x1c6fb9,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x1c6fb9)},_0x46053f=new kf(_0x335100,_0x10121c,_0x588d0d,_0xf12d8e);return Wf(_0x46053f,_0x3f1d44),_0x46053f;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x4fef4e,_0x47fd7b,_0x4854c0)=>{_0x4fef4e['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x1a3494=>{const _0x1135fc=qe(_0x1a3494['getProvider']('auth')['getImmediate']());return(_0x355b58=>new o_(_0x355b58))(_0x1135fc);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x1c6fb9)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x81dfd1=>async _0x354421=>{const _0x5f4077=_0x354421&&await _0x354421['getIdTokenResult'](),_0x3588ae=_0x5f4077&&(new Date()['getTime']()-Date['parse'](_0x5f4077['issuedAtTime']))/0x3e8;if(_0x3588ae&&_0x3588ae>h_)return;const _0x58cd63=_0x5f4077==null?void 0x0:_0x5f4077['token'];Wr!==_0x58cd63&&(Wr=_0x58cd63,await fetch(_0x81dfd1,{'method':_0x58cd63?'POST':'DELETE','headers':_0x58cd63?{'Authorization':'Bearer\x20'+_0x58cd63}:{}}));};function x_(_0x2da912=Zr()){const _0x54cbeb=Bi(_0x2da912,'auth');if(_0x54cbeb['isInitialized']())return _0x54cbeb['getImmediate']();const _0x104b2b=Uf(_0x2da912,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x3a90f9=zr('authTokenSyncURL');if(_0x3a90f9&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x4edcc2=new URL(_0x3a90f9,location['origin']);if(location['origin']===_0x4edcc2['origin']){const _0x1b9468=u_(_0x4edcc2['toString']());tp(_0x104b2b,_0x1b9468,()=>_0x1b9468(_0x104b2b['currentUser'])),ep(_0x104b2b,_0x3e666c=>_0x1b9468(_0x3e666c));}}const _0x538319=Gr('auth');return _0x538319&&Bf(_0x104b2b,'http://'+_0x538319),_0x104b2b;}function d_(){var _0x4bbd37;return((_0x4bbd37=document['getElementsByTagName']('head'))==null?void 0x0:_0x4bbd37[0x0])??document;}Nf({'loadJS'(_0x4c927b){return new Promise((_0x1592ff,_0x460f96)=>{const _0x44c66d=document['createElement']('script');_0x44c66d['setAttribute']('src',_0x4c927b),_0x44c66d['onload']=_0x1592ff,_0x44c66d['onerror']=_0x2ec83e=>{const _0x2345f8=X('internal-error');_0x2345f8['customData']=_0x2ec83e,_0x460f96(_0x2345f8);},_0x44c66d['type']='text/javascript',_0x44c66d['charset']='UTF-8',d_()['appendChild'](_0x44c66d);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};