const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0xcfebb2,_0x496533){if(!_0xcfebb2)throw rt(_0x496533);},rt=function(_0x539b31){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x539b31);},Vr=function(_0xb1596e){const _0x283f13=[];let _0x462899=0x0;for(let _0x188cac=0x0;_0x188cac<_0xb1596e['length'];_0x188cac++){let _0x5be862=_0xb1596e['charCodeAt'](_0x188cac);_0x5be862<0x80?_0x283f13[_0x462899++]=_0x5be862:_0x5be862<0x800?(_0x283f13[_0x462899++]=_0x5be862>>0x6|0xc0,_0x283f13[_0x462899++]=_0x5be862&0x3f|0x80):(_0x5be862&0xfc00)===0xd800&&_0x188cac+0x1<_0xb1596e['length']&&(_0xb1596e['charCodeAt'](_0x188cac+0x1)&0xfc00)===0xdc00?(_0x5be862=0x10000+((_0x5be862&0x3ff)<<0xa)+(_0xb1596e['charCodeAt'](++_0x188cac)&0x3ff),_0x283f13[_0x462899++]=_0x5be862>>0x12|0xf0,_0x283f13[_0x462899++]=_0x5be862>>0xc&0x3f|0x80,_0x283f13[_0x462899++]=_0x5be862>>0x6&0x3f|0x80,_0x283f13[_0x462899++]=_0x5be862&0x3f|0x80):(_0x283f13[_0x462899++]=_0x5be862>>0xc|0xe0,_0x283f13[_0x462899++]=_0x5be862>>0x6&0x3f|0x80,_0x283f13[_0x462899++]=_0x5be862&0x3f|0x80);}return _0x283f13;},ec=function(_0x3dacdc){const _0x2d5a4b=[];let _0x2eb1e2=0x0,_0x2bfcaf=0x0;for(;_0x2eb1e2<_0x3dacdc['length'];){const _0x2fe43b=_0x3dacdc[_0x2eb1e2++];if(_0x2fe43b<0x80)_0x2d5a4b[_0x2bfcaf++]=String['fromCharCode'](_0x2fe43b);else{if(_0x2fe43b>0xbf&&_0x2fe43b<0xe0){const _0x2f9679=_0x3dacdc[_0x2eb1e2++];_0x2d5a4b[_0x2bfcaf++]=String['fromCharCode']((_0x2fe43b&0x1f)<<0x6|_0x2f9679&0x3f);}else{if(_0x2fe43b>0xef&&_0x2fe43b<0x16d){const _0x4c07b4=_0x3dacdc[_0x2eb1e2++],_0x463264=_0x3dacdc[_0x2eb1e2++],_0x5d05ea=_0x3dacdc[_0x2eb1e2++],_0x52093e=((_0x2fe43b&0x7)<<0x12|(_0x4c07b4&0x3f)<<0xc|(_0x463264&0x3f)<<0x6|_0x5d05ea&0x3f)-0x10000;_0x2d5a4b[_0x2bfcaf++]=String['fromCharCode'](0xd800+(_0x52093e>>0xa)),_0x2d5a4b[_0x2bfcaf++]=String['fromCharCode'](0xdc00+(_0x52093e&0x3ff));}else{const _0x184e80=_0x3dacdc[_0x2eb1e2++],_0x5496ad=_0x3dacdc[_0x2eb1e2++];_0x2d5a4b[_0x2bfcaf++]=String['fromCharCode']((_0x2fe43b&0xf)<<0xc|(_0x184e80&0x3f)<<0x6|_0x5496ad&0x3f);}}}}return _0x2d5a4b['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x543b2b,_0x34b364){if(!Array['isArray'](_0x543b2b))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x37598d=_0x34b364?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x4ae4ff=[];for(let _0x4e19b8=0x0;_0x4e19b8<_0x543b2b['length'];_0x4e19b8+=0x3){const _0x537170=_0x543b2b[_0x4e19b8],_0x5aa862=_0x4e19b8+0x1<_0x543b2b['length'],_0x573eec=_0x5aa862?_0x543b2b[_0x4e19b8+0x1]:0x0,_0x2e95f2=_0x4e19b8+0x2<_0x543b2b['length'],_0x12c1db=_0x2e95f2?_0x543b2b[_0x4e19b8+0x2]:0x0,_0x145c69=_0x537170>>0x2,_0x299621=(_0x537170&0x3)<<0x4|_0x573eec>>0x4;let _0x15c3ef=(_0x573eec&0xf)<<0x2|_0x12c1db>>0x6,_0x3bc1cc=_0x12c1db&0x3f;_0x2e95f2||(_0x3bc1cc=0x40,_0x5aa862||(_0x15c3ef=0x40)),_0x4ae4ff['push'](_0x37598d[_0x145c69],_0x37598d[_0x299621],_0x37598d[_0x15c3ef],_0x37598d[_0x3bc1cc]);}return _0x4ae4ff['join']('');},'encodeString'(_0x1c6623,_0xe3adc1){return this['HAS_NATIVE_SUPPORT']&&!_0xe3adc1?btoa(_0x1c6623):this['encodeByteArray'](Vr(_0x1c6623),_0xe3adc1);},'decodeString'(_0x563684,_0x2e93de){return this['HAS_NATIVE_SUPPORT']&&!_0x2e93de?atob(_0x563684):ec(this['decodeStringToByteArray'](_0x563684,_0x2e93de));},'decodeStringToByteArray'(_0x463225,_0x352060){this['init_']();const _0x240d34=_0x352060?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x261954=[];for(let _0x208601=0x0;_0x208601<_0x463225['length'];){const _0x288f0f=_0x240d34[_0x463225['charAt'](_0x208601++)],_0x572261=_0x208601<_0x463225['length']?_0x240d34[_0x463225['charAt'](_0x208601)]:0x0;++_0x208601;const _0x9308b1=_0x208601<_0x463225['length']?_0x240d34[_0x463225['charAt'](_0x208601)]:0x40;++_0x208601;const _0x458f64=_0x208601<_0x463225['length']?_0x240d34[_0x463225['charAt'](_0x208601)]:0x40;if(++_0x208601,_0x288f0f==null||_0x572261==null||_0x9308b1==null||_0x458f64==null)throw new tc();const _0x4d0f74=_0x288f0f<<0x2|_0x572261>>0x4;if(_0x261954['push'](_0x4d0f74),_0x9308b1!==0x40){const _0x8a141d=_0x572261<<0x4&0xf0|_0x9308b1>>0x2;if(_0x261954['push'](_0x8a141d),_0x458f64!==0x40){const _0x38f637=_0x9308b1<<0x6&0xc0|_0x458f64;_0x261954['push'](_0x38f637);}}}return _0x261954;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x30af2e=0x0;_0x30af2e<this['ENCODED_VALS']['length'];_0x30af2e++)this['byteToCharMap_'][_0x30af2e]=this['ENCODED_VALS']['charAt'](_0x30af2e),this['charToByteMap_'][this['byteToCharMap_'][_0x30af2e]]=_0x30af2e,this['byteToCharMapWebSafe_'][_0x30af2e]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x30af2e),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x30af2e]]=_0x30af2e,_0x30af2e>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x30af2e)]=_0x30af2e,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x30af2e)]=_0x30af2e);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x8dc735){const _0x465c38=Vr(_0x8dc735);return Li['encodeByteArray'](_0x465c38,!0x0);},cn=function(_0x28eceb){return Hr(_0x28eceb)['replace'](/\./g,'');},ln=function(_0x4b07a2){try{return Li['decodeString'](_0x4b07a2,!0x0);}catch(_0x58c0fb){console['error']('base64Decode\x20failed:\x20',_0x58c0fb);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x5b02d5){return $r(void 0x0,_0x5b02d5);}function $r(_0x57a6a4,_0x451b2c){if(!(_0x451b2c instanceof Object))return _0x451b2c;switch(_0x451b2c['constructor']){case Date:const _0x27633c=_0x451b2c;return new Date(_0x27633c['getTime']());case Object:_0x57a6a4===void 0x0&&(_0x57a6a4={});break;case Array:_0x57a6a4=[];break;default:return _0x451b2c;}for(const _0x3e9eb5 in _0x451b2c)!_0x451b2c['hasOwnProperty'](_0x3e9eb5)||!ic(_0x3e9eb5)||(_0x57a6a4[_0x3e9eb5]=$r(_0x57a6a4[_0x3e9eb5],_0x451b2c[_0x3e9eb5]));return _0x57a6a4;}function ic(_0x11af9a){return _0x11af9a!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x2ce7f8=Ns['__FIREBASE_DEFAULTS__'];if(_0x2ce7f8)return JSON['parse'](_0x2ce7f8);},ac=()=>{if(typeof document>'u')return;let _0x5d7a0d;try{_0x5d7a0d=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x3d56ae=_0x5d7a0d&&ln(_0x5d7a0d[0x1]);return _0x3d56ae&&JSON['parse'](_0x3d56ae);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x3b2c34){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x3b2c34);return;}},Gr=_0x2db058=>{var _0x2959bd,_0x4e3c64;return(_0x4e3c64=(_0x2959bd=xi())==null?void 0x0:_0x2959bd['emulatorHosts'])==null?void 0x0:_0x4e3c64[_0x2db058];},cc=_0x194344=>{const _0xc68e53=Gr(_0x194344);if(!_0xc68e53)return;const _0x4559bb=_0xc68e53['lastIndexOf'](':');if(_0x4559bb<=0x0||_0x4559bb+0x1===_0xc68e53['length'])throw new Error('Invalid\x20host\x20'+_0xc68e53+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x2c580b=parseInt(_0xc68e53['substring'](_0x4559bb+0x1),0xa);return _0xc68e53[0x0]==='['?[_0xc68e53['substring'](0x1,_0x4559bb-0x1),_0x2c580b]:[_0xc68e53['substring'](0x0,_0x4559bb),_0x2c580b];},qr=()=>{var _0x398dc2;return(_0x398dc2=xi())==null?void 0x0:_0x398dc2['config'];},zr=_0x4725fb=>{var _0x4bb217;return(_0x4bb217=xi())==null?void 0x0:_0x4bb217['_'+_0x4725fb];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x102391,_0x3b6c0e)=>{this['resolve']=_0x102391,this['reject']=_0x3b6c0e;});}['wrapCallback'](_0x2c2b96){return(_0x3f9b57,_0x2156f0)=>{_0x3f9b57?this['reject'](_0x3f9b57):this['resolve'](_0x2156f0),typeof _0x2c2b96=='function'&&(this['promise']['catch'](()=>{}),_0x2c2b96['length']===0x1?_0x2c2b96(_0x3f9b57):_0x2c2b96(_0x3f9b57,_0x2156f0));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x13d4df){try{return(_0x13d4df['startsWith']('http://')||_0x13d4df['startsWith']('https://')?new URL(_0x13d4df)['hostname']:_0x13d4df)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x513673){return(await fetch(_0x513673,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x5d41c6,_0x3f2818){if(_0x5d41c6['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x5bc140={'alg':'none','type':'JWT'},_0x53b49a=_0x3f2818||'demo-project',_0x27b8b3=_0x5d41c6['iat']||0x0,_0x402254=_0x5d41c6['sub']||_0x5d41c6['user_id'];if(!_0x402254)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x50d9f3={'iss':'https://securetoken.google.com/'+_0x53b49a,'aud':_0x53b49a,'iat':_0x27b8b3,'exp':_0x27b8b3+0xe10,'auth_time':_0x27b8b3,'sub':_0x402254,'user_id':_0x402254,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x5d41c6};return[cn(JSON['stringify'](_0x5bc140)),cn(JSON['stringify'](_0x50d9f3)),'']['join']('.');}const It={};function hc(){const _0x3d1d67={'prod':[],'emulator':[]};for(const _0x1ec801 of Object['keys'](It))It[_0x1ec801]?_0x3d1d67['emulator']['push'](_0x1ec801):_0x3d1d67['prod']['push'](_0x1ec801);return _0x3d1d67;}function uc(_0x3b313a){let _0x306ee9=document['getElementById'](_0x3b313a),_0xbab363=!0x1;return _0x306ee9||(_0x306ee9=document['createElement']('div'),_0x306ee9['setAttribute']('id',_0x3b313a),_0xbab363=!0x0),{'created':_0xbab363,'element':_0x306ee9};}let Ps=!0x1;function Kr(_0x280193,_0x4587da){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x280193]===_0x4587da||It[_0x280193]||Ps)return;It[_0x280193]=_0x4587da;function _0x3c8a00(_0x32d17d){return'__firebase__banner__'+_0x32d17d;}const _0x15d337='__firebase__banner',_0x4c9d5d=hc()['prod']['length']>0x0;function _0x1b6814(){const _0x4fcd01=document['getElementById'](_0x15d337);_0x4fcd01&&_0x4fcd01['remove']();}function _0x27093d(_0x48c8fe){_0x48c8fe['style']['display']='flex',_0x48c8fe['style']['background']='#7faaf0',_0x48c8fe['style']['position']='fixed',_0x48c8fe['style']['bottom']='5px',_0x48c8fe['style']['left']='5px',_0x48c8fe['style']['padding']='.5em',_0x48c8fe['style']['borderRadius']='5px',_0x48c8fe['style']['alignItems']='center';}function _0x22fb18(_0x1801b7,_0x52c6af){_0x1801b7['setAttribute']('width','24'),_0x1801b7['setAttribute']('id',_0x52c6af),_0x1801b7['setAttribute']('height','24'),_0x1801b7['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x1801b7['setAttribute']('fill','none'),_0x1801b7['style']['marginLeft']='-6px';}function _0x2d2e25(){const _0x1e0d9d=document['createElement']('span');return _0x1e0d9d['style']['cursor']='pointer',_0x1e0d9d['style']['marginLeft']='16px',_0x1e0d9d['style']['fontSize']='24px',_0x1e0d9d['innerHTML']='\x20&times;',_0x1e0d9d['onclick']=()=>{Ps=!0x0,_0x1b6814();},_0x1e0d9d;}function _0x33b5b4(_0x1ac4cd,_0x50544d){_0x1ac4cd['setAttribute']('id',_0x50544d),_0x1ac4cd['innerText']='Learn\x20more',_0x1ac4cd['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x1ac4cd['setAttribute']('target','__blank'),_0x1ac4cd['style']['paddingLeft']='5px',_0x1ac4cd['style']['textDecoration']='underline';}function _0x204bb7(){const _0x3d91c5=uc(_0x15d337),_0x47e5ea=_0x3c8a00('text'),_0x76062=document['getElementById'](_0x47e5ea)||document['createElement']('span'),_0x2dd76e=_0x3c8a00('learnmore'),_0x30629c=document['getElementById'](_0x2dd76e)||document['createElement']('a'),_0x1ccdd3=_0x3c8a00('preprendIcon'),_0x396c75=document['getElementById'](_0x1ccdd3)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x3d91c5['created']){const _0x405eaa=_0x3d91c5['element'];_0x27093d(_0x405eaa),_0x33b5b4(_0x30629c,_0x2dd76e);const _0x56f020=_0x2d2e25();_0x22fb18(_0x396c75,_0x1ccdd3),_0x405eaa['append'](_0x396c75,_0x76062,_0x30629c,_0x56f020),document['body']['appendChild'](_0x405eaa);}_0x4c9d5d?(_0x76062['innerText']='Preview\x20backend\x20disconnected.',_0x396c75['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x396c75['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x76062['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x76062['setAttribute']('id',_0x47e5ea);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x204bb7):_0x204bb7();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x457d06=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x457d06=='object'&&_0x457d06['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x23c8a5=W();return _0x23c8a5['indexOf']('MSIE\x20')>=0x0||_0x23c8a5['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x404560,_0x57d2b3)=>{try{let _0x39643f=!0x0;const _0x251169='validate-browser-context-for-indexeddb-analytics-module',_0x112335=self['indexedDB']['open'](_0x251169);_0x112335['onsuccess']=()=>{_0x112335['result']['close'](),_0x39643f||self['indexedDB']['deleteDatabase'](_0x251169),_0x404560(!0x0);},_0x112335['onupgradeneeded']=()=>{_0x39643f=!0x1;},_0x112335['onerror']=()=>{var _0x399455;_0x57d2b3(((_0x399455=_0x112335['error'])==null?void 0x0:_0x399455['message'])||'');};}catch(_0x4be650){_0x57d2b3(_0x4be650);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x4d1ac5,_0x1944e5,_0x26bde9){super(_0x1944e5),this['code']=_0x4d1ac5,this['customData']=_0x26bde9,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x1f4679,_0x18e11e,_0x44dab2){this['service']=_0x1f4679,this['serviceName']=_0x18e11e,this['errors']=_0x44dab2;}['create'](_0x23f515,..._0x3c8e75){const _0x3d8809=_0x3c8e75[0x0]||{},_0xade82d=this['service']+'/'+_0x23f515,_0x43bfe9=this['errors'][_0x23f515],_0x2af802=_0x43bfe9?vc(_0x43bfe9,_0x3d8809):'Error',_0x2fb569=this['serviceName']+':\x20'+_0x2af802+'\x20('+_0xade82d+').';return new Se(_0xade82d,_0x2fb569,_0x3d8809);}}function vc(_0x7c7850,_0x384ff9){return _0x7c7850['replace'](Ec,(_0x36b47e,_0x530cc2)=>{const _0x2621bc=_0x384ff9[_0x530cc2];return _0x2621bc!=null?String(_0x2621bc):'<'+_0x530cc2+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x34581d){return JSON['parse'](_0x34581d);}function O(_0x5f500d){return JSON['stringify'](_0x5f500d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x5b5a5f){let _0x57056e={},_0x41d440={},_0x31bb55={},_0x3d2b8f='';try{const _0x3f67ed=_0x5b5a5f['split']('.');_0x57056e=At(ln(_0x3f67ed[0x0])||''),_0x41d440=At(ln(_0x3f67ed[0x1])||''),_0x3d2b8f=_0x3f67ed[0x2],_0x31bb55=_0x41d440['d']||{},delete _0x41d440['d'];}catch{}return{'header':_0x57056e,'claims':_0x41d440,'data':_0x31bb55,'signature':_0x3d2b8f};},Ic=function(_0x3dd7a4){const _0x4f938c=Qr(_0x3dd7a4),_0x59e620=_0x4f938c['claims'];return!!_0x59e620&&typeof _0x59e620=='object'&&_0x59e620['hasOwnProperty']('iat');},wc=function(_0xf1e2df){const _0x2705c9=Qr(_0xf1e2df)['claims'];return typeof _0x2705c9=='object'&&_0x2705c9['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x784bb3,_0x461d15){return Object['prototype']['hasOwnProperty']['call'](_0x784bb3,_0x461d15);}function De(_0xf51d2,_0x45487d){if(Object['prototype']['hasOwnProperty']['call'](_0xf51d2,_0x45487d))return _0xf51d2[_0x45487d];}function ui(_0x196e0e){for(const _0x5ee8c8 in _0x196e0e)if(Object['prototype']['hasOwnProperty']['call'](_0x196e0e,_0x5ee8c8))return!0x1;return!0x0;}function hn(_0x535e7c,_0x1f1e66,_0x55c5e6){const _0x1913d0={};for(const _0x5c442e in _0x535e7c)Object['prototype']['hasOwnProperty']['call'](_0x535e7c,_0x5c442e)&&(_0x1913d0[_0x5c442e]=_0x1f1e66['call'](_0x55c5e6,_0x535e7c[_0x5c442e],_0x5c442e,_0x535e7c));return _0x1913d0;}function Me(_0x429a3e,_0x30321f){if(_0x429a3e===_0x30321f)return!0x0;const _0x38a4f1=Object['keys'](_0x429a3e),_0x35340a=Object['keys'](_0x30321f);for(const _0x4f20ed of _0x38a4f1){if(!_0x35340a['includes'](_0x4f20ed))return!0x1;const _0x1d4e32=_0x429a3e[_0x4f20ed],_0x268226=_0x30321f[_0x4f20ed];if(Os(_0x1d4e32)&&Os(_0x268226)){if(!Me(_0x1d4e32,_0x268226))return!0x1;}else{if(_0x1d4e32!==_0x268226)return!0x1;}}for(const _0x4b4f19 of _0x35340a)if(!_0x38a4f1['includes'](_0x4b4f19))return!0x1;return!0x0;}function Os(_0x1bd591){return _0x1bd591!==null&&typeof _0x1bd591=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x31cfcf){const _0x500908=[];for(const [_0x22db83,_0x135eb0]of Object['entries'](_0x31cfcf))Array['isArray'](_0x135eb0)?_0x135eb0['forEach'](_0x37e6d1=>{_0x500908['push'](encodeURIComponent(_0x22db83)+'='+encodeURIComponent(_0x37e6d1));}):_0x500908['push'](encodeURIComponent(_0x22db83)+'='+encodeURIComponent(_0x135eb0));return _0x500908['length']?'&'+_0x500908['join']('&'):'';}function vt(_0x3ca20e){const _0x157986={};return _0x3ca20e['replace'](/^\?/,'')['split']('&')['forEach'](_0xfa27fe=>{if(_0xfa27fe){const [_0x5119b0,_0x376dbe]=_0xfa27fe['split']('=');_0x157986[decodeURIComponent(_0x5119b0)]=decodeURIComponent(_0x376dbe);}}),_0x157986;}function Et(_0x937e6f){const _0x44350e=_0x937e6f['indexOf']('?');if(!_0x44350e)return'';const _0xdf95c7=_0x937e6f['indexOf']('#',_0x44350e);return _0x937e6f['substring'](_0x44350e,_0xdf95c7>0x0?_0xdf95c7:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x30a98d=0x1;_0x30a98d<this['blockSize'];++_0x30a98d)this['pad_'][_0x30a98d]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x41dc19,_0x1276a3){_0x1276a3||(_0x1276a3=0x0);const _0x208837=this['W_'];if(typeof _0x41dc19=='string'){for(let _0x33219b=0x0;_0x33219b<0x10;_0x33219b++)_0x208837[_0x33219b]=_0x41dc19['charCodeAt'](_0x1276a3)<<0x18|_0x41dc19['charCodeAt'](_0x1276a3+0x1)<<0x10|_0x41dc19['charCodeAt'](_0x1276a3+0x2)<<0x8|_0x41dc19['charCodeAt'](_0x1276a3+0x3),_0x1276a3+=0x4;}else{for(let _0x4793de=0x0;_0x4793de<0x10;_0x4793de++)_0x208837[_0x4793de]=_0x41dc19[_0x1276a3]<<0x18|_0x41dc19[_0x1276a3+0x1]<<0x10|_0x41dc19[_0x1276a3+0x2]<<0x8|_0x41dc19[_0x1276a3+0x3],_0x1276a3+=0x4;}for(let _0x1b1f4e=0x10;_0x1b1f4e<0x50;_0x1b1f4e++){const _0x75340=_0x208837[_0x1b1f4e-0x3]^_0x208837[_0x1b1f4e-0x8]^_0x208837[_0x1b1f4e-0xe]^_0x208837[_0x1b1f4e-0x10];_0x208837[_0x1b1f4e]=(_0x75340<<0x1|_0x75340>>>0x1f)&0xffffffff;}let _0x42a1a6=this['chain_'][0x0],_0x40c5f8=this['chain_'][0x1],_0x2c509e=this['chain_'][0x2],_0x48f3fd=this['chain_'][0x3],_0x32a850=this['chain_'][0x4],_0x290e65,_0x13dada;for(let _0x1ecb8a=0x0;_0x1ecb8a<0x50;_0x1ecb8a++){_0x1ecb8a<0x28?_0x1ecb8a<0x14?(_0x290e65=_0x48f3fd^_0x40c5f8&(_0x2c509e^_0x48f3fd),_0x13dada=0x5a827999):(_0x290e65=_0x40c5f8^_0x2c509e^_0x48f3fd,_0x13dada=0x6ed9eba1):_0x1ecb8a<0x3c?(_0x290e65=_0x40c5f8&_0x2c509e|_0x48f3fd&(_0x40c5f8|_0x2c509e),_0x13dada=0x8f1bbcdc):(_0x290e65=_0x40c5f8^_0x2c509e^_0x48f3fd,_0x13dada=0xca62c1d6);const _0x19588b=(_0x42a1a6<<0x5|_0x42a1a6>>>0x1b)+_0x290e65+_0x32a850+_0x13dada+_0x208837[_0x1ecb8a]&0xffffffff;_0x32a850=_0x48f3fd,_0x48f3fd=_0x2c509e,_0x2c509e=(_0x40c5f8<<0x1e|_0x40c5f8>>>0x2)&0xffffffff,_0x40c5f8=_0x42a1a6,_0x42a1a6=_0x19588b;}this['chain_'][0x0]=this['chain_'][0x0]+_0x42a1a6&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x40c5f8&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x2c509e&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x48f3fd&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x32a850&0xffffffff;}['update'](_0x1b7a57,_0x41dd03){if(_0x1b7a57==null)return;_0x41dd03===void 0x0&&(_0x41dd03=_0x1b7a57['length']);const _0x189b1a=_0x41dd03-this['blockSize'];let _0x3ad993=0x0;const _0x195410=this['buf_'];let _0x1011a0=this['inbuf_'];for(;_0x3ad993<_0x41dd03;){if(_0x1011a0===0x0){for(;_0x3ad993<=_0x189b1a;)this['compress_'](_0x1b7a57,_0x3ad993),_0x3ad993+=this['blockSize'];}if(typeof _0x1b7a57=='string'){for(;_0x3ad993<_0x41dd03;)if(_0x195410[_0x1011a0]=_0x1b7a57['charCodeAt'](_0x3ad993),++_0x1011a0,++_0x3ad993,_0x1011a0===this['blockSize']){this['compress_'](_0x195410),_0x1011a0=0x0;break;}}else{for(;_0x3ad993<_0x41dd03;)if(_0x195410[_0x1011a0]=_0x1b7a57[_0x3ad993],++_0x1011a0,++_0x3ad993,_0x1011a0===this['blockSize']){this['compress_'](_0x195410),_0x1011a0=0x0;break;}}}this['inbuf_']=_0x1011a0,this['total_']+=_0x41dd03;}['digest'](){const _0x2db955=[];let _0x6fa2ff=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x5b1a6c=this['blockSize']-0x1;_0x5b1a6c>=0x38;_0x5b1a6c--)this['buf_'][_0x5b1a6c]=_0x6fa2ff&0xff,_0x6fa2ff/=0x100;this['compress_'](this['buf_']);let _0x62772b=0x0;for(let _0x2b07ce=0x0;_0x2b07ce<0x5;_0x2b07ce++)for(let _0x16c928=0x18;_0x16c928>=0x0;_0x16c928-=0x8)_0x2db955[_0x62772b]=this['chain_'][_0x2b07ce]>>_0x16c928&0xff,++_0x62772b;return _0x2db955;}}function Tc(_0x27dea3,_0x4bbcf1){const _0x49758d=new Sc(_0x27dea3,_0x4bbcf1);return _0x49758d['subscribe']['bind'](_0x49758d);}class Sc{constructor(_0x583249,_0x157dc1){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x157dc1,this['task']['then'](()=>{_0x583249(this);})['catch'](_0x3a02ab=>{this['error'](_0x3a02ab);});}['next'](_0x2b1ab7){this['forEachObserver'](_0x453c3f=>{_0x453c3f['next'](_0x2b1ab7);});}['error'](_0x33c559){this['forEachObserver'](_0xb77cc2=>{_0xb77cc2['error'](_0x33c559);}),this['close'](_0x33c559);}['complete'](){this['forEachObserver'](_0x40153a=>{_0x40153a['complete']();}),this['close']();}['subscribe'](_0x1808b8,_0x4d51c5,_0x1227c6){let _0x525340;if(_0x1808b8===void 0x0&&_0x4d51c5===void 0x0&&_0x1227c6===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x1808b8,['next','error','complete'])?_0x525340=_0x1808b8:_0x525340={'next':_0x1808b8,'error':_0x4d51c5,'complete':_0x1227c6},_0x525340['next']===void 0x0&&(_0x525340['next']=Jn),_0x525340['error']===void 0x0&&(_0x525340['error']=Jn),_0x525340['complete']===void 0x0&&(_0x525340['complete']=Jn);const _0x44de9e=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x525340['error'](this['finalError']):_0x525340['complete']();}catch{}}),this['observers']['push'](_0x525340),_0x44de9e;}['unsubscribeOne'](_0x275e9d){this['observers']===void 0x0||this['observers'][_0x275e9d]===void 0x0||(delete this['observers'][_0x275e9d],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x21c1f0){if(!this['finalized']){for(let _0x5cd122=0x0;_0x5cd122<this['observers']['length'];_0x5cd122++)this['sendOne'](_0x5cd122,_0x21c1f0);}}['sendOne'](_0x417f0a,_0x1576db){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x417f0a]!==void 0x0)try{_0x1576db(this['observers'][_0x417f0a]);}catch(_0x5b4262){typeof console<'u'&&console['error']&&console['error'](_0x5b4262);}});}['close'](_0x2c2fed){this['finalized']||(this['finalized']=!0x0,_0x2c2fed!==void 0x0&&(this['finalError']=_0x2c2fed),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x9973e7,_0x524901){if(typeof _0x9973e7!='object'||_0x9973e7===null)return!0x1;for(const _0x2403f6 of _0x524901)if(_0x2403f6 in _0x9973e7&&typeof _0x9973e7[_0x2403f6]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x4760b5,_0x213e04){return _0x4760b5+'\x20failed:\x20'+_0x213e04+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x4bf8ff){const _0x28538e=[];let _0x5b9487=0x0;for(let _0x577aab=0x0;_0x577aab<_0x4bf8ff['length'];_0x577aab++){let _0x350e87=_0x4bf8ff['charCodeAt'](_0x577aab);if(_0x350e87>=0xd800&&_0x350e87<=0xdbff){const _0x33d8d1=_0x350e87-0xd800;_0x577aab++,f(_0x577aab<_0x4bf8ff['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0xc360b6=_0x4bf8ff['charCodeAt'](_0x577aab)-0xdc00;_0x350e87=0x10000+(_0x33d8d1<<0xa)+_0xc360b6;}_0x350e87<0x80?_0x28538e[_0x5b9487++]=_0x350e87:_0x350e87<0x800?(_0x28538e[_0x5b9487++]=_0x350e87>>0x6|0xc0,_0x28538e[_0x5b9487++]=_0x350e87&0x3f|0x80):_0x350e87<0x10000?(_0x28538e[_0x5b9487++]=_0x350e87>>0xc|0xe0,_0x28538e[_0x5b9487++]=_0x350e87>>0x6&0x3f|0x80,_0x28538e[_0x5b9487++]=_0x350e87&0x3f|0x80):(_0x28538e[_0x5b9487++]=_0x350e87>>0x12|0xf0,_0x28538e[_0x5b9487++]=_0x350e87>>0xc&0x3f|0x80,_0x28538e[_0x5b9487++]=_0x350e87>>0x6&0x3f|0x80,_0x28538e[_0x5b9487++]=_0x350e87&0x3f|0x80);}return _0x28538e;},On=function(_0xb2db69){let _0x46d3bf=0x0;for(let _0x3efd90=0x0;_0x3efd90<_0xb2db69['length'];_0x3efd90++){const _0xc7549a=_0xb2db69['charCodeAt'](_0x3efd90);_0xc7549a<0x80?_0x46d3bf++:_0xc7549a<0x800?_0x46d3bf+=0x2:_0xc7549a>=0xd800&&_0xc7549a<=0xdbff?(_0x46d3bf+=0x4,_0x3efd90++):_0x46d3bf+=0x3;}return _0x46d3bf;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x25ef5a){return _0x25ef5a&&_0x25ef5a['_delegate']?_0x25ef5a['_delegate']:_0x25ef5a;}class Le{constructor(_0x3ec6db,_0x2bb1c6,_0x3aae62){this['name']=_0x3ec6db,this['instanceFactory']=_0x2bb1c6,this['type']=_0x3aae62,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x11648d){return this['instantiationMode']=_0x11648d,this;}['setMultipleInstances'](_0x5bf31a){return this['multipleInstances']=_0x5bf31a,this;}['setServiceProps'](_0x5c4765){return this['serviceProps']=_0x5c4765,this;}['setInstanceCreatedCallback'](_0x7eff40){return this['onInstanceCreated']=_0x7eff40,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x4683d6,_0x402ebc){this['name']=_0x4683d6,this['container']=_0x402ebc,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x7ef1c3){const _0x47172b=this['normalizeInstanceIdentifier'](_0x7ef1c3);if(!this['instancesDeferred']['has'](_0x47172b)){const _0x5530b8=new ot();if(this['instancesDeferred']['set'](_0x47172b,_0x5530b8),this['isInitialized'](_0x47172b)||this['shouldAutoInitialize']())try{const _0x13423c=this['getOrInitializeService']({'instanceIdentifier':_0x47172b});_0x13423c&&_0x5530b8['resolve'](_0x13423c);}catch{}}return this['instancesDeferred']['get'](_0x47172b)['promise'];}['getImmediate'](_0x39cca6){const _0x214431=this['normalizeInstanceIdentifier'](_0x39cca6==null?void 0x0:_0x39cca6['identifier']),_0x631386=(_0x39cca6==null?void 0x0:_0x39cca6['optional'])??!0x1;if(this['isInitialized'](_0x214431)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x214431});}catch(_0x30b5a9){if(_0x631386)return null;throw _0x30b5a9;}else{if(_0x631386)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x29c61f){if(_0x29c61f['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x29c61f['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x29c61f,!!this['shouldAutoInitialize']()){if(Nc(_0x29c61f))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x396721,_0x558067]of this['instancesDeferred']['entries']()){const _0x104ee1=this['normalizeInstanceIdentifier'](_0x396721);try{const _0x358762=this['getOrInitializeService']({'instanceIdentifier':_0x104ee1});_0x558067['resolve'](_0x358762);}catch{}}}}['clearInstance'](_0x388d78=Ne){this['instancesDeferred']['delete'](_0x388d78),this['instancesOptions']['delete'](_0x388d78),this['instances']['delete'](_0x388d78);}async['delete'](){const _0x490a94=Array['from'](this['instances']['values']());await Promise['all']([..._0x490a94['filter'](_0x222913=>'INTERNAL'in _0x222913)['map'](_0x66aa03=>_0x66aa03['INTERNAL']['delete']()),..._0x490a94['filter'](_0x104265=>'_delete'in _0x104265)['map'](_0x5f5728=>_0x5f5728['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x300ceb=Ne){return this['instances']['has'](_0x300ceb);}['getOptions'](_0x1e0f76=Ne){return this['instancesOptions']['get'](_0x1e0f76)||{};}['initialize'](_0x2e7d7f={}){const {options:_0x4f3474={}}=_0x2e7d7f,_0x149cfc=this['normalizeInstanceIdentifier'](_0x2e7d7f['instanceIdentifier']);if(this['isInitialized'](_0x149cfc))throw Error(this['name']+'('+_0x149cfc+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x449b9e=this['getOrInitializeService']({'instanceIdentifier':_0x149cfc,'options':_0x4f3474});for(const [_0x469651,_0x1fa88d]of this['instancesDeferred']['entries']()){const _0x524b92=this['normalizeInstanceIdentifier'](_0x469651);_0x149cfc===_0x524b92&&_0x1fa88d['resolve'](_0x449b9e);}return _0x449b9e;}['onInit'](_0x270808,_0x4d9db7){const _0x5c562b=this['normalizeInstanceIdentifier'](_0x4d9db7),_0x32e3e4=this['onInitCallbacks']['get'](_0x5c562b)??new Set();_0x32e3e4['add'](_0x270808),this['onInitCallbacks']['set'](_0x5c562b,_0x32e3e4);const _0x52ab29=this['instances']['get'](_0x5c562b);return _0x52ab29&&_0x270808(_0x52ab29,_0x5c562b),()=>{_0x32e3e4['delete'](_0x270808);};}['invokeOnInitCallbacks'](_0x2fea2a,_0x149fc1){const _0x4ceb65=this['onInitCallbacks']['get'](_0x149fc1);if(_0x4ceb65){for(const _0x228d98 of _0x4ceb65)try{_0x228d98(_0x2fea2a,_0x149fc1);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x2888b9,options:_0x3ff11a={}}){let _0x50a5a1=this['instances']['get'](_0x2888b9);if(!_0x50a5a1&&this['component']&&(_0x50a5a1=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x2888b9),'options':_0x3ff11a}),this['instances']['set'](_0x2888b9,_0x50a5a1),this['instancesOptions']['set'](_0x2888b9,_0x3ff11a),this['invokeOnInitCallbacks'](_0x50a5a1,_0x2888b9),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x2888b9,_0x50a5a1);}catch{}return _0x50a5a1||null;}['normalizeInstanceIdentifier'](_0x59ed22=Ne){return this['component']?this['component']['multipleInstances']?_0x59ed22:Ne:_0x59ed22;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x6bd3f3){return _0x6bd3f3===Ne?void 0x0:_0x6bd3f3;}function Nc(_0x13c13a){return _0x13c13a['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x48ef3d){this['name']=_0x48ef3d,this['providers']=new Map();}['addComponent'](_0x504ef){const _0x46a97f=this['getProvider'](_0x504ef['name']);if(_0x46a97f['isComponentSet']())throw new Error('Component\x20'+_0x504ef['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x46a97f['setComponent'](_0x504ef);}['addOrOverwriteComponent'](_0x383c03){this['getProvider'](_0x383c03['name'])['isComponentSet']()&&this['providers']['delete'](_0x383c03['name']),this['addComponent'](_0x383c03);}['getProvider'](_0x42db1b){if(this['providers']['has'](_0x42db1b))return this['providers']['get'](_0x42db1b);const _0x15182e=new Ac(_0x42db1b,this);return this['providers']['set'](_0x42db1b,_0x15182e),_0x15182e;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x3b19c7){_0x3b19c7[_0x3b19c7['DEBUG']=0x0]='DEBUG',_0x3b19c7[_0x3b19c7['VERBOSE']=0x1]='VERBOSE',_0x3b19c7[_0x3b19c7['INFO']=0x2]='INFO',_0x3b19c7[_0x3b19c7['WARN']=0x3]='WARN',_0x3b19c7[_0x3b19c7['ERROR']=0x4]='ERROR',_0x3b19c7[_0x3b19c7['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x539e64,_0x44ffea,..._0x10db1f)=>{if(_0x44ffea<_0x539e64['logLevel'])return;const _0x1da25d=new Date()['toISOString'](),_0x4e680b=Mc[_0x44ffea];if(_0x4e680b)console[_0x4e680b]('['+_0x1da25d+']\x20\x20'+_0x539e64['name']+':',..._0x10db1f);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x44ffea+')');};class Ui{constructor(_0x2cbf12){this['name']=_0x2cbf12,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x4d6405){if(!(_0x4d6405 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x4d6405+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x4d6405;}['setLogLevel'](_0x5bd608){this['_logLevel']=typeof _0x5bd608=='string'?Oc[_0x5bd608]:_0x5bd608;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x23e4f4){if(typeof _0x23e4f4!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x23e4f4;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x572a6c){this['_userLogHandler']=_0x572a6c;}['debug'](..._0x26de37){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x26de37),this['_logHandler'](this,T['DEBUG'],..._0x26de37);}['log'](..._0x2e7a40){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x2e7a40),this['_logHandler'](this,T['VERBOSE'],..._0x2e7a40);}['info'](..._0x22b35b){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x22b35b),this['_logHandler'](this,T['INFO'],..._0x22b35b);}['warn'](..._0x31474a){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x31474a),this['_logHandler'](this,T['WARN'],..._0x31474a);}['error'](..._0x142a52){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x142a52),this['_logHandler'](this,T['ERROR'],..._0x142a52);}}const xc=(_0x38eeb0,_0x23533b)=>_0x23533b['some'](_0x2d74eb=>_0x38eeb0 instanceof _0x2d74eb);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x501ab1){const _0x4d1b57=new Promise((_0x2956fb,_0xcb43e6)=>{const _0x1e17af=()=>{_0x501ab1['removeEventListener']('success',_0x1774d1),_0x501ab1['removeEventListener']('error',_0x4eec50);},_0x1774d1=()=>{_0x2956fb(_e(_0x501ab1['result'])),_0x1e17af();},_0x4eec50=()=>{_0xcb43e6(_0x501ab1['error']),_0x1e17af();};_0x501ab1['addEventListener']('success',_0x1774d1),_0x501ab1['addEventListener']('error',_0x4eec50);});return _0x4d1b57['then'](_0x22155b=>{_0x22155b instanceof IDBCursor&&Jr['set'](_0x22155b,_0x501ab1);})['catch'](()=>{}),Wi['set'](_0x4d1b57,_0x501ab1),_0x4d1b57;}function Bc(_0x22f54d){if(di['has'](_0x22f54d))return;const _0x53bc1f=new Promise((_0x45f9d2,_0x524a7c)=>{const _0x36c0be=()=>{_0x22f54d['removeEventListener']('complete',_0x71654d),_0x22f54d['removeEventListener']('error',_0x153be2),_0x22f54d['removeEventListener']('abort',_0x153be2);},_0x71654d=()=>{_0x45f9d2(),_0x36c0be();},_0x153be2=()=>{_0x524a7c(_0x22f54d['error']||new DOMException('AbortError','AbortError')),_0x36c0be();};_0x22f54d['addEventListener']('complete',_0x71654d),_0x22f54d['addEventListener']('error',_0x153be2),_0x22f54d['addEventListener']('abort',_0x153be2);});di['set'](_0x22f54d,_0x53bc1f);}let fi={'get'(_0x328f00,_0x3ab39b,_0x14217e){if(_0x328f00 instanceof IDBTransaction){if(_0x3ab39b==='done')return di['get'](_0x328f00);if(_0x3ab39b==='objectStoreNames')return _0x328f00['objectStoreNames']||Xr['get'](_0x328f00);if(_0x3ab39b==='store')return _0x14217e['objectStoreNames'][0x1]?void 0x0:_0x14217e['objectStore'](_0x14217e['objectStoreNames'][0x0]);}return _e(_0x328f00[_0x3ab39b]);},'set'(_0x44f8e4,_0x6c2683,_0x2276c3){return _0x44f8e4[_0x6c2683]=_0x2276c3,!0x0;},'has'(_0x28d6ec,_0x36fa9e){return _0x28d6ec instanceof IDBTransaction&&(_0x36fa9e==='done'||_0x36fa9e==='store')?!0x0:_0x36fa9e in _0x28d6ec;}};function Vc(_0x3c685d){fi=_0x3c685d(fi);}function Hc(_0x3a9bad){return _0x3a9bad===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x11c44a,..._0x575f44){const _0x1feb49=_0x3a9bad['call'](Zn(this),_0x11c44a,..._0x575f44);return Xr['set'](_0x1feb49,_0x11c44a['sort']?_0x11c44a['sort']():[_0x11c44a]),_e(_0x1feb49);}:Uc()['includes'](_0x3a9bad)?function(..._0x84c5c8){return _0x3a9bad['apply'](Zn(this),_0x84c5c8),_e(Jr['get'](this));}:function(..._0x371098){return _e(_0x3a9bad['apply'](Zn(this),_0x371098));};}function $c(_0x268c45){return typeof _0x268c45=='function'?Hc(_0x268c45):(_0x268c45 instanceof IDBTransaction&&Bc(_0x268c45),xc(_0x268c45,Fc())?new Proxy(_0x268c45,fi):_0x268c45);}function _e(_0xf5a237){if(_0xf5a237 instanceof IDBRequest)return Wc(_0xf5a237);if(Xn['has'](_0xf5a237))return Xn['get'](_0xf5a237);const _0x4b0ab1=$c(_0xf5a237);return _0x4b0ab1!==_0xf5a237&&(Xn['set'](_0xf5a237,_0x4b0ab1),Wi['set'](_0x4b0ab1,_0xf5a237)),_0x4b0ab1;}const Zn=_0x5779a2=>Wi['get'](_0x5779a2);function Gc(_0x25a525,_0x584798,{blocked:_0x11977d,upgrade:_0xf15114,blocking:_0x52f55e,terminated:_0x4b8f47}={}){const _0x20cf0b=indexedDB['open'](_0x25a525,_0x584798),_0x36eb40=_e(_0x20cf0b);return _0xf15114&&_0x20cf0b['addEventListener']('upgradeneeded',_0x51c776=>{_0xf15114(_e(_0x20cf0b['result']),_0x51c776['oldVersion'],_0x51c776['newVersion'],_e(_0x20cf0b['transaction']),_0x51c776);}),_0x11977d&&_0x20cf0b['addEventListener']('blocked',_0x56e3b5=>_0x11977d(_0x56e3b5['oldVersion'],_0x56e3b5['newVersion'],_0x56e3b5)),_0x36eb40['then'](_0x361d2a=>{_0x4b8f47&&_0x361d2a['addEventListener']('close',()=>_0x4b8f47()),_0x52f55e&&_0x361d2a['addEventListener']('versionchange',_0x4fa42f=>_0x52f55e(_0x4fa42f['oldVersion'],_0x4fa42f['newVersion'],_0x4fa42f));})['catch'](()=>{}),_0x36eb40;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x4b8374,_0x162183){if(!(_0x4b8374 instanceof IDBDatabase&&!(_0x162183 in _0x4b8374)&&typeof _0x162183=='string'))return;if(ei['get'](_0x162183))return ei['get'](_0x162183);const _0x13ec1e=_0x162183['replace'](/FromIndex$/,''),_0x2fe3ad=_0x162183!==_0x13ec1e,_0x1dfdcf=zc['includes'](_0x13ec1e);if(!(_0x13ec1e in(_0x2fe3ad?IDBIndex:IDBObjectStore)['prototype'])||!(_0x1dfdcf||qc['includes'](_0x13ec1e)))return;const _0x3a21bc=async function(_0x2117b3,..._0x4fea97){const _0x3cf295=this['transaction'](_0x2117b3,_0x1dfdcf?'readwrite':'readonly');let _0x4565d4=_0x3cf295['store'];return _0x2fe3ad&&(_0x4565d4=_0x4565d4['index'](_0x4fea97['shift']())),(await Promise['all']([_0x4565d4[_0x13ec1e](..._0x4fea97),_0x1dfdcf&&_0x3cf295['done']]))[0x0];};return ei['set'](_0x162183,_0x3a21bc),_0x3a21bc;}Vc(_0x61fd5=>({..._0x61fd5,'get':(_0x45771e,_0x3f4c04,_0x517f3a)=>Ls(_0x45771e,_0x3f4c04)||_0x61fd5['get'](_0x45771e,_0x3f4c04,_0x517f3a),'has':(_0x4ad7ba,_0x63062b)=>!!Ls(_0x4ad7ba,_0x63062b)||_0x61fd5['has'](_0x4ad7ba,_0x63062b)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x11b5e2){this['container']=_0x11b5e2;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x1b598b=>{if(Kc(_0x1b598b)){const _0x5667d8=_0x1b598b['getImmediate']();return _0x5667d8['library']+'/'+_0x5667d8['version'];}else return null;})['filter'](_0x1b7d59=>_0x1b7d59)['join']('\x20');}}function Kc(_0xe948f6){const _0x492f79=_0xe948f6['getComponent']();return(_0x492f79==null?void 0x0:_0x492f79['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x116677,_0x3057e3){try{_0x116677['container']['addComponent'](_0x3057e3);}catch(_0x4e6eb8){oe['debug']('Component\x20'+_0x3057e3['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x116677['name'],_0x4e6eb8);}}function Ze(_0x3ba425){const _0x7088e7=_0x3ba425['name'];if(mi['has'](_0x7088e7))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x7088e7+'.'),!0x1;mi['set'](_0x7088e7,_0x3ba425);for(const _0x3afdb4 of xe['values']())Fs(_0x3afdb4,_0x3ba425);for(const _0x1ca042 of gi['values']())Fs(_0x1ca042,_0x3ba425);return!0x0;}function Bi(_0x117ae3,_0x5b417e){const _0x5ad860=_0x117ae3['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x5ad860&&_0x5ad860['triggerHeartbeat'](),_0x117ae3['container']['getProvider'](_0x5b417e);}function $(_0x328d1c){return _0x328d1c==null?!0x1:_0x328d1c['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x3bd721,_0x56dc81,_0x1c8553){this['_isDeleted']=!0x1,this['_options']={..._0x3bd721},this['_config']={..._0x56dc81},this['_name']=_0x56dc81['name'],this['_automaticDataCollectionEnabled']=_0x56dc81['automaticDataCollectionEnabled'],this['_container']=_0x1c8553,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x345b1a){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x345b1a;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x55d0dd){this['_isDeleted']=_0x55d0dd;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x4866bf,_0xa47c86={}){let _0x36fa08=_0x4866bf;typeof _0xa47c86!='object'&&(_0xa47c86={'name':_0xa47c86});const _0x3f0c84={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0xa47c86},_0x855ac5=_0x3f0c84['name'];if(typeof _0x855ac5!='string'||!_0x855ac5)throw ge['create']('bad-app-name',{'appName':String(_0x855ac5)});if(_0x36fa08||(_0x36fa08=qr()),!_0x36fa08)throw ge['create']('no-options');const _0xa21bd0=xe['get'](_0x855ac5);if(_0xa21bd0){if(Me(_0x36fa08,_0xa21bd0['options'])&&Me(_0x3f0c84,_0xa21bd0['config']))return _0xa21bd0;throw ge['create']('duplicate-app',{'appName':_0x855ac5});}const _0x16b696=new Pc(_0x855ac5);for(const _0xa83c84 of mi['values']())_0x16b696['addComponent'](_0xa83c84);const _0x243a44=new Tl(_0x36fa08,_0x3f0c84,_0x16b696);return xe['set'](_0x855ac5,_0x243a44),_0x243a44;}function Zr(_0x3cc3f3=_i){const _0x23cd6f=xe['get'](_0x3cc3f3);if(!_0x23cd6f&&_0x3cc3f3===_i&&qr())return Sl();if(!_0x23cd6f)throw ge['create']('no-app',{'appName':_0x3cc3f3});return _0x23cd6f;}function f_(){return Array['from'](xe['values']());}async function p_(_0x478dc6){let _0x143380=!0x1;const _0x2327c2=_0x478dc6['name'];xe['has'](_0x2327c2)?(_0x143380=!0x0,xe['delete'](_0x2327c2)):gi['has'](_0x2327c2)&&_0x478dc6['decRefCount']()<=0x0&&(gi['delete'](_0x2327c2),_0x143380=!0x0),_0x143380&&(await Promise['all'](_0x478dc6['container']['getProviders']()['map'](_0x2617d1=>_0x2617d1['delete']())),_0x478dc6['isDeleted']=!0x0);}function me(_0x4a5fce,_0x1cf0eb,_0x3c0aaa){let _0x56d1cb=wl[_0x4a5fce]??_0x4a5fce;_0x3c0aaa&&(_0x56d1cb+='-'+_0x3c0aaa);const _0x1c9173=_0x56d1cb['match'](/\s|\//),_0x21edb1=_0x1cf0eb['match'](/\s|\//);if(_0x1c9173||_0x21edb1){const _0x79e471=['Unable\x20to\x20register\x20library\x20\x22'+_0x56d1cb+'\x22\x20with\x20version\x20\x22'+_0x1cf0eb+'\x22:'];_0x1c9173&&_0x79e471['push']('library\x20name\x20\x22'+_0x56d1cb+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x1c9173&&_0x21edb1&&_0x79e471['push']('and'),_0x21edb1&&_0x79e471['push']('version\x20name\x20\x22'+_0x1cf0eb+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x79e471['join']('\x20'));return;}Ze(new Le(_0x56d1cb+'-version',()=>({'library':_0x56d1cb,'version':_0x1cf0eb}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x45863a,_0x3785af)=>{switch(_0x3785af){case 0x0:try{_0x45863a['createObjectStore'](kt);}catch(_0x444fd9){console['warn'](_0x444fd9);}}}})['catch'](_0x504f46=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x504f46['message']});})),ti;}async function Al(_0x27b295){try{const _0x2797a7=(await eo())['transaction'](kt),_0x5f22c7=await _0x2797a7['objectStore'](kt)['get'](to(_0x27b295));return await _0x2797a7['done'],_0x5f22c7;}catch(_0x5269a3){if(_0x5269a3 instanceof Se)oe['warn'](_0x5269a3['message']);else{const _0x3386de=ge['create']('idb-get',{'originalErrorMessage':_0x5269a3==null?void 0x0:_0x5269a3['message']});oe['warn'](_0x3386de['message']);}}}async function Us(_0x2d7f16,_0x1fd07e){try{const _0x29bc9d=(await eo())['transaction'](kt,'readwrite');await _0x29bc9d['objectStore'](kt)['put'](_0x1fd07e,to(_0x2d7f16)),await _0x29bc9d['done'];}catch(_0xd01a55){if(_0xd01a55 instanceof Se)oe['warn'](_0xd01a55['message']);else{const _0x122124=ge['create']('idb-set',{'originalErrorMessage':_0xd01a55==null?void 0x0:_0xd01a55['message']});oe['warn'](_0x122124['message']);}}}function to(_0x122efe){return _0x122efe['name']+'!'+_0x122efe['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x1597c3){this['container']=_0x1597c3,this['_heartbeatsCache']=null;const _0x133ce5=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x133ce5),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x46f7a5=>(this['_heartbeatsCache']=_0x46f7a5,_0x46f7a5));}async['triggerHeartbeat'](){var _0x1b8bea,_0x2f93da;try{const _0x263c0b=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3fd19a=Ws();if(((_0x1b8bea=this['_heartbeatsCache'])==null?void 0x0:_0x1b8bea['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x2f93da=this['_heartbeatsCache'])==null?void 0x0:_0x2f93da['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3fd19a||this['_heartbeatsCache']['heartbeats']['some'](_0x129dcb=>_0x129dcb['date']===_0x3fd19a))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3fd19a,'agent':_0x263c0b}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x9f4a7c=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x9f4a7c,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x2cf602){oe['warn'](_0x2cf602);}}async['getHeartbeatsHeader'](){var _0x4f875a;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x4f875a=this['_heartbeatsCache'])==null?void 0x0:_0x4f875a['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x4a6b25=Ws(),{heartbeatsToSend:_0x29444a,unsentEntries:_0x1bdf39}=Ol(this['_heartbeatsCache']['heartbeats']),_0x2fadaa=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x29444a}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x4a6b25,_0x1bdf39['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x1bdf39,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x2fadaa;}catch(_0x476aa0){return oe['warn'](_0x476aa0),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x27bf77,_0x160e57=kl){const _0x1fe0dd=[];let _0x320508=_0x27bf77['slice']();for(const _0x152018 of _0x27bf77){const _0x30ae7a=_0x1fe0dd['find'](_0x4cdeff=>_0x4cdeff['agent']===_0x152018['agent']);if(_0x30ae7a){if(_0x30ae7a['dates']['push'](_0x152018['date']),Bs(_0x1fe0dd)>_0x160e57){_0x30ae7a['dates']['pop']();break;}}else{if(_0x1fe0dd['push']({'agent':_0x152018['agent'],'dates':[_0x152018['date']]}),Bs(_0x1fe0dd)>_0x160e57){_0x1fe0dd['pop']();break;}}_0x320508=_0x320508['slice'](0x1);}return{'heartbeatsToSend':_0x1fe0dd,'unsentEntries':_0x320508};}class Dl{constructor(_0x52127a){this['app']=_0x52127a,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x8f08c7=await Al(this['app']);return _0x8f08c7!=null&&_0x8f08c7['heartbeats']?_0x8f08c7:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x585397){if(await this['_canUseIndexedDBPromise']){const _0x45ead6=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x585397['lastSentHeartbeatDate']??_0x45ead6['lastSentHeartbeatDate'],'heartbeats':_0x585397['heartbeats']});}else return;}async['add'](_0x5df72b){if(await this['_canUseIndexedDBPromise']){const _0x501be5=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x5df72b['lastSentHeartbeatDate']??_0x501be5['lastSentHeartbeatDate'],'heartbeats':[..._0x501be5['heartbeats'],..._0x5df72b['heartbeats']]});}else return;}}function Bs(_0x403e0c){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x403e0c}))['length'];}function Ml(_0x2ab131){if(_0x2ab131['length']===0x0)return-0x1;let _0x1b14fc=0x0,_0x1eb593=_0x2ab131[0x0]['date'];for(let _0x328e83=0x1;_0x328e83<_0x2ab131['length'];_0x328e83++)_0x2ab131[_0x328e83]['date']<_0x1eb593&&(_0x1eb593=_0x2ab131[_0x328e83]['date'],_0x1b14fc=_0x328e83);return _0x1b14fc;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x1bd276){Ze(new Le('platform-logger',_0xd91b88=>new jc(_0xd91b88),'PRIVATE')),Ze(new Le('heartbeat',_0x37308e=>new Pl(_0x37308e),'PRIVATE')),me(pi,xs,_0x1bd276),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x559105){no=_0x559105;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x4f4224){this['domStorage_']=_0x4f4224,this['prefix_']='firebase:';}['set'](_0x787a4,_0x12fd75){_0x12fd75==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x787a4)):this['domStorage_']['setItem'](this['prefixedName_'](_0x787a4),O(_0x12fd75));}['get'](_0x5ee277){const _0x9933d1=this['domStorage_']['getItem'](this['prefixedName_'](_0x5ee277));return _0x9933d1==null?null:At(_0x9933d1);}['remove'](_0x5c72bc){this['domStorage_']['removeItem'](this['prefixedName_'](_0x5c72bc));}['prefixedName_'](_0x40803e){return this['prefix_']+_0x40803e;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x1f1da5,_0x4f9f36){_0x4f9f36==null?delete this['cache_'][_0x1f1da5]:this['cache_'][_0x1f1da5]=_0x4f9f36;}['get'](_0x3f33dd){return J(this['cache_'],_0x3f33dd)?this['cache_'][_0x3f33dd]:null;}['remove'](_0xf28a39){delete this['cache_'][_0xf28a39];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x1f5df8){try{if(typeof window<'u'&&typeof window[_0x1f5df8]<'u'){const _0x3c9e02=window[_0x1f5df8];return _0x3c9e02['setItem']('firebase:sentinel','cache'),_0x3c9e02['removeItem']('firebase:sentinel'),new Wl(_0x3c9e02);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x9f84e7=0x1;return function(){return _0x9f84e7++;};}()),ro=function(_0x4a6d8b){const _0x1efec1=Rc(_0x4a6d8b),_0x50995f=new Cc();_0x50995f['update'](_0x1efec1);const _0x24a82d=_0x50995f['digest']();return Li['encodeByteArray'](_0x24a82d);},Vt=function(..._0x2cd6d1){let _0xd0618c='';for(let _0xd9d7e6=0x0;_0xd9d7e6<_0x2cd6d1['length'];_0xd9d7e6++){const _0x4dc1c6=_0x2cd6d1[_0xd9d7e6];Array['isArray'](_0x4dc1c6)||_0x4dc1c6&&typeof _0x4dc1c6=='object'&&typeof _0x4dc1c6['length']=='number'?_0xd0618c+=Vt['apply'](null,_0x4dc1c6):typeof _0x4dc1c6=='object'?_0xd0618c+=O(_0x4dc1c6):_0xd0618c+=_0x4dc1c6,_0xd0618c+='\x20';}return _0xd0618c;};let wt=null,Gs=!0x0;const Hl=function(_0x74e54e,_0x592a66){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x4a8d30){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x295588=Vt['apply'](null,_0x4a8d30);wt(_0x295588);}},Ht=function(_0x5925a5){return function(..._0x44fda2){L(_0x5925a5,..._0x44fda2);};},yi=function(..._0x30863c){const _0x152b27='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x30863c);Ye['error'](_0x152b27);},ae=function(..._0x746ee4){const _0x2ff02c='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x746ee4);throw Ye['error'](_0x2ff02c),new Error(_0x2ff02c);},U=function(..._0x2c5c41){const _0x254270='FIREBASE\x20WARNING:\x20'+Vt(..._0x2c5c41);Ye['warn'](_0x254270);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0xfc5440){return typeof _0xfc5440=='number'&&(_0xfc5440!==_0xfc5440||_0xfc5440===Number['POSITIVE_INFINITY']||_0xfc5440===Number['NEGATIVE_INFINITY']);},Gl=function(_0x1f6b57){if(document['readyState']==='complete')_0x1f6b57();else{let _0x22a44f=!0x1;const _0x3405e2=function(){if(!document['body']){setTimeout(_0x3405e2,Math['floor'](0xa));return;}_0x22a44f||(_0x22a44f=!0x0,_0x1f6b57());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x3405e2,!0x1),window['addEventListener']('load',_0x3405e2,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x3405e2();}),window['attachEvent']('onload',_0x3405e2));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x792b6,_0x493f60){if(_0x792b6===_0x493f60)return 0x0;if(_0x792b6===Fe||_0x493f60===Ie)return-0x1;if(_0x493f60===Fe||_0x792b6===Ie)return 0x1;{const _0x4a8ffa=qs(_0x792b6),_0xce2e55=qs(_0x493f60);return _0x4a8ffa!==null?_0xce2e55!==null?_0x4a8ffa-_0xce2e55===0x0?_0x792b6['length']-_0x493f60['length']:_0x4a8ffa-_0xce2e55:-0x1:_0xce2e55!==null?0x1:_0x792b6<_0x493f60?-0x1:0x1;}},ql=function(_0x12e4b4,_0x4cf24c){return _0x12e4b4===_0x4cf24c?0x0:_0x12e4b4<_0x4cf24c?-0x1:0x1;},_t=function(_0x11dfcb,_0x32ea4c){if(_0x32ea4c&&_0x11dfcb in _0x32ea4c)return _0x32ea4c[_0x11dfcb];throw new Error('Missing\x20required\x20key\x20('+_0x11dfcb+')\x20in\x20object:\x20'+O(_0x32ea4c));},Hi=function(_0x1a82bf){if(typeof _0x1a82bf!='object'||_0x1a82bf===null)return O(_0x1a82bf);const _0x4abe1b=[];for(const _0x5bb233 in _0x1a82bf)_0x4abe1b['push'](_0x5bb233);_0x4abe1b['sort']();let _0x383b60='{';for(let _0x48ad9f=0x0;_0x48ad9f<_0x4abe1b['length'];_0x48ad9f++)_0x48ad9f!==0x0&&(_0x383b60+=','),_0x383b60+=O(_0x4abe1b[_0x48ad9f]),_0x383b60+=':',_0x383b60+=Hi(_0x1a82bf[_0x4abe1b[_0x48ad9f]]);return _0x383b60+='}',_0x383b60;},oo=function(_0xc0752c,_0x2f90fb){const _0x356f5c=_0xc0752c['length'];if(_0x356f5c<=_0x2f90fb)return[_0xc0752c];const _0x11a745=[];for(let _0x1b5dc2=0x0;_0x1b5dc2<_0x356f5c;_0x1b5dc2+=_0x2f90fb)_0x1b5dc2+_0x2f90fb>_0x356f5c?_0x11a745['push'](_0xc0752c['substring'](_0x1b5dc2,_0x356f5c)):_0x11a745['push'](_0xc0752c['substring'](_0x1b5dc2,_0x1b5dc2+_0x2f90fb));return _0x11a745;};function x(_0x5010fa,_0x4ba861){for(const _0x46ff08 in _0x5010fa)_0x5010fa['hasOwnProperty'](_0x46ff08)&&_0x4ba861(_0x46ff08,_0x5010fa[_0x46ff08]);}const ao=function(_0x5f4d53){f(!Vi(_0x5f4d53),'Invalid\x20JSON\x20number');const _0x5d30f0=0xb,_0x5b7ef0=0x34,_0x55036d=(0x1<<_0x5d30f0-0x1)-0x1;let _0x4aa761,_0x940e86,_0xf6bff5,_0xbea90,_0x27568f;_0x5f4d53===0x0?(_0x940e86=0x0,_0xf6bff5=0x0,_0x4aa761=0x1/_0x5f4d53===-0x1/0x0?0x1:0x0):(_0x4aa761=_0x5f4d53<0x0,_0x5f4d53=Math['abs'](_0x5f4d53),_0x5f4d53>=Math['pow'](0x2,0x1-_0x55036d)?(_0xbea90=Math['min'](Math['floor'](Math['log'](_0x5f4d53)/Math['LN2']),_0x55036d),_0x940e86=_0xbea90+_0x55036d,_0xf6bff5=Math['round'](_0x5f4d53*Math['pow'](0x2,_0x5b7ef0-_0xbea90)-Math['pow'](0x2,_0x5b7ef0))):(_0x940e86=0x0,_0xf6bff5=Math['round'](_0x5f4d53/Math['pow'](0x2,0x1-_0x55036d-_0x5b7ef0))));const _0x52bda2=[];for(_0x27568f=_0x5b7ef0;_0x27568f;_0x27568f-=0x1)_0x52bda2['push'](_0xf6bff5%0x2?0x1:0x0),_0xf6bff5=Math['floor'](_0xf6bff5/0x2);for(_0x27568f=_0x5d30f0;_0x27568f;_0x27568f-=0x1)_0x52bda2['push'](_0x940e86%0x2?0x1:0x0),_0x940e86=Math['floor'](_0x940e86/0x2);_0x52bda2['push'](_0x4aa761?0x1:0x0),_0x52bda2['reverse']();const _0x3f2f2e=_0x52bda2['join']('');let _0x23cbd0='';for(_0x27568f=0x0;_0x27568f<0x40;_0x27568f+=0x8){let _0x2a3472=parseInt(_0x3f2f2e['substr'](_0x27568f,0x8),0x2)['toString'](0x10);_0x2a3472['length']===0x1&&(_0x2a3472='0'+_0x2a3472),_0x23cbd0=_0x23cbd0+_0x2a3472;}return _0x23cbd0['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x59164b,_0x3ae535){let _0xfda8cc='Unknown\x20Error';_0x59164b==='too_big'?_0xfda8cc='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x59164b==='permission_denied'?_0xfda8cc='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x59164b==='unavailable'&&(_0xfda8cc='The\x20service\x20is\x20unavailable');const _0x398b18=new Error(_0x59164b+'\x20at\x20'+_0x3ae535['_path']['toString']()+':\x20'+_0xfda8cc);return _0x398b18['code']=_0x59164b['toUpperCase'](),_0x398b18;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x1ba6ea){if(Yl['test'](_0x1ba6ea)){const _0x3f5d60=Number(_0x1ba6ea);if(_0x3f5d60>=Ql&&_0x3f5d60<=Jl)return _0x3f5d60;}return null;},ht=function(_0x5bc0f6){try{_0x5bc0f6();}catch(_0x12c470){setTimeout(()=>{const _0x57b93b=_0x12c470['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x57b93b),_0x12c470;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x13f927,_0x363cc8){const _0x3c1029=setTimeout(_0x13f927,_0x363cc8);return typeof _0x3c1029=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x3c1029):typeof _0x3c1029=='object'&&_0x3c1029['unref']&&_0x3c1029['unref'](),_0x3c1029;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x319b0d,_0x3e4b3d){this['appCheckProvider']=_0x3e4b3d,this['appName']=_0x319b0d['name'],$(_0x319b0d)&&_0x319b0d['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x319b0d['settings']['appCheckToken']),this['appCheck']=_0x3e4b3d==null?void 0x0:_0x3e4b3d['getImmediate']({'optional':!0x0}),this['appCheck']||_0x3e4b3d==null||_0x3e4b3d['get']()['then'](_0x3fa4ce=>this['appCheck']=_0x3fa4ce);}['getToken'](_0x42bc39){if(this['serverAppAppCheckToken']){if(_0x42bc39)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x42bc39):new Promise((_0x39065c,_0x933c74)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x42bc39)['then'](_0x39065c,_0x933c74):_0x39065c(null);},0x0);});}['addTokenChangeListener'](_0x407586){var _0x3915c3;(_0x3915c3=this['appCheckProvider'])==null||_0x3915c3['get']()['then'](_0x2d8a2c=>_0x2d8a2c['addTokenListener'](_0x407586));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x39352b,_0x520037,_0x110082){this['appName_']=_0x39352b,this['firebaseOptions_']=_0x520037,this['authProvider_']=_0x110082,this['auth_']=null,this['auth_']=_0x110082['getImmediate']({'optional':!0x0}),this['auth_']||_0x110082['onInit'](_0x4a74c9=>this['auth_']=_0x4a74c9);}['getToken'](_0x806ab4){return this['auth_']?this['auth_']['getToken'](_0x806ab4)['catch'](_0x1d6101=>_0x1d6101&&_0x1d6101['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x1d6101)):new Promise((_0x1fc3f9,_0xd4637f)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x806ab4)['then'](_0x1fc3f9,_0xd4637f):_0x1fc3f9(null);},0x0);});}['addTokenChangeListener'](_0x5c9c9a){this['auth_']?this['auth_']['addAuthTokenListener'](_0x5c9c9a):this['authProvider_']['get']()['then'](_0x3d5014=>_0x3d5014['addAuthTokenListener'](_0x5c9c9a));}['removeTokenChangeListener'](_0x59c9e8){this['authProvider_']['get']()['then'](_0xbe3aa=>_0xbe3aa['removeAuthTokenListener'](_0x59c9e8));}['notifyForInvalidToken'](){let _0x14d785='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x14d785+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x14d785+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x14d785+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x14d785);}}class nn{constructor(_0x375a71){this['accessToken']=_0x375a71;}['getToken'](_0x12c0ab){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x31934f){_0x31934f(this['accessToken']);}['removeTokenChangeListener'](_0xc6c1d1){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x3702a3,_0x1e42f7,_0x4f57cd,_0x145a43,_0x39aedb=!0x1,_0x467180='',_0x4802ce=!0x1,_0x1acec2=!0x1,_0x52819c=null){this['secure']=_0x1e42f7,this['namespace']=_0x4f57cd,this['webSocketOnly']=_0x145a43,this['nodeAdmin']=_0x39aedb,this['persistenceKey']=_0x467180,this['includeNamespaceInQueryParams']=_0x4802ce,this['isUsingEmulator']=_0x1acec2,this['emulatorOptions']=_0x52819c,this['_host']=_0x3702a3['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x3702a3)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x53d17b){_0x53d17b!==this['internalHost']&&(this['internalHost']=_0x53d17b,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x1773c5=this['toURLString']();return this['persistenceKey']&&(_0x1773c5+='<'+this['persistenceKey']+'>'),_0x1773c5;}['toURLString'](){const _0xdce9c1=this['secure']?'https://':'http://',_0x339985=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0xdce9c1+this['host']+'/'+_0x339985;}}function th(_0x7a1f1){return _0x7a1f1['host']!==_0x7a1f1['internalHost']||_0x7a1f1['isCustomHost']()||_0x7a1f1['includeNamespaceInQueryParams'];}function vo(_0x4c47c4,_0x5b457b,_0x24fdd0){f(typeof _0x5b457b=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x24fdd0=='object','typeof\x20params\x20must\x20==\x20object');let _0x4d3fdc;if(_0x5b457b===go)_0x4d3fdc=(_0x4c47c4['secure']?'wss://':'ws://')+_0x4c47c4['internalHost']+'/.ws?';else{if(_0x5b457b===mo)_0x4d3fdc=(_0x4c47c4['secure']?'https://':'http://')+_0x4c47c4['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x5b457b);}th(_0x4c47c4)&&(_0x24fdd0['ns']=_0x4c47c4['namespace']);const _0x6df6b0=[];return x(_0x24fdd0,(_0x5ee226,_0x251332)=>{_0x6df6b0['push'](_0x5ee226+'='+_0x251332);}),_0x4d3fdc+_0x6df6b0['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x36dff1,_0x25220d=0x1){J(this['counters_'],_0x36dff1)||(this['counters_'][_0x36dff1]=0x0),this['counters_'][_0x36dff1]+=_0x25220d;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x3b53cb){const _0x233eae=_0x3b53cb['toString']();return ni[_0x233eae]||(ni[_0x233eae]=new nh()),ni[_0x233eae];}function ih(_0x32cd0e,_0x45420b){const _0x542a35=_0x32cd0e['toString']();return ii[_0x542a35]||(ii[_0x542a35]=_0x45420b()),ii[_0x542a35];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x4036c8){this['onMessage_']=_0x4036c8,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x5557f3,_0x2f6c56){this['closeAfterResponse']=_0x5557f3,this['onClose']=_0x2f6c56,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x54c116,_0x39f4ed){for(this['pendingResponses'][_0x54c116]=_0x39f4ed;this['pendingResponses'][this['currentResponseNum']];){const _0x510cd6=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0xa23c13=0x0;_0xa23c13<_0x510cd6['length'];++_0xa23c13)_0x510cd6[_0xa23c13]&&ht(()=>{this['onMessage_'](_0x510cd6[_0xa23c13]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x4466c0,_0x2589e2,_0x2ce4ea,_0x3ac659,_0x87259a,_0x3c4fe0,_0x223cd4){this['connId']=_0x4466c0,this['repoInfo']=_0x2589e2,this['applicationId']=_0x2ce4ea,this['appCheckToken']=_0x3ac659,this['authToken']=_0x87259a,this['transportSessionId']=_0x3c4fe0,this['lastSessionId']=_0x223cd4,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x4466c0),this['stats_']=Gi(_0x2589e2),this['urlFn']=_0xe4d676=>(this['appCheckToken']&&(_0xe4d676[vi]=this['appCheckToken']),vo(_0x2589e2,mo,_0xe4d676));}['open'](_0x34c3b4,_0x318fbb){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x318fbb,this['myPacketOrderer']=new sh(_0x34c3b4),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x3b793f)=>{const [_0x1a5941,_0x114544,_0x35ef06,_0x39fd7f,_0x2ed2b7]=_0x3b793f;if(this['incrementIncomingBytes_'](_0x3b793f),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x1a5941===zs)this['id']=_0x114544,this['password']=_0x35ef06;else{if(_0x1a5941===rh)_0x114544?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x114544,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x1a5941);}}},(..._0x29989c)=>{const [_0x4ec488,_0x3205cb]=_0x29989c;this['incrementIncomingBytes_'](_0x29989c),this['myPacketOrderer']['handleResponse'](_0x4ec488,_0x3205cb);},()=>{this['onClosed_']();},this['urlFn']);const _0x13b343={};_0x13b343[zs]='t',_0x13b343[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x13b343[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x13b343[co]=$i,this['transportSessionId']&&(_0x13b343[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x13b343[po]=this['lastSessionId']),this['applicationId']&&(_0x13b343[_o]=this['applicationId']),this['appCheckToken']&&(_0x13b343[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x13b343[ho]=uo);const _0x4e4b2f=this['urlFn'](_0x13b343);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4e4b2f),this['scriptTagHolder']['addTag'](_0x4e4b2f,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x1fd7cd){const _0xf44b2e=O(_0x1fd7cd);this['bytesSent']+=_0xf44b2e['length'],this['stats_']['incrementCounter']('bytes_sent',_0xf44b2e['length']);const _0xbcd6be=Hr(_0xf44b2e),_0x5c9853=oo(_0xbcd6be,fh);for(let _0x5d0df2=0x0;_0x5d0df2<_0x5c9853['length'];_0x5d0df2++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x5c9853['length'],_0x5c9853[_0x5d0df2]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x8429c0,_0x48aa31){this['myDisconnFrame']=document['createElement']('iframe');const _0x465f91={};_0x465f91[dh]='t',_0x465f91[Eo]=_0x8429c0,_0x465f91[Io]=_0x48aa31,this['myDisconnFrame']['src']=this['urlFn'](_0x465f91),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x2115a4){const _0x5add1c=O(_0x2115a4)['length'];this['bytesReceived']+=_0x5add1c,this['stats_']['incrementCounter']('bytes_received',_0x5add1c);}}class qi{constructor(_0x1c7565,_0x2a7321,_0x1f472a,_0xb7750a){this['onDisconnect']=_0x1f472a,this['urlFn']=_0xb7750a,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x1c7565,window[ah+this['uniqueCallbackIdentifier']]=_0x2a7321,this['myIFrame']=qi['createIFrame_']();let _0xafd109='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0xafd109='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x3d083d='<html><body>'+_0xafd109+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x3d083d),this['myIFrame']['doc']['close']();}catch(_0x3e2608){L('frame\x20writing\x20exception'),_0x3e2608['stack']&&L(_0x3e2608['stack']),L(_0x3e2608);}}}static['createIFrame_'](){const _0x6a339b=document['createElement']('iframe');if(_0x6a339b['style']['display']='none',document['body']){document['body']['appendChild'](_0x6a339b);try{_0x6a339b['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x1843f9=document['domain'];_0x6a339b['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x1843f9+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x6a339b['contentDocument']?_0x6a339b['doc']=_0x6a339b['contentDocument']:_0x6a339b['contentWindow']?_0x6a339b['doc']=_0x6a339b['contentWindow']['document']:_0x6a339b['document']&&(_0x6a339b['doc']=_0x6a339b['document']),_0x6a339b;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x547c41=this['onDisconnect'];_0x547c41&&(this['onDisconnect']=null,_0x547c41());}['startLongPoll'](_0x13bcfc,_0x3b9fcd){for(this['myID']=_0x13bcfc,this['myPW']=_0x3b9fcd,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x1b3995={};_0x1b3995[Eo]=this['myID'],_0x1b3995[Io]=this['myPW'],_0x1b3995[wo]=this['currentSerial'];let _0x401c06=this['urlFn'](_0x1b3995),_0x2c6177='',_0x4b3164=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x2c6177['length']<=Co;){const _0x46cc27=this['pendingSegs']['shift']();_0x2c6177=_0x2c6177+'&'+lh+_0x4b3164+'='+_0x46cc27['seg']+'&'+hh+_0x4b3164+'='+_0x46cc27['ts']+'&'+uh+_0x4b3164+'='+_0x46cc27['d'],_0x4b3164++;}return _0x401c06=_0x401c06+_0x2c6177,this['addLongPollTag_'](_0x401c06,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x1f193e,_0x582e4d,_0x30efab){this['pendingSegs']['push']({'seg':_0x1f193e,'ts':_0x582e4d,'d':_0x30efab}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x452849,_0x82e747){this['outstandingRequests']['add'](_0x82e747);const _0x498ae3=()=>{this['outstandingRequests']['delete'](_0x82e747),this['newRequest_']();},_0x44ad90=setTimeout(_0x498ae3,Math['floor'](ph)),_0x399a57=()=>{clearTimeout(_0x44ad90),_0x498ae3();};this['addTag'](_0x452849,_0x399a57);}['addTag'](_0x2a9d00,_0x3fb131){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x4defdc=this['myIFrame']['doc']['createElement']('script');_0x4defdc['type']='text/javascript',_0x4defdc['async']=!0x0,_0x4defdc['src']=_0x2a9d00,_0x4defdc['onload']=_0x4defdc['onreadystatechange']=function(){const _0x5539c5=_0x4defdc['readyState'];(!_0x5539c5||_0x5539c5==='loaded'||_0x5539c5==='complete')&&(_0x4defdc['onload']=_0x4defdc['onreadystatechange']=null,_0x4defdc['parentNode']&&_0x4defdc['parentNode']['removeChild'](_0x4defdc),_0x3fb131());},_0x4defdc['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x2a9d00),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x4defdc);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0xe90571,_0x46a433,_0x24171c,_0x506baa,_0x428ed1,_0x3dfd72,_0x5bc4d8){this['connId']=_0xe90571,this['applicationId']=_0x24171c,this['appCheckToken']=_0x506baa,this['authToken']=_0x428ed1,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x46a433),this['connURL']=z['connectionURL_'](_0x46a433,_0x3dfd72,_0x5bc4d8,_0x506baa,_0x24171c),this['nodeAdmin']=_0x46a433['nodeAdmin'];}static['connectionURL_'](_0x111d97,_0x127c11,_0x46b8ea,_0x4a28c,_0x54b061){const _0x1bb980={};return _0x1bb980[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x1bb980[ho]=uo),_0x127c11&&(_0x1bb980[lo]=_0x127c11),_0x46b8ea&&(_0x1bb980[po]=_0x46b8ea),_0x4a28c&&(_0x1bb980[vi]=_0x4a28c),_0x54b061&&(_0x1bb980[_o]=_0x54b061),vo(_0x111d97,go,_0x1bb980);}['open'](_0x40cfda,_0xec2ead){this['onDisconnect']=_0xec2ead,this['onMessage']=_0x40cfda,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x269715;_c(),this['mySock']=new un(this['connURL'],[],_0x269715);}catch(_0x5e6ef8){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x24993c=_0x5e6ef8['message']||_0x5e6ef8['data'];_0x24993c&&this['log_'](_0x24993c),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x5d5b0b=>{this['handleIncomingFrame'](_0x5d5b0b);},this['mySock']['onerror']=_0x4fe101=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x28fc7f=_0x4fe101['message']||_0x4fe101['data'];_0x28fc7f&&this['log_'](_0x28fc7f),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x29744c=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x5a55f2=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x13ef39=navigator['userAgent']['match'](_0x5a55f2);_0x13ef39&&_0x13ef39['length']>0x1&&parseFloat(_0x13ef39[0x1])<4.4&&(_0x29744c=!0x0);}return!_0x29744c&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x3ed646){if(this['frames']['push'](_0x3ed646),this['frames']['length']===this['totalFrames']){const _0xafe0f0=this['frames']['join']('');this['frames']=null;const _0x4a056b=At(_0xafe0f0);this['onMessage'](_0x4a056b);}}['handleNewFrameCount_'](_0x20313e){this['totalFrames']=_0x20313e,this['frames']=[];}['extractFrameCount_'](_0x55d1a4){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x55d1a4['length']<=0x6){const _0x4057f6=Number(_0x55d1a4);if(!isNaN(_0x4057f6))return this['handleNewFrameCount_'](_0x4057f6),null;}return this['handleNewFrameCount_'](0x1),_0x55d1a4;}['handleIncomingFrame'](_0x1a4224){if(this['mySock']===null)return;const _0x422db9=_0x1a4224['data'];if(this['bytesReceived']+=_0x422db9['length'],this['stats_']['incrementCounter']('bytes_received',_0x422db9['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x422db9);else{const _0x375214=this['extractFrameCount_'](_0x422db9);_0x375214!==null&&this['appendFrame_'](_0x375214);}}['send'](_0x437702){this['resetKeepAlive']();const _0x5b75ac=O(_0x437702);this['bytesSent']+=_0x5b75ac['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5b75ac['length']);const _0x1b60dc=oo(_0x5b75ac,gh);_0x1b60dc['length']>0x1&&this['sendString_'](String(_0x1b60dc['length']));for(let _0x50b85c=0x0;_0x50b85c<_0x1b60dc['length'];_0x50b85c++)this['sendString_'](_0x1b60dc[_0x50b85c]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x1dd5ff){try{this['mySock']['send'](_0x1dd5ff);}catch(_0x2fc0ca){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x2fc0ca['message']||_0x2fc0ca['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x160f4a){this['initTransports_'](_0x160f4a);}['initTransports_'](_0x46b728){const _0xda440d=z&&z['isAvailable']();let _0x273287=_0xda440d&&!z['previouslyFailed']();if(_0x46b728['webSocketOnly']&&(_0xda440d||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x273287=!0x0),_0x273287)this['transports_']=[z];else{const _0x2b269d=this['transports_']=[];for(const _0x36a1b4 of Nt['ALL_TRANSPORTS'])_0x36a1b4&&_0x36a1b4['isAvailable']()&&_0x2b269d['push'](_0x36a1b4);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x514c3d,_0x24ee18,_0x675511,_0x1551bd,_0x4163f6,_0x18ec4c,_0x152f59,_0x26f2c8,_0x1b5720,_0x2ce4b8){this['id']=_0x514c3d,this['repoInfo_']=_0x24ee18,this['applicationId_']=_0x675511,this['appCheckToken_']=_0x1551bd,this['authToken_']=_0x4163f6,this['onMessage_']=_0x18ec4c,this['onReady_']=_0x152f59,this['onDisconnect_']=_0x26f2c8,this['onKill_']=_0x1b5720,this['lastSessionId']=_0x2ce4b8,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x24ee18),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x56d34a=this['transportManager_']['initialTransport']();this['conn_']=new _0x56d34a(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x56d34a['responsesRequiredToBeHealthy']||0x0;const _0x30e5b4=this['connReceiver_'](this['conn_']),_0x809e33=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x30e5b4,_0x809e33);},Math['floor'](0x0));const _0x277dcf=_0x56d34a['healthyTimeout']||0x0;_0x277dcf>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x277dcf)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x546f38){return _0x22b5c4=>{_0x546f38===this['conn_']?this['onConnectionLost_'](_0x22b5c4):_0x546f38===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x4ab985){return _0x2a0d97=>{this['state_']!==0x2&&(_0x4ab985===this['rx_']?this['onPrimaryMessageReceived_'](_0x2a0d97):_0x4ab985===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x2a0d97):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x2d79cc){const _0x54b3b2={'t':'d','d':_0x2d79cc};this['sendData_'](_0x54b3b2);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0xc7141c){if(si in _0xc7141c){const _0x4f3e53=_0xc7141c[si];_0x4f3e53===Qs?this['upgradeIfSecondaryHealthy_']():_0x4f3e53===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x4f3e53===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x49dddc){const _0x36cf67=_t('t',_0x49dddc),_0x2274af=_t('d',_0x49dddc);if(_0x36cf67==='c')this['onSecondaryControl_'](_0x2274af);else{if(_0x36cf67==='d')this['pendingDataMessages']['push'](_0x2274af);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x36cf67);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x57a36f){const _0xe031c6=_t('t',_0x57a36f),_0x5a35bb=_t('d',_0x57a36f);_0xe031c6==='c'?this['onControl_'](_0x5a35bb):_0xe031c6==='d'&&this['onDataMessage_'](_0x5a35bb);}['onDataMessage_'](_0x3cdba6){this['onPrimaryResponse_'](),this['onMessage_'](_0x3cdba6);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x7937e0){const _0x20d156=_t(si,_0x7937e0);if(js in _0x7937e0){const _0x50df6d=_0x7937e0[js];if(_0x20d156===Th){const _0xf124a3={..._0x50df6d};this['repoInfo_']['isUsingEmulator']&&(_0xf124a3['h']=this['repoInfo_']['host']),this['onHandshake_'](_0xf124a3);}else{if(_0x20d156===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0xca789d=0x0;_0xca789d<this['pendingDataMessages']['length'];++_0xca789d)this['onDataMessage_'](this['pendingDataMessages'][_0xca789d]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x20d156===wh?this['onConnectionShutdown_'](_0x50df6d):_0x20d156===Ks?this['onReset_'](_0x50df6d):_0x20d156===Ch?yi('Server\x20Error:\x20'+_0x50df6d):_0x20d156===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x20d156);}}}['onHandshake_'](_0x1e7689){const _0x3dc94b=_0x1e7689['ts'],_0x336218=_0x1e7689['v'],_0x4b1e4e=_0x1e7689['h'];this['sessionId']=_0x1e7689['s'],this['repoInfo_']['host']=_0x4b1e4e,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x3dc94b),$i!==_0x336218&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x3cb5c0=this['transportManager_']['upgradeTransport']();_0x3cb5c0&&this['startUpgrade_'](_0x3cb5c0);}['startUpgrade_'](_0x53df59){this['secondaryConn_']=new _0x53df59(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x53df59['responsesRequiredToBeHealthy']||0x0;const _0x19d135=this['connReceiver_'](this['secondaryConn_']),_0x13b4fb=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x19d135,_0x13b4fb),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x2aa562){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x2aa562),this['repoInfo_']['host']=_0x2aa562,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x26e214,_0x37d60c){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x26e214,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x37d60c,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0xcc5ed3=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0xcc5ed3||this['rx_']===_0xcc5ed3)&&this['close']();}['onConnectionLost_'](_0x2afb03){this['conn_']=null,!_0x2afb03&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x197df6){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x197df6),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x354b15){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x354b15);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x19370b,_0x51fafd,_0x2a54b9,_0xaefc5a){}['merge'](_0x40c12f,_0x57b3cb,_0x201944,_0x514998){}['refreshAuthToken'](_0x3da4ad){}['refreshAppCheckToken'](_0x43d893){}['onDisconnectPut'](_0x494f5a,_0x2eab00,_0x57ddcb){}['onDisconnectMerge'](_0x393d75,_0x1441f9,_0x3aa462){}['onDisconnectCancel'](_0x39c9b5,_0x1813a9){}['reportStats'](_0x3f2c6e){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x43ad73){this['allowedEvents_']=_0x43ad73,this['listeners_']={},f(Array['isArray'](_0x43ad73)&&_0x43ad73['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x5435df,..._0x1df38d){if(Array['isArray'](this['listeners_'][_0x5435df])){const _0x28317c=[...this['listeners_'][_0x5435df]];for(let _0x4664d5=0x0;_0x4664d5<_0x28317c['length'];_0x4664d5++)_0x28317c[_0x4664d5]['callback']['apply'](_0x28317c[_0x4664d5]['context'],_0x1df38d);}}['on'](_0x2f4e6f,_0x10d795,_0x5aec98){this['validateEventType_'](_0x2f4e6f),this['listeners_'][_0x2f4e6f]=this['listeners_'][_0x2f4e6f]||[],this['listeners_'][_0x2f4e6f]['push']({'callback':_0x10d795,'context':_0x5aec98});const _0x22cf1b=this['getInitialEvent'](_0x2f4e6f);_0x22cf1b&&_0x10d795['apply'](_0x5aec98,_0x22cf1b);}['off'](_0x546dc3,_0x402b76,_0x58e39b){this['validateEventType_'](_0x546dc3);const _0x33d065=this['listeners_'][_0x546dc3]||[];for(let _0x1546ea=0x0;_0x1546ea<_0x33d065['length'];_0x1546ea++)if(_0x33d065[_0x1546ea]['callback']===_0x402b76&&(!_0x58e39b||_0x58e39b===_0x33d065[_0x1546ea]['context'])){_0x33d065['splice'](_0x1546ea,0x1);return;}}['validateEventType_'](_0x33d1d4){f(this['allowedEvents_']['find'](_0x1e7c5e=>_0x1e7c5e===_0x33d1d4),'Unknown\x20event:\x20'+_0x33d1d4);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x582965){return f(_0x582965==='online','Unknown\x20event\x20type:\x20'+_0x582965),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x463e04,_0x59fe58){if(_0x59fe58===void 0x0){this['pieces_']=_0x463e04['split']('/');let _0x275568=0x0;for(let _0x330f14=0x0;_0x330f14<this['pieces_']['length'];_0x330f14++)this['pieces_'][_0x330f14]['length']>0x0&&(this['pieces_'][_0x275568]=this['pieces_'][_0x330f14],_0x275568++);this['pieces_']['length']=_0x275568,this['pieceNum_']=0x0;}else this['pieces_']=_0x463e04,this['pieceNum_']=_0x59fe58;}['toString'](){let _0x45481c='';for(let _0x154f25=this['pieceNum_'];_0x154f25<this['pieces_']['length'];_0x154f25++)this['pieces_'][_0x154f25]!==''&&(_0x45481c+='/'+this['pieces_'][_0x154f25]);return _0x45481c||'/';}}function w(){return new C('');}function y(_0x26c2aa){return _0x26c2aa['pieceNum_']>=_0x26c2aa['pieces_']['length']?null:_0x26c2aa['pieces_'][_0x26c2aa['pieceNum_']];}function we(_0xe2e6b){return _0xe2e6b['pieces_']['length']-_0xe2e6b['pieceNum_'];}function b(_0x2cd1d3){let _0x39e2ba=_0x2cd1d3['pieceNum_'];return _0x39e2ba<_0x2cd1d3['pieces_']['length']&&_0x39e2ba++,new C(_0x2cd1d3['pieces_'],_0x39e2ba);}function zi(_0x5e6d9e){return _0x5e6d9e['pieceNum_']<_0x5e6d9e['pieces_']['length']?_0x5e6d9e['pieces_'][_0x5e6d9e['pieces_']['length']-0x1]:null;}function bh(_0x2fd965){let _0x4ea2c4='';for(let _0x24dbed=_0x2fd965['pieceNum_'];_0x24dbed<_0x2fd965['pieces_']['length'];_0x24dbed++)_0x2fd965['pieces_'][_0x24dbed]!==''&&(_0x4ea2c4+='/'+encodeURIComponent(String(_0x2fd965['pieces_'][_0x24dbed])));return _0x4ea2c4||'/';}function Pt(_0x3cd204,_0x594929=0x0){return _0x3cd204['pieces_']['slice'](_0x3cd204['pieceNum_']+_0x594929);}function Ro(_0x1a3a7a){if(_0x1a3a7a['pieceNum_']>=_0x1a3a7a['pieces_']['length'])return null;const _0x3b6ebe=[];for(let _0x257401=_0x1a3a7a['pieceNum_'];_0x257401<_0x1a3a7a['pieces_']['length']-0x1;_0x257401++)_0x3b6ebe['push'](_0x1a3a7a['pieces_'][_0x257401]);return new C(_0x3b6ebe,0x0);}function k(_0x5f5848,_0x41f1ab){const _0x5477a0=[];for(let _0x4a2da2=_0x5f5848['pieceNum_'];_0x4a2da2<_0x5f5848['pieces_']['length'];_0x4a2da2++)_0x5477a0['push'](_0x5f5848['pieces_'][_0x4a2da2]);if(_0x41f1ab instanceof C){for(let _0x33668c=_0x41f1ab['pieceNum_'];_0x33668c<_0x41f1ab['pieces_']['length'];_0x33668c++)_0x5477a0['push'](_0x41f1ab['pieces_'][_0x33668c]);}else{const _0x52cb8d=_0x41f1ab['split']('/');for(let _0x59fb6f=0x0;_0x59fb6f<_0x52cb8d['length'];_0x59fb6f++)_0x52cb8d[_0x59fb6f]['length']>0x0&&_0x5477a0['push'](_0x52cb8d[_0x59fb6f]);}return new C(_0x5477a0,0x0);}function v(_0x20097c){return _0x20097c['pieceNum_']>=_0x20097c['pieces_']['length'];}function F(_0x3341a6,_0x2c9b9d){const _0x356324=y(_0x3341a6),_0x17232b=y(_0x2c9b9d);if(_0x356324===null)return _0x2c9b9d;if(_0x356324===_0x17232b)return F(b(_0x3341a6),b(_0x2c9b9d));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x2c9b9d+')\x20is\x20not\x20within\x20outerPath\x20('+_0x3341a6+')');}function Rh(_0x2c860e,_0x2c3d72){const _0x23c447=Pt(_0x2c860e,0x0),_0x3aec38=Pt(_0x2c3d72,0x0);for(let _0x165cd1=0x0;_0x165cd1<_0x23c447['length']&&_0x165cd1<_0x3aec38['length'];_0x165cd1++){const _0x19b6ca=He(_0x23c447[_0x165cd1],_0x3aec38[_0x165cd1]);if(_0x19b6ca!==0x0)return _0x19b6ca;}return _0x23c447['length']===_0x3aec38['length']?0x0:_0x23c447['length']<_0x3aec38['length']?-0x1:0x1;}function ji(_0x56d874,_0x1ac7d8){if(we(_0x56d874)!==we(_0x1ac7d8))return!0x1;for(let _0x2224b0=_0x56d874['pieceNum_'],_0x2cb348=_0x1ac7d8['pieceNum_'];_0x2224b0<=_0x56d874['pieces_']['length'];_0x2224b0++,_0x2cb348++)if(_0x56d874['pieces_'][_0x2224b0]!==_0x1ac7d8['pieces_'][_0x2cb348])return!0x1;return!0x0;}function G(_0x5f1756,_0x241fa2){let _0x50d457=_0x5f1756['pieceNum_'],_0x21e902=_0x241fa2['pieceNum_'];if(we(_0x5f1756)>we(_0x241fa2))return!0x1;for(;_0x50d457<_0x5f1756['pieces_']['length'];){if(_0x5f1756['pieces_'][_0x50d457]!==_0x241fa2['pieces_'][_0x21e902])return!0x1;++_0x50d457,++_0x21e902;}return!0x0;}class Ah{constructor(_0x29492c,_0x1529ca){this['errorPrefix_']=_0x1529ca,this['parts_']=Pt(_0x29492c,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x511d3a=0x0;_0x511d3a<this['parts_']['length'];_0x511d3a++)this['byteLength_']+=On(this['parts_'][_0x511d3a]);Ao(this);}}function kh(_0x56205f,_0x5b1ec4){_0x56205f['parts_']['length']>0x0&&(_0x56205f['byteLength_']+=0x1),_0x56205f['parts_']['push'](_0x5b1ec4),_0x56205f['byteLength_']+=On(_0x5b1ec4),Ao(_0x56205f);}function Nh(_0x34a3ce){const _0x56ade7=_0x34a3ce['parts_']['pop']();_0x34a3ce['byteLength_']-=On(_0x56ade7),_0x34a3ce['parts_']['length']>0x0&&(_0x34a3ce['byteLength_']-=0x1);}function Ao(_0x5808bf){if(_0x5808bf['byteLength_']>er)throw new Error(_0x5808bf['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x5808bf['byteLength_']+').');if(_0x5808bf['parts_']['length']>Zs)throw new Error(_0x5808bf['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x5808bf));}function Pe(_0x74e679){return _0x74e679['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x74e679['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x5015e2,_0x68b1a9;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x68b1a9='visibilitychange',_0x5015e2='hidden'):typeof document['mozHidden']<'u'?(_0x68b1a9='mozvisibilitychange',_0x5015e2='mozHidden'):typeof document['msHidden']<'u'?(_0x68b1a9='msvisibilitychange',_0x5015e2='msHidden'):typeof document['webkitHidden']<'u'&&(_0x68b1a9='webkitvisibilitychange',_0x5015e2='webkitHidden')),this['visible_']=!0x0,_0x68b1a9&&document['addEventListener'](_0x68b1a9,()=>{const _0x229209=!document[_0x5015e2];_0x229209!==this['visible_']&&(this['visible_']=_0x229209,this['trigger']('visible',_0x229209));},!0x1);}['getInitialEvent'](_0x4b0e5){return f(_0x4b0e5==='visible','Unknown\x20event\x20type:\x20'+_0x4b0e5),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x1564f3,_0x3957d7,_0x4b3157,_0x15efc0,_0x23a2f9,_0x3e535e,_0x3416f7,_0x592259){if(super(),this['repoInfo_']=_0x1564f3,this['applicationId_']=_0x3957d7,this['onDataUpdate_']=_0x4b3157,this['onConnectStatus_']=_0x15efc0,this['onServerInfoUpdate_']=_0x23a2f9,this['authTokenProvider_']=_0x3e535e,this['appCheckTokenProvider_']=_0x3416f7,this['authOverride_']=_0x592259,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x592259)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x1564f3['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x245ee8,_0x1c046a,_0x44d488){const _0x5076e0=++this['requestNumber_'],_0xe898c7={'r':_0x5076e0,'a':_0x245ee8,'b':_0x1c046a};this['log_'](O(_0xe898c7)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0xe898c7),_0x44d488&&(this['requestCBHash_'][_0x5076e0]=_0x44d488);}['get'](_0x53ede2){this['initConnection_']();const _0x4f9e86=new ot(),_0x42d429={'action':'g','request':{'p':_0x53ede2['_path']['toString'](),'q':_0x53ede2['_queryObject']},'onComplete':_0x1e637c=>{const _0x2abe5f=_0x1e637c['d'];_0x1e637c['s']==='ok'?_0x4f9e86['resolve'](_0x2abe5f):_0x4f9e86['reject'](_0x2abe5f);}};this['outstandingGets_']['push'](_0x42d429),this['outstandingGetCount_']++;const _0x1825d6=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x1825d6),_0x4f9e86['promise'];}['listen'](_0x1eb565,_0x341cbf,_0x5f03c9,_0x801067){this['initConnection_']();const _0x538f86=_0x1eb565['_queryIdentifier'],_0x4d9d1f=_0x1eb565['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4d9d1f+'\x20'+_0x538f86),this['listens']['has'](_0x4d9d1f)||this['listens']['set'](_0x4d9d1f,new Map()),f(_0x1eb565['_queryParams']['isDefault']()||!_0x1eb565['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x4d9d1f)['has'](_0x538f86),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x167aee={'onComplete':_0x801067,'hashFn':_0x341cbf,'query':_0x1eb565,'tag':_0x5f03c9};this['listens']['get'](_0x4d9d1f)['set'](_0x538f86,_0x167aee),this['connected_']&&this['sendListen_'](_0x167aee);}['sendGet_'](_0x361dd6){const _0x44281a=this['outstandingGets_'][_0x361dd6];this['sendRequest']('g',_0x44281a['request'],_0x575498=>{delete this['outstandingGets_'][_0x361dd6],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x44281a['onComplete']&&_0x44281a['onComplete'](_0x575498);});}['sendListen_'](_0x284e73){const _0x1854ac=_0x284e73['query'],_0x15eec3=_0x1854ac['_path']['toString'](),_0x1cea11=_0x1854ac['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x15eec3+'\x20for\x20'+_0x1cea11);const _0x3c0dc6={'p':_0x15eec3},_0x2b96d4='q';_0x284e73['tag']&&(_0x3c0dc6['q']=_0x1854ac['_queryObject'],_0x3c0dc6['t']=_0x284e73['tag']),_0x3c0dc6['h']=_0x284e73['hashFn'](),this['sendRequest'](_0x2b96d4,_0x3c0dc6,_0x73c98d=>{const _0x2cc87f=_0x73c98d['d'],_0x3014ec=_0x73c98d['s'];se['warnOnListenWarnings_'](_0x2cc87f,_0x1854ac),(this['listens']['get'](_0x15eec3)&&this['listens']['get'](_0x15eec3)['get'](_0x1cea11))===_0x284e73&&(this['log_']('listen\x20response',_0x73c98d),_0x3014ec!=='ok'&&this['removeListen_'](_0x15eec3,_0x1cea11),_0x284e73['onComplete']&&_0x284e73['onComplete'](_0x3014ec,_0x2cc87f));});}static['warnOnListenWarnings_'](_0x5265a1,_0x61bdbf){if(_0x5265a1&&typeof _0x5265a1=='object'&&J(_0x5265a1,'w')){const _0x2de3a3=De(_0x5265a1,'w');if(Array['isArray'](_0x2de3a3)&&~_0x2de3a3['indexOf']('no_index')){const _0x4ff892='\x22.indexOn\x22:\x20\x22'+_0x61bdbf['_queryParams']['getIndex']()['toString']()+'\x22',_0x1e5803=_0x61bdbf['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x4ff892+'\x20at\x20'+_0x1e5803+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x46b7e4){this['authToken_']=_0x46b7e4,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x46b7e4);}['reduceReconnectDelayIfAdminCredential_'](_0x37e40e){(_0x37e40e&&_0x37e40e['length']===0x28||wc(_0x37e40e))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x1792c0){this['appCheckToken_']=_0x1792c0,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x104ff5=this['authToken_'],_0x2e5d0d=Ic(_0x104ff5)?'auth':'gauth',_0x4b03d0={'cred':_0x104ff5};this['authOverride_']===null?_0x4b03d0['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x4b03d0['authvar']=this['authOverride_']),this['sendRequest'](_0x2e5d0d,_0x4b03d0,_0x467775=>{const _0x3bf15e=_0x467775['s'],_0x4f4e1b=_0x467775['d']||'error';this['authToken_']===_0x104ff5&&(_0x3bf15e==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x3bf15e,_0x4f4e1b));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x3be424=>{const _0x19c8d8=_0x3be424['s'],_0x2ab8fb=_0x3be424['d']||'error';_0x19c8d8==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x19c8d8,_0x2ab8fb);});}['unlisten'](_0x2f6758,_0x28d59e){const _0x5c8844=_0x2f6758['_path']['toString'](),_0x45b32b=_0x2f6758['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x5c8844+'\x20'+_0x45b32b),f(_0x2f6758['_queryParams']['isDefault']()||!_0x2f6758['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x5c8844,_0x45b32b)&&this['connected_']&&this['sendUnlisten_'](_0x5c8844,_0x45b32b,_0x2f6758['_queryObject'],_0x28d59e);}['sendUnlisten_'](_0x3f0e64,_0x396c2e,_0x25eaee,_0x129545){this['log_']('Unlisten\x20on\x20'+_0x3f0e64+'\x20for\x20'+_0x396c2e);const _0x2be998={'p':_0x3f0e64},_0xd4cc09='n';_0x129545&&(_0x2be998['q']=_0x25eaee,_0x2be998['t']=_0x129545),this['sendRequest'](_0xd4cc09,_0x2be998);}['onDisconnectPut'](_0x177b50,_0x5ef2fc,_0x2bde6f){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x177b50,_0x5ef2fc,_0x2bde6f):this['onDisconnectRequestQueue_']['push']({'pathString':_0x177b50,'action':'o','data':_0x5ef2fc,'onComplete':_0x2bde6f});}['onDisconnectMerge'](_0x14f02e,_0x4f311f,_0x4ebc5e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x14f02e,_0x4f311f,_0x4ebc5e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x14f02e,'action':'om','data':_0x4f311f,'onComplete':_0x4ebc5e});}['onDisconnectCancel'](_0x50fc6e,_0x50ea84){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x50fc6e,null,_0x50ea84):this['onDisconnectRequestQueue_']['push']({'pathString':_0x50fc6e,'action':'oc','data':null,'onComplete':_0x50ea84});}['sendOnDisconnect_'](_0x4989ca,_0x1a821f,_0x5a18c9,_0x66a3b7){const _0x34901c={'p':_0x1a821f,'d':_0x5a18c9};this['log_']('onDisconnect\x20'+_0x4989ca,_0x34901c),this['sendRequest'](_0x4989ca,_0x34901c,_0x40908b=>{_0x66a3b7&&setTimeout(()=>{_0x66a3b7(_0x40908b['s'],_0x40908b['d']);},Math['floor'](0x0));});}['put'](_0x5e7ab3,_0xcc09c7,_0x39f6fb,_0x418f73){this['putInternal']('p',_0x5e7ab3,_0xcc09c7,_0x39f6fb,_0x418f73);}['merge'](_0x24a576,_0x1639b9,_0x1293e8,_0x5313a6){this['putInternal']('m',_0x24a576,_0x1639b9,_0x1293e8,_0x5313a6);}['putInternal'](_0x5a07d7,_0x43ec8e,_0x286ab0,_0x33f354,_0xbc9cf0){this['initConnection_']();const _0x3a0991={'p':_0x43ec8e,'d':_0x286ab0};_0xbc9cf0!==void 0x0&&(_0x3a0991['h']=_0xbc9cf0),this['outstandingPuts_']['push']({'action':_0x5a07d7,'request':_0x3a0991,'onComplete':_0x33f354}),this['outstandingPutCount_']++;const _0xc639a7=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0xc639a7):this['log_']('Buffering\x20put:\x20'+_0x43ec8e);}['sendPut_'](_0x510ea3){const _0x53fe73=this['outstandingPuts_'][_0x510ea3]['action'],_0x4a5900=this['outstandingPuts_'][_0x510ea3]['request'],_0x34b966=this['outstandingPuts_'][_0x510ea3]['onComplete'];this['outstandingPuts_'][_0x510ea3]['queued']=this['connected_'],this['sendRequest'](_0x53fe73,_0x4a5900,_0x23eabf=>{this['log_'](_0x53fe73+'\x20response',_0x23eabf),delete this['outstandingPuts_'][_0x510ea3],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x34b966&&_0x34b966(_0x23eabf['s'],_0x23eabf['d']);});}['reportStats'](_0x14228b){if(this['connected_']){const _0x234461={'c':_0x14228b};this['log_']('reportStats',_0x234461),this['sendRequest']('s',_0x234461,_0x1c406e=>{if(_0x1c406e['s']!=='ok'){const _0x25e521=_0x1c406e['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x25e521);}});}}['onDataMessage_'](_0xfb305f){if('r'in _0xfb305f){this['log_']('from\x20server:\x20'+O(_0xfb305f));const _0x34f286=_0xfb305f['r'],_0x5b3870=this['requestCBHash_'][_0x34f286];_0x5b3870&&(delete this['requestCBHash_'][_0x34f286],_0x5b3870(_0xfb305f['b']));}else{if('error'in _0xfb305f)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0xfb305f['error'];'a'in _0xfb305f&&this['onDataPush_'](_0xfb305f['a'],_0xfb305f['b']);}}['onDataPush_'](_0x5fa2ab,_0x11fe5e){this['log_']('handleServerMessage',_0x5fa2ab,_0x11fe5e),_0x5fa2ab==='d'?this['onDataUpdate_'](_0x11fe5e['p'],_0x11fe5e['d'],!0x1,_0x11fe5e['t']):_0x5fa2ab==='m'?this['onDataUpdate_'](_0x11fe5e['p'],_0x11fe5e['d'],!0x0,_0x11fe5e['t']):_0x5fa2ab==='c'?this['onListenRevoked_'](_0x11fe5e['p'],_0x11fe5e['q']):_0x5fa2ab==='ac'?this['onAuthRevoked_'](_0x11fe5e['s'],_0x11fe5e['d']):_0x5fa2ab==='apc'?this['onAppCheckRevoked_'](_0x11fe5e['s'],_0x11fe5e['d']):_0x5fa2ab==='sd'?this['onSecurityDebugPacket_'](_0x11fe5e):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x5fa2ab)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x3998e7,_0x2ac9e){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x3998e7),this['lastSessionId']=_0x2ac9e,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x52608a){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x52608a));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x4ea4de){_0x4ea4de&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x4ea4de;}['onOnline_'](_0x1fc62d){_0x1fc62d?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x5777be=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x1b56cb=Math['max'](0x0,this['reconnectDelay_']-_0x5777be);_0x1b56cb=Math['random']()*_0x1b56cb,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x1b56cb+'ms'),this['scheduleConnect_'](_0x1b56cb),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x3de82b=this['onDataMessage_']['bind'](this),_0xf8541f=this['onReady_']['bind'](this),_0x2eb4a8=this['onRealtimeDisconnect_']['bind'](this),_0x95896f=this['id']+':'+se['nextConnectionId_']++,_0x43fdf3=this['lastSessionId'];let _0x4ed073=!0x1,_0xc749c2=null;const _0x30f5bc=function(){_0xc749c2?_0xc749c2['close']():(_0x4ed073=!0x0,_0x2eb4a8());},_0x42b510=function(_0x21b74c){f(_0xc749c2,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0xc749c2['sendRequest'](_0x21b74c);};this['realtime_']={'close':_0x30f5bc,'sendRequest':_0x42b510};const _0xdafbbf=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x4db710,_0x2d0762]=await Promise['all']([this['authTokenProvider_']['getToken'](_0xdafbbf),this['appCheckTokenProvider_']['getToken'](_0xdafbbf)]);_0x4ed073?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x4db710&&_0x4db710['accessToken'],this['appCheckToken_']=_0x2d0762&&_0x2d0762['token'],_0xc749c2=new Sh(_0x95896f,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x3de82b,_0xf8541f,_0x2eb4a8,_0x3822af=>{U(_0x3822af+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x43fdf3));}catch(_0x226236){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x226236),_0x4ed073||(this['repoInfo_']['nodeAdmin']&&U(_0x226236),_0x30f5bc());}}}['interrupt'](_0x21e9a6){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x21e9a6),this['interruptReasons_'][_0x21e9a6]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x81b095){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x81b095),delete this['interruptReasons_'][_0x81b095],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x2bec4e){const _0x3159a2=_0x2bec4e-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x3159a2});}['cancelSentTransactions_'](){for(let _0x2f7bac=0x0;_0x2f7bac<this['outstandingPuts_']['length'];_0x2f7bac++){const _0x1d9054=this['outstandingPuts_'][_0x2f7bac];_0x1d9054&&'h'in _0x1d9054['request']&&_0x1d9054['queued']&&(_0x1d9054['onComplete']&&_0x1d9054['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x2f7bac],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x40e127,_0x503959){let _0x3a2f6e;_0x503959?_0x3a2f6e=_0x503959['map'](_0x2bd25d=>Hi(_0x2bd25d))['join']('$'):_0x3a2f6e='default';const _0xe5b5b2=this['removeListen_'](_0x40e127,_0x3a2f6e);_0xe5b5b2&&_0xe5b5b2['onComplete']&&_0xe5b5b2['onComplete']('permission_denied');}['removeListen_'](_0x15fe29,_0x47e35f){const _0x185e54=new C(_0x15fe29)['toString']();let _0x293c6e;if(this['listens']['has'](_0x185e54)){const _0x211bb6=this['listens']['get'](_0x185e54);_0x293c6e=_0x211bb6['get'](_0x47e35f),_0x211bb6['delete'](_0x47e35f),_0x211bb6['size']===0x0&&this['listens']['delete'](_0x185e54);}else _0x293c6e=void 0x0;return _0x293c6e;}['onAuthRevoked_'](_0x1e2557,_0x3dbb5d){L('Auth\x20token\x20revoked:\x20'+_0x1e2557+'/'+_0x3dbb5d),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x1e2557==='invalid_token'||_0x1e2557==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x20ba6c,_0x330958){L('App\x20check\x20token\x20revoked:\x20'+_0x20ba6c+'/'+_0x330958),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x20ba6c==='invalid_token'||_0x20ba6c==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x35b924){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x35b924):'msg'in _0x35b924&&console['log']('FIREBASE:\x20'+_0x35b924['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x4b2376 of this['listens']['values']())for(const _0xdd0e93 of _0x4b2376['values']())this['sendListen_'](_0xdd0e93);for(let _0x40f469=0x0;_0x40f469<this['outstandingPuts_']['length'];_0x40f469++)this['outstandingPuts_'][_0x40f469]&&this['sendPut_'](_0x40f469);for(;this['onDisconnectRequestQueue_']['length'];){const _0x27aedf=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x27aedf['action'],_0x27aedf['pathString'],_0x27aedf['data'],_0x27aedf['onComplete']);}for(let _0x2c5a2e=0x0;_0x2c5a2e<this['outstandingGets_']['length'];_0x2c5a2e++)this['outstandingGets_'][_0x2c5a2e]&&this['sendGet_'](_0x2c5a2e);}['sendConnectStats_'](){const _0x4bce5e={};let _0x17fce3='js';_0x4bce5e['sdk.'+_0x17fce3+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x4bce5e['framework.cordova']=0x1:Yr()&&(_0x4bce5e['framework.reactnative']=0x1),this['reportStats'](_0x4bce5e);}['shouldReconnect_'](){const _0x534c0d=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x534c0d;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x268151,_0x484f11){this['name']=_0x268151,this['node']=_0x484f11;}static['Wrap'](_0x1f8487,_0xf80f45){return new E(_0x1f8487,_0xf80f45);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x26d91d,_0x29f44e){const _0x4b14b2=new E(Fe,_0x26d91d),_0x498199=new E(Fe,_0x29f44e);return this['compare'](_0x4b14b2,_0x498199)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x1115a3){Zt=_0x1115a3;}['compare'](_0x2b6fe6,_0x1181da){return He(_0x2b6fe6['name'],_0x1181da['name']);}['isDefinedOn'](_0x2d0d10){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x32aa49,_0x35dc8e){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x17b501,_0x41177c){return f(typeof _0x17b501=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x17b501,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x4293b7,_0x55ce8f,_0x530ffe,_0x323117,_0x5859f5=null){this['isReverse_']=_0x323117,this['resultGenerator_']=_0x5859f5,this['nodeStack_']=[];let _0x19f5e8=0x1;for(;!_0x4293b7['isEmpty']();)if(_0x4293b7=_0x4293b7,_0x19f5e8=_0x55ce8f?_0x530ffe(_0x4293b7['key'],_0x55ce8f):0x1,_0x323117&&(_0x19f5e8*=-0x1),_0x19f5e8<0x0)this['isReverse_']?_0x4293b7=_0x4293b7['left']:_0x4293b7=_0x4293b7['right'];else{if(_0x19f5e8===0x0){this['nodeStack_']['push'](_0x4293b7);break;}else this['nodeStack_']['push'](_0x4293b7),this['isReverse_']?_0x4293b7=_0x4293b7['right']:_0x4293b7=_0x4293b7['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x263dcb=this['nodeStack_']['pop'](),_0x3cbbfb;if(this['resultGenerator_']?_0x3cbbfb=this['resultGenerator_'](_0x263dcb['key'],_0x263dcb['value']):_0x3cbbfb={'key':_0x263dcb['key'],'value':_0x263dcb['value']},this['isReverse_']){for(_0x263dcb=_0x263dcb['left'];!_0x263dcb['isEmpty']();)this['nodeStack_']['push'](_0x263dcb),_0x263dcb=_0x263dcb['right'];}else{for(_0x263dcb=_0x263dcb['right'];!_0x263dcb['isEmpty']();)this['nodeStack_']['push'](_0x263dcb),_0x263dcb=_0x263dcb['left'];}return _0x3cbbfb;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x1f7eeb=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x1f7eeb['key'],_0x1f7eeb['value']):{'key':_0x1f7eeb['key'],'value':_0x1f7eeb['value']};}}class M{constructor(_0x369fd2,_0x134310,_0x28e02a,_0x3a8b70,_0x5680f3){this['key']=_0x369fd2,this['value']=_0x134310,this['color']=_0x28e02a??M['RED'],this['left']=_0x3a8b70??B['EMPTY_NODE'],this['right']=_0x5680f3??B['EMPTY_NODE'];}['copy'](_0x4bdb95,_0x9b68d7,_0x4318c6,_0x5ca6a1,_0x4c2a97){return new M(_0x4bdb95??this['key'],_0x9b68d7??this['value'],_0x4318c6??this['color'],_0x5ca6a1??this['left'],_0x4c2a97??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x1361aa){return this['left']['inorderTraversal'](_0x1361aa)||!!_0x1361aa(this['key'],this['value'])||this['right']['inorderTraversal'](_0x1361aa);}['reverseTraversal'](_0x3e1867){return this['right']['reverseTraversal'](_0x3e1867)||_0x3e1867(this['key'],this['value'])||this['left']['reverseTraversal'](_0x3e1867);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x2c8a1d,_0x6337c3,_0x42da87){let _0x47384c=this;const _0x3ed263=_0x42da87(_0x2c8a1d,_0x47384c['key']);return _0x3ed263<0x0?_0x47384c=_0x47384c['copy'](null,null,null,_0x47384c['left']['insert'](_0x2c8a1d,_0x6337c3,_0x42da87),null):_0x3ed263===0x0?_0x47384c=_0x47384c['copy'](null,_0x6337c3,null,null,null):_0x47384c=_0x47384c['copy'](null,null,null,null,_0x47384c['right']['insert'](_0x2c8a1d,_0x6337c3,_0x42da87)),_0x47384c['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x442bbc=this;return!_0x442bbc['left']['isRed_']()&&!_0x442bbc['left']['left']['isRed_']()&&(_0x442bbc=_0x442bbc['moveRedLeft_']()),_0x442bbc=_0x442bbc['copy'](null,null,null,_0x442bbc['left']['removeMin_'](),null),_0x442bbc['fixUp_']();}['remove'](_0x5618b9,_0x52f662){let _0x47a4d3,_0x156761;if(_0x47a4d3=this,_0x52f662(_0x5618b9,_0x47a4d3['key'])<0x0)!_0x47a4d3['left']['isEmpty']()&&!_0x47a4d3['left']['isRed_']()&&!_0x47a4d3['left']['left']['isRed_']()&&(_0x47a4d3=_0x47a4d3['moveRedLeft_']()),_0x47a4d3=_0x47a4d3['copy'](null,null,null,_0x47a4d3['left']['remove'](_0x5618b9,_0x52f662),null);else{if(_0x47a4d3['left']['isRed_']()&&(_0x47a4d3=_0x47a4d3['rotateRight_']()),!_0x47a4d3['right']['isEmpty']()&&!_0x47a4d3['right']['isRed_']()&&!_0x47a4d3['right']['left']['isRed_']()&&(_0x47a4d3=_0x47a4d3['moveRedRight_']()),_0x52f662(_0x5618b9,_0x47a4d3['key'])===0x0){if(_0x47a4d3['right']['isEmpty']())return B['EMPTY_NODE'];_0x156761=_0x47a4d3['right']['min_'](),_0x47a4d3=_0x47a4d3['copy'](_0x156761['key'],_0x156761['value'],null,null,_0x47a4d3['right']['removeMin_']());}_0x47a4d3=_0x47a4d3['copy'](null,null,null,null,_0x47a4d3['right']['remove'](_0x5618b9,_0x52f662));}return _0x47a4d3['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x5b1424=this;return _0x5b1424['right']['isRed_']()&&!_0x5b1424['left']['isRed_']()&&(_0x5b1424=_0x5b1424['rotateLeft_']()),_0x5b1424['left']['isRed_']()&&_0x5b1424['left']['left']['isRed_']()&&(_0x5b1424=_0x5b1424['rotateRight_']()),_0x5b1424['left']['isRed_']()&&_0x5b1424['right']['isRed_']()&&(_0x5b1424=_0x5b1424['colorFlip_']()),_0x5b1424;}['moveRedLeft_'](){let _0x16be24=this['colorFlip_']();return _0x16be24['right']['left']['isRed_']()&&(_0x16be24=_0x16be24['copy'](null,null,null,null,_0x16be24['right']['rotateRight_']()),_0x16be24=_0x16be24['rotateLeft_'](),_0x16be24=_0x16be24['colorFlip_']()),_0x16be24;}['moveRedRight_'](){let _0x41a6de=this['colorFlip_']();return _0x41a6de['left']['left']['isRed_']()&&(_0x41a6de=_0x41a6de['rotateRight_'](),_0x41a6de=_0x41a6de['colorFlip_']()),_0x41a6de;}['rotateLeft_'](){const _0x2becd0=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x2becd0,null);}['rotateRight_'](){const _0x3aea12=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x3aea12);}['colorFlip_'](){const _0x558120=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x51485a=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x558120,_0x51485a);}['checkMaxDepth_'](){const _0x39c983=this['check_']();return Math['pow'](0x2,_0x39c983)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2f9382=this['left']['check_']();if(_0x2f9382!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2f9382+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x5e2864,_0x2968d8,_0xa19af9,_0x1f7aff,_0x473808){return this;}['insert'](_0x21bd83,_0xa5346a,_0x3b0e34){return new M(_0x21bd83,_0xa5346a,null);}['remove'](_0x2eee6a,_0x1d9bd0){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x43c0c3){return!0x1;}['reverseTraversal'](_0x1241e4){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x3798fd,_0x4c70f9=B['EMPTY_NODE']){this['comparator_']=_0x3798fd,this['root_']=_0x4c70f9;}['insert'](_0x4b4f3c,_0x221e5d){return new B(this['comparator_'],this['root_']['insert'](_0x4b4f3c,_0x221e5d,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x34a0a3){return new B(this['comparator_'],this['root_']['remove'](_0x34a0a3,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0xb1ed3e){let _0x55b713,_0x421677=this['root_'];for(;!_0x421677['isEmpty']();){if(_0x55b713=this['comparator_'](_0xb1ed3e,_0x421677['key']),_0x55b713===0x0)return _0x421677['value'];_0x55b713<0x0?_0x421677=_0x421677['left']:_0x55b713>0x0&&(_0x421677=_0x421677['right']);}return null;}['getPredecessorKey'](_0x1ac50b){let _0xb0f46c,_0x4d8a0b=this['root_'],_0x23c791=null;for(;!_0x4d8a0b['isEmpty']();)if(_0xb0f46c=this['comparator_'](_0x1ac50b,_0x4d8a0b['key']),_0xb0f46c===0x0){if(_0x4d8a0b['left']['isEmpty']())return _0x23c791?_0x23c791['key']:null;for(_0x4d8a0b=_0x4d8a0b['left'];!_0x4d8a0b['right']['isEmpty']();)_0x4d8a0b=_0x4d8a0b['right'];return _0x4d8a0b['key'];}else _0xb0f46c<0x0?_0x4d8a0b=_0x4d8a0b['left']:_0xb0f46c>0x0&&(_0x23c791=_0x4d8a0b,_0x4d8a0b=_0x4d8a0b['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0xf2d3c7){return this['root_']['inorderTraversal'](_0xf2d3c7);}['reverseTraversal'](_0x2a7015){return this['root_']['reverseTraversal'](_0x2a7015);}['getIterator'](_0x2217a2){return new en(this['root_'],null,this['comparator_'],!0x1,_0x2217a2);}['getIteratorFrom'](_0x4f9255,_0x3da788){return new en(this['root_'],_0x4f9255,this['comparator_'],!0x1,_0x3da788);}['getReverseIteratorFrom'](_0x5adc3b,_0x7c85cf){return new en(this['root_'],_0x5adc3b,this['comparator_'],!0x0,_0x7c85cf);}['getReverseIterator'](_0x1a5652){return new en(this['root_'],null,this['comparator_'],!0x0,_0x1a5652);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x1a07ee,_0x5e85e8){return He(_0x1a07ee['name'],_0x5e85e8['name']);}function Yi(_0x10f019,_0x42cbf7){return He(_0x10f019,_0x42cbf7);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x3686d8){Ei=_0x3686d8;}const No=function(_0x5a55b0){return typeof _0x5a55b0=='number'?'number:'+ao(_0x5a55b0):'string:'+_0x5a55b0;},Po=function(_0x563157){if(_0x563157['isLeafNode']()){const _0x429483=_0x563157['val']();f(typeof _0x429483=='string'||typeof _0x429483=='number'||typeof _0x429483=='object'&&J(_0x429483,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x563157===Ei||_0x563157['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x563157===Ei||_0x563157['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x6eb418){ir=_0x6eb418;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x1e14b4,_0x4b2eee=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x1e14b4,this['priorityNode_']=_0x4b2eee,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x7ac085){return new D(this['value_'],_0x7ac085);}['getImmediateChild'](_0x8c7aa0){return _0x8c7aa0==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x11fad1){return v(_0x11fad1)?this:y(_0x11fad1)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x2db83c,_0x4c2cff){return null;}['updateImmediateChild'](_0x1bec8f,_0x3d71b5){return _0x1bec8f==='.priority'?this['updatePriority'](_0x3d71b5):_0x3d71b5['isEmpty']()&&_0x1bec8f!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x1bec8f,_0x3d71b5)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x577d9a,_0x4b9f4e){const _0xf3df63=y(_0x577d9a);return _0xf3df63===null?_0x4b9f4e:_0x4b9f4e['isEmpty']()&&_0xf3df63!=='.priority'?this:(f(_0xf3df63!=='.priority'||we(_0x577d9a)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0xf3df63,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x577d9a),_0x4b9f4e)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x22b2cd,_0x2224a){return!0x1;}['val'](_0x3be46f){return _0x3be46f&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x2e27b8='';this['priorityNode_']['isEmpty']()||(_0x2e27b8+='priority:'+No(this['priorityNode_']['val']())+':');const _0x24ee87=typeof this['value_'];_0x2e27b8+=_0x24ee87+':',_0x24ee87==='number'?_0x2e27b8+=ao(this['value_']):_0x2e27b8+=this['value_'],this['lazyHash_']=ro(_0x2e27b8);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x3cdb35){return _0x3cdb35===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x3cdb35 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x3cdb35['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x3cdb35));}['compareToLeafNode_'](_0x261466){const _0x3a365d=typeof _0x261466['value_'],_0x220e26=typeof this['value_'],_0x4b70e9=D['VALUE_TYPE_ORDER']['indexOf'](_0x3a365d),_0x43ddda=D['VALUE_TYPE_ORDER']['indexOf'](_0x220e26);return f(_0x4b70e9>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x3a365d),f(_0x43ddda>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x220e26),_0x4b70e9===_0x43ddda?_0x220e26==='object'?0x0:this['value_']<_0x261466['value_']?-0x1:this['value_']===_0x261466['value_']?0x0:0x1:_0x43ddda-_0x4b70e9;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x3cff97){if(_0x3cff97===this)return!0x0;if(_0x3cff97['isLeafNode']()){const _0x5c7001=_0x3cff97;return this['value_']===_0x5c7001['value_']&&this['priorityNode_']['equals'](_0x5c7001['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x5b4349){Oo=_0x5b4349;}function Wh(_0x8bc9fb){Do=_0x8bc9fb;}class Bh extends Dn{['compare'](_0x2751cd,_0x532029){const _0x1ee25b=_0x2751cd['node']['getPriority'](),_0x199e1d=_0x532029['node']['getPriority'](),_0x3e8cd8=_0x1ee25b['compareTo'](_0x199e1d);return _0x3e8cd8===0x0?He(_0x2751cd['name'],_0x532029['name']):_0x3e8cd8;}['isDefinedOn'](_0x44fc44){return!_0x44fc44['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x973754,_0xd25b0c){return!_0x973754['getPriority']()['equals'](_0xd25b0c['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x4d0e10,_0x594ce9){const _0x2a64b1=Oo(_0x4d0e10);return new E(_0x594ce9,new D('[PRIORITY-POST]',_0x2a64b1));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x3c3b06){const _0x440e40=_0x1e0c4a=>parseInt(Math['log'](_0x1e0c4a)/Vh,0xa),_0xdebd30=_0x22db79=>parseInt(Array(_0x22db79+0x1)['join']('1'),0x2);this['count']=_0x440e40(_0x3c3b06+0x1),this['current_']=this['count']-0x1;const _0x218ef1=_0xdebd30(this['count']);this['bits_']=_0x3c3b06+0x1&_0x218ef1;}['nextBitIsOne'](){const _0x4613e7=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x4613e7;}}const fn=function(_0x269153,_0x1e534b,_0x30d600,_0x5357dc){_0x269153['sort'](_0x1e534b);const _0x265bab=function(_0x2cb648,_0x3f762){const _0x54885b=_0x3f762-_0x2cb648;let _0x577f79,_0x45589d;if(_0x54885b===0x0)return null;if(_0x54885b===0x1)return _0x577f79=_0x269153[_0x2cb648],_0x45589d=_0x30d600?_0x30d600(_0x577f79):_0x577f79,new M(_0x45589d,_0x577f79['node'],M['BLACK'],null,null);{const _0x4a3225=parseInt(_0x54885b/0x2,0xa)+_0x2cb648,_0x5833e1=_0x265bab(_0x2cb648,_0x4a3225),_0x8b4b41=_0x265bab(_0x4a3225+0x1,_0x3f762);return _0x577f79=_0x269153[_0x4a3225],_0x45589d=_0x30d600?_0x30d600(_0x577f79):_0x577f79,new M(_0x45589d,_0x577f79['node'],M['BLACK'],_0x5833e1,_0x8b4b41);}},_0x479a12=function(_0x129599){let _0x43f4bc=null,_0x5065b4=null,_0x5a264c=_0x269153['length'];const _0x539e17=function(_0x1d23e1,_0x4980f3){const _0x1d495d=_0x5a264c-_0x1d23e1,_0x1079cc=_0x5a264c;_0x5a264c-=_0x1d23e1;const _0x3021bb=_0x265bab(_0x1d495d+0x1,_0x1079cc),_0x4796fc=_0x269153[_0x1d495d],_0x20123c=_0x30d600?_0x30d600(_0x4796fc):_0x4796fc;_0x2d3812(new M(_0x20123c,_0x4796fc['node'],_0x4980f3,null,_0x3021bb));},_0x2d3812=function(_0x311d17){_0x43f4bc?(_0x43f4bc['left']=_0x311d17,_0x43f4bc=_0x311d17):(_0x5065b4=_0x311d17,_0x43f4bc=_0x311d17);};for(let _0xc9595=0x0;_0xc9595<_0x129599['count'];++_0xc9595){const _0x30a277=_0x129599['nextBitIsOne'](),_0x5078f6=Math['pow'](0x2,_0x129599['count']-(_0xc9595+0x1));_0x30a277?_0x539e17(_0x5078f6,M['BLACK']):(_0x539e17(_0x5078f6,M['BLACK']),_0x539e17(_0x5078f6,M['RED']));}return _0x5065b4;},_0x60070f=new Hh(_0x269153['length']),_0x394aae=_0x479a12(_0x60070f);return new B(_0x5357dc||_0x1e534b,_0x394aae);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x3f7040,_0x15dae9){this['indexes_']=_0x3f7040,this['indexSet_']=_0x15dae9;}['get'](_0x585fa6){const _0x54cf02=De(this['indexes_'],_0x585fa6);if(!_0x54cf02)throw new Error('No\x20index\x20defined\x20for\x20'+_0x585fa6);return _0x54cf02 instanceof B?_0x54cf02:null;}['hasIndex'](_0x461a86){return J(this['indexSet_'],_0x461a86['toString']());}['addIndex'](_0x1d15ef,_0x45f9e3){f(_0x1d15ef!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x39271d=[];let _0x3bdaa6=!0x1;const _0x573a05=_0x45f9e3['getIterator'](E['Wrap']);let _0x4c125a=_0x573a05['getNext']();for(;_0x4c125a;)_0x3bdaa6=_0x3bdaa6||_0x1d15ef['isDefinedOn'](_0x4c125a['node']),_0x39271d['push'](_0x4c125a),_0x4c125a=_0x573a05['getNext']();let _0x30fd8f;_0x3bdaa6?_0x30fd8f=fn(_0x39271d,_0x1d15ef['getCompare']()):_0x30fd8f=ze;const _0x99a570=_0x1d15ef['toString'](),_0x1ccd6b={...this['indexSet_']};_0x1ccd6b[_0x99a570]=_0x1d15ef;const _0x40d71c={...this['indexes_']};return _0x40d71c[_0x99a570]=_0x30fd8f,new te(_0x40d71c,_0x1ccd6b);}['addToIndexes'](_0x19712b,_0x39487a){const _0x5851dd=hn(this['indexes_'],(_0x3c5a0b,_0x38d217)=>{const _0x1b58d3=De(this['indexSet_'],_0x38d217);if(f(_0x1b58d3,'Missing\x20index\x20implementation\x20for\x20'+_0x38d217),_0x3c5a0b===ze){if(_0x1b58d3['isDefinedOn'](_0x19712b['node'])){const _0x2870dc=[],_0x1e059a=_0x39487a['getIterator'](E['Wrap']);let _0x549227=_0x1e059a['getNext']();for(;_0x549227;)_0x549227['name']!==_0x19712b['name']&&_0x2870dc['push'](_0x549227),_0x549227=_0x1e059a['getNext']();return _0x2870dc['push'](_0x19712b),fn(_0x2870dc,_0x1b58d3['getCompare']());}else return ze;}else{const _0x122485=_0x39487a['get'](_0x19712b['name']);let _0x3d1b54=_0x3c5a0b;return _0x122485&&(_0x3d1b54=_0x3d1b54['remove'](new E(_0x19712b['name'],_0x122485))),_0x3d1b54['insert'](_0x19712b,_0x19712b['node']);}});return new te(_0x5851dd,this['indexSet_']);}['removeFromIndexes'](_0x379792,_0x544ee4){const _0x2a7cf5=hn(this['indexes_'],_0x27a72f=>{if(_0x27a72f===ze)return _0x27a72f;{const _0x5e6f21=_0x544ee4['get'](_0x379792['name']);return _0x5e6f21?_0x27a72f['remove'](new E(_0x379792['name'],_0x5e6f21)):_0x27a72f;}});return new te(_0x2a7cf5,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x561b54,_0x211887,_0x2c68e4){this['children_']=_0x561b54,this['priorityNode_']=_0x211887,this['indexMap_']=_0x2c68e4,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x4b7a87){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x4b7a87,this['indexMap_']);}['getImmediateChild'](_0x2f1746){if(_0x2f1746==='.priority')return this['getPriority']();{const _0x2f885c=this['children_']['get'](_0x2f1746);return _0x2f885c===null?mt:_0x2f885c;}}['getChild'](_0xe2f9f3){const _0x364b21=y(_0xe2f9f3);return _0x364b21===null?this:this['getImmediateChild'](_0x364b21)['getChild'](b(_0xe2f9f3));}['hasChild'](_0x36e34a){return this['children_']['get'](_0x36e34a)!==null;}['updateImmediateChild'](_0x173fe3,_0x586ed9){if(f(_0x586ed9,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x173fe3==='.priority')return this['updatePriority'](_0x586ed9);{const _0x5c9c85=new E(_0x173fe3,_0x586ed9);let _0x2d907b,_0x11f5f4;_0x586ed9['isEmpty']()?(_0x2d907b=this['children_']['remove'](_0x173fe3),_0x11f5f4=this['indexMap_']['removeFromIndexes'](_0x5c9c85,this['children_'])):(_0x2d907b=this['children_']['insert'](_0x173fe3,_0x586ed9),_0x11f5f4=this['indexMap_']['addToIndexes'](_0x5c9c85,this['children_']));const _0x3f5c7b=_0x2d907b['isEmpty']()?mt:this['priorityNode_'];return new g(_0x2d907b,_0x3f5c7b,_0x11f5f4);}}['updateChild'](_0x33e45f,_0x2b6e28){const _0x2becc6=y(_0x33e45f);if(_0x2becc6===null)return _0x2b6e28;{f(y(_0x33e45f)!=='.priority'||we(_0x33e45f)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x441463=this['getImmediateChild'](_0x2becc6)['updateChild'](b(_0x33e45f),_0x2b6e28);return this['updateImmediateChild'](_0x2becc6,_0x441463);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x4075d8){if(this['isEmpty']())return null;const _0x5c1b3d={};let _0x36ff31=0x0,_0x493850=0x0,_0x194dcd=!0x0;if(this['forEachChild'](R,(_0x20cc0b,_0xbdbe63)=>{_0x5c1b3d[_0x20cc0b]=_0xbdbe63['val'](_0x4075d8),_0x36ff31++,_0x194dcd&&g['INTEGER_REGEXP_']['test'](_0x20cc0b)?_0x493850=Math['max'](_0x493850,Number(_0x20cc0b)):_0x194dcd=!0x1;}),!_0x4075d8&&_0x194dcd&&_0x493850<0x2*_0x36ff31){const _0x1358bd=[];for(const _0x44652a in _0x5c1b3d)_0x1358bd[_0x44652a]=_0x5c1b3d[_0x44652a];return _0x1358bd;}else return _0x4075d8&&!this['getPriority']()['isEmpty']()&&(_0x5c1b3d['.priority']=this['getPriority']()['val']()),_0x5c1b3d;}['hash'](){if(this['lazyHash_']===null){let _0x6831c6='';this['getPriority']()['isEmpty']()||(_0x6831c6+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x28f54c,_0x1db52d)=>{const _0x276d25=_0x1db52d['hash']();_0x276d25!==''&&(_0x6831c6+=':'+_0x28f54c+':'+_0x276d25);}),this['lazyHash_']=_0x6831c6===''?'':ro(_0x6831c6);}return this['lazyHash_'];}['getPredecessorChildName'](_0x272bb0,_0x4a75be,_0x4b88a9){const _0x2f1817=this['resolveIndex_'](_0x4b88a9);if(_0x2f1817){const _0x5ec531=_0x2f1817['getPredecessorKey'](new E(_0x272bb0,_0x4a75be));return _0x5ec531?_0x5ec531['name']:null;}else return this['children_']['getPredecessorKey'](_0x272bb0);}['getFirstChildName'](_0xb0ee8d){const _0x1f4987=this['resolveIndex_'](_0xb0ee8d);if(_0x1f4987){const _0x35895b=_0x1f4987['minKey']();return _0x35895b&&_0x35895b['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x5d7127){const _0xf8ab24=this['getFirstChildName'](_0x5d7127);return _0xf8ab24?new E(_0xf8ab24,this['children_']['get'](_0xf8ab24)):null;}['getLastChildName'](_0x97870e){const _0xf0a328=this['resolveIndex_'](_0x97870e);if(_0xf0a328){const _0xc15673=_0xf0a328['maxKey']();return _0xc15673&&_0xc15673['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x24a71b){const _0x221304=this['getLastChildName'](_0x24a71b);return _0x221304?new E(_0x221304,this['children_']['get'](_0x221304)):null;}['forEachChild'](_0x8c2c8f,_0x16e551){const _0x31a1ab=this['resolveIndex_'](_0x8c2c8f);return _0x31a1ab?_0x31a1ab['inorderTraversal'](_0x3b2823=>_0x16e551(_0x3b2823['name'],_0x3b2823['node'])):this['children_']['inorderTraversal'](_0x16e551);}['getIterator'](_0x1c83b4){return this['getIteratorFrom'](_0x1c83b4['minPost'](),_0x1c83b4);}['getIteratorFrom'](_0x3803b2,_0x5f3a3f){const _0x1af817=this['resolveIndex_'](_0x5f3a3f);if(_0x1af817)return _0x1af817['getIteratorFrom'](_0x3803b2,_0x53a431=>_0x53a431);{const _0x1177ab=this['children_']['getIteratorFrom'](_0x3803b2['name'],E['Wrap']);let _0x13c24e=_0x1177ab['peek']();for(;_0x13c24e!=null&&_0x5f3a3f['compare'](_0x13c24e,_0x3803b2)<0x0;)_0x1177ab['getNext'](),_0x13c24e=_0x1177ab['peek']();return _0x1177ab;}}['getReverseIterator'](_0x4d9d06){return this['getReverseIteratorFrom'](_0x4d9d06['maxPost'](),_0x4d9d06);}['getReverseIteratorFrom'](_0x44eab1,_0x5da8ac){const _0x2992df=this['resolveIndex_'](_0x5da8ac);if(_0x2992df)return _0x2992df['getReverseIteratorFrom'](_0x44eab1,_0x39125d=>_0x39125d);{const _0x6f45aa=this['children_']['getReverseIteratorFrom'](_0x44eab1['name'],E['Wrap']);let _0x3d7194=_0x6f45aa['peek']();for(;_0x3d7194!=null&&_0x5da8ac['compare'](_0x3d7194,_0x44eab1)>0x0;)_0x6f45aa['getNext'](),_0x3d7194=_0x6f45aa['peek']();return _0x6f45aa;}}['compareTo'](_0x2cf629){return this['isEmpty']()?_0x2cf629['isEmpty']()?0x0:-0x1:_0x2cf629['isLeafNode']()||_0x2cf629['isEmpty']()?0x1:_0x2cf629===$t?-0x1:0x0;}['withIndex'](_0x99955b){if(_0x99955b===ye||this['indexMap_']['hasIndex'](_0x99955b))return this;{const _0x1c8072=this['indexMap_']['addIndex'](_0x99955b,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x1c8072);}}['isIndexed'](_0x55916c){return _0x55916c===ye||this['indexMap_']['hasIndex'](_0x55916c);}['equals'](_0x2e4b1b){if(_0x2e4b1b===this)return!0x0;if(_0x2e4b1b['isLeafNode']())return!0x1;{const _0x1e9c8a=_0x2e4b1b;if(this['getPriority']()['equals'](_0x1e9c8a['getPriority']())){if(this['children_']['count']()===_0x1e9c8a['children_']['count']()){const _0x378986=this['getIterator'](R),_0x191cb1=_0x1e9c8a['getIterator'](R);let _0x1ceb04=_0x378986['getNext'](),_0x512ee6=_0x191cb1['getNext']();for(;_0x1ceb04&&_0x512ee6;){if(_0x1ceb04['name']!==_0x512ee6['name']||!_0x1ceb04['node']['equals'](_0x512ee6['node']))return!0x1;_0x1ceb04=_0x378986['getNext'](),_0x512ee6=_0x191cb1['getNext']();}return _0x1ceb04===null&&_0x512ee6===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x5410da){return _0x5410da===ye?null:this['indexMap_']['get'](_0x5410da['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0xbcea61){return _0xbcea61===this?0x0:0x1;}['equals'](_0x3ee770){return _0x3ee770===this;}['getPriority'](){return this;}['getImmediateChild'](_0x5bd9cb){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x151edd,_0x2616df=null){if(_0x151edd===null)return g['EMPTY_NODE'];if(typeof _0x151edd=='object'&&'.priority'in _0x151edd&&(_0x2616df=_0x151edd['.priority']),f(_0x2616df===null||typeof _0x2616df=='string'||typeof _0x2616df=='number'||typeof _0x2616df=='object'&&'.sv'in _0x2616df,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x2616df),typeof _0x151edd=='object'&&'.value'in _0x151edd&&_0x151edd['.value']!==null&&(_0x151edd=_0x151edd['.value']),typeof _0x151edd!='object'||'.sv'in _0x151edd){const _0x3f1d3f=_0x151edd;return new D(_0x3f1d3f,P(_0x2616df));}if(!(_0x151edd instanceof Array)&&Gh){const _0x25bd2e=[];let _0x429dc0=!0x1;if(x(_0x151edd,(_0x56eaf3,_0x4fa2ec)=>{if(_0x56eaf3['substring'](0x0,0x1)!=='.'){const _0x3ce8b1=P(_0x4fa2ec);_0x3ce8b1['isEmpty']()||(_0x429dc0=_0x429dc0||!_0x3ce8b1['getPriority']()['isEmpty'](),_0x25bd2e['push'](new E(_0x56eaf3,_0x3ce8b1)));}}),_0x25bd2e['length']===0x0)return g['EMPTY_NODE'];const _0x29a15c=fn(_0x25bd2e,xh,_0x218ae3=>_0x218ae3['name'],Yi);if(_0x429dc0){const _0x5cf371=fn(_0x25bd2e,R['getCompare']());return new g(_0x29a15c,P(_0x2616df),new te({'.priority':_0x5cf371},{'.priority':R}));}else return new g(_0x29a15c,P(_0x2616df),te['Default']);}else{let _0x558f4e=g['EMPTY_NODE'];return x(_0x151edd,(_0x3e8fb1,_0x2134d4)=>{if(J(_0x151edd,_0x3e8fb1)&&_0x3e8fb1['substring'](0x0,0x1)!=='.'){const _0x5e9536=P(_0x2134d4);(_0x5e9536['isLeafNode']()||!_0x5e9536['isEmpty']())&&(_0x558f4e=_0x558f4e['updateImmediateChild'](_0x3e8fb1,_0x5e9536));}}),_0x558f4e['updatePriority'](P(_0x2616df));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x549464){super(),this['indexPath_']=_0x549464,f(!v(_0x549464)&&y(_0x549464)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0xb99f46){return _0xb99f46['getChild'](this['indexPath_']);}['isDefinedOn'](_0x1ff07c){return!_0x1ff07c['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0xdea7d6,_0x5ebdf2){const _0x5bc469=this['extractChild'](_0xdea7d6['node']),_0x2f6db7=this['extractChild'](_0x5ebdf2['node']),_0x44444e=_0x5bc469['compareTo'](_0x2f6db7);return _0x44444e===0x0?He(_0xdea7d6['name'],_0x5ebdf2['name']):_0x44444e;}['makePost'](_0x10a455,_0x2a50a0){const _0x14cdcb=P(_0x10a455),_0x197d2b=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x14cdcb);return new E(_0x2a50a0,_0x197d2b);}['maxPost'](){const _0x2b801d=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x2b801d);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x505e6d,_0xbaaaac){const _0x17228c=_0x505e6d['node']['compareTo'](_0xbaaaac['node']);return _0x17228c===0x0?He(_0x505e6d['name'],_0xbaaaac['name']):_0x17228c;}['isDefinedOn'](_0x25e0db){return!0x0;}['indexedValueChanged'](_0x5d707a,_0x49bd83){return!_0x5d707a['equals'](_0x49bd83);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x1e7616,_0x5f9bb3){const _0x35f94e=P(_0x1e7616);return new E(_0x5f9bb3,_0x35f94e);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x17f1a1){return{'type':'value','snapshotNode':_0x17f1a1};}function et(_0x4e75d7,_0x3d011e){return{'type':'child_added','snapshotNode':_0x3d011e,'childName':_0x4e75d7};}function Ot(_0x29c05c,_0x135586){return{'type':'child_removed','snapshotNode':_0x135586,'childName':_0x29c05c};}function Dt(_0x1848ff,_0xe0537a,_0x54ea1c){return{'type':'child_changed','snapshotNode':_0xe0537a,'childName':_0x1848ff,'oldSnap':_0x54ea1c};}function zh(_0x581f00,_0x474ad8){return{'type':'child_moved','snapshotNode':_0x474ad8,'childName':_0x581f00};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x1b2c0a){this['index_']=_0x1b2c0a;}['updateChild'](_0x4fd459,_0x3a68aa,_0x1148a5,_0x4afea8,_0xf095a0,_0x69593d){f(_0x4fd459['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x39b12c=_0x4fd459['getImmediateChild'](_0x3a68aa);return _0x39b12c['getChild'](_0x4afea8)['equals'](_0x1148a5['getChild'](_0x4afea8))&&_0x39b12c['isEmpty']()===_0x1148a5['isEmpty']()||(_0x69593d!=null&&(_0x1148a5['isEmpty']()?_0x4fd459['hasChild'](_0x3a68aa)?_0x69593d['trackChildChange'](Ot(_0x3a68aa,_0x39b12c)):f(_0x4fd459['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x39b12c['isEmpty']()?_0x69593d['trackChildChange'](et(_0x3a68aa,_0x1148a5)):_0x69593d['trackChildChange'](Dt(_0x3a68aa,_0x1148a5,_0x39b12c))),_0x4fd459['isLeafNode']()&&_0x1148a5['isEmpty']())?_0x4fd459:_0x4fd459['updateImmediateChild'](_0x3a68aa,_0x1148a5)['withIndex'](this['index_']);}['updateFullNode'](_0x20e898,_0x326353,_0x2cf1ce){return _0x2cf1ce!=null&&(_0x20e898['isLeafNode']()||_0x20e898['forEachChild'](R,(_0x212380,_0xf72d30)=>{_0x326353['hasChild'](_0x212380)||_0x2cf1ce['trackChildChange'](Ot(_0x212380,_0xf72d30));}),_0x326353['isLeafNode']()||_0x326353['forEachChild'](R,(_0x5afc31,_0x6cac61)=>{if(_0x20e898['hasChild'](_0x5afc31)){const _0x3e9a79=_0x20e898['getImmediateChild'](_0x5afc31);_0x3e9a79['equals'](_0x6cac61)||_0x2cf1ce['trackChildChange'](Dt(_0x5afc31,_0x6cac61,_0x3e9a79));}else _0x2cf1ce['trackChildChange'](et(_0x5afc31,_0x6cac61));})),_0x326353['withIndex'](this['index_']);}['updatePriority'](_0x33fda2,_0x543b01){return _0x33fda2['isEmpty']()?g['EMPTY_NODE']:_0x33fda2['updatePriority'](_0x543b01);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x1bc371){this['indexedFilter_']=new Ji(_0x1bc371['getIndex']()),this['index_']=_0x1bc371['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x1bc371),this['endPost_']=Mt['getEndPost_'](_0x1bc371),this['startIsInclusive_']=!_0x1bc371['startAfterSet_'],this['endIsInclusive_']=!_0x1bc371['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x234da7){const _0x492e98=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x234da7)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x234da7)<0x0,_0x1bed26=this['endIsInclusive_']?this['index_']['compare'](_0x234da7,this['getEndPost']())<=0x0:this['index_']['compare'](_0x234da7,this['getEndPost']())<0x0;return _0x492e98&&_0x1bed26;}['updateChild'](_0x5c8dd5,_0x53f15e,_0x54a970,_0x1ea67b,_0x4f3cbe,_0x214d3b){return this['matches'](new E(_0x53f15e,_0x54a970))||(_0x54a970=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x5c8dd5,_0x53f15e,_0x54a970,_0x1ea67b,_0x4f3cbe,_0x214d3b);}['updateFullNode'](_0x2ad52b,_0x1eda38,_0x5f2fe3){_0x1eda38['isLeafNode']()&&(_0x1eda38=g['EMPTY_NODE']);let _0x3128fe=_0x1eda38['withIndex'](this['index_']);_0x3128fe=_0x3128fe['updatePriority'](g['EMPTY_NODE']);const _0x24fcc8=this;return _0x1eda38['forEachChild'](R,(_0x30108e,_0x2d351d)=>{_0x24fcc8['matches'](new E(_0x30108e,_0x2d351d))||(_0x3128fe=_0x3128fe['updateImmediateChild'](_0x30108e,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x2ad52b,_0x3128fe,_0x5f2fe3);}['updatePriority'](_0x383fc7,_0x3805f4){return _0x383fc7;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x3ad7d1){if(_0x3ad7d1['hasStart']()){const _0x14b9fe=_0x3ad7d1['getIndexStartName']();return _0x3ad7d1['getIndex']()['makePost'](_0x3ad7d1['getIndexStartValue'](),_0x14b9fe);}else return _0x3ad7d1['getIndex']()['minPost']();}static['getEndPost_'](_0x34c86e){if(_0x34c86e['hasEnd']()){const _0x11bfa7=_0x34c86e['getIndexEndName']();return _0x34c86e['getIndex']()['makePost'](_0x34c86e['getIndexEndValue'](),_0x11bfa7);}else return _0x34c86e['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x28c6a7){this['withinDirectionalStart']=_0x553960=>this['reverse_']?this['withinEndPost'](_0x553960):this['withinStartPost'](_0x553960),this['withinDirectionalEnd']=_0x2c548a=>this['reverse_']?this['withinStartPost'](_0x2c548a):this['withinEndPost'](_0x2c548a),this['withinStartPost']=_0x290f12=>{const _0x347ac7=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x290f12);return this['startIsInclusive_']?_0x347ac7<=0x0:_0x347ac7<0x0;},this['withinEndPost']=_0xadc80c=>{const _0x3a9202=this['index_']['compare'](_0xadc80c,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x3a9202<=0x0:_0x3a9202<0x0;},this['rangedFilter_']=new Mt(_0x28c6a7),this['index_']=_0x28c6a7['getIndex'](),this['limit_']=_0x28c6a7['getLimit'](),this['reverse_']=!_0x28c6a7['isViewFromLeft'](),this['startIsInclusive_']=!_0x28c6a7['startAfterSet_'],this['endIsInclusive_']=!_0x28c6a7['endBeforeSet_'];}['updateChild'](_0x2c48de,_0x7e3d2b,_0x585832,_0x2a95e3,_0x128433,_0x1a6188){return this['rangedFilter_']['matches'](new E(_0x7e3d2b,_0x585832))||(_0x585832=g['EMPTY_NODE']),_0x2c48de['getImmediateChild'](_0x7e3d2b)['equals'](_0x585832)?_0x2c48de:_0x2c48de['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x2c48de,_0x7e3d2b,_0x585832,_0x2a95e3,_0x128433,_0x1a6188):this['fullLimitUpdateChild_'](_0x2c48de,_0x7e3d2b,_0x585832,_0x128433,_0x1a6188);}['updateFullNode'](_0x5ac57e,_0x115224,_0x116010){let _0x35b2da;if(_0x115224['isLeafNode']()||_0x115224['isEmpty']())_0x35b2da=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x115224['numChildren']()&&_0x115224['isIndexed'](this['index_'])){_0x35b2da=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x413b32;this['reverse_']?_0x413b32=_0x115224['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x413b32=_0x115224['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x3b7e60=0x0;for(;_0x413b32['hasNext']()&&_0x3b7e60<this['limit_'];){const _0x461a84=_0x413b32['getNext']();if(this['withinDirectionalStart'](_0x461a84)){if(this['withinDirectionalEnd'](_0x461a84))_0x35b2da=_0x35b2da['updateImmediateChild'](_0x461a84['name'],_0x461a84['node']),_0x3b7e60++;else break;}else continue;}}else{_0x35b2da=_0x115224['withIndex'](this['index_']),_0x35b2da=_0x35b2da['updatePriority'](g['EMPTY_NODE']);let _0x54250b;this['reverse_']?_0x54250b=_0x35b2da['getReverseIterator'](this['index_']):_0x54250b=_0x35b2da['getIterator'](this['index_']);let _0x47fc34=0x0;for(;_0x54250b['hasNext']();){const _0xc55ed9=_0x54250b['getNext']();_0x47fc34<this['limit_']&&this['withinDirectionalStart'](_0xc55ed9)&&this['withinDirectionalEnd'](_0xc55ed9)?_0x47fc34++:_0x35b2da=_0x35b2da['updateImmediateChild'](_0xc55ed9['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x5ac57e,_0x35b2da,_0x116010);}['updatePriority'](_0x640177,_0x43745d){return _0x640177;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x5c4c94,_0x544f99,_0x4ba4b6,_0x3638e2,_0x3ad912){let _0x551768;if(this['reverse_']){const _0x3a8146=this['index_']['getCompare']();_0x551768=(_0x5bcb11,_0x332948)=>_0x3a8146(_0x332948,_0x5bcb11);}else _0x551768=this['index_']['getCompare']();const _0x498afc=_0x5c4c94;f(_0x498afc['numChildren']()===this['limit_'],'');const _0x2a4e68=new E(_0x544f99,_0x4ba4b6),_0x2d3bf3=this['reverse_']?_0x498afc['getFirstChild'](this['index_']):_0x498afc['getLastChild'](this['index_']),_0x27d530=this['rangedFilter_']['matches'](_0x2a4e68);if(_0x498afc['hasChild'](_0x544f99)){const _0x58bef1=_0x498afc['getImmediateChild'](_0x544f99);let _0x3e751d=_0x3638e2['getChildAfterChild'](this['index_'],_0x2d3bf3,this['reverse_']);for(;_0x3e751d!=null&&(_0x3e751d['name']===_0x544f99||_0x498afc['hasChild'](_0x3e751d['name']));)_0x3e751d=_0x3638e2['getChildAfterChild'](this['index_'],_0x3e751d,this['reverse_']);const _0x3c8fa5=_0x3e751d==null?0x1:_0x551768(_0x3e751d,_0x2a4e68);if(_0x27d530&&!_0x4ba4b6['isEmpty']()&&_0x3c8fa5>=0x0)return _0x3ad912!=null&&_0x3ad912['trackChildChange'](Dt(_0x544f99,_0x4ba4b6,_0x58bef1)),_0x498afc['updateImmediateChild'](_0x544f99,_0x4ba4b6);{_0x3ad912!=null&&_0x3ad912['trackChildChange'](Ot(_0x544f99,_0x58bef1));const _0x1caff9=_0x498afc['updateImmediateChild'](_0x544f99,g['EMPTY_NODE']);return _0x3e751d!=null&&this['rangedFilter_']['matches'](_0x3e751d)?(_0x3ad912!=null&&_0x3ad912['trackChildChange'](et(_0x3e751d['name'],_0x3e751d['node'])),_0x1caff9['updateImmediateChild'](_0x3e751d['name'],_0x3e751d['node'])):_0x1caff9;}}else return _0x4ba4b6['isEmpty']()?_0x5c4c94:_0x27d530&&_0x551768(_0x2d3bf3,_0x2a4e68)>=0x0?(_0x3ad912!=null&&(_0x3ad912['trackChildChange'](Ot(_0x2d3bf3['name'],_0x2d3bf3['node'])),_0x3ad912['trackChildChange'](et(_0x544f99,_0x4ba4b6))),_0x498afc['updateImmediateChild'](_0x544f99,_0x4ba4b6)['updateImmediateChild'](_0x2d3bf3['name'],g['EMPTY_NODE'])):_0x5c4c94;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x5366d3=new Xi();return _0x5366d3['limitSet_']=this['limitSet_'],_0x5366d3['limit_']=this['limit_'],_0x5366d3['startSet_']=this['startSet_'],_0x5366d3['startAfterSet_']=this['startAfterSet_'],_0x5366d3['indexStartValue_']=this['indexStartValue_'],_0x5366d3['startNameSet_']=this['startNameSet_'],_0x5366d3['indexStartName_']=this['indexStartName_'],_0x5366d3['endSet_']=this['endSet_'],_0x5366d3['endBeforeSet_']=this['endBeforeSet_'],_0x5366d3['indexEndValue_']=this['indexEndValue_'],_0x5366d3['endNameSet_']=this['endNameSet_'],_0x5366d3['indexEndName_']=this['indexEndName_'],_0x5366d3['index_']=this['index_'],_0x5366d3['viewFrom_']=this['viewFrom_'],_0x5366d3;}}function Kh(_0xe866c5){return _0xe866c5['loadsAllData']()?new Ji(_0xe866c5['getIndex']()):_0xe866c5['hasLimit']()?new jh(_0xe866c5):new Mt(_0xe866c5);}function Yh(_0x445be2,_0x33fc1a){const _0x3f95c0=_0x445be2['copy']();return _0x3f95c0['limitSet_']=!0x0,_0x3f95c0['limit_']=_0x33fc1a,_0x3f95c0['viewFrom_']='l',_0x3f95c0;}function Qh(_0x3b2d47,_0x323da2,_0x3a989d){const _0x1d2864=_0x3b2d47['copy']();return _0x1d2864['startSet_']=!0x0,_0x323da2===void 0x0&&(_0x323da2=null),_0x1d2864['indexStartValue_']=_0x323da2,_0x3a989d!=null?(_0x1d2864['startNameSet_']=!0x0,_0x1d2864['indexStartName_']=_0x3a989d):(_0x1d2864['startNameSet_']=!0x1,_0x1d2864['indexStartName_']=''),_0x1d2864;}function Jh(_0x2f3f1a,_0x2df159,_0xda3369){const _0x354f14=_0x2f3f1a['copy']();return _0x354f14['endSet_']=!0x0,_0x2df159===void 0x0&&(_0x2df159=null),_0x354f14['indexEndValue_']=_0x2df159,_0xda3369!==void 0x0?(_0x354f14['endNameSet_']=!0x0,_0x354f14['indexEndName_']=_0xda3369):(_0x354f14['endNameSet_']=!0x1,_0x354f14['indexEndName_']=''),_0x354f14;}function xo(_0x3bf3ca,_0x4d6500){const _0x26d23b=_0x3bf3ca['copy']();return _0x26d23b['index_']=_0x4d6500,_0x26d23b;}function sr(_0x57d2c7){const _0x532d5a={};if(_0x57d2c7['isDefault']())return _0x532d5a;let _0x1f75bc;if(_0x57d2c7['index_']===R?_0x1f75bc='$priority':_0x57d2c7['index_']===Mo?_0x1f75bc='$value':_0x57d2c7['index_']===ye?_0x1f75bc='$key':(f(_0x57d2c7['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x1f75bc=_0x57d2c7['index_']['toString']()),_0x532d5a['orderBy']=O(_0x1f75bc),_0x57d2c7['startSet_']){const _0x3d4fc5=_0x57d2c7['startAfterSet_']?'startAfter':'startAt';_0x532d5a[_0x3d4fc5]=O(_0x57d2c7['indexStartValue_']),_0x57d2c7['startNameSet_']&&(_0x532d5a[_0x3d4fc5]+=','+O(_0x57d2c7['indexStartName_']));}if(_0x57d2c7['endSet_']){const _0x112927=_0x57d2c7['endBeforeSet_']?'endBefore':'endAt';_0x532d5a[_0x112927]=O(_0x57d2c7['indexEndValue_']),_0x57d2c7['endNameSet_']&&(_0x532d5a[_0x112927]+=','+O(_0x57d2c7['indexEndName_']));}return _0x57d2c7['limitSet_']&&(_0x57d2c7['isViewFromLeft']()?_0x532d5a['limitToFirst']=_0x57d2c7['limit_']:_0x532d5a['limitToLast']=_0x57d2c7['limit_']),_0x532d5a;}function rr(_0x4da177){const _0x44ba70={};if(_0x4da177['startSet_']&&(_0x44ba70['sp']=_0x4da177['indexStartValue_'],_0x4da177['startNameSet_']&&(_0x44ba70['sn']=_0x4da177['indexStartName_']),_0x44ba70['sin']=!_0x4da177['startAfterSet_']),_0x4da177['endSet_']&&(_0x44ba70['ep']=_0x4da177['indexEndValue_'],_0x4da177['endNameSet_']&&(_0x44ba70['en']=_0x4da177['indexEndName_']),_0x44ba70['ein']=!_0x4da177['endBeforeSet_']),_0x4da177['limitSet_']){_0x44ba70['l']=_0x4da177['limit_'];let _0x1e5ce6=_0x4da177['viewFrom_'];_0x1e5ce6===''&&(_0x4da177['isViewFromLeft']()?_0x1e5ce6='l':_0x1e5ce6='r'),_0x44ba70['vf']=_0x1e5ce6;}return _0x4da177['index_']!==R&&(_0x44ba70['i']=_0x4da177['index_']['toString']()),_0x44ba70;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x29a8c2){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x545e56,_0x2c63e3){return _0x2c63e3!==void 0x0?'tag$'+_0x2c63e3:(f(_0x545e56['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x545e56['_path']['toString']());}constructor(_0x5341b,_0x156ba2,_0x588801,_0x1ef57c){super(),this['repoInfo_']=_0x5341b,this['onDataUpdate_']=_0x156ba2,this['authTokenProvider_']=_0x588801,this['appCheckTokenProvider_']=_0x1ef57c,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0xbee68c,_0x5d2b43,_0x49a5ab,_0xb395c5){const _0x4b4a3c=_0xbee68c['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4b4a3c+'\x20'+_0xbee68c['_queryIdentifier']);const _0x45182e=pn['getListenId_'](_0xbee68c,_0x49a5ab),_0x473b3f={};this['listens_'][_0x45182e]=_0x473b3f;const _0x5d1527=sr(_0xbee68c['_queryParams']);this['restRequest_'](_0x4b4a3c+'.json',_0x5d1527,(_0x477a8b,_0x4575c1)=>{let _0x15b05a=_0x4575c1;if(_0x477a8b===0x194&&(_0x15b05a=null,_0x477a8b=null),_0x477a8b===null&&this['onDataUpdate_'](_0x4b4a3c,_0x15b05a,!0x1,_0x49a5ab),De(this['listens_'],_0x45182e)===_0x473b3f){let _0x1a3390;_0x477a8b?_0x477a8b===0x191?_0x1a3390='permission_denied':_0x1a3390='rest_error:'+_0x477a8b:_0x1a3390='ok',_0xb395c5(_0x1a3390,null);}});}['unlisten'](_0x4bca48,_0x294bd1){const _0x335641=pn['getListenId_'](_0x4bca48,_0x294bd1);delete this['listens_'][_0x335641];}['get'](_0x1d5935){const _0x45ea66=sr(_0x1d5935['_queryParams']),_0x58d78e=_0x1d5935['_path']['toString'](),_0x4a101e=new ot();return this['restRequest_'](_0x58d78e+'.json',_0x45ea66,(_0xc43fbf,_0x332cfc)=>{let _0x4bd36b=_0x332cfc;_0xc43fbf===0x194&&(_0x4bd36b=null,_0xc43fbf=null),_0xc43fbf===null?(this['onDataUpdate_'](_0x58d78e,_0x4bd36b,!0x1,null),_0x4a101e['resolve'](_0x4bd36b)):_0x4a101e['reject'](new Error(_0x4bd36b));}),_0x4a101e['promise'];}['refreshAuthToken'](_0x424f1f){}['restRequest_'](_0x1d091f,_0x58effa={},_0x351bbc){return _0x58effa['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x5237e1,_0x2a5165])=>{_0x5237e1&&_0x5237e1['accessToken']&&(_0x58effa['auth']=_0x5237e1['accessToken']),_0x2a5165&&_0x2a5165['token']&&(_0x58effa['ac']=_0x2a5165['token']);const _0xec2ef2=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x1d091f+'?ns='+this['repoInfo_']['namespace']+ct(_0x58effa);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0xec2ef2);const _0x4f32c6=new XMLHttpRequest();_0x4f32c6['onreadystatechange']=()=>{if(_0x351bbc&&_0x4f32c6['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0xec2ef2+'\x20received.\x20status:',_0x4f32c6['status'],'response:',_0x4f32c6['responseText']);let _0x1be635=null;if(_0x4f32c6['status']>=0xc8&&_0x4f32c6['status']<0x12c){try{_0x1be635=At(_0x4f32c6['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0xec2ef2+':\x20'+_0x4f32c6['responseText']);}_0x351bbc(null,_0x1be635);}else _0x4f32c6['status']!==0x191&&_0x4f32c6['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0xec2ef2+'\x20Status:\x20'+_0x4f32c6['status']),_0x351bbc(_0x4f32c6['status']);_0x351bbc=null;}},_0x4f32c6['open']('GET',_0xec2ef2,!0x0),_0x4f32c6['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x370ad9){return this['rootNode_']['getChild'](_0x370ad9);}['updateSnapshot'](_0x11ecf0,_0x4b596a){this['rootNode_']=this['rootNode_']['updateChild'](_0x11ecf0,_0x4b596a);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x405a7f,_0x341973,_0x2f54d9){if(v(_0x341973))_0x405a7f['value']=_0x2f54d9,_0x405a7f['children']['clear']();else{if(_0x405a7f['value']!==null)_0x405a7f['value']=_0x405a7f['value']['updateChild'](_0x341973,_0x2f54d9);else{const _0x461c72=y(_0x341973);_0x405a7f['children']['has'](_0x461c72)||_0x405a7f['children']['set'](_0x461c72,_n());const _0x5579e3=_0x405a7f['children']['get'](_0x461c72);_0x341973=b(_0x341973),Fo(_0x5579e3,_0x341973,_0x2f54d9);}}}function Ii(_0x4f6602,_0x205239,_0xce59ff){_0x4f6602['value']!==null?_0xce59ff(_0x205239,_0x4f6602['value']):Zh(_0x4f6602,(_0x44a482,_0x1ac98f)=>{const _0x43ba8c=new C(_0x205239['toString']()+'/'+_0x44a482);Ii(_0x1ac98f,_0x43ba8c,_0xce59ff);});}function Zh(_0x391ad1,_0x3e004c){_0x391ad1['children']['forEach']((_0x28ae1f,_0x4a26e8)=>{_0x3e004c(_0x4a26e8,_0x28ae1f);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x4904fd){this['collection_']=_0x4904fd,this['last_']=null;}['get'](){const _0x5a8dce=this['collection_']['get'](),_0x476b01={..._0x5a8dce};return this['last_']&&x(this['last_'],(_0x40d100,_0x454be5)=>{_0x476b01[_0x40d100]=_0x476b01[_0x40d100]-_0x454be5;}),this['last_']=_0x5a8dce,_0x476b01;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x5c954f,_0x378774){this['server_']=_0x378774,this['statsToReport_']={},this['statsListener_']=new eu(_0x5c954f);const _0x37c79c=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x37c79c));}['reportStats_'](){const _0xf941f3=this['statsListener_']['get'](),_0x322410={};let _0x395e27=!0x1;x(_0xf941f3,(_0x34f1a9,_0xf18d7f)=>{_0xf18d7f>0x0&&J(this['statsToReport_'],_0x34f1a9)&&(_0x322410[_0x34f1a9]=_0xf18d7f,_0x395e27=!0x0);}),_0x395e27&&this['server_']['reportStats'](_0x322410),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0xc65c9e){_0xc65c9e[_0xc65c9e['OVERWRITE']=0x0]='OVERWRITE',_0xc65c9e[_0xc65c9e['MERGE']=0x1]='MERGE',_0xc65c9e[_0xc65c9e['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0xc65c9e[_0xc65c9e['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x5eb901){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x5eb901,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x151402,_0xa1fb1c,_0x571638){this['path']=_0x151402,this['affectedTree']=_0xa1fb1c,this['revert']=_0x571638,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x4045ea){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x4f8607=this['affectedTree']['subtree'](new C(_0x4045ea));return new gn(w(),_0x4f8607,this['revert']);}}else return f(y(this['path'])===_0x4045ea,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x15cc85,_0x1ba83d){this['source']=_0x15cc85,this['path']=_0x1ba83d,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x15b0d0){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0xadccb3,_0x7de2ea,_0x5c885a){this['source']=_0xadccb3,this['path']=_0x7de2ea,this['snap']=_0x5c885a,this['type']=j['OVERWRITE'];}['operationForChild'](_0x3bf8d2){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x3bf8d2)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x16f500,_0x1b8621,_0x3bb73e){this['source']=_0x16f500,this['path']=_0x1b8621,this['children']=_0x3bb73e,this['type']=j['MERGE'];}['operationForChild'](_0x65c89a){if(v(this['path'])){const _0x4e8f2d=this['children']['subtree'](new C(_0x65c89a));return _0x4e8f2d['isEmpty']()?null:_0x4e8f2d['value']?new Ue(this['source'],w(),_0x4e8f2d['value']):new tt(this['source'],w(),_0x4e8f2d);}else return f(y(this['path'])===_0x65c89a,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x2c0cc1,_0x32fa9d,_0x1c8afc){this['node_']=_0x2c0cc1,this['fullyInitialized_']=_0x32fa9d,this['filtered_']=_0x1c8afc;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0xbe0fa){if(v(_0xbe0fa))return this['isFullyInitialized']()&&!this['filtered_'];const _0x1a7661=y(_0xbe0fa);return this['isCompleteForChild'](_0x1a7661);}['isCompleteForChild'](_0x4032e1){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x4032e1);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x25e245){this['query_']=_0x25e245,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x396d51,_0x43274d,_0x22adbe,_0x2f4dae){const _0x4d7751=[],_0x5a4121=[];return _0x43274d['forEach'](_0x10dac5=>{_0x10dac5['type']==='child_changed'&&_0x396d51['index_']['indexedValueChanged'](_0x10dac5['oldSnap'],_0x10dac5['snapshotNode'])&&_0x5a4121['push'](zh(_0x10dac5['childName'],_0x10dac5['snapshotNode']));}),yt(_0x396d51,_0x4d7751,'child_removed',_0x43274d,_0x2f4dae,_0x22adbe),yt(_0x396d51,_0x4d7751,'child_added',_0x43274d,_0x2f4dae,_0x22adbe),yt(_0x396d51,_0x4d7751,'child_moved',_0x5a4121,_0x2f4dae,_0x22adbe),yt(_0x396d51,_0x4d7751,'child_changed',_0x43274d,_0x2f4dae,_0x22adbe),yt(_0x396d51,_0x4d7751,'value',_0x43274d,_0x2f4dae,_0x22adbe),_0x4d7751;}function yt(_0x327323,_0x19ede2,_0x6ad16e,_0x145638,_0x5c46a8,_0x570a79){const _0x50913d=_0x145638['filter'](_0x4fced9=>_0x4fced9['type']===_0x6ad16e);_0x50913d['sort']((_0x34eb26,_0x403f7f)=>au(_0x327323,_0x34eb26,_0x403f7f)),_0x50913d['forEach'](_0x3e4022=>{const _0x38610d=ou(_0x327323,_0x3e4022,_0x570a79);_0x5c46a8['forEach'](_0x1cb8d6=>{_0x1cb8d6['respondsTo'](_0x3e4022['type'])&&_0x19ede2['push'](_0x1cb8d6['createEvent'](_0x38610d,_0x327323['query_']));});});}function ou(_0x3732e2,_0x593ac9,_0x51a5a4){return _0x593ac9['type']==='value'||_0x593ac9['type']==='child_removed'||(_0x593ac9['prevName']=_0x51a5a4['getPredecessorChildName'](_0x593ac9['childName'],_0x593ac9['snapshotNode'],_0x3732e2['index_'])),_0x593ac9;}function au(_0x553b06,_0x54eed5,_0x1708e0){if(_0x54eed5['childName']==null||_0x1708e0['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x3893c3=new E(_0x54eed5['childName'],_0x54eed5['snapshotNode']),_0x448a80=new E(_0x1708e0['childName'],_0x1708e0['snapshotNode']);return _0x553b06['index_']['compare'](_0x3893c3,_0x448a80);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x58121c,_0x5e5b24){return{'eventCache':_0x58121c,'serverCache':_0x5e5b24};}function Tt(_0x2adee2,_0x17f735,_0x73449,_0x38dd77){return Mn(new Ce(_0x17f735,_0x73449,_0x38dd77),_0x2adee2['serverCache']);}function Uo(_0x23ae2d,_0x2dae07,_0x2e808d,_0x4913b4){return Mn(_0x23ae2d['eventCache'],new Ce(_0x2dae07,_0x2e808d,_0x4913b4));}function mn(_0x5bd867){return _0x5bd867['eventCache']['isFullyInitialized']()?_0x5bd867['eventCache']['getNode']():null;}function We(_0x5bbe98){return _0x5bbe98['serverCache']['isFullyInitialized']()?_0x5bbe98['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x4c4779){let _0x19763b=new S(null);return x(_0x4c4779,(_0x113367,_0x4145d9)=>{_0x19763b=_0x19763b['set'](new C(_0x113367),_0x4145d9);}),_0x19763b;}constructor(_0x4d5456,_0x30e2ab=cu()){this['value']=_0x4d5456,this['children']=_0x30e2ab;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x2e5dc7,_0x5cc51f){if(this['value']!=null&&_0x5cc51f(this['value']))return{'path':w(),'value':this['value']};if(v(_0x2e5dc7))return null;{const _0x3cdd08=y(_0x2e5dc7),_0x5deae7=this['children']['get'](_0x3cdd08);if(_0x5deae7!==null){const _0x46574b=_0x5deae7['findRootMostMatchingPathAndValue'](b(_0x2e5dc7),_0x5cc51f);return _0x46574b!=null?{'path':k(new C(_0x3cdd08),_0x46574b['path']),'value':_0x46574b['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x15c9d8){return this['findRootMostMatchingPathAndValue'](_0x15c9d8,()=>!0x0);}['subtree'](_0x44317c){if(v(_0x44317c))return this;{const _0x6201ed=y(_0x44317c),_0x2c5ab8=this['children']['get'](_0x6201ed);return _0x2c5ab8!==null?_0x2c5ab8['subtree'](b(_0x44317c)):new S(null);}}['set'](_0x683e46,_0x264774){if(v(_0x683e46))return new S(_0x264774,this['children']);{const _0xad3051=y(_0x683e46),_0x3b2972=(this['children']['get'](_0xad3051)||new S(null))['set'](b(_0x683e46),_0x264774),_0x46cc6b=this['children']['insert'](_0xad3051,_0x3b2972);return new S(this['value'],_0x46cc6b);}}['remove'](_0x124e45){if(v(_0x124e45))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x390b32=y(_0x124e45),_0x28741f=this['children']['get'](_0x390b32);if(_0x28741f){const _0x169305=_0x28741f['remove'](b(_0x124e45));let _0x3ccfdf;return _0x169305['isEmpty']()?_0x3ccfdf=this['children']['remove'](_0x390b32):_0x3ccfdf=this['children']['insert'](_0x390b32,_0x169305),this['value']===null&&_0x3ccfdf['isEmpty']()?new S(null):new S(this['value'],_0x3ccfdf);}else return this;}}['get'](_0x5bf77e){if(v(_0x5bf77e))return this['value'];{const _0x10af3d=y(_0x5bf77e),_0x15396a=this['children']['get'](_0x10af3d);return _0x15396a?_0x15396a['get'](b(_0x5bf77e)):null;}}['setTree'](_0x1cf1c7,_0x109c34){if(v(_0x1cf1c7))return _0x109c34;{const _0x177e29=y(_0x1cf1c7),_0x327f96=(this['children']['get'](_0x177e29)||new S(null))['setTree'](b(_0x1cf1c7),_0x109c34);let _0x383418;return _0x327f96['isEmpty']()?_0x383418=this['children']['remove'](_0x177e29):_0x383418=this['children']['insert'](_0x177e29,_0x327f96),new S(this['value'],_0x383418);}}['fold'](_0x27b759){return this['fold_'](w(),_0x27b759);}['fold_'](_0x4b58a1,_0x149bfa){const _0x51d764={};return this['children']['inorderTraversal']((_0x53bdc8,_0x5e7909)=>{_0x51d764[_0x53bdc8]=_0x5e7909['fold_'](k(_0x4b58a1,_0x53bdc8),_0x149bfa);}),_0x149bfa(_0x4b58a1,this['value'],_0x51d764);}['findOnPath'](_0x537fdb,_0x156604){return this['findOnPath_'](_0x537fdb,w(),_0x156604);}['findOnPath_'](_0x3dfd86,_0xcbf51a,_0x251850){const _0x4566ba=this['value']?_0x251850(_0xcbf51a,this['value']):!0x1;if(_0x4566ba)return _0x4566ba;if(v(_0x3dfd86))return null;{const _0x9f836a=y(_0x3dfd86),_0x320503=this['children']['get'](_0x9f836a);return _0x320503?_0x320503['findOnPath_'](b(_0x3dfd86),k(_0xcbf51a,_0x9f836a),_0x251850):null;}}['foreachOnPath'](_0x3c21da,_0x31f294){return this['foreachOnPath_'](_0x3c21da,w(),_0x31f294);}['foreachOnPath_'](_0x3bcf0a,_0x3f7274,_0x1b39a2){if(v(_0x3bcf0a))return this;{this['value']&&_0x1b39a2(_0x3f7274,this['value']);const _0x11ff15=y(_0x3bcf0a),_0x41e17a=this['children']['get'](_0x11ff15);return _0x41e17a?_0x41e17a['foreachOnPath_'](b(_0x3bcf0a),k(_0x3f7274,_0x11ff15),_0x1b39a2):new S(null);}}['foreach'](_0x506166){this['foreach_'](w(),_0x506166);}['foreach_'](_0x60446d,_0x219632){this['children']['inorderTraversal']((_0x65e3ad,_0x3a0e8c)=>{_0x3a0e8c['foreach_'](k(_0x60446d,_0x65e3ad),_0x219632);}),this['value']&&_0x219632(_0x60446d,this['value']);}['foreachChild'](_0x483e11){this['children']['inorderTraversal']((_0x212bca,_0x34486d)=>{_0x34486d['value']&&_0x483e11(_0x212bca,_0x34486d['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x209cbf){this['writeTree_']=_0x209cbf;}static['empty'](){return new Y(new S(null));}}function St(_0x862583,_0xad152e,_0x4c43f4){if(v(_0xad152e))return new Y(new S(_0x4c43f4));{const _0x26cfef=_0x862583['writeTree_']['findRootMostValueAndPath'](_0xad152e);if(_0x26cfef!=null){const _0x490711=_0x26cfef['path'];let _0x258790=_0x26cfef['value'];const _0x1c7bef=F(_0x490711,_0xad152e);return _0x258790=_0x258790['updateChild'](_0x1c7bef,_0x4c43f4),new Y(_0x862583['writeTree_']['set'](_0x490711,_0x258790));}else{const _0x5489c5=new S(_0x4c43f4),_0x1fbc6e=_0x862583['writeTree_']['setTree'](_0xad152e,_0x5489c5);return new Y(_0x1fbc6e);}}}function wi(_0x42e83c,_0x15d350,_0x4e5cf5){let _0x274841=_0x42e83c;return x(_0x4e5cf5,(_0x1ab148,_0xd5dc76)=>{_0x274841=St(_0x274841,k(_0x15d350,_0x1ab148),_0xd5dc76);}),_0x274841;}function ar(_0x3c93bb,_0x5ab5be){if(v(_0x5ab5be))return Y['empty']();{const _0x410f7c=_0x3c93bb['writeTree_']['setTree'](_0x5ab5be,new S(null));return new Y(_0x410f7c);}}function Ci(_0x4ef3ea,_0x27c972){return $e(_0x4ef3ea,_0x27c972)!=null;}function $e(_0x27d3cd,_0x1816b2){const _0x8133e1=_0x27d3cd['writeTree_']['findRootMostValueAndPath'](_0x1816b2);return _0x8133e1!=null?_0x27d3cd['writeTree_']['get'](_0x8133e1['path'])['getChild'](F(_0x8133e1['path'],_0x1816b2)):null;}function cr(_0x369015){const _0x4b1ed5=[],_0x588f9a=_0x369015['writeTree_']['value'];return _0x588f9a!=null?_0x588f9a['isLeafNode']()||_0x588f9a['forEachChild'](R,(_0xbcd899,_0x1df983)=>{_0x4b1ed5['push'](new E(_0xbcd899,_0x1df983));}):_0x369015['writeTree_']['children']['inorderTraversal']((_0x2fc3d3,_0x122d30)=>{_0x122d30['value']!=null&&_0x4b1ed5['push'](new E(_0x2fc3d3,_0x122d30['value']));}),_0x4b1ed5;}function ve(_0x5691ac,_0x28233a){if(v(_0x28233a))return _0x5691ac;{const _0x4ace65=$e(_0x5691ac,_0x28233a);return _0x4ace65!=null?new Y(new S(_0x4ace65)):new Y(_0x5691ac['writeTree_']['subtree'](_0x28233a));}}function Ti(_0x20b772){return _0x20b772['writeTree_']['isEmpty']();}function nt(_0x482d10,_0x446c08){return Wo(w(),_0x482d10['writeTree_'],_0x446c08);}function Wo(_0x24b733,_0x263cce,_0x28e88d){if(_0x263cce['value']!=null)return _0x28e88d['updateChild'](_0x24b733,_0x263cce['value']);{let _0x38e364=null;return _0x263cce['children']['inorderTraversal']((_0x4ee375,_0x39d88e)=>{_0x4ee375==='.priority'?(f(_0x39d88e['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x38e364=_0x39d88e['value']):_0x28e88d=Wo(k(_0x24b733,_0x4ee375),_0x39d88e,_0x28e88d);}),!_0x28e88d['getChild'](_0x24b733)['isEmpty']()&&_0x38e364!==null&&(_0x28e88d=_0x28e88d['updateChild'](k(_0x24b733,'.priority'),_0x38e364)),_0x28e88d;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x162cfd,_0x57d614){return $o(_0x57d614,_0x162cfd);}function lu(_0x85baf0,_0xa811c6,_0x1fc288,_0x3735b1,_0xd2b4f){f(_0x3735b1>_0x85baf0['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0xd2b4f===void 0x0&&(_0xd2b4f=!0x0),_0x85baf0['allWrites']['push']({'path':_0xa811c6,'snap':_0x1fc288,'writeId':_0x3735b1,'visible':_0xd2b4f}),_0xd2b4f&&(_0x85baf0['visibleWrites']=St(_0x85baf0['visibleWrites'],_0xa811c6,_0x1fc288)),_0x85baf0['lastWriteId']=_0x3735b1;}function hu(_0x3ce63a,_0x587c08,_0x200ede,_0x1e7ed4){f(_0x1e7ed4>_0x3ce63a['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x3ce63a['allWrites']['push']({'path':_0x587c08,'children':_0x200ede,'writeId':_0x1e7ed4,'visible':!0x0}),_0x3ce63a['visibleWrites']=wi(_0x3ce63a['visibleWrites'],_0x587c08,_0x200ede),_0x3ce63a['lastWriteId']=_0x1e7ed4;}function uu(_0x5acff7,_0x457cbd){for(let _0x5832b1=0x0;_0x5832b1<_0x5acff7['allWrites']['length'];_0x5832b1++){const _0x5ae69c=_0x5acff7['allWrites'][_0x5832b1];if(_0x5ae69c['writeId']===_0x457cbd)return _0x5ae69c;}return null;}function du(_0x4ced62,_0x5f723e){const _0x54a16f=_0x4ced62['allWrites']['findIndex'](_0x400700=>_0x400700['writeId']===_0x5f723e);f(_0x54a16f>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x160795=_0x4ced62['allWrites'][_0x54a16f];_0x4ced62['allWrites']['splice'](_0x54a16f,0x1);let _0x14426c=_0x160795['visible'],_0x300cf6=!0x1,_0x5259ab=_0x4ced62['allWrites']['length']-0x1;for(;_0x14426c&&_0x5259ab>=0x0;){const _0x31c4de=_0x4ced62['allWrites'][_0x5259ab];_0x31c4de['visible']&&(_0x5259ab>=_0x54a16f&&fu(_0x31c4de,_0x160795['path'])?_0x14426c=!0x1:G(_0x160795['path'],_0x31c4de['path'])&&(_0x300cf6=!0x0)),_0x5259ab--;}if(_0x14426c){if(_0x300cf6)return pu(_0x4ced62),!0x0;if(_0x160795['snap'])_0x4ced62['visibleWrites']=ar(_0x4ced62['visibleWrites'],_0x160795['path']);else{const _0x3fdc8d=_0x160795['children'];x(_0x3fdc8d,_0x2e95ec=>{_0x4ced62['visibleWrites']=ar(_0x4ced62['visibleWrites'],k(_0x160795['path'],_0x2e95ec));});}return!0x0;}else return!0x1;}function fu(_0x19c85d,_0x38633c){if(_0x19c85d['snap'])return G(_0x19c85d['path'],_0x38633c);for(const _0x2dbf86 in _0x19c85d['children'])if(_0x19c85d['children']['hasOwnProperty'](_0x2dbf86)&&G(k(_0x19c85d['path'],_0x2dbf86),_0x38633c))return!0x0;return!0x1;}function pu(_0x23a9b1){_0x23a9b1['visibleWrites']=Bo(_0x23a9b1['allWrites'],_u,w()),_0x23a9b1['allWrites']['length']>0x0?_0x23a9b1['lastWriteId']=_0x23a9b1['allWrites'][_0x23a9b1['allWrites']['length']-0x1]['writeId']:_0x23a9b1['lastWriteId']=-0x1;}function _u(_0x24eb7a){return _0x24eb7a['visible'];}function Bo(_0x5c2233,_0x44b939,_0xd85b66){let _0x434a00=Y['empty']();for(let _0x3ab392=0x0;_0x3ab392<_0x5c2233['length'];++_0x3ab392){const _0x432859=_0x5c2233[_0x3ab392];if(_0x44b939(_0x432859)){const _0x3f0cd1=_0x432859['path'];let _0x9be80e;if(_0x432859['snap'])G(_0xd85b66,_0x3f0cd1)?(_0x9be80e=F(_0xd85b66,_0x3f0cd1),_0x434a00=St(_0x434a00,_0x9be80e,_0x432859['snap'])):G(_0x3f0cd1,_0xd85b66)&&(_0x9be80e=F(_0x3f0cd1,_0xd85b66),_0x434a00=St(_0x434a00,w(),_0x432859['snap']['getChild'](_0x9be80e)));else{if(_0x432859['children']){if(G(_0xd85b66,_0x3f0cd1))_0x9be80e=F(_0xd85b66,_0x3f0cd1),_0x434a00=wi(_0x434a00,_0x9be80e,_0x432859['children']);else{if(G(_0x3f0cd1,_0xd85b66)){if(_0x9be80e=F(_0x3f0cd1,_0xd85b66),v(_0x9be80e))_0x434a00=wi(_0x434a00,w(),_0x432859['children']);else{const _0x5a79b4=De(_0x432859['children'],y(_0x9be80e));if(_0x5a79b4){const _0x1410a7=_0x5a79b4['getChild'](b(_0x9be80e));_0x434a00=St(_0x434a00,w(),_0x1410a7);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x434a00;}function Vo(_0x461caf,_0x325539,_0x257569,_0x2a2f8d,_0x4ed012){if(!_0x2a2f8d&&!_0x4ed012){const _0x25e434=$e(_0x461caf['visibleWrites'],_0x325539);if(_0x25e434!=null)return _0x25e434;{const _0x238003=ve(_0x461caf['visibleWrites'],_0x325539);if(Ti(_0x238003))return _0x257569;if(_0x257569==null&&!Ci(_0x238003,w()))return null;{const _0x593cff=_0x257569||g['EMPTY_NODE'];return nt(_0x238003,_0x593cff);}}}else{const _0x295a47=ve(_0x461caf['visibleWrites'],_0x325539);if(!_0x4ed012&&Ti(_0x295a47))return _0x257569;if(!_0x4ed012&&_0x257569==null&&!Ci(_0x295a47,w()))return null;{const _0x1896ae=function(_0x204906){return(_0x204906['visible']||_0x4ed012)&&(!_0x2a2f8d||!~_0x2a2f8d['indexOf'](_0x204906['writeId']))&&(G(_0x204906['path'],_0x325539)||G(_0x325539,_0x204906['path']));},_0x8fdfa9=Bo(_0x461caf['allWrites'],_0x1896ae,_0x325539),_0x5b29a9=_0x257569||g['EMPTY_NODE'];return nt(_0x8fdfa9,_0x5b29a9);}}}function gu(_0x5dab4d,_0x23a97b,_0x1df267){let _0x454a2b=g['EMPTY_NODE'];const _0x467e7f=$e(_0x5dab4d['visibleWrites'],_0x23a97b);if(_0x467e7f)return _0x467e7f['isLeafNode']()||_0x467e7f['forEachChild'](R,(_0x30a792,_0x33cb26)=>{_0x454a2b=_0x454a2b['updateImmediateChild'](_0x30a792,_0x33cb26);}),_0x454a2b;if(_0x1df267){const _0x466b62=ve(_0x5dab4d['visibleWrites'],_0x23a97b);return _0x1df267['forEachChild'](R,(_0xac889d,_0x2c863a)=>{const _0x4bb6b4=nt(ve(_0x466b62,new C(_0xac889d)),_0x2c863a);_0x454a2b=_0x454a2b['updateImmediateChild'](_0xac889d,_0x4bb6b4);}),cr(_0x466b62)['forEach'](_0x480d55=>{_0x454a2b=_0x454a2b['updateImmediateChild'](_0x480d55['name'],_0x480d55['node']);}),_0x454a2b;}else{const _0x53f24c=ve(_0x5dab4d['visibleWrites'],_0x23a97b);return cr(_0x53f24c)['forEach'](_0x105f96=>{_0x454a2b=_0x454a2b['updateImmediateChild'](_0x105f96['name'],_0x105f96['node']);}),_0x454a2b;}}function mu(_0x4bec59,_0x576637,_0x3d43b0,_0x55f6a2,_0x4943ab){f(_0x55f6a2||_0x4943ab,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x597f6c=k(_0x576637,_0x3d43b0);if(Ci(_0x4bec59['visibleWrites'],_0x597f6c))return null;{const _0x49a1ff=ve(_0x4bec59['visibleWrites'],_0x597f6c);return Ti(_0x49a1ff)?_0x4943ab['getChild'](_0x3d43b0):nt(_0x49a1ff,_0x4943ab['getChild'](_0x3d43b0));}}function yu(_0x226f43,_0x466b0f,_0x527260,_0x4d71b8){const _0x2536ba=k(_0x466b0f,_0x527260),_0x2600f8=$e(_0x226f43['visibleWrites'],_0x2536ba);if(_0x2600f8!=null)return _0x2600f8;if(_0x4d71b8['isCompleteForChild'](_0x527260)){const _0x3a423b=ve(_0x226f43['visibleWrites'],_0x2536ba);return nt(_0x3a423b,_0x4d71b8['getNode']()['getImmediateChild'](_0x527260));}else return null;}function vu(_0x534ccd,_0x12dc2b){return $e(_0x534ccd['visibleWrites'],_0x12dc2b);}function Eu(_0x40bc05,_0x169c0e,_0x478df3,_0x37ddfc,_0x356b43,_0x46ba2c,_0x3b8ac2){let _0xfc9b65;const _0x5badd1=ve(_0x40bc05['visibleWrites'],_0x169c0e),_0x3f2c36=$e(_0x5badd1,w());if(_0x3f2c36!=null)_0xfc9b65=_0x3f2c36;else{if(_0x478df3!=null)_0xfc9b65=nt(_0x5badd1,_0x478df3);else return[];}if(_0xfc9b65=_0xfc9b65['withIndex'](_0x3b8ac2),!_0xfc9b65['isEmpty']()&&!_0xfc9b65['isLeafNode']()){const _0x292055=[],_0x3f11a1=_0x3b8ac2['getCompare'](),_0x49b867=_0x46ba2c?_0xfc9b65['getReverseIteratorFrom'](_0x37ddfc,_0x3b8ac2):_0xfc9b65['getIteratorFrom'](_0x37ddfc,_0x3b8ac2);let _0x3b53dc=_0x49b867['getNext']();for(;_0x3b53dc&&_0x292055['length']<_0x356b43;)_0x3f11a1(_0x3b53dc,_0x37ddfc)!==0x0&&_0x292055['push'](_0x3b53dc),_0x3b53dc=_0x49b867['getNext']();return _0x292055;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x285229,_0x45c90f,_0x563a55,_0x42fe2f){return Vo(_0x285229['writeTree'],_0x285229['treePath'],_0x45c90f,_0x563a55,_0x42fe2f);}function ns(_0x15e587,_0xb55db8){return gu(_0x15e587['writeTree'],_0x15e587['treePath'],_0xb55db8);}function lr(_0x1f346c,_0xa560f8,_0x5186d3,_0x5124ea){return mu(_0x1f346c['writeTree'],_0x1f346c['treePath'],_0xa560f8,_0x5186d3,_0x5124ea);}function vn(_0x1a3e8d,_0x1b98d9){return vu(_0x1a3e8d['writeTree'],k(_0x1a3e8d['treePath'],_0x1b98d9));}function wu(_0x31c326,_0x3918b8,_0x18e33c,_0x368d49,_0x53664c,_0xeeacf9){return Eu(_0x31c326['writeTree'],_0x31c326['treePath'],_0x3918b8,_0x18e33c,_0x368d49,_0x53664c,_0xeeacf9);}function is(_0x620d38,_0x18b4ae,_0x526267){return yu(_0x620d38['writeTree'],_0x620d38['treePath'],_0x18b4ae,_0x526267);}function Ho(_0x105658,_0x223a9d){return $o(k(_0x105658['treePath'],_0x223a9d),_0x105658['writeTree']);}function $o(_0x152a68,_0x2149bb){return{'treePath':_0x152a68,'writeTree':_0x2149bb};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x393d71){const _0x4358ef=_0x393d71['type'],_0x2b4e52=_0x393d71['childName'];f(_0x4358ef==='child_added'||_0x4358ef==='child_changed'||_0x4358ef==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2b4e52!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x360b55=this['changeMap']['get'](_0x2b4e52);if(_0x360b55){const _0x4f121e=_0x360b55['type'];if(_0x4358ef==='child_added'&&_0x4f121e==='child_removed')this['changeMap']['set'](_0x2b4e52,Dt(_0x2b4e52,_0x393d71['snapshotNode'],_0x360b55['snapshotNode']));else{if(_0x4358ef==='child_removed'&&_0x4f121e==='child_added')this['changeMap']['delete'](_0x2b4e52);else{if(_0x4358ef==='child_removed'&&_0x4f121e==='child_changed')this['changeMap']['set'](_0x2b4e52,Ot(_0x2b4e52,_0x360b55['oldSnap']));else{if(_0x4358ef==='child_changed'&&_0x4f121e==='child_added')this['changeMap']['set'](_0x2b4e52,et(_0x2b4e52,_0x393d71['snapshotNode']));else{if(_0x4358ef==='child_changed'&&_0x4f121e==='child_changed')this['changeMap']['set'](_0x2b4e52,Dt(_0x2b4e52,_0x393d71['snapshotNode'],_0x360b55['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x393d71+'\x20occurred\x20after\x20'+_0x360b55);}}}}}else this['changeMap']['set'](_0x2b4e52,_0x393d71);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x3d2c5a){return null;}['getChildAfterChild'](_0x5c5c6d,_0x5cf857,_0x1bd681){return null;}}const Go=new Tu();class ss{constructor(_0x306764,_0x4c5835,_0x5101ed=null){this['writes_']=_0x306764,this['viewCache_']=_0x4c5835,this['optCompleteServerCache_']=_0x5101ed;}['getCompleteChild'](_0x1a8e48){const _0x25649f=this['viewCache_']['eventCache'];if(_0x25649f['isCompleteForChild'](_0x1a8e48))return _0x25649f['getNode']()['getImmediateChild'](_0x1a8e48);{const _0x58961b=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x1a8e48,_0x58961b);}}['getChildAfterChild'](_0x505352,_0x2aa1e2,_0x21da35){const _0x59ab52=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x2c84e4=wu(this['writes_'],_0x59ab52,_0x2aa1e2,0x1,_0x21da35,_0x505352);return _0x2c84e4['length']===0x0?null:_0x2c84e4[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x3c43fa){return{'filter':_0x3c43fa};}function bu(_0x12dc3f,_0x3d12d8){f(_0x3d12d8['eventCache']['getNode']()['isIndexed'](_0x12dc3f['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x3d12d8['serverCache']['getNode']()['isIndexed'](_0x12dc3f['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x13502c,_0x417bfa,_0x2001e4,_0x2853a9,_0x582a00){const _0xb18075=new Cu();let _0x218925,_0x416a9c;if(_0x2001e4['type']===j['OVERWRITE']){const _0x18c144=_0x2001e4;_0x18c144['source']['fromUser']?_0x218925=Si(_0x13502c,_0x417bfa,_0x18c144['path'],_0x18c144['snap'],_0x2853a9,_0x582a00,_0xb18075):(f(_0x18c144['source']['fromServer'],'Unknown\x20source.'),_0x416a9c=_0x18c144['source']['tagged']||_0x417bfa['serverCache']['isFiltered']()&&!v(_0x18c144['path']),_0x218925=En(_0x13502c,_0x417bfa,_0x18c144['path'],_0x18c144['snap'],_0x2853a9,_0x582a00,_0x416a9c,_0xb18075));}else{if(_0x2001e4['type']===j['MERGE']){const _0x3cc058=_0x2001e4;_0x3cc058['source']['fromUser']?_0x218925=ku(_0x13502c,_0x417bfa,_0x3cc058['path'],_0x3cc058['children'],_0x2853a9,_0x582a00,_0xb18075):(f(_0x3cc058['source']['fromServer'],'Unknown\x20source.'),_0x416a9c=_0x3cc058['source']['tagged']||_0x417bfa['serverCache']['isFiltered'](),_0x218925=bi(_0x13502c,_0x417bfa,_0x3cc058['path'],_0x3cc058['children'],_0x2853a9,_0x582a00,_0x416a9c,_0xb18075));}else{if(_0x2001e4['type']===j['ACK_USER_WRITE']){const _0xeaa21f=_0x2001e4;_0xeaa21f['revert']?_0x218925=Ou(_0x13502c,_0x417bfa,_0xeaa21f['path'],_0x2853a9,_0x582a00,_0xb18075):_0x218925=Nu(_0x13502c,_0x417bfa,_0xeaa21f['path'],_0xeaa21f['affectedTree'],_0x2853a9,_0x582a00,_0xb18075);}else{if(_0x2001e4['type']===j['LISTEN_COMPLETE'])_0x218925=Pu(_0x13502c,_0x417bfa,_0x2001e4['path'],_0x2853a9,_0xb18075);else throw rt('Unknown\x20operation\x20type:\x20'+_0x2001e4['type']);}}}const _0x7e3f9d=_0xb18075['getChanges']();return Au(_0x417bfa,_0x218925,_0x7e3f9d),{'viewCache':_0x218925,'changes':_0x7e3f9d};}function Au(_0x1e3013,_0x15b1ce,_0x818108){const _0x3323e6=_0x15b1ce['eventCache'];if(_0x3323e6['isFullyInitialized']()){const _0x10669b=_0x3323e6['getNode']()['isLeafNode']()||_0x3323e6['getNode']()['isEmpty'](),_0x528018=mn(_0x1e3013);(_0x818108['length']>0x0||!_0x1e3013['eventCache']['isFullyInitialized']()||_0x10669b&&!_0x3323e6['getNode']()['equals'](_0x528018)||!_0x3323e6['getNode']()['getPriority']()['equals'](_0x528018['getPriority']()))&&_0x818108['push'](Lo(mn(_0x15b1ce)));}}function qo(_0xf6709e,_0xe280e8,_0x22b167,_0x564b49,_0xbf6c05,_0x290b8d){const _0x4efd3b=_0xe280e8['eventCache'];if(vn(_0x564b49,_0x22b167)!=null)return _0xe280e8;{let _0x1c7d5d,_0x27c612;if(v(_0x22b167)){if(f(_0xe280e8['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0xe280e8['serverCache']['isFiltered']()){const _0x5af490=We(_0xe280e8),_0x20dbea=_0x5af490 instanceof g?_0x5af490:g['EMPTY_NODE'],_0x45c62e=ns(_0x564b49,_0x20dbea);_0x1c7d5d=_0xf6709e['filter']['updateFullNode'](_0xe280e8['eventCache']['getNode'](),_0x45c62e,_0x290b8d);}else{const _0x2f4fcb=yn(_0x564b49,We(_0xe280e8));_0x1c7d5d=_0xf6709e['filter']['updateFullNode'](_0xe280e8['eventCache']['getNode'](),_0x2f4fcb,_0x290b8d);}}else{const _0x2888c8=y(_0x22b167);if(_0x2888c8==='.priority'){f(we(_0x22b167)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0xbce964=_0x4efd3b['getNode']();_0x27c612=_0xe280e8['serverCache']['getNode']();const _0x1abd38=lr(_0x564b49,_0x22b167,_0xbce964,_0x27c612);_0x1abd38!=null?_0x1c7d5d=_0xf6709e['filter']['updatePriority'](_0xbce964,_0x1abd38):_0x1c7d5d=_0x4efd3b['getNode']();}else{const _0x3b78e5=b(_0x22b167);let _0x263a19;if(_0x4efd3b['isCompleteForChild'](_0x2888c8)){_0x27c612=_0xe280e8['serverCache']['getNode']();const _0x41c6bc=lr(_0x564b49,_0x22b167,_0x4efd3b['getNode'](),_0x27c612);_0x41c6bc!=null?_0x263a19=_0x4efd3b['getNode']()['getImmediateChild'](_0x2888c8)['updateChild'](_0x3b78e5,_0x41c6bc):_0x263a19=_0x4efd3b['getNode']()['getImmediateChild'](_0x2888c8);}else _0x263a19=is(_0x564b49,_0x2888c8,_0xe280e8['serverCache']);_0x263a19!=null?_0x1c7d5d=_0xf6709e['filter']['updateChild'](_0x4efd3b['getNode'](),_0x2888c8,_0x263a19,_0x3b78e5,_0xbf6c05,_0x290b8d):_0x1c7d5d=_0x4efd3b['getNode']();}}return Tt(_0xe280e8,_0x1c7d5d,_0x4efd3b['isFullyInitialized']()||v(_0x22b167),_0xf6709e['filter']['filtersNodes']());}}function En(_0x187d31,_0xa21689,_0x1c334f,_0x4f4faf,_0x3cd210,_0x5eeaf1,_0x1230ab,_0x747846){const _0x2f45c9=_0xa21689['serverCache'];let _0x46b6b5;const _0x430bfb=_0x1230ab?_0x187d31['filter']:_0x187d31['filter']['getIndexedFilter']();if(v(_0x1c334f))_0x46b6b5=_0x430bfb['updateFullNode'](_0x2f45c9['getNode'](),_0x4f4faf,null);else{if(_0x430bfb['filtersNodes']()&&!_0x2f45c9['isFiltered']()){const _0x5ad06f=_0x2f45c9['getNode']()['updateChild'](_0x1c334f,_0x4f4faf);_0x46b6b5=_0x430bfb['updateFullNode'](_0x2f45c9['getNode'](),_0x5ad06f,null);}else{const _0x552c09=y(_0x1c334f);if(!_0x2f45c9['isCompleteForPath'](_0x1c334f)&&we(_0x1c334f)>0x1)return _0xa21689;const _0x27999b=b(_0x1c334f),_0xb69ca9=_0x2f45c9['getNode']()['getImmediateChild'](_0x552c09)['updateChild'](_0x27999b,_0x4f4faf);_0x552c09==='.priority'?_0x46b6b5=_0x430bfb['updatePriority'](_0x2f45c9['getNode'](),_0xb69ca9):_0x46b6b5=_0x430bfb['updateChild'](_0x2f45c9['getNode'](),_0x552c09,_0xb69ca9,_0x27999b,Go,null);}}const _0x27183d=Uo(_0xa21689,_0x46b6b5,_0x2f45c9['isFullyInitialized']()||v(_0x1c334f),_0x430bfb['filtersNodes']()),_0x3522cd=new ss(_0x3cd210,_0x27183d,_0x5eeaf1);return qo(_0x187d31,_0x27183d,_0x1c334f,_0x3cd210,_0x3522cd,_0x747846);}function Si(_0x465247,_0x386631,_0x1c27e3,_0x5f4dc0,_0x3cdbc8,_0x1b5bf7,_0x5a34c6){const _0x37dbdb=_0x386631['eventCache'];let _0x507e4a,_0x5cd4a5;const _0x306ec2=new ss(_0x3cdbc8,_0x386631,_0x1b5bf7);if(v(_0x1c27e3))_0x5cd4a5=_0x465247['filter']['updateFullNode'](_0x386631['eventCache']['getNode'](),_0x5f4dc0,_0x5a34c6),_0x507e4a=Tt(_0x386631,_0x5cd4a5,!0x0,_0x465247['filter']['filtersNodes']());else{const _0x58c462=y(_0x1c27e3);if(_0x58c462==='.priority')_0x5cd4a5=_0x465247['filter']['updatePriority'](_0x386631['eventCache']['getNode'](),_0x5f4dc0),_0x507e4a=Tt(_0x386631,_0x5cd4a5,_0x37dbdb['isFullyInitialized'](),_0x37dbdb['isFiltered']());else{const _0x2e19c6=b(_0x1c27e3),_0x34acc9=_0x37dbdb['getNode']()['getImmediateChild'](_0x58c462);let _0x514671;if(v(_0x2e19c6))_0x514671=_0x5f4dc0;else{const _0xa2df=_0x306ec2['getCompleteChild'](_0x58c462);_0xa2df!=null?zi(_0x2e19c6)==='.priority'&&_0xa2df['getChild'](Ro(_0x2e19c6))['isEmpty']()?_0x514671=_0xa2df:_0x514671=_0xa2df['updateChild'](_0x2e19c6,_0x5f4dc0):_0x514671=g['EMPTY_NODE'];}if(_0x34acc9['equals'](_0x514671))_0x507e4a=_0x386631;else{const _0xd5cb1a=_0x465247['filter']['updateChild'](_0x37dbdb['getNode'](),_0x58c462,_0x514671,_0x2e19c6,_0x306ec2,_0x5a34c6);_0x507e4a=Tt(_0x386631,_0xd5cb1a,_0x37dbdb['isFullyInitialized'](),_0x465247['filter']['filtersNodes']());}}}return _0x507e4a;}function hr(_0x52a6d1,_0x9110cd){return _0x52a6d1['eventCache']['isCompleteForChild'](_0x9110cd);}function ku(_0x254e71,_0x129c20,_0x28ceaa,_0x323b0e,_0x430e0b,_0x4ec670,_0x43e4a8){let _0x57e416=_0x129c20;return _0x323b0e['foreach']((_0x1da101,_0x1bda73)=>{const _0x3d430c=k(_0x28ceaa,_0x1da101);hr(_0x129c20,y(_0x3d430c))&&(_0x57e416=Si(_0x254e71,_0x57e416,_0x3d430c,_0x1bda73,_0x430e0b,_0x4ec670,_0x43e4a8));}),_0x323b0e['foreach']((_0x26b708,_0x1e9285)=>{const _0x388544=k(_0x28ceaa,_0x26b708);hr(_0x129c20,y(_0x388544))||(_0x57e416=Si(_0x254e71,_0x57e416,_0x388544,_0x1e9285,_0x430e0b,_0x4ec670,_0x43e4a8));}),_0x57e416;}function ur(_0x245285,_0x342d5b,_0x37da1d){return _0x37da1d['foreach']((_0x53aea9,_0x2e6bbd)=>{_0x342d5b=_0x342d5b['updateChild'](_0x53aea9,_0x2e6bbd);}),_0x342d5b;}function bi(_0x4766f1,_0x256a04,_0x40a3c8,_0x5abb2e,_0x1f3677,_0xc2cca2,_0x30fed1,_0x291c26){if(_0x256a04['serverCache']['getNode']()['isEmpty']()&&!_0x256a04['serverCache']['isFullyInitialized']())return _0x256a04;let _0x1a3857=_0x256a04,_0x4085ff;v(_0x40a3c8)?_0x4085ff=_0x5abb2e:_0x4085ff=new S(null)['setTree'](_0x40a3c8,_0x5abb2e);const _0x13fd7e=_0x256a04['serverCache']['getNode']();return _0x4085ff['children']['inorderTraversal']((_0x40adac,_0x162d43)=>{if(_0x13fd7e['hasChild'](_0x40adac)){const _0x300323=_0x256a04['serverCache']['getNode']()['getImmediateChild'](_0x40adac),_0x13e1e3=ur(_0x4766f1,_0x300323,_0x162d43);_0x1a3857=En(_0x4766f1,_0x1a3857,new C(_0x40adac),_0x13e1e3,_0x1f3677,_0xc2cca2,_0x30fed1,_0x291c26);}}),_0x4085ff['children']['inorderTraversal']((_0x7a9874,_0x97f8af)=>{const _0x4f5a60=!_0x256a04['serverCache']['isCompleteForChild'](_0x7a9874)&&_0x97f8af['value']===null;if(!_0x13fd7e['hasChild'](_0x7a9874)&&!_0x4f5a60){const _0x1d82ba=_0x256a04['serverCache']['getNode']()['getImmediateChild'](_0x7a9874),_0x33facb=ur(_0x4766f1,_0x1d82ba,_0x97f8af);_0x1a3857=En(_0x4766f1,_0x1a3857,new C(_0x7a9874),_0x33facb,_0x1f3677,_0xc2cca2,_0x30fed1,_0x291c26);}}),_0x1a3857;}function Nu(_0x30061e,_0x106e11,_0x5ec84e,_0x3e9d91,_0x5ad233,_0x545668,_0x5ccde6){if(vn(_0x5ad233,_0x5ec84e)!=null)return _0x106e11;const _0x2daed0=_0x106e11['serverCache']['isFiltered'](),_0x242697=_0x106e11['serverCache'];if(_0x3e9d91['value']!=null){if(v(_0x5ec84e)&&_0x242697['isFullyInitialized']()||_0x242697['isCompleteForPath'](_0x5ec84e))return En(_0x30061e,_0x106e11,_0x5ec84e,_0x242697['getNode']()['getChild'](_0x5ec84e),_0x5ad233,_0x545668,_0x2daed0,_0x5ccde6);if(v(_0x5ec84e)){let _0x519c23=new S(null);return _0x242697['getNode']()['forEachChild'](ye,(_0x5d3495,_0x456a52)=>{_0x519c23=_0x519c23['set'](new C(_0x5d3495),_0x456a52);}),bi(_0x30061e,_0x106e11,_0x5ec84e,_0x519c23,_0x5ad233,_0x545668,_0x2daed0,_0x5ccde6);}else return _0x106e11;}else{let _0x362242=new S(null);return _0x3e9d91['foreach']((_0x287865,_0x545367)=>{const _0x36d0ad=k(_0x5ec84e,_0x287865);_0x242697['isCompleteForPath'](_0x36d0ad)&&(_0x362242=_0x362242['set'](_0x287865,_0x242697['getNode']()['getChild'](_0x36d0ad)));}),bi(_0x30061e,_0x106e11,_0x5ec84e,_0x362242,_0x5ad233,_0x545668,_0x2daed0,_0x5ccde6);}}function Pu(_0x3bc760,_0x42d34d,_0x165685,_0x184ec4,_0x20d520){const _0x5bc04a=_0x42d34d['serverCache'],_0xcaf406=Uo(_0x42d34d,_0x5bc04a['getNode'](),_0x5bc04a['isFullyInitialized']()||v(_0x165685),_0x5bc04a['isFiltered']());return qo(_0x3bc760,_0xcaf406,_0x165685,_0x184ec4,Go,_0x20d520);}function Ou(_0x58e23a,_0x18bdef,_0xcf12c9,_0x9d315d,_0x51f126,_0x1fee91){let _0x49546c;if(vn(_0x9d315d,_0xcf12c9)!=null)return _0x18bdef;{const _0x3fd941=new ss(_0x9d315d,_0x18bdef,_0x51f126),_0x3b0e94=_0x18bdef['eventCache']['getNode']();let _0x4c4b60;if(v(_0xcf12c9)||y(_0xcf12c9)==='.priority'){let _0x4b1f11;if(_0x18bdef['serverCache']['isFullyInitialized']())_0x4b1f11=yn(_0x9d315d,We(_0x18bdef));else{const _0x1bf4d9=_0x18bdef['serverCache']['getNode']();f(_0x1bf4d9 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x4b1f11=ns(_0x9d315d,_0x1bf4d9);}_0x4b1f11=_0x4b1f11,_0x4c4b60=_0x58e23a['filter']['updateFullNode'](_0x3b0e94,_0x4b1f11,_0x1fee91);}else{const _0x88984a=y(_0xcf12c9);let _0x2a67ed=is(_0x9d315d,_0x88984a,_0x18bdef['serverCache']);_0x2a67ed==null&&_0x18bdef['serverCache']['isCompleteForChild'](_0x88984a)&&(_0x2a67ed=_0x3b0e94['getImmediateChild'](_0x88984a)),_0x2a67ed!=null?_0x4c4b60=_0x58e23a['filter']['updateChild'](_0x3b0e94,_0x88984a,_0x2a67ed,b(_0xcf12c9),_0x3fd941,_0x1fee91):_0x18bdef['eventCache']['getNode']()['hasChild'](_0x88984a)?_0x4c4b60=_0x58e23a['filter']['updateChild'](_0x3b0e94,_0x88984a,g['EMPTY_NODE'],b(_0xcf12c9),_0x3fd941,_0x1fee91):_0x4c4b60=_0x3b0e94,_0x4c4b60['isEmpty']()&&_0x18bdef['serverCache']['isFullyInitialized']()&&(_0x49546c=yn(_0x9d315d,We(_0x18bdef)),_0x49546c['isLeafNode']()&&(_0x4c4b60=_0x58e23a['filter']['updateFullNode'](_0x4c4b60,_0x49546c,_0x1fee91)));}return _0x49546c=_0x18bdef['serverCache']['isFullyInitialized']()||vn(_0x9d315d,w())!=null,Tt(_0x18bdef,_0x4c4b60,_0x49546c,_0x58e23a['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x300160,_0x159db2){this['query_']=_0x300160,this['eventRegistrations_']=[];const _0x24dfac=this['query_']['_queryParams'],_0x496ffc=new Ji(_0x24dfac['getIndex']()),_0x28ddb=Kh(_0x24dfac);this['processor_']=Su(_0x28ddb);const _0x4140f6=_0x159db2['serverCache'],_0x2de591=_0x159db2['eventCache'],_0x4d5b74=_0x496ffc['updateFullNode'](g['EMPTY_NODE'],_0x4140f6['getNode'](),null),_0x4d65ee=_0x28ddb['updateFullNode'](g['EMPTY_NODE'],_0x2de591['getNode'](),null),_0x44a8f8=new Ce(_0x4d5b74,_0x4140f6['isFullyInitialized'](),_0x496ffc['filtersNodes']()),_0x3cb417=new Ce(_0x4d65ee,_0x2de591['isFullyInitialized'](),_0x28ddb['filtersNodes']());this['viewCache_']=Mn(_0x3cb417,_0x44a8f8),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x377202){return _0x377202['viewCache_']['serverCache']['getNode']();}function Lu(_0xa2ee40){return mn(_0xa2ee40['viewCache_']);}function xu(_0x42cd9e,_0x360130){const _0x14f877=We(_0x42cd9e['viewCache_']);return _0x14f877&&(_0x42cd9e['query']['_queryParams']['loadsAllData']()||!v(_0x360130)&&!_0x14f877['getImmediateChild'](y(_0x360130))['isEmpty']())?_0x14f877['getChild'](_0x360130):null;}function dr(_0x592ee0){return _0x592ee0['eventRegistrations_']['length']===0x0;}function Fu(_0xb374cc,_0x1e9e8d){_0xb374cc['eventRegistrations_']['push'](_0x1e9e8d);}function fr(_0x270291,_0x1a0b03,_0x744660){const _0xac8ab1=[];if(_0x744660){f(_0x1a0b03==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0xf55742=_0x270291['query']['_path'];_0x270291['eventRegistrations_']['forEach'](_0x3c17d8=>{const _0x1a8035=_0x3c17d8['createCancelEvent'](_0x744660,_0xf55742);_0x1a8035&&_0xac8ab1['push'](_0x1a8035);});}if(_0x1a0b03){let _0xa71fd3=[];for(let _0x1853f9=0x0;_0x1853f9<_0x270291['eventRegistrations_']['length'];++_0x1853f9){const _0x4782f1=_0x270291['eventRegistrations_'][_0x1853f9];if(!_0x4782f1['matches'](_0x1a0b03))_0xa71fd3['push'](_0x4782f1);else{if(_0x1a0b03['hasAnyCallback']()){_0xa71fd3=_0xa71fd3['concat'](_0x270291['eventRegistrations_']['slice'](_0x1853f9+0x1));break;}}}_0x270291['eventRegistrations_']=_0xa71fd3;}else _0x270291['eventRegistrations_']=[];return _0xac8ab1;}function pr(_0xd6cf7a,_0x1d93df,_0x146804,_0x3d74ce){_0x1d93df['type']===j['MERGE']&&_0x1d93df['source']['queryId']!==null&&(f(We(_0xd6cf7a['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0xd6cf7a['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x2e4bd4=_0xd6cf7a['viewCache_'],_0x32b382=Ru(_0xd6cf7a['processor_'],_0x2e4bd4,_0x1d93df,_0x146804,_0x3d74ce);return bu(_0xd6cf7a['processor_'],_0x32b382['viewCache']),f(_0x32b382['viewCache']['serverCache']['isFullyInitialized']()||!_0x2e4bd4['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0xd6cf7a['viewCache_']=_0x32b382['viewCache'],zo(_0xd6cf7a,_0x32b382['changes'],_0x32b382['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x270c91,_0x328686){const _0x1fa703=_0x270c91['viewCache_']['eventCache'],_0x26024b=[];return _0x1fa703['getNode']()['isLeafNode']()||_0x1fa703['getNode']()['forEachChild'](R,(_0x298ef6,_0x454f97)=>{_0x26024b['push'](et(_0x298ef6,_0x454f97));}),_0x1fa703['isFullyInitialized']()&&_0x26024b['push'](Lo(_0x1fa703['getNode']())),zo(_0x270c91,_0x26024b,_0x1fa703['getNode'](),_0x328686);}function zo(_0xebe2ef,_0x560825,_0x1f654d,_0x56e36f){const _0x96946f=_0x56e36f?[_0x56e36f]:_0xebe2ef['eventRegistrations_'];return ru(_0xebe2ef['eventGenerator_'],_0x560825,_0x1f654d,_0x96946f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x30f31c){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x30f31c;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x193930){return _0x193930['views']['size']===0x0;}function rs(_0x3fb034,_0xecd88d,_0x286a53,_0x22d793){const _0x156d00=_0xecd88d['source']['queryId'];if(_0x156d00!==null){const _0x37fed1=_0x3fb034['views']['get'](_0x156d00);return f(_0x37fed1!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x37fed1,_0xecd88d,_0x286a53,_0x22d793);}else{let _0x5bd704=[];for(const _0x31b0ff of _0x3fb034['views']['values']())_0x5bd704=_0x5bd704['concat'](pr(_0x31b0ff,_0xecd88d,_0x286a53,_0x22d793));return _0x5bd704;}}function Ko(_0x2454f6,_0xce8182,_0x2c6450,_0x18beac,_0x33c12a){const _0x5ab7f2=_0xce8182['_queryIdentifier'],_0x259ca2=_0x2454f6['views']['get'](_0x5ab7f2);if(!_0x259ca2){let _0x5175fc=yn(_0x2c6450,_0x33c12a?_0x18beac:null),_0x74ba24=!0x1;_0x5175fc?_0x74ba24=!0x0:_0x18beac instanceof g?(_0x5175fc=ns(_0x2c6450,_0x18beac),_0x74ba24=!0x1):(_0x5175fc=g['EMPTY_NODE'],_0x74ba24=!0x1);const _0x35c9b4=Mn(new Ce(_0x5175fc,_0x74ba24,!0x1),new Ce(_0x18beac,_0x33c12a,!0x1));return new Du(_0xce8182,_0x35c9b4);}return _0x259ca2;}function Hu(_0x517be3,_0x3d1bac,_0x4e9aa9,_0x365c01,_0x3f9a5c,_0x5db2e4){const _0x56d92a=Ko(_0x517be3,_0x3d1bac,_0x365c01,_0x3f9a5c,_0x5db2e4);return _0x517be3['views']['has'](_0x3d1bac['_queryIdentifier'])||_0x517be3['views']['set'](_0x3d1bac['_queryIdentifier'],_0x56d92a),Fu(_0x56d92a,_0x4e9aa9),Uu(_0x56d92a,_0x4e9aa9);}function $u(_0xefc327,_0x3c5d16,_0x5e59f9,_0x48144b){const _0x58eb95=_0x3c5d16['_queryIdentifier'],_0x18da16=[];let _0x28586b=[];const _0x528d2d=Te(_0xefc327);if(_0x58eb95==='default'){for(const [_0x2ab4fa,_0xa80895]of _0xefc327['views']['entries']())_0x28586b=_0x28586b['concat'](fr(_0xa80895,_0x5e59f9,_0x48144b)),dr(_0xa80895)&&(_0xefc327['views']['delete'](_0x2ab4fa),_0xa80895['query']['_queryParams']['loadsAllData']()||_0x18da16['push'](_0xa80895['query']));}else{const _0x235a53=_0xefc327['views']['get'](_0x58eb95);_0x235a53&&(_0x28586b=_0x28586b['concat'](fr(_0x235a53,_0x5e59f9,_0x48144b)),dr(_0x235a53)&&(_0xefc327['views']['delete'](_0x58eb95),_0x235a53['query']['_queryParams']['loadsAllData']()||_0x18da16['push'](_0x235a53['query'])));}return _0x528d2d&&!Te(_0xefc327)&&_0x18da16['push'](new(Bu())(_0x3c5d16['_repo'],_0x3c5d16['_path'])),{'removed':_0x18da16,'events':_0x28586b};}function Yo(_0x3255ff){const _0x333866=[];for(const _0x54317f of _0x3255ff['views']['values']())_0x54317f['query']['_queryParams']['loadsAllData']()||_0x333866['push'](_0x54317f);return _0x333866;}function Ee(_0x5bbbad,_0x5023f8){let _0x349e82=null;for(const _0x3a81c4 of _0x5bbbad['views']['values']())_0x349e82=_0x349e82||xu(_0x3a81c4,_0x5023f8);return _0x349e82;}function Qo(_0x219b5f,_0xfc33bb){if(_0xfc33bb['_queryParams']['loadsAllData']())return xn(_0x219b5f);{const _0x3aa9be=_0xfc33bb['_queryIdentifier'];return _0x219b5f['views']['get'](_0x3aa9be);}}function Jo(_0x268fc4,_0x35bbc3){return Qo(_0x268fc4,_0x35bbc3)!=null;}function Te(_0x111512){return xn(_0x111512)!=null;}function xn(_0x14920a){for(const _0x4c8504 of _0x14920a['views']['values']())if(_0x4c8504['query']['_queryParams']['loadsAllData']())return _0x4c8504;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x43038f){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x43038f;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0xdb250b){this['listenProvider_']=_0xdb250b,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x521045,_0x57af27,_0x3ef63b,_0x109024,_0x4424c8){return lu(_0x521045['pendingWriteTree_'],_0x57af27,_0x3ef63b,_0x109024,_0x4424c8),_0x4424c8?ut(_0x521045,new Ue(Zi(),_0x57af27,_0x3ef63b)):[];}function ju(_0x83e786,_0x21e451,_0x3f832f,_0x1f15dd){hu(_0x83e786['pendingWriteTree_'],_0x21e451,_0x3f832f,_0x1f15dd);const _0x5a45ab=S['fromObject'](_0x3f832f);return ut(_0x83e786,new tt(Zi(),_0x21e451,_0x5a45ab));}function pe(_0x211569,_0x1a74f3,_0x4c7911=!0x1){const _0x5343cd=uu(_0x211569['pendingWriteTree_'],_0x1a74f3);if(du(_0x211569['pendingWriteTree_'],_0x1a74f3)){let _0x644ebb=new S(null);return _0x5343cd['snap']!=null?_0x644ebb=_0x644ebb['set'](w(),!0x0):x(_0x5343cd['children'],_0x4c3424=>{_0x644ebb=_0x644ebb['set'](new C(_0x4c3424),!0x0);}),ut(_0x211569,new gn(_0x5343cd['path'],_0x644ebb,_0x4c7911));}else return[];}function Gt(_0x39b4c0,_0x4e9eb8,_0x164277){return ut(_0x39b4c0,new Ue(es(),_0x4e9eb8,_0x164277));}function Ku(_0x9ff8d1,_0x448982,_0x12dd50){const _0x2d0d59=S['fromObject'](_0x12dd50);return ut(_0x9ff8d1,new tt(es(),_0x448982,_0x2d0d59));}function Yu(_0x2dc1bb,_0x1b7e7e){return ut(_0x2dc1bb,new Lt(es(),_0x1b7e7e));}function Qu(_0x2646e6,_0x56053a,_0x5a720c){const _0xd75663=as(_0x2646e6,_0x5a720c);if(_0xd75663){const _0x472fd0=cs(_0xd75663),_0x1577f6=_0x472fd0['path'],_0x37ea24=_0x472fd0['queryId'],_0x3c6c81=F(_0x1577f6,_0x56053a),_0x47c3b1=new Lt(ts(_0x37ea24),_0x3c6c81);return ls(_0x2646e6,_0x1577f6,_0x47c3b1);}else return[];}function Cn(_0x568ea5,_0x3880d0,_0x4bbbf2,_0x518c10,_0x5c085c=!0x1){const _0x4636cf=_0x3880d0['_path'],_0x5becee=_0x568ea5['syncPointTree_']['get'](_0x4636cf);let _0x5b1eaf=[];if(_0x5becee&&(_0x3880d0['_queryIdentifier']==='default'||Jo(_0x5becee,_0x3880d0))){const _0x1cb12d=$u(_0x5becee,_0x3880d0,_0x4bbbf2,_0x518c10);Vu(_0x5becee)&&(_0x568ea5['syncPointTree_']=_0x568ea5['syncPointTree_']['remove'](_0x4636cf));const _0x58846c=_0x1cb12d['removed'];if(_0x5b1eaf=_0x1cb12d['events'],!_0x5c085c){const _0x375c09=_0x58846c['findIndex'](_0x2215fc=>_0x2215fc['_queryParams']['loadsAllData']())!==-0x1,_0x21a45b=_0x568ea5['syncPointTree_']['findOnPath'](_0x4636cf,(_0xb8dc3f,_0x319ac3)=>Te(_0x319ac3));if(_0x375c09&&!_0x21a45b){const _0x5f5af9=_0x568ea5['syncPointTree_']['subtree'](_0x4636cf);if(!_0x5f5af9['isEmpty']()){const _0x4b8118=Zu(_0x5f5af9);for(let _0x575667=0x0;_0x575667<_0x4b8118['length'];++_0x575667){const _0x55b5d0=_0x4b8118[_0x575667],_0x1f592d=_0x55b5d0['query'],_0x195f23=ta(_0x568ea5,_0x55b5d0);_0x568ea5['listenProvider_']['startListening'](bt(_0x1f592d),xt(_0x568ea5,_0x1f592d),_0x195f23['hashFn'],_0x195f23['onComplete']);}}}!_0x21a45b&&_0x58846c['length']>0x0&&!_0x518c10&&(_0x375c09?_0x568ea5['listenProvider_']['stopListening'](bt(_0x3880d0),null):_0x58846c['forEach'](_0x16184d=>{const _0x352a76=_0x568ea5['queryToTagMap']['get'](Un(_0x16184d));_0x568ea5['listenProvider_']['stopListening'](bt(_0x16184d),_0x352a76);}));}ed(_0x568ea5,_0x58846c);}return _0x5b1eaf;}function Xo(_0x55e4fb,_0x285e97,_0x59bf69,_0x341892){const _0x4d961c=as(_0x55e4fb,_0x341892);if(_0x4d961c!=null){const _0x2fe33a=cs(_0x4d961c),_0x2a18a0=_0x2fe33a['path'],_0x24b308=_0x2fe33a['queryId'],_0x7b0251=F(_0x2a18a0,_0x285e97),_0x5461df=new Ue(ts(_0x24b308),_0x7b0251,_0x59bf69);return ls(_0x55e4fb,_0x2a18a0,_0x5461df);}else return[];}function Ju(_0x285281,_0x52399d,_0x30b091,_0x4cffe8){const _0x393355=as(_0x285281,_0x4cffe8);if(_0x393355){const _0x3d6549=cs(_0x393355),_0xafd691=_0x3d6549['path'],_0x8d5885=_0x3d6549['queryId'],_0x3aa3e8=F(_0xafd691,_0x52399d),_0x9b764e=S['fromObject'](_0x30b091),_0x3869bf=new tt(ts(_0x8d5885),_0x3aa3e8,_0x9b764e);return ls(_0x285281,_0xafd691,_0x3869bf);}else return[];}function Ri(_0x5e53b7,_0x140dd6,_0x36dfec,_0x2f30ce=!0x1){const _0x431a13=_0x140dd6['_path'];let _0x30cade=null,_0x4f86a7=!0x1;_0x5e53b7['syncPointTree_']['foreachOnPath'](_0x431a13,(_0x1ad878,_0x17aef5)=>{const _0x909693=F(_0x1ad878,_0x431a13);_0x30cade=_0x30cade||Ee(_0x17aef5,_0x909693),_0x4f86a7=_0x4f86a7||Te(_0x17aef5);});let _0x2e4111=_0x5e53b7['syncPointTree_']['get'](_0x431a13);_0x2e4111?(_0x4f86a7=_0x4f86a7||Te(_0x2e4111),_0x30cade=_0x30cade||Ee(_0x2e4111,w())):(_0x2e4111=new jo(),_0x5e53b7['syncPointTree_']=_0x5e53b7['syncPointTree_']['set'](_0x431a13,_0x2e4111));let _0x369e81;_0x30cade!=null?_0x369e81=!0x0:(_0x369e81=!0x1,_0x30cade=g['EMPTY_NODE'],_0x5e53b7['syncPointTree_']['subtree'](_0x431a13)['foreachChild']((_0xa470aa,_0x28ba3e)=>{const _0x37f784=Ee(_0x28ba3e,w());_0x37f784&&(_0x30cade=_0x30cade['updateImmediateChild'](_0xa470aa,_0x37f784));}));const _0x3107dd=Jo(_0x2e4111,_0x140dd6);if(!_0x3107dd&&!_0x140dd6['_queryParams']['loadsAllData']()){const _0x5ab6e0=Un(_0x140dd6);f(!_0x5e53b7['queryToTagMap']['has'](_0x5ab6e0),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x34a91e=td();_0x5e53b7['queryToTagMap']['set'](_0x5ab6e0,_0x34a91e),_0x5e53b7['tagToQueryMap']['set'](_0x34a91e,_0x5ab6e0);}const _0x3b3658=Ln(_0x5e53b7['pendingWriteTree_'],_0x431a13);let _0x23cdd2=Hu(_0x2e4111,_0x140dd6,_0x36dfec,_0x3b3658,_0x30cade,_0x369e81);if(!_0x3107dd&&!_0x4f86a7&&!_0x2f30ce){const _0x4d90d5=Qo(_0x2e4111,_0x140dd6);_0x23cdd2=_0x23cdd2['concat'](nd(_0x5e53b7,_0x140dd6,_0x4d90d5));}return _0x23cdd2;}function Fn(_0x2cb2e0,_0x4aa485,_0x37bbdc){const _0x48057a=_0x2cb2e0['pendingWriteTree_'],_0x3118a5=_0x2cb2e0['syncPointTree_']['findOnPath'](_0x4aa485,(_0x487273,_0x15a6cb)=>{const _0x1d060c=F(_0x487273,_0x4aa485),_0x3a6773=Ee(_0x15a6cb,_0x1d060c);if(_0x3a6773)return _0x3a6773;});return Vo(_0x48057a,_0x4aa485,_0x3118a5,_0x37bbdc,!0x0);}function Xu(_0x1ffe57,_0x15ef9f){const _0x20a77e=_0x15ef9f['_path'];let _0x3bdec3=null;_0x1ffe57['syncPointTree_']['foreachOnPath'](_0x20a77e,(_0x368a29,_0x278de9)=>{const _0xf50757=F(_0x368a29,_0x20a77e);_0x3bdec3=_0x3bdec3||Ee(_0x278de9,_0xf50757);});let _0x5c1cbb=_0x1ffe57['syncPointTree_']['get'](_0x20a77e);_0x5c1cbb?_0x3bdec3=_0x3bdec3||Ee(_0x5c1cbb,w()):(_0x5c1cbb=new jo(),_0x1ffe57['syncPointTree_']=_0x1ffe57['syncPointTree_']['set'](_0x20a77e,_0x5c1cbb));const _0x46cc5e=_0x3bdec3!=null,_0x5e0c32=_0x46cc5e?new Ce(_0x3bdec3,!0x0,!0x1):null,_0x49e55f=Ln(_0x1ffe57['pendingWriteTree_'],_0x15ef9f['_path']),_0x1bd9a2=Ko(_0x5c1cbb,_0x15ef9f,_0x49e55f,_0x46cc5e?_0x5e0c32['getNode']():g['EMPTY_NODE'],_0x46cc5e);return Lu(_0x1bd9a2);}function ut(_0x343593,_0x5757fc){return Zo(_0x5757fc,_0x343593['syncPointTree_'],null,Ln(_0x343593['pendingWriteTree_'],w()));}function Zo(_0x169fba,_0x1365dd,_0x33f163,_0x1011b1){if(v(_0x169fba['path']))return ea(_0x169fba,_0x1365dd,_0x33f163,_0x1011b1);{const _0x42ae7f=_0x1365dd['get'](w());_0x33f163==null&&_0x42ae7f!=null&&(_0x33f163=Ee(_0x42ae7f,w()));let _0x4d5bb0=[];const _0x40fe2f=y(_0x169fba['path']),_0x5799e6=_0x169fba['operationForChild'](_0x40fe2f),_0x2c4c2f=_0x1365dd['children']['get'](_0x40fe2f);if(_0x2c4c2f&&_0x5799e6){const _0x3fdf4c=_0x33f163?_0x33f163['getImmediateChild'](_0x40fe2f):null,_0x42a641=Ho(_0x1011b1,_0x40fe2f);_0x4d5bb0=_0x4d5bb0['concat'](Zo(_0x5799e6,_0x2c4c2f,_0x3fdf4c,_0x42a641));}return _0x42ae7f&&(_0x4d5bb0=_0x4d5bb0['concat'](rs(_0x42ae7f,_0x169fba,_0x1011b1,_0x33f163))),_0x4d5bb0;}}function ea(_0x522276,_0x2fc7db,_0x5c5dc4,_0xf1b10){const _0x3f6133=_0x2fc7db['get'](w());_0x5c5dc4==null&&_0x3f6133!=null&&(_0x5c5dc4=Ee(_0x3f6133,w()));let _0x313d03=[];return _0x2fc7db['children']['inorderTraversal']((_0x3f3e19,_0x2f285b)=>{const _0x57cc38=_0x5c5dc4?_0x5c5dc4['getImmediateChild'](_0x3f3e19):null,_0x32f37f=Ho(_0xf1b10,_0x3f3e19),_0x5c0b99=_0x522276['operationForChild'](_0x3f3e19);_0x5c0b99&&(_0x313d03=_0x313d03['concat'](ea(_0x5c0b99,_0x2f285b,_0x57cc38,_0x32f37f)));}),_0x3f6133&&(_0x313d03=_0x313d03['concat'](rs(_0x3f6133,_0x522276,_0xf1b10,_0x5c5dc4))),_0x313d03;}function ta(_0x4f9585,_0x1fe3ff){const _0x4eff0d=_0x1fe3ff['query'],_0x5eee87=xt(_0x4f9585,_0x4eff0d);return{'hashFn':()=>(Mu(_0x1fe3ff)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x53daf5=>{if(_0x53daf5==='ok')return _0x5eee87?Qu(_0x4f9585,_0x4eff0d['_path'],_0x5eee87):Yu(_0x4f9585,_0x4eff0d['_path']);{const _0x7869ca=Kl(_0x53daf5,_0x4eff0d);return Cn(_0x4f9585,_0x4eff0d,null,_0x7869ca);}}};}function xt(_0x4ddb55,_0x4a919f){const _0x1cd2cb=Un(_0x4a919f);return _0x4ddb55['queryToTagMap']['get'](_0x1cd2cb);}function Un(_0x4fa206){return _0x4fa206['_path']['toString']()+'$'+_0x4fa206['_queryIdentifier'];}function as(_0xaf301e,_0x1e231b){return _0xaf301e['tagToQueryMap']['get'](_0x1e231b);}function cs(_0xc9f0a1){const _0x479305=_0xc9f0a1['indexOf']('$');return f(_0x479305!==-0x1&&_0x479305<_0xc9f0a1['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0xc9f0a1['substr'](_0x479305+0x1),'path':new C(_0xc9f0a1['substr'](0x0,_0x479305))};}function ls(_0x147c19,_0x54967b,_0x521b75){const _0x21761e=_0x147c19['syncPointTree_']['get'](_0x54967b);f(_0x21761e,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x4b0a9a=Ln(_0x147c19['pendingWriteTree_'],_0x54967b);return rs(_0x21761e,_0x521b75,_0x4b0a9a,null);}function Zu(_0x48a5f9){return _0x48a5f9['fold']((_0x36d7e8,_0x5af17d,_0x233aa7)=>{if(_0x5af17d&&Te(_0x5af17d))return[xn(_0x5af17d)];{let _0x545967=[];return _0x5af17d&&(_0x545967=Yo(_0x5af17d)),x(_0x233aa7,(_0x360e18,_0x47b205)=>{_0x545967=_0x545967['concat'](_0x47b205);}),_0x545967;}});}function bt(_0x40cd7b){return _0x40cd7b['_queryParams']['loadsAllData']()&&!_0x40cd7b['_queryParams']['isDefault']()?new(qu())(_0x40cd7b['_repo'],_0x40cd7b['_path']):_0x40cd7b;}function ed(_0x479a01,_0x3c5031){for(let _0x13ec91=0x0;_0x13ec91<_0x3c5031['length'];++_0x13ec91){const _0x53480c=_0x3c5031[_0x13ec91];if(!_0x53480c['_queryParams']['loadsAllData']()){const _0x108075=Un(_0x53480c),_0x44606c=_0x479a01['queryToTagMap']['get'](_0x108075);_0x479a01['queryToTagMap']['delete'](_0x108075),_0x479a01['tagToQueryMap']['delete'](_0x44606c);}}}function td(){return zu++;}function nd(_0xf17243,_0x147837,_0x185521){const _0x3cf020=_0x147837['_path'],_0x15479c=xt(_0xf17243,_0x147837),_0x57ebd8=ta(_0xf17243,_0x185521),_0xa1e041=_0xf17243['listenProvider_']['startListening'](bt(_0x147837),_0x15479c,_0x57ebd8['hashFn'],_0x57ebd8['onComplete']),_0x194576=_0xf17243['syncPointTree_']['subtree'](_0x3cf020);if(_0x15479c)f(!Te(_0x194576['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0xda09a2=_0x194576['fold']((_0x2d73d8,_0x44ece2,_0x358ffe)=>{if(!v(_0x2d73d8)&&_0x44ece2&&Te(_0x44ece2))return[xn(_0x44ece2)['query']];{let _0x3ac14a=[];return _0x44ece2&&(_0x3ac14a=_0x3ac14a['concat'](Yo(_0x44ece2)['map'](_0xd6251c=>_0xd6251c['query']))),x(_0x358ffe,(_0x3242bc,_0x2d3426)=>{_0x3ac14a=_0x3ac14a['concat'](_0x2d3426);}),_0x3ac14a;}});for(let _0x42d9a8=0x0;_0x42d9a8<_0xda09a2['length'];++_0x42d9a8){const _0x4ec3ee=_0xda09a2[_0x42d9a8];_0xf17243['listenProvider_']['stopListening'](bt(_0x4ec3ee),xt(_0xf17243,_0x4ec3ee));}}return _0xa1e041;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x19c892){this['node_']=_0x19c892;}['getImmediateChild'](_0x31a073){const _0x381c6b=this['node_']['getImmediateChild'](_0x31a073);return new hs(_0x381c6b);}['node'](){return this['node_'];}}class us{constructor(_0x10d3d0,_0x196e84){this['syncTree_']=_0x10d3d0,this['path_']=_0x196e84;}['getImmediateChild'](_0x2995c3){const _0x578b72=k(this['path_'],_0x2995c3);return new us(this['syncTree_'],_0x578b72);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x3159fe){return _0x3159fe=_0x3159fe||{},_0x3159fe['timestamp']=_0x3159fe['timestamp']||new Date()['getTime'](),_0x3159fe;},gr=function(_0x435045,_0x570c00,_0x376b62){if(!_0x435045||typeof _0x435045!='object')return _0x435045;if(f('.sv'in _0x435045,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x435045['.sv']=='string')return sd(_0x435045['.sv'],_0x570c00,_0x376b62);if(typeof _0x435045['.sv']=='object')return rd(_0x435045['.sv'],_0x570c00);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x435045,null,0x2));},sd=function(_0x278c12,_0x5013cd,_0x1ce986){switch(_0x278c12){case'timestamp':return _0x1ce986['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x278c12);}},rd=function(_0x3e914f,_0x3ce545,_0x5d45d2){_0x3e914f['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3e914f,null,0x2));const _0x22b585=_0x3e914f['increment'];typeof _0x22b585!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x22b585);const _0x1828a6=_0x3ce545['node']();if(f(_0x1828a6!==null&&typeof _0x1828a6<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x1828a6['isLeafNode']())return _0x22b585;const _0x50baf7=_0x1828a6['getValue']();return typeof _0x50baf7!='number'?_0x22b585:_0x50baf7+_0x22b585;},na=function(_0x50a931,_0x28ed30,_0x6f10e9,_0x58024b){return fs(_0x28ed30,new us(_0x6f10e9,_0x50a931),_0x58024b);},ds=function(_0x1d1a15,_0x5bef4c,_0x3c7991){return fs(_0x1d1a15,new hs(_0x5bef4c),_0x3c7991);};function fs(_0x1525c0,_0x57a127,_0x18605d){const _0x38b6f8=_0x1525c0['getPriority']()['val'](),_0x529b53=gr(_0x38b6f8,_0x57a127['getImmediateChild']('.priority'),_0x18605d);let _0x32ce0b;if(_0x1525c0['isLeafNode']()){const _0x4fcc15=_0x1525c0,_0x2516e4=gr(_0x4fcc15['getValue'](),_0x57a127,_0x18605d);return _0x2516e4!==_0x4fcc15['getValue']()||_0x529b53!==_0x4fcc15['getPriority']()['val']()?new D(_0x2516e4,P(_0x529b53)):_0x1525c0;}else{const _0x3c190a=_0x1525c0;return _0x32ce0b=_0x3c190a,_0x529b53!==_0x3c190a['getPriority']()['val']()&&(_0x32ce0b=_0x32ce0b['updatePriority'](new D(_0x529b53))),_0x3c190a['forEachChild'](R,(_0x385793,_0x49ad10)=>{const _0x3c61d0=fs(_0x49ad10,_0x57a127['getImmediateChild'](_0x385793),_0x18605d);_0x3c61d0!==_0x49ad10&&(_0x32ce0b=_0x32ce0b['updateImmediateChild'](_0x385793,_0x3c61d0));}),_0x32ce0b;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x103e5c='',_0x18cbc3=null,_0x375b31={'children':{},'childCount':0x0}){this['name']=_0x103e5c,this['parent']=_0x18cbc3,this['node']=_0x375b31;}}function Wn(_0x4fce18,_0x3cc62d){let _0x428a6a=_0x3cc62d instanceof C?_0x3cc62d:new C(_0x3cc62d),_0x4004a5=_0x4fce18,_0x4704fd=y(_0x428a6a);for(;_0x4704fd!==null;){const _0x126213=De(_0x4004a5['node']['children'],_0x4704fd)||{'children':{},'childCount':0x0};_0x4004a5=new ps(_0x4704fd,_0x4004a5,_0x126213),_0x428a6a=b(_0x428a6a),_0x4704fd=y(_0x428a6a);}return _0x4004a5;}function Ge(_0x18b644){return _0x18b644['node']['value'];}function _s(_0x4e184a,_0x2586b7){_0x4e184a['node']['value']=_0x2586b7,Ai(_0x4e184a);}function ia(_0xcf4e04){return _0xcf4e04['node']['childCount']>0x0;}function od(_0x45bf7d){return Ge(_0x45bf7d)===void 0x0&&!ia(_0x45bf7d);}function Bn(_0x541ac7,_0x43afca){x(_0x541ac7['node']['children'],(_0x39dcb4,_0x291d10)=>{_0x43afca(new ps(_0x39dcb4,_0x541ac7,_0x291d10));});}function sa(_0x5119be,_0x355cbf,_0x4dde0f,_0x1a88d4){_0x4dde0f&&_0x355cbf(_0x5119be),Bn(_0x5119be,_0x230d89=>{sa(_0x230d89,_0x355cbf,!0x0);});}function ad(_0x52b36d,_0x35de3f,_0x2132d6){let _0x5674d0=_0x52b36d['parent'];for(;_0x5674d0!==null;){if(_0x35de3f(_0x5674d0))return!0x0;_0x5674d0=_0x5674d0['parent'];}return!0x1;}function qt(_0x373b23){return new C(_0x373b23['parent']===null?_0x373b23['name']:qt(_0x373b23['parent'])+'/'+_0x373b23['name']);}function Ai(_0x1d6d18){_0x1d6d18['parent']!==null&&cd(_0x1d6d18['parent'],_0x1d6d18['name'],_0x1d6d18);}function cd(_0xb0238f,_0x2608d8,_0x1d4e57){const _0x5d9c53=od(_0x1d4e57),_0x2ac10b=J(_0xb0238f['node']['children'],_0x2608d8);_0x5d9c53&&_0x2ac10b?(delete _0xb0238f['node']['children'][_0x2608d8],_0xb0238f['node']['childCount']--,Ai(_0xb0238f)):!_0x5d9c53&&!_0x2ac10b&&(_0xb0238f['node']['children'][_0x2608d8]=_0x1d4e57['node'],_0xb0238f['node']['childCount']++,Ai(_0xb0238f));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0xb9ee73){return typeof _0xb9ee73=='string'&&_0xb9ee73['length']!==0x0&&!ld['test'](_0xb9ee73);},ra=function(_0x4656a5){return typeof _0x4656a5=='string'&&_0x4656a5['length']!==0x0&&!hd['test'](_0x4656a5);},ud=function(_0x16a007){return _0x16a007&&(_0x16a007=_0x16a007['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x16a007);},Tn=function(_0x2743c0){return _0x2743c0===null||typeof _0x2743c0=='string'||typeof _0x2743c0=='number'&&!Vi(_0x2743c0)||_0x2743c0&&typeof _0x2743c0=='object'&&J(_0x2743c0,'.sv');},zt=function(_0x30ce7b,_0x78f13e,_0x106819,_0x1d46bb){_0x1d46bb&&_0x78f13e===void 0x0||jt(Pn(_0x30ce7b,'value'),_0x78f13e,_0x106819);},jt=function(_0x1f9131,_0x1bd2ad,_0x488658){const _0x5031d4=_0x488658 instanceof C?new Ah(_0x488658,_0x1f9131):_0x488658;if(_0x1bd2ad===void 0x0)throw new Error(_0x1f9131+'contains\x20undefined\x20'+Pe(_0x5031d4));if(typeof _0x1bd2ad=='function')throw new Error(_0x1f9131+'contains\x20a\x20function\x20'+Pe(_0x5031d4)+'\x20with\x20contents\x20=\x20'+_0x1bd2ad['toString']());if(Vi(_0x1bd2ad))throw new Error(_0x1f9131+'contains\x20'+_0x1bd2ad['toString']()+'\x20'+Pe(_0x5031d4));if(typeof _0x1bd2ad=='string'&&_0x1bd2ad['length']>ai/0x3&&On(_0x1bd2ad)>ai)throw new Error(_0x1f9131+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x5031d4)+'\x20(\x27'+_0x1bd2ad['substring'](0x0,0x32)+'...\x27)');if(_0x1bd2ad&&typeof _0x1bd2ad=='object'){let _0x5b734a=!0x1,_0x10f742=!0x1;if(x(_0x1bd2ad,(_0x226ac6,_0x1aa890)=>{if(_0x226ac6==='.value')_0x5b734a=!0x0;else{if(_0x226ac6!=='.priority'&&_0x226ac6!=='.sv'&&(_0x10f742=!0x0,!gs(_0x226ac6)))throw new Error(_0x1f9131+'\x20contains\x20an\x20invalid\x20key\x20('+_0x226ac6+')\x20'+Pe(_0x5031d4)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x5031d4,_0x226ac6),jt(_0x1f9131,_0x1aa890,_0x5031d4),Nh(_0x5031d4);}),_0x5b734a&&_0x10f742)throw new Error(_0x1f9131+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x5031d4)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x150c08,_0x280d66){let _0x528404,_0xe35b09;for(_0x528404=0x0;_0x528404<_0x280d66['length'];_0x528404++){_0xe35b09=_0x280d66[_0x528404];const _0x1bf1dd=Pt(_0xe35b09);for(let _0x54edb7=0x0;_0x54edb7<_0x1bf1dd['length'];_0x54edb7++)if(!(_0x1bf1dd[_0x54edb7]==='.priority'&&_0x54edb7===_0x1bf1dd['length']-0x1)){if(!gs(_0x1bf1dd[_0x54edb7]))throw new Error(_0x150c08+'contains\x20an\x20invalid\x20key\x20('+_0x1bf1dd[_0x54edb7]+')\x20in\x20path\x20'+_0xe35b09['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x280d66['sort'](Rh);let _0x3f1ad1=null;for(_0x528404=0x0;_0x528404<_0x280d66['length'];_0x528404++){if(_0xe35b09=_0x280d66[_0x528404],_0x3f1ad1!==null&&G(_0x3f1ad1,_0xe35b09))throw new Error(_0x150c08+'contains\x20a\x20path\x20'+_0x3f1ad1['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0xe35b09['toString']());_0x3f1ad1=_0xe35b09;}},fd=function(_0x498a6f,_0x525b03,_0x168532,_0x224445){const _0x4709c9=Pn(_0x498a6f,'values');if(!(_0x525b03&&typeof _0x525b03=='object')||Array['isArray'](_0x525b03))throw new Error(_0x4709c9+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x316d7a=[];x(_0x525b03,(_0x2d03d3,_0x44d73b)=>{const _0x1dfdc7=new C(_0x2d03d3);if(jt(_0x4709c9,_0x44d73b,k(_0x168532,_0x1dfdc7)),zi(_0x1dfdc7)==='.priority'&&!Tn(_0x44d73b))throw new Error(_0x4709c9+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x1dfdc7['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x316d7a['push'](_0x1dfdc7);}),dd(_0x4709c9,_0x316d7a);},ms=function(_0x87b9b9,_0x85a16c,_0x362779,_0x3425d5){if(!ra(_0x362779))throw new Error(Pn(_0x87b9b9,_0x85a16c)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x362779+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x2bafbf,_0x54d781,_0x561644,_0x387c84){_0x561644&&(_0x561644=_0x561644['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x2bafbf,_0x54d781,_0x561644);},ys=function(_0x5df2e7,_0x3c58e6){if(y(_0x3c58e6)==='.info')throw new Error(_0x5df2e7+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x102398,_0x115c9a){const _0x40e3f4=_0x115c9a['path']['toString']();if(typeof _0x115c9a['repoInfo']['host']!='string'||_0x115c9a['repoInfo']['host']['length']===0x0||!gs(_0x115c9a['repoInfo']['namespace'])&&_0x115c9a['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x40e3f4['length']!==0x0&&!ud(_0x40e3f4))throw new Error(Pn(_0x102398,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x4a910e,_0x1a0a97){let _0x5f110c=null;for(let _0x26f846=0x0;_0x26f846<_0x1a0a97['length'];_0x26f846++){const _0x2fddc1=_0x1a0a97[_0x26f846],_0x3aa6d0=_0x2fddc1['getPath']();_0x5f110c!==null&&!ji(_0x3aa6d0,_0x5f110c['path'])&&(_0x4a910e['eventLists_']['push'](_0x5f110c),_0x5f110c=null),_0x5f110c===null&&(_0x5f110c={'events':[],'path':_0x3aa6d0}),_0x5f110c['events']['push'](_0x2fddc1);}_0x5f110c&&_0x4a910e['eventLists_']['push'](_0x5f110c);}function oa(_0x577a6f,_0x3fefcb,_0x3ef76a){Vn(_0x577a6f,_0x3ef76a),aa(_0x577a6f,_0x29c747=>ji(_0x29c747,_0x3fefcb));}function H(_0x4e22c8,_0x277711,_0x26c35e){Vn(_0x4e22c8,_0x26c35e),aa(_0x4e22c8,_0x4f676=>G(_0x4f676,_0x277711)||G(_0x277711,_0x4f676));}function aa(_0x4d359c,_0x2fbee9){_0x4d359c['recursionDepth_']++;let _0x5889c1=!0x0;for(let _0xac0d3e=0x0;_0xac0d3e<_0x4d359c['eventLists_']['length'];_0xac0d3e++){const _0x29eef1=_0x4d359c['eventLists_'][_0xac0d3e];if(_0x29eef1){const _0x4be2ca=_0x29eef1['path'];_0x2fbee9(_0x4be2ca)?(md(_0x4d359c['eventLists_'][_0xac0d3e]),_0x4d359c['eventLists_'][_0xac0d3e]=null):_0x5889c1=!0x1;}}_0x5889c1&&(_0x4d359c['eventLists_']=[]),_0x4d359c['recursionDepth_']--;}function md(_0xadde90){for(let _0x3cebe7=0x0;_0x3cebe7<_0xadde90['events']['length'];_0x3cebe7++){const _0x224774=_0xadde90['events'][_0x3cebe7];if(_0x224774!==null){_0xadde90['events'][_0x3cebe7]=null;const _0x4a475b=_0x224774['getEventRunner']();wt&&L('event:\x20'+_0x224774['toString']()),ht(_0x4a475b);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x294e6f,_0x30fa1f,_0xd7b206,_0x1cc493){this['repoInfo_']=_0x294e6f,this['forceRestClient_']=_0x30fa1f,this['authTokenProvider_']=_0xd7b206,this['appCheckProvider_']=_0x1cc493,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x2a5010,_0x483d63,_0x44df04){if(_0x2a5010['stats_']=Gi(_0x2a5010['repoInfo_']),_0x2a5010['forceRestClient_']||Xl())_0x2a5010['server_']=new pn(_0x2a5010['repoInfo_'],(_0x44d571,_0x4736a2,_0x2756e1,_0x384ff6)=>{mr(_0x2a5010,_0x44d571,_0x4736a2,_0x2756e1,_0x384ff6);},_0x2a5010['authTokenProvider_'],_0x2a5010['appCheckProvider_']),setTimeout(()=>yr(_0x2a5010,!0x0),0x0);else{if(typeof _0x44df04<'u'&&_0x44df04!==null){if(typeof _0x44df04!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x44df04);}catch(_0x49af47){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x49af47);}}_0x2a5010['persistentConnection_']=new se(_0x2a5010['repoInfo_'],_0x483d63,(_0x19a18e,_0x3ac0de,_0x19a359,_0x48ed60)=>{mr(_0x2a5010,_0x19a18e,_0x3ac0de,_0x19a359,_0x48ed60);},_0x5e8c4a=>{yr(_0x2a5010,_0x5e8c4a);},_0x206854=>{Id(_0x2a5010,_0x206854);},_0x2a5010['authTokenProvider_'],_0x2a5010['appCheckProvider_'],_0x44df04),_0x2a5010['server_']=_0x2a5010['persistentConnection_'];}_0x2a5010['authTokenProvider_']['addTokenChangeListener'](_0x1b3163=>{_0x2a5010['server_']['refreshAuthToken'](_0x1b3163);}),_0x2a5010['appCheckProvider_']['addTokenChangeListener'](_0x22e50e=>{_0x2a5010['server_']['refreshAppCheckToken'](_0x22e50e['token']);}),_0x2a5010['statsReporter_']=ih(_0x2a5010['repoInfo_'],()=>new iu(_0x2a5010['stats_'],_0x2a5010['server_'])),_0x2a5010['infoData_']=new Xh(),_0x2a5010['infoSyncTree_']=new _r({'startListening':(_0x5979d0,_0xa42d66,_0x4d5fb6,_0x42d7ce)=>{let _0x532c51=[];const _0x3276c6=_0x2a5010['infoData_']['getNode'](_0x5979d0['_path']);return _0x3276c6['isEmpty']()||(_0x532c51=Gt(_0x2a5010['infoSyncTree_'],_0x5979d0['_path'],_0x3276c6),setTimeout(()=>{_0x42d7ce('ok');},0x0)),_0x532c51;},'stopListening':()=>{}}),vs(_0x2a5010,'connected',!0x1),_0x2a5010['serverSyncTree_']=new _r({'startListening':(_0xa18c6b,_0x560efe,_0x1da19c,_0xe4b8d9)=>(_0x2a5010['server_']['listen'](_0xa18c6b,_0x1da19c,_0x560efe,(_0x5e84ca,_0x3de1fe)=>{const _0x56f8a3=_0xe4b8d9(_0x5e84ca,_0x3de1fe);H(_0x2a5010['eventQueue_'],_0xa18c6b['_path'],_0x56f8a3);}),[]),'stopListening':(_0x4a8760,_0x1900d0)=>{_0x2a5010['server_']['unlisten'](_0x4a8760,_0x1900d0);}});}function la(_0x2d9774){const _0xd9b731=_0x2d9774['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0xd9b731;}function Kt(_0x2e5f90){return id({'timestamp':la(_0x2e5f90)});}function mr(_0x38894b,_0x506407,_0x22e810,_0x66cfc1,_0x228f1c){_0x38894b['dataUpdateCount']++;const _0x4ade69=new C(_0x506407);_0x22e810=_0x38894b['interceptServerDataCallback_']?_0x38894b['interceptServerDataCallback_'](_0x506407,_0x22e810):_0x22e810;let _0x371e61=[];if(_0x228f1c){if(_0x66cfc1){const _0x55515e=hn(_0x22e810,_0x1f8a39=>P(_0x1f8a39));_0x371e61=Ju(_0x38894b['serverSyncTree_'],_0x4ade69,_0x55515e,_0x228f1c);}else{const _0x2d3b5f=P(_0x22e810);_0x371e61=Xo(_0x38894b['serverSyncTree_'],_0x4ade69,_0x2d3b5f,_0x228f1c);}}else{if(_0x66cfc1){const _0x3535f3=hn(_0x22e810,_0xb2f574=>P(_0xb2f574));_0x371e61=Ku(_0x38894b['serverSyncTree_'],_0x4ade69,_0x3535f3);}else{const _0x1396a1=P(_0x22e810);_0x371e61=Gt(_0x38894b['serverSyncTree_'],_0x4ade69,_0x1396a1);}}let _0x3e065e=_0x4ade69;_0x371e61['length']>0x0&&(_0x3e065e=it(_0x38894b,_0x4ade69)),H(_0x38894b['eventQueue_'],_0x3e065e,_0x371e61);}function yr(_0x36afc1,_0x1ba55a){vs(_0x36afc1,'connected',_0x1ba55a),_0x1ba55a===!0x1&&Sd(_0x36afc1);}function Id(_0x42a99c,_0x38484c){x(_0x38484c,(_0x4a89eb,_0x3bd31e)=>{vs(_0x42a99c,_0x4a89eb,_0x3bd31e);});}function vs(_0x3260f2,_0x5288c9,_0x454c38){const _0x55a6d4=new C('/.info/'+_0x5288c9),_0x4336dd=P(_0x454c38);_0x3260f2['infoData_']['updateSnapshot'](_0x55a6d4,_0x4336dd);const _0x1ae614=Gt(_0x3260f2['infoSyncTree_'],_0x55a6d4,_0x4336dd);H(_0x3260f2['eventQueue_'],_0x55a6d4,_0x1ae614);}function Hn(_0x37e362){return _0x37e362['nextWriteId_']++;}function wd(_0x48a0d5,_0x17978b,_0x336aed){const _0x553ad0=Xu(_0x48a0d5['serverSyncTree_'],_0x17978b);return _0x553ad0!=null?Promise['resolve'](_0x553ad0):_0x48a0d5['server_']['get'](_0x17978b)['then'](_0x495252=>{const _0x591081=P(_0x495252)['withIndex'](_0x17978b['_queryParams']['getIndex']());Ri(_0x48a0d5['serverSyncTree_'],_0x17978b,_0x336aed,!0x0);let _0xf56979;if(_0x17978b['_queryParams']['loadsAllData']())_0xf56979=Gt(_0x48a0d5['serverSyncTree_'],_0x17978b['_path'],_0x591081);else{const _0x4d1efe=xt(_0x48a0d5['serverSyncTree_'],_0x17978b);_0xf56979=Xo(_0x48a0d5['serverSyncTree_'],_0x17978b['_path'],_0x591081,_0x4d1efe);}return H(_0x48a0d5['eventQueue_'],_0x17978b['_path'],_0xf56979),Cn(_0x48a0d5['serverSyncTree_'],_0x17978b,_0x336aed,null,!0x0),_0x591081;},_0x144ac6=>(dt(_0x48a0d5,'get\x20for\x20query\x20'+O(_0x17978b)+'\x20failed:\x20'+_0x144ac6),Promise['reject'](new Error(_0x144ac6))));}function Cd(_0x226aaa,_0x31db3b,_0x1714eb,_0x55d370,_0x19e568){dt(_0x226aaa,'set',{'path':_0x31db3b['toString'](),'value':_0x1714eb,'priority':_0x55d370});const _0x37a34c=Kt(_0x226aaa),_0x27ba81=P(_0x1714eb,_0x55d370),_0x4f4357=Fn(_0x226aaa['serverSyncTree_'],_0x31db3b),_0x4f6aae=ds(_0x27ba81,_0x4f4357,_0x37a34c),_0x77dbbd=Hn(_0x226aaa),_0x939d30=os(_0x226aaa['serverSyncTree_'],_0x31db3b,_0x4f6aae,_0x77dbbd,!0x0);Vn(_0x226aaa['eventQueue_'],_0x939d30),_0x226aaa['server_']['put'](_0x31db3b['toString'](),_0x27ba81['val'](!0x0),(_0x2a1f97,_0x12a8cb)=>{const _0x9e95d2=_0x2a1f97==='ok';_0x9e95d2||U('set\x20at\x20'+_0x31db3b+'\x20failed:\x20'+_0x2a1f97);const _0x15cca7=pe(_0x226aaa['serverSyncTree_'],_0x77dbbd,!_0x9e95d2);H(_0x226aaa['eventQueue_'],_0x31db3b,_0x15cca7),ki(_0x226aaa,_0x19e568,_0x2a1f97,_0x12a8cb);});const _0x1787f3=Is(_0x226aaa,_0x31db3b);it(_0x226aaa,_0x1787f3),H(_0x226aaa['eventQueue_'],_0x1787f3,[]);}function Td(_0x2b7718,_0x33d761,_0x1def33,_0x1caa21){dt(_0x2b7718,'update',{'path':_0x33d761['toString'](),'value':_0x1def33});let _0x40d82c=!0x0;const _0xfaf071=Kt(_0x2b7718),_0x1bf349={};if(x(_0x1def33,(_0x595340,_0xfeffd4)=>{_0x40d82c=!0x1,_0x1bf349[_0x595340]=na(k(_0x33d761,_0x595340),P(_0xfeffd4),_0x2b7718['serverSyncTree_'],_0xfaf071);}),_0x40d82c)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x2b7718,_0x1caa21,'ok',void 0x0);else{const _0x32368f=Hn(_0x2b7718),_0x125359=ju(_0x2b7718['serverSyncTree_'],_0x33d761,_0x1bf349,_0x32368f);Vn(_0x2b7718['eventQueue_'],_0x125359),_0x2b7718['server_']['merge'](_0x33d761['toString'](),_0x1def33,(_0x3d86b3,_0x462ca6)=>{const _0xd36b13=_0x3d86b3==='ok';_0xd36b13||U('update\x20at\x20'+_0x33d761+'\x20failed:\x20'+_0x3d86b3);const _0x5c8ecb=pe(_0x2b7718['serverSyncTree_'],_0x32368f,!_0xd36b13),_0x133006=_0x5c8ecb['length']>0x0?it(_0x2b7718,_0x33d761):_0x33d761;H(_0x2b7718['eventQueue_'],_0x133006,_0x5c8ecb),ki(_0x2b7718,_0x1caa21,_0x3d86b3,_0x462ca6);}),x(_0x1def33,_0x5d45df=>{const _0x1b5f9d=Is(_0x2b7718,k(_0x33d761,_0x5d45df));it(_0x2b7718,_0x1b5f9d);}),H(_0x2b7718['eventQueue_'],_0x33d761,[]);}}function Sd(_0x7846fd){dt(_0x7846fd,'onDisconnectEvents');const _0x462d38=Kt(_0x7846fd),_0x4b961e=_n();Ii(_0x7846fd['onDisconnect_'],w(),(_0x164f69,_0x587d9d)=>{const _0x2ae339=na(_0x164f69,_0x587d9d,_0x7846fd['serverSyncTree_'],_0x462d38);Fo(_0x4b961e,_0x164f69,_0x2ae339);});let _0x344e23=[];Ii(_0x4b961e,w(),(_0x3ffc4a,_0x57684d)=>{_0x344e23=_0x344e23['concat'](Gt(_0x7846fd['serverSyncTree_'],_0x3ffc4a,_0x57684d));const _0x2040ac=Is(_0x7846fd,_0x3ffc4a);it(_0x7846fd,_0x2040ac);}),_0x7846fd['onDisconnect_']=_n(),H(_0x7846fd['eventQueue_'],w(),_0x344e23);}function bd(_0x4f62f0,_0x9d1cbf,_0x303224){let _0x56469b;y(_0x9d1cbf['_path'])==='.info'?_0x56469b=Ri(_0x4f62f0['infoSyncTree_'],_0x9d1cbf,_0x303224):_0x56469b=Ri(_0x4f62f0['serverSyncTree_'],_0x9d1cbf,_0x303224),oa(_0x4f62f0['eventQueue_'],_0x9d1cbf['_path'],_0x56469b);}function Rd(_0x1c4e4f,_0x3379ff,_0x504c9){let _0x27d38a;y(_0x3379ff['_path'])==='.info'?_0x27d38a=Cn(_0x1c4e4f['infoSyncTree_'],_0x3379ff,_0x504c9):_0x27d38a=Cn(_0x1c4e4f['serverSyncTree_'],_0x3379ff,_0x504c9),oa(_0x1c4e4f['eventQueue_'],_0x3379ff['_path'],_0x27d38a);}function ha(_0x192641){_0x192641['persistentConnection_']&&_0x192641['persistentConnection_']['interrupt'](ca);}function Ad(_0x5afdf5){_0x5afdf5['persistentConnection_']&&_0x5afdf5['persistentConnection_']['resume'](ca);}function dt(_0x24c365,..._0x1d6d4d){let _0x53f6b6='';_0x24c365['persistentConnection_']&&(_0x53f6b6=_0x24c365['persistentConnection_']['id']+':'),L(_0x53f6b6,..._0x1d6d4d);}function ki(_0x101f22,_0x54765a,_0x5c857b,_0x186422){_0x54765a&&ht(()=>{if(_0x5c857b==='ok')_0x54765a(null);else{const _0x48e444=(_0x5c857b||'error')['toUpperCase']();let _0x201a4b=_0x48e444;_0x186422&&(_0x201a4b+=':\x20'+_0x186422);const _0x13b549=new Error(_0x201a4b);_0x13b549['code']=_0x48e444,_0x54765a(_0x13b549);}});}function kd(_0x54333d,_0x4178d4,_0x4d739b,_0x1eb4d9,_0x1e4951,_0xe54ef1){dt(_0x54333d,'transaction\x20on\x20'+_0x4178d4);const _0x25c127={'path':_0x4178d4,'update':_0x4d739b,'onComplete':_0x1eb4d9,'status':null,'order':so(),'applyLocally':_0xe54ef1,'retryCount':0x0,'unwatcher':_0x1e4951,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x341d13=Es(_0x54333d,_0x4178d4,void 0x0);_0x25c127['currentInputSnapshot']=_0x341d13;const _0x5a09b3=_0x25c127['update'](_0x341d13['val']());if(_0x5a09b3===void 0x0)_0x25c127['unwatcher'](),_0x25c127['currentOutputSnapshotRaw']=null,_0x25c127['currentOutputSnapshotResolved']=null,_0x25c127['onComplete']&&_0x25c127['onComplete'](null,!0x1,_0x25c127['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x5a09b3,_0x25c127['path']),_0x25c127['status']=0x0;const _0x306649=Wn(_0x54333d['transactionQueueTree_'],_0x4178d4),_0x47eca1=Ge(_0x306649)||[];_0x47eca1['push'](_0x25c127),_s(_0x306649,_0x47eca1);let _0x5245db;typeof _0x5a09b3=='object'&&_0x5a09b3!==null&&J(_0x5a09b3,'.priority')?(_0x5245db=De(_0x5a09b3,'.priority'),f(Tn(_0x5245db),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x5245db=(Fn(_0x54333d['serverSyncTree_'],_0x4178d4)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x55e7a3=Kt(_0x54333d),_0x3f0f50=P(_0x5a09b3,_0x5245db),_0x15d301=ds(_0x3f0f50,_0x341d13,_0x55e7a3);_0x25c127['currentOutputSnapshotRaw']=_0x3f0f50,_0x25c127['currentOutputSnapshotResolved']=_0x15d301,_0x25c127['currentWriteId']=Hn(_0x54333d);const _0x44a513=os(_0x54333d['serverSyncTree_'],_0x4178d4,_0x15d301,_0x25c127['currentWriteId'],_0x25c127['applyLocally']);H(_0x54333d['eventQueue_'],_0x4178d4,_0x44a513),$n(_0x54333d,_0x54333d['transactionQueueTree_']);}}function Es(_0x5bb9d2,_0x3c51b1,_0x38224c){return Fn(_0x5bb9d2['serverSyncTree_'],_0x3c51b1,_0x38224c)||g['EMPTY_NODE'];}function $n(_0x1761e9,_0x273fec=_0x1761e9['transactionQueueTree_']){if(_0x273fec||Gn(_0x1761e9,_0x273fec),Ge(_0x273fec)){const _0x17165f=da(_0x1761e9,_0x273fec);f(_0x17165f['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x17165f['every'](_0x5d7b34=>_0x5d7b34['status']===0x0)&&Nd(_0x1761e9,qt(_0x273fec),_0x17165f);}else ia(_0x273fec)&&Bn(_0x273fec,_0x29c247=>{$n(_0x1761e9,_0x29c247);});}function Nd(_0x2a6e04,_0x27f6df,_0x124226){const _0x364ab9=_0x124226['map'](_0x214b06=>_0x214b06['currentWriteId']),_0xc668e8=Es(_0x2a6e04,_0x27f6df,_0x364ab9);let _0x53395b=_0xc668e8;const _0x5afa1f=_0xc668e8['hash']();for(let _0xae18db=0x0;_0xae18db<_0x124226['length'];_0xae18db++){const _0x189c48=_0x124226[_0xae18db];f(_0x189c48['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x189c48['status']=0x1,_0x189c48['retryCount']++;const _0x2dd473=F(_0x27f6df,_0x189c48['path']);_0x53395b=_0x53395b['updateChild'](_0x2dd473,_0x189c48['currentOutputSnapshotRaw']);}const _0x1791b9=_0x53395b['val'](!0x0),_0x48f9d0=_0x27f6df;_0x2a6e04['server_']['put'](_0x48f9d0['toString'](),_0x1791b9,_0x807058=>{dt(_0x2a6e04,'transaction\x20put\x20response',{'path':_0x48f9d0['toString'](),'status':_0x807058});let _0x4b394c=[];if(_0x807058==='ok'){const _0x32c9f7=[];for(let _0x591652=0x0;_0x591652<_0x124226['length'];_0x591652++)_0x124226[_0x591652]['status']=0x2,_0x4b394c=_0x4b394c['concat'](pe(_0x2a6e04['serverSyncTree_'],_0x124226[_0x591652]['currentWriteId'])),_0x124226[_0x591652]['onComplete']&&_0x32c9f7['push'](()=>_0x124226[_0x591652]['onComplete'](null,!0x0,_0x124226[_0x591652]['currentOutputSnapshotResolved'])),_0x124226[_0x591652]['unwatcher']();Gn(_0x2a6e04,Wn(_0x2a6e04['transactionQueueTree_'],_0x27f6df)),$n(_0x2a6e04,_0x2a6e04['transactionQueueTree_']),H(_0x2a6e04['eventQueue_'],_0x27f6df,_0x4b394c);for(let _0x265be1=0x0;_0x265be1<_0x32c9f7['length'];_0x265be1++)ht(_0x32c9f7[_0x265be1]);}else{if(_0x807058==='datastale'){for(let _0xd4fc8e=0x0;_0xd4fc8e<_0x124226['length'];_0xd4fc8e++)_0x124226[_0xd4fc8e]['status']===0x3?_0x124226[_0xd4fc8e]['status']=0x4:_0x124226[_0xd4fc8e]['status']=0x0;}else{U('transaction\x20at\x20'+_0x48f9d0['toString']()+'\x20failed:\x20'+_0x807058);for(let _0x5c44eb=0x0;_0x5c44eb<_0x124226['length'];_0x5c44eb++)_0x124226[_0x5c44eb]['status']=0x4,_0x124226[_0x5c44eb]['abortReason']=_0x807058;}it(_0x2a6e04,_0x27f6df);}},_0x5afa1f);}function it(_0x5e38c5,_0x48bb2a){const _0x3aa8e1=ua(_0x5e38c5,_0x48bb2a),_0x575b94=qt(_0x3aa8e1),_0x4dfb8d=da(_0x5e38c5,_0x3aa8e1);return Pd(_0x5e38c5,_0x4dfb8d,_0x575b94),_0x575b94;}function Pd(_0x3034ee,_0x4001d7,_0x5b8c87){if(_0x4001d7['length']===0x0)return;const _0x2bc5c4=[];let _0x26189c=[];const _0x361a7f=_0x4001d7['filter'](_0x1485e6=>_0x1485e6['status']===0x0)['map'](_0x1d2aa7=>_0x1d2aa7['currentWriteId']);for(let _0x909937=0x0;_0x909937<_0x4001d7['length'];_0x909937++){const _0x23775a=_0x4001d7[_0x909937],_0x3759ab=F(_0x5b8c87,_0x23775a['path']);let _0x44deb6=!0x1,_0x375bfa;if(f(_0x3759ab!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x23775a['status']===0x4)_0x44deb6=!0x0,_0x375bfa=_0x23775a['abortReason'],_0x26189c=_0x26189c['concat'](pe(_0x3034ee['serverSyncTree_'],_0x23775a['currentWriteId'],!0x0));else{if(_0x23775a['status']===0x0){if(_0x23775a['retryCount']>=yd)_0x44deb6=!0x0,_0x375bfa='maxretry',_0x26189c=_0x26189c['concat'](pe(_0x3034ee['serverSyncTree_'],_0x23775a['currentWriteId'],!0x0));else{const _0x28eada=Es(_0x3034ee,_0x23775a['path'],_0x361a7f);_0x23775a['currentInputSnapshot']=_0x28eada;const _0x4daa6e=_0x4001d7[_0x909937]['update'](_0x28eada['val']());if(_0x4daa6e!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4daa6e,_0x23775a['path']);let _0x4d6a07=P(_0x4daa6e);typeof _0x4daa6e=='object'&&_0x4daa6e!=null&&J(_0x4daa6e,'.priority')||(_0x4d6a07=_0x4d6a07['updatePriority'](_0x28eada['getPriority']()));const _0x59ad0b=_0x23775a['currentWriteId'],_0x5823da=Kt(_0x3034ee),_0x1ca651=ds(_0x4d6a07,_0x28eada,_0x5823da);_0x23775a['currentOutputSnapshotRaw']=_0x4d6a07,_0x23775a['currentOutputSnapshotResolved']=_0x1ca651,_0x23775a['currentWriteId']=Hn(_0x3034ee),_0x361a7f['splice'](_0x361a7f['indexOf'](_0x59ad0b),0x1),_0x26189c=_0x26189c['concat'](os(_0x3034ee['serverSyncTree_'],_0x23775a['path'],_0x1ca651,_0x23775a['currentWriteId'],_0x23775a['applyLocally'])),_0x26189c=_0x26189c['concat'](pe(_0x3034ee['serverSyncTree_'],_0x59ad0b,!0x0));}else _0x44deb6=!0x0,_0x375bfa='nodata',_0x26189c=_0x26189c['concat'](pe(_0x3034ee['serverSyncTree_'],_0x23775a['currentWriteId'],!0x0));}}}H(_0x3034ee['eventQueue_'],_0x5b8c87,_0x26189c),_0x26189c=[],_0x44deb6&&(_0x4001d7[_0x909937]['status']=0x2,function(_0x3ea30a){setTimeout(_0x3ea30a,Math['floor'](0x0));}(_0x4001d7[_0x909937]['unwatcher']),_0x4001d7[_0x909937]['onComplete']&&(_0x375bfa==='nodata'?_0x2bc5c4['push'](()=>_0x4001d7[_0x909937]['onComplete'](null,!0x1,_0x4001d7[_0x909937]['currentInputSnapshot'])):_0x2bc5c4['push'](()=>_0x4001d7[_0x909937]['onComplete'](new Error(_0x375bfa),!0x1,null))));}Gn(_0x3034ee,_0x3034ee['transactionQueueTree_']);for(let _0x167f5a=0x0;_0x167f5a<_0x2bc5c4['length'];_0x167f5a++)ht(_0x2bc5c4[_0x167f5a]);$n(_0x3034ee,_0x3034ee['transactionQueueTree_']);}function ua(_0x5a29ba,_0x50e480){let _0x3c59e7,_0xe4c513=_0x5a29ba['transactionQueueTree_'];for(_0x3c59e7=y(_0x50e480);_0x3c59e7!==null&&Ge(_0xe4c513)===void 0x0;)_0xe4c513=Wn(_0xe4c513,_0x3c59e7),_0x50e480=b(_0x50e480),_0x3c59e7=y(_0x50e480);return _0xe4c513;}function da(_0x18712c,_0x5f2c53){const _0x5c1964=[];return fa(_0x18712c,_0x5f2c53,_0x5c1964),_0x5c1964['sort']((_0x991124,_0x3c9648)=>_0x991124['order']-_0x3c9648['order']),_0x5c1964;}function fa(_0x277864,_0xcf8ecf,_0x121184){const _0x5c7c77=Ge(_0xcf8ecf);if(_0x5c7c77){for(let _0x44ae5e=0x0;_0x44ae5e<_0x5c7c77['length'];_0x44ae5e++)_0x121184['push'](_0x5c7c77[_0x44ae5e]);}Bn(_0xcf8ecf,_0x436e29=>{fa(_0x277864,_0x436e29,_0x121184);});}function Gn(_0x231f62,_0x4f1fcf){const _0x5bead0=Ge(_0x4f1fcf);if(_0x5bead0){let _0x2b8b05=0x0;for(let _0x57b514=0x0;_0x57b514<_0x5bead0['length'];_0x57b514++)_0x5bead0[_0x57b514]['status']!==0x2&&(_0x5bead0[_0x2b8b05]=_0x5bead0[_0x57b514],_0x2b8b05++);_0x5bead0['length']=_0x2b8b05,_s(_0x4f1fcf,_0x5bead0['length']>0x0?_0x5bead0:void 0x0);}Bn(_0x4f1fcf,_0x3a8166=>{Gn(_0x231f62,_0x3a8166);});}function Is(_0x3770e4,_0x411ab7){const _0x2d8272=qt(ua(_0x3770e4,_0x411ab7)),_0x26e26b=Wn(_0x3770e4['transactionQueueTree_'],_0x411ab7);return ad(_0x26e26b,_0x46e20b=>{ci(_0x3770e4,_0x46e20b);}),ci(_0x3770e4,_0x26e26b),sa(_0x26e26b,_0x3703df=>{ci(_0x3770e4,_0x3703df);}),_0x2d8272;}function ci(_0x627a2f,_0xb29c6d){const _0x122de6=Ge(_0xb29c6d);if(_0x122de6){const _0xff841f=[];let _0x562ba6=[],_0x3180e2=-0x1;for(let _0x118bee=0x0;_0x118bee<_0x122de6['length'];_0x118bee++)_0x122de6[_0x118bee]['status']===0x3||(_0x122de6[_0x118bee]['status']===0x1?(f(_0x3180e2===_0x118bee-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x3180e2=_0x118bee,_0x122de6[_0x118bee]['status']=0x3,_0x122de6[_0x118bee]['abortReason']='set'):(f(_0x122de6[_0x118bee]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x122de6[_0x118bee]['unwatcher'](),_0x562ba6=_0x562ba6['concat'](pe(_0x627a2f['serverSyncTree_'],_0x122de6[_0x118bee]['currentWriteId'],!0x0)),_0x122de6[_0x118bee]['onComplete']&&_0xff841f['push'](_0x122de6[_0x118bee]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x3180e2===-0x1?_s(_0xb29c6d,void 0x0):_0x122de6['length']=_0x3180e2+0x1,H(_0x627a2f['eventQueue_'],qt(_0xb29c6d),_0x562ba6);for(let _0x15b286=0x0;_0x15b286<_0xff841f['length'];_0x15b286++)ht(_0xff841f[_0x15b286]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x41de6b){let _0x135e58='';const _0x448fec=_0x41de6b['split']('/');for(let _0x5ea5b1=0x0;_0x5ea5b1<_0x448fec['length'];_0x5ea5b1++)if(_0x448fec[_0x5ea5b1]['length']>0x0){let _0x676854=_0x448fec[_0x5ea5b1];try{_0x676854=decodeURIComponent(_0x676854['replace'](/\+/g,'\x20'));}catch{}_0x135e58+='/'+_0x676854;}return _0x135e58;}function Dd(_0x17dc3b){const _0x55bf7d={};_0x17dc3b['charAt'](0x0)==='?'&&(_0x17dc3b=_0x17dc3b['substring'](0x1));for(const _0x1b8bc9 of _0x17dc3b['split']('&')){if(_0x1b8bc9['length']===0x0)continue;const _0x3bc49c=_0x1b8bc9['split']('=');_0x3bc49c['length']===0x2?_0x55bf7d[decodeURIComponent(_0x3bc49c[0x0])]=decodeURIComponent(_0x3bc49c[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x1b8bc9+'\x27\x20in\x20query\x20\x27'+_0x17dc3b+'\x27');}return _0x55bf7d;}const vr=function(_0x49da3b,_0x362f6b){const _0x11de1a=Md(_0x49da3b),_0x357409=_0x11de1a['namespace'];_0x11de1a['domain']==='firebase.com'&&ae(_0x11de1a['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x357409||_0x357409==='undefined')&&_0x11de1a['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x11de1a['secure']||$l();const _0x23e0a2=_0x11de1a['scheme']==='ws'||_0x11de1a['scheme']==='wss';return{'repoInfo':new yo(_0x11de1a['host'],_0x11de1a['secure'],_0x357409,_0x23e0a2,_0x362f6b,'',_0x357409!==_0x11de1a['subdomain']),'path':new C(_0x11de1a['pathString'])};},Md=function(_0x5aa042){let _0x5c0de9='',_0x228eb0='',_0xf8f216='',_0x312f8d='',_0x334d73='',_0x1822f4=!0x0,_0x1843b2='https',_0x57bad5=0x1bb;if(typeof _0x5aa042=='string'){let _0xe46fbf=_0x5aa042['indexOf']('//');_0xe46fbf>=0x0&&(_0x1843b2=_0x5aa042['substring'](0x0,_0xe46fbf-0x1),_0x5aa042=_0x5aa042['substring'](_0xe46fbf+0x2));let _0x548f3e=_0x5aa042['indexOf']('/');_0x548f3e===-0x1&&(_0x548f3e=_0x5aa042['length']);let _0x131cef=_0x5aa042['indexOf']('?');_0x131cef===-0x1&&(_0x131cef=_0x5aa042['length']),_0x5c0de9=_0x5aa042['substring'](0x0,Math['min'](_0x548f3e,_0x131cef)),_0x548f3e<_0x131cef&&(_0x312f8d=Od(_0x5aa042['substring'](_0x548f3e,_0x131cef)));const _0x4b3729=Dd(_0x5aa042['substring'](Math['min'](_0x5aa042['length'],_0x131cef)));_0xe46fbf=_0x5c0de9['indexOf'](':'),_0xe46fbf>=0x0?(_0x1822f4=_0x1843b2==='https'||_0x1843b2==='wss',_0x57bad5=parseInt(_0x5c0de9['substring'](_0xe46fbf+0x1),0xa)):_0xe46fbf=_0x5c0de9['length'];const _0x2b2d01=_0x5c0de9['slice'](0x0,_0xe46fbf);if(_0x2b2d01['toLowerCase']()==='localhost')_0x228eb0='localhost';else{if(_0x2b2d01['split']('.')['length']<=0x2)_0x228eb0=_0x2b2d01;else{const _0x495698=_0x5c0de9['indexOf']('.');_0xf8f216=_0x5c0de9['substring'](0x0,_0x495698)['toLowerCase'](),_0x228eb0=_0x5c0de9['substring'](_0x495698+0x1),_0x334d73=_0xf8f216;}}'ns'in _0x4b3729&&(_0x334d73=_0x4b3729['ns']);}return{'host':_0x5c0de9,'port':_0x57bad5,'domain':_0x228eb0,'subdomain':_0xf8f216,'secure':_0x1822f4,'scheme':_0x1843b2,'pathString':_0x312f8d,'namespace':_0x334d73};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x5b522d=0x0;const _0x52671d=[];return function(_0x4bf22f){const _0x41ea46=_0x4bf22f===_0x5b522d;_0x5b522d=_0x4bf22f;let _0x5ce31e;const _0x254581=new Array(0x8);for(_0x5ce31e=0x7;_0x5ce31e>=0x0;_0x5ce31e--)_0x254581[_0x5ce31e]=Er['charAt'](_0x4bf22f%0x40),_0x4bf22f=Math['floor'](_0x4bf22f/0x40);f(_0x4bf22f===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0xcbd79f=_0x254581['join']('');if(_0x41ea46){for(_0x5ce31e=0xb;_0x5ce31e>=0x0&&_0x52671d[_0x5ce31e]===0x3f;_0x5ce31e--)_0x52671d[_0x5ce31e]=0x0;_0x52671d[_0x5ce31e]++;}else{for(_0x5ce31e=0x0;_0x5ce31e<0xc;_0x5ce31e++)_0x52671d[_0x5ce31e]=Math['floor'](Math['random']()*0x40);}for(_0x5ce31e=0x0;_0x5ce31e<0xc;_0x5ce31e++)_0xcbd79f+=Er['charAt'](_0x52671d[_0x5ce31e]);return f(_0xcbd79f['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0xcbd79f;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x3ddf8e,_0x1d1c90,_0x3ff698,_0xd2dffe){this['eventType']=_0x3ddf8e,this['eventRegistration']=_0x1d1c90,this['snapshot']=_0x3ff698,this['prevName']=_0xd2dffe;}['getPath'](){const _0x544766=this['snapshot']['ref'];return this['eventType']==='value'?_0x544766['_path']:_0x544766['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x3d56da,_0x213ee8,_0x3c2d60){this['eventRegistration']=_0x3d56da,this['error']=_0x213ee8,this['path']=_0x3c2d60;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x57fb3e,_0x118671){this['snapshotCallback']=_0x57fb3e,this['cancelCallback']=_0x118671;}['onValue'](_0x4d399c,_0x1a47bb){this['snapshotCallback']['call'](null,_0x4d399c,_0x1a47bb);}['onCancel'](_0x50184c){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x50184c);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x296bf9){return this['snapshotCallback']===_0x296bf9['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x296bf9['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x296bf9['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x1b6736,_0x287799,_0xc5c178,_0x448cfb){this['_repo']=_0x1b6736,this['_path']=_0x287799,this['_queryParams']=_0xc5c178,this['_orderByCalled']=_0x448cfb;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0xe8ef01=rr(this['_queryParams']),_0x50a579=Hi(_0xe8ef01);return _0x50a579==='{}'?'default':_0x50a579;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x1c21d4){if(_0x1c21d4=N(_0x1c21d4),!(_0x1c21d4 instanceof be))return!0x1;const _0x23da59=this['_repo']===_0x1c21d4['_repo'],_0x53222a=ji(this['_path'],_0x1c21d4['_path']),_0x59e752=this['_queryIdentifier']===_0x1c21d4['_queryIdentifier'];return _0x23da59&&_0x53222a&&_0x59e752;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x2fd75f,_0x2f5acd){if(_0x2fd75f['_orderByCalled']===!0x0)throw new Error(_0x2f5acd+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x4dffdb){let _0xb8a4d=null,_0x51188d=null;if(_0x4dffdb['hasStart']()&&(_0xb8a4d=_0x4dffdb['getIndexStartValue']()),_0x4dffdb['hasEnd']()&&(_0x51188d=_0x4dffdb['getIndexEndValue']()),_0x4dffdb['getIndex']()===ye){const _0x3108e7='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0xa9ba70='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x4dffdb['hasStart']()){if(_0x4dffdb['getIndexStartName']()!==Fe)throw new Error(_0x3108e7);if(typeof _0xb8a4d!='string')throw new Error(_0xa9ba70);}if(_0x4dffdb['hasEnd']()){if(_0x4dffdb['getIndexEndName']()!==Ie)throw new Error(_0x3108e7);if(typeof _0x51188d!='string')throw new Error(_0xa9ba70);}}else{if(_0x4dffdb['getIndex']()===R){if(_0xb8a4d!=null&&!Tn(_0xb8a4d)||_0x51188d!=null&&!Tn(_0x51188d))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x4dffdb['getIndex']()instanceof Qi||_0x4dffdb['getIndex']()===Mo,'unknown\x20index\x20type.'),_0xb8a4d!=null&&typeof _0xb8a4d=='object'||_0x51188d!=null&&typeof _0x51188d=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x1b12df){if(_0x1b12df['hasStart']()&&_0x1b12df['hasEnd']()&&_0x1b12df['hasLimit']()&&!_0x1b12df['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x21f374,_0x1cdb9e){super(_0x21f374,_0x1cdb9e,new Xi(),!0x1);}get['parent'](){const _0x4e5a12=Ro(this['_path']);return _0x4e5a12===null?null:new ee(this['_repo'],_0x4e5a12);}get['root'](){let _0x3ecf85=this;for(;_0x3ecf85['parent']!==null;)_0x3ecf85=_0x3ecf85['parent'];return _0x3ecf85;}}class st{constructor(_0x21211c,_0x1025b2,_0x1b8941){this['_node']=_0x21211c,this['ref']=_0x1025b2,this['_index']=_0x1b8941;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x4f9b98){const _0x22a023=new C(_0x4f9b98),_0xc251c6=Ft(this['ref'],_0x4f9b98);return new st(this['_node']['getChild'](_0x22a023),_0xc251c6,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x39b201){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x4d1d5f,_0x3b4d92)=>_0x39b201(new st(_0x3b4d92,Ft(this['ref'],_0x4d1d5f),R)));}['hasChild'](_0x4cec1d){const _0x19b85d=new C(_0x4cec1d);return!this['_node']['getChild'](_0x19b85d)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x1fd3e7,_0x1aaaf3){return _0x1fd3e7=N(_0x1fd3e7),_0x1fd3e7['_checkNotDeleted']('ref'),_0x1aaaf3!==void 0x0?Ft(_0x1fd3e7['_root'],_0x1aaaf3):_0x1fd3e7['_root'];}function Ft(_0x5f33fd,_0x27bd04){return _0x5f33fd=N(_0x5f33fd),y(_0x5f33fd['_path'])===null?pd('child','path',_0x27bd04):ms('child','path',_0x27bd04),new ee(_0x5f33fd['_repo'],k(_0x5f33fd['_path'],_0x27bd04));}function g_(_0x33b7da,_0x453410){_0x33b7da=N(_0x33b7da),ys('push',_0x33b7da['_path']),zt('push',_0x453410,_0x33b7da['_path'],!0x0);const _0x28d40b=la(_0x33b7da['_repo']),_0x1fb943=Ld(_0x28d40b),_0x38db17=Ft(_0x33b7da,_0x1fb943),_0x3493a2=Ft(_0x33b7da,_0x1fb943);let _0x5b5f4e;return _0x453410!=null?_0x5b5f4e=Ud(_0x3493a2,_0x453410)['then'](()=>_0x3493a2):_0x5b5f4e=Promise['resolve'](_0x3493a2),_0x38db17['then']=_0x5b5f4e['then']['bind'](_0x5b5f4e),_0x38db17['catch']=_0x5b5f4e['then']['bind'](_0x5b5f4e,void 0x0),_0x38db17;}function Ud(_0x582c52,_0x52cdba){_0x582c52=N(_0x582c52),ys('set',_0x582c52['_path']),zt('set',_0x52cdba,_0x582c52['_path'],!0x1);const _0x304480=new ot();return Cd(_0x582c52['_repo'],_0x582c52['_path'],_0x52cdba,null,_0x304480['wrapCallback'](()=>{})),_0x304480['promise'];}function m_(_0x1035f3,_0x24d649){fd('update',_0x24d649,_0x1035f3['_path']);const _0xe7038c=new ot();return Td(_0x1035f3['_repo'],_0x1035f3['_path'],_0x24d649,_0xe7038c['wrapCallback'](()=>{})),_0xe7038c['promise'];}function y_(_0x48afbe){_0x48afbe=N(_0x48afbe);const _0x2db50a=new pa(()=>{}),_0x489f40=new zn(_0x2db50a);return wd(_0x48afbe['_repo'],_0x48afbe,_0x489f40)['then'](_0x18a607=>new st(_0x18a607,new ee(_0x48afbe['_repo'],_0x48afbe['_path']),_0x48afbe['_queryParams']['getIndex']()));}class zn{constructor(_0xbadd4e){this['callbackContext']=_0xbadd4e;}['respondsTo'](_0x24533b){return _0x24533b==='value';}['createEvent'](_0x369a5b,_0xd2bb3b){const _0x282a73=_0xd2bb3b['_queryParams']['getIndex']();return new xd('value',this,new st(_0x369a5b['snapshotNode'],new ee(_0xd2bb3b['_repo'],_0xd2bb3b['_path']),_0x282a73));}['getEventRunner'](_0xc756fd){return _0xc756fd['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0xc756fd['error']):()=>this['callbackContext']['onValue'](_0xc756fd['snapshot'],null);}['createCancelEvent'](_0x4f1849,_0x2084d8){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x4f1849,_0x2084d8):null;}['matches'](_0x2798dc){return _0x2798dc instanceof zn?!_0x2798dc['callbackContext']||!this['callbackContext']?!0x0:_0x2798dc['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x6d3b51,_0x253a19,_0x43e243,_0x393c2f,_0x150584){const _0xefa76b=new pa(_0x43e243,void 0x0),_0x317c59=new zn(_0xefa76b);return bd(_0x6d3b51['_repo'],_0x6d3b51,_0x317c59),()=>Rd(_0x6d3b51['_repo'],_0x6d3b51,_0x317c59);}function Bd(_0x260efa,_0x4b6d2e,_0x395027,_0xa78c62){return Wd(_0x260efa,'value',_0x4b6d2e);}class ft{}class ma extends ft{constructor(_0x56325d,_0x79e5ec){super(),this['_value']=_0x56325d,this['_key']=_0x79e5ec,this['type']='endAt';}['_apply'](_0x576d1f){zt('endAt',this['_value'],_0x576d1f['_path'],!0x0);const _0x7a92fb=Jh(_0x576d1f['_queryParams'],this['_value'],this['_key']);if(ga(_0x7a92fb),qn(_0x7a92fb),_0x576d1f['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x576d1f['_repo'],_0x576d1f['_path'],_0x7a92fb,_0x576d1f['_orderByCalled']);}}function v_(_0x196552,_0x4aca51){return new ma(_0x196552,_0x4aca51);}class ya extends ft{constructor(_0x53ccd5,_0x1e705a){super(),this['_value']=_0x53ccd5,this['_key']=_0x1e705a,this['type']='startAt';}['_apply'](_0x5b6493){zt('startAt',this['_value'],_0x5b6493['_path'],!0x0);const _0x5063ed=Qh(_0x5b6493['_queryParams'],this['_value'],this['_key']);if(ga(_0x5063ed),qn(_0x5063ed),_0x5b6493['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x5b6493['_repo'],_0x5b6493['_path'],_0x5063ed,_0x5b6493['_orderByCalled']);}}function E_(_0x36950c=null,_0x5c7a5a){return new ya(_0x36950c,_0x5c7a5a);}class Vd extends ft{constructor(_0x25d0f3){super(),this['_limit']=_0x25d0f3,this['type']='limitToFirst';}['_apply'](_0x47e025){if(_0x47e025['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x47e025['_repo'],_0x47e025['_path'],Yh(_0x47e025['_queryParams'],this['_limit']),_0x47e025['_orderByCalled']);}}function I_(_0x5271cc){if(Math['floor'](_0x5271cc)!==_0x5271cc||_0x5271cc<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x5271cc);}class Hd extends ft{constructor(_0x220514){super(),this['_path']=_0x220514,this['type']='orderByChild';}['_apply'](_0x3ef861){_a(_0x3ef861,'orderByChild');const _0x434590=new C(this['_path']);if(v(_0x434590))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x2e3d42=new Qi(_0x434590),_0x4676f2=xo(_0x3ef861['_queryParams'],_0x2e3d42);return qn(_0x4676f2),new be(_0x3ef861['_repo'],_0x3ef861['_path'],_0x4676f2,!0x0);}}function w_(_0x2d11f9){if(_0x2d11f9==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x2d11f9==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x2d11f9==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x2d11f9),new Hd(_0x2d11f9);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x4ddb08){_a(_0x4ddb08,'orderByKey');const _0x5b97d8=xo(_0x4ddb08['_queryParams'],ye);return qn(_0x5b97d8),new be(_0x4ddb08['_repo'],_0x4ddb08['_path'],_0x5b97d8,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x1c990e,_0x1b3d3d){super(),this['_value']=_0x1c990e,this['_key']=_0x1b3d3d,this['type']='equalTo';}['_apply'](_0x50d0a2){if(zt('equalTo',this['_value'],_0x50d0a2['_path'],!0x1),_0x50d0a2['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x50d0a2['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x50d0a2));}}function T_(_0x2fbf62,_0x20badb){return new Gd(_0x2fbf62,_0x20badb);}function S_(_0x3a2073,..._0x5b879e){let _0x361d60=N(_0x3a2073);for(const _0x1bdbef of _0x5b879e)_0x361d60=_0x1bdbef['_apply'](_0x361d60);return _0x361d60;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0xd3ff9e,_0x4386d8,_0x4a0ef4,_0x55b106){const _0x3903d4=_0x4386d8['lastIndexOf'](':'),_0x4d1b95=_0x4386d8['substring'](0x0,_0x3903d4),_0xdd8167=at(_0x4d1b95);_0xd3ff9e['repoInfo_']=new yo(_0x4386d8,_0xdd8167,_0xd3ff9e['repoInfo_']['namespace'],_0xd3ff9e['repoInfo_']['webSocketOnly'],_0xd3ff9e['repoInfo_']['nodeAdmin'],_0xd3ff9e['repoInfo_']['persistenceKey'],_0xd3ff9e['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x4a0ef4),_0x55b106&&(_0xd3ff9e['authTokenProvider_']=_0x55b106);}function Kd(_0x3b41f0,_0x3673b7,_0x2e7710,_0x5733cd,_0x4b52a5){let _0x2c8fc1=_0x5733cd||_0x3b41f0['options']['databaseURL'];_0x2c8fc1===void 0x0&&(_0x3b41f0['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x3b41f0['options']['projectId']),_0x2c8fc1=_0x3b41f0['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4aa975=vr(_0x2c8fc1,_0x4b52a5),_0x5f2768=_0x4aa975['repoInfo'],_0x59cf31;typeof process<'u'&&Vs&&(_0x59cf31=Vs[qd]),_0x59cf31?(_0x2c8fc1='http://'+_0x59cf31+'?ns='+_0x5f2768['namespace'],_0x4aa975=vr(_0x2c8fc1,_0x4b52a5),_0x5f2768=_0x4aa975['repoInfo']):_0x4aa975['repoInfo']['secure'];const _0x3af083=new eh(_0x3b41f0['name'],_0x3b41f0['options'],_0x3673b7);_d('Invalid\x20Firebase\x20Database\x20URL',_0x4aa975),v(_0x4aa975['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x48d92e=Qd(_0x5f2768,_0x3b41f0,_0x3af083,new Zl(_0x3b41f0,_0x2e7710));return new Jd(_0x48d92e,_0x3b41f0);}function Yd(_0x2b0867,_0xda285c){const _0x234d37=Ni[_0xda285c];(!_0x234d37||_0x234d37[_0x2b0867['key']]!==_0x2b0867)&&ae('Database\x20'+_0xda285c+'('+_0x2b0867['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x2b0867),delete _0x234d37[_0x2b0867['key']];}function Qd(_0x58d1e8,_0x1584a5,_0x533ffc,_0x4bb9f9){let _0x5148f5=Ni[_0x1584a5['name']];_0x5148f5||(_0x5148f5={},Ni[_0x1584a5['name']]=_0x5148f5);let _0x74876a=_0x5148f5[_0x58d1e8['toURLString']()];return _0x74876a&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x74876a=new vd(_0x58d1e8,zd,_0x533ffc,_0x4bb9f9),_0x5148f5[_0x58d1e8['toURLString']()]=_0x74876a,_0x74876a;}class Jd{constructor(_0x7aeca9,_0x57aeee){this['_repoInternal']=_0x7aeca9,this['app']=_0x57aeee,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x43e138){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x43e138+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x4c6b47=Zr(),_0x1b2247){const _0x4ed1f7=Bi(_0x4c6b47,'database')['getImmediate']({'identifier':_0x1b2247});if(!_0x4ed1f7['_instanceStarted']){const _0xf7cada=cc('database');_0xf7cada&&Xd(_0x4ed1f7,..._0xf7cada);}return _0x4ed1f7;}function Xd(_0x20c770,_0x70ed20,_0x4f225d,_0x30a431={}){_0x20c770=N(_0x20c770),_0x20c770['_checkNotDeleted']('useEmulator');const _0xded38a=_0x70ed20+':'+_0x4f225d,_0x524f3c=_0x20c770['_repoInternal'];if(_0x20c770['_instanceStarted']){if(_0xded38a===_0x20c770['_repoInternal']['repoInfo_']['host']&&Me(_0x30a431,_0x524f3c['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x1d2507;if(_0x524f3c['repoInfo_']['nodeAdmin'])_0x30a431['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x1d2507=new nn(nn['OWNER']);else{if(_0x30a431['mockUserToken']){const _0x5a0bcb=typeof _0x30a431['mockUserToken']=='string'?_0x30a431['mockUserToken']:lc(_0x30a431['mockUserToken'],_0x20c770['app']['options']['projectId']);_0x1d2507=new nn(_0x5a0bcb);}}at(_0x70ed20)&&(jr(_0x70ed20),Kr('Database',!0x0)),jd(_0x524f3c,_0xded38a,_0x30a431,_0x1d2507);}function R_(_0x5401f9){_0x5401f9=N(_0x5401f9),_0x5401f9['_checkNotDeleted']('goOffline'),ha(_0x5401f9['_repo']);}function A_(_0x20ca03){_0x20ca03=N(_0x20ca03),_0x20ca03['_checkNotDeleted']('goOnline'),Ad(_0x20ca03['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x3375e9){Ul(lt),Ze(new Le('database',(_0x4bb8dc,{instanceIdentifier:_0x53ace5})=>{const _0x444a3d=_0x4bb8dc['getProvider']('app')['getImmediate'](),_0x58117a=_0x4bb8dc['getProvider']('auth-internal'),_0x5bb332=_0x4bb8dc['getProvider']('app-check-internal');return Kd(_0x444a3d,_0x58117a,_0x5bb332,_0x53ace5);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x3375e9),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x49273c,_0x2ef937){this['committed']=_0x49273c,this['snapshot']=_0x2ef937;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x141d95,_0x454a45,_0x4d4d23){if(_0x141d95=N(_0x141d95),ys('Reference.transaction',_0x141d95['_path']),_0x141d95['key']==='.length'||_0x141d95['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x141d95['key']+'\x20is\x20a\x20read-only\x20object.';const _0x4452cd=!0x0,_0x1eb631=new ot(),_0x168698=(_0x422e8a,_0x41177d,_0x59d37f)=>{let _0x859468=null;_0x422e8a?_0x1eb631['reject'](_0x422e8a):(_0x859468=new st(_0x59d37f,new ee(_0x141d95['_repo'],_0x141d95['_path']),R),_0x1eb631['resolve'](new tf(_0x41177d,_0x859468)));},_0x3ae2a4=Bd(_0x141d95,()=>{});return kd(_0x141d95['_repo'],_0x141d95['_path'],_0x454a45,_0x168698,_0x3ae2a4,_0x4452cd),_0x1eb631['promise'];}se['prototype']['simpleListen']=function(_0x1a28a1,_0x24ab51){this['sendRequest']('q',{'p':_0x1a28a1},_0x24ab51);},se['prototype']['echo']=function(_0x1f7837,_0x82b2dd){this['sendRequest']('echo',{'d':_0x1f7837},_0x82b2dd);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x26610d,..._0x416b81){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x26610d,..._0x416b81);}function sn(_0x4dd459,..._0x40adc2){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x4dd459,..._0x40adc2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0xee4d93,..._0x5634e8){throw ws(_0xee4d93,..._0x5634e8);}function X(_0x1175b2,..._0x2a3a8a){return ws(_0x1175b2,..._0x2a3a8a);}function Ia(_0x28fc16,_0x1867ea,_0xb0208e){const _0x33088d={...nf(),[_0x1867ea]:_0xb0208e};return new Bt('auth','Firebase',_0x33088d)['create'](_0x1867ea,{'appName':_0x28fc16['name']});}function re(_0x5b8dfc){return Ia(_0x5b8dfc,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x258fd4,..._0x3173c4){if(typeof _0x258fd4!='string'){const _0x49a2f2=_0x3173c4[0x0],_0x4e0b51=[..._0x3173c4['slice'](0x1)];return _0x4e0b51[0x0]&&(_0x4e0b51[0x0]['appName']=_0x258fd4['name']),_0x258fd4['_errorFactory']['create'](_0x49a2f2,..._0x4e0b51);}return Ea['create'](_0x258fd4,..._0x3173c4);}function m(_0x3dc492,_0x5c4146,..._0x41474f){if(!_0x3dc492)throw ws(_0x5c4146,..._0x41474f);}function ne(_0x5ec4f5){const _0x3b5f22='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x5ec4f5;throw sn(_0x3b5f22),new Error(_0x3b5f22);}function ce(_0x40ae3d,_0x5efcfd){_0x40ae3d||ne(_0x5efcfd);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x40a657;return typeof self<'u'&&((_0x40a657=self['location'])==null?void 0x0:_0x40a657['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x3f1c8b;return typeof self<'u'&&((_0x3f1c8b=self['location'])==null?void 0x0:_0x3f1c8b['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x368df0=navigator;return _0x368df0['languages']&&_0x368df0['languages'][0x0]||_0x368df0['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x4d987b,_0x3470b8){this['shortDelay']=_0x4d987b,this['longDelay']=_0x3470b8,ce(_0x3470b8>_0x4d987b,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x519633,_0x59fe4e){ce(_0x519633['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x1094e9}=_0x519633['emulator'];return _0x59fe4e?''+_0x1094e9+(_0x59fe4e['startsWith']('/')?_0x59fe4e['slice'](0x1):_0x59fe4e):_0x1094e9;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x4db794,_0x4cd625,_0xd5c8d7){this['fetchImpl']=_0x4db794,_0x4cd625&&(this['headersImpl']=_0x4cd625),_0xd5c8d7&&(this['responseImpl']=_0xd5c8d7);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x2e70bb,_0x228a33){return _0x2e70bb['tenantId']&&!_0x228a33['tenantId']?{..._0x228a33,'tenantId':_0x2e70bb['tenantId']}:_0x228a33;}async function Ae(_0x551920,_0x158969,_0x46f44a,_0x172428,_0x30eefa={}){return Ca(_0x551920,_0x30eefa,async()=>{let _0x31b2fd={},_0x3a9d65={};_0x172428&&(_0x158969==='GET'?_0x3a9d65=_0x172428:_0x31b2fd={'body':JSON['stringify'](_0x172428)});const _0x594bdd=ct({'key':_0x551920['config']['apiKey'],..._0x3a9d65})['slice'](0x1),_0x56c541=await _0x551920['_getAdditionalHeaders']();_0x56c541['Content-Type']='application/json',_0x551920['languageCode']&&(_0x56c541['X-Firebase-Locale']=_0x551920['languageCode']);const _0x326a6b={'method':_0x158969,'headers':_0x56c541,..._0x31b2fd};return dc()||(_0x326a6b['referrerPolicy']='no-referrer'),_0x551920['emulatorConfig']&&at(_0x551920['emulatorConfig']['host'])&&(_0x326a6b['credentials']='include'),wa['fetch']()(await Ta(_0x551920,_0x551920['config']['apiHost'],_0x46f44a,_0x594bdd),_0x326a6b);});}async function Ca(_0x8f7239,_0x56ca9a,_0x56d6a0){_0x8f7239['_canInitEmulator']=!0x1;const _0x137c1b={...cf,..._0x56ca9a};try{const _0x488a91=new df(_0x8f7239),_0x492e2b=await Promise['race']([_0x56d6a0(),_0x488a91['promise']]);_0x488a91['clearNetworkTimeout']();const _0x15175=await _0x492e2b['json']();if('needConfirmation'in _0x15175)throw tn(_0x8f7239,'account-exists-with-different-credential',_0x15175);if(_0x492e2b['ok']&&!('errorMessage'in _0x15175))return _0x15175;{const _0x3ea95e=_0x492e2b['ok']?_0x15175['errorMessage']:_0x15175['error']['message'],[_0xceeca8,_0x23059f]=_0x3ea95e['split']('\x20:\x20');if(_0xceeca8==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x8f7239,'credential-already-in-use',_0x15175);if(_0xceeca8==='EMAIL_EXISTS')throw tn(_0x8f7239,'email-already-in-use',_0x15175);if(_0xceeca8==='USER_DISABLED')throw tn(_0x8f7239,'user-disabled',_0x15175);const _0x4ac0a0=_0x137c1b[_0xceeca8]||_0xceeca8['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x23059f)throw Ia(_0x8f7239,_0x4ac0a0,_0x23059f);Q(_0x8f7239,_0x4ac0a0);}}catch(_0x5f0389){if(_0x5f0389 instanceof Se)throw _0x5f0389;Q(_0x8f7239,'network-request-failed',{'message':String(_0x5f0389)});}}async function Qt(_0x127678,_0xbb22ed,_0x1445d5,_0x427731,_0x125b46={}){const _0x4926a2=await Ae(_0x127678,_0xbb22ed,_0x1445d5,_0x427731,_0x125b46);return'mfaPendingCredential'in _0x4926a2&&Q(_0x127678,'multi-factor-auth-required',{'_serverResponse':_0x4926a2}),_0x4926a2;}async function Ta(_0x487bff,_0x17d41d,_0x52494c,_0xa50881){const _0x165f51=''+_0x17d41d+_0x52494c+'?'+_0xa50881,_0x13f24f=_0x487bff,_0x17cb62=_0x13f24f['config']['emulator']?Cs(_0x487bff['config'],_0x165f51):_0x487bff['config']['apiScheme']+'://'+_0x165f51;return lf['includes'](_0x52494c)&&(await _0x13f24f['_persistenceManagerAvailable'],_0x13f24f['_getPersistenceType']()==='COOKIE')?_0x13f24f['_getPersistence']()['_getFinalTarget'](_0x17cb62)['toString']():_0x17cb62;}function uf(_0x3c6f3d){switch(_0x3c6f3d){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x1de67e){this['auth']=_0x1de67e,this['timer']=null,this['promise']=new Promise((_0x1f5d71,_0x1967ed)=>{this['timer']=setTimeout(()=>_0x1967ed(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x245559,_0x2c0050,_0x9a9f90){const _0x18e338={'appName':_0x245559['name']};_0x9a9f90['email']&&(_0x18e338['email']=_0x9a9f90['email']),_0x9a9f90['phoneNumber']&&(_0x18e338['phoneNumber']=_0x9a9f90['phoneNumber']);const _0x44ff39=X(_0x245559,_0x2c0050,_0x18e338);return _0x44ff39['customData']['_tokenResponse']=_0x9a9f90,_0x44ff39;}function wr(_0x1a9e15){return _0x1a9e15!==void 0x0&&_0x1a9e15['enterprise']!==void 0x0;}class ff{constructor(_0x5ab1d5){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x5ab1d5['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x5ab1d5['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x5ab1d5['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x42731f){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x173aef of this['recaptchaEnforcementState'])if(_0x173aef['provider']&&_0x173aef['provider']===_0x42731f)return uf(_0x173aef['enforcementState']);return null;}['isProviderEnabled'](_0x3fdbba){return this['getProviderEnforcementState'](_0x3fdbba)==='ENFORCE'||this['getProviderEnforcementState'](_0x3fdbba)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x555b61,_0x251afc){return Ae(_0x555b61,'GET','/v2/recaptchaConfig',Re(_0x555b61,_0x251afc));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0xcfc2bb,_0x3903f0){return Ae(_0xcfc2bb,'POST','/v1/accounts:delete',_0x3903f0);}async function bn(_0x3b6f37,_0x2f37fe){return Ae(_0x3b6f37,'POST','/v1/accounts:lookup',_0x2f37fe);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x7e4445){if(_0x7e4445)try{const _0x2d4084=new Date(Number(_0x7e4445));if(!isNaN(_0x2d4084['getTime']()))return _0x2d4084['toUTCString']();}catch{}}async function gf(_0x465e63,_0x42a082=!0x1){const _0x303bf5=N(_0x465e63),_0x5eef46=await _0x303bf5['getIdToken'](_0x42a082),_0x4daaf2=Ts(_0x5eef46);m(_0x4daaf2&&_0x4daaf2['exp']&&_0x4daaf2['auth_time']&&_0x4daaf2['iat'],_0x303bf5['auth'],'internal-error');const _0x10b5a6=typeof _0x4daaf2['firebase']=='object'?_0x4daaf2['firebase']:void 0x0,_0x3ddb13=_0x10b5a6==null?void 0x0:_0x10b5a6['sign_in_provider'];return{'claims':_0x4daaf2,'token':_0x5eef46,'authTime':Rt(li(_0x4daaf2['auth_time'])),'issuedAtTime':Rt(li(_0x4daaf2['iat'])),'expirationTime':Rt(li(_0x4daaf2['exp'])),'signInProvider':_0x3ddb13||null,'signInSecondFactor':(_0x10b5a6==null?void 0x0:_0x10b5a6['sign_in_second_factor'])||null};}function li(_0x6308b3){return Number(_0x6308b3)*0x3e8;}function Ts(_0xc8ef12){const [_0x1b89ff,_0x549f80,_0xaf398c]=_0xc8ef12['split']('.');if(_0x1b89ff===void 0x0||_0x549f80===void 0x0||_0xaf398c===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x5a5207=ln(_0x549f80);return _0x5a5207?JSON['parse'](_0x5a5207):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x468b22){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x468b22==null?void 0x0:_0x468b22['toString']()),null;}}function Cr(_0x32802c){const _0x225919=Ts(_0x32802c);return m(_0x225919,'internal-error'),m(typeof _0x225919['exp']<'u','internal-error'),m(typeof _0x225919['iat']<'u','internal-error'),Number(_0x225919['exp'])-Number(_0x225919['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x140c55,_0x3f1f8d,_0x550202=!0x1){if(_0x550202)return _0x3f1f8d;try{return await _0x3f1f8d;}catch(_0x5581ed){throw _0x5581ed instanceof Se&&mf(_0x5581ed)&&_0x140c55['auth']['currentUser']===_0x140c55&&await _0x140c55['auth']['signOut'](),_0x5581ed;}}function mf({code:_0x467ee5}){return _0x467ee5==='auth/user-disabled'||_0x467ee5==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x25e235){this['user']=_0x25e235,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0xfd8fdb){if(_0xfd8fdb){const _0x28b5fd=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x28b5fd;}else{this['errorBackoff']=0x7530;const _0x2b40f8=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x2b40f8);}}['schedule'](_0x38fbef=!0x1){if(!this['isRunning'])return;const _0x23ecf8=this['getInterval'](_0x38fbef);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x23ecf8);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x2411da){(_0x2411da==null?void 0x0:_0x2411da['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x3d5c88,_0xa13107){this['createdAt']=_0x3d5c88,this['lastLoginAt']=_0xa13107,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x47c818){this['createdAt']=_0x47c818['createdAt'],this['lastLoginAt']=_0x47c818['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0xf8bdd7){var _0xbf4ba8;const _0x186b20=_0xf8bdd7['auth'],_0xc480fb=await _0xf8bdd7['getIdToken'](),_0x22428f=await Ut(_0xf8bdd7,bn(_0x186b20,{'idToken':_0xc480fb}));m(_0x22428f==null?void 0x0:_0x22428f['users']['length'],_0x186b20,'internal-error');const _0x3128dd=_0x22428f['users'][0x0];_0xf8bdd7['_notifyReloadListener'](_0x3128dd);const _0x279f53=(_0xbf4ba8=_0x3128dd['providerUserInfo'])!=null&&_0xbf4ba8['length']?Sa(_0x3128dd['providerUserInfo']):[],_0x45d5dd=Ef(_0xf8bdd7['providerData'],_0x279f53),_0x53dac9=_0xf8bdd7['isAnonymous'],_0x90f52a=!(_0xf8bdd7['email']&&_0x3128dd['passwordHash'])&&!(_0x45d5dd!=null&&_0x45d5dd['length']),_0x5e0f87=_0x53dac9?_0x90f52a:!0x1,_0x1b0921={'uid':_0x3128dd['localId'],'displayName':_0x3128dd['displayName']||null,'photoURL':_0x3128dd['photoUrl']||null,'email':_0x3128dd['email']||null,'emailVerified':_0x3128dd['emailVerified']||!0x1,'phoneNumber':_0x3128dd['phoneNumber']||null,'tenantId':_0x3128dd['tenantId']||null,'providerData':_0x45d5dd,'metadata':new Oi(_0x3128dd['createdAt'],_0x3128dd['lastLoginAt']),'isAnonymous':_0x5e0f87};Object['assign'](_0xf8bdd7,_0x1b0921);}async function vf(_0x171a44){const _0x437151=N(_0x171a44);await Rn(_0x437151),await _0x437151['auth']['_persistUserIfCurrent'](_0x437151),_0x437151['auth']['_notifyListenersIfCurrent'](_0x437151);}function Ef(_0x100101,_0x2f79a1){return[..._0x100101['filter'](_0x213ca7=>!_0x2f79a1['some'](_0x27560d=>_0x27560d['providerId']===_0x213ca7['providerId'])),..._0x2f79a1];}function Sa(_0x35970c){return _0x35970c['map'](({providerId:_0xdd7207,..._0x2b1f29})=>({'providerId':_0xdd7207,'uid':_0x2b1f29['rawId']||'','displayName':_0x2b1f29['displayName']||null,'email':_0x2b1f29['email']||null,'phoneNumber':_0x2b1f29['phoneNumber']||null,'photoURL':_0x2b1f29['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x230201,_0x354b6a){const _0xd1cbeb=await Ca(_0x230201,{},async()=>{const _0x4fd44a=ct({'grant_type':'refresh_token','refresh_token':_0x354b6a})['slice'](0x1),{tokenApiHost:_0x23289f,apiKey:_0x59b67e}=_0x230201['config'],_0x3e410f=await Ta(_0x230201,_0x23289f,'/v1/token','key='+_0x59b67e),_0x5e8be2=await _0x230201['_getAdditionalHeaders']();_0x5e8be2['Content-Type']='application/x-www-form-urlencoded';const _0x349a7e={'method':'POST','headers':_0x5e8be2,'body':_0x4fd44a};return _0x230201['emulatorConfig']&&at(_0x230201['emulatorConfig']['host'])&&(_0x349a7e['credentials']='include'),wa['fetch']()(_0x3e410f,_0x349a7e);});return{'accessToken':_0xd1cbeb['access_token'],'expiresIn':_0xd1cbeb['expires_in'],'refreshToken':_0xd1cbeb['refresh_token']};}async function wf(_0x2f2178,_0x388e53){return Ae(_0x2f2178,'POST','/v2/accounts:revokeToken',Re(_0x2f2178,_0x388e53));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x302b1c){m(_0x302b1c['idToken'],'internal-error'),m(typeof _0x302b1c['idToken']<'u','internal-error'),m(typeof _0x302b1c['refreshToken']<'u','internal-error');const _0x76f617='expiresIn'in _0x302b1c&&typeof _0x302b1c['expiresIn']<'u'?Number(_0x302b1c['expiresIn']):Cr(_0x302b1c['idToken']);this['updateTokensAndExpiration'](_0x302b1c['idToken'],_0x302b1c['refreshToken'],_0x76f617);}['updateFromIdToken'](_0x3215ca){m(_0x3215ca['length']!==0x0,'internal-error');const _0x247211=Cr(_0x3215ca);this['updateTokensAndExpiration'](_0x3215ca,null,_0x247211);}async['getToken'](_0x4ecadc,_0x4be5e5=!0x1){return!_0x4be5e5&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x4ecadc,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x4ecadc,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x500343,_0xe58cea){const {accessToken:_0x1b0c23,refreshToken:_0x20ab71,expiresIn:_0x316524}=await If(_0x500343,_0xe58cea);this['updateTokensAndExpiration'](_0x1b0c23,_0x20ab71,Number(_0x316524));}['updateTokensAndExpiration'](_0x1a907a,_0x27a19b,_0x10a40c){this['refreshToken']=_0x27a19b||null,this['accessToken']=_0x1a907a||null,this['expirationTime']=Date['now']()+_0x10a40c*0x3e8;}static['fromJSON'](_0x37b6f5,_0x58419d){const {refreshToken:_0x3e6950,accessToken:_0x26dc1d,expirationTime:_0xee5f27}=_0x58419d,_0x51e5dd=new Qe();return _0x3e6950&&(m(typeof _0x3e6950=='string','internal-error',{'appName':_0x37b6f5}),_0x51e5dd['refreshToken']=_0x3e6950),_0x26dc1d&&(m(typeof _0x26dc1d=='string','internal-error',{'appName':_0x37b6f5}),_0x51e5dd['accessToken']=_0x26dc1d),_0xee5f27&&(m(typeof _0xee5f27=='number','internal-error',{'appName':_0x37b6f5}),_0x51e5dd['expirationTime']=_0xee5f27),_0x51e5dd;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x20abad){this['accessToken']=_0x20abad['accessToken'],this['refreshToken']=_0x20abad['refreshToken'],this['expirationTime']=_0x20abad['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0xf25e6d,_0x554263){m(typeof _0xf25e6d=='string'||typeof _0xf25e6d>'u','internal-error',{'appName':_0x554263});}class K{constructor({uid:_0x38bb9c,auth:_0x4a1e9c,stsTokenManager:_0x689c8,..._0x22d9dd}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x38bb9c,this['auth']=_0x4a1e9c,this['stsTokenManager']=_0x689c8,this['accessToken']=_0x689c8['accessToken'],this['displayName']=_0x22d9dd['displayName']||null,this['email']=_0x22d9dd['email']||null,this['emailVerified']=_0x22d9dd['emailVerified']||!0x1,this['phoneNumber']=_0x22d9dd['phoneNumber']||null,this['photoURL']=_0x22d9dd['photoURL']||null,this['isAnonymous']=_0x22d9dd['isAnonymous']||!0x1,this['tenantId']=_0x22d9dd['tenantId']||null,this['providerData']=_0x22d9dd['providerData']?[..._0x22d9dd['providerData']]:[],this['metadata']=new Oi(_0x22d9dd['createdAt']||void 0x0,_0x22d9dd['lastLoginAt']||void 0x0);}async['getIdToken'](_0xca30a){const _0x45c292=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0xca30a));return m(_0x45c292,this['auth'],'internal-error'),this['accessToken']!==_0x45c292&&(this['accessToken']=_0x45c292,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x45c292;}['getIdTokenResult'](_0x4ddb20){return gf(this,_0x4ddb20);}['reload'](){return vf(this);}['_assign'](_0xb3c85){this!==_0xb3c85&&(m(this['uid']===_0xb3c85['uid'],this['auth'],'internal-error'),this['displayName']=_0xb3c85['displayName'],this['photoURL']=_0xb3c85['photoURL'],this['email']=_0xb3c85['email'],this['emailVerified']=_0xb3c85['emailVerified'],this['phoneNumber']=_0xb3c85['phoneNumber'],this['isAnonymous']=_0xb3c85['isAnonymous'],this['tenantId']=_0xb3c85['tenantId'],this['providerData']=_0xb3c85['providerData']['map'](_0x3cb696=>({..._0x3cb696})),this['metadata']['_copy'](_0xb3c85['metadata']),this['stsTokenManager']['_assign'](_0xb3c85['stsTokenManager']));}['_clone'](_0x3b5bf6){const _0x2e1a67=new K({...this,'auth':_0x3b5bf6,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x2e1a67['metadata']['_copy'](this['metadata']),_0x2e1a67;}['_onReload'](_0x528168){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x528168,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x4185ac){this['reloadListener']?this['reloadListener'](_0x4185ac):this['reloadUserInfo']=_0x4185ac;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x283cf7,_0x42875f=!0x1){let _0x358d62=!0x1;_0x283cf7['idToken']&&_0x283cf7['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x283cf7),_0x358d62=!0x0),_0x42875f&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x358d62&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x24677a=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x24677a})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x510f6e=>({..._0x510f6e})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x53b86f,_0x37ba22){const _0x40a59e=_0x37ba22['displayName']??void 0x0,_0x4ac731=_0x37ba22['email']??void 0x0,_0x179fff=_0x37ba22['phoneNumber']??void 0x0,_0x338b14=_0x37ba22['photoURL']??void 0x0,_0x5ad5c8=_0x37ba22['tenantId']??void 0x0,_0x259e4b=_0x37ba22['_redirectEventId']??void 0x0,_0x3dcba7=_0x37ba22['createdAt']??void 0x0,_0x9e3d16=_0x37ba22['lastLoginAt']??void 0x0,{uid:_0x518e0b,emailVerified:_0x1e123a,isAnonymous:_0x4f6353,providerData:_0x34a8fe,stsTokenManager:_0x566964}=_0x37ba22;m(_0x518e0b&&_0x566964,_0x53b86f,'internal-error');const _0x35c7f2=Qe['fromJSON'](this['name'],_0x566964);m(typeof _0x518e0b=='string',_0x53b86f,'internal-error'),le(_0x40a59e,_0x53b86f['name']),le(_0x4ac731,_0x53b86f['name']),m(typeof _0x1e123a=='boolean',_0x53b86f,'internal-error'),m(typeof _0x4f6353=='boolean',_0x53b86f,'internal-error'),le(_0x179fff,_0x53b86f['name']),le(_0x338b14,_0x53b86f['name']),le(_0x5ad5c8,_0x53b86f['name']),le(_0x259e4b,_0x53b86f['name']),le(_0x3dcba7,_0x53b86f['name']),le(_0x9e3d16,_0x53b86f['name']);const _0x2dc213=new K({'uid':_0x518e0b,'auth':_0x53b86f,'email':_0x4ac731,'emailVerified':_0x1e123a,'displayName':_0x40a59e,'isAnonymous':_0x4f6353,'photoURL':_0x338b14,'phoneNumber':_0x179fff,'tenantId':_0x5ad5c8,'stsTokenManager':_0x35c7f2,'createdAt':_0x3dcba7,'lastLoginAt':_0x9e3d16});return _0x34a8fe&&Array['isArray'](_0x34a8fe)&&(_0x2dc213['providerData']=_0x34a8fe['map'](_0x2fe31d=>({..._0x2fe31d}))),_0x259e4b&&(_0x2dc213['_redirectEventId']=_0x259e4b),_0x2dc213;}static async['_fromIdTokenResponse'](_0x9deb22,_0x3dc66c,_0x33f28b=!0x1){const _0x2a4353=new Qe();_0x2a4353['updateFromServerResponse'](_0x3dc66c);const _0x216ad8=new K({'uid':_0x3dc66c['localId'],'auth':_0x9deb22,'stsTokenManager':_0x2a4353,'isAnonymous':_0x33f28b});return await Rn(_0x216ad8),_0x216ad8;}static async['_fromGetAccountInfoResponse'](_0x297f1f,_0x568740,_0x15476b){const _0xc4c1bc=_0x568740['users'][0x0];m(_0xc4c1bc['localId']!==void 0x0,'internal-error');const _0x4094a7=_0xc4c1bc['providerUserInfo']!==void 0x0?Sa(_0xc4c1bc['providerUserInfo']):[],_0x2b6c2c=!(_0xc4c1bc['email']&&_0xc4c1bc['passwordHash'])&&!(_0x4094a7!=null&&_0x4094a7['length']),_0x5cf17d=new Qe();_0x5cf17d['updateFromIdToken'](_0x15476b);const _0x333587=new K({'uid':_0xc4c1bc['localId'],'auth':_0x297f1f,'stsTokenManager':_0x5cf17d,'isAnonymous':_0x2b6c2c}),_0x2066fc={'uid':_0xc4c1bc['localId'],'displayName':_0xc4c1bc['displayName']||null,'photoURL':_0xc4c1bc['photoUrl']||null,'email':_0xc4c1bc['email']||null,'emailVerified':_0xc4c1bc['emailVerified']||!0x1,'phoneNumber':_0xc4c1bc['phoneNumber']||null,'tenantId':_0xc4c1bc['tenantId']||null,'providerData':_0x4094a7,'metadata':new Oi(_0xc4c1bc['createdAt'],_0xc4c1bc['lastLoginAt']),'isAnonymous':!(_0xc4c1bc['email']&&_0xc4c1bc['passwordHash'])&&!(_0x4094a7!=null&&_0x4094a7['length'])};return Object['assign'](_0x333587,_0x2066fc),_0x333587;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x5d3988){ce(_0x5d3988 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x530dcc=Tr['get'](_0x5d3988);return _0x530dcc?(ce(_0x530dcc instanceof _0x5d3988,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x530dcc):(_0x530dcc=new _0x5d3988(),Tr['set'](_0x5d3988,_0x530dcc),_0x530dcc);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x24a5b1,_0x4fe615){this['storage'][_0x24a5b1]=_0x4fe615;}async['_get'](_0x116193){const _0x31a897=this['storage'][_0x116193];return _0x31a897===void 0x0?null:_0x31a897;}async['_remove'](_0x559266){delete this['storage'][_0x559266];}['_addListener'](_0x1912d0,_0x2ee41c){}['_removeListener'](_0x1dc3e1,_0x6512f7){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x14fe4d,_0x55f9cd,_0x8e2b3a){return'firebase:'+_0x14fe4d+':'+_0x55f9cd+':'+_0x8e2b3a;}class Je{constructor(_0x3a2042,_0x33aa5a,_0x3855b3){this['persistence']=_0x3a2042,this['auth']=_0x33aa5a,this['userKey']=_0x3855b3;const {config:_0x92764d,name:_0x5765cf}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x92764d['apiKey'],_0x5765cf),this['fullPersistenceKey']=rn('persistence',_0x92764d['apiKey'],_0x5765cf),this['boundEventHandler']=_0x33aa5a['_onStorageEvent']['bind'](_0x33aa5a),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x395f6f){return this['persistence']['_set'](this['fullUserKey'],_0x395f6f['toJSON']());}async['getCurrentUser'](){const _0xcee83a=await this['persistence']['_get'](this['fullUserKey']);if(!_0xcee83a)return null;if(typeof _0xcee83a=='string'){const _0x2a8d3b=await bn(this['auth'],{'idToken':_0xcee83a})['catch'](()=>{});return _0x2a8d3b?K['_fromGetAccountInfoResponse'](this['auth'],_0x2a8d3b,_0xcee83a):null;}return K['_fromJSON'](this['auth'],_0xcee83a);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x18d1e4){if(this['persistence']===_0x18d1e4)return;const _0x50d00d=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x18d1e4,_0x50d00d)return this['setCurrentUser'](_0x50d00d);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x5b5189,_0x1e7cb5,_0x1f8499='authUser'){if(!_0x1e7cb5['length'])return new Je(ie(Sr),_0x5b5189,_0x1f8499);const _0x115519=(await Promise['all'](_0x1e7cb5['map'](async _0x3e8e32=>{if(await _0x3e8e32['_isAvailable']())return _0x3e8e32;})))['filter'](_0x21798e=>_0x21798e);let _0x589397=_0x115519[0x0]||ie(Sr);const _0x3dac47=rn(_0x1f8499,_0x5b5189['config']['apiKey'],_0x5b5189['name']);let _0x5db0b6=null;for(const _0x2e9a76 of _0x1e7cb5)try{const _0x50125e=await _0x2e9a76['_get'](_0x3dac47);if(_0x50125e){let _0x24af55;if(typeof _0x50125e=='string'){const _0x18a6f6=await bn(_0x5b5189,{'idToken':_0x50125e})['catch'](()=>{});if(!_0x18a6f6)break;_0x24af55=await K['_fromGetAccountInfoResponse'](_0x5b5189,_0x18a6f6,_0x50125e);}else _0x24af55=K['_fromJSON'](_0x5b5189,_0x50125e);_0x2e9a76!==_0x589397&&(_0x5db0b6=_0x24af55),_0x589397=_0x2e9a76;break;}}catch{}const _0xf438d0=_0x115519['filter'](_0x5734f7=>_0x5734f7['_shouldAllowMigration']);return!_0x589397['_shouldAllowMigration']||!_0xf438d0['length']?new Je(_0x589397,_0x5b5189,_0x1f8499):(_0x589397=_0xf438d0[0x0],_0x5db0b6&&await _0x589397['_set'](_0x3dac47,_0x5db0b6['toJSON']()),await Promise['all'](_0x1e7cb5['map'](async _0x47247c=>{if(_0x47247c!==_0x589397)try{await _0x47247c['_remove'](_0x3dac47);}catch{}})),new Je(_0x589397,_0x5b5189,_0x1f8499));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x1ea9e3){const _0x3fdae9=_0x1ea9e3['toLowerCase']();if(_0x3fdae9['includes']('opera/')||_0x3fdae9['includes']('opr/')||_0x3fdae9['includes']('opios/'))return'Opera';if(Na(_0x3fdae9))return'IEMobile';if(_0x3fdae9['includes']('msie')||_0x3fdae9['includes']('trident/'))return'IE';if(_0x3fdae9['includes']('edge/'))return'Edge';if(Ra(_0x3fdae9))return'Firefox';if(_0x3fdae9['includes']('silk/'))return'Silk';if(Oa(_0x3fdae9))return'Blackberry';if(Da(_0x3fdae9))return'Webos';if(Aa(_0x3fdae9))return'Safari';if((_0x3fdae9['includes']('chrome/')||ka(_0x3fdae9))&&!_0x3fdae9['includes']('edge/'))return'Chrome';if(Pa(_0x3fdae9))return'Android';{const _0x3b3209=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x5f0fc6=_0x1ea9e3['match'](_0x3b3209);if((_0x5f0fc6==null?void 0x0:_0x5f0fc6['length'])===0x2)return _0x5f0fc6[0x1];}return'Other';}function Ra(_0x4fd621=W()){return/firefox\//i['test'](_0x4fd621);}function Aa(_0x3ea641=W()){const _0x2d726d=_0x3ea641['toLowerCase']();return _0x2d726d['includes']('safari/')&&!_0x2d726d['includes']('chrome/')&&!_0x2d726d['includes']('crios/')&&!_0x2d726d['includes']('android');}function ka(_0x3d2d50=W()){return/crios\//i['test'](_0x3d2d50);}function Na(_0x57f43d=W()){return/iemobile/i['test'](_0x57f43d);}function Pa(_0x557d44=W()){return/android/i['test'](_0x557d44);}function Oa(_0x109300=W()){return/blackberry/i['test'](_0x109300);}function Da(_0x21058b=W()){return/webos/i['test'](_0x21058b);}function Ss(_0x53ec80=W()){return/iphone|ipad|ipod/i['test'](_0x53ec80)||/macintosh/i['test'](_0x53ec80)&&/mobile/i['test'](_0x53ec80);}function Cf(_0x531720=W()){var _0xb75fe7;return Ss(_0x531720)&&!!((_0xb75fe7=window['navigator'])!=null&&_0xb75fe7['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x51de7f=W()){return Ss(_0x51de7f)||Pa(_0x51de7f)||Da(_0x51de7f)||Oa(_0x51de7f)||/windows phone/i['test'](_0x51de7f)||Na(_0x51de7f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x23a398,_0x11a9df=[]){let _0x56d4b2;switch(_0x23a398){case'Browser':_0x56d4b2=br(W());break;case'Worker':_0x56d4b2=br(W())+'-'+_0x23a398;break;default:_0x56d4b2=_0x23a398;}const _0x3dd6fe=_0x11a9df['length']?_0x11a9df['join'](','):'FirebaseCore-web';return _0x56d4b2+'/JsCore/'+lt+'/'+_0x3dd6fe;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x5f37fb){this['auth']=_0x5f37fb,this['queue']=[];}['pushCallback'](_0x53eed8,_0x5b7c5b){const _0x32a5e3=_0x40d2a2=>new Promise((_0x1c64ab,_0x55ba8c)=>{try{const _0x439a3a=_0x53eed8(_0x40d2a2);_0x1c64ab(_0x439a3a);}catch(_0x23a6e1){_0x55ba8c(_0x23a6e1);}});_0x32a5e3['onAbort']=_0x5b7c5b,this['queue']['push'](_0x32a5e3);const _0xe3fe49=this['queue']['length']-0x1;return()=>{this['queue'][_0xe3fe49]=()=>Promise['resolve']();};}async['runMiddleware'](_0x30e911){if(this['auth']['currentUser']===_0x30e911)return;const _0x1486cf=[];try{for(const _0x2a049c of this['queue'])await _0x2a049c(_0x30e911),_0x2a049c['onAbort']&&_0x1486cf['push'](_0x2a049c['onAbort']);}catch(_0x4d073d){_0x1486cf['reverse']();for(const _0x460581 of _0x1486cf)try{_0x460581();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x4d073d==null?void 0x0:_0x4d073d['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x3ade92,_0x32cb55={}){return Ae(_0x3ade92,'GET','/v2/passwordPolicy',Re(_0x3ade92,_0x32cb55));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0xc2e681){var _0x94f9f5;const _0xdd3872=_0xc2e681['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0xdd3872['minPasswordLength']??Rf,_0xdd3872['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0xdd3872['maxPasswordLength']),_0xdd3872['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0xdd3872['containsLowercaseCharacter']),_0xdd3872['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0xdd3872['containsUppercaseCharacter']),_0xdd3872['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0xdd3872['containsNumericCharacter']),_0xdd3872['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0xdd3872['containsNonAlphanumericCharacter']),this['enforcementState']=_0xc2e681['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x94f9f5=_0xc2e681['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x94f9f5['join'](''))??'',this['forceUpgradeOnSignin']=_0xc2e681['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0xc2e681['schemaVersion'];}['validatePassword'](_0x100970){const _0x161fac={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x100970,_0x161fac),this['validatePasswordCharacterOptions'](_0x100970,_0x161fac),_0x161fac['isValid']&&(_0x161fac['isValid']=_0x161fac['meetsMinPasswordLength']??!0x0),_0x161fac['isValid']&&(_0x161fac['isValid']=_0x161fac['meetsMaxPasswordLength']??!0x0),_0x161fac['isValid']&&(_0x161fac['isValid']=_0x161fac['containsLowercaseLetter']??!0x0),_0x161fac['isValid']&&(_0x161fac['isValid']=_0x161fac['containsUppercaseLetter']??!0x0),_0x161fac['isValid']&&(_0x161fac['isValid']=_0x161fac['containsNumericCharacter']??!0x0),_0x161fac['isValid']&&(_0x161fac['isValid']=_0x161fac['containsNonAlphanumericCharacter']??!0x0),_0x161fac;}['validatePasswordLengthOptions'](_0x3d7685,_0x523ee4){const _0xfc6cea=this['customStrengthOptions']['minPasswordLength'],_0x48bfe1=this['customStrengthOptions']['maxPasswordLength'];_0xfc6cea&&(_0x523ee4['meetsMinPasswordLength']=_0x3d7685['length']>=_0xfc6cea),_0x48bfe1&&(_0x523ee4['meetsMaxPasswordLength']=_0x3d7685['length']<=_0x48bfe1);}['validatePasswordCharacterOptions'](_0x45e127,_0x3285bd){this['updatePasswordCharacterOptionsStatuses'](_0x3285bd,!0x1,!0x1,!0x1,!0x1);let _0x283551;for(let _0x58013d=0x0;_0x58013d<_0x45e127['length'];_0x58013d++)_0x283551=_0x45e127['charAt'](_0x58013d),this['updatePasswordCharacterOptionsStatuses'](_0x3285bd,_0x283551>='a'&&_0x283551<='z',_0x283551>='A'&&_0x283551<='Z',_0x283551>='0'&&_0x283551<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x283551));}['updatePasswordCharacterOptionsStatuses'](_0x1d19ae,_0x9e5785,_0x14273c,_0x13d6a6,_0x5e6140){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x1d19ae['containsLowercaseLetter']||(_0x1d19ae['containsLowercaseLetter']=_0x9e5785)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x1d19ae['containsUppercaseLetter']||(_0x1d19ae['containsUppercaseLetter']=_0x14273c)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x1d19ae['containsNumericCharacter']||(_0x1d19ae['containsNumericCharacter']=_0x13d6a6)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x1d19ae['containsNonAlphanumericCharacter']||(_0x1d19ae['containsNonAlphanumericCharacter']=_0x5e6140));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x4ed275,_0xcdda1c,_0x22d75b,_0x31a46e){this['app']=_0x4ed275,this['heartbeatServiceProvider']=_0xcdda1c,this['appCheckServiceProvider']=_0x22d75b,this['config']=_0x31a46e,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x4ed275['name'],this['clientVersion']=_0x31a46e['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x4fd7be=>this['_resolvePersistenceManagerAvailable']=_0x4fd7be);}['_initializeWithPersistence'](_0x4c7d48,_0x36a882){return _0x36a882&&(this['_popupRedirectResolver']=ie(_0x36a882)),this['_initializationPromise']=this['queue'](async()=>{var _0x440fd5,_0x57bdeb,_0x43f963;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x4c7d48),(_0x440fd5=this['_resolvePersistenceManagerAvailable'])==null||_0x440fd5['call'](this),!this['_deleted'])){if((_0x57bdeb=this['_popupRedirectResolver'])!=null&&_0x57bdeb['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x36a882),this['lastNotifiedUid']=((_0x43f963=this['currentUser'])==null?void 0x0:_0x43f963['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x253d21=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x253d21)){if(this['currentUser']&&_0x253d21&&this['currentUser']['uid']===_0x253d21['uid']){this['_currentUser']['_assign'](_0x253d21),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x253d21,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x3ca9c9){try{const _0x4428a1=await bn(this,{'idToken':_0x3ca9c9}),_0x15589c=await K['_fromGetAccountInfoResponse'](this,_0x4428a1,_0x3ca9c9);await this['directlySetCurrentUser'](_0x15589c);}catch(_0x1676bc){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x1676bc),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0xd343b6){var _0x36b928;if($(this['app'])){const _0x6d25bf=this['app']['settings']['authIdToken'];return _0x6d25bf?new Promise(_0x51b828=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x6d25bf)['then'](_0x51b828,_0x51b828));}):this['directlySetCurrentUser'](null);}const _0x87bfbe=await this['assertedPersistence']['getCurrentUser']();let _0x175f49=_0x87bfbe,_0x1c3aea=!0x1;if(_0xd343b6&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x138fc9=(_0x36b928=this['redirectUser'])==null?void 0x0:_0x36b928['_redirectEventId'],_0x43ddb3=_0x175f49==null?void 0x0:_0x175f49['_redirectEventId'],_0x1cc155=await this['tryRedirectSignIn'](_0xd343b6);(!_0x138fc9||_0x138fc9===_0x43ddb3)&&(_0x1cc155!=null&&_0x1cc155['user'])&&(_0x175f49=_0x1cc155['user'],_0x1c3aea=!0x0);}if(!_0x175f49)return this['directlySetCurrentUser'](null);if(!_0x175f49['_redirectEventId']){if(_0x1c3aea)try{await this['beforeStateQueue']['runMiddleware'](_0x175f49);}catch(_0x3b4a4f){_0x175f49=_0x87bfbe,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x3b4a4f));}return _0x175f49?this['reloadAndSetCurrentUserOrClear'](_0x175f49):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x175f49['_redirectEventId']?this['directlySetCurrentUser'](_0x175f49):this['reloadAndSetCurrentUserOrClear'](_0x175f49);}async['tryRedirectSignIn'](_0x4597a5){let _0x4aaa69=null;try{_0x4aaa69=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x4597a5,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x4aaa69;}async['reloadAndSetCurrentUserOrClear'](_0x3237c8){try{await Rn(_0x3237c8);}catch(_0x49d0f0){if((_0x49d0f0==null?void 0x0:_0x49d0f0['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x3237c8);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x5202ba){if($(this['app']))return Promise['reject'](re(this));const _0x2d4145=_0x5202ba?N(_0x5202ba):null;return _0x2d4145&&m(_0x2d4145['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x2d4145&&_0x2d4145['_clone'](this));}async['_updateCurrentUser'](_0x34a962,_0x455b4a=!0x1){if(!this['_deleted'])return _0x34a962&&m(this['tenantId']===_0x34a962['tenantId'],this,'tenant-id-mismatch'),_0x455b4a||await this['beforeStateQueue']['runMiddleware'](_0x34a962),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x34a962),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x4d79a8){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x4d79a8));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x3b26a4){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x2a9da6=this['_getPasswordPolicyInternal']();return _0x2a9da6['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x2a9da6['validatePassword'](_0x3b26a4);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x2ec23a=await bf(this),_0x4a2c71=new Af(_0x2ec23a);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4a2c71:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4a2c71;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x4556d2){this['_errorFactory']=new Bt('auth','Firebase',_0x4556d2());}['onAuthStateChanged'](_0x2795fe,_0x2aefcb,_0x27e30a){return this['registerStateListener'](this['authStateSubscription'],_0x2795fe,_0x2aefcb,_0x27e30a);}['beforeAuthStateChanged'](_0x395cb8,_0x5f2728){return this['beforeStateQueue']['pushCallback'](_0x395cb8,_0x5f2728);}['onIdTokenChanged'](_0x1e47d9,_0x1fc4df,_0x2bda5b){return this['registerStateListener'](this['idTokenSubscription'],_0x1e47d9,_0x1fc4df,_0x2bda5b);}['authStateReady'](){return new Promise((_0x4b3135,_0x3b9677)=>{if(this['currentUser'])_0x4b3135();else{const _0x5b80b6=this['onAuthStateChanged'](()=>{_0x5b80b6(),_0x4b3135();},_0x3b9677);}});}async['revokeAccessToken'](_0x2abed6){if(this['currentUser']){const _0x31b5d5=await this['currentUser']['getIdToken'](),_0x2ed825={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x2abed6,'idToken':_0x31b5d5};this['tenantId']!=null&&(_0x2ed825['tenantId']=this['tenantId']),await wf(this,_0x2ed825);}}['toJSON'](){var _0x48e18f;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x48e18f=this['_currentUser'])==null?void 0x0:_0x48e18f['toJSON']()};}async['_setRedirectUser'](_0x4b6c0e,_0x3eeacb){const _0x1d9ec5=await this['getOrInitRedirectPersistenceManager'](_0x3eeacb);return _0x4b6c0e===null?_0x1d9ec5['removeCurrentUser']():_0x1d9ec5['setCurrentUser'](_0x4b6c0e);}async['getOrInitRedirectPersistenceManager'](_0x3db79e){if(!this['redirectPersistenceManager']){const _0x2ecc97=_0x3db79e&&ie(_0x3db79e)||this['_popupRedirectResolver'];m(_0x2ecc97,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x2ecc97['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x3fc900){var _0x14d93a,_0x52751b;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x14d93a=this['_currentUser'])==null?void 0x0:_0x14d93a['_redirectEventId'])===_0x3fc900?this['_currentUser']:((_0x52751b=this['redirectUser'])==null?void 0x0:_0x52751b['_redirectEventId'])===_0x3fc900?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x137996){if(_0x137996===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x137996));}['_notifyListenersIfCurrent'](_0x594ddc){_0x594ddc===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x78d4fe;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x22e1e7=((_0x78d4fe=this['currentUser'])==null?void 0x0:_0x78d4fe['uid'])??null;this['lastNotifiedUid']!==_0x22e1e7&&(this['lastNotifiedUid']=_0x22e1e7,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x347194,_0x2a6e3b,_0xa83319,_0x1522e2){if(this['_deleted'])return()=>{};const _0x4fe2d0=typeof _0x2a6e3b=='function'?_0x2a6e3b:_0x2a6e3b['next']['bind'](_0x2a6e3b);let _0x413d75=!0x1;const _0x5beb73=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x5beb73,this,'internal-error'),_0x5beb73['then'](()=>{_0x413d75||_0x4fe2d0(this['currentUser']);}),typeof _0x2a6e3b=='function'){const _0x10791c=_0x347194['addObserver'](_0x2a6e3b,_0xa83319,_0x1522e2);return()=>{_0x413d75=!0x0,_0x10791c();};}else{const _0x4966cf=_0x347194['addObserver'](_0x2a6e3b);return()=>{_0x413d75=!0x0,_0x4966cf();};}}async['directlySetCurrentUser'](_0x4c8f06){this['currentUser']&&this['currentUser']!==_0x4c8f06&&this['_currentUser']['_stopProactiveRefresh'](),_0x4c8f06&&this['isProactiveRefreshEnabled']&&_0x4c8f06['_startProactiveRefresh'](),this['currentUser']=_0x4c8f06,_0x4c8f06?await this['assertedPersistence']['setCurrentUser'](_0x4c8f06):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x42a2aa){return this['operations']=this['operations']['then'](_0x42a2aa,_0x42a2aa),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x1e133e){!_0x1e133e||this['frameworks']['includes'](_0x1e133e)||(this['frameworks']['push'](_0x1e133e),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x2b32d0;const _0x3a54c0={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x3a54c0['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x4d8f75=await((_0x2b32d0=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x2b32d0['getHeartbeatsHeader']());_0x4d8f75&&(_0x3a54c0['X-Firebase-Client']=_0x4d8f75);const _0x461dd5=await this['_getAppCheckToken']();return _0x461dd5&&(_0x3a54c0['X-Firebase-AppCheck']=_0x461dd5),_0x3a54c0;}async['_getAppCheckToken'](){var _0x5a4786;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x325f0d=await((_0x5a4786=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5a4786['getToken']());return _0x325f0d!=null&&_0x325f0d['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x325f0d['error']),_0x325f0d==null?void 0x0:_0x325f0d['token'];}}function qe(_0x13dc25){return N(_0x13dc25);}class Rr{constructor(_0x138bad){this['auth']=_0x138bad,this['observer']=null,this['addObserver']=Tc(_0x2d8512=>this['observer']=_0x2d8512);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x9614dc){jn=_0x9614dc;}function xa(_0x8c908b){return jn['loadJS'](_0x8c908b);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x565cf8){return'__'+_0x565cf8+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x34f968){_0x34f968();}['execute'](_0x913073,_0x346f0c){return Promise['resolve']('token');}['render'](_0x32677a,_0x241608){return'';}}class Lf{['ready'](_0x175241){_0x175241();}['execute'](_0x45b59f,_0x14cd1e){return Promise['resolve']('token');}['render'](_0x317a95,_0x318cb2){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x40668b){this['type']=xf,this['auth']=qe(_0x40668b);}async['verify'](_0x4fba9b='verify',_0x34efef=!0x1){async function _0x551dd6(_0x1378ac){if(!_0x34efef){if(_0x1378ac['tenantId']==null&&_0x1378ac['_agentRecaptchaConfig']!=null)return _0x1378ac['_agentRecaptchaConfig']['siteKey'];if(_0x1378ac['tenantId']!=null&&_0x1378ac['_tenantRecaptchaConfigs'][_0x1378ac['tenantId']]!==void 0x0)return _0x1378ac['_tenantRecaptchaConfigs'][_0x1378ac['tenantId']]['siteKey'];}return new Promise(async(_0x4b73a2,_0x5b4be4)=>{pf(_0x1378ac,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0xd99c7b=>{if(_0xd99c7b['recaptchaKey']===void 0x0)_0x5b4be4(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x14048e=new ff(_0xd99c7b);return _0x1378ac['tenantId']==null?_0x1378ac['_agentRecaptchaConfig']=_0x14048e:_0x1378ac['_tenantRecaptchaConfigs'][_0x1378ac['tenantId']]=_0x14048e,_0x4b73a2(_0x14048e['siteKey']);}})['catch'](_0xd427c3=>{_0x5b4be4(_0xd427c3);});});}function _0xeb7449(_0x2c5f35,_0x20a58d,_0x1af75a){const _0x246055=window['grecaptcha'];wr(_0x246055)?_0x246055['enterprise']['ready'](()=>{_0x246055['enterprise']['execute'](_0x2c5f35,{'action':_0x4fba9b})['then'](_0x742b49=>{_0x20a58d(_0x742b49);})['catch'](()=>{_0x20a58d(Fa);});}):_0x1af75a(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x541fa2,_0x3de44f)=>{_0x551dd6(this['auth'])['then'](_0xc5fc70=>{if(!_0x34efef&&wr(window['grecaptcha']))_0xeb7449(_0xc5fc70,_0x541fa2,_0x3de44f);else{if(typeof window>'u'){_0x3de44f(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x473181=Pf();_0x473181['length']!==0x0&&(_0x473181+=_0xc5fc70),xa(_0x473181)['then'](()=>{_0xeb7449(_0xc5fc70,_0x541fa2,_0x3de44f);})['catch'](_0x1ec96a=>{_0x3de44f(_0x1ec96a);});}})['catch'](_0x2f3976=>{_0x3de44f(_0x2f3976);});});}}async function Ar(_0x3be2f0,_0x483bca,_0x174917,_0x2cd53f=!0x1,_0x5ca40d=!0x1){const _0x11e538=new Ff(_0x3be2f0);let _0x2c4b9d;if(_0x5ca40d)_0x2c4b9d=Fa;else try{_0x2c4b9d=await _0x11e538['verify'](_0x174917);}catch{_0x2c4b9d=await _0x11e538['verify'](_0x174917,!0x0);}const _0xceca8b={..._0x483bca};if(_0x174917==='mfaSmsEnrollment'||_0x174917==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0xceca8b){const _0x5772c8=_0xceca8b['phoneEnrollmentInfo']['phoneNumber'],_0x3eae56=_0xceca8b['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0xceca8b,{'phoneEnrollmentInfo':{'phoneNumber':_0x5772c8,'recaptchaToken':_0x3eae56,'captchaResponse':_0x2c4b9d,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0xceca8b){const _0x3dfb62=_0xceca8b['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0xceca8b,{'phoneSignInInfo':{'recaptchaToken':_0x3dfb62,'captchaResponse':_0x2c4b9d,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0xceca8b;}return _0x2cd53f?Object['assign'](_0xceca8b,{'captchaResp':_0x2c4b9d}):Object['assign'](_0xceca8b,{'captchaResponse':_0x2c4b9d}),Object['assign'](_0xceca8b,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0xceca8b,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0xceca8b;}async function Di(_0xede496,_0x4d4048,_0x24851f,_0x40f6ed,_0x27b4b6){var _0x22ad70;if((_0x22ad70=_0xede496['_getRecaptchaConfig']())!=null&&_0x22ad70['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x275eb4=await Ar(_0xede496,_0x4d4048,_0x24851f,_0x24851f==='getOobCode');return _0x40f6ed(_0xede496,_0x275eb4);}else return _0x40f6ed(_0xede496,_0x4d4048)['catch'](async _0x12c046=>{if(_0x12c046['code']==='auth/missing-recaptcha-token'){console['log'](_0x24851f+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0xa06dc8=await Ar(_0xede496,_0x4d4048,_0x24851f,_0x24851f==='getOobCode');return _0x40f6ed(_0xede496,_0xa06dc8);}else return Promise['reject'](_0x12c046);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x29ed2d,_0x107e42){const _0x2f731e=Bi(_0x29ed2d,'auth');if(_0x2f731e['isInitialized']()){const _0x4d5c58=_0x2f731e['getImmediate'](),_0xb902cc=_0x2f731e['getOptions']();if(Me(_0xb902cc,_0x107e42??{}))return _0x4d5c58;Q(_0x4d5c58,'already-initialized');}return _0x2f731e['initialize']({'options':_0x107e42});}function Wf(_0x55d8e1,_0x1373b9){const _0x44d677=(_0x1373b9==null?void 0x0:_0x1373b9['persistence'])||[],_0x719e08=(Array['isArray'](_0x44d677)?_0x44d677:[_0x44d677])['map'](ie);_0x1373b9!=null&&_0x1373b9['errorMap']&&_0x55d8e1['_updateErrorMap'](_0x1373b9['errorMap']),_0x55d8e1['_initializeWithPersistence'](_0x719e08,_0x1373b9==null?void 0x0:_0x1373b9['popupRedirectResolver']);}function Bf(_0x4f642e,_0x3104ae,_0x551cf2){const _0x2bb39f=qe(_0x4f642e);m(/^https?:\/\//['test'](_0x3104ae),_0x2bb39f,'invalid-emulator-scheme');const _0x44fc13=!0x1,_0x39c8ca=Ua(_0x3104ae),{host:_0x3feda6,port:_0x2de6ae}=Vf(_0x3104ae),_0x6a46ba=_0x2de6ae===null?'':':'+_0x2de6ae,_0xf8df05={'url':_0x39c8ca+'//'+_0x3feda6+_0x6a46ba+'/'},_0x29c607=Object['freeze']({'host':_0x3feda6,'port':_0x2de6ae,'protocol':_0x39c8ca['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x44fc13})});if(!_0x2bb39f['_canInitEmulator']){m(_0x2bb39f['config']['emulator']&&_0x2bb39f['emulatorConfig'],_0x2bb39f,'emulator-config-failed'),m(Me(_0xf8df05,_0x2bb39f['config']['emulator'])&&Me(_0x29c607,_0x2bb39f['emulatorConfig']),_0x2bb39f,'emulator-config-failed');return;}_0x2bb39f['config']['emulator']=_0xf8df05,_0x2bb39f['emulatorConfig']=_0x29c607,_0x2bb39f['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x3feda6)?(jr(_0x39c8ca+'//'+_0x3feda6+_0x6a46ba),Kr('Auth',!0x0)):Hf();}function Ua(_0x3347e8){const _0x2de51e=_0x3347e8['indexOf'](':');return _0x2de51e<0x0?'':_0x3347e8['substr'](0x0,_0x2de51e+0x1);}function Vf(_0xf4f35c){const _0x2a2634=Ua(_0xf4f35c),_0x372fab=/(\/\/)?([^?#/]+)/['exec'](_0xf4f35c['substr'](_0x2a2634['length']));if(!_0x372fab)return{'host':'','port':null};const _0x119a39=_0x372fab[0x2]['split']('@')['pop']()||'',_0x3b6613=/^(\[[^\]]+\])(:|$)/['exec'](_0x119a39);if(_0x3b6613){const _0x8702ce=_0x3b6613[0x1];return{'host':_0x8702ce,'port':kr(_0x119a39['substr'](_0x8702ce['length']+0x1))};}else{const [_0x219d5f,_0x1b4abf]=_0x119a39['split'](':');return{'host':_0x219d5f,'port':kr(_0x1b4abf)};}}function kr(_0xfcbc58){if(!_0xfcbc58)return null;const _0x27c9a4=Number(_0xfcbc58);return isNaN(_0x27c9a4)?null:_0x27c9a4;}function Hf(){function _0x1b6b5f(){const _0x295783=document['createElement']('p'),_0xc85cac=_0x295783['style'];_0x295783['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0xc85cac['position']='fixed',_0xc85cac['width']='100%',_0xc85cac['backgroundColor']='#ffffff',_0xc85cac['border']='.1em\x20solid\x20#000000',_0xc85cac['color']='#b50000',_0xc85cac['bottom']='0px',_0xc85cac['left']='0px',_0xc85cac['margin']='0px',_0xc85cac['zIndex']='10000',_0xc85cac['textAlign']='center',_0x295783['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x295783);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1b6b5f):_0x1b6b5f());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x4cb0c8,_0x4da430){this['providerId']=_0x4cb0c8,this['signInMethod']=_0x4da430;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x5ad6c7){return ne('not\x20implemented');}['_linkToIdToken'](_0x35eca9,_0x15a767){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x1da977){return ne('not\x20implemented');}}async function $f(_0x85d06,_0x14ed1b){return Ae(_0x85d06,'POST','/v1/accounts:signUp',_0x14ed1b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x396cd8,_0x432400){return Qt(_0x396cd8,'POST','/v1/accounts:signInWithPassword',Re(_0x396cd8,_0x432400));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x30d436,_0x9ea8a){return Qt(_0x30d436,'POST','/v1/accounts:signInWithEmailLink',Re(_0x30d436,_0x9ea8a));}async function zf(_0x23d18b,_0x5de75b){return Qt(_0x23d18b,'POST','/v1/accounts:signInWithEmailLink',Re(_0x23d18b,_0x5de75b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0xe99726,_0x37e1cc,_0x5cff04,_0x491e37=null){super('password',_0x5cff04),this['_email']=_0xe99726,this['_password']=_0x37e1cc,this['_tenantId']=_0x491e37;}static['_fromEmailAndPassword'](_0x3093b5,_0xb93ef1){return new Wt(_0x3093b5,_0xb93ef1,'password');}static['_fromEmailAndCode'](_0x33d978,_0x2bff8a,_0x52b5c0=null){return new Wt(_0x33d978,_0x2bff8a,'emailLink',_0x52b5c0);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x284b33){const _0x32ea59=typeof _0x284b33=='string'?JSON['parse'](_0x284b33):_0x284b33;if(_0x32ea59!=null&&_0x32ea59['email']&&(_0x32ea59!=null&&_0x32ea59['password'])){if(_0x32ea59['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x32ea59['email'],_0x32ea59['password']);if(_0x32ea59['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x32ea59['email'],_0x32ea59['password'],_0x32ea59['tenantId']);}return null;}async['_getIdTokenResponse'](_0x42dc21){switch(this['signInMethod']){case'password':const _0x6abd51={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x42dc21,_0x6abd51,'signInWithPassword',Gf);case'emailLink':return qf(_0x42dc21,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x42dc21,'internal-error');}}async['_linkToIdToken'](_0x32c2c0,_0x4a8378){switch(this['signInMethod']){case'password':const _0x194d8f={'idToken':_0x4a8378,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x32c2c0,_0x194d8f,'signUpPassword',$f);case'emailLink':return zf(_0x32c2c0,{'idToken':_0x4a8378,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x32c2c0,'internal-error');}}['_getReauthenticationResolver'](_0x1ff940){return this['_getIdTokenResponse'](_0x1ff940);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x14953f,_0x436258){return Qt(_0x14953f,'POST','/v1/accounts:signInWithIdp',Re(_0x14953f,_0x436258));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x56b736){const _0x10db63=new Be(_0x56b736['providerId'],_0x56b736['signInMethod']);return _0x56b736['idToken']||_0x56b736['accessToken']?(_0x56b736['idToken']&&(_0x10db63['idToken']=_0x56b736['idToken']),_0x56b736['accessToken']&&(_0x10db63['accessToken']=_0x56b736['accessToken']),_0x56b736['nonce']&&!_0x56b736['pendingToken']&&(_0x10db63['nonce']=_0x56b736['nonce']),_0x56b736['pendingToken']&&(_0x10db63['pendingToken']=_0x56b736['pendingToken'])):_0x56b736['oauthToken']&&_0x56b736['oauthTokenSecret']?(_0x10db63['accessToken']=_0x56b736['oauthToken'],_0x10db63['secret']=_0x56b736['oauthTokenSecret']):Q('argument-error'),_0x10db63;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x51cd83){const _0x4584bc=typeof _0x51cd83=='string'?JSON['parse'](_0x51cd83):_0x51cd83,{providerId:_0x1acc3c,signInMethod:_0x1d2c81,..._0x10db60}=_0x4584bc;if(!_0x1acc3c||!_0x1d2c81)return null;const _0x375018=new Be(_0x1acc3c,_0x1d2c81);return _0x375018['idToken']=_0x10db60['idToken']||void 0x0,_0x375018['accessToken']=_0x10db60['accessToken']||void 0x0,_0x375018['secret']=_0x10db60['secret'],_0x375018['nonce']=_0x10db60['nonce'],_0x375018['pendingToken']=_0x10db60['pendingToken']||null,_0x375018;}['_getIdTokenResponse'](_0x2637a9){const _0x4b6171=this['buildRequest']();return Xe(_0x2637a9,_0x4b6171);}['_linkToIdToken'](_0x4b5557,_0x19ac24){const _0x2f4b80=this['buildRequest']();return _0x2f4b80['idToken']=_0x19ac24,Xe(_0x4b5557,_0x2f4b80);}['_getReauthenticationResolver'](_0x1f549f){const _0x5b2d06=this['buildRequest']();return _0x5b2d06['autoCreate']=!0x1,Xe(_0x1f549f,_0x5b2d06);}['buildRequest'](){const _0x3182a4={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x3182a4['pendingToken']=this['pendingToken'];else{const _0x45d961={};this['idToken']&&(_0x45d961['id_token']=this['idToken']),this['accessToken']&&(_0x45d961['access_token']=this['accessToken']),this['secret']&&(_0x45d961['oauth_token_secret']=this['secret']),_0x45d961['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x45d961['nonce']=this['nonce']),_0x3182a4['postBody']=ct(_0x45d961);}return _0x3182a4;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x4dd3fa){switch(_0x4dd3fa){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x5d48ec){const _0x5e0d55=vt(Et(_0x5d48ec))['link'],_0x1d4ae6=_0x5e0d55?vt(Et(_0x5e0d55))['deep_link_id']:null,_0x1eca48=vt(Et(_0x5d48ec))['deep_link_id'];return(_0x1eca48?vt(Et(_0x1eca48))['link']:null)||_0x1eca48||_0x1d4ae6||_0x5e0d55||_0x5d48ec;}class Rs{constructor(_0x128c68){const _0x1bb9fd=vt(Et(_0x128c68)),_0x2c6962=_0x1bb9fd['apiKey']??null,_0x2c17e2=_0x1bb9fd['oobCode']??null,_0x1262ab=Kf(_0x1bb9fd['mode']??null);m(_0x2c6962&&_0x2c17e2&&_0x1262ab,'argument-error'),this['apiKey']=_0x2c6962,this['operation']=_0x1262ab,this['code']=_0x2c17e2,this['continueUrl']=_0x1bb9fd['continueUrl']??null,this['languageCode']=_0x1bb9fd['lang']??null,this['tenantId']=_0x1bb9fd['tenantId']??null;}static['parseLink'](_0x4836ec){const _0x271c30=Yf(_0x4836ec);try{return new Rs(_0x271c30);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x36628,_0x4ff88d){return Wt['_fromEmailAndPassword'](_0x36628,_0x4ff88d);}static['credentialWithLink'](_0x45a5ce,_0x3f4e65){const _0x4226fd=Rs['parseLink'](_0x3f4e65);return m(_0x4226fd,'argument-error'),Wt['_fromEmailAndCode'](_0x45a5ce,_0x4226fd['code'],_0x4226fd['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x566cd1){this['providerId']=_0x566cd1,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x39bbfa){this['defaultLanguageCode']=_0x39bbfa;}['setCustomParameters'](_0x344831){return this['customParameters']=_0x344831,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5792e0){return this['scopes']['includes'](_0x5792e0)||this['scopes']['push'](_0x5792e0),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x758aff){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x758aff});}static['credentialFromResult'](_0x41067c){return he['credentialFromTaggedObject'](_0x41067c);}static['credentialFromError'](_0x51907a){return he['credentialFromTaggedObject'](_0x51907a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x53e465}){if(!_0x53e465||!('oauthAccessToken'in _0x53e465)||!_0x53e465['oauthAccessToken'])return null;try{return he['credential'](_0x53e465['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x5e9700,_0x5bd4a4){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x5e9700,'accessToken':_0x5bd4a4});}static['credentialFromResult'](_0x4a8755){return ue['credentialFromTaggedObject'](_0x4a8755);}static['credentialFromError'](_0x2cc28d){return ue['credentialFromTaggedObject'](_0x2cc28d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x260b27}){if(!_0x260b27)return null;const {oauthIdToken:_0x110f97,oauthAccessToken:_0x39c7d0}=_0x260b27;if(!_0x110f97&&!_0x39c7d0)return null;try{return ue['credential'](_0x110f97,_0x39c7d0);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x5e91b0){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x5e91b0});}static['credentialFromResult'](_0x163012){return de['credentialFromTaggedObject'](_0x163012);}static['credentialFromError'](_0x31428f){return de['credentialFromTaggedObject'](_0x31428f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xeb5614}){if(!_0xeb5614||!('oauthAccessToken'in _0xeb5614)||!_0xeb5614['oauthAccessToken'])return null;try{return de['credential'](_0xeb5614['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x32a426,_0x13f832){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x32a426,'oauthTokenSecret':_0x13f832});}static['credentialFromResult'](_0x2b921b){return fe['credentialFromTaggedObject'](_0x2b921b);}static['credentialFromError'](_0x1bcb79){return fe['credentialFromTaggedObject'](_0x1bcb79['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x271c98}){if(!_0x271c98)return null;const {oauthAccessToken:_0x55de58,oauthTokenSecret:_0x8750e1}=_0x271c98;if(!_0x55de58||!_0x8750e1)return null;try{return fe['credential'](_0x55de58,_0x8750e1);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x5ef16b,_0x5d5ba2){return Qt(_0x5ef16b,'POST','/v1/accounts:signUp',Re(_0x5ef16b,_0x5d5ba2));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x379b9c){this['user']=_0x379b9c['user'],this['providerId']=_0x379b9c['providerId'],this['_tokenResponse']=_0x379b9c['_tokenResponse'],this['operationType']=_0x379b9c['operationType'];}static async['_fromIdTokenResponse'](_0x1091c7,_0x880d36,_0x4f7f5d,_0x4ada99=!0x1){const _0x434b0b=await K['_fromIdTokenResponse'](_0x1091c7,_0x4f7f5d,_0x4ada99),_0x3b9c00=Nr(_0x4f7f5d);return new Ve({'user':_0x434b0b,'providerId':_0x3b9c00,'_tokenResponse':_0x4f7f5d,'operationType':_0x880d36});}static async['_forOperation'](_0x54773c,_0x3e94cc,_0x18271c){await _0x54773c['_updateTokensIfNecessary'](_0x18271c,!0x0);const _0x2016b2=Nr(_0x18271c);return new Ve({'user':_0x54773c,'providerId':_0x2016b2,'_tokenResponse':_0x18271c,'operationType':_0x3e94cc});}}function Nr(_0x1c8f13){return _0x1c8f13['providerId']?_0x1c8f13['providerId']:'phoneNumber'in _0x1c8f13?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x19b2f8,_0x3a05ae,_0x4d6093,_0x2e0804){super(_0x3a05ae['code'],_0x3a05ae['message']),this['operationType']=_0x4d6093,this['user']=_0x2e0804,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x19b2f8['name'],'tenantId':_0x19b2f8['tenantId']??void 0x0,'_serverResponse':_0x3a05ae['customData']['_serverResponse'],'operationType':_0x4d6093};}static['_fromErrorAndOperation'](_0x1d2ba7,_0x1b42c0,_0xe0eb7e,_0x584866){return new An(_0x1d2ba7,_0x1b42c0,_0xe0eb7e,_0x584866);}}function Ba(_0x2a6fd4,_0x9a83ed,_0x323b9f,_0x2ab7a2){return(_0x9a83ed==='reauthenticate'?_0x323b9f['_getReauthenticationResolver'](_0x2a6fd4):_0x323b9f['_getIdTokenResponse'](_0x2a6fd4))['catch'](_0x1c106a=>{throw _0x1c106a['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x2a6fd4,_0x1c106a,_0x9a83ed,_0x2ab7a2):_0x1c106a;});}async function Jf(_0x2eac57,_0x4ae009,_0x39f21e=!0x1){const _0x356ba3=await Ut(_0x2eac57,_0x4ae009['_linkToIdToken'](_0x2eac57['auth'],await _0x2eac57['getIdToken']()),_0x39f21e);return Ve['_forOperation'](_0x2eac57,'link',_0x356ba3);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x167ed1,_0x577bd7,_0x137a89=!0x1){const {auth:_0x278f9b}=_0x167ed1;if($(_0x278f9b['app']))return Promise['reject'](re(_0x278f9b));const _0x3a640f='reauthenticate';try{const _0x52f3b9=await Ut(_0x167ed1,Ba(_0x278f9b,_0x3a640f,_0x577bd7,_0x167ed1),_0x137a89);m(_0x52f3b9['idToken'],_0x278f9b,'internal-error');const _0x342986=Ts(_0x52f3b9['idToken']);m(_0x342986,_0x278f9b,'internal-error');const {sub:_0x27671a}=_0x342986;return m(_0x167ed1['uid']===_0x27671a,_0x278f9b,'user-mismatch'),Ve['_forOperation'](_0x167ed1,_0x3a640f,_0x52f3b9);}catch(_0x3e69ef){throw(_0x3e69ef==null?void 0x0:_0x3e69ef['code'])==='auth/user-not-found'&&Q(_0x278f9b,'user-mismatch'),_0x3e69ef;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x4fbe26,_0x770fbc,_0x17d165=!0x1){if($(_0x4fbe26['app']))return Promise['reject'](re(_0x4fbe26));const _0x208acd='signIn',_0x371252=await Ba(_0x4fbe26,_0x208acd,_0x770fbc),_0x382e19=await Ve['_fromIdTokenResponse'](_0x4fbe26,_0x208acd,_0x371252);return _0x17d165||await _0x4fbe26['_updateCurrentUser'](_0x382e19['user']),_0x382e19;}async function Zf(_0x18033d,_0x4c7aa3){return Va(qe(_0x18033d),_0x4c7aa3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x309966){const _0x837467=qe(_0x309966);_0x837467['_getPasswordPolicyInternal']()&&await _0x837467['_updatePasswordPolicy']();}async function P_(_0x1c2237,_0x4a37fb,_0x314c03){if($(_0x1c2237['app']))return Promise['reject'](re(_0x1c2237));const _0x1b431d=qe(_0x1c2237),_0x380f3e=await Di(_0x1b431d,{'returnSecureToken':!0x0,'email':_0x4a37fb,'password':_0x314c03,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x3a9df9=>{throw _0x3a9df9['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x1c2237),_0x3a9df9;}),_0x4e9af8=await Ve['_fromIdTokenResponse'](_0x1b431d,'signIn',_0x380f3e);return await _0x1b431d['_updateCurrentUser'](_0x4e9af8['user']),_0x4e9af8;}function O_(_0x12aa8f,_0x223950,_0x4c70fc){return $(_0x12aa8f['app'])?Promise['reject'](re(_0x12aa8f)):Zf(N(_0x12aa8f),pt['credential'](_0x223950,_0x4c70fc))['catch'](async _0x27211e=>{throw _0x27211e['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x12aa8f),_0x27211e;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x5bb15d,_0x31ea56){return N(_0x5bb15d)['setPersistence'](_0x31ea56);}function ep(_0x5da044,_0x396cca,_0x597859,_0x798f10){return N(_0x5da044)['onIdTokenChanged'](_0x396cca,_0x597859,_0x798f10);}function tp(_0x43db59,_0x52dda7,_0x499317){return N(_0x43db59)['beforeAuthStateChanged'](_0x52dda7,_0x499317);}function M_(_0x2dea9c,_0x2ddf9c,_0x3f7f0f,_0x22982f){return N(_0x2dea9c)['onAuthStateChanged'](_0x2ddf9c,_0x3f7f0f,_0x22982f);}function L_(_0x295365){return N(_0x295365)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x5c653a,_0x420ce4){this['storageRetriever']=_0x5c653a,this['type']=_0x420ce4;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x39dbdc,_0x8555a7){return this['storage']['setItem'](_0x39dbdc,JSON['stringify'](_0x8555a7)),Promise['resolve']();}['_get'](_0x3d5be7){const _0x54021d=this['storage']['getItem'](_0x3d5be7);return Promise['resolve'](_0x54021d?JSON['parse'](_0x54021d):null);}['_remove'](_0xd37fcf){return this['storage']['removeItem'](_0xd37fcf),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x4ce559,_0x5238b6)=>this['onStorageEvent'](_0x4ce559,_0x5238b6),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x3a4115){for(const _0x304a6b of Object['keys'](this['listeners'])){const _0x518dd2=this['storage']['getItem'](_0x304a6b),_0xa076db=this['localCache'][_0x304a6b];_0x518dd2!==_0xa076db&&_0x3a4115(_0x304a6b,_0xa076db,_0x518dd2);}}['onStorageEvent'](_0x583855,_0x18f6a=!0x1){if(!_0x583855['key']){this['forAllChangedKeys']((_0x2d8f6f,_0x23eca6,_0x300b69)=>{this['notifyListeners'](_0x2d8f6f,_0x300b69);});return;}const _0x6d035=_0x583855['key'];_0x18f6a?this['detachListener']():this['stopPolling']();const _0x3d2179=()=>{const _0x5c0c5c=this['storage']['getItem'](_0x6d035);!_0x18f6a&&this['localCache'][_0x6d035]===_0x5c0c5c||this['notifyListeners'](_0x6d035,_0x5c0c5c);},_0x268684=this['storage']['getItem'](_0x6d035);Tf()&&_0x268684!==_0x583855['newValue']&&_0x583855['newValue']!==_0x583855['oldValue']?setTimeout(_0x3d2179,ip):_0x3d2179();}['notifyListeners'](_0x32606d,_0x9cba01){this['localCache'][_0x32606d]=_0x9cba01;const _0x4c5da6=this['listeners'][_0x32606d];if(_0x4c5da6){for(const _0x157f9a of Array['from'](_0x4c5da6))_0x157f9a(_0x9cba01&&JSON['parse'](_0x9cba01));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x429461,_0x5ef394,_0x567cbd)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x429461,'oldValue':_0x5ef394,'newValue':_0x567cbd}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x36b732,_0x4806e2){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x36b732]||(this['listeners'][_0x36b732]=new Set(),this['localCache'][_0x36b732]=this['storage']['getItem'](_0x36b732)),this['listeners'][_0x36b732]['add'](_0x4806e2);}['_removeListener'](_0x43a0b5,_0xd2bcc0){this['listeners'][_0x43a0b5]&&(this['listeners'][_0x43a0b5]['delete'](_0xd2bcc0),this['listeners'][_0x43a0b5]['size']===0x0&&delete this['listeners'][_0x43a0b5]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x3d5e63,_0x26db14){await super['_set'](_0x3d5e63,_0x26db14),this['localCache'][_0x3d5e63]=JSON['stringify'](_0x26db14);}async['_get'](_0x977ae2){const _0x10274b=await super['_get'](_0x977ae2);return this['localCache'][_0x977ae2]=JSON['stringify'](_0x10274b),_0x10274b;}async['_remove'](_0x2299bf){await super['_remove'](_0x2299bf),delete this['localCache'][_0x2299bf];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x13dd1f,_0x148ba7){}['_removeListener'](_0x18591e,_0x3b12c8){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x3e9701){return Promise['all'](_0x3e9701['map'](async _0x78d299=>{try{return{'fulfilled':!0x0,'value':await _0x78d299};}catch(_0x1de950){return{'fulfilled':!0x1,'reason':_0x1de950};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0xb8e09b){this['eventTarget']=_0xb8e09b,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x35911c){const _0x2f10f2=this['receivers']['find'](_0x2beab9=>_0x2beab9['isListeningto'](_0x35911c));if(_0x2f10f2)return _0x2f10f2;const _0x368acc=new Kn(_0x35911c);return this['receivers']['push'](_0x368acc),_0x368acc;}['isListeningto'](_0x2018a9){return this['eventTarget']===_0x2018a9;}async['handleEvent'](_0xbb04ff){const _0x8e5bc9=_0xbb04ff,{eventId:_0x5a2227,eventType:_0x271511,data:_0x190064}=_0x8e5bc9['data'],_0x255cee=this['handlersMap'][_0x271511];if(!(_0x255cee!=null&&_0x255cee['size']))return;_0x8e5bc9['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x5a2227,'eventType':_0x271511});const _0x50b8e6=Array['from'](_0x255cee)['map'](async _0x12e735=>_0x12e735(_0x8e5bc9['origin'],_0x190064)),_0x260a52=await rp(_0x50b8e6);_0x8e5bc9['ports'][0x0]['postMessage']({'status':'done','eventId':_0x5a2227,'eventType':_0x271511,'response':_0x260a52});}['_subscribe'](_0x1215cf,_0x162a80){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x1215cf]||(this['handlersMap'][_0x1215cf]=new Set()),this['handlersMap'][_0x1215cf]['add'](_0x162a80);}['_unsubscribe'](_0x511169,_0x2f641b){this['handlersMap'][_0x511169]&&_0x2f641b&&this['handlersMap'][_0x511169]['delete'](_0x2f641b),(!_0x2f641b||this['handlersMap'][_0x511169]['size']===0x0)&&delete this['handlersMap'][_0x511169],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x27babc='',_0x3001a4=0xa){let _0x6a5b72='';for(let _0x5c7c6b=0x0;_0x5c7c6b<_0x3001a4;_0x5c7c6b++)_0x6a5b72+=Math['floor'](Math['random']()*0xa);return _0x27babc+_0x6a5b72;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x298cd8){this['target']=_0x298cd8,this['handlers']=new Set();}['removeMessageHandler'](_0x305b82){_0x305b82['messageChannel']&&(_0x305b82['messageChannel']['port1']['removeEventListener']('message',_0x305b82['onMessage']),_0x305b82['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x305b82);}async['_send'](_0x1c7f5b,_0x472e86,_0x3a989e=0x32){const _0x4a2fff=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4a2fff)throw new Error('connection_unavailable');let _0x4b9a4e,_0x268c30;return new Promise((_0x485f95,_0x16d9b4)=>{const _0x13f84e=As('',0x14);_0x4a2fff['port1']['start']();const _0x22074e=setTimeout(()=>{_0x16d9b4(new Error('unsupported_event'));},_0x3a989e);_0x268c30={'messageChannel':_0x4a2fff,'onMessage'(_0x541b4f){const _0x19036b=_0x541b4f;if(_0x19036b['data']['eventId']===_0x13f84e)switch(_0x19036b['data']['status']){case'ack':clearTimeout(_0x22074e),_0x4b9a4e=setTimeout(()=>{_0x16d9b4(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x4b9a4e),_0x485f95(_0x19036b['data']['response']);break;default:clearTimeout(_0x22074e),clearTimeout(_0x4b9a4e),_0x16d9b4(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x268c30),_0x4a2fff['port1']['addEventListener']('message',_0x268c30['onMessage']),this['target']['postMessage']({'eventType':_0x1c7f5b,'eventId':_0x13f84e,'data':_0x472e86},[_0x4a2fff['port2']]);})['finally'](()=>{_0x268c30&&this['removeMessageHandler'](_0x268c30);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x1e8745){Z()['location']['href']=_0x1e8745;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x560e17;return((_0x560e17=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x560e17['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0xafb8e1){this['request']=_0xafb8e1;}['toPromise'](){return new Promise((_0x5a27ce,_0x126cdd)=>{this['request']['addEventListener']('success',()=>{_0x5a27ce(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x126cdd(this['request']['error']);});});}}function Yn(_0x27211,_0x3fbb0d){return _0x27211['transaction']([Nn],_0x3fbb0d?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x3a63ba=indexedDB['deleteDatabase'](Ka);return new Xt(_0x3a63ba)['toPromise']();}function Mi(){const _0x53a628=indexedDB['open'](Ka,up);return new Promise((_0x2450ad,_0x2f1ddf)=>{_0x53a628['addEventListener']('error',()=>{_0x2f1ddf(_0x53a628['error']);}),_0x53a628['addEventListener']('upgradeneeded',()=>{const _0x55223a=_0x53a628['result'];try{_0x55223a['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x484e53){_0x2f1ddf(_0x484e53);}}),_0x53a628['addEventListener']('success',async()=>{const _0xf608dc=_0x53a628['result'];_0xf608dc['objectStoreNames']['contains'](Nn)?_0x2450ad(_0xf608dc):(_0xf608dc['close'](),await dp(),_0x2450ad(await Mi()));});});}async function Pr(_0x3981e6,_0x1d44a8,_0x6e8d69){const _0x4ab90b=Yn(_0x3981e6,!0x0)['put']({[Ya]:_0x1d44a8,'value':_0x6e8d69});return new Xt(_0x4ab90b)['toPromise']();}async function fp(_0x2121b1,_0x330700){const _0x3efd09=Yn(_0x2121b1,!0x1)['get'](_0x330700),_0x205030=await new Xt(_0x3efd09)['toPromise']();return _0x205030===void 0x0?null:_0x205030['value'];}function Or(_0x3a9ae,_0x171f8c){const _0x37b3bc=Yn(_0x3a9ae,!0x0)['delete'](_0x171f8c);return new Xt(_0x37b3bc)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x59fc55){let _0x4708c3=0x0;for(;;)try{const _0x114043=await this['_openDb']();return await _0x59fc55(_0x114043);}catch(_0x58b5ee){if(_0x4708c3++>_p)throw _0x58b5ee;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x8e94f5,_0x167456)=>({'keyProcessed':(await this['_poll']())['includes'](_0x167456['key'])})),this['receiver']['_subscribe']('ping',async(_0x564697,_0x39dc00)=>['keyChanged']);}async['initializeSender'](){var _0x4608c4,_0x4c070c;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x42fb63=await this['sender']['_send']('ping',{},0x320);_0x42fb63&&(_0x4608c4=_0x42fb63[0x0])!=null&&_0x4608c4['fulfilled']&&(_0x4c070c=_0x42fb63[0x0])!=null&&_0x4c070c['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x4422ca){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x4422ca},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x1c3e7a=await Mi();return await Pr(_0x1c3e7a,kn,'1'),await Or(_0x1c3e7a,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x432573){this['pendingWrites']++;try{await _0x432573();}finally{this['pendingWrites']--;}}async['_set'](_0x289d47,_0x5d0144){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x36b0b3=>Pr(_0x36b0b3,_0x289d47,_0x5d0144)),this['localCache'][_0x289d47]=_0x5d0144,this['notifyServiceWorker'](_0x289d47)));}async['_get'](_0x14e82d){const _0x5eeaa6=await this['_withRetries'](_0x3ddcaa=>fp(_0x3ddcaa,_0x14e82d));return this['localCache'][_0x14e82d]=_0x5eeaa6,_0x5eeaa6;}async['_remove'](_0x3711b9){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xa3bdb1=>Or(_0xa3bdb1,_0x3711b9)),delete this['localCache'][_0x3711b9],this['notifyServiceWorker'](_0x3711b9)));}async['_poll'](){const _0x8a7c3e=await this['_withRetries'](_0x285391=>{const _0x30a642=Yn(_0x285391,!0x1)['getAll']();return new Xt(_0x30a642)['toPromise']();});if(!_0x8a7c3e)return[];if(this['pendingWrites']!==0x0)return[];const _0x4a66a3=[],_0x4f8d3f=new Set();if(_0x8a7c3e['length']!==0x0){for(const {fbase_key:_0xfaa740,value:_0x20f0a5}of _0x8a7c3e)_0x4f8d3f['add'](_0xfaa740),JSON['stringify'](this['localCache'][_0xfaa740])!==JSON['stringify'](_0x20f0a5)&&(this['notifyListeners'](_0xfaa740,_0x20f0a5),_0x4a66a3['push'](_0xfaa740));}for(const _0x27a6e3 of Object['keys'](this['localCache']))this['localCache'][_0x27a6e3]&&!_0x4f8d3f['has'](_0x27a6e3)&&(this['notifyListeners'](_0x27a6e3,null),_0x4a66a3['push'](_0x27a6e3));return _0x4a66a3;}['notifyListeners'](_0x9ea04,_0x38f28c){this['localCache'][_0x9ea04]=_0x38f28c;const _0x3480d4=this['listeners'][_0x9ea04];if(_0x3480d4){for(const _0x5b5742 of Array['from'](_0x3480d4))_0x5b5742(_0x38f28c);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x20e960,_0x2d2bb8){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x20e960]||(this['listeners'][_0x20e960]=new Set(),this['_get'](_0x20e960)),this['listeners'][_0x20e960]['add'](_0x2d2bb8);}['_removeListener'](_0x1533d6,_0x5b5801){this['listeners'][_0x1533d6]&&(this['listeners'][_0x1533d6]['delete'](_0x5b5801),this['listeners'][_0x1533d6]['size']===0x0&&delete this['listeners'][_0x1533d6]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x5a5ab9,_0x580996){return _0x580996?ie(_0x580996):(m(_0x5a5ab9['_popupRedirectResolver'],_0x5a5ab9,'argument-error'),_0x5a5ab9['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x48e3d2){super('custom','custom'),this['params']=_0x48e3d2;}['_getIdTokenResponse'](_0x1cb327){return Xe(_0x1cb327,this['_buildIdpRequest']());}['_linkToIdToken'](_0x39c1f8,_0x16ca01){return Xe(_0x39c1f8,this['_buildIdpRequest'](_0x16ca01));}['_getReauthenticationResolver'](_0x4307ec){return Xe(_0x4307ec,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x448fd9){const _0x2a9168={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x448fd9&&(_0x2a9168['idToken']=_0x448fd9),_0x2a9168;}}function yp(_0x235335){return Va(_0x235335['auth'],new ks(_0x235335),_0x235335['bypassAuthState']);}function vp(_0x288278){const {auth:_0x36f4f0,user:_0x362c98}=_0x288278;return m(_0x362c98,_0x36f4f0,'internal-error'),Xf(_0x362c98,new ks(_0x288278),_0x288278['bypassAuthState']);}async function Ep(_0x123416){const {auth:_0x4bd22b,user:_0x4f18d0}=_0x123416;return m(_0x4f18d0,_0x4bd22b,'internal-error'),Jf(_0x4f18d0,new ks(_0x123416),_0x123416['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x137de8,_0x5e231a,_0x55ac9e,_0x7d0935,_0x2cc039=!0x1){this['auth']=_0x137de8,this['resolver']=_0x55ac9e,this['user']=_0x7d0935,this['bypassAuthState']=_0x2cc039,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x5e231a)?_0x5e231a:[_0x5e231a];}['execute'](){return new Promise(async(_0x58e59b,_0x1bfd18)=>{this['pendingPromise']={'resolve':_0x58e59b,'reject':_0x1bfd18};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x5bfa39){this['reject'](_0x5bfa39);}});}async['onAuthEvent'](_0x36387e){const {urlResponse:_0x42151b,sessionId:_0x94ac29,postBody:_0x423918,tenantId:_0x10b079,error:_0x3675b5,type:_0x195822}=_0x36387e;if(_0x3675b5){this['reject'](_0x3675b5);return;}const _0x243c13={'auth':this['auth'],'requestUri':_0x42151b,'sessionId':_0x94ac29,'tenantId':_0x10b079||void 0x0,'postBody':_0x423918||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x195822)(_0x243c13));}catch(_0x2ab1ba){this['reject'](_0x2ab1ba);}}['onError'](_0x1c3fcd){this['reject'](_0x1c3fcd);}['getIdpTask'](_0x5c83aa){switch(_0x5c83aa){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x38636f){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x38636f),this['unregisterAndCleanUp']();}['reject'](_0xf3f151){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0xf3f151),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x1d8cc8,_0x50adfc,_0x28e92e,_0x4d578a,_0x58fba2){super(_0x1d8cc8,_0x50adfc,_0x4d578a,_0x58fba2),this['provider']=_0x28e92e,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x54eebc=await this['execute']();return m(_0x54eebc,this['auth'],'internal-error'),_0x54eebc;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x52ea37=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x52ea37),this['authWindow']['associatedEvent']=_0x52ea37,this['resolver']['_originValidation'](this['auth'])['catch'](_0x51e474=>{this['reject'](_0x51e474);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x1d912f=>{_0x1d912f||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x55f412;return((_0x55f412=this['authWindow'])==null?void 0x0:_0x55f412['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x45bb8e=()=>{var _0x20d262,_0x14c07b;if((_0x14c07b=(_0x20d262=this['authWindow'])==null?void 0x0:_0x20d262['window'])!=null&&_0x14c07b['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x45bb8e,Ip['get']());};_0x45bb8e();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x4773cd,_0x76a3fb,_0x2779f2=!0x1){super(_0x4773cd,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x76a3fb,void 0x0,_0x2779f2),this['eventId']=null;}async['execute'](){let _0x118e52=on['get'](this['auth']['_key']());if(!_0x118e52){try{const _0x9310aa=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x118e52=()=>Promise['resolve'](_0x9310aa);}catch(_0x25f669){_0x118e52=()=>Promise['reject'](_0x25f669);}on['set'](this['auth']['_key'](),_0x118e52);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x118e52();}async['onAuthEvent'](_0x5c8f9f){if(_0x5c8f9f['type']==='signInViaRedirect')return super['onAuthEvent'](_0x5c8f9f);if(_0x5c8f9f['type']==='unknown'){this['resolve'](null);return;}if(_0x5c8f9f['eventId']){const _0x502a00=await this['auth']['_redirectUserForId'](_0x5c8f9f['eventId']);if(_0x502a00)return this['user']=_0x502a00,super['onAuthEvent'](_0x5c8f9f);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x558404,_0x4734a6){const _0x693787=Rp(_0x4734a6),_0x208767=bp(_0x558404);if(!await _0x208767['_isAvailable']())return!0x1;const _0x878d04=await _0x208767['_get'](_0x693787)==='true';return await _0x208767['_remove'](_0x693787),_0x878d04;}function Sp(_0x1b9f06,_0xd3644d){on['set'](_0x1b9f06['_key'](),_0xd3644d);}function bp(_0x2331c3){return ie(_0x2331c3['_redirectPersistence']);}function Rp(_0x368e2f){return rn(wp,_0x368e2f['config']['apiKey'],_0x368e2f['name']);}async function Ap(_0x33e93a,_0x266e15,_0x63673b=!0x1){if($(_0x33e93a['app']))return Promise['reject'](re(_0x33e93a));const _0x7e43a0=qe(_0x33e93a),_0x513049=mp(_0x7e43a0,_0x266e15),_0x1e1221=await new Cp(_0x7e43a0,_0x513049,_0x63673b)['execute']();return _0x1e1221&&!_0x63673b&&(delete _0x1e1221['user']['_redirectEventId'],await _0x7e43a0['_persistUserIfCurrent'](_0x1e1221['user']),await _0x7e43a0['_setRedirectUser'](null,_0x266e15)),_0x1e1221;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x3846cf){this['auth']=_0x3846cf,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x52ef19){this['consumers']['add'](_0x52ef19),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x52ef19)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x52ef19),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x55c3c2){this['consumers']['delete'](_0x55c3c2);}['onEvent'](_0x1d62b3){if(this['hasEventBeenHandled'](_0x1d62b3))return!0x1;let _0x39cd16=!0x1;return this['consumers']['forEach'](_0x348daf=>{this['isEventForConsumer'](_0x1d62b3,_0x348daf)&&(_0x39cd16=!0x0,this['sendToConsumer'](_0x1d62b3,_0x348daf),this['saveEventToCache'](_0x1d62b3));}),this['hasHandledPotentialRedirect']||!Pp(_0x1d62b3)||(this['hasHandledPotentialRedirect']=!0x0,_0x39cd16||(this['queuedRedirectEvent']=_0x1d62b3,_0x39cd16=!0x0)),_0x39cd16;}['sendToConsumer'](_0x4274b4,_0x2602e2){var _0x3dc248;if(_0x4274b4['error']&&!Xa(_0x4274b4)){const _0x4ebe2a=((_0x3dc248=_0x4274b4['error']['code'])==null?void 0x0:_0x3dc248['split']('auth/')[0x1])||'internal-error';_0x2602e2['onError'](X(this['auth'],_0x4ebe2a));}else _0x2602e2['onAuthEvent'](_0x4274b4);}['isEventForConsumer'](_0x1b82ae,_0x2c57b3){const _0x5a1440=_0x2c57b3['eventId']===null||!!_0x1b82ae['eventId']&&_0x1b82ae['eventId']===_0x2c57b3['eventId'];return _0x2c57b3['filter']['includes'](_0x1b82ae['type'])&&_0x5a1440;}['hasEventBeenHandled'](_0x165344){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x165344));}['saveEventToCache'](_0x41694f){this['cachedEventUids']['add'](Dr(_0x41694f)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x143885){return[_0x143885['type'],_0x143885['eventId'],_0x143885['sessionId'],_0x143885['tenantId']]['filter'](_0x13f67a=>_0x13f67a)['join']('-');}function Xa({type:_0x41451f,error:_0x316f5e}){return _0x41451f==='unknown'&&(_0x316f5e==null?void 0x0:_0x316f5e['code'])==='auth/no-auth-event';}function Pp(_0xe3fa27){switch(_0xe3fa27['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0xe3fa27);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x4c7124,_0xcc0603={}){return Ae(_0x4c7124,'GET','/v1/projects',_0xcc0603);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x5ea3d7){if(_0x5ea3d7['config']['emulator'])return;const {authorizedDomains:_0x5a3737}=await Op(_0x5ea3d7);for(const _0x1a1d6d of _0x5a3737)try{if(xp(_0x1a1d6d))return;}catch{}Q(_0x5ea3d7,'unauthorized-domain');}function xp(_0x2936f5){const _0x5bd71e=Pi(),{protocol:_0xdc552a,hostname:_0x14344c}=new URL(_0x5bd71e);if(_0x2936f5['startsWith']('chrome-extension://')){const _0x243db5=new URL(_0x2936f5);return _0x243db5['hostname']===''&&_0x14344c===''?_0xdc552a==='chrome-extension:'&&_0x2936f5['replace']('chrome-extension://','')===_0x5bd71e['replace']('chrome-extension://',''):_0xdc552a==='chrome-extension:'&&_0x243db5['hostname']===_0x14344c;}if(!Mp['test'](_0xdc552a))return!0x1;if(Dp['test'](_0x2936f5))return _0x14344c===_0x2936f5;const _0x518ad1=_0x2936f5['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x518ad1+'|'+_0x518ad1+')$','i')['test'](_0x14344c);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x11c0d7=Z()['___jsl'];if(_0x11c0d7!=null&&_0x11c0d7['H']){for(const _0x314d79 of Object['keys'](_0x11c0d7['H']))if(_0x11c0d7['H'][_0x314d79]['r']=_0x11c0d7['H'][_0x314d79]['r']||[],_0x11c0d7['H'][_0x314d79]['L']=_0x11c0d7['H'][_0x314d79]['L']||[],_0x11c0d7['H'][_0x314d79]['r']=[..._0x11c0d7['H'][_0x314d79]['L']],_0x11c0d7['CP']){for(let _0x25d5e7=0x0;_0x25d5e7<_0x11c0d7['CP']['length'];_0x25d5e7++)_0x11c0d7['CP'][_0x25d5e7]=null;}}}function Up(_0x1ef174){return new Promise((_0x3a432b,_0xc9e4df)=>{var _0xc9891b,_0x18e741,_0x2f5182;function _0x53da6e(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x3a432b(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0xc9e4df(X(_0x1ef174,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x18e741=(_0xc9891b=Z()['gapi'])==null?void 0x0:_0xc9891b['iframes'])!=null&&_0x18e741['Iframe'])_0x3a432b(gapi['iframes']['getContext']());else{if((_0x2f5182=Z()['gapi'])!=null&&_0x2f5182['load'])_0x53da6e();else{const _0x3dc6d8=Df('iframefcb');return Z()[_0x3dc6d8]=()=>{gapi['load']?_0x53da6e():_0xc9e4df(X(_0x1ef174,'network-request-failed'));},xa(Of()+'?onload='+_0x3dc6d8)['catch'](_0x9d2420=>_0xc9e4df(_0x9d2420));}}})['catch'](_0x1f11a9=>{throw an=null,_0x1f11a9;});}let an=null;function Wp(_0x9508e7){return an=an||Up(_0x9508e7),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x45f6f1){const _0x24cb41=_0x45f6f1['config'];m(_0x24cb41['authDomain'],_0x45f6f1,'auth-domain-config-required');const _0x18e020=_0x24cb41['emulator']?Cs(_0x24cb41,Hp):'https://'+_0x45f6f1['config']['authDomain']+'/'+Vp,_0x2b1266={'apiKey':_0x24cb41['apiKey'],'appName':_0x45f6f1['name'],'v':lt},_0x545c23=Gp['get'](_0x45f6f1['config']['apiHost']);_0x545c23&&(_0x2b1266['eid']=_0x545c23);const _0x3977f4=_0x45f6f1['_getFrameworks']();return _0x3977f4['length']&&(_0x2b1266['fw']=_0x3977f4['join'](',')),_0x18e020+'?'+ct(_0x2b1266)['slice'](0x1);}async function zp(_0x2fff4c){const _0x5e81b0=await Wp(_0x2fff4c),_0x4e8624=Z()['gapi'];return m(_0x4e8624,_0x2fff4c,'internal-error'),_0x5e81b0['open']({'where':document['body'],'url':qp(_0x2fff4c),'messageHandlersFilter':_0x4e8624['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x36820e=>new Promise(async(_0x35601c,_0x57f699)=>{await _0x36820e['restyle']({'setHideOnLeave':!0x1});const _0x400dc5=X(_0x2fff4c,'network-request-failed'),_0x22af73=Z()['setTimeout'](()=>{_0x57f699(_0x400dc5);},Bp['get']());function _0x2a794b(){Z()['clearTimeout'](_0x22af73),_0x35601c(_0x36820e);}_0x36820e['ping'](_0x2a794b)['then'](_0x2a794b,()=>{_0x57f699(_0x400dc5);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x2bf6a7){this['window']=_0x2bf6a7,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x35fda3,_0x43ce03,_0x5c7111,_0x390047=Kp,_0x15fca4=Yp){const _0x51c4fb=Math['max']((window['screen']['availHeight']-_0x15fca4)/0x2,0x0)['toString'](),_0x3dc682=Math['max']((window['screen']['availWidth']-_0x390047)/0x2,0x0)['toString']();let _0x56c041='';const _0x490df8={...jp,'width':_0x390047['toString'](),'height':_0x15fca4['toString'](),'top':_0x51c4fb,'left':_0x3dc682},_0x15f9be=W()['toLowerCase']();_0x5c7111&&(_0x56c041=ka(_0x15f9be)?Qp:_0x5c7111),Ra(_0x15f9be)&&(_0x43ce03=_0x43ce03||Jp,_0x490df8['scrollbars']='yes');const _0x922656=Object['entries'](_0x490df8)['reduce']((_0x4728bd,[_0x3a3faf,_0x4ca8a2])=>''+_0x4728bd+_0x3a3faf+'='+_0x4ca8a2+',','');if(Cf(_0x15f9be)&&_0x56c041!=='_self')return Zp(_0x43ce03||'',_0x56c041),new Lr(null);const _0x5a4800=window['open'](_0x43ce03||'',_0x56c041,_0x922656);m(_0x5a4800,_0x35fda3,'popup-blocked');try{_0x5a4800['focus']();}catch{}return new Lr(_0x5a4800);}function Zp(_0xd87761,_0x2200c8){const _0x286919=document['createElement']('a');_0x286919['href']=_0xd87761,_0x286919['target']=_0x2200c8;const _0x419883=document['createEvent']('MouseEvent');_0x419883['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x286919['dispatchEvent'](_0x419883);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x403407,_0x25cdc0,_0x1a73eb,_0x5f48bc,_0x315266,_0x1b3aef){m(_0x403407['config']['authDomain'],_0x403407,'auth-domain-config-required'),m(_0x403407['config']['apiKey'],_0x403407,'invalid-api-key');const _0xa49114={'apiKey':_0x403407['config']['apiKey'],'appName':_0x403407['name'],'authType':_0x1a73eb,'redirectUrl':_0x5f48bc,'v':lt,'eventId':_0x315266};if(_0x25cdc0 instanceof Wa){_0x25cdc0['setDefaultLanguage'](_0x403407['languageCode']),_0xa49114['providerId']=_0x25cdc0['providerId']||'',ui(_0x25cdc0['getCustomParameters']())||(_0xa49114['customParameters']=JSON['stringify'](_0x25cdc0['getCustomParameters']()));for(const [_0x190e4,_0x445364]of Object['entries']({}))_0xa49114[_0x190e4]=_0x445364;}if(_0x25cdc0 instanceof Jt){const _0x3863d9=_0x25cdc0['getScopes']()['filter'](_0x1c1a66=>_0x1c1a66!=='');_0x3863d9['length']>0x0&&(_0xa49114['scopes']=_0x3863d9['join'](','));}_0x403407['tenantId']&&(_0xa49114['tid']=_0x403407['tenantId']);const _0x35f838=_0xa49114;for(const _0x14e2f4 of Object['keys'](_0x35f838))_0x35f838[_0x14e2f4]===void 0x0&&delete _0x35f838[_0x14e2f4];const _0x5a9b67=await _0x403407['_getAppCheckToken'](),_0x419f45=_0x5a9b67?'#'+n_+'='+encodeURIComponent(_0x5a9b67):'';return i_(_0x403407)+'?'+ct(_0x35f838)['slice'](0x1)+_0x419f45;}function i_({config:_0x2b7063}){return _0x2b7063['emulator']?Cs(_0x2b7063,t_):'https://'+_0x2b7063['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x4e81e2,_0x3be8c8,_0x34200a,_0x577d3c){var _0x4975ba;ce((_0x4975ba=this['eventManagers'][_0x4e81e2['_key']()])==null?void 0x0:_0x4975ba['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x46c507=await xr(_0x4e81e2,_0x3be8c8,_0x34200a,Pi(),_0x577d3c);return Xp(_0x4e81e2,_0x46c507,As());}async['_openRedirect'](_0x2cb279,_0x4c1523,_0x228809,_0x3904f3){await this['_originValidation'](_0x2cb279);const _0x4bb190=await xr(_0x2cb279,_0x4c1523,_0x228809,Pi(),_0x3904f3);return ap(_0x4bb190),new Promise(()=>{});}['_initialize'](_0xb5098){const _0x435b6e=_0xb5098['_key']();if(this['eventManagers'][_0x435b6e]){const {manager:_0x5e70e5,promise:_0x3bf5d0}=this['eventManagers'][_0x435b6e];return _0x5e70e5?Promise['resolve'](_0x5e70e5):(ce(_0x3bf5d0,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x3bf5d0);}const _0x2463f8=this['initAndGetManager'](_0xb5098);return this['eventManagers'][_0x435b6e]={'promise':_0x2463f8},_0x2463f8['catch'](()=>{delete this['eventManagers'][_0x435b6e];}),_0x2463f8;}async['initAndGetManager'](_0x105d3e){const _0x478fd8=await zp(_0x105d3e),_0x1b2a1f=new Np(_0x105d3e);return _0x478fd8['register']('authEvent',_0x3b2432=>(m(_0x3b2432==null?void 0x0:_0x3b2432['authEvent'],_0x105d3e,'invalid-auth-event'),{'status':_0x1b2a1f['onEvent'](_0x3b2432['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x105d3e['_key']()]={'manager':_0x1b2a1f},this['iframes'][_0x105d3e['_key']()]=_0x478fd8,_0x1b2a1f;}['_isIframeWebStorageSupported'](_0x13dfe7,_0xf272bc){this['iframes'][_0x13dfe7['_key']()]['send'](hi,{'type':hi},_0x5eebd4=>{var _0x3ca83f;const _0x4f4e55=(_0x3ca83f=_0x5eebd4==null?void 0x0:_0x5eebd4[0x0])==null?void 0x0:_0x3ca83f[hi];_0x4f4e55!==void 0x0&&_0xf272bc(!!_0x4f4e55),Q(_0x13dfe7,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x27ba55){const _0x29e488=_0x27ba55['_key']();return this['originValidationPromises'][_0x29e488]||(this['originValidationPromises'][_0x29e488]=Lp(_0x27ba55)),this['originValidationPromises'][_0x29e488];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x4a8e83){this['auth']=_0x4a8e83,this['internalListeners']=new Map();}['getUid'](){var _0x165b93;return this['assertAuthConfigured'](),((_0x165b93=this['auth']['currentUser'])==null?void 0x0:_0x165b93['uid'])||null;}async['getToken'](_0x7ae36d){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x7ae36d)}:null;}['addAuthTokenListener'](_0x181fb5){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x181fb5))return;const _0x39fd78=this['auth']['onIdTokenChanged'](_0x577e45=>{_0x181fb5((_0x577e45==null?void 0x0:_0x577e45['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x181fb5,_0x39fd78),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x31456d){this['assertAuthConfigured']();const _0x59f188=this['internalListeners']['get'](_0x31456d);_0x59f188&&(this['internalListeners']['delete'](_0x31456d),_0x59f188(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x5683aa){switch(_0x5683aa){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x5254fb){Ze(new Le('auth',(_0x3fa694,{options:_0x5070a8})=>{const _0x5f73c7=_0x3fa694['getProvider']('app')['getImmediate'](),_0x39949c=_0x3fa694['getProvider']('heartbeat'),_0x28cc3a=_0x3fa694['getProvider']('app-check-internal'),{apiKey:_0x3e1f84,authDomain:_0x2ce54c}=_0x5f73c7['options'];m(_0x3e1f84&&!_0x3e1f84['includes'](':'),'invalid-api-key',{'appName':_0x5f73c7['name']});const _0x4e5cc4={'apiKey':_0x3e1f84,'authDomain':_0x2ce54c,'clientPlatform':_0x5254fb,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x5254fb)},_0x3c3d0b=new kf(_0x5f73c7,_0x39949c,_0x28cc3a,_0x4e5cc4);return Wf(_0x3c3d0b,_0x5070a8),_0x3c3d0b;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x307f32,_0x125943,_0x90a0a0)=>{_0x307f32['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x393250=>{const _0x30d587=qe(_0x393250['getProvider']('auth')['getImmediate']());return(_0x32782e=>new o_(_0x32782e))(_0x30d587);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x5254fb)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x35957c=>async _0xe44d8=>{const _0x4f1e7d=_0xe44d8&&await _0xe44d8['getIdTokenResult'](),_0x2848d2=_0x4f1e7d&&(new Date()['getTime']()-Date['parse'](_0x4f1e7d['issuedAtTime']))/0x3e8;if(_0x2848d2&&_0x2848d2>h_)return;const _0x5745ec=_0x4f1e7d==null?void 0x0:_0x4f1e7d['token'];Wr!==_0x5745ec&&(Wr=_0x5745ec,await fetch(_0x35957c,{'method':_0x5745ec?'POST':'DELETE','headers':_0x5745ec?{'Authorization':'Bearer\x20'+_0x5745ec}:{}}));};function x_(_0x952bbc=Zr()){const _0x2460ac=Bi(_0x952bbc,'auth');if(_0x2460ac['isInitialized']())return _0x2460ac['getImmediate']();const _0x49105a=Uf(_0x952bbc,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x2749d3=zr('authTokenSyncURL');if(_0x2749d3&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x2eaaba=new URL(_0x2749d3,location['origin']);if(location['origin']===_0x2eaaba['origin']){const _0x35e62e=u_(_0x2eaaba['toString']());tp(_0x49105a,_0x35e62e,()=>_0x35e62e(_0x49105a['currentUser'])),ep(_0x49105a,_0x4b7ad2=>_0x35e62e(_0x4b7ad2));}}const _0x5ae50b=Gr('auth');return _0x5ae50b&&Bf(_0x49105a,'http://'+_0x5ae50b),_0x49105a;}function d_(){var _0x193704;return((_0x193704=document['getElementsByTagName']('head'))==null?void 0x0:_0x193704[0x0])??document;}Nf({'loadJS'(_0x7d7c6b){return new Promise((_0x2d4751,_0x5640fa)=>{const _0x437002=document['createElement']('script');_0x437002['setAttribute']('src',_0x7d7c6b),_0x437002['onload']=_0x2d4751,_0x437002['onerror']=_0xb0f7ee=>{const _0x5c5611=X('internal-error');_0x5c5611['customData']=_0xb0f7ee,_0x5640fa(_0x5c5611);},_0x437002['type']='text/javascript',_0x437002['charset']='UTF-8',d_()['appendChild'](_0x437002);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};