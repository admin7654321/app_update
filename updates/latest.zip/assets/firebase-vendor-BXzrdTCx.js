const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0xbe061d,_0x962665){if(!_0xbe061d)throw rt(_0x962665);},rt=function(_0x3ef0aa){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x3ef0aa);},Vr=function(_0x139827){const _0x5b1bac=[];let _0x438484=0x0;for(let _0x5314bf=0x0;_0x5314bf<_0x139827['length'];_0x5314bf++){let _0x221e92=_0x139827['charCodeAt'](_0x5314bf);_0x221e92<0x80?_0x5b1bac[_0x438484++]=_0x221e92:_0x221e92<0x800?(_0x5b1bac[_0x438484++]=_0x221e92>>0x6|0xc0,_0x5b1bac[_0x438484++]=_0x221e92&0x3f|0x80):(_0x221e92&0xfc00)===0xd800&&_0x5314bf+0x1<_0x139827['length']&&(_0x139827['charCodeAt'](_0x5314bf+0x1)&0xfc00)===0xdc00?(_0x221e92=0x10000+((_0x221e92&0x3ff)<<0xa)+(_0x139827['charCodeAt'](++_0x5314bf)&0x3ff),_0x5b1bac[_0x438484++]=_0x221e92>>0x12|0xf0,_0x5b1bac[_0x438484++]=_0x221e92>>0xc&0x3f|0x80,_0x5b1bac[_0x438484++]=_0x221e92>>0x6&0x3f|0x80,_0x5b1bac[_0x438484++]=_0x221e92&0x3f|0x80):(_0x5b1bac[_0x438484++]=_0x221e92>>0xc|0xe0,_0x5b1bac[_0x438484++]=_0x221e92>>0x6&0x3f|0x80,_0x5b1bac[_0x438484++]=_0x221e92&0x3f|0x80);}return _0x5b1bac;},ec=function(_0x24a569){const _0x10f06c=[];let _0xd297d5=0x0,_0x583f3e=0x0;for(;_0xd297d5<_0x24a569['length'];){const _0x43497e=_0x24a569[_0xd297d5++];if(_0x43497e<0x80)_0x10f06c[_0x583f3e++]=String['fromCharCode'](_0x43497e);else{if(_0x43497e>0xbf&&_0x43497e<0xe0){const _0x2071b5=_0x24a569[_0xd297d5++];_0x10f06c[_0x583f3e++]=String['fromCharCode']((_0x43497e&0x1f)<<0x6|_0x2071b5&0x3f);}else{if(_0x43497e>0xef&&_0x43497e<0x16d){const _0x54f191=_0x24a569[_0xd297d5++],_0x5b797d=_0x24a569[_0xd297d5++],_0x552b98=_0x24a569[_0xd297d5++],_0x232066=((_0x43497e&0x7)<<0x12|(_0x54f191&0x3f)<<0xc|(_0x5b797d&0x3f)<<0x6|_0x552b98&0x3f)-0x10000;_0x10f06c[_0x583f3e++]=String['fromCharCode'](0xd800+(_0x232066>>0xa)),_0x10f06c[_0x583f3e++]=String['fromCharCode'](0xdc00+(_0x232066&0x3ff));}else{const _0xe417b1=_0x24a569[_0xd297d5++],_0x41dff3=_0x24a569[_0xd297d5++];_0x10f06c[_0x583f3e++]=String['fromCharCode']((_0x43497e&0xf)<<0xc|(_0xe417b1&0x3f)<<0x6|_0x41dff3&0x3f);}}}}return _0x10f06c['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x2663e3,_0x594c08){if(!Array['isArray'](_0x2663e3))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x57ae81=_0x594c08?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x3684c1=[];for(let _0x46d5ee=0x0;_0x46d5ee<_0x2663e3['length'];_0x46d5ee+=0x3){const _0x2e8239=_0x2663e3[_0x46d5ee],_0x1f2913=_0x46d5ee+0x1<_0x2663e3['length'],_0x5b13b3=_0x1f2913?_0x2663e3[_0x46d5ee+0x1]:0x0,_0x177b75=_0x46d5ee+0x2<_0x2663e3['length'],_0x2de0a4=_0x177b75?_0x2663e3[_0x46d5ee+0x2]:0x0,_0x3d2f69=_0x2e8239>>0x2,_0x5f2c6f=(_0x2e8239&0x3)<<0x4|_0x5b13b3>>0x4;let _0x5824d4=(_0x5b13b3&0xf)<<0x2|_0x2de0a4>>0x6,_0x1d7783=_0x2de0a4&0x3f;_0x177b75||(_0x1d7783=0x40,_0x1f2913||(_0x5824d4=0x40)),_0x3684c1['push'](_0x57ae81[_0x3d2f69],_0x57ae81[_0x5f2c6f],_0x57ae81[_0x5824d4],_0x57ae81[_0x1d7783]);}return _0x3684c1['join']('');},'encodeString'(_0x4d7722,_0x2f1e99){return this['HAS_NATIVE_SUPPORT']&&!_0x2f1e99?btoa(_0x4d7722):this['encodeByteArray'](Vr(_0x4d7722),_0x2f1e99);},'decodeString'(_0x27c810,_0x4c346e){return this['HAS_NATIVE_SUPPORT']&&!_0x4c346e?atob(_0x27c810):ec(this['decodeStringToByteArray'](_0x27c810,_0x4c346e));},'decodeStringToByteArray'(_0x5bf19e,_0x1c8cec){this['init_']();const _0x3a42cb=_0x1c8cec?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x317e14=[];for(let _0x5f17f9=0x0;_0x5f17f9<_0x5bf19e['length'];){const _0x302df7=_0x3a42cb[_0x5bf19e['charAt'](_0x5f17f9++)],_0x5b03df=_0x5f17f9<_0x5bf19e['length']?_0x3a42cb[_0x5bf19e['charAt'](_0x5f17f9)]:0x0;++_0x5f17f9;const _0x1b22c8=_0x5f17f9<_0x5bf19e['length']?_0x3a42cb[_0x5bf19e['charAt'](_0x5f17f9)]:0x40;++_0x5f17f9;const _0x37bba4=_0x5f17f9<_0x5bf19e['length']?_0x3a42cb[_0x5bf19e['charAt'](_0x5f17f9)]:0x40;if(++_0x5f17f9,_0x302df7==null||_0x5b03df==null||_0x1b22c8==null||_0x37bba4==null)throw new tc();const _0x2169bf=_0x302df7<<0x2|_0x5b03df>>0x4;if(_0x317e14['push'](_0x2169bf),_0x1b22c8!==0x40){const _0x2ebe39=_0x5b03df<<0x4&0xf0|_0x1b22c8>>0x2;if(_0x317e14['push'](_0x2ebe39),_0x37bba4!==0x40){const _0x49b14c=_0x1b22c8<<0x6&0xc0|_0x37bba4;_0x317e14['push'](_0x49b14c);}}}return _0x317e14;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x2c97fc=0x0;_0x2c97fc<this['ENCODED_VALS']['length'];_0x2c97fc++)this['byteToCharMap_'][_0x2c97fc]=this['ENCODED_VALS']['charAt'](_0x2c97fc),this['charToByteMap_'][this['byteToCharMap_'][_0x2c97fc]]=_0x2c97fc,this['byteToCharMapWebSafe_'][_0x2c97fc]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x2c97fc),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x2c97fc]]=_0x2c97fc,_0x2c97fc>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x2c97fc)]=_0x2c97fc,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x2c97fc)]=_0x2c97fc);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x59ea67){const _0x42a810=Vr(_0x59ea67);return Li['encodeByteArray'](_0x42a810,!0x0);},cn=function(_0x5cc230){return Hr(_0x5cc230)['replace'](/\./g,'');},ln=function(_0x56db88){try{return Li['decodeString'](_0x56db88,!0x0);}catch(_0x442e80){console['error']('base64Decode\x20failed:\x20',_0x442e80);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x5c5133){return $r(void 0x0,_0x5c5133);}function $r(_0x4f97a6,_0x39be12){if(!(_0x39be12 instanceof Object))return _0x39be12;switch(_0x39be12['constructor']){case Date:const _0x53da14=_0x39be12;return new Date(_0x53da14['getTime']());case Object:_0x4f97a6===void 0x0&&(_0x4f97a6={});break;case Array:_0x4f97a6=[];break;default:return _0x39be12;}for(const _0x1774b1 in _0x39be12)!_0x39be12['hasOwnProperty'](_0x1774b1)||!ic(_0x1774b1)||(_0x4f97a6[_0x1774b1]=$r(_0x4f97a6[_0x1774b1],_0x39be12[_0x1774b1]));return _0x4f97a6;}function ic(_0x3eb42e){return _0x3eb42e!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x123d9a=Ns['__FIREBASE_DEFAULTS__'];if(_0x123d9a)return JSON['parse'](_0x123d9a);},ac=()=>{if(typeof document>'u')return;let _0x148bc4;try{_0x148bc4=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x3e059a=_0x148bc4&&ln(_0x148bc4[0x1]);return _0x3e059a&&JSON['parse'](_0x3e059a);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x27be9a){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x27be9a);return;}},Gr=_0x5c8ec1=>{var _0x274b30,_0x53ce08;return(_0x53ce08=(_0x274b30=xi())==null?void 0x0:_0x274b30['emulatorHosts'])==null?void 0x0:_0x53ce08[_0x5c8ec1];},cc=_0x163782=>{const _0x150e52=Gr(_0x163782);if(!_0x150e52)return;const _0x22006e=_0x150e52['lastIndexOf'](':');if(_0x22006e<=0x0||_0x22006e+0x1===_0x150e52['length'])throw new Error('Invalid\x20host\x20'+_0x150e52+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x303fdc=parseInt(_0x150e52['substring'](_0x22006e+0x1),0xa);return _0x150e52[0x0]==='['?[_0x150e52['substring'](0x1,_0x22006e-0x1),_0x303fdc]:[_0x150e52['substring'](0x0,_0x22006e),_0x303fdc];},qr=()=>{var _0x226c54;return(_0x226c54=xi())==null?void 0x0:_0x226c54['config'];},zr=_0x3d1c0b=>{var _0x13a765;return(_0x13a765=xi())==null?void 0x0:_0x13a765['_'+_0x3d1c0b];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x4b6337,_0x3f1ea7)=>{this['resolve']=_0x4b6337,this['reject']=_0x3f1ea7;});}['wrapCallback'](_0x32f5a9){return(_0x1ae097,_0x57ec27)=>{_0x1ae097?this['reject'](_0x1ae097):this['resolve'](_0x57ec27),typeof _0x32f5a9=='function'&&(this['promise']['catch'](()=>{}),_0x32f5a9['length']===0x1?_0x32f5a9(_0x1ae097):_0x32f5a9(_0x1ae097,_0x57ec27));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x16829c){try{return(_0x16829c['startsWith']('http://')||_0x16829c['startsWith']('https://')?new URL(_0x16829c)['hostname']:_0x16829c)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x508695){return(await fetch(_0x508695,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x484a88,_0x401161){if(_0x484a88['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x179294={'alg':'none','type':'JWT'},_0x51771b=_0x401161||'demo-project',_0x33f8d3=_0x484a88['iat']||0x0,_0x308f15=_0x484a88['sub']||_0x484a88['user_id'];if(!_0x308f15)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x128b1b={'iss':'https://securetoken.google.com/'+_0x51771b,'aud':_0x51771b,'iat':_0x33f8d3,'exp':_0x33f8d3+0xe10,'auth_time':_0x33f8d3,'sub':_0x308f15,'user_id':_0x308f15,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x484a88};return[cn(JSON['stringify'](_0x179294)),cn(JSON['stringify'](_0x128b1b)),'']['join']('.');}const It={};function hc(){const _0x31deaa={'prod':[],'emulator':[]};for(const _0x170f61 of Object['keys'](It))It[_0x170f61]?_0x31deaa['emulator']['push'](_0x170f61):_0x31deaa['prod']['push'](_0x170f61);return _0x31deaa;}function uc(_0x3973cb){let _0x309c07=document['getElementById'](_0x3973cb),_0x26bf36=!0x1;return _0x309c07||(_0x309c07=document['createElement']('div'),_0x309c07['setAttribute']('id',_0x3973cb),_0x26bf36=!0x0),{'created':_0x26bf36,'element':_0x309c07};}let Ps=!0x1;function Kr(_0x223639,_0x3b4f03){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x223639]===_0x3b4f03||It[_0x223639]||Ps)return;It[_0x223639]=_0x3b4f03;function _0x1ca3f7(_0xe93003){return'__firebase__banner__'+_0xe93003;}const _0x1a5373='__firebase__banner',_0x3d71de=hc()['prod']['length']>0x0;function _0x1a0f1a(){const _0x4a84e1=document['getElementById'](_0x1a5373);_0x4a84e1&&_0x4a84e1['remove']();}function _0x2f7cfc(_0x203b0c){_0x203b0c['style']['display']='flex',_0x203b0c['style']['background']='#7faaf0',_0x203b0c['style']['position']='fixed',_0x203b0c['style']['bottom']='5px',_0x203b0c['style']['left']='5px',_0x203b0c['style']['padding']='.5em',_0x203b0c['style']['borderRadius']='5px',_0x203b0c['style']['alignItems']='center';}function _0x42a4c3(_0x2098e8,_0x382f8d){_0x2098e8['setAttribute']('width','24'),_0x2098e8['setAttribute']('id',_0x382f8d),_0x2098e8['setAttribute']('height','24'),_0x2098e8['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x2098e8['setAttribute']('fill','none'),_0x2098e8['style']['marginLeft']='-6px';}function _0x244ab4(){const _0x4b27da=document['createElement']('span');return _0x4b27da['style']['cursor']='pointer',_0x4b27da['style']['marginLeft']='16px',_0x4b27da['style']['fontSize']='24px',_0x4b27da['innerHTML']='\x20&times;',_0x4b27da['onclick']=()=>{Ps=!0x0,_0x1a0f1a();},_0x4b27da;}function _0xb0dd8f(_0x1883a6,_0x3889b3){_0x1883a6['setAttribute']('id',_0x3889b3),_0x1883a6['innerText']='Learn\x20more',_0x1883a6['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x1883a6['setAttribute']('target','__blank'),_0x1883a6['style']['paddingLeft']='5px',_0x1883a6['style']['textDecoration']='underline';}function _0xd07daa(){const _0x330e80=uc(_0x1a5373),_0x3bb4c4=_0x1ca3f7('text'),_0x3945b7=document['getElementById'](_0x3bb4c4)||document['createElement']('span'),_0x56a8d4=_0x1ca3f7('learnmore'),_0x5844cf=document['getElementById'](_0x56a8d4)||document['createElement']('a'),_0x5a1d68=_0x1ca3f7('preprendIcon'),_0x5c7e0e=document['getElementById'](_0x5a1d68)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x330e80['created']){const _0xe6767d=_0x330e80['element'];_0x2f7cfc(_0xe6767d),_0xb0dd8f(_0x5844cf,_0x56a8d4);const _0x45ba29=_0x244ab4();_0x42a4c3(_0x5c7e0e,_0x5a1d68),_0xe6767d['append'](_0x5c7e0e,_0x3945b7,_0x5844cf,_0x45ba29),document['body']['appendChild'](_0xe6767d);}_0x3d71de?(_0x3945b7['innerText']='Preview\x20backend\x20disconnected.',_0x5c7e0e['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x5c7e0e['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x3945b7['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x3945b7['setAttribute']('id',_0x3bb4c4);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0xd07daa):_0xd07daa();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x28d289=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x28d289=='object'&&_0x28d289['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x5d2efe=W();return _0x5d2efe['indexOf']('MSIE\x20')>=0x0||_0x5d2efe['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x43e0f7,_0x10c516)=>{try{let _0x2485f7=!0x0;const _0x55b797='validate-browser-context-for-indexeddb-analytics-module',_0x39f42f=self['indexedDB']['open'](_0x55b797);_0x39f42f['onsuccess']=()=>{_0x39f42f['result']['close'](),_0x2485f7||self['indexedDB']['deleteDatabase'](_0x55b797),_0x43e0f7(!0x0);},_0x39f42f['onupgradeneeded']=()=>{_0x2485f7=!0x1;},_0x39f42f['onerror']=()=>{var _0x4c27e2;_0x10c516(((_0x4c27e2=_0x39f42f['error'])==null?void 0x0:_0x4c27e2['message'])||'');};}catch(_0x19d4fa){_0x10c516(_0x19d4fa);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x5e3349,_0x56f4c7,_0x3550fb){super(_0x56f4c7),this['code']=_0x5e3349,this['customData']=_0x3550fb,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0xeb1a9a,_0x72b577,_0x2c8085){this['service']=_0xeb1a9a,this['serviceName']=_0x72b577,this['errors']=_0x2c8085;}['create'](_0x42b608,..._0x34faf1){const _0x3b2a05=_0x34faf1[0x0]||{},_0xf5f70c=this['service']+'/'+_0x42b608,_0x93d1cf=this['errors'][_0x42b608],_0x187d6a=_0x93d1cf?vc(_0x93d1cf,_0x3b2a05):'Error',_0x5bd5cc=this['serviceName']+':\x20'+_0x187d6a+'\x20('+_0xf5f70c+').';return new Se(_0xf5f70c,_0x5bd5cc,_0x3b2a05);}}function vc(_0x2ee0e0,_0x24b590){return _0x2ee0e0['replace'](Ec,(_0xb99d53,_0xf0ce03)=>{const _0x344a3e=_0x24b590[_0xf0ce03];return _0x344a3e!=null?String(_0x344a3e):'<'+_0xf0ce03+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x429def){return JSON['parse'](_0x429def);}function O(_0x1b671c){return JSON['stringify'](_0x1b671c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x22e55d){let _0x2f140e={},_0x4c3f20={},_0x4d300c={},_0x243463='';try{const _0x13e2a9=_0x22e55d['split']('.');_0x2f140e=At(ln(_0x13e2a9[0x0])||''),_0x4c3f20=At(ln(_0x13e2a9[0x1])||''),_0x243463=_0x13e2a9[0x2],_0x4d300c=_0x4c3f20['d']||{},delete _0x4c3f20['d'];}catch{}return{'header':_0x2f140e,'claims':_0x4c3f20,'data':_0x4d300c,'signature':_0x243463};},Ic=function(_0x439d3f){const _0x4170d4=Qr(_0x439d3f),_0x385d27=_0x4170d4['claims'];return!!_0x385d27&&typeof _0x385d27=='object'&&_0x385d27['hasOwnProperty']('iat');},wc=function(_0x33a78f){const _0x3db1e6=Qr(_0x33a78f)['claims'];return typeof _0x3db1e6=='object'&&_0x3db1e6['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x1cf158,_0x372793){return Object['prototype']['hasOwnProperty']['call'](_0x1cf158,_0x372793);}function De(_0x1578c5,_0x48382d){if(Object['prototype']['hasOwnProperty']['call'](_0x1578c5,_0x48382d))return _0x1578c5[_0x48382d];}function ui(_0x550c8e){for(const _0x3bdf47 in _0x550c8e)if(Object['prototype']['hasOwnProperty']['call'](_0x550c8e,_0x3bdf47))return!0x1;return!0x0;}function hn(_0x18424a,_0x598135,_0x1ce295){const _0x24a5a3={};for(const _0xe89f3e in _0x18424a)Object['prototype']['hasOwnProperty']['call'](_0x18424a,_0xe89f3e)&&(_0x24a5a3[_0xe89f3e]=_0x598135['call'](_0x1ce295,_0x18424a[_0xe89f3e],_0xe89f3e,_0x18424a));return _0x24a5a3;}function Me(_0x276281,_0x221dae){if(_0x276281===_0x221dae)return!0x0;const _0x5744b1=Object['keys'](_0x276281),_0x5a98be=Object['keys'](_0x221dae);for(const _0x9bf488 of _0x5744b1){if(!_0x5a98be['includes'](_0x9bf488))return!0x1;const _0x5732bd=_0x276281[_0x9bf488],_0x1039dc=_0x221dae[_0x9bf488];if(Os(_0x5732bd)&&Os(_0x1039dc)){if(!Me(_0x5732bd,_0x1039dc))return!0x1;}else{if(_0x5732bd!==_0x1039dc)return!0x1;}}for(const _0x192383 of _0x5a98be)if(!_0x5744b1['includes'](_0x192383))return!0x1;return!0x0;}function Os(_0x475450){return _0x475450!==null&&typeof _0x475450=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x37cff2){const _0x392e88=[];for(const [_0x3f76ec,_0x41b700]of Object['entries'](_0x37cff2))Array['isArray'](_0x41b700)?_0x41b700['forEach'](_0x210123=>{_0x392e88['push'](encodeURIComponent(_0x3f76ec)+'='+encodeURIComponent(_0x210123));}):_0x392e88['push'](encodeURIComponent(_0x3f76ec)+'='+encodeURIComponent(_0x41b700));return _0x392e88['length']?'&'+_0x392e88['join']('&'):'';}function vt(_0x1f2430){const _0x4b08ea={};return _0x1f2430['replace'](/^\?/,'')['split']('&')['forEach'](_0x5d085a=>{if(_0x5d085a){const [_0x5b6148,_0x296381]=_0x5d085a['split']('=');_0x4b08ea[decodeURIComponent(_0x5b6148)]=decodeURIComponent(_0x296381);}}),_0x4b08ea;}function Et(_0xd4a9f){const _0xf2f4ec=_0xd4a9f['indexOf']('?');if(!_0xf2f4ec)return'';const _0x2c6566=_0xd4a9f['indexOf']('#',_0xf2f4ec);return _0xd4a9f['substring'](_0xf2f4ec,_0x2c6566>0x0?_0x2c6566:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x158f2a=0x1;_0x158f2a<this['blockSize'];++_0x158f2a)this['pad_'][_0x158f2a]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x22e29f,_0x4de196){_0x4de196||(_0x4de196=0x0);const _0x177bf6=this['W_'];if(typeof _0x22e29f=='string'){for(let _0x565182=0x0;_0x565182<0x10;_0x565182++)_0x177bf6[_0x565182]=_0x22e29f['charCodeAt'](_0x4de196)<<0x18|_0x22e29f['charCodeAt'](_0x4de196+0x1)<<0x10|_0x22e29f['charCodeAt'](_0x4de196+0x2)<<0x8|_0x22e29f['charCodeAt'](_0x4de196+0x3),_0x4de196+=0x4;}else{for(let _0x416701=0x0;_0x416701<0x10;_0x416701++)_0x177bf6[_0x416701]=_0x22e29f[_0x4de196]<<0x18|_0x22e29f[_0x4de196+0x1]<<0x10|_0x22e29f[_0x4de196+0x2]<<0x8|_0x22e29f[_0x4de196+0x3],_0x4de196+=0x4;}for(let _0x5afde2=0x10;_0x5afde2<0x50;_0x5afde2++){const _0x50743b=_0x177bf6[_0x5afde2-0x3]^_0x177bf6[_0x5afde2-0x8]^_0x177bf6[_0x5afde2-0xe]^_0x177bf6[_0x5afde2-0x10];_0x177bf6[_0x5afde2]=(_0x50743b<<0x1|_0x50743b>>>0x1f)&0xffffffff;}let _0x2691b0=this['chain_'][0x0],_0x5904bc=this['chain_'][0x1],_0x3a6e50=this['chain_'][0x2],_0x4eb0e1=this['chain_'][0x3],_0x10f20c=this['chain_'][0x4],_0x40a349,_0x302a69;for(let _0x1e5b5e=0x0;_0x1e5b5e<0x50;_0x1e5b5e++){_0x1e5b5e<0x28?_0x1e5b5e<0x14?(_0x40a349=_0x4eb0e1^_0x5904bc&(_0x3a6e50^_0x4eb0e1),_0x302a69=0x5a827999):(_0x40a349=_0x5904bc^_0x3a6e50^_0x4eb0e1,_0x302a69=0x6ed9eba1):_0x1e5b5e<0x3c?(_0x40a349=_0x5904bc&_0x3a6e50|_0x4eb0e1&(_0x5904bc|_0x3a6e50),_0x302a69=0x8f1bbcdc):(_0x40a349=_0x5904bc^_0x3a6e50^_0x4eb0e1,_0x302a69=0xca62c1d6);const _0x440592=(_0x2691b0<<0x5|_0x2691b0>>>0x1b)+_0x40a349+_0x10f20c+_0x302a69+_0x177bf6[_0x1e5b5e]&0xffffffff;_0x10f20c=_0x4eb0e1,_0x4eb0e1=_0x3a6e50,_0x3a6e50=(_0x5904bc<<0x1e|_0x5904bc>>>0x2)&0xffffffff,_0x5904bc=_0x2691b0,_0x2691b0=_0x440592;}this['chain_'][0x0]=this['chain_'][0x0]+_0x2691b0&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5904bc&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x3a6e50&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x4eb0e1&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x10f20c&0xffffffff;}['update'](_0x5bd80a,_0x2fc009){if(_0x5bd80a==null)return;_0x2fc009===void 0x0&&(_0x2fc009=_0x5bd80a['length']);const _0x1f278f=_0x2fc009-this['blockSize'];let _0x20a1ea=0x0;const _0xd0bd09=this['buf_'];let _0x3b56a5=this['inbuf_'];for(;_0x20a1ea<_0x2fc009;){if(_0x3b56a5===0x0){for(;_0x20a1ea<=_0x1f278f;)this['compress_'](_0x5bd80a,_0x20a1ea),_0x20a1ea+=this['blockSize'];}if(typeof _0x5bd80a=='string'){for(;_0x20a1ea<_0x2fc009;)if(_0xd0bd09[_0x3b56a5]=_0x5bd80a['charCodeAt'](_0x20a1ea),++_0x3b56a5,++_0x20a1ea,_0x3b56a5===this['blockSize']){this['compress_'](_0xd0bd09),_0x3b56a5=0x0;break;}}else{for(;_0x20a1ea<_0x2fc009;)if(_0xd0bd09[_0x3b56a5]=_0x5bd80a[_0x20a1ea],++_0x3b56a5,++_0x20a1ea,_0x3b56a5===this['blockSize']){this['compress_'](_0xd0bd09),_0x3b56a5=0x0;break;}}}this['inbuf_']=_0x3b56a5,this['total_']+=_0x2fc009;}['digest'](){const _0x43cdaf=[];let _0x5ad208=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x557d1d=this['blockSize']-0x1;_0x557d1d>=0x38;_0x557d1d--)this['buf_'][_0x557d1d]=_0x5ad208&0xff,_0x5ad208/=0x100;this['compress_'](this['buf_']);let _0x599f1b=0x0;for(let _0x4c2fa3=0x0;_0x4c2fa3<0x5;_0x4c2fa3++)for(let _0xd55dba=0x18;_0xd55dba>=0x0;_0xd55dba-=0x8)_0x43cdaf[_0x599f1b]=this['chain_'][_0x4c2fa3]>>_0xd55dba&0xff,++_0x599f1b;return _0x43cdaf;}}function Tc(_0x3b809f,_0x563ed3){const _0x467694=new Sc(_0x3b809f,_0x563ed3);return _0x467694['subscribe']['bind'](_0x467694);}class Sc{constructor(_0x3d260e,_0x2265bd){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x2265bd,this['task']['then'](()=>{_0x3d260e(this);})['catch'](_0x41d3cc=>{this['error'](_0x41d3cc);});}['next'](_0x2293ce){this['forEachObserver'](_0x28de2b=>{_0x28de2b['next'](_0x2293ce);});}['error'](_0x1920dd){this['forEachObserver'](_0x19eef0=>{_0x19eef0['error'](_0x1920dd);}),this['close'](_0x1920dd);}['complete'](){this['forEachObserver'](_0x29b92f=>{_0x29b92f['complete']();}),this['close']();}['subscribe'](_0x355d70,_0x41b332,_0xed660b){let _0x175b3c;if(_0x355d70===void 0x0&&_0x41b332===void 0x0&&_0xed660b===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x355d70,['next','error','complete'])?_0x175b3c=_0x355d70:_0x175b3c={'next':_0x355d70,'error':_0x41b332,'complete':_0xed660b},_0x175b3c['next']===void 0x0&&(_0x175b3c['next']=Jn),_0x175b3c['error']===void 0x0&&(_0x175b3c['error']=Jn),_0x175b3c['complete']===void 0x0&&(_0x175b3c['complete']=Jn);const _0x5674d1=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x175b3c['error'](this['finalError']):_0x175b3c['complete']();}catch{}}),this['observers']['push'](_0x175b3c),_0x5674d1;}['unsubscribeOne'](_0x393599){this['observers']===void 0x0||this['observers'][_0x393599]===void 0x0||(delete this['observers'][_0x393599],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x508eca){if(!this['finalized']){for(let _0x3891b0=0x0;_0x3891b0<this['observers']['length'];_0x3891b0++)this['sendOne'](_0x3891b0,_0x508eca);}}['sendOne'](_0x218edc,_0x55612b){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x218edc]!==void 0x0)try{_0x55612b(this['observers'][_0x218edc]);}catch(_0x5aacca){typeof console<'u'&&console['error']&&console['error'](_0x5aacca);}});}['close'](_0x37c010){this['finalized']||(this['finalized']=!0x0,_0x37c010!==void 0x0&&(this['finalError']=_0x37c010),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0xb00f37,_0x196427){if(typeof _0xb00f37!='object'||_0xb00f37===null)return!0x1;for(const _0x2fcf7d of _0x196427)if(_0x2fcf7d in _0xb00f37&&typeof _0xb00f37[_0x2fcf7d]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x3539e9,_0x1b94b0){return _0x3539e9+'\x20failed:\x20'+_0x1b94b0+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x5f5b4e){const _0x4da0e9=[];let _0x2065bb=0x0;for(let _0x50dd28=0x0;_0x50dd28<_0x5f5b4e['length'];_0x50dd28++){let _0x18fc52=_0x5f5b4e['charCodeAt'](_0x50dd28);if(_0x18fc52>=0xd800&&_0x18fc52<=0xdbff){const _0x1ee55d=_0x18fc52-0xd800;_0x50dd28++,f(_0x50dd28<_0x5f5b4e['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x21e4a8=_0x5f5b4e['charCodeAt'](_0x50dd28)-0xdc00;_0x18fc52=0x10000+(_0x1ee55d<<0xa)+_0x21e4a8;}_0x18fc52<0x80?_0x4da0e9[_0x2065bb++]=_0x18fc52:_0x18fc52<0x800?(_0x4da0e9[_0x2065bb++]=_0x18fc52>>0x6|0xc0,_0x4da0e9[_0x2065bb++]=_0x18fc52&0x3f|0x80):_0x18fc52<0x10000?(_0x4da0e9[_0x2065bb++]=_0x18fc52>>0xc|0xe0,_0x4da0e9[_0x2065bb++]=_0x18fc52>>0x6&0x3f|0x80,_0x4da0e9[_0x2065bb++]=_0x18fc52&0x3f|0x80):(_0x4da0e9[_0x2065bb++]=_0x18fc52>>0x12|0xf0,_0x4da0e9[_0x2065bb++]=_0x18fc52>>0xc&0x3f|0x80,_0x4da0e9[_0x2065bb++]=_0x18fc52>>0x6&0x3f|0x80,_0x4da0e9[_0x2065bb++]=_0x18fc52&0x3f|0x80);}return _0x4da0e9;},On=function(_0x440cc0){let _0x7ae405=0x0;for(let _0x576281=0x0;_0x576281<_0x440cc0['length'];_0x576281++){const _0x538481=_0x440cc0['charCodeAt'](_0x576281);_0x538481<0x80?_0x7ae405++:_0x538481<0x800?_0x7ae405+=0x2:_0x538481>=0xd800&&_0x538481<=0xdbff?(_0x7ae405+=0x4,_0x576281++):_0x7ae405+=0x3;}return _0x7ae405;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x1a0df0){return _0x1a0df0&&_0x1a0df0['_delegate']?_0x1a0df0['_delegate']:_0x1a0df0;}class Le{constructor(_0x48f5ae,_0x31d56f,_0x289e39){this['name']=_0x48f5ae,this['instanceFactory']=_0x31d56f,this['type']=_0x289e39,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x4cce76){return this['instantiationMode']=_0x4cce76,this;}['setMultipleInstances'](_0x30b8f4){return this['multipleInstances']=_0x30b8f4,this;}['setServiceProps'](_0x3517c2){return this['serviceProps']=_0x3517c2,this;}['setInstanceCreatedCallback'](_0x2e390){return this['onInstanceCreated']=_0x2e390,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x329b2e,_0x19b0ba){this['name']=_0x329b2e,this['container']=_0x19b0ba,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x13c3ec){const _0x2b07f7=this['normalizeInstanceIdentifier'](_0x13c3ec);if(!this['instancesDeferred']['has'](_0x2b07f7)){const _0x320c60=new ot();if(this['instancesDeferred']['set'](_0x2b07f7,_0x320c60),this['isInitialized'](_0x2b07f7)||this['shouldAutoInitialize']())try{const _0x49a6b5=this['getOrInitializeService']({'instanceIdentifier':_0x2b07f7});_0x49a6b5&&_0x320c60['resolve'](_0x49a6b5);}catch{}}return this['instancesDeferred']['get'](_0x2b07f7)['promise'];}['getImmediate'](_0x51f92a){const _0x2d2a4f=this['normalizeInstanceIdentifier'](_0x51f92a==null?void 0x0:_0x51f92a['identifier']),_0x235dbf=(_0x51f92a==null?void 0x0:_0x51f92a['optional'])??!0x1;if(this['isInitialized'](_0x2d2a4f)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x2d2a4f});}catch(_0x2a57a8){if(_0x235dbf)return null;throw _0x2a57a8;}else{if(_0x235dbf)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x57d209){if(_0x57d209['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x57d209['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x57d209,!!this['shouldAutoInitialize']()){if(Nc(_0x57d209))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x136581,_0x463696]of this['instancesDeferred']['entries']()){const _0x150b9f=this['normalizeInstanceIdentifier'](_0x136581);try{const _0x42983c=this['getOrInitializeService']({'instanceIdentifier':_0x150b9f});_0x463696['resolve'](_0x42983c);}catch{}}}}['clearInstance'](_0x40991b=Ne){this['instancesDeferred']['delete'](_0x40991b),this['instancesOptions']['delete'](_0x40991b),this['instances']['delete'](_0x40991b);}async['delete'](){const _0x15800c=Array['from'](this['instances']['values']());await Promise['all']([..._0x15800c['filter'](_0x52362c=>'INTERNAL'in _0x52362c)['map'](_0x2bf66d=>_0x2bf66d['INTERNAL']['delete']()),..._0x15800c['filter'](_0x16ba2d=>'_delete'in _0x16ba2d)['map'](_0x3a0aad=>_0x3a0aad['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x7a3b47=Ne){return this['instances']['has'](_0x7a3b47);}['getOptions'](_0x321a4d=Ne){return this['instancesOptions']['get'](_0x321a4d)||{};}['initialize'](_0xc0a125={}){const {options:_0x58db6b={}}=_0xc0a125,_0x381983=this['normalizeInstanceIdentifier'](_0xc0a125['instanceIdentifier']);if(this['isInitialized'](_0x381983))throw Error(this['name']+'('+_0x381983+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x2c6752=this['getOrInitializeService']({'instanceIdentifier':_0x381983,'options':_0x58db6b});for(const [_0x17d082,_0x523873]of this['instancesDeferred']['entries']()){const _0x4a2f0e=this['normalizeInstanceIdentifier'](_0x17d082);_0x381983===_0x4a2f0e&&_0x523873['resolve'](_0x2c6752);}return _0x2c6752;}['onInit'](_0x477d89,_0x22820a){const _0x1c2590=this['normalizeInstanceIdentifier'](_0x22820a),_0x17df66=this['onInitCallbacks']['get'](_0x1c2590)??new Set();_0x17df66['add'](_0x477d89),this['onInitCallbacks']['set'](_0x1c2590,_0x17df66);const _0x2d733a=this['instances']['get'](_0x1c2590);return _0x2d733a&&_0x477d89(_0x2d733a,_0x1c2590),()=>{_0x17df66['delete'](_0x477d89);};}['invokeOnInitCallbacks'](_0x10c437,_0x2d653b){const _0x9baabc=this['onInitCallbacks']['get'](_0x2d653b);if(_0x9baabc){for(const _0x386b04 of _0x9baabc)try{_0x386b04(_0x10c437,_0x2d653b);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x2953a9,options:_0x58c8c1={}}){let _0x4a2696=this['instances']['get'](_0x2953a9);if(!_0x4a2696&&this['component']&&(_0x4a2696=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x2953a9),'options':_0x58c8c1}),this['instances']['set'](_0x2953a9,_0x4a2696),this['instancesOptions']['set'](_0x2953a9,_0x58c8c1),this['invokeOnInitCallbacks'](_0x4a2696,_0x2953a9),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x2953a9,_0x4a2696);}catch{}return _0x4a2696||null;}['normalizeInstanceIdentifier'](_0x538891=Ne){return this['component']?this['component']['multipleInstances']?_0x538891:Ne:_0x538891;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x5eceb1){return _0x5eceb1===Ne?void 0x0:_0x5eceb1;}function Nc(_0x38283d){return _0x38283d['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x359db3){this['name']=_0x359db3,this['providers']=new Map();}['addComponent'](_0x2a90db){const _0x26351f=this['getProvider'](_0x2a90db['name']);if(_0x26351f['isComponentSet']())throw new Error('Component\x20'+_0x2a90db['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x26351f['setComponent'](_0x2a90db);}['addOrOverwriteComponent'](_0x40145c){this['getProvider'](_0x40145c['name'])['isComponentSet']()&&this['providers']['delete'](_0x40145c['name']),this['addComponent'](_0x40145c);}['getProvider'](_0x5e8f6f){if(this['providers']['has'](_0x5e8f6f))return this['providers']['get'](_0x5e8f6f);const _0x207ada=new Ac(_0x5e8f6f,this);return this['providers']['set'](_0x5e8f6f,_0x207ada),_0x207ada;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0xc52485){_0xc52485[_0xc52485['DEBUG']=0x0]='DEBUG',_0xc52485[_0xc52485['VERBOSE']=0x1]='VERBOSE',_0xc52485[_0xc52485['INFO']=0x2]='INFO',_0xc52485[_0xc52485['WARN']=0x3]='WARN',_0xc52485[_0xc52485['ERROR']=0x4]='ERROR',_0xc52485[_0xc52485['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x4bf112,_0x1880e3,..._0x711c0f)=>{if(_0x1880e3<_0x4bf112['logLevel'])return;const _0x598ab3=new Date()['toISOString'](),_0x27ca3c=Mc[_0x1880e3];if(_0x27ca3c)console[_0x27ca3c]('['+_0x598ab3+']\x20\x20'+_0x4bf112['name']+':',..._0x711c0f);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x1880e3+')');};class Ui{constructor(_0x3b5966){this['name']=_0x3b5966,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x4101b1){if(!(_0x4101b1 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x4101b1+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x4101b1;}['setLogLevel'](_0x31f97f){this['_logLevel']=typeof _0x31f97f=='string'?Oc[_0x31f97f]:_0x31f97f;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x3adfbb){if(typeof _0x3adfbb!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x3adfbb;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x5f54d4){this['_userLogHandler']=_0x5f54d4;}['debug'](..._0x220916){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x220916),this['_logHandler'](this,T['DEBUG'],..._0x220916);}['log'](..._0x38a744){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x38a744),this['_logHandler'](this,T['VERBOSE'],..._0x38a744);}['info'](..._0x5b3e43){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x5b3e43),this['_logHandler'](this,T['INFO'],..._0x5b3e43);}['warn'](..._0x1da883){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x1da883),this['_logHandler'](this,T['WARN'],..._0x1da883);}['error'](..._0x3a0e32){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x3a0e32),this['_logHandler'](this,T['ERROR'],..._0x3a0e32);}}const xc=(_0x464980,_0x2e67c8)=>_0x2e67c8['some'](_0x4da9d3=>_0x464980 instanceof _0x4da9d3);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x5a9938){const _0x4ef776=new Promise((_0x414a2d,_0x35d97a)=>{const _0x16c357=()=>{_0x5a9938['removeEventListener']('success',_0x2bff00),_0x5a9938['removeEventListener']('error',_0x3e7cd8);},_0x2bff00=()=>{_0x414a2d(_e(_0x5a9938['result'])),_0x16c357();},_0x3e7cd8=()=>{_0x35d97a(_0x5a9938['error']),_0x16c357();};_0x5a9938['addEventListener']('success',_0x2bff00),_0x5a9938['addEventListener']('error',_0x3e7cd8);});return _0x4ef776['then'](_0x44aaf4=>{_0x44aaf4 instanceof IDBCursor&&Jr['set'](_0x44aaf4,_0x5a9938);})['catch'](()=>{}),Wi['set'](_0x4ef776,_0x5a9938),_0x4ef776;}function Bc(_0x5b038f){if(di['has'](_0x5b038f))return;const _0x57bab7=new Promise((_0x2aa161,_0x3b1106)=>{const _0x5a0cfe=()=>{_0x5b038f['removeEventListener']('complete',_0x5ab164),_0x5b038f['removeEventListener']('error',_0x175b72),_0x5b038f['removeEventListener']('abort',_0x175b72);},_0x5ab164=()=>{_0x2aa161(),_0x5a0cfe();},_0x175b72=()=>{_0x3b1106(_0x5b038f['error']||new DOMException('AbortError','AbortError')),_0x5a0cfe();};_0x5b038f['addEventListener']('complete',_0x5ab164),_0x5b038f['addEventListener']('error',_0x175b72),_0x5b038f['addEventListener']('abort',_0x175b72);});di['set'](_0x5b038f,_0x57bab7);}let fi={'get'(_0x1b278a,_0x53306a,_0x3f25cc){if(_0x1b278a instanceof IDBTransaction){if(_0x53306a==='done')return di['get'](_0x1b278a);if(_0x53306a==='objectStoreNames')return _0x1b278a['objectStoreNames']||Xr['get'](_0x1b278a);if(_0x53306a==='store')return _0x3f25cc['objectStoreNames'][0x1]?void 0x0:_0x3f25cc['objectStore'](_0x3f25cc['objectStoreNames'][0x0]);}return _e(_0x1b278a[_0x53306a]);},'set'(_0x3046d6,_0x24d020,_0x5bcbcb){return _0x3046d6[_0x24d020]=_0x5bcbcb,!0x0;},'has'(_0x2cb1a2,_0x20c070){return _0x2cb1a2 instanceof IDBTransaction&&(_0x20c070==='done'||_0x20c070==='store')?!0x0:_0x20c070 in _0x2cb1a2;}};function Vc(_0xd126a3){fi=_0xd126a3(fi);}function Hc(_0x522067){return _0x522067===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x32ebbd,..._0x59a3dd){const _0x52f1b9=_0x522067['call'](Zn(this),_0x32ebbd,..._0x59a3dd);return Xr['set'](_0x52f1b9,_0x32ebbd['sort']?_0x32ebbd['sort']():[_0x32ebbd]),_e(_0x52f1b9);}:Uc()['includes'](_0x522067)?function(..._0x9372a4){return _0x522067['apply'](Zn(this),_0x9372a4),_e(Jr['get'](this));}:function(..._0x5f1423){return _e(_0x522067['apply'](Zn(this),_0x5f1423));};}function $c(_0x52456e){return typeof _0x52456e=='function'?Hc(_0x52456e):(_0x52456e instanceof IDBTransaction&&Bc(_0x52456e),xc(_0x52456e,Fc())?new Proxy(_0x52456e,fi):_0x52456e);}function _e(_0x3e9aa2){if(_0x3e9aa2 instanceof IDBRequest)return Wc(_0x3e9aa2);if(Xn['has'](_0x3e9aa2))return Xn['get'](_0x3e9aa2);const _0x12f0a9=$c(_0x3e9aa2);return _0x12f0a9!==_0x3e9aa2&&(Xn['set'](_0x3e9aa2,_0x12f0a9),Wi['set'](_0x12f0a9,_0x3e9aa2)),_0x12f0a9;}const Zn=_0x544e07=>Wi['get'](_0x544e07);function Gc(_0x4a2107,_0xe71018,{blocked:_0x237789,upgrade:_0x5100e4,blocking:_0x407108,terminated:_0x1ffa25}={}){const _0x3d0aa9=indexedDB['open'](_0x4a2107,_0xe71018),_0x42ac97=_e(_0x3d0aa9);return _0x5100e4&&_0x3d0aa9['addEventListener']('upgradeneeded',_0x283553=>{_0x5100e4(_e(_0x3d0aa9['result']),_0x283553['oldVersion'],_0x283553['newVersion'],_e(_0x3d0aa9['transaction']),_0x283553);}),_0x237789&&_0x3d0aa9['addEventListener']('blocked',_0x308bf7=>_0x237789(_0x308bf7['oldVersion'],_0x308bf7['newVersion'],_0x308bf7)),_0x42ac97['then'](_0x438ec7=>{_0x1ffa25&&_0x438ec7['addEventListener']('close',()=>_0x1ffa25()),_0x407108&&_0x438ec7['addEventListener']('versionchange',_0x52e42e=>_0x407108(_0x52e42e['oldVersion'],_0x52e42e['newVersion'],_0x52e42e));})['catch'](()=>{}),_0x42ac97;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x391747,_0x5e02cf){if(!(_0x391747 instanceof IDBDatabase&&!(_0x5e02cf in _0x391747)&&typeof _0x5e02cf=='string'))return;if(ei['get'](_0x5e02cf))return ei['get'](_0x5e02cf);const _0x59e3f0=_0x5e02cf['replace'](/FromIndex$/,''),_0x5db2b0=_0x5e02cf!==_0x59e3f0,_0x3da71d=zc['includes'](_0x59e3f0);if(!(_0x59e3f0 in(_0x5db2b0?IDBIndex:IDBObjectStore)['prototype'])||!(_0x3da71d||qc['includes'](_0x59e3f0)))return;const _0x425037=async function(_0x4b1583,..._0x15b45c){const _0x266bd6=this['transaction'](_0x4b1583,_0x3da71d?'readwrite':'readonly');let _0x4bad66=_0x266bd6['store'];return _0x5db2b0&&(_0x4bad66=_0x4bad66['index'](_0x15b45c['shift']())),(await Promise['all']([_0x4bad66[_0x59e3f0](..._0x15b45c),_0x3da71d&&_0x266bd6['done']]))[0x0];};return ei['set'](_0x5e02cf,_0x425037),_0x425037;}Vc(_0xacd42f=>({..._0xacd42f,'get':(_0x32dd17,_0x400e2f,_0x42a147)=>Ls(_0x32dd17,_0x400e2f)||_0xacd42f['get'](_0x32dd17,_0x400e2f,_0x42a147),'has':(_0x2d1ad3,_0x4997c9)=>!!Ls(_0x2d1ad3,_0x4997c9)||_0xacd42f['has'](_0x2d1ad3,_0x4997c9)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x4ec165){this['container']=_0x4ec165;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x40a54a=>{if(Kc(_0x40a54a)){const _0x2891ca=_0x40a54a['getImmediate']();return _0x2891ca['library']+'/'+_0x2891ca['version'];}else return null;})['filter'](_0x53aacf=>_0x53aacf)['join']('\x20');}}function Kc(_0x32e2b2){const _0x4b4ba6=_0x32e2b2['getComponent']();return(_0x4b4ba6==null?void 0x0:_0x4b4ba6['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x32b0e3,_0x2ffeb5){try{_0x32b0e3['container']['addComponent'](_0x2ffeb5);}catch(_0x5dcf30){oe['debug']('Component\x20'+_0x2ffeb5['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x32b0e3['name'],_0x5dcf30);}}function Ze(_0x361a96){const _0x1fb93f=_0x361a96['name'];if(mi['has'](_0x1fb93f))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x1fb93f+'.'),!0x1;mi['set'](_0x1fb93f,_0x361a96);for(const _0x3d15d9 of xe['values']())Fs(_0x3d15d9,_0x361a96);for(const _0x3d9c26 of gi['values']())Fs(_0x3d9c26,_0x361a96);return!0x0;}function Bi(_0x148b64,_0xe35d57){const _0x1d7b43=_0x148b64['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x1d7b43&&_0x1d7b43['triggerHeartbeat'](),_0x148b64['container']['getProvider'](_0xe35d57);}function $(_0x2b334e){return _0x2b334e==null?!0x1:_0x2b334e['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0xbb7617,_0x40acd5,_0x5e2128){this['_isDeleted']=!0x1,this['_options']={..._0xbb7617},this['_config']={..._0x40acd5},this['_name']=_0x40acd5['name'],this['_automaticDataCollectionEnabled']=_0x40acd5['automaticDataCollectionEnabled'],this['_container']=_0x5e2128,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x43a06b){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x43a06b;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x5999c0){this['_isDeleted']=_0x5999c0;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x439428,_0x456ea2={}){let _0x329361=_0x439428;typeof _0x456ea2!='object'&&(_0x456ea2={'name':_0x456ea2});const _0x2a71bd={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x456ea2},_0x3b882a=_0x2a71bd['name'];if(typeof _0x3b882a!='string'||!_0x3b882a)throw ge['create']('bad-app-name',{'appName':String(_0x3b882a)});if(_0x329361||(_0x329361=qr()),!_0x329361)throw ge['create']('no-options');const _0xc1afa8=xe['get'](_0x3b882a);if(_0xc1afa8){if(Me(_0x329361,_0xc1afa8['options'])&&Me(_0x2a71bd,_0xc1afa8['config']))return _0xc1afa8;throw ge['create']('duplicate-app',{'appName':_0x3b882a});}const _0x198250=new Pc(_0x3b882a);for(const _0x2bb77e of mi['values']())_0x198250['addComponent'](_0x2bb77e);const _0x211fc1=new Tl(_0x329361,_0x2a71bd,_0x198250);return xe['set'](_0x3b882a,_0x211fc1),_0x211fc1;}function Zr(_0x5c21ec=_i){const _0x91e7a4=xe['get'](_0x5c21ec);if(!_0x91e7a4&&_0x5c21ec===_i&&qr())return Sl();if(!_0x91e7a4)throw ge['create']('no-app',{'appName':_0x5c21ec});return _0x91e7a4;}function f_(){return Array['from'](xe['values']());}async function p_(_0x2836a2){let _0x490aae=!0x1;const _0x4cf841=_0x2836a2['name'];xe['has'](_0x4cf841)?(_0x490aae=!0x0,xe['delete'](_0x4cf841)):gi['has'](_0x4cf841)&&_0x2836a2['decRefCount']()<=0x0&&(gi['delete'](_0x4cf841),_0x490aae=!0x0),_0x490aae&&(await Promise['all'](_0x2836a2['container']['getProviders']()['map'](_0x13caee=>_0x13caee['delete']())),_0x2836a2['isDeleted']=!0x0);}function me(_0xec8d2e,_0x4a2013,_0x3f998d){let _0x1d1423=wl[_0xec8d2e]??_0xec8d2e;_0x3f998d&&(_0x1d1423+='-'+_0x3f998d);const _0x1f4450=_0x1d1423['match'](/\s|\//),_0xcbe1d1=_0x4a2013['match'](/\s|\//);if(_0x1f4450||_0xcbe1d1){const _0x55a47e=['Unable\x20to\x20register\x20library\x20\x22'+_0x1d1423+'\x22\x20with\x20version\x20\x22'+_0x4a2013+'\x22:'];_0x1f4450&&_0x55a47e['push']('library\x20name\x20\x22'+_0x1d1423+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x1f4450&&_0xcbe1d1&&_0x55a47e['push']('and'),_0xcbe1d1&&_0x55a47e['push']('version\x20name\x20\x22'+_0x4a2013+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x55a47e['join']('\x20'));return;}Ze(new Le(_0x1d1423+'-version',()=>({'library':_0x1d1423,'version':_0x4a2013}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x2f2494,_0x559cd7)=>{switch(_0x559cd7){case 0x0:try{_0x2f2494['createObjectStore'](kt);}catch(_0x1c0a7b){console['warn'](_0x1c0a7b);}}}})['catch'](_0xa2ac47=>{throw ge['create']('idb-open',{'originalErrorMessage':_0xa2ac47['message']});})),ti;}async function Al(_0x58c730){try{const _0x3adf46=(await eo())['transaction'](kt),_0x34d5f2=await _0x3adf46['objectStore'](kt)['get'](to(_0x58c730));return await _0x3adf46['done'],_0x34d5f2;}catch(_0x3cb03f){if(_0x3cb03f instanceof Se)oe['warn'](_0x3cb03f['message']);else{const _0x1812b8=ge['create']('idb-get',{'originalErrorMessage':_0x3cb03f==null?void 0x0:_0x3cb03f['message']});oe['warn'](_0x1812b8['message']);}}}async function Us(_0x254143,_0x5efede){try{const _0x200877=(await eo())['transaction'](kt,'readwrite');await _0x200877['objectStore'](kt)['put'](_0x5efede,to(_0x254143)),await _0x200877['done'];}catch(_0x47e4fb){if(_0x47e4fb instanceof Se)oe['warn'](_0x47e4fb['message']);else{const _0x508543=ge['create']('idb-set',{'originalErrorMessage':_0x47e4fb==null?void 0x0:_0x47e4fb['message']});oe['warn'](_0x508543['message']);}}}function to(_0x3f10bd){return _0x3f10bd['name']+'!'+_0x3f10bd['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x552fee){this['container']=_0x552fee,this['_heartbeatsCache']=null;const _0x4c0f32=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x4c0f32),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x1ae36=>(this['_heartbeatsCache']=_0x1ae36,_0x1ae36));}async['triggerHeartbeat'](){var _0x5ca9a3,_0x1d4182;try{const _0x4fd7f6=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x2c96f6=Ws();if(((_0x5ca9a3=this['_heartbeatsCache'])==null?void 0x0:_0x5ca9a3['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x1d4182=this['_heartbeatsCache'])==null?void 0x0:_0x1d4182['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x2c96f6||this['_heartbeatsCache']['heartbeats']['some'](_0x5724f1=>_0x5724f1['date']===_0x2c96f6))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x2c96f6,'agent':_0x4fd7f6}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x598b2b=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x598b2b,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x66d203){oe['warn'](_0x66d203);}}async['getHeartbeatsHeader'](){var _0x27c369;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x27c369=this['_heartbeatsCache'])==null?void 0x0:_0x27c369['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x4c8789=Ws(),{heartbeatsToSend:_0x1223d4,unsentEntries:_0x22b475}=Ol(this['_heartbeatsCache']['heartbeats']),_0xb1a5a2=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x1223d4}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x4c8789,_0x22b475['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x22b475,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0xb1a5a2;}catch(_0x2120ca){return oe['warn'](_0x2120ca),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x4db7be,_0x72d68e=kl){const _0x4d07db=[];let _0x41d04a=_0x4db7be['slice']();for(const _0x4a7226 of _0x4db7be){const _0x51e8fd=_0x4d07db['find'](_0x388062=>_0x388062['agent']===_0x4a7226['agent']);if(_0x51e8fd){if(_0x51e8fd['dates']['push'](_0x4a7226['date']),Bs(_0x4d07db)>_0x72d68e){_0x51e8fd['dates']['pop']();break;}}else{if(_0x4d07db['push']({'agent':_0x4a7226['agent'],'dates':[_0x4a7226['date']]}),Bs(_0x4d07db)>_0x72d68e){_0x4d07db['pop']();break;}}_0x41d04a=_0x41d04a['slice'](0x1);}return{'heartbeatsToSend':_0x4d07db,'unsentEntries':_0x41d04a};}class Dl{constructor(_0x33518a){this['app']=_0x33518a,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0xfadcc=await Al(this['app']);return _0xfadcc!=null&&_0xfadcc['heartbeats']?_0xfadcc:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x3cc0d7){if(await this['_canUseIndexedDBPromise']){const _0x73f5ad=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x3cc0d7['lastSentHeartbeatDate']??_0x73f5ad['lastSentHeartbeatDate'],'heartbeats':_0x3cc0d7['heartbeats']});}else return;}async['add'](_0x48b1be){if(await this['_canUseIndexedDBPromise']){const _0x4b65ae=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x48b1be['lastSentHeartbeatDate']??_0x4b65ae['lastSentHeartbeatDate'],'heartbeats':[..._0x4b65ae['heartbeats'],..._0x48b1be['heartbeats']]});}else return;}}function Bs(_0x5804bd){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x5804bd}))['length'];}function Ml(_0x1879fc){if(_0x1879fc['length']===0x0)return-0x1;let _0x1f94a2=0x0,_0x159170=_0x1879fc[0x0]['date'];for(let _0xd62c65=0x1;_0xd62c65<_0x1879fc['length'];_0xd62c65++)_0x1879fc[_0xd62c65]['date']<_0x159170&&(_0x159170=_0x1879fc[_0xd62c65]['date'],_0x1f94a2=_0xd62c65);return _0x1f94a2;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x1a3a75){Ze(new Le('platform-logger',_0x32511d=>new jc(_0x32511d),'PRIVATE')),Ze(new Le('heartbeat',_0x964d3a=>new Pl(_0x964d3a),'PRIVATE')),me(pi,xs,_0x1a3a75),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x13c33f){no=_0x13c33f;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x5172fc){this['domStorage_']=_0x5172fc,this['prefix_']='firebase:';}['set'](_0x31cf3a,_0x5b67e1){_0x5b67e1==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x31cf3a)):this['domStorage_']['setItem'](this['prefixedName_'](_0x31cf3a),O(_0x5b67e1));}['get'](_0x5007e2){const _0x553185=this['domStorage_']['getItem'](this['prefixedName_'](_0x5007e2));return _0x553185==null?null:At(_0x553185);}['remove'](_0x14c1f8){this['domStorage_']['removeItem'](this['prefixedName_'](_0x14c1f8));}['prefixedName_'](_0x5b38d0){return this['prefix_']+_0x5b38d0;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x53f17e,_0x18b9f6){_0x18b9f6==null?delete this['cache_'][_0x53f17e]:this['cache_'][_0x53f17e]=_0x18b9f6;}['get'](_0x691d47){return J(this['cache_'],_0x691d47)?this['cache_'][_0x691d47]:null;}['remove'](_0x53415b){delete this['cache_'][_0x53415b];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x56ea95){try{if(typeof window<'u'&&typeof window[_0x56ea95]<'u'){const _0x32a263=window[_0x56ea95];return _0x32a263['setItem']('firebase:sentinel','cache'),_0x32a263['removeItem']('firebase:sentinel'),new Wl(_0x32a263);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x1d4fe0=0x1;return function(){return _0x1d4fe0++;};}()),ro=function(_0x3471b3){const _0x4dfc7f=Rc(_0x3471b3),_0x16c988=new Cc();_0x16c988['update'](_0x4dfc7f);const _0x9223b9=_0x16c988['digest']();return Li['encodeByteArray'](_0x9223b9);},Vt=function(..._0x189dee){let _0x299e22='';for(let _0xaa22c4=0x0;_0xaa22c4<_0x189dee['length'];_0xaa22c4++){const _0x550c97=_0x189dee[_0xaa22c4];Array['isArray'](_0x550c97)||_0x550c97&&typeof _0x550c97=='object'&&typeof _0x550c97['length']=='number'?_0x299e22+=Vt['apply'](null,_0x550c97):typeof _0x550c97=='object'?_0x299e22+=O(_0x550c97):_0x299e22+=_0x550c97,_0x299e22+='\x20';}return _0x299e22;};let wt=null,Gs=!0x0;const Hl=function(_0x53aa54,_0x55ffce){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x50c64d){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0xd18025=Vt['apply'](null,_0x50c64d);wt(_0xd18025);}},Ht=function(_0x5191b5){return function(..._0x3743a0){L(_0x5191b5,..._0x3743a0);};},yi=function(..._0x5ad2a6){const _0x5d430b='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x5ad2a6);Ye['error'](_0x5d430b);},ae=function(..._0x33e9b7){const _0x14416c='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x33e9b7);throw Ye['error'](_0x14416c),new Error(_0x14416c);},U=function(..._0x2c4742){const _0x13dc77='FIREBASE\x20WARNING:\x20'+Vt(..._0x2c4742);Ye['warn'](_0x13dc77);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x354ca9){return typeof _0x354ca9=='number'&&(_0x354ca9!==_0x354ca9||_0x354ca9===Number['POSITIVE_INFINITY']||_0x354ca9===Number['NEGATIVE_INFINITY']);},Gl=function(_0x479587){if(document['readyState']==='complete')_0x479587();else{let _0x2ba43f=!0x1;const _0x86102e=function(){if(!document['body']){setTimeout(_0x86102e,Math['floor'](0xa));return;}_0x2ba43f||(_0x2ba43f=!0x0,_0x479587());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x86102e,!0x1),window['addEventListener']('load',_0x86102e,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x86102e();}),window['attachEvent']('onload',_0x86102e));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x43157c,_0x453ee2){if(_0x43157c===_0x453ee2)return 0x0;if(_0x43157c===Fe||_0x453ee2===Ie)return-0x1;if(_0x453ee2===Fe||_0x43157c===Ie)return 0x1;{const _0x18793b=qs(_0x43157c),_0x5a59a7=qs(_0x453ee2);return _0x18793b!==null?_0x5a59a7!==null?_0x18793b-_0x5a59a7===0x0?_0x43157c['length']-_0x453ee2['length']:_0x18793b-_0x5a59a7:-0x1:_0x5a59a7!==null?0x1:_0x43157c<_0x453ee2?-0x1:0x1;}},ql=function(_0x536afe,_0x5d0c3f){return _0x536afe===_0x5d0c3f?0x0:_0x536afe<_0x5d0c3f?-0x1:0x1;},_t=function(_0x33e0d0,_0x581430){if(_0x581430&&_0x33e0d0 in _0x581430)return _0x581430[_0x33e0d0];throw new Error('Missing\x20required\x20key\x20('+_0x33e0d0+')\x20in\x20object:\x20'+O(_0x581430));},Hi=function(_0xffe06c){if(typeof _0xffe06c!='object'||_0xffe06c===null)return O(_0xffe06c);const _0x5da20c=[];for(const _0x4bbb7c in _0xffe06c)_0x5da20c['push'](_0x4bbb7c);_0x5da20c['sort']();let _0x513624='{';for(let _0x120949=0x0;_0x120949<_0x5da20c['length'];_0x120949++)_0x120949!==0x0&&(_0x513624+=','),_0x513624+=O(_0x5da20c[_0x120949]),_0x513624+=':',_0x513624+=Hi(_0xffe06c[_0x5da20c[_0x120949]]);return _0x513624+='}',_0x513624;},oo=function(_0x420003,_0x1ee489){const _0x49d8fc=_0x420003['length'];if(_0x49d8fc<=_0x1ee489)return[_0x420003];const _0x255eb3=[];for(let _0x4d06c=0x0;_0x4d06c<_0x49d8fc;_0x4d06c+=_0x1ee489)_0x4d06c+_0x1ee489>_0x49d8fc?_0x255eb3['push'](_0x420003['substring'](_0x4d06c,_0x49d8fc)):_0x255eb3['push'](_0x420003['substring'](_0x4d06c,_0x4d06c+_0x1ee489));return _0x255eb3;};function x(_0x372c0e,_0x2fb63c){for(const _0x56ab9e in _0x372c0e)_0x372c0e['hasOwnProperty'](_0x56ab9e)&&_0x2fb63c(_0x56ab9e,_0x372c0e[_0x56ab9e]);}const ao=function(_0x14eb24){f(!Vi(_0x14eb24),'Invalid\x20JSON\x20number');const _0x5226ca=0xb,_0x5022e6=0x34,_0x45503b=(0x1<<_0x5226ca-0x1)-0x1;let _0x2da735,_0x4c545f,_0x55d0a7,_0xeeaa51,_0x1c8ac2;_0x14eb24===0x0?(_0x4c545f=0x0,_0x55d0a7=0x0,_0x2da735=0x1/_0x14eb24===-0x1/0x0?0x1:0x0):(_0x2da735=_0x14eb24<0x0,_0x14eb24=Math['abs'](_0x14eb24),_0x14eb24>=Math['pow'](0x2,0x1-_0x45503b)?(_0xeeaa51=Math['min'](Math['floor'](Math['log'](_0x14eb24)/Math['LN2']),_0x45503b),_0x4c545f=_0xeeaa51+_0x45503b,_0x55d0a7=Math['round'](_0x14eb24*Math['pow'](0x2,_0x5022e6-_0xeeaa51)-Math['pow'](0x2,_0x5022e6))):(_0x4c545f=0x0,_0x55d0a7=Math['round'](_0x14eb24/Math['pow'](0x2,0x1-_0x45503b-_0x5022e6))));const _0x1687d5=[];for(_0x1c8ac2=_0x5022e6;_0x1c8ac2;_0x1c8ac2-=0x1)_0x1687d5['push'](_0x55d0a7%0x2?0x1:0x0),_0x55d0a7=Math['floor'](_0x55d0a7/0x2);for(_0x1c8ac2=_0x5226ca;_0x1c8ac2;_0x1c8ac2-=0x1)_0x1687d5['push'](_0x4c545f%0x2?0x1:0x0),_0x4c545f=Math['floor'](_0x4c545f/0x2);_0x1687d5['push'](_0x2da735?0x1:0x0),_0x1687d5['reverse']();const _0x4cca5f=_0x1687d5['join']('');let _0x3ba096='';for(_0x1c8ac2=0x0;_0x1c8ac2<0x40;_0x1c8ac2+=0x8){let _0x234382=parseInt(_0x4cca5f['substr'](_0x1c8ac2,0x8),0x2)['toString'](0x10);_0x234382['length']===0x1&&(_0x234382='0'+_0x234382),_0x3ba096=_0x3ba096+_0x234382;}return _0x3ba096['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x3a39f3,_0x548467){let _0x1cb4a5='Unknown\x20Error';_0x3a39f3==='too_big'?_0x1cb4a5='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x3a39f3==='permission_denied'?_0x1cb4a5='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x3a39f3==='unavailable'&&(_0x1cb4a5='The\x20service\x20is\x20unavailable');const _0x3acef3=new Error(_0x3a39f3+'\x20at\x20'+_0x548467['_path']['toString']()+':\x20'+_0x1cb4a5);return _0x3acef3['code']=_0x3a39f3['toUpperCase'](),_0x3acef3;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x2384ad){if(Yl['test'](_0x2384ad)){const _0x39cdab=Number(_0x2384ad);if(_0x39cdab>=Ql&&_0x39cdab<=Jl)return _0x39cdab;}return null;},ht=function(_0x297b6c){try{_0x297b6c();}catch(_0x53d53c){setTimeout(()=>{const _0x1926c3=_0x53d53c['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x1926c3),_0x53d53c;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x4b3292,_0x37208d){const _0x39a1c2=setTimeout(_0x4b3292,_0x37208d);return typeof _0x39a1c2=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x39a1c2):typeof _0x39a1c2=='object'&&_0x39a1c2['unref']&&_0x39a1c2['unref'](),_0x39a1c2;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x4d2a98,_0x3ce181){this['appCheckProvider']=_0x3ce181,this['appName']=_0x4d2a98['name'],$(_0x4d2a98)&&_0x4d2a98['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x4d2a98['settings']['appCheckToken']),this['appCheck']=_0x3ce181==null?void 0x0:_0x3ce181['getImmediate']({'optional':!0x0}),this['appCheck']||_0x3ce181==null||_0x3ce181['get']()['then'](_0x16e755=>this['appCheck']=_0x16e755);}['getToken'](_0x264d37){if(this['serverAppAppCheckToken']){if(_0x264d37)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x264d37):new Promise((_0x55c804,_0x2ebff7)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x264d37)['then'](_0x55c804,_0x2ebff7):_0x55c804(null);},0x0);});}['addTokenChangeListener'](_0x27c49c){var _0xbc514e;(_0xbc514e=this['appCheckProvider'])==null||_0xbc514e['get']()['then'](_0x50017d=>_0x50017d['addTokenListener'](_0x27c49c));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x5d2865,_0x1d8a33,_0x4de75e){this['appName_']=_0x5d2865,this['firebaseOptions_']=_0x1d8a33,this['authProvider_']=_0x4de75e,this['auth_']=null,this['auth_']=_0x4de75e['getImmediate']({'optional':!0x0}),this['auth_']||_0x4de75e['onInit'](_0x479dd8=>this['auth_']=_0x479dd8);}['getToken'](_0x4e7202){return this['auth_']?this['auth_']['getToken'](_0x4e7202)['catch'](_0x16587c=>_0x16587c&&_0x16587c['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x16587c)):new Promise((_0x15daee,_0x166d61)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x4e7202)['then'](_0x15daee,_0x166d61):_0x15daee(null);},0x0);});}['addTokenChangeListener'](_0x63c7a0){this['auth_']?this['auth_']['addAuthTokenListener'](_0x63c7a0):this['authProvider_']['get']()['then'](_0x1165cf=>_0x1165cf['addAuthTokenListener'](_0x63c7a0));}['removeTokenChangeListener'](_0x4d1558){this['authProvider_']['get']()['then'](_0x1d575c=>_0x1d575c['removeAuthTokenListener'](_0x4d1558));}['notifyForInvalidToken'](){let _0x59c13b='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x59c13b+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x59c13b+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x59c13b+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x59c13b);}}class nn{constructor(_0x169f53){this['accessToken']=_0x169f53;}['getToken'](_0x13b369){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x2dc4d6){_0x2dc4d6(this['accessToken']);}['removeTokenChangeListener'](_0x48a718){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x345184,_0x5edbf3,_0x1a8528,_0x19ab06,_0x4f6782=!0x1,_0x5c103a='',_0x24944d=!0x1,_0x88ac30=!0x1,_0x5c37ee=null){this['secure']=_0x5edbf3,this['namespace']=_0x1a8528,this['webSocketOnly']=_0x19ab06,this['nodeAdmin']=_0x4f6782,this['persistenceKey']=_0x5c103a,this['includeNamespaceInQueryParams']=_0x24944d,this['isUsingEmulator']=_0x88ac30,this['emulatorOptions']=_0x5c37ee,this['_host']=_0x345184['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x345184)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0xc44f34){_0xc44f34!==this['internalHost']&&(this['internalHost']=_0xc44f34,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x1418f3=this['toURLString']();return this['persistenceKey']&&(_0x1418f3+='<'+this['persistenceKey']+'>'),_0x1418f3;}['toURLString'](){const _0x5b1e2e=this['secure']?'https://':'http://',_0x43eec2=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x5b1e2e+this['host']+'/'+_0x43eec2;}}function th(_0x280981){return _0x280981['host']!==_0x280981['internalHost']||_0x280981['isCustomHost']()||_0x280981['includeNamespaceInQueryParams'];}function vo(_0x2aa363,_0xb9a722,_0x4afb2f){f(typeof _0xb9a722=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x4afb2f=='object','typeof\x20params\x20must\x20==\x20object');let _0x3e4d62;if(_0xb9a722===go)_0x3e4d62=(_0x2aa363['secure']?'wss://':'ws://')+_0x2aa363['internalHost']+'/.ws?';else{if(_0xb9a722===mo)_0x3e4d62=(_0x2aa363['secure']?'https://':'http://')+_0x2aa363['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0xb9a722);}th(_0x2aa363)&&(_0x4afb2f['ns']=_0x2aa363['namespace']);const _0x1c380d=[];return x(_0x4afb2f,(_0x3f599a,_0x2a29fd)=>{_0x1c380d['push'](_0x3f599a+'='+_0x2a29fd);}),_0x3e4d62+_0x1c380d['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x65520,_0x5afb20=0x1){J(this['counters_'],_0x65520)||(this['counters_'][_0x65520]=0x0),this['counters_'][_0x65520]+=_0x5afb20;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0xa2167d){const _0x2e90fe=_0xa2167d['toString']();return ni[_0x2e90fe]||(ni[_0x2e90fe]=new nh()),ni[_0x2e90fe];}function ih(_0x91cbe2,_0x5351a1){const _0x2b6ca9=_0x91cbe2['toString']();return ii[_0x2b6ca9]||(ii[_0x2b6ca9]=_0x5351a1()),ii[_0x2b6ca9];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x133820){this['onMessage_']=_0x133820,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x10bf51,_0x2ae5c7){this['closeAfterResponse']=_0x10bf51,this['onClose']=_0x2ae5c7,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x4c07bb,_0xf94867){for(this['pendingResponses'][_0x4c07bb]=_0xf94867;this['pendingResponses'][this['currentResponseNum']];){const _0x3fa95c=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x22f8d4=0x0;_0x22f8d4<_0x3fa95c['length'];++_0x22f8d4)_0x3fa95c[_0x22f8d4]&&ht(()=>{this['onMessage_'](_0x3fa95c[_0x22f8d4]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x78fd18,_0x4807d9,_0x4cd26f,_0x27e669,_0x411584,_0x2573d7,_0x2839d6){this['connId']=_0x78fd18,this['repoInfo']=_0x4807d9,this['applicationId']=_0x4cd26f,this['appCheckToken']=_0x27e669,this['authToken']=_0x411584,this['transportSessionId']=_0x2573d7,this['lastSessionId']=_0x2839d6,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x78fd18),this['stats_']=Gi(_0x4807d9),this['urlFn']=_0x23393e=>(this['appCheckToken']&&(_0x23393e[vi]=this['appCheckToken']),vo(_0x4807d9,mo,_0x23393e));}['open'](_0x4c2059,_0xb5bd0d){this['curSegmentNum']=0x0,this['onDisconnect_']=_0xb5bd0d,this['myPacketOrderer']=new sh(_0x4c2059),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x2030f4)=>{const [_0x1ff7c8,_0x283a72,_0x30a89d,_0x2e5e41,_0x50e221]=_0x2030f4;if(this['incrementIncomingBytes_'](_0x2030f4),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x1ff7c8===zs)this['id']=_0x283a72,this['password']=_0x30a89d;else{if(_0x1ff7c8===rh)_0x283a72?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x283a72,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x1ff7c8);}}},(..._0x49961e)=>{const [_0x2f5655,_0x48c918]=_0x49961e;this['incrementIncomingBytes_'](_0x49961e),this['myPacketOrderer']['handleResponse'](_0x2f5655,_0x48c918);},()=>{this['onClosed_']();},this['urlFn']);const _0x3f57e0={};_0x3f57e0[zs]='t',_0x3f57e0[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x3f57e0[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x3f57e0[co]=$i,this['transportSessionId']&&(_0x3f57e0[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x3f57e0[po]=this['lastSessionId']),this['applicationId']&&(_0x3f57e0[_o]=this['applicationId']),this['appCheckToken']&&(_0x3f57e0[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3f57e0[ho]=uo);const _0x4bf50f=this['urlFn'](_0x3f57e0);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4bf50f),this['scriptTagHolder']['addTag'](_0x4bf50f,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x237b9d){const _0x2feb5c=O(_0x237b9d);this['bytesSent']+=_0x2feb5c['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2feb5c['length']);const _0x5171a8=Hr(_0x2feb5c),_0x3b8102=oo(_0x5171a8,fh);for(let _0x361527=0x0;_0x361527<_0x3b8102['length'];_0x361527++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3b8102['length'],_0x3b8102[_0x361527]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x508592,_0x39b388){this['myDisconnFrame']=document['createElement']('iframe');const _0x405746={};_0x405746[dh]='t',_0x405746[Eo]=_0x508592,_0x405746[Io]=_0x39b388,this['myDisconnFrame']['src']=this['urlFn'](_0x405746),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x2cd6c){const _0x1f9049=O(_0x2cd6c)['length'];this['bytesReceived']+=_0x1f9049,this['stats_']['incrementCounter']('bytes_received',_0x1f9049);}}class qi{constructor(_0x38d413,_0x10fec0,_0x1fc156,_0x5d2e3a){this['onDisconnect']=_0x1fc156,this['urlFn']=_0x5d2e3a,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x38d413,window[ah+this['uniqueCallbackIdentifier']]=_0x10fec0,this['myIFrame']=qi['createIFrame_']();let _0x4fe142='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x4fe142='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x132af6='<html><body>'+_0x4fe142+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x132af6),this['myIFrame']['doc']['close']();}catch(_0x6883e0){L('frame\x20writing\x20exception'),_0x6883e0['stack']&&L(_0x6883e0['stack']),L(_0x6883e0);}}}static['createIFrame_'](){const _0xdf985e=document['createElement']('iframe');if(_0xdf985e['style']['display']='none',document['body']){document['body']['appendChild'](_0xdf985e);try{_0xdf985e['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x29c175=document['domain'];_0xdf985e['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x29c175+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0xdf985e['contentDocument']?_0xdf985e['doc']=_0xdf985e['contentDocument']:_0xdf985e['contentWindow']?_0xdf985e['doc']=_0xdf985e['contentWindow']['document']:_0xdf985e['document']&&(_0xdf985e['doc']=_0xdf985e['document']),_0xdf985e;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x4ef089=this['onDisconnect'];_0x4ef089&&(this['onDisconnect']=null,_0x4ef089());}['startLongPoll'](_0x4178ff,_0x5eac26){for(this['myID']=_0x4178ff,this['myPW']=_0x5eac26,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x2a37f6={};_0x2a37f6[Eo]=this['myID'],_0x2a37f6[Io]=this['myPW'],_0x2a37f6[wo]=this['currentSerial'];let _0x36193e=this['urlFn'](_0x2a37f6),_0x51ec42='',_0x508442=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x51ec42['length']<=Co;){const _0x4e71f8=this['pendingSegs']['shift']();_0x51ec42=_0x51ec42+'&'+lh+_0x508442+'='+_0x4e71f8['seg']+'&'+hh+_0x508442+'='+_0x4e71f8['ts']+'&'+uh+_0x508442+'='+_0x4e71f8['d'],_0x508442++;}return _0x36193e=_0x36193e+_0x51ec42,this['addLongPollTag_'](_0x36193e,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0xd3b468,_0x839b18,_0x496a3e){this['pendingSegs']['push']({'seg':_0xd3b468,'ts':_0x839b18,'d':_0x496a3e}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x43fe55,_0x25fe81){this['outstandingRequests']['add'](_0x25fe81);const _0x3a8212=()=>{this['outstandingRequests']['delete'](_0x25fe81),this['newRequest_']();},_0x192038=setTimeout(_0x3a8212,Math['floor'](ph)),_0x51b5a9=()=>{clearTimeout(_0x192038),_0x3a8212();};this['addTag'](_0x43fe55,_0x51b5a9);}['addTag'](_0x139f74,_0x550bfb){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x154d59=this['myIFrame']['doc']['createElement']('script');_0x154d59['type']='text/javascript',_0x154d59['async']=!0x0,_0x154d59['src']=_0x139f74,_0x154d59['onload']=_0x154d59['onreadystatechange']=function(){const _0xc0a237=_0x154d59['readyState'];(!_0xc0a237||_0xc0a237==='loaded'||_0xc0a237==='complete')&&(_0x154d59['onload']=_0x154d59['onreadystatechange']=null,_0x154d59['parentNode']&&_0x154d59['parentNode']['removeChild'](_0x154d59),_0x550bfb());},_0x154d59['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x139f74),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x154d59);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x440a72,_0x13f2c6,_0x188f1b,_0x1be960,_0x2aa54b,_0x581560,_0x423ba0){this['connId']=_0x440a72,this['applicationId']=_0x188f1b,this['appCheckToken']=_0x1be960,this['authToken']=_0x2aa54b,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x13f2c6),this['connURL']=z['connectionURL_'](_0x13f2c6,_0x581560,_0x423ba0,_0x1be960,_0x188f1b),this['nodeAdmin']=_0x13f2c6['nodeAdmin'];}static['connectionURL_'](_0x485dfe,_0x39c12a,_0x3f52ff,_0x5d2df7,_0x276409){const _0x408aea={};return _0x408aea[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x408aea[ho]=uo),_0x39c12a&&(_0x408aea[lo]=_0x39c12a),_0x3f52ff&&(_0x408aea[po]=_0x3f52ff),_0x5d2df7&&(_0x408aea[vi]=_0x5d2df7),_0x276409&&(_0x408aea[_o]=_0x276409),vo(_0x485dfe,go,_0x408aea);}['open'](_0x58d89f,_0x54b3dc){this['onDisconnect']=_0x54b3dc,this['onMessage']=_0x58d89f,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x18d42d;_c(),this['mySock']=new un(this['connURL'],[],_0x18d42d);}catch(_0x261359){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x1d55c1=_0x261359['message']||_0x261359['data'];_0x1d55c1&&this['log_'](_0x1d55c1),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x2653fd=>{this['handleIncomingFrame'](_0x2653fd);},this['mySock']['onerror']=_0x18b063=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x5a5c2=_0x18b063['message']||_0x18b063['data'];_0x5a5c2&&this['log_'](_0x5a5c2),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x1491a9=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x1268e7=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x28dee8=navigator['userAgent']['match'](_0x1268e7);_0x28dee8&&_0x28dee8['length']>0x1&&parseFloat(_0x28dee8[0x1])<4.4&&(_0x1491a9=!0x0);}return!_0x1491a9&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x4623e8){if(this['frames']['push'](_0x4623e8),this['frames']['length']===this['totalFrames']){const _0x3a9897=this['frames']['join']('');this['frames']=null;const _0x5555f4=At(_0x3a9897);this['onMessage'](_0x5555f4);}}['handleNewFrameCount_'](_0x2170f6){this['totalFrames']=_0x2170f6,this['frames']=[];}['extractFrameCount_'](_0x432b3a){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x432b3a['length']<=0x6){const _0x4878eb=Number(_0x432b3a);if(!isNaN(_0x4878eb))return this['handleNewFrameCount_'](_0x4878eb),null;}return this['handleNewFrameCount_'](0x1),_0x432b3a;}['handleIncomingFrame'](_0x131d42){if(this['mySock']===null)return;const _0x4e05c1=_0x131d42['data'];if(this['bytesReceived']+=_0x4e05c1['length'],this['stats_']['incrementCounter']('bytes_received',_0x4e05c1['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x4e05c1);else{const _0x20db49=this['extractFrameCount_'](_0x4e05c1);_0x20db49!==null&&this['appendFrame_'](_0x20db49);}}['send'](_0x2f669c){this['resetKeepAlive']();const _0x11b393=O(_0x2f669c);this['bytesSent']+=_0x11b393['length'],this['stats_']['incrementCounter']('bytes_sent',_0x11b393['length']);const _0x392a39=oo(_0x11b393,gh);_0x392a39['length']>0x1&&this['sendString_'](String(_0x392a39['length']));for(let _0x2b5f00=0x0;_0x2b5f00<_0x392a39['length'];_0x2b5f00++)this['sendString_'](_0x392a39[_0x2b5f00]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x3b2972){try{this['mySock']['send'](_0x3b2972);}catch(_0x4633e2){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x4633e2['message']||_0x4633e2['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5a9718){this['initTransports_'](_0x5a9718);}['initTransports_'](_0x205a40){const _0x9d9549=z&&z['isAvailable']();let _0x47854b=_0x9d9549&&!z['previouslyFailed']();if(_0x205a40['webSocketOnly']&&(_0x9d9549||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x47854b=!0x0),_0x47854b)this['transports_']=[z];else{const _0x3e189b=this['transports_']=[];for(const _0x3fa051 of Nt['ALL_TRANSPORTS'])_0x3fa051&&_0x3fa051['isAvailable']()&&_0x3e189b['push'](_0x3fa051);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x5124ec,_0xd0963a,_0x31c9a3,_0x1e2e8a,_0x5770bf,_0x26a7f7,_0xdf2f5b,_0x5e32c6,_0x2ded65,_0x43ab07){this['id']=_0x5124ec,this['repoInfo_']=_0xd0963a,this['applicationId_']=_0x31c9a3,this['appCheckToken_']=_0x1e2e8a,this['authToken_']=_0x5770bf,this['onMessage_']=_0x26a7f7,this['onReady_']=_0xdf2f5b,this['onDisconnect_']=_0x5e32c6,this['onKill_']=_0x2ded65,this['lastSessionId']=_0x43ab07,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0xd0963a),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x57aefd=this['transportManager_']['initialTransport']();this['conn_']=new _0x57aefd(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x57aefd['responsesRequiredToBeHealthy']||0x0;const _0x2f7d45=this['connReceiver_'](this['conn_']),_0x464235=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x2f7d45,_0x464235);},Math['floor'](0x0));const _0x5af971=_0x57aefd['healthyTimeout']||0x0;_0x5af971>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x5af971)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x205003){return _0x65ec19=>{_0x205003===this['conn_']?this['onConnectionLost_'](_0x65ec19):_0x205003===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x1492c1){return _0x508b3e=>{this['state_']!==0x2&&(_0x1492c1===this['rx_']?this['onPrimaryMessageReceived_'](_0x508b3e):_0x1492c1===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x508b3e):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x48b955){const _0x1671aa={'t':'d','d':_0x48b955};this['sendData_'](_0x1671aa);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x316172){if(si in _0x316172){const _0x3a53ac=_0x316172[si];_0x3a53ac===Qs?this['upgradeIfSecondaryHealthy_']():_0x3a53ac===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x3a53ac===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x3a21ea){const _0x44e20e=_t('t',_0x3a21ea),_0x4178bf=_t('d',_0x3a21ea);if(_0x44e20e==='c')this['onSecondaryControl_'](_0x4178bf);else{if(_0x44e20e==='d')this['pendingDataMessages']['push'](_0x4178bf);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x44e20e);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x4938bf){const _0x5d6134=_t('t',_0x4938bf),_0x4a6493=_t('d',_0x4938bf);_0x5d6134==='c'?this['onControl_'](_0x4a6493):_0x5d6134==='d'&&this['onDataMessage_'](_0x4a6493);}['onDataMessage_'](_0x3aecb2){this['onPrimaryResponse_'](),this['onMessage_'](_0x3aecb2);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x3ef701){const _0x201673=_t(si,_0x3ef701);if(js in _0x3ef701){const _0x4a56dc=_0x3ef701[js];if(_0x201673===Th){const _0x42870c={..._0x4a56dc};this['repoInfo_']['isUsingEmulator']&&(_0x42870c['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x42870c);}else{if(_0x201673===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x16290d=0x0;_0x16290d<this['pendingDataMessages']['length'];++_0x16290d)this['onDataMessage_'](this['pendingDataMessages'][_0x16290d]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x201673===wh?this['onConnectionShutdown_'](_0x4a56dc):_0x201673===Ks?this['onReset_'](_0x4a56dc):_0x201673===Ch?yi('Server\x20Error:\x20'+_0x4a56dc):_0x201673===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x201673);}}}['onHandshake_'](_0x357536){const _0xbb7b5d=_0x357536['ts'],_0xb24cbd=_0x357536['v'],_0x49d7b1=_0x357536['h'];this['sessionId']=_0x357536['s'],this['repoInfo_']['host']=_0x49d7b1,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0xbb7b5d),$i!==_0xb24cbd&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x5a4ab6=this['transportManager_']['upgradeTransport']();_0x5a4ab6&&this['startUpgrade_'](_0x5a4ab6);}['startUpgrade_'](_0x1be183){this['secondaryConn_']=new _0x1be183(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x1be183['responsesRequiredToBeHealthy']||0x0;const _0xca3831=this['connReceiver_'](this['secondaryConn_']),_0x54755b=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0xca3831,_0x54755b),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x36e71d){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x36e71d),this['repoInfo_']['host']=_0x36e71d,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x1bc05f,_0xd700ee){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x1bc05f,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0xd700ee,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x270295=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x270295||this['rx_']===_0x270295)&&this['close']();}['onConnectionLost_'](_0x3afcc5){this['conn_']=null,!_0x3afcc5&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x5e7ea9){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x5e7ea9),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x536860){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x536860);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x525d8b,_0x52291c,_0xaa9c5d,_0x75fdb8){}['merge'](_0x264776,_0x51714b,_0x3e3a34,_0x1d8d85){}['refreshAuthToken'](_0x5676b1){}['refreshAppCheckToken'](_0x7e1bc){}['onDisconnectPut'](_0x7bc6cc,_0x5e938e,_0x2228d0){}['onDisconnectMerge'](_0x351ba6,_0x274193,_0xc1750f){}['onDisconnectCancel'](_0x557c06,_0x3829e5){}['reportStats'](_0x368234){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x11db14){this['allowedEvents_']=_0x11db14,this['listeners_']={},f(Array['isArray'](_0x11db14)&&_0x11db14['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x430cc5,..._0x59a1e8){if(Array['isArray'](this['listeners_'][_0x430cc5])){const _0x1eebec=[...this['listeners_'][_0x430cc5]];for(let _0x3014ed=0x0;_0x3014ed<_0x1eebec['length'];_0x3014ed++)_0x1eebec[_0x3014ed]['callback']['apply'](_0x1eebec[_0x3014ed]['context'],_0x59a1e8);}}['on'](_0x3fea58,_0x4c3b0a,_0x448f05){this['validateEventType_'](_0x3fea58),this['listeners_'][_0x3fea58]=this['listeners_'][_0x3fea58]||[],this['listeners_'][_0x3fea58]['push']({'callback':_0x4c3b0a,'context':_0x448f05});const _0x335bce=this['getInitialEvent'](_0x3fea58);_0x335bce&&_0x4c3b0a['apply'](_0x448f05,_0x335bce);}['off'](_0x4423d8,_0x4b3a0a,_0x119dbf){this['validateEventType_'](_0x4423d8);const _0x5797b5=this['listeners_'][_0x4423d8]||[];for(let _0x32b00b=0x0;_0x32b00b<_0x5797b5['length'];_0x32b00b++)if(_0x5797b5[_0x32b00b]['callback']===_0x4b3a0a&&(!_0x119dbf||_0x119dbf===_0x5797b5[_0x32b00b]['context'])){_0x5797b5['splice'](_0x32b00b,0x1);return;}}['validateEventType_'](_0x40eb64){f(this['allowedEvents_']['find'](_0x5af08a=>_0x5af08a===_0x40eb64),'Unknown\x20event:\x20'+_0x40eb64);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x3e627a){return f(_0x3e627a==='online','Unknown\x20event\x20type:\x20'+_0x3e627a),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x23bcaa,_0x4dec74){if(_0x4dec74===void 0x0){this['pieces_']=_0x23bcaa['split']('/');let _0x36acd2=0x0;for(let _0x6600c5=0x0;_0x6600c5<this['pieces_']['length'];_0x6600c5++)this['pieces_'][_0x6600c5]['length']>0x0&&(this['pieces_'][_0x36acd2]=this['pieces_'][_0x6600c5],_0x36acd2++);this['pieces_']['length']=_0x36acd2,this['pieceNum_']=0x0;}else this['pieces_']=_0x23bcaa,this['pieceNum_']=_0x4dec74;}['toString'](){let _0x35950c='';for(let _0x4f3a77=this['pieceNum_'];_0x4f3a77<this['pieces_']['length'];_0x4f3a77++)this['pieces_'][_0x4f3a77]!==''&&(_0x35950c+='/'+this['pieces_'][_0x4f3a77]);return _0x35950c||'/';}}function w(){return new C('');}function y(_0x3d609c){return _0x3d609c['pieceNum_']>=_0x3d609c['pieces_']['length']?null:_0x3d609c['pieces_'][_0x3d609c['pieceNum_']];}function we(_0x23f7df){return _0x23f7df['pieces_']['length']-_0x23f7df['pieceNum_'];}function b(_0x4d9757){let _0x206033=_0x4d9757['pieceNum_'];return _0x206033<_0x4d9757['pieces_']['length']&&_0x206033++,new C(_0x4d9757['pieces_'],_0x206033);}function zi(_0x57145c){return _0x57145c['pieceNum_']<_0x57145c['pieces_']['length']?_0x57145c['pieces_'][_0x57145c['pieces_']['length']-0x1]:null;}function bh(_0x384f12){let _0x46dbb5='';for(let _0x4723df=_0x384f12['pieceNum_'];_0x4723df<_0x384f12['pieces_']['length'];_0x4723df++)_0x384f12['pieces_'][_0x4723df]!==''&&(_0x46dbb5+='/'+encodeURIComponent(String(_0x384f12['pieces_'][_0x4723df])));return _0x46dbb5||'/';}function Pt(_0xfdb54b,_0x2b6c6a=0x0){return _0xfdb54b['pieces_']['slice'](_0xfdb54b['pieceNum_']+_0x2b6c6a);}function Ro(_0x21f388){if(_0x21f388['pieceNum_']>=_0x21f388['pieces_']['length'])return null;const _0x42c8e8=[];for(let _0x3bdf43=_0x21f388['pieceNum_'];_0x3bdf43<_0x21f388['pieces_']['length']-0x1;_0x3bdf43++)_0x42c8e8['push'](_0x21f388['pieces_'][_0x3bdf43]);return new C(_0x42c8e8,0x0);}function k(_0x5ecc25,_0x234d9c){const _0x926543=[];for(let _0xfd06eb=_0x5ecc25['pieceNum_'];_0xfd06eb<_0x5ecc25['pieces_']['length'];_0xfd06eb++)_0x926543['push'](_0x5ecc25['pieces_'][_0xfd06eb]);if(_0x234d9c instanceof C){for(let _0xfc25bd=_0x234d9c['pieceNum_'];_0xfc25bd<_0x234d9c['pieces_']['length'];_0xfc25bd++)_0x926543['push'](_0x234d9c['pieces_'][_0xfc25bd]);}else{const _0xbc9b72=_0x234d9c['split']('/');for(let _0x543971=0x0;_0x543971<_0xbc9b72['length'];_0x543971++)_0xbc9b72[_0x543971]['length']>0x0&&_0x926543['push'](_0xbc9b72[_0x543971]);}return new C(_0x926543,0x0);}function v(_0x2cf411){return _0x2cf411['pieceNum_']>=_0x2cf411['pieces_']['length'];}function F(_0x1b09a3,_0xcacaab){const _0x163c52=y(_0x1b09a3),_0x33df50=y(_0xcacaab);if(_0x163c52===null)return _0xcacaab;if(_0x163c52===_0x33df50)return F(b(_0x1b09a3),b(_0xcacaab));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0xcacaab+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1b09a3+')');}function Rh(_0x28f82b,_0x1acb53){const _0x170272=Pt(_0x28f82b,0x0),_0x5de246=Pt(_0x1acb53,0x0);for(let _0x1f63ca=0x0;_0x1f63ca<_0x170272['length']&&_0x1f63ca<_0x5de246['length'];_0x1f63ca++){const _0x345f0f=He(_0x170272[_0x1f63ca],_0x5de246[_0x1f63ca]);if(_0x345f0f!==0x0)return _0x345f0f;}return _0x170272['length']===_0x5de246['length']?0x0:_0x170272['length']<_0x5de246['length']?-0x1:0x1;}function ji(_0x2c2626,_0x12cef4){if(we(_0x2c2626)!==we(_0x12cef4))return!0x1;for(let _0x29e276=_0x2c2626['pieceNum_'],_0x4673da=_0x12cef4['pieceNum_'];_0x29e276<=_0x2c2626['pieces_']['length'];_0x29e276++,_0x4673da++)if(_0x2c2626['pieces_'][_0x29e276]!==_0x12cef4['pieces_'][_0x4673da])return!0x1;return!0x0;}function G(_0x2f8d09,_0x2b0b85){let _0x59df8a=_0x2f8d09['pieceNum_'],_0x58d700=_0x2b0b85['pieceNum_'];if(we(_0x2f8d09)>we(_0x2b0b85))return!0x1;for(;_0x59df8a<_0x2f8d09['pieces_']['length'];){if(_0x2f8d09['pieces_'][_0x59df8a]!==_0x2b0b85['pieces_'][_0x58d700])return!0x1;++_0x59df8a,++_0x58d700;}return!0x0;}class Ah{constructor(_0x4f1265,_0x2afc48){this['errorPrefix_']=_0x2afc48,this['parts_']=Pt(_0x4f1265,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x3a310a=0x0;_0x3a310a<this['parts_']['length'];_0x3a310a++)this['byteLength_']+=On(this['parts_'][_0x3a310a]);Ao(this);}}function kh(_0x257bef,_0x32f498){_0x257bef['parts_']['length']>0x0&&(_0x257bef['byteLength_']+=0x1),_0x257bef['parts_']['push'](_0x32f498),_0x257bef['byteLength_']+=On(_0x32f498),Ao(_0x257bef);}function Nh(_0xc3de32){const _0x3a1679=_0xc3de32['parts_']['pop']();_0xc3de32['byteLength_']-=On(_0x3a1679),_0xc3de32['parts_']['length']>0x0&&(_0xc3de32['byteLength_']-=0x1);}function Ao(_0x45ff01){if(_0x45ff01['byteLength_']>er)throw new Error(_0x45ff01['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x45ff01['byteLength_']+').');if(_0x45ff01['parts_']['length']>Zs)throw new Error(_0x45ff01['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x45ff01));}function Pe(_0x321311){return _0x321311['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x321311['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x229cab,_0x190547;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x190547='visibilitychange',_0x229cab='hidden'):typeof document['mozHidden']<'u'?(_0x190547='mozvisibilitychange',_0x229cab='mozHidden'):typeof document['msHidden']<'u'?(_0x190547='msvisibilitychange',_0x229cab='msHidden'):typeof document['webkitHidden']<'u'&&(_0x190547='webkitvisibilitychange',_0x229cab='webkitHidden')),this['visible_']=!0x0,_0x190547&&document['addEventListener'](_0x190547,()=>{const _0x545bee=!document[_0x229cab];_0x545bee!==this['visible_']&&(this['visible_']=_0x545bee,this['trigger']('visible',_0x545bee));},!0x1);}['getInitialEvent'](_0x10836e){return f(_0x10836e==='visible','Unknown\x20event\x20type:\x20'+_0x10836e),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x1aa2ff,_0x56185b,_0x449658,_0x32c644,_0x5dfa40,_0x4300c0,_0x3a2037,_0x43bce6){if(super(),this['repoInfo_']=_0x1aa2ff,this['applicationId_']=_0x56185b,this['onDataUpdate_']=_0x449658,this['onConnectStatus_']=_0x32c644,this['onServerInfoUpdate_']=_0x5dfa40,this['authTokenProvider_']=_0x4300c0,this['appCheckTokenProvider_']=_0x3a2037,this['authOverride_']=_0x43bce6,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x43bce6)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x1aa2ff['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0xb6ba8d,_0x34168a,_0x5437c9){const _0x344e9d=++this['requestNumber_'],_0x1e1f53={'r':_0x344e9d,'a':_0xb6ba8d,'b':_0x34168a};this['log_'](O(_0x1e1f53)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x1e1f53),_0x5437c9&&(this['requestCBHash_'][_0x344e9d]=_0x5437c9);}['get'](_0x26466d){this['initConnection_']();const _0x2e3521=new ot(),_0x5e5602={'action':'g','request':{'p':_0x26466d['_path']['toString'](),'q':_0x26466d['_queryObject']},'onComplete':_0xae0108=>{const _0x130feb=_0xae0108['d'];_0xae0108['s']==='ok'?_0x2e3521['resolve'](_0x130feb):_0x2e3521['reject'](_0x130feb);}};this['outstandingGets_']['push'](_0x5e5602),this['outstandingGetCount_']++;const _0x559730=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x559730),_0x2e3521['promise'];}['listen'](_0x29f63f,_0x192db5,_0x3af92d,_0x4d1698){this['initConnection_']();const _0x5441bc=_0x29f63f['_queryIdentifier'],_0x3287e1=_0x29f63f['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3287e1+'\x20'+_0x5441bc),this['listens']['has'](_0x3287e1)||this['listens']['set'](_0x3287e1,new Map()),f(_0x29f63f['_queryParams']['isDefault']()||!_0x29f63f['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3287e1)['has'](_0x5441bc),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x48ae39={'onComplete':_0x4d1698,'hashFn':_0x192db5,'query':_0x29f63f,'tag':_0x3af92d};this['listens']['get'](_0x3287e1)['set'](_0x5441bc,_0x48ae39),this['connected_']&&this['sendListen_'](_0x48ae39);}['sendGet_'](_0x2113b9){const _0x99e69=this['outstandingGets_'][_0x2113b9];this['sendRequest']('g',_0x99e69['request'],_0x1a0d0e=>{delete this['outstandingGets_'][_0x2113b9],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x99e69['onComplete']&&_0x99e69['onComplete'](_0x1a0d0e);});}['sendListen_'](_0x3e4ca4){const _0x447929=_0x3e4ca4['query'],_0x481d52=_0x447929['_path']['toString'](),_0x2ce90b=_0x447929['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x481d52+'\x20for\x20'+_0x2ce90b);const _0x3f1b76={'p':_0x481d52},_0x3a2205='q';_0x3e4ca4['tag']&&(_0x3f1b76['q']=_0x447929['_queryObject'],_0x3f1b76['t']=_0x3e4ca4['tag']),_0x3f1b76['h']=_0x3e4ca4['hashFn'](),this['sendRequest'](_0x3a2205,_0x3f1b76,_0x17cb0d=>{const _0x3ee06c=_0x17cb0d['d'],_0x572e32=_0x17cb0d['s'];se['warnOnListenWarnings_'](_0x3ee06c,_0x447929),(this['listens']['get'](_0x481d52)&&this['listens']['get'](_0x481d52)['get'](_0x2ce90b))===_0x3e4ca4&&(this['log_']('listen\x20response',_0x17cb0d),_0x572e32!=='ok'&&this['removeListen_'](_0x481d52,_0x2ce90b),_0x3e4ca4['onComplete']&&_0x3e4ca4['onComplete'](_0x572e32,_0x3ee06c));});}static['warnOnListenWarnings_'](_0x12ac3a,_0x30d416){if(_0x12ac3a&&typeof _0x12ac3a=='object'&&J(_0x12ac3a,'w')){const _0x58c8c2=De(_0x12ac3a,'w');if(Array['isArray'](_0x58c8c2)&&~_0x58c8c2['indexOf']('no_index')){const _0x15b9f8='\x22.indexOn\x22:\x20\x22'+_0x30d416['_queryParams']['getIndex']()['toString']()+'\x22',_0x447256=_0x30d416['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x15b9f8+'\x20at\x20'+_0x447256+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x170291){this['authToken_']=_0x170291,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x170291);}['reduceReconnectDelayIfAdminCredential_'](_0x40e894){(_0x40e894&&_0x40e894['length']===0x28||wc(_0x40e894))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x53d8e7){this['appCheckToken_']=_0x53d8e7,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x197ac5=this['authToken_'],_0x5cf12e=Ic(_0x197ac5)?'auth':'gauth',_0x5b8e96={'cred':_0x197ac5};this['authOverride_']===null?_0x5b8e96['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x5b8e96['authvar']=this['authOverride_']),this['sendRequest'](_0x5cf12e,_0x5b8e96,_0x50cd69=>{const _0x58bce3=_0x50cd69['s'],_0x2ba42e=_0x50cd69['d']||'error';this['authToken_']===_0x197ac5&&(_0x58bce3==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x58bce3,_0x2ba42e));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x5ce4e1=>{const _0xae6b3d=_0x5ce4e1['s'],_0x2bddc8=_0x5ce4e1['d']||'error';_0xae6b3d==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0xae6b3d,_0x2bddc8);});}['unlisten'](_0x1bd3b6,_0x25f948){const _0x1dca0d=_0x1bd3b6['_path']['toString'](),_0x23279c=_0x1bd3b6['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x1dca0d+'\x20'+_0x23279c),f(_0x1bd3b6['_queryParams']['isDefault']()||!_0x1bd3b6['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x1dca0d,_0x23279c)&&this['connected_']&&this['sendUnlisten_'](_0x1dca0d,_0x23279c,_0x1bd3b6['_queryObject'],_0x25f948);}['sendUnlisten_'](_0x568804,_0x23fe54,_0x27e04c,_0x2c6e42){this['log_']('Unlisten\x20on\x20'+_0x568804+'\x20for\x20'+_0x23fe54);const _0x3bf71f={'p':_0x568804},_0x27c22e='n';_0x2c6e42&&(_0x3bf71f['q']=_0x27e04c,_0x3bf71f['t']=_0x2c6e42),this['sendRequest'](_0x27c22e,_0x3bf71f);}['onDisconnectPut'](_0x1996c5,_0x4b44da,_0x1fa50b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x1996c5,_0x4b44da,_0x1fa50b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1996c5,'action':'o','data':_0x4b44da,'onComplete':_0x1fa50b});}['onDisconnectMerge'](_0x5b5e70,_0x42493f,_0x1abfa3){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x5b5e70,_0x42493f,_0x1abfa3):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5b5e70,'action':'om','data':_0x42493f,'onComplete':_0x1abfa3});}['onDisconnectCancel'](_0x23611b,_0x5bd32b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x23611b,null,_0x5bd32b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x23611b,'action':'oc','data':null,'onComplete':_0x5bd32b});}['sendOnDisconnect_'](_0x4cbcc4,_0x3828aa,_0xaecd9b,_0x4d3033){const _0x4bae57={'p':_0x3828aa,'d':_0xaecd9b};this['log_']('onDisconnect\x20'+_0x4cbcc4,_0x4bae57),this['sendRequest'](_0x4cbcc4,_0x4bae57,_0xa8fd83=>{_0x4d3033&&setTimeout(()=>{_0x4d3033(_0xa8fd83['s'],_0xa8fd83['d']);},Math['floor'](0x0));});}['put'](_0x145761,_0x1a96d8,_0x5446d2,_0x6ea943){this['putInternal']('p',_0x145761,_0x1a96d8,_0x5446d2,_0x6ea943);}['merge'](_0x36ab7e,_0x2d0843,_0x5221fd,_0x1d1242){this['putInternal']('m',_0x36ab7e,_0x2d0843,_0x5221fd,_0x1d1242);}['putInternal'](_0x44baf8,_0x1cc3af,_0x2ec9da,_0x1aaf80,_0x54b3e4){this['initConnection_']();const _0x14a07e={'p':_0x1cc3af,'d':_0x2ec9da};_0x54b3e4!==void 0x0&&(_0x14a07e['h']=_0x54b3e4),this['outstandingPuts_']['push']({'action':_0x44baf8,'request':_0x14a07e,'onComplete':_0x1aaf80}),this['outstandingPutCount_']++;const _0x406c53=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x406c53):this['log_']('Buffering\x20put:\x20'+_0x1cc3af);}['sendPut_'](_0x37403c){const _0x4cd26d=this['outstandingPuts_'][_0x37403c]['action'],_0x222655=this['outstandingPuts_'][_0x37403c]['request'],_0x5e535b=this['outstandingPuts_'][_0x37403c]['onComplete'];this['outstandingPuts_'][_0x37403c]['queued']=this['connected_'],this['sendRequest'](_0x4cd26d,_0x222655,_0x1a3a91=>{this['log_'](_0x4cd26d+'\x20response',_0x1a3a91),delete this['outstandingPuts_'][_0x37403c],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x5e535b&&_0x5e535b(_0x1a3a91['s'],_0x1a3a91['d']);});}['reportStats'](_0x1682f0){if(this['connected_']){const _0x1541cb={'c':_0x1682f0};this['log_']('reportStats',_0x1541cb),this['sendRequest']('s',_0x1541cb,_0x295ac3=>{if(_0x295ac3['s']!=='ok'){const _0x5cbbe0=_0x295ac3['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x5cbbe0);}});}}['onDataMessage_'](_0xe7385b){if('r'in _0xe7385b){this['log_']('from\x20server:\x20'+O(_0xe7385b));const _0x7e613=_0xe7385b['r'],_0x4c6abf=this['requestCBHash_'][_0x7e613];_0x4c6abf&&(delete this['requestCBHash_'][_0x7e613],_0x4c6abf(_0xe7385b['b']));}else{if('error'in _0xe7385b)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0xe7385b['error'];'a'in _0xe7385b&&this['onDataPush_'](_0xe7385b['a'],_0xe7385b['b']);}}['onDataPush_'](_0x31a42e,_0x25cd8b){this['log_']('handleServerMessage',_0x31a42e,_0x25cd8b),_0x31a42e==='d'?this['onDataUpdate_'](_0x25cd8b['p'],_0x25cd8b['d'],!0x1,_0x25cd8b['t']):_0x31a42e==='m'?this['onDataUpdate_'](_0x25cd8b['p'],_0x25cd8b['d'],!0x0,_0x25cd8b['t']):_0x31a42e==='c'?this['onListenRevoked_'](_0x25cd8b['p'],_0x25cd8b['q']):_0x31a42e==='ac'?this['onAuthRevoked_'](_0x25cd8b['s'],_0x25cd8b['d']):_0x31a42e==='apc'?this['onAppCheckRevoked_'](_0x25cd8b['s'],_0x25cd8b['d']):_0x31a42e==='sd'?this['onSecurityDebugPacket_'](_0x25cd8b):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x31a42e)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x43282f,_0x3007c8){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x43282f),this['lastSessionId']=_0x3007c8,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x5c9fd2){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x5c9fd2));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x5afcf2){_0x5afcf2&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x5afcf2;}['onOnline_'](_0x1cd889){_0x1cd889?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x4473ec=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x22fab4=Math['max'](0x0,this['reconnectDelay_']-_0x4473ec);_0x22fab4=Math['random']()*_0x22fab4,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x22fab4+'ms'),this['scheduleConnect_'](_0x22fab4),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x1417da=this['onDataMessage_']['bind'](this),_0x476f45=this['onReady_']['bind'](this),_0x5b0620=this['onRealtimeDisconnect_']['bind'](this),_0x2551a5=this['id']+':'+se['nextConnectionId_']++,_0x26b3ae=this['lastSessionId'];let _0x1eda00=!0x1,_0x2a7550=null;const _0x3e7d46=function(){_0x2a7550?_0x2a7550['close']():(_0x1eda00=!0x0,_0x5b0620());},_0x24ac5d=function(_0x372c79){f(_0x2a7550,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x2a7550['sendRequest'](_0x372c79);};this['realtime_']={'close':_0x3e7d46,'sendRequest':_0x24ac5d};const _0x596c01=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x25fa0a,_0x1f6ea3]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x596c01),this['appCheckTokenProvider_']['getToken'](_0x596c01)]);_0x1eda00?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x25fa0a&&_0x25fa0a['accessToken'],this['appCheckToken_']=_0x1f6ea3&&_0x1f6ea3['token'],_0x2a7550=new Sh(_0x2551a5,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x1417da,_0x476f45,_0x5b0620,_0x7f40ad=>{U(_0x7f40ad+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x26b3ae));}catch(_0x10380f){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x10380f),_0x1eda00||(this['repoInfo_']['nodeAdmin']&&U(_0x10380f),_0x3e7d46());}}}['interrupt'](_0x13cf06){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x13cf06),this['interruptReasons_'][_0x13cf06]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x5522e0){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x5522e0),delete this['interruptReasons_'][_0x5522e0],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x488147){const _0x1f4705=_0x488147-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x1f4705});}['cancelSentTransactions_'](){for(let _0x49726b=0x0;_0x49726b<this['outstandingPuts_']['length'];_0x49726b++){const _0x115465=this['outstandingPuts_'][_0x49726b];_0x115465&&'h'in _0x115465['request']&&_0x115465['queued']&&(_0x115465['onComplete']&&_0x115465['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x49726b],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x281f07,_0x1c592e){let _0x14dba1;_0x1c592e?_0x14dba1=_0x1c592e['map'](_0x821162=>Hi(_0x821162))['join']('$'):_0x14dba1='default';const _0x54e9a3=this['removeListen_'](_0x281f07,_0x14dba1);_0x54e9a3&&_0x54e9a3['onComplete']&&_0x54e9a3['onComplete']('permission_denied');}['removeListen_'](_0xb9d67d,_0x5f1bf3){const _0xc7d4d4=new C(_0xb9d67d)['toString']();let _0x55efe8;if(this['listens']['has'](_0xc7d4d4)){const _0x2b958f=this['listens']['get'](_0xc7d4d4);_0x55efe8=_0x2b958f['get'](_0x5f1bf3),_0x2b958f['delete'](_0x5f1bf3),_0x2b958f['size']===0x0&&this['listens']['delete'](_0xc7d4d4);}else _0x55efe8=void 0x0;return _0x55efe8;}['onAuthRevoked_'](_0x54c190,_0x5a480e){L('Auth\x20token\x20revoked:\x20'+_0x54c190+'/'+_0x5a480e),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x54c190==='invalid_token'||_0x54c190==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x541b3a,_0xdb8b96){L('App\x20check\x20token\x20revoked:\x20'+_0x541b3a+'/'+_0xdb8b96),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x541b3a==='invalid_token'||_0x541b3a==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x3d1ec2){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x3d1ec2):'msg'in _0x3d1ec2&&console['log']('FIREBASE:\x20'+_0x3d1ec2['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0xe1a552 of this['listens']['values']())for(const _0x408735 of _0xe1a552['values']())this['sendListen_'](_0x408735);for(let _0x4d051f=0x0;_0x4d051f<this['outstandingPuts_']['length'];_0x4d051f++)this['outstandingPuts_'][_0x4d051f]&&this['sendPut_'](_0x4d051f);for(;this['onDisconnectRequestQueue_']['length'];){const _0x4f92f9=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x4f92f9['action'],_0x4f92f9['pathString'],_0x4f92f9['data'],_0x4f92f9['onComplete']);}for(let _0x4e8f5d=0x0;_0x4e8f5d<this['outstandingGets_']['length'];_0x4e8f5d++)this['outstandingGets_'][_0x4e8f5d]&&this['sendGet_'](_0x4e8f5d);}['sendConnectStats_'](){const _0x2bef2f={};let _0x255480='js';_0x2bef2f['sdk.'+_0x255480+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x2bef2f['framework.cordova']=0x1:Yr()&&(_0x2bef2f['framework.reactnative']=0x1),this['reportStats'](_0x2bef2f);}['shouldReconnect_'](){const _0x2aa09e=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x2aa09e;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x33c304,_0x270289){this['name']=_0x33c304,this['node']=_0x270289;}static['Wrap'](_0x38f404,_0x3ceb65){return new E(_0x38f404,_0x3ceb65);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x3541b5,_0x4cec89){const _0x1c2422=new E(Fe,_0x3541b5),_0x110515=new E(Fe,_0x4cec89);return this['compare'](_0x1c2422,_0x110515)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x52a6fc){Zt=_0x52a6fc;}['compare'](_0x225899,_0x4f2d39){return He(_0x225899['name'],_0x4f2d39['name']);}['isDefinedOn'](_0x4761b1){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x1f3b80,_0x3488a4){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x51f285,_0x3f0455){return f(typeof _0x51f285=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x51f285,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x4cdf9d,_0x1d5f7c,_0x270134,_0x25e3cc,_0x1ff948=null){this['isReverse_']=_0x25e3cc,this['resultGenerator_']=_0x1ff948,this['nodeStack_']=[];let _0x38420b=0x1;for(;!_0x4cdf9d['isEmpty']();)if(_0x4cdf9d=_0x4cdf9d,_0x38420b=_0x1d5f7c?_0x270134(_0x4cdf9d['key'],_0x1d5f7c):0x1,_0x25e3cc&&(_0x38420b*=-0x1),_0x38420b<0x0)this['isReverse_']?_0x4cdf9d=_0x4cdf9d['left']:_0x4cdf9d=_0x4cdf9d['right'];else{if(_0x38420b===0x0){this['nodeStack_']['push'](_0x4cdf9d);break;}else this['nodeStack_']['push'](_0x4cdf9d),this['isReverse_']?_0x4cdf9d=_0x4cdf9d['right']:_0x4cdf9d=_0x4cdf9d['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0xe4e76b=this['nodeStack_']['pop'](),_0x3a35ce;if(this['resultGenerator_']?_0x3a35ce=this['resultGenerator_'](_0xe4e76b['key'],_0xe4e76b['value']):_0x3a35ce={'key':_0xe4e76b['key'],'value':_0xe4e76b['value']},this['isReverse_']){for(_0xe4e76b=_0xe4e76b['left'];!_0xe4e76b['isEmpty']();)this['nodeStack_']['push'](_0xe4e76b),_0xe4e76b=_0xe4e76b['right'];}else{for(_0xe4e76b=_0xe4e76b['right'];!_0xe4e76b['isEmpty']();)this['nodeStack_']['push'](_0xe4e76b),_0xe4e76b=_0xe4e76b['left'];}return _0x3a35ce;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x501573=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x501573['key'],_0x501573['value']):{'key':_0x501573['key'],'value':_0x501573['value']};}}class M{constructor(_0xfbac8c,_0x29b781,_0x1aca67,_0x58f7b6,_0x482639){this['key']=_0xfbac8c,this['value']=_0x29b781,this['color']=_0x1aca67??M['RED'],this['left']=_0x58f7b6??B['EMPTY_NODE'],this['right']=_0x482639??B['EMPTY_NODE'];}['copy'](_0x503b4f,_0x2c54cb,_0x157295,_0x2f8f54,_0x4fc3f4){return new M(_0x503b4f??this['key'],_0x2c54cb??this['value'],_0x157295??this['color'],_0x2f8f54??this['left'],_0x4fc3f4??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x4af0d1){return this['left']['inorderTraversal'](_0x4af0d1)||!!_0x4af0d1(this['key'],this['value'])||this['right']['inorderTraversal'](_0x4af0d1);}['reverseTraversal'](_0x522d69){return this['right']['reverseTraversal'](_0x522d69)||_0x522d69(this['key'],this['value'])||this['left']['reverseTraversal'](_0x522d69);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x3550a8,_0x26cbb3,_0x2d4621){let _0x4dcdd4=this;const _0x8cbe50=_0x2d4621(_0x3550a8,_0x4dcdd4['key']);return _0x8cbe50<0x0?_0x4dcdd4=_0x4dcdd4['copy'](null,null,null,_0x4dcdd4['left']['insert'](_0x3550a8,_0x26cbb3,_0x2d4621),null):_0x8cbe50===0x0?_0x4dcdd4=_0x4dcdd4['copy'](null,_0x26cbb3,null,null,null):_0x4dcdd4=_0x4dcdd4['copy'](null,null,null,null,_0x4dcdd4['right']['insert'](_0x3550a8,_0x26cbb3,_0x2d4621)),_0x4dcdd4['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x192d2f=this;return!_0x192d2f['left']['isRed_']()&&!_0x192d2f['left']['left']['isRed_']()&&(_0x192d2f=_0x192d2f['moveRedLeft_']()),_0x192d2f=_0x192d2f['copy'](null,null,null,_0x192d2f['left']['removeMin_'](),null),_0x192d2f['fixUp_']();}['remove'](_0x5258a4,_0x69d176){let _0x5084a8,_0x2ec56e;if(_0x5084a8=this,_0x69d176(_0x5258a4,_0x5084a8['key'])<0x0)!_0x5084a8['left']['isEmpty']()&&!_0x5084a8['left']['isRed_']()&&!_0x5084a8['left']['left']['isRed_']()&&(_0x5084a8=_0x5084a8['moveRedLeft_']()),_0x5084a8=_0x5084a8['copy'](null,null,null,_0x5084a8['left']['remove'](_0x5258a4,_0x69d176),null);else{if(_0x5084a8['left']['isRed_']()&&(_0x5084a8=_0x5084a8['rotateRight_']()),!_0x5084a8['right']['isEmpty']()&&!_0x5084a8['right']['isRed_']()&&!_0x5084a8['right']['left']['isRed_']()&&(_0x5084a8=_0x5084a8['moveRedRight_']()),_0x69d176(_0x5258a4,_0x5084a8['key'])===0x0){if(_0x5084a8['right']['isEmpty']())return B['EMPTY_NODE'];_0x2ec56e=_0x5084a8['right']['min_'](),_0x5084a8=_0x5084a8['copy'](_0x2ec56e['key'],_0x2ec56e['value'],null,null,_0x5084a8['right']['removeMin_']());}_0x5084a8=_0x5084a8['copy'](null,null,null,null,_0x5084a8['right']['remove'](_0x5258a4,_0x69d176));}return _0x5084a8['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x94a934=this;return _0x94a934['right']['isRed_']()&&!_0x94a934['left']['isRed_']()&&(_0x94a934=_0x94a934['rotateLeft_']()),_0x94a934['left']['isRed_']()&&_0x94a934['left']['left']['isRed_']()&&(_0x94a934=_0x94a934['rotateRight_']()),_0x94a934['left']['isRed_']()&&_0x94a934['right']['isRed_']()&&(_0x94a934=_0x94a934['colorFlip_']()),_0x94a934;}['moveRedLeft_'](){let _0x401886=this['colorFlip_']();return _0x401886['right']['left']['isRed_']()&&(_0x401886=_0x401886['copy'](null,null,null,null,_0x401886['right']['rotateRight_']()),_0x401886=_0x401886['rotateLeft_'](),_0x401886=_0x401886['colorFlip_']()),_0x401886;}['moveRedRight_'](){let _0x59e757=this['colorFlip_']();return _0x59e757['left']['left']['isRed_']()&&(_0x59e757=_0x59e757['rotateRight_'](),_0x59e757=_0x59e757['colorFlip_']()),_0x59e757;}['rotateLeft_'](){const _0x359127=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x359127,null);}['rotateRight_'](){const _0x2168e4=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x2168e4);}['colorFlip_'](){const _0x33428c=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x2872b8=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x33428c,_0x2872b8);}['checkMaxDepth_'](){const _0x4a3c87=this['check_']();return Math['pow'](0x2,_0x4a3c87)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x55abae=this['left']['check_']();if(_0x55abae!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x55abae+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x14f7a4,_0x2d7caa,_0x2062ef,_0x3d6f9a,_0x438a50){return this;}['insert'](_0x189475,_0x474202,_0x19f2b6){return new M(_0x189475,_0x474202,null);}['remove'](_0x3a4bc5,_0x5ecbab){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x27f13c){return!0x1;}['reverseTraversal'](_0x1eebab){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x221d13,_0x1c91ed=B['EMPTY_NODE']){this['comparator_']=_0x221d13,this['root_']=_0x1c91ed;}['insert'](_0x228d63,_0x1e1de3){return new B(this['comparator_'],this['root_']['insert'](_0x228d63,_0x1e1de3,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x2a32bd){return new B(this['comparator_'],this['root_']['remove'](_0x2a32bd,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x2902fb){let _0x357303,_0x4ade33=this['root_'];for(;!_0x4ade33['isEmpty']();){if(_0x357303=this['comparator_'](_0x2902fb,_0x4ade33['key']),_0x357303===0x0)return _0x4ade33['value'];_0x357303<0x0?_0x4ade33=_0x4ade33['left']:_0x357303>0x0&&(_0x4ade33=_0x4ade33['right']);}return null;}['getPredecessorKey'](_0x48dd12){let _0x2e304e,_0x4cedb8=this['root_'],_0x55b827=null;for(;!_0x4cedb8['isEmpty']();)if(_0x2e304e=this['comparator_'](_0x48dd12,_0x4cedb8['key']),_0x2e304e===0x0){if(_0x4cedb8['left']['isEmpty']())return _0x55b827?_0x55b827['key']:null;for(_0x4cedb8=_0x4cedb8['left'];!_0x4cedb8['right']['isEmpty']();)_0x4cedb8=_0x4cedb8['right'];return _0x4cedb8['key'];}else _0x2e304e<0x0?_0x4cedb8=_0x4cedb8['left']:_0x2e304e>0x0&&(_0x55b827=_0x4cedb8,_0x4cedb8=_0x4cedb8['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x39746a){return this['root_']['inorderTraversal'](_0x39746a);}['reverseTraversal'](_0x2bc9a4){return this['root_']['reverseTraversal'](_0x2bc9a4);}['getIterator'](_0x52899b){return new en(this['root_'],null,this['comparator_'],!0x1,_0x52899b);}['getIteratorFrom'](_0x4fb806,_0x35c894){return new en(this['root_'],_0x4fb806,this['comparator_'],!0x1,_0x35c894);}['getReverseIteratorFrom'](_0x28e9b4,_0x2a6750){return new en(this['root_'],_0x28e9b4,this['comparator_'],!0x0,_0x2a6750);}['getReverseIterator'](_0xa88ddf){return new en(this['root_'],null,this['comparator_'],!0x0,_0xa88ddf);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x3edf44,_0x44416c){return He(_0x3edf44['name'],_0x44416c['name']);}function Yi(_0x52936a,_0xaff6df){return He(_0x52936a,_0xaff6df);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x1c2fdb){Ei=_0x1c2fdb;}const No=function(_0x139613){return typeof _0x139613=='number'?'number:'+ao(_0x139613):'string:'+_0x139613;},Po=function(_0x348d80){if(_0x348d80['isLeafNode']()){const _0x2f4107=_0x348d80['val']();f(typeof _0x2f4107=='string'||typeof _0x2f4107=='number'||typeof _0x2f4107=='object'&&J(_0x2f4107,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x348d80===Ei||_0x348d80['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x348d80===Ei||_0x348d80['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x1f4867){ir=_0x1f4867;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x50b387,_0x1d0e9e=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x50b387,this['priorityNode_']=_0x1d0e9e,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x234eeb){return new D(this['value_'],_0x234eeb);}['getImmediateChild'](_0x50da40){return _0x50da40==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x3332e6){return v(_0x3332e6)?this:y(_0x3332e6)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x3148bf,_0x2394c3){return null;}['updateImmediateChild'](_0x527674,_0x5017ab){return _0x527674==='.priority'?this['updatePriority'](_0x5017ab):_0x5017ab['isEmpty']()&&_0x527674!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x527674,_0x5017ab)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x4ab1b5,_0x4b9d66){const _0x236513=y(_0x4ab1b5);return _0x236513===null?_0x4b9d66:_0x4b9d66['isEmpty']()&&_0x236513!=='.priority'?this:(f(_0x236513!=='.priority'||we(_0x4ab1b5)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x236513,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x4ab1b5),_0x4b9d66)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x5d913c,_0x530d29){return!0x1;}['val'](_0x29406d){return _0x29406d&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x24923a='';this['priorityNode_']['isEmpty']()||(_0x24923a+='priority:'+No(this['priorityNode_']['val']())+':');const _0x249a2e=typeof this['value_'];_0x24923a+=_0x249a2e+':',_0x249a2e==='number'?_0x24923a+=ao(this['value_']):_0x24923a+=this['value_'],this['lazyHash_']=ro(_0x24923a);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x166655){return _0x166655===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x166655 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x166655['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x166655));}['compareToLeafNode_'](_0x100102){const _0x59d6a3=typeof _0x100102['value_'],_0x2db5df=typeof this['value_'],_0x3a2f90=D['VALUE_TYPE_ORDER']['indexOf'](_0x59d6a3),_0x394a39=D['VALUE_TYPE_ORDER']['indexOf'](_0x2db5df);return f(_0x3a2f90>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x59d6a3),f(_0x394a39>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x2db5df),_0x3a2f90===_0x394a39?_0x2db5df==='object'?0x0:this['value_']<_0x100102['value_']?-0x1:this['value_']===_0x100102['value_']?0x0:0x1:_0x394a39-_0x3a2f90;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x34d554){if(_0x34d554===this)return!0x0;if(_0x34d554['isLeafNode']()){const _0x35fa55=_0x34d554;return this['value_']===_0x35fa55['value_']&&this['priorityNode_']['equals'](_0x35fa55['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x1a8a1c){Oo=_0x1a8a1c;}function Wh(_0x38d9c1){Do=_0x38d9c1;}class Bh extends Dn{['compare'](_0x357e19,_0x45c001){const _0x2b4285=_0x357e19['node']['getPriority'](),_0x5070df=_0x45c001['node']['getPriority'](),_0x266db6=_0x2b4285['compareTo'](_0x5070df);return _0x266db6===0x0?He(_0x357e19['name'],_0x45c001['name']):_0x266db6;}['isDefinedOn'](_0x51cde5){return!_0x51cde5['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x17af02,_0x413012){return!_0x17af02['getPriority']()['equals'](_0x413012['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x13a416,_0x547357){const _0x3cf091=Oo(_0x13a416);return new E(_0x547357,new D('[PRIORITY-POST]',_0x3cf091));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x498cbe){const _0x3354de=_0x415426=>parseInt(Math['log'](_0x415426)/Vh,0xa),_0x1494db=_0x42c4e0=>parseInt(Array(_0x42c4e0+0x1)['join']('1'),0x2);this['count']=_0x3354de(_0x498cbe+0x1),this['current_']=this['count']-0x1;const _0x4da915=_0x1494db(this['count']);this['bits_']=_0x498cbe+0x1&_0x4da915;}['nextBitIsOne'](){const _0x46a2df=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x46a2df;}}const fn=function(_0x374aac,_0x4dbf8c,_0x45b6b0,_0x5cf414){_0x374aac['sort'](_0x4dbf8c);const _0xdc7a78=function(_0x2781ec,_0x48f123){const _0x1a3ded=_0x48f123-_0x2781ec;let _0x4dc65d,_0x5f177e;if(_0x1a3ded===0x0)return null;if(_0x1a3ded===0x1)return _0x4dc65d=_0x374aac[_0x2781ec],_0x5f177e=_0x45b6b0?_0x45b6b0(_0x4dc65d):_0x4dc65d,new M(_0x5f177e,_0x4dc65d['node'],M['BLACK'],null,null);{const _0xc42144=parseInt(_0x1a3ded/0x2,0xa)+_0x2781ec,_0x41d2dd=_0xdc7a78(_0x2781ec,_0xc42144),_0x249d26=_0xdc7a78(_0xc42144+0x1,_0x48f123);return _0x4dc65d=_0x374aac[_0xc42144],_0x5f177e=_0x45b6b0?_0x45b6b0(_0x4dc65d):_0x4dc65d,new M(_0x5f177e,_0x4dc65d['node'],M['BLACK'],_0x41d2dd,_0x249d26);}},_0x537442=function(_0x5287ba){let _0x5d1f5=null,_0x542929=null,_0x2da27c=_0x374aac['length'];const _0x21b21f=function(_0xcf46b3,_0x453951){const _0x5a70fb=_0x2da27c-_0xcf46b3,_0x272548=_0x2da27c;_0x2da27c-=_0xcf46b3;const _0x374a8d=_0xdc7a78(_0x5a70fb+0x1,_0x272548),_0x4cccdc=_0x374aac[_0x5a70fb],_0x4d850c=_0x45b6b0?_0x45b6b0(_0x4cccdc):_0x4cccdc;_0x4a489f(new M(_0x4d850c,_0x4cccdc['node'],_0x453951,null,_0x374a8d));},_0x4a489f=function(_0x19e34d){_0x5d1f5?(_0x5d1f5['left']=_0x19e34d,_0x5d1f5=_0x19e34d):(_0x542929=_0x19e34d,_0x5d1f5=_0x19e34d);};for(let _0x38129c=0x0;_0x38129c<_0x5287ba['count'];++_0x38129c){const _0x59b7cd=_0x5287ba['nextBitIsOne'](),_0xa8746e=Math['pow'](0x2,_0x5287ba['count']-(_0x38129c+0x1));_0x59b7cd?_0x21b21f(_0xa8746e,M['BLACK']):(_0x21b21f(_0xa8746e,M['BLACK']),_0x21b21f(_0xa8746e,M['RED']));}return _0x542929;},_0x20c583=new Hh(_0x374aac['length']),_0x3914e4=_0x537442(_0x20c583);return new B(_0x5cf414||_0x4dbf8c,_0x3914e4);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x5a8ff8,_0x5e7a10){this['indexes_']=_0x5a8ff8,this['indexSet_']=_0x5e7a10;}['get'](_0x448584){const _0x387919=De(this['indexes_'],_0x448584);if(!_0x387919)throw new Error('No\x20index\x20defined\x20for\x20'+_0x448584);return _0x387919 instanceof B?_0x387919:null;}['hasIndex'](_0x33e3be){return J(this['indexSet_'],_0x33e3be['toString']());}['addIndex'](_0x238d67,_0x15fbec){f(_0x238d67!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x474f5f=[];let _0x70e36=!0x1;const _0x75feef=_0x15fbec['getIterator'](E['Wrap']);let _0x48a652=_0x75feef['getNext']();for(;_0x48a652;)_0x70e36=_0x70e36||_0x238d67['isDefinedOn'](_0x48a652['node']),_0x474f5f['push'](_0x48a652),_0x48a652=_0x75feef['getNext']();let _0x2c20ca;_0x70e36?_0x2c20ca=fn(_0x474f5f,_0x238d67['getCompare']()):_0x2c20ca=ze;const _0x342555=_0x238d67['toString'](),_0x34dbe8={...this['indexSet_']};_0x34dbe8[_0x342555]=_0x238d67;const _0x56d355={...this['indexes_']};return _0x56d355[_0x342555]=_0x2c20ca,new te(_0x56d355,_0x34dbe8);}['addToIndexes'](_0x168fa8,_0x4da979){const _0x2eb173=hn(this['indexes_'],(_0x4f6e77,_0x4a3525)=>{const _0x574467=De(this['indexSet_'],_0x4a3525);if(f(_0x574467,'Missing\x20index\x20implementation\x20for\x20'+_0x4a3525),_0x4f6e77===ze){if(_0x574467['isDefinedOn'](_0x168fa8['node'])){const _0xd59ee0=[],_0x28ce4f=_0x4da979['getIterator'](E['Wrap']);let _0x5654ac=_0x28ce4f['getNext']();for(;_0x5654ac;)_0x5654ac['name']!==_0x168fa8['name']&&_0xd59ee0['push'](_0x5654ac),_0x5654ac=_0x28ce4f['getNext']();return _0xd59ee0['push'](_0x168fa8),fn(_0xd59ee0,_0x574467['getCompare']());}else return ze;}else{const _0x5443df=_0x4da979['get'](_0x168fa8['name']);let _0x422806=_0x4f6e77;return _0x5443df&&(_0x422806=_0x422806['remove'](new E(_0x168fa8['name'],_0x5443df))),_0x422806['insert'](_0x168fa8,_0x168fa8['node']);}});return new te(_0x2eb173,this['indexSet_']);}['removeFromIndexes'](_0x1ceea5,_0x11602c){const _0x3b90ae=hn(this['indexes_'],_0x1c30d8=>{if(_0x1c30d8===ze)return _0x1c30d8;{const _0x5ec048=_0x11602c['get'](_0x1ceea5['name']);return _0x5ec048?_0x1c30d8['remove'](new E(_0x1ceea5['name'],_0x5ec048)):_0x1c30d8;}});return new te(_0x3b90ae,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x406e3a,_0x57fb27,_0x4f6511){this['children_']=_0x406e3a,this['priorityNode_']=_0x57fb27,this['indexMap_']=_0x4f6511,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x551e80){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x551e80,this['indexMap_']);}['getImmediateChild'](_0x128b41){if(_0x128b41==='.priority')return this['getPriority']();{const _0x51fbd8=this['children_']['get'](_0x128b41);return _0x51fbd8===null?mt:_0x51fbd8;}}['getChild'](_0xb14789){const _0x4d4cb8=y(_0xb14789);return _0x4d4cb8===null?this:this['getImmediateChild'](_0x4d4cb8)['getChild'](b(_0xb14789));}['hasChild'](_0x40a9ba){return this['children_']['get'](_0x40a9ba)!==null;}['updateImmediateChild'](_0x108dd5,_0x70d75a){if(f(_0x70d75a,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x108dd5==='.priority')return this['updatePriority'](_0x70d75a);{const _0x20e7e3=new E(_0x108dd5,_0x70d75a);let _0x4f6ec5,_0x31d5cd;_0x70d75a['isEmpty']()?(_0x4f6ec5=this['children_']['remove'](_0x108dd5),_0x31d5cd=this['indexMap_']['removeFromIndexes'](_0x20e7e3,this['children_'])):(_0x4f6ec5=this['children_']['insert'](_0x108dd5,_0x70d75a),_0x31d5cd=this['indexMap_']['addToIndexes'](_0x20e7e3,this['children_']));const _0x79ae34=_0x4f6ec5['isEmpty']()?mt:this['priorityNode_'];return new g(_0x4f6ec5,_0x79ae34,_0x31d5cd);}}['updateChild'](_0x5d4274,_0x2845fe){const _0x312293=y(_0x5d4274);if(_0x312293===null)return _0x2845fe;{f(y(_0x5d4274)!=='.priority'||we(_0x5d4274)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x4a723f=this['getImmediateChild'](_0x312293)['updateChild'](b(_0x5d4274),_0x2845fe);return this['updateImmediateChild'](_0x312293,_0x4a723f);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x226e2b){if(this['isEmpty']())return null;const _0x55ef24={};let _0x425b7d=0x0,_0x6d95d3=0x0,_0x1ce302=!0x0;if(this['forEachChild'](R,(_0x319bb2,_0x24cfac)=>{_0x55ef24[_0x319bb2]=_0x24cfac['val'](_0x226e2b),_0x425b7d++,_0x1ce302&&g['INTEGER_REGEXP_']['test'](_0x319bb2)?_0x6d95d3=Math['max'](_0x6d95d3,Number(_0x319bb2)):_0x1ce302=!0x1;}),!_0x226e2b&&_0x1ce302&&_0x6d95d3<0x2*_0x425b7d){const _0x1a4b72=[];for(const _0x5cafbd in _0x55ef24)_0x1a4b72[_0x5cafbd]=_0x55ef24[_0x5cafbd];return _0x1a4b72;}else return _0x226e2b&&!this['getPriority']()['isEmpty']()&&(_0x55ef24['.priority']=this['getPriority']()['val']()),_0x55ef24;}['hash'](){if(this['lazyHash_']===null){let _0x332f78='';this['getPriority']()['isEmpty']()||(_0x332f78+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x58456e,_0x764798)=>{const _0xdabfca=_0x764798['hash']();_0xdabfca!==''&&(_0x332f78+=':'+_0x58456e+':'+_0xdabfca);}),this['lazyHash_']=_0x332f78===''?'':ro(_0x332f78);}return this['lazyHash_'];}['getPredecessorChildName'](_0x121562,_0x537051,_0x2ec3fa){const _0x8cb76f=this['resolveIndex_'](_0x2ec3fa);if(_0x8cb76f){const _0x2ade5b=_0x8cb76f['getPredecessorKey'](new E(_0x121562,_0x537051));return _0x2ade5b?_0x2ade5b['name']:null;}else return this['children_']['getPredecessorKey'](_0x121562);}['getFirstChildName'](_0x59a9c2){const _0x32d21c=this['resolveIndex_'](_0x59a9c2);if(_0x32d21c){const _0x26a785=_0x32d21c['minKey']();return _0x26a785&&_0x26a785['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x527999){const _0x3359d1=this['getFirstChildName'](_0x527999);return _0x3359d1?new E(_0x3359d1,this['children_']['get'](_0x3359d1)):null;}['getLastChildName'](_0x1e696b){const _0x14b9cc=this['resolveIndex_'](_0x1e696b);if(_0x14b9cc){const _0x1eaa0b=_0x14b9cc['maxKey']();return _0x1eaa0b&&_0x1eaa0b['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x53d95f){const _0x5cab80=this['getLastChildName'](_0x53d95f);return _0x5cab80?new E(_0x5cab80,this['children_']['get'](_0x5cab80)):null;}['forEachChild'](_0x3ba2db,_0x5d7771){const _0x5c78b4=this['resolveIndex_'](_0x3ba2db);return _0x5c78b4?_0x5c78b4['inorderTraversal'](_0x53c15f=>_0x5d7771(_0x53c15f['name'],_0x53c15f['node'])):this['children_']['inorderTraversal'](_0x5d7771);}['getIterator'](_0x133faf){return this['getIteratorFrom'](_0x133faf['minPost'](),_0x133faf);}['getIteratorFrom'](_0x2a8ab9,_0x5f3649){const _0x499698=this['resolveIndex_'](_0x5f3649);if(_0x499698)return _0x499698['getIteratorFrom'](_0x2a8ab9,_0x4143a5=>_0x4143a5);{const _0x58a7c6=this['children_']['getIteratorFrom'](_0x2a8ab9['name'],E['Wrap']);let _0x3d108b=_0x58a7c6['peek']();for(;_0x3d108b!=null&&_0x5f3649['compare'](_0x3d108b,_0x2a8ab9)<0x0;)_0x58a7c6['getNext'](),_0x3d108b=_0x58a7c6['peek']();return _0x58a7c6;}}['getReverseIterator'](_0x33efbc){return this['getReverseIteratorFrom'](_0x33efbc['maxPost'](),_0x33efbc);}['getReverseIteratorFrom'](_0x5f055d,_0x157647){const _0x2a98bc=this['resolveIndex_'](_0x157647);if(_0x2a98bc)return _0x2a98bc['getReverseIteratorFrom'](_0x5f055d,_0x852214=>_0x852214);{const _0x4ad201=this['children_']['getReverseIteratorFrom'](_0x5f055d['name'],E['Wrap']);let _0x547386=_0x4ad201['peek']();for(;_0x547386!=null&&_0x157647['compare'](_0x547386,_0x5f055d)>0x0;)_0x4ad201['getNext'](),_0x547386=_0x4ad201['peek']();return _0x4ad201;}}['compareTo'](_0x98e8eb){return this['isEmpty']()?_0x98e8eb['isEmpty']()?0x0:-0x1:_0x98e8eb['isLeafNode']()||_0x98e8eb['isEmpty']()?0x1:_0x98e8eb===$t?-0x1:0x0;}['withIndex'](_0x2862ef){if(_0x2862ef===ye||this['indexMap_']['hasIndex'](_0x2862ef))return this;{const _0x584af2=this['indexMap_']['addIndex'](_0x2862ef,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x584af2);}}['isIndexed'](_0x2dedd4){return _0x2dedd4===ye||this['indexMap_']['hasIndex'](_0x2dedd4);}['equals'](_0x64b80b){if(_0x64b80b===this)return!0x0;if(_0x64b80b['isLeafNode']())return!0x1;{const _0xa409e8=_0x64b80b;if(this['getPriority']()['equals'](_0xa409e8['getPriority']())){if(this['children_']['count']()===_0xa409e8['children_']['count']()){const _0xbf820a=this['getIterator'](R),_0x2d0f55=_0xa409e8['getIterator'](R);let _0x26f6a4=_0xbf820a['getNext'](),_0x59d83e=_0x2d0f55['getNext']();for(;_0x26f6a4&&_0x59d83e;){if(_0x26f6a4['name']!==_0x59d83e['name']||!_0x26f6a4['node']['equals'](_0x59d83e['node']))return!0x1;_0x26f6a4=_0xbf820a['getNext'](),_0x59d83e=_0x2d0f55['getNext']();}return _0x26f6a4===null&&_0x59d83e===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x354e4c){return _0x354e4c===ye?null:this['indexMap_']['get'](_0x354e4c['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x3c9c1d){return _0x3c9c1d===this?0x0:0x1;}['equals'](_0x3a213a){return _0x3a213a===this;}['getPriority'](){return this;}['getImmediateChild'](_0x530932){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x293608,_0x521e69=null){if(_0x293608===null)return g['EMPTY_NODE'];if(typeof _0x293608=='object'&&'.priority'in _0x293608&&(_0x521e69=_0x293608['.priority']),f(_0x521e69===null||typeof _0x521e69=='string'||typeof _0x521e69=='number'||typeof _0x521e69=='object'&&'.sv'in _0x521e69,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x521e69),typeof _0x293608=='object'&&'.value'in _0x293608&&_0x293608['.value']!==null&&(_0x293608=_0x293608['.value']),typeof _0x293608!='object'||'.sv'in _0x293608){const _0xcedad8=_0x293608;return new D(_0xcedad8,P(_0x521e69));}if(!(_0x293608 instanceof Array)&&Gh){const _0xbcdcda=[];let _0x750150=!0x1;if(x(_0x293608,(_0x424c1f,_0x3c1b82)=>{if(_0x424c1f['substring'](0x0,0x1)!=='.'){const _0x4567e2=P(_0x3c1b82);_0x4567e2['isEmpty']()||(_0x750150=_0x750150||!_0x4567e2['getPriority']()['isEmpty'](),_0xbcdcda['push'](new E(_0x424c1f,_0x4567e2)));}}),_0xbcdcda['length']===0x0)return g['EMPTY_NODE'];const _0x494552=fn(_0xbcdcda,xh,_0x44e24c=>_0x44e24c['name'],Yi);if(_0x750150){const _0xfba3e0=fn(_0xbcdcda,R['getCompare']());return new g(_0x494552,P(_0x521e69),new te({'.priority':_0xfba3e0},{'.priority':R}));}else return new g(_0x494552,P(_0x521e69),te['Default']);}else{let _0x2fb4cb=g['EMPTY_NODE'];return x(_0x293608,(_0x1a7090,_0x4d2636)=>{if(J(_0x293608,_0x1a7090)&&_0x1a7090['substring'](0x0,0x1)!=='.'){const _0x130732=P(_0x4d2636);(_0x130732['isLeafNode']()||!_0x130732['isEmpty']())&&(_0x2fb4cb=_0x2fb4cb['updateImmediateChild'](_0x1a7090,_0x130732));}}),_0x2fb4cb['updatePriority'](P(_0x521e69));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x3e422c){super(),this['indexPath_']=_0x3e422c,f(!v(_0x3e422c)&&y(_0x3e422c)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x26b201){return _0x26b201['getChild'](this['indexPath_']);}['isDefinedOn'](_0x1944f5){return!_0x1944f5['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x5eb9b4,_0x2ff4e1){const _0x2cb5cf=this['extractChild'](_0x5eb9b4['node']),_0x559ef2=this['extractChild'](_0x2ff4e1['node']),_0x40bfce=_0x2cb5cf['compareTo'](_0x559ef2);return _0x40bfce===0x0?He(_0x5eb9b4['name'],_0x2ff4e1['name']):_0x40bfce;}['makePost'](_0x53317c,_0x3eed08){const _0x1d968b=P(_0x53317c),_0x2717e3=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x1d968b);return new E(_0x3eed08,_0x2717e3);}['maxPost'](){const _0x382e91=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x382e91);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x167650,_0x113d4a){const _0xe80cc=_0x167650['node']['compareTo'](_0x113d4a['node']);return _0xe80cc===0x0?He(_0x167650['name'],_0x113d4a['name']):_0xe80cc;}['isDefinedOn'](_0x469849){return!0x0;}['indexedValueChanged'](_0x27b647,_0x56a96d){return!_0x27b647['equals'](_0x56a96d);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x4213e6,_0x19d164){const _0x1d85ee=P(_0x4213e6);return new E(_0x19d164,_0x1d85ee);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x40e3a8){return{'type':'value','snapshotNode':_0x40e3a8};}function et(_0x4869c1,_0x5d9e79){return{'type':'child_added','snapshotNode':_0x5d9e79,'childName':_0x4869c1};}function Ot(_0x413e61,_0x359561){return{'type':'child_removed','snapshotNode':_0x359561,'childName':_0x413e61};}function Dt(_0x135ff7,_0x149aa8,_0x581f39){return{'type':'child_changed','snapshotNode':_0x149aa8,'childName':_0x135ff7,'oldSnap':_0x581f39};}function zh(_0x16b457,_0x1049e9){return{'type':'child_moved','snapshotNode':_0x1049e9,'childName':_0x16b457};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x4b953a){this['index_']=_0x4b953a;}['updateChild'](_0x47a9d0,_0x4ca702,_0x21bfbf,_0x3495b6,_0x43f250,_0x295169){f(_0x47a9d0['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x576d5b=_0x47a9d0['getImmediateChild'](_0x4ca702);return _0x576d5b['getChild'](_0x3495b6)['equals'](_0x21bfbf['getChild'](_0x3495b6))&&_0x576d5b['isEmpty']()===_0x21bfbf['isEmpty']()||(_0x295169!=null&&(_0x21bfbf['isEmpty']()?_0x47a9d0['hasChild'](_0x4ca702)?_0x295169['trackChildChange'](Ot(_0x4ca702,_0x576d5b)):f(_0x47a9d0['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x576d5b['isEmpty']()?_0x295169['trackChildChange'](et(_0x4ca702,_0x21bfbf)):_0x295169['trackChildChange'](Dt(_0x4ca702,_0x21bfbf,_0x576d5b))),_0x47a9d0['isLeafNode']()&&_0x21bfbf['isEmpty']())?_0x47a9d0:_0x47a9d0['updateImmediateChild'](_0x4ca702,_0x21bfbf)['withIndex'](this['index_']);}['updateFullNode'](_0x156e7c,_0x17a757,_0x5836ba){return _0x5836ba!=null&&(_0x156e7c['isLeafNode']()||_0x156e7c['forEachChild'](R,(_0x1e153d,_0x5e99bc)=>{_0x17a757['hasChild'](_0x1e153d)||_0x5836ba['trackChildChange'](Ot(_0x1e153d,_0x5e99bc));}),_0x17a757['isLeafNode']()||_0x17a757['forEachChild'](R,(_0x8e713c,_0x57e616)=>{if(_0x156e7c['hasChild'](_0x8e713c)){const _0x4f8a12=_0x156e7c['getImmediateChild'](_0x8e713c);_0x4f8a12['equals'](_0x57e616)||_0x5836ba['trackChildChange'](Dt(_0x8e713c,_0x57e616,_0x4f8a12));}else _0x5836ba['trackChildChange'](et(_0x8e713c,_0x57e616));})),_0x17a757['withIndex'](this['index_']);}['updatePriority'](_0x4ce112,_0x31bbaf){return _0x4ce112['isEmpty']()?g['EMPTY_NODE']:_0x4ce112['updatePriority'](_0x31bbaf);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x30b3e5){this['indexedFilter_']=new Ji(_0x30b3e5['getIndex']()),this['index_']=_0x30b3e5['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x30b3e5),this['endPost_']=Mt['getEndPost_'](_0x30b3e5),this['startIsInclusive_']=!_0x30b3e5['startAfterSet_'],this['endIsInclusive_']=!_0x30b3e5['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x19cd71){const _0x11842d=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x19cd71)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x19cd71)<0x0,_0x51b0b6=this['endIsInclusive_']?this['index_']['compare'](_0x19cd71,this['getEndPost']())<=0x0:this['index_']['compare'](_0x19cd71,this['getEndPost']())<0x0;return _0x11842d&&_0x51b0b6;}['updateChild'](_0x2ae77d,_0x3fdcef,_0x3c8cb2,_0xbdc7ba,_0x72524e,_0x5aa7e1){return this['matches'](new E(_0x3fdcef,_0x3c8cb2))||(_0x3c8cb2=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x2ae77d,_0x3fdcef,_0x3c8cb2,_0xbdc7ba,_0x72524e,_0x5aa7e1);}['updateFullNode'](_0x48d935,_0x23759e,_0x52d45f){_0x23759e['isLeafNode']()&&(_0x23759e=g['EMPTY_NODE']);let _0x415d86=_0x23759e['withIndex'](this['index_']);_0x415d86=_0x415d86['updatePriority'](g['EMPTY_NODE']);const _0x1786e7=this;return _0x23759e['forEachChild'](R,(_0x1c2e42,_0xd26633)=>{_0x1786e7['matches'](new E(_0x1c2e42,_0xd26633))||(_0x415d86=_0x415d86['updateImmediateChild'](_0x1c2e42,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x48d935,_0x415d86,_0x52d45f);}['updatePriority'](_0x61f335,_0x2ff131){return _0x61f335;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x3cbb95){if(_0x3cbb95['hasStart']()){const _0x431af3=_0x3cbb95['getIndexStartName']();return _0x3cbb95['getIndex']()['makePost'](_0x3cbb95['getIndexStartValue'](),_0x431af3);}else return _0x3cbb95['getIndex']()['minPost']();}static['getEndPost_'](_0x1fbb22){if(_0x1fbb22['hasEnd']()){const _0x412ba2=_0x1fbb22['getIndexEndName']();return _0x1fbb22['getIndex']()['makePost'](_0x1fbb22['getIndexEndValue'](),_0x412ba2);}else return _0x1fbb22['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x5d0ba5){this['withinDirectionalStart']=_0x5b273e=>this['reverse_']?this['withinEndPost'](_0x5b273e):this['withinStartPost'](_0x5b273e),this['withinDirectionalEnd']=_0x1cd65d=>this['reverse_']?this['withinStartPost'](_0x1cd65d):this['withinEndPost'](_0x1cd65d),this['withinStartPost']=_0x274b14=>{const _0x36ae60=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x274b14);return this['startIsInclusive_']?_0x36ae60<=0x0:_0x36ae60<0x0;},this['withinEndPost']=_0x15a5d0=>{const _0x1cdef5=this['index_']['compare'](_0x15a5d0,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x1cdef5<=0x0:_0x1cdef5<0x0;},this['rangedFilter_']=new Mt(_0x5d0ba5),this['index_']=_0x5d0ba5['getIndex'](),this['limit_']=_0x5d0ba5['getLimit'](),this['reverse_']=!_0x5d0ba5['isViewFromLeft'](),this['startIsInclusive_']=!_0x5d0ba5['startAfterSet_'],this['endIsInclusive_']=!_0x5d0ba5['endBeforeSet_'];}['updateChild'](_0x41c9fb,_0xfdd2c1,_0x156401,_0x85301,_0x5831b2,_0x4c5927){return this['rangedFilter_']['matches'](new E(_0xfdd2c1,_0x156401))||(_0x156401=g['EMPTY_NODE']),_0x41c9fb['getImmediateChild'](_0xfdd2c1)['equals'](_0x156401)?_0x41c9fb:_0x41c9fb['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x41c9fb,_0xfdd2c1,_0x156401,_0x85301,_0x5831b2,_0x4c5927):this['fullLimitUpdateChild_'](_0x41c9fb,_0xfdd2c1,_0x156401,_0x5831b2,_0x4c5927);}['updateFullNode'](_0x30941d,_0xa93d03,_0x4e2ee5){let _0x444a8e;if(_0xa93d03['isLeafNode']()||_0xa93d03['isEmpty']())_0x444a8e=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0xa93d03['numChildren']()&&_0xa93d03['isIndexed'](this['index_'])){_0x444a8e=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x290099;this['reverse_']?_0x290099=_0xa93d03['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x290099=_0xa93d03['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x3d950=0x0;for(;_0x290099['hasNext']()&&_0x3d950<this['limit_'];){const _0x44884f=_0x290099['getNext']();if(this['withinDirectionalStart'](_0x44884f)){if(this['withinDirectionalEnd'](_0x44884f))_0x444a8e=_0x444a8e['updateImmediateChild'](_0x44884f['name'],_0x44884f['node']),_0x3d950++;else break;}else continue;}}else{_0x444a8e=_0xa93d03['withIndex'](this['index_']),_0x444a8e=_0x444a8e['updatePriority'](g['EMPTY_NODE']);let _0x3df1a4;this['reverse_']?_0x3df1a4=_0x444a8e['getReverseIterator'](this['index_']):_0x3df1a4=_0x444a8e['getIterator'](this['index_']);let _0x23baa4=0x0;for(;_0x3df1a4['hasNext']();){const _0x4479ea=_0x3df1a4['getNext']();_0x23baa4<this['limit_']&&this['withinDirectionalStart'](_0x4479ea)&&this['withinDirectionalEnd'](_0x4479ea)?_0x23baa4++:_0x444a8e=_0x444a8e['updateImmediateChild'](_0x4479ea['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x30941d,_0x444a8e,_0x4e2ee5);}['updatePriority'](_0x183cc2,_0x1622b9){return _0x183cc2;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x11546c,_0x153b8a,_0x165bab,_0x425329,_0x5432c3){let _0x3f00d7;if(this['reverse_']){const _0x2a5507=this['index_']['getCompare']();_0x3f00d7=(_0x5722f9,_0x225cab)=>_0x2a5507(_0x225cab,_0x5722f9);}else _0x3f00d7=this['index_']['getCompare']();const _0x33e7e9=_0x11546c;f(_0x33e7e9['numChildren']()===this['limit_'],'');const _0xb68c3f=new E(_0x153b8a,_0x165bab),_0x12a14a=this['reverse_']?_0x33e7e9['getFirstChild'](this['index_']):_0x33e7e9['getLastChild'](this['index_']),_0x1021af=this['rangedFilter_']['matches'](_0xb68c3f);if(_0x33e7e9['hasChild'](_0x153b8a)){const _0x98130e=_0x33e7e9['getImmediateChild'](_0x153b8a);let _0xb194b=_0x425329['getChildAfterChild'](this['index_'],_0x12a14a,this['reverse_']);for(;_0xb194b!=null&&(_0xb194b['name']===_0x153b8a||_0x33e7e9['hasChild'](_0xb194b['name']));)_0xb194b=_0x425329['getChildAfterChild'](this['index_'],_0xb194b,this['reverse_']);const _0x66f97e=_0xb194b==null?0x1:_0x3f00d7(_0xb194b,_0xb68c3f);if(_0x1021af&&!_0x165bab['isEmpty']()&&_0x66f97e>=0x0)return _0x5432c3!=null&&_0x5432c3['trackChildChange'](Dt(_0x153b8a,_0x165bab,_0x98130e)),_0x33e7e9['updateImmediateChild'](_0x153b8a,_0x165bab);{_0x5432c3!=null&&_0x5432c3['trackChildChange'](Ot(_0x153b8a,_0x98130e));const _0x51a6b2=_0x33e7e9['updateImmediateChild'](_0x153b8a,g['EMPTY_NODE']);return _0xb194b!=null&&this['rangedFilter_']['matches'](_0xb194b)?(_0x5432c3!=null&&_0x5432c3['trackChildChange'](et(_0xb194b['name'],_0xb194b['node'])),_0x51a6b2['updateImmediateChild'](_0xb194b['name'],_0xb194b['node'])):_0x51a6b2;}}else return _0x165bab['isEmpty']()?_0x11546c:_0x1021af&&_0x3f00d7(_0x12a14a,_0xb68c3f)>=0x0?(_0x5432c3!=null&&(_0x5432c3['trackChildChange'](Ot(_0x12a14a['name'],_0x12a14a['node'])),_0x5432c3['trackChildChange'](et(_0x153b8a,_0x165bab))),_0x33e7e9['updateImmediateChild'](_0x153b8a,_0x165bab)['updateImmediateChild'](_0x12a14a['name'],g['EMPTY_NODE'])):_0x11546c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x24546a=new Xi();return _0x24546a['limitSet_']=this['limitSet_'],_0x24546a['limit_']=this['limit_'],_0x24546a['startSet_']=this['startSet_'],_0x24546a['startAfterSet_']=this['startAfterSet_'],_0x24546a['indexStartValue_']=this['indexStartValue_'],_0x24546a['startNameSet_']=this['startNameSet_'],_0x24546a['indexStartName_']=this['indexStartName_'],_0x24546a['endSet_']=this['endSet_'],_0x24546a['endBeforeSet_']=this['endBeforeSet_'],_0x24546a['indexEndValue_']=this['indexEndValue_'],_0x24546a['endNameSet_']=this['endNameSet_'],_0x24546a['indexEndName_']=this['indexEndName_'],_0x24546a['index_']=this['index_'],_0x24546a['viewFrom_']=this['viewFrom_'],_0x24546a;}}function Kh(_0x231dcc){return _0x231dcc['loadsAllData']()?new Ji(_0x231dcc['getIndex']()):_0x231dcc['hasLimit']()?new jh(_0x231dcc):new Mt(_0x231dcc);}function Yh(_0xe3ab43,_0x4a373a){const _0x3a0d41=_0xe3ab43['copy']();return _0x3a0d41['limitSet_']=!0x0,_0x3a0d41['limit_']=_0x4a373a,_0x3a0d41['viewFrom_']='l',_0x3a0d41;}function Qh(_0x5475a2,_0x293d39,_0x4bdb2d){const _0x4f635e=_0x5475a2['copy']();return _0x4f635e['startSet_']=!0x0,_0x293d39===void 0x0&&(_0x293d39=null),_0x4f635e['indexStartValue_']=_0x293d39,_0x4bdb2d!=null?(_0x4f635e['startNameSet_']=!0x0,_0x4f635e['indexStartName_']=_0x4bdb2d):(_0x4f635e['startNameSet_']=!0x1,_0x4f635e['indexStartName_']=''),_0x4f635e;}function Jh(_0x5473aa,_0x953123,_0x25718d){const _0x143a9=_0x5473aa['copy']();return _0x143a9['endSet_']=!0x0,_0x953123===void 0x0&&(_0x953123=null),_0x143a9['indexEndValue_']=_0x953123,_0x25718d!==void 0x0?(_0x143a9['endNameSet_']=!0x0,_0x143a9['indexEndName_']=_0x25718d):(_0x143a9['endNameSet_']=!0x1,_0x143a9['indexEndName_']=''),_0x143a9;}function xo(_0x19f484,_0x198a34){const _0x32da59=_0x19f484['copy']();return _0x32da59['index_']=_0x198a34,_0x32da59;}function sr(_0x333ee8){const _0x5f5454={};if(_0x333ee8['isDefault']())return _0x5f5454;let _0x159095;if(_0x333ee8['index_']===R?_0x159095='$priority':_0x333ee8['index_']===Mo?_0x159095='$value':_0x333ee8['index_']===ye?_0x159095='$key':(f(_0x333ee8['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x159095=_0x333ee8['index_']['toString']()),_0x5f5454['orderBy']=O(_0x159095),_0x333ee8['startSet_']){const _0x3599aa=_0x333ee8['startAfterSet_']?'startAfter':'startAt';_0x5f5454[_0x3599aa]=O(_0x333ee8['indexStartValue_']),_0x333ee8['startNameSet_']&&(_0x5f5454[_0x3599aa]+=','+O(_0x333ee8['indexStartName_']));}if(_0x333ee8['endSet_']){const _0xbe83=_0x333ee8['endBeforeSet_']?'endBefore':'endAt';_0x5f5454[_0xbe83]=O(_0x333ee8['indexEndValue_']),_0x333ee8['endNameSet_']&&(_0x5f5454[_0xbe83]+=','+O(_0x333ee8['indexEndName_']));}return _0x333ee8['limitSet_']&&(_0x333ee8['isViewFromLeft']()?_0x5f5454['limitToFirst']=_0x333ee8['limit_']:_0x5f5454['limitToLast']=_0x333ee8['limit_']),_0x5f5454;}function rr(_0x102ba9){const _0x59ddd6={};if(_0x102ba9['startSet_']&&(_0x59ddd6['sp']=_0x102ba9['indexStartValue_'],_0x102ba9['startNameSet_']&&(_0x59ddd6['sn']=_0x102ba9['indexStartName_']),_0x59ddd6['sin']=!_0x102ba9['startAfterSet_']),_0x102ba9['endSet_']&&(_0x59ddd6['ep']=_0x102ba9['indexEndValue_'],_0x102ba9['endNameSet_']&&(_0x59ddd6['en']=_0x102ba9['indexEndName_']),_0x59ddd6['ein']=!_0x102ba9['endBeforeSet_']),_0x102ba9['limitSet_']){_0x59ddd6['l']=_0x102ba9['limit_'];let _0x18a3bb=_0x102ba9['viewFrom_'];_0x18a3bb===''&&(_0x102ba9['isViewFromLeft']()?_0x18a3bb='l':_0x18a3bb='r'),_0x59ddd6['vf']=_0x18a3bb;}return _0x102ba9['index_']!==R&&(_0x59ddd6['i']=_0x102ba9['index_']['toString']()),_0x59ddd6;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x2d2fcc){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x5055da,_0x9cd819){return _0x9cd819!==void 0x0?'tag$'+_0x9cd819:(f(_0x5055da['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x5055da['_path']['toString']());}constructor(_0x1f20f9,_0x4e327b,_0x8222ba,_0x4007a5){super(),this['repoInfo_']=_0x1f20f9,this['onDataUpdate_']=_0x4e327b,this['authTokenProvider_']=_0x8222ba,this['appCheckTokenProvider_']=_0x4007a5,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x103dd0,_0x3749fa,_0x30b253,_0x41f1ac){const _0x504a28=_0x103dd0['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x504a28+'\x20'+_0x103dd0['_queryIdentifier']);const _0x50b66a=pn['getListenId_'](_0x103dd0,_0x30b253),_0x119f61={};this['listens_'][_0x50b66a]=_0x119f61;const _0x5588a2=sr(_0x103dd0['_queryParams']);this['restRequest_'](_0x504a28+'.json',_0x5588a2,(_0x632ebe,_0x583a97)=>{let _0xc8175e=_0x583a97;if(_0x632ebe===0x194&&(_0xc8175e=null,_0x632ebe=null),_0x632ebe===null&&this['onDataUpdate_'](_0x504a28,_0xc8175e,!0x1,_0x30b253),De(this['listens_'],_0x50b66a)===_0x119f61){let _0x30c30a;_0x632ebe?_0x632ebe===0x191?_0x30c30a='permission_denied':_0x30c30a='rest_error:'+_0x632ebe:_0x30c30a='ok',_0x41f1ac(_0x30c30a,null);}});}['unlisten'](_0x2bc0ca,_0x188f1d){const _0x49c20b=pn['getListenId_'](_0x2bc0ca,_0x188f1d);delete this['listens_'][_0x49c20b];}['get'](_0x581941){const _0x3c6d78=sr(_0x581941['_queryParams']),_0x45c08b=_0x581941['_path']['toString'](),_0x96592c=new ot();return this['restRequest_'](_0x45c08b+'.json',_0x3c6d78,(_0x45c58b,_0x445676)=>{let _0x56fe3a=_0x445676;_0x45c58b===0x194&&(_0x56fe3a=null,_0x45c58b=null),_0x45c58b===null?(this['onDataUpdate_'](_0x45c08b,_0x56fe3a,!0x1,null),_0x96592c['resolve'](_0x56fe3a)):_0x96592c['reject'](new Error(_0x56fe3a));}),_0x96592c['promise'];}['refreshAuthToken'](_0xbcf38){}['restRequest_'](_0x2f3741,_0x1cf7fe={},_0xd4b7fb){return _0x1cf7fe['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x57bff1,_0x5d8509])=>{_0x57bff1&&_0x57bff1['accessToken']&&(_0x1cf7fe['auth']=_0x57bff1['accessToken']),_0x5d8509&&_0x5d8509['token']&&(_0x1cf7fe['ac']=_0x5d8509['token']);const _0x5021d1=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x2f3741+'?ns='+this['repoInfo_']['namespace']+ct(_0x1cf7fe);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x5021d1);const _0x542159=new XMLHttpRequest();_0x542159['onreadystatechange']=()=>{if(_0xd4b7fb&&_0x542159['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x5021d1+'\x20received.\x20status:',_0x542159['status'],'response:',_0x542159['responseText']);let _0xb542cb=null;if(_0x542159['status']>=0xc8&&_0x542159['status']<0x12c){try{_0xb542cb=At(_0x542159['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x5021d1+':\x20'+_0x542159['responseText']);}_0xd4b7fb(null,_0xb542cb);}else _0x542159['status']!==0x191&&_0x542159['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x5021d1+'\x20Status:\x20'+_0x542159['status']),_0xd4b7fb(_0x542159['status']);_0xd4b7fb=null;}},_0x542159['open']('GET',_0x5021d1,!0x0),_0x542159['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x24c499){return this['rootNode_']['getChild'](_0x24c499);}['updateSnapshot'](_0x83134d,_0x470824){this['rootNode_']=this['rootNode_']['updateChild'](_0x83134d,_0x470824);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x522608,_0x2809b9,_0x278fc5){if(v(_0x2809b9))_0x522608['value']=_0x278fc5,_0x522608['children']['clear']();else{if(_0x522608['value']!==null)_0x522608['value']=_0x522608['value']['updateChild'](_0x2809b9,_0x278fc5);else{const _0x2850c0=y(_0x2809b9);_0x522608['children']['has'](_0x2850c0)||_0x522608['children']['set'](_0x2850c0,_n());const _0x1588c7=_0x522608['children']['get'](_0x2850c0);_0x2809b9=b(_0x2809b9),Fo(_0x1588c7,_0x2809b9,_0x278fc5);}}}function Ii(_0x231f7b,_0x49023f,_0x1ed000){_0x231f7b['value']!==null?_0x1ed000(_0x49023f,_0x231f7b['value']):Zh(_0x231f7b,(_0x14fd34,_0x139ef1)=>{const _0x2bd21d=new C(_0x49023f['toString']()+'/'+_0x14fd34);Ii(_0x139ef1,_0x2bd21d,_0x1ed000);});}function Zh(_0x21efc2,_0xf3f553){_0x21efc2['children']['forEach']((_0x493b15,_0xff5c65)=>{_0xf3f553(_0xff5c65,_0x493b15);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x1e7dda){this['collection_']=_0x1e7dda,this['last_']=null;}['get'](){const _0x388fc2=this['collection_']['get'](),_0x12f1c5={..._0x388fc2};return this['last_']&&x(this['last_'],(_0x47a232,_0x34c241)=>{_0x12f1c5[_0x47a232]=_0x12f1c5[_0x47a232]-_0x34c241;}),this['last_']=_0x388fc2,_0x12f1c5;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x3228ff,_0x2ebbb){this['server_']=_0x2ebbb,this['statsToReport_']={},this['statsListener_']=new eu(_0x3228ff);const _0x5d2385=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x5d2385));}['reportStats_'](){const _0x3839ec=this['statsListener_']['get'](),_0x2b6d2c={};let _0x31d662=!0x1;x(_0x3839ec,(_0x29026d,_0x1ae457)=>{_0x1ae457>0x0&&J(this['statsToReport_'],_0x29026d)&&(_0x2b6d2c[_0x29026d]=_0x1ae457,_0x31d662=!0x0);}),_0x31d662&&this['server_']['reportStats'](_0x2b6d2c),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x42f4f6){_0x42f4f6[_0x42f4f6['OVERWRITE']=0x0]='OVERWRITE',_0x42f4f6[_0x42f4f6['MERGE']=0x1]='MERGE',_0x42f4f6[_0x42f4f6['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x42f4f6[_0x42f4f6['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x4b422a){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x4b422a,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x5e9376,_0x70dcd5,_0x283f7b){this['path']=_0x5e9376,this['affectedTree']=_0x70dcd5,this['revert']=_0x283f7b,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x146361){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x262fed=this['affectedTree']['subtree'](new C(_0x146361));return new gn(w(),_0x262fed,this['revert']);}}else return f(y(this['path'])===_0x146361,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x332a8f,_0x166ddd){this['source']=_0x332a8f,this['path']=_0x166ddd,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x1e6a1d){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x3c143c,_0x654651,_0x30c7da){this['source']=_0x3c143c,this['path']=_0x654651,this['snap']=_0x30c7da,this['type']=j['OVERWRITE'];}['operationForChild'](_0x358500){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x358500)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x2e54bf,_0x140a95,_0x4f9b91){this['source']=_0x2e54bf,this['path']=_0x140a95,this['children']=_0x4f9b91,this['type']=j['MERGE'];}['operationForChild'](_0x1ee815){if(v(this['path'])){const _0x277300=this['children']['subtree'](new C(_0x1ee815));return _0x277300['isEmpty']()?null:_0x277300['value']?new Ue(this['source'],w(),_0x277300['value']):new tt(this['source'],w(),_0x277300);}else return f(y(this['path'])===_0x1ee815,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x3210b1,_0x21ad83,_0x1f2643){this['node_']=_0x3210b1,this['fullyInitialized_']=_0x21ad83,this['filtered_']=_0x1f2643;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x2a8832){if(v(_0x2a8832))return this['isFullyInitialized']()&&!this['filtered_'];const _0x3d3c69=y(_0x2a8832);return this['isCompleteForChild'](_0x3d3c69);}['isCompleteForChild'](_0x140b77){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x140b77);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0xcc475d){this['query_']=_0xcc475d,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x42d944,_0x9dabe9,_0x1211a6,_0x450737){const _0x11d283=[],_0x4edd08=[];return _0x9dabe9['forEach'](_0x423dba=>{_0x423dba['type']==='child_changed'&&_0x42d944['index_']['indexedValueChanged'](_0x423dba['oldSnap'],_0x423dba['snapshotNode'])&&_0x4edd08['push'](zh(_0x423dba['childName'],_0x423dba['snapshotNode']));}),yt(_0x42d944,_0x11d283,'child_removed',_0x9dabe9,_0x450737,_0x1211a6),yt(_0x42d944,_0x11d283,'child_added',_0x9dabe9,_0x450737,_0x1211a6),yt(_0x42d944,_0x11d283,'child_moved',_0x4edd08,_0x450737,_0x1211a6),yt(_0x42d944,_0x11d283,'child_changed',_0x9dabe9,_0x450737,_0x1211a6),yt(_0x42d944,_0x11d283,'value',_0x9dabe9,_0x450737,_0x1211a6),_0x11d283;}function yt(_0x2c4b0e,_0x3e526d,_0x1754a7,_0xf0de16,_0x5a7609,_0x7f64ea){const _0x1cace3=_0xf0de16['filter'](_0x58adc0=>_0x58adc0['type']===_0x1754a7);_0x1cace3['sort']((_0x1dd6bf,_0x3940b1)=>au(_0x2c4b0e,_0x1dd6bf,_0x3940b1)),_0x1cace3['forEach'](_0xff24e1=>{const _0x59db08=ou(_0x2c4b0e,_0xff24e1,_0x7f64ea);_0x5a7609['forEach'](_0x598138=>{_0x598138['respondsTo'](_0xff24e1['type'])&&_0x3e526d['push'](_0x598138['createEvent'](_0x59db08,_0x2c4b0e['query_']));});});}function ou(_0x43084d,_0x40547c,_0x443dd3){return _0x40547c['type']==='value'||_0x40547c['type']==='child_removed'||(_0x40547c['prevName']=_0x443dd3['getPredecessorChildName'](_0x40547c['childName'],_0x40547c['snapshotNode'],_0x43084d['index_'])),_0x40547c;}function au(_0x5022eb,_0x3b84fe,_0x24f5b6){if(_0x3b84fe['childName']==null||_0x24f5b6['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x9274e0=new E(_0x3b84fe['childName'],_0x3b84fe['snapshotNode']),_0x163610=new E(_0x24f5b6['childName'],_0x24f5b6['snapshotNode']);return _0x5022eb['index_']['compare'](_0x9274e0,_0x163610);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x2f79ea,_0x13120d){return{'eventCache':_0x2f79ea,'serverCache':_0x13120d};}function Tt(_0x1e6b6b,_0x56083d,_0x57ae2f,_0x52e6ef){return Mn(new Ce(_0x56083d,_0x57ae2f,_0x52e6ef),_0x1e6b6b['serverCache']);}function Uo(_0x510d1d,_0x43d7b3,_0x267db7,_0x362527){return Mn(_0x510d1d['eventCache'],new Ce(_0x43d7b3,_0x267db7,_0x362527));}function mn(_0x4b9250){return _0x4b9250['eventCache']['isFullyInitialized']()?_0x4b9250['eventCache']['getNode']():null;}function We(_0x31d542){return _0x31d542['serverCache']['isFullyInitialized']()?_0x31d542['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x2549a1){let _0x21024e=new S(null);return x(_0x2549a1,(_0x23f076,_0x4e0347)=>{_0x21024e=_0x21024e['set'](new C(_0x23f076),_0x4e0347);}),_0x21024e;}constructor(_0x8be218,_0x48a5bb=cu()){this['value']=_0x8be218,this['children']=_0x48a5bb;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x4303d4,_0x2c2da8){if(this['value']!=null&&_0x2c2da8(this['value']))return{'path':w(),'value':this['value']};if(v(_0x4303d4))return null;{const _0x1a5cc0=y(_0x4303d4),_0x19ce6c=this['children']['get'](_0x1a5cc0);if(_0x19ce6c!==null){const _0x655aeb=_0x19ce6c['findRootMostMatchingPathAndValue'](b(_0x4303d4),_0x2c2da8);return _0x655aeb!=null?{'path':k(new C(_0x1a5cc0),_0x655aeb['path']),'value':_0x655aeb['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x174692){return this['findRootMostMatchingPathAndValue'](_0x174692,()=>!0x0);}['subtree'](_0x39a0df){if(v(_0x39a0df))return this;{const _0x1e830e=y(_0x39a0df),_0x17ebff=this['children']['get'](_0x1e830e);return _0x17ebff!==null?_0x17ebff['subtree'](b(_0x39a0df)):new S(null);}}['set'](_0x48426f,_0x102e87){if(v(_0x48426f))return new S(_0x102e87,this['children']);{const _0x22e2fc=y(_0x48426f),_0x28db5c=(this['children']['get'](_0x22e2fc)||new S(null))['set'](b(_0x48426f),_0x102e87),_0x4495b5=this['children']['insert'](_0x22e2fc,_0x28db5c);return new S(this['value'],_0x4495b5);}}['remove'](_0x5db42b){if(v(_0x5db42b))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x429b2e=y(_0x5db42b),_0x5a3ecb=this['children']['get'](_0x429b2e);if(_0x5a3ecb){const _0x98dde6=_0x5a3ecb['remove'](b(_0x5db42b));let _0x16043c;return _0x98dde6['isEmpty']()?_0x16043c=this['children']['remove'](_0x429b2e):_0x16043c=this['children']['insert'](_0x429b2e,_0x98dde6),this['value']===null&&_0x16043c['isEmpty']()?new S(null):new S(this['value'],_0x16043c);}else return this;}}['get'](_0x4dc4cf){if(v(_0x4dc4cf))return this['value'];{const _0x522345=y(_0x4dc4cf),_0x590dcb=this['children']['get'](_0x522345);return _0x590dcb?_0x590dcb['get'](b(_0x4dc4cf)):null;}}['setTree'](_0x178957,_0x243bf5){if(v(_0x178957))return _0x243bf5;{const _0x884d32=y(_0x178957),_0x177739=(this['children']['get'](_0x884d32)||new S(null))['setTree'](b(_0x178957),_0x243bf5);let _0x7b3724;return _0x177739['isEmpty']()?_0x7b3724=this['children']['remove'](_0x884d32):_0x7b3724=this['children']['insert'](_0x884d32,_0x177739),new S(this['value'],_0x7b3724);}}['fold'](_0x15d717){return this['fold_'](w(),_0x15d717);}['fold_'](_0x526227,_0x171d83){const _0x5f27cb={};return this['children']['inorderTraversal']((_0x2ecec3,_0x3d4b07)=>{_0x5f27cb[_0x2ecec3]=_0x3d4b07['fold_'](k(_0x526227,_0x2ecec3),_0x171d83);}),_0x171d83(_0x526227,this['value'],_0x5f27cb);}['findOnPath'](_0x123baa,_0x38e216){return this['findOnPath_'](_0x123baa,w(),_0x38e216);}['findOnPath_'](_0x595a12,_0x75d40e,_0x4ffc7f){const _0x452b96=this['value']?_0x4ffc7f(_0x75d40e,this['value']):!0x1;if(_0x452b96)return _0x452b96;if(v(_0x595a12))return null;{const _0xd75ef8=y(_0x595a12),_0x375f2e=this['children']['get'](_0xd75ef8);return _0x375f2e?_0x375f2e['findOnPath_'](b(_0x595a12),k(_0x75d40e,_0xd75ef8),_0x4ffc7f):null;}}['foreachOnPath'](_0x2614ff,_0xf04c7c){return this['foreachOnPath_'](_0x2614ff,w(),_0xf04c7c);}['foreachOnPath_'](_0x4a6a55,_0x919bf4,_0x557666){if(v(_0x4a6a55))return this;{this['value']&&_0x557666(_0x919bf4,this['value']);const _0x44015b=y(_0x4a6a55),_0x79ffd2=this['children']['get'](_0x44015b);return _0x79ffd2?_0x79ffd2['foreachOnPath_'](b(_0x4a6a55),k(_0x919bf4,_0x44015b),_0x557666):new S(null);}}['foreach'](_0x53dc69){this['foreach_'](w(),_0x53dc69);}['foreach_'](_0x50c375,_0x782c8d){this['children']['inorderTraversal']((_0x3d8469,_0x3e6a30)=>{_0x3e6a30['foreach_'](k(_0x50c375,_0x3d8469),_0x782c8d);}),this['value']&&_0x782c8d(_0x50c375,this['value']);}['foreachChild'](_0x2bd79d){this['children']['inorderTraversal']((_0x3379e3,_0x48d16e)=>{_0x48d16e['value']&&_0x2bd79d(_0x3379e3,_0x48d16e['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x12bc2b){this['writeTree_']=_0x12bc2b;}static['empty'](){return new Y(new S(null));}}function St(_0x24c0d2,_0x3406d6,_0x5e7257){if(v(_0x3406d6))return new Y(new S(_0x5e7257));{const _0x568361=_0x24c0d2['writeTree_']['findRootMostValueAndPath'](_0x3406d6);if(_0x568361!=null){const _0x150b3a=_0x568361['path'];let _0x5675ab=_0x568361['value'];const _0x19bcc0=F(_0x150b3a,_0x3406d6);return _0x5675ab=_0x5675ab['updateChild'](_0x19bcc0,_0x5e7257),new Y(_0x24c0d2['writeTree_']['set'](_0x150b3a,_0x5675ab));}else{const _0x29e21c=new S(_0x5e7257),_0x598517=_0x24c0d2['writeTree_']['setTree'](_0x3406d6,_0x29e21c);return new Y(_0x598517);}}}function wi(_0x58ac96,_0x2ac30a,_0x5f3c92){let _0x4950d2=_0x58ac96;return x(_0x5f3c92,(_0x290e6e,_0x12a9f2)=>{_0x4950d2=St(_0x4950d2,k(_0x2ac30a,_0x290e6e),_0x12a9f2);}),_0x4950d2;}function ar(_0xf34c36,_0x374629){if(v(_0x374629))return Y['empty']();{const _0x5628d9=_0xf34c36['writeTree_']['setTree'](_0x374629,new S(null));return new Y(_0x5628d9);}}function Ci(_0xee786a,_0x31f75a){return $e(_0xee786a,_0x31f75a)!=null;}function $e(_0x1227e9,_0x23263){const _0x5433c6=_0x1227e9['writeTree_']['findRootMostValueAndPath'](_0x23263);return _0x5433c6!=null?_0x1227e9['writeTree_']['get'](_0x5433c6['path'])['getChild'](F(_0x5433c6['path'],_0x23263)):null;}function cr(_0x39b4bb){const _0x37ac6d=[],_0x43a9f1=_0x39b4bb['writeTree_']['value'];return _0x43a9f1!=null?_0x43a9f1['isLeafNode']()||_0x43a9f1['forEachChild'](R,(_0x39b31c,_0x3c5419)=>{_0x37ac6d['push'](new E(_0x39b31c,_0x3c5419));}):_0x39b4bb['writeTree_']['children']['inorderTraversal']((_0x8a9dc3,_0x7792e1)=>{_0x7792e1['value']!=null&&_0x37ac6d['push'](new E(_0x8a9dc3,_0x7792e1['value']));}),_0x37ac6d;}function ve(_0x4bb147,_0x5302d6){if(v(_0x5302d6))return _0x4bb147;{const _0x5a0368=$e(_0x4bb147,_0x5302d6);return _0x5a0368!=null?new Y(new S(_0x5a0368)):new Y(_0x4bb147['writeTree_']['subtree'](_0x5302d6));}}function Ti(_0x2ea796){return _0x2ea796['writeTree_']['isEmpty']();}function nt(_0x12ac13,_0x2de706){return Wo(w(),_0x12ac13['writeTree_'],_0x2de706);}function Wo(_0x11c96d,_0x138442,_0x46dc2f){if(_0x138442['value']!=null)return _0x46dc2f['updateChild'](_0x11c96d,_0x138442['value']);{let _0x5b815d=null;return _0x138442['children']['inorderTraversal']((_0x4a9e89,_0x4db54b)=>{_0x4a9e89==='.priority'?(f(_0x4db54b['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x5b815d=_0x4db54b['value']):_0x46dc2f=Wo(k(_0x11c96d,_0x4a9e89),_0x4db54b,_0x46dc2f);}),!_0x46dc2f['getChild'](_0x11c96d)['isEmpty']()&&_0x5b815d!==null&&(_0x46dc2f=_0x46dc2f['updateChild'](k(_0x11c96d,'.priority'),_0x5b815d)),_0x46dc2f;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x172ffe,_0x226773){return $o(_0x226773,_0x172ffe);}function lu(_0xfceb0d,_0x35b161,_0x330847,_0x34e74f,_0x485a10){f(_0x34e74f>_0xfceb0d['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x485a10===void 0x0&&(_0x485a10=!0x0),_0xfceb0d['allWrites']['push']({'path':_0x35b161,'snap':_0x330847,'writeId':_0x34e74f,'visible':_0x485a10}),_0x485a10&&(_0xfceb0d['visibleWrites']=St(_0xfceb0d['visibleWrites'],_0x35b161,_0x330847)),_0xfceb0d['lastWriteId']=_0x34e74f;}function hu(_0x9edde4,_0x386693,_0x46617,_0x4b65b3){f(_0x4b65b3>_0x9edde4['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x9edde4['allWrites']['push']({'path':_0x386693,'children':_0x46617,'writeId':_0x4b65b3,'visible':!0x0}),_0x9edde4['visibleWrites']=wi(_0x9edde4['visibleWrites'],_0x386693,_0x46617),_0x9edde4['lastWriteId']=_0x4b65b3;}function uu(_0x3cc905,_0x5a8899){for(let _0x11e4e9=0x0;_0x11e4e9<_0x3cc905['allWrites']['length'];_0x11e4e9++){const _0x424128=_0x3cc905['allWrites'][_0x11e4e9];if(_0x424128['writeId']===_0x5a8899)return _0x424128;}return null;}function du(_0x5aece0,_0x1a8a84){const _0x310087=_0x5aece0['allWrites']['findIndex'](_0xbc512=>_0xbc512['writeId']===_0x1a8a84);f(_0x310087>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x542ad4=_0x5aece0['allWrites'][_0x310087];_0x5aece0['allWrites']['splice'](_0x310087,0x1);let _0x2a5919=_0x542ad4['visible'],_0x5a6ee5=!0x1,_0x201444=_0x5aece0['allWrites']['length']-0x1;for(;_0x2a5919&&_0x201444>=0x0;){const _0x23814f=_0x5aece0['allWrites'][_0x201444];_0x23814f['visible']&&(_0x201444>=_0x310087&&fu(_0x23814f,_0x542ad4['path'])?_0x2a5919=!0x1:G(_0x542ad4['path'],_0x23814f['path'])&&(_0x5a6ee5=!0x0)),_0x201444--;}if(_0x2a5919){if(_0x5a6ee5)return pu(_0x5aece0),!0x0;if(_0x542ad4['snap'])_0x5aece0['visibleWrites']=ar(_0x5aece0['visibleWrites'],_0x542ad4['path']);else{const _0x31187a=_0x542ad4['children'];x(_0x31187a,_0x206184=>{_0x5aece0['visibleWrites']=ar(_0x5aece0['visibleWrites'],k(_0x542ad4['path'],_0x206184));});}return!0x0;}else return!0x1;}function fu(_0x55e745,_0x5f3ac7){if(_0x55e745['snap'])return G(_0x55e745['path'],_0x5f3ac7);for(const _0x47e31b in _0x55e745['children'])if(_0x55e745['children']['hasOwnProperty'](_0x47e31b)&&G(k(_0x55e745['path'],_0x47e31b),_0x5f3ac7))return!0x0;return!0x1;}function pu(_0x1d544c){_0x1d544c['visibleWrites']=Bo(_0x1d544c['allWrites'],_u,w()),_0x1d544c['allWrites']['length']>0x0?_0x1d544c['lastWriteId']=_0x1d544c['allWrites'][_0x1d544c['allWrites']['length']-0x1]['writeId']:_0x1d544c['lastWriteId']=-0x1;}function _u(_0x3aa889){return _0x3aa889['visible'];}function Bo(_0x11e509,_0x55f791,_0xe0d218){let _0x3e2c20=Y['empty']();for(let _0x53a7cd=0x0;_0x53a7cd<_0x11e509['length'];++_0x53a7cd){const _0x1be9be=_0x11e509[_0x53a7cd];if(_0x55f791(_0x1be9be)){const _0x4d4efe=_0x1be9be['path'];let _0xd170ab;if(_0x1be9be['snap'])G(_0xe0d218,_0x4d4efe)?(_0xd170ab=F(_0xe0d218,_0x4d4efe),_0x3e2c20=St(_0x3e2c20,_0xd170ab,_0x1be9be['snap'])):G(_0x4d4efe,_0xe0d218)&&(_0xd170ab=F(_0x4d4efe,_0xe0d218),_0x3e2c20=St(_0x3e2c20,w(),_0x1be9be['snap']['getChild'](_0xd170ab)));else{if(_0x1be9be['children']){if(G(_0xe0d218,_0x4d4efe))_0xd170ab=F(_0xe0d218,_0x4d4efe),_0x3e2c20=wi(_0x3e2c20,_0xd170ab,_0x1be9be['children']);else{if(G(_0x4d4efe,_0xe0d218)){if(_0xd170ab=F(_0x4d4efe,_0xe0d218),v(_0xd170ab))_0x3e2c20=wi(_0x3e2c20,w(),_0x1be9be['children']);else{const _0x248a9b=De(_0x1be9be['children'],y(_0xd170ab));if(_0x248a9b){const _0x4fb5cf=_0x248a9b['getChild'](b(_0xd170ab));_0x3e2c20=St(_0x3e2c20,w(),_0x4fb5cf);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x3e2c20;}function Vo(_0x111b8d,_0x154885,_0x394c18,_0x1bf4ff,_0x48b59e){if(!_0x1bf4ff&&!_0x48b59e){const _0xbe1e23=$e(_0x111b8d['visibleWrites'],_0x154885);if(_0xbe1e23!=null)return _0xbe1e23;{const _0x4555a9=ve(_0x111b8d['visibleWrites'],_0x154885);if(Ti(_0x4555a9))return _0x394c18;if(_0x394c18==null&&!Ci(_0x4555a9,w()))return null;{const _0x552205=_0x394c18||g['EMPTY_NODE'];return nt(_0x4555a9,_0x552205);}}}else{const _0xce3492=ve(_0x111b8d['visibleWrites'],_0x154885);if(!_0x48b59e&&Ti(_0xce3492))return _0x394c18;if(!_0x48b59e&&_0x394c18==null&&!Ci(_0xce3492,w()))return null;{const _0x5aa62d=function(_0x517448){return(_0x517448['visible']||_0x48b59e)&&(!_0x1bf4ff||!~_0x1bf4ff['indexOf'](_0x517448['writeId']))&&(G(_0x517448['path'],_0x154885)||G(_0x154885,_0x517448['path']));},_0x9289f6=Bo(_0x111b8d['allWrites'],_0x5aa62d,_0x154885),_0x2e34d0=_0x394c18||g['EMPTY_NODE'];return nt(_0x9289f6,_0x2e34d0);}}}function gu(_0x1c2866,_0x4078bf,_0x59df7f){let _0xef0efe=g['EMPTY_NODE'];const _0x23d979=$e(_0x1c2866['visibleWrites'],_0x4078bf);if(_0x23d979)return _0x23d979['isLeafNode']()||_0x23d979['forEachChild'](R,(_0x5ba28e,_0x37ee7e)=>{_0xef0efe=_0xef0efe['updateImmediateChild'](_0x5ba28e,_0x37ee7e);}),_0xef0efe;if(_0x59df7f){const _0x481768=ve(_0x1c2866['visibleWrites'],_0x4078bf);return _0x59df7f['forEachChild'](R,(_0x3127f5,_0x211eaa)=>{const _0x3c3b8b=nt(ve(_0x481768,new C(_0x3127f5)),_0x211eaa);_0xef0efe=_0xef0efe['updateImmediateChild'](_0x3127f5,_0x3c3b8b);}),cr(_0x481768)['forEach'](_0x59139d=>{_0xef0efe=_0xef0efe['updateImmediateChild'](_0x59139d['name'],_0x59139d['node']);}),_0xef0efe;}else{const _0x17af60=ve(_0x1c2866['visibleWrites'],_0x4078bf);return cr(_0x17af60)['forEach'](_0x2a5173=>{_0xef0efe=_0xef0efe['updateImmediateChild'](_0x2a5173['name'],_0x2a5173['node']);}),_0xef0efe;}}function mu(_0x59bf7c,_0x1bd907,_0x2457c8,_0x3d298b,_0x16c9d5){f(_0x3d298b||_0x16c9d5,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x2a151c=k(_0x1bd907,_0x2457c8);if(Ci(_0x59bf7c['visibleWrites'],_0x2a151c))return null;{const _0x43c9bf=ve(_0x59bf7c['visibleWrites'],_0x2a151c);return Ti(_0x43c9bf)?_0x16c9d5['getChild'](_0x2457c8):nt(_0x43c9bf,_0x16c9d5['getChild'](_0x2457c8));}}function yu(_0x360539,_0x4bda7b,_0xc991b8,_0x5689d1){const _0x3b4618=k(_0x4bda7b,_0xc991b8),_0x181727=$e(_0x360539['visibleWrites'],_0x3b4618);if(_0x181727!=null)return _0x181727;if(_0x5689d1['isCompleteForChild'](_0xc991b8)){const _0x242011=ve(_0x360539['visibleWrites'],_0x3b4618);return nt(_0x242011,_0x5689d1['getNode']()['getImmediateChild'](_0xc991b8));}else return null;}function vu(_0x7890b8,_0x143ffa){return $e(_0x7890b8['visibleWrites'],_0x143ffa);}function Eu(_0x3fee4d,_0x5e10aa,_0xd10d98,_0x4a5b73,_0x4ac2a1,_0x2dd1f3,_0x27d87f){let _0x42ecf8;const _0x4cbaab=ve(_0x3fee4d['visibleWrites'],_0x5e10aa),_0x35ee99=$e(_0x4cbaab,w());if(_0x35ee99!=null)_0x42ecf8=_0x35ee99;else{if(_0xd10d98!=null)_0x42ecf8=nt(_0x4cbaab,_0xd10d98);else return[];}if(_0x42ecf8=_0x42ecf8['withIndex'](_0x27d87f),!_0x42ecf8['isEmpty']()&&!_0x42ecf8['isLeafNode']()){const _0x1e4719=[],_0x2a0c2=_0x27d87f['getCompare'](),_0x3f87bd=_0x2dd1f3?_0x42ecf8['getReverseIteratorFrom'](_0x4a5b73,_0x27d87f):_0x42ecf8['getIteratorFrom'](_0x4a5b73,_0x27d87f);let _0x245989=_0x3f87bd['getNext']();for(;_0x245989&&_0x1e4719['length']<_0x4ac2a1;)_0x2a0c2(_0x245989,_0x4a5b73)!==0x0&&_0x1e4719['push'](_0x245989),_0x245989=_0x3f87bd['getNext']();return _0x1e4719;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x5aa6f5,_0x45e045,_0x4acb1d,_0x5bf970){return Vo(_0x5aa6f5['writeTree'],_0x5aa6f5['treePath'],_0x45e045,_0x4acb1d,_0x5bf970);}function ns(_0x31a2e5,_0x517a44){return gu(_0x31a2e5['writeTree'],_0x31a2e5['treePath'],_0x517a44);}function lr(_0x3a4052,_0x5bc157,_0x4c6d3a,_0x4dea3f){return mu(_0x3a4052['writeTree'],_0x3a4052['treePath'],_0x5bc157,_0x4c6d3a,_0x4dea3f);}function vn(_0x56b54c,_0x2e9b2d){return vu(_0x56b54c['writeTree'],k(_0x56b54c['treePath'],_0x2e9b2d));}function wu(_0x174ecb,_0x369613,_0x4310c5,_0x5cd6b6,_0x1e52bf,_0x1f5631){return Eu(_0x174ecb['writeTree'],_0x174ecb['treePath'],_0x369613,_0x4310c5,_0x5cd6b6,_0x1e52bf,_0x1f5631);}function is(_0x5231f4,_0x5504b9,_0x5367d5){return yu(_0x5231f4['writeTree'],_0x5231f4['treePath'],_0x5504b9,_0x5367d5);}function Ho(_0xa94f0c,_0x4a54b8){return $o(k(_0xa94f0c['treePath'],_0x4a54b8),_0xa94f0c['writeTree']);}function $o(_0x345945,_0x403902){return{'treePath':_0x345945,'writeTree':_0x403902};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x15c0b8){const _0x2e2048=_0x15c0b8['type'],_0x2bb0db=_0x15c0b8['childName'];f(_0x2e2048==='child_added'||_0x2e2048==='child_changed'||_0x2e2048==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2bb0db!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x529dc4=this['changeMap']['get'](_0x2bb0db);if(_0x529dc4){const _0x3c513c=_0x529dc4['type'];if(_0x2e2048==='child_added'&&_0x3c513c==='child_removed')this['changeMap']['set'](_0x2bb0db,Dt(_0x2bb0db,_0x15c0b8['snapshotNode'],_0x529dc4['snapshotNode']));else{if(_0x2e2048==='child_removed'&&_0x3c513c==='child_added')this['changeMap']['delete'](_0x2bb0db);else{if(_0x2e2048==='child_removed'&&_0x3c513c==='child_changed')this['changeMap']['set'](_0x2bb0db,Ot(_0x2bb0db,_0x529dc4['oldSnap']));else{if(_0x2e2048==='child_changed'&&_0x3c513c==='child_added')this['changeMap']['set'](_0x2bb0db,et(_0x2bb0db,_0x15c0b8['snapshotNode']));else{if(_0x2e2048==='child_changed'&&_0x3c513c==='child_changed')this['changeMap']['set'](_0x2bb0db,Dt(_0x2bb0db,_0x15c0b8['snapshotNode'],_0x529dc4['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x15c0b8+'\x20occurred\x20after\x20'+_0x529dc4);}}}}}else this['changeMap']['set'](_0x2bb0db,_0x15c0b8);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x39fd95){return null;}['getChildAfterChild'](_0x114b9c,_0x23275a,_0x3c5397){return null;}}const Go=new Tu();class ss{constructor(_0x322f2d,_0x5d92d0,_0x4df4cd=null){this['writes_']=_0x322f2d,this['viewCache_']=_0x5d92d0,this['optCompleteServerCache_']=_0x4df4cd;}['getCompleteChild'](_0x17f977){const _0x49fe39=this['viewCache_']['eventCache'];if(_0x49fe39['isCompleteForChild'](_0x17f977))return _0x49fe39['getNode']()['getImmediateChild'](_0x17f977);{const _0xa7d03=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x17f977,_0xa7d03);}}['getChildAfterChild'](_0x57a803,_0x214d86,_0xf33c20){const _0x2466aa=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x191f3a=wu(this['writes_'],_0x2466aa,_0x214d86,0x1,_0xf33c20,_0x57a803);return _0x191f3a['length']===0x0?null:_0x191f3a[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x20c78e){return{'filter':_0x20c78e};}function bu(_0x1d8a21,_0x1b77f3){f(_0x1b77f3['eventCache']['getNode']()['isIndexed'](_0x1d8a21['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x1b77f3['serverCache']['getNode']()['isIndexed'](_0x1d8a21['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x3b26db,_0x160d1e,_0x5848c6,_0x3bfd74,_0x677a98){const _0x4290c=new Cu();let _0x18b91d,_0x53463c;if(_0x5848c6['type']===j['OVERWRITE']){const _0x3f59e2=_0x5848c6;_0x3f59e2['source']['fromUser']?_0x18b91d=Si(_0x3b26db,_0x160d1e,_0x3f59e2['path'],_0x3f59e2['snap'],_0x3bfd74,_0x677a98,_0x4290c):(f(_0x3f59e2['source']['fromServer'],'Unknown\x20source.'),_0x53463c=_0x3f59e2['source']['tagged']||_0x160d1e['serverCache']['isFiltered']()&&!v(_0x3f59e2['path']),_0x18b91d=En(_0x3b26db,_0x160d1e,_0x3f59e2['path'],_0x3f59e2['snap'],_0x3bfd74,_0x677a98,_0x53463c,_0x4290c));}else{if(_0x5848c6['type']===j['MERGE']){const _0x234636=_0x5848c6;_0x234636['source']['fromUser']?_0x18b91d=ku(_0x3b26db,_0x160d1e,_0x234636['path'],_0x234636['children'],_0x3bfd74,_0x677a98,_0x4290c):(f(_0x234636['source']['fromServer'],'Unknown\x20source.'),_0x53463c=_0x234636['source']['tagged']||_0x160d1e['serverCache']['isFiltered'](),_0x18b91d=bi(_0x3b26db,_0x160d1e,_0x234636['path'],_0x234636['children'],_0x3bfd74,_0x677a98,_0x53463c,_0x4290c));}else{if(_0x5848c6['type']===j['ACK_USER_WRITE']){const _0x25c960=_0x5848c6;_0x25c960['revert']?_0x18b91d=Ou(_0x3b26db,_0x160d1e,_0x25c960['path'],_0x3bfd74,_0x677a98,_0x4290c):_0x18b91d=Nu(_0x3b26db,_0x160d1e,_0x25c960['path'],_0x25c960['affectedTree'],_0x3bfd74,_0x677a98,_0x4290c);}else{if(_0x5848c6['type']===j['LISTEN_COMPLETE'])_0x18b91d=Pu(_0x3b26db,_0x160d1e,_0x5848c6['path'],_0x3bfd74,_0x4290c);else throw rt('Unknown\x20operation\x20type:\x20'+_0x5848c6['type']);}}}const _0xe1ac41=_0x4290c['getChanges']();return Au(_0x160d1e,_0x18b91d,_0xe1ac41),{'viewCache':_0x18b91d,'changes':_0xe1ac41};}function Au(_0x50236e,_0x2fb29c,_0x259e80){const _0x2794d7=_0x2fb29c['eventCache'];if(_0x2794d7['isFullyInitialized']()){const _0x3b4845=_0x2794d7['getNode']()['isLeafNode']()||_0x2794d7['getNode']()['isEmpty'](),_0x2ab570=mn(_0x50236e);(_0x259e80['length']>0x0||!_0x50236e['eventCache']['isFullyInitialized']()||_0x3b4845&&!_0x2794d7['getNode']()['equals'](_0x2ab570)||!_0x2794d7['getNode']()['getPriority']()['equals'](_0x2ab570['getPriority']()))&&_0x259e80['push'](Lo(mn(_0x2fb29c)));}}function qo(_0xe30148,_0x1d03b6,_0x1ecfa0,_0x55456d,_0x4c9a17,_0x4ac87b){const _0xead5e6=_0x1d03b6['eventCache'];if(vn(_0x55456d,_0x1ecfa0)!=null)return _0x1d03b6;{let _0x40cf1c,_0x42d09e;if(v(_0x1ecfa0)){if(f(_0x1d03b6['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x1d03b6['serverCache']['isFiltered']()){const _0x584b65=We(_0x1d03b6),_0xb5c84e=_0x584b65 instanceof g?_0x584b65:g['EMPTY_NODE'],_0x2b2920=ns(_0x55456d,_0xb5c84e);_0x40cf1c=_0xe30148['filter']['updateFullNode'](_0x1d03b6['eventCache']['getNode'](),_0x2b2920,_0x4ac87b);}else{const _0x271986=yn(_0x55456d,We(_0x1d03b6));_0x40cf1c=_0xe30148['filter']['updateFullNode'](_0x1d03b6['eventCache']['getNode'](),_0x271986,_0x4ac87b);}}else{const _0x1018be=y(_0x1ecfa0);if(_0x1018be==='.priority'){f(we(_0x1ecfa0)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x4864de=_0xead5e6['getNode']();_0x42d09e=_0x1d03b6['serverCache']['getNode']();const _0x322b06=lr(_0x55456d,_0x1ecfa0,_0x4864de,_0x42d09e);_0x322b06!=null?_0x40cf1c=_0xe30148['filter']['updatePriority'](_0x4864de,_0x322b06):_0x40cf1c=_0xead5e6['getNode']();}else{const _0x6ed28=b(_0x1ecfa0);let _0x29a3f1;if(_0xead5e6['isCompleteForChild'](_0x1018be)){_0x42d09e=_0x1d03b6['serverCache']['getNode']();const _0x490d30=lr(_0x55456d,_0x1ecfa0,_0xead5e6['getNode'](),_0x42d09e);_0x490d30!=null?_0x29a3f1=_0xead5e6['getNode']()['getImmediateChild'](_0x1018be)['updateChild'](_0x6ed28,_0x490d30):_0x29a3f1=_0xead5e6['getNode']()['getImmediateChild'](_0x1018be);}else _0x29a3f1=is(_0x55456d,_0x1018be,_0x1d03b6['serverCache']);_0x29a3f1!=null?_0x40cf1c=_0xe30148['filter']['updateChild'](_0xead5e6['getNode'](),_0x1018be,_0x29a3f1,_0x6ed28,_0x4c9a17,_0x4ac87b):_0x40cf1c=_0xead5e6['getNode']();}}return Tt(_0x1d03b6,_0x40cf1c,_0xead5e6['isFullyInitialized']()||v(_0x1ecfa0),_0xe30148['filter']['filtersNodes']());}}function En(_0x1bb018,_0x3dd62e,_0x144504,_0xe7302a,_0xeaeefb,_0x362ab8,_0x4dbf59,_0x2753ba){const _0x47fd23=_0x3dd62e['serverCache'];let _0x24cb6b;const _0xe60c=_0x4dbf59?_0x1bb018['filter']:_0x1bb018['filter']['getIndexedFilter']();if(v(_0x144504))_0x24cb6b=_0xe60c['updateFullNode'](_0x47fd23['getNode'](),_0xe7302a,null);else{if(_0xe60c['filtersNodes']()&&!_0x47fd23['isFiltered']()){const _0x188715=_0x47fd23['getNode']()['updateChild'](_0x144504,_0xe7302a);_0x24cb6b=_0xe60c['updateFullNode'](_0x47fd23['getNode'](),_0x188715,null);}else{const _0x155a76=y(_0x144504);if(!_0x47fd23['isCompleteForPath'](_0x144504)&&we(_0x144504)>0x1)return _0x3dd62e;const _0x4e1ab5=b(_0x144504),_0x3a768a=_0x47fd23['getNode']()['getImmediateChild'](_0x155a76)['updateChild'](_0x4e1ab5,_0xe7302a);_0x155a76==='.priority'?_0x24cb6b=_0xe60c['updatePriority'](_0x47fd23['getNode'](),_0x3a768a):_0x24cb6b=_0xe60c['updateChild'](_0x47fd23['getNode'](),_0x155a76,_0x3a768a,_0x4e1ab5,Go,null);}}const _0x301ef5=Uo(_0x3dd62e,_0x24cb6b,_0x47fd23['isFullyInitialized']()||v(_0x144504),_0xe60c['filtersNodes']()),_0x41774d=new ss(_0xeaeefb,_0x301ef5,_0x362ab8);return qo(_0x1bb018,_0x301ef5,_0x144504,_0xeaeefb,_0x41774d,_0x2753ba);}function Si(_0x4e9cd0,_0x4df883,_0x3df8d4,_0x11df38,_0x492ccc,_0x3eb765,_0x13ef70){const _0x1cf93b=_0x4df883['eventCache'];let _0x53d65e,_0x4d6b52;const _0x4794ff=new ss(_0x492ccc,_0x4df883,_0x3eb765);if(v(_0x3df8d4))_0x4d6b52=_0x4e9cd0['filter']['updateFullNode'](_0x4df883['eventCache']['getNode'](),_0x11df38,_0x13ef70),_0x53d65e=Tt(_0x4df883,_0x4d6b52,!0x0,_0x4e9cd0['filter']['filtersNodes']());else{const _0x7793f1=y(_0x3df8d4);if(_0x7793f1==='.priority')_0x4d6b52=_0x4e9cd0['filter']['updatePriority'](_0x4df883['eventCache']['getNode'](),_0x11df38),_0x53d65e=Tt(_0x4df883,_0x4d6b52,_0x1cf93b['isFullyInitialized'](),_0x1cf93b['isFiltered']());else{const _0x1d2d92=b(_0x3df8d4),_0x457383=_0x1cf93b['getNode']()['getImmediateChild'](_0x7793f1);let _0x8b2ec2;if(v(_0x1d2d92))_0x8b2ec2=_0x11df38;else{const _0x2c765e=_0x4794ff['getCompleteChild'](_0x7793f1);_0x2c765e!=null?zi(_0x1d2d92)==='.priority'&&_0x2c765e['getChild'](Ro(_0x1d2d92))['isEmpty']()?_0x8b2ec2=_0x2c765e:_0x8b2ec2=_0x2c765e['updateChild'](_0x1d2d92,_0x11df38):_0x8b2ec2=g['EMPTY_NODE'];}if(_0x457383['equals'](_0x8b2ec2))_0x53d65e=_0x4df883;else{const _0x93fd69=_0x4e9cd0['filter']['updateChild'](_0x1cf93b['getNode'](),_0x7793f1,_0x8b2ec2,_0x1d2d92,_0x4794ff,_0x13ef70);_0x53d65e=Tt(_0x4df883,_0x93fd69,_0x1cf93b['isFullyInitialized'](),_0x4e9cd0['filter']['filtersNodes']());}}}return _0x53d65e;}function hr(_0x5946f8,_0x5afbd4){return _0x5946f8['eventCache']['isCompleteForChild'](_0x5afbd4);}function ku(_0xb6c4cb,_0x383c4a,_0x1cb793,_0xef371c,_0x41fa62,_0x715834,_0x44faeb){let _0x36474b=_0x383c4a;return _0xef371c['foreach']((_0x55abd8,_0x370586)=>{const _0xc82493=k(_0x1cb793,_0x55abd8);hr(_0x383c4a,y(_0xc82493))&&(_0x36474b=Si(_0xb6c4cb,_0x36474b,_0xc82493,_0x370586,_0x41fa62,_0x715834,_0x44faeb));}),_0xef371c['foreach']((_0x5c87ca,_0x4a8e40)=>{const _0x4c3937=k(_0x1cb793,_0x5c87ca);hr(_0x383c4a,y(_0x4c3937))||(_0x36474b=Si(_0xb6c4cb,_0x36474b,_0x4c3937,_0x4a8e40,_0x41fa62,_0x715834,_0x44faeb));}),_0x36474b;}function ur(_0x220129,_0x574318,_0x44d3bc){return _0x44d3bc['foreach']((_0x5d3573,_0x23fa23)=>{_0x574318=_0x574318['updateChild'](_0x5d3573,_0x23fa23);}),_0x574318;}function bi(_0x3e9d06,_0x1f4d73,_0x56b4ec,_0x2e35af,_0x102a5d,_0x164cf8,_0x4749a6,_0x5507c9){if(_0x1f4d73['serverCache']['getNode']()['isEmpty']()&&!_0x1f4d73['serverCache']['isFullyInitialized']())return _0x1f4d73;let _0x3b45a1=_0x1f4d73,_0x386a2a;v(_0x56b4ec)?_0x386a2a=_0x2e35af:_0x386a2a=new S(null)['setTree'](_0x56b4ec,_0x2e35af);const _0x3efb73=_0x1f4d73['serverCache']['getNode']();return _0x386a2a['children']['inorderTraversal']((_0x379e2b,_0x44865d)=>{if(_0x3efb73['hasChild'](_0x379e2b)){const _0x118488=_0x1f4d73['serverCache']['getNode']()['getImmediateChild'](_0x379e2b),_0x2f9f1c=ur(_0x3e9d06,_0x118488,_0x44865d);_0x3b45a1=En(_0x3e9d06,_0x3b45a1,new C(_0x379e2b),_0x2f9f1c,_0x102a5d,_0x164cf8,_0x4749a6,_0x5507c9);}}),_0x386a2a['children']['inorderTraversal']((_0x128ce4,_0x17f75d)=>{const _0x50b13d=!_0x1f4d73['serverCache']['isCompleteForChild'](_0x128ce4)&&_0x17f75d['value']===null;if(!_0x3efb73['hasChild'](_0x128ce4)&&!_0x50b13d){const _0x5c10a8=_0x1f4d73['serverCache']['getNode']()['getImmediateChild'](_0x128ce4),_0x1cf5f9=ur(_0x3e9d06,_0x5c10a8,_0x17f75d);_0x3b45a1=En(_0x3e9d06,_0x3b45a1,new C(_0x128ce4),_0x1cf5f9,_0x102a5d,_0x164cf8,_0x4749a6,_0x5507c9);}}),_0x3b45a1;}function Nu(_0x21f8a2,_0x33b470,_0x412ad5,_0x24db6e,_0x5d4032,_0x19e7d5,_0x5f2ae8){if(vn(_0x5d4032,_0x412ad5)!=null)return _0x33b470;const _0x4c0951=_0x33b470['serverCache']['isFiltered'](),_0x1dd4a9=_0x33b470['serverCache'];if(_0x24db6e['value']!=null){if(v(_0x412ad5)&&_0x1dd4a9['isFullyInitialized']()||_0x1dd4a9['isCompleteForPath'](_0x412ad5))return En(_0x21f8a2,_0x33b470,_0x412ad5,_0x1dd4a9['getNode']()['getChild'](_0x412ad5),_0x5d4032,_0x19e7d5,_0x4c0951,_0x5f2ae8);if(v(_0x412ad5)){let _0x355439=new S(null);return _0x1dd4a9['getNode']()['forEachChild'](ye,(_0x5c198f,_0x24ec3b)=>{_0x355439=_0x355439['set'](new C(_0x5c198f),_0x24ec3b);}),bi(_0x21f8a2,_0x33b470,_0x412ad5,_0x355439,_0x5d4032,_0x19e7d5,_0x4c0951,_0x5f2ae8);}else return _0x33b470;}else{let _0x46f470=new S(null);return _0x24db6e['foreach']((_0x606088,_0x422dfd)=>{const _0x311118=k(_0x412ad5,_0x606088);_0x1dd4a9['isCompleteForPath'](_0x311118)&&(_0x46f470=_0x46f470['set'](_0x606088,_0x1dd4a9['getNode']()['getChild'](_0x311118)));}),bi(_0x21f8a2,_0x33b470,_0x412ad5,_0x46f470,_0x5d4032,_0x19e7d5,_0x4c0951,_0x5f2ae8);}}function Pu(_0x20acd4,_0x374f87,_0x5d7df8,_0x534243,_0x48fa4b){const _0x2d5047=_0x374f87['serverCache'],_0x4512b2=Uo(_0x374f87,_0x2d5047['getNode'](),_0x2d5047['isFullyInitialized']()||v(_0x5d7df8),_0x2d5047['isFiltered']());return qo(_0x20acd4,_0x4512b2,_0x5d7df8,_0x534243,Go,_0x48fa4b);}function Ou(_0x14475f,_0x442acb,_0x25de9b,_0x226c8c,_0x4e1dd6,_0xc65f13){let _0x2755a4;if(vn(_0x226c8c,_0x25de9b)!=null)return _0x442acb;{const _0x252d42=new ss(_0x226c8c,_0x442acb,_0x4e1dd6),_0x287c21=_0x442acb['eventCache']['getNode']();let _0x2c8eff;if(v(_0x25de9b)||y(_0x25de9b)==='.priority'){let _0x128194;if(_0x442acb['serverCache']['isFullyInitialized']())_0x128194=yn(_0x226c8c,We(_0x442acb));else{const _0x5b2315=_0x442acb['serverCache']['getNode']();f(_0x5b2315 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x128194=ns(_0x226c8c,_0x5b2315);}_0x128194=_0x128194,_0x2c8eff=_0x14475f['filter']['updateFullNode'](_0x287c21,_0x128194,_0xc65f13);}else{const _0x353472=y(_0x25de9b);let _0x2a53ce=is(_0x226c8c,_0x353472,_0x442acb['serverCache']);_0x2a53ce==null&&_0x442acb['serverCache']['isCompleteForChild'](_0x353472)&&(_0x2a53ce=_0x287c21['getImmediateChild'](_0x353472)),_0x2a53ce!=null?_0x2c8eff=_0x14475f['filter']['updateChild'](_0x287c21,_0x353472,_0x2a53ce,b(_0x25de9b),_0x252d42,_0xc65f13):_0x442acb['eventCache']['getNode']()['hasChild'](_0x353472)?_0x2c8eff=_0x14475f['filter']['updateChild'](_0x287c21,_0x353472,g['EMPTY_NODE'],b(_0x25de9b),_0x252d42,_0xc65f13):_0x2c8eff=_0x287c21,_0x2c8eff['isEmpty']()&&_0x442acb['serverCache']['isFullyInitialized']()&&(_0x2755a4=yn(_0x226c8c,We(_0x442acb)),_0x2755a4['isLeafNode']()&&(_0x2c8eff=_0x14475f['filter']['updateFullNode'](_0x2c8eff,_0x2755a4,_0xc65f13)));}return _0x2755a4=_0x442acb['serverCache']['isFullyInitialized']()||vn(_0x226c8c,w())!=null,Tt(_0x442acb,_0x2c8eff,_0x2755a4,_0x14475f['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x3efc64,_0x16e82b){this['query_']=_0x3efc64,this['eventRegistrations_']=[];const _0x512688=this['query_']['_queryParams'],_0xc2ceb4=new Ji(_0x512688['getIndex']()),_0x2172d3=Kh(_0x512688);this['processor_']=Su(_0x2172d3);const _0x4bd295=_0x16e82b['serverCache'],_0x2fc422=_0x16e82b['eventCache'],_0x2e07c3=_0xc2ceb4['updateFullNode'](g['EMPTY_NODE'],_0x4bd295['getNode'](),null),_0x45352d=_0x2172d3['updateFullNode'](g['EMPTY_NODE'],_0x2fc422['getNode'](),null),_0xafc223=new Ce(_0x2e07c3,_0x4bd295['isFullyInitialized'](),_0xc2ceb4['filtersNodes']()),_0x58fdf8=new Ce(_0x45352d,_0x2fc422['isFullyInitialized'](),_0x2172d3['filtersNodes']());this['viewCache_']=Mn(_0x58fdf8,_0xafc223),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x4c642a){return _0x4c642a['viewCache_']['serverCache']['getNode']();}function Lu(_0x478513){return mn(_0x478513['viewCache_']);}function xu(_0x16e49c,_0x5e9584){const _0x265e42=We(_0x16e49c['viewCache_']);return _0x265e42&&(_0x16e49c['query']['_queryParams']['loadsAllData']()||!v(_0x5e9584)&&!_0x265e42['getImmediateChild'](y(_0x5e9584))['isEmpty']())?_0x265e42['getChild'](_0x5e9584):null;}function dr(_0x3a79e2){return _0x3a79e2['eventRegistrations_']['length']===0x0;}function Fu(_0x4eeaaf,_0x2844d9){_0x4eeaaf['eventRegistrations_']['push'](_0x2844d9);}function fr(_0x57d3e2,_0x5640c0,_0x138aac){const _0x14adf0=[];if(_0x138aac){f(_0x5640c0==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x2e603f=_0x57d3e2['query']['_path'];_0x57d3e2['eventRegistrations_']['forEach'](_0x2866fb=>{const _0x5b11d0=_0x2866fb['createCancelEvent'](_0x138aac,_0x2e603f);_0x5b11d0&&_0x14adf0['push'](_0x5b11d0);});}if(_0x5640c0){let _0x19dbb7=[];for(let _0x388012=0x0;_0x388012<_0x57d3e2['eventRegistrations_']['length'];++_0x388012){const _0x2baac3=_0x57d3e2['eventRegistrations_'][_0x388012];if(!_0x2baac3['matches'](_0x5640c0))_0x19dbb7['push'](_0x2baac3);else{if(_0x5640c0['hasAnyCallback']()){_0x19dbb7=_0x19dbb7['concat'](_0x57d3e2['eventRegistrations_']['slice'](_0x388012+0x1));break;}}}_0x57d3e2['eventRegistrations_']=_0x19dbb7;}else _0x57d3e2['eventRegistrations_']=[];return _0x14adf0;}function pr(_0x1f5207,_0x5b3508,_0x137415,_0x459093){_0x5b3508['type']===j['MERGE']&&_0x5b3508['source']['queryId']!==null&&(f(We(_0x1f5207['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x1f5207['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x29c167=_0x1f5207['viewCache_'],_0x3ebd89=Ru(_0x1f5207['processor_'],_0x29c167,_0x5b3508,_0x137415,_0x459093);return bu(_0x1f5207['processor_'],_0x3ebd89['viewCache']),f(_0x3ebd89['viewCache']['serverCache']['isFullyInitialized']()||!_0x29c167['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x1f5207['viewCache_']=_0x3ebd89['viewCache'],zo(_0x1f5207,_0x3ebd89['changes'],_0x3ebd89['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x3b958e,_0x2f35c9){const _0xc6840f=_0x3b958e['viewCache_']['eventCache'],_0x49f6a7=[];return _0xc6840f['getNode']()['isLeafNode']()||_0xc6840f['getNode']()['forEachChild'](R,(_0x4769dc,_0xcefbb7)=>{_0x49f6a7['push'](et(_0x4769dc,_0xcefbb7));}),_0xc6840f['isFullyInitialized']()&&_0x49f6a7['push'](Lo(_0xc6840f['getNode']())),zo(_0x3b958e,_0x49f6a7,_0xc6840f['getNode'](),_0x2f35c9);}function zo(_0x2c2ab2,_0x55be14,_0x4716d7,_0x14b0f2){const _0x1c6a5b=_0x14b0f2?[_0x14b0f2]:_0x2c2ab2['eventRegistrations_'];return ru(_0x2c2ab2['eventGenerator_'],_0x55be14,_0x4716d7,_0x1c6a5b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x104283){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x104283;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x5f473c){return _0x5f473c['views']['size']===0x0;}function rs(_0x5f4ae8,_0x598391,_0x316d65,_0x15ec8b){const _0x19b580=_0x598391['source']['queryId'];if(_0x19b580!==null){const _0x1ffb7c=_0x5f4ae8['views']['get'](_0x19b580);return f(_0x1ffb7c!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x1ffb7c,_0x598391,_0x316d65,_0x15ec8b);}else{let _0xec20e8=[];for(const _0x1a3b5d of _0x5f4ae8['views']['values']())_0xec20e8=_0xec20e8['concat'](pr(_0x1a3b5d,_0x598391,_0x316d65,_0x15ec8b));return _0xec20e8;}}function Ko(_0x596246,_0x56b098,_0x1c543d,_0x2f5f19,_0x10737a){const _0x547c57=_0x56b098['_queryIdentifier'],_0x37de73=_0x596246['views']['get'](_0x547c57);if(!_0x37de73){let _0x45fbdd=yn(_0x1c543d,_0x10737a?_0x2f5f19:null),_0x375593=!0x1;_0x45fbdd?_0x375593=!0x0:_0x2f5f19 instanceof g?(_0x45fbdd=ns(_0x1c543d,_0x2f5f19),_0x375593=!0x1):(_0x45fbdd=g['EMPTY_NODE'],_0x375593=!0x1);const _0xe436f0=Mn(new Ce(_0x45fbdd,_0x375593,!0x1),new Ce(_0x2f5f19,_0x10737a,!0x1));return new Du(_0x56b098,_0xe436f0);}return _0x37de73;}function Hu(_0x1d9c40,_0x5922dd,_0x56c7c2,_0x199ffe,_0x124973,_0x33a38f){const _0x3e488f=Ko(_0x1d9c40,_0x5922dd,_0x199ffe,_0x124973,_0x33a38f);return _0x1d9c40['views']['has'](_0x5922dd['_queryIdentifier'])||_0x1d9c40['views']['set'](_0x5922dd['_queryIdentifier'],_0x3e488f),Fu(_0x3e488f,_0x56c7c2),Uu(_0x3e488f,_0x56c7c2);}function $u(_0x4bf807,_0x2b4e97,_0x3b47a6,_0x124887){const _0x1ba10f=_0x2b4e97['_queryIdentifier'],_0x185da1=[];let _0x26efb9=[];const _0x2cd111=Te(_0x4bf807);if(_0x1ba10f==='default'){for(const [_0x546902,_0x354272]of _0x4bf807['views']['entries']())_0x26efb9=_0x26efb9['concat'](fr(_0x354272,_0x3b47a6,_0x124887)),dr(_0x354272)&&(_0x4bf807['views']['delete'](_0x546902),_0x354272['query']['_queryParams']['loadsAllData']()||_0x185da1['push'](_0x354272['query']));}else{const _0x414d28=_0x4bf807['views']['get'](_0x1ba10f);_0x414d28&&(_0x26efb9=_0x26efb9['concat'](fr(_0x414d28,_0x3b47a6,_0x124887)),dr(_0x414d28)&&(_0x4bf807['views']['delete'](_0x1ba10f),_0x414d28['query']['_queryParams']['loadsAllData']()||_0x185da1['push'](_0x414d28['query'])));}return _0x2cd111&&!Te(_0x4bf807)&&_0x185da1['push'](new(Bu())(_0x2b4e97['_repo'],_0x2b4e97['_path'])),{'removed':_0x185da1,'events':_0x26efb9};}function Yo(_0x120253){const _0x497821=[];for(const _0x367f1c of _0x120253['views']['values']())_0x367f1c['query']['_queryParams']['loadsAllData']()||_0x497821['push'](_0x367f1c);return _0x497821;}function Ee(_0x5559dc,_0x1e3e84){let _0x50518a=null;for(const _0x50ccf8 of _0x5559dc['views']['values']())_0x50518a=_0x50518a||xu(_0x50ccf8,_0x1e3e84);return _0x50518a;}function Qo(_0x13e53d,_0x4812c4){if(_0x4812c4['_queryParams']['loadsAllData']())return xn(_0x13e53d);{const _0x577ad4=_0x4812c4['_queryIdentifier'];return _0x13e53d['views']['get'](_0x577ad4);}}function Jo(_0x4c99fa,_0x276b7e){return Qo(_0x4c99fa,_0x276b7e)!=null;}function Te(_0x255fcb){return xn(_0x255fcb)!=null;}function xn(_0xab52ce){for(const _0x5d88b9 of _0xab52ce['views']['values']())if(_0x5d88b9['query']['_queryParams']['loadsAllData']())return _0x5d88b9;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x3cfc0d){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x3cfc0d;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x135ca7){this['listenProvider_']=_0x135ca7,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x597aab,_0x116381,_0x304243,_0x3af48a,_0x3d36cb){return lu(_0x597aab['pendingWriteTree_'],_0x116381,_0x304243,_0x3af48a,_0x3d36cb),_0x3d36cb?ut(_0x597aab,new Ue(Zi(),_0x116381,_0x304243)):[];}function ju(_0x43b52f,_0x411254,_0x41c8dc,_0x4681e0){hu(_0x43b52f['pendingWriteTree_'],_0x411254,_0x41c8dc,_0x4681e0);const _0x536044=S['fromObject'](_0x41c8dc);return ut(_0x43b52f,new tt(Zi(),_0x411254,_0x536044));}function pe(_0x421a6e,_0x3ee4c8,_0x42a079=!0x1){const _0x238c2c=uu(_0x421a6e['pendingWriteTree_'],_0x3ee4c8);if(du(_0x421a6e['pendingWriteTree_'],_0x3ee4c8)){let _0x358909=new S(null);return _0x238c2c['snap']!=null?_0x358909=_0x358909['set'](w(),!0x0):x(_0x238c2c['children'],_0x13c9f6=>{_0x358909=_0x358909['set'](new C(_0x13c9f6),!0x0);}),ut(_0x421a6e,new gn(_0x238c2c['path'],_0x358909,_0x42a079));}else return[];}function Gt(_0x4d5b5b,_0x384b4b,_0x34a835){return ut(_0x4d5b5b,new Ue(es(),_0x384b4b,_0x34a835));}function Ku(_0x4b6308,_0x176a95,_0xaf93a6){const _0x468369=S['fromObject'](_0xaf93a6);return ut(_0x4b6308,new tt(es(),_0x176a95,_0x468369));}function Yu(_0x22446b,_0x13bac5){return ut(_0x22446b,new Lt(es(),_0x13bac5));}function Qu(_0x4ae0b6,_0x30fd32,_0x3ec26a){const _0x16f215=as(_0x4ae0b6,_0x3ec26a);if(_0x16f215){const _0x2582f3=cs(_0x16f215),_0xcc9271=_0x2582f3['path'],_0x18da8c=_0x2582f3['queryId'],_0x48bad5=F(_0xcc9271,_0x30fd32),_0x37b6f2=new Lt(ts(_0x18da8c),_0x48bad5);return ls(_0x4ae0b6,_0xcc9271,_0x37b6f2);}else return[];}function Cn(_0x1a929c,_0x211f2e,_0x214fa3,_0x326a32,_0x5159a6=!0x1){const _0x169bf1=_0x211f2e['_path'],_0x11abc0=_0x1a929c['syncPointTree_']['get'](_0x169bf1);let _0x27b3ac=[];if(_0x11abc0&&(_0x211f2e['_queryIdentifier']==='default'||Jo(_0x11abc0,_0x211f2e))){const _0x30b42a=$u(_0x11abc0,_0x211f2e,_0x214fa3,_0x326a32);Vu(_0x11abc0)&&(_0x1a929c['syncPointTree_']=_0x1a929c['syncPointTree_']['remove'](_0x169bf1));const _0x4a8f80=_0x30b42a['removed'];if(_0x27b3ac=_0x30b42a['events'],!_0x5159a6){const _0x407d8c=_0x4a8f80['findIndex'](_0x44c4ac=>_0x44c4ac['_queryParams']['loadsAllData']())!==-0x1,_0x3199e4=_0x1a929c['syncPointTree_']['findOnPath'](_0x169bf1,(_0x2800ef,_0x5d2f55)=>Te(_0x5d2f55));if(_0x407d8c&&!_0x3199e4){const _0xef8a1=_0x1a929c['syncPointTree_']['subtree'](_0x169bf1);if(!_0xef8a1['isEmpty']()){const _0x513ae1=Zu(_0xef8a1);for(let _0x5af00f=0x0;_0x5af00f<_0x513ae1['length'];++_0x5af00f){const _0x5866b0=_0x513ae1[_0x5af00f],_0x53311a=_0x5866b0['query'],_0x4206e0=ta(_0x1a929c,_0x5866b0);_0x1a929c['listenProvider_']['startListening'](bt(_0x53311a),xt(_0x1a929c,_0x53311a),_0x4206e0['hashFn'],_0x4206e0['onComplete']);}}}!_0x3199e4&&_0x4a8f80['length']>0x0&&!_0x326a32&&(_0x407d8c?_0x1a929c['listenProvider_']['stopListening'](bt(_0x211f2e),null):_0x4a8f80['forEach'](_0x141683=>{const _0xdc7e1a=_0x1a929c['queryToTagMap']['get'](Un(_0x141683));_0x1a929c['listenProvider_']['stopListening'](bt(_0x141683),_0xdc7e1a);}));}ed(_0x1a929c,_0x4a8f80);}return _0x27b3ac;}function Xo(_0x3ed4de,_0x4e741f,_0x42a161,_0x29c0bb){const _0x4e2553=as(_0x3ed4de,_0x29c0bb);if(_0x4e2553!=null){const _0x55dcbb=cs(_0x4e2553),_0x31fc45=_0x55dcbb['path'],_0x588b9d=_0x55dcbb['queryId'],_0xba3d2e=F(_0x31fc45,_0x4e741f),_0x5e5eca=new Ue(ts(_0x588b9d),_0xba3d2e,_0x42a161);return ls(_0x3ed4de,_0x31fc45,_0x5e5eca);}else return[];}function Ju(_0x374cdb,_0x384833,_0x5bfd51,_0xac5873){const _0x46e815=as(_0x374cdb,_0xac5873);if(_0x46e815){const _0x3bf1a2=cs(_0x46e815),_0x5165b1=_0x3bf1a2['path'],_0x9f4612=_0x3bf1a2['queryId'],_0x56523a=F(_0x5165b1,_0x384833),_0x3defd6=S['fromObject'](_0x5bfd51),_0x54da32=new tt(ts(_0x9f4612),_0x56523a,_0x3defd6);return ls(_0x374cdb,_0x5165b1,_0x54da32);}else return[];}function Ri(_0xfa0c,_0xf6656,_0x1efcb7,_0x4e8b6a=!0x1){const _0x609d71=_0xf6656['_path'];let _0x31204b=null,_0x1ed210=!0x1;_0xfa0c['syncPointTree_']['foreachOnPath'](_0x609d71,(_0x3f8861,_0x901405)=>{const _0x17074f=F(_0x3f8861,_0x609d71);_0x31204b=_0x31204b||Ee(_0x901405,_0x17074f),_0x1ed210=_0x1ed210||Te(_0x901405);});let _0x2b62ac=_0xfa0c['syncPointTree_']['get'](_0x609d71);_0x2b62ac?(_0x1ed210=_0x1ed210||Te(_0x2b62ac),_0x31204b=_0x31204b||Ee(_0x2b62ac,w())):(_0x2b62ac=new jo(),_0xfa0c['syncPointTree_']=_0xfa0c['syncPointTree_']['set'](_0x609d71,_0x2b62ac));let _0x303f49;_0x31204b!=null?_0x303f49=!0x0:(_0x303f49=!0x1,_0x31204b=g['EMPTY_NODE'],_0xfa0c['syncPointTree_']['subtree'](_0x609d71)['foreachChild']((_0x502592,_0x4b2ad0)=>{const _0x4ee6b0=Ee(_0x4b2ad0,w());_0x4ee6b0&&(_0x31204b=_0x31204b['updateImmediateChild'](_0x502592,_0x4ee6b0));}));const _0x488465=Jo(_0x2b62ac,_0xf6656);if(!_0x488465&&!_0xf6656['_queryParams']['loadsAllData']()){const _0x2b4b79=Un(_0xf6656);f(!_0xfa0c['queryToTagMap']['has'](_0x2b4b79),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x381860=td();_0xfa0c['queryToTagMap']['set'](_0x2b4b79,_0x381860),_0xfa0c['tagToQueryMap']['set'](_0x381860,_0x2b4b79);}const _0x2b809a=Ln(_0xfa0c['pendingWriteTree_'],_0x609d71);let _0x1fec1e=Hu(_0x2b62ac,_0xf6656,_0x1efcb7,_0x2b809a,_0x31204b,_0x303f49);if(!_0x488465&&!_0x1ed210&&!_0x4e8b6a){const _0x1bd8a5=Qo(_0x2b62ac,_0xf6656);_0x1fec1e=_0x1fec1e['concat'](nd(_0xfa0c,_0xf6656,_0x1bd8a5));}return _0x1fec1e;}function Fn(_0x27c8c5,_0x3ca904,_0x1a7326){const _0x3db6fc=_0x27c8c5['pendingWriteTree_'],_0x14b757=_0x27c8c5['syncPointTree_']['findOnPath'](_0x3ca904,(_0x4000b2,_0x5a29f1)=>{const _0x21552d=F(_0x4000b2,_0x3ca904),_0x5c0b30=Ee(_0x5a29f1,_0x21552d);if(_0x5c0b30)return _0x5c0b30;});return Vo(_0x3db6fc,_0x3ca904,_0x14b757,_0x1a7326,!0x0);}function Xu(_0x32973f,_0x1b89c8){const _0x530df2=_0x1b89c8['_path'];let _0x1f2a32=null;_0x32973f['syncPointTree_']['foreachOnPath'](_0x530df2,(_0x390d9e,_0x5ed4ec)=>{const _0x444e8d=F(_0x390d9e,_0x530df2);_0x1f2a32=_0x1f2a32||Ee(_0x5ed4ec,_0x444e8d);});let _0x36d541=_0x32973f['syncPointTree_']['get'](_0x530df2);_0x36d541?_0x1f2a32=_0x1f2a32||Ee(_0x36d541,w()):(_0x36d541=new jo(),_0x32973f['syncPointTree_']=_0x32973f['syncPointTree_']['set'](_0x530df2,_0x36d541));const _0x2a8e5e=_0x1f2a32!=null,_0x431b26=_0x2a8e5e?new Ce(_0x1f2a32,!0x0,!0x1):null,_0x36156b=Ln(_0x32973f['pendingWriteTree_'],_0x1b89c8['_path']),_0x319f40=Ko(_0x36d541,_0x1b89c8,_0x36156b,_0x2a8e5e?_0x431b26['getNode']():g['EMPTY_NODE'],_0x2a8e5e);return Lu(_0x319f40);}function ut(_0x55a28f,_0x5839c4){return Zo(_0x5839c4,_0x55a28f['syncPointTree_'],null,Ln(_0x55a28f['pendingWriteTree_'],w()));}function Zo(_0xde1a7e,_0x2d7060,_0x27403c,_0xcc3323){if(v(_0xde1a7e['path']))return ea(_0xde1a7e,_0x2d7060,_0x27403c,_0xcc3323);{const _0x37a113=_0x2d7060['get'](w());_0x27403c==null&&_0x37a113!=null&&(_0x27403c=Ee(_0x37a113,w()));let _0x42413b=[];const _0x59a0b3=y(_0xde1a7e['path']),_0x5916f7=_0xde1a7e['operationForChild'](_0x59a0b3),_0x39d3fe=_0x2d7060['children']['get'](_0x59a0b3);if(_0x39d3fe&&_0x5916f7){const _0x24a3b8=_0x27403c?_0x27403c['getImmediateChild'](_0x59a0b3):null,_0x5ab8ef=Ho(_0xcc3323,_0x59a0b3);_0x42413b=_0x42413b['concat'](Zo(_0x5916f7,_0x39d3fe,_0x24a3b8,_0x5ab8ef));}return _0x37a113&&(_0x42413b=_0x42413b['concat'](rs(_0x37a113,_0xde1a7e,_0xcc3323,_0x27403c))),_0x42413b;}}function ea(_0x103508,_0x1f8771,_0x8bbfbe,_0x1886e2){const _0x2a3046=_0x1f8771['get'](w());_0x8bbfbe==null&&_0x2a3046!=null&&(_0x8bbfbe=Ee(_0x2a3046,w()));let _0x13fc68=[];return _0x1f8771['children']['inorderTraversal']((_0x395949,_0x40ea02)=>{const _0x45760f=_0x8bbfbe?_0x8bbfbe['getImmediateChild'](_0x395949):null,_0x1370f5=Ho(_0x1886e2,_0x395949),_0x2cff11=_0x103508['operationForChild'](_0x395949);_0x2cff11&&(_0x13fc68=_0x13fc68['concat'](ea(_0x2cff11,_0x40ea02,_0x45760f,_0x1370f5)));}),_0x2a3046&&(_0x13fc68=_0x13fc68['concat'](rs(_0x2a3046,_0x103508,_0x1886e2,_0x8bbfbe))),_0x13fc68;}function ta(_0x2c95da,_0x5c3f02){const _0x3a1936=_0x5c3f02['query'],_0x226e2c=xt(_0x2c95da,_0x3a1936);return{'hashFn':()=>(Mu(_0x5c3f02)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x27cf92=>{if(_0x27cf92==='ok')return _0x226e2c?Qu(_0x2c95da,_0x3a1936['_path'],_0x226e2c):Yu(_0x2c95da,_0x3a1936['_path']);{const _0xc83870=Kl(_0x27cf92,_0x3a1936);return Cn(_0x2c95da,_0x3a1936,null,_0xc83870);}}};}function xt(_0x268bd2,_0x59bc4f){const _0x4d4971=Un(_0x59bc4f);return _0x268bd2['queryToTagMap']['get'](_0x4d4971);}function Un(_0x57d65e){return _0x57d65e['_path']['toString']()+'$'+_0x57d65e['_queryIdentifier'];}function as(_0x33df13,_0x4db3c1){return _0x33df13['tagToQueryMap']['get'](_0x4db3c1);}function cs(_0x1d2ebc){const _0x43b07a=_0x1d2ebc['indexOf']('$');return f(_0x43b07a!==-0x1&&_0x43b07a<_0x1d2ebc['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x1d2ebc['substr'](_0x43b07a+0x1),'path':new C(_0x1d2ebc['substr'](0x0,_0x43b07a))};}function ls(_0x525c16,_0x1a86bb,_0x1c324){const _0x192532=_0x525c16['syncPointTree_']['get'](_0x1a86bb);f(_0x192532,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x488c65=Ln(_0x525c16['pendingWriteTree_'],_0x1a86bb);return rs(_0x192532,_0x1c324,_0x488c65,null);}function Zu(_0x2d743b){return _0x2d743b['fold']((_0x244271,_0x529673,_0x54d82f)=>{if(_0x529673&&Te(_0x529673))return[xn(_0x529673)];{let _0x3dba53=[];return _0x529673&&(_0x3dba53=Yo(_0x529673)),x(_0x54d82f,(_0x86980b,_0x512b87)=>{_0x3dba53=_0x3dba53['concat'](_0x512b87);}),_0x3dba53;}});}function bt(_0x3ca4e7){return _0x3ca4e7['_queryParams']['loadsAllData']()&&!_0x3ca4e7['_queryParams']['isDefault']()?new(qu())(_0x3ca4e7['_repo'],_0x3ca4e7['_path']):_0x3ca4e7;}function ed(_0xe95431,_0x5357df){for(let _0xadaebe=0x0;_0xadaebe<_0x5357df['length'];++_0xadaebe){const _0x5abc42=_0x5357df[_0xadaebe];if(!_0x5abc42['_queryParams']['loadsAllData']()){const _0x5f3acf=Un(_0x5abc42),_0x52e981=_0xe95431['queryToTagMap']['get'](_0x5f3acf);_0xe95431['queryToTagMap']['delete'](_0x5f3acf),_0xe95431['tagToQueryMap']['delete'](_0x52e981);}}}function td(){return zu++;}function nd(_0x2d8647,_0x15edb3,_0x3590c0){const _0x3fa2ba=_0x15edb3['_path'],_0x26220a=xt(_0x2d8647,_0x15edb3),_0x4295bc=ta(_0x2d8647,_0x3590c0),_0x11163e=_0x2d8647['listenProvider_']['startListening'](bt(_0x15edb3),_0x26220a,_0x4295bc['hashFn'],_0x4295bc['onComplete']),_0x227b0d=_0x2d8647['syncPointTree_']['subtree'](_0x3fa2ba);if(_0x26220a)f(!Te(_0x227b0d['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x344624=_0x227b0d['fold']((_0x1f2ec4,_0x1188cf,_0x358f18)=>{if(!v(_0x1f2ec4)&&_0x1188cf&&Te(_0x1188cf))return[xn(_0x1188cf)['query']];{let _0xeb81c9=[];return _0x1188cf&&(_0xeb81c9=_0xeb81c9['concat'](Yo(_0x1188cf)['map'](_0x541697=>_0x541697['query']))),x(_0x358f18,(_0x31de38,_0x31e839)=>{_0xeb81c9=_0xeb81c9['concat'](_0x31e839);}),_0xeb81c9;}});for(let _0x317448=0x0;_0x317448<_0x344624['length'];++_0x317448){const _0x1c467b=_0x344624[_0x317448];_0x2d8647['listenProvider_']['stopListening'](bt(_0x1c467b),xt(_0x2d8647,_0x1c467b));}}return _0x11163e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x2af3a0){this['node_']=_0x2af3a0;}['getImmediateChild'](_0x1bf069){const _0x490f24=this['node_']['getImmediateChild'](_0x1bf069);return new hs(_0x490f24);}['node'](){return this['node_'];}}class us{constructor(_0x8055b9,_0xa801d7){this['syncTree_']=_0x8055b9,this['path_']=_0xa801d7;}['getImmediateChild'](_0x143915){const _0x42f8ec=k(this['path_'],_0x143915);return new us(this['syncTree_'],_0x42f8ec);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x46dd1b){return _0x46dd1b=_0x46dd1b||{},_0x46dd1b['timestamp']=_0x46dd1b['timestamp']||new Date()['getTime'](),_0x46dd1b;},gr=function(_0x317151,_0x111915,_0x2ab483){if(!_0x317151||typeof _0x317151!='object')return _0x317151;if(f('.sv'in _0x317151,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x317151['.sv']=='string')return sd(_0x317151['.sv'],_0x111915,_0x2ab483);if(typeof _0x317151['.sv']=='object')return rd(_0x317151['.sv'],_0x111915);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x317151,null,0x2));},sd=function(_0x532843,_0x61ddac,_0x1a5dda){switch(_0x532843){case'timestamp':return _0x1a5dda['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x532843);}},rd=function(_0x293b75,_0x9851bc,_0x35f651){_0x293b75['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x293b75,null,0x2));const _0x342d22=_0x293b75['increment'];typeof _0x342d22!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x342d22);const _0x532fca=_0x9851bc['node']();if(f(_0x532fca!==null&&typeof _0x532fca<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x532fca['isLeafNode']())return _0x342d22;const _0xc61310=_0x532fca['getValue']();return typeof _0xc61310!='number'?_0x342d22:_0xc61310+_0x342d22;},na=function(_0x25a3c8,_0x38e6ff,_0x23c40b,_0x1027fa){return fs(_0x38e6ff,new us(_0x23c40b,_0x25a3c8),_0x1027fa);},ds=function(_0x391a47,_0x3b4a3b,_0x4bfa5a){return fs(_0x391a47,new hs(_0x3b4a3b),_0x4bfa5a);};function fs(_0x4aba18,_0x555af6,_0x39cd96){const _0x5e9b38=_0x4aba18['getPriority']()['val'](),_0x153277=gr(_0x5e9b38,_0x555af6['getImmediateChild']('.priority'),_0x39cd96);let _0x2561c1;if(_0x4aba18['isLeafNode']()){const _0x2e750b=_0x4aba18,_0x545fb9=gr(_0x2e750b['getValue'](),_0x555af6,_0x39cd96);return _0x545fb9!==_0x2e750b['getValue']()||_0x153277!==_0x2e750b['getPriority']()['val']()?new D(_0x545fb9,P(_0x153277)):_0x4aba18;}else{const _0x19cfc0=_0x4aba18;return _0x2561c1=_0x19cfc0,_0x153277!==_0x19cfc0['getPriority']()['val']()&&(_0x2561c1=_0x2561c1['updatePriority'](new D(_0x153277))),_0x19cfc0['forEachChild'](R,(_0x309b04,_0x1cd902)=>{const _0x378230=fs(_0x1cd902,_0x555af6['getImmediateChild'](_0x309b04),_0x39cd96);_0x378230!==_0x1cd902&&(_0x2561c1=_0x2561c1['updateImmediateChild'](_0x309b04,_0x378230));}),_0x2561c1;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x52b2da='',_0x45f28a=null,_0x31315e={'children':{},'childCount':0x0}){this['name']=_0x52b2da,this['parent']=_0x45f28a,this['node']=_0x31315e;}}function Wn(_0x531a4b,_0x343c3b){let _0x11de2f=_0x343c3b instanceof C?_0x343c3b:new C(_0x343c3b),_0x339f70=_0x531a4b,_0x58133c=y(_0x11de2f);for(;_0x58133c!==null;){const _0x19a3e5=De(_0x339f70['node']['children'],_0x58133c)||{'children':{},'childCount':0x0};_0x339f70=new ps(_0x58133c,_0x339f70,_0x19a3e5),_0x11de2f=b(_0x11de2f),_0x58133c=y(_0x11de2f);}return _0x339f70;}function Ge(_0x483ddd){return _0x483ddd['node']['value'];}function _s(_0x3be740,_0x277c40){_0x3be740['node']['value']=_0x277c40,Ai(_0x3be740);}function ia(_0x418522){return _0x418522['node']['childCount']>0x0;}function od(_0x1a5d51){return Ge(_0x1a5d51)===void 0x0&&!ia(_0x1a5d51);}function Bn(_0x27ed11,_0x4468ce){x(_0x27ed11['node']['children'],(_0x9349e2,_0x17379b)=>{_0x4468ce(new ps(_0x9349e2,_0x27ed11,_0x17379b));});}function sa(_0x30cfad,_0xa3e772,_0x15ea68,_0x4cebc8){_0x15ea68&&_0xa3e772(_0x30cfad),Bn(_0x30cfad,_0x3fa8d7=>{sa(_0x3fa8d7,_0xa3e772,!0x0);});}function ad(_0x4abeac,_0x291633,_0xcb7030){let _0x7e76d1=_0x4abeac['parent'];for(;_0x7e76d1!==null;){if(_0x291633(_0x7e76d1))return!0x0;_0x7e76d1=_0x7e76d1['parent'];}return!0x1;}function qt(_0x253a9c){return new C(_0x253a9c['parent']===null?_0x253a9c['name']:qt(_0x253a9c['parent'])+'/'+_0x253a9c['name']);}function Ai(_0xbe869d){_0xbe869d['parent']!==null&&cd(_0xbe869d['parent'],_0xbe869d['name'],_0xbe869d);}function cd(_0x2013d5,_0x1ff097,_0x15c7d0){const _0x41d0a3=od(_0x15c7d0),_0x425e95=J(_0x2013d5['node']['children'],_0x1ff097);_0x41d0a3&&_0x425e95?(delete _0x2013d5['node']['children'][_0x1ff097],_0x2013d5['node']['childCount']--,Ai(_0x2013d5)):!_0x41d0a3&&!_0x425e95&&(_0x2013d5['node']['children'][_0x1ff097]=_0x15c7d0['node'],_0x2013d5['node']['childCount']++,Ai(_0x2013d5));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x3868dd){return typeof _0x3868dd=='string'&&_0x3868dd['length']!==0x0&&!ld['test'](_0x3868dd);},ra=function(_0x2581b4){return typeof _0x2581b4=='string'&&_0x2581b4['length']!==0x0&&!hd['test'](_0x2581b4);},ud=function(_0x5ca467){return _0x5ca467&&(_0x5ca467=_0x5ca467['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x5ca467);},Tn=function(_0x4233e3){return _0x4233e3===null||typeof _0x4233e3=='string'||typeof _0x4233e3=='number'&&!Vi(_0x4233e3)||_0x4233e3&&typeof _0x4233e3=='object'&&J(_0x4233e3,'.sv');},zt=function(_0x26a7c4,_0x49e3da,_0x5ded6f,_0x4cc043){_0x4cc043&&_0x49e3da===void 0x0||jt(Pn(_0x26a7c4,'value'),_0x49e3da,_0x5ded6f);},jt=function(_0x1c8387,_0x4456f0,_0x55725b){const _0x788843=_0x55725b instanceof C?new Ah(_0x55725b,_0x1c8387):_0x55725b;if(_0x4456f0===void 0x0)throw new Error(_0x1c8387+'contains\x20undefined\x20'+Pe(_0x788843));if(typeof _0x4456f0=='function')throw new Error(_0x1c8387+'contains\x20a\x20function\x20'+Pe(_0x788843)+'\x20with\x20contents\x20=\x20'+_0x4456f0['toString']());if(Vi(_0x4456f0))throw new Error(_0x1c8387+'contains\x20'+_0x4456f0['toString']()+'\x20'+Pe(_0x788843));if(typeof _0x4456f0=='string'&&_0x4456f0['length']>ai/0x3&&On(_0x4456f0)>ai)throw new Error(_0x1c8387+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x788843)+'\x20(\x27'+_0x4456f0['substring'](0x0,0x32)+'...\x27)');if(_0x4456f0&&typeof _0x4456f0=='object'){let _0x45a7ea=!0x1,_0x3850df=!0x1;if(x(_0x4456f0,(_0x58846c,_0x541ea4)=>{if(_0x58846c==='.value')_0x45a7ea=!0x0;else{if(_0x58846c!=='.priority'&&_0x58846c!=='.sv'&&(_0x3850df=!0x0,!gs(_0x58846c)))throw new Error(_0x1c8387+'\x20contains\x20an\x20invalid\x20key\x20('+_0x58846c+')\x20'+Pe(_0x788843)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x788843,_0x58846c),jt(_0x1c8387,_0x541ea4,_0x788843),Nh(_0x788843);}),_0x45a7ea&&_0x3850df)throw new Error(_0x1c8387+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x788843)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x54ff01,_0x4abb42){let _0x17f0cd,_0x91bef3;for(_0x17f0cd=0x0;_0x17f0cd<_0x4abb42['length'];_0x17f0cd++){_0x91bef3=_0x4abb42[_0x17f0cd];const _0x30fce0=Pt(_0x91bef3);for(let _0x44824d=0x0;_0x44824d<_0x30fce0['length'];_0x44824d++)if(!(_0x30fce0[_0x44824d]==='.priority'&&_0x44824d===_0x30fce0['length']-0x1)){if(!gs(_0x30fce0[_0x44824d]))throw new Error(_0x54ff01+'contains\x20an\x20invalid\x20key\x20('+_0x30fce0[_0x44824d]+')\x20in\x20path\x20'+_0x91bef3['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x4abb42['sort'](Rh);let _0x5c26ee=null;for(_0x17f0cd=0x0;_0x17f0cd<_0x4abb42['length'];_0x17f0cd++){if(_0x91bef3=_0x4abb42[_0x17f0cd],_0x5c26ee!==null&&G(_0x5c26ee,_0x91bef3))throw new Error(_0x54ff01+'contains\x20a\x20path\x20'+_0x5c26ee['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x91bef3['toString']());_0x5c26ee=_0x91bef3;}},fd=function(_0x4d925b,_0x11d301,_0x52bf96,_0x247c68){const _0xcf3ee8=Pn(_0x4d925b,'values');if(!(_0x11d301&&typeof _0x11d301=='object')||Array['isArray'](_0x11d301))throw new Error(_0xcf3ee8+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x55d96f=[];x(_0x11d301,(_0x4857b0,_0x51a31a)=>{const _0x41413e=new C(_0x4857b0);if(jt(_0xcf3ee8,_0x51a31a,k(_0x52bf96,_0x41413e)),zi(_0x41413e)==='.priority'&&!Tn(_0x51a31a))throw new Error(_0xcf3ee8+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x41413e['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x55d96f['push'](_0x41413e);}),dd(_0xcf3ee8,_0x55d96f);},ms=function(_0x535cac,_0x33c260,_0x326d15,_0x157407){if(!ra(_0x326d15))throw new Error(Pn(_0x535cac,_0x33c260)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x326d15+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x33ee9b,_0x1c948d,_0x501326,_0x30b1f8){_0x501326&&(_0x501326=_0x501326['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x33ee9b,_0x1c948d,_0x501326);},ys=function(_0x46cbf1,_0x226ac9){if(y(_0x226ac9)==='.info')throw new Error(_0x46cbf1+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x484c97,_0x31a880){const _0x1e1181=_0x31a880['path']['toString']();if(typeof _0x31a880['repoInfo']['host']!='string'||_0x31a880['repoInfo']['host']['length']===0x0||!gs(_0x31a880['repoInfo']['namespace'])&&_0x31a880['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x1e1181['length']!==0x0&&!ud(_0x1e1181))throw new Error(Pn(_0x484c97,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x1117de,_0xdd4aa1){let _0x154030=null;for(let _0x70efdd=0x0;_0x70efdd<_0xdd4aa1['length'];_0x70efdd++){const _0xc4437e=_0xdd4aa1[_0x70efdd],_0x455b87=_0xc4437e['getPath']();_0x154030!==null&&!ji(_0x455b87,_0x154030['path'])&&(_0x1117de['eventLists_']['push'](_0x154030),_0x154030=null),_0x154030===null&&(_0x154030={'events':[],'path':_0x455b87}),_0x154030['events']['push'](_0xc4437e);}_0x154030&&_0x1117de['eventLists_']['push'](_0x154030);}function oa(_0x14999a,_0x2d0b2b,_0x204808){Vn(_0x14999a,_0x204808),aa(_0x14999a,_0x3eb87d=>ji(_0x3eb87d,_0x2d0b2b));}function H(_0x3f0a8f,_0x984d76,_0x13ccca){Vn(_0x3f0a8f,_0x13ccca),aa(_0x3f0a8f,_0x461c54=>G(_0x461c54,_0x984d76)||G(_0x984d76,_0x461c54));}function aa(_0x5ebefc,_0x55846d){_0x5ebefc['recursionDepth_']++;let _0x14834a=!0x0;for(let _0x3c9371=0x0;_0x3c9371<_0x5ebefc['eventLists_']['length'];_0x3c9371++){const _0x4ac910=_0x5ebefc['eventLists_'][_0x3c9371];if(_0x4ac910){const _0x33b44f=_0x4ac910['path'];_0x55846d(_0x33b44f)?(md(_0x5ebefc['eventLists_'][_0x3c9371]),_0x5ebefc['eventLists_'][_0x3c9371]=null):_0x14834a=!0x1;}}_0x14834a&&(_0x5ebefc['eventLists_']=[]),_0x5ebefc['recursionDepth_']--;}function md(_0x2f4508){for(let _0x1feeb2=0x0;_0x1feeb2<_0x2f4508['events']['length'];_0x1feeb2++){const _0x2ff4fb=_0x2f4508['events'][_0x1feeb2];if(_0x2ff4fb!==null){_0x2f4508['events'][_0x1feeb2]=null;const _0x39e6cf=_0x2ff4fb['getEventRunner']();wt&&L('event:\x20'+_0x2ff4fb['toString']()),ht(_0x39e6cf);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x248303,_0x1162b9,_0x568e6d,_0x1595dd){this['repoInfo_']=_0x248303,this['forceRestClient_']=_0x1162b9,this['authTokenProvider_']=_0x568e6d,this['appCheckProvider_']=_0x1595dd,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0xb06206,_0x4c9262,_0x22f685){if(_0xb06206['stats_']=Gi(_0xb06206['repoInfo_']),_0xb06206['forceRestClient_']||Xl())_0xb06206['server_']=new pn(_0xb06206['repoInfo_'],(_0x5bfb9b,_0x213571,_0x63c5b1,_0x19337d)=>{mr(_0xb06206,_0x5bfb9b,_0x213571,_0x63c5b1,_0x19337d);},_0xb06206['authTokenProvider_'],_0xb06206['appCheckProvider_']),setTimeout(()=>yr(_0xb06206,!0x0),0x0);else{if(typeof _0x22f685<'u'&&_0x22f685!==null){if(typeof _0x22f685!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x22f685);}catch(_0x29f2ee){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x29f2ee);}}_0xb06206['persistentConnection_']=new se(_0xb06206['repoInfo_'],_0x4c9262,(_0x31a775,_0x403604,_0x18485a,_0x91f773)=>{mr(_0xb06206,_0x31a775,_0x403604,_0x18485a,_0x91f773);},_0x2133a1=>{yr(_0xb06206,_0x2133a1);},_0x233fe8=>{Id(_0xb06206,_0x233fe8);},_0xb06206['authTokenProvider_'],_0xb06206['appCheckProvider_'],_0x22f685),_0xb06206['server_']=_0xb06206['persistentConnection_'];}_0xb06206['authTokenProvider_']['addTokenChangeListener'](_0x11bb59=>{_0xb06206['server_']['refreshAuthToken'](_0x11bb59);}),_0xb06206['appCheckProvider_']['addTokenChangeListener'](_0x8770c1=>{_0xb06206['server_']['refreshAppCheckToken'](_0x8770c1['token']);}),_0xb06206['statsReporter_']=ih(_0xb06206['repoInfo_'],()=>new iu(_0xb06206['stats_'],_0xb06206['server_'])),_0xb06206['infoData_']=new Xh(),_0xb06206['infoSyncTree_']=new _r({'startListening':(_0x11eb85,_0x563a40,_0x5602cf,_0x34cbc7)=>{let _0x27c6cf=[];const _0x3fd9c6=_0xb06206['infoData_']['getNode'](_0x11eb85['_path']);return _0x3fd9c6['isEmpty']()||(_0x27c6cf=Gt(_0xb06206['infoSyncTree_'],_0x11eb85['_path'],_0x3fd9c6),setTimeout(()=>{_0x34cbc7('ok');},0x0)),_0x27c6cf;},'stopListening':()=>{}}),vs(_0xb06206,'connected',!0x1),_0xb06206['serverSyncTree_']=new _r({'startListening':(_0xf259dd,_0x56175f,_0x2e57d2,_0x216dfb)=>(_0xb06206['server_']['listen'](_0xf259dd,_0x2e57d2,_0x56175f,(_0x366d01,_0x59b465)=>{const _0x229444=_0x216dfb(_0x366d01,_0x59b465);H(_0xb06206['eventQueue_'],_0xf259dd['_path'],_0x229444);}),[]),'stopListening':(_0x2e0ccf,_0x281447)=>{_0xb06206['server_']['unlisten'](_0x2e0ccf,_0x281447);}});}function la(_0x59e400){const _0x15d0e3=_0x59e400['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x15d0e3;}function Kt(_0x1b6317){return id({'timestamp':la(_0x1b6317)});}function mr(_0x175d72,_0x1bb6db,_0x2c8c54,_0x13c029,_0x13fb92){_0x175d72['dataUpdateCount']++;const _0x4b21e1=new C(_0x1bb6db);_0x2c8c54=_0x175d72['interceptServerDataCallback_']?_0x175d72['interceptServerDataCallback_'](_0x1bb6db,_0x2c8c54):_0x2c8c54;let _0x59a0ba=[];if(_0x13fb92){if(_0x13c029){const _0x3ca144=hn(_0x2c8c54,_0x3ede05=>P(_0x3ede05));_0x59a0ba=Ju(_0x175d72['serverSyncTree_'],_0x4b21e1,_0x3ca144,_0x13fb92);}else{const _0x1a6709=P(_0x2c8c54);_0x59a0ba=Xo(_0x175d72['serverSyncTree_'],_0x4b21e1,_0x1a6709,_0x13fb92);}}else{if(_0x13c029){const _0x4ad135=hn(_0x2c8c54,_0x25918d=>P(_0x25918d));_0x59a0ba=Ku(_0x175d72['serverSyncTree_'],_0x4b21e1,_0x4ad135);}else{const _0x3c31f1=P(_0x2c8c54);_0x59a0ba=Gt(_0x175d72['serverSyncTree_'],_0x4b21e1,_0x3c31f1);}}let _0x304cdd=_0x4b21e1;_0x59a0ba['length']>0x0&&(_0x304cdd=it(_0x175d72,_0x4b21e1)),H(_0x175d72['eventQueue_'],_0x304cdd,_0x59a0ba);}function yr(_0x54fd78,_0x1b2753){vs(_0x54fd78,'connected',_0x1b2753),_0x1b2753===!0x1&&Sd(_0x54fd78);}function Id(_0x331b9e,_0x5a812b){x(_0x5a812b,(_0xe6e2f8,_0x229944)=>{vs(_0x331b9e,_0xe6e2f8,_0x229944);});}function vs(_0x8e00a7,_0x39b854,_0x58eeef){const _0x4daa88=new C('/.info/'+_0x39b854),_0x177ad3=P(_0x58eeef);_0x8e00a7['infoData_']['updateSnapshot'](_0x4daa88,_0x177ad3);const _0x3692f9=Gt(_0x8e00a7['infoSyncTree_'],_0x4daa88,_0x177ad3);H(_0x8e00a7['eventQueue_'],_0x4daa88,_0x3692f9);}function Hn(_0x13b8c1){return _0x13b8c1['nextWriteId_']++;}function wd(_0x2c9354,_0x2cfe8c,_0x291b33){const _0x31d8b7=Xu(_0x2c9354['serverSyncTree_'],_0x2cfe8c);return _0x31d8b7!=null?Promise['resolve'](_0x31d8b7):_0x2c9354['server_']['get'](_0x2cfe8c)['then'](_0x6198c6=>{const _0x43af40=P(_0x6198c6)['withIndex'](_0x2cfe8c['_queryParams']['getIndex']());Ri(_0x2c9354['serverSyncTree_'],_0x2cfe8c,_0x291b33,!0x0);let _0x4eb1d8;if(_0x2cfe8c['_queryParams']['loadsAllData']())_0x4eb1d8=Gt(_0x2c9354['serverSyncTree_'],_0x2cfe8c['_path'],_0x43af40);else{const _0x2bd69c=xt(_0x2c9354['serverSyncTree_'],_0x2cfe8c);_0x4eb1d8=Xo(_0x2c9354['serverSyncTree_'],_0x2cfe8c['_path'],_0x43af40,_0x2bd69c);}return H(_0x2c9354['eventQueue_'],_0x2cfe8c['_path'],_0x4eb1d8),Cn(_0x2c9354['serverSyncTree_'],_0x2cfe8c,_0x291b33,null,!0x0),_0x43af40;},_0x286db1=>(dt(_0x2c9354,'get\x20for\x20query\x20'+O(_0x2cfe8c)+'\x20failed:\x20'+_0x286db1),Promise['reject'](new Error(_0x286db1))));}function Cd(_0x4dcdcc,_0x2d28a9,_0x54fd4f,_0x19ba1f,_0xfb5b){dt(_0x4dcdcc,'set',{'path':_0x2d28a9['toString'](),'value':_0x54fd4f,'priority':_0x19ba1f});const _0x1087b=Kt(_0x4dcdcc),_0xd9f1e1=P(_0x54fd4f,_0x19ba1f),_0x5c82b2=Fn(_0x4dcdcc['serverSyncTree_'],_0x2d28a9),_0x2087e6=ds(_0xd9f1e1,_0x5c82b2,_0x1087b),_0x14d09d=Hn(_0x4dcdcc),_0x48db48=os(_0x4dcdcc['serverSyncTree_'],_0x2d28a9,_0x2087e6,_0x14d09d,!0x0);Vn(_0x4dcdcc['eventQueue_'],_0x48db48),_0x4dcdcc['server_']['put'](_0x2d28a9['toString'](),_0xd9f1e1['val'](!0x0),(_0x20107d,_0x1c5603)=>{const _0x2c60b1=_0x20107d==='ok';_0x2c60b1||U('set\x20at\x20'+_0x2d28a9+'\x20failed:\x20'+_0x20107d);const _0x5e1914=pe(_0x4dcdcc['serverSyncTree_'],_0x14d09d,!_0x2c60b1);H(_0x4dcdcc['eventQueue_'],_0x2d28a9,_0x5e1914),ki(_0x4dcdcc,_0xfb5b,_0x20107d,_0x1c5603);});const _0x2d1627=Is(_0x4dcdcc,_0x2d28a9);it(_0x4dcdcc,_0x2d1627),H(_0x4dcdcc['eventQueue_'],_0x2d1627,[]);}function Td(_0x368883,_0x51a5fe,_0x1ab901,_0x326f66){dt(_0x368883,'update',{'path':_0x51a5fe['toString'](),'value':_0x1ab901});let _0x24be85=!0x0;const _0x408932=Kt(_0x368883),_0x102926={};if(x(_0x1ab901,(_0x499a99,_0x21741d)=>{_0x24be85=!0x1,_0x102926[_0x499a99]=na(k(_0x51a5fe,_0x499a99),P(_0x21741d),_0x368883['serverSyncTree_'],_0x408932);}),_0x24be85)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x368883,_0x326f66,'ok',void 0x0);else{const _0x554165=Hn(_0x368883),_0x1cce38=ju(_0x368883['serverSyncTree_'],_0x51a5fe,_0x102926,_0x554165);Vn(_0x368883['eventQueue_'],_0x1cce38),_0x368883['server_']['merge'](_0x51a5fe['toString'](),_0x1ab901,(_0xc4c2ba,_0x508f0c)=>{const _0x274b62=_0xc4c2ba==='ok';_0x274b62||U('update\x20at\x20'+_0x51a5fe+'\x20failed:\x20'+_0xc4c2ba);const _0x33f64e=pe(_0x368883['serverSyncTree_'],_0x554165,!_0x274b62),_0x152450=_0x33f64e['length']>0x0?it(_0x368883,_0x51a5fe):_0x51a5fe;H(_0x368883['eventQueue_'],_0x152450,_0x33f64e),ki(_0x368883,_0x326f66,_0xc4c2ba,_0x508f0c);}),x(_0x1ab901,_0x8b9cd0=>{const _0x3ae2f8=Is(_0x368883,k(_0x51a5fe,_0x8b9cd0));it(_0x368883,_0x3ae2f8);}),H(_0x368883['eventQueue_'],_0x51a5fe,[]);}}function Sd(_0x5d46af){dt(_0x5d46af,'onDisconnectEvents');const _0x596ecd=Kt(_0x5d46af),_0x5072a7=_n();Ii(_0x5d46af['onDisconnect_'],w(),(_0x41ed2e,_0x70974e)=>{const _0x170212=na(_0x41ed2e,_0x70974e,_0x5d46af['serverSyncTree_'],_0x596ecd);Fo(_0x5072a7,_0x41ed2e,_0x170212);});let _0x24fe49=[];Ii(_0x5072a7,w(),(_0x470c4a,_0x141040)=>{_0x24fe49=_0x24fe49['concat'](Gt(_0x5d46af['serverSyncTree_'],_0x470c4a,_0x141040));const _0x5c5323=Is(_0x5d46af,_0x470c4a);it(_0x5d46af,_0x5c5323);}),_0x5d46af['onDisconnect_']=_n(),H(_0x5d46af['eventQueue_'],w(),_0x24fe49);}function bd(_0x3f7f9c,_0x2868f0,_0x1c8d7d){let _0x2934ab;y(_0x2868f0['_path'])==='.info'?_0x2934ab=Ri(_0x3f7f9c['infoSyncTree_'],_0x2868f0,_0x1c8d7d):_0x2934ab=Ri(_0x3f7f9c['serverSyncTree_'],_0x2868f0,_0x1c8d7d),oa(_0x3f7f9c['eventQueue_'],_0x2868f0['_path'],_0x2934ab);}function Rd(_0x4bab1e,_0x414ed6,_0x478477){let _0x428004;y(_0x414ed6['_path'])==='.info'?_0x428004=Cn(_0x4bab1e['infoSyncTree_'],_0x414ed6,_0x478477):_0x428004=Cn(_0x4bab1e['serverSyncTree_'],_0x414ed6,_0x478477),oa(_0x4bab1e['eventQueue_'],_0x414ed6['_path'],_0x428004);}function ha(_0x31b4d2){_0x31b4d2['persistentConnection_']&&_0x31b4d2['persistentConnection_']['interrupt'](ca);}function Ad(_0x1bba3a){_0x1bba3a['persistentConnection_']&&_0x1bba3a['persistentConnection_']['resume'](ca);}function dt(_0x30a9c9,..._0x2cc716){let _0x1f92dd='';_0x30a9c9['persistentConnection_']&&(_0x1f92dd=_0x30a9c9['persistentConnection_']['id']+':'),L(_0x1f92dd,..._0x2cc716);}function ki(_0x4958f8,_0x45c84e,_0x3a623f,_0x5a72e1){_0x45c84e&&ht(()=>{if(_0x3a623f==='ok')_0x45c84e(null);else{const _0x36963f=(_0x3a623f||'error')['toUpperCase']();let _0xc56c65=_0x36963f;_0x5a72e1&&(_0xc56c65+=':\x20'+_0x5a72e1);const _0x490869=new Error(_0xc56c65);_0x490869['code']=_0x36963f,_0x45c84e(_0x490869);}});}function kd(_0x249b87,_0x36a07e,_0x5cc7f3,_0x17625b,_0x5780e9,_0x4fa8c1){dt(_0x249b87,'transaction\x20on\x20'+_0x36a07e);const _0x3e6e1b={'path':_0x36a07e,'update':_0x5cc7f3,'onComplete':_0x17625b,'status':null,'order':so(),'applyLocally':_0x4fa8c1,'retryCount':0x0,'unwatcher':_0x5780e9,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x396b56=Es(_0x249b87,_0x36a07e,void 0x0);_0x3e6e1b['currentInputSnapshot']=_0x396b56;const _0x9262c6=_0x3e6e1b['update'](_0x396b56['val']());if(_0x9262c6===void 0x0)_0x3e6e1b['unwatcher'](),_0x3e6e1b['currentOutputSnapshotRaw']=null,_0x3e6e1b['currentOutputSnapshotResolved']=null,_0x3e6e1b['onComplete']&&_0x3e6e1b['onComplete'](null,!0x1,_0x3e6e1b['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x9262c6,_0x3e6e1b['path']),_0x3e6e1b['status']=0x0;const _0x1712c4=Wn(_0x249b87['transactionQueueTree_'],_0x36a07e),_0x3d3829=Ge(_0x1712c4)||[];_0x3d3829['push'](_0x3e6e1b),_s(_0x1712c4,_0x3d3829);let _0xebbd44;typeof _0x9262c6=='object'&&_0x9262c6!==null&&J(_0x9262c6,'.priority')?(_0xebbd44=De(_0x9262c6,'.priority'),f(Tn(_0xebbd44),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0xebbd44=(Fn(_0x249b87['serverSyncTree_'],_0x36a07e)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x463d83=Kt(_0x249b87),_0x486acf=P(_0x9262c6,_0xebbd44),_0x2e8dff=ds(_0x486acf,_0x396b56,_0x463d83);_0x3e6e1b['currentOutputSnapshotRaw']=_0x486acf,_0x3e6e1b['currentOutputSnapshotResolved']=_0x2e8dff,_0x3e6e1b['currentWriteId']=Hn(_0x249b87);const _0x30c0e1=os(_0x249b87['serverSyncTree_'],_0x36a07e,_0x2e8dff,_0x3e6e1b['currentWriteId'],_0x3e6e1b['applyLocally']);H(_0x249b87['eventQueue_'],_0x36a07e,_0x30c0e1),$n(_0x249b87,_0x249b87['transactionQueueTree_']);}}function Es(_0x20ad84,_0x25acf8,_0x3347c7){return Fn(_0x20ad84['serverSyncTree_'],_0x25acf8,_0x3347c7)||g['EMPTY_NODE'];}function $n(_0x114855,_0x3bf46b=_0x114855['transactionQueueTree_']){if(_0x3bf46b||Gn(_0x114855,_0x3bf46b),Ge(_0x3bf46b)){const _0xe6ccec=da(_0x114855,_0x3bf46b);f(_0xe6ccec['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0xe6ccec['every'](_0x1dd286=>_0x1dd286['status']===0x0)&&Nd(_0x114855,qt(_0x3bf46b),_0xe6ccec);}else ia(_0x3bf46b)&&Bn(_0x3bf46b,_0xdf82ba=>{$n(_0x114855,_0xdf82ba);});}function Nd(_0x551265,_0x360ddb,_0x267370){const _0x4289df=_0x267370['map'](_0x7ce5eb=>_0x7ce5eb['currentWriteId']),_0x6fcc3d=Es(_0x551265,_0x360ddb,_0x4289df);let _0x549c79=_0x6fcc3d;const _0x4467a6=_0x6fcc3d['hash']();for(let _0x82320b=0x0;_0x82320b<_0x267370['length'];_0x82320b++){const _0x18eee0=_0x267370[_0x82320b];f(_0x18eee0['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x18eee0['status']=0x1,_0x18eee0['retryCount']++;const _0x1b8d42=F(_0x360ddb,_0x18eee0['path']);_0x549c79=_0x549c79['updateChild'](_0x1b8d42,_0x18eee0['currentOutputSnapshotRaw']);}const _0x3766c5=_0x549c79['val'](!0x0),_0x243a36=_0x360ddb;_0x551265['server_']['put'](_0x243a36['toString'](),_0x3766c5,_0x56d6bb=>{dt(_0x551265,'transaction\x20put\x20response',{'path':_0x243a36['toString'](),'status':_0x56d6bb});let _0x16b9d1=[];if(_0x56d6bb==='ok'){const _0x2a5631=[];for(let _0x4232ba=0x0;_0x4232ba<_0x267370['length'];_0x4232ba++)_0x267370[_0x4232ba]['status']=0x2,_0x16b9d1=_0x16b9d1['concat'](pe(_0x551265['serverSyncTree_'],_0x267370[_0x4232ba]['currentWriteId'])),_0x267370[_0x4232ba]['onComplete']&&_0x2a5631['push'](()=>_0x267370[_0x4232ba]['onComplete'](null,!0x0,_0x267370[_0x4232ba]['currentOutputSnapshotResolved'])),_0x267370[_0x4232ba]['unwatcher']();Gn(_0x551265,Wn(_0x551265['transactionQueueTree_'],_0x360ddb)),$n(_0x551265,_0x551265['transactionQueueTree_']),H(_0x551265['eventQueue_'],_0x360ddb,_0x16b9d1);for(let _0x211455=0x0;_0x211455<_0x2a5631['length'];_0x211455++)ht(_0x2a5631[_0x211455]);}else{if(_0x56d6bb==='datastale'){for(let _0x4857d8=0x0;_0x4857d8<_0x267370['length'];_0x4857d8++)_0x267370[_0x4857d8]['status']===0x3?_0x267370[_0x4857d8]['status']=0x4:_0x267370[_0x4857d8]['status']=0x0;}else{U('transaction\x20at\x20'+_0x243a36['toString']()+'\x20failed:\x20'+_0x56d6bb);for(let _0x4d231d=0x0;_0x4d231d<_0x267370['length'];_0x4d231d++)_0x267370[_0x4d231d]['status']=0x4,_0x267370[_0x4d231d]['abortReason']=_0x56d6bb;}it(_0x551265,_0x360ddb);}},_0x4467a6);}function it(_0x1ec7a3,_0x555218){const _0x150be8=ua(_0x1ec7a3,_0x555218),_0x57b541=qt(_0x150be8),_0x22f35a=da(_0x1ec7a3,_0x150be8);return Pd(_0x1ec7a3,_0x22f35a,_0x57b541),_0x57b541;}function Pd(_0x2d99ad,_0xa2906a,_0x5c0cbe){if(_0xa2906a['length']===0x0)return;const _0x1f4a15=[];let _0x3dc437=[];const _0x5af13e=_0xa2906a['filter'](_0x432771=>_0x432771['status']===0x0)['map'](_0x5ce2c4=>_0x5ce2c4['currentWriteId']);for(let _0x161a93=0x0;_0x161a93<_0xa2906a['length'];_0x161a93++){const _0x145389=_0xa2906a[_0x161a93],_0x452124=F(_0x5c0cbe,_0x145389['path']);let _0x3fd346=!0x1,_0x4a987f;if(f(_0x452124!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x145389['status']===0x4)_0x3fd346=!0x0,_0x4a987f=_0x145389['abortReason'],_0x3dc437=_0x3dc437['concat'](pe(_0x2d99ad['serverSyncTree_'],_0x145389['currentWriteId'],!0x0));else{if(_0x145389['status']===0x0){if(_0x145389['retryCount']>=yd)_0x3fd346=!0x0,_0x4a987f='maxretry',_0x3dc437=_0x3dc437['concat'](pe(_0x2d99ad['serverSyncTree_'],_0x145389['currentWriteId'],!0x0));else{const _0x596cc4=Es(_0x2d99ad,_0x145389['path'],_0x5af13e);_0x145389['currentInputSnapshot']=_0x596cc4;const _0x5a74c0=_0xa2906a[_0x161a93]['update'](_0x596cc4['val']());if(_0x5a74c0!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x5a74c0,_0x145389['path']);let _0x1807c7=P(_0x5a74c0);typeof _0x5a74c0=='object'&&_0x5a74c0!=null&&J(_0x5a74c0,'.priority')||(_0x1807c7=_0x1807c7['updatePriority'](_0x596cc4['getPriority']()));const _0x2f7d7a=_0x145389['currentWriteId'],_0x55874c=Kt(_0x2d99ad),_0x5ade6c=ds(_0x1807c7,_0x596cc4,_0x55874c);_0x145389['currentOutputSnapshotRaw']=_0x1807c7,_0x145389['currentOutputSnapshotResolved']=_0x5ade6c,_0x145389['currentWriteId']=Hn(_0x2d99ad),_0x5af13e['splice'](_0x5af13e['indexOf'](_0x2f7d7a),0x1),_0x3dc437=_0x3dc437['concat'](os(_0x2d99ad['serverSyncTree_'],_0x145389['path'],_0x5ade6c,_0x145389['currentWriteId'],_0x145389['applyLocally'])),_0x3dc437=_0x3dc437['concat'](pe(_0x2d99ad['serverSyncTree_'],_0x2f7d7a,!0x0));}else _0x3fd346=!0x0,_0x4a987f='nodata',_0x3dc437=_0x3dc437['concat'](pe(_0x2d99ad['serverSyncTree_'],_0x145389['currentWriteId'],!0x0));}}}H(_0x2d99ad['eventQueue_'],_0x5c0cbe,_0x3dc437),_0x3dc437=[],_0x3fd346&&(_0xa2906a[_0x161a93]['status']=0x2,function(_0xee991f){setTimeout(_0xee991f,Math['floor'](0x0));}(_0xa2906a[_0x161a93]['unwatcher']),_0xa2906a[_0x161a93]['onComplete']&&(_0x4a987f==='nodata'?_0x1f4a15['push'](()=>_0xa2906a[_0x161a93]['onComplete'](null,!0x1,_0xa2906a[_0x161a93]['currentInputSnapshot'])):_0x1f4a15['push'](()=>_0xa2906a[_0x161a93]['onComplete'](new Error(_0x4a987f),!0x1,null))));}Gn(_0x2d99ad,_0x2d99ad['transactionQueueTree_']);for(let _0x7efc79=0x0;_0x7efc79<_0x1f4a15['length'];_0x7efc79++)ht(_0x1f4a15[_0x7efc79]);$n(_0x2d99ad,_0x2d99ad['transactionQueueTree_']);}function ua(_0x1db6b0,_0x226422){let _0x355e0d,_0x2acb0d=_0x1db6b0['transactionQueueTree_'];for(_0x355e0d=y(_0x226422);_0x355e0d!==null&&Ge(_0x2acb0d)===void 0x0;)_0x2acb0d=Wn(_0x2acb0d,_0x355e0d),_0x226422=b(_0x226422),_0x355e0d=y(_0x226422);return _0x2acb0d;}function da(_0x433da1,_0x36a8f9){const _0x2f4f4a=[];return fa(_0x433da1,_0x36a8f9,_0x2f4f4a),_0x2f4f4a['sort']((_0x5c7f24,_0x3c7351)=>_0x5c7f24['order']-_0x3c7351['order']),_0x2f4f4a;}function fa(_0x2e37bd,_0x1120af,_0x555e19){const _0x3c57ae=Ge(_0x1120af);if(_0x3c57ae){for(let _0x3b30f3=0x0;_0x3b30f3<_0x3c57ae['length'];_0x3b30f3++)_0x555e19['push'](_0x3c57ae[_0x3b30f3]);}Bn(_0x1120af,_0x43def5=>{fa(_0x2e37bd,_0x43def5,_0x555e19);});}function Gn(_0x408017,_0x52ec9f){const _0x11b066=Ge(_0x52ec9f);if(_0x11b066){let _0x500f47=0x0;for(let _0x1c64e8=0x0;_0x1c64e8<_0x11b066['length'];_0x1c64e8++)_0x11b066[_0x1c64e8]['status']!==0x2&&(_0x11b066[_0x500f47]=_0x11b066[_0x1c64e8],_0x500f47++);_0x11b066['length']=_0x500f47,_s(_0x52ec9f,_0x11b066['length']>0x0?_0x11b066:void 0x0);}Bn(_0x52ec9f,_0x3e8421=>{Gn(_0x408017,_0x3e8421);});}function Is(_0x1d54bf,_0x501620){const _0x330fa4=qt(ua(_0x1d54bf,_0x501620)),_0x2bdd0b=Wn(_0x1d54bf['transactionQueueTree_'],_0x501620);return ad(_0x2bdd0b,_0x214b3d=>{ci(_0x1d54bf,_0x214b3d);}),ci(_0x1d54bf,_0x2bdd0b),sa(_0x2bdd0b,_0x53704e=>{ci(_0x1d54bf,_0x53704e);}),_0x330fa4;}function ci(_0xe4f9cb,_0x9dee30){const _0x4d8dab=Ge(_0x9dee30);if(_0x4d8dab){const _0x571e90=[];let _0x17c575=[],_0x1ffcf5=-0x1;for(let _0x23200f=0x0;_0x23200f<_0x4d8dab['length'];_0x23200f++)_0x4d8dab[_0x23200f]['status']===0x3||(_0x4d8dab[_0x23200f]['status']===0x1?(f(_0x1ffcf5===_0x23200f-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x1ffcf5=_0x23200f,_0x4d8dab[_0x23200f]['status']=0x3,_0x4d8dab[_0x23200f]['abortReason']='set'):(f(_0x4d8dab[_0x23200f]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x4d8dab[_0x23200f]['unwatcher'](),_0x17c575=_0x17c575['concat'](pe(_0xe4f9cb['serverSyncTree_'],_0x4d8dab[_0x23200f]['currentWriteId'],!0x0)),_0x4d8dab[_0x23200f]['onComplete']&&_0x571e90['push'](_0x4d8dab[_0x23200f]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x1ffcf5===-0x1?_s(_0x9dee30,void 0x0):_0x4d8dab['length']=_0x1ffcf5+0x1,H(_0xe4f9cb['eventQueue_'],qt(_0x9dee30),_0x17c575);for(let _0x5130c3=0x0;_0x5130c3<_0x571e90['length'];_0x5130c3++)ht(_0x571e90[_0x5130c3]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x237955){let _0x3daeee='';const _0x2ec392=_0x237955['split']('/');for(let _0x46e170=0x0;_0x46e170<_0x2ec392['length'];_0x46e170++)if(_0x2ec392[_0x46e170]['length']>0x0){let _0x337d00=_0x2ec392[_0x46e170];try{_0x337d00=decodeURIComponent(_0x337d00['replace'](/\+/g,'\x20'));}catch{}_0x3daeee+='/'+_0x337d00;}return _0x3daeee;}function Dd(_0x307754){const _0x3b69a2={};_0x307754['charAt'](0x0)==='?'&&(_0x307754=_0x307754['substring'](0x1));for(const _0x8121a6 of _0x307754['split']('&')){if(_0x8121a6['length']===0x0)continue;const _0x4ecdda=_0x8121a6['split']('=');_0x4ecdda['length']===0x2?_0x3b69a2[decodeURIComponent(_0x4ecdda[0x0])]=decodeURIComponent(_0x4ecdda[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x8121a6+'\x27\x20in\x20query\x20\x27'+_0x307754+'\x27');}return _0x3b69a2;}const vr=function(_0x491e37,_0x4ab2c4){const _0x1ca15e=Md(_0x491e37),_0x22617f=_0x1ca15e['namespace'];_0x1ca15e['domain']==='firebase.com'&&ae(_0x1ca15e['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x22617f||_0x22617f==='undefined')&&_0x1ca15e['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x1ca15e['secure']||$l();const _0x2c21ad=_0x1ca15e['scheme']==='ws'||_0x1ca15e['scheme']==='wss';return{'repoInfo':new yo(_0x1ca15e['host'],_0x1ca15e['secure'],_0x22617f,_0x2c21ad,_0x4ab2c4,'',_0x22617f!==_0x1ca15e['subdomain']),'path':new C(_0x1ca15e['pathString'])};},Md=function(_0x593f4e){let _0x1792bd='',_0x1d9b36='',_0x2f5816='',_0x6070b6='',_0x26e6ed='',_0x138682=!0x0,_0x3ed505='https',_0x530330=0x1bb;if(typeof _0x593f4e=='string'){let _0x4fa014=_0x593f4e['indexOf']('//');_0x4fa014>=0x0&&(_0x3ed505=_0x593f4e['substring'](0x0,_0x4fa014-0x1),_0x593f4e=_0x593f4e['substring'](_0x4fa014+0x2));let _0x2d4aa5=_0x593f4e['indexOf']('/');_0x2d4aa5===-0x1&&(_0x2d4aa5=_0x593f4e['length']);let _0x1c39ca=_0x593f4e['indexOf']('?');_0x1c39ca===-0x1&&(_0x1c39ca=_0x593f4e['length']),_0x1792bd=_0x593f4e['substring'](0x0,Math['min'](_0x2d4aa5,_0x1c39ca)),_0x2d4aa5<_0x1c39ca&&(_0x6070b6=Od(_0x593f4e['substring'](_0x2d4aa5,_0x1c39ca)));const _0x16bb17=Dd(_0x593f4e['substring'](Math['min'](_0x593f4e['length'],_0x1c39ca)));_0x4fa014=_0x1792bd['indexOf'](':'),_0x4fa014>=0x0?(_0x138682=_0x3ed505==='https'||_0x3ed505==='wss',_0x530330=parseInt(_0x1792bd['substring'](_0x4fa014+0x1),0xa)):_0x4fa014=_0x1792bd['length'];const _0x478844=_0x1792bd['slice'](0x0,_0x4fa014);if(_0x478844['toLowerCase']()==='localhost')_0x1d9b36='localhost';else{if(_0x478844['split']('.')['length']<=0x2)_0x1d9b36=_0x478844;else{const _0x46e467=_0x1792bd['indexOf']('.');_0x2f5816=_0x1792bd['substring'](0x0,_0x46e467)['toLowerCase'](),_0x1d9b36=_0x1792bd['substring'](_0x46e467+0x1),_0x26e6ed=_0x2f5816;}}'ns'in _0x16bb17&&(_0x26e6ed=_0x16bb17['ns']);}return{'host':_0x1792bd,'port':_0x530330,'domain':_0x1d9b36,'subdomain':_0x2f5816,'secure':_0x138682,'scheme':_0x3ed505,'pathString':_0x6070b6,'namespace':_0x26e6ed};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x2a8728=0x0;const _0xe87233=[];return function(_0xcf27e9){const _0x33b9e5=_0xcf27e9===_0x2a8728;_0x2a8728=_0xcf27e9;let _0x29ae9d;const _0x1b253a=new Array(0x8);for(_0x29ae9d=0x7;_0x29ae9d>=0x0;_0x29ae9d--)_0x1b253a[_0x29ae9d]=Er['charAt'](_0xcf27e9%0x40),_0xcf27e9=Math['floor'](_0xcf27e9/0x40);f(_0xcf27e9===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x5ad45c=_0x1b253a['join']('');if(_0x33b9e5){for(_0x29ae9d=0xb;_0x29ae9d>=0x0&&_0xe87233[_0x29ae9d]===0x3f;_0x29ae9d--)_0xe87233[_0x29ae9d]=0x0;_0xe87233[_0x29ae9d]++;}else{for(_0x29ae9d=0x0;_0x29ae9d<0xc;_0x29ae9d++)_0xe87233[_0x29ae9d]=Math['floor'](Math['random']()*0x40);}for(_0x29ae9d=0x0;_0x29ae9d<0xc;_0x29ae9d++)_0x5ad45c+=Er['charAt'](_0xe87233[_0x29ae9d]);return f(_0x5ad45c['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x5ad45c;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x39801c,_0x4b044f,_0xf86f1b,_0x17509e){this['eventType']=_0x39801c,this['eventRegistration']=_0x4b044f,this['snapshot']=_0xf86f1b,this['prevName']=_0x17509e;}['getPath'](){const _0x49df98=this['snapshot']['ref'];return this['eventType']==='value'?_0x49df98['_path']:_0x49df98['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x11f964,_0x510265,_0x3d1a05){this['eventRegistration']=_0x11f964,this['error']=_0x510265,this['path']=_0x3d1a05;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x234478,_0x2b65d2){this['snapshotCallback']=_0x234478,this['cancelCallback']=_0x2b65d2;}['onValue'](_0x2d3b92,_0x12a170){this['snapshotCallback']['call'](null,_0x2d3b92,_0x12a170);}['onCancel'](_0x235c3a){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x235c3a);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x185d19){return this['snapshotCallback']===_0x185d19['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x185d19['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x185d19['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x19c9d7,_0x289a1e,_0x5d032b,_0x121569){this['_repo']=_0x19c9d7,this['_path']=_0x289a1e,this['_queryParams']=_0x5d032b,this['_orderByCalled']=_0x121569;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x4ee4b8=rr(this['_queryParams']),_0x53e7af=Hi(_0x4ee4b8);return _0x53e7af==='{}'?'default':_0x53e7af;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x46966e){if(_0x46966e=N(_0x46966e),!(_0x46966e instanceof be))return!0x1;const _0x107444=this['_repo']===_0x46966e['_repo'],_0x14389c=ji(this['_path'],_0x46966e['_path']),_0x1ce152=this['_queryIdentifier']===_0x46966e['_queryIdentifier'];return _0x107444&&_0x14389c&&_0x1ce152;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x39ee29,_0xbe398b){if(_0x39ee29['_orderByCalled']===!0x0)throw new Error(_0xbe398b+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x211134){let _0x1f2182=null,_0x50d41a=null;if(_0x211134['hasStart']()&&(_0x1f2182=_0x211134['getIndexStartValue']()),_0x211134['hasEnd']()&&(_0x50d41a=_0x211134['getIndexEndValue']()),_0x211134['getIndex']()===ye){const _0x27eb16='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x4453b5='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x211134['hasStart']()){if(_0x211134['getIndexStartName']()!==Fe)throw new Error(_0x27eb16);if(typeof _0x1f2182!='string')throw new Error(_0x4453b5);}if(_0x211134['hasEnd']()){if(_0x211134['getIndexEndName']()!==Ie)throw new Error(_0x27eb16);if(typeof _0x50d41a!='string')throw new Error(_0x4453b5);}}else{if(_0x211134['getIndex']()===R){if(_0x1f2182!=null&&!Tn(_0x1f2182)||_0x50d41a!=null&&!Tn(_0x50d41a))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x211134['getIndex']()instanceof Qi||_0x211134['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x1f2182!=null&&typeof _0x1f2182=='object'||_0x50d41a!=null&&typeof _0x50d41a=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x3319da){if(_0x3319da['hasStart']()&&_0x3319da['hasEnd']()&&_0x3319da['hasLimit']()&&!_0x3319da['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x59d700,_0x2d27fa){super(_0x59d700,_0x2d27fa,new Xi(),!0x1);}get['parent'](){const _0x72224b=Ro(this['_path']);return _0x72224b===null?null:new ee(this['_repo'],_0x72224b);}get['root'](){let _0x42af0e=this;for(;_0x42af0e['parent']!==null;)_0x42af0e=_0x42af0e['parent'];return _0x42af0e;}}class st{constructor(_0x526d0b,_0x588cda,_0x53cfd1){this['_node']=_0x526d0b,this['ref']=_0x588cda,this['_index']=_0x53cfd1;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x2b41ba){const _0x210f58=new C(_0x2b41ba),_0x72827a=Ft(this['ref'],_0x2b41ba);return new st(this['_node']['getChild'](_0x210f58),_0x72827a,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x5a31cc){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x40e6d8,_0x418637)=>_0x5a31cc(new st(_0x418637,Ft(this['ref'],_0x40e6d8),R)));}['hasChild'](_0x13242d){const _0x10a87c=new C(_0x13242d);return!this['_node']['getChild'](_0x10a87c)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x32876e,_0x2a8b47){return _0x32876e=N(_0x32876e),_0x32876e['_checkNotDeleted']('ref'),_0x2a8b47!==void 0x0?Ft(_0x32876e['_root'],_0x2a8b47):_0x32876e['_root'];}function Ft(_0x2808f8,_0x462db5){return _0x2808f8=N(_0x2808f8),y(_0x2808f8['_path'])===null?pd('child','path',_0x462db5):ms('child','path',_0x462db5),new ee(_0x2808f8['_repo'],k(_0x2808f8['_path'],_0x462db5));}function g_(_0x397a49,_0x36eb9e){_0x397a49=N(_0x397a49),ys('push',_0x397a49['_path']),zt('push',_0x36eb9e,_0x397a49['_path'],!0x0);const _0x2030ab=la(_0x397a49['_repo']),_0x4e3c67=Ld(_0x2030ab),_0x285f5d=Ft(_0x397a49,_0x4e3c67),_0x1f8939=Ft(_0x397a49,_0x4e3c67);let _0x4119ca;return _0x36eb9e!=null?_0x4119ca=Ud(_0x1f8939,_0x36eb9e)['then'](()=>_0x1f8939):_0x4119ca=Promise['resolve'](_0x1f8939),_0x285f5d['then']=_0x4119ca['then']['bind'](_0x4119ca),_0x285f5d['catch']=_0x4119ca['then']['bind'](_0x4119ca,void 0x0),_0x285f5d;}function Ud(_0x119dcb,_0x596f39){_0x119dcb=N(_0x119dcb),ys('set',_0x119dcb['_path']),zt('set',_0x596f39,_0x119dcb['_path'],!0x1);const _0x3b294b=new ot();return Cd(_0x119dcb['_repo'],_0x119dcb['_path'],_0x596f39,null,_0x3b294b['wrapCallback'](()=>{})),_0x3b294b['promise'];}function m_(_0x38d805,_0x3dfaf1){fd('update',_0x3dfaf1,_0x38d805['_path']);const _0x4ab41e=new ot();return Td(_0x38d805['_repo'],_0x38d805['_path'],_0x3dfaf1,_0x4ab41e['wrapCallback'](()=>{})),_0x4ab41e['promise'];}function y_(_0x468559){_0x468559=N(_0x468559);const _0x2a9ea9=new pa(()=>{}),_0x33b9e6=new zn(_0x2a9ea9);return wd(_0x468559['_repo'],_0x468559,_0x33b9e6)['then'](_0x55483d=>new st(_0x55483d,new ee(_0x468559['_repo'],_0x468559['_path']),_0x468559['_queryParams']['getIndex']()));}class zn{constructor(_0x1e87fd){this['callbackContext']=_0x1e87fd;}['respondsTo'](_0x5bb0ea){return _0x5bb0ea==='value';}['createEvent'](_0x4186ab,_0x55bf09){const _0x2c2be2=_0x55bf09['_queryParams']['getIndex']();return new xd('value',this,new st(_0x4186ab['snapshotNode'],new ee(_0x55bf09['_repo'],_0x55bf09['_path']),_0x2c2be2));}['getEventRunner'](_0x368d7a){return _0x368d7a['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x368d7a['error']):()=>this['callbackContext']['onValue'](_0x368d7a['snapshot'],null);}['createCancelEvent'](_0x4da439,_0x155e94){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x4da439,_0x155e94):null;}['matches'](_0x1a5420){return _0x1a5420 instanceof zn?!_0x1a5420['callbackContext']||!this['callbackContext']?!0x0:_0x1a5420['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x48ca04,_0x43a312,_0x129fc1,_0x172d8f,_0x4e6a8a){const _0xe9295=new pa(_0x129fc1,void 0x0),_0x1d1b05=new zn(_0xe9295);return bd(_0x48ca04['_repo'],_0x48ca04,_0x1d1b05),()=>Rd(_0x48ca04['_repo'],_0x48ca04,_0x1d1b05);}function Bd(_0x52a302,_0x1d67d7,_0x443149,_0x2bc36b){return Wd(_0x52a302,'value',_0x1d67d7);}class ft{}class ma extends ft{constructor(_0x1ce540,_0xd5ffc7){super(),this['_value']=_0x1ce540,this['_key']=_0xd5ffc7,this['type']='endAt';}['_apply'](_0x303611){zt('endAt',this['_value'],_0x303611['_path'],!0x0);const _0x2f0249=Jh(_0x303611['_queryParams'],this['_value'],this['_key']);if(ga(_0x2f0249),qn(_0x2f0249),_0x303611['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x303611['_repo'],_0x303611['_path'],_0x2f0249,_0x303611['_orderByCalled']);}}function v_(_0x3b7410,_0x37421c){return new ma(_0x3b7410,_0x37421c);}class ya extends ft{constructor(_0x5c5fdb,_0x5a1dfe){super(),this['_value']=_0x5c5fdb,this['_key']=_0x5a1dfe,this['type']='startAt';}['_apply'](_0x43ba58){zt('startAt',this['_value'],_0x43ba58['_path'],!0x0);const _0x41c69e=Qh(_0x43ba58['_queryParams'],this['_value'],this['_key']);if(ga(_0x41c69e),qn(_0x41c69e),_0x43ba58['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x43ba58['_repo'],_0x43ba58['_path'],_0x41c69e,_0x43ba58['_orderByCalled']);}}function E_(_0x25d601=null,_0x580ef2){return new ya(_0x25d601,_0x580ef2);}class Vd extends ft{constructor(_0x48c41c){super(),this['_limit']=_0x48c41c,this['type']='limitToFirst';}['_apply'](_0x509b83){if(_0x509b83['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x509b83['_repo'],_0x509b83['_path'],Yh(_0x509b83['_queryParams'],this['_limit']),_0x509b83['_orderByCalled']);}}function I_(_0x2bea72){if(Math['floor'](_0x2bea72)!==_0x2bea72||_0x2bea72<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x2bea72);}class Hd extends ft{constructor(_0x2d60e2){super(),this['_path']=_0x2d60e2,this['type']='orderByChild';}['_apply'](_0x20f727){_a(_0x20f727,'orderByChild');const _0x5ee132=new C(this['_path']);if(v(_0x5ee132))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x4b1426=new Qi(_0x5ee132),_0x29bd52=xo(_0x20f727['_queryParams'],_0x4b1426);return qn(_0x29bd52),new be(_0x20f727['_repo'],_0x20f727['_path'],_0x29bd52,!0x0);}}function w_(_0x30f3aa){if(_0x30f3aa==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x30f3aa==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x30f3aa==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x30f3aa),new Hd(_0x30f3aa);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x5a4ee2){_a(_0x5a4ee2,'orderByKey');const _0x1fa081=xo(_0x5a4ee2['_queryParams'],ye);return qn(_0x1fa081),new be(_0x5a4ee2['_repo'],_0x5a4ee2['_path'],_0x1fa081,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x2ea9e4,_0x3ce817){super(),this['_value']=_0x2ea9e4,this['_key']=_0x3ce817,this['type']='equalTo';}['_apply'](_0x54c82b){if(zt('equalTo',this['_value'],_0x54c82b['_path'],!0x1),_0x54c82b['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x54c82b['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x54c82b));}}function T_(_0x9b168a,_0x31210d){return new Gd(_0x9b168a,_0x31210d);}function S_(_0x26476b,..._0x3ce180){let _0x830045=N(_0x26476b);for(const _0x7ce17a of _0x3ce180)_0x830045=_0x7ce17a['_apply'](_0x830045);return _0x830045;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x924e0f,_0x3f7a06,_0x3ea01e,_0x10340c){const _0xd49526=_0x3f7a06['lastIndexOf'](':'),_0x3529f3=_0x3f7a06['substring'](0x0,_0xd49526),_0x1d6749=at(_0x3529f3);_0x924e0f['repoInfo_']=new yo(_0x3f7a06,_0x1d6749,_0x924e0f['repoInfo_']['namespace'],_0x924e0f['repoInfo_']['webSocketOnly'],_0x924e0f['repoInfo_']['nodeAdmin'],_0x924e0f['repoInfo_']['persistenceKey'],_0x924e0f['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x3ea01e),_0x10340c&&(_0x924e0f['authTokenProvider_']=_0x10340c);}function Kd(_0x5a18f3,_0x5b0ebe,_0x44e768,_0x27f119,_0x7ebb08){let _0x102950=_0x27f119||_0x5a18f3['options']['databaseURL'];_0x102950===void 0x0&&(_0x5a18f3['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x5a18f3['options']['projectId']),_0x102950=_0x5a18f3['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x268b16=vr(_0x102950,_0x7ebb08),_0x25d79f=_0x268b16['repoInfo'],_0xfd1185;typeof process<'u'&&Vs&&(_0xfd1185=Vs[qd]),_0xfd1185?(_0x102950='http://'+_0xfd1185+'?ns='+_0x25d79f['namespace'],_0x268b16=vr(_0x102950,_0x7ebb08),_0x25d79f=_0x268b16['repoInfo']):_0x268b16['repoInfo']['secure'];const _0x5e7707=new eh(_0x5a18f3['name'],_0x5a18f3['options'],_0x5b0ebe);_d('Invalid\x20Firebase\x20Database\x20URL',_0x268b16),v(_0x268b16['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x3f9dd0=Qd(_0x25d79f,_0x5a18f3,_0x5e7707,new Zl(_0x5a18f3,_0x44e768));return new Jd(_0x3f9dd0,_0x5a18f3);}function Yd(_0x2d7684,_0x31db87){const _0x351224=Ni[_0x31db87];(!_0x351224||_0x351224[_0x2d7684['key']]!==_0x2d7684)&&ae('Database\x20'+_0x31db87+'('+_0x2d7684['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x2d7684),delete _0x351224[_0x2d7684['key']];}function Qd(_0x412c55,_0x5343be,_0x2ce311,_0x3d212a){let _0x59d823=Ni[_0x5343be['name']];_0x59d823||(_0x59d823={},Ni[_0x5343be['name']]=_0x59d823);let _0x17ab37=_0x59d823[_0x412c55['toURLString']()];return _0x17ab37&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x17ab37=new vd(_0x412c55,zd,_0x2ce311,_0x3d212a),_0x59d823[_0x412c55['toURLString']()]=_0x17ab37,_0x17ab37;}class Jd{constructor(_0x2520db,_0xa3dcd6){this['_repoInternal']=_0x2520db,this['app']=_0xa3dcd6,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x4487f2){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x4487f2+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x46b6ec=Zr(),_0x4dbac1){const _0x34a3c3=Bi(_0x46b6ec,'database')['getImmediate']({'identifier':_0x4dbac1});if(!_0x34a3c3['_instanceStarted']){const _0x4c64fd=cc('database');_0x4c64fd&&Xd(_0x34a3c3,..._0x4c64fd);}return _0x34a3c3;}function Xd(_0x40bade,_0x406650,_0x20648f,_0x1ac3d5={}){_0x40bade=N(_0x40bade),_0x40bade['_checkNotDeleted']('useEmulator');const _0x2da0c6=_0x406650+':'+_0x20648f,_0x47d2bf=_0x40bade['_repoInternal'];if(_0x40bade['_instanceStarted']){if(_0x2da0c6===_0x40bade['_repoInternal']['repoInfo_']['host']&&Me(_0x1ac3d5,_0x47d2bf['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x3d98f8;if(_0x47d2bf['repoInfo_']['nodeAdmin'])_0x1ac3d5['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x3d98f8=new nn(nn['OWNER']);else{if(_0x1ac3d5['mockUserToken']){const _0x5d0680=typeof _0x1ac3d5['mockUserToken']=='string'?_0x1ac3d5['mockUserToken']:lc(_0x1ac3d5['mockUserToken'],_0x40bade['app']['options']['projectId']);_0x3d98f8=new nn(_0x5d0680);}}at(_0x406650)&&(jr(_0x406650),Kr('Database',!0x0)),jd(_0x47d2bf,_0x2da0c6,_0x1ac3d5,_0x3d98f8);}function R_(_0x2df4c3){_0x2df4c3=N(_0x2df4c3),_0x2df4c3['_checkNotDeleted']('goOffline'),ha(_0x2df4c3['_repo']);}function A_(_0xc8e10f){_0xc8e10f=N(_0xc8e10f),_0xc8e10f['_checkNotDeleted']('goOnline'),Ad(_0xc8e10f['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x1e65b9){Ul(lt),Ze(new Le('database',(_0x3cf34d,{instanceIdentifier:_0xa094cf})=>{const _0x366401=_0x3cf34d['getProvider']('app')['getImmediate'](),_0x35cc70=_0x3cf34d['getProvider']('auth-internal'),_0x49982c=_0x3cf34d['getProvider']('app-check-internal');return Kd(_0x366401,_0x35cc70,_0x49982c,_0xa094cf);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x1e65b9),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x52c9bb,_0x29988d){this['committed']=_0x52c9bb,this['snapshot']=_0x29988d;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x5a8167,_0x1ab258,_0x2ea80e){if(_0x5a8167=N(_0x5a8167),ys('Reference.transaction',_0x5a8167['_path']),_0x5a8167['key']==='.length'||_0x5a8167['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x5a8167['key']+'\x20is\x20a\x20read-only\x20object.';const _0x54d4b4=!0x0,_0x183acc=new ot(),_0x174dde=(_0xad8796,_0x56777a,_0xfc2439)=>{let _0x1c4391=null;_0xad8796?_0x183acc['reject'](_0xad8796):(_0x1c4391=new st(_0xfc2439,new ee(_0x5a8167['_repo'],_0x5a8167['_path']),R),_0x183acc['resolve'](new tf(_0x56777a,_0x1c4391)));},_0x1b4efd=Bd(_0x5a8167,()=>{});return kd(_0x5a8167['_repo'],_0x5a8167['_path'],_0x1ab258,_0x174dde,_0x1b4efd,_0x54d4b4),_0x183acc['promise'];}se['prototype']['simpleListen']=function(_0x5b8fcb,_0x4d9dbe){this['sendRequest']('q',{'p':_0x5b8fcb},_0x4d9dbe);},se['prototype']['echo']=function(_0x4bb67f,_0xe52035){this['sendRequest']('echo',{'d':_0x4bb67f},_0xe52035);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x353d2a,..._0x255975){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x353d2a,..._0x255975);}function sn(_0x28ecc9,..._0x58cd43){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x28ecc9,..._0x58cd43);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x9f06f0,..._0x24b0cc){throw ws(_0x9f06f0,..._0x24b0cc);}function X(_0x4e1cc2,..._0x5c6b36){return ws(_0x4e1cc2,..._0x5c6b36);}function Ia(_0x27ac3e,_0x3f07db,_0x2d3c3b){const _0x528ec2={...nf(),[_0x3f07db]:_0x2d3c3b};return new Bt('auth','Firebase',_0x528ec2)['create'](_0x3f07db,{'appName':_0x27ac3e['name']});}function re(_0x325af9){return Ia(_0x325af9,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x17d358,..._0x160360){if(typeof _0x17d358!='string'){const _0x3fe931=_0x160360[0x0],_0x2a64df=[..._0x160360['slice'](0x1)];return _0x2a64df[0x0]&&(_0x2a64df[0x0]['appName']=_0x17d358['name']),_0x17d358['_errorFactory']['create'](_0x3fe931,..._0x2a64df);}return Ea['create'](_0x17d358,..._0x160360);}function m(_0x3d257c,_0x1f70c3,..._0x22597a){if(!_0x3d257c)throw ws(_0x1f70c3,..._0x22597a);}function ne(_0x7b3e28){const _0x1ac177='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x7b3e28;throw sn(_0x1ac177),new Error(_0x1ac177);}function ce(_0x40489a,_0x502cd2){_0x40489a||ne(_0x502cd2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x185e17;return typeof self<'u'&&((_0x185e17=self['location'])==null?void 0x0:_0x185e17['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0xd0ac2c;return typeof self<'u'&&((_0xd0ac2c=self['location'])==null?void 0x0:_0xd0ac2c['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x37f208=navigator;return _0x37f208['languages']&&_0x37f208['languages'][0x0]||_0x37f208['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x3c83e9,_0x2fb7bd){this['shortDelay']=_0x3c83e9,this['longDelay']=_0x2fb7bd,ce(_0x2fb7bd>_0x3c83e9,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x29f50d,_0x41c24c){ce(_0x29f50d['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x2edaee}=_0x29f50d['emulator'];return _0x41c24c?''+_0x2edaee+(_0x41c24c['startsWith']('/')?_0x41c24c['slice'](0x1):_0x41c24c):_0x2edaee;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x332a4e,_0x11e132,_0x5a0d91){this['fetchImpl']=_0x332a4e,_0x11e132&&(this['headersImpl']=_0x11e132),_0x5a0d91&&(this['responseImpl']=_0x5a0d91);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x1002fc,_0x422b1c){return _0x1002fc['tenantId']&&!_0x422b1c['tenantId']?{..._0x422b1c,'tenantId':_0x1002fc['tenantId']}:_0x422b1c;}async function Ae(_0x497384,_0x3a0453,_0x455a38,_0x2289a3,_0x31b99a={}){return Ca(_0x497384,_0x31b99a,async()=>{let _0x278461={},_0x5801e1={};_0x2289a3&&(_0x3a0453==='GET'?_0x5801e1=_0x2289a3:_0x278461={'body':JSON['stringify'](_0x2289a3)});const _0x1e6c8b=ct({'key':_0x497384['config']['apiKey'],..._0x5801e1})['slice'](0x1),_0x1a5308=await _0x497384['_getAdditionalHeaders']();_0x1a5308['Content-Type']='application/json',_0x497384['languageCode']&&(_0x1a5308['X-Firebase-Locale']=_0x497384['languageCode']);const _0x352be3={'method':_0x3a0453,'headers':_0x1a5308,..._0x278461};return dc()||(_0x352be3['referrerPolicy']='no-referrer'),_0x497384['emulatorConfig']&&at(_0x497384['emulatorConfig']['host'])&&(_0x352be3['credentials']='include'),wa['fetch']()(await Ta(_0x497384,_0x497384['config']['apiHost'],_0x455a38,_0x1e6c8b),_0x352be3);});}async function Ca(_0x49692c,_0x185532,_0x335188){_0x49692c['_canInitEmulator']=!0x1;const _0x38bd7a={...cf,..._0x185532};try{const _0x3fc4e5=new df(_0x49692c),_0x1451a5=await Promise['race']([_0x335188(),_0x3fc4e5['promise']]);_0x3fc4e5['clearNetworkTimeout']();const _0x58bc0c=await _0x1451a5['json']();if('needConfirmation'in _0x58bc0c)throw tn(_0x49692c,'account-exists-with-different-credential',_0x58bc0c);if(_0x1451a5['ok']&&!('errorMessage'in _0x58bc0c))return _0x58bc0c;{const _0x2c08e7=_0x1451a5['ok']?_0x58bc0c['errorMessage']:_0x58bc0c['error']['message'],[_0x3e8de8,_0x4a99a9]=_0x2c08e7['split']('\x20:\x20');if(_0x3e8de8==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x49692c,'credential-already-in-use',_0x58bc0c);if(_0x3e8de8==='EMAIL_EXISTS')throw tn(_0x49692c,'email-already-in-use',_0x58bc0c);if(_0x3e8de8==='USER_DISABLED')throw tn(_0x49692c,'user-disabled',_0x58bc0c);const _0x22119c=_0x38bd7a[_0x3e8de8]||_0x3e8de8['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x4a99a9)throw Ia(_0x49692c,_0x22119c,_0x4a99a9);Q(_0x49692c,_0x22119c);}}catch(_0x4a2d70){if(_0x4a2d70 instanceof Se)throw _0x4a2d70;Q(_0x49692c,'network-request-failed',{'message':String(_0x4a2d70)});}}async function Qt(_0x1dd471,_0x269ac5,_0x5963f2,_0x598e4e,_0x23ca8b={}){const _0x859406=await Ae(_0x1dd471,_0x269ac5,_0x5963f2,_0x598e4e,_0x23ca8b);return'mfaPendingCredential'in _0x859406&&Q(_0x1dd471,'multi-factor-auth-required',{'_serverResponse':_0x859406}),_0x859406;}async function Ta(_0x1f498c,_0x4f8453,_0x1bf372,_0x36c7d8){const _0x407c53=''+_0x4f8453+_0x1bf372+'?'+_0x36c7d8,_0x110813=_0x1f498c,_0x21d329=_0x110813['config']['emulator']?Cs(_0x1f498c['config'],_0x407c53):_0x1f498c['config']['apiScheme']+'://'+_0x407c53;return lf['includes'](_0x1bf372)&&(await _0x110813['_persistenceManagerAvailable'],_0x110813['_getPersistenceType']()==='COOKIE')?_0x110813['_getPersistence']()['_getFinalTarget'](_0x21d329)['toString']():_0x21d329;}function uf(_0x395474){switch(_0x395474){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x13fe6c){this['auth']=_0x13fe6c,this['timer']=null,this['promise']=new Promise((_0x2f77df,_0x459e89)=>{this['timer']=setTimeout(()=>_0x459e89(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x4ca944,_0x577ba0,_0x31ead4){const _0x434ee7={'appName':_0x4ca944['name']};_0x31ead4['email']&&(_0x434ee7['email']=_0x31ead4['email']),_0x31ead4['phoneNumber']&&(_0x434ee7['phoneNumber']=_0x31ead4['phoneNumber']);const _0x557f91=X(_0x4ca944,_0x577ba0,_0x434ee7);return _0x557f91['customData']['_tokenResponse']=_0x31ead4,_0x557f91;}function wr(_0x170e73){return _0x170e73!==void 0x0&&_0x170e73['enterprise']!==void 0x0;}class ff{constructor(_0x2712dc){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x2712dc['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x2712dc['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x2712dc['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x1ff8ce){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3eb699 of this['recaptchaEnforcementState'])if(_0x3eb699['provider']&&_0x3eb699['provider']===_0x1ff8ce)return uf(_0x3eb699['enforcementState']);return null;}['isProviderEnabled'](_0x51e5d4){return this['getProviderEnforcementState'](_0x51e5d4)==='ENFORCE'||this['getProviderEnforcementState'](_0x51e5d4)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x5d113d,_0x12b910){return Ae(_0x5d113d,'GET','/v2/recaptchaConfig',Re(_0x5d113d,_0x12b910));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x24e468,_0xd85611){return Ae(_0x24e468,'POST','/v1/accounts:delete',_0xd85611);}async function bn(_0x1cbba8,_0x206313){return Ae(_0x1cbba8,'POST','/v1/accounts:lookup',_0x206313);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x445505){if(_0x445505)try{const _0x7c157a=new Date(Number(_0x445505));if(!isNaN(_0x7c157a['getTime']()))return _0x7c157a['toUTCString']();}catch{}}async function gf(_0x2ec600,_0x5ba309=!0x1){const _0x4efdaf=N(_0x2ec600),_0x288151=await _0x4efdaf['getIdToken'](_0x5ba309),_0x111cb7=Ts(_0x288151);m(_0x111cb7&&_0x111cb7['exp']&&_0x111cb7['auth_time']&&_0x111cb7['iat'],_0x4efdaf['auth'],'internal-error');const _0x595ce0=typeof _0x111cb7['firebase']=='object'?_0x111cb7['firebase']:void 0x0,_0x2c0cd9=_0x595ce0==null?void 0x0:_0x595ce0['sign_in_provider'];return{'claims':_0x111cb7,'token':_0x288151,'authTime':Rt(li(_0x111cb7['auth_time'])),'issuedAtTime':Rt(li(_0x111cb7['iat'])),'expirationTime':Rt(li(_0x111cb7['exp'])),'signInProvider':_0x2c0cd9||null,'signInSecondFactor':(_0x595ce0==null?void 0x0:_0x595ce0['sign_in_second_factor'])||null};}function li(_0x150e58){return Number(_0x150e58)*0x3e8;}function Ts(_0x45b69f){const [_0x538a45,_0x116805,_0x294972]=_0x45b69f['split']('.');if(_0x538a45===void 0x0||_0x116805===void 0x0||_0x294972===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x19bdf2=ln(_0x116805);return _0x19bdf2?JSON['parse'](_0x19bdf2):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x3c5b5f){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x3c5b5f==null?void 0x0:_0x3c5b5f['toString']()),null;}}function Cr(_0x48a249){const _0x186d5a=Ts(_0x48a249);return m(_0x186d5a,'internal-error'),m(typeof _0x186d5a['exp']<'u','internal-error'),m(typeof _0x186d5a['iat']<'u','internal-error'),Number(_0x186d5a['exp'])-Number(_0x186d5a['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x400bcf,_0x12df2b,_0x36dbc5=!0x1){if(_0x36dbc5)return _0x12df2b;try{return await _0x12df2b;}catch(_0xd4ef95){throw _0xd4ef95 instanceof Se&&mf(_0xd4ef95)&&_0x400bcf['auth']['currentUser']===_0x400bcf&&await _0x400bcf['auth']['signOut'](),_0xd4ef95;}}function mf({code:_0x545127}){return _0x545127==='auth/user-disabled'||_0x545127==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x2cc9da){this['user']=_0x2cc9da,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x546c27){if(_0x546c27){const _0x130eff=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x130eff;}else{this['errorBackoff']=0x7530;const _0x49b110=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x49b110);}}['schedule'](_0x2da95c=!0x1){if(!this['isRunning'])return;const _0x1f2f8c=this['getInterval'](_0x2da95c);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x1f2f8c);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x435430){(_0x435430==null?void 0x0:_0x435430['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0xb74091,_0x31be4b){this['createdAt']=_0xb74091,this['lastLoginAt']=_0x31be4b,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x12e3df){this['createdAt']=_0x12e3df['createdAt'],this['lastLoginAt']=_0x12e3df['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x246774){var _0x438914;const _0x596df8=_0x246774['auth'],_0x264cc0=await _0x246774['getIdToken'](),_0x3890e0=await Ut(_0x246774,bn(_0x596df8,{'idToken':_0x264cc0}));m(_0x3890e0==null?void 0x0:_0x3890e0['users']['length'],_0x596df8,'internal-error');const _0x5165c0=_0x3890e0['users'][0x0];_0x246774['_notifyReloadListener'](_0x5165c0);const _0x148cc3=(_0x438914=_0x5165c0['providerUserInfo'])!=null&&_0x438914['length']?Sa(_0x5165c0['providerUserInfo']):[],_0x4944d0=Ef(_0x246774['providerData'],_0x148cc3),_0x677590=_0x246774['isAnonymous'],_0x110676=!(_0x246774['email']&&_0x5165c0['passwordHash'])&&!(_0x4944d0!=null&&_0x4944d0['length']),_0x3c314c=_0x677590?_0x110676:!0x1,_0x11af53={'uid':_0x5165c0['localId'],'displayName':_0x5165c0['displayName']||null,'photoURL':_0x5165c0['photoUrl']||null,'email':_0x5165c0['email']||null,'emailVerified':_0x5165c0['emailVerified']||!0x1,'phoneNumber':_0x5165c0['phoneNumber']||null,'tenantId':_0x5165c0['tenantId']||null,'providerData':_0x4944d0,'metadata':new Oi(_0x5165c0['createdAt'],_0x5165c0['lastLoginAt']),'isAnonymous':_0x3c314c};Object['assign'](_0x246774,_0x11af53);}async function vf(_0x1d1c5e){const _0x3d3d4b=N(_0x1d1c5e);await Rn(_0x3d3d4b),await _0x3d3d4b['auth']['_persistUserIfCurrent'](_0x3d3d4b),_0x3d3d4b['auth']['_notifyListenersIfCurrent'](_0x3d3d4b);}function Ef(_0x1a567e,_0x555f8a){return[..._0x1a567e['filter'](_0x3ff378=>!_0x555f8a['some'](_0x55b7e7=>_0x55b7e7['providerId']===_0x3ff378['providerId'])),..._0x555f8a];}function Sa(_0x11a646){return _0x11a646['map'](({providerId:_0x102930,..._0x2f3307})=>({'providerId':_0x102930,'uid':_0x2f3307['rawId']||'','displayName':_0x2f3307['displayName']||null,'email':_0x2f3307['email']||null,'phoneNumber':_0x2f3307['phoneNumber']||null,'photoURL':_0x2f3307['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x14b75c,_0x499039){const _0x4f58e6=await Ca(_0x14b75c,{},async()=>{const _0x2cf2cf=ct({'grant_type':'refresh_token','refresh_token':_0x499039})['slice'](0x1),{tokenApiHost:_0x184236,apiKey:_0x39b3e6}=_0x14b75c['config'],_0x4ba81a=await Ta(_0x14b75c,_0x184236,'/v1/token','key='+_0x39b3e6),_0x2ab279=await _0x14b75c['_getAdditionalHeaders']();_0x2ab279['Content-Type']='application/x-www-form-urlencoded';const _0x32c6c7={'method':'POST','headers':_0x2ab279,'body':_0x2cf2cf};return _0x14b75c['emulatorConfig']&&at(_0x14b75c['emulatorConfig']['host'])&&(_0x32c6c7['credentials']='include'),wa['fetch']()(_0x4ba81a,_0x32c6c7);});return{'accessToken':_0x4f58e6['access_token'],'expiresIn':_0x4f58e6['expires_in'],'refreshToken':_0x4f58e6['refresh_token']};}async function wf(_0x36f971,_0x1777ae){return Ae(_0x36f971,'POST','/v2/accounts:revokeToken',Re(_0x36f971,_0x1777ae));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x2e2e6a){m(_0x2e2e6a['idToken'],'internal-error'),m(typeof _0x2e2e6a['idToken']<'u','internal-error'),m(typeof _0x2e2e6a['refreshToken']<'u','internal-error');const _0x5c7366='expiresIn'in _0x2e2e6a&&typeof _0x2e2e6a['expiresIn']<'u'?Number(_0x2e2e6a['expiresIn']):Cr(_0x2e2e6a['idToken']);this['updateTokensAndExpiration'](_0x2e2e6a['idToken'],_0x2e2e6a['refreshToken'],_0x5c7366);}['updateFromIdToken'](_0x3bca5b){m(_0x3bca5b['length']!==0x0,'internal-error');const _0x107c5d=Cr(_0x3bca5b);this['updateTokensAndExpiration'](_0x3bca5b,null,_0x107c5d);}async['getToken'](_0x5a4c3f,_0x48d8b4=!0x1){return!_0x48d8b4&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x5a4c3f,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x5a4c3f,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x5c4126,_0x21895e){const {accessToken:_0x318b61,refreshToken:_0x512cef,expiresIn:_0x37393f}=await If(_0x5c4126,_0x21895e);this['updateTokensAndExpiration'](_0x318b61,_0x512cef,Number(_0x37393f));}['updateTokensAndExpiration'](_0x30a656,_0x426db0,_0x39f1a2){this['refreshToken']=_0x426db0||null,this['accessToken']=_0x30a656||null,this['expirationTime']=Date['now']()+_0x39f1a2*0x3e8;}static['fromJSON'](_0x2cc1af,_0x7445f3){const {refreshToken:_0x1ba00a,accessToken:_0x137289,expirationTime:_0x5e14bc}=_0x7445f3,_0xed318a=new Qe();return _0x1ba00a&&(m(typeof _0x1ba00a=='string','internal-error',{'appName':_0x2cc1af}),_0xed318a['refreshToken']=_0x1ba00a),_0x137289&&(m(typeof _0x137289=='string','internal-error',{'appName':_0x2cc1af}),_0xed318a['accessToken']=_0x137289),_0x5e14bc&&(m(typeof _0x5e14bc=='number','internal-error',{'appName':_0x2cc1af}),_0xed318a['expirationTime']=_0x5e14bc),_0xed318a;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4f2460){this['accessToken']=_0x4f2460['accessToken'],this['refreshToken']=_0x4f2460['refreshToken'],this['expirationTime']=_0x4f2460['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x456aac,_0x675366){m(typeof _0x456aac=='string'||typeof _0x456aac>'u','internal-error',{'appName':_0x675366});}class K{constructor({uid:_0xa6f3e6,auth:_0x134248,stsTokenManager:_0x3130ce,..._0x498c2b}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0xa6f3e6,this['auth']=_0x134248,this['stsTokenManager']=_0x3130ce,this['accessToken']=_0x3130ce['accessToken'],this['displayName']=_0x498c2b['displayName']||null,this['email']=_0x498c2b['email']||null,this['emailVerified']=_0x498c2b['emailVerified']||!0x1,this['phoneNumber']=_0x498c2b['phoneNumber']||null,this['photoURL']=_0x498c2b['photoURL']||null,this['isAnonymous']=_0x498c2b['isAnonymous']||!0x1,this['tenantId']=_0x498c2b['tenantId']||null,this['providerData']=_0x498c2b['providerData']?[..._0x498c2b['providerData']]:[],this['metadata']=new Oi(_0x498c2b['createdAt']||void 0x0,_0x498c2b['lastLoginAt']||void 0x0);}async['getIdToken'](_0x5b3205){const _0x12fa37=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x5b3205));return m(_0x12fa37,this['auth'],'internal-error'),this['accessToken']!==_0x12fa37&&(this['accessToken']=_0x12fa37,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x12fa37;}['getIdTokenResult'](_0xcc904c){return gf(this,_0xcc904c);}['reload'](){return vf(this);}['_assign'](_0x4e1336){this!==_0x4e1336&&(m(this['uid']===_0x4e1336['uid'],this['auth'],'internal-error'),this['displayName']=_0x4e1336['displayName'],this['photoURL']=_0x4e1336['photoURL'],this['email']=_0x4e1336['email'],this['emailVerified']=_0x4e1336['emailVerified'],this['phoneNumber']=_0x4e1336['phoneNumber'],this['isAnonymous']=_0x4e1336['isAnonymous'],this['tenantId']=_0x4e1336['tenantId'],this['providerData']=_0x4e1336['providerData']['map'](_0x4f626f=>({..._0x4f626f})),this['metadata']['_copy'](_0x4e1336['metadata']),this['stsTokenManager']['_assign'](_0x4e1336['stsTokenManager']));}['_clone'](_0xe615ef){const _0x19bfd5=new K({...this,'auth':_0xe615ef,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x19bfd5['metadata']['_copy'](this['metadata']),_0x19bfd5;}['_onReload'](_0x285de3){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x285de3,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0xab1370){this['reloadListener']?this['reloadListener'](_0xab1370):this['reloadUserInfo']=_0xab1370;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x5ae5f8,_0x4ab928=!0x1){let _0x5e09c7=!0x1;_0x5ae5f8['idToken']&&_0x5ae5f8['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x5ae5f8),_0x5e09c7=!0x0),_0x4ab928&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x5e09c7&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x1e69de=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x1e69de})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x146357=>({..._0x146357})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x3e293d,_0x257177){const _0x50399e=_0x257177['displayName']??void 0x0,_0x44a282=_0x257177['email']??void 0x0,_0x308288=_0x257177['phoneNumber']??void 0x0,_0x5262cd=_0x257177['photoURL']??void 0x0,_0xf84944=_0x257177['tenantId']??void 0x0,_0xb1cc80=_0x257177['_redirectEventId']??void 0x0,_0x47c3e2=_0x257177['createdAt']??void 0x0,_0x5843a8=_0x257177['lastLoginAt']??void 0x0,{uid:_0x53b087,emailVerified:_0x53927e,isAnonymous:_0x10ec26,providerData:_0x449e4e,stsTokenManager:_0x1818d9}=_0x257177;m(_0x53b087&&_0x1818d9,_0x3e293d,'internal-error');const _0x3b51be=Qe['fromJSON'](this['name'],_0x1818d9);m(typeof _0x53b087=='string',_0x3e293d,'internal-error'),le(_0x50399e,_0x3e293d['name']),le(_0x44a282,_0x3e293d['name']),m(typeof _0x53927e=='boolean',_0x3e293d,'internal-error'),m(typeof _0x10ec26=='boolean',_0x3e293d,'internal-error'),le(_0x308288,_0x3e293d['name']),le(_0x5262cd,_0x3e293d['name']),le(_0xf84944,_0x3e293d['name']),le(_0xb1cc80,_0x3e293d['name']),le(_0x47c3e2,_0x3e293d['name']),le(_0x5843a8,_0x3e293d['name']);const _0x2bf7b1=new K({'uid':_0x53b087,'auth':_0x3e293d,'email':_0x44a282,'emailVerified':_0x53927e,'displayName':_0x50399e,'isAnonymous':_0x10ec26,'photoURL':_0x5262cd,'phoneNumber':_0x308288,'tenantId':_0xf84944,'stsTokenManager':_0x3b51be,'createdAt':_0x47c3e2,'lastLoginAt':_0x5843a8});return _0x449e4e&&Array['isArray'](_0x449e4e)&&(_0x2bf7b1['providerData']=_0x449e4e['map'](_0x5463cc=>({..._0x5463cc}))),_0xb1cc80&&(_0x2bf7b1['_redirectEventId']=_0xb1cc80),_0x2bf7b1;}static async['_fromIdTokenResponse'](_0x572758,_0x5c732a,_0x35c814=!0x1){const _0x5c92a3=new Qe();_0x5c92a3['updateFromServerResponse'](_0x5c732a);const _0x12b3d1=new K({'uid':_0x5c732a['localId'],'auth':_0x572758,'stsTokenManager':_0x5c92a3,'isAnonymous':_0x35c814});return await Rn(_0x12b3d1),_0x12b3d1;}static async['_fromGetAccountInfoResponse'](_0x20a7b3,_0x566cad,_0xfe3d4a){const _0x427d7e=_0x566cad['users'][0x0];m(_0x427d7e['localId']!==void 0x0,'internal-error');const _0x34cb94=_0x427d7e['providerUserInfo']!==void 0x0?Sa(_0x427d7e['providerUserInfo']):[],_0x1eb6b0=!(_0x427d7e['email']&&_0x427d7e['passwordHash'])&&!(_0x34cb94!=null&&_0x34cb94['length']),_0x5b428a=new Qe();_0x5b428a['updateFromIdToken'](_0xfe3d4a);const _0x27713f=new K({'uid':_0x427d7e['localId'],'auth':_0x20a7b3,'stsTokenManager':_0x5b428a,'isAnonymous':_0x1eb6b0}),_0x3b3269={'uid':_0x427d7e['localId'],'displayName':_0x427d7e['displayName']||null,'photoURL':_0x427d7e['photoUrl']||null,'email':_0x427d7e['email']||null,'emailVerified':_0x427d7e['emailVerified']||!0x1,'phoneNumber':_0x427d7e['phoneNumber']||null,'tenantId':_0x427d7e['tenantId']||null,'providerData':_0x34cb94,'metadata':new Oi(_0x427d7e['createdAt'],_0x427d7e['lastLoginAt']),'isAnonymous':!(_0x427d7e['email']&&_0x427d7e['passwordHash'])&&!(_0x34cb94!=null&&_0x34cb94['length'])};return Object['assign'](_0x27713f,_0x3b3269),_0x27713f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x1be100){ce(_0x1be100 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x2ecf2f=Tr['get'](_0x1be100);return _0x2ecf2f?(ce(_0x2ecf2f instanceof _0x1be100,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x2ecf2f):(_0x2ecf2f=new _0x1be100(),Tr['set'](_0x1be100,_0x2ecf2f),_0x2ecf2f);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x543556,_0x368cc1){this['storage'][_0x543556]=_0x368cc1;}async['_get'](_0x580ba8){const _0xe65d47=this['storage'][_0x580ba8];return _0xe65d47===void 0x0?null:_0xe65d47;}async['_remove'](_0x376808){delete this['storage'][_0x376808];}['_addListener'](_0x234ea5,_0x558bce){}['_removeListener'](_0x2aefe9,_0x50ebb3){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x299a05,_0x30bcd5,_0x2751f2){return'firebase:'+_0x299a05+':'+_0x30bcd5+':'+_0x2751f2;}class Je{constructor(_0x3f83ed,_0x2632dd,_0x18cff7){this['persistence']=_0x3f83ed,this['auth']=_0x2632dd,this['userKey']=_0x18cff7;const {config:_0x537123,name:_0x4190b8}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x537123['apiKey'],_0x4190b8),this['fullPersistenceKey']=rn('persistence',_0x537123['apiKey'],_0x4190b8),this['boundEventHandler']=_0x2632dd['_onStorageEvent']['bind'](_0x2632dd),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x3caaf1){return this['persistence']['_set'](this['fullUserKey'],_0x3caaf1['toJSON']());}async['getCurrentUser'](){const _0x1aa888=await this['persistence']['_get'](this['fullUserKey']);if(!_0x1aa888)return null;if(typeof _0x1aa888=='string'){const _0x283b60=await bn(this['auth'],{'idToken':_0x1aa888})['catch'](()=>{});return _0x283b60?K['_fromGetAccountInfoResponse'](this['auth'],_0x283b60,_0x1aa888):null;}return K['_fromJSON'](this['auth'],_0x1aa888);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x46385d){if(this['persistence']===_0x46385d)return;const _0x1103ae=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x46385d,_0x1103ae)return this['setCurrentUser'](_0x1103ae);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x74fcde,_0x1c9a79,_0x23654c='authUser'){if(!_0x1c9a79['length'])return new Je(ie(Sr),_0x74fcde,_0x23654c);const _0x14d605=(await Promise['all'](_0x1c9a79['map'](async _0x1ea9e8=>{if(await _0x1ea9e8['_isAvailable']())return _0x1ea9e8;})))['filter'](_0x2eef1e=>_0x2eef1e);let _0x3bceab=_0x14d605[0x0]||ie(Sr);const _0x3bf87a=rn(_0x23654c,_0x74fcde['config']['apiKey'],_0x74fcde['name']);let _0x3db397=null;for(const _0x10f395 of _0x1c9a79)try{const _0x39ab84=await _0x10f395['_get'](_0x3bf87a);if(_0x39ab84){let _0x2a525d;if(typeof _0x39ab84=='string'){const _0x43ddc3=await bn(_0x74fcde,{'idToken':_0x39ab84})['catch'](()=>{});if(!_0x43ddc3)break;_0x2a525d=await K['_fromGetAccountInfoResponse'](_0x74fcde,_0x43ddc3,_0x39ab84);}else _0x2a525d=K['_fromJSON'](_0x74fcde,_0x39ab84);_0x10f395!==_0x3bceab&&(_0x3db397=_0x2a525d),_0x3bceab=_0x10f395;break;}}catch{}const _0x143444=_0x14d605['filter'](_0x5a4fa2=>_0x5a4fa2['_shouldAllowMigration']);return!_0x3bceab['_shouldAllowMigration']||!_0x143444['length']?new Je(_0x3bceab,_0x74fcde,_0x23654c):(_0x3bceab=_0x143444[0x0],_0x3db397&&await _0x3bceab['_set'](_0x3bf87a,_0x3db397['toJSON']()),await Promise['all'](_0x1c9a79['map'](async _0xa34cf6=>{if(_0xa34cf6!==_0x3bceab)try{await _0xa34cf6['_remove'](_0x3bf87a);}catch{}})),new Je(_0x3bceab,_0x74fcde,_0x23654c));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x48c314){const _0x3bfb1f=_0x48c314['toLowerCase']();if(_0x3bfb1f['includes']('opera/')||_0x3bfb1f['includes']('opr/')||_0x3bfb1f['includes']('opios/'))return'Opera';if(Na(_0x3bfb1f))return'IEMobile';if(_0x3bfb1f['includes']('msie')||_0x3bfb1f['includes']('trident/'))return'IE';if(_0x3bfb1f['includes']('edge/'))return'Edge';if(Ra(_0x3bfb1f))return'Firefox';if(_0x3bfb1f['includes']('silk/'))return'Silk';if(Oa(_0x3bfb1f))return'Blackberry';if(Da(_0x3bfb1f))return'Webos';if(Aa(_0x3bfb1f))return'Safari';if((_0x3bfb1f['includes']('chrome/')||ka(_0x3bfb1f))&&!_0x3bfb1f['includes']('edge/'))return'Chrome';if(Pa(_0x3bfb1f))return'Android';{const _0x14a304=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x3ef13c=_0x48c314['match'](_0x14a304);if((_0x3ef13c==null?void 0x0:_0x3ef13c['length'])===0x2)return _0x3ef13c[0x1];}return'Other';}function Ra(_0x3d373b=W()){return/firefox\//i['test'](_0x3d373b);}function Aa(_0x1ad1a6=W()){const _0x7602a5=_0x1ad1a6['toLowerCase']();return _0x7602a5['includes']('safari/')&&!_0x7602a5['includes']('chrome/')&&!_0x7602a5['includes']('crios/')&&!_0x7602a5['includes']('android');}function ka(_0x2fc925=W()){return/crios\//i['test'](_0x2fc925);}function Na(_0x26a28d=W()){return/iemobile/i['test'](_0x26a28d);}function Pa(_0x59bba8=W()){return/android/i['test'](_0x59bba8);}function Oa(_0x571c88=W()){return/blackberry/i['test'](_0x571c88);}function Da(_0x556867=W()){return/webos/i['test'](_0x556867);}function Ss(_0x193b7e=W()){return/iphone|ipad|ipod/i['test'](_0x193b7e)||/macintosh/i['test'](_0x193b7e)&&/mobile/i['test'](_0x193b7e);}function Cf(_0x4e26fe=W()){var _0x2005c7;return Ss(_0x4e26fe)&&!!((_0x2005c7=window['navigator'])!=null&&_0x2005c7['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x467a55=W()){return Ss(_0x467a55)||Pa(_0x467a55)||Da(_0x467a55)||Oa(_0x467a55)||/windows phone/i['test'](_0x467a55)||Na(_0x467a55);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x1b8807,_0x53aa97=[]){let _0x54f253;switch(_0x1b8807){case'Browser':_0x54f253=br(W());break;case'Worker':_0x54f253=br(W())+'-'+_0x1b8807;break;default:_0x54f253=_0x1b8807;}const _0xdb9e02=_0x53aa97['length']?_0x53aa97['join'](','):'FirebaseCore-web';return _0x54f253+'/JsCore/'+lt+'/'+_0xdb9e02;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0xf0a39b){this['auth']=_0xf0a39b,this['queue']=[];}['pushCallback'](_0x2805b7,_0x23f7c9){const _0x53ded7=_0x512b3b=>new Promise((_0x1f48a7,_0x11c50a)=>{try{const _0x5f1494=_0x2805b7(_0x512b3b);_0x1f48a7(_0x5f1494);}catch(_0x4adb34){_0x11c50a(_0x4adb34);}});_0x53ded7['onAbort']=_0x23f7c9,this['queue']['push'](_0x53ded7);const _0x3b6ee8=this['queue']['length']-0x1;return()=>{this['queue'][_0x3b6ee8]=()=>Promise['resolve']();};}async['runMiddleware'](_0x448dcf){if(this['auth']['currentUser']===_0x448dcf)return;const _0x426276=[];try{for(const _0x1967d5 of this['queue'])await _0x1967d5(_0x448dcf),_0x1967d5['onAbort']&&_0x426276['push'](_0x1967d5['onAbort']);}catch(_0x544d77){_0x426276['reverse']();for(const _0x5cf0f6 of _0x426276)try{_0x5cf0f6();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x544d77==null?void 0x0:_0x544d77['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x35c7fa,_0x567b2d={}){return Ae(_0x35c7fa,'GET','/v2/passwordPolicy',Re(_0x35c7fa,_0x567b2d));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x4296ad){var _0x593b4b;const _0x4d77af=_0x4296ad['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x4d77af['minPasswordLength']??Rf,_0x4d77af['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x4d77af['maxPasswordLength']),_0x4d77af['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x4d77af['containsLowercaseCharacter']),_0x4d77af['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x4d77af['containsUppercaseCharacter']),_0x4d77af['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x4d77af['containsNumericCharacter']),_0x4d77af['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x4d77af['containsNonAlphanumericCharacter']),this['enforcementState']=_0x4296ad['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x593b4b=_0x4296ad['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x593b4b['join'](''))??'',this['forceUpgradeOnSignin']=_0x4296ad['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x4296ad['schemaVersion'];}['validatePassword'](_0x397efa){const _0xdb8ca9={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x397efa,_0xdb8ca9),this['validatePasswordCharacterOptions'](_0x397efa,_0xdb8ca9),_0xdb8ca9['isValid']&&(_0xdb8ca9['isValid']=_0xdb8ca9['meetsMinPasswordLength']??!0x0),_0xdb8ca9['isValid']&&(_0xdb8ca9['isValid']=_0xdb8ca9['meetsMaxPasswordLength']??!0x0),_0xdb8ca9['isValid']&&(_0xdb8ca9['isValid']=_0xdb8ca9['containsLowercaseLetter']??!0x0),_0xdb8ca9['isValid']&&(_0xdb8ca9['isValid']=_0xdb8ca9['containsUppercaseLetter']??!0x0),_0xdb8ca9['isValid']&&(_0xdb8ca9['isValid']=_0xdb8ca9['containsNumericCharacter']??!0x0),_0xdb8ca9['isValid']&&(_0xdb8ca9['isValid']=_0xdb8ca9['containsNonAlphanumericCharacter']??!0x0),_0xdb8ca9;}['validatePasswordLengthOptions'](_0x4f284c,_0x4e870c){const _0x316a4f=this['customStrengthOptions']['minPasswordLength'],_0x3cf79f=this['customStrengthOptions']['maxPasswordLength'];_0x316a4f&&(_0x4e870c['meetsMinPasswordLength']=_0x4f284c['length']>=_0x316a4f),_0x3cf79f&&(_0x4e870c['meetsMaxPasswordLength']=_0x4f284c['length']<=_0x3cf79f);}['validatePasswordCharacterOptions'](_0x59961c,_0x84c4fc){this['updatePasswordCharacterOptionsStatuses'](_0x84c4fc,!0x1,!0x1,!0x1,!0x1);let _0x472e4f;for(let _0x32791a=0x0;_0x32791a<_0x59961c['length'];_0x32791a++)_0x472e4f=_0x59961c['charAt'](_0x32791a),this['updatePasswordCharacterOptionsStatuses'](_0x84c4fc,_0x472e4f>='a'&&_0x472e4f<='z',_0x472e4f>='A'&&_0x472e4f<='Z',_0x472e4f>='0'&&_0x472e4f<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x472e4f));}['updatePasswordCharacterOptionsStatuses'](_0x554468,_0x5a96ef,_0x11c06,_0x11b95f,_0x2a1722){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x554468['containsLowercaseLetter']||(_0x554468['containsLowercaseLetter']=_0x5a96ef)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x554468['containsUppercaseLetter']||(_0x554468['containsUppercaseLetter']=_0x11c06)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x554468['containsNumericCharacter']||(_0x554468['containsNumericCharacter']=_0x11b95f)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x554468['containsNonAlphanumericCharacter']||(_0x554468['containsNonAlphanumericCharacter']=_0x2a1722));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x25dbd1,_0x495aac,_0x57086b,_0x5b976b){this['app']=_0x25dbd1,this['heartbeatServiceProvider']=_0x495aac,this['appCheckServiceProvider']=_0x57086b,this['config']=_0x5b976b,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x25dbd1['name'],this['clientVersion']=_0x5b976b['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x22acfa=>this['_resolvePersistenceManagerAvailable']=_0x22acfa);}['_initializeWithPersistence'](_0x5779fa,_0x12fbfd){return _0x12fbfd&&(this['_popupRedirectResolver']=ie(_0x12fbfd)),this['_initializationPromise']=this['queue'](async()=>{var _0x1200a6,_0xd5f83,_0x34c663;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x5779fa),(_0x1200a6=this['_resolvePersistenceManagerAvailable'])==null||_0x1200a6['call'](this),!this['_deleted'])){if((_0xd5f83=this['_popupRedirectResolver'])!=null&&_0xd5f83['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x12fbfd),this['lastNotifiedUid']=((_0x34c663=this['currentUser'])==null?void 0x0:_0x34c663['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x3448d4=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x3448d4)){if(this['currentUser']&&_0x3448d4&&this['currentUser']['uid']===_0x3448d4['uid']){this['_currentUser']['_assign'](_0x3448d4),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x3448d4,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x4046ec){try{const _0x264c4b=await bn(this,{'idToken':_0x4046ec}),_0x3f63ae=await K['_fromGetAccountInfoResponse'](this,_0x264c4b,_0x4046ec);await this['directlySetCurrentUser'](_0x3f63ae);}catch(_0x4978ed){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x4978ed),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x397ed5){var _0x24d163;if($(this['app'])){const _0x2dc121=this['app']['settings']['authIdToken'];return _0x2dc121?new Promise(_0x515306=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2dc121)['then'](_0x515306,_0x515306));}):this['directlySetCurrentUser'](null);}const _0x5a99ea=await this['assertedPersistence']['getCurrentUser']();let _0x3fe50f=_0x5a99ea,_0x2748fb=!0x1;if(_0x397ed5&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x527835=(_0x24d163=this['redirectUser'])==null?void 0x0:_0x24d163['_redirectEventId'],_0x44874d=_0x3fe50f==null?void 0x0:_0x3fe50f['_redirectEventId'],_0xe7bb59=await this['tryRedirectSignIn'](_0x397ed5);(!_0x527835||_0x527835===_0x44874d)&&(_0xe7bb59!=null&&_0xe7bb59['user'])&&(_0x3fe50f=_0xe7bb59['user'],_0x2748fb=!0x0);}if(!_0x3fe50f)return this['directlySetCurrentUser'](null);if(!_0x3fe50f['_redirectEventId']){if(_0x2748fb)try{await this['beforeStateQueue']['runMiddleware'](_0x3fe50f);}catch(_0x5744cb){_0x3fe50f=_0x5a99ea,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x5744cb));}return _0x3fe50f?this['reloadAndSetCurrentUserOrClear'](_0x3fe50f):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x3fe50f['_redirectEventId']?this['directlySetCurrentUser'](_0x3fe50f):this['reloadAndSetCurrentUserOrClear'](_0x3fe50f);}async['tryRedirectSignIn'](_0x2ab991){let _0x5a88a1=null;try{_0x5a88a1=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x2ab991,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x5a88a1;}async['reloadAndSetCurrentUserOrClear'](_0x28d70c){try{await Rn(_0x28d70c);}catch(_0x4dbdbe){if((_0x4dbdbe==null?void 0x0:_0x4dbdbe['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x28d70c);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0xbc5a34){if($(this['app']))return Promise['reject'](re(this));const _0x47d9fd=_0xbc5a34?N(_0xbc5a34):null;return _0x47d9fd&&m(_0x47d9fd['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x47d9fd&&_0x47d9fd['_clone'](this));}async['_updateCurrentUser'](_0x24eeb1,_0xf6446c=!0x1){if(!this['_deleted'])return _0x24eeb1&&m(this['tenantId']===_0x24eeb1['tenantId'],this,'tenant-id-mismatch'),_0xf6446c||await this['beforeStateQueue']['runMiddleware'](_0x24eeb1),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x24eeb1),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0xe76dc7){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0xe76dc7));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x3e5e2b){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x44d375=this['_getPasswordPolicyInternal']();return _0x44d375['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x44d375['validatePassword'](_0x3e5e2b);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x54854f=await bf(this),_0x5481ab=new Af(_0x54854f);this['tenantId']===null?this['_projectPasswordPolicy']=_0x5481ab:this['_tenantPasswordPolicies'][this['tenantId']]=_0x5481ab;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x1e81ce){this['_errorFactory']=new Bt('auth','Firebase',_0x1e81ce());}['onAuthStateChanged'](_0x53cb75,_0x1e5763,_0x200f3f){return this['registerStateListener'](this['authStateSubscription'],_0x53cb75,_0x1e5763,_0x200f3f);}['beforeAuthStateChanged'](_0xf56af6,_0x20447d){return this['beforeStateQueue']['pushCallback'](_0xf56af6,_0x20447d);}['onIdTokenChanged'](_0x31f144,_0x35a688,_0x4d2c91){return this['registerStateListener'](this['idTokenSubscription'],_0x31f144,_0x35a688,_0x4d2c91);}['authStateReady'](){return new Promise((_0x24190d,_0x42e27d)=>{if(this['currentUser'])_0x24190d();else{const _0x1ffcb5=this['onAuthStateChanged'](()=>{_0x1ffcb5(),_0x24190d();},_0x42e27d);}});}async['revokeAccessToken'](_0x324691){if(this['currentUser']){const _0x1fa3f3=await this['currentUser']['getIdToken'](),_0x1225df={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x324691,'idToken':_0x1fa3f3};this['tenantId']!=null&&(_0x1225df['tenantId']=this['tenantId']),await wf(this,_0x1225df);}}['toJSON'](){var _0x6d074a;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x6d074a=this['_currentUser'])==null?void 0x0:_0x6d074a['toJSON']()};}async['_setRedirectUser'](_0x5714aa,_0x2d0b5b){const _0x5cb590=await this['getOrInitRedirectPersistenceManager'](_0x2d0b5b);return _0x5714aa===null?_0x5cb590['removeCurrentUser']():_0x5cb590['setCurrentUser'](_0x5714aa);}async['getOrInitRedirectPersistenceManager'](_0x3a9885){if(!this['redirectPersistenceManager']){const _0x77e13b=_0x3a9885&&ie(_0x3a9885)||this['_popupRedirectResolver'];m(_0x77e13b,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x77e13b['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x375769){var _0x179d65,_0x182c5b;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x179d65=this['_currentUser'])==null?void 0x0:_0x179d65['_redirectEventId'])===_0x375769?this['_currentUser']:((_0x182c5b=this['redirectUser'])==null?void 0x0:_0x182c5b['_redirectEventId'])===_0x375769?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x11b9ef){if(_0x11b9ef===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x11b9ef));}['_notifyListenersIfCurrent'](_0x3f3518){_0x3f3518===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x383ef4;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x198e12=((_0x383ef4=this['currentUser'])==null?void 0x0:_0x383ef4['uid'])??null;this['lastNotifiedUid']!==_0x198e12&&(this['lastNotifiedUid']=_0x198e12,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x19e925,_0x2d6e60,_0x262174,_0x1bcd20){if(this['_deleted'])return()=>{};const _0x505d96=typeof _0x2d6e60=='function'?_0x2d6e60:_0x2d6e60['next']['bind'](_0x2d6e60);let _0x1d19e7=!0x1;const _0x2575b4=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x2575b4,this,'internal-error'),_0x2575b4['then'](()=>{_0x1d19e7||_0x505d96(this['currentUser']);}),typeof _0x2d6e60=='function'){const _0x248982=_0x19e925['addObserver'](_0x2d6e60,_0x262174,_0x1bcd20);return()=>{_0x1d19e7=!0x0,_0x248982();};}else{const _0x23122c=_0x19e925['addObserver'](_0x2d6e60);return()=>{_0x1d19e7=!0x0,_0x23122c();};}}async['directlySetCurrentUser'](_0x2d7ac0){this['currentUser']&&this['currentUser']!==_0x2d7ac0&&this['_currentUser']['_stopProactiveRefresh'](),_0x2d7ac0&&this['isProactiveRefreshEnabled']&&_0x2d7ac0['_startProactiveRefresh'](),this['currentUser']=_0x2d7ac0,_0x2d7ac0?await this['assertedPersistence']['setCurrentUser'](_0x2d7ac0):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x6b8f67){return this['operations']=this['operations']['then'](_0x6b8f67,_0x6b8f67),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x2bffc9){!_0x2bffc9||this['frameworks']['includes'](_0x2bffc9)||(this['frameworks']['push'](_0x2bffc9),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x537b0c;const _0x48ef25={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x48ef25['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x44a4ba=await((_0x537b0c=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x537b0c['getHeartbeatsHeader']());_0x44a4ba&&(_0x48ef25['X-Firebase-Client']=_0x44a4ba);const _0x5279a2=await this['_getAppCheckToken']();return _0x5279a2&&(_0x48ef25['X-Firebase-AppCheck']=_0x5279a2),_0x48ef25;}async['_getAppCheckToken'](){var _0x3e6afa;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x2378f9=await((_0x3e6afa=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x3e6afa['getToken']());return _0x2378f9!=null&&_0x2378f9['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x2378f9['error']),_0x2378f9==null?void 0x0:_0x2378f9['token'];}}function qe(_0x1c575f){return N(_0x1c575f);}class Rr{constructor(_0x1ae3ae){this['auth']=_0x1ae3ae,this['observer']=null,this['addObserver']=Tc(_0x201dc6=>this['observer']=_0x201dc6);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x226430){jn=_0x226430;}function xa(_0x4a8748){return jn['loadJS'](_0x4a8748);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x14bd1c){return'__'+_0x14bd1c+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x4a3ef5){_0x4a3ef5();}['execute'](_0x8c6d0b,_0x1d84fb){return Promise['resolve']('token');}['render'](_0xb4203,_0x88b27f){return'';}}class Lf{['ready'](_0x40af06){_0x40af06();}['execute'](_0x53b596,_0x5cc2a4){return Promise['resolve']('token');}['render'](_0x58e765,_0x26f065){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x572113){this['type']=xf,this['auth']=qe(_0x572113);}async['verify'](_0xcaa7ac='verify',_0x2f08e1=!0x1){async function _0xd5198a(_0x2c51a3){if(!_0x2f08e1){if(_0x2c51a3['tenantId']==null&&_0x2c51a3['_agentRecaptchaConfig']!=null)return _0x2c51a3['_agentRecaptchaConfig']['siteKey'];if(_0x2c51a3['tenantId']!=null&&_0x2c51a3['_tenantRecaptchaConfigs'][_0x2c51a3['tenantId']]!==void 0x0)return _0x2c51a3['_tenantRecaptchaConfigs'][_0x2c51a3['tenantId']]['siteKey'];}return new Promise(async(_0x4c3473,_0x3446d1)=>{pf(_0x2c51a3,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0xc199e9=>{if(_0xc199e9['recaptchaKey']===void 0x0)_0x3446d1(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x1cddf7=new ff(_0xc199e9);return _0x2c51a3['tenantId']==null?_0x2c51a3['_agentRecaptchaConfig']=_0x1cddf7:_0x2c51a3['_tenantRecaptchaConfigs'][_0x2c51a3['tenantId']]=_0x1cddf7,_0x4c3473(_0x1cddf7['siteKey']);}})['catch'](_0x45e350=>{_0x3446d1(_0x45e350);});});}function _0x17bc0e(_0xa5bc2d,_0x200dc3,_0xfda487){const _0x440f60=window['grecaptcha'];wr(_0x440f60)?_0x440f60['enterprise']['ready'](()=>{_0x440f60['enterprise']['execute'](_0xa5bc2d,{'action':_0xcaa7ac})['then'](_0x325300=>{_0x200dc3(_0x325300);})['catch'](()=>{_0x200dc3(Fa);});}):_0xfda487(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x4d28e8,_0x38e156)=>{_0xd5198a(this['auth'])['then'](_0x297c86=>{if(!_0x2f08e1&&wr(window['grecaptcha']))_0x17bc0e(_0x297c86,_0x4d28e8,_0x38e156);else{if(typeof window>'u'){_0x38e156(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x1dc73e=Pf();_0x1dc73e['length']!==0x0&&(_0x1dc73e+=_0x297c86),xa(_0x1dc73e)['then'](()=>{_0x17bc0e(_0x297c86,_0x4d28e8,_0x38e156);})['catch'](_0x2f6600=>{_0x38e156(_0x2f6600);});}})['catch'](_0x6d67bf=>{_0x38e156(_0x6d67bf);});});}}async function Ar(_0x154994,_0x484bea,_0x532e35,_0x4ad90=!0x1,_0x544ad9=!0x1){const _0x26fd76=new Ff(_0x154994);let _0x344c06;if(_0x544ad9)_0x344c06=Fa;else try{_0x344c06=await _0x26fd76['verify'](_0x532e35);}catch{_0x344c06=await _0x26fd76['verify'](_0x532e35,!0x0);}const _0x2eb43d={..._0x484bea};if(_0x532e35==='mfaSmsEnrollment'||_0x532e35==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x2eb43d){const _0x37a72b=_0x2eb43d['phoneEnrollmentInfo']['phoneNumber'],_0x546394=_0x2eb43d['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x2eb43d,{'phoneEnrollmentInfo':{'phoneNumber':_0x37a72b,'recaptchaToken':_0x546394,'captchaResponse':_0x344c06,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x2eb43d){const _0xe69d22=_0x2eb43d['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x2eb43d,{'phoneSignInInfo':{'recaptchaToken':_0xe69d22,'captchaResponse':_0x344c06,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x2eb43d;}return _0x4ad90?Object['assign'](_0x2eb43d,{'captchaResp':_0x344c06}):Object['assign'](_0x2eb43d,{'captchaResponse':_0x344c06}),Object['assign'](_0x2eb43d,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x2eb43d,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x2eb43d;}async function Di(_0x597b3e,_0x5e1b90,_0x50c595,_0x203e73,_0x3d6b62){var _0x5444c3;if((_0x5444c3=_0x597b3e['_getRecaptchaConfig']())!=null&&_0x5444c3['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0xd452c6=await Ar(_0x597b3e,_0x5e1b90,_0x50c595,_0x50c595==='getOobCode');return _0x203e73(_0x597b3e,_0xd452c6);}else return _0x203e73(_0x597b3e,_0x5e1b90)['catch'](async _0x25ba9d=>{if(_0x25ba9d['code']==='auth/missing-recaptcha-token'){console['log'](_0x50c595+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x785585=await Ar(_0x597b3e,_0x5e1b90,_0x50c595,_0x50c595==='getOobCode');return _0x203e73(_0x597b3e,_0x785585);}else return Promise['reject'](_0x25ba9d);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x341b09,_0x34dad8){const _0x25b84a=Bi(_0x341b09,'auth');if(_0x25b84a['isInitialized']()){const _0x3ecd48=_0x25b84a['getImmediate'](),_0x3fa487=_0x25b84a['getOptions']();if(Me(_0x3fa487,_0x34dad8??{}))return _0x3ecd48;Q(_0x3ecd48,'already-initialized');}return _0x25b84a['initialize']({'options':_0x34dad8});}function Wf(_0x9d9dc7,_0x287712){const _0x4b9c41=(_0x287712==null?void 0x0:_0x287712['persistence'])||[],_0x389d62=(Array['isArray'](_0x4b9c41)?_0x4b9c41:[_0x4b9c41])['map'](ie);_0x287712!=null&&_0x287712['errorMap']&&_0x9d9dc7['_updateErrorMap'](_0x287712['errorMap']),_0x9d9dc7['_initializeWithPersistence'](_0x389d62,_0x287712==null?void 0x0:_0x287712['popupRedirectResolver']);}function Bf(_0x1a5be6,_0x3c22dc,_0x15ce08){const _0x2fb0c0=qe(_0x1a5be6);m(/^https?:\/\//['test'](_0x3c22dc),_0x2fb0c0,'invalid-emulator-scheme');const _0x1b03d6=!0x1,_0x36f613=Ua(_0x3c22dc),{host:_0x32433b,port:_0x51f6a9}=Vf(_0x3c22dc),_0x699f63=_0x51f6a9===null?'':':'+_0x51f6a9,_0x23556c={'url':_0x36f613+'//'+_0x32433b+_0x699f63+'/'},_0x25e794=Object['freeze']({'host':_0x32433b,'port':_0x51f6a9,'protocol':_0x36f613['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x1b03d6})});if(!_0x2fb0c0['_canInitEmulator']){m(_0x2fb0c0['config']['emulator']&&_0x2fb0c0['emulatorConfig'],_0x2fb0c0,'emulator-config-failed'),m(Me(_0x23556c,_0x2fb0c0['config']['emulator'])&&Me(_0x25e794,_0x2fb0c0['emulatorConfig']),_0x2fb0c0,'emulator-config-failed');return;}_0x2fb0c0['config']['emulator']=_0x23556c,_0x2fb0c0['emulatorConfig']=_0x25e794,_0x2fb0c0['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x32433b)?(jr(_0x36f613+'//'+_0x32433b+_0x699f63),Kr('Auth',!0x0)):Hf();}function Ua(_0x58e7ab){const _0x190024=_0x58e7ab['indexOf'](':');return _0x190024<0x0?'':_0x58e7ab['substr'](0x0,_0x190024+0x1);}function Vf(_0x5ecf34){const _0x199d42=Ua(_0x5ecf34),_0xb4e210=/(\/\/)?([^?#/]+)/['exec'](_0x5ecf34['substr'](_0x199d42['length']));if(!_0xb4e210)return{'host':'','port':null};const _0x4e658e=_0xb4e210[0x2]['split']('@')['pop']()||'',_0x5a8f37=/^(\[[^\]]+\])(:|$)/['exec'](_0x4e658e);if(_0x5a8f37){const _0x22070c=_0x5a8f37[0x1];return{'host':_0x22070c,'port':kr(_0x4e658e['substr'](_0x22070c['length']+0x1))};}else{const [_0x3d0471,_0x549c66]=_0x4e658e['split'](':');return{'host':_0x3d0471,'port':kr(_0x549c66)};}}function kr(_0x5905d1){if(!_0x5905d1)return null;const _0x5d3048=Number(_0x5905d1);return isNaN(_0x5d3048)?null:_0x5d3048;}function Hf(){function _0x11aaaa(){const _0x3a9332=document['createElement']('p'),_0x15b529=_0x3a9332['style'];_0x3a9332['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x15b529['position']='fixed',_0x15b529['width']='100%',_0x15b529['backgroundColor']='#ffffff',_0x15b529['border']='.1em\x20solid\x20#000000',_0x15b529['color']='#b50000',_0x15b529['bottom']='0px',_0x15b529['left']='0px',_0x15b529['margin']='0px',_0x15b529['zIndex']='10000',_0x15b529['textAlign']='center',_0x3a9332['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x3a9332);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x11aaaa):_0x11aaaa());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x155c95,_0x3a52b2){this['providerId']=_0x155c95,this['signInMethod']=_0x3a52b2;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x40a1b6){return ne('not\x20implemented');}['_linkToIdToken'](_0xfbe0a2,_0x46d4cb){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x1294fb){return ne('not\x20implemented');}}async function $f(_0x53fbf6,_0xff92de){return Ae(_0x53fbf6,'POST','/v1/accounts:signUp',_0xff92de);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x51e090,_0x2e80e6){return Qt(_0x51e090,'POST','/v1/accounts:signInWithPassword',Re(_0x51e090,_0x2e80e6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x344af3,_0x4bd644){return Qt(_0x344af3,'POST','/v1/accounts:signInWithEmailLink',Re(_0x344af3,_0x4bd644));}async function zf(_0x59ddb5,_0x13d885){return Qt(_0x59ddb5,'POST','/v1/accounts:signInWithEmailLink',Re(_0x59ddb5,_0x13d885));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x107c89,_0x4a5c45,_0x11f187,_0x3a6439=null){super('password',_0x11f187),this['_email']=_0x107c89,this['_password']=_0x4a5c45,this['_tenantId']=_0x3a6439;}static['_fromEmailAndPassword'](_0x4a3984,_0x35fc67){return new Wt(_0x4a3984,_0x35fc67,'password');}static['_fromEmailAndCode'](_0x165985,_0x413ae1,_0x30e1f7=null){return new Wt(_0x165985,_0x413ae1,'emailLink',_0x30e1f7);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0xe12053){const _0xa261ce=typeof _0xe12053=='string'?JSON['parse'](_0xe12053):_0xe12053;if(_0xa261ce!=null&&_0xa261ce['email']&&(_0xa261ce!=null&&_0xa261ce['password'])){if(_0xa261ce['signInMethod']==='password')return this['_fromEmailAndPassword'](_0xa261ce['email'],_0xa261ce['password']);if(_0xa261ce['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0xa261ce['email'],_0xa261ce['password'],_0xa261ce['tenantId']);}return null;}async['_getIdTokenResponse'](_0x1d0d3c){switch(this['signInMethod']){case'password':const _0x2d8df8={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x1d0d3c,_0x2d8df8,'signInWithPassword',Gf);case'emailLink':return qf(_0x1d0d3c,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x1d0d3c,'internal-error');}}async['_linkToIdToken'](_0x14434e,_0x3a2dab){switch(this['signInMethod']){case'password':const _0x5a569a={'idToken':_0x3a2dab,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x14434e,_0x5a569a,'signUpPassword',$f);case'emailLink':return zf(_0x14434e,{'idToken':_0x3a2dab,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x14434e,'internal-error');}}['_getReauthenticationResolver'](_0x6b6726){return this['_getIdTokenResponse'](_0x6b6726);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x1af5d3,_0x529c97){return Qt(_0x1af5d3,'POST','/v1/accounts:signInWithIdp',Re(_0x1af5d3,_0x529c97));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x2f070e){const _0x57b571=new Be(_0x2f070e['providerId'],_0x2f070e['signInMethod']);return _0x2f070e['idToken']||_0x2f070e['accessToken']?(_0x2f070e['idToken']&&(_0x57b571['idToken']=_0x2f070e['idToken']),_0x2f070e['accessToken']&&(_0x57b571['accessToken']=_0x2f070e['accessToken']),_0x2f070e['nonce']&&!_0x2f070e['pendingToken']&&(_0x57b571['nonce']=_0x2f070e['nonce']),_0x2f070e['pendingToken']&&(_0x57b571['pendingToken']=_0x2f070e['pendingToken'])):_0x2f070e['oauthToken']&&_0x2f070e['oauthTokenSecret']?(_0x57b571['accessToken']=_0x2f070e['oauthToken'],_0x57b571['secret']=_0x2f070e['oauthTokenSecret']):Q('argument-error'),_0x57b571;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x2f290b){const _0x1771ef=typeof _0x2f290b=='string'?JSON['parse'](_0x2f290b):_0x2f290b,{providerId:_0x5dba37,signInMethod:_0x35c68f,..._0x57eb63}=_0x1771ef;if(!_0x5dba37||!_0x35c68f)return null;const _0x3aec47=new Be(_0x5dba37,_0x35c68f);return _0x3aec47['idToken']=_0x57eb63['idToken']||void 0x0,_0x3aec47['accessToken']=_0x57eb63['accessToken']||void 0x0,_0x3aec47['secret']=_0x57eb63['secret'],_0x3aec47['nonce']=_0x57eb63['nonce'],_0x3aec47['pendingToken']=_0x57eb63['pendingToken']||null,_0x3aec47;}['_getIdTokenResponse'](_0x150da1){const _0x385764=this['buildRequest']();return Xe(_0x150da1,_0x385764);}['_linkToIdToken'](_0x3d173f,_0x3fd8ac){const _0x489076=this['buildRequest']();return _0x489076['idToken']=_0x3fd8ac,Xe(_0x3d173f,_0x489076);}['_getReauthenticationResolver'](_0x3a5ce9){const _0x2cce2f=this['buildRequest']();return _0x2cce2f['autoCreate']=!0x1,Xe(_0x3a5ce9,_0x2cce2f);}['buildRequest'](){const _0x5d3613={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x5d3613['pendingToken']=this['pendingToken'];else{const _0x3349c9={};this['idToken']&&(_0x3349c9['id_token']=this['idToken']),this['accessToken']&&(_0x3349c9['access_token']=this['accessToken']),this['secret']&&(_0x3349c9['oauth_token_secret']=this['secret']),_0x3349c9['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x3349c9['nonce']=this['nonce']),_0x5d3613['postBody']=ct(_0x3349c9);}return _0x5d3613;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0xd66ea1){switch(_0xd66ea1){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x5dc292){const _0x42b793=vt(Et(_0x5dc292))['link'],_0x7176e7=_0x42b793?vt(Et(_0x42b793))['deep_link_id']:null,_0x1407f9=vt(Et(_0x5dc292))['deep_link_id'];return(_0x1407f9?vt(Et(_0x1407f9))['link']:null)||_0x1407f9||_0x7176e7||_0x42b793||_0x5dc292;}class Rs{constructor(_0xe95aca){const _0x4476d6=vt(Et(_0xe95aca)),_0x3713fe=_0x4476d6['apiKey']??null,_0x447602=_0x4476d6['oobCode']??null,_0x449241=Kf(_0x4476d6['mode']??null);m(_0x3713fe&&_0x447602&&_0x449241,'argument-error'),this['apiKey']=_0x3713fe,this['operation']=_0x449241,this['code']=_0x447602,this['continueUrl']=_0x4476d6['continueUrl']??null,this['languageCode']=_0x4476d6['lang']??null,this['tenantId']=_0x4476d6['tenantId']??null;}static['parseLink'](_0x53ee43){const _0x1034b1=Yf(_0x53ee43);try{return new Rs(_0x1034b1);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x3316fd,_0x1d0d2a){return Wt['_fromEmailAndPassword'](_0x3316fd,_0x1d0d2a);}static['credentialWithLink'](_0x249f52,_0x5c9bc4){const _0x3371aa=Rs['parseLink'](_0x5c9bc4);return m(_0x3371aa,'argument-error'),Wt['_fromEmailAndCode'](_0x249f52,_0x3371aa['code'],_0x3371aa['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x29872f){this['providerId']=_0x29872f,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x3e55ad){this['defaultLanguageCode']=_0x3e55ad;}['setCustomParameters'](_0x94b524){return this['customParameters']=_0x94b524,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0xcb4ce2){return this['scopes']['includes'](_0xcb4ce2)||this['scopes']['push'](_0xcb4ce2),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0xf3dfb4){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0xf3dfb4});}static['credentialFromResult'](_0x53b2a6){return he['credentialFromTaggedObject'](_0x53b2a6);}static['credentialFromError'](_0x5ed158){return he['credentialFromTaggedObject'](_0x5ed158['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x497ff5}){if(!_0x497ff5||!('oauthAccessToken'in _0x497ff5)||!_0x497ff5['oauthAccessToken'])return null;try{return he['credential'](_0x497ff5['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x22c4f8,_0x5c5268){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x22c4f8,'accessToken':_0x5c5268});}static['credentialFromResult'](_0x53ff13){return ue['credentialFromTaggedObject'](_0x53ff13);}static['credentialFromError'](_0x5d8216){return ue['credentialFromTaggedObject'](_0x5d8216['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x17dbe3}){if(!_0x17dbe3)return null;const {oauthIdToken:_0x388e45,oauthAccessToken:_0x54ec3e}=_0x17dbe3;if(!_0x388e45&&!_0x54ec3e)return null;try{return ue['credential'](_0x388e45,_0x54ec3e);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x5d5e7b){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x5d5e7b});}static['credentialFromResult'](_0x4e209f){return de['credentialFromTaggedObject'](_0x4e209f);}static['credentialFromError'](_0x5927ec){return de['credentialFromTaggedObject'](_0x5927ec['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4d9a84}){if(!_0x4d9a84||!('oauthAccessToken'in _0x4d9a84)||!_0x4d9a84['oauthAccessToken'])return null;try{return de['credential'](_0x4d9a84['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x1d0748,_0x3c76a2){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x1d0748,'oauthTokenSecret':_0x3c76a2});}static['credentialFromResult'](_0x596f00){return fe['credentialFromTaggedObject'](_0x596f00);}static['credentialFromError'](_0x403894){return fe['credentialFromTaggedObject'](_0x403894['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5b613f}){if(!_0x5b613f)return null;const {oauthAccessToken:_0x190dba,oauthTokenSecret:_0x86e93a}=_0x5b613f;if(!_0x190dba||!_0x86e93a)return null;try{return fe['credential'](_0x190dba,_0x86e93a);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x193fb5,_0x297324){return Qt(_0x193fb5,'POST','/v1/accounts:signUp',Re(_0x193fb5,_0x297324));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x4d7c58){this['user']=_0x4d7c58['user'],this['providerId']=_0x4d7c58['providerId'],this['_tokenResponse']=_0x4d7c58['_tokenResponse'],this['operationType']=_0x4d7c58['operationType'];}static async['_fromIdTokenResponse'](_0x3b03da,_0x45d5c3,_0x1ffb5d,_0x4aa89f=!0x1){const _0x5cba05=await K['_fromIdTokenResponse'](_0x3b03da,_0x1ffb5d,_0x4aa89f),_0x2194d2=Nr(_0x1ffb5d);return new Ve({'user':_0x5cba05,'providerId':_0x2194d2,'_tokenResponse':_0x1ffb5d,'operationType':_0x45d5c3});}static async['_forOperation'](_0x301888,_0xfda0a1,_0x3645cd){await _0x301888['_updateTokensIfNecessary'](_0x3645cd,!0x0);const _0x1b728f=Nr(_0x3645cd);return new Ve({'user':_0x301888,'providerId':_0x1b728f,'_tokenResponse':_0x3645cd,'operationType':_0xfda0a1});}}function Nr(_0x27b129){return _0x27b129['providerId']?_0x27b129['providerId']:'phoneNumber'in _0x27b129?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x2068f5,_0x24aca6,_0x440503,_0x4cacad){super(_0x24aca6['code'],_0x24aca6['message']),this['operationType']=_0x440503,this['user']=_0x4cacad,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x2068f5['name'],'tenantId':_0x2068f5['tenantId']??void 0x0,'_serverResponse':_0x24aca6['customData']['_serverResponse'],'operationType':_0x440503};}static['_fromErrorAndOperation'](_0x4895e4,_0x12de90,_0x40b5af,_0x4f1994){return new An(_0x4895e4,_0x12de90,_0x40b5af,_0x4f1994);}}function Ba(_0x12eec7,_0x562edb,_0x3dad4b,_0x8b159b){return(_0x562edb==='reauthenticate'?_0x3dad4b['_getReauthenticationResolver'](_0x12eec7):_0x3dad4b['_getIdTokenResponse'](_0x12eec7))['catch'](_0x34a1f7=>{throw _0x34a1f7['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x12eec7,_0x34a1f7,_0x562edb,_0x8b159b):_0x34a1f7;});}async function Jf(_0x229d15,_0x5155da,_0x414516=!0x1){const _0x4cebb8=await Ut(_0x229d15,_0x5155da['_linkToIdToken'](_0x229d15['auth'],await _0x229d15['getIdToken']()),_0x414516);return Ve['_forOperation'](_0x229d15,'link',_0x4cebb8);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x2df9de,_0xc38c0a,_0xe6cb7e=!0x1){const {auth:_0x2e37fa}=_0x2df9de;if($(_0x2e37fa['app']))return Promise['reject'](re(_0x2e37fa));const _0x2a24d4='reauthenticate';try{const _0x212979=await Ut(_0x2df9de,Ba(_0x2e37fa,_0x2a24d4,_0xc38c0a,_0x2df9de),_0xe6cb7e);m(_0x212979['idToken'],_0x2e37fa,'internal-error');const _0x1dfea1=Ts(_0x212979['idToken']);m(_0x1dfea1,_0x2e37fa,'internal-error');const {sub:_0x130da2}=_0x1dfea1;return m(_0x2df9de['uid']===_0x130da2,_0x2e37fa,'user-mismatch'),Ve['_forOperation'](_0x2df9de,_0x2a24d4,_0x212979);}catch(_0x55c01c){throw(_0x55c01c==null?void 0x0:_0x55c01c['code'])==='auth/user-not-found'&&Q(_0x2e37fa,'user-mismatch'),_0x55c01c;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x466459,_0x5855e5,_0x3a5c6b=!0x1){if($(_0x466459['app']))return Promise['reject'](re(_0x466459));const _0x1f5132='signIn',_0x1d7e89=await Ba(_0x466459,_0x1f5132,_0x5855e5),_0x47b373=await Ve['_fromIdTokenResponse'](_0x466459,_0x1f5132,_0x1d7e89);return _0x3a5c6b||await _0x466459['_updateCurrentUser'](_0x47b373['user']),_0x47b373;}async function Zf(_0x5d9317,_0x4c8e6e){return Va(qe(_0x5d9317),_0x4c8e6e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x427724){const _0x5d0cdc=qe(_0x427724);_0x5d0cdc['_getPasswordPolicyInternal']()&&await _0x5d0cdc['_updatePasswordPolicy']();}async function P_(_0x1676b2,_0x1dbccb,_0x45440f){if($(_0x1676b2['app']))return Promise['reject'](re(_0x1676b2));const _0x43a8c6=qe(_0x1676b2),_0x3548ff=await Di(_0x43a8c6,{'returnSecureToken':!0x0,'email':_0x1dbccb,'password':_0x45440f,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x1b31de=>{throw _0x1b31de['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x1676b2),_0x1b31de;}),_0x1ffd20=await Ve['_fromIdTokenResponse'](_0x43a8c6,'signIn',_0x3548ff);return await _0x43a8c6['_updateCurrentUser'](_0x1ffd20['user']),_0x1ffd20;}function O_(_0x3beeae,_0x588616,_0x355225){return $(_0x3beeae['app'])?Promise['reject'](re(_0x3beeae)):Zf(N(_0x3beeae),pt['credential'](_0x588616,_0x355225))['catch'](async _0xbca5ce=>{throw _0xbca5ce['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x3beeae),_0xbca5ce;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x53341b,_0x4b0e78){return N(_0x53341b)['setPersistence'](_0x4b0e78);}function ep(_0xe4d2f9,_0x26103c,_0xba4d2,_0xc2e5ba){return N(_0xe4d2f9)['onIdTokenChanged'](_0x26103c,_0xba4d2,_0xc2e5ba);}function tp(_0x57568a,_0x4d2cd2,_0x3cf759){return N(_0x57568a)['beforeAuthStateChanged'](_0x4d2cd2,_0x3cf759);}function M_(_0x8db172,_0x5d2b4d,_0x38ad60,_0x387add){return N(_0x8db172)['onAuthStateChanged'](_0x5d2b4d,_0x38ad60,_0x387add);}function L_(_0x442d54){return N(_0x442d54)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0xde35ef,_0x455c41){this['storageRetriever']=_0xde35ef,this['type']=_0x455c41;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x4bcae4,_0x5ae7bd){return this['storage']['setItem'](_0x4bcae4,JSON['stringify'](_0x5ae7bd)),Promise['resolve']();}['_get'](_0x274224){const _0x4e06a7=this['storage']['getItem'](_0x274224);return Promise['resolve'](_0x4e06a7?JSON['parse'](_0x4e06a7):null);}['_remove'](_0xe24a68){return this['storage']['removeItem'](_0xe24a68),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x1906b8,_0x5b3186)=>this['onStorageEvent'](_0x1906b8,_0x5b3186),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x4e9048){for(const _0x110e41 of Object['keys'](this['listeners'])){const _0x161f0c=this['storage']['getItem'](_0x110e41),_0x43be01=this['localCache'][_0x110e41];_0x161f0c!==_0x43be01&&_0x4e9048(_0x110e41,_0x43be01,_0x161f0c);}}['onStorageEvent'](_0x41b1bb,_0x37421d=!0x1){if(!_0x41b1bb['key']){this['forAllChangedKeys']((_0xf79a56,_0x5012ec,_0x5dfe7d)=>{this['notifyListeners'](_0xf79a56,_0x5dfe7d);});return;}const _0x2b8ebf=_0x41b1bb['key'];_0x37421d?this['detachListener']():this['stopPolling']();const _0x5de0df=()=>{const _0x8f71a9=this['storage']['getItem'](_0x2b8ebf);!_0x37421d&&this['localCache'][_0x2b8ebf]===_0x8f71a9||this['notifyListeners'](_0x2b8ebf,_0x8f71a9);},_0x1eeb52=this['storage']['getItem'](_0x2b8ebf);Tf()&&_0x1eeb52!==_0x41b1bb['newValue']&&_0x41b1bb['newValue']!==_0x41b1bb['oldValue']?setTimeout(_0x5de0df,ip):_0x5de0df();}['notifyListeners'](_0x133b00,_0x408eb3){this['localCache'][_0x133b00]=_0x408eb3;const _0x2aec10=this['listeners'][_0x133b00];if(_0x2aec10){for(const _0x551b0d of Array['from'](_0x2aec10))_0x551b0d(_0x408eb3&&JSON['parse'](_0x408eb3));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x247c06,_0x7e512,_0xa7efe4)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x247c06,'oldValue':_0x7e512,'newValue':_0xa7efe4}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x14129b,_0x38253a){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x14129b]||(this['listeners'][_0x14129b]=new Set(),this['localCache'][_0x14129b]=this['storage']['getItem'](_0x14129b)),this['listeners'][_0x14129b]['add'](_0x38253a);}['_removeListener'](_0x375bfc,_0x4fa9af){this['listeners'][_0x375bfc]&&(this['listeners'][_0x375bfc]['delete'](_0x4fa9af),this['listeners'][_0x375bfc]['size']===0x0&&delete this['listeners'][_0x375bfc]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x8105fd,_0x1d8547){await super['_set'](_0x8105fd,_0x1d8547),this['localCache'][_0x8105fd]=JSON['stringify'](_0x1d8547);}async['_get'](_0x2eb567){const _0xfd1295=await super['_get'](_0x2eb567);return this['localCache'][_0x2eb567]=JSON['stringify'](_0xfd1295),_0xfd1295;}async['_remove'](_0x5b80d0){await super['_remove'](_0x5b80d0),delete this['localCache'][_0x5b80d0];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0xbafbd4,_0xb91398){}['_removeListener'](_0x12a4be,_0x52ffbd){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x5bcd34){return Promise['all'](_0x5bcd34['map'](async _0x32a68f=>{try{return{'fulfilled':!0x0,'value':await _0x32a68f};}catch(_0x22cf33){return{'fulfilled':!0x1,'reason':_0x22cf33};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x38dc03){this['eventTarget']=_0x38dc03,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0xe3d6df){const _0x3543f0=this['receivers']['find'](_0x203c20=>_0x203c20['isListeningto'](_0xe3d6df));if(_0x3543f0)return _0x3543f0;const _0x4b06f3=new Kn(_0xe3d6df);return this['receivers']['push'](_0x4b06f3),_0x4b06f3;}['isListeningto'](_0x1d05b9){return this['eventTarget']===_0x1d05b9;}async['handleEvent'](_0x51d85a){const _0x420480=_0x51d85a,{eventId:_0x50a98c,eventType:_0x2563da,data:_0x114d5f}=_0x420480['data'],_0x3254d7=this['handlersMap'][_0x2563da];if(!(_0x3254d7!=null&&_0x3254d7['size']))return;_0x420480['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x50a98c,'eventType':_0x2563da});const _0x5995be=Array['from'](_0x3254d7)['map'](async _0x1c511f=>_0x1c511f(_0x420480['origin'],_0x114d5f)),_0x18b990=await rp(_0x5995be);_0x420480['ports'][0x0]['postMessage']({'status':'done','eventId':_0x50a98c,'eventType':_0x2563da,'response':_0x18b990});}['_subscribe'](_0x3738bd,_0x5d2552){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x3738bd]||(this['handlersMap'][_0x3738bd]=new Set()),this['handlersMap'][_0x3738bd]['add'](_0x5d2552);}['_unsubscribe'](_0x24fbae,_0x397f24){this['handlersMap'][_0x24fbae]&&_0x397f24&&this['handlersMap'][_0x24fbae]['delete'](_0x397f24),(!_0x397f24||this['handlersMap'][_0x24fbae]['size']===0x0)&&delete this['handlersMap'][_0x24fbae],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x41ecad='',_0x57ef28=0xa){let _0x5e7ce4='';for(let _0x32edca=0x0;_0x32edca<_0x57ef28;_0x32edca++)_0x5e7ce4+=Math['floor'](Math['random']()*0xa);return _0x41ecad+_0x5e7ce4;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x3e5fb5){this['target']=_0x3e5fb5,this['handlers']=new Set();}['removeMessageHandler'](_0x53b8ed){_0x53b8ed['messageChannel']&&(_0x53b8ed['messageChannel']['port1']['removeEventListener']('message',_0x53b8ed['onMessage']),_0x53b8ed['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x53b8ed);}async['_send'](_0x2b932a,_0x4137de,_0x16ef39=0x32){const _0x3095a2=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x3095a2)throw new Error('connection_unavailable');let _0x4ca6aa,_0x323ce2;return new Promise((_0x13dc1e,_0x188e8b)=>{const _0x1e9542=As('',0x14);_0x3095a2['port1']['start']();const _0x51d5c9=setTimeout(()=>{_0x188e8b(new Error('unsupported_event'));},_0x16ef39);_0x323ce2={'messageChannel':_0x3095a2,'onMessage'(_0x575860){const _0x429a62=_0x575860;if(_0x429a62['data']['eventId']===_0x1e9542)switch(_0x429a62['data']['status']){case'ack':clearTimeout(_0x51d5c9),_0x4ca6aa=setTimeout(()=>{_0x188e8b(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x4ca6aa),_0x13dc1e(_0x429a62['data']['response']);break;default:clearTimeout(_0x51d5c9),clearTimeout(_0x4ca6aa),_0x188e8b(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x323ce2),_0x3095a2['port1']['addEventListener']('message',_0x323ce2['onMessage']),this['target']['postMessage']({'eventType':_0x2b932a,'eventId':_0x1e9542,'data':_0x4137de},[_0x3095a2['port2']]);})['finally'](()=>{_0x323ce2&&this['removeMessageHandler'](_0x323ce2);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x171dcd){Z()['location']['href']=_0x171dcd;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0xfd0665;return((_0xfd0665=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0xfd0665['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x38f5be){this['request']=_0x38f5be;}['toPromise'](){return new Promise((_0x331e9c,_0x403bfe)=>{this['request']['addEventListener']('success',()=>{_0x331e9c(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x403bfe(this['request']['error']);});});}}function Yn(_0x2f3073,_0x5533c9){return _0x2f3073['transaction']([Nn],_0x5533c9?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x29619d=indexedDB['deleteDatabase'](Ka);return new Xt(_0x29619d)['toPromise']();}function Mi(){const _0x17fd57=indexedDB['open'](Ka,up);return new Promise((_0x5d14ba,_0x52865c)=>{_0x17fd57['addEventListener']('error',()=>{_0x52865c(_0x17fd57['error']);}),_0x17fd57['addEventListener']('upgradeneeded',()=>{const _0x3d91aa=_0x17fd57['result'];try{_0x3d91aa['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x84c1be){_0x52865c(_0x84c1be);}}),_0x17fd57['addEventListener']('success',async()=>{const _0x34d5a2=_0x17fd57['result'];_0x34d5a2['objectStoreNames']['contains'](Nn)?_0x5d14ba(_0x34d5a2):(_0x34d5a2['close'](),await dp(),_0x5d14ba(await Mi()));});});}async function Pr(_0x1a0a04,_0x448cb4,_0x190a24){const _0x1f99d9=Yn(_0x1a0a04,!0x0)['put']({[Ya]:_0x448cb4,'value':_0x190a24});return new Xt(_0x1f99d9)['toPromise']();}async function fp(_0x47a929,_0x4fba15){const _0x457781=Yn(_0x47a929,!0x1)['get'](_0x4fba15),_0x29f71a=await new Xt(_0x457781)['toPromise']();return _0x29f71a===void 0x0?null:_0x29f71a['value'];}function Or(_0x4f735d,_0x23f31e){const _0x39fd76=Yn(_0x4f735d,!0x0)['delete'](_0x23f31e);return new Xt(_0x39fd76)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x1ee68e){let _0x4a7035=0x0;for(;;)try{const _0x43e05d=await this['_openDb']();return await _0x1ee68e(_0x43e05d);}catch(_0x2835bb){if(_0x4a7035++>_p)throw _0x2835bb;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x152e0a,_0xbd6588)=>({'keyProcessed':(await this['_poll']())['includes'](_0xbd6588['key'])})),this['receiver']['_subscribe']('ping',async(_0x1b51a6,_0x1d080c)=>['keyChanged']);}async['initializeSender'](){var _0x78e438,_0x106068;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x4504a6=await this['sender']['_send']('ping',{},0x320);_0x4504a6&&(_0x78e438=_0x4504a6[0x0])!=null&&_0x78e438['fulfilled']&&(_0x106068=_0x4504a6[0x0])!=null&&_0x106068['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x118a5a){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x118a5a},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x38d12d=await Mi();return await Pr(_0x38d12d,kn,'1'),await Or(_0x38d12d,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x55127d){this['pendingWrites']++;try{await _0x55127d();}finally{this['pendingWrites']--;}}async['_set'](_0x281aa2,_0x5b9afd){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4efdbe=>Pr(_0x4efdbe,_0x281aa2,_0x5b9afd)),this['localCache'][_0x281aa2]=_0x5b9afd,this['notifyServiceWorker'](_0x281aa2)));}async['_get'](_0x4136ce){const _0x507a86=await this['_withRetries'](_0x344c8e=>fp(_0x344c8e,_0x4136ce));return this['localCache'][_0x4136ce]=_0x507a86,_0x507a86;}async['_remove'](_0x5b58d2){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xa8c4f2=>Or(_0xa8c4f2,_0x5b58d2)),delete this['localCache'][_0x5b58d2],this['notifyServiceWorker'](_0x5b58d2)));}async['_poll'](){const _0xac0d73=await this['_withRetries'](_0x11e283=>{const _0x473258=Yn(_0x11e283,!0x1)['getAll']();return new Xt(_0x473258)['toPromise']();});if(!_0xac0d73)return[];if(this['pendingWrites']!==0x0)return[];const _0x403daa=[],_0x95e407=new Set();if(_0xac0d73['length']!==0x0){for(const {fbase_key:_0x4b5ba0,value:_0x386c38}of _0xac0d73)_0x95e407['add'](_0x4b5ba0),JSON['stringify'](this['localCache'][_0x4b5ba0])!==JSON['stringify'](_0x386c38)&&(this['notifyListeners'](_0x4b5ba0,_0x386c38),_0x403daa['push'](_0x4b5ba0));}for(const _0x3c0d57 of Object['keys'](this['localCache']))this['localCache'][_0x3c0d57]&&!_0x95e407['has'](_0x3c0d57)&&(this['notifyListeners'](_0x3c0d57,null),_0x403daa['push'](_0x3c0d57));return _0x403daa;}['notifyListeners'](_0x1804a5,_0x55b55b){this['localCache'][_0x1804a5]=_0x55b55b;const _0x2baeec=this['listeners'][_0x1804a5];if(_0x2baeec){for(const _0x287520 of Array['from'](_0x2baeec))_0x287520(_0x55b55b);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x22c250,_0x50b956){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x22c250]||(this['listeners'][_0x22c250]=new Set(),this['_get'](_0x22c250)),this['listeners'][_0x22c250]['add'](_0x50b956);}['_removeListener'](_0x3f06b8,_0xfb7e4f){this['listeners'][_0x3f06b8]&&(this['listeners'][_0x3f06b8]['delete'](_0xfb7e4f),this['listeners'][_0x3f06b8]['size']===0x0&&delete this['listeners'][_0x3f06b8]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x18176d,_0x3d16e7){return _0x3d16e7?ie(_0x3d16e7):(m(_0x18176d['_popupRedirectResolver'],_0x18176d,'argument-error'),_0x18176d['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x4b4c6e){super('custom','custom'),this['params']=_0x4b4c6e;}['_getIdTokenResponse'](_0x41db9a){return Xe(_0x41db9a,this['_buildIdpRequest']());}['_linkToIdToken'](_0xb87d8a,_0x55703d){return Xe(_0xb87d8a,this['_buildIdpRequest'](_0x55703d));}['_getReauthenticationResolver'](_0x9d6ccd){return Xe(_0x9d6ccd,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x3bbd74){const _0xb237e1={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x3bbd74&&(_0xb237e1['idToken']=_0x3bbd74),_0xb237e1;}}function yp(_0x38455b){return Va(_0x38455b['auth'],new ks(_0x38455b),_0x38455b['bypassAuthState']);}function vp(_0x5ee67d){const {auth:_0x285923,user:_0x50b9a2}=_0x5ee67d;return m(_0x50b9a2,_0x285923,'internal-error'),Xf(_0x50b9a2,new ks(_0x5ee67d),_0x5ee67d['bypassAuthState']);}async function Ep(_0x4a9b50){const {auth:_0x3d9082,user:_0xff4b5e}=_0x4a9b50;return m(_0xff4b5e,_0x3d9082,'internal-error'),Jf(_0xff4b5e,new ks(_0x4a9b50),_0x4a9b50['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x97ecff,_0x2e3c68,_0x15fdac,_0x4161f1,_0x2f474e=!0x1){this['auth']=_0x97ecff,this['resolver']=_0x15fdac,this['user']=_0x4161f1,this['bypassAuthState']=_0x2f474e,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x2e3c68)?_0x2e3c68:[_0x2e3c68];}['execute'](){return new Promise(async(_0x50466f,_0x485169)=>{this['pendingPromise']={'resolve':_0x50466f,'reject':_0x485169};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x495125){this['reject'](_0x495125);}});}async['onAuthEvent'](_0x37892e){const {urlResponse:_0x1eea0e,sessionId:_0x489fea,postBody:_0xecd8b9,tenantId:_0x3e9e8e,error:_0xf0028b,type:_0x584a61}=_0x37892e;if(_0xf0028b){this['reject'](_0xf0028b);return;}const _0x14de9c={'auth':this['auth'],'requestUri':_0x1eea0e,'sessionId':_0x489fea,'tenantId':_0x3e9e8e||void 0x0,'postBody':_0xecd8b9||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x584a61)(_0x14de9c));}catch(_0x120601){this['reject'](_0x120601);}}['onError'](_0x3b9d3c){this['reject'](_0x3b9d3c);}['getIdpTask'](_0x115bc5){switch(_0x115bc5){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x3d93e2){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x3d93e2),this['unregisterAndCleanUp']();}['reject'](_0x13e764){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x13e764),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x34435c,_0x3a2429,_0x3eeb04,_0x44bd34,_0x5483ce){super(_0x34435c,_0x3a2429,_0x44bd34,_0x5483ce),this['provider']=_0x3eeb04,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0xcfbd6c=await this['execute']();return m(_0xcfbd6c,this['auth'],'internal-error'),_0xcfbd6c;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x1880f4=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x1880f4),this['authWindow']['associatedEvent']=_0x1880f4,this['resolver']['_originValidation'](this['auth'])['catch'](_0x3096d3=>{this['reject'](_0x3096d3);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x3f7f2a=>{_0x3f7f2a||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x55af78;return((_0x55af78=this['authWindow'])==null?void 0x0:_0x55af78['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x50fb03=()=>{var _0x4aa7f6,_0x3822ac;if((_0x3822ac=(_0x4aa7f6=this['authWindow'])==null?void 0x0:_0x4aa7f6['window'])!=null&&_0x3822ac['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x50fb03,Ip['get']());};_0x50fb03();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x2cfeb0,_0x1b7c92,_0x48d638=!0x1){super(_0x2cfeb0,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x1b7c92,void 0x0,_0x48d638),this['eventId']=null;}async['execute'](){let _0x177c3b=on['get'](this['auth']['_key']());if(!_0x177c3b){try{const _0x30cec0=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x177c3b=()=>Promise['resolve'](_0x30cec0);}catch(_0x568115){_0x177c3b=()=>Promise['reject'](_0x568115);}on['set'](this['auth']['_key'](),_0x177c3b);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x177c3b();}async['onAuthEvent'](_0x5f4182){if(_0x5f4182['type']==='signInViaRedirect')return super['onAuthEvent'](_0x5f4182);if(_0x5f4182['type']==='unknown'){this['resolve'](null);return;}if(_0x5f4182['eventId']){const _0xcf3eb5=await this['auth']['_redirectUserForId'](_0x5f4182['eventId']);if(_0xcf3eb5)return this['user']=_0xcf3eb5,super['onAuthEvent'](_0x5f4182);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0xa717b2,_0x588f7d){const _0x3ec51a=Rp(_0x588f7d),_0x19c9f6=bp(_0xa717b2);if(!await _0x19c9f6['_isAvailable']())return!0x1;const _0x16e4e8=await _0x19c9f6['_get'](_0x3ec51a)==='true';return await _0x19c9f6['_remove'](_0x3ec51a),_0x16e4e8;}function Sp(_0x240365,_0xd4732f){on['set'](_0x240365['_key'](),_0xd4732f);}function bp(_0x313b2e){return ie(_0x313b2e['_redirectPersistence']);}function Rp(_0x3ba929){return rn(wp,_0x3ba929['config']['apiKey'],_0x3ba929['name']);}async function Ap(_0x18a427,_0x474b5e,_0x5bbf51=!0x1){if($(_0x18a427['app']))return Promise['reject'](re(_0x18a427));const _0x5ea1ae=qe(_0x18a427),_0x191bcc=mp(_0x5ea1ae,_0x474b5e),_0x29361e=await new Cp(_0x5ea1ae,_0x191bcc,_0x5bbf51)['execute']();return _0x29361e&&!_0x5bbf51&&(delete _0x29361e['user']['_redirectEventId'],await _0x5ea1ae['_persistUserIfCurrent'](_0x29361e['user']),await _0x5ea1ae['_setRedirectUser'](null,_0x474b5e)),_0x29361e;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x3d5b48){this['auth']=_0x3d5b48,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x5215b8){this['consumers']['add'](_0x5215b8),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x5215b8)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x5215b8),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x29dfe7){this['consumers']['delete'](_0x29dfe7);}['onEvent'](_0x38912e){if(this['hasEventBeenHandled'](_0x38912e))return!0x1;let _0xa96bc7=!0x1;return this['consumers']['forEach'](_0x2eee99=>{this['isEventForConsumer'](_0x38912e,_0x2eee99)&&(_0xa96bc7=!0x0,this['sendToConsumer'](_0x38912e,_0x2eee99),this['saveEventToCache'](_0x38912e));}),this['hasHandledPotentialRedirect']||!Pp(_0x38912e)||(this['hasHandledPotentialRedirect']=!0x0,_0xa96bc7||(this['queuedRedirectEvent']=_0x38912e,_0xa96bc7=!0x0)),_0xa96bc7;}['sendToConsumer'](_0x418049,_0x3d5b4){var _0x538e16;if(_0x418049['error']&&!Xa(_0x418049)){const _0x544755=((_0x538e16=_0x418049['error']['code'])==null?void 0x0:_0x538e16['split']('auth/')[0x1])||'internal-error';_0x3d5b4['onError'](X(this['auth'],_0x544755));}else _0x3d5b4['onAuthEvent'](_0x418049);}['isEventForConsumer'](_0x1478b6,_0x355a86){const _0x994ab1=_0x355a86['eventId']===null||!!_0x1478b6['eventId']&&_0x1478b6['eventId']===_0x355a86['eventId'];return _0x355a86['filter']['includes'](_0x1478b6['type'])&&_0x994ab1;}['hasEventBeenHandled'](_0x2d1b3e){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x2d1b3e));}['saveEventToCache'](_0x31e39e){this['cachedEventUids']['add'](Dr(_0x31e39e)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x5d1e54){return[_0x5d1e54['type'],_0x5d1e54['eventId'],_0x5d1e54['sessionId'],_0x5d1e54['tenantId']]['filter'](_0x467989=>_0x467989)['join']('-');}function Xa({type:_0x120858,error:_0x2caf88}){return _0x120858==='unknown'&&(_0x2caf88==null?void 0x0:_0x2caf88['code'])==='auth/no-auth-event';}function Pp(_0xbeaf90){switch(_0xbeaf90['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0xbeaf90);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x3a9635,_0x4fbc07={}){return Ae(_0x3a9635,'GET','/v1/projects',_0x4fbc07);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x15195e){if(_0x15195e['config']['emulator'])return;const {authorizedDomains:_0x16fa67}=await Op(_0x15195e);for(const _0x3f591e of _0x16fa67)try{if(xp(_0x3f591e))return;}catch{}Q(_0x15195e,'unauthorized-domain');}function xp(_0x153f22){const _0x27db3a=Pi(),{protocol:_0x49b61b,hostname:_0x346446}=new URL(_0x27db3a);if(_0x153f22['startsWith']('chrome-extension://')){const _0x323f93=new URL(_0x153f22);return _0x323f93['hostname']===''&&_0x346446===''?_0x49b61b==='chrome-extension:'&&_0x153f22['replace']('chrome-extension://','')===_0x27db3a['replace']('chrome-extension://',''):_0x49b61b==='chrome-extension:'&&_0x323f93['hostname']===_0x346446;}if(!Mp['test'](_0x49b61b))return!0x1;if(Dp['test'](_0x153f22))return _0x346446===_0x153f22;const _0x4aa05c=_0x153f22['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x4aa05c+'|'+_0x4aa05c+')$','i')['test'](_0x346446);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x685246=Z()['___jsl'];if(_0x685246!=null&&_0x685246['H']){for(const _0x25e73a of Object['keys'](_0x685246['H']))if(_0x685246['H'][_0x25e73a]['r']=_0x685246['H'][_0x25e73a]['r']||[],_0x685246['H'][_0x25e73a]['L']=_0x685246['H'][_0x25e73a]['L']||[],_0x685246['H'][_0x25e73a]['r']=[..._0x685246['H'][_0x25e73a]['L']],_0x685246['CP']){for(let _0x3e5752=0x0;_0x3e5752<_0x685246['CP']['length'];_0x3e5752++)_0x685246['CP'][_0x3e5752]=null;}}}function Up(_0x1ebe08){return new Promise((_0x15e2a9,_0x3c9013)=>{var _0x487df3,_0x317af6,_0x1e7129;function _0x321761(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x15e2a9(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x3c9013(X(_0x1ebe08,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x317af6=(_0x487df3=Z()['gapi'])==null?void 0x0:_0x487df3['iframes'])!=null&&_0x317af6['Iframe'])_0x15e2a9(gapi['iframes']['getContext']());else{if((_0x1e7129=Z()['gapi'])!=null&&_0x1e7129['load'])_0x321761();else{const _0x1181ae=Df('iframefcb');return Z()[_0x1181ae]=()=>{gapi['load']?_0x321761():_0x3c9013(X(_0x1ebe08,'network-request-failed'));},xa(Of()+'?onload='+_0x1181ae)['catch'](_0x4c102e=>_0x3c9013(_0x4c102e));}}})['catch'](_0x1a7dfb=>{throw an=null,_0x1a7dfb;});}let an=null;function Wp(_0x1d7246){return an=an||Up(_0x1d7246),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x4607eb){const _0x4a7144=_0x4607eb['config'];m(_0x4a7144['authDomain'],_0x4607eb,'auth-domain-config-required');const _0x95892f=_0x4a7144['emulator']?Cs(_0x4a7144,Hp):'https://'+_0x4607eb['config']['authDomain']+'/'+Vp,_0x45b7ff={'apiKey':_0x4a7144['apiKey'],'appName':_0x4607eb['name'],'v':lt},_0x1cf6e2=Gp['get'](_0x4607eb['config']['apiHost']);_0x1cf6e2&&(_0x45b7ff['eid']=_0x1cf6e2);const _0x503f67=_0x4607eb['_getFrameworks']();return _0x503f67['length']&&(_0x45b7ff['fw']=_0x503f67['join'](',')),_0x95892f+'?'+ct(_0x45b7ff)['slice'](0x1);}async function zp(_0x173dc1){const _0x5a061c=await Wp(_0x173dc1),_0x33ae21=Z()['gapi'];return m(_0x33ae21,_0x173dc1,'internal-error'),_0x5a061c['open']({'where':document['body'],'url':qp(_0x173dc1),'messageHandlersFilter':_0x33ae21['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x2f8c9b=>new Promise(async(_0x343339,_0x330567)=>{await _0x2f8c9b['restyle']({'setHideOnLeave':!0x1});const _0x470dd6=X(_0x173dc1,'network-request-failed'),_0x26c6ff=Z()['setTimeout'](()=>{_0x330567(_0x470dd6);},Bp['get']());function _0x5bc028(){Z()['clearTimeout'](_0x26c6ff),_0x343339(_0x2f8c9b);}_0x2f8c9b['ping'](_0x5bc028)['then'](_0x5bc028,()=>{_0x330567(_0x470dd6);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x3d911c){this['window']=_0x3d911c,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x1c2408,_0x225734,_0x13091b,_0x2058d6=Kp,_0x4b6f46=Yp){const _0x54c6ed=Math['max']((window['screen']['availHeight']-_0x4b6f46)/0x2,0x0)['toString'](),_0x430608=Math['max']((window['screen']['availWidth']-_0x2058d6)/0x2,0x0)['toString']();let _0x29a9d8='';const _0x27ff8f={...jp,'width':_0x2058d6['toString'](),'height':_0x4b6f46['toString'](),'top':_0x54c6ed,'left':_0x430608},_0x200f50=W()['toLowerCase']();_0x13091b&&(_0x29a9d8=ka(_0x200f50)?Qp:_0x13091b),Ra(_0x200f50)&&(_0x225734=_0x225734||Jp,_0x27ff8f['scrollbars']='yes');const _0x46d42a=Object['entries'](_0x27ff8f)['reduce']((_0x8efcf7,[_0x47b96a,_0x35d4bb])=>''+_0x8efcf7+_0x47b96a+'='+_0x35d4bb+',','');if(Cf(_0x200f50)&&_0x29a9d8!=='_self')return Zp(_0x225734||'',_0x29a9d8),new Lr(null);const _0x50083e=window['open'](_0x225734||'',_0x29a9d8,_0x46d42a);m(_0x50083e,_0x1c2408,'popup-blocked');try{_0x50083e['focus']();}catch{}return new Lr(_0x50083e);}function Zp(_0xcd5907,_0x452d50){const _0x23db3f=document['createElement']('a');_0x23db3f['href']=_0xcd5907,_0x23db3f['target']=_0x452d50;const _0x36f7c5=document['createEvent']('MouseEvent');_0x36f7c5['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x23db3f['dispatchEvent'](_0x36f7c5);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0xcf4806,_0x8b8951,_0x29251b,_0xaf2a5a,_0x4707f9,_0x27afe6){m(_0xcf4806['config']['authDomain'],_0xcf4806,'auth-domain-config-required'),m(_0xcf4806['config']['apiKey'],_0xcf4806,'invalid-api-key');const _0x25e08b={'apiKey':_0xcf4806['config']['apiKey'],'appName':_0xcf4806['name'],'authType':_0x29251b,'redirectUrl':_0xaf2a5a,'v':lt,'eventId':_0x4707f9};if(_0x8b8951 instanceof Wa){_0x8b8951['setDefaultLanguage'](_0xcf4806['languageCode']),_0x25e08b['providerId']=_0x8b8951['providerId']||'',ui(_0x8b8951['getCustomParameters']())||(_0x25e08b['customParameters']=JSON['stringify'](_0x8b8951['getCustomParameters']()));for(const [_0x1a3900,_0x3238b1]of Object['entries']({}))_0x25e08b[_0x1a3900]=_0x3238b1;}if(_0x8b8951 instanceof Jt){const _0x7d1e75=_0x8b8951['getScopes']()['filter'](_0x1bc1d6=>_0x1bc1d6!=='');_0x7d1e75['length']>0x0&&(_0x25e08b['scopes']=_0x7d1e75['join'](','));}_0xcf4806['tenantId']&&(_0x25e08b['tid']=_0xcf4806['tenantId']);const _0x41351a=_0x25e08b;for(const _0x58487b of Object['keys'](_0x41351a))_0x41351a[_0x58487b]===void 0x0&&delete _0x41351a[_0x58487b];const _0x350385=await _0xcf4806['_getAppCheckToken'](),_0x4efa37=_0x350385?'#'+n_+'='+encodeURIComponent(_0x350385):'';return i_(_0xcf4806)+'?'+ct(_0x41351a)['slice'](0x1)+_0x4efa37;}function i_({config:_0x1b844c}){return _0x1b844c['emulator']?Cs(_0x1b844c,t_):'https://'+_0x1b844c['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x48cb28,_0x1d9b54,_0x6e5c4c,_0x102a54){var _0x2810f8;ce((_0x2810f8=this['eventManagers'][_0x48cb28['_key']()])==null?void 0x0:_0x2810f8['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x2771c8=await xr(_0x48cb28,_0x1d9b54,_0x6e5c4c,Pi(),_0x102a54);return Xp(_0x48cb28,_0x2771c8,As());}async['_openRedirect'](_0x501ff4,_0x4c6520,_0x8b4bab,_0x2f0cd7){await this['_originValidation'](_0x501ff4);const _0x1e0e10=await xr(_0x501ff4,_0x4c6520,_0x8b4bab,Pi(),_0x2f0cd7);return ap(_0x1e0e10),new Promise(()=>{});}['_initialize'](_0x17809c){const _0x215f18=_0x17809c['_key']();if(this['eventManagers'][_0x215f18]){const {manager:_0xe16126,promise:_0x5a43a9}=this['eventManagers'][_0x215f18];return _0xe16126?Promise['resolve'](_0xe16126):(ce(_0x5a43a9,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x5a43a9);}const _0x47c17f=this['initAndGetManager'](_0x17809c);return this['eventManagers'][_0x215f18]={'promise':_0x47c17f},_0x47c17f['catch'](()=>{delete this['eventManagers'][_0x215f18];}),_0x47c17f;}async['initAndGetManager'](_0x3fd1a1){const _0x31f52e=await zp(_0x3fd1a1),_0x3e63d1=new Np(_0x3fd1a1);return _0x31f52e['register']('authEvent',_0x3da56d=>(m(_0x3da56d==null?void 0x0:_0x3da56d['authEvent'],_0x3fd1a1,'invalid-auth-event'),{'status':_0x3e63d1['onEvent'](_0x3da56d['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x3fd1a1['_key']()]={'manager':_0x3e63d1},this['iframes'][_0x3fd1a1['_key']()]=_0x31f52e,_0x3e63d1;}['_isIframeWebStorageSupported'](_0xd2a9ef,_0x5c88ee){this['iframes'][_0xd2a9ef['_key']()]['send'](hi,{'type':hi},_0x2cd124=>{var _0x1c5097;const _0x38ddab=(_0x1c5097=_0x2cd124==null?void 0x0:_0x2cd124[0x0])==null?void 0x0:_0x1c5097[hi];_0x38ddab!==void 0x0&&_0x5c88ee(!!_0x38ddab),Q(_0xd2a9ef,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x294a10){const _0x522435=_0x294a10['_key']();return this['originValidationPromises'][_0x522435]||(this['originValidationPromises'][_0x522435]=Lp(_0x294a10)),this['originValidationPromises'][_0x522435];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x55940c){this['auth']=_0x55940c,this['internalListeners']=new Map();}['getUid'](){var _0x1a99f2;return this['assertAuthConfigured'](),((_0x1a99f2=this['auth']['currentUser'])==null?void 0x0:_0x1a99f2['uid'])||null;}async['getToken'](_0x38bc58){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x38bc58)}:null;}['addAuthTokenListener'](_0x1ea482){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x1ea482))return;const _0x3ed129=this['auth']['onIdTokenChanged'](_0x1a3365=>{_0x1ea482((_0x1a3365==null?void 0x0:_0x1a3365['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x1ea482,_0x3ed129),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x287172){this['assertAuthConfigured']();const _0x264c7d=this['internalListeners']['get'](_0x287172);_0x264c7d&&(this['internalListeners']['delete'](_0x287172),_0x264c7d(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x24fde6){switch(_0x24fde6){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x3c2dc6){Ze(new Le('auth',(_0x24c353,{options:_0x4a6c0d})=>{const _0x250139=_0x24c353['getProvider']('app')['getImmediate'](),_0x1d83ee=_0x24c353['getProvider']('heartbeat'),_0x109eec=_0x24c353['getProvider']('app-check-internal'),{apiKey:_0x2ba0d5,authDomain:_0x537e6d}=_0x250139['options'];m(_0x2ba0d5&&!_0x2ba0d5['includes'](':'),'invalid-api-key',{'appName':_0x250139['name']});const _0x3e5db6={'apiKey':_0x2ba0d5,'authDomain':_0x537e6d,'clientPlatform':_0x3c2dc6,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x3c2dc6)},_0x13a31c=new kf(_0x250139,_0x1d83ee,_0x109eec,_0x3e5db6);return Wf(_0x13a31c,_0x4a6c0d),_0x13a31c;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x365146,_0x112370,_0x176296)=>{_0x365146['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x74c0de=>{const _0x4ab342=qe(_0x74c0de['getProvider']('auth')['getImmediate']());return(_0x102fea=>new o_(_0x102fea))(_0x4ab342);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x3c2dc6)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x208e40=>async _0x2f11ef=>{const _0x3ea571=_0x2f11ef&&await _0x2f11ef['getIdTokenResult'](),_0x4e78fc=_0x3ea571&&(new Date()['getTime']()-Date['parse'](_0x3ea571['issuedAtTime']))/0x3e8;if(_0x4e78fc&&_0x4e78fc>h_)return;const _0x318f75=_0x3ea571==null?void 0x0:_0x3ea571['token'];Wr!==_0x318f75&&(Wr=_0x318f75,await fetch(_0x208e40,{'method':_0x318f75?'POST':'DELETE','headers':_0x318f75?{'Authorization':'Bearer\x20'+_0x318f75}:{}}));};function x_(_0x4300e8=Zr()){const _0x12171f=Bi(_0x4300e8,'auth');if(_0x12171f['isInitialized']())return _0x12171f['getImmediate']();const _0x49a98e=Uf(_0x4300e8,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x17a399=zr('authTokenSyncURL');if(_0x17a399&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x16316b=new URL(_0x17a399,location['origin']);if(location['origin']===_0x16316b['origin']){const _0x4f4d8a=u_(_0x16316b['toString']());tp(_0x49a98e,_0x4f4d8a,()=>_0x4f4d8a(_0x49a98e['currentUser'])),ep(_0x49a98e,_0x1302e8=>_0x4f4d8a(_0x1302e8));}}const _0x4d742f=Gr('auth');return _0x4d742f&&Bf(_0x49a98e,'http://'+_0x4d742f),_0x49a98e;}function d_(){var _0x5e76c7;return((_0x5e76c7=document['getElementsByTagName']('head'))==null?void 0x0:_0x5e76c7[0x0])??document;}Nf({'loadJS'(_0x30d833){return new Promise((_0x2484d0,_0x21609e)=>{const _0x7717f8=document['createElement']('script');_0x7717f8['setAttribute']('src',_0x30d833),_0x7717f8['onload']=_0x2484d0,_0x7717f8['onerror']=_0x2ccb52=>{const _0x1845dc=X('internal-error');_0x1845dc['customData']=_0x2ccb52,_0x21609e(_0x1845dc);},_0x7717f8['type']='text/javascript',_0x7717f8['charset']='UTF-8',d_()['appendChild'](_0x7717f8);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};