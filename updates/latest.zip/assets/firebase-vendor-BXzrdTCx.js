const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x2f41b0,_0xac2d81){if(!_0x2f41b0)throw rt(_0xac2d81);},rt=function(_0x570540){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x570540);},Vr=function(_0x3a69b2){const _0x5b2a41=[];let _0x6229c8=0x0;for(let _0x3afe24=0x0;_0x3afe24<_0x3a69b2['length'];_0x3afe24++){let _0xab3e13=_0x3a69b2['charCodeAt'](_0x3afe24);_0xab3e13<0x80?_0x5b2a41[_0x6229c8++]=_0xab3e13:_0xab3e13<0x800?(_0x5b2a41[_0x6229c8++]=_0xab3e13>>0x6|0xc0,_0x5b2a41[_0x6229c8++]=_0xab3e13&0x3f|0x80):(_0xab3e13&0xfc00)===0xd800&&_0x3afe24+0x1<_0x3a69b2['length']&&(_0x3a69b2['charCodeAt'](_0x3afe24+0x1)&0xfc00)===0xdc00?(_0xab3e13=0x10000+((_0xab3e13&0x3ff)<<0xa)+(_0x3a69b2['charCodeAt'](++_0x3afe24)&0x3ff),_0x5b2a41[_0x6229c8++]=_0xab3e13>>0x12|0xf0,_0x5b2a41[_0x6229c8++]=_0xab3e13>>0xc&0x3f|0x80,_0x5b2a41[_0x6229c8++]=_0xab3e13>>0x6&0x3f|0x80,_0x5b2a41[_0x6229c8++]=_0xab3e13&0x3f|0x80):(_0x5b2a41[_0x6229c8++]=_0xab3e13>>0xc|0xe0,_0x5b2a41[_0x6229c8++]=_0xab3e13>>0x6&0x3f|0x80,_0x5b2a41[_0x6229c8++]=_0xab3e13&0x3f|0x80);}return _0x5b2a41;},ec=function(_0x20c0de){const _0x1d2370=[];let _0xe3c950=0x0,_0x5dce9e=0x0;for(;_0xe3c950<_0x20c0de['length'];){const _0xbbd4d0=_0x20c0de[_0xe3c950++];if(_0xbbd4d0<0x80)_0x1d2370[_0x5dce9e++]=String['fromCharCode'](_0xbbd4d0);else{if(_0xbbd4d0>0xbf&&_0xbbd4d0<0xe0){const _0xac3ed0=_0x20c0de[_0xe3c950++];_0x1d2370[_0x5dce9e++]=String['fromCharCode']((_0xbbd4d0&0x1f)<<0x6|_0xac3ed0&0x3f);}else{if(_0xbbd4d0>0xef&&_0xbbd4d0<0x16d){const _0x7334b8=_0x20c0de[_0xe3c950++],_0x43545d=_0x20c0de[_0xe3c950++],_0x6e7ca8=_0x20c0de[_0xe3c950++],_0x509da7=((_0xbbd4d0&0x7)<<0x12|(_0x7334b8&0x3f)<<0xc|(_0x43545d&0x3f)<<0x6|_0x6e7ca8&0x3f)-0x10000;_0x1d2370[_0x5dce9e++]=String['fromCharCode'](0xd800+(_0x509da7>>0xa)),_0x1d2370[_0x5dce9e++]=String['fromCharCode'](0xdc00+(_0x509da7&0x3ff));}else{const _0x5b12d0=_0x20c0de[_0xe3c950++],_0x205854=_0x20c0de[_0xe3c950++];_0x1d2370[_0x5dce9e++]=String['fromCharCode']((_0xbbd4d0&0xf)<<0xc|(_0x5b12d0&0x3f)<<0x6|_0x205854&0x3f);}}}}return _0x1d2370['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x3190bb,_0xd40321){if(!Array['isArray'](_0x3190bb))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x3f2d0b=_0xd40321?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x19b1ee=[];for(let _0x5a2687=0x0;_0x5a2687<_0x3190bb['length'];_0x5a2687+=0x3){const _0x4195ce=_0x3190bb[_0x5a2687],_0x2d9614=_0x5a2687+0x1<_0x3190bb['length'],_0x6b711c=_0x2d9614?_0x3190bb[_0x5a2687+0x1]:0x0,_0x2ec59d=_0x5a2687+0x2<_0x3190bb['length'],_0x4b8e8b=_0x2ec59d?_0x3190bb[_0x5a2687+0x2]:0x0,_0x3d5c6b=_0x4195ce>>0x2,_0x6ea2a2=(_0x4195ce&0x3)<<0x4|_0x6b711c>>0x4;let _0x57bf34=(_0x6b711c&0xf)<<0x2|_0x4b8e8b>>0x6,_0x4ee7eb=_0x4b8e8b&0x3f;_0x2ec59d||(_0x4ee7eb=0x40,_0x2d9614||(_0x57bf34=0x40)),_0x19b1ee['push'](_0x3f2d0b[_0x3d5c6b],_0x3f2d0b[_0x6ea2a2],_0x3f2d0b[_0x57bf34],_0x3f2d0b[_0x4ee7eb]);}return _0x19b1ee['join']('');},'encodeString'(_0x155727,_0x2797cb){return this['HAS_NATIVE_SUPPORT']&&!_0x2797cb?btoa(_0x155727):this['encodeByteArray'](Vr(_0x155727),_0x2797cb);},'decodeString'(_0x3942f7,_0x26c4b0){return this['HAS_NATIVE_SUPPORT']&&!_0x26c4b0?atob(_0x3942f7):ec(this['decodeStringToByteArray'](_0x3942f7,_0x26c4b0));},'decodeStringToByteArray'(_0x37b9e9,_0x148c60){this['init_']();const _0x128958=_0x148c60?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x3ab78f=[];for(let _0x4d35a3=0x0;_0x4d35a3<_0x37b9e9['length'];){const _0x56e1e7=_0x128958[_0x37b9e9['charAt'](_0x4d35a3++)],_0x3a9ae8=_0x4d35a3<_0x37b9e9['length']?_0x128958[_0x37b9e9['charAt'](_0x4d35a3)]:0x0;++_0x4d35a3;const _0x1bab00=_0x4d35a3<_0x37b9e9['length']?_0x128958[_0x37b9e9['charAt'](_0x4d35a3)]:0x40;++_0x4d35a3;const _0x310ddc=_0x4d35a3<_0x37b9e9['length']?_0x128958[_0x37b9e9['charAt'](_0x4d35a3)]:0x40;if(++_0x4d35a3,_0x56e1e7==null||_0x3a9ae8==null||_0x1bab00==null||_0x310ddc==null)throw new tc();const _0xda4471=_0x56e1e7<<0x2|_0x3a9ae8>>0x4;if(_0x3ab78f['push'](_0xda4471),_0x1bab00!==0x40){const _0x25d5b9=_0x3a9ae8<<0x4&0xf0|_0x1bab00>>0x2;if(_0x3ab78f['push'](_0x25d5b9),_0x310ddc!==0x40){const _0x40bee2=_0x1bab00<<0x6&0xc0|_0x310ddc;_0x3ab78f['push'](_0x40bee2);}}}return _0x3ab78f;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x3c236e=0x0;_0x3c236e<this['ENCODED_VALS']['length'];_0x3c236e++)this['byteToCharMap_'][_0x3c236e]=this['ENCODED_VALS']['charAt'](_0x3c236e),this['charToByteMap_'][this['byteToCharMap_'][_0x3c236e]]=_0x3c236e,this['byteToCharMapWebSafe_'][_0x3c236e]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3c236e),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x3c236e]]=_0x3c236e,_0x3c236e>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3c236e)]=_0x3c236e,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x3c236e)]=_0x3c236e);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x5cc698){const _0x2665e2=Vr(_0x5cc698);return Li['encodeByteArray'](_0x2665e2,!0x0);},cn=function(_0x4e6f86){return Hr(_0x4e6f86)['replace'](/\./g,'');},ln=function(_0x1224c6){try{return Li['decodeString'](_0x1224c6,!0x0);}catch(_0x5bccbc){console['error']('base64Decode\x20failed:\x20',_0x5bccbc);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x2f3e10){return $r(void 0x0,_0x2f3e10);}function $r(_0x33c284,_0x14302a){if(!(_0x14302a instanceof Object))return _0x14302a;switch(_0x14302a['constructor']){case Date:const _0x4120ef=_0x14302a;return new Date(_0x4120ef['getTime']());case Object:_0x33c284===void 0x0&&(_0x33c284={});break;case Array:_0x33c284=[];break;default:return _0x14302a;}for(const _0x4b3d25 in _0x14302a)!_0x14302a['hasOwnProperty'](_0x4b3d25)||!ic(_0x4b3d25)||(_0x33c284[_0x4b3d25]=$r(_0x33c284[_0x4b3d25],_0x14302a[_0x4b3d25]));return _0x33c284;}function ic(_0x1356f2){return _0x1356f2!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x55f9b9=Ns['__FIREBASE_DEFAULTS__'];if(_0x55f9b9)return JSON['parse'](_0x55f9b9);},ac=()=>{if(typeof document>'u')return;let _0x14204e;try{_0x14204e=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x4fe3df=_0x14204e&&ln(_0x14204e[0x1]);return _0x4fe3df&&JSON['parse'](_0x4fe3df);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0xbaf49f){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0xbaf49f);return;}},Gr=_0x27c7e9=>{var _0x3f5228,_0x40cff8;return(_0x40cff8=(_0x3f5228=xi())==null?void 0x0:_0x3f5228['emulatorHosts'])==null?void 0x0:_0x40cff8[_0x27c7e9];},cc=_0x47853e=>{const _0x508866=Gr(_0x47853e);if(!_0x508866)return;const _0x5934f3=_0x508866['lastIndexOf'](':');if(_0x5934f3<=0x0||_0x5934f3+0x1===_0x508866['length'])throw new Error('Invalid\x20host\x20'+_0x508866+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x579a0e=parseInt(_0x508866['substring'](_0x5934f3+0x1),0xa);return _0x508866[0x0]==='['?[_0x508866['substring'](0x1,_0x5934f3-0x1),_0x579a0e]:[_0x508866['substring'](0x0,_0x5934f3),_0x579a0e];},qr=()=>{var _0x114cfc;return(_0x114cfc=xi())==null?void 0x0:_0x114cfc['config'];},zr=_0x250d8e=>{var _0x582ad5;return(_0x582ad5=xi())==null?void 0x0:_0x582ad5['_'+_0x250d8e];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x25f444,_0x474e93)=>{this['resolve']=_0x25f444,this['reject']=_0x474e93;});}['wrapCallback'](_0x115dc2){return(_0x400d15,_0x58b8d4)=>{_0x400d15?this['reject'](_0x400d15):this['resolve'](_0x58b8d4),typeof _0x115dc2=='function'&&(this['promise']['catch'](()=>{}),_0x115dc2['length']===0x1?_0x115dc2(_0x400d15):_0x115dc2(_0x400d15,_0x58b8d4));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x3efc85){try{return(_0x3efc85['startsWith']('http://')||_0x3efc85['startsWith']('https://')?new URL(_0x3efc85)['hostname']:_0x3efc85)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x1ed293){return(await fetch(_0x1ed293,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x2566ca,_0x4a905a){if(_0x2566ca['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x13b806={'alg':'none','type':'JWT'},_0x3a041d=_0x4a905a||'demo-project',_0x48a555=_0x2566ca['iat']||0x0,_0x19c937=_0x2566ca['sub']||_0x2566ca['user_id'];if(!_0x19c937)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x3d5ddc={'iss':'https://securetoken.google.com/'+_0x3a041d,'aud':_0x3a041d,'iat':_0x48a555,'exp':_0x48a555+0xe10,'auth_time':_0x48a555,'sub':_0x19c937,'user_id':_0x19c937,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x2566ca};return[cn(JSON['stringify'](_0x13b806)),cn(JSON['stringify'](_0x3d5ddc)),'']['join']('.');}const It={};function hc(){const _0x695a36={'prod':[],'emulator':[]};for(const _0x2b539b of Object['keys'](It))It[_0x2b539b]?_0x695a36['emulator']['push'](_0x2b539b):_0x695a36['prod']['push'](_0x2b539b);return _0x695a36;}function uc(_0x4cc78c){let _0xe82d76=document['getElementById'](_0x4cc78c),_0x4d2558=!0x1;return _0xe82d76||(_0xe82d76=document['createElement']('div'),_0xe82d76['setAttribute']('id',_0x4cc78c),_0x4d2558=!0x0),{'created':_0x4d2558,'element':_0xe82d76};}let Ps=!0x1;function Kr(_0x287be0,_0x5a42b5){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x287be0]===_0x5a42b5||It[_0x287be0]||Ps)return;It[_0x287be0]=_0x5a42b5;function _0x9620ab(_0x7aee17){return'__firebase__banner__'+_0x7aee17;}const _0x5cf157='__firebase__banner',_0x48c38c=hc()['prod']['length']>0x0;function _0x3a24e8(){const _0x121efc=document['getElementById'](_0x5cf157);_0x121efc&&_0x121efc['remove']();}function _0x297d8f(_0x10a5cc){_0x10a5cc['style']['display']='flex',_0x10a5cc['style']['background']='#7faaf0',_0x10a5cc['style']['position']='fixed',_0x10a5cc['style']['bottom']='5px',_0x10a5cc['style']['left']='5px',_0x10a5cc['style']['padding']='.5em',_0x10a5cc['style']['borderRadius']='5px',_0x10a5cc['style']['alignItems']='center';}function _0x3b5120(_0x188f21,_0x5a2110){_0x188f21['setAttribute']('width','24'),_0x188f21['setAttribute']('id',_0x5a2110),_0x188f21['setAttribute']('height','24'),_0x188f21['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x188f21['setAttribute']('fill','none'),_0x188f21['style']['marginLeft']='-6px';}function _0x42e038(){const _0x9af1aa=document['createElement']('span');return _0x9af1aa['style']['cursor']='pointer',_0x9af1aa['style']['marginLeft']='16px',_0x9af1aa['style']['fontSize']='24px',_0x9af1aa['innerHTML']='\x20&times;',_0x9af1aa['onclick']=()=>{Ps=!0x0,_0x3a24e8();},_0x9af1aa;}function _0x50a2b8(_0x1f8910,_0x12fe91){_0x1f8910['setAttribute']('id',_0x12fe91),_0x1f8910['innerText']='Learn\x20more',_0x1f8910['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x1f8910['setAttribute']('target','__blank'),_0x1f8910['style']['paddingLeft']='5px',_0x1f8910['style']['textDecoration']='underline';}function _0x1a2dfe(){const _0x18a006=uc(_0x5cf157),_0x4f0f5b=_0x9620ab('text'),_0x335b69=document['getElementById'](_0x4f0f5b)||document['createElement']('span'),_0x315169=_0x9620ab('learnmore'),_0x38765b=document['getElementById'](_0x315169)||document['createElement']('a'),_0x5b846e=_0x9620ab('preprendIcon'),_0x5c38f4=document['getElementById'](_0x5b846e)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x18a006['created']){const _0x309f16=_0x18a006['element'];_0x297d8f(_0x309f16),_0x50a2b8(_0x38765b,_0x315169);const _0x3d2c9b=_0x42e038();_0x3b5120(_0x5c38f4,_0x5b846e),_0x309f16['append'](_0x5c38f4,_0x335b69,_0x38765b,_0x3d2c9b),document['body']['appendChild'](_0x309f16);}_0x48c38c?(_0x335b69['innerText']='Preview\x20backend\x20disconnected.',_0x5c38f4['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x5c38f4['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x335b69['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x335b69['setAttribute']('id',_0x4f0f5b);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1a2dfe):_0x1a2dfe();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x14875c=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x14875c=='object'&&_0x14875c['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x48f2ab=W();return _0x48f2ab['indexOf']('MSIE\x20')>=0x0||_0x48f2ab['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x116eb7,_0x395744)=>{try{let _0x3c1f03=!0x0;const _0x2c0125='validate-browser-context-for-indexeddb-analytics-module',_0x518472=self['indexedDB']['open'](_0x2c0125);_0x518472['onsuccess']=()=>{_0x518472['result']['close'](),_0x3c1f03||self['indexedDB']['deleteDatabase'](_0x2c0125),_0x116eb7(!0x0);},_0x518472['onupgradeneeded']=()=>{_0x3c1f03=!0x1;},_0x518472['onerror']=()=>{var _0x1b94ae;_0x395744(((_0x1b94ae=_0x518472['error'])==null?void 0x0:_0x1b94ae['message'])||'');};}catch(_0x4fe6c9){_0x395744(_0x4fe6c9);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x366aa1,_0x1eb4b1,_0x5428fb){super(_0x1eb4b1),this['code']=_0x366aa1,this['customData']=_0x5428fb,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x4dea33,_0x241831,_0x2a08e0){this['service']=_0x4dea33,this['serviceName']=_0x241831,this['errors']=_0x2a08e0;}['create'](_0x5aa15e,..._0x2f9dd1){const _0x4b7e7f=_0x2f9dd1[0x0]||{},_0x1f519b=this['service']+'/'+_0x5aa15e,_0x5e5cd4=this['errors'][_0x5aa15e],_0x417c48=_0x5e5cd4?vc(_0x5e5cd4,_0x4b7e7f):'Error',_0x49ea42=this['serviceName']+':\x20'+_0x417c48+'\x20('+_0x1f519b+').';return new Se(_0x1f519b,_0x49ea42,_0x4b7e7f);}}function vc(_0x37d52f,_0x590914){return _0x37d52f['replace'](Ec,(_0x27dd5e,_0x423409)=>{const _0x1a8527=_0x590914[_0x423409];return _0x1a8527!=null?String(_0x1a8527):'<'+_0x423409+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x17edd0){return JSON['parse'](_0x17edd0);}function O(_0x314372){return JSON['stringify'](_0x314372);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x54dc5b){let _0x1cf601={},_0x5b2ec0={},_0x5e2595={},_0x173b7d='';try{const _0x24fa36=_0x54dc5b['split']('.');_0x1cf601=At(ln(_0x24fa36[0x0])||''),_0x5b2ec0=At(ln(_0x24fa36[0x1])||''),_0x173b7d=_0x24fa36[0x2],_0x5e2595=_0x5b2ec0['d']||{},delete _0x5b2ec0['d'];}catch{}return{'header':_0x1cf601,'claims':_0x5b2ec0,'data':_0x5e2595,'signature':_0x173b7d};},Ic=function(_0x27c804){const _0x42b0d1=Qr(_0x27c804),_0x1873ae=_0x42b0d1['claims'];return!!_0x1873ae&&typeof _0x1873ae=='object'&&_0x1873ae['hasOwnProperty']('iat');},wc=function(_0x5c806b){const _0x5cea00=Qr(_0x5c806b)['claims'];return typeof _0x5cea00=='object'&&_0x5cea00['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x59b3bf,_0x581713){return Object['prototype']['hasOwnProperty']['call'](_0x59b3bf,_0x581713);}function De(_0x3823db,_0x429db6){if(Object['prototype']['hasOwnProperty']['call'](_0x3823db,_0x429db6))return _0x3823db[_0x429db6];}function ui(_0x2fcc86){for(const _0xb15f69 in _0x2fcc86)if(Object['prototype']['hasOwnProperty']['call'](_0x2fcc86,_0xb15f69))return!0x1;return!0x0;}function hn(_0x3cfa6b,_0x4fb088,_0x80331b){const _0x23cd48={};for(const _0x200e5c in _0x3cfa6b)Object['prototype']['hasOwnProperty']['call'](_0x3cfa6b,_0x200e5c)&&(_0x23cd48[_0x200e5c]=_0x4fb088['call'](_0x80331b,_0x3cfa6b[_0x200e5c],_0x200e5c,_0x3cfa6b));return _0x23cd48;}function Me(_0x54ee0d,_0x55f40a){if(_0x54ee0d===_0x55f40a)return!0x0;const _0x372b2f=Object['keys'](_0x54ee0d),_0x480dce=Object['keys'](_0x55f40a);for(const _0xd9870 of _0x372b2f){if(!_0x480dce['includes'](_0xd9870))return!0x1;const _0xc11536=_0x54ee0d[_0xd9870],_0x3b5a3d=_0x55f40a[_0xd9870];if(Os(_0xc11536)&&Os(_0x3b5a3d)){if(!Me(_0xc11536,_0x3b5a3d))return!0x1;}else{if(_0xc11536!==_0x3b5a3d)return!0x1;}}for(const _0x3a9007 of _0x480dce)if(!_0x372b2f['includes'](_0x3a9007))return!0x1;return!0x0;}function Os(_0x2dc1f4){return _0x2dc1f4!==null&&typeof _0x2dc1f4=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x28516f){const _0x36f87f=[];for(const [_0x53f279,_0x2230c3]of Object['entries'](_0x28516f))Array['isArray'](_0x2230c3)?_0x2230c3['forEach'](_0x4f1ddb=>{_0x36f87f['push'](encodeURIComponent(_0x53f279)+'='+encodeURIComponent(_0x4f1ddb));}):_0x36f87f['push'](encodeURIComponent(_0x53f279)+'='+encodeURIComponent(_0x2230c3));return _0x36f87f['length']?'&'+_0x36f87f['join']('&'):'';}function vt(_0x9ba9f){const _0x39b7b1={};return _0x9ba9f['replace'](/^\?/,'')['split']('&')['forEach'](_0x477d40=>{if(_0x477d40){const [_0xa22a18,_0x2c2674]=_0x477d40['split']('=');_0x39b7b1[decodeURIComponent(_0xa22a18)]=decodeURIComponent(_0x2c2674);}}),_0x39b7b1;}function Et(_0x41e4e0){const _0x32f499=_0x41e4e0['indexOf']('?');if(!_0x32f499)return'';const _0x301ebb=_0x41e4e0['indexOf']('#',_0x32f499);return _0x41e4e0['substring'](_0x32f499,_0x301ebb>0x0?_0x301ebb:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x21b7fc=0x1;_0x21b7fc<this['blockSize'];++_0x21b7fc)this['pad_'][_0x21b7fc]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x5774d9,_0x12616f){_0x12616f||(_0x12616f=0x0);const _0xc14d1d=this['W_'];if(typeof _0x5774d9=='string'){for(let _0x2eda6c=0x0;_0x2eda6c<0x10;_0x2eda6c++)_0xc14d1d[_0x2eda6c]=_0x5774d9['charCodeAt'](_0x12616f)<<0x18|_0x5774d9['charCodeAt'](_0x12616f+0x1)<<0x10|_0x5774d9['charCodeAt'](_0x12616f+0x2)<<0x8|_0x5774d9['charCodeAt'](_0x12616f+0x3),_0x12616f+=0x4;}else{for(let _0xa52fc9=0x0;_0xa52fc9<0x10;_0xa52fc9++)_0xc14d1d[_0xa52fc9]=_0x5774d9[_0x12616f]<<0x18|_0x5774d9[_0x12616f+0x1]<<0x10|_0x5774d9[_0x12616f+0x2]<<0x8|_0x5774d9[_0x12616f+0x3],_0x12616f+=0x4;}for(let _0x1a27dc=0x10;_0x1a27dc<0x50;_0x1a27dc++){const _0x46eaf6=_0xc14d1d[_0x1a27dc-0x3]^_0xc14d1d[_0x1a27dc-0x8]^_0xc14d1d[_0x1a27dc-0xe]^_0xc14d1d[_0x1a27dc-0x10];_0xc14d1d[_0x1a27dc]=(_0x46eaf6<<0x1|_0x46eaf6>>>0x1f)&0xffffffff;}let _0x23be49=this['chain_'][0x0],_0x57b1f1=this['chain_'][0x1],_0x264bdf=this['chain_'][0x2],_0x1ea6b3=this['chain_'][0x3],_0x56d647=this['chain_'][0x4],_0x65b3bf,_0x4a4e5d;for(let _0x2ba4fa=0x0;_0x2ba4fa<0x50;_0x2ba4fa++){_0x2ba4fa<0x28?_0x2ba4fa<0x14?(_0x65b3bf=_0x1ea6b3^_0x57b1f1&(_0x264bdf^_0x1ea6b3),_0x4a4e5d=0x5a827999):(_0x65b3bf=_0x57b1f1^_0x264bdf^_0x1ea6b3,_0x4a4e5d=0x6ed9eba1):_0x2ba4fa<0x3c?(_0x65b3bf=_0x57b1f1&_0x264bdf|_0x1ea6b3&(_0x57b1f1|_0x264bdf),_0x4a4e5d=0x8f1bbcdc):(_0x65b3bf=_0x57b1f1^_0x264bdf^_0x1ea6b3,_0x4a4e5d=0xca62c1d6);const _0xa78c17=(_0x23be49<<0x5|_0x23be49>>>0x1b)+_0x65b3bf+_0x56d647+_0x4a4e5d+_0xc14d1d[_0x2ba4fa]&0xffffffff;_0x56d647=_0x1ea6b3,_0x1ea6b3=_0x264bdf,_0x264bdf=(_0x57b1f1<<0x1e|_0x57b1f1>>>0x2)&0xffffffff,_0x57b1f1=_0x23be49,_0x23be49=_0xa78c17;}this['chain_'][0x0]=this['chain_'][0x0]+_0x23be49&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x57b1f1&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x264bdf&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x1ea6b3&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x56d647&0xffffffff;}['update'](_0x2b9128,_0x41d98b){if(_0x2b9128==null)return;_0x41d98b===void 0x0&&(_0x41d98b=_0x2b9128['length']);const _0x4b68a7=_0x41d98b-this['blockSize'];let _0x553764=0x0;const _0x5ecaef=this['buf_'];let _0x5c101e=this['inbuf_'];for(;_0x553764<_0x41d98b;){if(_0x5c101e===0x0){for(;_0x553764<=_0x4b68a7;)this['compress_'](_0x2b9128,_0x553764),_0x553764+=this['blockSize'];}if(typeof _0x2b9128=='string'){for(;_0x553764<_0x41d98b;)if(_0x5ecaef[_0x5c101e]=_0x2b9128['charCodeAt'](_0x553764),++_0x5c101e,++_0x553764,_0x5c101e===this['blockSize']){this['compress_'](_0x5ecaef),_0x5c101e=0x0;break;}}else{for(;_0x553764<_0x41d98b;)if(_0x5ecaef[_0x5c101e]=_0x2b9128[_0x553764],++_0x5c101e,++_0x553764,_0x5c101e===this['blockSize']){this['compress_'](_0x5ecaef),_0x5c101e=0x0;break;}}}this['inbuf_']=_0x5c101e,this['total_']+=_0x41d98b;}['digest'](){const _0x4ec999=[];let _0x37e811=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x1bd242=this['blockSize']-0x1;_0x1bd242>=0x38;_0x1bd242--)this['buf_'][_0x1bd242]=_0x37e811&0xff,_0x37e811/=0x100;this['compress_'](this['buf_']);let _0x5ac887=0x0;for(let _0x483a96=0x0;_0x483a96<0x5;_0x483a96++)for(let _0x31a9fa=0x18;_0x31a9fa>=0x0;_0x31a9fa-=0x8)_0x4ec999[_0x5ac887]=this['chain_'][_0x483a96]>>_0x31a9fa&0xff,++_0x5ac887;return _0x4ec999;}}function Tc(_0x1e809c,_0x3005c9){const _0x2d4044=new Sc(_0x1e809c,_0x3005c9);return _0x2d4044['subscribe']['bind'](_0x2d4044);}class Sc{constructor(_0x564dbe,_0x33d906){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x33d906,this['task']['then'](()=>{_0x564dbe(this);})['catch'](_0x47639e=>{this['error'](_0x47639e);});}['next'](_0x1af76d){this['forEachObserver'](_0x3faa8e=>{_0x3faa8e['next'](_0x1af76d);});}['error'](_0x550d44){this['forEachObserver'](_0x345e08=>{_0x345e08['error'](_0x550d44);}),this['close'](_0x550d44);}['complete'](){this['forEachObserver'](_0x5de4bd=>{_0x5de4bd['complete']();}),this['close']();}['subscribe'](_0x2f16f3,_0x257b6e,_0xcd3b7c){let _0x920ecb;if(_0x2f16f3===void 0x0&&_0x257b6e===void 0x0&&_0xcd3b7c===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x2f16f3,['next','error','complete'])?_0x920ecb=_0x2f16f3:_0x920ecb={'next':_0x2f16f3,'error':_0x257b6e,'complete':_0xcd3b7c},_0x920ecb['next']===void 0x0&&(_0x920ecb['next']=Jn),_0x920ecb['error']===void 0x0&&(_0x920ecb['error']=Jn),_0x920ecb['complete']===void 0x0&&(_0x920ecb['complete']=Jn);const _0x3389af=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x920ecb['error'](this['finalError']):_0x920ecb['complete']();}catch{}}),this['observers']['push'](_0x920ecb),_0x3389af;}['unsubscribeOne'](_0x5a30b0){this['observers']===void 0x0||this['observers'][_0x5a30b0]===void 0x0||(delete this['observers'][_0x5a30b0],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x218abb){if(!this['finalized']){for(let _0x46d01f=0x0;_0x46d01f<this['observers']['length'];_0x46d01f++)this['sendOne'](_0x46d01f,_0x218abb);}}['sendOne'](_0x2bf9e9,_0x6f9341){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x2bf9e9]!==void 0x0)try{_0x6f9341(this['observers'][_0x2bf9e9]);}catch(_0x58d316){typeof console<'u'&&console['error']&&console['error'](_0x58d316);}});}['close'](_0x3d31f0){this['finalized']||(this['finalized']=!0x0,_0x3d31f0!==void 0x0&&(this['finalError']=_0x3d31f0),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x3fef61,_0x5912f6){if(typeof _0x3fef61!='object'||_0x3fef61===null)return!0x1;for(const _0x2377ac of _0x5912f6)if(_0x2377ac in _0x3fef61&&typeof _0x3fef61[_0x2377ac]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x6bceaf,_0x45e23c){return _0x6bceaf+'\x20failed:\x20'+_0x45e23c+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x3a8e85){const _0x3cf171=[];let _0x7c7ce4=0x0;for(let _0x1c0ddb=0x0;_0x1c0ddb<_0x3a8e85['length'];_0x1c0ddb++){let _0xb0a12e=_0x3a8e85['charCodeAt'](_0x1c0ddb);if(_0xb0a12e>=0xd800&&_0xb0a12e<=0xdbff){const _0x1033fd=_0xb0a12e-0xd800;_0x1c0ddb++,f(_0x1c0ddb<_0x3a8e85['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x373ce2=_0x3a8e85['charCodeAt'](_0x1c0ddb)-0xdc00;_0xb0a12e=0x10000+(_0x1033fd<<0xa)+_0x373ce2;}_0xb0a12e<0x80?_0x3cf171[_0x7c7ce4++]=_0xb0a12e:_0xb0a12e<0x800?(_0x3cf171[_0x7c7ce4++]=_0xb0a12e>>0x6|0xc0,_0x3cf171[_0x7c7ce4++]=_0xb0a12e&0x3f|0x80):_0xb0a12e<0x10000?(_0x3cf171[_0x7c7ce4++]=_0xb0a12e>>0xc|0xe0,_0x3cf171[_0x7c7ce4++]=_0xb0a12e>>0x6&0x3f|0x80,_0x3cf171[_0x7c7ce4++]=_0xb0a12e&0x3f|0x80):(_0x3cf171[_0x7c7ce4++]=_0xb0a12e>>0x12|0xf0,_0x3cf171[_0x7c7ce4++]=_0xb0a12e>>0xc&0x3f|0x80,_0x3cf171[_0x7c7ce4++]=_0xb0a12e>>0x6&0x3f|0x80,_0x3cf171[_0x7c7ce4++]=_0xb0a12e&0x3f|0x80);}return _0x3cf171;},On=function(_0x336ff7){let _0x51d2a0=0x0;for(let _0x556d3c=0x0;_0x556d3c<_0x336ff7['length'];_0x556d3c++){const _0x122cd4=_0x336ff7['charCodeAt'](_0x556d3c);_0x122cd4<0x80?_0x51d2a0++:_0x122cd4<0x800?_0x51d2a0+=0x2:_0x122cd4>=0xd800&&_0x122cd4<=0xdbff?(_0x51d2a0+=0x4,_0x556d3c++):_0x51d2a0+=0x3;}return _0x51d2a0;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x403434){return _0x403434&&_0x403434['_delegate']?_0x403434['_delegate']:_0x403434;}class Le{constructor(_0x56077d,_0x253f01,_0x351f6a){this['name']=_0x56077d,this['instanceFactory']=_0x253f01,this['type']=_0x351f6a,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x1c2e8f){return this['instantiationMode']=_0x1c2e8f,this;}['setMultipleInstances'](_0x1bf901){return this['multipleInstances']=_0x1bf901,this;}['setServiceProps'](_0x284a63){return this['serviceProps']=_0x284a63,this;}['setInstanceCreatedCallback'](_0x5035bc){return this['onInstanceCreated']=_0x5035bc,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x32ae7c,_0x6441c1){this['name']=_0x32ae7c,this['container']=_0x6441c1,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x26c961){const _0x279ab0=this['normalizeInstanceIdentifier'](_0x26c961);if(!this['instancesDeferred']['has'](_0x279ab0)){const _0x262c7d=new ot();if(this['instancesDeferred']['set'](_0x279ab0,_0x262c7d),this['isInitialized'](_0x279ab0)||this['shouldAutoInitialize']())try{const _0x215580=this['getOrInitializeService']({'instanceIdentifier':_0x279ab0});_0x215580&&_0x262c7d['resolve'](_0x215580);}catch{}}return this['instancesDeferred']['get'](_0x279ab0)['promise'];}['getImmediate'](_0x261589){const _0x359025=this['normalizeInstanceIdentifier'](_0x261589==null?void 0x0:_0x261589['identifier']),_0x2e2016=(_0x261589==null?void 0x0:_0x261589['optional'])??!0x1;if(this['isInitialized'](_0x359025)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x359025});}catch(_0x389bf5){if(_0x2e2016)return null;throw _0x389bf5;}else{if(_0x2e2016)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x4d27a0){if(_0x4d27a0['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x4d27a0['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x4d27a0,!!this['shouldAutoInitialize']()){if(Nc(_0x4d27a0))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x476e88,_0x3b3ac3]of this['instancesDeferred']['entries']()){const _0x102124=this['normalizeInstanceIdentifier'](_0x476e88);try{const _0x16900e=this['getOrInitializeService']({'instanceIdentifier':_0x102124});_0x3b3ac3['resolve'](_0x16900e);}catch{}}}}['clearInstance'](_0x1a7caf=Ne){this['instancesDeferred']['delete'](_0x1a7caf),this['instancesOptions']['delete'](_0x1a7caf),this['instances']['delete'](_0x1a7caf);}async['delete'](){const _0x4ebd2f=Array['from'](this['instances']['values']());await Promise['all']([..._0x4ebd2f['filter'](_0x1dcd15=>'INTERNAL'in _0x1dcd15)['map'](_0x4f5072=>_0x4f5072['INTERNAL']['delete']()),..._0x4ebd2f['filter'](_0x4b4a24=>'_delete'in _0x4b4a24)['map'](_0xce8b2b=>_0xce8b2b['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x379fbc=Ne){return this['instances']['has'](_0x379fbc);}['getOptions'](_0x469639=Ne){return this['instancesOptions']['get'](_0x469639)||{};}['initialize'](_0x55c39a={}){const {options:_0x3ea70b={}}=_0x55c39a,_0x5b33ff=this['normalizeInstanceIdentifier'](_0x55c39a['instanceIdentifier']);if(this['isInitialized'](_0x5b33ff))throw Error(this['name']+'('+_0x5b33ff+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x318bdd=this['getOrInitializeService']({'instanceIdentifier':_0x5b33ff,'options':_0x3ea70b});for(const [_0x4f73f0,_0x1db103]of this['instancesDeferred']['entries']()){const _0x2a6d43=this['normalizeInstanceIdentifier'](_0x4f73f0);_0x5b33ff===_0x2a6d43&&_0x1db103['resolve'](_0x318bdd);}return _0x318bdd;}['onInit'](_0x407d05,_0x1f72d8){const _0x58181d=this['normalizeInstanceIdentifier'](_0x1f72d8),_0x5d9947=this['onInitCallbacks']['get'](_0x58181d)??new Set();_0x5d9947['add'](_0x407d05),this['onInitCallbacks']['set'](_0x58181d,_0x5d9947);const _0xc6b682=this['instances']['get'](_0x58181d);return _0xc6b682&&_0x407d05(_0xc6b682,_0x58181d),()=>{_0x5d9947['delete'](_0x407d05);};}['invokeOnInitCallbacks'](_0x532752,_0x3a80e4){const _0x7e08=this['onInitCallbacks']['get'](_0x3a80e4);if(_0x7e08){for(const _0x31f19d of _0x7e08)try{_0x31f19d(_0x532752,_0x3a80e4);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x599263,options:_0x5c5e9b={}}){let _0x2b8201=this['instances']['get'](_0x599263);if(!_0x2b8201&&this['component']&&(_0x2b8201=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x599263),'options':_0x5c5e9b}),this['instances']['set'](_0x599263,_0x2b8201),this['instancesOptions']['set'](_0x599263,_0x5c5e9b),this['invokeOnInitCallbacks'](_0x2b8201,_0x599263),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x599263,_0x2b8201);}catch{}return _0x2b8201||null;}['normalizeInstanceIdentifier'](_0x14b6e5=Ne){return this['component']?this['component']['multipleInstances']?_0x14b6e5:Ne:_0x14b6e5;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x45681d){return _0x45681d===Ne?void 0x0:_0x45681d;}function Nc(_0x3a8df7){return _0x3a8df7['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x49f684){this['name']=_0x49f684,this['providers']=new Map();}['addComponent'](_0x6adec){const _0xb33c1b=this['getProvider'](_0x6adec['name']);if(_0xb33c1b['isComponentSet']())throw new Error('Component\x20'+_0x6adec['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0xb33c1b['setComponent'](_0x6adec);}['addOrOverwriteComponent'](_0x4a633e){this['getProvider'](_0x4a633e['name'])['isComponentSet']()&&this['providers']['delete'](_0x4a633e['name']),this['addComponent'](_0x4a633e);}['getProvider'](_0x18b6cf){if(this['providers']['has'](_0x18b6cf))return this['providers']['get'](_0x18b6cf);const _0x8b49c4=new Ac(_0x18b6cf,this);return this['providers']['set'](_0x18b6cf,_0x8b49c4),_0x8b49c4;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x5ba794){_0x5ba794[_0x5ba794['DEBUG']=0x0]='DEBUG',_0x5ba794[_0x5ba794['VERBOSE']=0x1]='VERBOSE',_0x5ba794[_0x5ba794['INFO']=0x2]='INFO',_0x5ba794[_0x5ba794['WARN']=0x3]='WARN',_0x5ba794[_0x5ba794['ERROR']=0x4]='ERROR',_0x5ba794[_0x5ba794['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x680565,_0x451734,..._0x322427)=>{if(_0x451734<_0x680565['logLevel'])return;const _0x454154=new Date()['toISOString'](),_0x3c709d=Mc[_0x451734];if(_0x3c709d)console[_0x3c709d]('['+_0x454154+']\x20\x20'+_0x680565['name']+':',..._0x322427);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x451734+')');};class Ui{constructor(_0x59ddba){this['name']=_0x59ddba,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x526419){if(!(_0x526419 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x526419+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x526419;}['setLogLevel'](_0x21a123){this['_logLevel']=typeof _0x21a123=='string'?Oc[_0x21a123]:_0x21a123;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x5b45a7){if(typeof _0x5b45a7!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x5b45a7;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x5f5112){this['_userLogHandler']=_0x5f5112;}['debug'](..._0x305207){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x305207),this['_logHandler'](this,T['DEBUG'],..._0x305207);}['log'](..._0x17a0ec){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x17a0ec),this['_logHandler'](this,T['VERBOSE'],..._0x17a0ec);}['info'](..._0x3db31f){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x3db31f),this['_logHandler'](this,T['INFO'],..._0x3db31f);}['warn'](..._0x50538a){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x50538a),this['_logHandler'](this,T['WARN'],..._0x50538a);}['error'](..._0x1c306e){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x1c306e),this['_logHandler'](this,T['ERROR'],..._0x1c306e);}}const xc=(_0x1f3233,_0x380c1b)=>_0x380c1b['some'](_0x1d66fb=>_0x1f3233 instanceof _0x1d66fb);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0xb4365f){const _0xfe2801=new Promise((_0x3a5209,_0x2d7c14)=>{const _0x1c1313=()=>{_0xb4365f['removeEventListener']('success',_0x3c12c2),_0xb4365f['removeEventListener']('error',_0x5d0bc8);},_0x3c12c2=()=>{_0x3a5209(_e(_0xb4365f['result'])),_0x1c1313();},_0x5d0bc8=()=>{_0x2d7c14(_0xb4365f['error']),_0x1c1313();};_0xb4365f['addEventListener']('success',_0x3c12c2),_0xb4365f['addEventListener']('error',_0x5d0bc8);});return _0xfe2801['then'](_0x59f430=>{_0x59f430 instanceof IDBCursor&&Jr['set'](_0x59f430,_0xb4365f);})['catch'](()=>{}),Wi['set'](_0xfe2801,_0xb4365f),_0xfe2801;}function Bc(_0x227a42){if(di['has'](_0x227a42))return;const _0x2d0a53=new Promise((_0x53e641,_0x55cd76)=>{const _0x34be27=()=>{_0x227a42['removeEventListener']('complete',_0xb77385),_0x227a42['removeEventListener']('error',_0x2cc5d9),_0x227a42['removeEventListener']('abort',_0x2cc5d9);},_0xb77385=()=>{_0x53e641(),_0x34be27();},_0x2cc5d9=()=>{_0x55cd76(_0x227a42['error']||new DOMException('AbortError','AbortError')),_0x34be27();};_0x227a42['addEventListener']('complete',_0xb77385),_0x227a42['addEventListener']('error',_0x2cc5d9),_0x227a42['addEventListener']('abort',_0x2cc5d9);});di['set'](_0x227a42,_0x2d0a53);}let fi={'get'(_0x118fe4,_0x47609c,_0x4c6988){if(_0x118fe4 instanceof IDBTransaction){if(_0x47609c==='done')return di['get'](_0x118fe4);if(_0x47609c==='objectStoreNames')return _0x118fe4['objectStoreNames']||Xr['get'](_0x118fe4);if(_0x47609c==='store')return _0x4c6988['objectStoreNames'][0x1]?void 0x0:_0x4c6988['objectStore'](_0x4c6988['objectStoreNames'][0x0]);}return _e(_0x118fe4[_0x47609c]);},'set'(_0x21de38,_0x196ed1,_0x53ac97){return _0x21de38[_0x196ed1]=_0x53ac97,!0x0;},'has'(_0x42f15f,_0x2c550d){return _0x42f15f instanceof IDBTransaction&&(_0x2c550d==='done'||_0x2c550d==='store')?!0x0:_0x2c550d in _0x42f15f;}};function Vc(_0x521b7a){fi=_0x521b7a(fi);}function Hc(_0x9f382d){return _0x9f382d===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x240d8b,..._0x3d5de1){const _0x332905=_0x9f382d['call'](Zn(this),_0x240d8b,..._0x3d5de1);return Xr['set'](_0x332905,_0x240d8b['sort']?_0x240d8b['sort']():[_0x240d8b]),_e(_0x332905);}:Uc()['includes'](_0x9f382d)?function(..._0x2a56ae){return _0x9f382d['apply'](Zn(this),_0x2a56ae),_e(Jr['get'](this));}:function(..._0x52a3e5){return _e(_0x9f382d['apply'](Zn(this),_0x52a3e5));};}function $c(_0x330bce){return typeof _0x330bce=='function'?Hc(_0x330bce):(_0x330bce instanceof IDBTransaction&&Bc(_0x330bce),xc(_0x330bce,Fc())?new Proxy(_0x330bce,fi):_0x330bce);}function _e(_0x5cbcd1){if(_0x5cbcd1 instanceof IDBRequest)return Wc(_0x5cbcd1);if(Xn['has'](_0x5cbcd1))return Xn['get'](_0x5cbcd1);const _0xc07458=$c(_0x5cbcd1);return _0xc07458!==_0x5cbcd1&&(Xn['set'](_0x5cbcd1,_0xc07458),Wi['set'](_0xc07458,_0x5cbcd1)),_0xc07458;}const Zn=_0x86a5ca=>Wi['get'](_0x86a5ca);function Gc(_0x3ff83f,_0x2ec1a4,{blocked:_0x17e074,upgrade:_0x5d919c,blocking:_0x29ce9c,terminated:_0x4e05ed}={}){const _0x691968=indexedDB['open'](_0x3ff83f,_0x2ec1a4),_0x41facc=_e(_0x691968);return _0x5d919c&&_0x691968['addEventListener']('upgradeneeded',_0x4f176d=>{_0x5d919c(_e(_0x691968['result']),_0x4f176d['oldVersion'],_0x4f176d['newVersion'],_e(_0x691968['transaction']),_0x4f176d);}),_0x17e074&&_0x691968['addEventListener']('blocked',_0x988fce=>_0x17e074(_0x988fce['oldVersion'],_0x988fce['newVersion'],_0x988fce)),_0x41facc['then'](_0x1c6446=>{_0x4e05ed&&_0x1c6446['addEventListener']('close',()=>_0x4e05ed()),_0x29ce9c&&_0x1c6446['addEventListener']('versionchange',_0xf80c20=>_0x29ce9c(_0xf80c20['oldVersion'],_0xf80c20['newVersion'],_0xf80c20));})['catch'](()=>{}),_0x41facc;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x5e5ee3,_0x1dae35){if(!(_0x5e5ee3 instanceof IDBDatabase&&!(_0x1dae35 in _0x5e5ee3)&&typeof _0x1dae35=='string'))return;if(ei['get'](_0x1dae35))return ei['get'](_0x1dae35);const _0x3b4662=_0x1dae35['replace'](/FromIndex$/,''),_0x11bcb7=_0x1dae35!==_0x3b4662,_0x100e28=zc['includes'](_0x3b4662);if(!(_0x3b4662 in(_0x11bcb7?IDBIndex:IDBObjectStore)['prototype'])||!(_0x100e28||qc['includes'](_0x3b4662)))return;const _0x198d47=async function(_0x3a25ac,..._0x469040){const _0x43e2c9=this['transaction'](_0x3a25ac,_0x100e28?'readwrite':'readonly');let _0x5e835a=_0x43e2c9['store'];return _0x11bcb7&&(_0x5e835a=_0x5e835a['index'](_0x469040['shift']())),(await Promise['all']([_0x5e835a[_0x3b4662](..._0x469040),_0x100e28&&_0x43e2c9['done']]))[0x0];};return ei['set'](_0x1dae35,_0x198d47),_0x198d47;}Vc(_0x1d58e0=>({..._0x1d58e0,'get':(_0x1d7fd7,_0x20bd72,_0x430a36)=>Ls(_0x1d7fd7,_0x20bd72)||_0x1d58e0['get'](_0x1d7fd7,_0x20bd72,_0x430a36),'has':(_0x36007b,_0x24831b)=>!!Ls(_0x36007b,_0x24831b)||_0x1d58e0['has'](_0x36007b,_0x24831b)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x2221b7){this['container']=_0x2221b7;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x4cf0c2=>{if(Kc(_0x4cf0c2)){const _0x334e2d=_0x4cf0c2['getImmediate']();return _0x334e2d['library']+'/'+_0x334e2d['version'];}else return null;})['filter'](_0x2173ed=>_0x2173ed)['join']('\x20');}}function Kc(_0x17628c){const _0x304b29=_0x17628c['getComponent']();return(_0x304b29==null?void 0x0:_0x304b29['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x398560,_0x581594){try{_0x398560['container']['addComponent'](_0x581594);}catch(_0x12f29d){oe['debug']('Component\x20'+_0x581594['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x398560['name'],_0x12f29d);}}function Ze(_0x2ba00d){const _0x5f5a61=_0x2ba00d['name'];if(mi['has'](_0x5f5a61))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x5f5a61+'.'),!0x1;mi['set'](_0x5f5a61,_0x2ba00d);for(const _0x2c7703 of xe['values']())Fs(_0x2c7703,_0x2ba00d);for(const _0x18bc3d of gi['values']())Fs(_0x18bc3d,_0x2ba00d);return!0x0;}function Bi(_0x13a0d0,_0x1fb5f9){const _0x38537d=_0x13a0d0['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x38537d&&_0x38537d['triggerHeartbeat'](),_0x13a0d0['container']['getProvider'](_0x1fb5f9);}function $(_0x2f6ce6){return _0x2f6ce6==null?!0x1:_0x2f6ce6['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x5b4060,_0x2abb1a,_0x181297){this['_isDeleted']=!0x1,this['_options']={..._0x5b4060},this['_config']={..._0x2abb1a},this['_name']=_0x2abb1a['name'],this['_automaticDataCollectionEnabled']=_0x2abb1a['automaticDataCollectionEnabled'],this['_container']=_0x181297,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0xb73cf2){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0xb73cf2;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x234120){this['_isDeleted']=_0x234120;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x4ab7d2,_0x399199={}){let _0x4986bd=_0x4ab7d2;typeof _0x399199!='object'&&(_0x399199={'name':_0x399199});const _0xee3661={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x399199},_0x2943e9=_0xee3661['name'];if(typeof _0x2943e9!='string'||!_0x2943e9)throw ge['create']('bad-app-name',{'appName':String(_0x2943e9)});if(_0x4986bd||(_0x4986bd=qr()),!_0x4986bd)throw ge['create']('no-options');const _0x3c3535=xe['get'](_0x2943e9);if(_0x3c3535){if(Me(_0x4986bd,_0x3c3535['options'])&&Me(_0xee3661,_0x3c3535['config']))return _0x3c3535;throw ge['create']('duplicate-app',{'appName':_0x2943e9});}const _0x227bc8=new Pc(_0x2943e9);for(const _0x3e5b42 of mi['values']())_0x227bc8['addComponent'](_0x3e5b42);const _0x4789e9=new Tl(_0x4986bd,_0xee3661,_0x227bc8);return xe['set'](_0x2943e9,_0x4789e9),_0x4789e9;}function Zr(_0x5b2077=_i){const _0x191ddc=xe['get'](_0x5b2077);if(!_0x191ddc&&_0x5b2077===_i&&qr())return Sl();if(!_0x191ddc)throw ge['create']('no-app',{'appName':_0x5b2077});return _0x191ddc;}function f_(){return Array['from'](xe['values']());}async function p_(_0xf09c98){let _0x512ac4=!0x1;const _0x49ef7f=_0xf09c98['name'];xe['has'](_0x49ef7f)?(_0x512ac4=!0x0,xe['delete'](_0x49ef7f)):gi['has'](_0x49ef7f)&&_0xf09c98['decRefCount']()<=0x0&&(gi['delete'](_0x49ef7f),_0x512ac4=!0x0),_0x512ac4&&(await Promise['all'](_0xf09c98['container']['getProviders']()['map'](_0x53aa04=>_0x53aa04['delete']())),_0xf09c98['isDeleted']=!0x0);}function me(_0x143a0f,_0x5a0732,_0xfb059f){let _0x2d819a=wl[_0x143a0f]??_0x143a0f;_0xfb059f&&(_0x2d819a+='-'+_0xfb059f);const _0xded0d1=_0x2d819a['match'](/\s|\//),_0x24ed9c=_0x5a0732['match'](/\s|\//);if(_0xded0d1||_0x24ed9c){const _0x3da8b2=['Unable\x20to\x20register\x20library\x20\x22'+_0x2d819a+'\x22\x20with\x20version\x20\x22'+_0x5a0732+'\x22:'];_0xded0d1&&_0x3da8b2['push']('library\x20name\x20\x22'+_0x2d819a+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0xded0d1&&_0x24ed9c&&_0x3da8b2['push']('and'),_0x24ed9c&&_0x3da8b2['push']('version\x20name\x20\x22'+_0x5a0732+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x3da8b2['join']('\x20'));return;}Ze(new Le(_0x2d819a+'-version',()=>({'library':_0x2d819a,'version':_0x5a0732}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x452da0,_0x2c9b61)=>{switch(_0x2c9b61){case 0x0:try{_0x452da0['createObjectStore'](kt);}catch(_0x56dfd2){console['warn'](_0x56dfd2);}}}})['catch'](_0x2d1fc2=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x2d1fc2['message']});})),ti;}async function Al(_0x336e04){try{const _0x299d48=(await eo())['transaction'](kt),_0x40e4fb=await _0x299d48['objectStore'](kt)['get'](to(_0x336e04));return await _0x299d48['done'],_0x40e4fb;}catch(_0x3dbd7d){if(_0x3dbd7d instanceof Se)oe['warn'](_0x3dbd7d['message']);else{const _0x530fc4=ge['create']('idb-get',{'originalErrorMessage':_0x3dbd7d==null?void 0x0:_0x3dbd7d['message']});oe['warn'](_0x530fc4['message']);}}}async function Us(_0x3ed312,_0x143335){try{const _0x2e67a8=(await eo())['transaction'](kt,'readwrite');await _0x2e67a8['objectStore'](kt)['put'](_0x143335,to(_0x3ed312)),await _0x2e67a8['done'];}catch(_0x20bde0){if(_0x20bde0 instanceof Se)oe['warn'](_0x20bde0['message']);else{const _0x583a07=ge['create']('idb-set',{'originalErrorMessage':_0x20bde0==null?void 0x0:_0x20bde0['message']});oe['warn'](_0x583a07['message']);}}}function to(_0x3f1975){return _0x3f1975['name']+'!'+_0x3f1975['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x475f2d){this['container']=_0x475f2d,this['_heartbeatsCache']=null;const _0x541ca7=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x541ca7),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x250efb=>(this['_heartbeatsCache']=_0x250efb,_0x250efb));}async['triggerHeartbeat'](){var _0x30d06d,_0x3964b8;try{const _0x4c7495=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x1c12d0=Ws();if(((_0x30d06d=this['_heartbeatsCache'])==null?void 0x0:_0x30d06d['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x3964b8=this['_heartbeatsCache'])==null?void 0x0:_0x3964b8['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x1c12d0||this['_heartbeatsCache']['heartbeats']['some'](_0x53d101=>_0x53d101['date']===_0x1c12d0))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x1c12d0,'agent':_0x4c7495}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x4eb1d9=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x4eb1d9,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x2ce110){oe['warn'](_0x2ce110);}}async['getHeartbeatsHeader'](){var _0x1e9cfd;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x1e9cfd=this['_heartbeatsCache'])==null?void 0x0:_0x1e9cfd['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x2e5302=Ws(),{heartbeatsToSend:_0x4d1e9f,unsentEntries:_0x4660db}=Ol(this['_heartbeatsCache']['heartbeats']),_0x3cdb1a=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x4d1e9f}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x2e5302,_0x4660db['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x4660db,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x3cdb1a;}catch(_0x49fb62){return oe['warn'](_0x49fb62),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x5b3df5,_0x1ce6d5=kl){const _0x76992b=[];let _0x1522ae=_0x5b3df5['slice']();for(const _0x22a969 of _0x5b3df5){const _0x56d5f4=_0x76992b['find'](_0x2f5231=>_0x2f5231['agent']===_0x22a969['agent']);if(_0x56d5f4){if(_0x56d5f4['dates']['push'](_0x22a969['date']),Bs(_0x76992b)>_0x1ce6d5){_0x56d5f4['dates']['pop']();break;}}else{if(_0x76992b['push']({'agent':_0x22a969['agent'],'dates':[_0x22a969['date']]}),Bs(_0x76992b)>_0x1ce6d5){_0x76992b['pop']();break;}}_0x1522ae=_0x1522ae['slice'](0x1);}return{'heartbeatsToSend':_0x76992b,'unsentEntries':_0x1522ae};}class Dl{constructor(_0x141d1c){this['app']=_0x141d1c,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x2be9ba=await Al(this['app']);return _0x2be9ba!=null&&_0x2be9ba['heartbeats']?_0x2be9ba:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x3cd3c4){if(await this['_canUseIndexedDBPromise']){const _0x5800be=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x3cd3c4['lastSentHeartbeatDate']??_0x5800be['lastSentHeartbeatDate'],'heartbeats':_0x3cd3c4['heartbeats']});}else return;}async['add'](_0x17c53b){if(await this['_canUseIndexedDBPromise']){const _0x10b402=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x17c53b['lastSentHeartbeatDate']??_0x10b402['lastSentHeartbeatDate'],'heartbeats':[..._0x10b402['heartbeats'],..._0x17c53b['heartbeats']]});}else return;}}function Bs(_0x1bf762){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x1bf762}))['length'];}function Ml(_0x28d303){if(_0x28d303['length']===0x0)return-0x1;let _0xc4e23e=0x0,_0x3b0baf=_0x28d303[0x0]['date'];for(let _0x27f958=0x1;_0x27f958<_0x28d303['length'];_0x27f958++)_0x28d303[_0x27f958]['date']<_0x3b0baf&&(_0x3b0baf=_0x28d303[_0x27f958]['date'],_0xc4e23e=_0x27f958);return _0xc4e23e;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x2b018b){Ze(new Le('platform-logger',_0x102734=>new jc(_0x102734),'PRIVATE')),Ze(new Le('heartbeat',_0x1d1288=>new Pl(_0x1d1288),'PRIVATE')),me(pi,xs,_0x2b018b),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0xd20bca){no=_0xd20bca;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x175c9b){this['domStorage_']=_0x175c9b,this['prefix_']='firebase:';}['set'](_0x1bf334,_0x247567){_0x247567==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x1bf334)):this['domStorage_']['setItem'](this['prefixedName_'](_0x1bf334),O(_0x247567));}['get'](_0x25a215){const _0x51f812=this['domStorage_']['getItem'](this['prefixedName_'](_0x25a215));return _0x51f812==null?null:At(_0x51f812);}['remove'](_0x3532a3){this['domStorage_']['removeItem'](this['prefixedName_'](_0x3532a3));}['prefixedName_'](_0x252696){return this['prefix_']+_0x252696;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x12e4e1,_0x5583a8){_0x5583a8==null?delete this['cache_'][_0x12e4e1]:this['cache_'][_0x12e4e1]=_0x5583a8;}['get'](_0x358e9c){return J(this['cache_'],_0x358e9c)?this['cache_'][_0x358e9c]:null;}['remove'](_0xbafd92){delete this['cache_'][_0xbafd92];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x418412){try{if(typeof window<'u'&&typeof window[_0x418412]<'u'){const _0x42c2b6=window[_0x418412];return _0x42c2b6['setItem']('firebase:sentinel','cache'),_0x42c2b6['removeItem']('firebase:sentinel'),new Wl(_0x42c2b6);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x131263=0x1;return function(){return _0x131263++;};}()),ro=function(_0x4457cb){const _0x370694=Rc(_0x4457cb),_0x97fddf=new Cc();_0x97fddf['update'](_0x370694);const _0x2e1cd9=_0x97fddf['digest']();return Li['encodeByteArray'](_0x2e1cd9);},Vt=function(..._0x423789){let _0x2a4a92='';for(let _0x257102=0x0;_0x257102<_0x423789['length'];_0x257102++){const _0x2008d4=_0x423789[_0x257102];Array['isArray'](_0x2008d4)||_0x2008d4&&typeof _0x2008d4=='object'&&typeof _0x2008d4['length']=='number'?_0x2a4a92+=Vt['apply'](null,_0x2008d4):typeof _0x2008d4=='object'?_0x2a4a92+=O(_0x2008d4):_0x2a4a92+=_0x2008d4,_0x2a4a92+='\x20';}return _0x2a4a92;};let wt=null,Gs=!0x0;const Hl=function(_0x466f42,_0xa0c905){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x4761a8){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x308f64=Vt['apply'](null,_0x4761a8);wt(_0x308f64);}},Ht=function(_0x1bb687){return function(..._0x510216){L(_0x1bb687,..._0x510216);};},yi=function(..._0x42aa50){const _0xa732f7='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x42aa50);Ye['error'](_0xa732f7);},ae=function(..._0x4c504c){const _0x76b32d='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x4c504c);throw Ye['error'](_0x76b32d),new Error(_0x76b32d);},U=function(..._0x255cb5){const _0x487749='FIREBASE\x20WARNING:\x20'+Vt(..._0x255cb5);Ye['warn'](_0x487749);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x26e157){return typeof _0x26e157=='number'&&(_0x26e157!==_0x26e157||_0x26e157===Number['POSITIVE_INFINITY']||_0x26e157===Number['NEGATIVE_INFINITY']);},Gl=function(_0x2497ef){if(document['readyState']==='complete')_0x2497ef();else{let _0x1d1dee=!0x1;const _0x5edb9d=function(){if(!document['body']){setTimeout(_0x5edb9d,Math['floor'](0xa));return;}_0x1d1dee||(_0x1d1dee=!0x0,_0x2497ef());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x5edb9d,!0x1),window['addEventListener']('load',_0x5edb9d,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x5edb9d();}),window['attachEvent']('onload',_0x5edb9d));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x18ac17,_0x4b0141){if(_0x18ac17===_0x4b0141)return 0x0;if(_0x18ac17===Fe||_0x4b0141===Ie)return-0x1;if(_0x4b0141===Fe||_0x18ac17===Ie)return 0x1;{const _0x4c3d37=qs(_0x18ac17),_0x1ecc58=qs(_0x4b0141);return _0x4c3d37!==null?_0x1ecc58!==null?_0x4c3d37-_0x1ecc58===0x0?_0x18ac17['length']-_0x4b0141['length']:_0x4c3d37-_0x1ecc58:-0x1:_0x1ecc58!==null?0x1:_0x18ac17<_0x4b0141?-0x1:0x1;}},ql=function(_0x2b0954,_0x5488d2){return _0x2b0954===_0x5488d2?0x0:_0x2b0954<_0x5488d2?-0x1:0x1;},_t=function(_0x56f0fe,_0x48bd7f){if(_0x48bd7f&&_0x56f0fe in _0x48bd7f)return _0x48bd7f[_0x56f0fe];throw new Error('Missing\x20required\x20key\x20('+_0x56f0fe+')\x20in\x20object:\x20'+O(_0x48bd7f));},Hi=function(_0xbde7d2){if(typeof _0xbde7d2!='object'||_0xbde7d2===null)return O(_0xbde7d2);const _0x3e073e=[];for(const _0x3e9644 in _0xbde7d2)_0x3e073e['push'](_0x3e9644);_0x3e073e['sort']();let _0x50696c='{';for(let _0x4ce8d5=0x0;_0x4ce8d5<_0x3e073e['length'];_0x4ce8d5++)_0x4ce8d5!==0x0&&(_0x50696c+=','),_0x50696c+=O(_0x3e073e[_0x4ce8d5]),_0x50696c+=':',_0x50696c+=Hi(_0xbde7d2[_0x3e073e[_0x4ce8d5]]);return _0x50696c+='}',_0x50696c;},oo=function(_0x458618,_0x409165){const _0x23830e=_0x458618['length'];if(_0x23830e<=_0x409165)return[_0x458618];const _0x4fa45f=[];for(let _0x1b1f9b=0x0;_0x1b1f9b<_0x23830e;_0x1b1f9b+=_0x409165)_0x1b1f9b+_0x409165>_0x23830e?_0x4fa45f['push'](_0x458618['substring'](_0x1b1f9b,_0x23830e)):_0x4fa45f['push'](_0x458618['substring'](_0x1b1f9b,_0x1b1f9b+_0x409165));return _0x4fa45f;};function x(_0x1cb047,_0x1a6b2e){for(const _0x62f676 in _0x1cb047)_0x1cb047['hasOwnProperty'](_0x62f676)&&_0x1a6b2e(_0x62f676,_0x1cb047[_0x62f676]);}const ao=function(_0x54aae8){f(!Vi(_0x54aae8),'Invalid\x20JSON\x20number');const _0x3b5d29=0xb,_0x371947=0x34,_0x59ddd3=(0x1<<_0x3b5d29-0x1)-0x1;let _0xbb4357,_0x5e4d51,_0x139e00,_0x1786b1,_0x3ee17c;_0x54aae8===0x0?(_0x5e4d51=0x0,_0x139e00=0x0,_0xbb4357=0x1/_0x54aae8===-0x1/0x0?0x1:0x0):(_0xbb4357=_0x54aae8<0x0,_0x54aae8=Math['abs'](_0x54aae8),_0x54aae8>=Math['pow'](0x2,0x1-_0x59ddd3)?(_0x1786b1=Math['min'](Math['floor'](Math['log'](_0x54aae8)/Math['LN2']),_0x59ddd3),_0x5e4d51=_0x1786b1+_0x59ddd3,_0x139e00=Math['round'](_0x54aae8*Math['pow'](0x2,_0x371947-_0x1786b1)-Math['pow'](0x2,_0x371947))):(_0x5e4d51=0x0,_0x139e00=Math['round'](_0x54aae8/Math['pow'](0x2,0x1-_0x59ddd3-_0x371947))));const _0x29d8ca=[];for(_0x3ee17c=_0x371947;_0x3ee17c;_0x3ee17c-=0x1)_0x29d8ca['push'](_0x139e00%0x2?0x1:0x0),_0x139e00=Math['floor'](_0x139e00/0x2);for(_0x3ee17c=_0x3b5d29;_0x3ee17c;_0x3ee17c-=0x1)_0x29d8ca['push'](_0x5e4d51%0x2?0x1:0x0),_0x5e4d51=Math['floor'](_0x5e4d51/0x2);_0x29d8ca['push'](_0xbb4357?0x1:0x0),_0x29d8ca['reverse']();const _0x467494=_0x29d8ca['join']('');let _0x233f94='';for(_0x3ee17c=0x0;_0x3ee17c<0x40;_0x3ee17c+=0x8){let _0x93cce1=parseInt(_0x467494['substr'](_0x3ee17c,0x8),0x2)['toString'](0x10);_0x93cce1['length']===0x1&&(_0x93cce1='0'+_0x93cce1),_0x233f94=_0x233f94+_0x93cce1;}return _0x233f94['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x2ba1c7,_0x3a32e9){let _0x50f836='Unknown\x20Error';_0x2ba1c7==='too_big'?_0x50f836='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x2ba1c7==='permission_denied'?_0x50f836='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x2ba1c7==='unavailable'&&(_0x50f836='The\x20service\x20is\x20unavailable');const _0x4e3fa3=new Error(_0x2ba1c7+'\x20at\x20'+_0x3a32e9['_path']['toString']()+':\x20'+_0x50f836);return _0x4e3fa3['code']=_0x2ba1c7['toUpperCase'](),_0x4e3fa3;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x49da02){if(Yl['test'](_0x49da02)){const _0x5cbcaa=Number(_0x49da02);if(_0x5cbcaa>=Ql&&_0x5cbcaa<=Jl)return _0x5cbcaa;}return null;},ht=function(_0xe11c6b){try{_0xe11c6b();}catch(_0x501b3d){setTimeout(()=>{const _0x3bd8a2=_0x501b3d['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x3bd8a2),_0x501b3d;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0xe7d6e8,_0x4f8dc8){const _0x15bd7b=setTimeout(_0xe7d6e8,_0x4f8dc8);return typeof _0x15bd7b=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x15bd7b):typeof _0x15bd7b=='object'&&_0x15bd7b['unref']&&_0x15bd7b['unref'](),_0x15bd7b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x1be5e0,_0x5938c6){this['appCheckProvider']=_0x5938c6,this['appName']=_0x1be5e0['name'],$(_0x1be5e0)&&_0x1be5e0['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x1be5e0['settings']['appCheckToken']),this['appCheck']=_0x5938c6==null?void 0x0:_0x5938c6['getImmediate']({'optional':!0x0}),this['appCheck']||_0x5938c6==null||_0x5938c6['get']()['then'](_0x2e2f88=>this['appCheck']=_0x2e2f88);}['getToken'](_0x22da28){if(this['serverAppAppCheckToken']){if(_0x22da28)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x22da28):new Promise((_0x24d5b4,_0x31a15c)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x22da28)['then'](_0x24d5b4,_0x31a15c):_0x24d5b4(null);},0x0);});}['addTokenChangeListener'](_0x2ba7fb){var _0x4efd2e;(_0x4efd2e=this['appCheckProvider'])==null||_0x4efd2e['get']()['then'](_0x49f2dc=>_0x49f2dc['addTokenListener'](_0x2ba7fb));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x2039dc,_0x2024d6,_0x91eec4){this['appName_']=_0x2039dc,this['firebaseOptions_']=_0x2024d6,this['authProvider_']=_0x91eec4,this['auth_']=null,this['auth_']=_0x91eec4['getImmediate']({'optional':!0x0}),this['auth_']||_0x91eec4['onInit'](_0x5b7f25=>this['auth_']=_0x5b7f25);}['getToken'](_0x536d42){return this['auth_']?this['auth_']['getToken'](_0x536d42)['catch'](_0x3dec34=>_0x3dec34&&_0x3dec34['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x3dec34)):new Promise((_0x3957cf,_0x6498fd)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x536d42)['then'](_0x3957cf,_0x6498fd):_0x3957cf(null);},0x0);});}['addTokenChangeListener'](_0x45efdf){this['auth_']?this['auth_']['addAuthTokenListener'](_0x45efdf):this['authProvider_']['get']()['then'](_0xdaebc3=>_0xdaebc3['addAuthTokenListener'](_0x45efdf));}['removeTokenChangeListener'](_0xd87d04){this['authProvider_']['get']()['then'](_0x2c1b21=>_0x2c1b21['removeAuthTokenListener'](_0xd87d04));}['notifyForInvalidToken'](){let _0x15efeb='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x15efeb+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x15efeb+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x15efeb+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x15efeb);}}class nn{constructor(_0x43fa17){this['accessToken']=_0x43fa17;}['getToken'](_0x27e7b8){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x56137b){_0x56137b(this['accessToken']);}['removeTokenChangeListener'](_0xfb358c){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x41958b,_0x98930e,_0x5bba1f,_0x40ec49,_0x576e0d=!0x1,_0x12a717='',_0x33d0a0=!0x1,_0x2b8712=!0x1,_0x7967a7=null){this['secure']=_0x98930e,this['namespace']=_0x5bba1f,this['webSocketOnly']=_0x40ec49,this['nodeAdmin']=_0x576e0d,this['persistenceKey']=_0x12a717,this['includeNamespaceInQueryParams']=_0x33d0a0,this['isUsingEmulator']=_0x2b8712,this['emulatorOptions']=_0x7967a7,this['_host']=_0x41958b['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x41958b)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x4b4ef4){_0x4b4ef4!==this['internalHost']&&(this['internalHost']=_0x4b4ef4,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x39c93b=this['toURLString']();return this['persistenceKey']&&(_0x39c93b+='<'+this['persistenceKey']+'>'),_0x39c93b;}['toURLString'](){const _0x187f47=this['secure']?'https://':'http://',_0x11d8c1=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x187f47+this['host']+'/'+_0x11d8c1;}}function th(_0x1ac595){return _0x1ac595['host']!==_0x1ac595['internalHost']||_0x1ac595['isCustomHost']()||_0x1ac595['includeNamespaceInQueryParams'];}function vo(_0x53e93d,_0x585d25,_0x3bbba1){f(typeof _0x585d25=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x3bbba1=='object','typeof\x20params\x20must\x20==\x20object');let _0x2b3d15;if(_0x585d25===go)_0x2b3d15=(_0x53e93d['secure']?'wss://':'ws://')+_0x53e93d['internalHost']+'/.ws?';else{if(_0x585d25===mo)_0x2b3d15=(_0x53e93d['secure']?'https://':'http://')+_0x53e93d['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x585d25);}th(_0x53e93d)&&(_0x3bbba1['ns']=_0x53e93d['namespace']);const _0x3f1b72=[];return x(_0x3bbba1,(_0x1edd3,_0xfdd7f5)=>{_0x3f1b72['push'](_0x1edd3+'='+_0xfdd7f5);}),_0x2b3d15+_0x3f1b72['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x194f31,_0x1d1c80=0x1){J(this['counters_'],_0x194f31)||(this['counters_'][_0x194f31]=0x0),this['counters_'][_0x194f31]+=_0x1d1c80;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x4ea93e){const _0x23b898=_0x4ea93e['toString']();return ni[_0x23b898]||(ni[_0x23b898]=new nh()),ni[_0x23b898];}function ih(_0x10d961,_0x54fcd2){const _0x35b89c=_0x10d961['toString']();return ii[_0x35b89c]||(ii[_0x35b89c]=_0x54fcd2()),ii[_0x35b89c];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x284496){this['onMessage_']=_0x284496,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x547b3b,_0x55b083){this['closeAfterResponse']=_0x547b3b,this['onClose']=_0x55b083,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x3f3441,_0x162b84){for(this['pendingResponses'][_0x3f3441]=_0x162b84;this['pendingResponses'][this['currentResponseNum']];){const _0x481df7=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x5b77ce=0x0;_0x5b77ce<_0x481df7['length'];++_0x5b77ce)_0x481df7[_0x5b77ce]&&ht(()=>{this['onMessage_'](_0x481df7[_0x5b77ce]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0xdc234a,_0x39601d,_0x387114,_0x28519b,_0x189f8e,_0xa36b25,_0x2897e7){this['connId']=_0xdc234a,this['repoInfo']=_0x39601d,this['applicationId']=_0x387114,this['appCheckToken']=_0x28519b,this['authToken']=_0x189f8e,this['transportSessionId']=_0xa36b25,this['lastSessionId']=_0x2897e7,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0xdc234a),this['stats_']=Gi(_0x39601d),this['urlFn']=_0x39c5e5=>(this['appCheckToken']&&(_0x39c5e5[vi]=this['appCheckToken']),vo(_0x39601d,mo,_0x39c5e5));}['open'](_0x1a9fc1,_0x7aa714){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x7aa714,this['myPacketOrderer']=new sh(_0x1a9fc1),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x2b0c1c)=>{const [_0x4758c2,_0x577025,_0x5add30,_0x576f0b,_0x5e9d25]=_0x2b0c1c;if(this['incrementIncomingBytes_'](_0x2b0c1c),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x4758c2===zs)this['id']=_0x577025,this['password']=_0x5add30;else{if(_0x4758c2===rh)_0x577025?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x577025,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x4758c2);}}},(..._0x1ac7c6)=>{const [_0xd33cd2,_0x5592bb]=_0x1ac7c6;this['incrementIncomingBytes_'](_0x1ac7c6),this['myPacketOrderer']['handleResponse'](_0xd33cd2,_0x5592bb);},()=>{this['onClosed_']();},this['urlFn']);const _0x395bd1={};_0x395bd1[zs]='t',_0x395bd1[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x395bd1[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x395bd1[co]=$i,this['transportSessionId']&&(_0x395bd1[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x395bd1[po]=this['lastSessionId']),this['applicationId']&&(_0x395bd1[_o]=this['applicationId']),this['appCheckToken']&&(_0x395bd1[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x395bd1[ho]=uo);const _0x233fe6=this['urlFn'](_0x395bd1);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x233fe6),this['scriptTagHolder']['addTag'](_0x233fe6,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x36912e){const _0x5ced3b=O(_0x36912e);this['bytesSent']+=_0x5ced3b['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5ced3b['length']);const _0x97c772=Hr(_0x5ced3b),_0xeb6498=oo(_0x97c772,fh);for(let _0x345f69=0x0;_0x345f69<_0xeb6498['length'];_0x345f69++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0xeb6498['length'],_0xeb6498[_0x345f69]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x14386a,_0xb9545f){this['myDisconnFrame']=document['createElement']('iframe');const _0x38b1cc={};_0x38b1cc[dh]='t',_0x38b1cc[Eo]=_0x14386a,_0x38b1cc[Io]=_0xb9545f,this['myDisconnFrame']['src']=this['urlFn'](_0x38b1cc),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x2053fa){const _0x1136b7=O(_0x2053fa)['length'];this['bytesReceived']+=_0x1136b7,this['stats_']['incrementCounter']('bytes_received',_0x1136b7);}}class qi{constructor(_0x79017,_0x446791,_0x421d58,_0x3a3ce1){this['onDisconnect']=_0x421d58,this['urlFn']=_0x3a3ce1,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x79017,window[ah+this['uniqueCallbackIdentifier']]=_0x446791,this['myIFrame']=qi['createIFrame_']();let _0x11b1ae='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x11b1ae='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x2c5445='<html><body>'+_0x11b1ae+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x2c5445),this['myIFrame']['doc']['close']();}catch(_0x49e4a2){L('frame\x20writing\x20exception'),_0x49e4a2['stack']&&L(_0x49e4a2['stack']),L(_0x49e4a2);}}}static['createIFrame_'](){const _0xfc4fd6=document['createElement']('iframe');if(_0xfc4fd6['style']['display']='none',document['body']){document['body']['appendChild'](_0xfc4fd6);try{_0xfc4fd6['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x50254e=document['domain'];_0xfc4fd6['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x50254e+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0xfc4fd6['contentDocument']?_0xfc4fd6['doc']=_0xfc4fd6['contentDocument']:_0xfc4fd6['contentWindow']?_0xfc4fd6['doc']=_0xfc4fd6['contentWindow']['document']:_0xfc4fd6['document']&&(_0xfc4fd6['doc']=_0xfc4fd6['document']),_0xfc4fd6;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x495a58=this['onDisconnect'];_0x495a58&&(this['onDisconnect']=null,_0x495a58());}['startLongPoll'](_0x1fcd87,_0x587d86){for(this['myID']=_0x1fcd87,this['myPW']=_0x587d86,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x24a1e0={};_0x24a1e0[Eo]=this['myID'],_0x24a1e0[Io]=this['myPW'],_0x24a1e0[wo]=this['currentSerial'];let _0x125a00=this['urlFn'](_0x24a1e0),_0x36925e='',_0x439fa3=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x36925e['length']<=Co;){const _0x779eb=this['pendingSegs']['shift']();_0x36925e=_0x36925e+'&'+lh+_0x439fa3+'='+_0x779eb['seg']+'&'+hh+_0x439fa3+'='+_0x779eb['ts']+'&'+uh+_0x439fa3+'='+_0x779eb['d'],_0x439fa3++;}return _0x125a00=_0x125a00+_0x36925e,this['addLongPollTag_'](_0x125a00,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x174d75,_0x3851af,_0x4c4e46){this['pendingSegs']['push']({'seg':_0x174d75,'ts':_0x3851af,'d':_0x4c4e46}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0xc452cd,_0x4b579e){this['outstandingRequests']['add'](_0x4b579e);const _0x760fad=()=>{this['outstandingRequests']['delete'](_0x4b579e),this['newRequest_']();},_0x2a4164=setTimeout(_0x760fad,Math['floor'](ph)),_0x2ead64=()=>{clearTimeout(_0x2a4164),_0x760fad();};this['addTag'](_0xc452cd,_0x2ead64);}['addTag'](_0x4b2a24,_0x5cfca5){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0xc16876=this['myIFrame']['doc']['createElement']('script');_0xc16876['type']='text/javascript',_0xc16876['async']=!0x0,_0xc16876['src']=_0x4b2a24,_0xc16876['onload']=_0xc16876['onreadystatechange']=function(){const _0x19bd4b=_0xc16876['readyState'];(!_0x19bd4b||_0x19bd4b==='loaded'||_0x19bd4b==='complete')&&(_0xc16876['onload']=_0xc16876['onreadystatechange']=null,_0xc16876['parentNode']&&_0xc16876['parentNode']['removeChild'](_0xc16876),_0x5cfca5());},_0xc16876['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x4b2a24),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0xc16876);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x31b9ab,_0x571876,_0x101f5b,_0x469b88,_0x2eee3a,_0x1699aa,_0x3ecba7){this['connId']=_0x31b9ab,this['applicationId']=_0x101f5b,this['appCheckToken']=_0x469b88,this['authToken']=_0x2eee3a,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x571876),this['connURL']=z['connectionURL_'](_0x571876,_0x1699aa,_0x3ecba7,_0x469b88,_0x101f5b),this['nodeAdmin']=_0x571876['nodeAdmin'];}static['connectionURL_'](_0x45c1ec,_0x5d3250,_0x433b3d,_0x26a7b9,_0x471dee){const _0x571d1c={};return _0x571d1c[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x571d1c[ho]=uo),_0x5d3250&&(_0x571d1c[lo]=_0x5d3250),_0x433b3d&&(_0x571d1c[po]=_0x433b3d),_0x26a7b9&&(_0x571d1c[vi]=_0x26a7b9),_0x471dee&&(_0x571d1c[_o]=_0x471dee),vo(_0x45c1ec,go,_0x571d1c);}['open'](_0x3d7327,_0x40f8b4){this['onDisconnect']=_0x40f8b4,this['onMessage']=_0x3d7327,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x25d667;_c(),this['mySock']=new un(this['connURL'],[],_0x25d667);}catch(_0x57ccfc){this['log_']('Error\x20instantiating\x20WebSocket.');const _0xe278cc=_0x57ccfc['message']||_0x57ccfc['data'];_0xe278cc&&this['log_'](_0xe278cc),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x58bb2d=>{this['handleIncomingFrame'](_0x58bb2d);},this['mySock']['onerror']=_0x398ff7=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x1f5499=_0x398ff7['message']||_0x398ff7['data'];_0x1f5499&&this['log_'](_0x1f5499),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x40e804=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x3da76f=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x23323e=navigator['userAgent']['match'](_0x3da76f);_0x23323e&&_0x23323e['length']>0x1&&parseFloat(_0x23323e[0x1])<4.4&&(_0x40e804=!0x0);}return!_0x40e804&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x4278f9){if(this['frames']['push'](_0x4278f9),this['frames']['length']===this['totalFrames']){const _0xbf06b=this['frames']['join']('');this['frames']=null;const _0x257f40=At(_0xbf06b);this['onMessage'](_0x257f40);}}['handleNewFrameCount_'](_0x3b521b){this['totalFrames']=_0x3b521b,this['frames']=[];}['extractFrameCount_'](_0x4e3bf7){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x4e3bf7['length']<=0x6){const _0x563fb6=Number(_0x4e3bf7);if(!isNaN(_0x563fb6))return this['handleNewFrameCount_'](_0x563fb6),null;}return this['handleNewFrameCount_'](0x1),_0x4e3bf7;}['handleIncomingFrame'](_0x4d6750){if(this['mySock']===null)return;const _0x16f24f=_0x4d6750['data'];if(this['bytesReceived']+=_0x16f24f['length'],this['stats_']['incrementCounter']('bytes_received',_0x16f24f['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x16f24f);else{const _0x9e4ffa=this['extractFrameCount_'](_0x16f24f);_0x9e4ffa!==null&&this['appendFrame_'](_0x9e4ffa);}}['send'](_0x159c83){this['resetKeepAlive']();const _0x10ee0e=O(_0x159c83);this['bytesSent']+=_0x10ee0e['length'],this['stats_']['incrementCounter']('bytes_sent',_0x10ee0e['length']);const _0x1812e1=oo(_0x10ee0e,gh);_0x1812e1['length']>0x1&&this['sendString_'](String(_0x1812e1['length']));for(let _0x125482=0x0;_0x125482<_0x1812e1['length'];_0x125482++)this['sendString_'](_0x1812e1[_0x125482]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x246fb6){try{this['mySock']['send'](_0x246fb6);}catch(_0x27bc51){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x27bc51['message']||_0x27bc51['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x2f2837){this['initTransports_'](_0x2f2837);}['initTransports_'](_0x37f5cf){const _0x3e8c83=z&&z['isAvailable']();let _0xef7ae5=_0x3e8c83&&!z['previouslyFailed']();if(_0x37f5cf['webSocketOnly']&&(_0x3e8c83||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0xef7ae5=!0x0),_0xef7ae5)this['transports_']=[z];else{const _0x4503c7=this['transports_']=[];for(const _0x26b4da of Nt['ALL_TRANSPORTS'])_0x26b4da&&_0x26b4da['isAvailable']()&&_0x4503c7['push'](_0x26b4da);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x1bb305,_0x35e24c,_0x4b19dd,_0x3e6ccd,_0x161837,_0x1f5d7d,_0x5b2e3c,_0x3ad66d,_0x23bf9f,_0x2cbcc8){this['id']=_0x1bb305,this['repoInfo_']=_0x35e24c,this['applicationId_']=_0x4b19dd,this['appCheckToken_']=_0x3e6ccd,this['authToken_']=_0x161837,this['onMessage_']=_0x1f5d7d,this['onReady_']=_0x5b2e3c,this['onDisconnect_']=_0x3ad66d,this['onKill_']=_0x23bf9f,this['lastSessionId']=_0x2cbcc8,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x35e24c),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x36b54b=this['transportManager_']['initialTransport']();this['conn_']=new _0x36b54b(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x36b54b['responsesRequiredToBeHealthy']||0x0;const _0x5009bb=this['connReceiver_'](this['conn_']),_0x46beb3=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x5009bb,_0x46beb3);},Math['floor'](0x0));const _0x29ef15=_0x36b54b['healthyTimeout']||0x0;_0x29ef15>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x29ef15)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x10de31){return _0x1819b3=>{_0x10de31===this['conn_']?this['onConnectionLost_'](_0x1819b3):_0x10de31===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x1a9cf4){return _0x5bd46d=>{this['state_']!==0x2&&(_0x1a9cf4===this['rx_']?this['onPrimaryMessageReceived_'](_0x5bd46d):_0x1a9cf4===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x5bd46d):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x358482){const _0x5b134c={'t':'d','d':_0x358482};this['sendData_'](_0x5b134c);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x4ee239){if(si in _0x4ee239){const _0x2e4cbc=_0x4ee239[si];_0x2e4cbc===Qs?this['upgradeIfSecondaryHealthy_']():_0x2e4cbc===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x2e4cbc===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x434bb3){const _0x209073=_t('t',_0x434bb3),_0x358951=_t('d',_0x434bb3);if(_0x209073==='c')this['onSecondaryControl_'](_0x358951);else{if(_0x209073==='d')this['pendingDataMessages']['push'](_0x358951);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x209073);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x5b576c){const _0x138570=_t('t',_0x5b576c),_0x31f1be=_t('d',_0x5b576c);_0x138570==='c'?this['onControl_'](_0x31f1be):_0x138570==='d'&&this['onDataMessage_'](_0x31f1be);}['onDataMessage_'](_0x3e0440){this['onPrimaryResponse_'](),this['onMessage_'](_0x3e0440);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x1894ce){const _0x10d554=_t(si,_0x1894ce);if(js in _0x1894ce){const _0x445baf=_0x1894ce[js];if(_0x10d554===Th){const _0x168b37={..._0x445baf};this['repoInfo_']['isUsingEmulator']&&(_0x168b37['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x168b37);}else{if(_0x10d554===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x26ab67=0x0;_0x26ab67<this['pendingDataMessages']['length'];++_0x26ab67)this['onDataMessage_'](this['pendingDataMessages'][_0x26ab67]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x10d554===wh?this['onConnectionShutdown_'](_0x445baf):_0x10d554===Ks?this['onReset_'](_0x445baf):_0x10d554===Ch?yi('Server\x20Error:\x20'+_0x445baf):_0x10d554===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x10d554);}}}['onHandshake_'](_0x318548){const _0x15a291=_0x318548['ts'],_0x3a7a59=_0x318548['v'],_0x176aad=_0x318548['h'];this['sessionId']=_0x318548['s'],this['repoInfo_']['host']=_0x176aad,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x15a291),$i!==_0x3a7a59&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x2220ef=this['transportManager_']['upgradeTransport']();_0x2220ef&&this['startUpgrade_'](_0x2220ef);}['startUpgrade_'](_0x4d4f02){this['secondaryConn_']=new _0x4d4f02(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x4d4f02['responsesRequiredToBeHealthy']||0x0;const _0x5ed519=this['connReceiver_'](this['secondaryConn_']),_0x23db00=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x5ed519,_0x23db00),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x1a759c){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x1a759c),this['repoInfo_']['host']=_0x1a759c,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x3cedf8,_0x56336a){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x3cedf8,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x56336a,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x5cf8ec=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x5cf8ec||this['rx_']===_0x5cf8ec)&&this['close']();}['onConnectionLost_'](_0x65fe93){this['conn_']=null,!_0x65fe93&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x525e07){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x525e07),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x425bf1){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x425bf1);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0xd60a1,_0x28cfe1,_0x2f9046,_0x18cc2c){}['merge'](_0x2613c6,_0x15fdaa,_0x5751cd,_0x2e5b7b){}['refreshAuthToken'](_0x1de609){}['refreshAppCheckToken'](_0x33b195){}['onDisconnectPut'](_0x350757,_0xa5fa12,_0x3c9a4f){}['onDisconnectMerge'](_0x2524f0,_0x2af96e,_0x13abed){}['onDisconnectCancel'](_0x134bb0,_0x4cb98f){}['reportStats'](_0xf053df){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x301232){this['allowedEvents_']=_0x301232,this['listeners_']={},f(Array['isArray'](_0x301232)&&_0x301232['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x17ee29,..._0x5372fe){if(Array['isArray'](this['listeners_'][_0x17ee29])){const _0x1e36d5=[...this['listeners_'][_0x17ee29]];for(let _0x12ac49=0x0;_0x12ac49<_0x1e36d5['length'];_0x12ac49++)_0x1e36d5[_0x12ac49]['callback']['apply'](_0x1e36d5[_0x12ac49]['context'],_0x5372fe);}}['on'](_0x54c479,_0x2d8932,_0x16f238){this['validateEventType_'](_0x54c479),this['listeners_'][_0x54c479]=this['listeners_'][_0x54c479]||[],this['listeners_'][_0x54c479]['push']({'callback':_0x2d8932,'context':_0x16f238});const _0x5d579b=this['getInitialEvent'](_0x54c479);_0x5d579b&&_0x2d8932['apply'](_0x16f238,_0x5d579b);}['off'](_0x410300,_0xf31577,_0x1083bd){this['validateEventType_'](_0x410300);const _0x7db978=this['listeners_'][_0x410300]||[];for(let _0x52b488=0x0;_0x52b488<_0x7db978['length'];_0x52b488++)if(_0x7db978[_0x52b488]['callback']===_0xf31577&&(!_0x1083bd||_0x1083bd===_0x7db978[_0x52b488]['context'])){_0x7db978['splice'](_0x52b488,0x1);return;}}['validateEventType_'](_0x41ff4c){f(this['allowedEvents_']['find'](_0x4447ac=>_0x4447ac===_0x41ff4c),'Unknown\x20event:\x20'+_0x41ff4c);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x3a45ce){return f(_0x3a45ce==='online','Unknown\x20event\x20type:\x20'+_0x3a45ce),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x4192f8,_0x2e065e){if(_0x2e065e===void 0x0){this['pieces_']=_0x4192f8['split']('/');let _0x2b8aa3=0x0;for(let _0x22625f=0x0;_0x22625f<this['pieces_']['length'];_0x22625f++)this['pieces_'][_0x22625f]['length']>0x0&&(this['pieces_'][_0x2b8aa3]=this['pieces_'][_0x22625f],_0x2b8aa3++);this['pieces_']['length']=_0x2b8aa3,this['pieceNum_']=0x0;}else this['pieces_']=_0x4192f8,this['pieceNum_']=_0x2e065e;}['toString'](){let _0x4ddd2f='';for(let _0x20deef=this['pieceNum_'];_0x20deef<this['pieces_']['length'];_0x20deef++)this['pieces_'][_0x20deef]!==''&&(_0x4ddd2f+='/'+this['pieces_'][_0x20deef]);return _0x4ddd2f||'/';}}function w(){return new C('');}function y(_0x217ed4){return _0x217ed4['pieceNum_']>=_0x217ed4['pieces_']['length']?null:_0x217ed4['pieces_'][_0x217ed4['pieceNum_']];}function we(_0x293fb0){return _0x293fb0['pieces_']['length']-_0x293fb0['pieceNum_'];}function b(_0x512dd4){let _0x59cc8a=_0x512dd4['pieceNum_'];return _0x59cc8a<_0x512dd4['pieces_']['length']&&_0x59cc8a++,new C(_0x512dd4['pieces_'],_0x59cc8a);}function zi(_0x103e9b){return _0x103e9b['pieceNum_']<_0x103e9b['pieces_']['length']?_0x103e9b['pieces_'][_0x103e9b['pieces_']['length']-0x1]:null;}function bh(_0xb244ee){let _0x395c72='';for(let _0x25b402=_0xb244ee['pieceNum_'];_0x25b402<_0xb244ee['pieces_']['length'];_0x25b402++)_0xb244ee['pieces_'][_0x25b402]!==''&&(_0x395c72+='/'+encodeURIComponent(String(_0xb244ee['pieces_'][_0x25b402])));return _0x395c72||'/';}function Pt(_0x20f32e,_0x1ccc36=0x0){return _0x20f32e['pieces_']['slice'](_0x20f32e['pieceNum_']+_0x1ccc36);}function Ro(_0x1d8865){if(_0x1d8865['pieceNum_']>=_0x1d8865['pieces_']['length'])return null;const _0x48e1d8=[];for(let _0x4a7c67=_0x1d8865['pieceNum_'];_0x4a7c67<_0x1d8865['pieces_']['length']-0x1;_0x4a7c67++)_0x48e1d8['push'](_0x1d8865['pieces_'][_0x4a7c67]);return new C(_0x48e1d8,0x0);}function k(_0x1b3f70,_0x74f1c2){const _0x33a96a=[];for(let _0x4d84fb=_0x1b3f70['pieceNum_'];_0x4d84fb<_0x1b3f70['pieces_']['length'];_0x4d84fb++)_0x33a96a['push'](_0x1b3f70['pieces_'][_0x4d84fb]);if(_0x74f1c2 instanceof C){for(let _0x1c15a5=_0x74f1c2['pieceNum_'];_0x1c15a5<_0x74f1c2['pieces_']['length'];_0x1c15a5++)_0x33a96a['push'](_0x74f1c2['pieces_'][_0x1c15a5]);}else{const _0x5c5852=_0x74f1c2['split']('/');for(let _0x41b011=0x0;_0x41b011<_0x5c5852['length'];_0x41b011++)_0x5c5852[_0x41b011]['length']>0x0&&_0x33a96a['push'](_0x5c5852[_0x41b011]);}return new C(_0x33a96a,0x0);}function v(_0x1e71ed){return _0x1e71ed['pieceNum_']>=_0x1e71ed['pieces_']['length'];}function F(_0x978f79,_0x2c8a6c){const _0x31b758=y(_0x978f79),_0xa9fcee=y(_0x2c8a6c);if(_0x31b758===null)return _0x2c8a6c;if(_0x31b758===_0xa9fcee)return F(b(_0x978f79),b(_0x2c8a6c));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x2c8a6c+')\x20is\x20not\x20within\x20outerPath\x20('+_0x978f79+')');}function Rh(_0x31bc36,_0x10e9b0){const _0x34388e=Pt(_0x31bc36,0x0),_0x48f5c7=Pt(_0x10e9b0,0x0);for(let _0x263f26=0x0;_0x263f26<_0x34388e['length']&&_0x263f26<_0x48f5c7['length'];_0x263f26++){const _0x2fe78b=He(_0x34388e[_0x263f26],_0x48f5c7[_0x263f26]);if(_0x2fe78b!==0x0)return _0x2fe78b;}return _0x34388e['length']===_0x48f5c7['length']?0x0:_0x34388e['length']<_0x48f5c7['length']?-0x1:0x1;}function ji(_0x155613,_0x7b24db){if(we(_0x155613)!==we(_0x7b24db))return!0x1;for(let _0x1d82f7=_0x155613['pieceNum_'],_0x1225ca=_0x7b24db['pieceNum_'];_0x1d82f7<=_0x155613['pieces_']['length'];_0x1d82f7++,_0x1225ca++)if(_0x155613['pieces_'][_0x1d82f7]!==_0x7b24db['pieces_'][_0x1225ca])return!0x1;return!0x0;}function G(_0x25d25c,_0x3a9df0){let _0x55ecd1=_0x25d25c['pieceNum_'],_0x29089b=_0x3a9df0['pieceNum_'];if(we(_0x25d25c)>we(_0x3a9df0))return!0x1;for(;_0x55ecd1<_0x25d25c['pieces_']['length'];){if(_0x25d25c['pieces_'][_0x55ecd1]!==_0x3a9df0['pieces_'][_0x29089b])return!0x1;++_0x55ecd1,++_0x29089b;}return!0x0;}class Ah{constructor(_0x37081a,_0x15929c){this['errorPrefix_']=_0x15929c,this['parts_']=Pt(_0x37081a,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x58f0a3=0x0;_0x58f0a3<this['parts_']['length'];_0x58f0a3++)this['byteLength_']+=On(this['parts_'][_0x58f0a3]);Ao(this);}}function kh(_0x475428,_0x1dc909){_0x475428['parts_']['length']>0x0&&(_0x475428['byteLength_']+=0x1),_0x475428['parts_']['push'](_0x1dc909),_0x475428['byteLength_']+=On(_0x1dc909),Ao(_0x475428);}function Nh(_0x1b3c74){const _0x163871=_0x1b3c74['parts_']['pop']();_0x1b3c74['byteLength_']-=On(_0x163871),_0x1b3c74['parts_']['length']>0x0&&(_0x1b3c74['byteLength_']-=0x1);}function Ao(_0xf160ee){if(_0xf160ee['byteLength_']>er)throw new Error(_0xf160ee['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0xf160ee['byteLength_']+').');if(_0xf160ee['parts_']['length']>Zs)throw new Error(_0xf160ee['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0xf160ee));}function Pe(_0x2d4b63){return _0x2d4b63['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x2d4b63['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x2f5226,_0x2b6fc7;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x2b6fc7='visibilitychange',_0x2f5226='hidden'):typeof document['mozHidden']<'u'?(_0x2b6fc7='mozvisibilitychange',_0x2f5226='mozHidden'):typeof document['msHidden']<'u'?(_0x2b6fc7='msvisibilitychange',_0x2f5226='msHidden'):typeof document['webkitHidden']<'u'&&(_0x2b6fc7='webkitvisibilitychange',_0x2f5226='webkitHidden')),this['visible_']=!0x0,_0x2b6fc7&&document['addEventListener'](_0x2b6fc7,()=>{const _0x5c23c2=!document[_0x2f5226];_0x5c23c2!==this['visible_']&&(this['visible_']=_0x5c23c2,this['trigger']('visible',_0x5c23c2));},!0x1);}['getInitialEvent'](_0x591d43){return f(_0x591d43==='visible','Unknown\x20event\x20type:\x20'+_0x591d43),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x56a9b8,_0x29c672,_0x3e0726,_0x569ce0,_0x2bc549,_0x4cbf70,_0x174da2,_0x45aa4b){if(super(),this['repoInfo_']=_0x56a9b8,this['applicationId_']=_0x29c672,this['onDataUpdate_']=_0x3e0726,this['onConnectStatus_']=_0x569ce0,this['onServerInfoUpdate_']=_0x2bc549,this['authTokenProvider_']=_0x4cbf70,this['appCheckTokenProvider_']=_0x174da2,this['authOverride_']=_0x45aa4b,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x45aa4b)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x56a9b8['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x50fb90,_0xb6071,_0x4540e0){const _0x5ec509=++this['requestNumber_'],_0x5e89d7={'r':_0x5ec509,'a':_0x50fb90,'b':_0xb6071};this['log_'](O(_0x5e89d7)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x5e89d7),_0x4540e0&&(this['requestCBHash_'][_0x5ec509]=_0x4540e0);}['get'](_0x2afe4f){this['initConnection_']();const _0x18c21b=new ot(),_0x2861d7={'action':'g','request':{'p':_0x2afe4f['_path']['toString'](),'q':_0x2afe4f['_queryObject']},'onComplete':_0x41d968=>{const _0x3ee542=_0x41d968['d'];_0x41d968['s']==='ok'?_0x18c21b['resolve'](_0x3ee542):_0x18c21b['reject'](_0x3ee542);}};this['outstandingGets_']['push'](_0x2861d7),this['outstandingGetCount_']++;const _0x45afc1=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x45afc1),_0x18c21b['promise'];}['listen'](_0x4921db,_0xb7a1db,_0x5a0b7e,_0x585dec){this['initConnection_']();const _0x2ccd27=_0x4921db['_queryIdentifier'],_0x4a6920=_0x4921db['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4a6920+'\x20'+_0x2ccd27),this['listens']['has'](_0x4a6920)||this['listens']['set'](_0x4a6920,new Map()),f(_0x4921db['_queryParams']['isDefault']()||!_0x4921db['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x4a6920)['has'](_0x2ccd27),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x6179a6={'onComplete':_0x585dec,'hashFn':_0xb7a1db,'query':_0x4921db,'tag':_0x5a0b7e};this['listens']['get'](_0x4a6920)['set'](_0x2ccd27,_0x6179a6),this['connected_']&&this['sendListen_'](_0x6179a6);}['sendGet_'](_0x241578){const _0x1f3944=this['outstandingGets_'][_0x241578];this['sendRequest']('g',_0x1f3944['request'],_0x27aa04=>{delete this['outstandingGets_'][_0x241578],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1f3944['onComplete']&&_0x1f3944['onComplete'](_0x27aa04);});}['sendListen_'](_0x4a7bc8){const _0x1d5cea=_0x4a7bc8['query'],_0x234a10=_0x1d5cea['_path']['toString'](),_0x44c6e6=_0x1d5cea['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x234a10+'\x20for\x20'+_0x44c6e6);const _0x68c6fd={'p':_0x234a10},_0x3a92b9='q';_0x4a7bc8['tag']&&(_0x68c6fd['q']=_0x1d5cea['_queryObject'],_0x68c6fd['t']=_0x4a7bc8['tag']),_0x68c6fd['h']=_0x4a7bc8['hashFn'](),this['sendRequest'](_0x3a92b9,_0x68c6fd,_0x4fc08b=>{const _0x4abd7d=_0x4fc08b['d'],_0x43e560=_0x4fc08b['s'];se['warnOnListenWarnings_'](_0x4abd7d,_0x1d5cea),(this['listens']['get'](_0x234a10)&&this['listens']['get'](_0x234a10)['get'](_0x44c6e6))===_0x4a7bc8&&(this['log_']('listen\x20response',_0x4fc08b),_0x43e560!=='ok'&&this['removeListen_'](_0x234a10,_0x44c6e6),_0x4a7bc8['onComplete']&&_0x4a7bc8['onComplete'](_0x43e560,_0x4abd7d));});}static['warnOnListenWarnings_'](_0x2a0813,_0x1117c6){if(_0x2a0813&&typeof _0x2a0813=='object'&&J(_0x2a0813,'w')){const _0x27d4e7=De(_0x2a0813,'w');if(Array['isArray'](_0x27d4e7)&&~_0x27d4e7['indexOf']('no_index')){const _0x20da68='\x22.indexOn\x22:\x20\x22'+_0x1117c6['_queryParams']['getIndex']()['toString']()+'\x22',_0x108184=_0x1117c6['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x20da68+'\x20at\x20'+_0x108184+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x4349d0){this['authToken_']=_0x4349d0,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x4349d0);}['reduceReconnectDelayIfAdminCredential_'](_0x50b8f4){(_0x50b8f4&&_0x50b8f4['length']===0x28||wc(_0x50b8f4))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x2b4375){this['appCheckToken_']=_0x2b4375,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x44e870=this['authToken_'],_0x22ce21=Ic(_0x44e870)?'auth':'gauth',_0x5ba390={'cred':_0x44e870};this['authOverride_']===null?_0x5ba390['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x5ba390['authvar']=this['authOverride_']),this['sendRequest'](_0x22ce21,_0x5ba390,_0x40cba2=>{const _0x487791=_0x40cba2['s'],_0x5b8179=_0x40cba2['d']||'error';this['authToken_']===_0x44e870&&(_0x487791==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x487791,_0x5b8179));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x1ab111=>{const _0x2caaa5=_0x1ab111['s'],_0x1a8b23=_0x1ab111['d']||'error';_0x2caaa5==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x2caaa5,_0x1a8b23);});}['unlisten'](_0x52973a,_0x1134e1){const _0x35f88e=_0x52973a['_path']['toString'](),_0x413eb4=_0x52973a['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x35f88e+'\x20'+_0x413eb4),f(_0x52973a['_queryParams']['isDefault']()||!_0x52973a['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x35f88e,_0x413eb4)&&this['connected_']&&this['sendUnlisten_'](_0x35f88e,_0x413eb4,_0x52973a['_queryObject'],_0x1134e1);}['sendUnlisten_'](_0x30d9b9,_0x40b640,_0x4c00f8,_0x5ab3ab){this['log_']('Unlisten\x20on\x20'+_0x30d9b9+'\x20for\x20'+_0x40b640);const _0x3d8809={'p':_0x30d9b9},_0xb4a5f5='n';_0x5ab3ab&&(_0x3d8809['q']=_0x4c00f8,_0x3d8809['t']=_0x5ab3ab),this['sendRequest'](_0xb4a5f5,_0x3d8809);}['onDisconnectPut'](_0x524c29,_0x143562,_0x826afd){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x524c29,_0x143562,_0x826afd):this['onDisconnectRequestQueue_']['push']({'pathString':_0x524c29,'action':'o','data':_0x143562,'onComplete':_0x826afd});}['onDisconnectMerge'](_0xcba58b,_0x3dd98a,_0x1fa37b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0xcba58b,_0x3dd98a,_0x1fa37b):this['onDisconnectRequestQueue_']['push']({'pathString':_0xcba58b,'action':'om','data':_0x3dd98a,'onComplete':_0x1fa37b});}['onDisconnectCancel'](_0xccf924,_0x14cfcf){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0xccf924,null,_0x14cfcf):this['onDisconnectRequestQueue_']['push']({'pathString':_0xccf924,'action':'oc','data':null,'onComplete':_0x14cfcf});}['sendOnDisconnect_'](_0x1cf0fe,_0x385b34,_0x40e485,_0xa6dfac){const _0x1a26a3={'p':_0x385b34,'d':_0x40e485};this['log_']('onDisconnect\x20'+_0x1cf0fe,_0x1a26a3),this['sendRequest'](_0x1cf0fe,_0x1a26a3,_0x1cd277=>{_0xa6dfac&&setTimeout(()=>{_0xa6dfac(_0x1cd277['s'],_0x1cd277['d']);},Math['floor'](0x0));});}['put'](_0x1f2a7c,_0x15ab71,_0x169ef1,_0x26657b){this['putInternal']('p',_0x1f2a7c,_0x15ab71,_0x169ef1,_0x26657b);}['merge'](_0x2ec56b,_0x5f5cc1,_0x1c6f15,_0x343bd9){this['putInternal']('m',_0x2ec56b,_0x5f5cc1,_0x1c6f15,_0x343bd9);}['putInternal'](_0x4719b1,_0x50c1f3,_0x258d06,_0x561ad8,_0x906ba4){this['initConnection_']();const _0xe37d76={'p':_0x50c1f3,'d':_0x258d06};_0x906ba4!==void 0x0&&(_0xe37d76['h']=_0x906ba4),this['outstandingPuts_']['push']({'action':_0x4719b1,'request':_0xe37d76,'onComplete':_0x561ad8}),this['outstandingPutCount_']++;const _0x20e657=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x20e657):this['log_']('Buffering\x20put:\x20'+_0x50c1f3);}['sendPut_'](_0x39fe29){const _0x53c2eb=this['outstandingPuts_'][_0x39fe29]['action'],_0x807273=this['outstandingPuts_'][_0x39fe29]['request'],_0x22f8b1=this['outstandingPuts_'][_0x39fe29]['onComplete'];this['outstandingPuts_'][_0x39fe29]['queued']=this['connected_'],this['sendRequest'](_0x53c2eb,_0x807273,_0x193e28=>{this['log_'](_0x53c2eb+'\x20response',_0x193e28),delete this['outstandingPuts_'][_0x39fe29],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x22f8b1&&_0x22f8b1(_0x193e28['s'],_0x193e28['d']);});}['reportStats'](_0x3c07af){if(this['connected_']){const _0xdafdd7={'c':_0x3c07af};this['log_']('reportStats',_0xdafdd7),this['sendRequest']('s',_0xdafdd7,_0x3530b8=>{if(_0x3530b8['s']!=='ok'){const _0x4bfb08=_0x3530b8['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x4bfb08);}});}}['onDataMessage_'](_0x54dfdf){if('r'in _0x54dfdf){this['log_']('from\x20server:\x20'+O(_0x54dfdf));const _0x540241=_0x54dfdf['r'],_0x437d65=this['requestCBHash_'][_0x540241];_0x437d65&&(delete this['requestCBHash_'][_0x540241],_0x437d65(_0x54dfdf['b']));}else{if('error'in _0x54dfdf)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x54dfdf['error'];'a'in _0x54dfdf&&this['onDataPush_'](_0x54dfdf['a'],_0x54dfdf['b']);}}['onDataPush_'](_0x4fc346,_0x12df80){this['log_']('handleServerMessage',_0x4fc346,_0x12df80),_0x4fc346==='d'?this['onDataUpdate_'](_0x12df80['p'],_0x12df80['d'],!0x1,_0x12df80['t']):_0x4fc346==='m'?this['onDataUpdate_'](_0x12df80['p'],_0x12df80['d'],!0x0,_0x12df80['t']):_0x4fc346==='c'?this['onListenRevoked_'](_0x12df80['p'],_0x12df80['q']):_0x4fc346==='ac'?this['onAuthRevoked_'](_0x12df80['s'],_0x12df80['d']):_0x4fc346==='apc'?this['onAppCheckRevoked_'](_0x12df80['s'],_0x12df80['d']):_0x4fc346==='sd'?this['onSecurityDebugPacket_'](_0x12df80):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x4fc346)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x3a7c08,_0x5da180){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x3a7c08),this['lastSessionId']=_0x5da180,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x299947){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x299947));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x560a25){_0x560a25&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x560a25;}['onOnline_'](_0x263fd7){_0x263fd7?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x1aa5de=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x26db45=Math['max'](0x0,this['reconnectDelay_']-_0x1aa5de);_0x26db45=Math['random']()*_0x26db45,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x26db45+'ms'),this['scheduleConnect_'](_0x26db45),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x2e340c=this['onDataMessage_']['bind'](this),_0x41c64d=this['onReady_']['bind'](this),_0x33c79e=this['onRealtimeDisconnect_']['bind'](this),_0x217406=this['id']+':'+se['nextConnectionId_']++,_0x3ce4ae=this['lastSessionId'];let _0x1c8c0d=!0x1,_0x235954=null;const _0x210006=function(){_0x235954?_0x235954['close']():(_0x1c8c0d=!0x0,_0x33c79e());},_0x475ad0=function(_0x1d40ef){f(_0x235954,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x235954['sendRequest'](_0x1d40ef);};this['realtime_']={'close':_0x210006,'sendRequest':_0x475ad0};const _0x283c86=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x4bc3e2,_0x9b77e9]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x283c86),this['appCheckTokenProvider_']['getToken'](_0x283c86)]);_0x1c8c0d?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x4bc3e2&&_0x4bc3e2['accessToken'],this['appCheckToken_']=_0x9b77e9&&_0x9b77e9['token'],_0x235954=new Sh(_0x217406,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x2e340c,_0x41c64d,_0x33c79e,_0x185bec=>{U(_0x185bec+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x3ce4ae));}catch(_0x373e02){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x373e02),_0x1c8c0d||(this['repoInfo_']['nodeAdmin']&&U(_0x373e02),_0x210006());}}}['interrupt'](_0x129c48){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x129c48),this['interruptReasons_'][_0x129c48]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x52da75){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x52da75),delete this['interruptReasons_'][_0x52da75],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x5afddf){const _0x1aae19=_0x5afddf-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x1aae19});}['cancelSentTransactions_'](){for(let _0x7ff687=0x0;_0x7ff687<this['outstandingPuts_']['length'];_0x7ff687++){const _0x3b0166=this['outstandingPuts_'][_0x7ff687];_0x3b0166&&'h'in _0x3b0166['request']&&_0x3b0166['queued']&&(_0x3b0166['onComplete']&&_0x3b0166['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x7ff687],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x5ca598,_0x2c8cac){let _0x42a84b;_0x2c8cac?_0x42a84b=_0x2c8cac['map'](_0x4d2fc0=>Hi(_0x4d2fc0))['join']('$'):_0x42a84b='default';const _0x4f81a5=this['removeListen_'](_0x5ca598,_0x42a84b);_0x4f81a5&&_0x4f81a5['onComplete']&&_0x4f81a5['onComplete']('permission_denied');}['removeListen_'](_0x1aeb98,_0x28ae31){const _0x33f36f=new C(_0x1aeb98)['toString']();let _0x28849e;if(this['listens']['has'](_0x33f36f)){const _0xbe08e3=this['listens']['get'](_0x33f36f);_0x28849e=_0xbe08e3['get'](_0x28ae31),_0xbe08e3['delete'](_0x28ae31),_0xbe08e3['size']===0x0&&this['listens']['delete'](_0x33f36f);}else _0x28849e=void 0x0;return _0x28849e;}['onAuthRevoked_'](_0x51be4f,_0x2f737d){L('Auth\x20token\x20revoked:\x20'+_0x51be4f+'/'+_0x2f737d),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x51be4f==='invalid_token'||_0x51be4f==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x39a5ce,_0x337897){L('App\x20check\x20token\x20revoked:\x20'+_0x39a5ce+'/'+_0x337897),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x39a5ce==='invalid_token'||_0x39a5ce==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x1658c2){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x1658c2):'msg'in _0x1658c2&&console['log']('FIREBASE:\x20'+_0x1658c2['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x470f2b of this['listens']['values']())for(const _0x17386e of _0x470f2b['values']())this['sendListen_'](_0x17386e);for(let _0x5f42e4=0x0;_0x5f42e4<this['outstandingPuts_']['length'];_0x5f42e4++)this['outstandingPuts_'][_0x5f42e4]&&this['sendPut_'](_0x5f42e4);for(;this['onDisconnectRequestQueue_']['length'];){const _0x176770=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x176770['action'],_0x176770['pathString'],_0x176770['data'],_0x176770['onComplete']);}for(let _0x47e2e7=0x0;_0x47e2e7<this['outstandingGets_']['length'];_0x47e2e7++)this['outstandingGets_'][_0x47e2e7]&&this['sendGet_'](_0x47e2e7);}['sendConnectStats_'](){const _0x32f5f6={};let _0x1985eb='js';_0x32f5f6['sdk.'+_0x1985eb+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x32f5f6['framework.cordova']=0x1:Yr()&&(_0x32f5f6['framework.reactnative']=0x1),this['reportStats'](_0x32f5f6);}['shouldReconnect_'](){const _0x4ebb97=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x4ebb97;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x4e249a,_0x479282){this['name']=_0x4e249a,this['node']=_0x479282;}static['Wrap'](_0x2883bf,_0x1b6f16){return new E(_0x2883bf,_0x1b6f16);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x56787a,_0x29fa6e){const _0x3c2574=new E(Fe,_0x56787a),_0x1c33f8=new E(Fe,_0x29fa6e);return this['compare'](_0x3c2574,_0x1c33f8)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x23d7e3){Zt=_0x23d7e3;}['compare'](_0x41dcfb,_0x232ec8){return He(_0x41dcfb['name'],_0x232ec8['name']);}['isDefinedOn'](_0x129924){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0xc48ffa,_0x1b5ce4){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x49a6cd,_0x3f7bdc){return f(typeof _0x49a6cd=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x49a6cd,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x153625,_0x1ed08f,_0x591578,_0x4f48cf,_0x343a89=null){this['isReverse_']=_0x4f48cf,this['resultGenerator_']=_0x343a89,this['nodeStack_']=[];let _0x164c1a=0x1;for(;!_0x153625['isEmpty']();)if(_0x153625=_0x153625,_0x164c1a=_0x1ed08f?_0x591578(_0x153625['key'],_0x1ed08f):0x1,_0x4f48cf&&(_0x164c1a*=-0x1),_0x164c1a<0x0)this['isReverse_']?_0x153625=_0x153625['left']:_0x153625=_0x153625['right'];else{if(_0x164c1a===0x0){this['nodeStack_']['push'](_0x153625);break;}else this['nodeStack_']['push'](_0x153625),this['isReverse_']?_0x153625=_0x153625['right']:_0x153625=_0x153625['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x330dd8=this['nodeStack_']['pop'](),_0x4176df;if(this['resultGenerator_']?_0x4176df=this['resultGenerator_'](_0x330dd8['key'],_0x330dd8['value']):_0x4176df={'key':_0x330dd8['key'],'value':_0x330dd8['value']},this['isReverse_']){for(_0x330dd8=_0x330dd8['left'];!_0x330dd8['isEmpty']();)this['nodeStack_']['push'](_0x330dd8),_0x330dd8=_0x330dd8['right'];}else{for(_0x330dd8=_0x330dd8['right'];!_0x330dd8['isEmpty']();)this['nodeStack_']['push'](_0x330dd8),_0x330dd8=_0x330dd8['left'];}return _0x4176df;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x4d0451=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x4d0451['key'],_0x4d0451['value']):{'key':_0x4d0451['key'],'value':_0x4d0451['value']};}}class M{constructor(_0x196dc4,_0x47577d,_0x422fe5,_0x15f8b9,_0xebb809){this['key']=_0x196dc4,this['value']=_0x47577d,this['color']=_0x422fe5??M['RED'],this['left']=_0x15f8b9??B['EMPTY_NODE'],this['right']=_0xebb809??B['EMPTY_NODE'];}['copy'](_0x3081db,_0x55090a,_0x1b1d0a,_0x4bc59c,_0x4a02af){return new M(_0x3081db??this['key'],_0x55090a??this['value'],_0x1b1d0a??this['color'],_0x4bc59c??this['left'],_0x4a02af??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x5797dc){return this['left']['inorderTraversal'](_0x5797dc)||!!_0x5797dc(this['key'],this['value'])||this['right']['inorderTraversal'](_0x5797dc);}['reverseTraversal'](_0x3c4896){return this['right']['reverseTraversal'](_0x3c4896)||_0x3c4896(this['key'],this['value'])||this['left']['reverseTraversal'](_0x3c4896);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x4cb291,_0x39d901,_0x152c2b){let _0x9607f1=this;const _0xa6c852=_0x152c2b(_0x4cb291,_0x9607f1['key']);return _0xa6c852<0x0?_0x9607f1=_0x9607f1['copy'](null,null,null,_0x9607f1['left']['insert'](_0x4cb291,_0x39d901,_0x152c2b),null):_0xa6c852===0x0?_0x9607f1=_0x9607f1['copy'](null,_0x39d901,null,null,null):_0x9607f1=_0x9607f1['copy'](null,null,null,null,_0x9607f1['right']['insert'](_0x4cb291,_0x39d901,_0x152c2b)),_0x9607f1['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x39c100=this;return!_0x39c100['left']['isRed_']()&&!_0x39c100['left']['left']['isRed_']()&&(_0x39c100=_0x39c100['moveRedLeft_']()),_0x39c100=_0x39c100['copy'](null,null,null,_0x39c100['left']['removeMin_'](),null),_0x39c100['fixUp_']();}['remove'](_0x22ec31,_0x57b588){let _0x371283,_0x35267b;if(_0x371283=this,_0x57b588(_0x22ec31,_0x371283['key'])<0x0)!_0x371283['left']['isEmpty']()&&!_0x371283['left']['isRed_']()&&!_0x371283['left']['left']['isRed_']()&&(_0x371283=_0x371283['moveRedLeft_']()),_0x371283=_0x371283['copy'](null,null,null,_0x371283['left']['remove'](_0x22ec31,_0x57b588),null);else{if(_0x371283['left']['isRed_']()&&(_0x371283=_0x371283['rotateRight_']()),!_0x371283['right']['isEmpty']()&&!_0x371283['right']['isRed_']()&&!_0x371283['right']['left']['isRed_']()&&(_0x371283=_0x371283['moveRedRight_']()),_0x57b588(_0x22ec31,_0x371283['key'])===0x0){if(_0x371283['right']['isEmpty']())return B['EMPTY_NODE'];_0x35267b=_0x371283['right']['min_'](),_0x371283=_0x371283['copy'](_0x35267b['key'],_0x35267b['value'],null,null,_0x371283['right']['removeMin_']());}_0x371283=_0x371283['copy'](null,null,null,null,_0x371283['right']['remove'](_0x22ec31,_0x57b588));}return _0x371283['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x43f8d6=this;return _0x43f8d6['right']['isRed_']()&&!_0x43f8d6['left']['isRed_']()&&(_0x43f8d6=_0x43f8d6['rotateLeft_']()),_0x43f8d6['left']['isRed_']()&&_0x43f8d6['left']['left']['isRed_']()&&(_0x43f8d6=_0x43f8d6['rotateRight_']()),_0x43f8d6['left']['isRed_']()&&_0x43f8d6['right']['isRed_']()&&(_0x43f8d6=_0x43f8d6['colorFlip_']()),_0x43f8d6;}['moveRedLeft_'](){let _0x47fb54=this['colorFlip_']();return _0x47fb54['right']['left']['isRed_']()&&(_0x47fb54=_0x47fb54['copy'](null,null,null,null,_0x47fb54['right']['rotateRight_']()),_0x47fb54=_0x47fb54['rotateLeft_'](),_0x47fb54=_0x47fb54['colorFlip_']()),_0x47fb54;}['moveRedRight_'](){let _0x15a2ba=this['colorFlip_']();return _0x15a2ba['left']['left']['isRed_']()&&(_0x15a2ba=_0x15a2ba['rotateRight_'](),_0x15a2ba=_0x15a2ba['colorFlip_']()),_0x15a2ba;}['rotateLeft_'](){const _0x42f1af=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x42f1af,null);}['rotateRight_'](){const _0x332c4c=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x332c4c);}['colorFlip_'](){const _0x523908=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x3f3619=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x523908,_0x3f3619);}['checkMaxDepth_'](){const _0x53a0f2=this['check_']();return Math['pow'](0x2,_0x53a0f2)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x5a9e49=this['left']['check_']();if(_0x5a9e49!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x5a9e49+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x372d4b,_0x4c90a0,_0x142d52,_0x352066,_0x3c924c){return this;}['insert'](_0x3633d8,_0x2c99dc,_0x2e072b){return new M(_0x3633d8,_0x2c99dc,null);}['remove'](_0x4ff590,_0x46dd57){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0xd64c1d){return!0x1;}['reverseTraversal'](_0x675019){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x185ce3,_0x261fbb=B['EMPTY_NODE']){this['comparator_']=_0x185ce3,this['root_']=_0x261fbb;}['insert'](_0x7d7b8,_0x3d92e2){return new B(this['comparator_'],this['root_']['insert'](_0x7d7b8,_0x3d92e2,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x32c2e9){return new B(this['comparator_'],this['root_']['remove'](_0x32c2e9,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x5dff47){let _0x1a7e57,_0x26557f=this['root_'];for(;!_0x26557f['isEmpty']();){if(_0x1a7e57=this['comparator_'](_0x5dff47,_0x26557f['key']),_0x1a7e57===0x0)return _0x26557f['value'];_0x1a7e57<0x0?_0x26557f=_0x26557f['left']:_0x1a7e57>0x0&&(_0x26557f=_0x26557f['right']);}return null;}['getPredecessorKey'](_0x50a499){let _0x528981,_0x3b4bd0=this['root_'],_0x57034e=null;for(;!_0x3b4bd0['isEmpty']();)if(_0x528981=this['comparator_'](_0x50a499,_0x3b4bd0['key']),_0x528981===0x0){if(_0x3b4bd0['left']['isEmpty']())return _0x57034e?_0x57034e['key']:null;for(_0x3b4bd0=_0x3b4bd0['left'];!_0x3b4bd0['right']['isEmpty']();)_0x3b4bd0=_0x3b4bd0['right'];return _0x3b4bd0['key'];}else _0x528981<0x0?_0x3b4bd0=_0x3b4bd0['left']:_0x528981>0x0&&(_0x57034e=_0x3b4bd0,_0x3b4bd0=_0x3b4bd0['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x16ecf4){return this['root_']['inorderTraversal'](_0x16ecf4);}['reverseTraversal'](_0x2c814a){return this['root_']['reverseTraversal'](_0x2c814a);}['getIterator'](_0x339473){return new en(this['root_'],null,this['comparator_'],!0x1,_0x339473);}['getIteratorFrom'](_0x30b7d1,_0x4f5797){return new en(this['root_'],_0x30b7d1,this['comparator_'],!0x1,_0x4f5797);}['getReverseIteratorFrom'](_0x237e7e,_0xd15e86){return new en(this['root_'],_0x237e7e,this['comparator_'],!0x0,_0xd15e86);}['getReverseIterator'](_0x4e822f){return new en(this['root_'],null,this['comparator_'],!0x0,_0x4e822f);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x467ae3,_0x1bc033){return He(_0x467ae3['name'],_0x1bc033['name']);}function Yi(_0x5366b8,_0x4c57ee){return He(_0x5366b8,_0x4c57ee);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x3053d6){Ei=_0x3053d6;}const No=function(_0x15654c){return typeof _0x15654c=='number'?'number:'+ao(_0x15654c):'string:'+_0x15654c;},Po=function(_0x6c9f40){if(_0x6c9f40['isLeafNode']()){const _0x52c16c=_0x6c9f40['val']();f(typeof _0x52c16c=='string'||typeof _0x52c16c=='number'||typeof _0x52c16c=='object'&&J(_0x52c16c,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x6c9f40===Ei||_0x6c9f40['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x6c9f40===Ei||_0x6c9f40['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x53b463){ir=_0x53b463;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x57f2fd,_0x66ae37=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x57f2fd,this['priorityNode_']=_0x66ae37,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x356f75){return new D(this['value_'],_0x356f75);}['getImmediateChild'](_0x26e24d){return _0x26e24d==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x17871c){return v(_0x17871c)?this:y(_0x17871c)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x222f05,_0xfbea1e){return null;}['updateImmediateChild'](_0x9632ff,_0x50f85f){return _0x9632ff==='.priority'?this['updatePriority'](_0x50f85f):_0x50f85f['isEmpty']()&&_0x9632ff!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x9632ff,_0x50f85f)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x207a05,_0x465b1d){const _0x3f9d68=y(_0x207a05);return _0x3f9d68===null?_0x465b1d:_0x465b1d['isEmpty']()&&_0x3f9d68!=='.priority'?this:(f(_0x3f9d68!=='.priority'||we(_0x207a05)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x3f9d68,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x207a05),_0x465b1d)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x152924,_0x3076d6){return!0x1;}['val'](_0x11e1a4){return _0x11e1a4&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x3090b7='';this['priorityNode_']['isEmpty']()||(_0x3090b7+='priority:'+No(this['priorityNode_']['val']())+':');const _0x2bdd6f=typeof this['value_'];_0x3090b7+=_0x2bdd6f+':',_0x2bdd6f==='number'?_0x3090b7+=ao(this['value_']):_0x3090b7+=this['value_'],this['lazyHash_']=ro(_0x3090b7);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x294bd9){return _0x294bd9===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x294bd9 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x294bd9['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x294bd9));}['compareToLeafNode_'](_0x47a70a){const _0x5beee4=typeof _0x47a70a['value_'],_0x4e3a07=typeof this['value_'],_0x42a6a5=D['VALUE_TYPE_ORDER']['indexOf'](_0x5beee4),_0x3ffedb=D['VALUE_TYPE_ORDER']['indexOf'](_0x4e3a07);return f(_0x42a6a5>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5beee4),f(_0x3ffedb>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4e3a07),_0x42a6a5===_0x3ffedb?_0x4e3a07==='object'?0x0:this['value_']<_0x47a70a['value_']?-0x1:this['value_']===_0x47a70a['value_']?0x0:0x1:_0x3ffedb-_0x42a6a5;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x39df90){if(_0x39df90===this)return!0x0;if(_0x39df90['isLeafNode']()){const _0x33ba41=_0x39df90;return this['value_']===_0x33ba41['value_']&&this['priorityNode_']['equals'](_0x33ba41['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x332dde){Oo=_0x332dde;}function Wh(_0x41c98a){Do=_0x41c98a;}class Bh extends Dn{['compare'](_0x1a72e1,_0x163fdf){const _0x5dc8a2=_0x1a72e1['node']['getPriority'](),_0x5bfe20=_0x163fdf['node']['getPriority'](),_0x3fe777=_0x5dc8a2['compareTo'](_0x5bfe20);return _0x3fe777===0x0?He(_0x1a72e1['name'],_0x163fdf['name']):_0x3fe777;}['isDefinedOn'](_0x56f28f){return!_0x56f28f['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x1bd255,_0x1fa344){return!_0x1bd255['getPriority']()['equals'](_0x1fa344['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x13d1be,_0x14739a){const _0x5d2103=Oo(_0x13d1be);return new E(_0x14739a,new D('[PRIORITY-POST]',_0x5d2103));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x460818){const _0x8a1cf3=_0x1e87c7=>parseInt(Math['log'](_0x1e87c7)/Vh,0xa),_0x329d22=_0xcb8a15=>parseInt(Array(_0xcb8a15+0x1)['join']('1'),0x2);this['count']=_0x8a1cf3(_0x460818+0x1),this['current_']=this['count']-0x1;const _0x295be6=_0x329d22(this['count']);this['bits_']=_0x460818+0x1&_0x295be6;}['nextBitIsOne'](){const _0x42392e=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x42392e;}}const fn=function(_0x3b867f,_0x46d04a,_0x5b2a5f,_0x30e7d7){_0x3b867f['sort'](_0x46d04a);const _0x5704f5=function(_0x15a528,_0x347054){const _0x31dc22=_0x347054-_0x15a528;let _0x1f1cb3,_0x465ee5;if(_0x31dc22===0x0)return null;if(_0x31dc22===0x1)return _0x1f1cb3=_0x3b867f[_0x15a528],_0x465ee5=_0x5b2a5f?_0x5b2a5f(_0x1f1cb3):_0x1f1cb3,new M(_0x465ee5,_0x1f1cb3['node'],M['BLACK'],null,null);{const _0x30d1ce=parseInt(_0x31dc22/0x2,0xa)+_0x15a528,_0x520eaf=_0x5704f5(_0x15a528,_0x30d1ce),_0x17a150=_0x5704f5(_0x30d1ce+0x1,_0x347054);return _0x1f1cb3=_0x3b867f[_0x30d1ce],_0x465ee5=_0x5b2a5f?_0x5b2a5f(_0x1f1cb3):_0x1f1cb3,new M(_0x465ee5,_0x1f1cb3['node'],M['BLACK'],_0x520eaf,_0x17a150);}},_0x408984=function(_0xef5ed7){let _0x15d39a=null,_0x52c4ad=null,_0x4fcb48=_0x3b867f['length'];const _0x34b0fe=function(_0x4c19cc,_0x56d319){const _0x19bb35=_0x4fcb48-_0x4c19cc,_0x47c5ee=_0x4fcb48;_0x4fcb48-=_0x4c19cc;const _0x4177c7=_0x5704f5(_0x19bb35+0x1,_0x47c5ee),_0x30c55a=_0x3b867f[_0x19bb35],_0x401033=_0x5b2a5f?_0x5b2a5f(_0x30c55a):_0x30c55a;_0x2adc65(new M(_0x401033,_0x30c55a['node'],_0x56d319,null,_0x4177c7));},_0x2adc65=function(_0xfdb04e){_0x15d39a?(_0x15d39a['left']=_0xfdb04e,_0x15d39a=_0xfdb04e):(_0x52c4ad=_0xfdb04e,_0x15d39a=_0xfdb04e);};for(let _0x23a730=0x0;_0x23a730<_0xef5ed7['count'];++_0x23a730){const _0x25177f=_0xef5ed7['nextBitIsOne'](),_0x59d296=Math['pow'](0x2,_0xef5ed7['count']-(_0x23a730+0x1));_0x25177f?_0x34b0fe(_0x59d296,M['BLACK']):(_0x34b0fe(_0x59d296,M['BLACK']),_0x34b0fe(_0x59d296,M['RED']));}return _0x52c4ad;},_0x47a95f=new Hh(_0x3b867f['length']),_0x2dabcf=_0x408984(_0x47a95f);return new B(_0x30e7d7||_0x46d04a,_0x2dabcf);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x27a048,_0x180f08){this['indexes_']=_0x27a048,this['indexSet_']=_0x180f08;}['get'](_0x1e9dba){const _0x2e8eab=De(this['indexes_'],_0x1e9dba);if(!_0x2e8eab)throw new Error('No\x20index\x20defined\x20for\x20'+_0x1e9dba);return _0x2e8eab instanceof B?_0x2e8eab:null;}['hasIndex'](_0x359d9a){return J(this['indexSet_'],_0x359d9a['toString']());}['addIndex'](_0x1b8b71,_0x5491d9){f(_0x1b8b71!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x90544f=[];let _0x52a9f4=!0x1;const _0x1d7398=_0x5491d9['getIterator'](E['Wrap']);let _0x50e792=_0x1d7398['getNext']();for(;_0x50e792;)_0x52a9f4=_0x52a9f4||_0x1b8b71['isDefinedOn'](_0x50e792['node']),_0x90544f['push'](_0x50e792),_0x50e792=_0x1d7398['getNext']();let _0xc98668;_0x52a9f4?_0xc98668=fn(_0x90544f,_0x1b8b71['getCompare']()):_0xc98668=ze;const _0x4d4f21=_0x1b8b71['toString'](),_0x1616c3={...this['indexSet_']};_0x1616c3[_0x4d4f21]=_0x1b8b71;const _0x3dc837={...this['indexes_']};return _0x3dc837[_0x4d4f21]=_0xc98668,new te(_0x3dc837,_0x1616c3);}['addToIndexes'](_0x34f9ac,_0x58b97c){const _0x183400=hn(this['indexes_'],(_0xc44695,_0x43e746)=>{const _0x2bd8d6=De(this['indexSet_'],_0x43e746);if(f(_0x2bd8d6,'Missing\x20index\x20implementation\x20for\x20'+_0x43e746),_0xc44695===ze){if(_0x2bd8d6['isDefinedOn'](_0x34f9ac['node'])){const _0x299d99=[],_0x4d072d=_0x58b97c['getIterator'](E['Wrap']);let _0x4c3f40=_0x4d072d['getNext']();for(;_0x4c3f40;)_0x4c3f40['name']!==_0x34f9ac['name']&&_0x299d99['push'](_0x4c3f40),_0x4c3f40=_0x4d072d['getNext']();return _0x299d99['push'](_0x34f9ac),fn(_0x299d99,_0x2bd8d6['getCompare']());}else return ze;}else{const _0x49f537=_0x58b97c['get'](_0x34f9ac['name']);let _0x4cc7c3=_0xc44695;return _0x49f537&&(_0x4cc7c3=_0x4cc7c3['remove'](new E(_0x34f9ac['name'],_0x49f537))),_0x4cc7c3['insert'](_0x34f9ac,_0x34f9ac['node']);}});return new te(_0x183400,this['indexSet_']);}['removeFromIndexes'](_0x5416fe,_0x59cf92){const _0x3e81dd=hn(this['indexes_'],_0x91776f=>{if(_0x91776f===ze)return _0x91776f;{const _0x542c35=_0x59cf92['get'](_0x5416fe['name']);return _0x542c35?_0x91776f['remove'](new E(_0x5416fe['name'],_0x542c35)):_0x91776f;}});return new te(_0x3e81dd,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x47bef9,_0x277732,_0x19adda){this['children_']=_0x47bef9,this['priorityNode_']=_0x277732,this['indexMap_']=_0x19adda,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x53cce2){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x53cce2,this['indexMap_']);}['getImmediateChild'](_0x46fd48){if(_0x46fd48==='.priority')return this['getPriority']();{const _0x459fd0=this['children_']['get'](_0x46fd48);return _0x459fd0===null?mt:_0x459fd0;}}['getChild'](_0x5e2569){const _0xddaa53=y(_0x5e2569);return _0xddaa53===null?this:this['getImmediateChild'](_0xddaa53)['getChild'](b(_0x5e2569));}['hasChild'](_0x1f2d67){return this['children_']['get'](_0x1f2d67)!==null;}['updateImmediateChild'](_0x38739c,_0x46deb9){if(f(_0x46deb9,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x38739c==='.priority')return this['updatePriority'](_0x46deb9);{const _0x396d0a=new E(_0x38739c,_0x46deb9);let _0x8efbc4,_0x17239e;_0x46deb9['isEmpty']()?(_0x8efbc4=this['children_']['remove'](_0x38739c),_0x17239e=this['indexMap_']['removeFromIndexes'](_0x396d0a,this['children_'])):(_0x8efbc4=this['children_']['insert'](_0x38739c,_0x46deb9),_0x17239e=this['indexMap_']['addToIndexes'](_0x396d0a,this['children_']));const _0x1de867=_0x8efbc4['isEmpty']()?mt:this['priorityNode_'];return new g(_0x8efbc4,_0x1de867,_0x17239e);}}['updateChild'](_0x4011ac,_0x4012f7){const _0x18a974=y(_0x4011ac);if(_0x18a974===null)return _0x4012f7;{f(y(_0x4011ac)!=='.priority'||we(_0x4011ac)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x28eb01=this['getImmediateChild'](_0x18a974)['updateChild'](b(_0x4011ac),_0x4012f7);return this['updateImmediateChild'](_0x18a974,_0x28eb01);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x794417){if(this['isEmpty']())return null;const _0x3df115={};let _0x474113=0x0,_0x3ff213=0x0,_0x13d759=!0x0;if(this['forEachChild'](R,(_0x124ff0,_0x2cc396)=>{_0x3df115[_0x124ff0]=_0x2cc396['val'](_0x794417),_0x474113++,_0x13d759&&g['INTEGER_REGEXP_']['test'](_0x124ff0)?_0x3ff213=Math['max'](_0x3ff213,Number(_0x124ff0)):_0x13d759=!0x1;}),!_0x794417&&_0x13d759&&_0x3ff213<0x2*_0x474113){const _0x36e8f8=[];for(const _0x3c191f in _0x3df115)_0x36e8f8[_0x3c191f]=_0x3df115[_0x3c191f];return _0x36e8f8;}else return _0x794417&&!this['getPriority']()['isEmpty']()&&(_0x3df115['.priority']=this['getPriority']()['val']()),_0x3df115;}['hash'](){if(this['lazyHash_']===null){let _0x911ec6='';this['getPriority']()['isEmpty']()||(_0x911ec6+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x21039f,_0x3913f4)=>{const _0x546d7c=_0x3913f4['hash']();_0x546d7c!==''&&(_0x911ec6+=':'+_0x21039f+':'+_0x546d7c);}),this['lazyHash_']=_0x911ec6===''?'':ro(_0x911ec6);}return this['lazyHash_'];}['getPredecessorChildName'](_0x5be694,_0x50d937,_0x334c41){const _0x189e56=this['resolveIndex_'](_0x334c41);if(_0x189e56){const _0x1a0624=_0x189e56['getPredecessorKey'](new E(_0x5be694,_0x50d937));return _0x1a0624?_0x1a0624['name']:null;}else return this['children_']['getPredecessorKey'](_0x5be694);}['getFirstChildName'](_0x2a1eae){const _0x2952e5=this['resolveIndex_'](_0x2a1eae);if(_0x2952e5){const _0x39d999=_0x2952e5['minKey']();return _0x39d999&&_0x39d999['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x3dd0f7){const _0x33fdb1=this['getFirstChildName'](_0x3dd0f7);return _0x33fdb1?new E(_0x33fdb1,this['children_']['get'](_0x33fdb1)):null;}['getLastChildName'](_0x47460e){const _0x52dd95=this['resolveIndex_'](_0x47460e);if(_0x52dd95){const _0x5b43a7=_0x52dd95['maxKey']();return _0x5b43a7&&_0x5b43a7['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x39ac5c){const _0xa3f9eb=this['getLastChildName'](_0x39ac5c);return _0xa3f9eb?new E(_0xa3f9eb,this['children_']['get'](_0xa3f9eb)):null;}['forEachChild'](_0x4a1222,_0x5ff1c3){const _0x1beedf=this['resolveIndex_'](_0x4a1222);return _0x1beedf?_0x1beedf['inorderTraversal'](_0x55d283=>_0x5ff1c3(_0x55d283['name'],_0x55d283['node'])):this['children_']['inorderTraversal'](_0x5ff1c3);}['getIterator'](_0x4e2a37){return this['getIteratorFrom'](_0x4e2a37['minPost'](),_0x4e2a37);}['getIteratorFrom'](_0x4aedf9,_0x127eb1){const _0x3dec87=this['resolveIndex_'](_0x127eb1);if(_0x3dec87)return _0x3dec87['getIteratorFrom'](_0x4aedf9,_0x2baaba=>_0x2baaba);{const _0x2c063a=this['children_']['getIteratorFrom'](_0x4aedf9['name'],E['Wrap']);let _0x17046a=_0x2c063a['peek']();for(;_0x17046a!=null&&_0x127eb1['compare'](_0x17046a,_0x4aedf9)<0x0;)_0x2c063a['getNext'](),_0x17046a=_0x2c063a['peek']();return _0x2c063a;}}['getReverseIterator'](_0x5b6c53){return this['getReverseIteratorFrom'](_0x5b6c53['maxPost'](),_0x5b6c53);}['getReverseIteratorFrom'](_0x482c40,_0x4aa533){const _0x595170=this['resolveIndex_'](_0x4aa533);if(_0x595170)return _0x595170['getReverseIteratorFrom'](_0x482c40,_0x388ab7=>_0x388ab7);{const _0x1b03ae=this['children_']['getReverseIteratorFrom'](_0x482c40['name'],E['Wrap']);let _0xe44c6d=_0x1b03ae['peek']();for(;_0xe44c6d!=null&&_0x4aa533['compare'](_0xe44c6d,_0x482c40)>0x0;)_0x1b03ae['getNext'](),_0xe44c6d=_0x1b03ae['peek']();return _0x1b03ae;}}['compareTo'](_0x24c1b7){return this['isEmpty']()?_0x24c1b7['isEmpty']()?0x0:-0x1:_0x24c1b7['isLeafNode']()||_0x24c1b7['isEmpty']()?0x1:_0x24c1b7===$t?-0x1:0x0;}['withIndex'](_0x16fbce){if(_0x16fbce===ye||this['indexMap_']['hasIndex'](_0x16fbce))return this;{const _0x23d5e5=this['indexMap_']['addIndex'](_0x16fbce,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x23d5e5);}}['isIndexed'](_0x35e449){return _0x35e449===ye||this['indexMap_']['hasIndex'](_0x35e449);}['equals'](_0x2b8c70){if(_0x2b8c70===this)return!0x0;if(_0x2b8c70['isLeafNode']())return!0x1;{const _0x48bc22=_0x2b8c70;if(this['getPriority']()['equals'](_0x48bc22['getPriority']())){if(this['children_']['count']()===_0x48bc22['children_']['count']()){const _0x406bdb=this['getIterator'](R),_0x1a5959=_0x48bc22['getIterator'](R);let _0x4db8af=_0x406bdb['getNext'](),_0x539add=_0x1a5959['getNext']();for(;_0x4db8af&&_0x539add;){if(_0x4db8af['name']!==_0x539add['name']||!_0x4db8af['node']['equals'](_0x539add['node']))return!0x1;_0x4db8af=_0x406bdb['getNext'](),_0x539add=_0x1a5959['getNext']();}return _0x4db8af===null&&_0x539add===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x1141cc){return _0x1141cc===ye?null:this['indexMap_']['get'](_0x1141cc['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x15ee65){return _0x15ee65===this?0x0:0x1;}['equals'](_0x5d6ad6){return _0x5d6ad6===this;}['getPriority'](){return this;}['getImmediateChild'](_0x2798d8){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x4b3c7d,_0x3e6843=null){if(_0x4b3c7d===null)return g['EMPTY_NODE'];if(typeof _0x4b3c7d=='object'&&'.priority'in _0x4b3c7d&&(_0x3e6843=_0x4b3c7d['.priority']),f(_0x3e6843===null||typeof _0x3e6843=='string'||typeof _0x3e6843=='number'||typeof _0x3e6843=='object'&&'.sv'in _0x3e6843,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x3e6843),typeof _0x4b3c7d=='object'&&'.value'in _0x4b3c7d&&_0x4b3c7d['.value']!==null&&(_0x4b3c7d=_0x4b3c7d['.value']),typeof _0x4b3c7d!='object'||'.sv'in _0x4b3c7d){const _0x2c9493=_0x4b3c7d;return new D(_0x2c9493,P(_0x3e6843));}if(!(_0x4b3c7d instanceof Array)&&Gh){const _0x409306=[];let _0x24b058=!0x1;if(x(_0x4b3c7d,(_0x1c294f,_0x335e18)=>{if(_0x1c294f['substring'](0x0,0x1)!=='.'){const _0x4e8024=P(_0x335e18);_0x4e8024['isEmpty']()||(_0x24b058=_0x24b058||!_0x4e8024['getPriority']()['isEmpty'](),_0x409306['push'](new E(_0x1c294f,_0x4e8024)));}}),_0x409306['length']===0x0)return g['EMPTY_NODE'];const _0x213532=fn(_0x409306,xh,_0x1f6ce9=>_0x1f6ce9['name'],Yi);if(_0x24b058){const _0x63d97f=fn(_0x409306,R['getCompare']());return new g(_0x213532,P(_0x3e6843),new te({'.priority':_0x63d97f},{'.priority':R}));}else return new g(_0x213532,P(_0x3e6843),te['Default']);}else{let _0x4b8b84=g['EMPTY_NODE'];return x(_0x4b3c7d,(_0x2413c7,_0x5ee5ed)=>{if(J(_0x4b3c7d,_0x2413c7)&&_0x2413c7['substring'](0x0,0x1)!=='.'){const _0x9ce982=P(_0x5ee5ed);(_0x9ce982['isLeafNode']()||!_0x9ce982['isEmpty']())&&(_0x4b8b84=_0x4b8b84['updateImmediateChild'](_0x2413c7,_0x9ce982));}}),_0x4b8b84['updatePriority'](P(_0x3e6843));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x38c078){super(),this['indexPath_']=_0x38c078,f(!v(_0x38c078)&&y(_0x38c078)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x39af3c){return _0x39af3c['getChild'](this['indexPath_']);}['isDefinedOn'](_0x284335){return!_0x284335['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x2576fc,_0x4394e2){const _0x42c512=this['extractChild'](_0x2576fc['node']),_0x19c9d3=this['extractChild'](_0x4394e2['node']),_0x415ab1=_0x42c512['compareTo'](_0x19c9d3);return _0x415ab1===0x0?He(_0x2576fc['name'],_0x4394e2['name']):_0x415ab1;}['makePost'](_0x39e169,_0x1f795f){const _0x171d10=P(_0x39e169),_0x27a48c=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x171d10);return new E(_0x1f795f,_0x27a48c);}['maxPost'](){const _0x5d9300=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x5d9300);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0xfb6fa0,_0xb09087){const _0x54529a=_0xfb6fa0['node']['compareTo'](_0xb09087['node']);return _0x54529a===0x0?He(_0xfb6fa0['name'],_0xb09087['name']):_0x54529a;}['isDefinedOn'](_0xf080ab){return!0x0;}['indexedValueChanged'](_0x4b1b30,_0x1b1fa5){return!_0x4b1b30['equals'](_0x1b1fa5);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x57b45a,_0x26f629){const _0x56e3d4=P(_0x57b45a);return new E(_0x26f629,_0x56e3d4);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x53ea8a){return{'type':'value','snapshotNode':_0x53ea8a};}function et(_0x456aef,_0x389bf6){return{'type':'child_added','snapshotNode':_0x389bf6,'childName':_0x456aef};}function Ot(_0x16306b,_0xdc1aac){return{'type':'child_removed','snapshotNode':_0xdc1aac,'childName':_0x16306b};}function Dt(_0x32de68,_0x1c8855,_0x593941){return{'type':'child_changed','snapshotNode':_0x1c8855,'childName':_0x32de68,'oldSnap':_0x593941};}function zh(_0x54c5da,_0x4ce37d){return{'type':'child_moved','snapshotNode':_0x4ce37d,'childName':_0x54c5da};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x2b80d7){this['index_']=_0x2b80d7;}['updateChild'](_0x789019,_0x452db5,_0x317171,_0x36d4a9,_0x48bbb6,_0x5948fb){f(_0x789019['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x549276=_0x789019['getImmediateChild'](_0x452db5);return _0x549276['getChild'](_0x36d4a9)['equals'](_0x317171['getChild'](_0x36d4a9))&&_0x549276['isEmpty']()===_0x317171['isEmpty']()||(_0x5948fb!=null&&(_0x317171['isEmpty']()?_0x789019['hasChild'](_0x452db5)?_0x5948fb['trackChildChange'](Ot(_0x452db5,_0x549276)):f(_0x789019['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x549276['isEmpty']()?_0x5948fb['trackChildChange'](et(_0x452db5,_0x317171)):_0x5948fb['trackChildChange'](Dt(_0x452db5,_0x317171,_0x549276))),_0x789019['isLeafNode']()&&_0x317171['isEmpty']())?_0x789019:_0x789019['updateImmediateChild'](_0x452db5,_0x317171)['withIndex'](this['index_']);}['updateFullNode'](_0x2f6861,_0x31eb15,_0x5bb970){return _0x5bb970!=null&&(_0x2f6861['isLeafNode']()||_0x2f6861['forEachChild'](R,(_0x4ef55e,_0x157b88)=>{_0x31eb15['hasChild'](_0x4ef55e)||_0x5bb970['trackChildChange'](Ot(_0x4ef55e,_0x157b88));}),_0x31eb15['isLeafNode']()||_0x31eb15['forEachChild'](R,(_0x514e78,_0x268641)=>{if(_0x2f6861['hasChild'](_0x514e78)){const _0x2518be=_0x2f6861['getImmediateChild'](_0x514e78);_0x2518be['equals'](_0x268641)||_0x5bb970['trackChildChange'](Dt(_0x514e78,_0x268641,_0x2518be));}else _0x5bb970['trackChildChange'](et(_0x514e78,_0x268641));})),_0x31eb15['withIndex'](this['index_']);}['updatePriority'](_0x265354,_0x14a7dc){return _0x265354['isEmpty']()?g['EMPTY_NODE']:_0x265354['updatePriority'](_0x14a7dc);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x4528e7){this['indexedFilter_']=new Ji(_0x4528e7['getIndex']()),this['index_']=_0x4528e7['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x4528e7),this['endPost_']=Mt['getEndPost_'](_0x4528e7),this['startIsInclusive_']=!_0x4528e7['startAfterSet_'],this['endIsInclusive_']=!_0x4528e7['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x57e786){const _0x4447fb=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x57e786)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x57e786)<0x0,_0x417ddc=this['endIsInclusive_']?this['index_']['compare'](_0x57e786,this['getEndPost']())<=0x0:this['index_']['compare'](_0x57e786,this['getEndPost']())<0x0;return _0x4447fb&&_0x417ddc;}['updateChild'](_0x30290e,_0x59dc8b,_0x51ab45,_0x175c51,_0x28dffe,_0x28c7b3){return this['matches'](new E(_0x59dc8b,_0x51ab45))||(_0x51ab45=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x30290e,_0x59dc8b,_0x51ab45,_0x175c51,_0x28dffe,_0x28c7b3);}['updateFullNode'](_0x3b621f,_0x17b941,_0x4d09){_0x17b941['isLeafNode']()&&(_0x17b941=g['EMPTY_NODE']);let _0x3f98cc=_0x17b941['withIndex'](this['index_']);_0x3f98cc=_0x3f98cc['updatePriority'](g['EMPTY_NODE']);const _0x40c4c0=this;return _0x17b941['forEachChild'](R,(_0x4e1700,_0x28643d)=>{_0x40c4c0['matches'](new E(_0x4e1700,_0x28643d))||(_0x3f98cc=_0x3f98cc['updateImmediateChild'](_0x4e1700,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x3b621f,_0x3f98cc,_0x4d09);}['updatePriority'](_0x1818a2,_0x243e20){return _0x1818a2;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0xd4ff69){if(_0xd4ff69['hasStart']()){const _0x5483dd=_0xd4ff69['getIndexStartName']();return _0xd4ff69['getIndex']()['makePost'](_0xd4ff69['getIndexStartValue'](),_0x5483dd);}else return _0xd4ff69['getIndex']()['minPost']();}static['getEndPost_'](_0x3670e1){if(_0x3670e1['hasEnd']()){const _0x59164a=_0x3670e1['getIndexEndName']();return _0x3670e1['getIndex']()['makePost'](_0x3670e1['getIndexEndValue'](),_0x59164a);}else return _0x3670e1['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x2ac456){this['withinDirectionalStart']=_0x5f2738=>this['reverse_']?this['withinEndPost'](_0x5f2738):this['withinStartPost'](_0x5f2738),this['withinDirectionalEnd']=_0x4a26be=>this['reverse_']?this['withinStartPost'](_0x4a26be):this['withinEndPost'](_0x4a26be),this['withinStartPost']=_0x1b65c8=>{const _0x38f1d4=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x1b65c8);return this['startIsInclusive_']?_0x38f1d4<=0x0:_0x38f1d4<0x0;},this['withinEndPost']=_0x1b2ec0=>{const _0x32a29f=this['index_']['compare'](_0x1b2ec0,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x32a29f<=0x0:_0x32a29f<0x0;},this['rangedFilter_']=new Mt(_0x2ac456),this['index_']=_0x2ac456['getIndex'](),this['limit_']=_0x2ac456['getLimit'](),this['reverse_']=!_0x2ac456['isViewFromLeft'](),this['startIsInclusive_']=!_0x2ac456['startAfterSet_'],this['endIsInclusive_']=!_0x2ac456['endBeforeSet_'];}['updateChild'](_0x2ba237,_0x456dd4,_0x200fbd,_0x24414f,_0xc473a8,_0x2916f1){return this['rangedFilter_']['matches'](new E(_0x456dd4,_0x200fbd))||(_0x200fbd=g['EMPTY_NODE']),_0x2ba237['getImmediateChild'](_0x456dd4)['equals'](_0x200fbd)?_0x2ba237:_0x2ba237['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x2ba237,_0x456dd4,_0x200fbd,_0x24414f,_0xc473a8,_0x2916f1):this['fullLimitUpdateChild_'](_0x2ba237,_0x456dd4,_0x200fbd,_0xc473a8,_0x2916f1);}['updateFullNode'](_0xbf78a1,_0x24483d,_0x4a2e7f){let _0x2b9750;if(_0x24483d['isLeafNode']()||_0x24483d['isEmpty']())_0x2b9750=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x24483d['numChildren']()&&_0x24483d['isIndexed'](this['index_'])){_0x2b9750=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x1f7427;this['reverse_']?_0x1f7427=_0x24483d['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x1f7427=_0x24483d['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x2946f2=0x0;for(;_0x1f7427['hasNext']()&&_0x2946f2<this['limit_'];){const _0x34900a=_0x1f7427['getNext']();if(this['withinDirectionalStart'](_0x34900a)){if(this['withinDirectionalEnd'](_0x34900a))_0x2b9750=_0x2b9750['updateImmediateChild'](_0x34900a['name'],_0x34900a['node']),_0x2946f2++;else break;}else continue;}}else{_0x2b9750=_0x24483d['withIndex'](this['index_']),_0x2b9750=_0x2b9750['updatePriority'](g['EMPTY_NODE']);let _0x13670e;this['reverse_']?_0x13670e=_0x2b9750['getReverseIterator'](this['index_']):_0x13670e=_0x2b9750['getIterator'](this['index_']);let _0x11ad71=0x0;for(;_0x13670e['hasNext']();){const _0x5c92be=_0x13670e['getNext']();_0x11ad71<this['limit_']&&this['withinDirectionalStart'](_0x5c92be)&&this['withinDirectionalEnd'](_0x5c92be)?_0x11ad71++:_0x2b9750=_0x2b9750['updateImmediateChild'](_0x5c92be['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0xbf78a1,_0x2b9750,_0x4a2e7f);}['updatePriority'](_0x25e7c3,_0x411cbc){return _0x25e7c3;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x3bedec,_0x397f37,_0x54f826,_0x496a48,_0x5e47eb){let _0x33bdc7;if(this['reverse_']){const _0x5f365a=this['index_']['getCompare']();_0x33bdc7=(_0x59a4af,_0x28e21e)=>_0x5f365a(_0x28e21e,_0x59a4af);}else _0x33bdc7=this['index_']['getCompare']();const _0x4410f4=_0x3bedec;f(_0x4410f4['numChildren']()===this['limit_'],'');const _0x3de338=new E(_0x397f37,_0x54f826),_0x5b000a=this['reverse_']?_0x4410f4['getFirstChild'](this['index_']):_0x4410f4['getLastChild'](this['index_']),_0x500ca0=this['rangedFilter_']['matches'](_0x3de338);if(_0x4410f4['hasChild'](_0x397f37)){const _0x4c45c9=_0x4410f4['getImmediateChild'](_0x397f37);let _0x4a7a69=_0x496a48['getChildAfterChild'](this['index_'],_0x5b000a,this['reverse_']);for(;_0x4a7a69!=null&&(_0x4a7a69['name']===_0x397f37||_0x4410f4['hasChild'](_0x4a7a69['name']));)_0x4a7a69=_0x496a48['getChildAfterChild'](this['index_'],_0x4a7a69,this['reverse_']);const _0x5071d5=_0x4a7a69==null?0x1:_0x33bdc7(_0x4a7a69,_0x3de338);if(_0x500ca0&&!_0x54f826['isEmpty']()&&_0x5071d5>=0x0)return _0x5e47eb!=null&&_0x5e47eb['trackChildChange'](Dt(_0x397f37,_0x54f826,_0x4c45c9)),_0x4410f4['updateImmediateChild'](_0x397f37,_0x54f826);{_0x5e47eb!=null&&_0x5e47eb['trackChildChange'](Ot(_0x397f37,_0x4c45c9));const _0x1884f6=_0x4410f4['updateImmediateChild'](_0x397f37,g['EMPTY_NODE']);return _0x4a7a69!=null&&this['rangedFilter_']['matches'](_0x4a7a69)?(_0x5e47eb!=null&&_0x5e47eb['trackChildChange'](et(_0x4a7a69['name'],_0x4a7a69['node'])),_0x1884f6['updateImmediateChild'](_0x4a7a69['name'],_0x4a7a69['node'])):_0x1884f6;}}else return _0x54f826['isEmpty']()?_0x3bedec:_0x500ca0&&_0x33bdc7(_0x5b000a,_0x3de338)>=0x0?(_0x5e47eb!=null&&(_0x5e47eb['trackChildChange'](Ot(_0x5b000a['name'],_0x5b000a['node'])),_0x5e47eb['trackChildChange'](et(_0x397f37,_0x54f826))),_0x4410f4['updateImmediateChild'](_0x397f37,_0x54f826)['updateImmediateChild'](_0x5b000a['name'],g['EMPTY_NODE'])):_0x3bedec;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x3b5bc7=new Xi();return _0x3b5bc7['limitSet_']=this['limitSet_'],_0x3b5bc7['limit_']=this['limit_'],_0x3b5bc7['startSet_']=this['startSet_'],_0x3b5bc7['startAfterSet_']=this['startAfterSet_'],_0x3b5bc7['indexStartValue_']=this['indexStartValue_'],_0x3b5bc7['startNameSet_']=this['startNameSet_'],_0x3b5bc7['indexStartName_']=this['indexStartName_'],_0x3b5bc7['endSet_']=this['endSet_'],_0x3b5bc7['endBeforeSet_']=this['endBeforeSet_'],_0x3b5bc7['indexEndValue_']=this['indexEndValue_'],_0x3b5bc7['endNameSet_']=this['endNameSet_'],_0x3b5bc7['indexEndName_']=this['indexEndName_'],_0x3b5bc7['index_']=this['index_'],_0x3b5bc7['viewFrom_']=this['viewFrom_'],_0x3b5bc7;}}function Kh(_0x217965){return _0x217965['loadsAllData']()?new Ji(_0x217965['getIndex']()):_0x217965['hasLimit']()?new jh(_0x217965):new Mt(_0x217965);}function Yh(_0x480bd6,_0x394d29){const _0x24cdbc=_0x480bd6['copy']();return _0x24cdbc['limitSet_']=!0x0,_0x24cdbc['limit_']=_0x394d29,_0x24cdbc['viewFrom_']='l',_0x24cdbc;}function Qh(_0x11a404,_0x542b0e,_0x2cdc2c){const _0x345fad=_0x11a404['copy']();return _0x345fad['startSet_']=!0x0,_0x542b0e===void 0x0&&(_0x542b0e=null),_0x345fad['indexStartValue_']=_0x542b0e,_0x2cdc2c!=null?(_0x345fad['startNameSet_']=!0x0,_0x345fad['indexStartName_']=_0x2cdc2c):(_0x345fad['startNameSet_']=!0x1,_0x345fad['indexStartName_']=''),_0x345fad;}function Jh(_0x1f7c75,_0x5e63ce,_0x59359e){const _0x1f34ed=_0x1f7c75['copy']();return _0x1f34ed['endSet_']=!0x0,_0x5e63ce===void 0x0&&(_0x5e63ce=null),_0x1f34ed['indexEndValue_']=_0x5e63ce,_0x59359e!==void 0x0?(_0x1f34ed['endNameSet_']=!0x0,_0x1f34ed['indexEndName_']=_0x59359e):(_0x1f34ed['endNameSet_']=!0x1,_0x1f34ed['indexEndName_']=''),_0x1f34ed;}function xo(_0xd2591,_0x185456){const _0x168717=_0xd2591['copy']();return _0x168717['index_']=_0x185456,_0x168717;}function sr(_0x5ffb8c){const _0x58ba92={};if(_0x5ffb8c['isDefault']())return _0x58ba92;let _0x21b47f;if(_0x5ffb8c['index_']===R?_0x21b47f='$priority':_0x5ffb8c['index_']===Mo?_0x21b47f='$value':_0x5ffb8c['index_']===ye?_0x21b47f='$key':(f(_0x5ffb8c['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x21b47f=_0x5ffb8c['index_']['toString']()),_0x58ba92['orderBy']=O(_0x21b47f),_0x5ffb8c['startSet_']){const _0x4e1549=_0x5ffb8c['startAfterSet_']?'startAfter':'startAt';_0x58ba92[_0x4e1549]=O(_0x5ffb8c['indexStartValue_']),_0x5ffb8c['startNameSet_']&&(_0x58ba92[_0x4e1549]+=','+O(_0x5ffb8c['indexStartName_']));}if(_0x5ffb8c['endSet_']){const _0x4f806c=_0x5ffb8c['endBeforeSet_']?'endBefore':'endAt';_0x58ba92[_0x4f806c]=O(_0x5ffb8c['indexEndValue_']),_0x5ffb8c['endNameSet_']&&(_0x58ba92[_0x4f806c]+=','+O(_0x5ffb8c['indexEndName_']));}return _0x5ffb8c['limitSet_']&&(_0x5ffb8c['isViewFromLeft']()?_0x58ba92['limitToFirst']=_0x5ffb8c['limit_']:_0x58ba92['limitToLast']=_0x5ffb8c['limit_']),_0x58ba92;}function rr(_0x2f6e4d){const _0x2bd6dc={};if(_0x2f6e4d['startSet_']&&(_0x2bd6dc['sp']=_0x2f6e4d['indexStartValue_'],_0x2f6e4d['startNameSet_']&&(_0x2bd6dc['sn']=_0x2f6e4d['indexStartName_']),_0x2bd6dc['sin']=!_0x2f6e4d['startAfterSet_']),_0x2f6e4d['endSet_']&&(_0x2bd6dc['ep']=_0x2f6e4d['indexEndValue_'],_0x2f6e4d['endNameSet_']&&(_0x2bd6dc['en']=_0x2f6e4d['indexEndName_']),_0x2bd6dc['ein']=!_0x2f6e4d['endBeforeSet_']),_0x2f6e4d['limitSet_']){_0x2bd6dc['l']=_0x2f6e4d['limit_'];let _0x2ef965=_0x2f6e4d['viewFrom_'];_0x2ef965===''&&(_0x2f6e4d['isViewFromLeft']()?_0x2ef965='l':_0x2ef965='r'),_0x2bd6dc['vf']=_0x2ef965;}return _0x2f6e4d['index_']!==R&&(_0x2bd6dc['i']=_0x2f6e4d['index_']['toString']()),_0x2bd6dc;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x5c125c){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x4cb775,_0x5a2cec){return _0x5a2cec!==void 0x0?'tag$'+_0x5a2cec:(f(_0x4cb775['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x4cb775['_path']['toString']());}constructor(_0x174cc0,_0x33e976,_0x40f777,_0xde06dd){super(),this['repoInfo_']=_0x174cc0,this['onDataUpdate_']=_0x33e976,this['authTokenProvider_']=_0x40f777,this['appCheckTokenProvider_']=_0xde06dd,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x3a9cd0,_0x4fc91b,_0x5e471d,_0x2e89d8){const _0x2cc15a=_0x3a9cd0['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2cc15a+'\x20'+_0x3a9cd0['_queryIdentifier']);const _0xc44b83=pn['getListenId_'](_0x3a9cd0,_0x5e471d),_0x20e559={};this['listens_'][_0xc44b83]=_0x20e559;const _0x22e4ed=sr(_0x3a9cd0['_queryParams']);this['restRequest_'](_0x2cc15a+'.json',_0x22e4ed,(_0x1d1a7f,_0x5e8e19)=>{let _0x1eff83=_0x5e8e19;if(_0x1d1a7f===0x194&&(_0x1eff83=null,_0x1d1a7f=null),_0x1d1a7f===null&&this['onDataUpdate_'](_0x2cc15a,_0x1eff83,!0x1,_0x5e471d),De(this['listens_'],_0xc44b83)===_0x20e559){let _0x13f6a5;_0x1d1a7f?_0x1d1a7f===0x191?_0x13f6a5='permission_denied':_0x13f6a5='rest_error:'+_0x1d1a7f:_0x13f6a5='ok',_0x2e89d8(_0x13f6a5,null);}});}['unlisten'](_0x338595,_0xc8fb0){const _0x3b0f88=pn['getListenId_'](_0x338595,_0xc8fb0);delete this['listens_'][_0x3b0f88];}['get'](_0xa1d36){const _0x587f66=sr(_0xa1d36['_queryParams']),_0x5434b2=_0xa1d36['_path']['toString'](),_0x1abb66=new ot();return this['restRequest_'](_0x5434b2+'.json',_0x587f66,(_0x49c2c4,_0x2c1669)=>{let _0x103ddc=_0x2c1669;_0x49c2c4===0x194&&(_0x103ddc=null,_0x49c2c4=null),_0x49c2c4===null?(this['onDataUpdate_'](_0x5434b2,_0x103ddc,!0x1,null),_0x1abb66['resolve'](_0x103ddc)):_0x1abb66['reject'](new Error(_0x103ddc));}),_0x1abb66['promise'];}['refreshAuthToken'](_0x254823){}['restRequest_'](_0x3f0974,_0x2ff30a={},_0x4324e8){return _0x2ff30a['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x121109,_0x2118de])=>{_0x121109&&_0x121109['accessToken']&&(_0x2ff30a['auth']=_0x121109['accessToken']),_0x2118de&&_0x2118de['token']&&(_0x2ff30a['ac']=_0x2118de['token']);const _0x5130e8=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x3f0974+'?ns='+this['repoInfo_']['namespace']+ct(_0x2ff30a);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x5130e8);const _0xb08d08=new XMLHttpRequest();_0xb08d08['onreadystatechange']=()=>{if(_0x4324e8&&_0xb08d08['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x5130e8+'\x20received.\x20status:',_0xb08d08['status'],'response:',_0xb08d08['responseText']);let _0x534c54=null;if(_0xb08d08['status']>=0xc8&&_0xb08d08['status']<0x12c){try{_0x534c54=At(_0xb08d08['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x5130e8+':\x20'+_0xb08d08['responseText']);}_0x4324e8(null,_0x534c54);}else _0xb08d08['status']!==0x191&&_0xb08d08['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x5130e8+'\x20Status:\x20'+_0xb08d08['status']),_0x4324e8(_0xb08d08['status']);_0x4324e8=null;}},_0xb08d08['open']('GET',_0x5130e8,!0x0),_0xb08d08['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x58f90e){return this['rootNode_']['getChild'](_0x58f90e);}['updateSnapshot'](_0x42888f,_0xe52ab3){this['rootNode_']=this['rootNode_']['updateChild'](_0x42888f,_0xe52ab3);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x30e035,_0x3dcdba,_0x494f0d){if(v(_0x3dcdba))_0x30e035['value']=_0x494f0d,_0x30e035['children']['clear']();else{if(_0x30e035['value']!==null)_0x30e035['value']=_0x30e035['value']['updateChild'](_0x3dcdba,_0x494f0d);else{const _0xefbc9d=y(_0x3dcdba);_0x30e035['children']['has'](_0xefbc9d)||_0x30e035['children']['set'](_0xefbc9d,_n());const _0x2c8023=_0x30e035['children']['get'](_0xefbc9d);_0x3dcdba=b(_0x3dcdba),Fo(_0x2c8023,_0x3dcdba,_0x494f0d);}}}function Ii(_0x41328f,_0x3f1c6d,_0x4c967b){_0x41328f['value']!==null?_0x4c967b(_0x3f1c6d,_0x41328f['value']):Zh(_0x41328f,(_0x2a1744,_0x180df4)=>{const _0x56067a=new C(_0x3f1c6d['toString']()+'/'+_0x2a1744);Ii(_0x180df4,_0x56067a,_0x4c967b);});}function Zh(_0x5a56b3,_0x1ce1b5){_0x5a56b3['children']['forEach']((_0x1311f8,_0x564c58)=>{_0x1ce1b5(_0x564c58,_0x1311f8);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x43bd54){this['collection_']=_0x43bd54,this['last_']=null;}['get'](){const _0x31a170=this['collection_']['get'](),_0x55b8bc={..._0x31a170};return this['last_']&&x(this['last_'],(_0x2a90f3,_0x2327e2)=>{_0x55b8bc[_0x2a90f3]=_0x55b8bc[_0x2a90f3]-_0x2327e2;}),this['last_']=_0x31a170,_0x55b8bc;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x42707f,_0x3dedc4){this['server_']=_0x3dedc4,this['statsToReport_']={},this['statsListener_']=new eu(_0x42707f);const _0x58067d=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x58067d));}['reportStats_'](){const _0x27c904=this['statsListener_']['get'](),_0x303bfc={};let _0x5c53a2=!0x1;x(_0x27c904,(_0x50b53f,_0x2a8975)=>{_0x2a8975>0x0&&J(this['statsToReport_'],_0x50b53f)&&(_0x303bfc[_0x50b53f]=_0x2a8975,_0x5c53a2=!0x0);}),_0x5c53a2&&this['server_']['reportStats'](_0x303bfc),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x2bb210){_0x2bb210[_0x2bb210['OVERWRITE']=0x0]='OVERWRITE',_0x2bb210[_0x2bb210['MERGE']=0x1]='MERGE',_0x2bb210[_0x2bb210['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x2bb210[_0x2bb210['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x17c500){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x17c500,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x1ce918,_0x4bb047,_0x15e21b){this['path']=_0x1ce918,this['affectedTree']=_0x4bb047,this['revert']=_0x15e21b,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x113a6f){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x336f01=this['affectedTree']['subtree'](new C(_0x113a6f));return new gn(w(),_0x336f01,this['revert']);}}else return f(y(this['path'])===_0x113a6f,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x4dd6e0,_0x4f9a62){this['source']=_0x4dd6e0,this['path']=_0x4f9a62,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x156340){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x232534,_0x31311c,_0x2766c4){this['source']=_0x232534,this['path']=_0x31311c,this['snap']=_0x2766c4,this['type']=j['OVERWRITE'];}['operationForChild'](_0x287c8c){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x287c8c)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0xf8b7c,_0x3831b6,_0x153954){this['source']=_0xf8b7c,this['path']=_0x3831b6,this['children']=_0x153954,this['type']=j['MERGE'];}['operationForChild'](_0x2fc274){if(v(this['path'])){const _0x3618e2=this['children']['subtree'](new C(_0x2fc274));return _0x3618e2['isEmpty']()?null:_0x3618e2['value']?new Ue(this['source'],w(),_0x3618e2['value']):new tt(this['source'],w(),_0x3618e2);}else return f(y(this['path'])===_0x2fc274,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x59d4a3,_0x5d470a,_0xf91d5){this['node_']=_0x59d4a3,this['fullyInitialized_']=_0x5d470a,this['filtered_']=_0xf91d5;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x20d215){if(v(_0x20d215))return this['isFullyInitialized']()&&!this['filtered_'];const _0x23f07b=y(_0x20d215);return this['isCompleteForChild'](_0x23f07b);}['isCompleteForChild'](_0x1b2178){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x1b2178);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x32c277){this['query_']=_0x32c277,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x1c2f26,_0x54b418,_0x411bde,_0x95d4a1){const _0x165ab5=[],_0x3fa9cb=[];return _0x54b418['forEach'](_0x336089=>{_0x336089['type']==='child_changed'&&_0x1c2f26['index_']['indexedValueChanged'](_0x336089['oldSnap'],_0x336089['snapshotNode'])&&_0x3fa9cb['push'](zh(_0x336089['childName'],_0x336089['snapshotNode']));}),yt(_0x1c2f26,_0x165ab5,'child_removed',_0x54b418,_0x95d4a1,_0x411bde),yt(_0x1c2f26,_0x165ab5,'child_added',_0x54b418,_0x95d4a1,_0x411bde),yt(_0x1c2f26,_0x165ab5,'child_moved',_0x3fa9cb,_0x95d4a1,_0x411bde),yt(_0x1c2f26,_0x165ab5,'child_changed',_0x54b418,_0x95d4a1,_0x411bde),yt(_0x1c2f26,_0x165ab5,'value',_0x54b418,_0x95d4a1,_0x411bde),_0x165ab5;}function yt(_0x182462,_0x4e9cdc,_0x12de46,_0x4a2840,_0x1b24a7,_0x2fc09b){const _0x381030=_0x4a2840['filter'](_0x4c61cc=>_0x4c61cc['type']===_0x12de46);_0x381030['sort']((_0x2bf7b1,_0x5ec083)=>au(_0x182462,_0x2bf7b1,_0x5ec083)),_0x381030['forEach'](_0x1909f0=>{const _0x1a2aeb=ou(_0x182462,_0x1909f0,_0x2fc09b);_0x1b24a7['forEach'](_0x284989=>{_0x284989['respondsTo'](_0x1909f0['type'])&&_0x4e9cdc['push'](_0x284989['createEvent'](_0x1a2aeb,_0x182462['query_']));});});}function ou(_0x111f27,_0x5c6d0b,_0x5bb6fa){return _0x5c6d0b['type']==='value'||_0x5c6d0b['type']==='child_removed'||(_0x5c6d0b['prevName']=_0x5bb6fa['getPredecessorChildName'](_0x5c6d0b['childName'],_0x5c6d0b['snapshotNode'],_0x111f27['index_'])),_0x5c6d0b;}function au(_0xa37272,_0x314d15,_0x1723f2){if(_0x314d15['childName']==null||_0x1723f2['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x21514f=new E(_0x314d15['childName'],_0x314d15['snapshotNode']),_0x29f418=new E(_0x1723f2['childName'],_0x1723f2['snapshotNode']);return _0xa37272['index_']['compare'](_0x21514f,_0x29f418);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x268c59,_0x51e901){return{'eventCache':_0x268c59,'serverCache':_0x51e901};}function Tt(_0x26823c,_0x1330fb,_0xcf518e,_0x367dfe){return Mn(new Ce(_0x1330fb,_0xcf518e,_0x367dfe),_0x26823c['serverCache']);}function Uo(_0xd9372d,_0x305a37,_0x6fb0bc,_0x451d64){return Mn(_0xd9372d['eventCache'],new Ce(_0x305a37,_0x6fb0bc,_0x451d64));}function mn(_0x2f8eb2){return _0x2f8eb2['eventCache']['isFullyInitialized']()?_0x2f8eb2['eventCache']['getNode']():null;}function We(_0x596c00){return _0x596c00['serverCache']['isFullyInitialized']()?_0x596c00['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x5c1f0e){let _0x40a0e6=new S(null);return x(_0x5c1f0e,(_0x5e143c,_0x8a8899)=>{_0x40a0e6=_0x40a0e6['set'](new C(_0x5e143c),_0x8a8899);}),_0x40a0e6;}constructor(_0x20f9b5,_0x496f59=cu()){this['value']=_0x20f9b5,this['children']=_0x496f59;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x62fa8e,_0x1eb3d8){if(this['value']!=null&&_0x1eb3d8(this['value']))return{'path':w(),'value':this['value']};if(v(_0x62fa8e))return null;{const _0x56aa20=y(_0x62fa8e),_0x24ad57=this['children']['get'](_0x56aa20);if(_0x24ad57!==null){const _0x30ddd8=_0x24ad57['findRootMostMatchingPathAndValue'](b(_0x62fa8e),_0x1eb3d8);return _0x30ddd8!=null?{'path':k(new C(_0x56aa20),_0x30ddd8['path']),'value':_0x30ddd8['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0xbd9e6a){return this['findRootMostMatchingPathAndValue'](_0xbd9e6a,()=>!0x0);}['subtree'](_0x3ec3ff){if(v(_0x3ec3ff))return this;{const _0x1389fa=y(_0x3ec3ff),_0x2b4278=this['children']['get'](_0x1389fa);return _0x2b4278!==null?_0x2b4278['subtree'](b(_0x3ec3ff)):new S(null);}}['set'](_0x3cae0b,_0x45a5ba){if(v(_0x3cae0b))return new S(_0x45a5ba,this['children']);{const _0x5445d7=y(_0x3cae0b),_0x200895=(this['children']['get'](_0x5445d7)||new S(null))['set'](b(_0x3cae0b),_0x45a5ba),_0x4613db=this['children']['insert'](_0x5445d7,_0x200895);return new S(this['value'],_0x4613db);}}['remove'](_0x4015cc){if(v(_0x4015cc))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0xa9d14e=y(_0x4015cc),_0x10bfc5=this['children']['get'](_0xa9d14e);if(_0x10bfc5){const _0x360818=_0x10bfc5['remove'](b(_0x4015cc));let _0x268b66;return _0x360818['isEmpty']()?_0x268b66=this['children']['remove'](_0xa9d14e):_0x268b66=this['children']['insert'](_0xa9d14e,_0x360818),this['value']===null&&_0x268b66['isEmpty']()?new S(null):new S(this['value'],_0x268b66);}else return this;}}['get'](_0x2f7e11){if(v(_0x2f7e11))return this['value'];{const _0x1ae70f=y(_0x2f7e11),_0x60ce06=this['children']['get'](_0x1ae70f);return _0x60ce06?_0x60ce06['get'](b(_0x2f7e11)):null;}}['setTree'](_0x6bfbe9,_0x3fd436){if(v(_0x6bfbe9))return _0x3fd436;{const _0x4d0ad6=y(_0x6bfbe9),_0xb382da=(this['children']['get'](_0x4d0ad6)||new S(null))['setTree'](b(_0x6bfbe9),_0x3fd436);let _0xd643f0;return _0xb382da['isEmpty']()?_0xd643f0=this['children']['remove'](_0x4d0ad6):_0xd643f0=this['children']['insert'](_0x4d0ad6,_0xb382da),new S(this['value'],_0xd643f0);}}['fold'](_0x9afc14){return this['fold_'](w(),_0x9afc14);}['fold_'](_0xfe9adf,_0x3b0bc8){const _0x437e34={};return this['children']['inorderTraversal']((_0x488a7c,_0x2ef4c5)=>{_0x437e34[_0x488a7c]=_0x2ef4c5['fold_'](k(_0xfe9adf,_0x488a7c),_0x3b0bc8);}),_0x3b0bc8(_0xfe9adf,this['value'],_0x437e34);}['findOnPath'](_0x3a2f65,_0x2f3774){return this['findOnPath_'](_0x3a2f65,w(),_0x2f3774);}['findOnPath_'](_0x4b1623,_0x3475c5,_0x50e045){const _0xa15f23=this['value']?_0x50e045(_0x3475c5,this['value']):!0x1;if(_0xa15f23)return _0xa15f23;if(v(_0x4b1623))return null;{const _0x245598=y(_0x4b1623),_0x525af0=this['children']['get'](_0x245598);return _0x525af0?_0x525af0['findOnPath_'](b(_0x4b1623),k(_0x3475c5,_0x245598),_0x50e045):null;}}['foreachOnPath'](_0x1605f0,_0x4999df){return this['foreachOnPath_'](_0x1605f0,w(),_0x4999df);}['foreachOnPath_'](_0x81b237,_0x5dbcf7,_0xf7b88c){if(v(_0x81b237))return this;{this['value']&&_0xf7b88c(_0x5dbcf7,this['value']);const _0x46e7cf=y(_0x81b237),_0xe3256=this['children']['get'](_0x46e7cf);return _0xe3256?_0xe3256['foreachOnPath_'](b(_0x81b237),k(_0x5dbcf7,_0x46e7cf),_0xf7b88c):new S(null);}}['foreach'](_0x1868a6){this['foreach_'](w(),_0x1868a6);}['foreach_'](_0xcbe208,_0x58efff){this['children']['inorderTraversal']((_0x3dcf1c,_0x199fdb)=>{_0x199fdb['foreach_'](k(_0xcbe208,_0x3dcf1c),_0x58efff);}),this['value']&&_0x58efff(_0xcbe208,this['value']);}['foreachChild'](_0x6eef5d){this['children']['inorderTraversal']((_0x319eb1,_0x246321)=>{_0x246321['value']&&_0x6eef5d(_0x319eb1,_0x246321['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x298d1c){this['writeTree_']=_0x298d1c;}static['empty'](){return new Y(new S(null));}}function St(_0x7d5c25,_0xb42b06,_0x1e82dc){if(v(_0xb42b06))return new Y(new S(_0x1e82dc));{const _0x19235e=_0x7d5c25['writeTree_']['findRootMostValueAndPath'](_0xb42b06);if(_0x19235e!=null){const _0x2820b6=_0x19235e['path'];let _0x1777ca=_0x19235e['value'];const _0x2c9e53=F(_0x2820b6,_0xb42b06);return _0x1777ca=_0x1777ca['updateChild'](_0x2c9e53,_0x1e82dc),new Y(_0x7d5c25['writeTree_']['set'](_0x2820b6,_0x1777ca));}else{const _0x1ec480=new S(_0x1e82dc),_0x2fe8b3=_0x7d5c25['writeTree_']['setTree'](_0xb42b06,_0x1ec480);return new Y(_0x2fe8b3);}}}function wi(_0x54abe2,_0x468c1a,_0x5f5b59){let _0x4a89cd=_0x54abe2;return x(_0x5f5b59,(_0x8023c5,_0x11685f)=>{_0x4a89cd=St(_0x4a89cd,k(_0x468c1a,_0x8023c5),_0x11685f);}),_0x4a89cd;}function ar(_0x100665,_0x7ce9ac){if(v(_0x7ce9ac))return Y['empty']();{const _0x23b92f=_0x100665['writeTree_']['setTree'](_0x7ce9ac,new S(null));return new Y(_0x23b92f);}}function Ci(_0x46887e,_0x352e0d){return $e(_0x46887e,_0x352e0d)!=null;}function $e(_0x2288e8,_0x258b8d){const _0x4ce270=_0x2288e8['writeTree_']['findRootMostValueAndPath'](_0x258b8d);return _0x4ce270!=null?_0x2288e8['writeTree_']['get'](_0x4ce270['path'])['getChild'](F(_0x4ce270['path'],_0x258b8d)):null;}function cr(_0x41eee9){const _0x24a5c4=[],_0x568b54=_0x41eee9['writeTree_']['value'];return _0x568b54!=null?_0x568b54['isLeafNode']()||_0x568b54['forEachChild'](R,(_0x3b8b0f,_0x2d1712)=>{_0x24a5c4['push'](new E(_0x3b8b0f,_0x2d1712));}):_0x41eee9['writeTree_']['children']['inorderTraversal']((_0x59e36e,_0x357d19)=>{_0x357d19['value']!=null&&_0x24a5c4['push'](new E(_0x59e36e,_0x357d19['value']));}),_0x24a5c4;}function ve(_0x34e86e,_0x1c4c32){if(v(_0x1c4c32))return _0x34e86e;{const _0x151f15=$e(_0x34e86e,_0x1c4c32);return _0x151f15!=null?new Y(new S(_0x151f15)):new Y(_0x34e86e['writeTree_']['subtree'](_0x1c4c32));}}function Ti(_0x1c85d6){return _0x1c85d6['writeTree_']['isEmpty']();}function nt(_0x29247c,_0x3c2fab){return Wo(w(),_0x29247c['writeTree_'],_0x3c2fab);}function Wo(_0x225b96,_0x5d94ae,_0x3f39d2){if(_0x5d94ae['value']!=null)return _0x3f39d2['updateChild'](_0x225b96,_0x5d94ae['value']);{let _0x201d0c=null;return _0x5d94ae['children']['inorderTraversal']((_0x559087,_0x9753cd)=>{_0x559087==='.priority'?(f(_0x9753cd['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x201d0c=_0x9753cd['value']):_0x3f39d2=Wo(k(_0x225b96,_0x559087),_0x9753cd,_0x3f39d2);}),!_0x3f39d2['getChild'](_0x225b96)['isEmpty']()&&_0x201d0c!==null&&(_0x3f39d2=_0x3f39d2['updateChild'](k(_0x225b96,'.priority'),_0x201d0c)),_0x3f39d2;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x92a220,_0x1dee1a){return $o(_0x1dee1a,_0x92a220);}function lu(_0x247cc1,_0x3293c6,_0x4de99b,_0x1aeb2d,_0x31fe92){f(_0x1aeb2d>_0x247cc1['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x31fe92===void 0x0&&(_0x31fe92=!0x0),_0x247cc1['allWrites']['push']({'path':_0x3293c6,'snap':_0x4de99b,'writeId':_0x1aeb2d,'visible':_0x31fe92}),_0x31fe92&&(_0x247cc1['visibleWrites']=St(_0x247cc1['visibleWrites'],_0x3293c6,_0x4de99b)),_0x247cc1['lastWriteId']=_0x1aeb2d;}function hu(_0x4dbea2,_0x45d706,_0x161a5e,_0x1ff114){f(_0x1ff114>_0x4dbea2['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x4dbea2['allWrites']['push']({'path':_0x45d706,'children':_0x161a5e,'writeId':_0x1ff114,'visible':!0x0}),_0x4dbea2['visibleWrites']=wi(_0x4dbea2['visibleWrites'],_0x45d706,_0x161a5e),_0x4dbea2['lastWriteId']=_0x1ff114;}function uu(_0x3d2072,_0x12c36d){for(let _0x3c0ff4=0x0;_0x3c0ff4<_0x3d2072['allWrites']['length'];_0x3c0ff4++){const _0x344975=_0x3d2072['allWrites'][_0x3c0ff4];if(_0x344975['writeId']===_0x12c36d)return _0x344975;}return null;}function du(_0xd09aff,_0x4c8522){const _0x117e53=_0xd09aff['allWrites']['findIndex'](_0x42b53a=>_0x42b53a['writeId']===_0x4c8522);f(_0x117e53>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x5eaf8e=_0xd09aff['allWrites'][_0x117e53];_0xd09aff['allWrites']['splice'](_0x117e53,0x1);let _0x514788=_0x5eaf8e['visible'],_0x5625d5=!0x1,_0x3d247c=_0xd09aff['allWrites']['length']-0x1;for(;_0x514788&&_0x3d247c>=0x0;){const _0x2a0d97=_0xd09aff['allWrites'][_0x3d247c];_0x2a0d97['visible']&&(_0x3d247c>=_0x117e53&&fu(_0x2a0d97,_0x5eaf8e['path'])?_0x514788=!0x1:G(_0x5eaf8e['path'],_0x2a0d97['path'])&&(_0x5625d5=!0x0)),_0x3d247c--;}if(_0x514788){if(_0x5625d5)return pu(_0xd09aff),!0x0;if(_0x5eaf8e['snap'])_0xd09aff['visibleWrites']=ar(_0xd09aff['visibleWrites'],_0x5eaf8e['path']);else{const _0x45429d=_0x5eaf8e['children'];x(_0x45429d,_0x173465=>{_0xd09aff['visibleWrites']=ar(_0xd09aff['visibleWrites'],k(_0x5eaf8e['path'],_0x173465));});}return!0x0;}else return!0x1;}function fu(_0x341ab1,_0xdf9bee){if(_0x341ab1['snap'])return G(_0x341ab1['path'],_0xdf9bee);for(const _0x40e6a9 in _0x341ab1['children'])if(_0x341ab1['children']['hasOwnProperty'](_0x40e6a9)&&G(k(_0x341ab1['path'],_0x40e6a9),_0xdf9bee))return!0x0;return!0x1;}function pu(_0x49b00e){_0x49b00e['visibleWrites']=Bo(_0x49b00e['allWrites'],_u,w()),_0x49b00e['allWrites']['length']>0x0?_0x49b00e['lastWriteId']=_0x49b00e['allWrites'][_0x49b00e['allWrites']['length']-0x1]['writeId']:_0x49b00e['lastWriteId']=-0x1;}function _u(_0x4f1289){return _0x4f1289['visible'];}function Bo(_0x3f1232,_0x2b9ec0,_0xb75398){let _0x58c32d=Y['empty']();for(let _0x1dff09=0x0;_0x1dff09<_0x3f1232['length'];++_0x1dff09){const _0x2a3a44=_0x3f1232[_0x1dff09];if(_0x2b9ec0(_0x2a3a44)){const _0x431686=_0x2a3a44['path'];let _0x2b1a4f;if(_0x2a3a44['snap'])G(_0xb75398,_0x431686)?(_0x2b1a4f=F(_0xb75398,_0x431686),_0x58c32d=St(_0x58c32d,_0x2b1a4f,_0x2a3a44['snap'])):G(_0x431686,_0xb75398)&&(_0x2b1a4f=F(_0x431686,_0xb75398),_0x58c32d=St(_0x58c32d,w(),_0x2a3a44['snap']['getChild'](_0x2b1a4f)));else{if(_0x2a3a44['children']){if(G(_0xb75398,_0x431686))_0x2b1a4f=F(_0xb75398,_0x431686),_0x58c32d=wi(_0x58c32d,_0x2b1a4f,_0x2a3a44['children']);else{if(G(_0x431686,_0xb75398)){if(_0x2b1a4f=F(_0x431686,_0xb75398),v(_0x2b1a4f))_0x58c32d=wi(_0x58c32d,w(),_0x2a3a44['children']);else{const _0x2bde1f=De(_0x2a3a44['children'],y(_0x2b1a4f));if(_0x2bde1f){const _0x167664=_0x2bde1f['getChild'](b(_0x2b1a4f));_0x58c32d=St(_0x58c32d,w(),_0x167664);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x58c32d;}function Vo(_0x56fb27,_0x4e7469,_0x502bb0,_0x413b9c,_0x210fa6){if(!_0x413b9c&&!_0x210fa6){const _0x36dc8d=$e(_0x56fb27['visibleWrites'],_0x4e7469);if(_0x36dc8d!=null)return _0x36dc8d;{const _0x48791c=ve(_0x56fb27['visibleWrites'],_0x4e7469);if(Ti(_0x48791c))return _0x502bb0;if(_0x502bb0==null&&!Ci(_0x48791c,w()))return null;{const _0x577083=_0x502bb0||g['EMPTY_NODE'];return nt(_0x48791c,_0x577083);}}}else{const _0x34f8b3=ve(_0x56fb27['visibleWrites'],_0x4e7469);if(!_0x210fa6&&Ti(_0x34f8b3))return _0x502bb0;if(!_0x210fa6&&_0x502bb0==null&&!Ci(_0x34f8b3,w()))return null;{const _0x2194a6=function(_0x5b800a){return(_0x5b800a['visible']||_0x210fa6)&&(!_0x413b9c||!~_0x413b9c['indexOf'](_0x5b800a['writeId']))&&(G(_0x5b800a['path'],_0x4e7469)||G(_0x4e7469,_0x5b800a['path']));},_0x39eeee=Bo(_0x56fb27['allWrites'],_0x2194a6,_0x4e7469),_0x20a7ce=_0x502bb0||g['EMPTY_NODE'];return nt(_0x39eeee,_0x20a7ce);}}}function gu(_0x503345,_0x5a65f9,_0x2967eb){let _0x1d6803=g['EMPTY_NODE'];const _0xd3f20e=$e(_0x503345['visibleWrites'],_0x5a65f9);if(_0xd3f20e)return _0xd3f20e['isLeafNode']()||_0xd3f20e['forEachChild'](R,(_0x157619,_0x43ae3b)=>{_0x1d6803=_0x1d6803['updateImmediateChild'](_0x157619,_0x43ae3b);}),_0x1d6803;if(_0x2967eb){const _0x19ebaa=ve(_0x503345['visibleWrites'],_0x5a65f9);return _0x2967eb['forEachChild'](R,(_0x13bf58,_0x19adfc)=>{const _0x21fd90=nt(ve(_0x19ebaa,new C(_0x13bf58)),_0x19adfc);_0x1d6803=_0x1d6803['updateImmediateChild'](_0x13bf58,_0x21fd90);}),cr(_0x19ebaa)['forEach'](_0x334372=>{_0x1d6803=_0x1d6803['updateImmediateChild'](_0x334372['name'],_0x334372['node']);}),_0x1d6803;}else{const _0x272ec8=ve(_0x503345['visibleWrites'],_0x5a65f9);return cr(_0x272ec8)['forEach'](_0x1c44bf=>{_0x1d6803=_0x1d6803['updateImmediateChild'](_0x1c44bf['name'],_0x1c44bf['node']);}),_0x1d6803;}}function mu(_0x345ad9,_0x4e3842,_0x544589,_0x3aa164,_0x50522b){f(_0x3aa164||_0x50522b,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x4f1fcd=k(_0x4e3842,_0x544589);if(Ci(_0x345ad9['visibleWrites'],_0x4f1fcd))return null;{const _0x347ba1=ve(_0x345ad9['visibleWrites'],_0x4f1fcd);return Ti(_0x347ba1)?_0x50522b['getChild'](_0x544589):nt(_0x347ba1,_0x50522b['getChild'](_0x544589));}}function yu(_0x27db71,_0x4777a0,_0x5720ee,_0xe66190){const _0x171ef1=k(_0x4777a0,_0x5720ee),_0x2ac383=$e(_0x27db71['visibleWrites'],_0x171ef1);if(_0x2ac383!=null)return _0x2ac383;if(_0xe66190['isCompleteForChild'](_0x5720ee)){const _0x11a4fe=ve(_0x27db71['visibleWrites'],_0x171ef1);return nt(_0x11a4fe,_0xe66190['getNode']()['getImmediateChild'](_0x5720ee));}else return null;}function vu(_0x320488,_0x3d1510){return $e(_0x320488['visibleWrites'],_0x3d1510);}function Eu(_0x38e4b1,_0x26ce43,_0x351b13,_0x1d032e,_0x342012,_0x524f24,_0x58d9a5){let _0x48d975;const _0x317d4a=ve(_0x38e4b1['visibleWrites'],_0x26ce43),_0x216fd6=$e(_0x317d4a,w());if(_0x216fd6!=null)_0x48d975=_0x216fd6;else{if(_0x351b13!=null)_0x48d975=nt(_0x317d4a,_0x351b13);else return[];}if(_0x48d975=_0x48d975['withIndex'](_0x58d9a5),!_0x48d975['isEmpty']()&&!_0x48d975['isLeafNode']()){const _0x2c3c89=[],_0x403bb4=_0x58d9a5['getCompare'](),_0x2d454f=_0x524f24?_0x48d975['getReverseIteratorFrom'](_0x1d032e,_0x58d9a5):_0x48d975['getIteratorFrom'](_0x1d032e,_0x58d9a5);let _0x5f14b8=_0x2d454f['getNext']();for(;_0x5f14b8&&_0x2c3c89['length']<_0x342012;)_0x403bb4(_0x5f14b8,_0x1d032e)!==0x0&&_0x2c3c89['push'](_0x5f14b8),_0x5f14b8=_0x2d454f['getNext']();return _0x2c3c89;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x57389a,_0x1d4849,_0x195b9e,_0x256485){return Vo(_0x57389a['writeTree'],_0x57389a['treePath'],_0x1d4849,_0x195b9e,_0x256485);}function ns(_0x552890,_0x18abac){return gu(_0x552890['writeTree'],_0x552890['treePath'],_0x18abac);}function lr(_0xdc61ff,_0x250cd8,_0xefa5ab,_0x4e0f29){return mu(_0xdc61ff['writeTree'],_0xdc61ff['treePath'],_0x250cd8,_0xefa5ab,_0x4e0f29);}function vn(_0x5c73d4,_0x473e66){return vu(_0x5c73d4['writeTree'],k(_0x5c73d4['treePath'],_0x473e66));}function wu(_0x9b24ab,_0x27ebbd,_0x1bad31,_0x5ee4b6,_0x470ce4,_0x183e78){return Eu(_0x9b24ab['writeTree'],_0x9b24ab['treePath'],_0x27ebbd,_0x1bad31,_0x5ee4b6,_0x470ce4,_0x183e78);}function is(_0x153dbb,_0x5002de,_0x3fa739){return yu(_0x153dbb['writeTree'],_0x153dbb['treePath'],_0x5002de,_0x3fa739);}function Ho(_0x4f818c,_0x1f0d9a){return $o(k(_0x4f818c['treePath'],_0x1f0d9a),_0x4f818c['writeTree']);}function $o(_0xe26af0,_0x56cbc2){return{'treePath':_0xe26af0,'writeTree':_0x56cbc2};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x18562e){const _0x464a46=_0x18562e['type'],_0x462b3d=_0x18562e['childName'];f(_0x464a46==='child_added'||_0x464a46==='child_changed'||_0x464a46==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x462b3d!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x2662d5=this['changeMap']['get'](_0x462b3d);if(_0x2662d5){const _0x517ff9=_0x2662d5['type'];if(_0x464a46==='child_added'&&_0x517ff9==='child_removed')this['changeMap']['set'](_0x462b3d,Dt(_0x462b3d,_0x18562e['snapshotNode'],_0x2662d5['snapshotNode']));else{if(_0x464a46==='child_removed'&&_0x517ff9==='child_added')this['changeMap']['delete'](_0x462b3d);else{if(_0x464a46==='child_removed'&&_0x517ff9==='child_changed')this['changeMap']['set'](_0x462b3d,Ot(_0x462b3d,_0x2662d5['oldSnap']));else{if(_0x464a46==='child_changed'&&_0x517ff9==='child_added')this['changeMap']['set'](_0x462b3d,et(_0x462b3d,_0x18562e['snapshotNode']));else{if(_0x464a46==='child_changed'&&_0x517ff9==='child_changed')this['changeMap']['set'](_0x462b3d,Dt(_0x462b3d,_0x18562e['snapshotNode'],_0x2662d5['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x18562e+'\x20occurred\x20after\x20'+_0x2662d5);}}}}}else this['changeMap']['set'](_0x462b3d,_0x18562e);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x529b86){return null;}['getChildAfterChild'](_0x45bce5,_0x35385f,_0x4337ea){return null;}}const Go=new Tu();class ss{constructor(_0x472dba,_0xaf054,_0x562bba=null){this['writes_']=_0x472dba,this['viewCache_']=_0xaf054,this['optCompleteServerCache_']=_0x562bba;}['getCompleteChild'](_0x395f96){const _0x40850b=this['viewCache_']['eventCache'];if(_0x40850b['isCompleteForChild'](_0x395f96))return _0x40850b['getNode']()['getImmediateChild'](_0x395f96);{const _0x5f48f5=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x395f96,_0x5f48f5);}}['getChildAfterChild'](_0x34a806,_0x7af808,_0x40c5a4){const _0x77786d=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x5f2ed1=wu(this['writes_'],_0x77786d,_0x7af808,0x1,_0x40c5a4,_0x34a806);return _0x5f2ed1['length']===0x0?null:_0x5f2ed1[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x319861){return{'filter':_0x319861};}function bu(_0x107f59,_0x489d44){f(_0x489d44['eventCache']['getNode']()['isIndexed'](_0x107f59['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x489d44['serverCache']['getNode']()['isIndexed'](_0x107f59['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0xe51837,_0x24b32d,_0x3504e6,_0x3cc1d3,_0x1b5e85){const _0x2c9e25=new Cu();let _0x5d28e5,_0x46ed8d;if(_0x3504e6['type']===j['OVERWRITE']){const _0x4585b6=_0x3504e6;_0x4585b6['source']['fromUser']?_0x5d28e5=Si(_0xe51837,_0x24b32d,_0x4585b6['path'],_0x4585b6['snap'],_0x3cc1d3,_0x1b5e85,_0x2c9e25):(f(_0x4585b6['source']['fromServer'],'Unknown\x20source.'),_0x46ed8d=_0x4585b6['source']['tagged']||_0x24b32d['serverCache']['isFiltered']()&&!v(_0x4585b6['path']),_0x5d28e5=En(_0xe51837,_0x24b32d,_0x4585b6['path'],_0x4585b6['snap'],_0x3cc1d3,_0x1b5e85,_0x46ed8d,_0x2c9e25));}else{if(_0x3504e6['type']===j['MERGE']){const _0x440733=_0x3504e6;_0x440733['source']['fromUser']?_0x5d28e5=ku(_0xe51837,_0x24b32d,_0x440733['path'],_0x440733['children'],_0x3cc1d3,_0x1b5e85,_0x2c9e25):(f(_0x440733['source']['fromServer'],'Unknown\x20source.'),_0x46ed8d=_0x440733['source']['tagged']||_0x24b32d['serverCache']['isFiltered'](),_0x5d28e5=bi(_0xe51837,_0x24b32d,_0x440733['path'],_0x440733['children'],_0x3cc1d3,_0x1b5e85,_0x46ed8d,_0x2c9e25));}else{if(_0x3504e6['type']===j['ACK_USER_WRITE']){const _0x2ad376=_0x3504e6;_0x2ad376['revert']?_0x5d28e5=Ou(_0xe51837,_0x24b32d,_0x2ad376['path'],_0x3cc1d3,_0x1b5e85,_0x2c9e25):_0x5d28e5=Nu(_0xe51837,_0x24b32d,_0x2ad376['path'],_0x2ad376['affectedTree'],_0x3cc1d3,_0x1b5e85,_0x2c9e25);}else{if(_0x3504e6['type']===j['LISTEN_COMPLETE'])_0x5d28e5=Pu(_0xe51837,_0x24b32d,_0x3504e6['path'],_0x3cc1d3,_0x2c9e25);else throw rt('Unknown\x20operation\x20type:\x20'+_0x3504e6['type']);}}}const _0x1f47c8=_0x2c9e25['getChanges']();return Au(_0x24b32d,_0x5d28e5,_0x1f47c8),{'viewCache':_0x5d28e5,'changes':_0x1f47c8};}function Au(_0x3fbcf3,_0x4d521d,_0xf5d447){const _0x11c392=_0x4d521d['eventCache'];if(_0x11c392['isFullyInitialized']()){const _0x4bb7dc=_0x11c392['getNode']()['isLeafNode']()||_0x11c392['getNode']()['isEmpty'](),_0x2d6357=mn(_0x3fbcf3);(_0xf5d447['length']>0x0||!_0x3fbcf3['eventCache']['isFullyInitialized']()||_0x4bb7dc&&!_0x11c392['getNode']()['equals'](_0x2d6357)||!_0x11c392['getNode']()['getPriority']()['equals'](_0x2d6357['getPriority']()))&&_0xf5d447['push'](Lo(mn(_0x4d521d)));}}function qo(_0x5600fc,_0x1641db,_0x2b1856,_0x23fc57,_0x86c0a6,_0x33925d){const _0x1fde63=_0x1641db['eventCache'];if(vn(_0x23fc57,_0x2b1856)!=null)return _0x1641db;{let _0x4841f8,_0x555d9f;if(v(_0x2b1856)){if(f(_0x1641db['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x1641db['serverCache']['isFiltered']()){const _0x13f030=We(_0x1641db),_0x54149b=_0x13f030 instanceof g?_0x13f030:g['EMPTY_NODE'],_0x561399=ns(_0x23fc57,_0x54149b);_0x4841f8=_0x5600fc['filter']['updateFullNode'](_0x1641db['eventCache']['getNode'](),_0x561399,_0x33925d);}else{const _0x393776=yn(_0x23fc57,We(_0x1641db));_0x4841f8=_0x5600fc['filter']['updateFullNode'](_0x1641db['eventCache']['getNode'](),_0x393776,_0x33925d);}}else{const _0x4de771=y(_0x2b1856);if(_0x4de771==='.priority'){f(we(_0x2b1856)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x44c7f4=_0x1fde63['getNode']();_0x555d9f=_0x1641db['serverCache']['getNode']();const _0x1e2fe3=lr(_0x23fc57,_0x2b1856,_0x44c7f4,_0x555d9f);_0x1e2fe3!=null?_0x4841f8=_0x5600fc['filter']['updatePriority'](_0x44c7f4,_0x1e2fe3):_0x4841f8=_0x1fde63['getNode']();}else{const _0x48a9f4=b(_0x2b1856);let _0x512498;if(_0x1fde63['isCompleteForChild'](_0x4de771)){_0x555d9f=_0x1641db['serverCache']['getNode']();const _0x1666a1=lr(_0x23fc57,_0x2b1856,_0x1fde63['getNode'](),_0x555d9f);_0x1666a1!=null?_0x512498=_0x1fde63['getNode']()['getImmediateChild'](_0x4de771)['updateChild'](_0x48a9f4,_0x1666a1):_0x512498=_0x1fde63['getNode']()['getImmediateChild'](_0x4de771);}else _0x512498=is(_0x23fc57,_0x4de771,_0x1641db['serverCache']);_0x512498!=null?_0x4841f8=_0x5600fc['filter']['updateChild'](_0x1fde63['getNode'](),_0x4de771,_0x512498,_0x48a9f4,_0x86c0a6,_0x33925d):_0x4841f8=_0x1fde63['getNode']();}}return Tt(_0x1641db,_0x4841f8,_0x1fde63['isFullyInitialized']()||v(_0x2b1856),_0x5600fc['filter']['filtersNodes']());}}function En(_0xba3b8f,_0x1712b9,_0x41e8ef,_0xd48970,_0x19de45,_0x1503cd,_0x16b8f3,_0x2f215b){const _0x4aba84=_0x1712b9['serverCache'];let _0x5eadf0;const _0x52095e=_0x16b8f3?_0xba3b8f['filter']:_0xba3b8f['filter']['getIndexedFilter']();if(v(_0x41e8ef))_0x5eadf0=_0x52095e['updateFullNode'](_0x4aba84['getNode'](),_0xd48970,null);else{if(_0x52095e['filtersNodes']()&&!_0x4aba84['isFiltered']()){const _0x578f9a=_0x4aba84['getNode']()['updateChild'](_0x41e8ef,_0xd48970);_0x5eadf0=_0x52095e['updateFullNode'](_0x4aba84['getNode'](),_0x578f9a,null);}else{const _0x28fe3f=y(_0x41e8ef);if(!_0x4aba84['isCompleteForPath'](_0x41e8ef)&&we(_0x41e8ef)>0x1)return _0x1712b9;const _0x31ac16=b(_0x41e8ef),_0x4a5726=_0x4aba84['getNode']()['getImmediateChild'](_0x28fe3f)['updateChild'](_0x31ac16,_0xd48970);_0x28fe3f==='.priority'?_0x5eadf0=_0x52095e['updatePriority'](_0x4aba84['getNode'](),_0x4a5726):_0x5eadf0=_0x52095e['updateChild'](_0x4aba84['getNode'](),_0x28fe3f,_0x4a5726,_0x31ac16,Go,null);}}const _0x4fd210=Uo(_0x1712b9,_0x5eadf0,_0x4aba84['isFullyInitialized']()||v(_0x41e8ef),_0x52095e['filtersNodes']()),_0x4a6577=new ss(_0x19de45,_0x4fd210,_0x1503cd);return qo(_0xba3b8f,_0x4fd210,_0x41e8ef,_0x19de45,_0x4a6577,_0x2f215b);}function Si(_0x2a8fba,_0x438748,_0x304939,_0x886a93,_0x854a99,_0x4063e2,_0x51c022){const _0x2952ff=_0x438748['eventCache'];let _0x1596a,_0x4ac2ce;const _0x40cf2c=new ss(_0x854a99,_0x438748,_0x4063e2);if(v(_0x304939))_0x4ac2ce=_0x2a8fba['filter']['updateFullNode'](_0x438748['eventCache']['getNode'](),_0x886a93,_0x51c022),_0x1596a=Tt(_0x438748,_0x4ac2ce,!0x0,_0x2a8fba['filter']['filtersNodes']());else{const _0xbc45b4=y(_0x304939);if(_0xbc45b4==='.priority')_0x4ac2ce=_0x2a8fba['filter']['updatePriority'](_0x438748['eventCache']['getNode'](),_0x886a93),_0x1596a=Tt(_0x438748,_0x4ac2ce,_0x2952ff['isFullyInitialized'](),_0x2952ff['isFiltered']());else{const _0x18bc0c=b(_0x304939),_0x4d4995=_0x2952ff['getNode']()['getImmediateChild'](_0xbc45b4);let _0xf56ec4;if(v(_0x18bc0c))_0xf56ec4=_0x886a93;else{const _0xe2b1b2=_0x40cf2c['getCompleteChild'](_0xbc45b4);_0xe2b1b2!=null?zi(_0x18bc0c)==='.priority'&&_0xe2b1b2['getChild'](Ro(_0x18bc0c))['isEmpty']()?_0xf56ec4=_0xe2b1b2:_0xf56ec4=_0xe2b1b2['updateChild'](_0x18bc0c,_0x886a93):_0xf56ec4=g['EMPTY_NODE'];}if(_0x4d4995['equals'](_0xf56ec4))_0x1596a=_0x438748;else{const _0x3e39ab=_0x2a8fba['filter']['updateChild'](_0x2952ff['getNode'](),_0xbc45b4,_0xf56ec4,_0x18bc0c,_0x40cf2c,_0x51c022);_0x1596a=Tt(_0x438748,_0x3e39ab,_0x2952ff['isFullyInitialized'](),_0x2a8fba['filter']['filtersNodes']());}}}return _0x1596a;}function hr(_0x459aa3,_0x2cb670){return _0x459aa3['eventCache']['isCompleteForChild'](_0x2cb670);}function ku(_0x1eb17b,_0x3201e4,_0x3ac7a6,_0x2c7664,_0x19454f,_0x4167d7,_0x2afc91){let _0x53d054=_0x3201e4;return _0x2c7664['foreach']((_0x120fca,_0x6f49de)=>{const _0x43a7af=k(_0x3ac7a6,_0x120fca);hr(_0x3201e4,y(_0x43a7af))&&(_0x53d054=Si(_0x1eb17b,_0x53d054,_0x43a7af,_0x6f49de,_0x19454f,_0x4167d7,_0x2afc91));}),_0x2c7664['foreach']((_0x4378c8,_0x2627c6)=>{const _0x5702f0=k(_0x3ac7a6,_0x4378c8);hr(_0x3201e4,y(_0x5702f0))||(_0x53d054=Si(_0x1eb17b,_0x53d054,_0x5702f0,_0x2627c6,_0x19454f,_0x4167d7,_0x2afc91));}),_0x53d054;}function ur(_0x4a0c07,_0x137b15,_0xcbd893){return _0xcbd893['foreach']((_0x49f1d6,_0x42a86a)=>{_0x137b15=_0x137b15['updateChild'](_0x49f1d6,_0x42a86a);}),_0x137b15;}function bi(_0x24cd82,_0x268e3e,_0x34b396,_0x26cd72,_0x1a7b25,_0xe0aa38,_0x28da14,_0x338626){if(_0x268e3e['serverCache']['getNode']()['isEmpty']()&&!_0x268e3e['serverCache']['isFullyInitialized']())return _0x268e3e;let _0x5110e0=_0x268e3e,_0x5e58fa;v(_0x34b396)?_0x5e58fa=_0x26cd72:_0x5e58fa=new S(null)['setTree'](_0x34b396,_0x26cd72);const _0x1422f0=_0x268e3e['serverCache']['getNode']();return _0x5e58fa['children']['inorderTraversal']((_0x4fb65a,_0x1487ea)=>{if(_0x1422f0['hasChild'](_0x4fb65a)){const _0x5c7c73=_0x268e3e['serverCache']['getNode']()['getImmediateChild'](_0x4fb65a),_0x250b09=ur(_0x24cd82,_0x5c7c73,_0x1487ea);_0x5110e0=En(_0x24cd82,_0x5110e0,new C(_0x4fb65a),_0x250b09,_0x1a7b25,_0xe0aa38,_0x28da14,_0x338626);}}),_0x5e58fa['children']['inorderTraversal']((_0x2beeb3,_0x4984ac)=>{const _0x1e7828=!_0x268e3e['serverCache']['isCompleteForChild'](_0x2beeb3)&&_0x4984ac['value']===null;if(!_0x1422f0['hasChild'](_0x2beeb3)&&!_0x1e7828){const _0x591a82=_0x268e3e['serverCache']['getNode']()['getImmediateChild'](_0x2beeb3),_0x5aa4c5=ur(_0x24cd82,_0x591a82,_0x4984ac);_0x5110e0=En(_0x24cd82,_0x5110e0,new C(_0x2beeb3),_0x5aa4c5,_0x1a7b25,_0xe0aa38,_0x28da14,_0x338626);}}),_0x5110e0;}function Nu(_0x2bad84,_0x1e87d3,_0x55fffa,_0x203085,_0x43bc87,_0x127d30,_0x24e94e){if(vn(_0x43bc87,_0x55fffa)!=null)return _0x1e87d3;const _0x3e8ad3=_0x1e87d3['serverCache']['isFiltered'](),_0x193034=_0x1e87d3['serverCache'];if(_0x203085['value']!=null){if(v(_0x55fffa)&&_0x193034['isFullyInitialized']()||_0x193034['isCompleteForPath'](_0x55fffa))return En(_0x2bad84,_0x1e87d3,_0x55fffa,_0x193034['getNode']()['getChild'](_0x55fffa),_0x43bc87,_0x127d30,_0x3e8ad3,_0x24e94e);if(v(_0x55fffa)){let _0x3a5bbf=new S(null);return _0x193034['getNode']()['forEachChild'](ye,(_0x52fc5f,_0x1828c1)=>{_0x3a5bbf=_0x3a5bbf['set'](new C(_0x52fc5f),_0x1828c1);}),bi(_0x2bad84,_0x1e87d3,_0x55fffa,_0x3a5bbf,_0x43bc87,_0x127d30,_0x3e8ad3,_0x24e94e);}else return _0x1e87d3;}else{let _0x1d047e=new S(null);return _0x203085['foreach']((_0x4d70d6,_0x260920)=>{const _0x5d5494=k(_0x55fffa,_0x4d70d6);_0x193034['isCompleteForPath'](_0x5d5494)&&(_0x1d047e=_0x1d047e['set'](_0x4d70d6,_0x193034['getNode']()['getChild'](_0x5d5494)));}),bi(_0x2bad84,_0x1e87d3,_0x55fffa,_0x1d047e,_0x43bc87,_0x127d30,_0x3e8ad3,_0x24e94e);}}function Pu(_0x167852,_0x49a71f,_0x2c300c,_0x19b12b,_0x222bc7){const _0x1b6ae6=_0x49a71f['serverCache'],_0x3363b5=Uo(_0x49a71f,_0x1b6ae6['getNode'](),_0x1b6ae6['isFullyInitialized']()||v(_0x2c300c),_0x1b6ae6['isFiltered']());return qo(_0x167852,_0x3363b5,_0x2c300c,_0x19b12b,Go,_0x222bc7);}function Ou(_0x424c21,_0x4a2da8,_0x5c0772,_0x155c90,_0x5dffb9,_0xde6f5c){let _0x435d03;if(vn(_0x155c90,_0x5c0772)!=null)return _0x4a2da8;{const _0x403649=new ss(_0x155c90,_0x4a2da8,_0x5dffb9),_0x1f1ca6=_0x4a2da8['eventCache']['getNode']();let _0x130f10;if(v(_0x5c0772)||y(_0x5c0772)==='.priority'){let _0x3da47b;if(_0x4a2da8['serverCache']['isFullyInitialized']())_0x3da47b=yn(_0x155c90,We(_0x4a2da8));else{const _0x2d6023=_0x4a2da8['serverCache']['getNode']();f(_0x2d6023 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x3da47b=ns(_0x155c90,_0x2d6023);}_0x3da47b=_0x3da47b,_0x130f10=_0x424c21['filter']['updateFullNode'](_0x1f1ca6,_0x3da47b,_0xde6f5c);}else{const _0x3a707f=y(_0x5c0772);let _0x318592=is(_0x155c90,_0x3a707f,_0x4a2da8['serverCache']);_0x318592==null&&_0x4a2da8['serverCache']['isCompleteForChild'](_0x3a707f)&&(_0x318592=_0x1f1ca6['getImmediateChild'](_0x3a707f)),_0x318592!=null?_0x130f10=_0x424c21['filter']['updateChild'](_0x1f1ca6,_0x3a707f,_0x318592,b(_0x5c0772),_0x403649,_0xde6f5c):_0x4a2da8['eventCache']['getNode']()['hasChild'](_0x3a707f)?_0x130f10=_0x424c21['filter']['updateChild'](_0x1f1ca6,_0x3a707f,g['EMPTY_NODE'],b(_0x5c0772),_0x403649,_0xde6f5c):_0x130f10=_0x1f1ca6,_0x130f10['isEmpty']()&&_0x4a2da8['serverCache']['isFullyInitialized']()&&(_0x435d03=yn(_0x155c90,We(_0x4a2da8)),_0x435d03['isLeafNode']()&&(_0x130f10=_0x424c21['filter']['updateFullNode'](_0x130f10,_0x435d03,_0xde6f5c)));}return _0x435d03=_0x4a2da8['serverCache']['isFullyInitialized']()||vn(_0x155c90,w())!=null,Tt(_0x4a2da8,_0x130f10,_0x435d03,_0x424c21['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x10ac3c,_0x2dbc04){this['query_']=_0x10ac3c,this['eventRegistrations_']=[];const _0x1fb0e9=this['query_']['_queryParams'],_0x37b7b3=new Ji(_0x1fb0e9['getIndex']()),_0x476e23=Kh(_0x1fb0e9);this['processor_']=Su(_0x476e23);const _0xfb006a=_0x2dbc04['serverCache'],_0x47bf7b=_0x2dbc04['eventCache'],_0x28c519=_0x37b7b3['updateFullNode'](g['EMPTY_NODE'],_0xfb006a['getNode'](),null),_0x1ab95b=_0x476e23['updateFullNode'](g['EMPTY_NODE'],_0x47bf7b['getNode'](),null),_0x2cddc1=new Ce(_0x28c519,_0xfb006a['isFullyInitialized'](),_0x37b7b3['filtersNodes']()),_0xb600f9=new Ce(_0x1ab95b,_0x47bf7b['isFullyInitialized'](),_0x476e23['filtersNodes']());this['viewCache_']=Mn(_0xb600f9,_0x2cddc1),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x5aeaa3){return _0x5aeaa3['viewCache_']['serverCache']['getNode']();}function Lu(_0x4466fe){return mn(_0x4466fe['viewCache_']);}function xu(_0x59f32c,_0x4b0bc8){const _0x3ed162=We(_0x59f32c['viewCache_']);return _0x3ed162&&(_0x59f32c['query']['_queryParams']['loadsAllData']()||!v(_0x4b0bc8)&&!_0x3ed162['getImmediateChild'](y(_0x4b0bc8))['isEmpty']())?_0x3ed162['getChild'](_0x4b0bc8):null;}function dr(_0x59c4a3){return _0x59c4a3['eventRegistrations_']['length']===0x0;}function Fu(_0x1a159d,_0x21e58f){_0x1a159d['eventRegistrations_']['push'](_0x21e58f);}function fr(_0x56217b,_0x2c51f3,_0x395708){const _0x415e5c=[];if(_0x395708){f(_0x2c51f3==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x4b8b23=_0x56217b['query']['_path'];_0x56217b['eventRegistrations_']['forEach'](_0x2d15b4=>{const _0x1f57fd=_0x2d15b4['createCancelEvent'](_0x395708,_0x4b8b23);_0x1f57fd&&_0x415e5c['push'](_0x1f57fd);});}if(_0x2c51f3){let _0x33cbcb=[];for(let _0x5f0de6=0x0;_0x5f0de6<_0x56217b['eventRegistrations_']['length'];++_0x5f0de6){const _0x563042=_0x56217b['eventRegistrations_'][_0x5f0de6];if(!_0x563042['matches'](_0x2c51f3))_0x33cbcb['push'](_0x563042);else{if(_0x2c51f3['hasAnyCallback']()){_0x33cbcb=_0x33cbcb['concat'](_0x56217b['eventRegistrations_']['slice'](_0x5f0de6+0x1));break;}}}_0x56217b['eventRegistrations_']=_0x33cbcb;}else _0x56217b['eventRegistrations_']=[];return _0x415e5c;}function pr(_0x2e1798,_0x64d1df,_0x34b315,_0x44bad6){_0x64d1df['type']===j['MERGE']&&_0x64d1df['source']['queryId']!==null&&(f(We(_0x2e1798['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x2e1798['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x5e3167=_0x2e1798['viewCache_'],_0xecc455=Ru(_0x2e1798['processor_'],_0x5e3167,_0x64d1df,_0x34b315,_0x44bad6);return bu(_0x2e1798['processor_'],_0xecc455['viewCache']),f(_0xecc455['viewCache']['serverCache']['isFullyInitialized']()||!_0x5e3167['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x2e1798['viewCache_']=_0xecc455['viewCache'],zo(_0x2e1798,_0xecc455['changes'],_0xecc455['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x2022d4,_0x1bd015){const _0x2b7547=_0x2022d4['viewCache_']['eventCache'],_0xed9af=[];return _0x2b7547['getNode']()['isLeafNode']()||_0x2b7547['getNode']()['forEachChild'](R,(_0x4c453d,_0x599839)=>{_0xed9af['push'](et(_0x4c453d,_0x599839));}),_0x2b7547['isFullyInitialized']()&&_0xed9af['push'](Lo(_0x2b7547['getNode']())),zo(_0x2022d4,_0xed9af,_0x2b7547['getNode'](),_0x1bd015);}function zo(_0x77dca8,_0x2a4ddd,_0x2e9526,_0x3d11b6){const _0x3c738c=_0x3d11b6?[_0x3d11b6]:_0x77dca8['eventRegistrations_'];return ru(_0x77dca8['eventGenerator_'],_0x2a4ddd,_0x2e9526,_0x3c738c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x2fdf59){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x2fdf59;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x41e16d){return _0x41e16d['views']['size']===0x0;}function rs(_0x5e4418,_0x33f058,_0x1eb9dc,_0x2415da){const _0x1ab32d=_0x33f058['source']['queryId'];if(_0x1ab32d!==null){const _0x173579=_0x5e4418['views']['get'](_0x1ab32d);return f(_0x173579!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x173579,_0x33f058,_0x1eb9dc,_0x2415da);}else{let _0x252e72=[];for(const _0xf348d5 of _0x5e4418['views']['values']())_0x252e72=_0x252e72['concat'](pr(_0xf348d5,_0x33f058,_0x1eb9dc,_0x2415da));return _0x252e72;}}function Ko(_0x570846,_0x5e0fca,_0x5e14f8,_0x3edf2c,_0x53d139){const _0x3f432a=_0x5e0fca['_queryIdentifier'],_0x170e21=_0x570846['views']['get'](_0x3f432a);if(!_0x170e21){let _0x3a69a9=yn(_0x5e14f8,_0x53d139?_0x3edf2c:null),_0x29451a=!0x1;_0x3a69a9?_0x29451a=!0x0:_0x3edf2c instanceof g?(_0x3a69a9=ns(_0x5e14f8,_0x3edf2c),_0x29451a=!0x1):(_0x3a69a9=g['EMPTY_NODE'],_0x29451a=!0x1);const _0x480aa7=Mn(new Ce(_0x3a69a9,_0x29451a,!0x1),new Ce(_0x3edf2c,_0x53d139,!0x1));return new Du(_0x5e0fca,_0x480aa7);}return _0x170e21;}function Hu(_0xcf728c,_0x12757d,_0x56cc49,_0x5761f2,_0x565644,_0x4197b0){const _0x3bd56b=Ko(_0xcf728c,_0x12757d,_0x5761f2,_0x565644,_0x4197b0);return _0xcf728c['views']['has'](_0x12757d['_queryIdentifier'])||_0xcf728c['views']['set'](_0x12757d['_queryIdentifier'],_0x3bd56b),Fu(_0x3bd56b,_0x56cc49),Uu(_0x3bd56b,_0x56cc49);}function $u(_0x5cb27c,_0x1db11c,_0x27f57a,_0x157955){const _0x1d3c2e=_0x1db11c['_queryIdentifier'],_0x27af96=[];let _0x4662c2=[];const _0x533cc8=Te(_0x5cb27c);if(_0x1d3c2e==='default'){for(const [_0x3251e3,_0x7a424d]of _0x5cb27c['views']['entries']())_0x4662c2=_0x4662c2['concat'](fr(_0x7a424d,_0x27f57a,_0x157955)),dr(_0x7a424d)&&(_0x5cb27c['views']['delete'](_0x3251e3),_0x7a424d['query']['_queryParams']['loadsAllData']()||_0x27af96['push'](_0x7a424d['query']));}else{const _0x4809cc=_0x5cb27c['views']['get'](_0x1d3c2e);_0x4809cc&&(_0x4662c2=_0x4662c2['concat'](fr(_0x4809cc,_0x27f57a,_0x157955)),dr(_0x4809cc)&&(_0x5cb27c['views']['delete'](_0x1d3c2e),_0x4809cc['query']['_queryParams']['loadsAllData']()||_0x27af96['push'](_0x4809cc['query'])));}return _0x533cc8&&!Te(_0x5cb27c)&&_0x27af96['push'](new(Bu())(_0x1db11c['_repo'],_0x1db11c['_path'])),{'removed':_0x27af96,'events':_0x4662c2};}function Yo(_0x400bc8){const _0x1cc3f8=[];for(const _0x35138a of _0x400bc8['views']['values']())_0x35138a['query']['_queryParams']['loadsAllData']()||_0x1cc3f8['push'](_0x35138a);return _0x1cc3f8;}function Ee(_0x499c33,_0x29712a){let _0x5e3118=null;for(const _0x88329b of _0x499c33['views']['values']())_0x5e3118=_0x5e3118||xu(_0x88329b,_0x29712a);return _0x5e3118;}function Qo(_0x50e86b,_0x30cfc1){if(_0x30cfc1['_queryParams']['loadsAllData']())return xn(_0x50e86b);{const _0x4dc25b=_0x30cfc1['_queryIdentifier'];return _0x50e86b['views']['get'](_0x4dc25b);}}function Jo(_0x43899e,_0x303703){return Qo(_0x43899e,_0x303703)!=null;}function Te(_0x15eb4e){return xn(_0x15eb4e)!=null;}function xn(_0x308c13){for(const _0x57c4cb of _0x308c13['views']['values']())if(_0x57c4cb['query']['_queryParams']['loadsAllData']())return _0x57c4cb;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x4e1303){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x4e1303;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x4d96c5){this['listenProvider_']=_0x4d96c5,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x5284f0,_0x46369b,_0x2aceca,_0x93dd3d,_0x3bf99b){return lu(_0x5284f0['pendingWriteTree_'],_0x46369b,_0x2aceca,_0x93dd3d,_0x3bf99b),_0x3bf99b?ut(_0x5284f0,new Ue(Zi(),_0x46369b,_0x2aceca)):[];}function ju(_0x4ddb71,_0x338815,_0x143e70,_0x57eee8){hu(_0x4ddb71['pendingWriteTree_'],_0x338815,_0x143e70,_0x57eee8);const _0x46384c=S['fromObject'](_0x143e70);return ut(_0x4ddb71,new tt(Zi(),_0x338815,_0x46384c));}function pe(_0x502149,_0x1d4183,_0x5f3755=!0x1){const _0xc5f28c=uu(_0x502149['pendingWriteTree_'],_0x1d4183);if(du(_0x502149['pendingWriteTree_'],_0x1d4183)){let _0x384bea=new S(null);return _0xc5f28c['snap']!=null?_0x384bea=_0x384bea['set'](w(),!0x0):x(_0xc5f28c['children'],_0x35fa57=>{_0x384bea=_0x384bea['set'](new C(_0x35fa57),!0x0);}),ut(_0x502149,new gn(_0xc5f28c['path'],_0x384bea,_0x5f3755));}else return[];}function Gt(_0x1041ff,_0x186e1c,_0x255528){return ut(_0x1041ff,new Ue(es(),_0x186e1c,_0x255528));}function Ku(_0x3240ee,_0x229873,_0x4edc33){const _0x1ebb62=S['fromObject'](_0x4edc33);return ut(_0x3240ee,new tt(es(),_0x229873,_0x1ebb62));}function Yu(_0x266e24,_0x4a0e7f){return ut(_0x266e24,new Lt(es(),_0x4a0e7f));}function Qu(_0x208cd6,_0x57058a,_0x4ffcae){const _0x31c83c=as(_0x208cd6,_0x4ffcae);if(_0x31c83c){const _0xa01783=cs(_0x31c83c),_0x1dfdc9=_0xa01783['path'],_0x1dcef0=_0xa01783['queryId'],_0x78dfc1=F(_0x1dfdc9,_0x57058a),_0x3d7ad3=new Lt(ts(_0x1dcef0),_0x78dfc1);return ls(_0x208cd6,_0x1dfdc9,_0x3d7ad3);}else return[];}function Cn(_0x111a05,_0x5e4116,_0x4d3770,_0x67b682,_0x470d75=!0x1){const _0x573d6a=_0x5e4116['_path'],_0x46446d=_0x111a05['syncPointTree_']['get'](_0x573d6a);let _0x5af63f=[];if(_0x46446d&&(_0x5e4116['_queryIdentifier']==='default'||Jo(_0x46446d,_0x5e4116))){const _0x523877=$u(_0x46446d,_0x5e4116,_0x4d3770,_0x67b682);Vu(_0x46446d)&&(_0x111a05['syncPointTree_']=_0x111a05['syncPointTree_']['remove'](_0x573d6a));const _0x5afb83=_0x523877['removed'];if(_0x5af63f=_0x523877['events'],!_0x470d75){const _0x366c33=_0x5afb83['findIndex'](_0x404907=>_0x404907['_queryParams']['loadsAllData']())!==-0x1,_0x2e1622=_0x111a05['syncPointTree_']['findOnPath'](_0x573d6a,(_0x21b2d3,_0x4eea7b)=>Te(_0x4eea7b));if(_0x366c33&&!_0x2e1622){const _0x4d7033=_0x111a05['syncPointTree_']['subtree'](_0x573d6a);if(!_0x4d7033['isEmpty']()){const _0x42a975=Zu(_0x4d7033);for(let _0x460c2a=0x0;_0x460c2a<_0x42a975['length'];++_0x460c2a){const _0x36d3ee=_0x42a975[_0x460c2a],_0x5d34ba=_0x36d3ee['query'],_0x547efd=ta(_0x111a05,_0x36d3ee);_0x111a05['listenProvider_']['startListening'](bt(_0x5d34ba),xt(_0x111a05,_0x5d34ba),_0x547efd['hashFn'],_0x547efd['onComplete']);}}}!_0x2e1622&&_0x5afb83['length']>0x0&&!_0x67b682&&(_0x366c33?_0x111a05['listenProvider_']['stopListening'](bt(_0x5e4116),null):_0x5afb83['forEach'](_0x3ac8f0=>{const _0xcdf8af=_0x111a05['queryToTagMap']['get'](Un(_0x3ac8f0));_0x111a05['listenProvider_']['stopListening'](bt(_0x3ac8f0),_0xcdf8af);}));}ed(_0x111a05,_0x5afb83);}return _0x5af63f;}function Xo(_0x51eaaf,_0x20af83,_0x2ea09b,_0x3201f1){const _0x8a63fb=as(_0x51eaaf,_0x3201f1);if(_0x8a63fb!=null){const _0x4af440=cs(_0x8a63fb),_0xabc53f=_0x4af440['path'],_0x3b18a2=_0x4af440['queryId'],_0x3616e2=F(_0xabc53f,_0x20af83),_0x234b16=new Ue(ts(_0x3b18a2),_0x3616e2,_0x2ea09b);return ls(_0x51eaaf,_0xabc53f,_0x234b16);}else return[];}function Ju(_0x4a7e8f,_0x118f09,_0x412a63,_0x545afe){const _0x19f878=as(_0x4a7e8f,_0x545afe);if(_0x19f878){const _0x53c293=cs(_0x19f878),_0x15af08=_0x53c293['path'],_0xa9cc65=_0x53c293['queryId'],_0x2b1c92=F(_0x15af08,_0x118f09),_0x1c007e=S['fromObject'](_0x412a63),_0x27ede2=new tt(ts(_0xa9cc65),_0x2b1c92,_0x1c007e);return ls(_0x4a7e8f,_0x15af08,_0x27ede2);}else return[];}function Ri(_0x3a8869,_0x4acf01,_0x34f4bf,_0x5f1d92=!0x1){const _0x5781b0=_0x4acf01['_path'];let _0x5613cb=null,_0x14d985=!0x1;_0x3a8869['syncPointTree_']['foreachOnPath'](_0x5781b0,(_0x2c2438,_0x1c37f2)=>{const _0x20d758=F(_0x2c2438,_0x5781b0);_0x5613cb=_0x5613cb||Ee(_0x1c37f2,_0x20d758),_0x14d985=_0x14d985||Te(_0x1c37f2);});let _0x238c29=_0x3a8869['syncPointTree_']['get'](_0x5781b0);_0x238c29?(_0x14d985=_0x14d985||Te(_0x238c29),_0x5613cb=_0x5613cb||Ee(_0x238c29,w())):(_0x238c29=new jo(),_0x3a8869['syncPointTree_']=_0x3a8869['syncPointTree_']['set'](_0x5781b0,_0x238c29));let _0x4518f2;_0x5613cb!=null?_0x4518f2=!0x0:(_0x4518f2=!0x1,_0x5613cb=g['EMPTY_NODE'],_0x3a8869['syncPointTree_']['subtree'](_0x5781b0)['foreachChild']((_0x3001f3,_0x3bad72)=>{const _0x1e032a=Ee(_0x3bad72,w());_0x1e032a&&(_0x5613cb=_0x5613cb['updateImmediateChild'](_0x3001f3,_0x1e032a));}));const _0x8f67d7=Jo(_0x238c29,_0x4acf01);if(!_0x8f67d7&&!_0x4acf01['_queryParams']['loadsAllData']()){const _0x2725ca=Un(_0x4acf01);f(!_0x3a8869['queryToTagMap']['has'](_0x2725ca),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x48ffb6=td();_0x3a8869['queryToTagMap']['set'](_0x2725ca,_0x48ffb6),_0x3a8869['tagToQueryMap']['set'](_0x48ffb6,_0x2725ca);}const _0x980299=Ln(_0x3a8869['pendingWriteTree_'],_0x5781b0);let _0x268cc4=Hu(_0x238c29,_0x4acf01,_0x34f4bf,_0x980299,_0x5613cb,_0x4518f2);if(!_0x8f67d7&&!_0x14d985&&!_0x5f1d92){const _0x88394b=Qo(_0x238c29,_0x4acf01);_0x268cc4=_0x268cc4['concat'](nd(_0x3a8869,_0x4acf01,_0x88394b));}return _0x268cc4;}function Fn(_0x3a0c39,_0x923583,_0x1a52e5){const _0x458050=_0x3a0c39['pendingWriteTree_'],_0x190914=_0x3a0c39['syncPointTree_']['findOnPath'](_0x923583,(_0x44b06d,_0x206d41)=>{const _0x54b6e7=F(_0x44b06d,_0x923583),_0x3665f7=Ee(_0x206d41,_0x54b6e7);if(_0x3665f7)return _0x3665f7;});return Vo(_0x458050,_0x923583,_0x190914,_0x1a52e5,!0x0);}function Xu(_0x4ab1df,_0x5c3bc3){const _0x288124=_0x5c3bc3['_path'];let _0x4ed707=null;_0x4ab1df['syncPointTree_']['foreachOnPath'](_0x288124,(_0x439bc6,_0x307e30)=>{const _0x128898=F(_0x439bc6,_0x288124);_0x4ed707=_0x4ed707||Ee(_0x307e30,_0x128898);});let _0x1397bd=_0x4ab1df['syncPointTree_']['get'](_0x288124);_0x1397bd?_0x4ed707=_0x4ed707||Ee(_0x1397bd,w()):(_0x1397bd=new jo(),_0x4ab1df['syncPointTree_']=_0x4ab1df['syncPointTree_']['set'](_0x288124,_0x1397bd));const _0x58d6ed=_0x4ed707!=null,_0x259dd6=_0x58d6ed?new Ce(_0x4ed707,!0x0,!0x1):null,_0x2427f1=Ln(_0x4ab1df['pendingWriteTree_'],_0x5c3bc3['_path']),_0x1ad6fc=Ko(_0x1397bd,_0x5c3bc3,_0x2427f1,_0x58d6ed?_0x259dd6['getNode']():g['EMPTY_NODE'],_0x58d6ed);return Lu(_0x1ad6fc);}function ut(_0x47ed7e,_0x52578c){return Zo(_0x52578c,_0x47ed7e['syncPointTree_'],null,Ln(_0x47ed7e['pendingWriteTree_'],w()));}function Zo(_0x5a6a67,_0x400d1a,_0x19a31e,_0x21304b){if(v(_0x5a6a67['path']))return ea(_0x5a6a67,_0x400d1a,_0x19a31e,_0x21304b);{const _0x615c81=_0x400d1a['get'](w());_0x19a31e==null&&_0x615c81!=null&&(_0x19a31e=Ee(_0x615c81,w()));let _0x161fa9=[];const _0x5a4282=y(_0x5a6a67['path']),_0x384e65=_0x5a6a67['operationForChild'](_0x5a4282),_0x212a4b=_0x400d1a['children']['get'](_0x5a4282);if(_0x212a4b&&_0x384e65){const _0x412938=_0x19a31e?_0x19a31e['getImmediateChild'](_0x5a4282):null,_0x459062=Ho(_0x21304b,_0x5a4282);_0x161fa9=_0x161fa9['concat'](Zo(_0x384e65,_0x212a4b,_0x412938,_0x459062));}return _0x615c81&&(_0x161fa9=_0x161fa9['concat'](rs(_0x615c81,_0x5a6a67,_0x21304b,_0x19a31e))),_0x161fa9;}}function ea(_0x2c6259,_0x33817f,_0x128131,_0x50b553){const _0x2b7a7c=_0x33817f['get'](w());_0x128131==null&&_0x2b7a7c!=null&&(_0x128131=Ee(_0x2b7a7c,w()));let _0x1642d8=[];return _0x33817f['children']['inorderTraversal']((_0x5f1621,_0x33c633)=>{const _0x46e129=_0x128131?_0x128131['getImmediateChild'](_0x5f1621):null,_0x7acb4a=Ho(_0x50b553,_0x5f1621),_0x359153=_0x2c6259['operationForChild'](_0x5f1621);_0x359153&&(_0x1642d8=_0x1642d8['concat'](ea(_0x359153,_0x33c633,_0x46e129,_0x7acb4a)));}),_0x2b7a7c&&(_0x1642d8=_0x1642d8['concat'](rs(_0x2b7a7c,_0x2c6259,_0x50b553,_0x128131))),_0x1642d8;}function ta(_0xef15,_0x10cfb3){const _0x55edcc=_0x10cfb3['query'],_0x326630=xt(_0xef15,_0x55edcc);return{'hashFn':()=>(Mu(_0x10cfb3)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x351642=>{if(_0x351642==='ok')return _0x326630?Qu(_0xef15,_0x55edcc['_path'],_0x326630):Yu(_0xef15,_0x55edcc['_path']);{const _0x1d2205=Kl(_0x351642,_0x55edcc);return Cn(_0xef15,_0x55edcc,null,_0x1d2205);}}};}function xt(_0x43de9f,_0xed25fa){const _0x39ab7e=Un(_0xed25fa);return _0x43de9f['queryToTagMap']['get'](_0x39ab7e);}function Un(_0x266aa6){return _0x266aa6['_path']['toString']()+'$'+_0x266aa6['_queryIdentifier'];}function as(_0x3b2360,_0x5c757c){return _0x3b2360['tagToQueryMap']['get'](_0x5c757c);}function cs(_0x1ae6fc){const _0x5471b6=_0x1ae6fc['indexOf']('$');return f(_0x5471b6!==-0x1&&_0x5471b6<_0x1ae6fc['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x1ae6fc['substr'](_0x5471b6+0x1),'path':new C(_0x1ae6fc['substr'](0x0,_0x5471b6))};}function ls(_0x5cc246,_0x1e77c5,_0x5c1796){const _0x4df15e=_0x5cc246['syncPointTree_']['get'](_0x1e77c5);f(_0x4df15e,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x43626f=Ln(_0x5cc246['pendingWriteTree_'],_0x1e77c5);return rs(_0x4df15e,_0x5c1796,_0x43626f,null);}function Zu(_0x430334){return _0x430334['fold']((_0x187aa5,_0xb54ee1,_0x1358fc)=>{if(_0xb54ee1&&Te(_0xb54ee1))return[xn(_0xb54ee1)];{let _0x4a9ffd=[];return _0xb54ee1&&(_0x4a9ffd=Yo(_0xb54ee1)),x(_0x1358fc,(_0x51b1cf,_0xf342cb)=>{_0x4a9ffd=_0x4a9ffd['concat'](_0xf342cb);}),_0x4a9ffd;}});}function bt(_0x370887){return _0x370887['_queryParams']['loadsAllData']()&&!_0x370887['_queryParams']['isDefault']()?new(qu())(_0x370887['_repo'],_0x370887['_path']):_0x370887;}function ed(_0x459ae4,_0x5d297a){for(let _0x2fc52a=0x0;_0x2fc52a<_0x5d297a['length'];++_0x2fc52a){const _0xa1b31=_0x5d297a[_0x2fc52a];if(!_0xa1b31['_queryParams']['loadsAllData']()){const _0x4068e0=Un(_0xa1b31),_0x4202e0=_0x459ae4['queryToTagMap']['get'](_0x4068e0);_0x459ae4['queryToTagMap']['delete'](_0x4068e0),_0x459ae4['tagToQueryMap']['delete'](_0x4202e0);}}}function td(){return zu++;}function nd(_0x31c542,_0x11e967,_0x5161e1){const _0x26f583=_0x11e967['_path'],_0x5e9e12=xt(_0x31c542,_0x11e967),_0x4578a7=ta(_0x31c542,_0x5161e1),_0x14aa54=_0x31c542['listenProvider_']['startListening'](bt(_0x11e967),_0x5e9e12,_0x4578a7['hashFn'],_0x4578a7['onComplete']),_0x11b35d=_0x31c542['syncPointTree_']['subtree'](_0x26f583);if(_0x5e9e12)f(!Te(_0x11b35d['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x2380b0=_0x11b35d['fold']((_0x26b2a6,_0x4131af,_0x3ac232)=>{if(!v(_0x26b2a6)&&_0x4131af&&Te(_0x4131af))return[xn(_0x4131af)['query']];{let _0x5774ab=[];return _0x4131af&&(_0x5774ab=_0x5774ab['concat'](Yo(_0x4131af)['map'](_0x28a8bd=>_0x28a8bd['query']))),x(_0x3ac232,(_0x324e1a,_0x7af51c)=>{_0x5774ab=_0x5774ab['concat'](_0x7af51c);}),_0x5774ab;}});for(let _0x1314df=0x0;_0x1314df<_0x2380b0['length'];++_0x1314df){const _0x26e275=_0x2380b0[_0x1314df];_0x31c542['listenProvider_']['stopListening'](bt(_0x26e275),xt(_0x31c542,_0x26e275));}}return _0x14aa54;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x4f942e){this['node_']=_0x4f942e;}['getImmediateChild'](_0x1ec186){const _0x28b014=this['node_']['getImmediateChild'](_0x1ec186);return new hs(_0x28b014);}['node'](){return this['node_'];}}class us{constructor(_0xaeca2d,_0x430ded){this['syncTree_']=_0xaeca2d,this['path_']=_0x430ded;}['getImmediateChild'](_0x12699b){const _0x472106=k(this['path_'],_0x12699b);return new us(this['syncTree_'],_0x472106);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x50afac){return _0x50afac=_0x50afac||{},_0x50afac['timestamp']=_0x50afac['timestamp']||new Date()['getTime'](),_0x50afac;},gr=function(_0x1d503d,_0x59fbb4,_0x1703fc){if(!_0x1d503d||typeof _0x1d503d!='object')return _0x1d503d;if(f('.sv'in _0x1d503d,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x1d503d['.sv']=='string')return sd(_0x1d503d['.sv'],_0x59fbb4,_0x1703fc);if(typeof _0x1d503d['.sv']=='object')return rd(_0x1d503d['.sv'],_0x59fbb4);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1d503d,null,0x2));},sd=function(_0x1ae1c0,_0x4a0bf6,_0x10e503){switch(_0x1ae1c0){case'timestamp':return _0x10e503['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1ae1c0);}},rd=function(_0x2e0529,_0x51f840,_0x59f702){_0x2e0529['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x2e0529,null,0x2));const _0x13780f=_0x2e0529['increment'];typeof _0x13780f!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x13780f);const _0x5ae59f=_0x51f840['node']();if(f(_0x5ae59f!==null&&typeof _0x5ae59f<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x5ae59f['isLeafNode']())return _0x13780f;const _0x57e294=_0x5ae59f['getValue']();return typeof _0x57e294!='number'?_0x13780f:_0x57e294+_0x13780f;},na=function(_0x30bdb8,_0x146a75,_0x4afdfb,_0x26fc21){return fs(_0x146a75,new us(_0x4afdfb,_0x30bdb8),_0x26fc21);},ds=function(_0x468d14,_0x4bc78d,_0xa925c3){return fs(_0x468d14,new hs(_0x4bc78d),_0xa925c3);};function fs(_0x58ff18,_0x4516aa,_0x5278d4){const _0x517b75=_0x58ff18['getPriority']()['val'](),_0x5e200c=gr(_0x517b75,_0x4516aa['getImmediateChild']('.priority'),_0x5278d4);let _0x2e9481;if(_0x58ff18['isLeafNode']()){const _0x4eab7f=_0x58ff18,_0xbb2120=gr(_0x4eab7f['getValue'](),_0x4516aa,_0x5278d4);return _0xbb2120!==_0x4eab7f['getValue']()||_0x5e200c!==_0x4eab7f['getPriority']()['val']()?new D(_0xbb2120,P(_0x5e200c)):_0x58ff18;}else{const _0x534c3b=_0x58ff18;return _0x2e9481=_0x534c3b,_0x5e200c!==_0x534c3b['getPriority']()['val']()&&(_0x2e9481=_0x2e9481['updatePriority'](new D(_0x5e200c))),_0x534c3b['forEachChild'](R,(_0x49a63f,_0x326c72)=>{const _0x350004=fs(_0x326c72,_0x4516aa['getImmediateChild'](_0x49a63f),_0x5278d4);_0x350004!==_0x326c72&&(_0x2e9481=_0x2e9481['updateImmediateChild'](_0x49a63f,_0x350004));}),_0x2e9481;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x3ef855='',_0x2cf4a3=null,_0x5c8453={'children':{},'childCount':0x0}){this['name']=_0x3ef855,this['parent']=_0x2cf4a3,this['node']=_0x5c8453;}}function Wn(_0x4f9031,_0x16891a){let _0x315501=_0x16891a instanceof C?_0x16891a:new C(_0x16891a),_0x194aa5=_0x4f9031,_0x1fddaa=y(_0x315501);for(;_0x1fddaa!==null;){const _0x2ff0e8=De(_0x194aa5['node']['children'],_0x1fddaa)||{'children':{},'childCount':0x0};_0x194aa5=new ps(_0x1fddaa,_0x194aa5,_0x2ff0e8),_0x315501=b(_0x315501),_0x1fddaa=y(_0x315501);}return _0x194aa5;}function Ge(_0x24327b){return _0x24327b['node']['value'];}function _s(_0x691cf3,_0x35a184){_0x691cf3['node']['value']=_0x35a184,Ai(_0x691cf3);}function ia(_0x4863a9){return _0x4863a9['node']['childCount']>0x0;}function od(_0x48fde8){return Ge(_0x48fde8)===void 0x0&&!ia(_0x48fde8);}function Bn(_0x207c83,_0xcc6843){x(_0x207c83['node']['children'],(_0x1f0742,_0x57a494)=>{_0xcc6843(new ps(_0x1f0742,_0x207c83,_0x57a494));});}function sa(_0x44f79e,_0x593da0,_0x110fa7,_0x52a808){_0x110fa7&&_0x593da0(_0x44f79e),Bn(_0x44f79e,_0x2ff639=>{sa(_0x2ff639,_0x593da0,!0x0);});}function ad(_0x17c742,_0x38f717,_0x1e4515){let _0x11d80b=_0x17c742['parent'];for(;_0x11d80b!==null;){if(_0x38f717(_0x11d80b))return!0x0;_0x11d80b=_0x11d80b['parent'];}return!0x1;}function qt(_0x4a449b){return new C(_0x4a449b['parent']===null?_0x4a449b['name']:qt(_0x4a449b['parent'])+'/'+_0x4a449b['name']);}function Ai(_0x54a51a){_0x54a51a['parent']!==null&&cd(_0x54a51a['parent'],_0x54a51a['name'],_0x54a51a);}function cd(_0x2d1e5c,_0x30c958,_0x189fa5){const _0x8e2221=od(_0x189fa5),_0x57acba=J(_0x2d1e5c['node']['children'],_0x30c958);_0x8e2221&&_0x57acba?(delete _0x2d1e5c['node']['children'][_0x30c958],_0x2d1e5c['node']['childCount']--,Ai(_0x2d1e5c)):!_0x8e2221&&!_0x57acba&&(_0x2d1e5c['node']['children'][_0x30c958]=_0x189fa5['node'],_0x2d1e5c['node']['childCount']++,Ai(_0x2d1e5c));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x855b5b){return typeof _0x855b5b=='string'&&_0x855b5b['length']!==0x0&&!ld['test'](_0x855b5b);},ra=function(_0x5e1b79){return typeof _0x5e1b79=='string'&&_0x5e1b79['length']!==0x0&&!hd['test'](_0x5e1b79);},ud=function(_0x5f2c6e){return _0x5f2c6e&&(_0x5f2c6e=_0x5f2c6e['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x5f2c6e);},Tn=function(_0xd4db81){return _0xd4db81===null||typeof _0xd4db81=='string'||typeof _0xd4db81=='number'&&!Vi(_0xd4db81)||_0xd4db81&&typeof _0xd4db81=='object'&&J(_0xd4db81,'.sv');},zt=function(_0x54a061,_0x1eb420,_0x138211,_0x10361e){_0x10361e&&_0x1eb420===void 0x0||jt(Pn(_0x54a061,'value'),_0x1eb420,_0x138211);},jt=function(_0x324760,_0x479da5,_0xa83e96){const _0x5a3640=_0xa83e96 instanceof C?new Ah(_0xa83e96,_0x324760):_0xa83e96;if(_0x479da5===void 0x0)throw new Error(_0x324760+'contains\x20undefined\x20'+Pe(_0x5a3640));if(typeof _0x479da5=='function')throw new Error(_0x324760+'contains\x20a\x20function\x20'+Pe(_0x5a3640)+'\x20with\x20contents\x20=\x20'+_0x479da5['toString']());if(Vi(_0x479da5))throw new Error(_0x324760+'contains\x20'+_0x479da5['toString']()+'\x20'+Pe(_0x5a3640));if(typeof _0x479da5=='string'&&_0x479da5['length']>ai/0x3&&On(_0x479da5)>ai)throw new Error(_0x324760+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x5a3640)+'\x20(\x27'+_0x479da5['substring'](0x0,0x32)+'...\x27)');if(_0x479da5&&typeof _0x479da5=='object'){let _0xf174b8=!0x1,_0x1a5774=!0x1;if(x(_0x479da5,(_0x610361,_0x358bbc)=>{if(_0x610361==='.value')_0xf174b8=!0x0;else{if(_0x610361!=='.priority'&&_0x610361!=='.sv'&&(_0x1a5774=!0x0,!gs(_0x610361)))throw new Error(_0x324760+'\x20contains\x20an\x20invalid\x20key\x20('+_0x610361+')\x20'+Pe(_0x5a3640)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x5a3640,_0x610361),jt(_0x324760,_0x358bbc,_0x5a3640),Nh(_0x5a3640);}),_0xf174b8&&_0x1a5774)throw new Error(_0x324760+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x5a3640)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x446ed9,_0x2eb9b9){let _0x481a49,_0x5ec936;for(_0x481a49=0x0;_0x481a49<_0x2eb9b9['length'];_0x481a49++){_0x5ec936=_0x2eb9b9[_0x481a49];const _0x2777a9=Pt(_0x5ec936);for(let _0x2c5f35=0x0;_0x2c5f35<_0x2777a9['length'];_0x2c5f35++)if(!(_0x2777a9[_0x2c5f35]==='.priority'&&_0x2c5f35===_0x2777a9['length']-0x1)){if(!gs(_0x2777a9[_0x2c5f35]))throw new Error(_0x446ed9+'contains\x20an\x20invalid\x20key\x20('+_0x2777a9[_0x2c5f35]+')\x20in\x20path\x20'+_0x5ec936['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x2eb9b9['sort'](Rh);let _0x1f0ec3=null;for(_0x481a49=0x0;_0x481a49<_0x2eb9b9['length'];_0x481a49++){if(_0x5ec936=_0x2eb9b9[_0x481a49],_0x1f0ec3!==null&&G(_0x1f0ec3,_0x5ec936))throw new Error(_0x446ed9+'contains\x20a\x20path\x20'+_0x1f0ec3['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x5ec936['toString']());_0x1f0ec3=_0x5ec936;}},fd=function(_0x4be208,_0xbec250,_0x1224e0,_0x2205e6){const _0x249d00=Pn(_0x4be208,'values');if(!(_0xbec250&&typeof _0xbec250=='object')||Array['isArray'](_0xbec250))throw new Error(_0x249d00+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x579196=[];x(_0xbec250,(_0x1bf0c4,_0x3884cf)=>{const _0x355a33=new C(_0x1bf0c4);if(jt(_0x249d00,_0x3884cf,k(_0x1224e0,_0x355a33)),zi(_0x355a33)==='.priority'&&!Tn(_0x3884cf))throw new Error(_0x249d00+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x355a33['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x579196['push'](_0x355a33);}),dd(_0x249d00,_0x579196);},ms=function(_0x488fa8,_0xb8e558,_0x5c1875,_0x4a6cab){if(!ra(_0x5c1875))throw new Error(Pn(_0x488fa8,_0xb8e558)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x5c1875+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x3e6586,_0x5552d6,_0x256014,_0x367958){_0x256014&&(_0x256014=_0x256014['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x3e6586,_0x5552d6,_0x256014);},ys=function(_0x112042,_0x512594){if(y(_0x512594)==='.info')throw new Error(_0x112042+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0xeef2d9,_0x23b0cf){const _0x37d7d1=_0x23b0cf['path']['toString']();if(typeof _0x23b0cf['repoInfo']['host']!='string'||_0x23b0cf['repoInfo']['host']['length']===0x0||!gs(_0x23b0cf['repoInfo']['namespace'])&&_0x23b0cf['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x37d7d1['length']!==0x0&&!ud(_0x37d7d1))throw new Error(Pn(_0xeef2d9,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x4d29bb,_0x1dab1c){let _0xdfee81=null;for(let _0x2a4988=0x0;_0x2a4988<_0x1dab1c['length'];_0x2a4988++){const _0xfef499=_0x1dab1c[_0x2a4988],_0x588553=_0xfef499['getPath']();_0xdfee81!==null&&!ji(_0x588553,_0xdfee81['path'])&&(_0x4d29bb['eventLists_']['push'](_0xdfee81),_0xdfee81=null),_0xdfee81===null&&(_0xdfee81={'events':[],'path':_0x588553}),_0xdfee81['events']['push'](_0xfef499);}_0xdfee81&&_0x4d29bb['eventLists_']['push'](_0xdfee81);}function oa(_0x389530,_0x4545ee,_0x3ab8a0){Vn(_0x389530,_0x3ab8a0),aa(_0x389530,_0xcfdf65=>ji(_0xcfdf65,_0x4545ee));}function H(_0x2fbe79,_0x4cf083,_0x74b853){Vn(_0x2fbe79,_0x74b853),aa(_0x2fbe79,_0x4c2565=>G(_0x4c2565,_0x4cf083)||G(_0x4cf083,_0x4c2565));}function aa(_0x410f01,_0x2e558e){_0x410f01['recursionDepth_']++;let _0x2cf696=!0x0;for(let _0x56d74c=0x0;_0x56d74c<_0x410f01['eventLists_']['length'];_0x56d74c++){const _0x106ace=_0x410f01['eventLists_'][_0x56d74c];if(_0x106ace){const _0x45b698=_0x106ace['path'];_0x2e558e(_0x45b698)?(md(_0x410f01['eventLists_'][_0x56d74c]),_0x410f01['eventLists_'][_0x56d74c]=null):_0x2cf696=!0x1;}}_0x2cf696&&(_0x410f01['eventLists_']=[]),_0x410f01['recursionDepth_']--;}function md(_0x304739){for(let _0x54056e=0x0;_0x54056e<_0x304739['events']['length'];_0x54056e++){const _0x55213c=_0x304739['events'][_0x54056e];if(_0x55213c!==null){_0x304739['events'][_0x54056e]=null;const _0x5dfbfa=_0x55213c['getEventRunner']();wt&&L('event:\x20'+_0x55213c['toString']()),ht(_0x5dfbfa);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x1a221d,_0x88544a,_0x4e85c6,_0x339d1a){this['repoInfo_']=_0x1a221d,this['forceRestClient_']=_0x88544a,this['authTokenProvider_']=_0x4e85c6,this['appCheckProvider_']=_0x339d1a,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0xfa96b4,_0x10ed5e,_0x1bc9ec){if(_0xfa96b4['stats_']=Gi(_0xfa96b4['repoInfo_']),_0xfa96b4['forceRestClient_']||Xl())_0xfa96b4['server_']=new pn(_0xfa96b4['repoInfo_'],(_0x1f3474,_0x14765b,_0x50cbae,_0x39dc6b)=>{mr(_0xfa96b4,_0x1f3474,_0x14765b,_0x50cbae,_0x39dc6b);},_0xfa96b4['authTokenProvider_'],_0xfa96b4['appCheckProvider_']),setTimeout(()=>yr(_0xfa96b4,!0x0),0x0);else{if(typeof _0x1bc9ec<'u'&&_0x1bc9ec!==null){if(typeof _0x1bc9ec!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x1bc9ec);}catch(_0x22f486){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x22f486);}}_0xfa96b4['persistentConnection_']=new se(_0xfa96b4['repoInfo_'],_0x10ed5e,(_0x3f537f,_0x13f70a,_0x4326ee,_0x58b07d)=>{mr(_0xfa96b4,_0x3f537f,_0x13f70a,_0x4326ee,_0x58b07d);},_0x3551a4=>{yr(_0xfa96b4,_0x3551a4);},_0x627ed8=>{Id(_0xfa96b4,_0x627ed8);},_0xfa96b4['authTokenProvider_'],_0xfa96b4['appCheckProvider_'],_0x1bc9ec),_0xfa96b4['server_']=_0xfa96b4['persistentConnection_'];}_0xfa96b4['authTokenProvider_']['addTokenChangeListener'](_0x221622=>{_0xfa96b4['server_']['refreshAuthToken'](_0x221622);}),_0xfa96b4['appCheckProvider_']['addTokenChangeListener'](_0x401c3c=>{_0xfa96b4['server_']['refreshAppCheckToken'](_0x401c3c['token']);}),_0xfa96b4['statsReporter_']=ih(_0xfa96b4['repoInfo_'],()=>new iu(_0xfa96b4['stats_'],_0xfa96b4['server_'])),_0xfa96b4['infoData_']=new Xh(),_0xfa96b4['infoSyncTree_']=new _r({'startListening':(_0x569ee1,_0x4c5ce1,_0x36ed1b,_0x28ef26)=>{let _0x124d7b=[];const _0xe9714c=_0xfa96b4['infoData_']['getNode'](_0x569ee1['_path']);return _0xe9714c['isEmpty']()||(_0x124d7b=Gt(_0xfa96b4['infoSyncTree_'],_0x569ee1['_path'],_0xe9714c),setTimeout(()=>{_0x28ef26('ok');},0x0)),_0x124d7b;},'stopListening':()=>{}}),vs(_0xfa96b4,'connected',!0x1),_0xfa96b4['serverSyncTree_']=new _r({'startListening':(_0x4b64a2,_0xb88434,_0x1c1fd6,_0x18d5f2)=>(_0xfa96b4['server_']['listen'](_0x4b64a2,_0x1c1fd6,_0xb88434,(_0x40746c,_0x34fe97)=>{const _0x3256f2=_0x18d5f2(_0x40746c,_0x34fe97);H(_0xfa96b4['eventQueue_'],_0x4b64a2['_path'],_0x3256f2);}),[]),'stopListening':(_0x2d4082,_0x46dead)=>{_0xfa96b4['server_']['unlisten'](_0x2d4082,_0x46dead);}});}function la(_0x4f896b){const _0x841363=_0x4f896b['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x841363;}function Kt(_0x1f7d13){return id({'timestamp':la(_0x1f7d13)});}function mr(_0x1c7268,_0x4fc623,_0x234262,_0xe2770,_0x3a3a1f){_0x1c7268['dataUpdateCount']++;const _0x42cb46=new C(_0x4fc623);_0x234262=_0x1c7268['interceptServerDataCallback_']?_0x1c7268['interceptServerDataCallback_'](_0x4fc623,_0x234262):_0x234262;let _0x1a7639=[];if(_0x3a3a1f){if(_0xe2770){const _0x14eb7a=hn(_0x234262,_0x3092aa=>P(_0x3092aa));_0x1a7639=Ju(_0x1c7268['serverSyncTree_'],_0x42cb46,_0x14eb7a,_0x3a3a1f);}else{const _0x382131=P(_0x234262);_0x1a7639=Xo(_0x1c7268['serverSyncTree_'],_0x42cb46,_0x382131,_0x3a3a1f);}}else{if(_0xe2770){const _0x11d5cc=hn(_0x234262,_0x118fc3=>P(_0x118fc3));_0x1a7639=Ku(_0x1c7268['serverSyncTree_'],_0x42cb46,_0x11d5cc);}else{const _0x4931e2=P(_0x234262);_0x1a7639=Gt(_0x1c7268['serverSyncTree_'],_0x42cb46,_0x4931e2);}}let _0x436152=_0x42cb46;_0x1a7639['length']>0x0&&(_0x436152=it(_0x1c7268,_0x42cb46)),H(_0x1c7268['eventQueue_'],_0x436152,_0x1a7639);}function yr(_0x547f16,_0x1b4fa6){vs(_0x547f16,'connected',_0x1b4fa6),_0x1b4fa6===!0x1&&Sd(_0x547f16);}function Id(_0x1afa6a,_0x4dfbad){x(_0x4dfbad,(_0x60d8ee,_0x3e6561)=>{vs(_0x1afa6a,_0x60d8ee,_0x3e6561);});}function vs(_0x215f0d,_0x135d00,_0xe904f9){const _0x803629=new C('/.info/'+_0x135d00),_0x34269d=P(_0xe904f9);_0x215f0d['infoData_']['updateSnapshot'](_0x803629,_0x34269d);const _0x56b46d=Gt(_0x215f0d['infoSyncTree_'],_0x803629,_0x34269d);H(_0x215f0d['eventQueue_'],_0x803629,_0x56b46d);}function Hn(_0x4497f8){return _0x4497f8['nextWriteId_']++;}function wd(_0xc2eaed,_0x205a23,_0xe0967e){const _0x400b35=Xu(_0xc2eaed['serverSyncTree_'],_0x205a23);return _0x400b35!=null?Promise['resolve'](_0x400b35):_0xc2eaed['server_']['get'](_0x205a23)['then'](_0x59dacb=>{const _0x48b1cd=P(_0x59dacb)['withIndex'](_0x205a23['_queryParams']['getIndex']());Ri(_0xc2eaed['serverSyncTree_'],_0x205a23,_0xe0967e,!0x0);let _0x40ceca;if(_0x205a23['_queryParams']['loadsAllData']())_0x40ceca=Gt(_0xc2eaed['serverSyncTree_'],_0x205a23['_path'],_0x48b1cd);else{const _0x4d9d26=xt(_0xc2eaed['serverSyncTree_'],_0x205a23);_0x40ceca=Xo(_0xc2eaed['serverSyncTree_'],_0x205a23['_path'],_0x48b1cd,_0x4d9d26);}return H(_0xc2eaed['eventQueue_'],_0x205a23['_path'],_0x40ceca),Cn(_0xc2eaed['serverSyncTree_'],_0x205a23,_0xe0967e,null,!0x0),_0x48b1cd;},_0x1ca380=>(dt(_0xc2eaed,'get\x20for\x20query\x20'+O(_0x205a23)+'\x20failed:\x20'+_0x1ca380),Promise['reject'](new Error(_0x1ca380))));}function Cd(_0x14a8de,_0x5315d,_0x351705,_0x47fc0a,_0x295c37){dt(_0x14a8de,'set',{'path':_0x5315d['toString'](),'value':_0x351705,'priority':_0x47fc0a});const _0x9b77ab=Kt(_0x14a8de),_0x5a2cda=P(_0x351705,_0x47fc0a),_0x4d7c7b=Fn(_0x14a8de['serverSyncTree_'],_0x5315d),_0x5802d7=ds(_0x5a2cda,_0x4d7c7b,_0x9b77ab),_0x565a24=Hn(_0x14a8de),_0xa8ab30=os(_0x14a8de['serverSyncTree_'],_0x5315d,_0x5802d7,_0x565a24,!0x0);Vn(_0x14a8de['eventQueue_'],_0xa8ab30),_0x14a8de['server_']['put'](_0x5315d['toString'](),_0x5a2cda['val'](!0x0),(_0x47f6b0,_0xa427f4)=>{const _0x2609c5=_0x47f6b0==='ok';_0x2609c5||U('set\x20at\x20'+_0x5315d+'\x20failed:\x20'+_0x47f6b0);const _0x2259a8=pe(_0x14a8de['serverSyncTree_'],_0x565a24,!_0x2609c5);H(_0x14a8de['eventQueue_'],_0x5315d,_0x2259a8),ki(_0x14a8de,_0x295c37,_0x47f6b0,_0xa427f4);});const _0x1ca571=Is(_0x14a8de,_0x5315d);it(_0x14a8de,_0x1ca571),H(_0x14a8de['eventQueue_'],_0x1ca571,[]);}function Td(_0x4a60e6,_0x5eb4e4,_0x41ad9c,_0x1a7134){dt(_0x4a60e6,'update',{'path':_0x5eb4e4['toString'](),'value':_0x41ad9c});let _0x1fed24=!0x0;const _0x22433b=Kt(_0x4a60e6),_0x4495a5={};if(x(_0x41ad9c,(_0x3463ba,_0x568d9d)=>{_0x1fed24=!0x1,_0x4495a5[_0x3463ba]=na(k(_0x5eb4e4,_0x3463ba),P(_0x568d9d),_0x4a60e6['serverSyncTree_'],_0x22433b);}),_0x1fed24)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x4a60e6,_0x1a7134,'ok',void 0x0);else{const _0xdd1806=Hn(_0x4a60e6),_0x1ac423=ju(_0x4a60e6['serverSyncTree_'],_0x5eb4e4,_0x4495a5,_0xdd1806);Vn(_0x4a60e6['eventQueue_'],_0x1ac423),_0x4a60e6['server_']['merge'](_0x5eb4e4['toString'](),_0x41ad9c,(_0x5afa27,_0x1e0ac0)=>{const _0x34c389=_0x5afa27==='ok';_0x34c389||U('update\x20at\x20'+_0x5eb4e4+'\x20failed:\x20'+_0x5afa27);const _0x1923a3=pe(_0x4a60e6['serverSyncTree_'],_0xdd1806,!_0x34c389),_0x44c83f=_0x1923a3['length']>0x0?it(_0x4a60e6,_0x5eb4e4):_0x5eb4e4;H(_0x4a60e6['eventQueue_'],_0x44c83f,_0x1923a3),ki(_0x4a60e6,_0x1a7134,_0x5afa27,_0x1e0ac0);}),x(_0x41ad9c,_0x67d325=>{const _0x458f78=Is(_0x4a60e6,k(_0x5eb4e4,_0x67d325));it(_0x4a60e6,_0x458f78);}),H(_0x4a60e6['eventQueue_'],_0x5eb4e4,[]);}}function Sd(_0x101175){dt(_0x101175,'onDisconnectEvents');const _0x310066=Kt(_0x101175),_0x4be5f0=_n();Ii(_0x101175['onDisconnect_'],w(),(_0x282fd5,_0x56e44e)=>{const _0x59e7fc=na(_0x282fd5,_0x56e44e,_0x101175['serverSyncTree_'],_0x310066);Fo(_0x4be5f0,_0x282fd5,_0x59e7fc);});let _0x418687=[];Ii(_0x4be5f0,w(),(_0x43df3e,_0xa99014)=>{_0x418687=_0x418687['concat'](Gt(_0x101175['serverSyncTree_'],_0x43df3e,_0xa99014));const _0x45f055=Is(_0x101175,_0x43df3e);it(_0x101175,_0x45f055);}),_0x101175['onDisconnect_']=_n(),H(_0x101175['eventQueue_'],w(),_0x418687);}function bd(_0xbe796c,_0x218890,_0x24a8aa){let _0x4bcdf9;y(_0x218890['_path'])==='.info'?_0x4bcdf9=Ri(_0xbe796c['infoSyncTree_'],_0x218890,_0x24a8aa):_0x4bcdf9=Ri(_0xbe796c['serverSyncTree_'],_0x218890,_0x24a8aa),oa(_0xbe796c['eventQueue_'],_0x218890['_path'],_0x4bcdf9);}function Rd(_0x39a5fc,_0x2d53ff,_0x3c89f0){let _0x1ac14b;y(_0x2d53ff['_path'])==='.info'?_0x1ac14b=Cn(_0x39a5fc['infoSyncTree_'],_0x2d53ff,_0x3c89f0):_0x1ac14b=Cn(_0x39a5fc['serverSyncTree_'],_0x2d53ff,_0x3c89f0),oa(_0x39a5fc['eventQueue_'],_0x2d53ff['_path'],_0x1ac14b);}function ha(_0x11eec2){_0x11eec2['persistentConnection_']&&_0x11eec2['persistentConnection_']['interrupt'](ca);}function Ad(_0x356cdc){_0x356cdc['persistentConnection_']&&_0x356cdc['persistentConnection_']['resume'](ca);}function dt(_0x13fbd0,..._0x7c968e){let _0x39dbe0='';_0x13fbd0['persistentConnection_']&&(_0x39dbe0=_0x13fbd0['persistentConnection_']['id']+':'),L(_0x39dbe0,..._0x7c968e);}function ki(_0x517121,_0x55059d,_0x4eb505,_0x3e20ab){_0x55059d&&ht(()=>{if(_0x4eb505==='ok')_0x55059d(null);else{const _0x4d3598=(_0x4eb505||'error')['toUpperCase']();let _0x36b32d=_0x4d3598;_0x3e20ab&&(_0x36b32d+=':\x20'+_0x3e20ab);const _0x57b023=new Error(_0x36b32d);_0x57b023['code']=_0x4d3598,_0x55059d(_0x57b023);}});}function kd(_0x17048a,_0x4663bb,_0x39ee7f,_0x46d5e5,_0x333da9,_0x3be657){dt(_0x17048a,'transaction\x20on\x20'+_0x4663bb);const _0x335aa1={'path':_0x4663bb,'update':_0x39ee7f,'onComplete':_0x46d5e5,'status':null,'order':so(),'applyLocally':_0x3be657,'retryCount':0x0,'unwatcher':_0x333da9,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x5ce5e5=Es(_0x17048a,_0x4663bb,void 0x0);_0x335aa1['currentInputSnapshot']=_0x5ce5e5;const _0x31b6f8=_0x335aa1['update'](_0x5ce5e5['val']());if(_0x31b6f8===void 0x0)_0x335aa1['unwatcher'](),_0x335aa1['currentOutputSnapshotRaw']=null,_0x335aa1['currentOutputSnapshotResolved']=null,_0x335aa1['onComplete']&&_0x335aa1['onComplete'](null,!0x1,_0x335aa1['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x31b6f8,_0x335aa1['path']),_0x335aa1['status']=0x0;const _0x8ecbe5=Wn(_0x17048a['transactionQueueTree_'],_0x4663bb),_0x51dc37=Ge(_0x8ecbe5)||[];_0x51dc37['push'](_0x335aa1),_s(_0x8ecbe5,_0x51dc37);let _0x4fe633;typeof _0x31b6f8=='object'&&_0x31b6f8!==null&&J(_0x31b6f8,'.priority')?(_0x4fe633=De(_0x31b6f8,'.priority'),f(Tn(_0x4fe633),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x4fe633=(Fn(_0x17048a['serverSyncTree_'],_0x4663bb)||g['EMPTY_NODE'])['getPriority']()['val']();const _0xcb5c29=Kt(_0x17048a),_0x53b829=P(_0x31b6f8,_0x4fe633),_0x3ed2a6=ds(_0x53b829,_0x5ce5e5,_0xcb5c29);_0x335aa1['currentOutputSnapshotRaw']=_0x53b829,_0x335aa1['currentOutputSnapshotResolved']=_0x3ed2a6,_0x335aa1['currentWriteId']=Hn(_0x17048a);const _0x3a55a6=os(_0x17048a['serverSyncTree_'],_0x4663bb,_0x3ed2a6,_0x335aa1['currentWriteId'],_0x335aa1['applyLocally']);H(_0x17048a['eventQueue_'],_0x4663bb,_0x3a55a6),$n(_0x17048a,_0x17048a['transactionQueueTree_']);}}function Es(_0xe3dc9b,_0x51ec64,_0x14c88e){return Fn(_0xe3dc9b['serverSyncTree_'],_0x51ec64,_0x14c88e)||g['EMPTY_NODE'];}function $n(_0x2548c6,_0x5bfcba=_0x2548c6['transactionQueueTree_']){if(_0x5bfcba||Gn(_0x2548c6,_0x5bfcba),Ge(_0x5bfcba)){const _0x2cc186=da(_0x2548c6,_0x5bfcba);f(_0x2cc186['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x2cc186['every'](_0x57b722=>_0x57b722['status']===0x0)&&Nd(_0x2548c6,qt(_0x5bfcba),_0x2cc186);}else ia(_0x5bfcba)&&Bn(_0x5bfcba,_0x49d63c=>{$n(_0x2548c6,_0x49d63c);});}function Nd(_0xe2e5d7,_0x5d8c07,_0xa1340f){const _0x2579f2=_0xa1340f['map'](_0x211423=>_0x211423['currentWriteId']),_0x20bc84=Es(_0xe2e5d7,_0x5d8c07,_0x2579f2);let _0x12ccc8=_0x20bc84;const _0x310132=_0x20bc84['hash']();for(let _0x4e5409=0x0;_0x4e5409<_0xa1340f['length'];_0x4e5409++){const _0x1f90e2=_0xa1340f[_0x4e5409];f(_0x1f90e2['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x1f90e2['status']=0x1,_0x1f90e2['retryCount']++;const _0x22069e=F(_0x5d8c07,_0x1f90e2['path']);_0x12ccc8=_0x12ccc8['updateChild'](_0x22069e,_0x1f90e2['currentOutputSnapshotRaw']);}const _0x4f0a3e=_0x12ccc8['val'](!0x0),_0x426a9b=_0x5d8c07;_0xe2e5d7['server_']['put'](_0x426a9b['toString'](),_0x4f0a3e,_0x10f6ad=>{dt(_0xe2e5d7,'transaction\x20put\x20response',{'path':_0x426a9b['toString'](),'status':_0x10f6ad});let _0x55b38c=[];if(_0x10f6ad==='ok'){const _0x2570ff=[];for(let _0x53d672=0x0;_0x53d672<_0xa1340f['length'];_0x53d672++)_0xa1340f[_0x53d672]['status']=0x2,_0x55b38c=_0x55b38c['concat'](pe(_0xe2e5d7['serverSyncTree_'],_0xa1340f[_0x53d672]['currentWriteId'])),_0xa1340f[_0x53d672]['onComplete']&&_0x2570ff['push'](()=>_0xa1340f[_0x53d672]['onComplete'](null,!0x0,_0xa1340f[_0x53d672]['currentOutputSnapshotResolved'])),_0xa1340f[_0x53d672]['unwatcher']();Gn(_0xe2e5d7,Wn(_0xe2e5d7['transactionQueueTree_'],_0x5d8c07)),$n(_0xe2e5d7,_0xe2e5d7['transactionQueueTree_']),H(_0xe2e5d7['eventQueue_'],_0x5d8c07,_0x55b38c);for(let _0x693deb=0x0;_0x693deb<_0x2570ff['length'];_0x693deb++)ht(_0x2570ff[_0x693deb]);}else{if(_0x10f6ad==='datastale'){for(let _0x48fd67=0x0;_0x48fd67<_0xa1340f['length'];_0x48fd67++)_0xa1340f[_0x48fd67]['status']===0x3?_0xa1340f[_0x48fd67]['status']=0x4:_0xa1340f[_0x48fd67]['status']=0x0;}else{U('transaction\x20at\x20'+_0x426a9b['toString']()+'\x20failed:\x20'+_0x10f6ad);for(let _0x150a04=0x0;_0x150a04<_0xa1340f['length'];_0x150a04++)_0xa1340f[_0x150a04]['status']=0x4,_0xa1340f[_0x150a04]['abortReason']=_0x10f6ad;}it(_0xe2e5d7,_0x5d8c07);}},_0x310132);}function it(_0x51d2e9,_0x2833ee){const _0x33cbf3=ua(_0x51d2e9,_0x2833ee),_0x1eeabb=qt(_0x33cbf3),_0x29f965=da(_0x51d2e9,_0x33cbf3);return Pd(_0x51d2e9,_0x29f965,_0x1eeabb),_0x1eeabb;}function Pd(_0x39a75c,_0x4aa812,_0x4e34cf){if(_0x4aa812['length']===0x0)return;const _0x104ef0=[];let _0x498255=[];const _0x27ffb2=_0x4aa812['filter'](_0x337f44=>_0x337f44['status']===0x0)['map'](_0x1b685e=>_0x1b685e['currentWriteId']);for(let _0x135d97=0x0;_0x135d97<_0x4aa812['length'];_0x135d97++){const _0x4681aa=_0x4aa812[_0x135d97],_0x505590=F(_0x4e34cf,_0x4681aa['path']);let _0x7707ef=!0x1,_0x450647;if(f(_0x505590!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x4681aa['status']===0x4)_0x7707ef=!0x0,_0x450647=_0x4681aa['abortReason'],_0x498255=_0x498255['concat'](pe(_0x39a75c['serverSyncTree_'],_0x4681aa['currentWriteId'],!0x0));else{if(_0x4681aa['status']===0x0){if(_0x4681aa['retryCount']>=yd)_0x7707ef=!0x0,_0x450647='maxretry',_0x498255=_0x498255['concat'](pe(_0x39a75c['serverSyncTree_'],_0x4681aa['currentWriteId'],!0x0));else{const _0x9b2bb=Es(_0x39a75c,_0x4681aa['path'],_0x27ffb2);_0x4681aa['currentInputSnapshot']=_0x9b2bb;const _0x13767b=_0x4aa812[_0x135d97]['update'](_0x9b2bb['val']());if(_0x13767b!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x13767b,_0x4681aa['path']);let _0x346a86=P(_0x13767b);typeof _0x13767b=='object'&&_0x13767b!=null&&J(_0x13767b,'.priority')||(_0x346a86=_0x346a86['updatePriority'](_0x9b2bb['getPriority']()));const _0x3efbaa=_0x4681aa['currentWriteId'],_0x3eb759=Kt(_0x39a75c),_0x4dc9e1=ds(_0x346a86,_0x9b2bb,_0x3eb759);_0x4681aa['currentOutputSnapshotRaw']=_0x346a86,_0x4681aa['currentOutputSnapshotResolved']=_0x4dc9e1,_0x4681aa['currentWriteId']=Hn(_0x39a75c),_0x27ffb2['splice'](_0x27ffb2['indexOf'](_0x3efbaa),0x1),_0x498255=_0x498255['concat'](os(_0x39a75c['serverSyncTree_'],_0x4681aa['path'],_0x4dc9e1,_0x4681aa['currentWriteId'],_0x4681aa['applyLocally'])),_0x498255=_0x498255['concat'](pe(_0x39a75c['serverSyncTree_'],_0x3efbaa,!0x0));}else _0x7707ef=!0x0,_0x450647='nodata',_0x498255=_0x498255['concat'](pe(_0x39a75c['serverSyncTree_'],_0x4681aa['currentWriteId'],!0x0));}}}H(_0x39a75c['eventQueue_'],_0x4e34cf,_0x498255),_0x498255=[],_0x7707ef&&(_0x4aa812[_0x135d97]['status']=0x2,function(_0x2b7894){setTimeout(_0x2b7894,Math['floor'](0x0));}(_0x4aa812[_0x135d97]['unwatcher']),_0x4aa812[_0x135d97]['onComplete']&&(_0x450647==='nodata'?_0x104ef0['push'](()=>_0x4aa812[_0x135d97]['onComplete'](null,!0x1,_0x4aa812[_0x135d97]['currentInputSnapshot'])):_0x104ef0['push'](()=>_0x4aa812[_0x135d97]['onComplete'](new Error(_0x450647),!0x1,null))));}Gn(_0x39a75c,_0x39a75c['transactionQueueTree_']);for(let _0x7c073a=0x0;_0x7c073a<_0x104ef0['length'];_0x7c073a++)ht(_0x104ef0[_0x7c073a]);$n(_0x39a75c,_0x39a75c['transactionQueueTree_']);}function ua(_0x130bd0,_0x2c73f4){let _0x402ef7,_0x943209=_0x130bd0['transactionQueueTree_'];for(_0x402ef7=y(_0x2c73f4);_0x402ef7!==null&&Ge(_0x943209)===void 0x0;)_0x943209=Wn(_0x943209,_0x402ef7),_0x2c73f4=b(_0x2c73f4),_0x402ef7=y(_0x2c73f4);return _0x943209;}function da(_0x27941d,_0x1feb2c){const _0x4e6238=[];return fa(_0x27941d,_0x1feb2c,_0x4e6238),_0x4e6238['sort']((_0x516ceb,_0x21062d)=>_0x516ceb['order']-_0x21062d['order']),_0x4e6238;}function fa(_0x42cb1d,_0x9031d6,_0xc5d617){const _0x13b2ed=Ge(_0x9031d6);if(_0x13b2ed){for(let _0x4455a0=0x0;_0x4455a0<_0x13b2ed['length'];_0x4455a0++)_0xc5d617['push'](_0x13b2ed[_0x4455a0]);}Bn(_0x9031d6,_0x48614e=>{fa(_0x42cb1d,_0x48614e,_0xc5d617);});}function Gn(_0x51eae4,_0x5653db){const _0x585fb7=Ge(_0x5653db);if(_0x585fb7){let _0x1c78b2=0x0;for(let _0x212ccc=0x0;_0x212ccc<_0x585fb7['length'];_0x212ccc++)_0x585fb7[_0x212ccc]['status']!==0x2&&(_0x585fb7[_0x1c78b2]=_0x585fb7[_0x212ccc],_0x1c78b2++);_0x585fb7['length']=_0x1c78b2,_s(_0x5653db,_0x585fb7['length']>0x0?_0x585fb7:void 0x0);}Bn(_0x5653db,_0x4fdf88=>{Gn(_0x51eae4,_0x4fdf88);});}function Is(_0x334f33,_0x11dbf6){const _0x5ecae6=qt(ua(_0x334f33,_0x11dbf6)),_0x30c083=Wn(_0x334f33['transactionQueueTree_'],_0x11dbf6);return ad(_0x30c083,_0x14ae14=>{ci(_0x334f33,_0x14ae14);}),ci(_0x334f33,_0x30c083),sa(_0x30c083,_0x220893=>{ci(_0x334f33,_0x220893);}),_0x5ecae6;}function ci(_0x14e547,_0x232945){const _0x9864b9=Ge(_0x232945);if(_0x9864b9){const _0x21705c=[];let _0x327512=[],_0x1d9a55=-0x1;for(let _0x4ed944=0x0;_0x4ed944<_0x9864b9['length'];_0x4ed944++)_0x9864b9[_0x4ed944]['status']===0x3||(_0x9864b9[_0x4ed944]['status']===0x1?(f(_0x1d9a55===_0x4ed944-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x1d9a55=_0x4ed944,_0x9864b9[_0x4ed944]['status']=0x3,_0x9864b9[_0x4ed944]['abortReason']='set'):(f(_0x9864b9[_0x4ed944]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x9864b9[_0x4ed944]['unwatcher'](),_0x327512=_0x327512['concat'](pe(_0x14e547['serverSyncTree_'],_0x9864b9[_0x4ed944]['currentWriteId'],!0x0)),_0x9864b9[_0x4ed944]['onComplete']&&_0x21705c['push'](_0x9864b9[_0x4ed944]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x1d9a55===-0x1?_s(_0x232945,void 0x0):_0x9864b9['length']=_0x1d9a55+0x1,H(_0x14e547['eventQueue_'],qt(_0x232945),_0x327512);for(let _0x48b87d=0x0;_0x48b87d<_0x21705c['length'];_0x48b87d++)ht(_0x21705c[_0x48b87d]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x4c1a8a){let _0x402c39='';const _0x1328fb=_0x4c1a8a['split']('/');for(let _0x4c2603=0x0;_0x4c2603<_0x1328fb['length'];_0x4c2603++)if(_0x1328fb[_0x4c2603]['length']>0x0){let _0x8185d4=_0x1328fb[_0x4c2603];try{_0x8185d4=decodeURIComponent(_0x8185d4['replace'](/\+/g,'\x20'));}catch{}_0x402c39+='/'+_0x8185d4;}return _0x402c39;}function Dd(_0x2fb7a1){const _0x5f439c={};_0x2fb7a1['charAt'](0x0)==='?'&&(_0x2fb7a1=_0x2fb7a1['substring'](0x1));for(const _0x5d710a of _0x2fb7a1['split']('&')){if(_0x5d710a['length']===0x0)continue;const _0x35506a=_0x5d710a['split']('=');_0x35506a['length']===0x2?_0x5f439c[decodeURIComponent(_0x35506a[0x0])]=decodeURIComponent(_0x35506a[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x5d710a+'\x27\x20in\x20query\x20\x27'+_0x2fb7a1+'\x27');}return _0x5f439c;}const vr=function(_0x319b35,_0x255daa){const _0x1e9053=Md(_0x319b35),_0x351c91=_0x1e9053['namespace'];_0x1e9053['domain']==='firebase.com'&&ae(_0x1e9053['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x351c91||_0x351c91==='undefined')&&_0x1e9053['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x1e9053['secure']||$l();const _0x3600a3=_0x1e9053['scheme']==='ws'||_0x1e9053['scheme']==='wss';return{'repoInfo':new yo(_0x1e9053['host'],_0x1e9053['secure'],_0x351c91,_0x3600a3,_0x255daa,'',_0x351c91!==_0x1e9053['subdomain']),'path':new C(_0x1e9053['pathString'])};},Md=function(_0x19be9a){let _0x502c64='',_0x2c0edf='',_0xe80f82='',_0x2090a0='',_0x1498f5='',_0x405dc2=!0x0,_0x2aa574='https',_0x34fecf=0x1bb;if(typeof _0x19be9a=='string'){let _0x1cd1f8=_0x19be9a['indexOf']('//');_0x1cd1f8>=0x0&&(_0x2aa574=_0x19be9a['substring'](0x0,_0x1cd1f8-0x1),_0x19be9a=_0x19be9a['substring'](_0x1cd1f8+0x2));let _0x1d9b54=_0x19be9a['indexOf']('/');_0x1d9b54===-0x1&&(_0x1d9b54=_0x19be9a['length']);let _0x5698b0=_0x19be9a['indexOf']('?');_0x5698b0===-0x1&&(_0x5698b0=_0x19be9a['length']),_0x502c64=_0x19be9a['substring'](0x0,Math['min'](_0x1d9b54,_0x5698b0)),_0x1d9b54<_0x5698b0&&(_0x2090a0=Od(_0x19be9a['substring'](_0x1d9b54,_0x5698b0)));const _0x5695a7=Dd(_0x19be9a['substring'](Math['min'](_0x19be9a['length'],_0x5698b0)));_0x1cd1f8=_0x502c64['indexOf'](':'),_0x1cd1f8>=0x0?(_0x405dc2=_0x2aa574==='https'||_0x2aa574==='wss',_0x34fecf=parseInt(_0x502c64['substring'](_0x1cd1f8+0x1),0xa)):_0x1cd1f8=_0x502c64['length'];const _0x2dde25=_0x502c64['slice'](0x0,_0x1cd1f8);if(_0x2dde25['toLowerCase']()==='localhost')_0x2c0edf='localhost';else{if(_0x2dde25['split']('.')['length']<=0x2)_0x2c0edf=_0x2dde25;else{const _0x43b05d=_0x502c64['indexOf']('.');_0xe80f82=_0x502c64['substring'](0x0,_0x43b05d)['toLowerCase'](),_0x2c0edf=_0x502c64['substring'](_0x43b05d+0x1),_0x1498f5=_0xe80f82;}}'ns'in _0x5695a7&&(_0x1498f5=_0x5695a7['ns']);}return{'host':_0x502c64,'port':_0x34fecf,'domain':_0x2c0edf,'subdomain':_0xe80f82,'secure':_0x405dc2,'scheme':_0x2aa574,'pathString':_0x2090a0,'namespace':_0x1498f5};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0xc581f3=0x0;const _0x3db33c=[];return function(_0x27d12b){const _0x224a39=_0x27d12b===_0xc581f3;_0xc581f3=_0x27d12b;let _0x172874;const _0x3879b9=new Array(0x8);for(_0x172874=0x7;_0x172874>=0x0;_0x172874--)_0x3879b9[_0x172874]=Er['charAt'](_0x27d12b%0x40),_0x27d12b=Math['floor'](_0x27d12b/0x40);f(_0x27d12b===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x5ac24e=_0x3879b9['join']('');if(_0x224a39){for(_0x172874=0xb;_0x172874>=0x0&&_0x3db33c[_0x172874]===0x3f;_0x172874--)_0x3db33c[_0x172874]=0x0;_0x3db33c[_0x172874]++;}else{for(_0x172874=0x0;_0x172874<0xc;_0x172874++)_0x3db33c[_0x172874]=Math['floor'](Math['random']()*0x40);}for(_0x172874=0x0;_0x172874<0xc;_0x172874++)_0x5ac24e+=Er['charAt'](_0x3db33c[_0x172874]);return f(_0x5ac24e['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x5ac24e;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x9838c3,_0x1a3bee,_0x55ed6a,_0x3ba073){this['eventType']=_0x9838c3,this['eventRegistration']=_0x1a3bee,this['snapshot']=_0x55ed6a,this['prevName']=_0x3ba073;}['getPath'](){const _0x22c1b5=this['snapshot']['ref'];return this['eventType']==='value'?_0x22c1b5['_path']:_0x22c1b5['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x34d501,_0x4e539d,_0x3bdcbc){this['eventRegistration']=_0x34d501,this['error']=_0x4e539d,this['path']=_0x3bdcbc;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x27e032,_0x5165db){this['snapshotCallback']=_0x27e032,this['cancelCallback']=_0x5165db;}['onValue'](_0x52416c,_0x48113b){this['snapshotCallback']['call'](null,_0x52416c,_0x48113b);}['onCancel'](_0x3cefeb){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x3cefeb);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x4a8718){return this['snapshotCallback']===_0x4a8718['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x4a8718['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x4a8718['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x274605,_0x56220b,_0x2f68b7,_0x5cd04b){this['_repo']=_0x274605,this['_path']=_0x56220b,this['_queryParams']=_0x2f68b7,this['_orderByCalled']=_0x5cd04b;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x3772ee=rr(this['_queryParams']),_0x1e3e9b=Hi(_0x3772ee);return _0x1e3e9b==='{}'?'default':_0x1e3e9b;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x29aace){if(_0x29aace=N(_0x29aace),!(_0x29aace instanceof be))return!0x1;const _0x1c4e79=this['_repo']===_0x29aace['_repo'],_0x5558fa=ji(this['_path'],_0x29aace['_path']),_0x31f096=this['_queryIdentifier']===_0x29aace['_queryIdentifier'];return _0x1c4e79&&_0x5558fa&&_0x31f096;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0xa9f253,_0x449130){if(_0xa9f253['_orderByCalled']===!0x0)throw new Error(_0x449130+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x55c3a2){let _0x32a30f=null,_0x1ee87e=null;if(_0x55c3a2['hasStart']()&&(_0x32a30f=_0x55c3a2['getIndexStartValue']()),_0x55c3a2['hasEnd']()&&(_0x1ee87e=_0x55c3a2['getIndexEndValue']()),_0x55c3a2['getIndex']()===ye){const _0x455d2e='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2917cc='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x55c3a2['hasStart']()){if(_0x55c3a2['getIndexStartName']()!==Fe)throw new Error(_0x455d2e);if(typeof _0x32a30f!='string')throw new Error(_0x2917cc);}if(_0x55c3a2['hasEnd']()){if(_0x55c3a2['getIndexEndName']()!==Ie)throw new Error(_0x455d2e);if(typeof _0x1ee87e!='string')throw new Error(_0x2917cc);}}else{if(_0x55c3a2['getIndex']()===R){if(_0x32a30f!=null&&!Tn(_0x32a30f)||_0x1ee87e!=null&&!Tn(_0x1ee87e))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x55c3a2['getIndex']()instanceof Qi||_0x55c3a2['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x32a30f!=null&&typeof _0x32a30f=='object'||_0x1ee87e!=null&&typeof _0x1ee87e=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x1f577a){if(_0x1f577a['hasStart']()&&_0x1f577a['hasEnd']()&&_0x1f577a['hasLimit']()&&!_0x1f577a['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x5ba2a6,_0x30f661){super(_0x5ba2a6,_0x30f661,new Xi(),!0x1);}get['parent'](){const _0x3327d8=Ro(this['_path']);return _0x3327d8===null?null:new ee(this['_repo'],_0x3327d8);}get['root'](){let _0x5af74d=this;for(;_0x5af74d['parent']!==null;)_0x5af74d=_0x5af74d['parent'];return _0x5af74d;}}class st{constructor(_0x3270c2,_0x2a8273,_0x272ecf){this['_node']=_0x3270c2,this['ref']=_0x2a8273,this['_index']=_0x272ecf;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x2d7bb2){const _0x2e5011=new C(_0x2d7bb2),_0x501272=Ft(this['ref'],_0x2d7bb2);return new st(this['_node']['getChild'](_0x2e5011),_0x501272,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x48042e){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x49116f,_0x5cde65)=>_0x48042e(new st(_0x5cde65,Ft(this['ref'],_0x49116f),R)));}['hasChild'](_0x59ada9){const _0x473636=new C(_0x59ada9);return!this['_node']['getChild'](_0x473636)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x4e68a2,_0x45f4d5){return _0x4e68a2=N(_0x4e68a2),_0x4e68a2['_checkNotDeleted']('ref'),_0x45f4d5!==void 0x0?Ft(_0x4e68a2['_root'],_0x45f4d5):_0x4e68a2['_root'];}function Ft(_0x25d272,_0x401144){return _0x25d272=N(_0x25d272),y(_0x25d272['_path'])===null?pd('child','path',_0x401144):ms('child','path',_0x401144),new ee(_0x25d272['_repo'],k(_0x25d272['_path'],_0x401144));}function g_(_0x5e0fde,_0x464275){_0x5e0fde=N(_0x5e0fde),ys('push',_0x5e0fde['_path']),zt('push',_0x464275,_0x5e0fde['_path'],!0x0);const _0x58cd4d=la(_0x5e0fde['_repo']),_0x27704a=Ld(_0x58cd4d),_0x3da184=Ft(_0x5e0fde,_0x27704a),_0x43868a=Ft(_0x5e0fde,_0x27704a);let _0x5b9a94;return _0x464275!=null?_0x5b9a94=Ud(_0x43868a,_0x464275)['then'](()=>_0x43868a):_0x5b9a94=Promise['resolve'](_0x43868a),_0x3da184['then']=_0x5b9a94['then']['bind'](_0x5b9a94),_0x3da184['catch']=_0x5b9a94['then']['bind'](_0x5b9a94,void 0x0),_0x3da184;}function Ud(_0x5138de,_0x216c33){_0x5138de=N(_0x5138de),ys('set',_0x5138de['_path']),zt('set',_0x216c33,_0x5138de['_path'],!0x1);const _0x462159=new ot();return Cd(_0x5138de['_repo'],_0x5138de['_path'],_0x216c33,null,_0x462159['wrapCallback'](()=>{})),_0x462159['promise'];}function m_(_0x5dc6ca,_0x4ad535){fd('update',_0x4ad535,_0x5dc6ca['_path']);const _0x1d04c3=new ot();return Td(_0x5dc6ca['_repo'],_0x5dc6ca['_path'],_0x4ad535,_0x1d04c3['wrapCallback'](()=>{})),_0x1d04c3['promise'];}function y_(_0x358db0){_0x358db0=N(_0x358db0);const _0x26b2fa=new pa(()=>{}),_0x4cf563=new zn(_0x26b2fa);return wd(_0x358db0['_repo'],_0x358db0,_0x4cf563)['then'](_0x366f5b=>new st(_0x366f5b,new ee(_0x358db0['_repo'],_0x358db0['_path']),_0x358db0['_queryParams']['getIndex']()));}class zn{constructor(_0x4e8c71){this['callbackContext']=_0x4e8c71;}['respondsTo'](_0x11f723){return _0x11f723==='value';}['createEvent'](_0x253533,_0x3d46b3){const _0x1d9bc6=_0x3d46b3['_queryParams']['getIndex']();return new xd('value',this,new st(_0x253533['snapshotNode'],new ee(_0x3d46b3['_repo'],_0x3d46b3['_path']),_0x1d9bc6));}['getEventRunner'](_0x2a3810){return _0x2a3810['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x2a3810['error']):()=>this['callbackContext']['onValue'](_0x2a3810['snapshot'],null);}['createCancelEvent'](_0x3cf853,_0x2f6fd7){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x3cf853,_0x2f6fd7):null;}['matches'](_0x333a35){return _0x333a35 instanceof zn?!_0x333a35['callbackContext']||!this['callbackContext']?!0x0:_0x333a35['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x28c9f9,_0x54ca32,_0x36b6b8,_0x1abc7f,_0x1adebb){const _0x18472a=new pa(_0x36b6b8,void 0x0),_0xcab84b=new zn(_0x18472a);return bd(_0x28c9f9['_repo'],_0x28c9f9,_0xcab84b),()=>Rd(_0x28c9f9['_repo'],_0x28c9f9,_0xcab84b);}function Bd(_0xf08405,_0xfb1776,_0x30723e,_0x4dd5e2){return Wd(_0xf08405,'value',_0xfb1776);}class ft{}class ma extends ft{constructor(_0x5e254d,_0x2efe63){super(),this['_value']=_0x5e254d,this['_key']=_0x2efe63,this['type']='endAt';}['_apply'](_0xe2229c){zt('endAt',this['_value'],_0xe2229c['_path'],!0x0);const _0x2b7699=Jh(_0xe2229c['_queryParams'],this['_value'],this['_key']);if(ga(_0x2b7699),qn(_0x2b7699),_0xe2229c['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0xe2229c['_repo'],_0xe2229c['_path'],_0x2b7699,_0xe2229c['_orderByCalled']);}}function v_(_0x1d1e96,_0x34254a){return new ma(_0x1d1e96,_0x34254a);}class ya extends ft{constructor(_0x11fadb,_0x5baf7f){super(),this['_value']=_0x11fadb,this['_key']=_0x5baf7f,this['type']='startAt';}['_apply'](_0x3abe83){zt('startAt',this['_value'],_0x3abe83['_path'],!0x0);const _0x3bd6b4=Qh(_0x3abe83['_queryParams'],this['_value'],this['_key']);if(ga(_0x3bd6b4),qn(_0x3bd6b4),_0x3abe83['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x3abe83['_repo'],_0x3abe83['_path'],_0x3bd6b4,_0x3abe83['_orderByCalled']);}}function E_(_0x20797e=null,_0x2e4f89){return new ya(_0x20797e,_0x2e4f89);}class Vd extends ft{constructor(_0x418666){super(),this['_limit']=_0x418666,this['type']='limitToFirst';}['_apply'](_0x5817a4){if(_0x5817a4['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x5817a4['_repo'],_0x5817a4['_path'],Yh(_0x5817a4['_queryParams'],this['_limit']),_0x5817a4['_orderByCalled']);}}function I_(_0x5a5423){if(Math['floor'](_0x5a5423)!==_0x5a5423||_0x5a5423<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x5a5423);}class Hd extends ft{constructor(_0x4c181b){super(),this['_path']=_0x4c181b,this['type']='orderByChild';}['_apply'](_0x3186da){_a(_0x3186da,'orderByChild');const _0x1d7176=new C(this['_path']);if(v(_0x1d7176))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x511ec5=new Qi(_0x1d7176),_0x154279=xo(_0x3186da['_queryParams'],_0x511ec5);return qn(_0x154279),new be(_0x3186da['_repo'],_0x3186da['_path'],_0x154279,!0x0);}}function w_(_0x41575e){if(_0x41575e==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x41575e==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x41575e==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x41575e),new Hd(_0x41575e);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x22a5c5){_a(_0x22a5c5,'orderByKey');const _0xcbf5db=xo(_0x22a5c5['_queryParams'],ye);return qn(_0xcbf5db),new be(_0x22a5c5['_repo'],_0x22a5c5['_path'],_0xcbf5db,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x2d230a,_0x229fe4){super(),this['_value']=_0x2d230a,this['_key']=_0x229fe4,this['type']='equalTo';}['_apply'](_0x347bed){if(zt('equalTo',this['_value'],_0x347bed['_path'],!0x1),_0x347bed['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x347bed['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x347bed));}}function T_(_0x352e5f,_0x20817c){return new Gd(_0x352e5f,_0x20817c);}function S_(_0x8e4cc7,..._0x3cacf3){let _0x151892=N(_0x8e4cc7);for(const _0x3db574 of _0x3cacf3)_0x151892=_0x3db574['_apply'](_0x151892);return _0x151892;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x2559e0,_0x2ce9a2,_0x555683,_0x1094c3){const _0x270276=_0x2ce9a2['lastIndexOf'](':'),_0x381dc1=_0x2ce9a2['substring'](0x0,_0x270276),_0x2cc113=at(_0x381dc1);_0x2559e0['repoInfo_']=new yo(_0x2ce9a2,_0x2cc113,_0x2559e0['repoInfo_']['namespace'],_0x2559e0['repoInfo_']['webSocketOnly'],_0x2559e0['repoInfo_']['nodeAdmin'],_0x2559e0['repoInfo_']['persistenceKey'],_0x2559e0['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x555683),_0x1094c3&&(_0x2559e0['authTokenProvider_']=_0x1094c3);}function Kd(_0x586aa0,_0xd912c6,_0x253cca,_0x318722,_0x19d3c9){let _0x43b9a8=_0x318722||_0x586aa0['options']['databaseURL'];_0x43b9a8===void 0x0&&(_0x586aa0['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x586aa0['options']['projectId']),_0x43b9a8=_0x586aa0['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x18a665=vr(_0x43b9a8,_0x19d3c9),_0x2d4ed3=_0x18a665['repoInfo'],_0x7fa7e5;typeof process<'u'&&Vs&&(_0x7fa7e5=Vs[qd]),_0x7fa7e5?(_0x43b9a8='http://'+_0x7fa7e5+'?ns='+_0x2d4ed3['namespace'],_0x18a665=vr(_0x43b9a8,_0x19d3c9),_0x2d4ed3=_0x18a665['repoInfo']):_0x18a665['repoInfo']['secure'];const _0x9daef6=new eh(_0x586aa0['name'],_0x586aa0['options'],_0xd912c6);_d('Invalid\x20Firebase\x20Database\x20URL',_0x18a665),v(_0x18a665['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x631d4d=Qd(_0x2d4ed3,_0x586aa0,_0x9daef6,new Zl(_0x586aa0,_0x253cca));return new Jd(_0x631d4d,_0x586aa0);}function Yd(_0x418a92,_0x4f2359){const _0x314f3b=Ni[_0x4f2359];(!_0x314f3b||_0x314f3b[_0x418a92['key']]!==_0x418a92)&&ae('Database\x20'+_0x4f2359+'('+_0x418a92['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x418a92),delete _0x314f3b[_0x418a92['key']];}function Qd(_0x55dde4,_0x3cbf42,_0xcf0210,_0x21fe10){let _0x59ecf6=Ni[_0x3cbf42['name']];_0x59ecf6||(_0x59ecf6={},Ni[_0x3cbf42['name']]=_0x59ecf6);let _0x3f4baa=_0x59ecf6[_0x55dde4['toURLString']()];return _0x3f4baa&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x3f4baa=new vd(_0x55dde4,zd,_0xcf0210,_0x21fe10),_0x59ecf6[_0x55dde4['toURLString']()]=_0x3f4baa,_0x3f4baa;}class Jd{constructor(_0x1450cf,_0x25fd30){this['_repoInternal']=_0x1450cf,this['app']=_0x25fd30,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x1e8665){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x1e8665+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x3eba05=Zr(),_0x3bcf2d){const _0x5ced40=Bi(_0x3eba05,'database')['getImmediate']({'identifier':_0x3bcf2d});if(!_0x5ced40['_instanceStarted']){const _0x4888ff=cc('database');_0x4888ff&&Xd(_0x5ced40,..._0x4888ff);}return _0x5ced40;}function Xd(_0x4dd42b,_0x36874a,_0x53e16c,_0x599aa2={}){_0x4dd42b=N(_0x4dd42b),_0x4dd42b['_checkNotDeleted']('useEmulator');const _0x90fa39=_0x36874a+':'+_0x53e16c,_0x24aae7=_0x4dd42b['_repoInternal'];if(_0x4dd42b['_instanceStarted']){if(_0x90fa39===_0x4dd42b['_repoInternal']['repoInfo_']['host']&&Me(_0x599aa2,_0x24aae7['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x1e0583;if(_0x24aae7['repoInfo_']['nodeAdmin'])_0x599aa2['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x1e0583=new nn(nn['OWNER']);else{if(_0x599aa2['mockUserToken']){const _0x16012e=typeof _0x599aa2['mockUserToken']=='string'?_0x599aa2['mockUserToken']:lc(_0x599aa2['mockUserToken'],_0x4dd42b['app']['options']['projectId']);_0x1e0583=new nn(_0x16012e);}}at(_0x36874a)&&(jr(_0x36874a),Kr('Database',!0x0)),jd(_0x24aae7,_0x90fa39,_0x599aa2,_0x1e0583);}function R_(_0x87b0fd){_0x87b0fd=N(_0x87b0fd),_0x87b0fd['_checkNotDeleted']('goOffline'),ha(_0x87b0fd['_repo']);}function A_(_0x485187){_0x485187=N(_0x485187),_0x485187['_checkNotDeleted']('goOnline'),Ad(_0x485187['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x41709d){Ul(lt),Ze(new Le('database',(_0x29f6ce,{instanceIdentifier:_0x5517e1})=>{const _0x3dad9e=_0x29f6ce['getProvider']('app')['getImmediate'](),_0x10c36b=_0x29f6ce['getProvider']('auth-internal'),_0x4e0312=_0x29f6ce['getProvider']('app-check-internal');return Kd(_0x3dad9e,_0x10c36b,_0x4e0312,_0x5517e1);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x41709d),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x25f483,_0x35bcf2){this['committed']=_0x25f483,this['snapshot']=_0x35bcf2;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x510550,_0x4a6b7b,_0x75ef55){if(_0x510550=N(_0x510550),ys('Reference.transaction',_0x510550['_path']),_0x510550['key']==='.length'||_0x510550['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x510550['key']+'\x20is\x20a\x20read-only\x20object.';const _0x1b8657=!0x0,_0x233374=new ot(),_0x16e545=(_0x4dec8a,_0xdd8263,_0x13e1e7)=>{let _0x494982=null;_0x4dec8a?_0x233374['reject'](_0x4dec8a):(_0x494982=new st(_0x13e1e7,new ee(_0x510550['_repo'],_0x510550['_path']),R),_0x233374['resolve'](new tf(_0xdd8263,_0x494982)));},_0x16fb16=Bd(_0x510550,()=>{});return kd(_0x510550['_repo'],_0x510550['_path'],_0x4a6b7b,_0x16e545,_0x16fb16,_0x1b8657),_0x233374['promise'];}se['prototype']['simpleListen']=function(_0x49690a,_0xfbc1b4){this['sendRequest']('q',{'p':_0x49690a},_0xfbc1b4);},se['prototype']['echo']=function(_0x2caed3,_0x572c38){this['sendRequest']('echo',{'d':_0x2caed3},_0x572c38);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x5cbee4,..._0xa9484f){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x5cbee4,..._0xa9484f);}function sn(_0x3b7a1f,..._0xa7d992){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x3b7a1f,..._0xa7d992);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x1aedd0,..._0x27f3df){throw ws(_0x1aedd0,..._0x27f3df);}function X(_0x4fc933,..._0x71b314){return ws(_0x4fc933,..._0x71b314);}function Ia(_0x533a4a,_0x261696,_0x28e559){const _0x4a74b2={...nf(),[_0x261696]:_0x28e559};return new Bt('auth','Firebase',_0x4a74b2)['create'](_0x261696,{'appName':_0x533a4a['name']});}function re(_0x39ffd2){return Ia(_0x39ffd2,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x550181,..._0x4e00bf){if(typeof _0x550181!='string'){const _0x4a3fee=_0x4e00bf[0x0],_0x29a202=[..._0x4e00bf['slice'](0x1)];return _0x29a202[0x0]&&(_0x29a202[0x0]['appName']=_0x550181['name']),_0x550181['_errorFactory']['create'](_0x4a3fee,..._0x29a202);}return Ea['create'](_0x550181,..._0x4e00bf);}function m(_0x19dac7,_0x3dde45,..._0x5dd5a0){if(!_0x19dac7)throw ws(_0x3dde45,..._0x5dd5a0);}function ne(_0x1b0c66){const _0xc2dcd2='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1b0c66;throw sn(_0xc2dcd2),new Error(_0xc2dcd2);}function ce(_0x481652,_0x3a4fc5){_0x481652||ne(_0x3a4fc5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x52c5e3;return typeof self<'u'&&((_0x52c5e3=self['location'])==null?void 0x0:_0x52c5e3['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x529790;return typeof self<'u'&&((_0x529790=self['location'])==null?void 0x0:_0x529790['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x2722c4=navigator;return _0x2722c4['languages']&&_0x2722c4['languages'][0x0]||_0x2722c4['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x51f4f6,_0x57cf83){this['shortDelay']=_0x51f4f6,this['longDelay']=_0x57cf83,ce(_0x57cf83>_0x51f4f6,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x9e5b4,_0x522de8){ce(_0x9e5b4['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x445130}=_0x9e5b4['emulator'];return _0x522de8?''+_0x445130+(_0x522de8['startsWith']('/')?_0x522de8['slice'](0x1):_0x522de8):_0x445130;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x3aadb5,_0x234cae,_0x2175a4){this['fetchImpl']=_0x3aadb5,_0x234cae&&(this['headersImpl']=_0x234cae),_0x2175a4&&(this['responseImpl']=_0x2175a4);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x519783,_0x31fbfa){return _0x519783['tenantId']&&!_0x31fbfa['tenantId']?{..._0x31fbfa,'tenantId':_0x519783['tenantId']}:_0x31fbfa;}async function Ae(_0xe7c6b9,_0x1e85a7,_0x55b576,_0x14bf11,_0x35d317={}){return Ca(_0xe7c6b9,_0x35d317,async()=>{let _0x3a849a={},_0x11443a={};_0x14bf11&&(_0x1e85a7==='GET'?_0x11443a=_0x14bf11:_0x3a849a={'body':JSON['stringify'](_0x14bf11)});const _0x575d58=ct({'key':_0xe7c6b9['config']['apiKey'],..._0x11443a})['slice'](0x1),_0x5b8136=await _0xe7c6b9['_getAdditionalHeaders']();_0x5b8136['Content-Type']='application/json',_0xe7c6b9['languageCode']&&(_0x5b8136['X-Firebase-Locale']=_0xe7c6b9['languageCode']);const _0x5d637e={'method':_0x1e85a7,'headers':_0x5b8136,..._0x3a849a};return dc()||(_0x5d637e['referrerPolicy']='no-referrer'),_0xe7c6b9['emulatorConfig']&&at(_0xe7c6b9['emulatorConfig']['host'])&&(_0x5d637e['credentials']='include'),wa['fetch']()(await Ta(_0xe7c6b9,_0xe7c6b9['config']['apiHost'],_0x55b576,_0x575d58),_0x5d637e);});}async function Ca(_0x1b937e,_0x231322,_0x1ae9a1){_0x1b937e['_canInitEmulator']=!0x1;const _0x4dbb7e={...cf,..._0x231322};try{const _0x53d65b=new df(_0x1b937e),_0xad640c=await Promise['race']([_0x1ae9a1(),_0x53d65b['promise']]);_0x53d65b['clearNetworkTimeout']();const _0x55a807=await _0xad640c['json']();if('needConfirmation'in _0x55a807)throw tn(_0x1b937e,'account-exists-with-different-credential',_0x55a807);if(_0xad640c['ok']&&!('errorMessage'in _0x55a807))return _0x55a807;{const _0x5e5c85=_0xad640c['ok']?_0x55a807['errorMessage']:_0x55a807['error']['message'],[_0x56cd32,_0x425726]=_0x5e5c85['split']('\x20:\x20');if(_0x56cd32==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x1b937e,'credential-already-in-use',_0x55a807);if(_0x56cd32==='EMAIL_EXISTS')throw tn(_0x1b937e,'email-already-in-use',_0x55a807);if(_0x56cd32==='USER_DISABLED')throw tn(_0x1b937e,'user-disabled',_0x55a807);const _0x172069=_0x4dbb7e[_0x56cd32]||_0x56cd32['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x425726)throw Ia(_0x1b937e,_0x172069,_0x425726);Q(_0x1b937e,_0x172069);}}catch(_0x4abfce){if(_0x4abfce instanceof Se)throw _0x4abfce;Q(_0x1b937e,'network-request-failed',{'message':String(_0x4abfce)});}}async function Qt(_0x109667,_0x54864b,_0x92c847,_0x8112a0,_0x5e4e69={}){const _0x1d0c02=await Ae(_0x109667,_0x54864b,_0x92c847,_0x8112a0,_0x5e4e69);return'mfaPendingCredential'in _0x1d0c02&&Q(_0x109667,'multi-factor-auth-required',{'_serverResponse':_0x1d0c02}),_0x1d0c02;}async function Ta(_0x5431f3,_0x4f5cf7,_0x3192dc,_0x45380a){const _0x17a1dc=''+_0x4f5cf7+_0x3192dc+'?'+_0x45380a,_0x4964b1=_0x5431f3,_0x5a3cfb=_0x4964b1['config']['emulator']?Cs(_0x5431f3['config'],_0x17a1dc):_0x5431f3['config']['apiScheme']+'://'+_0x17a1dc;return lf['includes'](_0x3192dc)&&(await _0x4964b1['_persistenceManagerAvailable'],_0x4964b1['_getPersistenceType']()==='COOKIE')?_0x4964b1['_getPersistence']()['_getFinalTarget'](_0x5a3cfb)['toString']():_0x5a3cfb;}function uf(_0x1da6d2){switch(_0x1da6d2){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x528ecb){this['auth']=_0x528ecb,this['timer']=null,this['promise']=new Promise((_0x2c6182,_0x5d08b9)=>{this['timer']=setTimeout(()=>_0x5d08b9(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x4f8fe2,_0x360a5c,_0x2d7506){const _0x317488={'appName':_0x4f8fe2['name']};_0x2d7506['email']&&(_0x317488['email']=_0x2d7506['email']),_0x2d7506['phoneNumber']&&(_0x317488['phoneNumber']=_0x2d7506['phoneNumber']);const _0x3ad9e7=X(_0x4f8fe2,_0x360a5c,_0x317488);return _0x3ad9e7['customData']['_tokenResponse']=_0x2d7506,_0x3ad9e7;}function wr(_0x5e859d){return _0x5e859d!==void 0x0&&_0x5e859d['enterprise']!==void 0x0;}class ff{constructor(_0x5740a8){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x5740a8['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x5740a8['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x5740a8['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x25277a){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x39c3ce of this['recaptchaEnforcementState'])if(_0x39c3ce['provider']&&_0x39c3ce['provider']===_0x25277a)return uf(_0x39c3ce['enforcementState']);return null;}['isProviderEnabled'](_0x2badf9){return this['getProviderEnforcementState'](_0x2badf9)==='ENFORCE'||this['getProviderEnforcementState'](_0x2badf9)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x798ba,_0x1db566){return Ae(_0x798ba,'GET','/v2/recaptchaConfig',Re(_0x798ba,_0x1db566));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x5e6101,_0x57b84a){return Ae(_0x5e6101,'POST','/v1/accounts:delete',_0x57b84a);}async function bn(_0x2f4b85,_0x13a3c5){return Ae(_0x2f4b85,'POST','/v1/accounts:lookup',_0x13a3c5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x1a40c2){if(_0x1a40c2)try{const _0x1bbdfb=new Date(Number(_0x1a40c2));if(!isNaN(_0x1bbdfb['getTime']()))return _0x1bbdfb['toUTCString']();}catch{}}async function gf(_0x1740cf,_0x45a5e5=!0x1){const _0xde2be3=N(_0x1740cf),_0x2caafb=await _0xde2be3['getIdToken'](_0x45a5e5),_0x157c25=Ts(_0x2caafb);m(_0x157c25&&_0x157c25['exp']&&_0x157c25['auth_time']&&_0x157c25['iat'],_0xde2be3['auth'],'internal-error');const _0x292e5c=typeof _0x157c25['firebase']=='object'?_0x157c25['firebase']:void 0x0,_0x3d898d=_0x292e5c==null?void 0x0:_0x292e5c['sign_in_provider'];return{'claims':_0x157c25,'token':_0x2caafb,'authTime':Rt(li(_0x157c25['auth_time'])),'issuedAtTime':Rt(li(_0x157c25['iat'])),'expirationTime':Rt(li(_0x157c25['exp'])),'signInProvider':_0x3d898d||null,'signInSecondFactor':(_0x292e5c==null?void 0x0:_0x292e5c['sign_in_second_factor'])||null};}function li(_0x23539b){return Number(_0x23539b)*0x3e8;}function Ts(_0x2de4b1){const [_0x58e61a,_0x3e3fd1,_0x1d4845]=_0x2de4b1['split']('.');if(_0x58e61a===void 0x0||_0x3e3fd1===void 0x0||_0x1d4845===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x7399f4=ln(_0x3e3fd1);return _0x7399f4?JSON['parse'](_0x7399f4):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x20ea44){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x20ea44==null?void 0x0:_0x20ea44['toString']()),null;}}function Cr(_0x41c8e5){const _0x17f572=Ts(_0x41c8e5);return m(_0x17f572,'internal-error'),m(typeof _0x17f572['exp']<'u','internal-error'),m(typeof _0x17f572['iat']<'u','internal-error'),Number(_0x17f572['exp'])-Number(_0x17f572['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x1bd180,_0x41c962,_0xb75927=!0x1){if(_0xb75927)return _0x41c962;try{return await _0x41c962;}catch(_0x5e7f5a){throw _0x5e7f5a instanceof Se&&mf(_0x5e7f5a)&&_0x1bd180['auth']['currentUser']===_0x1bd180&&await _0x1bd180['auth']['signOut'](),_0x5e7f5a;}}function mf({code:_0x444fc1}){return _0x444fc1==='auth/user-disabled'||_0x444fc1==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x45ebc3){this['user']=_0x45ebc3,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x126f05){if(_0x126f05){const _0x502114=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x502114;}else{this['errorBackoff']=0x7530;const _0x5ebfc1=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x5ebfc1);}}['schedule'](_0x2bc66a=!0x1){if(!this['isRunning'])return;const _0x24e65c=this['getInterval'](_0x2bc66a);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x24e65c);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0xf58a62){(_0xf58a62==null?void 0x0:_0xf58a62['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x3f6c91,_0x23c0ae){this['createdAt']=_0x3f6c91,this['lastLoginAt']=_0x23c0ae,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x16f1af){this['createdAt']=_0x16f1af['createdAt'],this['lastLoginAt']=_0x16f1af['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x494c32){var _0x339a9f;const _0x143ec4=_0x494c32['auth'],_0x1735a5=await _0x494c32['getIdToken'](),_0x3e2048=await Ut(_0x494c32,bn(_0x143ec4,{'idToken':_0x1735a5}));m(_0x3e2048==null?void 0x0:_0x3e2048['users']['length'],_0x143ec4,'internal-error');const _0x320834=_0x3e2048['users'][0x0];_0x494c32['_notifyReloadListener'](_0x320834);const _0x1782de=(_0x339a9f=_0x320834['providerUserInfo'])!=null&&_0x339a9f['length']?Sa(_0x320834['providerUserInfo']):[],_0x27f1df=Ef(_0x494c32['providerData'],_0x1782de),_0x57fa6b=_0x494c32['isAnonymous'],_0x54c0fe=!(_0x494c32['email']&&_0x320834['passwordHash'])&&!(_0x27f1df!=null&&_0x27f1df['length']),_0x401b34=_0x57fa6b?_0x54c0fe:!0x1,_0x4cbdf4={'uid':_0x320834['localId'],'displayName':_0x320834['displayName']||null,'photoURL':_0x320834['photoUrl']||null,'email':_0x320834['email']||null,'emailVerified':_0x320834['emailVerified']||!0x1,'phoneNumber':_0x320834['phoneNumber']||null,'tenantId':_0x320834['tenantId']||null,'providerData':_0x27f1df,'metadata':new Oi(_0x320834['createdAt'],_0x320834['lastLoginAt']),'isAnonymous':_0x401b34};Object['assign'](_0x494c32,_0x4cbdf4);}async function vf(_0x46d544){const _0x8c236=N(_0x46d544);await Rn(_0x8c236),await _0x8c236['auth']['_persistUserIfCurrent'](_0x8c236),_0x8c236['auth']['_notifyListenersIfCurrent'](_0x8c236);}function Ef(_0x13d301,_0x5cab47){return[..._0x13d301['filter'](_0x1dea3b=>!_0x5cab47['some'](_0x24913c=>_0x24913c['providerId']===_0x1dea3b['providerId'])),..._0x5cab47];}function Sa(_0x6d786b){return _0x6d786b['map'](({providerId:_0x338c8b,..._0x37aac7})=>({'providerId':_0x338c8b,'uid':_0x37aac7['rawId']||'','displayName':_0x37aac7['displayName']||null,'email':_0x37aac7['email']||null,'phoneNumber':_0x37aac7['phoneNumber']||null,'photoURL':_0x37aac7['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x520162,_0x505b13){const _0x1aa909=await Ca(_0x520162,{},async()=>{const _0x515a2b=ct({'grant_type':'refresh_token','refresh_token':_0x505b13})['slice'](0x1),{tokenApiHost:_0x5f4809,apiKey:_0x230d25}=_0x520162['config'],_0x33584e=await Ta(_0x520162,_0x5f4809,'/v1/token','key='+_0x230d25),_0x1fabb2=await _0x520162['_getAdditionalHeaders']();_0x1fabb2['Content-Type']='application/x-www-form-urlencoded';const _0x222955={'method':'POST','headers':_0x1fabb2,'body':_0x515a2b};return _0x520162['emulatorConfig']&&at(_0x520162['emulatorConfig']['host'])&&(_0x222955['credentials']='include'),wa['fetch']()(_0x33584e,_0x222955);});return{'accessToken':_0x1aa909['access_token'],'expiresIn':_0x1aa909['expires_in'],'refreshToken':_0x1aa909['refresh_token']};}async function wf(_0x2040de,_0x1b61be){return Ae(_0x2040de,'POST','/v2/accounts:revokeToken',Re(_0x2040de,_0x1b61be));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x49b586){m(_0x49b586['idToken'],'internal-error'),m(typeof _0x49b586['idToken']<'u','internal-error'),m(typeof _0x49b586['refreshToken']<'u','internal-error');const _0x41fbb6='expiresIn'in _0x49b586&&typeof _0x49b586['expiresIn']<'u'?Number(_0x49b586['expiresIn']):Cr(_0x49b586['idToken']);this['updateTokensAndExpiration'](_0x49b586['idToken'],_0x49b586['refreshToken'],_0x41fbb6);}['updateFromIdToken'](_0x427c49){m(_0x427c49['length']!==0x0,'internal-error');const _0xd1b615=Cr(_0x427c49);this['updateTokensAndExpiration'](_0x427c49,null,_0xd1b615);}async['getToken'](_0x2bf797,_0x514dbd=!0x1){return!_0x514dbd&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x2bf797,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x2bf797,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x3c818c,_0x1fc6f2){const {accessToken:_0x664ec6,refreshToken:_0x29ee39,expiresIn:_0x2b6efd}=await If(_0x3c818c,_0x1fc6f2);this['updateTokensAndExpiration'](_0x664ec6,_0x29ee39,Number(_0x2b6efd));}['updateTokensAndExpiration'](_0xa67058,_0x8a828c,_0x114887){this['refreshToken']=_0x8a828c||null,this['accessToken']=_0xa67058||null,this['expirationTime']=Date['now']()+_0x114887*0x3e8;}static['fromJSON'](_0x43735a,_0x48d9f7){const {refreshToken:_0x467e1a,accessToken:_0x60a2f9,expirationTime:_0x1f5e16}=_0x48d9f7,_0x49dbb0=new Qe();return _0x467e1a&&(m(typeof _0x467e1a=='string','internal-error',{'appName':_0x43735a}),_0x49dbb0['refreshToken']=_0x467e1a),_0x60a2f9&&(m(typeof _0x60a2f9=='string','internal-error',{'appName':_0x43735a}),_0x49dbb0['accessToken']=_0x60a2f9),_0x1f5e16&&(m(typeof _0x1f5e16=='number','internal-error',{'appName':_0x43735a}),_0x49dbb0['expirationTime']=_0x1f5e16),_0x49dbb0;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x3ad850){this['accessToken']=_0x3ad850['accessToken'],this['refreshToken']=_0x3ad850['refreshToken'],this['expirationTime']=_0x3ad850['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x145373,_0x155cd0){m(typeof _0x145373=='string'||typeof _0x145373>'u','internal-error',{'appName':_0x155cd0});}class K{constructor({uid:_0x46c8d7,auth:_0x25f257,stsTokenManager:_0x4cafe8,..._0x36deef}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x46c8d7,this['auth']=_0x25f257,this['stsTokenManager']=_0x4cafe8,this['accessToken']=_0x4cafe8['accessToken'],this['displayName']=_0x36deef['displayName']||null,this['email']=_0x36deef['email']||null,this['emailVerified']=_0x36deef['emailVerified']||!0x1,this['phoneNumber']=_0x36deef['phoneNumber']||null,this['photoURL']=_0x36deef['photoURL']||null,this['isAnonymous']=_0x36deef['isAnonymous']||!0x1,this['tenantId']=_0x36deef['tenantId']||null,this['providerData']=_0x36deef['providerData']?[..._0x36deef['providerData']]:[],this['metadata']=new Oi(_0x36deef['createdAt']||void 0x0,_0x36deef['lastLoginAt']||void 0x0);}async['getIdToken'](_0x208389){const _0x1fce82=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x208389));return m(_0x1fce82,this['auth'],'internal-error'),this['accessToken']!==_0x1fce82&&(this['accessToken']=_0x1fce82,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x1fce82;}['getIdTokenResult'](_0x46e83c){return gf(this,_0x46e83c);}['reload'](){return vf(this);}['_assign'](_0x986a59){this!==_0x986a59&&(m(this['uid']===_0x986a59['uid'],this['auth'],'internal-error'),this['displayName']=_0x986a59['displayName'],this['photoURL']=_0x986a59['photoURL'],this['email']=_0x986a59['email'],this['emailVerified']=_0x986a59['emailVerified'],this['phoneNumber']=_0x986a59['phoneNumber'],this['isAnonymous']=_0x986a59['isAnonymous'],this['tenantId']=_0x986a59['tenantId'],this['providerData']=_0x986a59['providerData']['map'](_0x1bcd73=>({..._0x1bcd73})),this['metadata']['_copy'](_0x986a59['metadata']),this['stsTokenManager']['_assign'](_0x986a59['stsTokenManager']));}['_clone'](_0x563fa4){const _0x48ec=new K({...this,'auth':_0x563fa4,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x48ec['metadata']['_copy'](this['metadata']),_0x48ec;}['_onReload'](_0x1283b8){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x1283b8,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0xa66f02){this['reloadListener']?this['reloadListener'](_0xa66f02):this['reloadUserInfo']=_0xa66f02;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x18ac91,_0xa26422=!0x1){let _0x117e82=!0x1;_0x18ac91['idToken']&&_0x18ac91['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x18ac91),_0x117e82=!0x0),_0xa26422&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x117e82&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x1c8e44=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x1c8e44})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x56194e=>({..._0x56194e})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x28790f,_0x408ce5){const _0x233ec6=_0x408ce5['displayName']??void 0x0,_0x350f6a=_0x408ce5['email']??void 0x0,_0x44bf14=_0x408ce5['phoneNumber']??void 0x0,_0x2ffaaf=_0x408ce5['photoURL']??void 0x0,_0x57876e=_0x408ce5['tenantId']??void 0x0,_0x4f86ae=_0x408ce5['_redirectEventId']??void 0x0,_0x4bbcd6=_0x408ce5['createdAt']??void 0x0,_0x2108bd=_0x408ce5['lastLoginAt']??void 0x0,{uid:_0x307d3b,emailVerified:_0x1f7b54,isAnonymous:_0x56b36b,providerData:_0x480625,stsTokenManager:_0x11f7cf}=_0x408ce5;m(_0x307d3b&&_0x11f7cf,_0x28790f,'internal-error');const _0x434c35=Qe['fromJSON'](this['name'],_0x11f7cf);m(typeof _0x307d3b=='string',_0x28790f,'internal-error'),le(_0x233ec6,_0x28790f['name']),le(_0x350f6a,_0x28790f['name']),m(typeof _0x1f7b54=='boolean',_0x28790f,'internal-error'),m(typeof _0x56b36b=='boolean',_0x28790f,'internal-error'),le(_0x44bf14,_0x28790f['name']),le(_0x2ffaaf,_0x28790f['name']),le(_0x57876e,_0x28790f['name']),le(_0x4f86ae,_0x28790f['name']),le(_0x4bbcd6,_0x28790f['name']),le(_0x2108bd,_0x28790f['name']);const _0x5c8050=new K({'uid':_0x307d3b,'auth':_0x28790f,'email':_0x350f6a,'emailVerified':_0x1f7b54,'displayName':_0x233ec6,'isAnonymous':_0x56b36b,'photoURL':_0x2ffaaf,'phoneNumber':_0x44bf14,'tenantId':_0x57876e,'stsTokenManager':_0x434c35,'createdAt':_0x4bbcd6,'lastLoginAt':_0x2108bd});return _0x480625&&Array['isArray'](_0x480625)&&(_0x5c8050['providerData']=_0x480625['map'](_0x4734a7=>({..._0x4734a7}))),_0x4f86ae&&(_0x5c8050['_redirectEventId']=_0x4f86ae),_0x5c8050;}static async['_fromIdTokenResponse'](_0x571422,_0x34f644,_0x48e31=!0x1){const _0x7a7e7b=new Qe();_0x7a7e7b['updateFromServerResponse'](_0x34f644);const _0x484671=new K({'uid':_0x34f644['localId'],'auth':_0x571422,'stsTokenManager':_0x7a7e7b,'isAnonymous':_0x48e31});return await Rn(_0x484671),_0x484671;}static async['_fromGetAccountInfoResponse'](_0x4d9ac8,_0x9f47f0,_0x24e446){const _0x642531=_0x9f47f0['users'][0x0];m(_0x642531['localId']!==void 0x0,'internal-error');const _0x33723e=_0x642531['providerUserInfo']!==void 0x0?Sa(_0x642531['providerUserInfo']):[],_0x44ba53=!(_0x642531['email']&&_0x642531['passwordHash'])&&!(_0x33723e!=null&&_0x33723e['length']),_0x4e3148=new Qe();_0x4e3148['updateFromIdToken'](_0x24e446);const _0x196147=new K({'uid':_0x642531['localId'],'auth':_0x4d9ac8,'stsTokenManager':_0x4e3148,'isAnonymous':_0x44ba53}),_0x16d625={'uid':_0x642531['localId'],'displayName':_0x642531['displayName']||null,'photoURL':_0x642531['photoUrl']||null,'email':_0x642531['email']||null,'emailVerified':_0x642531['emailVerified']||!0x1,'phoneNumber':_0x642531['phoneNumber']||null,'tenantId':_0x642531['tenantId']||null,'providerData':_0x33723e,'metadata':new Oi(_0x642531['createdAt'],_0x642531['lastLoginAt']),'isAnonymous':!(_0x642531['email']&&_0x642531['passwordHash'])&&!(_0x33723e!=null&&_0x33723e['length'])};return Object['assign'](_0x196147,_0x16d625),_0x196147;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x2821db){ce(_0x2821db instanceof Function,'Expected\x20a\x20class\x20definition');let _0x3850cd=Tr['get'](_0x2821db);return _0x3850cd?(ce(_0x3850cd instanceof _0x2821db,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x3850cd):(_0x3850cd=new _0x2821db(),Tr['set'](_0x2821db,_0x3850cd),_0x3850cd);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x917a41,_0x240c2d){this['storage'][_0x917a41]=_0x240c2d;}async['_get'](_0x4e9c60){const _0x52f326=this['storage'][_0x4e9c60];return _0x52f326===void 0x0?null:_0x52f326;}async['_remove'](_0x111d94){delete this['storage'][_0x111d94];}['_addListener'](_0x2dcf25,_0x122716){}['_removeListener'](_0x1b8463,_0x5f1556){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x2fab6d,_0x55600a,_0x5706b0){return'firebase:'+_0x2fab6d+':'+_0x55600a+':'+_0x5706b0;}class Je{constructor(_0x50194a,_0x58f1b7,_0x21469d){this['persistence']=_0x50194a,this['auth']=_0x58f1b7,this['userKey']=_0x21469d;const {config:_0x200562,name:_0x32a244}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x200562['apiKey'],_0x32a244),this['fullPersistenceKey']=rn('persistence',_0x200562['apiKey'],_0x32a244),this['boundEventHandler']=_0x58f1b7['_onStorageEvent']['bind'](_0x58f1b7),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x49ae7e){return this['persistence']['_set'](this['fullUserKey'],_0x49ae7e['toJSON']());}async['getCurrentUser'](){const _0x493127=await this['persistence']['_get'](this['fullUserKey']);if(!_0x493127)return null;if(typeof _0x493127=='string'){const _0x1a56d8=await bn(this['auth'],{'idToken':_0x493127})['catch'](()=>{});return _0x1a56d8?K['_fromGetAccountInfoResponse'](this['auth'],_0x1a56d8,_0x493127):null;}return K['_fromJSON'](this['auth'],_0x493127);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x19e8ef){if(this['persistence']===_0x19e8ef)return;const _0x463f5a=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x19e8ef,_0x463f5a)return this['setCurrentUser'](_0x463f5a);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x16daf3,_0x3e9e2e,_0x31633e='authUser'){if(!_0x3e9e2e['length'])return new Je(ie(Sr),_0x16daf3,_0x31633e);const _0x2f345e=(await Promise['all'](_0x3e9e2e['map'](async _0x552f70=>{if(await _0x552f70['_isAvailable']())return _0x552f70;})))['filter'](_0x1ca28c=>_0x1ca28c);let _0x2c22d6=_0x2f345e[0x0]||ie(Sr);const _0x1d4fbc=rn(_0x31633e,_0x16daf3['config']['apiKey'],_0x16daf3['name']);let _0x6bb849=null;for(const _0x5da307 of _0x3e9e2e)try{const _0x1da9ea=await _0x5da307['_get'](_0x1d4fbc);if(_0x1da9ea){let _0x36d99e;if(typeof _0x1da9ea=='string'){const _0x162943=await bn(_0x16daf3,{'idToken':_0x1da9ea})['catch'](()=>{});if(!_0x162943)break;_0x36d99e=await K['_fromGetAccountInfoResponse'](_0x16daf3,_0x162943,_0x1da9ea);}else _0x36d99e=K['_fromJSON'](_0x16daf3,_0x1da9ea);_0x5da307!==_0x2c22d6&&(_0x6bb849=_0x36d99e),_0x2c22d6=_0x5da307;break;}}catch{}const _0x502b4d=_0x2f345e['filter'](_0x423c3d=>_0x423c3d['_shouldAllowMigration']);return!_0x2c22d6['_shouldAllowMigration']||!_0x502b4d['length']?new Je(_0x2c22d6,_0x16daf3,_0x31633e):(_0x2c22d6=_0x502b4d[0x0],_0x6bb849&&await _0x2c22d6['_set'](_0x1d4fbc,_0x6bb849['toJSON']()),await Promise['all'](_0x3e9e2e['map'](async _0x2eefc6=>{if(_0x2eefc6!==_0x2c22d6)try{await _0x2eefc6['_remove'](_0x1d4fbc);}catch{}})),new Je(_0x2c22d6,_0x16daf3,_0x31633e));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x131a0e){const _0x3698dd=_0x131a0e['toLowerCase']();if(_0x3698dd['includes']('opera/')||_0x3698dd['includes']('opr/')||_0x3698dd['includes']('opios/'))return'Opera';if(Na(_0x3698dd))return'IEMobile';if(_0x3698dd['includes']('msie')||_0x3698dd['includes']('trident/'))return'IE';if(_0x3698dd['includes']('edge/'))return'Edge';if(Ra(_0x3698dd))return'Firefox';if(_0x3698dd['includes']('silk/'))return'Silk';if(Oa(_0x3698dd))return'Blackberry';if(Da(_0x3698dd))return'Webos';if(Aa(_0x3698dd))return'Safari';if((_0x3698dd['includes']('chrome/')||ka(_0x3698dd))&&!_0x3698dd['includes']('edge/'))return'Chrome';if(Pa(_0x3698dd))return'Android';{const _0x2ee9e4=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x48b85f=_0x131a0e['match'](_0x2ee9e4);if((_0x48b85f==null?void 0x0:_0x48b85f['length'])===0x2)return _0x48b85f[0x1];}return'Other';}function Ra(_0x28b981=W()){return/firefox\//i['test'](_0x28b981);}function Aa(_0x460c1b=W()){const _0x79b0c2=_0x460c1b['toLowerCase']();return _0x79b0c2['includes']('safari/')&&!_0x79b0c2['includes']('chrome/')&&!_0x79b0c2['includes']('crios/')&&!_0x79b0c2['includes']('android');}function ka(_0x52a798=W()){return/crios\//i['test'](_0x52a798);}function Na(_0x4ef181=W()){return/iemobile/i['test'](_0x4ef181);}function Pa(_0x23b263=W()){return/android/i['test'](_0x23b263);}function Oa(_0x1d1a41=W()){return/blackberry/i['test'](_0x1d1a41);}function Da(_0x167018=W()){return/webos/i['test'](_0x167018);}function Ss(_0x23dfa0=W()){return/iphone|ipad|ipod/i['test'](_0x23dfa0)||/macintosh/i['test'](_0x23dfa0)&&/mobile/i['test'](_0x23dfa0);}function Cf(_0x45e4f4=W()){var _0x320a8f;return Ss(_0x45e4f4)&&!!((_0x320a8f=window['navigator'])!=null&&_0x320a8f['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x428066=W()){return Ss(_0x428066)||Pa(_0x428066)||Da(_0x428066)||Oa(_0x428066)||/windows phone/i['test'](_0x428066)||Na(_0x428066);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x4dba0a,_0x587820=[]){let _0x4bbd5a;switch(_0x4dba0a){case'Browser':_0x4bbd5a=br(W());break;case'Worker':_0x4bbd5a=br(W())+'-'+_0x4dba0a;break;default:_0x4bbd5a=_0x4dba0a;}const _0x5b4171=_0x587820['length']?_0x587820['join'](','):'FirebaseCore-web';return _0x4bbd5a+'/JsCore/'+lt+'/'+_0x5b4171;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x545d28){this['auth']=_0x545d28,this['queue']=[];}['pushCallback'](_0xaa2ab2,_0x5437f9){const _0x275093=_0x2ebdab=>new Promise((_0x2c8bf9,_0x1883f3)=>{try{const _0x4ad570=_0xaa2ab2(_0x2ebdab);_0x2c8bf9(_0x4ad570);}catch(_0x2e5a1f){_0x1883f3(_0x2e5a1f);}});_0x275093['onAbort']=_0x5437f9,this['queue']['push'](_0x275093);const _0x5b600b=this['queue']['length']-0x1;return()=>{this['queue'][_0x5b600b]=()=>Promise['resolve']();};}async['runMiddleware'](_0x38fa20){if(this['auth']['currentUser']===_0x38fa20)return;const _0x3d355c=[];try{for(const _0x490154 of this['queue'])await _0x490154(_0x38fa20),_0x490154['onAbort']&&_0x3d355c['push'](_0x490154['onAbort']);}catch(_0x403f7a){_0x3d355c['reverse']();for(const _0x368dc0 of _0x3d355c)try{_0x368dc0();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x403f7a==null?void 0x0:_0x403f7a['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x36a636,_0x137e7f={}){return Ae(_0x36a636,'GET','/v2/passwordPolicy',Re(_0x36a636,_0x137e7f));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x396c7f){var _0x141a1d;const _0x58e9a6=_0x396c7f['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x58e9a6['minPasswordLength']??Rf,_0x58e9a6['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x58e9a6['maxPasswordLength']),_0x58e9a6['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x58e9a6['containsLowercaseCharacter']),_0x58e9a6['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x58e9a6['containsUppercaseCharacter']),_0x58e9a6['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x58e9a6['containsNumericCharacter']),_0x58e9a6['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x58e9a6['containsNonAlphanumericCharacter']),this['enforcementState']=_0x396c7f['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x141a1d=_0x396c7f['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x141a1d['join'](''))??'',this['forceUpgradeOnSignin']=_0x396c7f['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x396c7f['schemaVersion'];}['validatePassword'](_0xd04480){const _0x4718bb={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0xd04480,_0x4718bb),this['validatePasswordCharacterOptions'](_0xd04480,_0x4718bb),_0x4718bb['isValid']&&(_0x4718bb['isValid']=_0x4718bb['meetsMinPasswordLength']??!0x0),_0x4718bb['isValid']&&(_0x4718bb['isValid']=_0x4718bb['meetsMaxPasswordLength']??!0x0),_0x4718bb['isValid']&&(_0x4718bb['isValid']=_0x4718bb['containsLowercaseLetter']??!0x0),_0x4718bb['isValid']&&(_0x4718bb['isValid']=_0x4718bb['containsUppercaseLetter']??!0x0),_0x4718bb['isValid']&&(_0x4718bb['isValid']=_0x4718bb['containsNumericCharacter']??!0x0),_0x4718bb['isValid']&&(_0x4718bb['isValid']=_0x4718bb['containsNonAlphanumericCharacter']??!0x0),_0x4718bb;}['validatePasswordLengthOptions'](_0x14873c,_0x51bd63){const _0x4b1e99=this['customStrengthOptions']['minPasswordLength'],_0x4167e2=this['customStrengthOptions']['maxPasswordLength'];_0x4b1e99&&(_0x51bd63['meetsMinPasswordLength']=_0x14873c['length']>=_0x4b1e99),_0x4167e2&&(_0x51bd63['meetsMaxPasswordLength']=_0x14873c['length']<=_0x4167e2);}['validatePasswordCharacterOptions'](_0x2cae43,_0x4d00a4){this['updatePasswordCharacterOptionsStatuses'](_0x4d00a4,!0x1,!0x1,!0x1,!0x1);let _0xea9bd5;for(let _0x135e38=0x0;_0x135e38<_0x2cae43['length'];_0x135e38++)_0xea9bd5=_0x2cae43['charAt'](_0x135e38),this['updatePasswordCharacterOptionsStatuses'](_0x4d00a4,_0xea9bd5>='a'&&_0xea9bd5<='z',_0xea9bd5>='A'&&_0xea9bd5<='Z',_0xea9bd5>='0'&&_0xea9bd5<='9',this['allowedNonAlphanumericCharacters']['includes'](_0xea9bd5));}['updatePasswordCharacterOptionsStatuses'](_0x26ffcb,_0x51618a,_0x4045a4,_0x294db3,_0x2acfa4){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x26ffcb['containsLowercaseLetter']||(_0x26ffcb['containsLowercaseLetter']=_0x51618a)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x26ffcb['containsUppercaseLetter']||(_0x26ffcb['containsUppercaseLetter']=_0x4045a4)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x26ffcb['containsNumericCharacter']||(_0x26ffcb['containsNumericCharacter']=_0x294db3)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x26ffcb['containsNonAlphanumericCharacter']||(_0x26ffcb['containsNonAlphanumericCharacter']=_0x2acfa4));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x14446e,_0x365145,_0xd06cc3,_0x167b50){this['app']=_0x14446e,this['heartbeatServiceProvider']=_0x365145,this['appCheckServiceProvider']=_0xd06cc3,this['config']=_0x167b50,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x14446e['name'],this['clientVersion']=_0x167b50['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x10ace0=>this['_resolvePersistenceManagerAvailable']=_0x10ace0);}['_initializeWithPersistence'](_0x1c0b9c,_0x38a700){return _0x38a700&&(this['_popupRedirectResolver']=ie(_0x38a700)),this['_initializationPromise']=this['queue'](async()=>{var _0x2e1b26,_0x27cd3b,_0x365cb2;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x1c0b9c),(_0x2e1b26=this['_resolvePersistenceManagerAvailable'])==null||_0x2e1b26['call'](this),!this['_deleted'])){if((_0x27cd3b=this['_popupRedirectResolver'])!=null&&_0x27cd3b['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x38a700),this['lastNotifiedUid']=((_0x365cb2=this['currentUser'])==null?void 0x0:_0x365cb2['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x5ed2bb=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x5ed2bb)){if(this['currentUser']&&_0x5ed2bb&&this['currentUser']['uid']===_0x5ed2bb['uid']){this['_currentUser']['_assign'](_0x5ed2bb),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x5ed2bb,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x3d1b8f){try{const _0x453301=await bn(this,{'idToken':_0x3d1b8f}),_0x280377=await K['_fromGetAccountInfoResponse'](this,_0x453301,_0x3d1b8f);await this['directlySetCurrentUser'](_0x280377);}catch(_0x3ce663){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x3ce663),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x318706){var _0x7ac5c4;if($(this['app'])){const _0x4ecb49=this['app']['settings']['authIdToken'];return _0x4ecb49?new Promise(_0x429243=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x4ecb49)['then'](_0x429243,_0x429243));}):this['directlySetCurrentUser'](null);}const _0x5686cf=await this['assertedPersistence']['getCurrentUser']();let _0x3f5488=_0x5686cf,_0x50fb7a=!0x1;if(_0x318706&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x276265=(_0x7ac5c4=this['redirectUser'])==null?void 0x0:_0x7ac5c4['_redirectEventId'],_0x4e6904=_0x3f5488==null?void 0x0:_0x3f5488['_redirectEventId'],_0x3716f7=await this['tryRedirectSignIn'](_0x318706);(!_0x276265||_0x276265===_0x4e6904)&&(_0x3716f7!=null&&_0x3716f7['user'])&&(_0x3f5488=_0x3716f7['user'],_0x50fb7a=!0x0);}if(!_0x3f5488)return this['directlySetCurrentUser'](null);if(!_0x3f5488['_redirectEventId']){if(_0x50fb7a)try{await this['beforeStateQueue']['runMiddleware'](_0x3f5488);}catch(_0x3fb5d1){_0x3f5488=_0x5686cf,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x3fb5d1));}return _0x3f5488?this['reloadAndSetCurrentUserOrClear'](_0x3f5488):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x3f5488['_redirectEventId']?this['directlySetCurrentUser'](_0x3f5488):this['reloadAndSetCurrentUserOrClear'](_0x3f5488);}async['tryRedirectSignIn'](_0x7bfc20){let _0x1be031=null;try{_0x1be031=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x7bfc20,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x1be031;}async['reloadAndSetCurrentUserOrClear'](_0x226f21){try{await Rn(_0x226f21);}catch(_0x11f87c){if((_0x11f87c==null?void 0x0:_0x11f87c['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x226f21);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x38d10b){if($(this['app']))return Promise['reject'](re(this));const _0x454ea5=_0x38d10b?N(_0x38d10b):null;return _0x454ea5&&m(_0x454ea5['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x454ea5&&_0x454ea5['_clone'](this));}async['_updateCurrentUser'](_0x27d621,_0x35307b=!0x1){if(!this['_deleted'])return _0x27d621&&m(this['tenantId']===_0x27d621['tenantId'],this,'tenant-id-mismatch'),_0x35307b||await this['beforeStateQueue']['runMiddleware'](_0x27d621),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x27d621),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x24f381){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x24f381));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x5432b7){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x3a897a=this['_getPasswordPolicyInternal']();return _0x3a897a['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x3a897a['validatePassword'](_0x5432b7);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x4da86c=await bf(this),_0x5f2a39=new Af(_0x4da86c);this['tenantId']===null?this['_projectPasswordPolicy']=_0x5f2a39:this['_tenantPasswordPolicies'][this['tenantId']]=_0x5f2a39;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x547d6f){this['_errorFactory']=new Bt('auth','Firebase',_0x547d6f());}['onAuthStateChanged'](_0x24880c,_0x529f6c,_0x4ab17d){return this['registerStateListener'](this['authStateSubscription'],_0x24880c,_0x529f6c,_0x4ab17d);}['beforeAuthStateChanged'](_0x14519d,_0x385692){return this['beforeStateQueue']['pushCallback'](_0x14519d,_0x385692);}['onIdTokenChanged'](_0x3a5afd,_0x2d432,_0x4142a7){return this['registerStateListener'](this['idTokenSubscription'],_0x3a5afd,_0x2d432,_0x4142a7);}['authStateReady'](){return new Promise((_0x4f1d4d,_0x403580)=>{if(this['currentUser'])_0x4f1d4d();else{const _0x58b7eb=this['onAuthStateChanged'](()=>{_0x58b7eb(),_0x4f1d4d();},_0x403580);}});}async['revokeAccessToken'](_0x20aa63){if(this['currentUser']){const _0x5cea8f=await this['currentUser']['getIdToken'](),_0x1e01d3={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x20aa63,'idToken':_0x5cea8f};this['tenantId']!=null&&(_0x1e01d3['tenantId']=this['tenantId']),await wf(this,_0x1e01d3);}}['toJSON'](){var _0x2048bb;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x2048bb=this['_currentUser'])==null?void 0x0:_0x2048bb['toJSON']()};}async['_setRedirectUser'](_0xee2755,_0x118336){const _0x35dcc4=await this['getOrInitRedirectPersistenceManager'](_0x118336);return _0xee2755===null?_0x35dcc4['removeCurrentUser']():_0x35dcc4['setCurrentUser'](_0xee2755);}async['getOrInitRedirectPersistenceManager'](_0x5aea4b){if(!this['redirectPersistenceManager']){const _0x50cf49=_0x5aea4b&&ie(_0x5aea4b)||this['_popupRedirectResolver'];m(_0x50cf49,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x50cf49['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x5198c9){var _0x58881c,_0x35d0db;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x58881c=this['_currentUser'])==null?void 0x0:_0x58881c['_redirectEventId'])===_0x5198c9?this['_currentUser']:((_0x35d0db=this['redirectUser'])==null?void 0x0:_0x35d0db['_redirectEventId'])===_0x5198c9?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2f8808){if(_0x2f8808===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2f8808));}['_notifyListenersIfCurrent'](_0x1dcd2d){_0x1dcd2d===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x25bbe1;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0xf297c=((_0x25bbe1=this['currentUser'])==null?void 0x0:_0x25bbe1['uid'])??null;this['lastNotifiedUid']!==_0xf297c&&(this['lastNotifiedUid']=_0xf297c,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x521e94,_0x20a812,_0x4512d4,_0x2e8639){if(this['_deleted'])return()=>{};const _0x1560c3=typeof _0x20a812=='function'?_0x20a812:_0x20a812['next']['bind'](_0x20a812);let _0x2d486d=!0x1;const _0x36fb0d=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x36fb0d,this,'internal-error'),_0x36fb0d['then'](()=>{_0x2d486d||_0x1560c3(this['currentUser']);}),typeof _0x20a812=='function'){const _0x16236e=_0x521e94['addObserver'](_0x20a812,_0x4512d4,_0x2e8639);return()=>{_0x2d486d=!0x0,_0x16236e();};}else{const _0x10528d=_0x521e94['addObserver'](_0x20a812);return()=>{_0x2d486d=!0x0,_0x10528d();};}}async['directlySetCurrentUser'](_0x33b50f){this['currentUser']&&this['currentUser']!==_0x33b50f&&this['_currentUser']['_stopProactiveRefresh'](),_0x33b50f&&this['isProactiveRefreshEnabled']&&_0x33b50f['_startProactiveRefresh'](),this['currentUser']=_0x33b50f,_0x33b50f?await this['assertedPersistence']['setCurrentUser'](_0x33b50f):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0xb3beee){return this['operations']=this['operations']['then'](_0xb3beee,_0xb3beee),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4f12c3){!_0x4f12c3||this['frameworks']['includes'](_0x4f12c3)||(this['frameworks']['push'](_0x4f12c3),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x1e69be;const _0xf06881={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0xf06881['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x1f5701=await((_0x1e69be=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1e69be['getHeartbeatsHeader']());_0x1f5701&&(_0xf06881['X-Firebase-Client']=_0x1f5701);const _0x598cdd=await this['_getAppCheckToken']();return _0x598cdd&&(_0xf06881['X-Firebase-AppCheck']=_0x598cdd),_0xf06881;}async['_getAppCheckToken'](){var _0x14dd5a;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x125fb7=await((_0x14dd5a=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x14dd5a['getToken']());return _0x125fb7!=null&&_0x125fb7['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x125fb7['error']),_0x125fb7==null?void 0x0:_0x125fb7['token'];}}function qe(_0x51bc68){return N(_0x51bc68);}class Rr{constructor(_0x5a0434){this['auth']=_0x5a0434,this['observer']=null,this['addObserver']=Tc(_0x23d4fc=>this['observer']=_0x23d4fc);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x2bb65a){jn=_0x2bb65a;}function xa(_0xba6526){return jn['loadJS'](_0xba6526);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x373171){return'__'+_0x373171+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x2a822d){_0x2a822d();}['execute'](_0x27ba0e,_0x3d7c67){return Promise['resolve']('token');}['render'](_0x3dab6d,_0x1b4f02){return'';}}class Lf{['ready'](_0x3a1ef1){_0x3a1ef1();}['execute'](_0x199814,_0x186ad5){return Promise['resolve']('token');}['render'](_0x17335d,_0x5066dc){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x322aa4){this['type']=xf,this['auth']=qe(_0x322aa4);}async['verify'](_0x5502ef='verify',_0x4d6828=!0x1){async function _0x3f2fb2(_0x4ac92a){if(!_0x4d6828){if(_0x4ac92a['tenantId']==null&&_0x4ac92a['_agentRecaptchaConfig']!=null)return _0x4ac92a['_agentRecaptchaConfig']['siteKey'];if(_0x4ac92a['tenantId']!=null&&_0x4ac92a['_tenantRecaptchaConfigs'][_0x4ac92a['tenantId']]!==void 0x0)return _0x4ac92a['_tenantRecaptchaConfigs'][_0x4ac92a['tenantId']]['siteKey'];}return new Promise(async(_0x494e4d,_0x3cd20e)=>{pf(_0x4ac92a,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x36c917=>{if(_0x36c917['recaptchaKey']===void 0x0)_0x3cd20e(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x2e9287=new ff(_0x36c917);return _0x4ac92a['tenantId']==null?_0x4ac92a['_agentRecaptchaConfig']=_0x2e9287:_0x4ac92a['_tenantRecaptchaConfigs'][_0x4ac92a['tenantId']]=_0x2e9287,_0x494e4d(_0x2e9287['siteKey']);}})['catch'](_0xddfcb5=>{_0x3cd20e(_0xddfcb5);});});}function _0x586c84(_0x3f67ac,_0x5cb42b,_0x2d9bee){const _0x10b87b=window['grecaptcha'];wr(_0x10b87b)?_0x10b87b['enterprise']['ready'](()=>{_0x10b87b['enterprise']['execute'](_0x3f67ac,{'action':_0x5502ef})['then'](_0x2e2260=>{_0x5cb42b(_0x2e2260);})['catch'](()=>{_0x5cb42b(Fa);});}):_0x2d9bee(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x4cba7b,_0x1212e4)=>{_0x3f2fb2(this['auth'])['then'](_0x52a294=>{if(!_0x4d6828&&wr(window['grecaptcha']))_0x586c84(_0x52a294,_0x4cba7b,_0x1212e4);else{if(typeof window>'u'){_0x1212e4(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x206dc5=Pf();_0x206dc5['length']!==0x0&&(_0x206dc5+=_0x52a294),xa(_0x206dc5)['then'](()=>{_0x586c84(_0x52a294,_0x4cba7b,_0x1212e4);})['catch'](_0x497ba5=>{_0x1212e4(_0x497ba5);});}})['catch'](_0x37df39=>{_0x1212e4(_0x37df39);});});}}async function Ar(_0x5bb74b,_0x351b72,_0x277383,_0xf3a489=!0x1,_0x1b92f7=!0x1){const _0x4c2f7=new Ff(_0x5bb74b);let _0x4ba797;if(_0x1b92f7)_0x4ba797=Fa;else try{_0x4ba797=await _0x4c2f7['verify'](_0x277383);}catch{_0x4ba797=await _0x4c2f7['verify'](_0x277383,!0x0);}const _0x4eee38={..._0x351b72};if(_0x277383==='mfaSmsEnrollment'||_0x277383==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x4eee38){const _0x50fcfe=_0x4eee38['phoneEnrollmentInfo']['phoneNumber'],_0x5385bc=_0x4eee38['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x4eee38,{'phoneEnrollmentInfo':{'phoneNumber':_0x50fcfe,'recaptchaToken':_0x5385bc,'captchaResponse':_0x4ba797,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x4eee38){const _0xb79707=_0x4eee38['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x4eee38,{'phoneSignInInfo':{'recaptchaToken':_0xb79707,'captchaResponse':_0x4ba797,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x4eee38;}return _0xf3a489?Object['assign'](_0x4eee38,{'captchaResp':_0x4ba797}):Object['assign'](_0x4eee38,{'captchaResponse':_0x4ba797}),Object['assign'](_0x4eee38,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x4eee38,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x4eee38;}async function Di(_0x52ba33,_0x1ce66f,_0x4f4ad9,_0x5ad594,_0x23368c){var _0x6a81c5;if((_0x6a81c5=_0x52ba33['_getRecaptchaConfig']())!=null&&_0x6a81c5['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x93500e=await Ar(_0x52ba33,_0x1ce66f,_0x4f4ad9,_0x4f4ad9==='getOobCode');return _0x5ad594(_0x52ba33,_0x93500e);}else return _0x5ad594(_0x52ba33,_0x1ce66f)['catch'](async _0x6dae47=>{if(_0x6dae47['code']==='auth/missing-recaptcha-token'){console['log'](_0x4f4ad9+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x55fb5f=await Ar(_0x52ba33,_0x1ce66f,_0x4f4ad9,_0x4f4ad9==='getOobCode');return _0x5ad594(_0x52ba33,_0x55fb5f);}else return Promise['reject'](_0x6dae47);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x289ed7,_0x552b0d){const _0x218336=Bi(_0x289ed7,'auth');if(_0x218336['isInitialized']()){const _0x6c2d2=_0x218336['getImmediate'](),_0x454c31=_0x218336['getOptions']();if(Me(_0x454c31,_0x552b0d??{}))return _0x6c2d2;Q(_0x6c2d2,'already-initialized');}return _0x218336['initialize']({'options':_0x552b0d});}function Wf(_0x21f32e,_0x406202){const _0x34b88e=(_0x406202==null?void 0x0:_0x406202['persistence'])||[],_0x1df717=(Array['isArray'](_0x34b88e)?_0x34b88e:[_0x34b88e])['map'](ie);_0x406202!=null&&_0x406202['errorMap']&&_0x21f32e['_updateErrorMap'](_0x406202['errorMap']),_0x21f32e['_initializeWithPersistence'](_0x1df717,_0x406202==null?void 0x0:_0x406202['popupRedirectResolver']);}function Bf(_0x38ae42,_0x21560f,_0x54c6c5){const _0x47a961=qe(_0x38ae42);m(/^https?:\/\//['test'](_0x21560f),_0x47a961,'invalid-emulator-scheme');const _0x32277d=!0x1,_0x528883=Ua(_0x21560f),{host:_0x52fbd2,port:_0x3a92a8}=Vf(_0x21560f),_0x3f2e15=_0x3a92a8===null?'':':'+_0x3a92a8,_0x18f88e={'url':_0x528883+'//'+_0x52fbd2+_0x3f2e15+'/'},_0x1ba962=Object['freeze']({'host':_0x52fbd2,'port':_0x3a92a8,'protocol':_0x528883['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x32277d})});if(!_0x47a961['_canInitEmulator']){m(_0x47a961['config']['emulator']&&_0x47a961['emulatorConfig'],_0x47a961,'emulator-config-failed'),m(Me(_0x18f88e,_0x47a961['config']['emulator'])&&Me(_0x1ba962,_0x47a961['emulatorConfig']),_0x47a961,'emulator-config-failed');return;}_0x47a961['config']['emulator']=_0x18f88e,_0x47a961['emulatorConfig']=_0x1ba962,_0x47a961['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x52fbd2)?(jr(_0x528883+'//'+_0x52fbd2+_0x3f2e15),Kr('Auth',!0x0)):Hf();}function Ua(_0x1b30c2){const _0x48cd8d=_0x1b30c2['indexOf'](':');return _0x48cd8d<0x0?'':_0x1b30c2['substr'](0x0,_0x48cd8d+0x1);}function Vf(_0x353db0){const _0x473d4b=Ua(_0x353db0),_0x95fa11=/(\/\/)?([^?#/]+)/['exec'](_0x353db0['substr'](_0x473d4b['length']));if(!_0x95fa11)return{'host':'','port':null};const _0x94755d=_0x95fa11[0x2]['split']('@')['pop']()||'',_0x4a73ad=/^(\[[^\]]+\])(:|$)/['exec'](_0x94755d);if(_0x4a73ad){const _0x1655d2=_0x4a73ad[0x1];return{'host':_0x1655d2,'port':kr(_0x94755d['substr'](_0x1655d2['length']+0x1))};}else{const [_0xec1123,_0x5c669d]=_0x94755d['split'](':');return{'host':_0xec1123,'port':kr(_0x5c669d)};}}function kr(_0x5ba29c){if(!_0x5ba29c)return null;const _0x21a6c2=Number(_0x5ba29c);return isNaN(_0x21a6c2)?null:_0x21a6c2;}function Hf(){function _0x1d3619(){const _0x17b24c=document['createElement']('p'),_0x1e1811=_0x17b24c['style'];_0x17b24c['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x1e1811['position']='fixed',_0x1e1811['width']='100%',_0x1e1811['backgroundColor']='#ffffff',_0x1e1811['border']='.1em\x20solid\x20#000000',_0x1e1811['color']='#b50000',_0x1e1811['bottom']='0px',_0x1e1811['left']='0px',_0x1e1811['margin']='0px',_0x1e1811['zIndex']='10000',_0x1e1811['textAlign']='center',_0x17b24c['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x17b24c);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1d3619):_0x1d3619());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x42d8f0,_0x2c2930){this['providerId']=_0x42d8f0,this['signInMethod']=_0x2c2930;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x53de36){return ne('not\x20implemented');}['_linkToIdToken'](_0x1a48e6,_0x43ef50){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0xc0f83c){return ne('not\x20implemented');}}async function $f(_0x3f66b3,_0x5d050c){return Ae(_0x3f66b3,'POST','/v1/accounts:signUp',_0x5d050c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x111339,_0x588dd4){return Qt(_0x111339,'POST','/v1/accounts:signInWithPassword',Re(_0x111339,_0x588dd4));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x294c56,_0x2042c5){return Qt(_0x294c56,'POST','/v1/accounts:signInWithEmailLink',Re(_0x294c56,_0x2042c5));}async function zf(_0x609b2,_0x4b680a){return Qt(_0x609b2,'POST','/v1/accounts:signInWithEmailLink',Re(_0x609b2,_0x4b680a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0xdb8d76,_0x56d3fd,_0x48e3ee,_0x19fe4e=null){super('password',_0x48e3ee),this['_email']=_0xdb8d76,this['_password']=_0x56d3fd,this['_tenantId']=_0x19fe4e;}static['_fromEmailAndPassword'](_0x453fb4,_0x36ccb1){return new Wt(_0x453fb4,_0x36ccb1,'password');}static['_fromEmailAndCode'](_0x13c94d,_0x4224e4,_0x17878e=null){return new Wt(_0x13c94d,_0x4224e4,'emailLink',_0x17878e);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x2065cd){const _0x7adff8=typeof _0x2065cd=='string'?JSON['parse'](_0x2065cd):_0x2065cd;if(_0x7adff8!=null&&_0x7adff8['email']&&(_0x7adff8!=null&&_0x7adff8['password'])){if(_0x7adff8['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x7adff8['email'],_0x7adff8['password']);if(_0x7adff8['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x7adff8['email'],_0x7adff8['password'],_0x7adff8['tenantId']);}return null;}async['_getIdTokenResponse'](_0x4f3fde){switch(this['signInMethod']){case'password':const _0xad29be={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x4f3fde,_0xad29be,'signInWithPassword',Gf);case'emailLink':return qf(_0x4f3fde,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x4f3fde,'internal-error');}}async['_linkToIdToken'](_0x283da,_0x382e59){switch(this['signInMethod']){case'password':const _0x1f13d1={'idToken':_0x382e59,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x283da,_0x1f13d1,'signUpPassword',$f);case'emailLink':return zf(_0x283da,{'idToken':_0x382e59,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x283da,'internal-error');}}['_getReauthenticationResolver'](_0x137162){return this['_getIdTokenResponse'](_0x137162);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x1e233a,_0x409eb6){return Qt(_0x1e233a,'POST','/v1/accounts:signInWithIdp',Re(_0x1e233a,_0x409eb6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x7b24a6){const _0x2d54af=new Be(_0x7b24a6['providerId'],_0x7b24a6['signInMethod']);return _0x7b24a6['idToken']||_0x7b24a6['accessToken']?(_0x7b24a6['idToken']&&(_0x2d54af['idToken']=_0x7b24a6['idToken']),_0x7b24a6['accessToken']&&(_0x2d54af['accessToken']=_0x7b24a6['accessToken']),_0x7b24a6['nonce']&&!_0x7b24a6['pendingToken']&&(_0x2d54af['nonce']=_0x7b24a6['nonce']),_0x7b24a6['pendingToken']&&(_0x2d54af['pendingToken']=_0x7b24a6['pendingToken'])):_0x7b24a6['oauthToken']&&_0x7b24a6['oauthTokenSecret']?(_0x2d54af['accessToken']=_0x7b24a6['oauthToken'],_0x2d54af['secret']=_0x7b24a6['oauthTokenSecret']):Q('argument-error'),_0x2d54af;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x378a6d){const _0x4ca8a1=typeof _0x378a6d=='string'?JSON['parse'](_0x378a6d):_0x378a6d,{providerId:_0x421a74,signInMethod:_0x125269,..._0x245154}=_0x4ca8a1;if(!_0x421a74||!_0x125269)return null;const _0x55c091=new Be(_0x421a74,_0x125269);return _0x55c091['idToken']=_0x245154['idToken']||void 0x0,_0x55c091['accessToken']=_0x245154['accessToken']||void 0x0,_0x55c091['secret']=_0x245154['secret'],_0x55c091['nonce']=_0x245154['nonce'],_0x55c091['pendingToken']=_0x245154['pendingToken']||null,_0x55c091;}['_getIdTokenResponse'](_0x517429){const _0x2b4b59=this['buildRequest']();return Xe(_0x517429,_0x2b4b59);}['_linkToIdToken'](_0x398102,_0x1f2b42){const _0xbfb7f4=this['buildRequest']();return _0xbfb7f4['idToken']=_0x1f2b42,Xe(_0x398102,_0xbfb7f4);}['_getReauthenticationResolver'](_0x26628a){const _0x425344=this['buildRequest']();return _0x425344['autoCreate']=!0x1,Xe(_0x26628a,_0x425344);}['buildRequest'](){const _0x4fe2e8={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x4fe2e8['pendingToken']=this['pendingToken'];else{const _0x19d3eb={};this['idToken']&&(_0x19d3eb['id_token']=this['idToken']),this['accessToken']&&(_0x19d3eb['access_token']=this['accessToken']),this['secret']&&(_0x19d3eb['oauth_token_secret']=this['secret']),_0x19d3eb['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x19d3eb['nonce']=this['nonce']),_0x4fe2e8['postBody']=ct(_0x19d3eb);}return _0x4fe2e8;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x59c3bc){switch(_0x59c3bc){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x3ff4ab){const _0x42db2c=vt(Et(_0x3ff4ab))['link'],_0x5d4e42=_0x42db2c?vt(Et(_0x42db2c))['deep_link_id']:null,_0x36ffe8=vt(Et(_0x3ff4ab))['deep_link_id'];return(_0x36ffe8?vt(Et(_0x36ffe8))['link']:null)||_0x36ffe8||_0x5d4e42||_0x42db2c||_0x3ff4ab;}class Rs{constructor(_0x2c2d05){const _0x54c95a=vt(Et(_0x2c2d05)),_0x101740=_0x54c95a['apiKey']??null,_0x5339bd=_0x54c95a['oobCode']??null,_0xd5a2f1=Kf(_0x54c95a['mode']??null);m(_0x101740&&_0x5339bd&&_0xd5a2f1,'argument-error'),this['apiKey']=_0x101740,this['operation']=_0xd5a2f1,this['code']=_0x5339bd,this['continueUrl']=_0x54c95a['continueUrl']??null,this['languageCode']=_0x54c95a['lang']??null,this['tenantId']=_0x54c95a['tenantId']??null;}static['parseLink'](_0x500304){const _0x34f09f=Yf(_0x500304);try{return new Rs(_0x34f09f);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x19a3b9,_0x52ea26){return Wt['_fromEmailAndPassword'](_0x19a3b9,_0x52ea26);}static['credentialWithLink'](_0x9bff13,_0x416fc3){const _0x2db9d4=Rs['parseLink'](_0x416fc3);return m(_0x2db9d4,'argument-error'),Wt['_fromEmailAndCode'](_0x9bff13,_0x2db9d4['code'],_0x2db9d4['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x250792){this['providerId']=_0x250792,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x5ee831){this['defaultLanguageCode']=_0x5ee831;}['setCustomParameters'](_0x4483e1){return this['customParameters']=_0x4483e1,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x55c894){return this['scopes']['includes'](_0x55c894)||this['scopes']['push'](_0x55c894),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x217dfb){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x217dfb});}static['credentialFromResult'](_0x2fe514){return he['credentialFromTaggedObject'](_0x2fe514);}static['credentialFromError'](_0x4c2e49){return he['credentialFromTaggedObject'](_0x4c2e49['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4a4199}){if(!_0x4a4199||!('oauthAccessToken'in _0x4a4199)||!_0x4a4199['oauthAccessToken'])return null;try{return he['credential'](_0x4a4199['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x400f7e,_0x83252a){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x400f7e,'accessToken':_0x83252a});}static['credentialFromResult'](_0x7c054){return ue['credentialFromTaggedObject'](_0x7c054);}static['credentialFromError'](_0x1cebc4){return ue['credentialFromTaggedObject'](_0x1cebc4['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x273765}){if(!_0x273765)return null;const {oauthIdToken:_0x255465,oauthAccessToken:_0x44cfd6}=_0x273765;if(!_0x255465&&!_0x44cfd6)return null;try{return ue['credential'](_0x255465,_0x44cfd6);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0xf3699f){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0xf3699f});}static['credentialFromResult'](_0x5217f0){return de['credentialFromTaggedObject'](_0x5217f0);}static['credentialFromError'](_0x500292){return de['credentialFromTaggedObject'](_0x500292['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x167dd1}){if(!_0x167dd1||!('oauthAccessToken'in _0x167dd1)||!_0x167dd1['oauthAccessToken'])return null;try{return de['credential'](_0x167dd1['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x2ff08f,_0x368aa9){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x2ff08f,'oauthTokenSecret':_0x368aa9});}static['credentialFromResult'](_0x52c380){return fe['credentialFromTaggedObject'](_0x52c380);}static['credentialFromError'](_0x312f3b){return fe['credentialFromTaggedObject'](_0x312f3b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x45fcbc}){if(!_0x45fcbc)return null;const {oauthAccessToken:_0x377ed5,oauthTokenSecret:_0x4b4ff6}=_0x45fcbc;if(!_0x377ed5||!_0x4b4ff6)return null;try{return fe['credential'](_0x377ed5,_0x4b4ff6);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x54b610,_0x4d0cad){return Qt(_0x54b610,'POST','/v1/accounts:signUp',Re(_0x54b610,_0x4d0cad));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x430d12){this['user']=_0x430d12['user'],this['providerId']=_0x430d12['providerId'],this['_tokenResponse']=_0x430d12['_tokenResponse'],this['operationType']=_0x430d12['operationType'];}static async['_fromIdTokenResponse'](_0x800c7,_0x5c500d,_0x53d87a,_0x177e80=!0x1){const _0x48f94f=await K['_fromIdTokenResponse'](_0x800c7,_0x53d87a,_0x177e80),_0xdcd9e4=Nr(_0x53d87a);return new Ve({'user':_0x48f94f,'providerId':_0xdcd9e4,'_tokenResponse':_0x53d87a,'operationType':_0x5c500d});}static async['_forOperation'](_0x2bd141,_0x235ee5,_0x130a5b){await _0x2bd141['_updateTokensIfNecessary'](_0x130a5b,!0x0);const _0x35fbea=Nr(_0x130a5b);return new Ve({'user':_0x2bd141,'providerId':_0x35fbea,'_tokenResponse':_0x130a5b,'operationType':_0x235ee5});}}function Nr(_0x5783ae){return _0x5783ae['providerId']?_0x5783ae['providerId']:'phoneNumber'in _0x5783ae?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x31b296,_0x35e254,_0x5f2773,_0x5b2563){super(_0x35e254['code'],_0x35e254['message']),this['operationType']=_0x5f2773,this['user']=_0x5b2563,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x31b296['name'],'tenantId':_0x31b296['tenantId']??void 0x0,'_serverResponse':_0x35e254['customData']['_serverResponse'],'operationType':_0x5f2773};}static['_fromErrorAndOperation'](_0x47e212,_0x520ba2,_0x368424,_0x7a1efc){return new An(_0x47e212,_0x520ba2,_0x368424,_0x7a1efc);}}function Ba(_0x545e2d,_0x2110e6,_0x4c5c3e,_0xc83372){return(_0x2110e6==='reauthenticate'?_0x4c5c3e['_getReauthenticationResolver'](_0x545e2d):_0x4c5c3e['_getIdTokenResponse'](_0x545e2d))['catch'](_0x3c46d3=>{throw _0x3c46d3['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x545e2d,_0x3c46d3,_0x2110e6,_0xc83372):_0x3c46d3;});}async function Jf(_0x171511,_0x31de0b,_0xe84233=!0x1){const _0x58f3a7=await Ut(_0x171511,_0x31de0b['_linkToIdToken'](_0x171511['auth'],await _0x171511['getIdToken']()),_0xe84233);return Ve['_forOperation'](_0x171511,'link',_0x58f3a7);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x2c52eb,_0x4ced8b,_0x42c072=!0x1){const {auth:_0x2c66eb}=_0x2c52eb;if($(_0x2c66eb['app']))return Promise['reject'](re(_0x2c66eb));const _0x10c7dd='reauthenticate';try{const _0x12c467=await Ut(_0x2c52eb,Ba(_0x2c66eb,_0x10c7dd,_0x4ced8b,_0x2c52eb),_0x42c072);m(_0x12c467['idToken'],_0x2c66eb,'internal-error');const _0x4ac706=Ts(_0x12c467['idToken']);m(_0x4ac706,_0x2c66eb,'internal-error');const {sub:_0x3a8c4f}=_0x4ac706;return m(_0x2c52eb['uid']===_0x3a8c4f,_0x2c66eb,'user-mismatch'),Ve['_forOperation'](_0x2c52eb,_0x10c7dd,_0x12c467);}catch(_0x3c2d84){throw(_0x3c2d84==null?void 0x0:_0x3c2d84['code'])==='auth/user-not-found'&&Q(_0x2c66eb,'user-mismatch'),_0x3c2d84;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x2d52ef,_0x4d3485,_0x3ca613=!0x1){if($(_0x2d52ef['app']))return Promise['reject'](re(_0x2d52ef));const _0x33cb37='signIn',_0x5e1ad5=await Ba(_0x2d52ef,_0x33cb37,_0x4d3485),_0x1cf653=await Ve['_fromIdTokenResponse'](_0x2d52ef,_0x33cb37,_0x5e1ad5);return _0x3ca613||await _0x2d52ef['_updateCurrentUser'](_0x1cf653['user']),_0x1cf653;}async function Zf(_0x2dec32,_0x4635e5){return Va(qe(_0x2dec32),_0x4635e5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x2d4ed7){const _0x5c8d4b=qe(_0x2d4ed7);_0x5c8d4b['_getPasswordPolicyInternal']()&&await _0x5c8d4b['_updatePasswordPolicy']();}async function P_(_0x4b87f9,_0x1a1583,_0x1d7733){if($(_0x4b87f9['app']))return Promise['reject'](re(_0x4b87f9));const _0x1e8e34=qe(_0x4b87f9),_0x4d561c=await Di(_0x1e8e34,{'returnSecureToken':!0x0,'email':_0x1a1583,'password':_0x1d7733,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0xe54f1f=>{throw _0xe54f1f['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x4b87f9),_0xe54f1f;}),_0x286030=await Ve['_fromIdTokenResponse'](_0x1e8e34,'signIn',_0x4d561c);return await _0x1e8e34['_updateCurrentUser'](_0x286030['user']),_0x286030;}function O_(_0x4fa41c,_0x29f26a,_0x29cc6d){return $(_0x4fa41c['app'])?Promise['reject'](re(_0x4fa41c)):Zf(N(_0x4fa41c),pt['credential'](_0x29f26a,_0x29cc6d))['catch'](async _0x1e0770=>{throw _0x1e0770['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x4fa41c),_0x1e0770;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x1a6d49,_0x22e23e){return N(_0x1a6d49)['setPersistence'](_0x22e23e);}function ep(_0x484f28,_0x5dafb5,_0x4c8131,_0x4d70ed){return N(_0x484f28)['onIdTokenChanged'](_0x5dafb5,_0x4c8131,_0x4d70ed);}function tp(_0x51aee8,_0x23cdcd,_0x28b25d){return N(_0x51aee8)['beforeAuthStateChanged'](_0x23cdcd,_0x28b25d);}function M_(_0x1570ab,_0x50a676,_0x39063c,_0x5cfd1b){return N(_0x1570ab)['onAuthStateChanged'](_0x50a676,_0x39063c,_0x5cfd1b);}function L_(_0x51d7ed){return N(_0x51d7ed)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x4be979,_0x43cd3d){this['storageRetriever']=_0x4be979,this['type']=_0x43cd3d;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x747a71,_0x4a6f7b){return this['storage']['setItem'](_0x747a71,JSON['stringify'](_0x4a6f7b)),Promise['resolve']();}['_get'](_0x2a48b2){const _0x4a4e10=this['storage']['getItem'](_0x2a48b2);return Promise['resolve'](_0x4a4e10?JSON['parse'](_0x4a4e10):null);}['_remove'](_0x54b45a){return this['storage']['removeItem'](_0x54b45a),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x57f7cd,_0x416969)=>this['onStorageEvent'](_0x57f7cd,_0x416969),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0xa8a833){for(const _0x25f8e1 of Object['keys'](this['listeners'])){const _0x3c0f98=this['storage']['getItem'](_0x25f8e1),_0x42def3=this['localCache'][_0x25f8e1];_0x3c0f98!==_0x42def3&&_0xa8a833(_0x25f8e1,_0x42def3,_0x3c0f98);}}['onStorageEvent'](_0x5ae5d2,_0x1a71fc=!0x1){if(!_0x5ae5d2['key']){this['forAllChangedKeys']((_0x2050ed,_0xae12d9,_0x419d0b)=>{this['notifyListeners'](_0x2050ed,_0x419d0b);});return;}const _0x4be8f6=_0x5ae5d2['key'];_0x1a71fc?this['detachListener']():this['stopPolling']();const _0x4562eb=()=>{const _0x196ba2=this['storage']['getItem'](_0x4be8f6);!_0x1a71fc&&this['localCache'][_0x4be8f6]===_0x196ba2||this['notifyListeners'](_0x4be8f6,_0x196ba2);},_0x31fd0a=this['storage']['getItem'](_0x4be8f6);Tf()&&_0x31fd0a!==_0x5ae5d2['newValue']&&_0x5ae5d2['newValue']!==_0x5ae5d2['oldValue']?setTimeout(_0x4562eb,ip):_0x4562eb();}['notifyListeners'](_0x15c533,_0x3e84ba){this['localCache'][_0x15c533]=_0x3e84ba;const _0x42a10e=this['listeners'][_0x15c533];if(_0x42a10e){for(const _0x4e6887 of Array['from'](_0x42a10e))_0x4e6887(_0x3e84ba&&JSON['parse'](_0x3e84ba));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x46fe5c,_0x1e01e5,_0x31b147)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x46fe5c,'oldValue':_0x1e01e5,'newValue':_0x31b147}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x2a83eb,_0x34692e){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x2a83eb]||(this['listeners'][_0x2a83eb]=new Set(),this['localCache'][_0x2a83eb]=this['storage']['getItem'](_0x2a83eb)),this['listeners'][_0x2a83eb]['add'](_0x34692e);}['_removeListener'](_0x5c87ed,_0x1a84a1){this['listeners'][_0x5c87ed]&&(this['listeners'][_0x5c87ed]['delete'](_0x1a84a1),this['listeners'][_0x5c87ed]['size']===0x0&&delete this['listeners'][_0x5c87ed]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x4d1978,_0x5e21f7){await super['_set'](_0x4d1978,_0x5e21f7),this['localCache'][_0x4d1978]=JSON['stringify'](_0x5e21f7);}async['_get'](_0x27a01c){const _0x1c2ee9=await super['_get'](_0x27a01c);return this['localCache'][_0x27a01c]=JSON['stringify'](_0x1c2ee9),_0x1c2ee9;}async['_remove'](_0x5e33b4){await super['_remove'](_0x5e33b4),delete this['localCache'][_0x5e33b4];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x55571c,_0x365c00){}['_removeListener'](_0x59d2da,_0x6b8ba7){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x272a1e){return Promise['all'](_0x272a1e['map'](async _0x10d247=>{try{return{'fulfilled':!0x0,'value':await _0x10d247};}catch(_0xee6a82){return{'fulfilled':!0x1,'reason':_0xee6a82};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x3d6716){this['eventTarget']=_0x3d6716,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x193045){const _0x29e138=this['receivers']['find'](_0x66141a=>_0x66141a['isListeningto'](_0x193045));if(_0x29e138)return _0x29e138;const _0x4e34dc=new Kn(_0x193045);return this['receivers']['push'](_0x4e34dc),_0x4e34dc;}['isListeningto'](_0x53a75f){return this['eventTarget']===_0x53a75f;}async['handleEvent'](_0x3dfaf4){const _0x21f3de=_0x3dfaf4,{eventId:_0x33a54d,eventType:_0x4e30c0,data:_0x21daa9}=_0x21f3de['data'],_0x24fc09=this['handlersMap'][_0x4e30c0];if(!(_0x24fc09!=null&&_0x24fc09['size']))return;_0x21f3de['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x33a54d,'eventType':_0x4e30c0});const _0x5ea046=Array['from'](_0x24fc09)['map'](async _0x167a50=>_0x167a50(_0x21f3de['origin'],_0x21daa9)),_0x4d6374=await rp(_0x5ea046);_0x21f3de['ports'][0x0]['postMessage']({'status':'done','eventId':_0x33a54d,'eventType':_0x4e30c0,'response':_0x4d6374});}['_subscribe'](_0x26cf1c,_0x54b449){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x26cf1c]||(this['handlersMap'][_0x26cf1c]=new Set()),this['handlersMap'][_0x26cf1c]['add'](_0x54b449);}['_unsubscribe'](_0x197588,_0x2ace03){this['handlersMap'][_0x197588]&&_0x2ace03&&this['handlersMap'][_0x197588]['delete'](_0x2ace03),(!_0x2ace03||this['handlersMap'][_0x197588]['size']===0x0)&&delete this['handlersMap'][_0x197588],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x38ea84='',_0x1dcc93=0xa){let _0x5a38f0='';for(let _0x4a6c7d=0x0;_0x4a6c7d<_0x1dcc93;_0x4a6c7d++)_0x5a38f0+=Math['floor'](Math['random']()*0xa);return _0x38ea84+_0x5a38f0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x4ea304){this['target']=_0x4ea304,this['handlers']=new Set();}['removeMessageHandler'](_0x431ae2){_0x431ae2['messageChannel']&&(_0x431ae2['messageChannel']['port1']['removeEventListener']('message',_0x431ae2['onMessage']),_0x431ae2['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x431ae2);}async['_send'](_0x5c9b24,_0x11b30e,_0x3198e0=0x32){const _0x48a5c1=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x48a5c1)throw new Error('connection_unavailable');let _0x558643,_0x4ce8c3;return new Promise((_0x17ca5e,_0x1bba20)=>{const _0x50c5c3=As('',0x14);_0x48a5c1['port1']['start']();const _0x55142b=setTimeout(()=>{_0x1bba20(new Error('unsupported_event'));},_0x3198e0);_0x4ce8c3={'messageChannel':_0x48a5c1,'onMessage'(_0x3bfbd9){const _0x715e89=_0x3bfbd9;if(_0x715e89['data']['eventId']===_0x50c5c3)switch(_0x715e89['data']['status']){case'ack':clearTimeout(_0x55142b),_0x558643=setTimeout(()=>{_0x1bba20(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x558643),_0x17ca5e(_0x715e89['data']['response']);break;default:clearTimeout(_0x55142b),clearTimeout(_0x558643),_0x1bba20(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x4ce8c3),_0x48a5c1['port1']['addEventListener']('message',_0x4ce8c3['onMessage']),this['target']['postMessage']({'eventType':_0x5c9b24,'eventId':_0x50c5c3,'data':_0x11b30e},[_0x48a5c1['port2']]);})['finally'](()=>{_0x4ce8c3&&this['removeMessageHandler'](_0x4ce8c3);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x3a23a2){Z()['location']['href']=_0x3a23a2;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x3da73b;return((_0x3da73b=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x3da73b['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x5b9b4f){this['request']=_0x5b9b4f;}['toPromise'](){return new Promise((_0x56b61e,_0x363df2)=>{this['request']['addEventListener']('success',()=>{_0x56b61e(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x363df2(this['request']['error']);});});}}function Yn(_0x8540a4,_0x344ef1){return _0x8540a4['transaction']([Nn],_0x344ef1?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x52f549=indexedDB['deleteDatabase'](Ka);return new Xt(_0x52f549)['toPromise']();}function Mi(){const _0x47b618=indexedDB['open'](Ka,up);return new Promise((_0x97170a,_0x14e14c)=>{_0x47b618['addEventListener']('error',()=>{_0x14e14c(_0x47b618['error']);}),_0x47b618['addEventListener']('upgradeneeded',()=>{const _0x36491b=_0x47b618['result'];try{_0x36491b['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x5aabf2){_0x14e14c(_0x5aabf2);}}),_0x47b618['addEventListener']('success',async()=>{const _0x146575=_0x47b618['result'];_0x146575['objectStoreNames']['contains'](Nn)?_0x97170a(_0x146575):(_0x146575['close'](),await dp(),_0x97170a(await Mi()));});});}async function Pr(_0x1dfc29,_0x40fc65,_0x2a74b6){const _0x3bd316=Yn(_0x1dfc29,!0x0)['put']({[Ya]:_0x40fc65,'value':_0x2a74b6});return new Xt(_0x3bd316)['toPromise']();}async function fp(_0x7666ed,_0x32693f){const _0x4783a5=Yn(_0x7666ed,!0x1)['get'](_0x32693f),_0x334f30=await new Xt(_0x4783a5)['toPromise']();return _0x334f30===void 0x0?null:_0x334f30['value'];}function Or(_0x194c90,_0x29642a){const _0x250557=Yn(_0x194c90,!0x0)['delete'](_0x29642a);return new Xt(_0x250557)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x3233bf){let _0x2e84f9=0x0;for(;;)try{const _0x34e3aa=await this['_openDb']();return await _0x3233bf(_0x34e3aa);}catch(_0xba9042){if(_0x2e84f9++>_p)throw _0xba9042;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x5c06c4,_0x51b18b)=>({'keyProcessed':(await this['_poll']())['includes'](_0x51b18b['key'])})),this['receiver']['_subscribe']('ping',async(_0x5d10d6,_0x1e8f00)=>['keyChanged']);}async['initializeSender'](){var _0xe6f36f,_0x4dd842;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x5a6a5=await this['sender']['_send']('ping',{},0x320);_0x5a6a5&&(_0xe6f36f=_0x5a6a5[0x0])!=null&&_0xe6f36f['fulfilled']&&(_0x4dd842=_0x5a6a5[0x0])!=null&&_0x4dd842['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x26e82f){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x26e82f},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x553c5c=await Mi();return await Pr(_0x553c5c,kn,'1'),await Or(_0x553c5c,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x2a2289){this['pendingWrites']++;try{await _0x2a2289();}finally{this['pendingWrites']--;}}async['_set'](_0x2d1b2a,_0x915cbb){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2841a2=>Pr(_0x2841a2,_0x2d1b2a,_0x915cbb)),this['localCache'][_0x2d1b2a]=_0x915cbb,this['notifyServiceWorker'](_0x2d1b2a)));}async['_get'](_0xb3c058){const _0x44b74=await this['_withRetries'](_0x11cb20=>fp(_0x11cb20,_0xb3c058));return this['localCache'][_0xb3c058]=_0x44b74,_0x44b74;}async['_remove'](_0x2db715){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x45f57f=>Or(_0x45f57f,_0x2db715)),delete this['localCache'][_0x2db715],this['notifyServiceWorker'](_0x2db715)));}async['_poll'](){const _0xe030be=await this['_withRetries'](_0x48027d=>{const _0x2e21de=Yn(_0x48027d,!0x1)['getAll']();return new Xt(_0x2e21de)['toPromise']();});if(!_0xe030be)return[];if(this['pendingWrites']!==0x0)return[];const _0x305811=[],_0x3bb427=new Set();if(_0xe030be['length']!==0x0){for(const {fbase_key:_0x338aab,value:_0x9087}of _0xe030be)_0x3bb427['add'](_0x338aab),JSON['stringify'](this['localCache'][_0x338aab])!==JSON['stringify'](_0x9087)&&(this['notifyListeners'](_0x338aab,_0x9087),_0x305811['push'](_0x338aab));}for(const _0x53d0f4 of Object['keys'](this['localCache']))this['localCache'][_0x53d0f4]&&!_0x3bb427['has'](_0x53d0f4)&&(this['notifyListeners'](_0x53d0f4,null),_0x305811['push'](_0x53d0f4));return _0x305811;}['notifyListeners'](_0x523d54,_0x5a0fc4){this['localCache'][_0x523d54]=_0x5a0fc4;const _0x4ddb04=this['listeners'][_0x523d54];if(_0x4ddb04){for(const _0x176fca of Array['from'](_0x4ddb04))_0x176fca(_0x5a0fc4);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x14ff9c,_0x509bc7){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x14ff9c]||(this['listeners'][_0x14ff9c]=new Set(),this['_get'](_0x14ff9c)),this['listeners'][_0x14ff9c]['add'](_0x509bc7);}['_removeListener'](_0x38123b,_0xb7e77a){this['listeners'][_0x38123b]&&(this['listeners'][_0x38123b]['delete'](_0xb7e77a),this['listeners'][_0x38123b]['size']===0x0&&delete this['listeners'][_0x38123b]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x234496,_0x2243df){return _0x2243df?ie(_0x2243df):(m(_0x234496['_popupRedirectResolver'],_0x234496,'argument-error'),_0x234496['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x18faac){super('custom','custom'),this['params']=_0x18faac;}['_getIdTokenResponse'](_0x61152b){return Xe(_0x61152b,this['_buildIdpRequest']());}['_linkToIdToken'](_0x432ff5,_0x288334){return Xe(_0x432ff5,this['_buildIdpRequest'](_0x288334));}['_getReauthenticationResolver'](_0x20f05e){return Xe(_0x20f05e,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x29a583){const _0xf8f9d0={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x29a583&&(_0xf8f9d0['idToken']=_0x29a583),_0xf8f9d0;}}function yp(_0x2d1d9a){return Va(_0x2d1d9a['auth'],new ks(_0x2d1d9a),_0x2d1d9a['bypassAuthState']);}function vp(_0x49d852){const {auth:_0x4d15d9,user:_0x44922d}=_0x49d852;return m(_0x44922d,_0x4d15d9,'internal-error'),Xf(_0x44922d,new ks(_0x49d852),_0x49d852['bypassAuthState']);}async function Ep(_0x5478fb){const {auth:_0x10526b,user:_0x3ef401}=_0x5478fb;return m(_0x3ef401,_0x10526b,'internal-error'),Jf(_0x3ef401,new ks(_0x5478fb),_0x5478fb['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x57408a,_0x1ab2fd,_0x1a786c,_0xbffbf8,_0x2425a9=!0x1){this['auth']=_0x57408a,this['resolver']=_0x1a786c,this['user']=_0xbffbf8,this['bypassAuthState']=_0x2425a9,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x1ab2fd)?_0x1ab2fd:[_0x1ab2fd];}['execute'](){return new Promise(async(_0x341b03,_0x20a827)=>{this['pendingPromise']={'resolve':_0x341b03,'reject':_0x20a827};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x3cbf2f){this['reject'](_0x3cbf2f);}});}async['onAuthEvent'](_0x233092){const {urlResponse:_0x4e765a,sessionId:_0x21de46,postBody:_0x38f865,tenantId:_0x30a66a,error:_0x53b30c,type:_0x2160cd}=_0x233092;if(_0x53b30c){this['reject'](_0x53b30c);return;}const _0x2f1e0e={'auth':this['auth'],'requestUri':_0x4e765a,'sessionId':_0x21de46,'tenantId':_0x30a66a||void 0x0,'postBody':_0x38f865||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x2160cd)(_0x2f1e0e));}catch(_0x2e3b3c){this['reject'](_0x2e3b3c);}}['onError'](_0x21da05){this['reject'](_0x21da05);}['getIdpTask'](_0x304644){switch(_0x304644){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x1c0404){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x1c0404),this['unregisterAndCleanUp']();}['reject'](_0x2b2820){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x2b2820),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x26ca34,_0x4e8c6d,_0xea129d,_0x566125,_0x1e5a40){super(_0x26ca34,_0x4e8c6d,_0x566125,_0x1e5a40),this['provider']=_0xea129d,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x5e2b8b=await this['execute']();return m(_0x5e2b8b,this['auth'],'internal-error'),_0x5e2b8b;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x4d7b18=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x4d7b18),this['authWindow']['associatedEvent']=_0x4d7b18,this['resolver']['_originValidation'](this['auth'])['catch'](_0x52dcc1=>{this['reject'](_0x52dcc1);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x5a632f=>{_0x5a632f||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x57f45a;return((_0x57f45a=this['authWindow'])==null?void 0x0:_0x57f45a['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x58785e=()=>{var _0x8101ac,_0x4d03d2;if((_0x4d03d2=(_0x8101ac=this['authWindow'])==null?void 0x0:_0x8101ac['window'])!=null&&_0x4d03d2['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x58785e,Ip['get']());};_0x58785e();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x2a8636,_0x5e2355,_0x1446a0=!0x1){super(_0x2a8636,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x5e2355,void 0x0,_0x1446a0),this['eventId']=null;}async['execute'](){let _0x4d3ec4=on['get'](this['auth']['_key']());if(!_0x4d3ec4){try{const _0x2c1c65=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x4d3ec4=()=>Promise['resolve'](_0x2c1c65);}catch(_0x1aa5a9){_0x4d3ec4=()=>Promise['reject'](_0x1aa5a9);}on['set'](this['auth']['_key'](),_0x4d3ec4);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x4d3ec4();}async['onAuthEvent'](_0x5642d1){if(_0x5642d1['type']==='signInViaRedirect')return super['onAuthEvent'](_0x5642d1);if(_0x5642d1['type']==='unknown'){this['resolve'](null);return;}if(_0x5642d1['eventId']){const _0x3f3b5d=await this['auth']['_redirectUserForId'](_0x5642d1['eventId']);if(_0x3f3b5d)return this['user']=_0x3f3b5d,super['onAuthEvent'](_0x5642d1);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x278340,_0x5a305c){const _0xbfc828=Rp(_0x5a305c),_0x17d1b7=bp(_0x278340);if(!await _0x17d1b7['_isAvailable']())return!0x1;const _0x24c1f9=await _0x17d1b7['_get'](_0xbfc828)==='true';return await _0x17d1b7['_remove'](_0xbfc828),_0x24c1f9;}function Sp(_0x14d289,_0x228830){on['set'](_0x14d289['_key'](),_0x228830);}function bp(_0x25362b){return ie(_0x25362b['_redirectPersistence']);}function Rp(_0x5873e5){return rn(wp,_0x5873e5['config']['apiKey'],_0x5873e5['name']);}async function Ap(_0xb2d9e5,_0x2cddc9,_0x9058ea=!0x1){if($(_0xb2d9e5['app']))return Promise['reject'](re(_0xb2d9e5));const _0x162374=qe(_0xb2d9e5),_0x2a9f67=mp(_0x162374,_0x2cddc9),_0x12c96a=await new Cp(_0x162374,_0x2a9f67,_0x9058ea)['execute']();return _0x12c96a&&!_0x9058ea&&(delete _0x12c96a['user']['_redirectEventId'],await _0x162374['_persistUserIfCurrent'](_0x12c96a['user']),await _0x162374['_setRedirectUser'](null,_0x2cddc9)),_0x12c96a;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x3772a6){this['auth']=_0x3772a6,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x285347){this['consumers']['add'](_0x285347),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x285347)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x285347),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x51216e){this['consumers']['delete'](_0x51216e);}['onEvent'](_0x1ead40){if(this['hasEventBeenHandled'](_0x1ead40))return!0x1;let _0x449353=!0x1;return this['consumers']['forEach'](_0x4df18a=>{this['isEventForConsumer'](_0x1ead40,_0x4df18a)&&(_0x449353=!0x0,this['sendToConsumer'](_0x1ead40,_0x4df18a),this['saveEventToCache'](_0x1ead40));}),this['hasHandledPotentialRedirect']||!Pp(_0x1ead40)||(this['hasHandledPotentialRedirect']=!0x0,_0x449353||(this['queuedRedirectEvent']=_0x1ead40,_0x449353=!0x0)),_0x449353;}['sendToConsumer'](_0x178226,_0x553563){var _0x245bb9;if(_0x178226['error']&&!Xa(_0x178226)){const _0x2ca193=((_0x245bb9=_0x178226['error']['code'])==null?void 0x0:_0x245bb9['split']('auth/')[0x1])||'internal-error';_0x553563['onError'](X(this['auth'],_0x2ca193));}else _0x553563['onAuthEvent'](_0x178226);}['isEventForConsumer'](_0x3a503a,_0x1e7ded){const _0x38e1fb=_0x1e7ded['eventId']===null||!!_0x3a503a['eventId']&&_0x3a503a['eventId']===_0x1e7ded['eventId'];return _0x1e7ded['filter']['includes'](_0x3a503a['type'])&&_0x38e1fb;}['hasEventBeenHandled'](_0x3cc82f){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x3cc82f));}['saveEventToCache'](_0x5191f4){this['cachedEventUids']['add'](Dr(_0x5191f4)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x46f174){return[_0x46f174['type'],_0x46f174['eventId'],_0x46f174['sessionId'],_0x46f174['tenantId']]['filter'](_0x238978=>_0x238978)['join']('-');}function Xa({type:_0x3b8722,error:_0x2effb8}){return _0x3b8722==='unknown'&&(_0x2effb8==null?void 0x0:_0x2effb8['code'])==='auth/no-auth-event';}function Pp(_0x1dd20a){switch(_0x1dd20a['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x1dd20a);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x1e9607,_0xd8f40={}){return Ae(_0x1e9607,'GET','/v1/projects',_0xd8f40);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x126723){if(_0x126723['config']['emulator'])return;const {authorizedDomains:_0x49cee3}=await Op(_0x126723);for(const _0x56f209 of _0x49cee3)try{if(xp(_0x56f209))return;}catch{}Q(_0x126723,'unauthorized-domain');}function xp(_0x52891f){const _0x254b55=Pi(),{protocol:_0x466f3b,hostname:_0x211050}=new URL(_0x254b55);if(_0x52891f['startsWith']('chrome-extension://')){const _0x52b62b=new URL(_0x52891f);return _0x52b62b['hostname']===''&&_0x211050===''?_0x466f3b==='chrome-extension:'&&_0x52891f['replace']('chrome-extension://','')===_0x254b55['replace']('chrome-extension://',''):_0x466f3b==='chrome-extension:'&&_0x52b62b['hostname']===_0x211050;}if(!Mp['test'](_0x466f3b))return!0x1;if(Dp['test'](_0x52891f))return _0x211050===_0x52891f;const _0x453c54=_0x52891f['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x453c54+'|'+_0x453c54+')$','i')['test'](_0x211050);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x6aa377=Z()['___jsl'];if(_0x6aa377!=null&&_0x6aa377['H']){for(const _0x2f28b2 of Object['keys'](_0x6aa377['H']))if(_0x6aa377['H'][_0x2f28b2]['r']=_0x6aa377['H'][_0x2f28b2]['r']||[],_0x6aa377['H'][_0x2f28b2]['L']=_0x6aa377['H'][_0x2f28b2]['L']||[],_0x6aa377['H'][_0x2f28b2]['r']=[..._0x6aa377['H'][_0x2f28b2]['L']],_0x6aa377['CP']){for(let _0xea6230=0x0;_0xea6230<_0x6aa377['CP']['length'];_0xea6230++)_0x6aa377['CP'][_0xea6230]=null;}}}function Up(_0x322f41){return new Promise((_0x11a151,_0x48f6a9)=>{var _0x2849dd,_0x7bfc3,_0x419593;function _0x56b096(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x11a151(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x48f6a9(X(_0x322f41,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x7bfc3=(_0x2849dd=Z()['gapi'])==null?void 0x0:_0x2849dd['iframes'])!=null&&_0x7bfc3['Iframe'])_0x11a151(gapi['iframes']['getContext']());else{if((_0x419593=Z()['gapi'])!=null&&_0x419593['load'])_0x56b096();else{const _0x2d327a=Df('iframefcb');return Z()[_0x2d327a]=()=>{gapi['load']?_0x56b096():_0x48f6a9(X(_0x322f41,'network-request-failed'));},xa(Of()+'?onload='+_0x2d327a)['catch'](_0x27642f=>_0x48f6a9(_0x27642f));}}})['catch'](_0x1d99a1=>{throw an=null,_0x1d99a1;});}let an=null;function Wp(_0x20fc73){return an=an||Up(_0x20fc73),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x31de80){const _0x1b91d7=_0x31de80['config'];m(_0x1b91d7['authDomain'],_0x31de80,'auth-domain-config-required');const _0x1990b2=_0x1b91d7['emulator']?Cs(_0x1b91d7,Hp):'https://'+_0x31de80['config']['authDomain']+'/'+Vp,_0x274a70={'apiKey':_0x1b91d7['apiKey'],'appName':_0x31de80['name'],'v':lt},_0x20f371=Gp['get'](_0x31de80['config']['apiHost']);_0x20f371&&(_0x274a70['eid']=_0x20f371);const _0x241528=_0x31de80['_getFrameworks']();return _0x241528['length']&&(_0x274a70['fw']=_0x241528['join'](',')),_0x1990b2+'?'+ct(_0x274a70)['slice'](0x1);}async function zp(_0xac325c){const _0x5c5316=await Wp(_0xac325c),_0x12e848=Z()['gapi'];return m(_0x12e848,_0xac325c,'internal-error'),_0x5c5316['open']({'where':document['body'],'url':qp(_0xac325c),'messageHandlersFilter':_0x12e848['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x48e393=>new Promise(async(_0x5e2647,_0x4861d1)=>{await _0x48e393['restyle']({'setHideOnLeave':!0x1});const _0x39fe85=X(_0xac325c,'network-request-failed'),_0x25f20a=Z()['setTimeout'](()=>{_0x4861d1(_0x39fe85);},Bp['get']());function _0x1c72b3(){Z()['clearTimeout'](_0x25f20a),_0x5e2647(_0x48e393);}_0x48e393['ping'](_0x1c72b3)['then'](_0x1c72b3,()=>{_0x4861d1(_0x39fe85);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x100a89){this['window']=_0x100a89,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x4f54bd,_0x243a51,_0xd21f,_0x5809d1=Kp,_0x2e53ef=Yp){const _0x490baa=Math['max']((window['screen']['availHeight']-_0x2e53ef)/0x2,0x0)['toString'](),_0x135c9e=Math['max']((window['screen']['availWidth']-_0x5809d1)/0x2,0x0)['toString']();let _0x5abcf0='';const _0x15f785={...jp,'width':_0x5809d1['toString'](),'height':_0x2e53ef['toString'](),'top':_0x490baa,'left':_0x135c9e},_0x331380=W()['toLowerCase']();_0xd21f&&(_0x5abcf0=ka(_0x331380)?Qp:_0xd21f),Ra(_0x331380)&&(_0x243a51=_0x243a51||Jp,_0x15f785['scrollbars']='yes');const _0x43f1c7=Object['entries'](_0x15f785)['reduce']((_0x2ff957,[_0x24f6f8,_0x373e13])=>''+_0x2ff957+_0x24f6f8+'='+_0x373e13+',','');if(Cf(_0x331380)&&_0x5abcf0!=='_self')return Zp(_0x243a51||'',_0x5abcf0),new Lr(null);const _0x5bf7dd=window['open'](_0x243a51||'',_0x5abcf0,_0x43f1c7);m(_0x5bf7dd,_0x4f54bd,'popup-blocked');try{_0x5bf7dd['focus']();}catch{}return new Lr(_0x5bf7dd);}function Zp(_0x572cc0,_0x4eb671){const _0x126c81=document['createElement']('a');_0x126c81['href']=_0x572cc0,_0x126c81['target']=_0x4eb671;const _0x3f9e57=document['createEvent']('MouseEvent');_0x3f9e57['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x126c81['dispatchEvent'](_0x3f9e57);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x16e89b,_0x4630e9,_0x29281a,_0x2280e1,_0x5b514b,_0x56ba8d){m(_0x16e89b['config']['authDomain'],_0x16e89b,'auth-domain-config-required'),m(_0x16e89b['config']['apiKey'],_0x16e89b,'invalid-api-key');const _0x3c43ec={'apiKey':_0x16e89b['config']['apiKey'],'appName':_0x16e89b['name'],'authType':_0x29281a,'redirectUrl':_0x2280e1,'v':lt,'eventId':_0x5b514b};if(_0x4630e9 instanceof Wa){_0x4630e9['setDefaultLanguage'](_0x16e89b['languageCode']),_0x3c43ec['providerId']=_0x4630e9['providerId']||'',ui(_0x4630e9['getCustomParameters']())||(_0x3c43ec['customParameters']=JSON['stringify'](_0x4630e9['getCustomParameters']()));for(const [_0x49ce9d,_0x582e39]of Object['entries']({}))_0x3c43ec[_0x49ce9d]=_0x582e39;}if(_0x4630e9 instanceof Jt){const _0x5f24be=_0x4630e9['getScopes']()['filter'](_0xa31753=>_0xa31753!=='');_0x5f24be['length']>0x0&&(_0x3c43ec['scopes']=_0x5f24be['join'](','));}_0x16e89b['tenantId']&&(_0x3c43ec['tid']=_0x16e89b['tenantId']);const _0x2796fb=_0x3c43ec;for(const _0x2601f8 of Object['keys'](_0x2796fb))_0x2796fb[_0x2601f8]===void 0x0&&delete _0x2796fb[_0x2601f8];const _0x57cbcb=await _0x16e89b['_getAppCheckToken'](),_0x30493c=_0x57cbcb?'#'+n_+'='+encodeURIComponent(_0x57cbcb):'';return i_(_0x16e89b)+'?'+ct(_0x2796fb)['slice'](0x1)+_0x30493c;}function i_({config:_0x46587d}){return _0x46587d['emulator']?Cs(_0x46587d,t_):'https://'+_0x46587d['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x38ce98,_0x25ae3a,_0x18e6f8,_0x2aa601){var _0x37d37e;ce((_0x37d37e=this['eventManagers'][_0x38ce98['_key']()])==null?void 0x0:_0x37d37e['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x5e49fc=await xr(_0x38ce98,_0x25ae3a,_0x18e6f8,Pi(),_0x2aa601);return Xp(_0x38ce98,_0x5e49fc,As());}async['_openRedirect'](_0x5f29d2,_0x16a761,_0x3a664d,_0xd2a96){await this['_originValidation'](_0x5f29d2);const _0x29e2c2=await xr(_0x5f29d2,_0x16a761,_0x3a664d,Pi(),_0xd2a96);return ap(_0x29e2c2),new Promise(()=>{});}['_initialize'](_0x303818){const _0xd48dd9=_0x303818['_key']();if(this['eventManagers'][_0xd48dd9]){const {manager:_0x16e5a4,promise:_0x19e432}=this['eventManagers'][_0xd48dd9];return _0x16e5a4?Promise['resolve'](_0x16e5a4):(ce(_0x19e432,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x19e432);}const _0x31b613=this['initAndGetManager'](_0x303818);return this['eventManagers'][_0xd48dd9]={'promise':_0x31b613},_0x31b613['catch'](()=>{delete this['eventManagers'][_0xd48dd9];}),_0x31b613;}async['initAndGetManager'](_0x2791fe){const _0x594eb7=await zp(_0x2791fe),_0x5ae65a=new Np(_0x2791fe);return _0x594eb7['register']('authEvent',_0xe56138=>(m(_0xe56138==null?void 0x0:_0xe56138['authEvent'],_0x2791fe,'invalid-auth-event'),{'status':_0x5ae65a['onEvent'](_0xe56138['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x2791fe['_key']()]={'manager':_0x5ae65a},this['iframes'][_0x2791fe['_key']()]=_0x594eb7,_0x5ae65a;}['_isIframeWebStorageSupported'](_0x43d645,_0x56bf59){this['iframes'][_0x43d645['_key']()]['send'](hi,{'type':hi},_0x44c000=>{var _0x18c503;const _0x3f7b95=(_0x18c503=_0x44c000==null?void 0x0:_0x44c000[0x0])==null?void 0x0:_0x18c503[hi];_0x3f7b95!==void 0x0&&_0x56bf59(!!_0x3f7b95),Q(_0x43d645,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x55a90c){const _0x4a23c9=_0x55a90c['_key']();return this['originValidationPromises'][_0x4a23c9]||(this['originValidationPromises'][_0x4a23c9]=Lp(_0x55a90c)),this['originValidationPromises'][_0x4a23c9];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x65c2e1){this['auth']=_0x65c2e1,this['internalListeners']=new Map();}['getUid'](){var _0x2548f0;return this['assertAuthConfigured'](),((_0x2548f0=this['auth']['currentUser'])==null?void 0x0:_0x2548f0['uid'])||null;}async['getToken'](_0x225c70){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x225c70)}:null;}['addAuthTokenListener'](_0x1d580c){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x1d580c))return;const _0x2c84d7=this['auth']['onIdTokenChanged'](_0x48da64=>{_0x1d580c((_0x48da64==null?void 0x0:_0x48da64['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x1d580c,_0x2c84d7),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x4937a7){this['assertAuthConfigured']();const _0x1abc98=this['internalListeners']['get'](_0x4937a7);_0x1abc98&&(this['internalListeners']['delete'](_0x4937a7),_0x1abc98(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x3ae792){switch(_0x3ae792){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0xc9ddca){Ze(new Le('auth',(_0x262e34,{options:_0x3890f0})=>{const _0x49e30a=_0x262e34['getProvider']('app')['getImmediate'](),_0x121e99=_0x262e34['getProvider']('heartbeat'),_0x4abc40=_0x262e34['getProvider']('app-check-internal'),{apiKey:_0x207920,authDomain:_0x3210a3}=_0x49e30a['options'];m(_0x207920&&!_0x207920['includes'](':'),'invalid-api-key',{'appName':_0x49e30a['name']});const _0x28f36d={'apiKey':_0x207920,'authDomain':_0x3210a3,'clientPlatform':_0xc9ddca,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0xc9ddca)},_0x233434=new kf(_0x49e30a,_0x121e99,_0x4abc40,_0x28f36d);return Wf(_0x233434,_0x3890f0),_0x233434;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x43a70c,_0x480515,_0x77dcfb)=>{_0x43a70c['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x2252fc=>{const _0x1aeb6f=qe(_0x2252fc['getProvider']('auth')['getImmediate']());return(_0x24e0e4=>new o_(_0x24e0e4))(_0x1aeb6f);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0xc9ddca)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x3f0445=>async _0x1d722e=>{const _0x51382e=_0x1d722e&&await _0x1d722e['getIdTokenResult'](),_0x58acde=_0x51382e&&(new Date()['getTime']()-Date['parse'](_0x51382e['issuedAtTime']))/0x3e8;if(_0x58acde&&_0x58acde>h_)return;const _0x5bd247=_0x51382e==null?void 0x0:_0x51382e['token'];Wr!==_0x5bd247&&(Wr=_0x5bd247,await fetch(_0x3f0445,{'method':_0x5bd247?'POST':'DELETE','headers':_0x5bd247?{'Authorization':'Bearer\x20'+_0x5bd247}:{}}));};function x_(_0x4f1d3a=Zr()){const _0x4d5197=Bi(_0x4f1d3a,'auth');if(_0x4d5197['isInitialized']())return _0x4d5197['getImmediate']();const _0x570b4e=Uf(_0x4f1d3a,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x54d3c2=zr('authTokenSyncURL');if(_0x54d3c2&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x3481d5=new URL(_0x54d3c2,location['origin']);if(location['origin']===_0x3481d5['origin']){const _0x400642=u_(_0x3481d5['toString']());tp(_0x570b4e,_0x400642,()=>_0x400642(_0x570b4e['currentUser'])),ep(_0x570b4e,_0x448287=>_0x400642(_0x448287));}}const _0xe422ec=Gr('auth');return _0xe422ec&&Bf(_0x570b4e,'http://'+_0xe422ec),_0x570b4e;}function d_(){var _0x248ac8;return((_0x248ac8=document['getElementsByTagName']('head'))==null?void 0x0:_0x248ac8[0x0])??document;}Nf({'loadJS'(_0x3f4a83){return new Promise((_0x3291fa,_0x73e145)=>{const _0x5e62fa=document['createElement']('script');_0x5e62fa['setAttribute']('src',_0x3f4a83),_0x5e62fa['onload']=_0x3291fa,_0x5e62fa['onerror']=_0x4eef63=>{const _0x54c8ad=X('internal-error');_0x54c8ad['customData']=_0x4eef63,_0x73e145(_0x54c8ad);},_0x5e62fa['type']='text/javascript',_0x5e62fa['charset']='UTF-8',d_()['appendChild'](_0x5e62fa);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};