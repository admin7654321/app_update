const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x1bc3a4,_0x10329e){if(!_0x1bc3a4)throw rt(_0x10329e);},rt=function(_0x3f9e15){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x3f9e15);},Vr=function(_0x41c7dc){const _0x54f3b6=[];let _0x1a6e88=0x0;for(let _0xcd39d=0x0;_0xcd39d<_0x41c7dc['length'];_0xcd39d++){let _0x215174=_0x41c7dc['charCodeAt'](_0xcd39d);_0x215174<0x80?_0x54f3b6[_0x1a6e88++]=_0x215174:_0x215174<0x800?(_0x54f3b6[_0x1a6e88++]=_0x215174>>0x6|0xc0,_0x54f3b6[_0x1a6e88++]=_0x215174&0x3f|0x80):(_0x215174&0xfc00)===0xd800&&_0xcd39d+0x1<_0x41c7dc['length']&&(_0x41c7dc['charCodeAt'](_0xcd39d+0x1)&0xfc00)===0xdc00?(_0x215174=0x10000+((_0x215174&0x3ff)<<0xa)+(_0x41c7dc['charCodeAt'](++_0xcd39d)&0x3ff),_0x54f3b6[_0x1a6e88++]=_0x215174>>0x12|0xf0,_0x54f3b6[_0x1a6e88++]=_0x215174>>0xc&0x3f|0x80,_0x54f3b6[_0x1a6e88++]=_0x215174>>0x6&0x3f|0x80,_0x54f3b6[_0x1a6e88++]=_0x215174&0x3f|0x80):(_0x54f3b6[_0x1a6e88++]=_0x215174>>0xc|0xe0,_0x54f3b6[_0x1a6e88++]=_0x215174>>0x6&0x3f|0x80,_0x54f3b6[_0x1a6e88++]=_0x215174&0x3f|0x80);}return _0x54f3b6;},ec=function(_0x18f3c4){const _0x5dbd1c=[];let _0x4556ad=0x0,_0x4c5eee=0x0;for(;_0x4556ad<_0x18f3c4['length'];){const _0xb969c2=_0x18f3c4[_0x4556ad++];if(_0xb969c2<0x80)_0x5dbd1c[_0x4c5eee++]=String['fromCharCode'](_0xb969c2);else{if(_0xb969c2>0xbf&&_0xb969c2<0xe0){const _0x2fc89d=_0x18f3c4[_0x4556ad++];_0x5dbd1c[_0x4c5eee++]=String['fromCharCode']((_0xb969c2&0x1f)<<0x6|_0x2fc89d&0x3f);}else{if(_0xb969c2>0xef&&_0xb969c2<0x16d){const _0x596474=_0x18f3c4[_0x4556ad++],_0x1490aa=_0x18f3c4[_0x4556ad++],_0x448648=_0x18f3c4[_0x4556ad++],_0x24d7d7=((_0xb969c2&0x7)<<0x12|(_0x596474&0x3f)<<0xc|(_0x1490aa&0x3f)<<0x6|_0x448648&0x3f)-0x10000;_0x5dbd1c[_0x4c5eee++]=String['fromCharCode'](0xd800+(_0x24d7d7>>0xa)),_0x5dbd1c[_0x4c5eee++]=String['fromCharCode'](0xdc00+(_0x24d7d7&0x3ff));}else{const _0x514904=_0x18f3c4[_0x4556ad++],_0x9d531a=_0x18f3c4[_0x4556ad++];_0x5dbd1c[_0x4c5eee++]=String['fromCharCode']((_0xb969c2&0xf)<<0xc|(_0x514904&0x3f)<<0x6|_0x9d531a&0x3f);}}}}return _0x5dbd1c['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x209d4c,_0x61be75){if(!Array['isArray'](_0x209d4c))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x4aafc6=_0x61be75?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x51730c=[];for(let _0x4f5aa1=0x0;_0x4f5aa1<_0x209d4c['length'];_0x4f5aa1+=0x3){const _0x9ed81e=_0x209d4c[_0x4f5aa1],_0x5ca237=_0x4f5aa1+0x1<_0x209d4c['length'],_0xb7ad7b=_0x5ca237?_0x209d4c[_0x4f5aa1+0x1]:0x0,_0x14e398=_0x4f5aa1+0x2<_0x209d4c['length'],_0x3edcb2=_0x14e398?_0x209d4c[_0x4f5aa1+0x2]:0x0,_0x450a97=_0x9ed81e>>0x2,_0x43e448=(_0x9ed81e&0x3)<<0x4|_0xb7ad7b>>0x4;let _0x3f8aaf=(_0xb7ad7b&0xf)<<0x2|_0x3edcb2>>0x6,_0x2e328c=_0x3edcb2&0x3f;_0x14e398||(_0x2e328c=0x40,_0x5ca237||(_0x3f8aaf=0x40)),_0x51730c['push'](_0x4aafc6[_0x450a97],_0x4aafc6[_0x43e448],_0x4aafc6[_0x3f8aaf],_0x4aafc6[_0x2e328c]);}return _0x51730c['join']('');},'encodeString'(_0x47075e,_0x187558){return this['HAS_NATIVE_SUPPORT']&&!_0x187558?btoa(_0x47075e):this['encodeByteArray'](Vr(_0x47075e),_0x187558);},'decodeString'(_0x38cc6b,_0x37d6c6){return this['HAS_NATIVE_SUPPORT']&&!_0x37d6c6?atob(_0x38cc6b):ec(this['decodeStringToByteArray'](_0x38cc6b,_0x37d6c6));},'decodeStringToByteArray'(_0x20791f,_0x14a976){this['init_']();const _0x2fffc3=_0x14a976?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x523e61=[];for(let _0x487e04=0x0;_0x487e04<_0x20791f['length'];){const _0x15b976=_0x2fffc3[_0x20791f['charAt'](_0x487e04++)],_0xb184e2=_0x487e04<_0x20791f['length']?_0x2fffc3[_0x20791f['charAt'](_0x487e04)]:0x0;++_0x487e04;const _0x187a16=_0x487e04<_0x20791f['length']?_0x2fffc3[_0x20791f['charAt'](_0x487e04)]:0x40;++_0x487e04;const _0x555a6d=_0x487e04<_0x20791f['length']?_0x2fffc3[_0x20791f['charAt'](_0x487e04)]:0x40;if(++_0x487e04,_0x15b976==null||_0xb184e2==null||_0x187a16==null||_0x555a6d==null)throw new tc();const _0x23a617=_0x15b976<<0x2|_0xb184e2>>0x4;if(_0x523e61['push'](_0x23a617),_0x187a16!==0x40){const _0x2e8f15=_0xb184e2<<0x4&0xf0|_0x187a16>>0x2;if(_0x523e61['push'](_0x2e8f15),_0x555a6d!==0x40){const _0x141e4e=_0x187a16<<0x6&0xc0|_0x555a6d;_0x523e61['push'](_0x141e4e);}}}return _0x523e61;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x32feae=0x0;_0x32feae<this['ENCODED_VALS']['length'];_0x32feae++)this['byteToCharMap_'][_0x32feae]=this['ENCODED_VALS']['charAt'](_0x32feae),this['charToByteMap_'][this['byteToCharMap_'][_0x32feae]]=_0x32feae,this['byteToCharMapWebSafe_'][_0x32feae]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x32feae),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x32feae]]=_0x32feae,_0x32feae>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x32feae)]=_0x32feae,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x32feae)]=_0x32feae);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x468b4a){const _0x37a297=Vr(_0x468b4a);return Li['encodeByteArray'](_0x37a297,!0x0);},cn=function(_0x3cad4b){return Hr(_0x3cad4b)['replace'](/\./g,'');},ln=function(_0x324ca5){try{return Li['decodeString'](_0x324ca5,!0x0);}catch(_0x4131bd){console['error']('base64Decode\x20failed:\x20',_0x4131bd);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x33aee6){return $r(void 0x0,_0x33aee6);}function $r(_0x5417fc,_0xb3249f){if(!(_0xb3249f instanceof Object))return _0xb3249f;switch(_0xb3249f['constructor']){case Date:const _0x51cce6=_0xb3249f;return new Date(_0x51cce6['getTime']());case Object:_0x5417fc===void 0x0&&(_0x5417fc={});break;case Array:_0x5417fc=[];break;default:return _0xb3249f;}for(const _0x5a8627 in _0xb3249f)!_0xb3249f['hasOwnProperty'](_0x5a8627)||!ic(_0x5a8627)||(_0x5417fc[_0x5a8627]=$r(_0x5417fc[_0x5a8627],_0xb3249f[_0x5a8627]));return _0x5417fc;}function ic(_0x1e7058){return _0x1e7058!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x49c8e3=Ns['__FIREBASE_DEFAULTS__'];if(_0x49c8e3)return JSON['parse'](_0x49c8e3);},ac=()=>{if(typeof document>'u')return;let _0x231b55;try{_0x231b55=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x189fe2=_0x231b55&&ln(_0x231b55[0x1]);return _0x189fe2&&JSON['parse'](_0x189fe2);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x45a4a1){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x45a4a1);return;}},Gr=_0x2762af=>{var _0x4c721a,_0x5dae6c;return(_0x5dae6c=(_0x4c721a=xi())==null?void 0x0:_0x4c721a['emulatorHosts'])==null?void 0x0:_0x5dae6c[_0x2762af];},cc=_0x1b3fa3=>{const _0xad825f=Gr(_0x1b3fa3);if(!_0xad825f)return;const _0x1b3763=_0xad825f['lastIndexOf'](':');if(_0x1b3763<=0x0||_0x1b3763+0x1===_0xad825f['length'])throw new Error('Invalid\x20host\x20'+_0xad825f+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x4a8c21=parseInt(_0xad825f['substring'](_0x1b3763+0x1),0xa);return _0xad825f[0x0]==='['?[_0xad825f['substring'](0x1,_0x1b3763-0x1),_0x4a8c21]:[_0xad825f['substring'](0x0,_0x1b3763),_0x4a8c21];},qr=()=>{var _0x3796b7;return(_0x3796b7=xi())==null?void 0x0:_0x3796b7['config'];},zr=_0x127c33=>{var _0x415d89;return(_0x415d89=xi())==null?void 0x0:_0x415d89['_'+_0x127c33];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x75b8d7,_0x4933b)=>{this['resolve']=_0x75b8d7,this['reject']=_0x4933b;});}['wrapCallback'](_0xe0e922){return(_0xc9cce4,_0x1217fc)=>{_0xc9cce4?this['reject'](_0xc9cce4):this['resolve'](_0x1217fc),typeof _0xe0e922=='function'&&(this['promise']['catch'](()=>{}),_0xe0e922['length']===0x1?_0xe0e922(_0xc9cce4):_0xe0e922(_0xc9cce4,_0x1217fc));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x1df138){try{return(_0x1df138['startsWith']('http://')||_0x1df138['startsWith']('https://')?new URL(_0x1df138)['hostname']:_0x1df138)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x4765da){return(await fetch(_0x4765da,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x3b6d0d,_0x5d2953){if(_0x3b6d0d['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x202734={'alg':'none','type':'JWT'},_0x574576=_0x5d2953||'demo-project',_0x129c5a=_0x3b6d0d['iat']||0x0,_0x706294=_0x3b6d0d['sub']||_0x3b6d0d['user_id'];if(!_0x706294)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x54938b={'iss':'https://securetoken.google.com/'+_0x574576,'aud':_0x574576,'iat':_0x129c5a,'exp':_0x129c5a+0xe10,'auth_time':_0x129c5a,'sub':_0x706294,'user_id':_0x706294,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x3b6d0d};return[cn(JSON['stringify'](_0x202734)),cn(JSON['stringify'](_0x54938b)),'']['join']('.');}const It={};function hc(){const _0x4214db={'prod':[],'emulator':[]};for(const _0x1b1e62 of Object['keys'](It))It[_0x1b1e62]?_0x4214db['emulator']['push'](_0x1b1e62):_0x4214db['prod']['push'](_0x1b1e62);return _0x4214db;}function uc(_0x5213ee){let _0x1a8609=document['getElementById'](_0x5213ee),_0x78344d=!0x1;return _0x1a8609||(_0x1a8609=document['createElement']('div'),_0x1a8609['setAttribute']('id',_0x5213ee),_0x78344d=!0x0),{'created':_0x78344d,'element':_0x1a8609};}let Ps=!0x1;function Kr(_0x4bc78d,_0x1d2015){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x4bc78d]===_0x1d2015||It[_0x4bc78d]||Ps)return;It[_0x4bc78d]=_0x1d2015;function _0x40b4a5(_0x542657){return'__firebase__banner__'+_0x542657;}const _0x2e1f44='__firebase__banner',_0x514d87=hc()['prod']['length']>0x0;function _0x1f9d81(){const _0x100594=document['getElementById'](_0x2e1f44);_0x100594&&_0x100594['remove']();}function _0x3d4409(_0x6d5966){_0x6d5966['style']['display']='flex',_0x6d5966['style']['background']='#7faaf0',_0x6d5966['style']['position']='fixed',_0x6d5966['style']['bottom']='5px',_0x6d5966['style']['left']='5px',_0x6d5966['style']['padding']='.5em',_0x6d5966['style']['borderRadius']='5px',_0x6d5966['style']['alignItems']='center';}function _0x51b5d1(_0x170845,_0x231f80){_0x170845['setAttribute']('width','24'),_0x170845['setAttribute']('id',_0x231f80),_0x170845['setAttribute']('height','24'),_0x170845['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x170845['setAttribute']('fill','none'),_0x170845['style']['marginLeft']='-6px';}function _0x2be722(){const _0x147079=document['createElement']('span');return _0x147079['style']['cursor']='pointer',_0x147079['style']['marginLeft']='16px',_0x147079['style']['fontSize']='24px',_0x147079['innerHTML']='\x20&times;',_0x147079['onclick']=()=>{Ps=!0x0,_0x1f9d81();},_0x147079;}function _0x1a276b(_0x3d00e4,_0x2b310d){_0x3d00e4['setAttribute']('id',_0x2b310d),_0x3d00e4['innerText']='Learn\x20more',_0x3d00e4['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x3d00e4['setAttribute']('target','__blank'),_0x3d00e4['style']['paddingLeft']='5px',_0x3d00e4['style']['textDecoration']='underline';}function _0x539e60(){const _0x385708=uc(_0x2e1f44),_0x3e28ea=_0x40b4a5('text'),_0x13100f=document['getElementById'](_0x3e28ea)||document['createElement']('span'),_0x47391c=_0x40b4a5('learnmore'),_0x2f8416=document['getElementById'](_0x47391c)||document['createElement']('a'),_0x36b60b=_0x40b4a5('preprendIcon'),_0x419f24=document['getElementById'](_0x36b60b)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x385708['created']){const _0x7c4c71=_0x385708['element'];_0x3d4409(_0x7c4c71),_0x1a276b(_0x2f8416,_0x47391c);const _0x52c3b5=_0x2be722();_0x51b5d1(_0x419f24,_0x36b60b),_0x7c4c71['append'](_0x419f24,_0x13100f,_0x2f8416,_0x52c3b5),document['body']['appendChild'](_0x7c4c71);}_0x514d87?(_0x13100f['innerText']='Preview\x20backend\x20disconnected.',_0x419f24['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x419f24['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x13100f['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x13100f['setAttribute']('id',_0x3e28ea);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x539e60):_0x539e60();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x3b8a0a=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x3b8a0a=='object'&&_0x3b8a0a['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x1ac195=W();return _0x1ac195['indexOf']('MSIE\x20')>=0x0||_0x1ac195['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x373f62,_0x5a419f)=>{try{let _0x1b0e25=!0x0;const _0x3f5e42='validate-browser-context-for-indexeddb-analytics-module',_0x59ad0e=self['indexedDB']['open'](_0x3f5e42);_0x59ad0e['onsuccess']=()=>{_0x59ad0e['result']['close'](),_0x1b0e25||self['indexedDB']['deleteDatabase'](_0x3f5e42),_0x373f62(!0x0);},_0x59ad0e['onupgradeneeded']=()=>{_0x1b0e25=!0x1;},_0x59ad0e['onerror']=()=>{var _0x25d144;_0x5a419f(((_0x25d144=_0x59ad0e['error'])==null?void 0x0:_0x25d144['message'])||'');};}catch(_0x22fd30){_0x5a419f(_0x22fd30);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x26468a,_0x54a777,_0x488cd2){super(_0x54a777),this['code']=_0x26468a,this['customData']=_0x488cd2,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x1edd72,_0x4d1c97,_0x55f431){this['service']=_0x1edd72,this['serviceName']=_0x4d1c97,this['errors']=_0x55f431;}['create'](_0x226754,..._0x177871){const _0x7e296e=_0x177871[0x0]||{},_0xe34d25=this['service']+'/'+_0x226754,_0x3e397a=this['errors'][_0x226754],_0x5a3d58=_0x3e397a?vc(_0x3e397a,_0x7e296e):'Error',_0x3a483a=this['serviceName']+':\x20'+_0x5a3d58+'\x20('+_0xe34d25+').';return new Se(_0xe34d25,_0x3a483a,_0x7e296e);}}function vc(_0xbc2ace,_0x2980ad){return _0xbc2ace['replace'](Ec,(_0x527234,_0x563fbc)=>{const _0x4a5c25=_0x2980ad[_0x563fbc];return _0x4a5c25!=null?String(_0x4a5c25):'<'+_0x563fbc+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x148b70){return JSON['parse'](_0x148b70);}function O(_0x1b4599){return JSON['stringify'](_0x1b4599);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x28de80){let _0x340d26={},_0x14d8a7={},_0x5e192b={},_0x284b55='';try{const _0x30a0d3=_0x28de80['split']('.');_0x340d26=At(ln(_0x30a0d3[0x0])||''),_0x14d8a7=At(ln(_0x30a0d3[0x1])||''),_0x284b55=_0x30a0d3[0x2],_0x5e192b=_0x14d8a7['d']||{},delete _0x14d8a7['d'];}catch{}return{'header':_0x340d26,'claims':_0x14d8a7,'data':_0x5e192b,'signature':_0x284b55};},Ic=function(_0x50d737){const _0x5e562d=Qr(_0x50d737),_0x32a1c8=_0x5e562d['claims'];return!!_0x32a1c8&&typeof _0x32a1c8=='object'&&_0x32a1c8['hasOwnProperty']('iat');},wc=function(_0x59eb08){const _0x26bcc0=Qr(_0x59eb08)['claims'];return typeof _0x26bcc0=='object'&&_0x26bcc0['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x34d40b,_0x30d3a6){return Object['prototype']['hasOwnProperty']['call'](_0x34d40b,_0x30d3a6);}function De(_0x2106d6,_0xc0c1f7){if(Object['prototype']['hasOwnProperty']['call'](_0x2106d6,_0xc0c1f7))return _0x2106d6[_0xc0c1f7];}function ui(_0x4c9ce7){for(const _0x378816 in _0x4c9ce7)if(Object['prototype']['hasOwnProperty']['call'](_0x4c9ce7,_0x378816))return!0x1;return!0x0;}function hn(_0x15ec41,_0x1bee53,_0x527895){const _0x1b2f34={};for(const _0x17b4a1 in _0x15ec41)Object['prototype']['hasOwnProperty']['call'](_0x15ec41,_0x17b4a1)&&(_0x1b2f34[_0x17b4a1]=_0x1bee53['call'](_0x527895,_0x15ec41[_0x17b4a1],_0x17b4a1,_0x15ec41));return _0x1b2f34;}function Me(_0x435d59,_0x499e1a){if(_0x435d59===_0x499e1a)return!0x0;const _0x472396=Object['keys'](_0x435d59),_0x146925=Object['keys'](_0x499e1a);for(const _0x10c41d of _0x472396){if(!_0x146925['includes'](_0x10c41d))return!0x1;const _0x3e8e83=_0x435d59[_0x10c41d],_0xeb4432=_0x499e1a[_0x10c41d];if(Os(_0x3e8e83)&&Os(_0xeb4432)){if(!Me(_0x3e8e83,_0xeb4432))return!0x1;}else{if(_0x3e8e83!==_0xeb4432)return!0x1;}}for(const _0x42e371 of _0x146925)if(!_0x472396['includes'](_0x42e371))return!0x1;return!0x0;}function Os(_0x42dadc){return _0x42dadc!==null&&typeof _0x42dadc=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x2197d2){const _0x3d51f9=[];for(const [_0x30be13,_0xac7946]of Object['entries'](_0x2197d2))Array['isArray'](_0xac7946)?_0xac7946['forEach'](_0x5514a8=>{_0x3d51f9['push'](encodeURIComponent(_0x30be13)+'='+encodeURIComponent(_0x5514a8));}):_0x3d51f9['push'](encodeURIComponent(_0x30be13)+'='+encodeURIComponent(_0xac7946));return _0x3d51f9['length']?'&'+_0x3d51f9['join']('&'):'';}function vt(_0x104b68){const _0xeb276b={};return _0x104b68['replace'](/^\?/,'')['split']('&')['forEach'](_0x4da947=>{if(_0x4da947){const [_0x18bec3,_0x14ba73]=_0x4da947['split']('=');_0xeb276b[decodeURIComponent(_0x18bec3)]=decodeURIComponent(_0x14ba73);}}),_0xeb276b;}function Et(_0x39df4b){const _0x4315b7=_0x39df4b['indexOf']('?');if(!_0x4315b7)return'';const _0x1e2401=_0x39df4b['indexOf']('#',_0x4315b7);return _0x39df4b['substring'](_0x4315b7,_0x1e2401>0x0?_0x1e2401:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0xabaf1a=0x1;_0xabaf1a<this['blockSize'];++_0xabaf1a)this['pad_'][_0xabaf1a]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1a0e9d,_0xedd2b){_0xedd2b||(_0xedd2b=0x0);const _0x1e8f57=this['W_'];if(typeof _0x1a0e9d=='string'){for(let _0x846afe=0x0;_0x846afe<0x10;_0x846afe++)_0x1e8f57[_0x846afe]=_0x1a0e9d['charCodeAt'](_0xedd2b)<<0x18|_0x1a0e9d['charCodeAt'](_0xedd2b+0x1)<<0x10|_0x1a0e9d['charCodeAt'](_0xedd2b+0x2)<<0x8|_0x1a0e9d['charCodeAt'](_0xedd2b+0x3),_0xedd2b+=0x4;}else{for(let _0x328230=0x0;_0x328230<0x10;_0x328230++)_0x1e8f57[_0x328230]=_0x1a0e9d[_0xedd2b]<<0x18|_0x1a0e9d[_0xedd2b+0x1]<<0x10|_0x1a0e9d[_0xedd2b+0x2]<<0x8|_0x1a0e9d[_0xedd2b+0x3],_0xedd2b+=0x4;}for(let _0x45fee0=0x10;_0x45fee0<0x50;_0x45fee0++){const _0x323684=_0x1e8f57[_0x45fee0-0x3]^_0x1e8f57[_0x45fee0-0x8]^_0x1e8f57[_0x45fee0-0xe]^_0x1e8f57[_0x45fee0-0x10];_0x1e8f57[_0x45fee0]=(_0x323684<<0x1|_0x323684>>>0x1f)&0xffffffff;}let _0x25b2e1=this['chain_'][0x0],_0x5db1a7=this['chain_'][0x1],_0xb58934=this['chain_'][0x2],_0x31f4e5=this['chain_'][0x3],_0x568245=this['chain_'][0x4],_0xc327b2,_0x1bcecd;for(let _0x442328=0x0;_0x442328<0x50;_0x442328++){_0x442328<0x28?_0x442328<0x14?(_0xc327b2=_0x31f4e5^_0x5db1a7&(_0xb58934^_0x31f4e5),_0x1bcecd=0x5a827999):(_0xc327b2=_0x5db1a7^_0xb58934^_0x31f4e5,_0x1bcecd=0x6ed9eba1):_0x442328<0x3c?(_0xc327b2=_0x5db1a7&_0xb58934|_0x31f4e5&(_0x5db1a7|_0xb58934),_0x1bcecd=0x8f1bbcdc):(_0xc327b2=_0x5db1a7^_0xb58934^_0x31f4e5,_0x1bcecd=0xca62c1d6);const _0x563d16=(_0x25b2e1<<0x5|_0x25b2e1>>>0x1b)+_0xc327b2+_0x568245+_0x1bcecd+_0x1e8f57[_0x442328]&0xffffffff;_0x568245=_0x31f4e5,_0x31f4e5=_0xb58934,_0xb58934=(_0x5db1a7<<0x1e|_0x5db1a7>>>0x2)&0xffffffff,_0x5db1a7=_0x25b2e1,_0x25b2e1=_0x563d16;}this['chain_'][0x0]=this['chain_'][0x0]+_0x25b2e1&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5db1a7&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0xb58934&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x31f4e5&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x568245&0xffffffff;}['update'](_0x417363,_0x2e8dc7){if(_0x417363==null)return;_0x2e8dc7===void 0x0&&(_0x2e8dc7=_0x417363['length']);const _0x54b2d7=_0x2e8dc7-this['blockSize'];let _0x518206=0x0;const _0x505e10=this['buf_'];let _0x3fbaf9=this['inbuf_'];for(;_0x518206<_0x2e8dc7;){if(_0x3fbaf9===0x0){for(;_0x518206<=_0x54b2d7;)this['compress_'](_0x417363,_0x518206),_0x518206+=this['blockSize'];}if(typeof _0x417363=='string'){for(;_0x518206<_0x2e8dc7;)if(_0x505e10[_0x3fbaf9]=_0x417363['charCodeAt'](_0x518206),++_0x3fbaf9,++_0x518206,_0x3fbaf9===this['blockSize']){this['compress_'](_0x505e10),_0x3fbaf9=0x0;break;}}else{for(;_0x518206<_0x2e8dc7;)if(_0x505e10[_0x3fbaf9]=_0x417363[_0x518206],++_0x3fbaf9,++_0x518206,_0x3fbaf9===this['blockSize']){this['compress_'](_0x505e10),_0x3fbaf9=0x0;break;}}}this['inbuf_']=_0x3fbaf9,this['total_']+=_0x2e8dc7;}['digest'](){const _0x427186=[];let _0x291fea=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x5d36f3=this['blockSize']-0x1;_0x5d36f3>=0x38;_0x5d36f3--)this['buf_'][_0x5d36f3]=_0x291fea&0xff,_0x291fea/=0x100;this['compress_'](this['buf_']);let _0x21d6ef=0x0;for(let _0x26e841=0x0;_0x26e841<0x5;_0x26e841++)for(let _0x200e2f=0x18;_0x200e2f>=0x0;_0x200e2f-=0x8)_0x427186[_0x21d6ef]=this['chain_'][_0x26e841]>>_0x200e2f&0xff,++_0x21d6ef;return _0x427186;}}function Tc(_0x445059,_0x3218fb){const _0x4ac1bc=new Sc(_0x445059,_0x3218fb);return _0x4ac1bc['subscribe']['bind'](_0x4ac1bc);}class Sc{constructor(_0x1a4c98,_0x226af2){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x226af2,this['task']['then'](()=>{_0x1a4c98(this);})['catch'](_0x1ddc3e=>{this['error'](_0x1ddc3e);});}['next'](_0x4012bb){this['forEachObserver'](_0x18adc4=>{_0x18adc4['next'](_0x4012bb);});}['error'](_0x315428){this['forEachObserver'](_0x1fa3ec=>{_0x1fa3ec['error'](_0x315428);}),this['close'](_0x315428);}['complete'](){this['forEachObserver'](_0x4f4219=>{_0x4f4219['complete']();}),this['close']();}['subscribe'](_0x93ae77,_0x4e1163,_0x3a04de){let _0x148bf5;if(_0x93ae77===void 0x0&&_0x4e1163===void 0x0&&_0x3a04de===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x93ae77,['next','error','complete'])?_0x148bf5=_0x93ae77:_0x148bf5={'next':_0x93ae77,'error':_0x4e1163,'complete':_0x3a04de},_0x148bf5['next']===void 0x0&&(_0x148bf5['next']=Jn),_0x148bf5['error']===void 0x0&&(_0x148bf5['error']=Jn),_0x148bf5['complete']===void 0x0&&(_0x148bf5['complete']=Jn);const _0x5a6858=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x148bf5['error'](this['finalError']):_0x148bf5['complete']();}catch{}}),this['observers']['push'](_0x148bf5),_0x5a6858;}['unsubscribeOne'](_0xf1d7f8){this['observers']===void 0x0||this['observers'][_0xf1d7f8]===void 0x0||(delete this['observers'][_0xf1d7f8],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x48730b){if(!this['finalized']){for(let _0x240676=0x0;_0x240676<this['observers']['length'];_0x240676++)this['sendOne'](_0x240676,_0x48730b);}}['sendOne'](_0x1fd4ad,_0x5495c1){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x1fd4ad]!==void 0x0)try{_0x5495c1(this['observers'][_0x1fd4ad]);}catch(_0x5dd0a8){typeof console<'u'&&console['error']&&console['error'](_0x5dd0a8);}});}['close'](_0x485088){this['finalized']||(this['finalized']=!0x0,_0x485088!==void 0x0&&(this['finalError']=_0x485088),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x49f8cf,_0x4ee1ee){if(typeof _0x49f8cf!='object'||_0x49f8cf===null)return!0x1;for(const _0x1a3137 of _0x4ee1ee)if(_0x1a3137 in _0x49f8cf&&typeof _0x49f8cf[_0x1a3137]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x2fc81d,_0x3cbc49){return _0x2fc81d+'\x20failed:\x20'+_0x3cbc49+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x31290a){const _0x220b63=[];let _0x5a71de=0x0;for(let _0x9e00e1=0x0;_0x9e00e1<_0x31290a['length'];_0x9e00e1++){let _0x2f99d2=_0x31290a['charCodeAt'](_0x9e00e1);if(_0x2f99d2>=0xd800&&_0x2f99d2<=0xdbff){const _0x44a970=_0x2f99d2-0xd800;_0x9e00e1++,f(_0x9e00e1<_0x31290a['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x11462d=_0x31290a['charCodeAt'](_0x9e00e1)-0xdc00;_0x2f99d2=0x10000+(_0x44a970<<0xa)+_0x11462d;}_0x2f99d2<0x80?_0x220b63[_0x5a71de++]=_0x2f99d2:_0x2f99d2<0x800?(_0x220b63[_0x5a71de++]=_0x2f99d2>>0x6|0xc0,_0x220b63[_0x5a71de++]=_0x2f99d2&0x3f|0x80):_0x2f99d2<0x10000?(_0x220b63[_0x5a71de++]=_0x2f99d2>>0xc|0xe0,_0x220b63[_0x5a71de++]=_0x2f99d2>>0x6&0x3f|0x80,_0x220b63[_0x5a71de++]=_0x2f99d2&0x3f|0x80):(_0x220b63[_0x5a71de++]=_0x2f99d2>>0x12|0xf0,_0x220b63[_0x5a71de++]=_0x2f99d2>>0xc&0x3f|0x80,_0x220b63[_0x5a71de++]=_0x2f99d2>>0x6&0x3f|0x80,_0x220b63[_0x5a71de++]=_0x2f99d2&0x3f|0x80);}return _0x220b63;},On=function(_0x1387f5){let _0x57bd95=0x0;for(let _0x314539=0x0;_0x314539<_0x1387f5['length'];_0x314539++){const _0x2df42e=_0x1387f5['charCodeAt'](_0x314539);_0x2df42e<0x80?_0x57bd95++:_0x2df42e<0x800?_0x57bd95+=0x2:_0x2df42e>=0xd800&&_0x2df42e<=0xdbff?(_0x57bd95+=0x4,_0x314539++):_0x57bd95+=0x3;}return _0x57bd95;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x3103ec){return _0x3103ec&&_0x3103ec['_delegate']?_0x3103ec['_delegate']:_0x3103ec;}class Le{constructor(_0x999f45,_0x408f6e,_0xc3aa9){this['name']=_0x999f45,this['instanceFactory']=_0x408f6e,this['type']=_0xc3aa9,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x2c0d7f){return this['instantiationMode']=_0x2c0d7f,this;}['setMultipleInstances'](_0xebc66c){return this['multipleInstances']=_0xebc66c,this;}['setServiceProps'](_0x48b90b){return this['serviceProps']=_0x48b90b,this;}['setInstanceCreatedCallback'](_0x516d5e){return this['onInstanceCreated']=_0x516d5e,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x27e7a1,_0x16450c){this['name']=_0x27e7a1,this['container']=_0x16450c,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x40dd37){const _0x21cfdf=this['normalizeInstanceIdentifier'](_0x40dd37);if(!this['instancesDeferred']['has'](_0x21cfdf)){const _0xe09fe2=new ot();if(this['instancesDeferred']['set'](_0x21cfdf,_0xe09fe2),this['isInitialized'](_0x21cfdf)||this['shouldAutoInitialize']())try{const _0x811374=this['getOrInitializeService']({'instanceIdentifier':_0x21cfdf});_0x811374&&_0xe09fe2['resolve'](_0x811374);}catch{}}return this['instancesDeferred']['get'](_0x21cfdf)['promise'];}['getImmediate'](_0x14cb1a){const _0x59b865=this['normalizeInstanceIdentifier'](_0x14cb1a==null?void 0x0:_0x14cb1a['identifier']),_0x472520=(_0x14cb1a==null?void 0x0:_0x14cb1a['optional'])??!0x1;if(this['isInitialized'](_0x59b865)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x59b865});}catch(_0x3e5032){if(_0x472520)return null;throw _0x3e5032;}else{if(_0x472520)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x48c3c1){if(_0x48c3c1['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x48c3c1['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x48c3c1,!!this['shouldAutoInitialize']()){if(Nc(_0x48c3c1))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x9a2238,_0x30aee2]of this['instancesDeferred']['entries']()){const _0x2f6e30=this['normalizeInstanceIdentifier'](_0x9a2238);try{const _0x451a50=this['getOrInitializeService']({'instanceIdentifier':_0x2f6e30});_0x30aee2['resolve'](_0x451a50);}catch{}}}}['clearInstance'](_0x2737ff=Ne){this['instancesDeferred']['delete'](_0x2737ff),this['instancesOptions']['delete'](_0x2737ff),this['instances']['delete'](_0x2737ff);}async['delete'](){const _0x7a6838=Array['from'](this['instances']['values']());await Promise['all']([..._0x7a6838['filter'](_0x3e9e1e=>'INTERNAL'in _0x3e9e1e)['map'](_0x954f1e=>_0x954f1e['INTERNAL']['delete']()),..._0x7a6838['filter'](_0x2ae777=>'_delete'in _0x2ae777)['map'](_0x446458=>_0x446458['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x5a594a=Ne){return this['instances']['has'](_0x5a594a);}['getOptions'](_0x19855d=Ne){return this['instancesOptions']['get'](_0x19855d)||{};}['initialize'](_0x29a092={}){const {options:_0x4df4fd={}}=_0x29a092,_0x134dc4=this['normalizeInstanceIdentifier'](_0x29a092['instanceIdentifier']);if(this['isInitialized'](_0x134dc4))throw Error(this['name']+'('+_0x134dc4+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x4fe233=this['getOrInitializeService']({'instanceIdentifier':_0x134dc4,'options':_0x4df4fd});for(const [_0x37e022,_0x1091cb]of this['instancesDeferred']['entries']()){const _0x463895=this['normalizeInstanceIdentifier'](_0x37e022);_0x134dc4===_0x463895&&_0x1091cb['resolve'](_0x4fe233);}return _0x4fe233;}['onInit'](_0x2b62e6,_0x336e80){const _0x322f83=this['normalizeInstanceIdentifier'](_0x336e80),_0x7b139d=this['onInitCallbacks']['get'](_0x322f83)??new Set();_0x7b139d['add'](_0x2b62e6),this['onInitCallbacks']['set'](_0x322f83,_0x7b139d);const _0x52c966=this['instances']['get'](_0x322f83);return _0x52c966&&_0x2b62e6(_0x52c966,_0x322f83),()=>{_0x7b139d['delete'](_0x2b62e6);};}['invokeOnInitCallbacks'](_0x3430c8,_0x56c693){const _0x1ef8bc=this['onInitCallbacks']['get'](_0x56c693);if(_0x1ef8bc){for(const _0x32ecb6 of _0x1ef8bc)try{_0x32ecb6(_0x3430c8,_0x56c693);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x4cc6ec,options:_0x51614f={}}){let _0x410856=this['instances']['get'](_0x4cc6ec);if(!_0x410856&&this['component']&&(_0x410856=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x4cc6ec),'options':_0x51614f}),this['instances']['set'](_0x4cc6ec,_0x410856),this['instancesOptions']['set'](_0x4cc6ec,_0x51614f),this['invokeOnInitCallbacks'](_0x410856,_0x4cc6ec),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x4cc6ec,_0x410856);}catch{}return _0x410856||null;}['normalizeInstanceIdentifier'](_0x1c5728=Ne){return this['component']?this['component']['multipleInstances']?_0x1c5728:Ne:_0x1c5728;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x4e06c0){return _0x4e06c0===Ne?void 0x0:_0x4e06c0;}function Nc(_0x5a35d5){return _0x5a35d5['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x43522f){this['name']=_0x43522f,this['providers']=new Map();}['addComponent'](_0x37812d){const _0x388b83=this['getProvider'](_0x37812d['name']);if(_0x388b83['isComponentSet']())throw new Error('Component\x20'+_0x37812d['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x388b83['setComponent'](_0x37812d);}['addOrOverwriteComponent'](_0x2df622){this['getProvider'](_0x2df622['name'])['isComponentSet']()&&this['providers']['delete'](_0x2df622['name']),this['addComponent'](_0x2df622);}['getProvider'](_0x20e8f6){if(this['providers']['has'](_0x20e8f6))return this['providers']['get'](_0x20e8f6);const _0x143dc5=new Ac(_0x20e8f6,this);return this['providers']['set'](_0x20e8f6,_0x143dc5),_0x143dc5;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x42488a){_0x42488a[_0x42488a['DEBUG']=0x0]='DEBUG',_0x42488a[_0x42488a['VERBOSE']=0x1]='VERBOSE',_0x42488a[_0x42488a['INFO']=0x2]='INFO',_0x42488a[_0x42488a['WARN']=0x3]='WARN',_0x42488a[_0x42488a['ERROR']=0x4]='ERROR',_0x42488a[_0x42488a['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x283efd,_0x23318b,..._0x4c4057)=>{if(_0x23318b<_0x283efd['logLevel'])return;const _0xf0205c=new Date()['toISOString'](),_0x15bac5=Mc[_0x23318b];if(_0x15bac5)console[_0x15bac5]('['+_0xf0205c+']\x20\x20'+_0x283efd['name']+':',..._0x4c4057);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x23318b+')');};class Ui{constructor(_0x37ffde){this['name']=_0x37ffde,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x531e2d){if(!(_0x531e2d in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x531e2d+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x531e2d;}['setLogLevel'](_0x38a7e1){this['_logLevel']=typeof _0x38a7e1=='string'?Oc[_0x38a7e1]:_0x38a7e1;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x4349cb){if(typeof _0x4349cb!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x4349cb;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x482680){this['_userLogHandler']=_0x482680;}['debug'](..._0x3fe50d){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x3fe50d),this['_logHandler'](this,T['DEBUG'],..._0x3fe50d);}['log'](..._0x1d4436){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x1d4436),this['_logHandler'](this,T['VERBOSE'],..._0x1d4436);}['info'](..._0x406577){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x406577),this['_logHandler'](this,T['INFO'],..._0x406577);}['warn'](..._0x15d1f5){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x15d1f5),this['_logHandler'](this,T['WARN'],..._0x15d1f5);}['error'](..._0x15fd61){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x15fd61),this['_logHandler'](this,T['ERROR'],..._0x15fd61);}}const xc=(_0x16087e,_0x49b5e6)=>_0x49b5e6['some'](_0x113626=>_0x16087e instanceof _0x113626);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x2774b3){const _0x263a03=new Promise((_0x56d60c,_0x410e12)=>{const _0x215896=()=>{_0x2774b3['removeEventListener']('success',_0xa38b67),_0x2774b3['removeEventListener']('error',_0x1a265d);},_0xa38b67=()=>{_0x56d60c(_e(_0x2774b3['result'])),_0x215896();},_0x1a265d=()=>{_0x410e12(_0x2774b3['error']),_0x215896();};_0x2774b3['addEventListener']('success',_0xa38b67),_0x2774b3['addEventListener']('error',_0x1a265d);});return _0x263a03['then'](_0x4efd6c=>{_0x4efd6c instanceof IDBCursor&&Jr['set'](_0x4efd6c,_0x2774b3);})['catch'](()=>{}),Wi['set'](_0x263a03,_0x2774b3),_0x263a03;}function Bc(_0x132f90){if(di['has'](_0x132f90))return;const _0x2ea524=new Promise((_0x29972b,_0x129555)=>{const _0x41090e=()=>{_0x132f90['removeEventListener']('complete',_0x8c3460),_0x132f90['removeEventListener']('error',_0x2c7b16),_0x132f90['removeEventListener']('abort',_0x2c7b16);},_0x8c3460=()=>{_0x29972b(),_0x41090e();},_0x2c7b16=()=>{_0x129555(_0x132f90['error']||new DOMException('AbortError','AbortError')),_0x41090e();};_0x132f90['addEventListener']('complete',_0x8c3460),_0x132f90['addEventListener']('error',_0x2c7b16),_0x132f90['addEventListener']('abort',_0x2c7b16);});di['set'](_0x132f90,_0x2ea524);}let fi={'get'(_0x4aec4e,_0x49891a,_0x34ffa0){if(_0x4aec4e instanceof IDBTransaction){if(_0x49891a==='done')return di['get'](_0x4aec4e);if(_0x49891a==='objectStoreNames')return _0x4aec4e['objectStoreNames']||Xr['get'](_0x4aec4e);if(_0x49891a==='store')return _0x34ffa0['objectStoreNames'][0x1]?void 0x0:_0x34ffa0['objectStore'](_0x34ffa0['objectStoreNames'][0x0]);}return _e(_0x4aec4e[_0x49891a]);},'set'(_0x338f03,_0x283f82,_0x56ed39){return _0x338f03[_0x283f82]=_0x56ed39,!0x0;},'has'(_0x28538e,_0x31689c){return _0x28538e instanceof IDBTransaction&&(_0x31689c==='done'||_0x31689c==='store')?!0x0:_0x31689c in _0x28538e;}};function Vc(_0x2ab734){fi=_0x2ab734(fi);}function Hc(_0x32c3b8){return _0x32c3b8===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x2b37ce,..._0x539c41){const _0x18f4ad=_0x32c3b8['call'](Zn(this),_0x2b37ce,..._0x539c41);return Xr['set'](_0x18f4ad,_0x2b37ce['sort']?_0x2b37ce['sort']():[_0x2b37ce]),_e(_0x18f4ad);}:Uc()['includes'](_0x32c3b8)?function(..._0x2418c4){return _0x32c3b8['apply'](Zn(this),_0x2418c4),_e(Jr['get'](this));}:function(..._0x3551a0){return _e(_0x32c3b8['apply'](Zn(this),_0x3551a0));};}function $c(_0x8b49cc){return typeof _0x8b49cc=='function'?Hc(_0x8b49cc):(_0x8b49cc instanceof IDBTransaction&&Bc(_0x8b49cc),xc(_0x8b49cc,Fc())?new Proxy(_0x8b49cc,fi):_0x8b49cc);}function _e(_0x1a3aa5){if(_0x1a3aa5 instanceof IDBRequest)return Wc(_0x1a3aa5);if(Xn['has'](_0x1a3aa5))return Xn['get'](_0x1a3aa5);const _0x1fdbe2=$c(_0x1a3aa5);return _0x1fdbe2!==_0x1a3aa5&&(Xn['set'](_0x1a3aa5,_0x1fdbe2),Wi['set'](_0x1fdbe2,_0x1a3aa5)),_0x1fdbe2;}const Zn=_0x5691e2=>Wi['get'](_0x5691e2);function Gc(_0x5c8985,_0x40fd3e,{blocked:_0x34345a,upgrade:_0x42b7b8,blocking:_0x366929,terminated:_0x378e5f}={}){const _0x280199=indexedDB['open'](_0x5c8985,_0x40fd3e),_0xcf8b19=_e(_0x280199);return _0x42b7b8&&_0x280199['addEventListener']('upgradeneeded',_0x131e92=>{_0x42b7b8(_e(_0x280199['result']),_0x131e92['oldVersion'],_0x131e92['newVersion'],_e(_0x280199['transaction']),_0x131e92);}),_0x34345a&&_0x280199['addEventListener']('blocked',_0x2cb3f0=>_0x34345a(_0x2cb3f0['oldVersion'],_0x2cb3f0['newVersion'],_0x2cb3f0)),_0xcf8b19['then'](_0x315486=>{_0x378e5f&&_0x315486['addEventListener']('close',()=>_0x378e5f()),_0x366929&&_0x315486['addEventListener']('versionchange',_0x4577c0=>_0x366929(_0x4577c0['oldVersion'],_0x4577c0['newVersion'],_0x4577c0));})['catch'](()=>{}),_0xcf8b19;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x2506fc,_0x1c7d73){if(!(_0x2506fc instanceof IDBDatabase&&!(_0x1c7d73 in _0x2506fc)&&typeof _0x1c7d73=='string'))return;if(ei['get'](_0x1c7d73))return ei['get'](_0x1c7d73);const _0x58fa5c=_0x1c7d73['replace'](/FromIndex$/,''),_0x5aaa86=_0x1c7d73!==_0x58fa5c,_0x3f2e1f=zc['includes'](_0x58fa5c);if(!(_0x58fa5c in(_0x5aaa86?IDBIndex:IDBObjectStore)['prototype'])||!(_0x3f2e1f||qc['includes'](_0x58fa5c)))return;const _0x37e3b3=async function(_0x35539c,..._0x21c995){const _0x3644f0=this['transaction'](_0x35539c,_0x3f2e1f?'readwrite':'readonly');let _0x5cda57=_0x3644f0['store'];return _0x5aaa86&&(_0x5cda57=_0x5cda57['index'](_0x21c995['shift']())),(await Promise['all']([_0x5cda57[_0x58fa5c](..._0x21c995),_0x3f2e1f&&_0x3644f0['done']]))[0x0];};return ei['set'](_0x1c7d73,_0x37e3b3),_0x37e3b3;}Vc(_0xcd9b=>({..._0xcd9b,'get':(_0x39d861,_0x1c1488,_0x4bc875)=>Ls(_0x39d861,_0x1c1488)||_0xcd9b['get'](_0x39d861,_0x1c1488,_0x4bc875),'has':(_0x596301,_0x4d3076)=>!!Ls(_0x596301,_0x4d3076)||_0xcd9b['has'](_0x596301,_0x4d3076)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x4b2c95){this['container']=_0x4b2c95;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x2cec6d=>{if(Kc(_0x2cec6d)){const _0x5d224a=_0x2cec6d['getImmediate']();return _0x5d224a['library']+'/'+_0x5d224a['version'];}else return null;})['filter'](_0x12a129=>_0x12a129)['join']('\x20');}}function Kc(_0x39ff78){const _0x28613b=_0x39ff78['getComponent']();return(_0x28613b==null?void 0x0:_0x28613b['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x37ddbe,_0x2e63e3){try{_0x37ddbe['container']['addComponent'](_0x2e63e3);}catch(_0x426e09){oe['debug']('Component\x20'+_0x2e63e3['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x37ddbe['name'],_0x426e09);}}function Ze(_0x42f893){const _0x15dada=_0x42f893['name'];if(mi['has'](_0x15dada))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x15dada+'.'),!0x1;mi['set'](_0x15dada,_0x42f893);for(const _0x56af9d of xe['values']())Fs(_0x56af9d,_0x42f893);for(const _0x571187 of gi['values']())Fs(_0x571187,_0x42f893);return!0x0;}function Bi(_0x15a175,_0x3960b4){const _0xfd1a77=_0x15a175['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0xfd1a77&&_0xfd1a77['triggerHeartbeat'](),_0x15a175['container']['getProvider'](_0x3960b4);}function $(_0x3f2925){return _0x3f2925==null?!0x1:_0x3f2925['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x443eb0,_0x4b484d,_0x51a391){this['_isDeleted']=!0x1,this['_options']={..._0x443eb0},this['_config']={..._0x4b484d},this['_name']=_0x4b484d['name'],this['_automaticDataCollectionEnabled']=_0x4b484d['automaticDataCollectionEnabled'],this['_container']=_0x51a391,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x225d11){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x225d11;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x4bd5f0){this['_isDeleted']=_0x4bd5f0;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x1fd005,_0x4c5364={}){let _0x239b82=_0x1fd005;typeof _0x4c5364!='object'&&(_0x4c5364={'name':_0x4c5364});const _0x15cee8={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x4c5364},_0x4328e7=_0x15cee8['name'];if(typeof _0x4328e7!='string'||!_0x4328e7)throw ge['create']('bad-app-name',{'appName':String(_0x4328e7)});if(_0x239b82||(_0x239b82=qr()),!_0x239b82)throw ge['create']('no-options');const _0x16de67=xe['get'](_0x4328e7);if(_0x16de67){if(Me(_0x239b82,_0x16de67['options'])&&Me(_0x15cee8,_0x16de67['config']))return _0x16de67;throw ge['create']('duplicate-app',{'appName':_0x4328e7});}const _0x25c1e4=new Pc(_0x4328e7);for(const _0x57251f of mi['values']())_0x25c1e4['addComponent'](_0x57251f);const _0x5c1632=new Tl(_0x239b82,_0x15cee8,_0x25c1e4);return xe['set'](_0x4328e7,_0x5c1632),_0x5c1632;}function Zr(_0x31ab10=_i){const _0x56ea8e=xe['get'](_0x31ab10);if(!_0x56ea8e&&_0x31ab10===_i&&qr())return Sl();if(!_0x56ea8e)throw ge['create']('no-app',{'appName':_0x31ab10});return _0x56ea8e;}function f_(){return Array['from'](xe['values']());}async function p_(_0x2cff38){let _0x3eb2a6=!0x1;const _0x355848=_0x2cff38['name'];xe['has'](_0x355848)?(_0x3eb2a6=!0x0,xe['delete'](_0x355848)):gi['has'](_0x355848)&&_0x2cff38['decRefCount']()<=0x0&&(gi['delete'](_0x355848),_0x3eb2a6=!0x0),_0x3eb2a6&&(await Promise['all'](_0x2cff38['container']['getProviders']()['map'](_0x5ef415=>_0x5ef415['delete']())),_0x2cff38['isDeleted']=!0x0);}function me(_0x44f238,_0x45a19f,_0x4710f2){let _0x1e77f7=wl[_0x44f238]??_0x44f238;_0x4710f2&&(_0x1e77f7+='-'+_0x4710f2);const _0x1893df=_0x1e77f7['match'](/\s|\//),_0x40a0e3=_0x45a19f['match'](/\s|\//);if(_0x1893df||_0x40a0e3){const _0x14c837=['Unable\x20to\x20register\x20library\x20\x22'+_0x1e77f7+'\x22\x20with\x20version\x20\x22'+_0x45a19f+'\x22:'];_0x1893df&&_0x14c837['push']('library\x20name\x20\x22'+_0x1e77f7+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x1893df&&_0x40a0e3&&_0x14c837['push']('and'),_0x40a0e3&&_0x14c837['push']('version\x20name\x20\x22'+_0x45a19f+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x14c837['join']('\x20'));return;}Ze(new Le(_0x1e77f7+'-version',()=>({'library':_0x1e77f7,'version':_0x45a19f}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0xdb66a1,_0x110239)=>{switch(_0x110239){case 0x0:try{_0xdb66a1['createObjectStore'](kt);}catch(_0x27506c){console['warn'](_0x27506c);}}}})['catch'](_0x26d1ec=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x26d1ec['message']});})),ti;}async function Al(_0x37dbd4){try{const _0x2539b7=(await eo())['transaction'](kt),_0x4a7473=await _0x2539b7['objectStore'](kt)['get'](to(_0x37dbd4));return await _0x2539b7['done'],_0x4a7473;}catch(_0x268c8c){if(_0x268c8c instanceof Se)oe['warn'](_0x268c8c['message']);else{const _0x249e72=ge['create']('idb-get',{'originalErrorMessage':_0x268c8c==null?void 0x0:_0x268c8c['message']});oe['warn'](_0x249e72['message']);}}}async function Us(_0xde7ef0,_0x519710){try{const _0x3a9e8a=(await eo())['transaction'](kt,'readwrite');await _0x3a9e8a['objectStore'](kt)['put'](_0x519710,to(_0xde7ef0)),await _0x3a9e8a['done'];}catch(_0x433446){if(_0x433446 instanceof Se)oe['warn'](_0x433446['message']);else{const _0x313e22=ge['create']('idb-set',{'originalErrorMessage':_0x433446==null?void 0x0:_0x433446['message']});oe['warn'](_0x313e22['message']);}}}function to(_0xad7d5e){return _0xad7d5e['name']+'!'+_0xad7d5e['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x4d3294){this['container']=_0x4d3294,this['_heartbeatsCache']=null;const _0x35bec6=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x35bec6),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x34b49b=>(this['_heartbeatsCache']=_0x34b49b,_0x34b49b));}async['triggerHeartbeat'](){var _0x2f77a1,_0x502d4d;try{const _0x28a9a7=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x1efa22=Ws();if(((_0x2f77a1=this['_heartbeatsCache'])==null?void 0x0:_0x2f77a1['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x502d4d=this['_heartbeatsCache'])==null?void 0x0:_0x502d4d['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x1efa22||this['_heartbeatsCache']['heartbeats']['some'](_0x1c564a=>_0x1c564a['date']===_0x1efa22))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x1efa22,'agent':_0x28a9a7}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x3991d0=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x3991d0,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x59806a){oe['warn'](_0x59806a);}}async['getHeartbeatsHeader'](){var _0x1fb272;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x1fb272=this['_heartbeatsCache'])==null?void 0x0:_0x1fb272['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x456f4e=Ws(),{heartbeatsToSend:_0x486020,unsentEntries:_0x1b3688}=Ol(this['_heartbeatsCache']['heartbeats']),_0x3d1015=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x486020}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x456f4e,_0x1b3688['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x1b3688,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x3d1015;}catch(_0x3e25ac){return oe['warn'](_0x3e25ac),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x480e25,_0x2a00e4=kl){const _0x7a0478=[];let _0x37091d=_0x480e25['slice']();for(const _0x3429c8 of _0x480e25){const _0x5273fe=_0x7a0478['find'](_0x3b196e=>_0x3b196e['agent']===_0x3429c8['agent']);if(_0x5273fe){if(_0x5273fe['dates']['push'](_0x3429c8['date']),Bs(_0x7a0478)>_0x2a00e4){_0x5273fe['dates']['pop']();break;}}else{if(_0x7a0478['push']({'agent':_0x3429c8['agent'],'dates':[_0x3429c8['date']]}),Bs(_0x7a0478)>_0x2a00e4){_0x7a0478['pop']();break;}}_0x37091d=_0x37091d['slice'](0x1);}return{'heartbeatsToSend':_0x7a0478,'unsentEntries':_0x37091d};}class Dl{constructor(_0x563aac){this['app']=_0x563aac,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x221dfc=await Al(this['app']);return _0x221dfc!=null&&_0x221dfc['heartbeats']?_0x221dfc:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x1d99ca){if(await this['_canUseIndexedDBPromise']){const _0xf8d913=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x1d99ca['lastSentHeartbeatDate']??_0xf8d913['lastSentHeartbeatDate'],'heartbeats':_0x1d99ca['heartbeats']});}else return;}async['add'](_0x4ef640){if(await this['_canUseIndexedDBPromise']){const _0x101014=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x4ef640['lastSentHeartbeatDate']??_0x101014['lastSentHeartbeatDate'],'heartbeats':[..._0x101014['heartbeats'],..._0x4ef640['heartbeats']]});}else return;}}function Bs(_0x29359a){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x29359a}))['length'];}function Ml(_0xffd3ad){if(_0xffd3ad['length']===0x0)return-0x1;let _0x3efa6b=0x0,_0x2a7c04=_0xffd3ad[0x0]['date'];for(let _0x135a0b=0x1;_0x135a0b<_0xffd3ad['length'];_0x135a0b++)_0xffd3ad[_0x135a0b]['date']<_0x2a7c04&&(_0x2a7c04=_0xffd3ad[_0x135a0b]['date'],_0x3efa6b=_0x135a0b);return _0x3efa6b;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x3729e7){Ze(new Le('platform-logger',_0x15c803=>new jc(_0x15c803),'PRIVATE')),Ze(new Le('heartbeat',_0x15412a=>new Pl(_0x15412a),'PRIVATE')),me(pi,xs,_0x3729e7),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x72b0a7){no=_0x72b0a7;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x1bff71){this['domStorage_']=_0x1bff71,this['prefix_']='firebase:';}['set'](_0x3cecbd,_0x36b12a){_0x36b12a==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x3cecbd)):this['domStorage_']['setItem'](this['prefixedName_'](_0x3cecbd),O(_0x36b12a));}['get'](_0x5347ce){const _0x49f954=this['domStorage_']['getItem'](this['prefixedName_'](_0x5347ce));return _0x49f954==null?null:At(_0x49f954);}['remove'](_0x4af306){this['domStorage_']['removeItem'](this['prefixedName_'](_0x4af306));}['prefixedName_'](_0x202684){return this['prefix_']+_0x202684;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x1f095c,_0x2414a9){_0x2414a9==null?delete this['cache_'][_0x1f095c]:this['cache_'][_0x1f095c]=_0x2414a9;}['get'](_0x58c2cc){return J(this['cache_'],_0x58c2cc)?this['cache_'][_0x58c2cc]:null;}['remove'](_0x343725){delete this['cache_'][_0x343725];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x5b782d){try{if(typeof window<'u'&&typeof window[_0x5b782d]<'u'){const _0x2ef73e=window[_0x5b782d];return _0x2ef73e['setItem']('firebase:sentinel','cache'),_0x2ef73e['removeItem']('firebase:sentinel'),new Wl(_0x2ef73e);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x41cde0=0x1;return function(){return _0x41cde0++;};}()),ro=function(_0xc736f9){const _0x4ff900=Rc(_0xc736f9),_0x23aa43=new Cc();_0x23aa43['update'](_0x4ff900);const _0x52ccba=_0x23aa43['digest']();return Li['encodeByteArray'](_0x52ccba);},Vt=function(..._0x3068c0){let _0x5c0a20='';for(let _0x2a8f93=0x0;_0x2a8f93<_0x3068c0['length'];_0x2a8f93++){const _0x3fd785=_0x3068c0[_0x2a8f93];Array['isArray'](_0x3fd785)||_0x3fd785&&typeof _0x3fd785=='object'&&typeof _0x3fd785['length']=='number'?_0x5c0a20+=Vt['apply'](null,_0x3fd785):typeof _0x3fd785=='object'?_0x5c0a20+=O(_0x3fd785):_0x5c0a20+=_0x3fd785,_0x5c0a20+='\x20';}return _0x5c0a20;};let wt=null,Gs=!0x0;const Hl=function(_0xe654a2,_0x3cc12f){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x1f017b){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x5cc2fe=Vt['apply'](null,_0x1f017b);wt(_0x5cc2fe);}},Ht=function(_0x2ba554){return function(..._0x4682c2){L(_0x2ba554,..._0x4682c2);};},yi=function(..._0x3ed281){const _0x51c96b='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x3ed281);Ye['error'](_0x51c96b);},ae=function(..._0xf5e3e2){const _0x4aa542='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0xf5e3e2);throw Ye['error'](_0x4aa542),new Error(_0x4aa542);},U=function(..._0x56a287){const _0x565117='FIREBASE\x20WARNING:\x20'+Vt(..._0x56a287);Ye['warn'](_0x565117);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x4bdd52){return typeof _0x4bdd52=='number'&&(_0x4bdd52!==_0x4bdd52||_0x4bdd52===Number['POSITIVE_INFINITY']||_0x4bdd52===Number['NEGATIVE_INFINITY']);},Gl=function(_0x2d5842){if(document['readyState']==='complete')_0x2d5842();else{let _0x33d67b=!0x1;const _0x55d1ba=function(){if(!document['body']){setTimeout(_0x55d1ba,Math['floor'](0xa));return;}_0x33d67b||(_0x33d67b=!0x0,_0x2d5842());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x55d1ba,!0x1),window['addEventListener']('load',_0x55d1ba,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x55d1ba();}),window['attachEvent']('onload',_0x55d1ba));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x407ad7,_0x11f2b1){if(_0x407ad7===_0x11f2b1)return 0x0;if(_0x407ad7===Fe||_0x11f2b1===Ie)return-0x1;if(_0x11f2b1===Fe||_0x407ad7===Ie)return 0x1;{const _0x200600=qs(_0x407ad7),_0x225e7c=qs(_0x11f2b1);return _0x200600!==null?_0x225e7c!==null?_0x200600-_0x225e7c===0x0?_0x407ad7['length']-_0x11f2b1['length']:_0x200600-_0x225e7c:-0x1:_0x225e7c!==null?0x1:_0x407ad7<_0x11f2b1?-0x1:0x1;}},ql=function(_0x38b847,_0x2160d8){return _0x38b847===_0x2160d8?0x0:_0x38b847<_0x2160d8?-0x1:0x1;},_t=function(_0x3f97e3,_0x3ab5ac){if(_0x3ab5ac&&_0x3f97e3 in _0x3ab5ac)return _0x3ab5ac[_0x3f97e3];throw new Error('Missing\x20required\x20key\x20('+_0x3f97e3+')\x20in\x20object:\x20'+O(_0x3ab5ac));},Hi=function(_0x3633dd){if(typeof _0x3633dd!='object'||_0x3633dd===null)return O(_0x3633dd);const _0x59a0f7=[];for(const _0x3f4504 in _0x3633dd)_0x59a0f7['push'](_0x3f4504);_0x59a0f7['sort']();let _0x497e18='{';for(let _0x22ea38=0x0;_0x22ea38<_0x59a0f7['length'];_0x22ea38++)_0x22ea38!==0x0&&(_0x497e18+=','),_0x497e18+=O(_0x59a0f7[_0x22ea38]),_0x497e18+=':',_0x497e18+=Hi(_0x3633dd[_0x59a0f7[_0x22ea38]]);return _0x497e18+='}',_0x497e18;},oo=function(_0x5c6545,_0x32b160){const _0x42138a=_0x5c6545['length'];if(_0x42138a<=_0x32b160)return[_0x5c6545];const _0x54f3d3=[];for(let _0x2496b1=0x0;_0x2496b1<_0x42138a;_0x2496b1+=_0x32b160)_0x2496b1+_0x32b160>_0x42138a?_0x54f3d3['push'](_0x5c6545['substring'](_0x2496b1,_0x42138a)):_0x54f3d3['push'](_0x5c6545['substring'](_0x2496b1,_0x2496b1+_0x32b160));return _0x54f3d3;};function x(_0xed6496,_0x311134){for(const _0x49a406 in _0xed6496)_0xed6496['hasOwnProperty'](_0x49a406)&&_0x311134(_0x49a406,_0xed6496[_0x49a406]);}const ao=function(_0x3cf5a0){f(!Vi(_0x3cf5a0),'Invalid\x20JSON\x20number');const _0x27c83f=0xb,_0x3d6dbc=0x34,_0x1a9862=(0x1<<_0x27c83f-0x1)-0x1;let _0x1a323b,_0x3e120e,_0x328cc7,_0x412d5b,_0x47606f;_0x3cf5a0===0x0?(_0x3e120e=0x0,_0x328cc7=0x0,_0x1a323b=0x1/_0x3cf5a0===-0x1/0x0?0x1:0x0):(_0x1a323b=_0x3cf5a0<0x0,_0x3cf5a0=Math['abs'](_0x3cf5a0),_0x3cf5a0>=Math['pow'](0x2,0x1-_0x1a9862)?(_0x412d5b=Math['min'](Math['floor'](Math['log'](_0x3cf5a0)/Math['LN2']),_0x1a9862),_0x3e120e=_0x412d5b+_0x1a9862,_0x328cc7=Math['round'](_0x3cf5a0*Math['pow'](0x2,_0x3d6dbc-_0x412d5b)-Math['pow'](0x2,_0x3d6dbc))):(_0x3e120e=0x0,_0x328cc7=Math['round'](_0x3cf5a0/Math['pow'](0x2,0x1-_0x1a9862-_0x3d6dbc))));const _0x2a9fca=[];for(_0x47606f=_0x3d6dbc;_0x47606f;_0x47606f-=0x1)_0x2a9fca['push'](_0x328cc7%0x2?0x1:0x0),_0x328cc7=Math['floor'](_0x328cc7/0x2);for(_0x47606f=_0x27c83f;_0x47606f;_0x47606f-=0x1)_0x2a9fca['push'](_0x3e120e%0x2?0x1:0x0),_0x3e120e=Math['floor'](_0x3e120e/0x2);_0x2a9fca['push'](_0x1a323b?0x1:0x0),_0x2a9fca['reverse']();const _0x5a755c=_0x2a9fca['join']('');let _0x30cf2a='';for(_0x47606f=0x0;_0x47606f<0x40;_0x47606f+=0x8){let _0xb812e0=parseInt(_0x5a755c['substr'](_0x47606f,0x8),0x2)['toString'](0x10);_0xb812e0['length']===0x1&&(_0xb812e0='0'+_0xb812e0),_0x30cf2a=_0x30cf2a+_0xb812e0;}return _0x30cf2a['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x2c777c,_0x56d498){let _0x2fdad5='Unknown\x20Error';_0x2c777c==='too_big'?_0x2fdad5='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x2c777c==='permission_denied'?_0x2fdad5='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x2c777c==='unavailable'&&(_0x2fdad5='The\x20service\x20is\x20unavailable');const _0x19bc4f=new Error(_0x2c777c+'\x20at\x20'+_0x56d498['_path']['toString']()+':\x20'+_0x2fdad5);return _0x19bc4f['code']=_0x2c777c['toUpperCase'](),_0x19bc4f;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x49a2ff){if(Yl['test'](_0x49a2ff)){const _0x5272ed=Number(_0x49a2ff);if(_0x5272ed>=Ql&&_0x5272ed<=Jl)return _0x5272ed;}return null;},ht=function(_0x40d1b3){try{_0x40d1b3();}catch(_0x20668c){setTimeout(()=>{const _0x4524c2=_0x20668c['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x4524c2),_0x20668c;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x279586,_0x9e16e){const _0x3a423d=setTimeout(_0x279586,_0x9e16e);return typeof _0x3a423d=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x3a423d):typeof _0x3a423d=='object'&&_0x3a423d['unref']&&_0x3a423d['unref'](),_0x3a423d;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x2934a1,_0x212949){this['appCheckProvider']=_0x212949,this['appName']=_0x2934a1['name'],$(_0x2934a1)&&_0x2934a1['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x2934a1['settings']['appCheckToken']),this['appCheck']=_0x212949==null?void 0x0:_0x212949['getImmediate']({'optional':!0x0}),this['appCheck']||_0x212949==null||_0x212949['get']()['then'](_0x23b77f=>this['appCheck']=_0x23b77f);}['getToken'](_0x2160b9){if(this['serverAppAppCheckToken']){if(_0x2160b9)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x2160b9):new Promise((_0x297683,_0x4f095f)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x2160b9)['then'](_0x297683,_0x4f095f):_0x297683(null);},0x0);});}['addTokenChangeListener'](_0x31eabc){var _0xc0b7c0;(_0xc0b7c0=this['appCheckProvider'])==null||_0xc0b7c0['get']()['then'](_0x36fb60=>_0x36fb60['addTokenListener'](_0x31eabc));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x58846c,_0x3a9e84,_0x1fca8f){this['appName_']=_0x58846c,this['firebaseOptions_']=_0x3a9e84,this['authProvider_']=_0x1fca8f,this['auth_']=null,this['auth_']=_0x1fca8f['getImmediate']({'optional':!0x0}),this['auth_']||_0x1fca8f['onInit'](_0x426833=>this['auth_']=_0x426833);}['getToken'](_0x281aee){return this['auth_']?this['auth_']['getToken'](_0x281aee)['catch'](_0x8a846d=>_0x8a846d&&_0x8a846d['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x8a846d)):new Promise((_0x5f2581,_0x61292a)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x281aee)['then'](_0x5f2581,_0x61292a):_0x5f2581(null);},0x0);});}['addTokenChangeListener'](_0x1b25d6){this['auth_']?this['auth_']['addAuthTokenListener'](_0x1b25d6):this['authProvider_']['get']()['then'](_0x917632=>_0x917632['addAuthTokenListener'](_0x1b25d6));}['removeTokenChangeListener'](_0x4fdb86){this['authProvider_']['get']()['then'](_0x3f42fa=>_0x3f42fa['removeAuthTokenListener'](_0x4fdb86));}['notifyForInvalidToken'](){let _0x4d95b0='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x4d95b0+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x4d95b0+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x4d95b0+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x4d95b0);}}class nn{constructor(_0x201518){this['accessToken']=_0x201518;}['getToken'](_0x4cb09b){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x6d54bf){_0x6d54bf(this['accessToken']);}['removeTokenChangeListener'](_0x44e2bf){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x344a8f,_0x5d0f9c,_0xd59c18,_0x1621fe,_0x527700=!0x1,_0x32160d='',_0x26647a=!0x1,_0x5500a4=!0x1,_0x2d9543=null){this['secure']=_0x5d0f9c,this['namespace']=_0xd59c18,this['webSocketOnly']=_0x1621fe,this['nodeAdmin']=_0x527700,this['persistenceKey']=_0x32160d,this['includeNamespaceInQueryParams']=_0x26647a,this['isUsingEmulator']=_0x5500a4,this['emulatorOptions']=_0x2d9543,this['_host']=_0x344a8f['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x344a8f)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x573124){_0x573124!==this['internalHost']&&(this['internalHost']=_0x573124,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x1f40ef=this['toURLString']();return this['persistenceKey']&&(_0x1f40ef+='<'+this['persistenceKey']+'>'),_0x1f40ef;}['toURLString'](){const _0x376bb4=this['secure']?'https://':'http://',_0x533928=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x376bb4+this['host']+'/'+_0x533928;}}function th(_0x2451d6){return _0x2451d6['host']!==_0x2451d6['internalHost']||_0x2451d6['isCustomHost']()||_0x2451d6['includeNamespaceInQueryParams'];}function vo(_0x28057c,_0x4edb23,_0x3bca43){f(typeof _0x4edb23=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x3bca43=='object','typeof\x20params\x20must\x20==\x20object');let _0x210155;if(_0x4edb23===go)_0x210155=(_0x28057c['secure']?'wss://':'ws://')+_0x28057c['internalHost']+'/.ws?';else{if(_0x4edb23===mo)_0x210155=(_0x28057c['secure']?'https://':'http://')+_0x28057c['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x4edb23);}th(_0x28057c)&&(_0x3bca43['ns']=_0x28057c['namespace']);const _0x366eef=[];return x(_0x3bca43,(_0x5d033e,_0x1e0966)=>{_0x366eef['push'](_0x5d033e+'='+_0x1e0966);}),_0x210155+_0x366eef['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x48baa6,_0xf652cd=0x1){J(this['counters_'],_0x48baa6)||(this['counters_'][_0x48baa6]=0x0),this['counters_'][_0x48baa6]+=_0xf652cd;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x144a32){const _0x2f70d9=_0x144a32['toString']();return ni[_0x2f70d9]||(ni[_0x2f70d9]=new nh()),ni[_0x2f70d9];}function ih(_0x133933,_0x4c53ac){const _0x2aba16=_0x133933['toString']();return ii[_0x2aba16]||(ii[_0x2aba16]=_0x4c53ac()),ii[_0x2aba16];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x48c171){this['onMessage_']=_0x48c171,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x1f4546,_0x23a48a){this['closeAfterResponse']=_0x1f4546,this['onClose']=_0x23a48a,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x3e6e36,_0x5465b6){for(this['pendingResponses'][_0x3e6e36]=_0x5465b6;this['pendingResponses'][this['currentResponseNum']];){const _0x184227=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x51028e=0x0;_0x51028e<_0x184227['length'];++_0x51028e)_0x184227[_0x51028e]&&ht(()=>{this['onMessage_'](_0x184227[_0x51028e]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x11b57a,_0x6b4950,_0x3b5ef3,_0x25afba,_0x1e141f,_0x365397,_0x290a12){this['connId']=_0x11b57a,this['repoInfo']=_0x6b4950,this['applicationId']=_0x3b5ef3,this['appCheckToken']=_0x25afba,this['authToken']=_0x1e141f,this['transportSessionId']=_0x365397,this['lastSessionId']=_0x290a12,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x11b57a),this['stats_']=Gi(_0x6b4950),this['urlFn']=_0x153c15=>(this['appCheckToken']&&(_0x153c15[vi]=this['appCheckToken']),vo(_0x6b4950,mo,_0x153c15));}['open'](_0x1e10b5,_0x55210d){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x55210d,this['myPacketOrderer']=new sh(_0x1e10b5),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x4d099e)=>{const [_0x227683,_0x4f512e,_0x38af62,_0x5d1c06,_0x3e5b12]=_0x4d099e;if(this['incrementIncomingBytes_'](_0x4d099e),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x227683===zs)this['id']=_0x4f512e,this['password']=_0x38af62;else{if(_0x227683===rh)_0x4f512e?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x4f512e,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x227683);}}},(..._0x4b8ebc)=>{const [_0x3e9fd7,_0x79429f]=_0x4b8ebc;this['incrementIncomingBytes_'](_0x4b8ebc),this['myPacketOrderer']['handleResponse'](_0x3e9fd7,_0x79429f);},()=>{this['onClosed_']();},this['urlFn']);const _0x4e6de0={};_0x4e6de0[zs]='t',_0x4e6de0[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x4e6de0[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x4e6de0[co]=$i,this['transportSessionId']&&(_0x4e6de0[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x4e6de0[po]=this['lastSessionId']),this['applicationId']&&(_0x4e6de0[_o]=this['applicationId']),this['appCheckToken']&&(_0x4e6de0[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x4e6de0[ho]=uo);const _0x59134a=this['urlFn'](_0x4e6de0);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x59134a),this['scriptTagHolder']['addTag'](_0x59134a,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x482543){const _0x199611=O(_0x482543);this['bytesSent']+=_0x199611['length'],this['stats_']['incrementCounter']('bytes_sent',_0x199611['length']);const _0x2c7c74=Hr(_0x199611),_0x1819d2=oo(_0x2c7c74,fh);for(let _0x5c038c=0x0;_0x5c038c<_0x1819d2['length'];_0x5c038c++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x1819d2['length'],_0x1819d2[_0x5c038c]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x2dbc81,_0x6e5976){this['myDisconnFrame']=document['createElement']('iframe');const _0x1c1c0d={};_0x1c1c0d[dh]='t',_0x1c1c0d[Eo]=_0x2dbc81,_0x1c1c0d[Io]=_0x6e5976,this['myDisconnFrame']['src']=this['urlFn'](_0x1c1c0d),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x5a7e0e){const _0x2ee9d6=O(_0x5a7e0e)['length'];this['bytesReceived']+=_0x2ee9d6,this['stats_']['incrementCounter']('bytes_received',_0x2ee9d6);}}class qi{constructor(_0x174828,_0x11ee0c,_0x386c69,_0x4a4bbb){this['onDisconnect']=_0x386c69,this['urlFn']=_0x4a4bbb,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x174828,window[ah+this['uniqueCallbackIdentifier']]=_0x11ee0c,this['myIFrame']=qi['createIFrame_']();let _0x7061c3='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x7061c3='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x5c47f2='<html><body>'+_0x7061c3+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x5c47f2),this['myIFrame']['doc']['close']();}catch(_0x2084ca){L('frame\x20writing\x20exception'),_0x2084ca['stack']&&L(_0x2084ca['stack']),L(_0x2084ca);}}}static['createIFrame_'](){const _0x50b7c0=document['createElement']('iframe');if(_0x50b7c0['style']['display']='none',document['body']){document['body']['appendChild'](_0x50b7c0);try{_0x50b7c0['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x353bec=document['domain'];_0x50b7c0['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x353bec+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x50b7c0['contentDocument']?_0x50b7c0['doc']=_0x50b7c0['contentDocument']:_0x50b7c0['contentWindow']?_0x50b7c0['doc']=_0x50b7c0['contentWindow']['document']:_0x50b7c0['document']&&(_0x50b7c0['doc']=_0x50b7c0['document']),_0x50b7c0;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x26dbc4=this['onDisconnect'];_0x26dbc4&&(this['onDisconnect']=null,_0x26dbc4());}['startLongPoll'](_0x4a7890,_0x51ebd9){for(this['myID']=_0x4a7890,this['myPW']=_0x51ebd9,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x34ccd4={};_0x34ccd4[Eo]=this['myID'],_0x34ccd4[Io]=this['myPW'],_0x34ccd4[wo]=this['currentSerial'];let _0x4f9352=this['urlFn'](_0x34ccd4),_0x1f31dc='',_0x23845b=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x1f31dc['length']<=Co;){const _0xb24c5d=this['pendingSegs']['shift']();_0x1f31dc=_0x1f31dc+'&'+lh+_0x23845b+'='+_0xb24c5d['seg']+'&'+hh+_0x23845b+'='+_0xb24c5d['ts']+'&'+uh+_0x23845b+'='+_0xb24c5d['d'],_0x23845b++;}return _0x4f9352=_0x4f9352+_0x1f31dc,this['addLongPollTag_'](_0x4f9352,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x5ab0ca,_0x3f6d8f,_0x526119){this['pendingSegs']['push']({'seg':_0x5ab0ca,'ts':_0x3f6d8f,'d':_0x526119}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x2cce16,_0x47bcac){this['outstandingRequests']['add'](_0x47bcac);const _0x153c0d=()=>{this['outstandingRequests']['delete'](_0x47bcac),this['newRequest_']();},_0x40e5c7=setTimeout(_0x153c0d,Math['floor'](ph)),_0x2e82e0=()=>{clearTimeout(_0x40e5c7),_0x153c0d();};this['addTag'](_0x2cce16,_0x2e82e0);}['addTag'](_0x44a5c3,_0x36f9b3){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x515f38=this['myIFrame']['doc']['createElement']('script');_0x515f38['type']='text/javascript',_0x515f38['async']=!0x0,_0x515f38['src']=_0x44a5c3,_0x515f38['onload']=_0x515f38['onreadystatechange']=function(){const _0x5359f5=_0x515f38['readyState'];(!_0x5359f5||_0x5359f5==='loaded'||_0x5359f5==='complete')&&(_0x515f38['onload']=_0x515f38['onreadystatechange']=null,_0x515f38['parentNode']&&_0x515f38['parentNode']['removeChild'](_0x515f38),_0x36f9b3());},_0x515f38['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x44a5c3),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x515f38);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x4c9928,_0x2a6097,_0xa50975,_0xdbd857,_0x4836a9,_0x3db345,_0x339176){this['connId']=_0x4c9928,this['applicationId']=_0xa50975,this['appCheckToken']=_0xdbd857,this['authToken']=_0x4836a9,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x2a6097),this['connURL']=z['connectionURL_'](_0x2a6097,_0x3db345,_0x339176,_0xdbd857,_0xa50975),this['nodeAdmin']=_0x2a6097['nodeAdmin'];}static['connectionURL_'](_0x5f0a65,_0x5cc84c,_0x4fbf8b,_0x12b40b,_0x3a8b60){const _0xcfdf5b={};return _0xcfdf5b[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0xcfdf5b[ho]=uo),_0x5cc84c&&(_0xcfdf5b[lo]=_0x5cc84c),_0x4fbf8b&&(_0xcfdf5b[po]=_0x4fbf8b),_0x12b40b&&(_0xcfdf5b[vi]=_0x12b40b),_0x3a8b60&&(_0xcfdf5b[_o]=_0x3a8b60),vo(_0x5f0a65,go,_0xcfdf5b);}['open'](_0x57e3c9,_0x29598f){this['onDisconnect']=_0x29598f,this['onMessage']=_0x57e3c9,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x17f71c;_c(),this['mySock']=new un(this['connURL'],[],_0x17f71c);}catch(_0x52160e){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x5bb4ab=_0x52160e['message']||_0x52160e['data'];_0x5bb4ab&&this['log_'](_0x5bb4ab),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x10ef9f=>{this['handleIncomingFrame'](_0x10ef9f);},this['mySock']['onerror']=_0x58f734=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x230c03=_0x58f734['message']||_0x58f734['data'];_0x230c03&&this['log_'](_0x230c03),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x41bfef=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x2933d9=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x48f521=navigator['userAgent']['match'](_0x2933d9);_0x48f521&&_0x48f521['length']>0x1&&parseFloat(_0x48f521[0x1])<4.4&&(_0x41bfef=!0x0);}return!_0x41bfef&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x5e318e){if(this['frames']['push'](_0x5e318e),this['frames']['length']===this['totalFrames']){const _0x4d1940=this['frames']['join']('');this['frames']=null;const _0x4b2f56=At(_0x4d1940);this['onMessage'](_0x4b2f56);}}['handleNewFrameCount_'](_0x30372a){this['totalFrames']=_0x30372a,this['frames']=[];}['extractFrameCount_'](_0xa6fef5){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0xa6fef5['length']<=0x6){const _0x3e02b2=Number(_0xa6fef5);if(!isNaN(_0x3e02b2))return this['handleNewFrameCount_'](_0x3e02b2),null;}return this['handleNewFrameCount_'](0x1),_0xa6fef5;}['handleIncomingFrame'](_0x3c225b){if(this['mySock']===null)return;const _0x4c8e59=_0x3c225b['data'];if(this['bytesReceived']+=_0x4c8e59['length'],this['stats_']['incrementCounter']('bytes_received',_0x4c8e59['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x4c8e59);else{const _0xa8a7ca=this['extractFrameCount_'](_0x4c8e59);_0xa8a7ca!==null&&this['appendFrame_'](_0xa8a7ca);}}['send'](_0x49b7d5){this['resetKeepAlive']();const _0x7f1b4c=O(_0x49b7d5);this['bytesSent']+=_0x7f1b4c['length'],this['stats_']['incrementCounter']('bytes_sent',_0x7f1b4c['length']);const _0x2c472e=oo(_0x7f1b4c,gh);_0x2c472e['length']>0x1&&this['sendString_'](String(_0x2c472e['length']));for(let _0x7ed578=0x0;_0x7ed578<_0x2c472e['length'];_0x7ed578++)this['sendString_'](_0x2c472e[_0x7ed578]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x5bd4b9){try{this['mySock']['send'](_0x5bd4b9);}catch(_0x8a17d2){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x8a17d2['message']||_0x8a17d2['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x35a803){this['initTransports_'](_0x35a803);}['initTransports_'](_0x4eea24){const _0x4c3e14=z&&z['isAvailable']();let _0x5dc7cb=_0x4c3e14&&!z['previouslyFailed']();if(_0x4eea24['webSocketOnly']&&(_0x4c3e14||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x5dc7cb=!0x0),_0x5dc7cb)this['transports_']=[z];else{const _0x2bd648=this['transports_']=[];for(const _0x4e6bc5 of Nt['ALL_TRANSPORTS'])_0x4e6bc5&&_0x4e6bc5['isAvailable']()&&_0x2bd648['push'](_0x4e6bc5);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x346132,_0x5f2cbc,_0x5bb04b,_0x53fd5b,_0x577dbf,_0xcce2ac,_0x5474d2,_0x5308d5,_0x2c1895,_0x1aeff3){this['id']=_0x346132,this['repoInfo_']=_0x5f2cbc,this['applicationId_']=_0x5bb04b,this['appCheckToken_']=_0x53fd5b,this['authToken_']=_0x577dbf,this['onMessage_']=_0xcce2ac,this['onReady_']=_0x5474d2,this['onDisconnect_']=_0x5308d5,this['onKill_']=_0x2c1895,this['lastSessionId']=_0x1aeff3,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x5f2cbc),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x378f41=this['transportManager_']['initialTransport']();this['conn_']=new _0x378f41(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x378f41['responsesRequiredToBeHealthy']||0x0;const _0x4515b5=this['connReceiver_'](this['conn_']),_0x174e5=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x4515b5,_0x174e5);},Math['floor'](0x0));const _0x1e7af8=_0x378f41['healthyTimeout']||0x0;_0x1e7af8>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x1e7af8)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x3af6e1){return _0x254960=>{_0x3af6e1===this['conn_']?this['onConnectionLost_'](_0x254960):_0x3af6e1===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x44cbd9){return _0x36c355=>{this['state_']!==0x2&&(_0x44cbd9===this['rx_']?this['onPrimaryMessageReceived_'](_0x36c355):_0x44cbd9===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x36c355):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x3ba96b){const _0x584b02={'t':'d','d':_0x3ba96b};this['sendData_'](_0x584b02);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x48f158){if(si in _0x48f158){const _0x754614=_0x48f158[si];_0x754614===Qs?this['upgradeIfSecondaryHealthy_']():_0x754614===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x754614===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x5c54fd){const _0x3faccd=_t('t',_0x5c54fd),_0x1425b9=_t('d',_0x5c54fd);if(_0x3faccd==='c')this['onSecondaryControl_'](_0x1425b9);else{if(_0x3faccd==='d')this['pendingDataMessages']['push'](_0x1425b9);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x3faccd);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x28e7fa){const _0x5aad43=_t('t',_0x28e7fa),_0x1a3d34=_t('d',_0x28e7fa);_0x5aad43==='c'?this['onControl_'](_0x1a3d34):_0x5aad43==='d'&&this['onDataMessage_'](_0x1a3d34);}['onDataMessage_'](_0x38a8c1){this['onPrimaryResponse_'](),this['onMessage_'](_0x38a8c1);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x49beba){const _0x2d6004=_t(si,_0x49beba);if(js in _0x49beba){const _0xf4cdd4=_0x49beba[js];if(_0x2d6004===Th){const _0x13ffee={..._0xf4cdd4};this['repoInfo_']['isUsingEmulator']&&(_0x13ffee['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x13ffee);}else{if(_0x2d6004===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x199af6=0x0;_0x199af6<this['pendingDataMessages']['length'];++_0x199af6)this['onDataMessage_'](this['pendingDataMessages'][_0x199af6]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x2d6004===wh?this['onConnectionShutdown_'](_0xf4cdd4):_0x2d6004===Ks?this['onReset_'](_0xf4cdd4):_0x2d6004===Ch?yi('Server\x20Error:\x20'+_0xf4cdd4):_0x2d6004===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x2d6004);}}}['onHandshake_'](_0x1d28e5){const _0xfb00cf=_0x1d28e5['ts'],_0x246161=_0x1d28e5['v'],_0xa0c0b7=_0x1d28e5['h'];this['sessionId']=_0x1d28e5['s'],this['repoInfo_']['host']=_0xa0c0b7,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0xfb00cf),$i!==_0x246161&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x4c4bc3=this['transportManager_']['upgradeTransport']();_0x4c4bc3&&this['startUpgrade_'](_0x4c4bc3);}['startUpgrade_'](_0xc12192){this['secondaryConn_']=new _0xc12192(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0xc12192['responsesRequiredToBeHealthy']||0x0;const _0x9f0a07=this['connReceiver_'](this['secondaryConn_']),_0x3ddb87=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x9f0a07,_0x3ddb87),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x1b4977){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x1b4977),this['repoInfo_']['host']=_0x1b4977,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x3b982a,_0x13c7d6){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x3b982a,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x13c7d6,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x1a4b52=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x1a4b52||this['rx_']===_0x1a4b52)&&this['close']();}['onConnectionLost_'](_0x54cfeb){this['conn_']=null,!_0x54cfeb&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x34f72f){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x34f72f),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x4b9626){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x4b9626);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x2583d8,_0x234277,_0x418556,_0x15a16f){}['merge'](_0x39c75a,_0xf6a321,_0x1777e0,_0x17ea13){}['refreshAuthToken'](_0x53e72a){}['refreshAppCheckToken'](_0x1a3a9f){}['onDisconnectPut'](_0x3d625,_0x132c43,_0x52a664){}['onDisconnectMerge'](_0xdc3e2b,_0x4a6c2e,_0x48adb7){}['onDisconnectCancel'](_0x39761e,_0x15a251){}['reportStats'](_0x5609e3){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x13dddb){this['allowedEvents_']=_0x13dddb,this['listeners_']={},f(Array['isArray'](_0x13dddb)&&_0x13dddb['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x29e5fd,..._0xdc70eb){if(Array['isArray'](this['listeners_'][_0x29e5fd])){const _0x33d828=[...this['listeners_'][_0x29e5fd]];for(let _0x149d0d=0x0;_0x149d0d<_0x33d828['length'];_0x149d0d++)_0x33d828[_0x149d0d]['callback']['apply'](_0x33d828[_0x149d0d]['context'],_0xdc70eb);}}['on'](_0x327451,_0xcf5be3,_0x63ae25){this['validateEventType_'](_0x327451),this['listeners_'][_0x327451]=this['listeners_'][_0x327451]||[],this['listeners_'][_0x327451]['push']({'callback':_0xcf5be3,'context':_0x63ae25});const _0x418b3e=this['getInitialEvent'](_0x327451);_0x418b3e&&_0xcf5be3['apply'](_0x63ae25,_0x418b3e);}['off'](_0x3df34b,_0xc9244a,_0x2df053){this['validateEventType_'](_0x3df34b);const _0x8ef4f0=this['listeners_'][_0x3df34b]||[];for(let _0x41873d=0x0;_0x41873d<_0x8ef4f0['length'];_0x41873d++)if(_0x8ef4f0[_0x41873d]['callback']===_0xc9244a&&(!_0x2df053||_0x2df053===_0x8ef4f0[_0x41873d]['context'])){_0x8ef4f0['splice'](_0x41873d,0x1);return;}}['validateEventType_'](_0x18b609){f(this['allowedEvents_']['find'](_0x5ec2e5=>_0x5ec2e5===_0x18b609),'Unknown\x20event:\x20'+_0x18b609);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x2aa5a2){return f(_0x2aa5a2==='online','Unknown\x20event\x20type:\x20'+_0x2aa5a2),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x3ee4be,_0x14ec98){if(_0x14ec98===void 0x0){this['pieces_']=_0x3ee4be['split']('/');let _0x5e56e6=0x0;for(let _0x158621=0x0;_0x158621<this['pieces_']['length'];_0x158621++)this['pieces_'][_0x158621]['length']>0x0&&(this['pieces_'][_0x5e56e6]=this['pieces_'][_0x158621],_0x5e56e6++);this['pieces_']['length']=_0x5e56e6,this['pieceNum_']=0x0;}else this['pieces_']=_0x3ee4be,this['pieceNum_']=_0x14ec98;}['toString'](){let _0x24bed0='';for(let _0x40729f=this['pieceNum_'];_0x40729f<this['pieces_']['length'];_0x40729f++)this['pieces_'][_0x40729f]!==''&&(_0x24bed0+='/'+this['pieces_'][_0x40729f]);return _0x24bed0||'/';}}function w(){return new C('');}function y(_0x4d09b6){return _0x4d09b6['pieceNum_']>=_0x4d09b6['pieces_']['length']?null:_0x4d09b6['pieces_'][_0x4d09b6['pieceNum_']];}function we(_0x35d067){return _0x35d067['pieces_']['length']-_0x35d067['pieceNum_'];}function b(_0x5517de){let _0x613936=_0x5517de['pieceNum_'];return _0x613936<_0x5517de['pieces_']['length']&&_0x613936++,new C(_0x5517de['pieces_'],_0x613936);}function zi(_0x550bb2){return _0x550bb2['pieceNum_']<_0x550bb2['pieces_']['length']?_0x550bb2['pieces_'][_0x550bb2['pieces_']['length']-0x1]:null;}function bh(_0x28907b){let _0x46b573='';for(let _0x3e5428=_0x28907b['pieceNum_'];_0x3e5428<_0x28907b['pieces_']['length'];_0x3e5428++)_0x28907b['pieces_'][_0x3e5428]!==''&&(_0x46b573+='/'+encodeURIComponent(String(_0x28907b['pieces_'][_0x3e5428])));return _0x46b573||'/';}function Pt(_0x5f5954,_0x49bdd1=0x0){return _0x5f5954['pieces_']['slice'](_0x5f5954['pieceNum_']+_0x49bdd1);}function Ro(_0x9f4ed7){if(_0x9f4ed7['pieceNum_']>=_0x9f4ed7['pieces_']['length'])return null;const _0x10dd61=[];for(let _0x21b27d=_0x9f4ed7['pieceNum_'];_0x21b27d<_0x9f4ed7['pieces_']['length']-0x1;_0x21b27d++)_0x10dd61['push'](_0x9f4ed7['pieces_'][_0x21b27d]);return new C(_0x10dd61,0x0);}function k(_0x467b95,_0x511e90){const _0x372ad8=[];for(let _0x4ce8e5=_0x467b95['pieceNum_'];_0x4ce8e5<_0x467b95['pieces_']['length'];_0x4ce8e5++)_0x372ad8['push'](_0x467b95['pieces_'][_0x4ce8e5]);if(_0x511e90 instanceof C){for(let _0x47474c=_0x511e90['pieceNum_'];_0x47474c<_0x511e90['pieces_']['length'];_0x47474c++)_0x372ad8['push'](_0x511e90['pieces_'][_0x47474c]);}else{const _0xc23bd4=_0x511e90['split']('/');for(let _0x3c3405=0x0;_0x3c3405<_0xc23bd4['length'];_0x3c3405++)_0xc23bd4[_0x3c3405]['length']>0x0&&_0x372ad8['push'](_0xc23bd4[_0x3c3405]);}return new C(_0x372ad8,0x0);}function v(_0x518a4c){return _0x518a4c['pieceNum_']>=_0x518a4c['pieces_']['length'];}function F(_0x1e969b,_0x49c343){const _0x64b0d8=y(_0x1e969b),_0x40f985=y(_0x49c343);if(_0x64b0d8===null)return _0x49c343;if(_0x64b0d8===_0x40f985)return F(b(_0x1e969b),b(_0x49c343));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x49c343+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1e969b+')');}function Rh(_0x2ece16,_0x2978d4){const _0x1428e6=Pt(_0x2ece16,0x0),_0x4fcbcb=Pt(_0x2978d4,0x0);for(let _0x2b639c=0x0;_0x2b639c<_0x1428e6['length']&&_0x2b639c<_0x4fcbcb['length'];_0x2b639c++){const _0x5b2cb3=He(_0x1428e6[_0x2b639c],_0x4fcbcb[_0x2b639c]);if(_0x5b2cb3!==0x0)return _0x5b2cb3;}return _0x1428e6['length']===_0x4fcbcb['length']?0x0:_0x1428e6['length']<_0x4fcbcb['length']?-0x1:0x1;}function ji(_0x1f4de0,_0x873a1c){if(we(_0x1f4de0)!==we(_0x873a1c))return!0x1;for(let _0x4271bf=_0x1f4de0['pieceNum_'],_0xa524b=_0x873a1c['pieceNum_'];_0x4271bf<=_0x1f4de0['pieces_']['length'];_0x4271bf++,_0xa524b++)if(_0x1f4de0['pieces_'][_0x4271bf]!==_0x873a1c['pieces_'][_0xa524b])return!0x1;return!0x0;}function G(_0x31d7b0,_0x52f7b2){let _0x352d1d=_0x31d7b0['pieceNum_'],_0x2cf0ea=_0x52f7b2['pieceNum_'];if(we(_0x31d7b0)>we(_0x52f7b2))return!0x1;for(;_0x352d1d<_0x31d7b0['pieces_']['length'];){if(_0x31d7b0['pieces_'][_0x352d1d]!==_0x52f7b2['pieces_'][_0x2cf0ea])return!0x1;++_0x352d1d,++_0x2cf0ea;}return!0x0;}class Ah{constructor(_0x458bc0,_0x19f061){this['errorPrefix_']=_0x19f061,this['parts_']=Pt(_0x458bc0,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x5cd423=0x0;_0x5cd423<this['parts_']['length'];_0x5cd423++)this['byteLength_']+=On(this['parts_'][_0x5cd423]);Ao(this);}}function kh(_0x4d63f3,_0x2c30bb){_0x4d63f3['parts_']['length']>0x0&&(_0x4d63f3['byteLength_']+=0x1),_0x4d63f3['parts_']['push'](_0x2c30bb),_0x4d63f3['byteLength_']+=On(_0x2c30bb),Ao(_0x4d63f3);}function Nh(_0x43ad21){const _0x2a3934=_0x43ad21['parts_']['pop']();_0x43ad21['byteLength_']-=On(_0x2a3934),_0x43ad21['parts_']['length']>0x0&&(_0x43ad21['byteLength_']-=0x1);}function Ao(_0x4cf797){if(_0x4cf797['byteLength_']>er)throw new Error(_0x4cf797['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x4cf797['byteLength_']+').');if(_0x4cf797['parts_']['length']>Zs)throw new Error(_0x4cf797['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x4cf797));}function Pe(_0x257995){return _0x257995['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x257995['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x4bb301,_0x6b8167;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x6b8167='visibilitychange',_0x4bb301='hidden'):typeof document['mozHidden']<'u'?(_0x6b8167='mozvisibilitychange',_0x4bb301='mozHidden'):typeof document['msHidden']<'u'?(_0x6b8167='msvisibilitychange',_0x4bb301='msHidden'):typeof document['webkitHidden']<'u'&&(_0x6b8167='webkitvisibilitychange',_0x4bb301='webkitHidden')),this['visible_']=!0x0,_0x6b8167&&document['addEventListener'](_0x6b8167,()=>{const _0x231756=!document[_0x4bb301];_0x231756!==this['visible_']&&(this['visible_']=_0x231756,this['trigger']('visible',_0x231756));},!0x1);}['getInitialEvent'](_0x5e0525){return f(_0x5e0525==='visible','Unknown\x20event\x20type:\x20'+_0x5e0525),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x2ceee2,_0x4348dc,_0x5353d5,_0x2e7c43,_0x2aabab,_0x23307f,_0x410045,_0x42db51){if(super(),this['repoInfo_']=_0x2ceee2,this['applicationId_']=_0x4348dc,this['onDataUpdate_']=_0x5353d5,this['onConnectStatus_']=_0x2e7c43,this['onServerInfoUpdate_']=_0x2aabab,this['authTokenProvider_']=_0x23307f,this['appCheckTokenProvider_']=_0x410045,this['authOverride_']=_0x42db51,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x42db51)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x2ceee2['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x4e7c30,_0x5a5b3c,_0x19247b){const _0x19d6b9=++this['requestNumber_'],_0x592aa6={'r':_0x19d6b9,'a':_0x4e7c30,'b':_0x5a5b3c};this['log_'](O(_0x592aa6)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x592aa6),_0x19247b&&(this['requestCBHash_'][_0x19d6b9]=_0x19247b);}['get'](_0x2534c6){this['initConnection_']();const _0x2ea547=new ot(),_0x2e0168={'action':'g','request':{'p':_0x2534c6['_path']['toString'](),'q':_0x2534c6['_queryObject']},'onComplete':_0x31a448=>{const _0x34dc31=_0x31a448['d'];_0x31a448['s']==='ok'?_0x2ea547['resolve'](_0x34dc31):_0x2ea547['reject'](_0x34dc31);}};this['outstandingGets_']['push'](_0x2e0168),this['outstandingGetCount_']++;const _0x3ba431=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x3ba431),_0x2ea547['promise'];}['listen'](_0x34553e,_0x1733ee,_0x39404b,_0xc2a317){this['initConnection_']();const _0x504e13=_0x34553e['_queryIdentifier'],_0x14d6d0=_0x34553e['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x14d6d0+'\x20'+_0x504e13),this['listens']['has'](_0x14d6d0)||this['listens']['set'](_0x14d6d0,new Map()),f(_0x34553e['_queryParams']['isDefault']()||!_0x34553e['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x14d6d0)['has'](_0x504e13),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x13af04={'onComplete':_0xc2a317,'hashFn':_0x1733ee,'query':_0x34553e,'tag':_0x39404b};this['listens']['get'](_0x14d6d0)['set'](_0x504e13,_0x13af04),this['connected_']&&this['sendListen_'](_0x13af04);}['sendGet_'](_0x35d622){const _0x1b54c9=this['outstandingGets_'][_0x35d622];this['sendRequest']('g',_0x1b54c9['request'],_0x8ec848=>{delete this['outstandingGets_'][_0x35d622],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1b54c9['onComplete']&&_0x1b54c9['onComplete'](_0x8ec848);});}['sendListen_'](_0x1650a6){const _0x3224ef=_0x1650a6['query'],_0x2b62d3=_0x3224ef['_path']['toString'](),_0x10e0b9=_0x3224ef['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x2b62d3+'\x20for\x20'+_0x10e0b9);const _0x576275={'p':_0x2b62d3},_0x196efe='q';_0x1650a6['tag']&&(_0x576275['q']=_0x3224ef['_queryObject'],_0x576275['t']=_0x1650a6['tag']),_0x576275['h']=_0x1650a6['hashFn'](),this['sendRequest'](_0x196efe,_0x576275,_0x5f49b2=>{const _0x255144=_0x5f49b2['d'],_0x2c04f6=_0x5f49b2['s'];se['warnOnListenWarnings_'](_0x255144,_0x3224ef),(this['listens']['get'](_0x2b62d3)&&this['listens']['get'](_0x2b62d3)['get'](_0x10e0b9))===_0x1650a6&&(this['log_']('listen\x20response',_0x5f49b2),_0x2c04f6!=='ok'&&this['removeListen_'](_0x2b62d3,_0x10e0b9),_0x1650a6['onComplete']&&_0x1650a6['onComplete'](_0x2c04f6,_0x255144));});}static['warnOnListenWarnings_'](_0x36689f,_0x735eac){if(_0x36689f&&typeof _0x36689f=='object'&&J(_0x36689f,'w')){const _0x33badf=De(_0x36689f,'w');if(Array['isArray'](_0x33badf)&&~_0x33badf['indexOf']('no_index')){const _0x3010a2='\x22.indexOn\x22:\x20\x22'+_0x735eac['_queryParams']['getIndex']()['toString']()+'\x22',_0x17025b=_0x735eac['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x3010a2+'\x20at\x20'+_0x17025b+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x38197b){this['authToken_']=_0x38197b,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x38197b);}['reduceReconnectDelayIfAdminCredential_'](_0x2c1a1c){(_0x2c1a1c&&_0x2c1a1c['length']===0x28||wc(_0x2c1a1c))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x3831d0){this['appCheckToken_']=_0x3831d0,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x2980d5=this['authToken_'],_0x2b9fef=Ic(_0x2980d5)?'auth':'gauth',_0x5ab1c3={'cred':_0x2980d5};this['authOverride_']===null?_0x5ab1c3['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x5ab1c3['authvar']=this['authOverride_']),this['sendRequest'](_0x2b9fef,_0x5ab1c3,_0x124f44=>{const _0x4a20d3=_0x124f44['s'],_0x3419c7=_0x124f44['d']||'error';this['authToken_']===_0x2980d5&&(_0x4a20d3==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x4a20d3,_0x3419c7));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x46bbd5=>{const _0x73150b=_0x46bbd5['s'],_0x4b16cf=_0x46bbd5['d']||'error';_0x73150b==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x73150b,_0x4b16cf);});}['unlisten'](_0x49a22d,_0xc70467){const _0x361d2e=_0x49a22d['_path']['toString'](),_0x2c4bff=_0x49a22d['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x361d2e+'\x20'+_0x2c4bff),f(_0x49a22d['_queryParams']['isDefault']()||!_0x49a22d['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x361d2e,_0x2c4bff)&&this['connected_']&&this['sendUnlisten_'](_0x361d2e,_0x2c4bff,_0x49a22d['_queryObject'],_0xc70467);}['sendUnlisten_'](_0x3aa0d9,_0x325574,_0x3dbc25,_0xb4b513){this['log_']('Unlisten\x20on\x20'+_0x3aa0d9+'\x20for\x20'+_0x325574);const _0x248bf8={'p':_0x3aa0d9},_0x915d7a='n';_0xb4b513&&(_0x248bf8['q']=_0x3dbc25,_0x248bf8['t']=_0xb4b513),this['sendRequest'](_0x915d7a,_0x248bf8);}['onDisconnectPut'](_0x35426a,_0x53ad2b,_0x1103a4){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x35426a,_0x53ad2b,_0x1103a4):this['onDisconnectRequestQueue_']['push']({'pathString':_0x35426a,'action':'o','data':_0x53ad2b,'onComplete':_0x1103a4});}['onDisconnectMerge'](_0x7c9f27,_0x22d23d,_0x16328e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x7c9f27,_0x22d23d,_0x16328e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x7c9f27,'action':'om','data':_0x22d23d,'onComplete':_0x16328e});}['onDisconnectCancel'](_0x1ad20f,_0x2e195e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x1ad20f,null,_0x2e195e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1ad20f,'action':'oc','data':null,'onComplete':_0x2e195e});}['sendOnDisconnect_'](_0x4a8e2e,_0xab10b1,_0x2e3450,_0x2c7679){const _0x53a960={'p':_0xab10b1,'d':_0x2e3450};this['log_']('onDisconnect\x20'+_0x4a8e2e,_0x53a960),this['sendRequest'](_0x4a8e2e,_0x53a960,_0x5ded73=>{_0x2c7679&&setTimeout(()=>{_0x2c7679(_0x5ded73['s'],_0x5ded73['d']);},Math['floor'](0x0));});}['put'](_0xf19577,_0x173383,_0x1cdbc5,_0x42b845){this['putInternal']('p',_0xf19577,_0x173383,_0x1cdbc5,_0x42b845);}['merge'](_0x2e4122,_0x4a5035,_0x44b3e6,_0x5d4723){this['putInternal']('m',_0x2e4122,_0x4a5035,_0x44b3e6,_0x5d4723);}['putInternal'](_0x5c94d7,_0x248904,_0x23b6f7,_0x41cd60,_0x447deb){this['initConnection_']();const _0x50bab0={'p':_0x248904,'d':_0x23b6f7};_0x447deb!==void 0x0&&(_0x50bab0['h']=_0x447deb),this['outstandingPuts_']['push']({'action':_0x5c94d7,'request':_0x50bab0,'onComplete':_0x41cd60}),this['outstandingPutCount_']++;const _0x25cac1=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x25cac1):this['log_']('Buffering\x20put:\x20'+_0x248904);}['sendPut_'](_0x56961b){const _0x16d936=this['outstandingPuts_'][_0x56961b]['action'],_0xed9fb7=this['outstandingPuts_'][_0x56961b]['request'],_0x4d94ac=this['outstandingPuts_'][_0x56961b]['onComplete'];this['outstandingPuts_'][_0x56961b]['queued']=this['connected_'],this['sendRequest'](_0x16d936,_0xed9fb7,_0x2da511=>{this['log_'](_0x16d936+'\x20response',_0x2da511),delete this['outstandingPuts_'][_0x56961b],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x4d94ac&&_0x4d94ac(_0x2da511['s'],_0x2da511['d']);});}['reportStats'](_0x489c5c){if(this['connected_']){const _0x28084f={'c':_0x489c5c};this['log_']('reportStats',_0x28084f),this['sendRequest']('s',_0x28084f,_0x3700f7=>{if(_0x3700f7['s']!=='ok'){const _0x57672b=_0x3700f7['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x57672b);}});}}['onDataMessage_'](_0x56fced){if('r'in _0x56fced){this['log_']('from\x20server:\x20'+O(_0x56fced));const _0x57e177=_0x56fced['r'],_0x3e6926=this['requestCBHash_'][_0x57e177];_0x3e6926&&(delete this['requestCBHash_'][_0x57e177],_0x3e6926(_0x56fced['b']));}else{if('error'in _0x56fced)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x56fced['error'];'a'in _0x56fced&&this['onDataPush_'](_0x56fced['a'],_0x56fced['b']);}}['onDataPush_'](_0xfaf3da,_0x30143a){this['log_']('handleServerMessage',_0xfaf3da,_0x30143a),_0xfaf3da==='d'?this['onDataUpdate_'](_0x30143a['p'],_0x30143a['d'],!0x1,_0x30143a['t']):_0xfaf3da==='m'?this['onDataUpdate_'](_0x30143a['p'],_0x30143a['d'],!0x0,_0x30143a['t']):_0xfaf3da==='c'?this['onListenRevoked_'](_0x30143a['p'],_0x30143a['q']):_0xfaf3da==='ac'?this['onAuthRevoked_'](_0x30143a['s'],_0x30143a['d']):_0xfaf3da==='apc'?this['onAppCheckRevoked_'](_0x30143a['s'],_0x30143a['d']):_0xfaf3da==='sd'?this['onSecurityDebugPacket_'](_0x30143a):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0xfaf3da)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x58a36e,_0x15c5ce){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x58a36e),this['lastSessionId']=_0x15c5ce,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x8a81b2){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x8a81b2));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0xca3eb9){_0xca3eb9&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0xca3eb9;}['onOnline_'](_0x580ec7){_0x580ec7?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x261573=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x218eff=Math['max'](0x0,this['reconnectDelay_']-_0x261573);_0x218eff=Math['random']()*_0x218eff,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x218eff+'ms'),this['scheduleConnect_'](_0x218eff),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x507857=this['onDataMessage_']['bind'](this),_0x36e7fd=this['onReady_']['bind'](this),_0x5d9820=this['onRealtimeDisconnect_']['bind'](this),_0x2532ce=this['id']+':'+se['nextConnectionId_']++,_0x377b4c=this['lastSessionId'];let _0x23c90a=!0x1,_0x34444d=null;const _0x47bea3=function(){_0x34444d?_0x34444d['close']():(_0x23c90a=!0x0,_0x5d9820());},_0x59739d=function(_0x5c6f5c){f(_0x34444d,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x34444d['sendRequest'](_0x5c6f5c);};this['realtime_']={'close':_0x47bea3,'sendRequest':_0x59739d};const _0x42ee99=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x465cac,_0x1388f2]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x42ee99),this['appCheckTokenProvider_']['getToken'](_0x42ee99)]);_0x23c90a?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x465cac&&_0x465cac['accessToken'],this['appCheckToken_']=_0x1388f2&&_0x1388f2['token'],_0x34444d=new Sh(_0x2532ce,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x507857,_0x36e7fd,_0x5d9820,_0x2307a2=>{U(_0x2307a2+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x377b4c));}catch(_0x53fc12){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x53fc12),_0x23c90a||(this['repoInfo_']['nodeAdmin']&&U(_0x53fc12),_0x47bea3());}}}['interrupt'](_0x3bb431){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x3bb431),this['interruptReasons_'][_0x3bb431]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x447af1){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x447af1),delete this['interruptReasons_'][_0x447af1],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0xec5008){const _0x3bd6a6=_0xec5008-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x3bd6a6});}['cancelSentTransactions_'](){for(let _0x46ca4b=0x0;_0x46ca4b<this['outstandingPuts_']['length'];_0x46ca4b++){const _0x3c38ad=this['outstandingPuts_'][_0x46ca4b];_0x3c38ad&&'h'in _0x3c38ad['request']&&_0x3c38ad['queued']&&(_0x3c38ad['onComplete']&&_0x3c38ad['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x46ca4b],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x12a950,_0x4e3c32){let _0x353191;_0x4e3c32?_0x353191=_0x4e3c32['map'](_0x195b33=>Hi(_0x195b33))['join']('$'):_0x353191='default';const _0x429cd2=this['removeListen_'](_0x12a950,_0x353191);_0x429cd2&&_0x429cd2['onComplete']&&_0x429cd2['onComplete']('permission_denied');}['removeListen_'](_0x468d8a,_0x2ddf2b){const _0x339587=new C(_0x468d8a)['toString']();let _0x13ebf4;if(this['listens']['has'](_0x339587)){const _0x5882fd=this['listens']['get'](_0x339587);_0x13ebf4=_0x5882fd['get'](_0x2ddf2b),_0x5882fd['delete'](_0x2ddf2b),_0x5882fd['size']===0x0&&this['listens']['delete'](_0x339587);}else _0x13ebf4=void 0x0;return _0x13ebf4;}['onAuthRevoked_'](_0x3042f7,_0x5568ef){L('Auth\x20token\x20revoked:\x20'+_0x3042f7+'/'+_0x5568ef),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x3042f7==='invalid_token'||_0x3042f7==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x20ae59,_0x13dbda){L('App\x20check\x20token\x20revoked:\x20'+_0x20ae59+'/'+_0x13dbda),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x20ae59==='invalid_token'||_0x20ae59==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x51f3f4){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x51f3f4):'msg'in _0x51f3f4&&console['log']('FIREBASE:\x20'+_0x51f3f4['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x573d1f of this['listens']['values']())for(const _0x3fb3f3 of _0x573d1f['values']())this['sendListen_'](_0x3fb3f3);for(let _0x8db535=0x0;_0x8db535<this['outstandingPuts_']['length'];_0x8db535++)this['outstandingPuts_'][_0x8db535]&&this['sendPut_'](_0x8db535);for(;this['onDisconnectRequestQueue_']['length'];){const _0x55b3bb=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x55b3bb['action'],_0x55b3bb['pathString'],_0x55b3bb['data'],_0x55b3bb['onComplete']);}for(let _0x2172ab=0x0;_0x2172ab<this['outstandingGets_']['length'];_0x2172ab++)this['outstandingGets_'][_0x2172ab]&&this['sendGet_'](_0x2172ab);}['sendConnectStats_'](){const _0x29b49b={};let _0x5bf87a='js';_0x29b49b['sdk.'+_0x5bf87a+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x29b49b['framework.cordova']=0x1:Yr()&&(_0x29b49b['framework.reactnative']=0x1),this['reportStats'](_0x29b49b);}['shouldReconnect_'](){const _0x2f380f=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x2f380f;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x8cb16a,_0x3cd26f){this['name']=_0x8cb16a,this['node']=_0x3cd26f;}static['Wrap'](_0x5674bf,_0x449248){return new E(_0x5674bf,_0x449248);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x3b35f7,_0x54bf50){const _0x343998=new E(Fe,_0x3b35f7),_0x49aa5b=new E(Fe,_0x54bf50);return this['compare'](_0x343998,_0x49aa5b)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0xa5b8a7){Zt=_0xa5b8a7;}['compare'](_0x3bce71,_0x4e60f5){return He(_0x3bce71['name'],_0x4e60f5['name']);}['isDefinedOn'](_0xd38e8a){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x3e2b74,_0x38d400){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x4b0801,_0x8809ec){return f(typeof _0x4b0801=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x4b0801,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x340a54,_0x1a2d6e,_0x327fd6,_0x118159,_0x455436=null){this['isReverse_']=_0x118159,this['resultGenerator_']=_0x455436,this['nodeStack_']=[];let _0x114521=0x1;for(;!_0x340a54['isEmpty']();)if(_0x340a54=_0x340a54,_0x114521=_0x1a2d6e?_0x327fd6(_0x340a54['key'],_0x1a2d6e):0x1,_0x118159&&(_0x114521*=-0x1),_0x114521<0x0)this['isReverse_']?_0x340a54=_0x340a54['left']:_0x340a54=_0x340a54['right'];else{if(_0x114521===0x0){this['nodeStack_']['push'](_0x340a54);break;}else this['nodeStack_']['push'](_0x340a54),this['isReverse_']?_0x340a54=_0x340a54['right']:_0x340a54=_0x340a54['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x32a571=this['nodeStack_']['pop'](),_0x2392c6;if(this['resultGenerator_']?_0x2392c6=this['resultGenerator_'](_0x32a571['key'],_0x32a571['value']):_0x2392c6={'key':_0x32a571['key'],'value':_0x32a571['value']},this['isReverse_']){for(_0x32a571=_0x32a571['left'];!_0x32a571['isEmpty']();)this['nodeStack_']['push'](_0x32a571),_0x32a571=_0x32a571['right'];}else{for(_0x32a571=_0x32a571['right'];!_0x32a571['isEmpty']();)this['nodeStack_']['push'](_0x32a571),_0x32a571=_0x32a571['left'];}return _0x2392c6;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0xfe47f1=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0xfe47f1['key'],_0xfe47f1['value']):{'key':_0xfe47f1['key'],'value':_0xfe47f1['value']};}}class M{constructor(_0x3802d8,_0xc60365,_0x11bb6f,_0x419338,_0x49788e){this['key']=_0x3802d8,this['value']=_0xc60365,this['color']=_0x11bb6f??M['RED'],this['left']=_0x419338??B['EMPTY_NODE'],this['right']=_0x49788e??B['EMPTY_NODE'];}['copy'](_0x415707,_0x214ca8,_0x4a3a0f,_0x5e06a2,_0x45feb0){return new M(_0x415707??this['key'],_0x214ca8??this['value'],_0x4a3a0f??this['color'],_0x5e06a2??this['left'],_0x45feb0??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x449ffc){return this['left']['inorderTraversal'](_0x449ffc)||!!_0x449ffc(this['key'],this['value'])||this['right']['inorderTraversal'](_0x449ffc);}['reverseTraversal'](_0x1088f3){return this['right']['reverseTraversal'](_0x1088f3)||_0x1088f3(this['key'],this['value'])||this['left']['reverseTraversal'](_0x1088f3);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x50ffdc,_0x1ab078,_0x3927b2){let _0x2a559a=this;const _0x1e05a8=_0x3927b2(_0x50ffdc,_0x2a559a['key']);return _0x1e05a8<0x0?_0x2a559a=_0x2a559a['copy'](null,null,null,_0x2a559a['left']['insert'](_0x50ffdc,_0x1ab078,_0x3927b2),null):_0x1e05a8===0x0?_0x2a559a=_0x2a559a['copy'](null,_0x1ab078,null,null,null):_0x2a559a=_0x2a559a['copy'](null,null,null,null,_0x2a559a['right']['insert'](_0x50ffdc,_0x1ab078,_0x3927b2)),_0x2a559a['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x4d1f56=this;return!_0x4d1f56['left']['isRed_']()&&!_0x4d1f56['left']['left']['isRed_']()&&(_0x4d1f56=_0x4d1f56['moveRedLeft_']()),_0x4d1f56=_0x4d1f56['copy'](null,null,null,_0x4d1f56['left']['removeMin_'](),null),_0x4d1f56['fixUp_']();}['remove'](_0x4044cc,_0x84b615){let _0x58d4dc,_0x5896f0;if(_0x58d4dc=this,_0x84b615(_0x4044cc,_0x58d4dc['key'])<0x0)!_0x58d4dc['left']['isEmpty']()&&!_0x58d4dc['left']['isRed_']()&&!_0x58d4dc['left']['left']['isRed_']()&&(_0x58d4dc=_0x58d4dc['moveRedLeft_']()),_0x58d4dc=_0x58d4dc['copy'](null,null,null,_0x58d4dc['left']['remove'](_0x4044cc,_0x84b615),null);else{if(_0x58d4dc['left']['isRed_']()&&(_0x58d4dc=_0x58d4dc['rotateRight_']()),!_0x58d4dc['right']['isEmpty']()&&!_0x58d4dc['right']['isRed_']()&&!_0x58d4dc['right']['left']['isRed_']()&&(_0x58d4dc=_0x58d4dc['moveRedRight_']()),_0x84b615(_0x4044cc,_0x58d4dc['key'])===0x0){if(_0x58d4dc['right']['isEmpty']())return B['EMPTY_NODE'];_0x5896f0=_0x58d4dc['right']['min_'](),_0x58d4dc=_0x58d4dc['copy'](_0x5896f0['key'],_0x5896f0['value'],null,null,_0x58d4dc['right']['removeMin_']());}_0x58d4dc=_0x58d4dc['copy'](null,null,null,null,_0x58d4dc['right']['remove'](_0x4044cc,_0x84b615));}return _0x58d4dc['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x2802d3=this;return _0x2802d3['right']['isRed_']()&&!_0x2802d3['left']['isRed_']()&&(_0x2802d3=_0x2802d3['rotateLeft_']()),_0x2802d3['left']['isRed_']()&&_0x2802d3['left']['left']['isRed_']()&&(_0x2802d3=_0x2802d3['rotateRight_']()),_0x2802d3['left']['isRed_']()&&_0x2802d3['right']['isRed_']()&&(_0x2802d3=_0x2802d3['colorFlip_']()),_0x2802d3;}['moveRedLeft_'](){let _0x57238f=this['colorFlip_']();return _0x57238f['right']['left']['isRed_']()&&(_0x57238f=_0x57238f['copy'](null,null,null,null,_0x57238f['right']['rotateRight_']()),_0x57238f=_0x57238f['rotateLeft_'](),_0x57238f=_0x57238f['colorFlip_']()),_0x57238f;}['moveRedRight_'](){let _0x37ac33=this['colorFlip_']();return _0x37ac33['left']['left']['isRed_']()&&(_0x37ac33=_0x37ac33['rotateRight_'](),_0x37ac33=_0x37ac33['colorFlip_']()),_0x37ac33;}['rotateLeft_'](){const _0x5a8c05=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x5a8c05,null);}['rotateRight_'](){const _0x2909c1=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x2909c1);}['colorFlip_'](){const _0x5ce22e=this['left']['copy'](null,null,!this['left']['color'],null,null),_0xf046a8=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x5ce22e,_0xf046a8);}['checkMaxDepth_'](){const _0x395302=this['check_']();return Math['pow'](0x2,_0x395302)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x555d8b=this['left']['check_']();if(_0x555d8b!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x555d8b+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x143a44,_0x202b2f,_0xcdd5b9,_0x13957e,_0x42780a){return this;}['insert'](_0x479b1e,_0x473fde,_0x2a6054){return new M(_0x479b1e,_0x473fde,null);}['remove'](_0x4047aa,_0x3587bf){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x2a0d6f){return!0x1;}['reverseTraversal'](_0x319945){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x2f9a87,_0x3264e8=B['EMPTY_NODE']){this['comparator_']=_0x2f9a87,this['root_']=_0x3264e8;}['insert'](_0x528c94,_0x18c854){return new B(this['comparator_'],this['root_']['insert'](_0x528c94,_0x18c854,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x5a7464){return new B(this['comparator_'],this['root_']['remove'](_0x5a7464,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x47acea){let _0x3d8418,_0x4a19ea=this['root_'];for(;!_0x4a19ea['isEmpty']();){if(_0x3d8418=this['comparator_'](_0x47acea,_0x4a19ea['key']),_0x3d8418===0x0)return _0x4a19ea['value'];_0x3d8418<0x0?_0x4a19ea=_0x4a19ea['left']:_0x3d8418>0x0&&(_0x4a19ea=_0x4a19ea['right']);}return null;}['getPredecessorKey'](_0x453791){let _0x94bbe,_0x49bf2e=this['root_'],_0x51602b=null;for(;!_0x49bf2e['isEmpty']();)if(_0x94bbe=this['comparator_'](_0x453791,_0x49bf2e['key']),_0x94bbe===0x0){if(_0x49bf2e['left']['isEmpty']())return _0x51602b?_0x51602b['key']:null;for(_0x49bf2e=_0x49bf2e['left'];!_0x49bf2e['right']['isEmpty']();)_0x49bf2e=_0x49bf2e['right'];return _0x49bf2e['key'];}else _0x94bbe<0x0?_0x49bf2e=_0x49bf2e['left']:_0x94bbe>0x0&&(_0x51602b=_0x49bf2e,_0x49bf2e=_0x49bf2e['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x5ea925){return this['root_']['inorderTraversal'](_0x5ea925);}['reverseTraversal'](_0x412461){return this['root_']['reverseTraversal'](_0x412461);}['getIterator'](_0x348485){return new en(this['root_'],null,this['comparator_'],!0x1,_0x348485);}['getIteratorFrom'](_0x14ac3f,_0x212d6f){return new en(this['root_'],_0x14ac3f,this['comparator_'],!0x1,_0x212d6f);}['getReverseIteratorFrom'](_0x5d7722,_0x205587){return new en(this['root_'],_0x5d7722,this['comparator_'],!0x0,_0x205587);}['getReverseIterator'](_0x496262){return new en(this['root_'],null,this['comparator_'],!0x0,_0x496262);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x5b85e1,_0x2b290a){return He(_0x5b85e1['name'],_0x2b290a['name']);}function Yi(_0x57e7b0,_0x1125f9){return He(_0x57e7b0,_0x1125f9);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x3b8407){Ei=_0x3b8407;}const No=function(_0x4d6123){return typeof _0x4d6123=='number'?'number:'+ao(_0x4d6123):'string:'+_0x4d6123;},Po=function(_0x7ca685){if(_0x7ca685['isLeafNode']()){const _0xc1f617=_0x7ca685['val']();f(typeof _0xc1f617=='string'||typeof _0xc1f617=='number'||typeof _0xc1f617=='object'&&J(_0xc1f617,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x7ca685===Ei||_0x7ca685['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x7ca685===Ei||_0x7ca685['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x18bfa7){ir=_0x18bfa7;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x1c0e1b,_0x4f9f65=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x1c0e1b,this['priorityNode_']=_0x4f9f65,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1c9fb1){return new D(this['value_'],_0x1c9fb1);}['getImmediateChild'](_0x47644e){return _0x47644e==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x481714){return v(_0x481714)?this:y(_0x481714)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x19bbfa,_0x21414c){return null;}['updateImmediateChild'](_0x19d13b,_0x578965){return _0x19d13b==='.priority'?this['updatePriority'](_0x578965):_0x578965['isEmpty']()&&_0x19d13b!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x19d13b,_0x578965)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x6c1432,_0x1fd2ec){const _0x359d1e=y(_0x6c1432);return _0x359d1e===null?_0x1fd2ec:_0x1fd2ec['isEmpty']()&&_0x359d1e!=='.priority'?this:(f(_0x359d1e!=='.priority'||we(_0x6c1432)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x359d1e,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x6c1432),_0x1fd2ec)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x5ec99c,_0x14767d){return!0x1;}['val'](_0xcd90c1){return _0xcd90c1&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x5c8cdf='';this['priorityNode_']['isEmpty']()||(_0x5c8cdf+='priority:'+No(this['priorityNode_']['val']())+':');const _0x364cb9=typeof this['value_'];_0x5c8cdf+=_0x364cb9+':',_0x364cb9==='number'?_0x5c8cdf+=ao(this['value_']):_0x5c8cdf+=this['value_'],this['lazyHash_']=ro(_0x5c8cdf);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0xfd52ba){return _0xfd52ba===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0xfd52ba instanceof D['__childrenNodeConstructor']?-0x1:(f(_0xfd52ba['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0xfd52ba));}['compareToLeafNode_'](_0x29c048){const _0x103b95=typeof _0x29c048['value_'],_0x1cfa21=typeof this['value_'],_0x235bc5=D['VALUE_TYPE_ORDER']['indexOf'](_0x103b95),_0x23f925=D['VALUE_TYPE_ORDER']['indexOf'](_0x1cfa21);return f(_0x235bc5>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x103b95),f(_0x23f925>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1cfa21),_0x235bc5===_0x23f925?_0x1cfa21==='object'?0x0:this['value_']<_0x29c048['value_']?-0x1:this['value_']===_0x29c048['value_']?0x0:0x1:_0x23f925-_0x235bc5;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x1bd746){if(_0x1bd746===this)return!0x0;if(_0x1bd746['isLeafNode']()){const _0x468392=_0x1bd746;return this['value_']===_0x468392['value_']&&this['priorityNode_']['equals'](_0x468392['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x31d2da){Oo=_0x31d2da;}function Wh(_0x113a90){Do=_0x113a90;}class Bh extends Dn{['compare'](_0x33521e,_0x43db45){const _0x76eea=_0x33521e['node']['getPriority'](),_0x46d695=_0x43db45['node']['getPriority'](),_0x361fa3=_0x76eea['compareTo'](_0x46d695);return _0x361fa3===0x0?He(_0x33521e['name'],_0x43db45['name']):_0x361fa3;}['isDefinedOn'](_0x1dcc05){return!_0x1dcc05['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x2e16d6,_0x1d47c4){return!_0x2e16d6['getPriority']()['equals'](_0x1d47c4['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x27b99b,_0x3b3cca){const _0x51837f=Oo(_0x27b99b);return new E(_0x3b3cca,new D('[PRIORITY-POST]',_0x51837f));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x5da734){const _0xfeecf8=_0x3ee920=>parseInt(Math['log'](_0x3ee920)/Vh,0xa),_0x8bf87a=_0x155191=>parseInt(Array(_0x155191+0x1)['join']('1'),0x2);this['count']=_0xfeecf8(_0x5da734+0x1),this['current_']=this['count']-0x1;const _0x2457f2=_0x8bf87a(this['count']);this['bits_']=_0x5da734+0x1&_0x2457f2;}['nextBitIsOne'](){const _0x1e34be=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x1e34be;}}const fn=function(_0x1b8227,_0x2694eb,_0x4622af,_0x14b2a3){_0x1b8227['sort'](_0x2694eb);const _0x38350e=function(_0xb8c7ea,_0x4dfa3d){const _0x161b82=_0x4dfa3d-_0xb8c7ea;let _0x5b8242,_0x7af5a;if(_0x161b82===0x0)return null;if(_0x161b82===0x1)return _0x5b8242=_0x1b8227[_0xb8c7ea],_0x7af5a=_0x4622af?_0x4622af(_0x5b8242):_0x5b8242,new M(_0x7af5a,_0x5b8242['node'],M['BLACK'],null,null);{const _0x5be569=parseInt(_0x161b82/0x2,0xa)+_0xb8c7ea,_0x10de7b=_0x38350e(_0xb8c7ea,_0x5be569),_0x31cae9=_0x38350e(_0x5be569+0x1,_0x4dfa3d);return _0x5b8242=_0x1b8227[_0x5be569],_0x7af5a=_0x4622af?_0x4622af(_0x5b8242):_0x5b8242,new M(_0x7af5a,_0x5b8242['node'],M['BLACK'],_0x10de7b,_0x31cae9);}},_0x57648c=function(_0x3dce0b){let _0x5208ff=null,_0x47ef32=null,_0x50dd67=_0x1b8227['length'];const _0x581d76=function(_0x4811ab,_0x1baf91){const _0x1c9831=_0x50dd67-_0x4811ab,_0x41d980=_0x50dd67;_0x50dd67-=_0x4811ab;const _0xf39dce=_0x38350e(_0x1c9831+0x1,_0x41d980),_0x478aea=_0x1b8227[_0x1c9831],_0x3969a8=_0x4622af?_0x4622af(_0x478aea):_0x478aea;_0x901b4b(new M(_0x3969a8,_0x478aea['node'],_0x1baf91,null,_0xf39dce));},_0x901b4b=function(_0x41774c){_0x5208ff?(_0x5208ff['left']=_0x41774c,_0x5208ff=_0x41774c):(_0x47ef32=_0x41774c,_0x5208ff=_0x41774c);};for(let _0x24d35f=0x0;_0x24d35f<_0x3dce0b['count'];++_0x24d35f){const _0x307c0f=_0x3dce0b['nextBitIsOne'](),_0x29e99c=Math['pow'](0x2,_0x3dce0b['count']-(_0x24d35f+0x1));_0x307c0f?_0x581d76(_0x29e99c,M['BLACK']):(_0x581d76(_0x29e99c,M['BLACK']),_0x581d76(_0x29e99c,M['RED']));}return _0x47ef32;},_0x1c5b47=new Hh(_0x1b8227['length']),_0x535217=_0x57648c(_0x1c5b47);return new B(_0x14b2a3||_0x2694eb,_0x535217);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x4b2199,_0xbd5a2d){this['indexes_']=_0x4b2199,this['indexSet_']=_0xbd5a2d;}['get'](_0x9adac2){const _0x3c57cf=De(this['indexes_'],_0x9adac2);if(!_0x3c57cf)throw new Error('No\x20index\x20defined\x20for\x20'+_0x9adac2);return _0x3c57cf instanceof B?_0x3c57cf:null;}['hasIndex'](_0x3b96d2){return J(this['indexSet_'],_0x3b96d2['toString']());}['addIndex'](_0x250e1d,_0x51760a){f(_0x250e1d!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x3a020a=[];let _0x10237d=!0x1;const _0x553fb1=_0x51760a['getIterator'](E['Wrap']);let _0x2b1161=_0x553fb1['getNext']();for(;_0x2b1161;)_0x10237d=_0x10237d||_0x250e1d['isDefinedOn'](_0x2b1161['node']),_0x3a020a['push'](_0x2b1161),_0x2b1161=_0x553fb1['getNext']();let _0x182d65;_0x10237d?_0x182d65=fn(_0x3a020a,_0x250e1d['getCompare']()):_0x182d65=ze;const _0x56bad0=_0x250e1d['toString'](),_0x2921b8={...this['indexSet_']};_0x2921b8[_0x56bad0]=_0x250e1d;const _0x8c7825={...this['indexes_']};return _0x8c7825[_0x56bad0]=_0x182d65,new te(_0x8c7825,_0x2921b8);}['addToIndexes'](_0x59bbbf,_0x589b8c){const _0x32ad72=hn(this['indexes_'],(_0x5c3d64,_0x46af20)=>{const _0x6dd544=De(this['indexSet_'],_0x46af20);if(f(_0x6dd544,'Missing\x20index\x20implementation\x20for\x20'+_0x46af20),_0x5c3d64===ze){if(_0x6dd544['isDefinedOn'](_0x59bbbf['node'])){const _0x178391=[],_0xc9f3a=_0x589b8c['getIterator'](E['Wrap']);let _0x598720=_0xc9f3a['getNext']();for(;_0x598720;)_0x598720['name']!==_0x59bbbf['name']&&_0x178391['push'](_0x598720),_0x598720=_0xc9f3a['getNext']();return _0x178391['push'](_0x59bbbf),fn(_0x178391,_0x6dd544['getCompare']());}else return ze;}else{const _0x43e173=_0x589b8c['get'](_0x59bbbf['name']);let _0x3aff1b=_0x5c3d64;return _0x43e173&&(_0x3aff1b=_0x3aff1b['remove'](new E(_0x59bbbf['name'],_0x43e173))),_0x3aff1b['insert'](_0x59bbbf,_0x59bbbf['node']);}});return new te(_0x32ad72,this['indexSet_']);}['removeFromIndexes'](_0x3f0640,_0x38315d){const _0x258aa4=hn(this['indexes_'],_0x292b00=>{if(_0x292b00===ze)return _0x292b00;{const _0x603b52=_0x38315d['get'](_0x3f0640['name']);return _0x603b52?_0x292b00['remove'](new E(_0x3f0640['name'],_0x603b52)):_0x292b00;}});return new te(_0x258aa4,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0xbc3ae8,_0x659d2d,_0x5a493c){this['children_']=_0xbc3ae8,this['priorityNode_']=_0x659d2d,this['indexMap_']=_0x5a493c,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x1346ee){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x1346ee,this['indexMap_']);}['getImmediateChild'](_0x5b3440){if(_0x5b3440==='.priority')return this['getPriority']();{const _0x5f926c=this['children_']['get'](_0x5b3440);return _0x5f926c===null?mt:_0x5f926c;}}['getChild'](_0x557f65){const _0x162009=y(_0x557f65);return _0x162009===null?this:this['getImmediateChild'](_0x162009)['getChild'](b(_0x557f65));}['hasChild'](_0x46e0e4){return this['children_']['get'](_0x46e0e4)!==null;}['updateImmediateChild'](_0x5ef1cd,_0x1e1e39){if(f(_0x1e1e39,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x5ef1cd==='.priority')return this['updatePriority'](_0x1e1e39);{const _0x5f4398=new E(_0x5ef1cd,_0x1e1e39);let _0x14e78b,_0x2a8d94;_0x1e1e39['isEmpty']()?(_0x14e78b=this['children_']['remove'](_0x5ef1cd),_0x2a8d94=this['indexMap_']['removeFromIndexes'](_0x5f4398,this['children_'])):(_0x14e78b=this['children_']['insert'](_0x5ef1cd,_0x1e1e39),_0x2a8d94=this['indexMap_']['addToIndexes'](_0x5f4398,this['children_']));const _0x4f4ead=_0x14e78b['isEmpty']()?mt:this['priorityNode_'];return new g(_0x14e78b,_0x4f4ead,_0x2a8d94);}}['updateChild'](_0x159894,_0x3d79e6){const _0x59a180=y(_0x159894);if(_0x59a180===null)return _0x3d79e6;{f(y(_0x159894)!=='.priority'||we(_0x159894)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x4e4f0f=this['getImmediateChild'](_0x59a180)['updateChild'](b(_0x159894),_0x3d79e6);return this['updateImmediateChild'](_0x59a180,_0x4e4f0f);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x8c9190){if(this['isEmpty']())return null;const _0x30d0e2={};let _0x150ddb=0x0,_0x14c1f8=0x0,_0x2312e7=!0x0;if(this['forEachChild'](R,(_0x5ca540,_0x4f0e96)=>{_0x30d0e2[_0x5ca540]=_0x4f0e96['val'](_0x8c9190),_0x150ddb++,_0x2312e7&&g['INTEGER_REGEXP_']['test'](_0x5ca540)?_0x14c1f8=Math['max'](_0x14c1f8,Number(_0x5ca540)):_0x2312e7=!0x1;}),!_0x8c9190&&_0x2312e7&&_0x14c1f8<0x2*_0x150ddb){const _0x55c34b=[];for(const _0x5b4ad5 in _0x30d0e2)_0x55c34b[_0x5b4ad5]=_0x30d0e2[_0x5b4ad5];return _0x55c34b;}else return _0x8c9190&&!this['getPriority']()['isEmpty']()&&(_0x30d0e2['.priority']=this['getPriority']()['val']()),_0x30d0e2;}['hash'](){if(this['lazyHash_']===null){let _0xcb2377='';this['getPriority']()['isEmpty']()||(_0xcb2377+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x760c5f,_0x3958d6)=>{const _0x41d51a=_0x3958d6['hash']();_0x41d51a!==''&&(_0xcb2377+=':'+_0x760c5f+':'+_0x41d51a);}),this['lazyHash_']=_0xcb2377===''?'':ro(_0xcb2377);}return this['lazyHash_'];}['getPredecessorChildName'](_0x26be29,_0x11be05,_0x5f3f9d){const _0x130b9e=this['resolveIndex_'](_0x5f3f9d);if(_0x130b9e){const _0x20a69a=_0x130b9e['getPredecessorKey'](new E(_0x26be29,_0x11be05));return _0x20a69a?_0x20a69a['name']:null;}else return this['children_']['getPredecessorKey'](_0x26be29);}['getFirstChildName'](_0x3b4546){const _0x246842=this['resolveIndex_'](_0x3b4546);if(_0x246842){const _0x14e591=_0x246842['minKey']();return _0x14e591&&_0x14e591['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x1ce59d){const _0x5122d8=this['getFirstChildName'](_0x1ce59d);return _0x5122d8?new E(_0x5122d8,this['children_']['get'](_0x5122d8)):null;}['getLastChildName'](_0x5330fd){const _0x228ca2=this['resolveIndex_'](_0x5330fd);if(_0x228ca2){const _0x2ec23e=_0x228ca2['maxKey']();return _0x2ec23e&&_0x2ec23e['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x396c90){const _0x9eb389=this['getLastChildName'](_0x396c90);return _0x9eb389?new E(_0x9eb389,this['children_']['get'](_0x9eb389)):null;}['forEachChild'](_0x432760,_0x35b57e){const _0x450333=this['resolveIndex_'](_0x432760);return _0x450333?_0x450333['inorderTraversal'](_0x4794e1=>_0x35b57e(_0x4794e1['name'],_0x4794e1['node'])):this['children_']['inorderTraversal'](_0x35b57e);}['getIterator'](_0x32543e){return this['getIteratorFrom'](_0x32543e['minPost'](),_0x32543e);}['getIteratorFrom'](_0x1c144c,_0x220ac1){const _0x3b62f3=this['resolveIndex_'](_0x220ac1);if(_0x3b62f3)return _0x3b62f3['getIteratorFrom'](_0x1c144c,_0x31dea8=>_0x31dea8);{const _0xabdea9=this['children_']['getIteratorFrom'](_0x1c144c['name'],E['Wrap']);let _0x1a3ffb=_0xabdea9['peek']();for(;_0x1a3ffb!=null&&_0x220ac1['compare'](_0x1a3ffb,_0x1c144c)<0x0;)_0xabdea9['getNext'](),_0x1a3ffb=_0xabdea9['peek']();return _0xabdea9;}}['getReverseIterator'](_0x3b65b8){return this['getReverseIteratorFrom'](_0x3b65b8['maxPost'](),_0x3b65b8);}['getReverseIteratorFrom'](_0x86812e,_0x2a2891){const _0x554f12=this['resolveIndex_'](_0x2a2891);if(_0x554f12)return _0x554f12['getReverseIteratorFrom'](_0x86812e,_0x556593=>_0x556593);{const _0x1b9bff=this['children_']['getReverseIteratorFrom'](_0x86812e['name'],E['Wrap']);let _0x428539=_0x1b9bff['peek']();for(;_0x428539!=null&&_0x2a2891['compare'](_0x428539,_0x86812e)>0x0;)_0x1b9bff['getNext'](),_0x428539=_0x1b9bff['peek']();return _0x1b9bff;}}['compareTo'](_0x255acc){return this['isEmpty']()?_0x255acc['isEmpty']()?0x0:-0x1:_0x255acc['isLeafNode']()||_0x255acc['isEmpty']()?0x1:_0x255acc===$t?-0x1:0x0;}['withIndex'](_0x4b41de){if(_0x4b41de===ye||this['indexMap_']['hasIndex'](_0x4b41de))return this;{const _0x284a3d=this['indexMap_']['addIndex'](_0x4b41de,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x284a3d);}}['isIndexed'](_0x52c5a0){return _0x52c5a0===ye||this['indexMap_']['hasIndex'](_0x52c5a0);}['equals'](_0x537227){if(_0x537227===this)return!0x0;if(_0x537227['isLeafNode']())return!0x1;{const _0x53e9f8=_0x537227;if(this['getPriority']()['equals'](_0x53e9f8['getPriority']())){if(this['children_']['count']()===_0x53e9f8['children_']['count']()){const _0x294533=this['getIterator'](R),_0x46ef0c=_0x53e9f8['getIterator'](R);let _0x2ac382=_0x294533['getNext'](),_0x5efaef=_0x46ef0c['getNext']();for(;_0x2ac382&&_0x5efaef;){if(_0x2ac382['name']!==_0x5efaef['name']||!_0x2ac382['node']['equals'](_0x5efaef['node']))return!0x1;_0x2ac382=_0x294533['getNext'](),_0x5efaef=_0x46ef0c['getNext']();}return _0x2ac382===null&&_0x5efaef===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x5c1fb0){return _0x5c1fb0===ye?null:this['indexMap_']['get'](_0x5c1fb0['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x518c06){return _0x518c06===this?0x0:0x1;}['equals'](_0x59b2ec){return _0x59b2ec===this;}['getPriority'](){return this;}['getImmediateChild'](_0x1a8a8e){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x2628ca,_0x112513=null){if(_0x2628ca===null)return g['EMPTY_NODE'];if(typeof _0x2628ca=='object'&&'.priority'in _0x2628ca&&(_0x112513=_0x2628ca['.priority']),f(_0x112513===null||typeof _0x112513=='string'||typeof _0x112513=='number'||typeof _0x112513=='object'&&'.sv'in _0x112513,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x112513),typeof _0x2628ca=='object'&&'.value'in _0x2628ca&&_0x2628ca['.value']!==null&&(_0x2628ca=_0x2628ca['.value']),typeof _0x2628ca!='object'||'.sv'in _0x2628ca){const _0x6aba34=_0x2628ca;return new D(_0x6aba34,P(_0x112513));}if(!(_0x2628ca instanceof Array)&&Gh){const _0x5349cc=[];let _0x24c5ad=!0x1;if(x(_0x2628ca,(_0x953e21,_0x40aaf6)=>{if(_0x953e21['substring'](0x0,0x1)!=='.'){const _0x12ed2c=P(_0x40aaf6);_0x12ed2c['isEmpty']()||(_0x24c5ad=_0x24c5ad||!_0x12ed2c['getPriority']()['isEmpty'](),_0x5349cc['push'](new E(_0x953e21,_0x12ed2c)));}}),_0x5349cc['length']===0x0)return g['EMPTY_NODE'];const _0xc59aab=fn(_0x5349cc,xh,_0x3d2a40=>_0x3d2a40['name'],Yi);if(_0x24c5ad){const _0x3bad82=fn(_0x5349cc,R['getCompare']());return new g(_0xc59aab,P(_0x112513),new te({'.priority':_0x3bad82},{'.priority':R}));}else return new g(_0xc59aab,P(_0x112513),te['Default']);}else{let _0x1879b2=g['EMPTY_NODE'];return x(_0x2628ca,(_0x14b783,_0x13bf78)=>{if(J(_0x2628ca,_0x14b783)&&_0x14b783['substring'](0x0,0x1)!=='.'){const _0x3d10ba=P(_0x13bf78);(_0x3d10ba['isLeafNode']()||!_0x3d10ba['isEmpty']())&&(_0x1879b2=_0x1879b2['updateImmediateChild'](_0x14b783,_0x3d10ba));}}),_0x1879b2['updatePriority'](P(_0x112513));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x101261){super(),this['indexPath_']=_0x101261,f(!v(_0x101261)&&y(_0x101261)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x1230aa){return _0x1230aa['getChild'](this['indexPath_']);}['isDefinedOn'](_0xfa15ef){return!_0xfa15ef['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x2d3ca1,_0x456f77){const _0x92e596=this['extractChild'](_0x2d3ca1['node']),_0x4092e8=this['extractChild'](_0x456f77['node']),_0x1e5004=_0x92e596['compareTo'](_0x4092e8);return _0x1e5004===0x0?He(_0x2d3ca1['name'],_0x456f77['name']):_0x1e5004;}['makePost'](_0x19becc,_0x30c4ed){const _0x477c50=P(_0x19becc),_0xbdcb05=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x477c50);return new E(_0x30c4ed,_0xbdcb05);}['maxPost'](){const _0x4e3d36=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x4e3d36);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x1eff46,_0x1067f9){const _0x4da5d1=_0x1eff46['node']['compareTo'](_0x1067f9['node']);return _0x4da5d1===0x0?He(_0x1eff46['name'],_0x1067f9['name']):_0x4da5d1;}['isDefinedOn'](_0x5be8b4){return!0x0;}['indexedValueChanged'](_0x352cef,_0x47d87b){return!_0x352cef['equals'](_0x47d87b);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x22fca6,_0x24f877){const _0x4d4f1a=P(_0x22fca6);return new E(_0x24f877,_0x4d4f1a);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0xd393cb){return{'type':'value','snapshotNode':_0xd393cb};}function et(_0x540499,_0x372dd4){return{'type':'child_added','snapshotNode':_0x372dd4,'childName':_0x540499};}function Ot(_0x334896,_0xbaff1d){return{'type':'child_removed','snapshotNode':_0xbaff1d,'childName':_0x334896};}function Dt(_0x17b0c8,_0x3f7faa,_0x5111b8){return{'type':'child_changed','snapshotNode':_0x3f7faa,'childName':_0x17b0c8,'oldSnap':_0x5111b8};}function zh(_0x510700,_0x3baa1d){return{'type':'child_moved','snapshotNode':_0x3baa1d,'childName':_0x510700};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x16a9e9){this['index_']=_0x16a9e9;}['updateChild'](_0x5aca64,_0x191af7,_0x402f7c,_0x266c26,_0x1780e7,_0x283463){f(_0x5aca64['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x2d336a=_0x5aca64['getImmediateChild'](_0x191af7);return _0x2d336a['getChild'](_0x266c26)['equals'](_0x402f7c['getChild'](_0x266c26))&&_0x2d336a['isEmpty']()===_0x402f7c['isEmpty']()||(_0x283463!=null&&(_0x402f7c['isEmpty']()?_0x5aca64['hasChild'](_0x191af7)?_0x283463['trackChildChange'](Ot(_0x191af7,_0x2d336a)):f(_0x5aca64['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x2d336a['isEmpty']()?_0x283463['trackChildChange'](et(_0x191af7,_0x402f7c)):_0x283463['trackChildChange'](Dt(_0x191af7,_0x402f7c,_0x2d336a))),_0x5aca64['isLeafNode']()&&_0x402f7c['isEmpty']())?_0x5aca64:_0x5aca64['updateImmediateChild'](_0x191af7,_0x402f7c)['withIndex'](this['index_']);}['updateFullNode'](_0x892b34,_0x17d1de,_0x1a979c){return _0x1a979c!=null&&(_0x892b34['isLeafNode']()||_0x892b34['forEachChild'](R,(_0xb4fd95,_0x15d481)=>{_0x17d1de['hasChild'](_0xb4fd95)||_0x1a979c['trackChildChange'](Ot(_0xb4fd95,_0x15d481));}),_0x17d1de['isLeafNode']()||_0x17d1de['forEachChild'](R,(_0x420779,_0x519b3e)=>{if(_0x892b34['hasChild'](_0x420779)){const _0x44951b=_0x892b34['getImmediateChild'](_0x420779);_0x44951b['equals'](_0x519b3e)||_0x1a979c['trackChildChange'](Dt(_0x420779,_0x519b3e,_0x44951b));}else _0x1a979c['trackChildChange'](et(_0x420779,_0x519b3e));})),_0x17d1de['withIndex'](this['index_']);}['updatePriority'](_0x10356d,_0x14ccd4){return _0x10356d['isEmpty']()?g['EMPTY_NODE']:_0x10356d['updatePriority'](_0x14ccd4);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x233a70){this['indexedFilter_']=new Ji(_0x233a70['getIndex']()),this['index_']=_0x233a70['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x233a70),this['endPost_']=Mt['getEndPost_'](_0x233a70),this['startIsInclusive_']=!_0x233a70['startAfterSet_'],this['endIsInclusive_']=!_0x233a70['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x11a6c7){const _0x441b80=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x11a6c7)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x11a6c7)<0x0,_0x47c3b7=this['endIsInclusive_']?this['index_']['compare'](_0x11a6c7,this['getEndPost']())<=0x0:this['index_']['compare'](_0x11a6c7,this['getEndPost']())<0x0;return _0x441b80&&_0x47c3b7;}['updateChild'](_0x5a2378,_0x35c580,_0x192e9b,_0x1038a1,_0x543516,_0x3226d3){return this['matches'](new E(_0x35c580,_0x192e9b))||(_0x192e9b=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x5a2378,_0x35c580,_0x192e9b,_0x1038a1,_0x543516,_0x3226d3);}['updateFullNode'](_0x23277c,_0x3fd3db,_0x1113c3){_0x3fd3db['isLeafNode']()&&(_0x3fd3db=g['EMPTY_NODE']);let _0x47483e=_0x3fd3db['withIndex'](this['index_']);_0x47483e=_0x47483e['updatePriority'](g['EMPTY_NODE']);const _0x5449bc=this;return _0x3fd3db['forEachChild'](R,(_0x4ef9d3,_0x18f403)=>{_0x5449bc['matches'](new E(_0x4ef9d3,_0x18f403))||(_0x47483e=_0x47483e['updateImmediateChild'](_0x4ef9d3,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x23277c,_0x47483e,_0x1113c3);}['updatePriority'](_0x4bc2ca,_0x51c052){return _0x4bc2ca;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0xe43222){if(_0xe43222['hasStart']()){const _0x2b9866=_0xe43222['getIndexStartName']();return _0xe43222['getIndex']()['makePost'](_0xe43222['getIndexStartValue'](),_0x2b9866);}else return _0xe43222['getIndex']()['minPost']();}static['getEndPost_'](_0xb133e0){if(_0xb133e0['hasEnd']()){const _0x272247=_0xb133e0['getIndexEndName']();return _0xb133e0['getIndex']()['makePost'](_0xb133e0['getIndexEndValue'](),_0x272247);}else return _0xb133e0['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x3ce518){this['withinDirectionalStart']=_0x34c078=>this['reverse_']?this['withinEndPost'](_0x34c078):this['withinStartPost'](_0x34c078),this['withinDirectionalEnd']=_0xa6b112=>this['reverse_']?this['withinStartPost'](_0xa6b112):this['withinEndPost'](_0xa6b112),this['withinStartPost']=_0x2a9c97=>{const _0x507c7d=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x2a9c97);return this['startIsInclusive_']?_0x507c7d<=0x0:_0x507c7d<0x0;},this['withinEndPost']=_0x369717=>{const _0xe9582e=this['index_']['compare'](_0x369717,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0xe9582e<=0x0:_0xe9582e<0x0;},this['rangedFilter_']=new Mt(_0x3ce518),this['index_']=_0x3ce518['getIndex'](),this['limit_']=_0x3ce518['getLimit'](),this['reverse_']=!_0x3ce518['isViewFromLeft'](),this['startIsInclusive_']=!_0x3ce518['startAfterSet_'],this['endIsInclusive_']=!_0x3ce518['endBeforeSet_'];}['updateChild'](_0x47c352,_0x1993cc,_0x331597,_0x21af9e,_0x3047cd,_0x5d6ed2){return this['rangedFilter_']['matches'](new E(_0x1993cc,_0x331597))||(_0x331597=g['EMPTY_NODE']),_0x47c352['getImmediateChild'](_0x1993cc)['equals'](_0x331597)?_0x47c352:_0x47c352['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x47c352,_0x1993cc,_0x331597,_0x21af9e,_0x3047cd,_0x5d6ed2):this['fullLimitUpdateChild_'](_0x47c352,_0x1993cc,_0x331597,_0x3047cd,_0x5d6ed2);}['updateFullNode'](_0x49097e,_0x50127b,_0x295597){let _0x533813;if(_0x50127b['isLeafNode']()||_0x50127b['isEmpty']())_0x533813=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x50127b['numChildren']()&&_0x50127b['isIndexed'](this['index_'])){_0x533813=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x487cb9;this['reverse_']?_0x487cb9=_0x50127b['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x487cb9=_0x50127b['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x1a3310=0x0;for(;_0x487cb9['hasNext']()&&_0x1a3310<this['limit_'];){const _0x370986=_0x487cb9['getNext']();if(this['withinDirectionalStart'](_0x370986)){if(this['withinDirectionalEnd'](_0x370986))_0x533813=_0x533813['updateImmediateChild'](_0x370986['name'],_0x370986['node']),_0x1a3310++;else break;}else continue;}}else{_0x533813=_0x50127b['withIndex'](this['index_']),_0x533813=_0x533813['updatePriority'](g['EMPTY_NODE']);let _0x1409d0;this['reverse_']?_0x1409d0=_0x533813['getReverseIterator'](this['index_']):_0x1409d0=_0x533813['getIterator'](this['index_']);let _0x446ba8=0x0;for(;_0x1409d0['hasNext']();){const _0x58b84e=_0x1409d0['getNext']();_0x446ba8<this['limit_']&&this['withinDirectionalStart'](_0x58b84e)&&this['withinDirectionalEnd'](_0x58b84e)?_0x446ba8++:_0x533813=_0x533813['updateImmediateChild'](_0x58b84e['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x49097e,_0x533813,_0x295597);}['updatePriority'](_0x2d6541,_0x3cdb07){return _0x2d6541;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x44f556,_0x2faa63,_0x439b20,_0x5b07ad,_0x5af6a9){let _0x3f7f2b;if(this['reverse_']){const _0x398197=this['index_']['getCompare']();_0x3f7f2b=(_0x18706c,_0x50dae2)=>_0x398197(_0x50dae2,_0x18706c);}else _0x3f7f2b=this['index_']['getCompare']();const _0x319739=_0x44f556;f(_0x319739['numChildren']()===this['limit_'],'');const _0x479480=new E(_0x2faa63,_0x439b20),_0x3eb880=this['reverse_']?_0x319739['getFirstChild'](this['index_']):_0x319739['getLastChild'](this['index_']),_0x352a9a=this['rangedFilter_']['matches'](_0x479480);if(_0x319739['hasChild'](_0x2faa63)){const _0x4dba73=_0x319739['getImmediateChild'](_0x2faa63);let _0x30b069=_0x5b07ad['getChildAfterChild'](this['index_'],_0x3eb880,this['reverse_']);for(;_0x30b069!=null&&(_0x30b069['name']===_0x2faa63||_0x319739['hasChild'](_0x30b069['name']));)_0x30b069=_0x5b07ad['getChildAfterChild'](this['index_'],_0x30b069,this['reverse_']);const _0x598b91=_0x30b069==null?0x1:_0x3f7f2b(_0x30b069,_0x479480);if(_0x352a9a&&!_0x439b20['isEmpty']()&&_0x598b91>=0x0)return _0x5af6a9!=null&&_0x5af6a9['trackChildChange'](Dt(_0x2faa63,_0x439b20,_0x4dba73)),_0x319739['updateImmediateChild'](_0x2faa63,_0x439b20);{_0x5af6a9!=null&&_0x5af6a9['trackChildChange'](Ot(_0x2faa63,_0x4dba73));const _0x5dc477=_0x319739['updateImmediateChild'](_0x2faa63,g['EMPTY_NODE']);return _0x30b069!=null&&this['rangedFilter_']['matches'](_0x30b069)?(_0x5af6a9!=null&&_0x5af6a9['trackChildChange'](et(_0x30b069['name'],_0x30b069['node'])),_0x5dc477['updateImmediateChild'](_0x30b069['name'],_0x30b069['node'])):_0x5dc477;}}else return _0x439b20['isEmpty']()?_0x44f556:_0x352a9a&&_0x3f7f2b(_0x3eb880,_0x479480)>=0x0?(_0x5af6a9!=null&&(_0x5af6a9['trackChildChange'](Ot(_0x3eb880['name'],_0x3eb880['node'])),_0x5af6a9['trackChildChange'](et(_0x2faa63,_0x439b20))),_0x319739['updateImmediateChild'](_0x2faa63,_0x439b20)['updateImmediateChild'](_0x3eb880['name'],g['EMPTY_NODE'])):_0x44f556;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x50d92b=new Xi();return _0x50d92b['limitSet_']=this['limitSet_'],_0x50d92b['limit_']=this['limit_'],_0x50d92b['startSet_']=this['startSet_'],_0x50d92b['startAfterSet_']=this['startAfterSet_'],_0x50d92b['indexStartValue_']=this['indexStartValue_'],_0x50d92b['startNameSet_']=this['startNameSet_'],_0x50d92b['indexStartName_']=this['indexStartName_'],_0x50d92b['endSet_']=this['endSet_'],_0x50d92b['endBeforeSet_']=this['endBeforeSet_'],_0x50d92b['indexEndValue_']=this['indexEndValue_'],_0x50d92b['endNameSet_']=this['endNameSet_'],_0x50d92b['indexEndName_']=this['indexEndName_'],_0x50d92b['index_']=this['index_'],_0x50d92b['viewFrom_']=this['viewFrom_'],_0x50d92b;}}function Kh(_0xd106ef){return _0xd106ef['loadsAllData']()?new Ji(_0xd106ef['getIndex']()):_0xd106ef['hasLimit']()?new jh(_0xd106ef):new Mt(_0xd106ef);}function Yh(_0x5d1e09,_0x3435fd){const _0x216171=_0x5d1e09['copy']();return _0x216171['limitSet_']=!0x0,_0x216171['limit_']=_0x3435fd,_0x216171['viewFrom_']='l',_0x216171;}function Qh(_0x26adaf,_0x4f28e4,_0x45f0ac){const _0x17dbc7=_0x26adaf['copy']();return _0x17dbc7['startSet_']=!0x0,_0x4f28e4===void 0x0&&(_0x4f28e4=null),_0x17dbc7['indexStartValue_']=_0x4f28e4,_0x45f0ac!=null?(_0x17dbc7['startNameSet_']=!0x0,_0x17dbc7['indexStartName_']=_0x45f0ac):(_0x17dbc7['startNameSet_']=!0x1,_0x17dbc7['indexStartName_']=''),_0x17dbc7;}function Jh(_0x25ff64,_0x868235,_0x498787){const _0x371473=_0x25ff64['copy']();return _0x371473['endSet_']=!0x0,_0x868235===void 0x0&&(_0x868235=null),_0x371473['indexEndValue_']=_0x868235,_0x498787!==void 0x0?(_0x371473['endNameSet_']=!0x0,_0x371473['indexEndName_']=_0x498787):(_0x371473['endNameSet_']=!0x1,_0x371473['indexEndName_']=''),_0x371473;}function xo(_0x48cb8a,_0x3b2cd6){const _0x4aa644=_0x48cb8a['copy']();return _0x4aa644['index_']=_0x3b2cd6,_0x4aa644;}function sr(_0x252b8b){const _0x115a5c={};if(_0x252b8b['isDefault']())return _0x115a5c;let _0x5d9368;if(_0x252b8b['index_']===R?_0x5d9368='$priority':_0x252b8b['index_']===Mo?_0x5d9368='$value':_0x252b8b['index_']===ye?_0x5d9368='$key':(f(_0x252b8b['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x5d9368=_0x252b8b['index_']['toString']()),_0x115a5c['orderBy']=O(_0x5d9368),_0x252b8b['startSet_']){const _0xa2dba=_0x252b8b['startAfterSet_']?'startAfter':'startAt';_0x115a5c[_0xa2dba]=O(_0x252b8b['indexStartValue_']),_0x252b8b['startNameSet_']&&(_0x115a5c[_0xa2dba]+=','+O(_0x252b8b['indexStartName_']));}if(_0x252b8b['endSet_']){const _0xcd5ae2=_0x252b8b['endBeforeSet_']?'endBefore':'endAt';_0x115a5c[_0xcd5ae2]=O(_0x252b8b['indexEndValue_']),_0x252b8b['endNameSet_']&&(_0x115a5c[_0xcd5ae2]+=','+O(_0x252b8b['indexEndName_']));}return _0x252b8b['limitSet_']&&(_0x252b8b['isViewFromLeft']()?_0x115a5c['limitToFirst']=_0x252b8b['limit_']:_0x115a5c['limitToLast']=_0x252b8b['limit_']),_0x115a5c;}function rr(_0x24bc3b){const _0x41296c={};if(_0x24bc3b['startSet_']&&(_0x41296c['sp']=_0x24bc3b['indexStartValue_'],_0x24bc3b['startNameSet_']&&(_0x41296c['sn']=_0x24bc3b['indexStartName_']),_0x41296c['sin']=!_0x24bc3b['startAfterSet_']),_0x24bc3b['endSet_']&&(_0x41296c['ep']=_0x24bc3b['indexEndValue_'],_0x24bc3b['endNameSet_']&&(_0x41296c['en']=_0x24bc3b['indexEndName_']),_0x41296c['ein']=!_0x24bc3b['endBeforeSet_']),_0x24bc3b['limitSet_']){_0x41296c['l']=_0x24bc3b['limit_'];let _0x481923=_0x24bc3b['viewFrom_'];_0x481923===''&&(_0x24bc3b['isViewFromLeft']()?_0x481923='l':_0x481923='r'),_0x41296c['vf']=_0x481923;}return _0x24bc3b['index_']!==R&&(_0x41296c['i']=_0x24bc3b['index_']['toString']()),_0x41296c;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x39972c){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x4f36b5,_0x1e165d){return _0x1e165d!==void 0x0?'tag$'+_0x1e165d:(f(_0x4f36b5['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x4f36b5['_path']['toString']());}constructor(_0x128e74,_0x2d62d2,_0x46fbdb,_0x474826){super(),this['repoInfo_']=_0x128e74,this['onDataUpdate_']=_0x2d62d2,this['authTokenProvider_']=_0x46fbdb,this['appCheckTokenProvider_']=_0x474826,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x3b54f1,_0x3c7ed7,_0x756431,_0x5f0044){const _0x379944=_0x3b54f1['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x379944+'\x20'+_0x3b54f1['_queryIdentifier']);const _0x1827ae=pn['getListenId_'](_0x3b54f1,_0x756431),_0x45aa2c={};this['listens_'][_0x1827ae]=_0x45aa2c;const _0x2e0b5b=sr(_0x3b54f1['_queryParams']);this['restRequest_'](_0x379944+'.json',_0x2e0b5b,(_0x97b970,_0x16a10d)=>{let _0x3c48af=_0x16a10d;if(_0x97b970===0x194&&(_0x3c48af=null,_0x97b970=null),_0x97b970===null&&this['onDataUpdate_'](_0x379944,_0x3c48af,!0x1,_0x756431),De(this['listens_'],_0x1827ae)===_0x45aa2c){let _0x396a9a;_0x97b970?_0x97b970===0x191?_0x396a9a='permission_denied':_0x396a9a='rest_error:'+_0x97b970:_0x396a9a='ok',_0x5f0044(_0x396a9a,null);}});}['unlisten'](_0x631785,_0x1877a7){const _0x4e3ffc=pn['getListenId_'](_0x631785,_0x1877a7);delete this['listens_'][_0x4e3ffc];}['get'](_0x4d1aa0){const _0xfd4a28=sr(_0x4d1aa0['_queryParams']),_0x4d005f=_0x4d1aa0['_path']['toString'](),_0x23efa1=new ot();return this['restRequest_'](_0x4d005f+'.json',_0xfd4a28,(_0x5e7c0c,_0x19f01f)=>{let _0x5627a1=_0x19f01f;_0x5e7c0c===0x194&&(_0x5627a1=null,_0x5e7c0c=null),_0x5e7c0c===null?(this['onDataUpdate_'](_0x4d005f,_0x5627a1,!0x1,null),_0x23efa1['resolve'](_0x5627a1)):_0x23efa1['reject'](new Error(_0x5627a1));}),_0x23efa1['promise'];}['refreshAuthToken'](_0x9832d9){}['restRequest_'](_0x530b02,_0x3be159={},_0x159734){return _0x3be159['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0xeab26c,_0x4172d0])=>{_0xeab26c&&_0xeab26c['accessToken']&&(_0x3be159['auth']=_0xeab26c['accessToken']),_0x4172d0&&_0x4172d0['token']&&(_0x3be159['ac']=_0x4172d0['token']);const _0x59f74b=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x530b02+'?ns='+this['repoInfo_']['namespace']+ct(_0x3be159);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x59f74b);const _0x3fbaa7=new XMLHttpRequest();_0x3fbaa7['onreadystatechange']=()=>{if(_0x159734&&_0x3fbaa7['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x59f74b+'\x20received.\x20status:',_0x3fbaa7['status'],'response:',_0x3fbaa7['responseText']);let _0x4e18a0=null;if(_0x3fbaa7['status']>=0xc8&&_0x3fbaa7['status']<0x12c){try{_0x4e18a0=At(_0x3fbaa7['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x59f74b+':\x20'+_0x3fbaa7['responseText']);}_0x159734(null,_0x4e18a0);}else _0x3fbaa7['status']!==0x191&&_0x3fbaa7['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x59f74b+'\x20Status:\x20'+_0x3fbaa7['status']),_0x159734(_0x3fbaa7['status']);_0x159734=null;}},_0x3fbaa7['open']('GET',_0x59f74b,!0x0),_0x3fbaa7['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x15c9ad){return this['rootNode_']['getChild'](_0x15c9ad);}['updateSnapshot'](_0x164abd,_0x22073c){this['rootNode_']=this['rootNode_']['updateChild'](_0x164abd,_0x22073c);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x3c79ff,_0x3474a8,_0xf0b8bd){if(v(_0x3474a8))_0x3c79ff['value']=_0xf0b8bd,_0x3c79ff['children']['clear']();else{if(_0x3c79ff['value']!==null)_0x3c79ff['value']=_0x3c79ff['value']['updateChild'](_0x3474a8,_0xf0b8bd);else{const _0x4d90c6=y(_0x3474a8);_0x3c79ff['children']['has'](_0x4d90c6)||_0x3c79ff['children']['set'](_0x4d90c6,_n());const _0x1517fd=_0x3c79ff['children']['get'](_0x4d90c6);_0x3474a8=b(_0x3474a8),Fo(_0x1517fd,_0x3474a8,_0xf0b8bd);}}}function Ii(_0x1982a2,_0x1f0a1f,_0x3c982b){_0x1982a2['value']!==null?_0x3c982b(_0x1f0a1f,_0x1982a2['value']):Zh(_0x1982a2,(_0xa63b20,_0x4b0709)=>{const _0x3971ef=new C(_0x1f0a1f['toString']()+'/'+_0xa63b20);Ii(_0x4b0709,_0x3971ef,_0x3c982b);});}function Zh(_0x5b0da3,_0x5767bb){_0x5b0da3['children']['forEach']((_0x90aa10,_0x3170d5)=>{_0x5767bb(_0x3170d5,_0x90aa10);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x3aba42){this['collection_']=_0x3aba42,this['last_']=null;}['get'](){const _0x5c8c1e=this['collection_']['get'](),_0x3e494b={..._0x5c8c1e};return this['last_']&&x(this['last_'],(_0x5780be,_0x2969f5)=>{_0x3e494b[_0x5780be]=_0x3e494b[_0x5780be]-_0x2969f5;}),this['last_']=_0x5c8c1e,_0x3e494b;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x389fd7,_0x7d823d){this['server_']=_0x7d823d,this['statsToReport_']={},this['statsListener_']=new eu(_0x389fd7);const _0xd49e99=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0xd49e99));}['reportStats_'](){const _0xd3ee3=this['statsListener_']['get'](),_0x2503a0={};let _0x3200b6=!0x1;x(_0xd3ee3,(_0x437e71,_0x5248bc)=>{_0x5248bc>0x0&&J(this['statsToReport_'],_0x437e71)&&(_0x2503a0[_0x437e71]=_0x5248bc,_0x3200b6=!0x0);}),_0x3200b6&&this['server_']['reportStats'](_0x2503a0),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x9a9499){_0x9a9499[_0x9a9499['OVERWRITE']=0x0]='OVERWRITE',_0x9a9499[_0x9a9499['MERGE']=0x1]='MERGE',_0x9a9499[_0x9a9499['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x9a9499[_0x9a9499['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x147222){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x147222,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x6bb6eb,_0x142a7c,_0x36d043){this['path']=_0x6bb6eb,this['affectedTree']=_0x142a7c,this['revert']=_0x36d043,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x423f2a){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x4a8d00=this['affectedTree']['subtree'](new C(_0x423f2a));return new gn(w(),_0x4a8d00,this['revert']);}}else return f(y(this['path'])===_0x423f2a,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x1c73f4,_0x2eaf26){this['source']=_0x1c73f4,this['path']=_0x2eaf26,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x2b91c9){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x25e31f,_0x314a0f,_0x13e22a){this['source']=_0x25e31f,this['path']=_0x314a0f,this['snap']=_0x13e22a,this['type']=j['OVERWRITE'];}['operationForChild'](_0x20b302){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x20b302)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x551833,_0x34fdd6,_0x5645f7){this['source']=_0x551833,this['path']=_0x34fdd6,this['children']=_0x5645f7,this['type']=j['MERGE'];}['operationForChild'](_0x979847){if(v(this['path'])){const _0x3dd6d1=this['children']['subtree'](new C(_0x979847));return _0x3dd6d1['isEmpty']()?null:_0x3dd6d1['value']?new Ue(this['source'],w(),_0x3dd6d1['value']):new tt(this['source'],w(),_0x3dd6d1);}else return f(y(this['path'])===_0x979847,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x187421,_0x273180,_0x85b705){this['node_']=_0x187421,this['fullyInitialized_']=_0x273180,this['filtered_']=_0x85b705;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x5f4d59){if(v(_0x5f4d59))return this['isFullyInitialized']()&&!this['filtered_'];const _0x5d52c8=y(_0x5f4d59);return this['isCompleteForChild'](_0x5d52c8);}['isCompleteForChild'](_0x8c2071){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x8c2071);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x8bb57e){this['query_']=_0x8bb57e,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x94af75,_0x6703de,_0x1474b9,_0x5bceaa){const _0x47bc15=[],_0x5c269d=[];return _0x6703de['forEach'](_0x26ec0d=>{_0x26ec0d['type']==='child_changed'&&_0x94af75['index_']['indexedValueChanged'](_0x26ec0d['oldSnap'],_0x26ec0d['snapshotNode'])&&_0x5c269d['push'](zh(_0x26ec0d['childName'],_0x26ec0d['snapshotNode']));}),yt(_0x94af75,_0x47bc15,'child_removed',_0x6703de,_0x5bceaa,_0x1474b9),yt(_0x94af75,_0x47bc15,'child_added',_0x6703de,_0x5bceaa,_0x1474b9),yt(_0x94af75,_0x47bc15,'child_moved',_0x5c269d,_0x5bceaa,_0x1474b9),yt(_0x94af75,_0x47bc15,'child_changed',_0x6703de,_0x5bceaa,_0x1474b9),yt(_0x94af75,_0x47bc15,'value',_0x6703de,_0x5bceaa,_0x1474b9),_0x47bc15;}function yt(_0x2759dc,_0x10a576,_0xc1ebb9,_0xf4edb0,_0x3c608f,_0x4c0a67){const _0x2b0fa3=_0xf4edb0['filter'](_0x5943fa=>_0x5943fa['type']===_0xc1ebb9);_0x2b0fa3['sort']((_0x23acdd,_0x22a92b)=>au(_0x2759dc,_0x23acdd,_0x22a92b)),_0x2b0fa3['forEach'](_0x258a99=>{const _0xe1815e=ou(_0x2759dc,_0x258a99,_0x4c0a67);_0x3c608f['forEach'](_0x369ed3=>{_0x369ed3['respondsTo'](_0x258a99['type'])&&_0x10a576['push'](_0x369ed3['createEvent'](_0xe1815e,_0x2759dc['query_']));});});}function ou(_0x162cab,_0x50932a,_0xac77d2){return _0x50932a['type']==='value'||_0x50932a['type']==='child_removed'||(_0x50932a['prevName']=_0xac77d2['getPredecessorChildName'](_0x50932a['childName'],_0x50932a['snapshotNode'],_0x162cab['index_'])),_0x50932a;}function au(_0x2b79ae,_0x5d14bb,_0x108f28){if(_0x5d14bb['childName']==null||_0x108f28['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x302d6e=new E(_0x5d14bb['childName'],_0x5d14bb['snapshotNode']),_0x58e7d0=new E(_0x108f28['childName'],_0x108f28['snapshotNode']);return _0x2b79ae['index_']['compare'](_0x302d6e,_0x58e7d0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x121493,_0x356d26){return{'eventCache':_0x121493,'serverCache':_0x356d26};}function Tt(_0x5c3289,_0x20dac2,_0x317c2d,_0x9852d5){return Mn(new Ce(_0x20dac2,_0x317c2d,_0x9852d5),_0x5c3289['serverCache']);}function Uo(_0xe45b6,_0x5aeff4,_0x2f57fc,_0x1d4349){return Mn(_0xe45b6['eventCache'],new Ce(_0x5aeff4,_0x2f57fc,_0x1d4349));}function mn(_0x13acc0){return _0x13acc0['eventCache']['isFullyInitialized']()?_0x13acc0['eventCache']['getNode']():null;}function We(_0x350ef3){return _0x350ef3['serverCache']['isFullyInitialized']()?_0x350ef3['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x15221e){let _0x3c2247=new S(null);return x(_0x15221e,(_0x3584dd,_0x4f3fe9)=>{_0x3c2247=_0x3c2247['set'](new C(_0x3584dd),_0x4f3fe9);}),_0x3c2247;}constructor(_0x1843b0,_0x3b9aa9=cu()){this['value']=_0x1843b0,this['children']=_0x3b9aa9;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x49e6b7,_0x509f91){if(this['value']!=null&&_0x509f91(this['value']))return{'path':w(),'value':this['value']};if(v(_0x49e6b7))return null;{const _0x2c46d3=y(_0x49e6b7),_0x3919ae=this['children']['get'](_0x2c46d3);if(_0x3919ae!==null){const _0x5d2dac=_0x3919ae['findRootMostMatchingPathAndValue'](b(_0x49e6b7),_0x509f91);return _0x5d2dac!=null?{'path':k(new C(_0x2c46d3),_0x5d2dac['path']),'value':_0x5d2dac['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x24b476){return this['findRootMostMatchingPathAndValue'](_0x24b476,()=>!0x0);}['subtree'](_0x56c421){if(v(_0x56c421))return this;{const _0x8fd5f=y(_0x56c421),_0x48d8a0=this['children']['get'](_0x8fd5f);return _0x48d8a0!==null?_0x48d8a0['subtree'](b(_0x56c421)):new S(null);}}['set'](_0x530ea1,_0x33b36a){if(v(_0x530ea1))return new S(_0x33b36a,this['children']);{const _0x1fd512=y(_0x530ea1),_0x2e2aae=(this['children']['get'](_0x1fd512)||new S(null))['set'](b(_0x530ea1),_0x33b36a),_0x5389c0=this['children']['insert'](_0x1fd512,_0x2e2aae);return new S(this['value'],_0x5389c0);}}['remove'](_0x190272){if(v(_0x190272))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x5d961f=y(_0x190272),_0x47bde6=this['children']['get'](_0x5d961f);if(_0x47bde6){const _0x538bdd=_0x47bde6['remove'](b(_0x190272));let _0x181c62;return _0x538bdd['isEmpty']()?_0x181c62=this['children']['remove'](_0x5d961f):_0x181c62=this['children']['insert'](_0x5d961f,_0x538bdd),this['value']===null&&_0x181c62['isEmpty']()?new S(null):new S(this['value'],_0x181c62);}else return this;}}['get'](_0x4e37bd){if(v(_0x4e37bd))return this['value'];{const _0x5d5f48=y(_0x4e37bd),_0x55efb9=this['children']['get'](_0x5d5f48);return _0x55efb9?_0x55efb9['get'](b(_0x4e37bd)):null;}}['setTree'](_0x17c94d,_0x1ba09d){if(v(_0x17c94d))return _0x1ba09d;{const _0x9ba1db=y(_0x17c94d),_0x98279=(this['children']['get'](_0x9ba1db)||new S(null))['setTree'](b(_0x17c94d),_0x1ba09d);let _0x575c8f;return _0x98279['isEmpty']()?_0x575c8f=this['children']['remove'](_0x9ba1db):_0x575c8f=this['children']['insert'](_0x9ba1db,_0x98279),new S(this['value'],_0x575c8f);}}['fold'](_0x3219d2){return this['fold_'](w(),_0x3219d2);}['fold_'](_0x2f4b97,_0x2365f5){const _0x4dfdfd={};return this['children']['inorderTraversal']((_0x37b420,_0x253e7c)=>{_0x4dfdfd[_0x37b420]=_0x253e7c['fold_'](k(_0x2f4b97,_0x37b420),_0x2365f5);}),_0x2365f5(_0x2f4b97,this['value'],_0x4dfdfd);}['findOnPath'](_0x4c20f4,_0x4edebf){return this['findOnPath_'](_0x4c20f4,w(),_0x4edebf);}['findOnPath_'](_0x54e934,_0x5bdd04,_0x5782d0){const _0x4cdab3=this['value']?_0x5782d0(_0x5bdd04,this['value']):!0x1;if(_0x4cdab3)return _0x4cdab3;if(v(_0x54e934))return null;{const _0x3afa00=y(_0x54e934),_0xfb1adc=this['children']['get'](_0x3afa00);return _0xfb1adc?_0xfb1adc['findOnPath_'](b(_0x54e934),k(_0x5bdd04,_0x3afa00),_0x5782d0):null;}}['foreachOnPath'](_0x42632e,_0x10a7b9){return this['foreachOnPath_'](_0x42632e,w(),_0x10a7b9);}['foreachOnPath_'](_0x135d54,_0x6b9248,_0x4abf21){if(v(_0x135d54))return this;{this['value']&&_0x4abf21(_0x6b9248,this['value']);const _0x34ac05=y(_0x135d54),_0x5b7cf3=this['children']['get'](_0x34ac05);return _0x5b7cf3?_0x5b7cf3['foreachOnPath_'](b(_0x135d54),k(_0x6b9248,_0x34ac05),_0x4abf21):new S(null);}}['foreach'](_0x1ab10f){this['foreach_'](w(),_0x1ab10f);}['foreach_'](_0x2aac4b,_0x7b90){this['children']['inorderTraversal']((_0x25b633,_0x39b09e)=>{_0x39b09e['foreach_'](k(_0x2aac4b,_0x25b633),_0x7b90);}),this['value']&&_0x7b90(_0x2aac4b,this['value']);}['foreachChild'](_0x504f13){this['children']['inorderTraversal']((_0x19e02d,_0x2aa807)=>{_0x2aa807['value']&&_0x504f13(_0x19e02d,_0x2aa807['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x48f181){this['writeTree_']=_0x48f181;}static['empty'](){return new Y(new S(null));}}function St(_0x5fccc4,_0xe1ea83,_0x5f2a2c){if(v(_0xe1ea83))return new Y(new S(_0x5f2a2c));{const _0x80190a=_0x5fccc4['writeTree_']['findRootMostValueAndPath'](_0xe1ea83);if(_0x80190a!=null){const _0x49357d=_0x80190a['path'];let _0x5a33ce=_0x80190a['value'];const _0x15e499=F(_0x49357d,_0xe1ea83);return _0x5a33ce=_0x5a33ce['updateChild'](_0x15e499,_0x5f2a2c),new Y(_0x5fccc4['writeTree_']['set'](_0x49357d,_0x5a33ce));}else{const _0x3965b1=new S(_0x5f2a2c),_0x5d056c=_0x5fccc4['writeTree_']['setTree'](_0xe1ea83,_0x3965b1);return new Y(_0x5d056c);}}}function wi(_0x3c83d2,_0x45e231,_0x3617dc){let _0x1335d1=_0x3c83d2;return x(_0x3617dc,(_0x3839e2,_0x139d23)=>{_0x1335d1=St(_0x1335d1,k(_0x45e231,_0x3839e2),_0x139d23);}),_0x1335d1;}function ar(_0x41c4f4,_0x550fa9){if(v(_0x550fa9))return Y['empty']();{const _0x255e29=_0x41c4f4['writeTree_']['setTree'](_0x550fa9,new S(null));return new Y(_0x255e29);}}function Ci(_0x36c39d,_0x2f524e){return $e(_0x36c39d,_0x2f524e)!=null;}function $e(_0x2fc74f,_0x4314c4){const _0x2545ed=_0x2fc74f['writeTree_']['findRootMostValueAndPath'](_0x4314c4);return _0x2545ed!=null?_0x2fc74f['writeTree_']['get'](_0x2545ed['path'])['getChild'](F(_0x2545ed['path'],_0x4314c4)):null;}function cr(_0x3984c4){const _0x3a86db=[],_0x2762d9=_0x3984c4['writeTree_']['value'];return _0x2762d9!=null?_0x2762d9['isLeafNode']()||_0x2762d9['forEachChild'](R,(_0x3bb835,_0x1e7e01)=>{_0x3a86db['push'](new E(_0x3bb835,_0x1e7e01));}):_0x3984c4['writeTree_']['children']['inorderTraversal']((_0xc7a49e,_0x5b16c5)=>{_0x5b16c5['value']!=null&&_0x3a86db['push'](new E(_0xc7a49e,_0x5b16c5['value']));}),_0x3a86db;}function ve(_0x5b860c,_0x35fd17){if(v(_0x35fd17))return _0x5b860c;{const _0x10ca9c=$e(_0x5b860c,_0x35fd17);return _0x10ca9c!=null?new Y(new S(_0x10ca9c)):new Y(_0x5b860c['writeTree_']['subtree'](_0x35fd17));}}function Ti(_0xf04f4f){return _0xf04f4f['writeTree_']['isEmpty']();}function nt(_0x27c63b,_0x2569cb){return Wo(w(),_0x27c63b['writeTree_'],_0x2569cb);}function Wo(_0x41eeb1,_0x104af0,_0x22730e){if(_0x104af0['value']!=null)return _0x22730e['updateChild'](_0x41eeb1,_0x104af0['value']);{let _0x2ab7b1=null;return _0x104af0['children']['inorderTraversal']((_0x5e5480,_0x380421)=>{_0x5e5480==='.priority'?(f(_0x380421['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2ab7b1=_0x380421['value']):_0x22730e=Wo(k(_0x41eeb1,_0x5e5480),_0x380421,_0x22730e);}),!_0x22730e['getChild'](_0x41eeb1)['isEmpty']()&&_0x2ab7b1!==null&&(_0x22730e=_0x22730e['updateChild'](k(_0x41eeb1,'.priority'),_0x2ab7b1)),_0x22730e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x2d0e6c,_0x39fa85){return $o(_0x39fa85,_0x2d0e6c);}function lu(_0x7bf6f9,_0x58b20f,_0x844e03,_0xb4a5e5,_0x3296b3){f(_0xb4a5e5>_0x7bf6f9['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x3296b3===void 0x0&&(_0x3296b3=!0x0),_0x7bf6f9['allWrites']['push']({'path':_0x58b20f,'snap':_0x844e03,'writeId':_0xb4a5e5,'visible':_0x3296b3}),_0x3296b3&&(_0x7bf6f9['visibleWrites']=St(_0x7bf6f9['visibleWrites'],_0x58b20f,_0x844e03)),_0x7bf6f9['lastWriteId']=_0xb4a5e5;}function hu(_0x32a20b,_0x410ede,_0x4bdbab,_0x106641){f(_0x106641>_0x32a20b['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x32a20b['allWrites']['push']({'path':_0x410ede,'children':_0x4bdbab,'writeId':_0x106641,'visible':!0x0}),_0x32a20b['visibleWrites']=wi(_0x32a20b['visibleWrites'],_0x410ede,_0x4bdbab),_0x32a20b['lastWriteId']=_0x106641;}function uu(_0x2fe070,_0x5cb059){for(let _0x3bec67=0x0;_0x3bec67<_0x2fe070['allWrites']['length'];_0x3bec67++){const _0x493300=_0x2fe070['allWrites'][_0x3bec67];if(_0x493300['writeId']===_0x5cb059)return _0x493300;}return null;}function du(_0x10445b,_0x3dece8){const _0x498bbe=_0x10445b['allWrites']['findIndex'](_0x4e58d=>_0x4e58d['writeId']===_0x3dece8);f(_0x498bbe>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0xbeaabf=_0x10445b['allWrites'][_0x498bbe];_0x10445b['allWrites']['splice'](_0x498bbe,0x1);let _0x3ec15a=_0xbeaabf['visible'],_0x4d0cb5=!0x1,_0x3b9053=_0x10445b['allWrites']['length']-0x1;for(;_0x3ec15a&&_0x3b9053>=0x0;){const _0x4d3920=_0x10445b['allWrites'][_0x3b9053];_0x4d3920['visible']&&(_0x3b9053>=_0x498bbe&&fu(_0x4d3920,_0xbeaabf['path'])?_0x3ec15a=!0x1:G(_0xbeaabf['path'],_0x4d3920['path'])&&(_0x4d0cb5=!0x0)),_0x3b9053--;}if(_0x3ec15a){if(_0x4d0cb5)return pu(_0x10445b),!0x0;if(_0xbeaabf['snap'])_0x10445b['visibleWrites']=ar(_0x10445b['visibleWrites'],_0xbeaabf['path']);else{const _0x5d524a=_0xbeaabf['children'];x(_0x5d524a,_0x34cb33=>{_0x10445b['visibleWrites']=ar(_0x10445b['visibleWrites'],k(_0xbeaabf['path'],_0x34cb33));});}return!0x0;}else return!0x1;}function fu(_0x32a018,_0x35d593){if(_0x32a018['snap'])return G(_0x32a018['path'],_0x35d593);for(const _0xe07cbf in _0x32a018['children'])if(_0x32a018['children']['hasOwnProperty'](_0xe07cbf)&&G(k(_0x32a018['path'],_0xe07cbf),_0x35d593))return!0x0;return!0x1;}function pu(_0x32a422){_0x32a422['visibleWrites']=Bo(_0x32a422['allWrites'],_u,w()),_0x32a422['allWrites']['length']>0x0?_0x32a422['lastWriteId']=_0x32a422['allWrites'][_0x32a422['allWrites']['length']-0x1]['writeId']:_0x32a422['lastWriteId']=-0x1;}function _u(_0x59fc29){return _0x59fc29['visible'];}function Bo(_0x1ef259,_0x5ddc35,_0x108e1d){let _0x5dfdb0=Y['empty']();for(let _0x146b1c=0x0;_0x146b1c<_0x1ef259['length'];++_0x146b1c){const _0xe085be=_0x1ef259[_0x146b1c];if(_0x5ddc35(_0xe085be)){const _0x19178d=_0xe085be['path'];let _0x51fc9e;if(_0xe085be['snap'])G(_0x108e1d,_0x19178d)?(_0x51fc9e=F(_0x108e1d,_0x19178d),_0x5dfdb0=St(_0x5dfdb0,_0x51fc9e,_0xe085be['snap'])):G(_0x19178d,_0x108e1d)&&(_0x51fc9e=F(_0x19178d,_0x108e1d),_0x5dfdb0=St(_0x5dfdb0,w(),_0xe085be['snap']['getChild'](_0x51fc9e)));else{if(_0xe085be['children']){if(G(_0x108e1d,_0x19178d))_0x51fc9e=F(_0x108e1d,_0x19178d),_0x5dfdb0=wi(_0x5dfdb0,_0x51fc9e,_0xe085be['children']);else{if(G(_0x19178d,_0x108e1d)){if(_0x51fc9e=F(_0x19178d,_0x108e1d),v(_0x51fc9e))_0x5dfdb0=wi(_0x5dfdb0,w(),_0xe085be['children']);else{const _0x297a67=De(_0xe085be['children'],y(_0x51fc9e));if(_0x297a67){const _0x30be76=_0x297a67['getChild'](b(_0x51fc9e));_0x5dfdb0=St(_0x5dfdb0,w(),_0x30be76);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x5dfdb0;}function Vo(_0x2436a0,_0x28da9b,_0x5df71b,_0x93a6be,_0x54bbae){if(!_0x93a6be&&!_0x54bbae){const _0x221c13=$e(_0x2436a0['visibleWrites'],_0x28da9b);if(_0x221c13!=null)return _0x221c13;{const _0x207ff8=ve(_0x2436a0['visibleWrites'],_0x28da9b);if(Ti(_0x207ff8))return _0x5df71b;if(_0x5df71b==null&&!Ci(_0x207ff8,w()))return null;{const _0x2daeb0=_0x5df71b||g['EMPTY_NODE'];return nt(_0x207ff8,_0x2daeb0);}}}else{const _0x1b3812=ve(_0x2436a0['visibleWrites'],_0x28da9b);if(!_0x54bbae&&Ti(_0x1b3812))return _0x5df71b;if(!_0x54bbae&&_0x5df71b==null&&!Ci(_0x1b3812,w()))return null;{const _0x31a371=function(_0x1d07d7){return(_0x1d07d7['visible']||_0x54bbae)&&(!_0x93a6be||!~_0x93a6be['indexOf'](_0x1d07d7['writeId']))&&(G(_0x1d07d7['path'],_0x28da9b)||G(_0x28da9b,_0x1d07d7['path']));},_0x3d44b4=Bo(_0x2436a0['allWrites'],_0x31a371,_0x28da9b),_0x2e52ae=_0x5df71b||g['EMPTY_NODE'];return nt(_0x3d44b4,_0x2e52ae);}}}function gu(_0x61fa33,_0xa499c4,_0x19cfe4){let _0x172641=g['EMPTY_NODE'];const _0x2b019e=$e(_0x61fa33['visibleWrites'],_0xa499c4);if(_0x2b019e)return _0x2b019e['isLeafNode']()||_0x2b019e['forEachChild'](R,(_0x66b396,_0x1bd3fb)=>{_0x172641=_0x172641['updateImmediateChild'](_0x66b396,_0x1bd3fb);}),_0x172641;if(_0x19cfe4){const _0x50cb82=ve(_0x61fa33['visibleWrites'],_0xa499c4);return _0x19cfe4['forEachChild'](R,(_0x24e994,_0x48e306)=>{const _0x112da1=nt(ve(_0x50cb82,new C(_0x24e994)),_0x48e306);_0x172641=_0x172641['updateImmediateChild'](_0x24e994,_0x112da1);}),cr(_0x50cb82)['forEach'](_0x27e455=>{_0x172641=_0x172641['updateImmediateChild'](_0x27e455['name'],_0x27e455['node']);}),_0x172641;}else{const _0x2bbbbf=ve(_0x61fa33['visibleWrites'],_0xa499c4);return cr(_0x2bbbbf)['forEach'](_0x246b78=>{_0x172641=_0x172641['updateImmediateChild'](_0x246b78['name'],_0x246b78['node']);}),_0x172641;}}function mu(_0x52253e,_0x592454,_0x477583,_0x407b03,_0x1f513b){f(_0x407b03||_0x1f513b,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x5c926d=k(_0x592454,_0x477583);if(Ci(_0x52253e['visibleWrites'],_0x5c926d))return null;{const _0xf9e35b=ve(_0x52253e['visibleWrites'],_0x5c926d);return Ti(_0xf9e35b)?_0x1f513b['getChild'](_0x477583):nt(_0xf9e35b,_0x1f513b['getChild'](_0x477583));}}function yu(_0x1feab8,_0x4bfe1d,_0x57b6bd,_0x433b08){const _0x18c1a4=k(_0x4bfe1d,_0x57b6bd),_0x3aaf05=$e(_0x1feab8['visibleWrites'],_0x18c1a4);if(_0x3aaf05!=null)return _0x3aaf05;if(_0x433b08['isCompleteForChild'](_0x57b6bd)){const _0x28ac1a=ve(_0x1feab8['visibleWrites'],_0x18c1a4);return nt(_0x28ac1a,_0x433b08['getNode']()['getImmediateChild'](_0x57b6bd));}else return null;}function vu(_0x585c05,_0x4dd77d){return $e(_0x585c05['visibleWrites'],_0x4dd77d);}function Eu(_0x27e422,_0x3074aa,_0x1014e2,_0xfe307b,_0x3af5bb,_0x177ea7,_0x32cc93){let _0x36a581;const _0x41b8c1=ve(_0x27e422['visibleWrites'],_0x3074aa),_0x10a951=$e(_0x41b8c1,w());if(_0x10a951!=null)_0x36a581=_0x10a951;else{if(_0x1014e2!=null)_0x36a581=nt(_0x41b8c1,_0x1014e2);else return[];}if(_0x36a581=_0x36a581['withIndex'](_0x32cc93),!_0x36a581['isEmpty']()&&!_0x36a581['isLeafNode']()){const _0x4aa31e=[],_0x3319a3=_0x32cc93['getCompare'](),_0x483634=_0x177ea7?_0x36a581['getReverseIteratorFrom'](_0xfe307b,_0x32cc93):_0x36a581['getIteratorFrom'](_0xfe307b,_0x32cc93);let _0x152c64=_0x483634['getNext']();for(;_0x152c64&&_0x4aa31e['length']<_0x3af5bb;)_0x3319a3(_0x152c64,_0xfe307b)!==0x0&&_0x4aa31e['push'](_0x152c64),_0x152c64=_0x483634['getNext']();return _0x4aa31e;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x2d860a,_0x10e744,_0x2d8c6a,_0x2ccaf2){return Vo(_0x2d860a['writeTree'],_0x2d860a['treePath'],_0x10e744,_0x2d8c6a,_0x2ccaf2);}function ns(_0x5aea35,_0x33bc81){return gu(_0x5aea35['writeTree'],_0x5aea35['treePath'],_0x33bc81);}function lr(_0x5e152d,_0x389234,_0x1f33d6,_0x1424f6){return mu(_0x5e152d['writeTree'],_0x5e152d['treePath'],_0x389234,_0x1f33d6,_0x1424f6);}function vn(_0x18f665,_0x59b02f){return vu(_0x18f665['writeTree'],k(_0x18f665['treePath'],_0x59b02f));}function wu(_0x5d8562,_0x50910d,_0xb403ef,_0x153ecf,_0x43a0d9,_0x3b6e54){return Eu(_0x5d8562['writeTree'],_0x5d8562['treePath'],_0x50910d,_0xb403ef,_0x153ecf,_0x43a0d9,_0x3b6e54);}function is(_0x57d6f8,_0x113e5c,_0x9057b4){return yu(_0x57d6f8['writeTree'],_0x57d6f8['treePath'],_0x113e5c,_0x9057b4);}function Ho(_0x33ba10,_0x10e357){return $o(k(_0x33ba10['treePath'],_0x10e357),_0x33ba10['writeTree']);}function $o(_0xd07451,_0x370b8e){return{'treePath':_0xd07451,'writeTree':_0x370b8e};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x458d8c){const _0x1a938f=_0x458d8c['type'],_0xab7634=_0x458d8c['childName'];f(_0x1a938f==='child_added'||_0x1a938f==='child_changed'||_0x1a938f==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0xab7634!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x38a18c=this['changeMap']['get'](_0xab7634);if(_0x38a18c){const _0x3231c2=_0x38a18c['type'];if(_0x1a938f==='child_added'&&_0x3231c2==='child_removed')this['changeMap']['set'](_0xab7634,Dt(_0xab7634,_0x458d8c['snapshotNode'],_0x38a18c['snapshotNode']));else{if(_0x1a938f==='child_removed'&&_0x3231c2==='child_added')this['changeMap']['delete'](_0xab7634);else{if(_0x1a938f==='child_removed'&&_0x3231c2==='child_changed')this['changeMap']['set'](_0xab7634,Ot(_0xab7634,_0x38a18c['oldSnap']));else{if(_0x1a938f==='child_changed'&&_0x3231c2==='child_added')this['changeMap']['set'](_0xab7634,et(_0xab7634,_0x458d8c['snapshotNode']));else{if(_0x1a938f==='child_changed'&&_0x3231c2==='child_changed')this['changeMap']['set'](_0xab7634,Dt(_0xab7634,_0x458d8c['snapshotNode'],_0x38a18c['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x458d8c+'\x20occurred\x20after\x20'+_0x38a18c);}}}}}else this['changeMap']['set'](_0xab7634,_0x458d8c);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x3bc20b){return null;}['getChildAfterChild'](_0x5d9fa0,_0x10b971,_0x7fcfc6){return null;}}const Go=new Tu();class ss{constructor(_0xf47d2b,_0x5f4393,_0x4112fa=null){this['writes_']=_0xf47d2b,this['viewCache_']=_0x5f4393,this['optCompleteServerCache_']=_0x4112fa;}['getCompleteChild'](_0x5c3691){const _0x546be6=this['viewCache_']['eventCache'];if(_0x546be6['isCompleteForChild'](_0x5c3691))return _0x546be6['getNode']()['getImmediateChild'](_0x5c3691);{const _0x5cb75a=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x5c3691,_0x5cb75a);}}['getChildAfterChild'](_0x343ce3,_0xb8600c,_0x31ea33){const _0x3e02aa=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x458745=wu(this['writes_'],_0x3e02aa,_0xb8600c,0x1,_0x31ea33,_0x343ce3);return _0x458745['length']===0x0?null:_0x458745[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x3b2d58){return{'filter':_0x3b2d58};}function bu(_0xaccb64,_0x5b6767){f(_0x5b6767['eventCache']['getNode']()['isIndexed'](_0xaccb64['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x5b6767['serverCache']['getNode']()['isIndexed'](_0xaccb64['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0xff666b,_0x4e4b8b,_0x369b84,_0x7cc593,_0x39409f){const _0x71483e=new Cu();let _0x3979bc,_0x469d69;if(_0x369b84['type']===j['OVERWRITE']){const _0x2180c6=_0x369b84;_0x2180c6['source']['fromUser']?_0x3979bc=Si(_0xff666b,_0x4e4b8b,_0x2180c6['path'],_0x2180c6['snap'],_0x7cc593,_0x39409f,_0x71483e):(f(_0x2180c6['source']['fromServer'],'Unknown\x20source.'),_0x469d69=_0x2180c6['source']['tagged']||_0x4e4b8b['serverCache']['isFiltered']()&&!v(_0x2180c6['path']),_0x3979bc=En(_0xff666b,_0x4e4b8b,_0x2180c6['path'],_0x2180c6['snap'],_0x7cc593,_0x39409f,_0x469d69,_0x71483e));}else{if(_0x369b84['type']===j['MERGE']){const _0x54c5bd=_0x369b84;_0x54c5bd['source']['fromUser']?_0x3979bc=ku(_0xff666b,_0x4e4b8b,_0x54c5bd['path'],_0x54c5bd['children'],_0x7cc593,_0x39409f,_0x71483e):(f(_0x54c5bd['source']['fromServer'],'Unknown\x20source.'),_0x469d69=_0x54c5bd['source']['tagged']||_0x4e4b8b['serverCache']['isFiltered'](),_0x3979bc=bi(_0xff666b,_0x4e4b8b,_0x54c5bd['path'],_0x54c5bd['children'],_0x7cc593,_0x39409f,_0x469d69,_0x71483e));}else{if(_0x369b84['type']===j['ACK_USER_WRITE']){const _0x39670b=_0x369b84;_0x39670b['revert']?_0x3979bc=Ou(_0xff666b,_0x4e4b8b,_0x39670b['path'],_0x7cc593,_0x39409f,_0x71483e):_0x3979bc=Nu(_0xff666b,_0x4e4b8b,_0x39670b['path'],_0x39670b['affectedTree'],_0x7cc593,_0x39409f,_0x71483e);}else{if(_0x369b84['type']===j['LISTEN_COMPLETE'])_0x3979bc=Pu(_0xff666b,_0x4e4b8b,_0x369b84['path'],_0x7cc593,_0x71483e);else throw rt('Unknown\x20operation\x20type:\x20'+_0x369b84['type']);}}}const _0x16e082=_0x71483e['getChanges']();return Au(_0x4e4b8b,_0x3979bc,_0x16e082),{'viewCache':_0x3979bc,'changes':_0x16e082};}function Au(_0x228cf6,_0x356228,_0x2ef5b9){const _0x3f58ac=_0x356228['eventCache'];if(_0x3f58ac['isFullyInitialized']()){const _0x2ee599=_0x3f58ac['getNode']()['isLeafNode']()||_0x3f58ac['getNode']()['isEmpty'](),_0x297274=mn(_0x228cf6);(_0x2ef5b9['length']>0x0||!_0x228cf6['eventCache']['isFullyInitialized']()||_0x2ee599&&!_0x3f58ac['getNode']()['equals'](_0x297274)||!_0x3f58ac['getNode']()['getPriority']()['equals'](_0x297274['getPriority']()))&&_0x2ef5b9['push'](Lo(mn(_0x356228)));}}function qo(_0x1b77e5,_0x85d90f,_0x43d334,_0x1bcb5e,_0x51efc7,_0x1a8b33){const _0x4759f0=_0x85d90f['eventCache'];if(vn(_0x1bcb5e,_0x43d334)!=null)return _0x85d90f;{let _0x38fff9,_0x2bde46;if(v(_0x43d334)){if(f(_0x85d90f['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x85d90f['serverCache']['isFiltered']()){const _0x5eb4fd=We(_0x85d90f),_0x544772=_0x5eb4fd instanceof g?_0x5eb4fd:g['EMPTY_NODE'],_0x85a49a=ns(_0x1bcb5e,_0x544772);_0x38fff9=_0x1b77e5['filter']['updateFullNode'](_0x85d90f['eventCache']['getNode'](),_0x85a49a,_0x1a8b33);}else{const _0x2f3a6e=yn(_0x1bcb5e,We(_0x85d90f));_0x38fff9=_0x1b77e5['filter']['updateFullNode'](_0x85d90f['eventCache']['getNode'](),_0x2f3a6e,_0x1a8b33);}}else{const _0x2f813b=y(_0x43d334);if(_0x2f813b==='.priority'){f(we(_0x43d334)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x4fc922=_0x4759f0['getNode']();_0x2bde46=_0x85d90f['serverCache']['getNode']();const _0x1703b0=lr(_0x1bcb5e,_0x43d334,_0x4fc922,_0x2bde46);_0x1703b0!=null?_0x38fff9=_0x1b77e5['filter']['updatePriority'](_0x4fc922,_0x1703b0):_0x38fff9=_0x4759f0['getNode']();}else{const _0x4ef391=b(_0x43d334);let _0x2dc0a3;if(_0x4759f0['isCompleteForChild'](_0x2f813b)){_0x2bde46=_0x85d90f['serverCache']['getNode']();const _0x2ddfb0=lr(_0x1bcb5e,_0x43d334,_0x4759f0['getNode'](),_0x2bde46);_0x2ddfb0!=null?_0x2dc0a3=_0x4759f0['getNode']()['getImmediateChild'](_0x2f813b)['updateChild'](_0x4ef391,_0x2ddfb0):_0x2dc0a3=_0x4759f0['getNode']()['getImmediateChild'](_0x2f813b);}else _0x2dc0a3=is(_0x1bcb5e,_0x2f813b,_0x85d90f['serverCache']);_0x2dc0a3!=null?_0x38fff9=_0x1b77e5['filter']['updateChild'](_0x4759f0['getNode'](),_0x2f813b,_0x2dc0a3,_0x4ef391,_0x51efc7,_0x1a8b33):_0x38fff9=_0x4759f0['getNode']();}}return Tt(_0x85d90f,_0x38fff9,_0x4759f0['isFullyInitialized']()||v(_0x43d334),_0x1b77e5['filter']['filtersNodes']());}}function En(_0xae895f,_0x36fb22,_0x384cbd,_0x5c69bd,_0x12daed,_0x5b83ba,_0x3ce834,_0x4070b2){const _0x32f06c=_0x36fb22['serverCache'];let _0x33a468;const _0x441054=_0x3ce834?_0xae895f['filter']:_0xae895f['filter']['getIndexedFilter']();if(v(_0x384cbd))_0x33a468=_0x441054['updateFullNode'](_0x32f06c['getNode'](),_0x5c69bd,null);else{if(_0x441054['filtersNodes']()&&!_0x32f06c['isFiltered']()){const _0xc4852f=_0x32f06c['getNode']()['updateChild'](_0x384cbd,_0x5c69bd);_0x33a468=_0x441054['updateFullNode'](_0x32f06c['getNode'](),_0xc4852f,null);}else{const _0x2687a4=y(_0x384cbd);if(!_0x32f06c['isCompleteForPath'](_0x384cbd)&&we(_0x384cbd)>0x1)return _0x36fb22;const _0x5cfacd=b(_0x384cbd),_0x5a9d3e=_0x32f06c['getNode']()['getImmediateChild'](_0x2687a4)['updateChild'](_0x5cfacd,_0x5c69bd);_0x2687a4==='.priority'?_0x33a468=_0x441054['updatePriority'](_0x32f06c['getNode'](),_0x5a9d3e):_0x33a468=_0x441054['updateChild'](_0x32f06c['getNode'](),_0x2687a4,_0x5a9d3e,_0x5cfacd,Go,null);}}const _0x2e2b4f=Uo(_0x36fb22,_0x33a468,_0x32f06c['isFullyInitialized']()||v(_0x384cbd),_0x441054['filtersNodes']()),_0x1422a4=new ss(_0x12daed,_0x2e2b4f,_0x5b83ba);return qo(_0xae895f,_0x2e2b4f,_0x384cbd,_0x12daed,_0x1422a4,_0x4070b2);}function Si(_0x642514,_0x38785d,_0x2dcc96,_0x2c7137,_0x46ec34,_0x63d6bb,_0x2a73a4){const _0x2793a7=_0x38785d['eventCache'];let _0x59d581,_0x16c9fc;const _0x4a9402=new ss(_0x46ec34,_0x38785d,_0x63d6bb);if(v(_0x2dcc96))_0x16c9fc=_0x642514['filter']['updateFullNode'](_0x38785d['eventCache']['getNode'](),_0x2c7137,_0x2a73a4),_0x59d581=Tt(_0x38785d,_0x16c9fc,!0x0,_0x642514['filter']['filtersNodes']());else{const _0x527e6c=y(_0x2dcc96);if(_0x527e6c==='.priority')_0x16c9fc=_0x642514['filter']['updatePriority'](_0x38785d['eventCache']['getNode'](),_0x2c7137),_0x59d581=Tt(_0x38785d,_0x16c9fc,_0x2793a7['isFullyInitialized'](),_0x2793a7['isFiltered']());else{const _0x1e77e0=b(_0x2dcc96),_0x1a959d=_0x2793a7['getNode']()['getImmediateChild'](_0x527e6c);let _0x4ef9b2;if(v(_0x1e77e0))_0x4ef9b2=_0x2c7137;else{const _0x394fcb=_0x4a9402['getCompleteChild'](_0x527e6c);_0x394fcb!=null?zi(_0x1e77e0)==='.priority'&&_0x394fcb['getChild'](Ro(_0x1e77e0))['isEmpty']()?_0x4ef9b2=_0x394fcb:_0x4ef9b2=_0x394fcb['updateChild'](_0x1e77e0,_0x2c7137):_0x4ef9b2=g['EMPTY_NODE'];}if(_0x1a959d['equals'](_0x4ef9b2))_0x59d581=_0x38785d;else{const _0x363cae=_0x642514['filter']['updateChild'](_0x2793a7['getNode'](),_0x527e6c,_0x4ef9b2,_0x1e77e0,_0x4a9402,_0x2a73a4);_0x59d581=Tt(_0x38785d,_0x363cae,_0x2793a7['isFullyInitialized'](),_0x642514['filter']['filtersNodes']());}}}return _0x59d581;}function hr(_0xeb00f8,_0x183ae8){return _0xeb00f8['eventCache']['isCompleteForChild'](_0x183ae8);}function ku(_0x21f2d9,_0x45d9fa,_0x4b2402,_0x54dcde,_0x33fc0d,_0x44bccb,_0x31fbcf){let _0x3310c4=_0x45d9fa;return _0x54dcde['foreach']((_0x2153c8,_0xf4c767)=>{const _0xf3ec64=k(_0x4b2402,_0x2153c8);hr(_0x45d9fa,y(_0xf3ec64))&&(_0x3310c4=Si(_0x21f2d9,_0x3310c4,_0xf3ec64,_0xf4c767,_0x33fc0d,_0x44bccb,_0x31fbcf));}),_0x54dcde['foreach']((_0x5993d0,_0x17feaf)=>{const _0x3f104b=k(_0x4b2402,_0x5993d0);hr(_0x45d9fa,y(_0x3f104b))||(_0x3310c4=Si(_0x21f2d9,_0x3310c4,_0x3f104b,_0x17feaf,_0x33fc0d,_0x44bccb,_0x31fbcf));}),_0x3310c4;}function ur(_0x126330,_0x45a575,_0x3f64c1){return _0x3f64c1['foreach']((_0x3350ca,_0x1c5f1d)=>{_0x45a575=_0x45a575['updateChild'](_0x3350ca,_0x1c5f1d);}),_0x45a575;}function bi(_0x2ec9aa,_0x63e1b,_0x5e9cbc,_0x44fb0d,_0x10c217,_0x504453,_0x47e438,_0x4705db){if(_0x63e1b['serverCache']['getNode']()['isEmpty']()&&!_0x63e1b['serverCache']['isFullyInitialized']())return _0x63e1b;let _0x38eeaf=_0x63e1b,_0xe8a6c8;v(_0x5e9cbc)?_0xe8a6c8=_0x44fb0d:_0xe8a6c8=new S(null)['setTree'](_0x5e9cbc,_0x44fb0d);const _0x2d91ae=_0x63e1b['serverCache']['getNode']();return _0xe8a6c8['children']['inorderTraversal']((_0x708085,_0x1a6142)=>{if(_0x2d91ae['hasChild'](_0x708085)){const _0x1f35a9=_0x63e1b['serverCache']['getNode']()['getImmediateChild'](_0x708085),_0x3cea3e=ur(_0x2ec9aa,_0x1f35a9,_0x1a6142);_0x38eeaf=En(_0x2ec9aa,_0x38eeaf,new C(_0x708085),_0x3cea3e,_0x10c217,_0x504453,_0x47e438,_0x4705db);}}),_0xe8a6c8['children']['inorderTraversal']((_0x24bd9a,_0x355d96)=>{const _0x9514c5=!_0x63e1b['serverCache']['isCompleteForChild'](_0x24bd9a)&&_0x355d96['value']===null;if(!_0x2d91ae['hasChild'](_0x24bd9a)&&!_0x9514c5){const _0x1803ae=_0x63e1b['serverCache']['getNode']()['getImmediateChild'](_0x24bd9a),_0x749585=ur(_0x2ec9aa,_0x1803ae,_0x355d96);_0x38eeaf=En(_0x2ec9aa,_0x38eeaf,new C(_0x24bd9a),_0x749585,_0x10c217,_0x504453,_0x47e438,_0x4705db);}}),_0x38eeaf;}function Nu(_0x3be1d5,_0x6978a0,_0x1de6f6,_0x277428,_0x2fb2a4,_0x3f67f1,_0x5aaa2){if(vn(_0x2fb2a4,_0x1de6f6)!=null)return _0x6978a0;const _0x54068f=_0x6978a0['serverCache']['isFiltered'](),_0x43cd3f=_0x6978a0['serverCache'];if(_0x277428['value']!=null){if(v(_0x1de6f6)&&_0x43cd3f['isFullyInitialized']()||_0x43cd3f['isCompleteForPath'](_0x1de6f6))return En(_0x3be1d5,_0x6978a0,_0x1de6f6,_0x43cd3f['getNode']()['getChild'](_0x1de6f6),_0x2fb2a4,_0x3f67f1,_0x54068f,_0x5aaa2);if(v(_0x1de6f6)){let _0x3a2d59=new S(null);return _0x43cd3f['getNode']()['forEachChild'](ye,(_0x30516b,_0x13db4a)=>{_0x3a2d59=_0x3a2d59['set'](new C(_0x30516b),_0x13db4a);}),bi(_0x3be1d5,_0x6978a0,_0x1de6f6,_0x3a2d59,_0x2fb2a4,_0x3f67f1,_0x54068f,_0x5aaa2);}else return _0x6978a0;}else{let _0x5ec6d9=new S(null);return _0x277428['foreach']((_0x2ee26b,_0x380c86)=>{const _0x3eb0ce=k(_0x1de6f6,_0x2ee26b);_0x43cd3f['isCompleteForPath'](_0x3eb0ce)&&(_0x5ec6d9=_0x5ec6d9['set'](_0x2ee26b,_0x43cd3f['getNode']()['getChild'](_0x3eb0ce)));}),bi(_0x3be1d5,_0x6978a0,_0x1de6f6,_0x5ec6d9,_0x2fb2a4,_0x3f67f1,_0x54068f,_0x5aaa2);}}function Pu(_0x526a79,_0x5c0e51,_0x5e1b44,_0x36efb1,_0x312dcd){const _0x2df1a6=_0x5c0e51['serverCache'],_0x899ae2=Uo(_0x5c0e51,_0x2df1a6['getNode'](),_0x2df1a6['isFullyInitialized']()||v(_0x5e1b44),_0x2df1a6['isFiltered']());return qo(_0x526a79,_0x899ae2,_0x5e1b44,_0x36efb1,Go,_0x312dcd);}function Ou(_0x2aa8db,_0xe5296,_0x37392b,_0x21172c,_0x268fe6,_0x1f1d49){let _0x48c4ad;if(vn(_0x21172c,_0x37392b)!=null)return _0xe5296;{const _0x3fc68e=new ss(_0x21172c,_0xe5296,_0x268fe6),_0x386dae=_0xe5296['eventCache']['getNode']();let _0x31cab9;if(v(_0x37392b)||y(_0x37392b)==='.priority'){let _0x48d1ba;if(_0xe5296['serverCache']['isFullyInitialized']())_0x48d1ba=yn(_0x21172c,We(_0xe5296));else{const _0x5eafcf=_0xe5296['serverCache']['getNode']();f(_0x5eafcf instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x48d1ba=ns(_0x21172c,_0x5eafcf);}_0x48d1ba=_0x48d1ba,_0x31cab9=_0x2aa8db['filter']['updateFullNode'](_0x386dae,_0x48d1ba,_0x1f1d49);}else{const _0x587486=y(_0x37392b);let _0x38a169=is(_0x21172c,_0x587486,_0xe5296['serverCache']);_0x38a169==null&&_0xe5296['serverCache']['isCompleteForChild'](_0x587486)&&(_0x38a169=_0x386dae['getImmediateChild'](_0x587486)),_0x38a169!=null?_0x31cab9=_0x2aa8db['filter']['updateChild'](_0x386dae,_0x587486,_0x38a169,b(_0x37392b),_0x3fc68e,_0x1f1d49):_0xe5296['eventCache']['getNode']()['hasChild'](_0x587486)?_0x31cab9=_0x2aa8db['filter']['updateChild'](_0x386dae,_0x587486,g['EMPTY_NODE'],b(_0x37392b),_0x3fc68e,_0x1f1d49):_0x31cab9=_0x386dae,_0x31cab9['isEmpty']()&&_0xe5296['serverCache']['isFullyInitialized']()&&(_0x48c4ad=yn(_0x21172c,We(_0xe5296)),_0x48c4ad['isLeafNode']()&&(_0x31cab9=_0x2aa8db['filter']['updateFullNode'](_0x31cab9,_0x48c4ad,_0x1f1d49)));}return _0x48c4ad=_0xe5296['serverCache']['isFullyInitialized']()||vn(_0x21172c,w())!=null,Tt(_0xe5296,_0x31cab9,_0x48c4ad,_0x2aa8db['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x22ebf8,_0x18cc43){this['query_']=_0x22ebf8,this['eventRegistrations_']=[];const _0x2546e4=this['query_']['_queryParams'],_0xdadc71=new Ji(_0x2546e4['getIndex']()),_0x2f1a07=Kh(_0x2546e4);this['processor_']=Su(_0x2f1a07);const _0x23bb69=_0x18cc43['serverCache'],_0x481e09=_0x18cc43['eventCache'],_0x18bc64=_0xdadc71['updateFullNode'](g['EMPTY_NODE'],_0x23bb69['getNode'](),null),_0x409411=_0x2f1a07['updateFullNode'](g['EMPTY_NODE'],_0x481e09['getNode'](),null),_0x8cc2b7=new Ce(_0x18bc64,_0x23bb69['isFullyInitialized'](),_0xdadc71['filtersNodes']()),_0x42e703=new Ce(_0x409411,_0x481e09['isFullyInitialized'](),_0x2f1a07['filtersNodes']());this['viewCache_']=Mn(_0x42e703,_0x8cc2b7),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x5d797c){return _0x5d797c['viewCache_']['serverCache']['getNode']();}function Lu(_0x3a651d){return mn(_0x3a651d['viewCache_']);}function xu(_0x4a8eaa,_0x302c98){const _0x533f39=We(_0x4a8eaa['viewCache_']);return _0x533f39&&(_0x4a8eaa['query']['_queryParams']['loadsAllData']()||!v(_0x302c98)&&!_0x533f39['getImmediateChild'](y(_0x302c98))['isEmpty']())?_0x533f39['getChild'](_0x302c98):null;}function dr(_0x186e30){return _0x186e30['eventRegistrations_']['length']===0x0;}function Fu(_0x35a45a,_0x369773){_0x35a45a['eventRegistrations_']['push'](_0x369773);}function fr(_0x370fea,_0x1de1e1,_0x440a90){const _0x3ec38a=[];if(_0x440a90){f(_0x1de1e1==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x511327=_0x370fea['query']['_path'];_0x370fea['eventRegistrations_']['forEach'](_0x2b5fcb=>{const _0x2c4406=_0x2b5fcb['createCancelEvent'](_0x440a90,_0x511327);_0x2c4406&&_0x3ec38a['push'](_0x2c4406);});}if(_0x1de1e1){let _0x23f6cb=[];for(let _0x593daf=0x0;_0x593daf<_0x370fea['eventRegistrations_']['length'];++_0x593daf){const _0x1e1e0c=_0x370fea['eventRegistrations_'][_0x593daf];if(!_0x1e1e0c['matches'](_0x1de1e1))_0x23f6cb['push'](_0x1e1e0c);else{if(_0x1de1e1['hasAnyCallback']()){_0x23f6cb=_0x23f6cb['concat'](_0x370fea['eventRegistrations_']['slice'](_0x593daf+0x1));break;}}}_0x370fea['eventRegistrations_']=_0x23f6cb;}else _0x370fea['eventRegistrations_']=[];return _0x3ec38a;}function pr(_0x1fc48f,_0x26ebaf,_0x4d0cd8,_0x293f3a){_0x26ebaf['type']===j['MERGE']&&_0x26ebaf['source']['queryId']!==null&&(f(We(_0x1fc48f['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x1fc48f['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x4a681c=_0x1fc48f['viewCache_'],_0x516350=Ru(_0x1fc48f['processor_'],_0x4a681c,_0x26ebaf,_0x4d0cd8,_0x293f3a);return bu(_0x1fc48f['processor_'],_0x516350['viewCache']),f(_0x516350['viewCache']['serverCache']['isFullyInitialized']()||!_0x4a681c['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x1fc48f['viewCache_']=_0x516350['viewCache'],zo(_0x1fc48f,_0x516350['changes'],_0x516350['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x5aa0d8,_0x329677){const _0x3f020c=_0x5aa0d8['viewCache_']['eventCache'],_0x19ee5e=[];return _0x3f020c['getNode']()['isLeafNode']()||_0x3f020c['getNode']()['forEachChild'](R,(_0xe3cf03,_0x1b3a9a)=>{_0x19ee5e['push'](et(_0xe3cf03,_0x1b3a9a));}),_0x3f020c['isFullyInitialized']()&&_0x19ee5e['push'](Lo(_0x3f020c['getNode']())),zo(_0x5aa0d8,_0x19ee5e,_0x3f020c['getNode'](),_0x329677);}function zo(_0x19e126,_0x35ad2c,_0x541724,_0x526f9c){const _0x4e794d=_0x526f9c?[_0x526f9c]:_0x19e126['eventRegistrations_'];return ru(_0x19e126['eventGenerator_'],_0x35ad2c,_0x541724,_0x4e794d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x222a82){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x222a82;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x3ae5cb){return _0x3ae5cb['views']['size']===0x0;}function rs(_0x461729,_0x89639b,_0x2b6124,_0xe4021c){const _0x57e4ab=_0x89639b['source']['queryId'];if(_0x57e4ab!==null){const _0x371d54=_0x461729['views']['get'](_0x57e4ab);return f(_0x371d54!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x371d54,_0x89639b,_0x2b6124,_0xe4021c);}else{let _0x37d0f8=[];for(const _0x34d2ba of _0x461729['views']['values']())_0x37d0f8=_0x37d0f8['concat'](pr(_0x34d2ba,_0x89639b,_0x2b6124,_0xe4021c));return _0x37d0f8;}}function Ko(_0x67c73a,_0x26a903,_0x31b29d,_0x2b5052,_0x31513b){const _0x301d23=_0x26a903['_queryIdentifier'],_0x49cd5c=_0x67c73a['views']['get'](_0x301d23);if(!_0x49cd5c){let _0x408896=yn(_0x31b29d,_0x31513b?_0x2b5052:null),_0x469a43=!0x1;_0x408896?_0x469a43=!0x0:_0x2b5052 instanceof g?(_0x408896=ns(_0x31b29d,_0x2b5052),_0x469a43=!0x1):(_0x408896=g['EMPTY_NODE'],_0x469a43=!0x1);const _0x4d3323=Mn(new Ce(_0x408896,_0x469a43,!0x1),new Ce(_0x2b5052,_0x31513b,!0x1));return new Du(_0x26a903,_0x4d3323);}return _0x49cd5c;}function Hu(_0x46d16a,_0x3ffbdb,_0x61ff52,_0x104061,_0x3be676,_0x104d18){const _0x283b2d=Ko(_0x46d16a,_0x3ffbdb,_0x104061,_0x3be676,_0x104d18);return _0x46d16a['views']['has'](_0x3ffbdb['_queryIdentifier'])||_0x46d16a['views']['set'](_0x3ffbdb['_queryIdentifier'],_0x283b2d),Fu(_0x283b2d,_0x61ff52),Uu(_0x283b2d,_0x61ff52);}function $u(_0x516008,_0x4a9bbe,_0x7b61bc,_0x4329e1){const _0x42b769=_0x4a9bbe['_queryIdentifier'],_0x4964ef=[];let _0x4d2b62=[];const _0x58710f=Te(_0x516008);if(_0x42b769==='default'){for(const [_0x10a938,_0x1cd392]of _0x516008['views']['entries']())_0x4d2b62=_0x4d2b62['concat'](fr(_0x1cd392,_0x7b61bc,_0x4329e1)),dr(_0x1cd392)&&(_0x516008['views']['delete'](_0x10a938),_0x1cd392['query']['_queryParams']['loadsAllData']()||_0x4964ef['push'](_0x1cd392['query']));}else{const _0x537d5f=_0x516008['views']['get'](_0x42b769);_0x537d5f&&(_0x4d2b62=_0x4d2b62['concat'](fr(_0x537d5f,_0x7b61bc,_0x4329e1)),dr(_0x537d5f)&&(_0x516008['views']['delete'](_0x42b769),_0x537d5f['query']['_queryParams']['loadsAllData']()||_0x4964ef['push'](_0x537d5f['query'])));}return _0x58710f&&!Te(_0x516008)&&_0x4964ef['push'](new(Bu())(_0x4a9bbe['_repo'],_0x4a9bbe['_path'])),{'removed':_0x4964ef,'events':_0x4d2b62};}function Yo(_0x2336a3){const _0x1606a2=[];for(const _0x5ae788 of _0x2336a3['views']['values']())_0x5ae788['query']['_queryParams']['loadsAllData']()||_0x1606a2['push'](_0x5ae788);return _0x1606a2;}function Ee(_0x3add40,_0x516a81){let _0x35f2a9=null;for(const _0x23d9d8 of _0x3add40['views']['values']())_0x35f2a9=_0x35f2a9||xu(_0x23d9d8,_0x516a81);return _0x35f2a9;}function Qo(_0x1a2ead,_0x4e1b7d){if(_0x4e1b7d['_queryParams']['loadsAllData']())return xn(_0x1a2ead);{const _0x9c753d=_0x4e1b7d['_queryIdentifier'];return _0x1a2ead['views']['get'](_0x9c753d);}}function Jo(_0x147262,_0x18852e){return Qo(_0x147262,_0x18852e)!=null;}function Te(_0x65220a){return xn(_0x65220a)!=null;}function xn(_0x1dcefe){for(const _0x4abd4c of _0x1dcefe['views']['values']())if(_0x4abd4c['query']['_queryParams']['loadsAllData']())return _0x4abd4c;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x4fb856){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x4fb856;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x3a65d0){this['listenProvider_']=_0x3a65d0,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x578129,_0x2fbede,_0x2c7d22,_0x26e7ec,_0x513c5e){return lu(_0x578129['pendingWriteTree_'],_0x2fbede,_0x2c7d22,_0x26e7ec,_0x513c5e),_0x513c5e?ut(_0x578129,new Ue(Zi(),_0x2fbede,_0x2c7d22)):[];}function ju(_0x5d1247,_0x2b4a56,_0x4a9435,_0x3febbb){hu(_0x5d1247['pendingWriteTree_'],_0x2b4a56,_0x4a9435,_0x3febbb);const _0x4a9f8d=S['fromObject'](_0x4a9435);return ut(_0x5d1247,new tt(Zi(),_0x2b4a56,_0x4a9f8d));}function pe(_0xc37f53,_0x34a4eb,_0x305290=!0x1){const _0x5301a3=uu(_0xc37f53['pendingWriteTree_'],_0x34a4eb);if(du(_0xc37f53['pendingWriteTree_'],_0x34a4eb)){let _0x21e65b=new S(null);return _0x5301a3['snap']!=null?_0x21e65b=_0x21e65b['set'](w(),!0x0):x(_0x5301a3['children'],_0x5eca82=>{_0x21e65b=_0x21e65b['set'](new C(_0x5eca82),!0x0);}),ut(_0xc37f53,new gn(_0x5301a3['path'],_0x21e65b,_0x305290));}else return[];}function Gt(_0x87b6a5,_0x4a7618,_0x564c68){return ut(_0x87b6a5,new Ue(es(),_0x4a7618,_0x564c68));}function Ku(_0x2a64af,_0x2bd89e,_0x2170bd){const _0x460171=S['fromObject'](_0x2170bd);return ut(_0x2a64af,new tt(es(),_0x2bd89e,_0x460171));}function Yu(_0x3ecb48,_0x4354fe){return ut(_0x3ecb48,new Lt(es(),_0x4354fe));}function Qu(_0x37f58b,_0x12a0f2,_0x2528a4){const _0x53284e=as(_0x37f58b,_0x2528a4);if(_0x53284e){const _0x8fa0d3=cs(_0x53284e),_0x4759d3=_0x8fa0d3['path'],_0x1074c2=_0x8fa0d3['queryId'],_0x3feccd=F(_0x4759d3,_0x12a0f2),_0x40db7e=new Lt(ts(_0x1074c2),_0x3feccd);return ls(_0x37f58b,_0x4759d3,_0x40db7e);}else return[];}function Cn(_0x3425ff,_0x470ae4,_0x1ff039,_0x4a6d93,_0xf2c972=!0x1){const _0x18fd13=_0x470ae4['_path'],_0x572870=_0x3425ff['syncPointTree_']['get'](_0x18fd13);let _0x75232d=[];if(_0x572870&&(_0x470ae4['_queryIdentifier']==='default'||Jo(_0x572870,_0x470ae4))){const _0x24e906=$u(_0x572870,_0x470ae4,_0x1ff039,_0x4a6d93);Vu(_0x572870)&&(_0x3425ff['syncPointTree_']=_0x3425ff['syncPointTree_']['remove'](_0x18fd13));const _0x4220e4=_0x24e906['removed'];if(_0x75232d=_0x24e906['events'],!_0xf2c972){const _0x16bb55=_0x4220e4['findIndex'](_0x39eee4=>_0x39eee4['_queryParams']['loadsAllData']())!==-0x1,_0x3924be=_0x3425ff['syncPointTree_']['findOnPath'](_0x18fd13,(_0x599614,_0x24377b)=>Te(_0x24377b));if(_0x16bb55&&!_0x3924be){const _0x2c82e8=_0x3425ff['syncPointTree_']['subtree'](_0x18fd13);if(!_0x2c82e8['isEmpty']()){const _0x135ec5=Zu(_0x2c82e8);for(let _0x15d85c=0x0;_0x15d85c<_0x135ec5['length'];++_0x15d85c){const _0x2d7ceb=_0x135ec5[_0x15d85c],_0x5759f0=_0x2d7ceb['query'],_0x3c2744=ta(_0x3425ff,_0x2d7ceb);_0x3425ff['listenProvider_']['startListening'](bt(_0x5759f0),xt(_0x3425ff,_0x5759f0),_0x3c2744['hashFn'],_0x3c2744['onComplete']);}}}!_0x3924be&&_0x4220e4['length']>0x0&&!_0x4a6d93&&(_0x16bb55?_0x3425ff['listenProvider_']['stopListening'](bt(_0x470ae4),null):_0x4220e4['forEach'](_0x10b485=>{const _0x351c74=_0x3425ff['queryToTagMap']['get'](Un(_0x10b485));_0x3425ff['listenProvider_']['stopListening'](bt(_0x10b485),_0x351c74);}));}ed(_0x3425ff,_0x4220e4);}return _0x75232d;}function Xo(_0x51db63,_0x49e130,_0x10baa7,_0x264a68){const _0x17a85d=as(_0x51db63,_0x264a68);if(_0x17a85d!=null){const _0x4c7bca=cs(_0x17a85d),_0x3a4e77=_0x4c7bca['path'],_0x4f1989=_0x4c7bca['queryId'],_0x151661=F(_0x3a4e77,_0x49e130),_0x2b23b4=new Ue(ts(_0x4f1989),_0x151661,_0x10baa7);return ls(_0x51db63,_0x3a4e77,_0x2b23b4);}else return[];}function Ju(_0x237833,_0x23ac95,_0x27f4d5,_0x3fae0c){const _0x1b523d=as(_0x237833,_0x3fae0c);if(_0x1b523d){const _0x3745ba=cs(_0x1b523d),_0x440ea8=_0x3745ba['path'],_0x265fa2=_0x3745ba['queryId'],_0x5bfb59=F(_0x440ea8,_0x23ac95),_0x1a7dca=S['fromObject'](_0x27f4d5),_0x56bb55=new tt(ts(_0x265fa2),_0x5bfb59,_0x1a7dca);return ls(_0x237833,_0x440ea8,_0x56bb55);}else return[];}function Ri(_0x135626,_0xd2383e,_0x10ba12,_0x3aea9c=!0x1){const _0x388c3b=_0xd2383e['_path'];let _0x4c1ea9=null,_0xde71f8=!0x1;_0x135626['syncPointTree_']['foreachOnPath'](_0x388c3b,(_0x529eb3,_0xa73179)=>{const _0x3e2473=F(_0x529eb3,_0x388c3b);_0x4c1ea9=_0x4c1ea9||Ee(_0xa73179,_0x3e2473),_0xde71f8=_0xde71f8||Te(_0xa73179);});let _0x1d7aad=_0x135626['syncPointTree_']['get'](_0x388c3b);_0x1d7aad?(_0xde71f8=_0xde71f8||Te(_0x1d7aad),_0x4c1ea9=_0x4c1ea9||Ee(_0x1d7aad,w())):(_0x1d7aad=new jo(),_0x135626['syncPointTree_']=_0x135626['syncPointTree_']['set'](_0x388c3b,_0x1d7aad));let _0x4df265;_0x4c1ea9!=null?_0x4df265=!0x0:(_0x4df265=!0x1,_0x4c1ea9=g['EMPTY_NODE'],_0x135626['syncPointTree_']['subtree'](_0x388c3b)['foreachChild']((_0x14d1a7,_0x319221)=>{const _0x1c9be1=Ee(_0x319221,w());_0x1c9be1&&(_0x4c1ea9=_0x4c1ea9['updateImmediateChild'](_0x14d1a7,_0x1c9be1));}));const _0x329122=Jo(_0x1d7aad,_0xd2383e);if(!_0x329122&&!_0xd2383e['_queryParams']['loadsAllData']()){const _0x2decc2=Un(_0xd2383e);f(!_0x135626['queryToTagMap']['has'](_0x2decc2),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x41e2e1=td();_0x135626['queryToTagMap']['set'](_0x2decc2,_0x41e2e1),_0x135626['tagToQueryMap']['set'](_0x41e2e1,_0x2decc2);}const _0x5dcd4b=Ln(_0x135626['pendingWriteTree_'],_0x388c3b);let _0x572062=Hu(_0x1d7aad,_0xd2383e,_0x10ba12,_0x5dcd4b,_0x4c1ea9,_0x4df265);if(!_0x329122&&!_0xde71f8&&!_0x3aea9c){const _0xebc523=Qo(_0x1d7aad,_0xd2383e);_0x572062=_0x572062['concat'](nd(_0x135626,_0xd2383e,_0xebc523));}return _0x572062;}function Fn(_0x3daee5,_0x2beba6,_0x2ea186){const _0x21beb1=_0x3daee5['pendingWriteTree_'],_0x5abf85=_0x3daee5['syncPointTree_']['findOnPath'](_0x2beba6,(_0x3ce9e2,_0x5bf1b0)=>{const _0x4cf62e=F(_0x3ce9e2,_0x2beba6),_0x5d82c8=Ee(_0x5bf1b0,_0x4cf62e);if(_0x5d82c8)return _0x5d82c8;});return Vo(_0x21beb1,_0x2beba6,_0x5abf85,_0x2ea186,!0x0);}function Xu(_0x2cca8f,_0x30d85f){const _0x56e6fd=_0x30d85f['_path'];let _0x5e714e=null;_0x2cca8f['syncPointTree_']['foreachOnPath'](_0x56e6fd,(_0xd5ebc6,_0x51f46f)=>{const _0x5605c3=F(_0xd5ebc6,_0x56e6fd);_0x5e714e=_0x5e714e||Ee(_0x51f46f,_0x5605c3);});let _0x3cd7dc=_0x2cca8f['syncPointTree_']['get'](_0x56e6fd);_0x3cd7dc?_0x5e714e=_0x5e714e||Ee(_0x3cd7dc,w()):(_0x3cd7dc=new jo(),_0x2cca8f['syncPointTree_']=_0x2cca8f['syncPointTree_']['set'](_0x56e6fd,_0x3cd7dc));const _0x1d447e=_0x5e714e!=null,_0x5652d2=_0x1d447e?new Ce(_0x5e714e,!0x0,!0x1):null,_0x411126=Ln(_0x2cca8f['pendingWriteTree_'],_0x30d85f['_path']),_0x3f18a8=Ko(_0x3cd7dc,_0x30d85f,_0x411126,_0x1d447e?_0x5652d2['getNode']():g['EMPTY_NODE'],_0x1d447e);return Lu(_0x3f18a8);}function ut(_0x2e070d,_0xe0109){return Zo(_0xe0109,_0x2e070d['syncPointTree_'],null,Ln(_0x2e070d['pendingWriteTree_'],w()));}function Zo(_0x3c0523,_0x2109a1,_0x4c3838,_0x459342){if(v(_0x3c0523['path']))return ea(_0x3c0523,_0x2109a1,_0x4c3838,_0x459342);{const _0xcc0240=_0x2109a1['get'](w());_0x4c3838==null&&_0xcc0240!=null&&(_0x4c3838=Ee(_0xcc0240,w()));let _0x5b5700=[];const _0x3bee89=y(_0x3c0523['path']),_0x3f6753=_0x3c0523['operationForChild'](_0x3bee89),_0x2c8374=_0x2109a1['children']['get'](_0x3bee89);if(_0x2c8374&&_0x3f6753){const _0x153b3e=_0x4c3838?_0x4c3838['getImmediateChild'](_0x3bee89):null,_0x2884d4=Ho(_0x459342,_0x3bee89);_0x5b5700=_0x5b5700['concat'](Zo(_0x3f6753,_0x2c8374,_0x153b3e,_0x2884d4));}return _0xcc0240&&(_0x5b5700=_0x5b5700['concat'](rs(_0xcc0240,_0x3c0523,_0x459342,_0x4c3838))),_0x5b5700;}}function ea(_0x47aae3,_0x534539,_0x675ac2,_0x52ded2){const _0x38f5e7=_0x534539['get'](w());_0x675ac2==null&&_0x38f5e7!=null&&(_0x675ac2=Ee(_0x38f5e7,w()));let _0x188fb4=[];return _0x534539['children']['inorderTraversal']((_0x1d199e,_0x3120d3)=>{const _0x534b48=_0x675ac2?_0x675ac2['getImmediateChild'](_0x1d199e):null,_0x487538=Ho(_0x52ded2,_0x1d199e),_0x4893c0=_0x47aae3['operationForChild'](_0x1d199e);_0x4893c0&&(_0x188fb4=_0x188fb4['concat'](ea(_0x4893c0,_0x3120d3,_0x534b48,_0x487538)));}),_0x38f5e7&&(_0x188fb4=_0x188fb4['concat'](rs(_0x38f5e7,_0x47aae3,_0x52ded2,_0x675ac2))),_0x188fb4;}function ta(_0x38c22c,_0x50aa98){const _0x2ea463=_0x50aa98['query'],_0x3e1728=xt(_0x38c22c,_0x2ea463);return{'hashFn':()=>(Mu(_0x50aa98)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x29ecde=>{if(_0x29ecde==='ok')return _0x3e1728?Qu(_0x38c22c,_0x2ea463['_path'],_0x3e1728):Yu(_0x38c22c,_0x2ea463['_path']);{const _0x27f9c3=Kl(_0x29ecde,_0x2ea463);return Cn(_0x38c22c,_0x2ea463,null,_0x27f9c3);}}};}function xt(_0x47ea64,_0x52f528){const _0xe03333=Un(_0x52f528);return _0x47ea64['queryToTagMap']['get'](_0xe03333);}function Un(_0x401677){return _0x401677['_path']['toString']()+'$'+_0x401677['_queryIdentifier'];}function as(_0x19a35f,_0x1b5f6a){return _0x19a35f['tagToQueryMap']['get'](_0x1b5f6a);}function cs(_0x4f82e1){const _0x5858fa=_0x4f82e1['indexOf']('$');return f(_0x5858fa!==-0x1&&_0x5858fa<_0x4f82e1['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x4f82e1['substr'](_0x5858fa+0x1),'path':new C(_0x4f82e1['substr'](0x0,_0x5858fa))};}function ls(_0x2b1ba1,_0x48641a,_0x39f83a){const _0x9cf32e=_0x2b1ba1['syncPointTree_']['get'](_0x48641a);f(_0x9cf32e,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x516210=Ln(_0x2b1ba1['pendingWriteTree_'],_0x48641a);return rs(_0x9cf32e,_0x39f83a,_0x516210,null);}function Zu(_0x72c890){return _0x72c890['fold']((_0x10b43e,_0x58be5d,_0x1d9ddd)=>{if(_0x58be5d&&Te(_0x58be5d))return[xn(_0x58be5d)];{let _0x4dbf9b=[];return _0x58be5d&&(_0x4dbf9b=Yo(_0x58be5d)),x(_0x1d9ddd,(_0x4c462b,_0x533133)=>{_0x4dbf9b=_0x4dbf9b['concat'](_0x533133);}),_0x4dbf9b;}});}function bt(_0x5cc11e){return _0x5cc11e['_queryParams']['loadsAllData']()&&!_0x5cc11e['_queryParams']['isDefault']()?new(qu())(_0x5cc11e['_repo'],_0x5cc11e['_path']):_0x5cc11e;}function ed(_0x113043,_0x4fe7d7){for(let _0x20171a=0x0;_0x20171a<_0x4fe7d7['length'];++_0x20171a){const _0x1137d8=_0x4fe7d7[_0x20171a];if(!_0x1137d8['_queryParams']['loadsAllData']()){const _0x14c537=Un(_0x1137d8),_0x4d6de7=_0x113043['queryToTagMap']['get'](_0x14c537);_0x113043['queryToTagMap']['delete'](_0x14c537),_0x113043['tagToQueryMap']['delete'](_0x4d6de7);}}}function td(){return zu++;}function nd(_0x3ab3c1,_0x276eb3,_0x25ceee){const _0x3453fa=_0x276eb3['_path'],_0x2510b9=xt(_0x3ab3c1,_0x276eb3),_0x5f1af0=ta(_0x3ab3c1,_0x25ceee),_0x22be8a=_0x3ab3c1['listenProvider_']['startListening'](bt(_0x276eb3),_0x2510b9,_0x5f1af0['hashFn'],_0x5f1af0['onComplete']),_0x412655=_0x3ab3c1['syncPointTree_']['subtree'](_0x3453fa);if(_0x2510b9)f(!Te(_0x412655['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x522a53=_0x412655['fold']((_0x4ceaaa,_0x2778da,_0x342d70)=>{if(!v(_0x4ceaaa)&&_0x2778da&&Te(_0x2778da))return[xn(_0x2778da)['query']];{let _0x3e70a1=[];return _0x2778da&&(_0x3e70a1=_0x3e70a1['concat'](Yo(_0x2778da)['map'](_0x29f434=>_0x29f434['query']))),x(_0x342d70,(_0x16dd24,_0x1d6fd6)=>{_0x3e70a1=_0x3e70a1['concat'](_0x1d6fd6);}),_0x3e70a1;}});for(let _0x31875e=0x0;_0x31875e<_0x522a53['length'];++_0x31875e){const _0x303291=_0x522a53[_0x31875e];_0x3ab3c1['listenProvider_']['stopListening'](bt(_0x303291),xt(_0x3ab3c1,_0x303291));}}return _0x22be8a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x41d0c7){this['node_']=_0x41d0c7;}['getImmediateChild'](_0x21a149){const _0x2ed49f=this['node_']['getImmediateChild'](_0x21a149);return new hs(_0x2ed49f);}['node'](){return this['node_'];}}class us{constructor(_0x5ed4d0,_0x4966a4){this['syncTree_']=_0x5ed4d0,this['path_']=_0x4966a4;}['getImmediateChild'](_0x40a40d){const _0x574b06=k(this['path_'],_0x40a40d);return new us(this['syncTree_'],_0x574b06);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x44ccf4){return _0x44ccf4=_0x44ccf4||{},_0x44ccf4['timestamp']=_0x44ccf4['timestamp']||new Date()['getTime'](),_0x44ccf4;},gr=function(_0x1f71d0,_0x37222c,_0x540a36){if(!_0x1f71d0||typeof _0x1f71d0!='object')return _0x1f71d0;if(f('.sv'in _0x1f71d0,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x1f71d0['.sv']=='string')return sd(_0x1f71d0['.sv'],_0x37222c,_0x540a36);if(typeof _0x1f71d0['.sv']=='object')return rd(_0x1f71d0['.sv'],_0x37222c);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1f71d0,null,0x2));},sd=function(_0x1381f3,_0xd77f56,_0x1bc47b){switch(_0x1381f3){case'timestamp':return _0x1bc47b['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1381f3);}},rd=function(_0xe97ed4,_0x36771e,_0x16f3d1){_0xe97ed4['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xe97ed4,null,0x2));const _0x416bd3=_0xe97ed4['increment'];typeof _0x416bd3!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x416bd3);const _0x42732b=_0x36771e['node']();if(f(_0x42732b!==null&&typeof _0x42732b<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x42732b['isLeafNode']())return _0x416bd3;const _0x3d8a25=_0x42732b['getValue']();return typeof _0x3d8a25!='number'?_0x416bd3:_0x3d8a25+_0x416bd3;},na=function(_0x556394,_0x2bf3c1,_0x385a5a,_0x377dc2){return fs(_0x2bf3c1,new us(_0x385a5a,_0x556394),_0x377dc2);},ds=function(_0x4a6a4b,_0x302d5e,_0xaf8f8d){return fs(_0x4a6a4b,new hs(_0x302d5e),_0xaf8f8d);};function fs(_0xd665ae,_0x56a8d3,_0x100a1b){const _0x3cd981=_0xd665ae['getPriority']()['val'](),_0x2ce088=gr(_0x3cd981,_0x56a8d3['getImmediateChild']('.priority'),_0x100a1b);let _0x3778f7;if(_0xd665ae['isLeafNode']()){const _0x92ccd3=_0xd665ae,_0x96cda5=gr(_0x92ccd3['getValue'](),_0x56a8d3,_0x100a1b);return _0x96cda5!==_0x92ccd3['getValue']()||_0x2ce088!==_0x92ccd3['getPriority']()['val']()?new D(_0x96cda5,P(_0x2ce088)):_0xd665ae;}else{const _0x4c554b=_0xd665ae;return _0x3778f7=_0x4c554b,_0x2ce088!==_0x4c554b['getPriority']()['val']()&&(_0x3778f7=_0x3778f7['updatePriority'](new D(_0x2ce088))),_0x4c554b['forEachChild'](R,(_0x1d28de,_0x4e6bb3)=>{const _0x1737ce=fs(_0x4e6bb3,_0x56a8d3['getImmediateChild'](_0x1d28de),_0x100a1b);_0x1737ce!==_0x4e6bb3&&(_0x3778f7=_0x3778f7['updateImmediateChild'](_0x1d28de,_0x1737ce));}),_0x3778f7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x1fd7d3='',_0x1e00f6=null,_0x4c41df={'children':{},'childCount':0x0}){this['name']=_0x1fd7d3,this['parent']=_0x1e00f6,this['node']=_0x4c41df;}}function Wn(_0x30c664,_0x30a073){let _0x568a2c=_0x30a073 instanceof C?_0x30a073:new C(_0x30a073),_0x4881b5=_0x30c664,_0x3db9a6=y(_0x568a2c);for(;_0x3db9a6!==null;){const _0x20b222=De(_0x4881b5['node']['children'],_0x3db9a6)||{'children':{},'childCount':0x0};_0x4881b5=new ps(_0x3db9a6,_0x4881b5,_0x20b222),_0x568a2c=b(_0x568a2c),_0x3db9a6=y(_0x568a2c);}return _0x4881b5;}function Ge(_0x35963c){return _0x35963c['node']['value'];}function _s(_0xc1ee63,_0x18ee72){_0xc1ee63['node']['value']=_0x18ee72,Ai(_0xc1ee63);}function ia(_0x32b453){return _0x32b453['node']['childCount']>0x0;}function od(_0xcba56){return Ge(_0xcba56)===void 0x0&&!ia(_0xcba56);}function Bn(_0x4fd344,_0x526213){x(_0x4fd344['node']['children'],(_0xec5c,_0x434506)=>{_0x526213(new ps(_0xec5c,_0x4fd344,_0x434506));});}function sa(_0x445aa0,_0x276358,_0x2bf06c,_0x2f42a5){_0x2bf06c&&_0x276358(_0x445aa0),Bn(_0x445aa0,_0x4e3453=>{sa(_0x4e3453,_0x276358,!0x0);});}function ad(_0x3f00e6,_0x15ab07,_0x5a2c7b){let _0x87ef81=_0x3f00e6['parent'];for(;_0x87ef81!==null;){if(_0x15ab07(_0x87ef81))return!0x0;_0x87ef81=_0x87ef81['parent'];}return!0x1;}function qt(_0x39ae18){return new C(_0x39ae18['parent']===null?_0x39ae18['name']:qt(_0x39ae18['parent'])+'/'+_0x39ae18['name']);}function Ai(_0x5c7116){_0x5c7116['parent']!==null&&cd(_0x5c7116['parent'],_0x5c7116['name'],_0x5c7116);}function cd(_0x42282c,_0x2bbd27,_0x57942d){const _0x540527=od(_0x57942d),_0x23b94d=J(_0x42282c['node']['children'],_0x2bbd27);_0x540527&&_0x23b94d?(delete _0x42282c['node']['children'][_0x2bbd27],_0x42282c['node']['childCount']--,Ai(_0x42282c)):!_0x540527&&!_0x23b94d&&(_0x42282c['node']['children'][_0x2bbd27]=_0x57942d['node'],_0x42282c['node']['childCount']++,Ai(_0x42282c));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x1ddc37){return typeof _0x1ddc37=='string'&&_0x1ddc37['length']!==0x0&&!ld['test'](_0x1ddc37);},ra=function(_0x4f56d9){return typeof _0x4f56d9=='string'&&_0x4f56d9['length']!==0x0&&!hd['test'](_0x4f56d9);},ud=function(_0x2d8b91){return _0x2d8b91&&(_0x2d8b91=_0x2d8b91['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x2d8b91);},Tn=function(_0x47683d){return _0x47683d===null||typeof _0x47683d=='string'||typeof _0x47683d=='number'&&!Vi(_0x47683d)||_0x47683d&&typeof _0x47683d=='object'&&J(_0x47683d,'.sv');},zt=function(_0x19d6e5,_0x56d891,_0x10a1db,_0x41e5cd){_0x41e5cd&&_0x56d891===void 0x0||jt(Pn(_0x19d6e5,'value'),_0x56d891,_0x10a1db);},jt=function(_0x500d02,_0x48c16b,_0x3e85a0){const _0x1ce640=_0x3e85a0 instanceof C?new Ah(_0x3e85a0,_0x500d02):_0x3e85a0;if(_0x48c16b===void 0x0)throw new Error(_0x500d02+'contains\x20undefined\x20'+Pe(_0x1ce640));if(typeof _0x48c16b=='function')throw new Error(_0x500d02+'contains\x20a\x20function\x20'+Pe(_0x1ce640)+'\x20with\x20contents\x20=\x20'+_0x48c16b['toString']());if(Vi(_0x48c16b))throw new Error(_0x500d02+'contains\x20'+_0x48c16b['toString']()+'\x20'+Pe(_0x1ce640));if(typeof _0x48c16b=='string'&&_0x48c16b['length']>ai/0x3&&On(_0x48c16b)>ai)throw new Error(_0x500d02+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x1ce640)+'\x20(\x27'+_0x48c16b['substring'](0x0,0x32)+'...\x27)');if(_0x48c16b&&typeof _0x48c16b=='object'){let _0x2c0aa7=!0x1,_0x2490aa=!0x1;if(x(_0x48c16b,(_0x195f26,_0x55347e)=>{if(_0x195f26==='.value')_0x2c0aa7=!0x0;else{if(_0x195f26!=='.priority'&&_0x195f26!=='.sv'&&(_0x2490aa=!0x0,!gs(_0x195f26)))throw new Error(_0x500d02+'\x20contains\x20an\x20invalid\x20key\x20('+_0x195f26+')\x20'+Pe(_0x1ce640)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x1ce640,_0x195f26),jt(_0x500d02,_0x55347e,_0x1ce640),Nh(_0x1ce640);}),_0x2c0aa7&&_0x2490aa)throw new Error(_0x500d02+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x1ce640)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x1c5e6e,_0x3e2776){let _0x5603eb,_0x2fc770;for(_0x5603eb=0x0;_0x5603eb<_0x3e2776['length'];_0x5603eb++){_0x2fc770=_0x3e2776[_0x5603eb];const _0x2b43d0=Pt(_0x2fc770);for(let _0x42bbd3=0x0;_0x42bbd3<_0x2b43d0['length'];_0x42bbd3++)if(!(_0x2b43d0[_0x42bbd3]==='.priority'&&_0x42bbd3===_0x2b43d0['length']-0x1)){if(!gs(_0x2b43d0[_0x42bbd3]))throw new Error(_0x1c5e6e+'contains\x20an\x20invalid\x20key\x20('+_0x2b43d0[_0x42bbd3]+')\x20in\x20path\x20'+_0x2fc770['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x3e2776['sort'](Rh);let _0x129371=null;for(_0x5603eb=0x0;_0x5603eb<_0x3e2776['length'];_0x5603eb++){if(_0x2fc770=_0x3e2776[_0x5603eb],_0x129371!==null&&G(_0x129371,_0x2fc770))throw new Error(_0x1c5e6e+'contains\x20a\x20path\x20'+_0x129371['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x2fc770['toString']());_0x129371=_0x2fc770;}},fd=function(_0x552bf3,_0x20ed08,_0x213bb3,_0x564d29){const _0x48efd0=Pn(_0x552bf3,'values');if(!(_0x20ed08&&typeof _0x20ed08=='object')||Array['isArray'](_0x20ed08))throw new Error(_0x48efd0+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x32ee0d=[];x(_0x20ed08,(_0x4ce681,_0x95b347)=>{const _0x325465=new C(_0x4ce681);if(jt(_0x48efd0,_0x95b347,k(_0x213bb3,_0x325465)),zi(_0x325465)==='.priority'&&!Tn(_0x95b347))throw new Error(_0x48efd0+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x325465['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x32ee0d['push'](_0x325465);}),dd(_0x48efd0,_0x32ee0d);},ms=function(_0x1322ad,_0xa09442,_0x5f81,_0x5a3e61){if(!ra(_0x5f81))throw new Error(Pn(_0x1322ad,_0xa09442)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x5f81+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x30b37a,_0x2609e2,_0x4663bb,_0x2f5f9a){_0x4663bb&&(_0x4663bb=_0x4663bb['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x30b37a,_0x2609e2,_0x4663bb);},ys=function(_0x1da2e3,_0x51debf){if(y(_0x51debf)==='.info')throw new Error(_0x1da2e3+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x519bae,_0x594834){const _0x459d8b=_0x594834['path']['toString']();if(typeof _0x594834['repoInfo']['host']!='string'||_0x594834['repoInfo']['host']['length']===0x0||!gs(_0x594834['repoInfo']['namespace'])&&_0x594834['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x459d8b['length']!==0x0&&!ud(_0x459d8b))throw new Error(Pn(_0x519bae,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x2e89e4,_0x27fe1b){let _0x2045ad=null;for(let _0x77d2c8=0x0;_0x77d2c8<_0x27fe1b['length'];_0x77d2c8++){const _0x20d6d2=_0x27fe1b[_0x77d2c8],_0x415eab=_0x20d6d2['getPath']();_0x2045ad!==null&&!ji(_0x415eab,_0x2045ad['path'])&&(_0x2e89e4['eventLists_']['push'](_0x2045ad),_0x2045ad=null),_0x2045ad===null&&(_0x2045ad={'events':[],'path':_0x415eab}),_0x2045ad['events']['push'](_0x20d6d2);}_0x2045ad&&_0x2e89e4['eventLists_']['push'](_0x2045ad);}function oa(_0x53fef3,_0x17bd4b,_0x3b738d){Vn(_0x53fef3,_0x3b738d),aa(_0x53fef3,_0x2fdac5=>ji(_0x2fdac5,_0x17bd4b));}function H(_0x3e1da9,_0x4dbe97,_0x4ecba8){Vn(_0x3e1da9,_0x4ecba8),aa(_0x3e1da9,_0x466698=>G(_0x466698,_0x4dbe97)||G(_0x4dbe97,_0x466698));}function aa(_0xb168a0,_0x22c896){_0xb168a0['recursionDepth_']++;let _0x9237b6=!0x0;for(let _0xef980=0x0;_0xef980<_0xb168a0['eventLists_']['length'];_0xef980++){const _0x4eb21d=_0xb168a0['eventLists_'][_0xef980];if(_0x4eb21d){const _0x4b3f8c=_0x4eb21d['path'];_0x22c896(_0x4b3f8c)?(md(_0xb168a0['eventLists_'][_0xef980]),_0xb168a0['eventLists_'][_0xef980]=null):_0x9237b6=!0x1;}}_0x9237b6&&(_0xb168a0['eventLists_']=[]),_0xb168a0['recursionDepth_']--;}function md(_0x286f7a){for(let _0x3c99ed=0x0;_0x3c99ed<_0x286f7a['events']['length'];_0x3c99ed++){const _0x2b43e3=_0x286f7a['events'][_0x3c99ed];if(_0x2b43e3!==null){_0x286f7a['events'][_0x3c99ed]=null;const _0x5be5bd=_0x2b43e3['getEventRunner']();wt&&L('event:\x20'+_0x2b43e3['toString']()),ht(_0x5be5bd);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x3c2462,_0x55e422,_0x26abeb,_0x41cfeb){this['repoInfo_']=_0x3c2462,this['forceRestClient_']=_0x55e422,this['authTokenProvider_']=_0x26abeb,this['appCheckProvider_']=_0x41cfeb,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x292117,_0x209f10,_0x5a3ef4){if(_0x292117['stats_']=Gi(_0x292117['repoInfo_']),_0x292117['forceRestClient_']||Xl())_0x292117['server_']=new pn(_0x292117['repoInfo_'],(_0x5251ac,_0x5184ad,_0x2ae557,_0x1bc4d1)=>{mr(_0x292117,_0x5251ac,_0x5184ad,_0x2ae557,_0x1bc4d1);},_0x292117['authTokenProvider_'],_0x292117['appCheckProvider_']),setTimeout(()=>yr(_0x292117,!0x0),0x0);else{if(typeof _0x5a3ef4<'u'&&_0x5a3ef4!==null){if(typeof _0x5a3ef4!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x5a3ef4);}catch(_0x519e54){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x519e54);}}_0x292117['persistentConnection_']=new se(_0x292117['repoInfo_'],_0x209f10,(_0x50b2a4,_0x1572ea,_0x2c80db,_0x2481c6)=>{mr(_0x292117,_0x50b2a4,_0x1572ea,_0x2c80db,_0x2481c6);},_0x547cf2=>{yr(_0x292117,_0x547cf2);},_0x1db94d=>{Id(_0x292117,_0x1db94d);},_0x292117['authTokenProvider_'],_0x292117['appCheckProvider_'],_0x5a3ef4),_0x292117['server_']=_0x292117['persistentConnection_'];}_0x292117['authTokenProvider_']['addTokenChangeListener'](_0x161771=>{_0x292117['server_']['refreshAuthToken'](_0x161771);}),_0x292117['appCheckProvider_']['addTokenChangeListener'](_0x3638d0=>{_0x292117['server_']['refreshAppCheckToken'](_0x3638d0['token']);}),_0x292117['statsReporter_']=ih(_0x292117['repoInfo_'],()=>new iu(_0x292117['stats_'],_0x292117['server_'])),_0x292117['infoData_']=new Xh(),_0x292117['infoSyncTree_']=new _r({'startListening':(_0x43ef5a,_0xdcbdd9,_0x5aca81,_0x55453e)=>{let _0x39e306=[];const _0x2ed773=_0x292117['infoData_']['getNode'](_0x43ef5a['_path']);return _0x2ed773['isEmpty']()||(_0x39e306=Gt(_0x292117['infoSyncTree_'],_0x43ef5a['_path'],_0x2ed773),setTimeout(()=>{_0x55453e('ok');},0x0)),_0x39e306;},'stopListening':()=>{}}),vs(_0x292117,'connected',!0x1),_0x292117['serverSyncTree_']=new _r({'startListening':(_0x56a8b9,_0x3430e4,_0x12d87a,_0x1cb8f8)=>(_0x292117['server_']['listen'](_0x56a8b9,_0x12d87a,_0x3430e4,(_0x4d5278,_0x240519)=>{const _0x5b1d49=_0x1cb8f8(_0x4d5278,_0x240519);H(_0x292117['eventQueue_'],_0x56a8b9['_path'],_0x5b1d49);}),[]),'stopListening':(_0x4e97c0,_0x56f71b)=>{_0x292117['server_']['unlisten'](_0x4e97c0,_0x56f71b);}});}function la(_0x238ce8){const _0x4a373d=_0x238ce8['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x4a373d;}function Kt(_0x138b5a){return id({'timestamp':la(_0x138b5a)});}function mr(_0x1fee57,_0xe94bb3,_0xcbb707,_0x3e5448,_0xec2c86){_0x1fee57['dataUpdateCount']++;const _0x5dec7c=new C(_0xe94bb3);_0xcbb707=_0x1fee57['interceptServerDataCallback_']?_0x1fee57['interceptServerDataCallback_'](_0xe94bb3,_0xcbb707):_0xcbb707;let _0x45fcbb=[];if(_0xec2c86){if(_0x3e5448){const _0x4338f2=hn(_0xcbb707,_0x4c96fa=>P(_0x4c96fa));_0x45fcbb=Ju(_0x1fee57['serverSyncTree_'],_0x5dec7c,_0x4338f2,_0xec2c86);}else{const _0x1e9840=P(_0xcbb707);_0x45fcbb=Xo(_0x1fee57['serverSyncTree_'],_0x5dec7c,_0x1e9840,_0xec2c86);}}else{if(_0x3e5448){const _0x4328a6=hn(_0xcbb707,_0x1c4e82=>P(_0x1c4e82));_0x45fcbb=Ku(_0x1fee57['serverSyncTree_'],_0x5dec7c,_0x4328a6);}else{const _0x588658=P(_0xcbb707);_0x45fcbb=Gt(_0x1fee57['serverSyncTree_'],_0x5dec7c,_0x588658);}}let _0x2111ff=_0x5dec7c;_0x45fcbb['length']>0x0&&(_0x2111ff=it(_0x1fee57,_0x5dec7c)),H(_0x1fee57['eventQueue_'],_0x2111ff,_0x45fcbb);}function yr(_0x93bd6a,_0x2fa1c2){vs(_0x93bd6a,'connected',_0x2fa1c2),_0x2fa1c2===!0x1&&Sd(_0x93bd6a);}function Id(_0x20db57,_0x1abdb7){x(_0x1abdb7,(_0x142a0a,_0x27ce44)=>{vs(_0x20db57,_0x142a0a,_0x27ce44);});}function vs(_0x553ebb,_0x3d97af,_0x208bf9){const _0x39e851=new C('/.info/'+_0x3d97af),_0x1edce2=P(_0x208bf9);_0x553ebb['infoData_']['updateSnapshot'](_0x39e851,_0x1edce2);const _0x836310=Gt(_0x553ebb['infoSyncTree_'],_0x39e851,_0x1edce2);H(_0x553ebb['eventQueue_'],_0x39e851,_0x836310);}function Hn(_0x2b6193){return _0x2b6193['nextWriteId_']++;}function wd(_0x200fb4,_0x208a87,_0x4b9a4a){const _0xa4bec4=Xu(_0x200fb4['serverSyncTree_'],_0x208a87);return _0xa4bec4!=null?Promise['resolve'](_0xa4bec4):_0x200fb4['server_']['get'](_0x208a87)['then'](_0x10568d=>{const _0x2ec73c=P(_0x10568d)['withIndex'](_0x208a87['_queryParams']['getIndex']());Ri(_0x200fb4['serverSyncTree_'],_0x208a87,_0x4b9a4a,!0x0);let _0x17eab8;if(_0x208a87['_queryParams']['loadsAllData']())_0x17eab8=Gt(_0x200fb4['serverSyncTree_'],_0x208a87['_path'],_0x2ec73c);else{const _0x26b39a=xt(_0x200fb4['serverSyncTree_'],_0x208a87);_0x17eab8=Xo(_0x200fb4['serverSyncTree_'],_0x208a87['_path'],_0x2ec73c,_0x26b39a);}return H(_0x200fb4['eventQueue_'],_0x208a87['_path'],_0x17eab8),Cn(_0x200fb4['serverSyncTree_'],_0x208a87,_0x4b9a4a,null,!0x0),_0x2ec73c;},_0x24e2c3=>(dt(_0x200fb4,'get\x20for\x20query\x20'+O(_0x208a87)+'\x20failed:\x20'+_0x24e2c3),Promise['reject'](new Error(_0x24e2c3))));}function Cd(_0x91cb7f,_0x22d99d,_0x24f5b5,_0x490772,_0x187892){dt(_0x91cb7f,'set',{'path':_0x22d99d['toString'](),'value':_0x24f5b5,'priority':_0x490772});const _0x3a44b6=Kt(_0x91cb7f),_0x41575a=P(_0x24f5b5,_0x490772),_0x4d1768=Fn(_0x91cb7f['serverSyncTree_'],_0x22d99d),_0x103fd5=ds(_0x41575a,_0x4d1768,_0x3a44b6),_0x39397d=Hn(_0x91cb7f),_0x4d86bb=os(_0x91cb7f['serverSyncTree_'],_0x22d99d,_0x103fd5,_0x39397d,!0x0);Vn(_0x91cb7f['eventQueue_'],_0x4d86bb),_0x91cb7f['server_']['put'](_0x22d99d['toString'](),_0x41575a['val'](!0x0),(_0x558221,_0x3c64ce)=>{const _0x1035bb=_0x558221==='ok';_0x1035bb||U('set\x20at\x20'+_0x22d99d+'\x20failed:\x20'+_0x558221);const _0x2632bb=pe(_0x91cb7f['serverSyncTree_'],_0x39397d,!_0x1035bb);H(_0x91cb7f['eventQueue_'],_0x22d99d,_0x2632bb),ki(_0x91cb7f,_0x187892,_0x558221,_0x3c64ce);});const _0x439ecd=Is(_0x91cb7f,_0x22d99d);it(_0x91cb7f,_0x439ecd),H(_0x91cb7f['eventQueue_'],_0x439ecd,[]);}function Td(_0x482b07,_0x4d7f8d,_0x5bbe63,_0x455ce0){dt(_0x482b07,'update',{'path':_0x4d7f8d['toString'](),'value':_0x5bbe63});let _0x5bb200=!0x0;const _0x569222=Kt(_0x482b07),_0x5438f9={};if(x(_0x5bbe63,(_0x348dfd,_0x257602)=>{_0x5bb200=!0x1,_0x5438f9[_0x348dfd]=na(k(_0x4d7f8d,_0x348dfd),P(_0x257602),_0x482b07['serverSyncTree_'],_0x569222);}),_0x5bb200)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x482b07,_0x455ce0,'ok',void 0x0);else{const _0x2f6c58=Hn(_0x482b07),_0x7d5bda=ju(_0x482b07['serverSyncTree_'],_0x4d7f8d,_0x5438f9,_0x2f6c58);Vn(_0x482b07['eventQueue_'],_0x7d5bda),_0x482b07['server_']['merge'](_0x4d7f8d['toString'](),_0x5bbe63,(_0x46d858,_0x18bb5a)=>{const _0x1a65b2=_0x46d858==='ok';_0x1a65b2||U('update\x20at\x20'+_0x4d7f8d+'\x20failed:\x20'+_0x46d858);const _0x40f38d=pe(_0x482b07['serverSyncTree_'],_0x2f6c58,!_0x1a65b2),_0x961040=_0x40f38d['length']>0x0?it(_0x482b07,_0x4d7f8d):_0x4d7f8d;H(_0x482b07['eventQueue_'],_0x961040,_0x40f38d),ki(_0x482b07,_0x455ce0,_0x46d858,_0x18bb5a);}),x(_0x5bbe63,_0x18663a=>{const _0x6a5f19=Is(_0x482b07,k(_0x4d7f8d,_0x18663a));it(_0x482b07,_0x6a5f19);}),H(_0x482b07['eventQueue_'],_0x4d7f8d,[]);}}function Sd(_0x405769){dt(_0x405769,'onDisconnectEvents');const _0x272a1b=Kt(_0x405769),_0x1fff80=_n();Ii(_0x405769['onDisconnect_'],w(),(_0x4749e8,_0x5d23dc)=>{const _0x318982=na(_0x4749e8,_0x5d23dc,_0x405769['serverSyncTree_'],_0x272a1b);Fo(_0x1fff80,_0x4749e8,_0x318982);});let _0x40ebbf=[];Ii(_0x1fff80,w(),(_0x3d31a8,_0x4024d2)=>{_0x40ebbf=_0x40ebbf['concat'](Gt(_0x405769['serverSyncTree_'],_0x3d31a8,_0x4024d2));const _0x365913=Is(_0x405769,_0x3d31a8);it(_0x405769,_0x365913);}),_0x405769['onDisconnect_']=_n(),H(_0x405769['eventQueue_'],w(),_0x40ebbf);}function bd(_0x352bc7,_0x4e3924,_0x2bbd88){let _0x1a3500;y(_0x4e3924['_path'])==='.info'?_0x1a3500=Ri(_0x352bc7['infoSyncTree_'],_0x4e3924,_0x2bbd88):_0x1a3500=Ri(_0x352bc7['serverSyncTree_'],_0x4e3924,_0x2bbd88),oa(_0x352bc7['eventQueue_'],_0x4e3924['_path'],_0x1a3500);}function Rd(_0x561f11,_0x14d881,_0xcab301){let _0x5cf236;y(_0x14d881['_path'])==='.info'?_0x5cf236=Cn(_0x561f11['infoSyncTree_'],_0x14d881,_0xcab301):_0x5cf236=Cn(_0x561f11['serverSyncTree_'],_0x14d881,_0xcab301),oa(_0x561f11['eventQueue_'],_0x14d881['_path'],_0x5cf236);}function ha(_0x52d0cf){_0x52d0cf['persistentConnection_']&&_0x52d0cf['persistentConnection_']['interrupt'](ca);}function Ad(_0x524119){_0x524119['persistentConnection_']&&_0x524119['persistentConnection_']['resume'](ca);}function dt(_0x6b912c,..._0x316eb0){let _0x2e602f='';_0x6b912c['persistentConnection_']&&(_0x2e602f=_0x6b912c['persistentConnection_']['id']+':'),L(_0x2e602f,..._0x316eb0);}function ki(_0x76e616,_0x5175be,_0x3a67db,_0x177948){_0x5175be&&ht(()=>{if(_0x3a67db==='ok')_0x5175be(null);else{const _0x4a2108=(_0x3a67db||'error')['toUpperCase']();let _0x2ca92c=_0x4a2108;_0x177948&&(_0x2ca92c+=':\x20'+_0x177948);const _0x317b7c=new Error(_0x2ca92c);_0x317b7c['code']=_0x4a2108,_0x5175be(_0x317b7c);}});}function kd(_0x158c6a,_0xc494d8,_0x25131e,_0x5f01e8,_0x1ead03,_0x5b57af){dt(_0x158c6a,'transaction\x20on\x20'+_0xc494d8);const _0x5ec1e9={'path':_0xc494d8,'update':_0x25131e,'onComplete':_0x5f01e8,'status':null,'order':so(),'applyLocally':_0x5b57af,'retryCount':0x0,'unwatcher':_0x1ead03,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x1c5c4d=Es(_0x158c6a,_0xc494d8,void 0x0);_0x5ec1e9['currentInputSnapshot']=_0x1c5c4d;const _0x725ffb=_0x5ec1e9['update'](_0x1c5c4d['val']());if(_0x725ffb===void 0x0)_0x5ec1e9['unwatcher'](),_0x5ec1e9['currentOutputSnapshotRaw']=null,_0x5ec1e9['currentOutputSnapshotResolved']=null,_0x5ec1e9['onComplete']&&_0x5ec1e9['onComplete'](null,!0x1,_0x5ec1e9['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x725ffb,_0x5ec1e9['path']),_0x5ec1e9['status']=0x0;const _0x384d0=Wn(_0x158c6a['transactionQueueTree_'],_0xc494d8),_0x1cd1f5=Ge(_0x384d0)||[];_0x1cd1f5['push'](_0x5ec1e9),_s(_0x384d0,_0x1cd1f5);let _0x52af51;typeof _0x725ffb=='object'&&_0x725ffb!==null&&J(_0x725ffb,'.priority')?(_0x52af51=De(_0x725ffb,'.priority'),f(Tn(_0x52af51),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x52af51=(Fn(_0x158c6a['serverSyncTree_'],_0xc494d8)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x326efb=Kt(_0x158c6a),_0x50899b=P(_0x725ffb,_0x52af51),_0x55b03f=ds(_0x50899b,_0x1c5c4d,_0x326efb);_0x5ec1e9['currentOutputSnapshotRaw']=_0x50899b,_0x5ec1e9['currentOutputSnapshotResolved']=_0x55b03f,_0x5ec1e9['currentWriteId']=Hn(_0x158c6a);const _0x417347=os(_0x158c6a['serverSyncTree_'],_0xc494d8,_0x55b03f,_0x5ec1e9['currentWriteId'],_0x5ec1e9['applyLocally']);H(_0x158c6a['eventQueue_'],_0xc494d8,_0x417347),$n(_0x158c6a,_0x158c6a['transactionQueueTree_']);}}function Es(_0xaa4433,_0x859926,_0x16e221){return Fn(_0xaa4433['serverSyncTree_'],_0x859926,_0x16e221)||g['EMPTY_NODE'];}function $n(_0x123381,_0x1ddbf1=_0x123381['transactionQueueTree_']){if(_0x1ddbf1||Gn(_0x123381,_0x1ddbf1),Ge(_0x1ddbf1)){const _0x5f47be=da(_0x123381,_0x1ddbf1);f(_0x5f47be['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x5f47be['every'](_0x227498=>_0x227498['status']===0x0)&&Nd(_0x123381,qt(_0x1ddbf1),_0x5f47be);}else ia(_0x1ddbf1)&&Bn(_0x1ddbf1,_0x309664=>{$n(_0x123381,_0x309664);});}function Nd(_0x48fdbf,_0x31c2f8,_0x33c240){const _0x2bed15=_0x33c240['map'](_0x481bfe=>_0x481bfe['currentWriteId']),_0x410dde=Es(_0x48fdbf,_0x31c2f8,_0x2bed15);let _0x4366e3=_0x410dde;const _0xdc48df=_0x410dde['hash']();for(let _0xa8d3ae=0x0;_0xa8d3ae<_0x33c240['length'];_0xa8d3ae++){const _0x437d68=_0x33c240[_0xa8d3ae];f(_0x437d68['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x437d68['status']=0x1,_0x437d68['retryCount']++;const _0x4b17f4=F(_0x31c2f8,_0x437d68['path']);_0x4366e3=_0x4366e3['updateChild'](_0x4b17f4,_0x437d68['currentOutputSnapshotRaw']);}const _0x234add=_0x4366e3['val'](!0x0),_0x551a98=_0x31c2f8;_0x48fdbf['server_']['put'](_0x551a98['toString'](),_0x234add,_0xb7ccd2=>{dt(_0x48fdbf,'transaction\x20put\x20response',{'path':_0x551a98['toString'](),'status':_0xb7ccd2});let _0x3f090b=[];if(_0xb7ccd2==='ok'){const _0x2caab9=[];for(let _0x50fdff=0x0;_0x50fdff<_0x33c240['length'];_0x50fdff++)_0x33c240[_0x50fdff]['status']=0x2,_0x3f090b=_0x3f090b['concat'](pe(_0x48fdbf['serverSyncTree_'],_0x33c240[_0x50fdff]['currentWriteId'])),_0x33c240[_0x50fdff]['onComplete']&&_0x2caab9['push'](()=>_0x33c240[_0x50fdff]['onComplete'](null,!0x0,_0x33c240[_0x50fdff]['currentOutputSnapshotResolved'])),_0x33c240[_0x50fdff]['unwatcher']();Gn(_0x48fdbf,Wn(_0x48fdbf['transactionQueueTree_'],_0x31c2f8)),$n(_0x48fdbf,_0x48fdbf['transactionQueueTree_']),H(_0x48fdbf['eventQueue_'],_0x31c2f8,_0x3f090b);for(let _0x4b28b1=0x0;_0x4b28b1<_0x2caab9['length'];_0x4b28b1++)ht(_0x2caab9[_0x4b28b1]);}else{if(_0xb7ccd2==='datastale'){for(let _0x4e955f=0x0;_0x4e955f<_0x33c240['length'];_0x4e955f++)_0x33c240[_0x4e955f]['status']===0x3?_0x33c240[_0x4e955f]['status']=0x4:_0x33c240[_0x4e955f]['status']=0x0;}else{U('transaction\x20at\x20'+_0x551a98['toString']()+'\x20failed:\x20'+_0xb7ccd2);for(let _0x128a31=0x0;_0x128a31<_0x33c240['length'];_0x128a31++)_0x33c240[_0x128a31]['status']=0x4,_0x33c240[_0x128a31]['abortReason']=_0xb7ccd2;}it(_0x48fdbf,_0x31c2f8);}},_0xdc48df);}function it(_0x551089,_0x1edf37){const _0x2cbbc8=ua(_0x551089,_0x1edf37),_0x572130=qt(_0x2cbbc8),_0x5a15d1=da(_0x551089,_0x2cbbc8);return Pd(_0x551089,_0x5a15d1,_0x572130),_0x572130;}function Pd(_0x250ff9,_0x1d141d,_0x4ced34){if(_0x1d141d['length']===0x0)return;const _0x1d638b=[];let _0x56774e=[];const _0x990bd=_0x1d141d['filter'](_0x2f6e81=>_0x2f6e81['status']===0x0)['map'](_0x48cc38=>_0x48cc38['currentWriteId']);for(let _0x6e3985=0x0;_0x6e3985<_0x1d141d['length'];_0x6e3985++){const _0x277203=_0x1d141d[_0x6e3985],_0x4e9b2c=F(_0x4ced34,_0x277203['path']);let _0xd860fa=!0x1,_0x2f3562;if(f(_0x4e9b2c!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x277203['status']===0x4)_0xd860fa=!0x0,_0x2f3562=_0x277203['abortReason'],_0x56774e=_0x56774e['concat'](pe(_0x250ff9['serverSyncTree_'],_0x277203['currentWriteId'],!0x0));else{if(_0x277203['status']===0x0){if(_0x277203['retryCount']>=yd)_0xd860fa=!0x0,_0x2f3562='maxretry',_0x56774e=_0x56774e['concat'](pe(_0x250ff9['serverSyncTree_'],_0x277203['currentWriteId'],!0x0));else{const _0x5ccdf7=Es(_0x250ff9,_0x277203['path'],_0x990bd);_0x277203['currentInputSnapshot']=_0x5ccdf7;const _0x1401a1=_0x1d141d[_0x6e3985]['update'](_0x5ccdf7['val']());if(_0x1401a1!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x1401a1,_0x277203['path']);let _0x329e6e=P(_0x1401a1);typeof _0x1401a1=='object'&&_0x1401a1!=null&&J(_0x1401a1,'.priority')||(_0x329e6e=_0x329e6e['updatePriority'](_0x5ccdf7['getPriority']()));const _0x45d677=_0x277203['currentWriteId'],_0x2186bd=Kt(_0x250ff9),_0x2fe4aa=ds(_0x329e6e,_0x5ccdf7,_0x2186bd);_0x277203['currentOutputSnapshotRaw']=_0x329e6e,_0x277203['currentOutputSnapshotResolved']=_0x2fe4aa,_0x277203['currentWriteId']=Hn(_0x250ff9),_0x990bd['splice'](_0x990bd['indexOf'](_0x45d677),0x1),_0x56774e=_0x56774e['concat'](os(_0x250ff9['serverSyncTree_'],_0x277203['path'],_0x2fe4aa,_0x277203['currentWriteId'],_0x277203['applyLocally'])),_0x56774e=_0x56774e['concat'](pe(_0x250ff9['serverSyncTree_'],_0x45d677,!0x0));}else _0xd860fa=!0x0,_0x2f3562='nodata',_0x56774e=_0x56774e['concat'](pe(_0x250ff9['serverSyncTree_'],_0x277203['currentWriteId'],!0x0));}}}H(_0x250ff9['eventQueue_'],_0x4ced34,_0x56774e),_0x56774e=[],_0xd860fa&&(_0x1d141d[_0x6e3985]['status']=0x2,function(_0x5c5093){setTimeout(_0x5c5093,Math['floor'](0x0));}(_0x1d141d[_0x6e3985]['unwatcher']),_0x1d141d[_0x6e3985]['onComplete']&&(_0x2f3562==='nodata'?_0x1d638b['push'](()=>_0x1d141d[_0x6e3985]['onComplete'](null,!0x1,_0x1d141d[_0x6e3985]['currentInputSnapshot'])):_0x1d638b['push'](()=>_0x1d141d[_0x6e3985]['onComplete'](new Error(_0x2f3562),!0x1,null))));}Gn(_0x250ff9,_0x250ff9['transactionQueueTree_']);for(let _0x106ba3=0x0;_0x106ba3<_0x1d638b['length'];_0x106ba3++)ht(_0x1d638b[_0x106ba3]);$n(_0x250ff9,_0x250ff9['transactionQueueTree_']);}function ua(_0x58c3a4,_0x5d41af){let _0x1a52e9,_0x534aaa=_0x58c3a4['transactionQueueTree_'];for(_0x1a52e9=y(_0x5d41af);_0x1a52e9!==null&&Ge(_0x534aaa)===void 0x0;)_0x534aaa=Wn(_0x534aaa,_0x1a52e9),_0x5d41af=b(_0x5d41af),_0x1a52e9=y(_0x5d41af);return _0x534aaa;}function da(_0x502834,_0x550c36){const _0x44c153=[];return fa(_0x502834,_0x550c36,_0x44c153),_0x44c153['sort']((_0xe0a063,_0x342dc0)=>_0xe0a063['order']-_0x342dc0['order']),_0x44c153;}function fa(_0x1cba6b,_0x207dce,_0x4b0b16){const _0x5b9079=Ge(_0x207dce);if(_0x5b9079){for(let _0x24c169=0x0;_0x24c169<_0x5b9079['length'];_0x24c169++)_0x4b0b16['push'](_0x5b9079[_0x24c169]);}Bn(_0x207dce,_0x22c1c9=>{fa(_0x1cba6b,_0x22c1c9,_0x4b0b16);});}function Gn(_0x1a042b,_0x7cf597){const _0x11defa=Ge(_0x7cf597);if(_0x11defa){let _0xb609cd=0x0;for(let _0x4cd52a=0x0;_0x4cd52a<_0x11defa['length'];_0x4cd52a++)_0x11defa[_0x4cd52a]['status']!==0x2&&(_0x11defa[_0xb609cd]=_0x11defa[_0x4cd52a],_0xb609cd++);_0x11defa['length']=_0xb609cd,_s(_0x7cf597,_0x11defa['length']>0x0?_0x11defa:void 0x0);}Bn(_0x7cf597,_0x24fb5e=>{Gn(_0x1a042b,_0x24fb5e);});}function Is(_0xe4e290,_0x576f60){const _0x237c45=qt(ua(_0xe4e290,_0x576f60)),_0x36d590=Wn(_0xe4e290['transactionQueueTree_'],_0x576f60);return ad(_0x36d590,_0x19c571=>{ci(_0xe4e290,_0x19c571);}),ci(_0xe4e290,_0x36d590),sa(_0x36d590,_0x1d8468=>{ci(_0xe4e290,_0x1d8468);}),_0x237c45;}function ci(_0x339a60,_0x5e5b2e){const _0x4de209=Ge(_0x5e5b2e);if(_0x4de209){const _0x1189a8=[];let _0xda2779=[],_0x4a2fd5=-0x1;for(let _0x28f98f=0x0;_0x28f98f<_0x4de209['length'];_0x28f98f++)_0x4de209[_0x28f98f]['status']===0x3||(_0x4de209[_0x28f98f]['status']===0x1?(f(_0x4a2fd5===_0x28f98f-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x4a2fd5=_0x28f98f,_0x4de209[_0x28f98f]['status']=0x3,_0x4de209[_0x28f98f]['abortReason']='set'):(f(_0x4de209[_0x28f98f]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x4de209[_0x28f98f]['unwatcher'](),_0xda2779=_0xda2779['concat'](pe(_0x339a60['serverSyncTree_'],_0x4de209[_0x28f98f]['currentWriteId'],!0x0)),_0x4de209[_0x28f98f]['onComplete']&&_0x1189a8['push'](_0x4de209[_0x28f98f]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x4a2fd5===-0x1?_s(_0x5e5b2e,void 0x0):_0x4de209['length']=_0x4a2fd5+0x1,H(_0x339a60['eventQueue_'],qt(_0x5e5b2e),_0xda2779);for(let _0x1e9499=0x0;_0x1e9499<_0x1189a8['length'];_0x1e9499++)ht(_0x1189a8[_0x1e9499]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x1bf7e8){let _0x2a6d57='';const _0x1b067d=_0x1bf7e8['split']('/');for(let _0x27a1a1=0x0;_0x27a1a1<_0x1b067d['length'];_0x27a1a1++)if(_0x1b067d[_0x27a1a1]['length']>0x0){let _0x358a05=_0x1b067d[_0x27a1a1];try{_0x358a05=decodeURIComponent(_0x358a05['replace'](/\+/g,'\x20'));}catch{}_0x2a6d57+='/'+_0x358a05;}return _0x2a6d57;}function Dd(_0x15e598){const _0x5776b0={};_0x15e598['charAt'](0x0)==='?'&&(_0x15e598=_0x15e598['substring'](0x1));for(const _0x240cc5 of _0x15e598['split']('&')){if(_0x240cc5['length']===0x0)continue;const _0x50104e=_0x240cc5['split']('=');_0x50104e['length']===0x2?_0x5776b0[decodeURIComponent(_0x50104e[0x0])]=decodeURIComponent(_0x50104e[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x240cc5+'\x27\x20in\x20query\x20\x27'+_0x15e598+'\x27');}return _0x5776b0;}const vr=function(_0x53482c,_0x243ec6){const _0x35f0d5=Md(_0x53482c),_0x59db44=_0x35f0d5['namespace'];_0x35f0d5['domain']==='firebase.com'&&ae(_0x35f0d5['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x59db44||_0x59db44==='undefined')&&_0x35f0d5['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x35f0d5['secure']||$l();const _0x60394b=_0x35f0d5['scheme']==='ws'||_0x35f0d5['scheme']==='wss';return{'repoInfo':new yo(_0x35f0d5['host'],_0x35f0d5['secure'],_0x59db44,_0x60394b,_0x243ec6,'',_0x59db44!==_0x35f0d5['subdomain']),'path':new C(_0x35f0d5['pathString'])};},Md=function(_0x33af92){let _0x560af4='',_0x141319='',_0x4f00d3='',_0x51f45c='',_0x3aedbf='',_0x106276=!0x0,_0x3f0285='https',_0x39cec=0x1bb;if(typeof _0x33af92=='string'){let _0x36d25e=_0x33af92['indexOf']('//');_0x36d25e>=0x0&&(_0x3f0285=_0x33af92['substring'](0x0,_0x36d25e-0x1),_0x33af92=_0x33af92['substring'](_0x36d25e+0x2));let _0x15675e=_0x33af92['indexOf']('/');_0x15675e===-0x1&&(_0x15675e=_0x33af92['length']);let _0x56f62f=_0x33af92['indexOf']('?');_0x56f62f===-0x1&&(_0x56f62f=_0x33af92['length']),_0x560af4=_0x33af92['substring'](0x0,Math['min'](_0x15675e,_0x56f62f)),_0x15675e<_0x56f62f&&(_0x51f45c=Od(_0x33af92['substring'](_0x15675e,_0x56f62f)));const _0x1b6a35=Dd(_0x33af92['substring'](Math['min'](_0x33af92['length'],_0x56f62f)));_0x36d25e=_0x560af4['indexOf'](':'),_0x36d25e>=0x0?(_0x106276=_0x3f0285==='https'||_0x3f0285==='wss',_0x39cec=parseInt(_0x560af4['substring'](_0x36d25e+0x1),0xa)):_0x36d25e=_0x560af4['length'];const _0x3b6a4b=_0x560af4['slice'](0x0,_0x36d25e);if(_0x3b6a4b['toLowerCase']()==='localhost')_0x141319='localhost';else{if(_0x3b6a4b['split']('.')['length']<=0x2)_0x141319=_0x3b6a4b;else{const _0x12580c=_0x560af4['indexOf']('.');_0x4f00d3=_0x560af4['substring'](0x0,_0x12580c)['toLowerCase'](),_0x141319=_0x560af4['substring'](_0x12580c+0x1),_0x3aedbf=_0x4f00d3;}}'ns'in _0x1b6a35&&(_0x3aedbf=_0x1b6a35['ns']);}return{'host':_0x560af4,'port':_0x39cec,'domain':_0x141319,'subdomain':_0x4f00d3,'secure':_0x106276,'scheme':_0x3f0285,'pathString':_0x51f45c,'namespace':_0x3aedbf};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x3a44ba=0x0;const _0xf2ee92=[];return function(_0x272ea9){const _0x373834=_0x272ea9===_0x3a44ba;_0x3a44ba=_0x272ea9;let _0x1904f8;const _0x5ed4cc=new Array(0x8);for(_0x1904f8=0x7;_0x1904f8>=0x0;_0x1904f8--)_0x5ed4cc[_0x1904f8]=Er['charAt'](_0x272ea9%0x40),_0x272ea9=Math['floor'](_0x272ea9/0x40);f(_0x272ea9===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x285b4e=_0x5ed4cc['join']('');if(_0x373834){for(_0x1904f8=0xb;_0x1904f8>=0x0&&_0xf2ee92[_0x1904f8]===0x3f;_0x1904f8--)_0xf2ee92[_0x1904f8]=0x0;_0xf2ee92[_0x1904f8]++;}else{for(_0x1904f8=0x0;_0x1904f8<0xc;_0x1904f8++)_0xf2ee92[_0x1904f8]=Math['floor'](Math['random']()*0x40);}for(_0x1904f8=0x0;_0x1904f8<0xc;_0x1904f8++)_0x285b4e+=Er['charAt'](_0xf2ee92[_0x1904f8]);return f(_0x285b4e['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x285b4e;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x3b407e,_0x50ab9b,_0x2ee7b6,_0x13412b){this['eventType']=_0x3b407e,this['eventRegistration']=_0x50ab9b,this['snapshot']=_0x2ee7b6,this['prevName']=_0x13412b;}['getPath'](){const _0x37363e=this['snapshot']['ref'];return this['eventType']==='value'?_0x37363e['_path']:_0x37363e['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x29ff18,_0xcbabd0,_0x5d8c65){this['eventRegistration']=_0x29ff18,this['error']=_0xcbabd0,this['path']=_0x5d8c65;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x2ac9ce,_0x4b87f2){this['snapshotCallback']=_0x2ac9ce,this['cancelCallback']=_0x4b87f2;}['onValue'](_0xe53ba1,_0x53d2cf){this['snapshotCallback']['call'](null,_0xe53ba1,_0x53d2cf);}['onCancel'](_0x59842f){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x59842f);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x4c8f60){return this['snapshotCallback']===_0x4c8f60['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x4c8f60['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x4c8f60['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x2cd6e3,_0x4b775e,_0x4b612c,_0x385b9a){this['_repo']=_0x2cd6e3,this['_path']=_0x4b775e,this['_queryParams']=_0x4b612c,this['_orderByCalled']=_0x385b9a;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x252e82=rr(this['_queryParams']),_0x4a1ac2=Hi(_0x252e82);return _0x4a1ac2==='{}'?'default':_0x4a1ac2;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0xd0587a){if(_0xd0587a=N(_0xd0587a),!(_0xd0587a instanceof be))return!0x1;const _0x12afd0=this['_repo']===_0xd0587a['_repo'],_0x3445e7=ji(this['_path'],_0xd0587a['_path']),_0xfcc3dd=this['_queryIdentifier']===_0xd0587a['_queryIdentifier'];return _0x12afd0&&_0x3445e7&&_0xfcc3dd;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x4ed8c8,_0x1eb089){if(_0x4ed8c8['_orderByCalled']===!0x0)throw new Error(_0x1eb089+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0xe2692c){let _0x2f86fb=null,_0x8b6ae2=null;if(_0xe2692c['hasStart']()&&(_0x2f86fb=_0xe2692c['getIndexStartValue']()),_0xe2692c['hasEnd']()&&(_0x8b6ae2=_0xe2692c['getIndexEndValue']()),_0xe2692c['getIndex']()===ye){const _0x52d82d='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x268666='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0xe2692c['hasStart']()){if(_0xe2692c['getIndexStartName']()!==Fe)throw new Error(_0x52d82d);if(typeof _0x2f86fb!='string')throw new Error(_0x268666);}if(_0xe2692c['hasEnd']()){if(_0xe2692c['getIndexEndName']()!==Ie)throw new Error(_0x52d82d);if(typeof _0x8b6ae2!='string')throw new Error(_0x268666);}}else{if(_0xe2692c['getIndex']()===R){if(_0x2f86fb!=null&&!Tn(_0x2f86fb)||_0x8b6ae2!=null&&!Tn(_0x8b6ae2))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0xe2692c['getIndex']()instanceof Qi||_0xe2692c['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x2f86fb!=null&&typeof _0x2f86fb=='object'||_0x8b6ae2!=null&&typeof _0x8b6ae2=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x4d71a1){if(_0x4d71a1['hasStart']()&&_0x4d71a1['hasEnd']()&&_0x4d71a1['hasLimit']()&&!_0x4d71a1['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x3e0881,_0x5ca223){super(_0x3e0881,_0x5ca223,new Xi(),!0x1);}get['parent'](){const _0x2ccff3=Ro(this['_path']);return _0x2ccff3===null?null:new ee(this['_repo'],_0x2ccff3);}get['root'](){let _0xa59ee3=this;for(;_0xa59ee3['parent']!==null;)_0xa59ee3=_0xa59ee3['parent'];return _0xa59ee3;}}class st{constructor(_0x20bd9f,_0x2b954a,_0x390c47){this['_node']=_0x20bd9f,this['ref']=_0x2b954a,this['_index']=_0x390c47;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x5c2d41){const _0x246630=new C(_0x5c2d41),_0x5b60ac=Ft(this['ref'],_0x5c2d41);return new st(this['_node']['getChild'](_0x246630),_0x5b60ac,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x5d1d2a){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x191a43,_0x38032a)=>_0x5d1d2a(new st(_0x38032a,Ft(this['ref'],_0x191a43),R)));}['hasChild'](_0x2be303){const _0x34fab3=new C(_0x2be303);return!this['_node']['getChild'](_0x34fab3)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x263bdc,_0x27240f){return _0x263bdc=N(_0x263bdc),_0x263bdc['_checkNotDeleted']('ref'),_0x27240f!==void 0x0?Ft(_0x263bdc['_root'],_0x27240f):_0x263bdc['_root'];}function Ft(_0x50ddf5,_0x14086b){return _0x50ddf5=N(_0x50ddf5),y(_0x50ddf5['_path'])===null?pd('child','path',_0x14086b):ms('child','path',_0x14086b),new ee(_0x50ddf5['_repo'],k(_0x50ddf5['_path'],_0x14086b));}function g_(_0x34fa68,_0x589e45){_0x34fa68=N(_0x34fa68),ys('push',_0x34fa68['_path']),zt('push',_0x589e45,_0x34fa68['_path'],!0x0);const _0x53df4f=la(_0x34fa68['_repo']),_0x1e319b=Ld(_0x53df4f),_0x1dd013=Ft(_0x34fa68,_0x1e319b),_0x5d9ddb=Ft(_0x34fa68,_0x1e319b);let _0x57ec3f;return _0x589e45!=null?_0x57ec3f=Ud(_0x5d9ddb,_0x589e45)['then'](()=>_0x5d9ddb):_0x57ec3f=Promise['resolve'](_0x5d9ddb),_0x1dd013['then']=_0x57ec3f['then']['bind'](_0x57ec3f),_0x1dd013['catch']=_0x57ec3f['then']['bind'](_0x57ec3f,void 0x0),_0x1dd013;}function Ud(_0x1faf29,_0x489116){_0x1faf29=N(_0x1faf29),ys('set',_0x1faf29['_path']),zt('set',_0x489116,_0x1faf29['_path'],!0x1);const _0x5a215c=new ot();return Cd(_0x1faf29['_repo'],_0x1faf29['_path'],_0x489116,null,_0x5a215c['wrapCallback'](()=>{})),_0x5a215c['promise'];}function m_(_0x11cc70,_0x30a805){fd('update',_0x30a805,_0x11cc70['_path']);const _0x3cdcf2=new ot();return Td(_0x11cc70['_repo'],_0x11cc70['_path'],_0x30a805,_0x3cdcf2['wrapCallback'](()=>{})),_0x3cdcf2['promise'];}function y_(_0x518cd9){_0x518cd9=N(_0x518cd9);const _0x2c4b4e=new pa(()=>{}),_0x295335=new zn(_0x2c4b4e);return wd(_0x518cd9['_repo'],_0x518cd9,_0x295335)['then'](_0x191783=>new st(_0x191783,new ee(_0x518cd9['_repo'],_0x518cd9['_path']),_0x518cd9['_queryParams']['getIndex']()));}class zn{constructor(_0x1b0dc8){this['callbackContext']=_0x1b0dc8;}['respondsTo'](_0x212a9e){return _0x212a9e==='value';}['createEvent'](_0x4c7e41,_0xd8fd2c){const _0x5e8e1a=_0xd8fd2c['_queryParams']['getIndex']();return new xd('value',this,new st(_0x4c7e41['snapshotNode'],new ee(_0xd8fd2c['_repo'],_0xd8fd2c['_path']),_0x5e8e1a));}['getEventRunner'](_0x71347e){return _0x71347e['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x71347e['error']):()=>this['callbackContext']['onValue'](_0x71347e['snapshot'],null);}['createCancelEvent'](_0x564e62,_0x47c9c8){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x564e62,_0x47c9c8):null;}['matches'](_0x423dfd){return _0x423dfd instanceof zn?!_0x423dfd['callbackContext']||!this['callbackContext']?!0x0:_0x423dfd['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0xb765d9,_0x4fbe8d,_0x50731c,_0x1bc9eb,_0x3069ed){const _0x25bbd3=new pa(_0x50731c,void 0x0),_0x4ebb4f=new zn(_0x25bbd3);return bd(_0xb765d9['_repo'],_0xb765d9,_0x4ebb4f),()=>Rd(_0xb765d9['_repo'],_0xb765d9,_0x4ebb4f);}function Bd(_0x22c54a,_0x2d71dd,_0x378272,_0x28e56c){return Wd(_0x22c54a,'value',_0x2d71dd);}class ft{}class ma extends ft{constructor(_0x532522,_0x5cb7ad){super(),this['_value']=_0x532522,this['_key']=_0x5cb7ad,this['type']='endAt';}['_apply'](_0x4f7d7b){zt('endAt',this['_value'],_0x4f7d7b['_path'],!0x0);const _0x247438=Jh(_0x4f7d7b['_queryParams'],this['_value'],this['_key']);if(ga(_0x247438),qn(_0x247438),_0x4f7d7b['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x4f7d7b['_repo'],_0x4f7d7b['_path'],_0x247438,_0x4f7d7b['_orderByCalled']);}}function v_(_0x4429f7,_0x137d02){return new ma(_0x4429f7,_0x137d02);}class ya extends ft{constructor(_0x46010e,_0x493029){super(),this['_value']=_0x46010e,this['_key']=_0x493029,this['type']='startAt';}['_apply'](_0x373f40){zt('startAt',this['_value'],_0x373f40['_path'],!0x0);const _0x251ca2=Qh(_0x373f40['_queryParams'],this['_value'],this['_key']);if(ga(_0x251ca2),qn(_0x251ca2),_0x373f40['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x373f40['_repo'],_0x373f40['_path'],_0x251ca2,_0x373f40['_orderByCalled']);}}function E_(_0x2f5498=null,_0x24165c){return new ya(_0x2f5498,_0x24165c);}class Vd extends ft{constructor(_0x288c83){super(),this['_limit']=_0x288c83,this['type']='limitToFirst';}['_apply'](_0x2aa874){if(_0x2aa874['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x2aa874['_repo'],_0x2aa874['_path'],Yh(_0x2aa874['_queryParams'],this['_limit']),_0x2aa874['_orderByCalled']);}}function I_(_0x319421){if(Math['floor'](_0x319421)!==_0x319421||_0x319421<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x319421);}class Hd extends ft{constructor(_0x167587){super(),this['_path']=_0x167587,this['type']='orderByChild';}['_apply'](_0x39a5b2){_a(_0x39a5b2,'orderByChild');const _0x4a8e7f=new C(this['_path']);if(v(_0x4a8e7f))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x21edcf=new Qi(_0x4a8e7f),_0x4521cb=xo(_0x39a5b2['_queryParams'],_0x21edcf);return qn(_0x4521cb),new be(_0x39a5b2['_repo'],_0x39a5b2['_path'],_0x4521cb,!0x0);}}function w_(_0x1cd061){if(_0x1cd061==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x1cd061==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x1cd061==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x1cd061),new Hd(_0x1cd061);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0xdb8ba0){_a(_0xdb8ba0,'orderByKey');const _0x397cdd=xo(_0xdb8ba0['_queryParams'],ye);return qn(_0x397cdd),new be(_0xdb8ba0['_repo'],_0xdb8ba0['_path'],_0x397cdd,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x6cff3a,_0x456a9b){super(),this['_value']=_0x6cff3a,this['_key']=_0x456a9b,this['type']='equalTo';}['_apply'](_0x2a9b11){if(zt('equalTo',this['_value'],_0x2a9b11['_path'],!0x1),_0x2a9b11['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x2a9b11['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x2a9b11));}}function T_(_0x35af93,_0x3b6657){return new Gd(_0x35af93,_0x3b6657);}function S_(_0x40f0b1,..._0x47a0fb){let _0x624026=N(_0x40f0b1);for(const _0x57ed04 of _0x47a0fb)_0x624026=_0x57ed04['_apply'](_0x624026);return _0x624026;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x51e026,_0x556633,_0x40c7ce,_0x527bea){const _0x5abde3=_0x556633['lastIndexOf'](':'),_0x4e2fc8=_0x556633['substring'](0x0,_0x5abde3),_0x1fe32d=at(_0x4e2fc8);_0x51e026['repoInfo_']=new yo(_0x556633,_0x1fe32d,_0x51e026['repoInfo_']['namespace'],_0x51e026['repoInfo_']['webSocketOnly'],_0x51e026['repoInfo_']['nodeAdmin'],_0x51e026['repoInfo_']['persistenceKey'],_0x51e026['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x40c7ce),_0x527bea&&(_0x51e026['authTokenProvider_']=_0x527bea);}function Kd(_0x6657e8,_0x2e5939,_0x5125a0,_0x52b84e,_0x65185d){let _0x122f77=_0x52b84e||_0x6657e8['options']['databaseURL'];_0x122f77===void 0x0&&(_0x6657e8['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x6657e8['options']['projectId']),_0x122f77=_0x6657e8['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x7fe860=vr(_0x122f77,_0x65185d),_0x9baf90=_0x7fe860['repoInfo'],_0x144e34;typeof process<'u'&&Vs&&(_0x144e34=Vs[qd]),_0x144e34?(_0x122f77='http://'+_0x144e34+'?ns='+_0x9baf90['namespace'],_0x7fe860=vr(_0x122f77,_0x65185d),_0x9baf90=_0x7fe860['repoInfo']):_0x7fe860['repoInfo']['secure'];const _0x322d1b=new eh(_0x6657e8['name'],_0x6657e8['options'],_0x2e5939);_d('Invalid\x20Firebase\x20Database\x20URL',_0x7fe860),v(_0x7fe860['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x73ca44=Qd(_0x9baf90,_0x6657e8,_0x322d1b,new Zl(_0x6657e8,_0x5125a0));return new Jd(_0x73ca44,_0x6657e8);}function Yd(_0x294fd1,_0xea8cd6){const _0x51a687=Ni[_0xea8cd6];(!_0x51a687||_0x51a687[_0x294fd1['key']]!==_0x294fd1)&&ae('Database\x20'+_0xea8cd6+'('+_0x294fd1['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x294fd1),delete _0x51a687[_0x294fd1['key']];}function Qd(_0x4f767a,_0x1ec662,_0x460342,_0x293ff5){let _0x4e5236=Ni[_0x1ec662['name']];_0x4e5236||(_0x4e5236={},Ni[_0x1ec662['name']]=_0x4e5236);let _0x2de482=_0x4e5236[_0x4f767a['toURLString']()];return _0x2de482&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x2de482=new vd(_0x4f767a,zd,_0x460342,_0x293ff5),_0x4e5236[_0x4f767a['toURLString']()]=_0x2de482,_0x2de482;}class Jd{constructor(_0xb87e03,_0x5c768b){this['_repoInternal']=_0xb87e03,this['app']=_0x5c768b,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x30cb5f){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x30cb5f+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x2cb7a2=Zr(),_0x26cee3){const _0x2a50d9=Bi(_0x2cb7a2,'database')['getImmediate']({'identifier':_0x26cee3});if(!_0x2a50d9['_instanceStarted']){const _0x81aed9=cc('database');_0x81aed9&&Xd(_0x2a50d9,..._0x81aed9);}return _0x2a50d9;}function Xd(_0x57bffe,_0x5281ce,_0x438c7c,_0x43dc87={}){_0x57bffe=N(_0x57bffe),_0x57bffe['_checkNotDeleted']('useEmulator');const _0x268637=_0x5281ce+':'+_0x438c7c,_0x2979a3=_0x57bffe['_repoInternal'];if(_0x57bffe['_instanceStarted']){if(_0x268637===_0x57bffe['_repoInternal']['repoInfo_']['host']&&Me(_0x43dc87,_0x2979a3['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x5b4482;if(_0x2979a3['repoInfo_']['nodeAdmin'])_0x43dc87['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x5b4482=new nn(nn['OWNER']);else{if(_0x43dc87['mockUserToken']){const _0x46e998=typeof _0x43dc87['mockUserToken']=='string'?_0x43dc87['mockUserToken']:lc(_0x43dc87['mockUserToken'],_0x57bffe['app']['options']['projectId']);_0x5b4482=new nn(_0x46e998);}}at(_0x5281ce)&&(jr(_0x5281ce),Kr('Database',!0x0)),jd(_0x2979a3,_0x268637,_0x43dc87,_0x5b4482);}function R_(_0x39ab65){_0x39ab65=N(_0x39ab65),_0x39ab65['_checkNotDeleted']('goOffline'),ha(_0x39ab65['_repo']);}function A_(_0x3fe61f){_0x3fe61f=N(_0x3fe61f),_0x3fe61f['_checkNotDeleted']('goOnline'),Ad(_0x3fe61f['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x3ddb37){Ul(lt),Ze(new Le('database',(_0x269308,{instanceIdentifier:_0x3a4b82})=>{const _0x5bb46f=_0x269308['getProvider']('app')['getImmediate'](),_0x372c98=_0x269308['getProvider']('auth-internal'),_0x375b7d=_0x269308['getProvider']('app-check-internal');return Kd(_0x5bb46f,_0x372c98,_0x375b7d,_0x3a4b82);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x3ddb37),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x50149e,_0x2ef566){this['committed']=_0x50149e,this['snapshot']=_0x2ef566;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0xc4ba6b,_0xdb367,_0x5080cd){if(_0xc4ba6b=N(_0xc4ba6b),ys('Reference.transaction',_0xc4ba6b['_path']),_0xc4ba6b['key']==='.length'||_0xc4ba6b['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0xc4ba6b['key']+'\x20is\x20a\x20read-only\x20object.';const _0xba665b=!0x0,_0x4ee889=new ot(),_0x48a32d=(_0x591822,_0xb95a95,_0x31f1d1)=>{let _0x22e46a=null;_0x591822?_0x4ee889['reject'](_0x591822):(_0x22e46a=new st(_0x31f1d1,new ee(_0xc4ba6b['_repo'],_0xc4ba6b['_path']),R),_0x4ee889['resolve'](new tf(_0xb95a95,_0x22e46a)));},_0x38e11a=Bd(_0xc4ba6b,()=>{});return kd(_0xc4ba6b['_repo'],_0xc4ba6b['_path'],_0xdb367,_0x48a32d,_0x38e11a,_0xba665b),_0x4ee889['promise'];}se['prototype']['simpleListen']=function(_0x50f88a,_0x151b14){this['sendRequest']('q',{'p':_0x50f88a},_0x151b14);},se['prototype']['echo']=function(_0x4c91df,_0x1c1799){this['sendRequest']('echo',{'d':_0x4c91df},_0x1c1799);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x6fe6b8,..._0x3aeb67){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x6fe6b8,..._0x3aeb67);}function sn(_0x2fc4fe,..._0x1997d3){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x2fc4fe,..._0x1997d3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x3597c9,..._0x5a0aa2){throw ws(_0x3597c9,..._0x5a0aa2);}function X(_0x513fcc,..._0x20a27e){return ws(_0x513fcc,..._0x20a27e);}function Ia(_0x144a1c,_0x55bafd,_0x12acce){const _0x50a776={...nf(),[_0x55bafd]:_0x12acce};return new Bt('auth','Firebase',_0x50a776)['create'](_0x55bafd,{'appName':_0x144a1c['name']});}function re(_0x1e4ed7){return Ia(_0x1e4ed7,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x4e4fae,..._0x1a413e){if(typeof _0x4e4fae!='string'){const _0x1140b9=_0x1a413e[0x0],_0x2ccffe=[..._0x1a413e['slice'](0x1)];return _0x2ccffe[0x0]&&(_0x2ccffe[0x0]['appName']=_0x4e4fae['name']),_0x4e4fae['_errorFactory']['create'](_0x1140b9,..._0x2ccffe);}return Ea['create'](_0x4e4fae,..._0x1a413e);}function m(_0x4ca8bd,_0x18291c,..._0x5949f7){if(!_0x4ca8bd)throw ws(_0x18291c,..._0x5949f7);}function ne(_0x1e4308){const _0x5800b4='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1e4308;throw sn(_0x5800b4),new Error(_0x5800b4);}function ce(_0x5972ac,_0x1eb7b6){_0x5972ac||ne(_0x1eb7b6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x1f15b3;return typeof self<'u'&&((_0x1f15b3=self['location'])==null?void 0x0:_0x1f15b3['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x253ec2;return typeof self<'u'&&((_0x253ec2=self['location'])==null?void 0x0:_0x253ec2['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x1aaa4e=navigator;return _0x1aaa4e['languages']&&_0x1aaa4e['languages'][0x0]||_0x1aaa4e['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x1aa66b,_0x38f04d){this['shortDelay']=_0x1aa66b,this['longDelay']=_0x38f04d,ce(_0x38f04d>_0x1aa66b,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x4a3e96,_0x1edde6){ce(_0x4a3e96['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x3154ca}=_0x4a3e96['emulator'];return _0x1edde6?''+_0x3154ca+(_0x1edde6['startsWith']('/')?_0x1edde6['slice'](0x1):_0x1edde6):_0x3154ca;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x4b6b01,_0x28f41f,_0x43f6a5){this['fetchImpl']=_0x4b6b01,_0x28f41f&&(this['headersImpl']=_0x28f41f),_0x43f6a5&&(this['responseImpl']=_0x43f6a5);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x45c6c6,_0x3de0e4){return _0x45c6c6['tenantId']&&!_0x3de0e4['tenantId']?{..._0x3de0e4,'tenantId':_0x45c6c6['tenantId']}:_0x3de0e4;}async function Ae(_0x5811bf,_0x6aa8c2,_0x42d3a1,_0x1821c3,_0x309d05={}){return Ca(_0x5811bf,_0x309d05,async()=>{let _0x3eaa1a={},_0x1d6c75={};_0x1821c3&&(_0x6aa8c2==='GET'?_0x1d6c75=_0x1821c3:_0x3eaa1a={'body':JSON['stringify'](_0x1821c3)});const _0x267a12=ct({'key':_0x5811bf['config']['apiKey'],..._0x1d6c75})['slice'](0x1),_0x3fdcb8=await _0x5811bf['_getAdditionalHeaders']();_0x3fdcb8['Content-Type']='application/json',_0x5811bf['languageCode']&&(_0x3fdcb8['X-Firebase-Locale']=_0x5811bf['languageCode']);const _0x2d78f1={'method':_0x6aa8c2,'headers':_0x3fdcb8,..._0x3eaa1a};return dc()||(_0x2d78f1['referrerPolicy']='no-referrer'),_0x5811bf['emulatorConfig']&&at(_0x5811bf['emulatorConfig']['host'])&&(_0x2d78f1['credentials']='include'),wa['fetch']()(await Ta(_0x5811bf,_0x5811bf['config']['apiHost'],_0x42d3a1,_0x267a12),_0x2d78f1);});}async function Ca(_0x42feaa,_0x5bebbf,_0x54d64f){_0x42feaa['_canInitEmulator']=!0x1;const _0x277136={...cf,..._0x5bebbf};try{const _0x2728a8=new df(_0x42feaa),_0x5404e3=await Promise['race']([_0x54d64f(),_0x2728a8['promise']]);_0x2728a8['clearNetworkTimeout']();const _0x4760ac=await _0x5404e3['json']();if('needConfirmation'in _0x4760ac)throw tn(_0x42feaa,'account-exists-with-different-credential',_0x4760ac);if(_0x5404e3['ok']&&!('errorMessage'in _0x4760ac))return _0x4760ac;{const _0x5525b9=_0x5404e3['ok']?_0x4760ac['errorMessage']:_0x4760ac['error']['message'],[_0x45cb6e,_0x4de93e]=_0x5525b9['split']('\x20:\x20');if(_0x45cb6e==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x42feaa,'credential-already-in-use',_0x4760ac);if(_0x45cb6e==='EMAIL_EXISTS')throw tn(_0x42feaa,'email-already-in-use',_0x4760ac);if(_0x45cb6e==='USER_DISABLED')throw tn(_0x42feaa,'user-disabled',_0x4760ac);const _0x2d6d6f=_0x277136[_0x45cb6e]||_0x45cb6e['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x4de93e)throw Ia(_0x42feaa,_0x2d6d6f,_0x4de93e);Q(_0x42feaa,_0x2d6d6f);}}catch(_0x96d766){if(_0x96d766 instanceof Se)throw _0x96d766;Q(_0x42feaa,'network-request-failed',{'message':String(_0x96d766)});}}async function Qt(_0x32011d,_0x32789f,_0x4af119,_0x3be389,_0x168d38={}){const _0x1d6821=await Ae(_0x32011d,_0x32789f,_0x4af119,_0x3be389,_0x168d38);return'mfaPendingCredential'in _0x1d6821&&Q(_0x32011d,'multi-factor-auth-required',{'_serverResponse':_0x1d6821}),_0x1d6821;}async function Ta(_0x35b5ca,_0x894802,_0x348dca,_0x40fab2){const _0x86d55d=''+_0x894802+_0x348dca+'?'+_0x40fab2,_0x317adc=_0x35b5ca,_0x37aa4e=_0x317adc['config']['emulator']?Cs(_0x35b5ca['config'],_0x86d55d):_0x35b5ca['config']['apiScheme']+'://'+_0x86d55d;return lf['includes'](_0x348dca)&&(await _0x317adc['_persistenceManagerAvailable'],_0x317adc['_getPersistenceType']()==='COOKIE')?_0x317adc['_getPersistence']()['_getFinalTarget'](_0x37aa4e)['toString']():_0x37aa4e;}function uf(_0x509117){switch(_0x509117){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x3ba845){this['auth']=_0x3ba845,this['timer']=null,this['promise']=new Promise((_0x6654d3,_0x2d2094)=>{this['timer']=setTimeout(()=>_0x2d2094(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x4ac51d,_0xe91f85,_0x1af8af){const _0x5bc28a={'appName':_0x4ac51d['name']};_0x1af8af['email']&&(_0x5bc28a['email']=_0x1af8af['email']),_0x1af8af['phoneNumber']&&(_0x5bc28a['phoneNumber']=_0x1af8af['phoneNumber']);const _0x392041=X(_0x4ac51d,_0xe91f85,_0x5bc28a);return _0x392041['customData']['_tokenResponse']=_0x1af8af,_0x392041;}function wr(_0x568eb4){return _0x568eb4!==void 0x0&&_0x568eb4['enterprise']!==void 0x0;}class ff{constructor(_0x4213d8){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x4213d8['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x4213d8['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x4213d8['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x305ac5){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x4090b8 of this['recaptchaEnforcementState'])if(_0x4090b8['provider']&&_0x4090b8['provider']===_0x305ac5)return uf(_0x4090b8['enforcementState']);return null;}['isProviderEnabled'](_0xc7ebf7){return this['getProviderEnforcementState'](_0xc7ebf7)==='ENFORCE'||this['getProviderEnforcementState'](_0xc7ebf7)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x58fd4a,_0x4a1e9a){return Ae(_0x58fd4a,'GET','/v2/recaptchaConfig',Re(_0x58fd4a,_0x4a1e9a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x4a2dab,_0x57a9d9){return Ae(_0x4a2dab,'POST','/v1/accounts:delete',_0x57a9d9);}async function bn(_0x207bcb,_0x10f11d){return Ae(_0x207bcb,'POST','/v1/accounts:lookup',_0x10f11d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x5862b5){if(_0x5862b5)try{const _0x5c4791=new Date(Number(_0x5862b5));if(!isNaN(_0x5c4791['getTime']()))return _0x5c4791['toUTCString']();}catch{}}async function gf(_0x2d24bd,_0x2e4754=!0x1){const _0x1611ec=N(_0x2d24bd),_0x4eefdc=await _0x1611ec['getIdToken'](_0x2e4754),_0x9aa620=Ts(_0x4eefdc);m(_0x9aa620&&_0x9aa620['exp']&&_0x9aa620['auth_time']&&_0x9aa620['iat'],_0x1611ec['auth'],'internal-error');const _0x2e1669=typeof _0x9aa620['firebase']=='object'?_0x9aa620['firebase']:void 0x0,_0xacd006=_0x2e1669==null?void 0x0:_0x2e1669['sign_in_provider'];return{'claims':_0x9aa620,'token':_0x4eefdc,'authTime':Rt(li(_0x9aa620['auth_time'])),'issuedAtTime':Rt(li(_0x9aa620['iat'])),'expirationTime':Rt(li(_0x9aa620['exp'])),'signInProvider':_0xacd006||null,'signInSecondFactor':(_0x2e1669==null?void 0x0:_0x2e1669['sign_in_second_factor'])||null};}function li(_0x150427){return Number(_0x150427)*0x3e8;}function Ts(_0x5a8cd4){const [_0xd0d9b3,_0x23f677,_0xd3a09f]=_0x5a8cd4['split']('.');if(_0xd0d9b3===void 0x0||_0x23f677===void 0x0||_0xd3a09f===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x51271b=ln(_0x23f677);return _0x51271b?JSON['parse'](_0x51271b):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x248f05){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x248f05==null?void 0x0:_0x248f05['toString']()),null;}}function Cr(_0x38fdff){const _0x1a4ac4=Ts(_0x38fdff);return m(_0x1a4ac4,'internal-error'),m(typeof _0x1a4ac4['exp']<'u','internal-error'),m(typeof _0x1a4ac4['iat']<'u','internal-error'),Number(_0x1a4ac4['exp'])-Number(_0x1a4ac4['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x1a8e0a,_0x7ec508,_0x54bc3f=!0x1){if(_0x54bc3f)return _0x7ec508;try{return await _0x7ec508;}catch(_0x33999f){throw _0x33999f instanceof Se&&mf(_0x33999f)&&_0x1a8e0a['auth']['currentUser']===_0x1a8e0a&&await _0x1a8e0a['auth']['signOut'](),_0x33999f;}}function mf({code:_0x5a4613}){return _0x5a4613==='auth/user-disabled'||_0x5a4613==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x309abf){this['user']=_0x309abf,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x8a81d4){if(_0x8a81d4){const _0x421e1c=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x421e1c;}else{this['errorBackoff']=0x7530;const _0x4a21bb=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x4a21bb);}}['schedule'](_0x357ca8=!0x1){if(!this['isRunning'])return;const _0x461252=this['getInterval'](_0x357ca8);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x461252);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x42eebf){(_0x42eebf==null?void 0x0:_0x42eebf['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x5ae7ec,_0xa6f2){this['createdAt']=_0x5ae7ec,this['lastLoginAt']=_0xa6f2,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x4944a7){this['createdAt']=_0x4944a7['createdAt'],this['lastLoginAt']=_0x4944a7['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x3bceaa){var _0x31d7e4;const _0x339b24=_0x3bceaa['auth'],_0x293c15=await _0x3bceaa['getIdToken'](),_0x52d5d6=await Ut(_0x3bceaa,bn(_0x339b24,{'idToken':_0x293c15}));m(_0x52d5d6==null?void 0x0:_0x52d5d6['users']['length'],_0x339b24,'internal-error');const _0x4fb841=_0x52d5d6['users'][0x0];_0x3bceaa['_notifyReloadListener'](_0x4fb841);const _0x1f5db6=(_0x31d7e4=_0x4fb841['providerUserInfo'])!=null&&_0x31d7e4['length']?Sa(_0x4fb841['providerUserInfo']):[],_0x4bf243=Ef(_0x3bceaa['providerData'],_0x1f5db6),_0x1bab1e=_0x3bceaa['isAnonymous'],_0x5a0207=!(_0x3bceaa['email']&&_0x4fb841['passwordHash'])&&!(_0x4bf243!=null&&_0x4bf243['length']),_0x5cfe3c=_0x1bab1e?_0x5a0207:!0x1,_0x3e1a4c={'uid':_0x4fb841['localId'],'displayName':_0x4fb841['displayName']||null,'photoURL':_0x4fb841['photoUrl']||null,'email':_0x4fb841['email']||null,'emailVerified':_0x4fb841['emailVerified']||!0x1,'phoneNumber':_0x4fb841['phoneNumber']||null,'tenantId':_0x4fb841['tenantId']||null,'providerData':_0x4bf243,'metadata':new Oi(_0x4fb841['createdAt'],_0x4fb841['lastLoginAt']),'isAnonymous':_0x5cfe3c};Object['assign'](_0x3bceaa,_0x3e1a4c);}async function vf(_0x41f49a){const _0x4c2478=N(_0x41f49a);await Rn(_0x4c2478),await _0x4c2478['auth']['_persistUserIfCurrent'](_0x4c2478),_0x4c2478['auth']['_notifyListenersIfCurrent'](_0x4c2478);}function Ef(_0x19ec9c,_0x209633){return[..._0x19ec9c['filter'](_0x5483a4=>!_0x209633['some'](_0x43316d=>_0x43316d['providerId']===_0x5483a4['providerId'])),..._0x209633];}function Sa(_0x7a7371){return _0x7a7371['map'](({providerId:_0x3acfa7,..._0x320dd8})=>({'providerId':_0x3acfa7,'uid':_0x320dd8['rawId']||'','displayName':_0x320dd8['displayName']||null,'email':_0x320dd8['email']||null,'phoneNumber':_0x320dd8['phoneNumber']||null,'photoURL':_0x320dd8['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x32b771,_0xf1a5){const _0x578c71=await Ca(_0x32b771,{},async()=>{const _0x449ca4=ct({'grant_type':'refresh_token','refresh_token':_0xf1a5})['slice'](0x1),{tokenApiHost:_0x594af3,apiKey:_0x5bbf09}=_0x32b771['config'],_0x4fe565=await Ta(_0x32b771,_0x594af3,'/v1/token','key='+_0x5bbf09),_0x264a4b=await _0x32b771['_getAdditionalHeaders']();_0x264a4b['Content-Type']='application/x-www-form-urlencoded';const _0x54d460={'method':'POST','headers':_0x264a4b,'body':_0x449ca4};return _0x32b771['emulatorConfig']&&at(_0x32b771['emulatorConfig']['host'])&&(_0x54d460['credentials']='include'),wa['fetch']()(_0x4fe565,_0x54d460);});return{'accessToken':_0x578c71['access_token'],'expiresIn':_0x578c71['expires_in'],'refreshToken':_0x578c71['refresh_token']};}async function wf(_0x450ede,_0x4465c6){return Ae(_0x450ede,'POST','/v2/accounts:revokeToken',Re(_0x450ede,_0x4465c6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x4a4ea7){m(_0x4a4ea7['idToken'],'internal-error'),m(typeof _0x4a4ea7['idToken']<'u','internal-error'),m(typeof _0x4a4ea7['refreshToken']<'u','internal-error');const _0x3c848f='expiresIn'in _0x4a4ea7&&typeof _0x4a4ea7['expiresIn']<'u'?Number(_0x4a4ea7['expiresIn']):Cr(_0x4a4ea7['idToken']);this['updateTokensAndExpiration'](_0x4a4ea7['idToken'],_0x4a4ea7['refreshToken'],_0x3c848f);}['updateFromIdToken'](_0x6ba27a){m(_0x6ba27a['length']!==0x0,'internal-error');const _0x334c60=Cr(_0x6ba27a);this['updateTokensAndExpiration'](_0x6ba27a,null,_0x334c60);}async['getToken'](_0x533a69,_0x487a1e=!0x1){return!_0x487a1e&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x533a69,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x533a69,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x1980dd,_0x5f02d3){const {accessToken:_0x22524f,refreshToken:_0x2c9bc9,expiresIn:_0x597e70}=await If(_0x1980dd,_0x5f02d3);this['updateTokensAndExpiration'](_0x22524f,_0x2c9bc9,Number(_0x597e70));}['updateTokensAndExpiration'](_0x2ec06e,_0x45afe9,_0x528802){this['refreshToken']=_0x45afe9||null,this['accessToken']=_0x2ec06e||null,this['expirationTime']=Date['now']()+_0x528802*0x3e8;}static['fromJSON'](_0x4a28c6,_0x487755){const {refreshToken:_0x40d409,accessToken:_0x49b1f1,expirationTime:_0x43f517}=_0x487755,_0x377ad9=new Qe();return _0x40d409&&(m(typeof _0x40d409=='string','internal-error',{'appName':_0x4a28c6}),_0x377ad9['refreshToken']=_0x40d409),_0x49b1f1&&(m(typeof _0x49b1f1=='string','internal-error',{'appName':_0x4a28c6}),_0x377ad9['accessToken']=_0x49b1f1),_0x43f517&&(m(typeof _0x43f517=='number','internal-error',{'appName':_0x4a28c6}),_0x377ad9['expirationTime']=_0x43f517),_0x377ad9;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x58beba){this['accessToken']=_0x58beba['accessToken'],this['refreshToken']=_0x58beba['refreshToken'],this['expirationTime']=_0x58beba['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x36a3ca,_0x1b2cad){m(typeof _0x36a3ca=='string'||typeof _0x36a3ca>'u','internal-error',{'appName':_0x1b2cad});}class K{constructor({uid:_0xd4c1e4,auth:_0xb59d4d,stsTokenManager:_0x54b124,..._0x23630e}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0xd4c1e4,this['auth']=_0xb59d4d,this['stsTokenManager']=_0x54b124,this['accessToken']=_0x54b124['accessToken'],this['displayName']=_0x23630e['displayName']||null,this['email']=_0x23630e['email']||null,this['emailVerified']=_0x23630e['emailVerified']||!0x1,this['phoneNumber']=_0x23630e['phoneNumber']||null,this['photoURL']=_0x23630e['photoURL']||null,this['isAnonymous']=_0x23630e['isAnonymous']||!0x1,this['tenantId']=_0x23630e['tenantId']||null,this['providerData']=_0x23630e['providerData']?[..._0x23630e['providerData']]:[],this['metadata']=new Oi(_0x23630e['createdAt']||void 0x0,_0x23630e['lastLoginAt']||void 0x0);}async['getIdToken'](_0x36f219){const _0x1d624a=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x36f219));return m(_0x1d624a,this['auth'],'internal-error'),this['accessToken']!==_0x1d624a&&(this['accessToken']=_0x1d624a,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x1d624a;}['getIdTokenResult'](_0x10d031){return gf(this,_0x10d031);}['reload'](){return vf(this);}['_assign'](_0x4196d5){this!==_0x4196d5&&(m(this['uid']===_0x4196d5['uid'],this['auth'],'internal-error'),this['displayName']=_0x4196d5['displayName'],this['photoURL']=_0x4196d5['photoURL'],this['email']=_0x4196d5['email'],this['emailVerified']=_0x4196d5['emailVerified'],this['phoneNumber']=_0x4196d5['phoneNumber'],this['isAnonymous']=_0x4196d5['isAnonymous'],this['tenantId']=_0x4196d5['tenantId'],this['providerData']=_0x4196d5['providerData']['map'](_0x325080=>({..._0x325080})),this['metadata']['_copy'](_0x4196d5['metadata']),this['stsTokenManager']['_assign'](_0x4196d5['stsTokenManager']));}['_clone'](_0x245acf){const _0x2d1275=new K({...this,'auth':_0x245acf,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x2d1275['metadata']['_copy'](this['metadata']),_0x2d1275;}['_onReload'](_0x5eee51){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x5eee51,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x238001){this['reloadListener']?this['reloadListener'](_0x238001):this['reloadUserInfo']=_0x238001;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x456924,_0x357d7b=!0x1){let _0x389c1f=!0x1;_0x456924['idToken']&&_0x456924['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x456924),_0x389c1f=!0x0),_0x357d7b&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x389c1f&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x16f710=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x16f710})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x544c50=>({..._0x544c50})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x10ccf8,_0x3476cc){const _0x2f59d1=_0x3476cc['displayName']??void 0x0,_0x153e4d=_0x3476cc['email']??void 0x0,_0xd3a298=_0x3476cc['phoneNumber']??void 0x0,_0x17f7fc=_0x3476cc['photoURL']??void 0x0,_0x340aba=_0x3476cc['tenantId']??void 0x0,_0x16d225=_0x3476cc['_redirectEventId']??void 0x0,_0x1c785c=_0x3476cc['createdAt']??void 0x0,_0x472291=_0x3476cc['lastLoginAt']??void 0x0,{uid:_0x388f71,emailVerified:_0x27db70,isAnonymous:_0xc80f1d,providerData:_0x5dfa45,stsTokenManager:_0x4dfc9f}=_0x3476cc;m(_0x388f71&&_0x4dfc9f,_0x10ccf8,'internal-error');const _0x5a23e2=Qe['fromJSON'](this['name'],_0x4dfc9f);m(typeof _0x388f71=='string',_0x10ccf8,'internal-error'),le(_0x2f59d1,_0x10ccf8['name']),le(_0x153e4d,_0x10ccf8['name']),m(typeof _0x27db70=='boolean',_0x10ccf8,'internal-error'),m(typeof _0xc80f1d=='boolean',_0x10ccf8,'internal-error'),le(_0xd3a298,_0x10ccf8['name']),le(_0x17f7fc,_0x10ccf8['name']),le(_0x340aba,_0x10ccf8['name']),le(_0x16d225,_0x10ccf8['name']),le(_0x1c785c,_0x10ccf8['name']),le(_0x472291,_0x10ccf8['name']);const _0x55725e=new K({'uid':_0x388f71,'auth':_0x10ccf8,'email':_0x153e4d,'emailVerified':_0x27db70,'displayName':_0x2f59d1,'isAnonymous':_0xc80f1d,'photoURL':_0x17f7fc,'phoneNumber':_0xd3a298,'tenantId':_0x340aba,'stsTokenManager':_0x5a23e2,'createdAt':_0x1c785c,'lastLoginAt':_0x472291});return _0x5dfa45&&Array['isArray'](_0x5dfa45)&&(_0x55725e['providerData']=_0x5dfa45['map'](_0x5f7c36=>({..._0x5f7c36}))),_0x16d225&&(_0x55725e['_redirectEventId']=_0x16d225),_0x55725e;}static async['_fromIdTokenResponse'](_0x4da344,_0x3eed68,_0x1f06bf=!0x1){const _0x2d2629=new Qe();_0x2d2629['updateFromServerResponse'](_0x3eed68);const _0x298fd9=new K({'uid':_0x3eed68['localId'],'auth':_0x4da344,'stsTokenManager':_0x2d2629,'isAnonymous':_0x1f06bf});return await Rn(_0x298fd9),_0x298fd9;}static async['_fromGetAccountInfoResponse'](_0x9b733d,_0x458e47,_0x16137a){const _0x119467=_0x458e47['users'][0x0];m(_0x119467['localId']!==void 0x0,'internal-error');const _0x4d63a7=_0x119467['providerUserInfo']!==void 0x0?Sa(_0x119467['providerUserInfo']):[],_0x207692=!(_0x119467['email']&&_0x119467['passwordHash'])&&!(_0x4d63a7!=null&&_0x4d63a7['length']),_0x102008=new Qe();_0x102008['updateFromIdToken'](_0x16137a);const _0x1f192b=new K({'uid':_0x119467['localId'],'auth':_0x9b733d,'stsTokenManager':_0x102008,'isAnonymous':_0x207692}),_0x4db9de={'uid':_0x119467['localId'],'displayName':_0x119467['displayName']||null,'photoURL':_0x119467['photoUrl']||null,'email':_0x119467['email']||null,'emailVerified':_0x119467['emailVerified']||!0x1,'phoneNumber':_0x119467['phoneNumber']||null,'tenantId':_0x119467['tenantId']||null,'providerData':_0x4d63a7,'metadata':new Oi(_0x119467['createdAt'],_0x119467['lastLoginAt']),'isAnonymous':!(_0x119467['email']&&_0x119467['passwordHash'])&&!(_0x4d63a7!=null&&_0x4d63a7['length'])};return Object['assign'](_0x1f192b,_0x4db9de),_0x1f192b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x1f49b7){ce(_0x1f49b7 instanceof Function,'Expected\x20a\x20class\x20definition');let _0xe26fc2=Tr['get'](_0x1f49b7);return _0xe26fc2?(ce(_0xe26fc2 instanceof _0x1f49b7,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0xe26fc2):(_0xe26fc2=new _0x1f49b7(),Tr['set'](_0x1f49b7,_0xe26fc2),_0xe26fc2);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x12e330,_0xf748e1){this['storage'][_0x12e330]=_0xf748e1;}async['_get'](_0x11dcad){const _0x180617=this['storage'][_0x11dcad];return _0x180617===void 0x0?null:_0x180617;}async['_remove'](_0x29e319){delete this['storage'][_0x29e319];}['_addListener'](_0x2caaf6,_0x381238){}['_removeListener'](_0x5e496b,_0x521688){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0xb24c41,_0x4a7f22,_0x5d042d){return'firebase:'+_0xb24c41+':'+_0x4a7f22+':'+_0x5d042d;}class Je{constructor(_0x43cfce,_0xff4961,_0x1a75a7){this['persistence']=_0x43cfce,this['auth']=_0xff4961,this['userKey']=_0x1a75a7;const {config:_0x1b1475,name:_0x3469c9}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x1b1475['apiKey'],_0x3469c9),this['fullPersistenceKey']=rn('persistence',_0x1b1475['apiKey'],_0x3469c9),this['boundEventHandler']=_0xff4961['_onStorageEvent']['bind'](_0xff4961),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x9cb1af){return this['persistence']['_set'](this['fullUserKey'],_0x9cb1af['toJSON']());}async['getCurrentUser'](){const _0x1f5b64=await this['persistence']['_get'](this['fullUserKey']);if(!_0x1f5b64)return null;if(typeof _0x1f5b64=='string'){const _0x459309=await bn(this['auth'],{'idToken':_0x1f5b64})['catch'](()=>{});return _0x459309?K['_fromGetAccountInfoResponse'](this['auth'],_0x459309,_0x1f5b64):null;}return K['_fromJSON'](this['auth'],_0x1f5b64);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x17cf65){if(this['persistence']===_0x17cf65)return;const _0x1c3e7c=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x17cf65,_0x1c3e7c)return this['setCurrentUser'](_0x1c3e7c);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0xe7a094,_0x121375,_0x4de03f='authUser'){if(!_0x121375['length'])return new Je(ie(Sr),_0xe7a094,_0x4de03f);const _0x3dcf68=(await Promise['all'](_0x121375['map'](async _0x2eba50=>{if(await _0x2eba50['_isAvailable']())return _0x2eba50;})))['filter'](_0x138f3f=>_0x138f3f);let _0x497ed6=_0x3dcf68[0x0]||ie(Sr);const _0x59ad50=rn(_0x4de03f,_0xe7a094['config']['apiKey'],_0xe7a094['name']);let _0xb183cb=null;for(const _0x48684b of _0x121375)try{const _0xeb5836=await _0x48684b['_get'](_0x59ad50);if(_0xeb5836){let _0xd03879;if(typeof _0xeb5836=='string'){const _0x3f07d9=await bn(_0xe7a094,{'idToken':_0xeb5836})['catch'](()=>{});if(!_0x3f07d9)break;_0xd03879=await K['_fromGetAccountInfoResponse'](_0xe7a094,_0x3f07d9,_0xeb5836);}else _0xd03879=K['_fromJSON'](_0xe7a094,_0xeb5836);_0x48684b!==_0x497ed6&&(_0xb183cb=_0xd03879),_0x497ed6=_0x48684b;break;}}catch{}const _0x38232d=_0x3dcf68['filter'](_0x28abad=>_0x28abad['_shouldAllowMigration']);return!_0x497ed6['_shouldAllowMigration']||!_0x38232d['length']?new Je(_0x497ed6,_0xe7a094,_0x4de03f):(_0x497ed6=_0x38232d[0x0],_0xb183cb&&await _0x497ed6['_set'](_0x59ad50,_0xb183cb['toJSON']()),await Promise['all'](_0x121375['map'](async _0x1d3b80=>{if(_0x1d3b80!==_0x497ed6)try{await _0x1d3b80['_remove'](_0x59ad50);}catch{}})),new Je(_0x497ed6,_0xe7a094,_0x4de03f));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x4892d9){const _0x42bc1e=_0x4892d9['toLowerCase']();if(_0x42bc1e['includes']('opera/')||_0x42bc1e['includes']('opr/')||_0x42bc1e['includes']('opios/'))return'Opera';if(Na(_0x42bc1e))return'IEMobile';if(_0x42bc1e['includes']('msie')||_0x42bc1e['includes']('trident/'))return'IE';if(_0x42bc1e['includes']('edge/'))return'Edge';if(Ra(_0x42bc1e))return'Firefox';if(_0x42bc1e['includes']('silk/'))return'Silk';if(Oa(_0x42bc1e))return'Blackberry';if(Da(_0x42bc1e))return'Webos';if(Aa(_0x42bc1e))return'Safari';if((_0x42bc1e['includes']('chrome/')||ka(_0x42bc1e))&&!_0x42bc1e['includes']('edge/'))return'Chrome';if(Pa(_0x42bc1e))return'Android';{const _0x877ef5=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x106202=_0x4892d9['match'](_0x877ef5);if((_0x106202==null?void 0x0:_0x106202['length'])===0x2)return _0x106202[0x1];}return'Other';}function Ra(_0x517b08=W()){return/firefox\//i['test'](_0x517b08);}function Aa(_0x5831b0=W()){const _0x39eee8=_0x5831b0['toLowerCase']();return _0x39eee8['includes']('safari/')&&!_0x39eee8['includes']('chrome/')&&!_0x39eee8['includes']('crios/')&&!_0x39eee8['includes']('android');}function ka(_0x123fd7=W()){return/crios\//i['test'](_0x123fd7);}function Na(_0x47ad57=W()){return/iemobile/i['test'](_0x47ad57);}function Pa(_0x1daf56=W()){return/android/i['test'](_0x1daf56);}function Oa(_0x51a13a=W()){return/blackberry/i['test'](_0x51a13a);}function Da(_0x5a4a85=W()){return/webos/i['test'](_0x5a4a85);}function Ss(_0x5b80aa=W()){return/iphone|ipad|ipod/i['test'](_0x5b80aa)||/macintosh/i['test'](_0x5b80aa)&&/mobile/i['test'](_0x5b80aa);}function Cf(_0x458f54=W()){var _0x18d5b0;return Ss(_0x458f54)&&!!((_0x18d5b0=window['navigator'])!=null&&_0x18d5b0['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x30c197=W()){return Ss(_0x30c197)||Pa(_0x30c197)||Da(_0x30c197)||Oa(_0x30c197)||/windows phone/i['test'](_0x30c197)||Na(_0x30c197);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x3e00e9,_0x32c52e=[]){let _0x268d45;switch(_0x3e00e9){case'Browser':_0x268d45=br(W());break;case'Worker':_0x268d45=br(W())+'-'+_0x3e00e9;break;default:_0x268d45=_0x3e00e9;}const _0x37c165=_0x32c52e['length']?_0x32c52e['join'](','):'FirebaseCore-web';return _0x268d45+'/JsCore/'+lt+'/'+_0x37c165;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x473546){this['auth']=_0x473546,this['queue']=[];}['pushCallback'](_0x1e771e,_0x51a891){const _0x353f59=_0x1b8e6f=>new Promise((_0x127a7a,_0x11e17d)=>{try{const _0xf7a82e=_0x1e771e(_0x1b8e6f);_0x127a7a(_0xf7a82e);}catch(_0x168dc8){_0x11e17d(_0x168dc8);}});_0x353f59['onAbort']=_0x51a891,this['queue']['push'](_0x353f59);const _0x3a09d6=this['queue']['length']-0x1;return()=>{this['queue'][_0x3a09d6]=()=>Promise['resolve']();};}async['runMiddleware'](_0x52befd){if(this['auth']['currentUser']===_0x52befd)return;const _0x32700a=[];try{for(const _0x299b55 of this['queue'])await _0x299b55(_0x52befd),_0x299b55['onAbort']&&_0x32700a['push'](_0x299b55['onAbort']);}catch(_0x3a39bb){_0x32700a['reverse']();for(const _0x1def23 of _0x32700a)try{_0x1def23();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x3a39bb==null?void 0x0:_0x3a39bb['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x23c49e,_0x370dc0={}){return Ae(_0x23c49e,'GET','/v2/passwordPolicy',Re(_0x23c49e,_0x370dc0));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x375c8f){var _0x493f15;const _0x539663=_0x375c8f['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x539663['minPasswordLength']??Rf,_0x539663['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x539663['maxPasswordLength']),_0x539663['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x539663['containsLowercaseCharacter']),_0x539663['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x539663['containsUppercaseCharacter']),_0x539663['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x539663['containsNumericCharacter']),_0x539663['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x539663['containsNonAlphanumericCharacter']),this['enforcementState']=_0x375c8f['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x493f15=_0x375c8f['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x493f15['join'](''))??'',this['forceUpgradeOnSignin']=_0x375c8f['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x375c8f['schemaVersion'];}['validatePassword'](_0x4e4d6f){const _0x34742f={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x4e4d6f,_0x34742f),this['validatePasswordCharacterOptions'](_0x4e4d6f,_0x34742f),_0x34742f['isValid']&&(_0x34742f['isValid']=_0x34742f['meetsMinPasswordLength']??!0x0),_0x34742f['isValid']&&(_0x34742f['isValid']=_0x34742f['meetsMaxPasswordLength']??!0x0),_0x34742f['isValid']&&(_0x34742f['isValid']=_0x34742f['containsLowercaseLetter']??!0x0),_0x34742f['isValid']&&(_0x34742f['isValid']=_0x34742f['containsUppercaseLetter']??!0x0),_0x34742f['isValid']&&(_0x34742f['isValid']=_0x34742f['containsNumericCharacter']??!0x0),_0x34742f['isValid']&&(_0x34742f['isValid']=_0x34742f['containsNonAlphanumericCharacter']??!0x0),_0x34742f;}['validatePasswordLengthOptions'](_0x3af657,_0x3ea55a){const _0x52adc6=this['customStrengthOptions']['minPasswordLength'],_0x729ad3=this['customStrengthOptions']['maxPasswordLength'];_0x52adc6&&(_0x3ea55a['meetsMinPasswordLength']=_0x3af657['length']>=_0x52adc6),_0x729ad3&&(_0x3ea55a['meetsMaxPasswordLength']=_0x3af657['length']<=_0x729ad3);}['validatePasswordCharacterOptions'](_0x22179b,_0x52b79e){this['updatePasswordCharacterOptionsStatuses'](_0x52b79e,!0x1,!0x1,!0x1,!0x1);let _0x57fa9e;for(let _0xfbfe9f=0x0;_0xfbfe9f<_0x22179b['length'];_0xfbfe9f++)_0x57fa9e=_0x22179b['charAt'](_0xfbfe9f),this['updatePasswordCharacterOptionsStatuses'](_0x52b79e,_0x57fa9e>='a'&&_0x57fa9e<='z',_0x57fa9e>='A'&&_0x57fa9e<='Z',_0x57fa9e>='0'&&_0x57fa9e<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x57fa9e));}['updatePasswordCharacterOptionsStatuses'](_0x2351dc,_0x461147,_0x13ec85,_0xd6be79,_0x2990ad){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x2351dc['containsLowercaseLetter']||(_0x2351dc['containsLowercaseLetter']=_0x461147)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x2351dc['containsUppercaseLetter']||(_0x2351dc['containsUppercaseLetter']=_0x13ec85)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x2351dc['containsNumericCharacter']||(_0x2351dc['containsNumericCharacter']=_0xd6be79)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x2351dc['containsNonAlphanumericCharacter']||(_0x2351dc['containsNonAlphanumericCharacter']=_0x2990ad));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x1a90b9,_0x3ef95d,_0x4a50e8,_0x19dcd8){this['app']=_0x1a90b9,this['heartbeatServiceProvider']=_0x3ef95d,this['appCheckServiceProvider']=_0x4a50e8,this['config']=_0x19dcd8,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x1a90b9['name'],this['clientVersion']=_0x19dcd8['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0xc3c942=>this['_resolvePersistenceManagerAvailable']=_0xc3c942);}['_initializeWithPersistence'](_0x54f69f,_0x3a06e6){return _0x3a06e6&&(this['_popupRedirectResolver']=ie(_0x3a06e6)),this['_initializationPromise']=this['queue'](async()=>{var _0x2562de,_0x477258,_0x2914d1;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x54f69f),(_0x2562de=this['_resolvePersistenceManagerAvailable'])==null||_0x2562de['call'](this),!this['_deleted'])){if((_0x477258=this['_popupRedirectResolver'])!=null&&_0x477258['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x3a06e6),this['lastNotifiedUid']=((_0x2914d1=this['currentUser'])==null?void 0x0:_0x2914d1['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0xcd65b2=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0xcd65b2)){if(this['currentUser']&&_0xcd65b2&&this['currentUser']['uid']===_0xcd65b2['uid']){this['_currentUser']['_assign'](_0xcd65b2),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0xcd65b2,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x4d1662){try{const _0x181294=await bn(this,{'idToken':_0x4d1662}),_0x4a49cc=await K['_fromGetAccountInfoResponse'](this,_0x181294,_0x4d1662);await this['directlySetCurrentUser'](_0x4a49cc);}catch(_0x5259b7){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x5259b7),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x39058d){var _0x2f86eb;if($(this['app'])){const _0x55d90d=this['app']['settings']['authIdToken'];return _0x55d90d?new Promise(_0xabc6da=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x55d90d)['then'](_0xabc6da,_0xabc6da));}):this['directlySetCurrentUser'](null);}const _0x1ab016=await this['assertedPersistence']['getCurrentUser']();let _0x3dfd55=_0x1ab016,_0x238c6e=!0x1;if(_0x39058d&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x351e9e=(_0x2f86eb=this['redirectUser'])==null?void 0x0:_0x2f86eb['_redirectEventId'],_0x4bded1=_0x3dfd55==null?void 0x0:_0x3dfd55['_redirectEventId'],_0x346287=await this['tryRedirectSignIn'](_0x39058d);(!_0x351e9e||_0x351e9e===_0x4bded1)&&(_0x346287!=null&&_0x346287['user'])&&(_0x3dfd55=_0x346287['user'],_0x238c6e=!0x0);}if(!_0x3dfd55)return this['directlySetCurrentUser'](null);if(!_0x3dfd55['_redirectEventId']){if(_0x238c6e)try{await this['beforeStateQueue']['runMiddleware'](_0x3dfd55);}catch(_0x578a95){_0x3dfd55=_0x1ab016,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x578a95));}return _0x3dfd55?this['reloadAndSetCurrentUserOrClear'](_0x3dfd55):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x3dfd55['_redirectEventId']?this['directlySetCurrentUser'](_0x3dfd55):this['reloadAndSetCurrentUserOrClear'](_0x3dfd55);}async['tryRedirectSignIn'](_0x2177ab){let _0x1779f7=null;try{_0x1779f7=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x2177ab,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x1779f7;}async['reloadAndSetCurrentUserOrClear'](_0x203d6b){try{await Rn(_0x203d6b);}catch(_0x3f87ca){if((_0x3f87ca==null?void 0x0:_0x3f87ca['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x203d6b);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x56b01c){if($(this['app']))return Promise['reject'](re(this));const _0x497628=_0x56b01c?N(_0x56b01c):null;return _0x497628&&m(_0x497628['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x497628&&_0x497628['_clone'](this));}async['_updateCurrentUser'](_0x44a7f3,_0x8d6624=!0x1){if(!this['_deleted'])return _0x44a7f3&&m(this['tenantId']===_0x44a7f3['tenantId'],this,'tenant-id-mismatch'),_0x8d6624||await this['beforeStateQueue']['runMiddleware'](_0x44a7f3),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x44a7f3),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x26f0ab){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x26f0ab));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x605ddc){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x1e5be4=this['_getPasswordPolicyInternal']();return _0x1e5be4['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x1e5be4['validatePassword'](_0x605ddc);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x5e59dd=await bf(this),_0x24669b=new Af(_0x5e59dd);this['tenantId']===null?this['_projectPasswordPolicy']=_0x24669b:this['_tenantPasswordPolicies'][this['tenantId']]=_0x24669b;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x1c368a){this['_errorFactory']=new Bt('auth','Firebase',_0x1c368a());}['onAuthStateChanged'](_0x359c6e,_0x1cc6be,_0x500a21){return this['registerStateListener'](this['authStateSubscription'],_0x359c6e,_0x1cc6be,_0x500a21);}['beforeAuthStateChanged'](_0x19aa3a,_0x283c6e){return this['beforeStateQueue']['pushCallback'](_0x19aa3a,_0x283c6e);}['onIdTokenChanged'](_0x3ee138,_0x545769,_0x12e179){return this['registerStateListener'](this['idTokenSubscription'],_0x3ee138,_0x545769,_0x12e179);}['authStateReady'](){return new Promise((_0x4b1251,_0x519a8e)=>{if(this['currentUser'])_0x4b1251();else{const _0x5a9ee7=this['onAuthStateChanged'](()=>{_0x5a9ee7(),_0x4b1251();},_0x519a8e);}});}async['revokeAccessToken'](_0x3e15aa){if(this['currentUser']){const _0x5492dd=await this['currentUser']['getIdToken'](),_0x4b7b57={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x3e15aa,'idToken':_0x5492dd};this['tenantId']!=null&&(_0x4b7b57['tenantId']=this['tenantId']),await wf(this,_0x4b7b57);}}['toJSON'](){var _0x5db6b7;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x5db6b7=this['_currentUser'])==null?void 0x0:_0x5db6b7['toJSON']()};}async['_setRedirectUser'](_0x48f77b,_0x2da226){const _0x571f74=await this['getOrInitRedirectPersistenceManager'](_0x2da226);return _0x48f77b===null?_0x571f74['removeCurrentUser']():_0x571f74['setCurrentUser'](_0x48f77b);}async['getOrInitRedirectPersistenceManager'](_0x57b746){if(!this['redirectPersistenceManager']){const _0x5e1660=_0x57b746&&ie(_0x57b746)||this['_popupRedirectResolver'];m(_0x5e1660,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x5e1660['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x3ecd62){var _0x21ad65,_0x444374;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x21ad65=this['_currentUser'])==null?void 0x0:_0x21ad65['_redirectEventId'])===_0x3ecd62?this['_currentUser']:((_0x444374=this['redirectUser'])==null?void 0x0:_0x444374['_redirectEventId'])===_0x3ecd62?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x1a7bb8){if(_0x1a7bb8===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x1a7bb8));}['_notifyListenersIfCurrent'](_0x3e0e6c){_0x3e0e6c===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x267a3b;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x3b6c80=((_0x267a3b=this['currentUser'])==null?void 0x0:_0x267a3b['uid'])??null;this['lastNotifiedUid']!==_0x3b6c80&&(this['lastNotifiedUid']=_0x3b6c80,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x357677,_0x3ad9c2,_0x2d8d03,_0x2219e3){if(this['_deleted'])return()=>{};const _0x201931=typeof _0x3ad9c2=='function'?_0x3ad9c2:_0x3ad9c2['next']['bind'](_0x3ad9c2);let _0x27203e=!0x1;const _0x47173e=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x47173e,this,'internal-error'),_0x47173e['then'](()=>{_0x27203e||_0x201931(this['currentUser']);}),typeof _0x3ad9c2=='function'){const _0x9f2391=_0x357677['addObserver'](_0x3ad9c2,_0x2d8d03,_0x2219e3);return()=>{_0x27203e=!0x0,_0x9f2391();};}else{const _0x452192=_0x357677['addObserver'](_0x3ad9c2);return()=>{_0x27203e=!0x0,_0x452192();};}}async['directlySetCurrentUser'](_0x3782a5){this['currentUser']&&this['currentUser']!==_0x3782a5&&this['_currentUser']['_stopProactiveRefresh'](),_0x3782a5&&this['isProactiveRefreshEnabled']&&_0x3782a5['_startProactiveRefresh'](),this['currentUser']=_0x3782a5,_0x3782a5?await this['assertedPersistence']['setCurrentUser'](_0x3782a5):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x51ee97){return this['operations']=this['operations']['then'](_0x51ee97,_0x51ee97),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x30e90c){!_0x30e90c||this['frameworks']['includes'](_0x30e90c)||(this['frameworks']['push'](_0x30e90c),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x100674;const _0x241c94={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x241c94['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x55984d=await((_0x100674=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x100674['getHeartbeatsHeader']());_0x55984d&&(_0x241c94['X-Firebase-Client']=_0x55984d);const _0xd95f91=await this['_getAppCheckToken']();return _0xd95f91&&(_0x241c94['X-Firebase-AppCheck']=_0xd95f91),_0x241c94;}async['_getAppCheckToken'](){var _0x135444;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x3ed98f=await((_0x135444=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x135444['getToken']());return _0x3ed98f!=null&&_0x3ed98f['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x3ed98f['error']),_0x3ed98f==null?void 0x0:_0x3ed98f['token'];}}function qe(_0x211d8c){return N(_0x211d8c);}class Rr{constructor(_0x18b6f9){this['auth']=_0x18b6f9,this['observer']=null,this['addObserver']=Tc(_0x58f7f1=>this['observer']=_0x58f7f1);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x573541){jn=_0x573541;}function xa(_0x12ca0f){return jn['loadJS'](_0x12ca0f);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x4c8df7){return'__'+_0x4c8df7+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x539ccd){_0x539ccd();}['execute'](_0x4e1629,_0x3a844f){return Promise['resolve']('token');}['render'](_0x1ba887,_0x569175){return'';}}class Lf{['ready'](_0x4897d6){_0x4897d6();}['execute'](_0x2b70b9,_0x5e0c9a){return Promise['resolve']('token');}['render'](_0x518575,_0x5c68d1){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x2ce141){this['type']=xf,this['auth']=qe(_0x2ce141);}async['verify'](_0x4b52ed='verify',_0x56aa5e=!0x1){async function _0x2d5c7e(_0x4a1b92){if(!_0x56aa5e){if(_0x4a1b92['tenantId']==null&&_0x4a1b92['_agentRecaptchaConfig']!=null)return _0x4a1b92['_agentRecaptchaConfig']['siteKey'];if(_0x4a1b92['tenantId']!=null&&_0x4a1b92['_tenantRecaptchaConfigs'][_0x4a1b92['tenantId']]!==void 0x0)return _0x4a1b92['_tenantRecaptchaConfigs'][_0x4a1b92['tenantId']]['siteKey'];}return new Promise(async(_0x31a263,_0x36c9ae)=>{pf(_0x4a1b92,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x1851d2=>{if(_0x1851d2['recaptchaKey']===void 0x0)_0x36c9ae(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x414354=new ff(_0x1851d2);return _0x4a1b92['tenantId']==null?_0x4a1b92['_agentRecaptchaConfig']=_0x414354:_0x4a1b92['_tenantRecaptchaConfigs'][_0x4a1b92['tenantId']]=_0x414354,_0x31a263(_0x414354['siteKey']);}})['catch'](_0x44c694=>{_0x36c9ae(_0x44c694);});});}function _0x473780(_0xd53530,_0x2b6735,_0x436cc8){const _0xdfc7b3=window['grecaptcha'];wr(_0xdfc7b3)?_0xdfc7b3['enterprise']['ready'](()=>{_0xdfc7b3['enterprise']['execute'](_0xd53530,{'action':_0x4b52ed})['then'](_0x5276b6=>{_0x2b6735(_0x5276b6);})['catch'](()=>{_0x2b6735(Fa);});}):_0x436cc8(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x37dc9f,_0xf0953c)=>{_0x2d5c7e(this['auth'])['then'](_0x2878ca=>{if(!_0x56aa5e&&wr(window['grecaptcha']))_0x473780(_0x2878ca,_0x37dc9f,_0xf0953c);else{if(typeof window>'u'){_0xf0953c(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x5bedef=Pf();_0x5bedef['length']!==0x0&&(_0x5bedef+=_0x2878ca),xa(_0x5bedef)['then'](()=>{_0x473780(_0x2878ca,_0x37dc9f,_0xf0953c);})['catch'](_0x4d61d3=>{_0xf0953c(_0x4d61d3);});}})['catch'](_0x3c220d=>{_0xf0953c(_0x3c220d);});});}}async function Ar(_0x42b7cf,_0x193812,_0x123a3a,_0x4d1922=!0x1,_0x4b7369=!0x1){const _0x23581d=new Ff(_0x42b7cf);let _0x2184d1;if(_0x4b7369)_0x2184d1=Fa;else try{_0x2184d1=await _0x23581d['verify'](_0x123a3a);}catch{_0x2184d1=await _0x23581d['verify'](_0x123a3a,!0x0);}const _0x17cfd5={..._0x193812};if(_0x123a3a==='mfaSmsEnrollment'||_0x123a3a==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x17cfd5){const _0x306c79=_0x17cfd5['phoneEnrollmentInfo']['phoneNumber'],_0x3f1684=_0x17cfd5['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x17cfd5,{'phoneEnrollmentInfo':{'phoneNumber':_0x306c79,'recaptchaToken':_0x3f1684,'captchaResponse':_0x2184d1,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x17cfd5){const _0x24ba58=_0x17cfd5['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x17cfd5,{'phoneSignInInfo':{'recaptchaToken':_0x24ba58,'captchaResponse':_0x2184d1,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x17cfd5;}return _0x4d1922?Object['assign'](_0x17cfd5,{'captchaResp':_0x2184d1}):Object['assign'](_0x17cfd5,{'captchaResponse':_0x2184d1}),Object['assign'](_0x17cfd5,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x17cfd5,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x17cfd5;}async function Di(_0x3e7bb1,_0x68b802,_0x3e6f7a,_0x2a911d,_0x445858){var _0xd16be3;if((_0xd16be3=_0x3e7bb1['_getRecaptchaConfig']())!=null&&_0xd16be3['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0xdb8430=await Ar(_0x3e7bb1,_0x68b802,_0x3e6f7a,_0x3e6f7a==='getOobCode');return _0x2a911d(_0x3e7bb1,_0xdb8430);}else return _0x2a911d(_0x3e7bb1,_0x68b802)['catch'](async _0x11bc63=>{if(_0x11bc63['code']==='auth/missing-recaptcha-token'){console['log'](_0x3e6f7a+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x5d59f2=await Ar(_0x3e7bb1,_0x68b802,_0x3e6f7a,_0x3e6f7a==='getOobCode');return _0x2a911d(_0x3e7bb1,_0x5d59f2);}else return Promise['reject'](_0x11bc63);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0xbdb9dd,_0x1cc86b){const _0x358a00=Bi(_0xbdb9dd,'auth');if(_0x358a00['isInitialized']()){const _0xc5347d=_0x358a00['getImmediate'](),_0x2db196=_0x358a00['getOptions']();if(Me(_0x2db196,_0x1cc86b??{}))return _0xc5347d;Q(_0xc5347d,'already-initialized');}return _0x358a00['initialize']({'options':_0x1cc86b});}function Wf(_0xadb996,_0x45fb74){const _0x562ea6=(_0x45fb74==null?void 0x0:_0x45fb74['persistence'])||[],_0x2882f4=(Array['isArray'](_0x562ea6)?_0x562ea6:[_0x562ea6])['map'](ie);_0x45fb74!=null&&_0x45fb74['errorMap']&&_0xadb996['_updateErrorMap'](_0x45fb74['errorMap']),_0xadb996['_initializeWithPersistence'](_0x2882f4,_0x45fb74==null?void 0x0:_0x45fb74['popupRedirectResolver']);}function Bf(_0x3173e1,_0x578e92,_0x1c1aba){const _0x10893e=qe(_0x3173e1);m(/^https?:\/\//['test'](_0x578e92),_0x10893e,'invalid-emulator-scheme');const _0x27f7aa=!0x1,_0x4f20e5=Ua(_0x578e92),{host:_0xac89b4,port:_0x45c69a}=Vf(_0x578e92),_0x313fad=_0x45c69a===null?'':':'+_0x45c69a,_0xb1ad28={'url':_0x4f20e5+'//'+_0xac89b4+_0x313fad+'/'},_0x668faf=Object['freeze']({'host':_0xac89b4,'port':_0x45c69a,'protocol':_0x4f20e5['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x27f7aa})});if(!_0x10893e['_canInitEmulator']){m(_0x10893e['config']['emulator']&&_0x10893e['emulatorConfig'],_0x10893e,'emulator-config-failed'),m(Me(_0xb1ad28,_0x10893e['config']['emulator'])&&Me(_0x668faf,_0x10893e['emulatorConfig']),_0x10893e,'emulator-config-failed');return;}_0x10893e['config']['emulator']=_0xb1ad28,_0x10893e['emulatorConfig']=_0x668faf,_0x10893e['settings']['appVerificationDisabledForTesting']=!0x0,at(_0xac89b4)?(jr(_0x4f20e5+'//'+_0xac89b4+_0x313fad),Kr('Auth',!0x0)):Hf();}function Ua(_0x12c8d8){const _0x4f005e=_0x12c8d8['indexOf'](':');return _0x4f005e<0x0?'':_0x12c8d8['substr'](0x0,_0x4f005e+0x1);}function Vf(_0x57134d){const _0x116af5=Ua(_0x57134d),_0x207a79=/(\/\/)?([^?#/]+)/['exec'](_0x57134d['substr'](_0x116af5['length']));if(!_0x207a79)return{'host':'','port':null};const _0x5dc0b8=_0x207a79[0x2]['split']('@')['pop']()||'',_0x209910=/^(\[[^\]]+\])(:|$)/['exec'](_0x5dc0b8);if(_0x209910){const _0x32e0f9=_0x209910[0x1];return{'host':_0x32e0f9,'port':kr(_0x5dc0b8['substr'](_0x32e0f9['length']+0x1))};}else{const [_0x4fad0c,_0x325f9f]=_0x5dc0b8['split'](':');return{'host':_0x4fad0c,'port':kr(_0x325f9f)};}}function kr(_0x48eb76){if(!_0x48eb76)return null;const _0x5c46e1=Number(_0x48eb76);return isNaN(_0x5c46e1)?null:_0x5c46e1;}function Hf(){function _0x14dc8b(){const _0x15c6b3=document['createElement']('p'),_0x403828=_0x15c6b3['style'];_0x15c6b3['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x403828['position']='fixed',_0x403828['width']='100%',_0x403828['backgroundColor']='#ffffff',_0x403828['border']='.1em\x20solid\x20#000000',_0x403828['color']='#b50000',_0x403828['bottom']='0px',_0x403828['left']='0px',_0x403828['margin']='0px',_0x403828['zIndex']='10000',_0x403828['textAlign']='center',_0x15c6b3['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x15c6b3);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x14dc8b):_0x14dc8b());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0xea5137,_0x2fc635){this['providerId']=_0xea5137,this['signInMethod']=_0x2fc635;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x5c9e58){return ne('not\x20implemented');}['_linkToIdToken'](_0x27d95e,_0x1df416){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x162b8c){return ne('not\x20implemented');}}async function $f(_0x414c4c,_0x368d03){return Ae(_0x414c4c,'POST','/v1/accounts:signUp',_0x368d03);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x268ad7,_0x5fb201){return Qt(_0x268ad7,'POST','/v1/accounts:signInWithPassword',Re(_0x268ad7,_0x5fb201));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x1f3745,_0x493052){return Qt(_0x1f3745,'POST','/v1/accounts:signInWithEmailLink',Re(_0x1f3745,_0x493052));}async function zf(_0x242134,_0x1df903){return Qt(_0x242134,'POST','/v1/accounts:signInWithEmailLink',Re(_0x242134,_0x1df903));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x52b63f,_0x59b335,_0x183b6e,_0x1bab69=null){super('password',_0x183b6e),this['_email']=_0x52b63f,this['_password']=_0x59b335,this['_tenantId']=_0x1bab69;}static['_fromEmailAndPassword'](_0x296468,_0x212647){return new Wt(_0x296468,_0x212647,'password');}static['_fromEmailAndCode'](_0x3bcdca,_0x505627,_0x33ff6a=null){return new Wt(_0x3bcdca,_0x505627,'emailLink',_0x33ff6a);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x2b8571){const _0x2de290=typeof _0x2b8571=='string'?JSON['parse'](_0x2b8571):_0x2b8571;if(_0x2de290!=null&&_0x2de290['email']&&(_0x2de290!=null&&_0x2de290['password'])){if(_0x2de290['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x2de290['email'],_0x2de290['password']);if(_0x2de290['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x2de290['email'],_0x2de290['password'],_0x2de290['tenantId']);}return null;}async['_getIdTokenResponse'](_0x489ae6){switch(this['signInMethod']){case'password':const _0x4174e4={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x489ae6,_0x4174e4,'signInWithPassword',Gf);case'emailLink':return qf(_0x489ae6,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x489ae6,'internal-error');}}async['_linkToIdToken'](_0x3008d9,_0x4184c3){switch(this['signInMethod']){case'password':const _0x38e63b={'idToken':_0x4184c3,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x3008d9,_0x38e63b,'signUpPassword',$f);case'emailLink':return zf(_0x3008d9,{'idToken':_0x4184c3,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x3008d9,'internal-error');}}['_getReauthenticationResolver'](_0x269a26){return this['_getIdTokenResponse'](_0x269a26);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x592583,_0x2e2921){return Qt(_0x592583,'POST','/v1/accounts:signInWithIdp',Re(_0x592583,_0x2e2921));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x5a5801){const _0x21585d=new Be(_0x5a5801['providerId'],_0x5a5801['signInMethod']);return _0x5a5801['idToken']||_0x5a5801['accessToken']?(_0x5a5801['idToken']&&(_0x21585d['idToken']=_0x5a5801['idToken']),_0x5a5801['accessToken']&&(_0x21585d['accessToken']=_0x5a5801['accessToken']),_0x5a5801['nonce']&&!_0x5a5801['pendingToken']&&(_0x21585d['nonce']=_0x5a5801['nonce']),_0x5a5801['pendingToken']&&(_0x21585d['pendingToken']=_0x5a5801['pendingToken'])):_0x5a5801['oauthToken']&&_0x5a5801['oauthTokenSecret']?(_0x21585d['accessToken']=_0x5a5801['oauthToken'],_0x21585d['secret']=_0x5a5801['oauthTokenSecret']):Q('argument-error'),_0x21585d;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x18c590){const _0x5b6eee=typeof _0x18c590=='string'?JSON['parse'](_0x18c590):_0x18c590,{providerId:_0x50a2f0,signInMethod:_0x39e9b5,..._0x591f45}=_0x5b6eee;if(!_0x50a2f0||!_0x39e9b5)return null;const _0x28e941=new Be(_0x50a2f0,_0x39e9b5);return _0x28e941['idToken']=_0x591f45['idToken']||void 0x0,_0x28e941['accessToken']=_0x591f45['accessToken']||void 0x0,_0x28e941['secret']=_0x591f45['secret'],_0x28e941['nonce']=_0x591f45['nonce'],_0x28e941['pendingToken']=_0x591f45['pendingToken']||null,_0x28e941;}['_getIdTokenResponse'](_0x219744){const _0x2def8f=this['buildRequest']();return Xe(_0x219744,_0x2def8f);}['_linkToIdToken'](_0x33bf60,_0x57d13c){const _0x1acc5f=this['buildRequest']();return _0x1acc5f['idToken']=_0x57d13c,Xe(_0x33bf60,_0x1acc5f);}['_getReauthenticationResolver'](_0x90878a){const _0x47ce2f=this['buildRequest']();return _0x47ce2f['autoCreate']=!0x1,Xe(_0x90878a,_0x47ce2f);}['buildRequest'](){const _0x4a5169={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x4a5169['pendingToken']=this['pendingToken'];else{const _0x474e12={};this['idToken']&&(_0x474e12['id_token']=this['idToken']),this['accessToken']&&(_0x474e12['access_token']=this['accessToken']),this['secret']&&(_0x474e12['oauth_token_secret']=this['secret']),_0x474e12['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x474e12['nonce']=this['nonce']),_0x4a5169['postBody']=ct(_0x474e12);}return _0x4a5169;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x581f27){switch(_0x581f27){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x320d17){const _0x110f80=vt(Et(_0x320d17))['link'],_0x3cfc45=_0x110f80?vt(Et(_0x110f80))['deep_link_id']:null,_0x1458f0=vt(Et(_0x320d17))['deep_link_id'];return(_0x1458f0?vt(Et(_0x1458f0))['link']:null)||_0x1458f0||_0x3cfc45||_0x110f80||_0x320d17;}class Rs{constructor(_0x5b5737){const _0x2effe2=vt(Et(_0x5b5737)),_0x3b6033=_0x2effe2['apiKey']??null,_0x154dd3=_0x2effe2['oobCode']??null,_0xe19c26=Kf(_0x2effe2['mode']??null);m(_0x3b6033&&_0x154dd3&&_0xe19c26,'argument-error'),this['apiKey']=_0x3b6033,this['operation']=_0xe19c26,this['code']=_0x154dd3,this['continueUrl']=_0x2effe2['continueUrl']??null,this['languageCode']=_0x2effe2['lang']??null,this['tenantId']=_0x2effe2['tenantId']??null;}static['parseLink'](_0x2ca553){const _0x4e637b=Yf(_0x2ca553);try{return new Rs(_0x4e637b);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x46ae47,_0x447eea){return Wt['_fromEmailAndPassword'](_0x46ae47,_0x447eea);}static['credentialWithLink'](_0x8e468e,_0x5dc3ba){const _0x28a76b=Rs['parseLink'](_0x5dc3ba);return m(_0x28a76b,'argument-error'),Wt['_fromEmailAndCode'](_0x8e468e,_0x28a76b['code'],_0x28a76b['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x5ccab6){this['providerId']=_0x5ccab6,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x19b8a9){this['defaultLanguageCode']=_0x19b8a9;}['setCustomParameters'](_0x40ba6a){return this['customParameters']=_0x40ba6a,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5caca8){return this['scopes']['includes'](_0x5caca8)||this['scopes']['push'](_0x5caca8),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x151fd5){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x151fd5});}static['credentialFromResult'](_0x296cb1){return he['credentialFromTaggedObject'](_0x296cb1);}static['credentialFromError'](_0x2661bd){return he['credentialFromTaggedObject'](_0x2661bd['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xee2e14}){if(!_0xee2e14||!('oauthAccessToken'in _0xee2e14)||!_0xee2e14['oauthAccessToken'])return null;try{return he['credential'](_0xee2e14['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x8d3294,_0x376013){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x8d3294,'accessToken':_0x376013});}static['credentialFromResult'](_0x17a681){return ue['credentialFromTaggedObject'](_0x17a681);}static['credentialFromError'](_0xdd348c){return ue['credentialFromTaggedObject'](_0xdd348c['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5ed252}){if(!_0x5ed252)return null;const {oauthIdToken:_0x18b0d0,oauthAccessToken:_0x76ff55}=_0x5ed252;if(!_0x18b0d0&&!_0x76ff55)return null;try{return ue['credential'](_0x18b0d0,_0x76ff55);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x288b7e){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x288b7e});}static['credentialFromResult'](_0x3b4343){return de['credentialFromTaggedObject'](_0x3b4343);}static['credentialFromError'](_0x65334c){return de['credentialFromTaggedObject'](_0x65334c['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5e08b9}){if(!_0x5e08b9||!('oauthAccessToken'in _0x5e08b9)||!_0x5e08b9['oauthAccessToken'])return null;try{return de['credential'](_0x5e08b9['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x251a76,_0x17417b){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x251a76,'oauthTokenSecret':_0x17417b});}static['credentialFromResult'](_0x539480){return fe['credentialFromTaggedObject'](_0x539480);}static['credentialFromError'](_0x508f34){return fe['credentialFromTaggedObject'](_0x508f34['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5a98b0}){if(!_0x5a98b0)return null;const {oauthAccessToken:_0x4e6a33,oauthTokenSecret:_0x3d70ce}=_0x5a98b0;if(!_0x4e6a33||!_0x3d70ce)return null;try{return fe['credential'](_0x4e6a33,_0x3d70ce);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x4a6b6d,_0x4a0169){return Qt(_0x4a6b6d,'POST','/v1/accounts:signUp',Re(_0x4a6b6d,_0x4a0169));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0xddab5b){this['user']=_0xddab5b['user'],this['providerId']=_0xddab5b['providerId'],this['_tokenResponse']=_0xddab5b['_tokenResponse'],this['operationType']=_0xddab5b['operationType'];}static async['_fromIdTokenResponse'](_0x200ecd,_0x4358df,_0x46488b,_0x2b12a8=!0x1){const _0x29f4ce=await K['_fromIdTokenResponse'](_0x200ecd,_0x46488b,_0x2b12a8),_0xab7034=Nr(_0x46488b);return new Ve({'user':_0x29f4ce,'providerId':_0xab7034,'_tokenResponse':_0x46488b,'operationType':_0x4358df});}static async['_forOperation'](_0x41e940,_0x64a4e7,_0x54d563){await _0x41e940['_updateTokensIfNecessary'](_0x54d563,!0x0);const _0x32f8e4=Nr(_0x54d563);return new Ve({'user':_0x41e940,'providerId':_0x32f8e4,'_tokenResponse':_0x54d563,'operationType':_0x64a4e7});}}function Nr(_0x26d51f){return _0x26d51f['providerId']?_0x26d51f['providerId']:'phoneNumber'in _0x26d51f?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x9c2ab5,_0x30a837,_0x2559d2,_0x57cabf){super(_0x30a837['code'],_0x30a837['message']),this['operationType']=_0x2559d2,this['user']=_0x57cabf,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x9c2ab5['name'],'tenantId':_0x9c2ab5['tenantId']??void 0x0,'_serverResponse':_0x30a837['customData']['_serverResponse'],'operationType':_0x2559d2};}static['_fromErrorAndOperation'](_0x177f9a,_0x4f05c7,_0x178381,_0x2f7bd7){return new An(_0x177f9a,_0x4f05c7,_0x178381,_0x2f7bd7);}}function Ba(_0xb91c2,_0x4ee3b1,_0x578389,_0x1ff793){return(_0x4ee3b1==='reauthenticate'?_0x578389['_getReauthenticationResolver'](_0xb91c2):_0x578389['_getIdTokenResponse'](_0xb91c2))['catch'](_0x251b41=>{throw _0x251b41['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0xb91c2,_0x251b41,_0x4ee3b1,_0x1ff793):_0x251b41;});}async function Jf(_0x40b271,_0x26838f,_0x33c4eb=!0x1){const _0x2d383c=await Ut(_0x40b271,_0x26838f['_linkToIdToken'](_0x40b271['auth'],await _0x40b271['getIdToken']()),_0x33c4eb);return Ve['_forOperation'](_0x40b271,'link',_0x2d383c);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x3c362e,_0x558700,_0x12e25c=!0x1){const {auth:_0x55f1e4}=_0x3c362e;if($(_0x55f1e4['app']))return Promise['reject'](re(_0x55f1e4));const _0x34e52f='reauthenticate';try{const _0x1f6d04=await Ut(_0x3c362e,Ba(_0x55f1e4,_0x34e52f,_0x558700,_0x3c362e),_0x12e25c);m(_0x1f6d04['idToken'],_0x55f1e4,'internal-error');const _0x5b0bc6=Ts(_0x1f6d04['idToken']);m(_0x5b0bc6,_0x55f1e4,'internal-error');const {sub:_0xad4cab}=_0x5b0bc6;return m(_0x3c362e['uid']===_0xad4cab,_0x55f1e4,'user-mismatch'),Ve['_forOperation'](_0x3c362e,_0x34e52f,_0x1f6d04);}catch(_0x1f94c4){throw(_0x1f94c4==null?void 0x0:_0x1f94c4['code'])==='auth/user-not-found'&&Q(_0x55f1e4,'user-mismatch'),_0x1f94c4;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x1bd256,_0x34cac6,_0x2f4ea0=!0x1){if($(_0x1bd256['app']))return Promise['reject'](re(_0x1bd256));const _0x52ea74='signIn',_0x173751=await Ba(_0x1bd256,_0x52ea74,_0x34cac6),_0x4e37c5=await Ve['_fromIdTokenResponse'](_0x1bd256,_0x52ea74,_0x173751);return _0x2f4ea0||await _0x1bd256['_updateCurrentUser'](_0x4e37c5['user']),_0x4e37c5;}async function Zf(_0x2e38ff,_0x7bdf96){return Va(qe(_0x2e38ff),_0x7bdf96);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x17ebc3){const _0x41eba1=qe(_0x17ebc3);_0x41eba1['_getPasswordPolicyInternal']()&&await _0x41eba1['_updatePasswordPolicy']();}async function P_(_0xa36bf1,_0x3a106e,_0x538645){if($(_0xa36bf1['app']))return Promise['reject'](re(_0xa36bf1));const _0x3ac31a=qe(_0xa36bf1),_0x1175b7=await Di(_0x3ac31a,{'returnSecureToken':!0x0,'email':_0x3a106e,'password':_0x538645,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x154023=>{throw _0x154023['code']==='auth/password-does-not-meet-requirements'&&Ha(_0xa36bf1),_0x154023;}),_0x3a3c85=await Ve['_fromIdTokenResponse'](_0x3ac31a,'signIn',_0x1175b7);return await _0x3ac31a['_updateCurrentUser'](_0x3a3c85['user']),_0x3a3c85;}function O_(_0x140032,_0x4f0141,_0x1283ae){return $(_0x140032['app'])?Promise['reject'](re(_0x140032)):Zf(N(_0x140032),pt['credential'](_0x4f0141,_0x1283ae))['catch'](async _0x395234=>{throw _0x395234['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x140032),_0x395234;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x31fd23,_0xc3da3f){return N(_0x31fd23)['setPersistence'](_0xc3da3f);}function ep(_0x35aea8,_0x52b70c,_0x5b5485,_0x47d8d8){return N(_0x35aea8)['onIdTokenChanged'](_0x52b70c,_0x5b5485,_0x47d8d8);}function tp(_0x26795a,_0xad163,_0x61cdfe){return N(_0x26795a)['beforeAuthStateChanged'](_0xad163,_0x61cdfe);}function M_(_0x1add42,_0x4d6fb2,_0x1c1d22,_0x3a8b4c){return N(_0x1add42)['onAuthStateChanged'](_0x4d6fb2,_0x1c1d22,_0x3a8b4c);}function L_(_0x1b45c0){return N(_0x1b45c0)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0xc00007,_0x47d22a){this['storageRetriever']=_0xc00007,this['type']=_0x47d22a;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x5248f5,_0x79769d){return this['storage']['setItem'](_0x5248f5,JSON['stringify'](_0x79769d)),Promise['resolve']();}['_get'](_0x46d8c3){const _0x351b22=this['storage']['getItem'](_0x46d8c3);return Promise['resolve'](_0x351b22?JSON['parse'](_0x351b22):null);}['_remove'](_0x203ff5){return this['storage']['removeItem'](_0x203ff5),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x120890,_0x454941)=>this['onStorageEvent'](_0x120890,_0x454941),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x3c6902){for(const _0x26965b of Object['keys'](this['listeners'])){const _0x8d3e1e=this['storage']['getItem'](_0x26965b),_0x18f974=this['localCache'][_0x26965b];_0x8d3e1e!==_0x18f974&&_0x3c6902(_0x26965b,_0x18f974,_0x8d3e1e);}}['onStorageEvent'](_0x27de07,_0x3c015d=!0x1){if(!_0x27de07['key']){this['forAllChangedKeys']((_0x4da05f,_0x580aae,_0x47857a)=>{this['notifyListeners'](_0x4da05f,_0x47857a);});return;}const _0x30eaa8=_0x27de07['key'];_0x3c015d?this['detachListener']():this['stopPolling']();const _0x44b2c8=()=>{const _0x3e5cb0=this['storage']['getItem'](_0x30eaa8);!_0x3c015d&&this['localCache'][_0x30eaa8]===_0x3e5cb0||this['notifyListeners'](_0x30eaa8,_0x3e5cb0);},_0xcc387b=this['storage']['getItem'](_0x30eaa8);Tf()&&_0xcc387b!==_0x27de07['newValue']&&_0x27de07['newValue']!==_0x27de07['oldValue']?setTimeout(_0x44b2c8,ip):_0x44b2c8();}['notifyListeners'](_0x37cd34,_0x3eb4b1){this['localCache'][_0x37cd34]=_0x3eb4b1;const _0x12163f=this['listeners'][_0x37cd34];if(_0x12163f){for(const _0x362265 of Array['from'](_0x12163f))_0x362265(_0x3eb4b1&&JSON['parse'](_0x3eb4b1));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x529315,_0x42b60c,_0x16bf52)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x529315,'oldValue':_0x42b60c,'newValue':_0x16bf52}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x16cc96,_0x22961d){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x16cc96]||(this['listeners'][_0x16cc96]=new Set(),this['localCache'][_0x16cc96]=this['storage']['getItem'](_0x16cc96)),this['listeners'][_0x16cc96]['add'](_0x22961d);}['_removeListener'](_0x49519c,_0x3f1280){this['listeners'][_0x49519c]&&(this['listeners'][_0x49519c]['delete'](_0x3f1280),this['listeners'][_0x49519c]['size']===0x0&&delete this['listeners'][_0x49519c]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x1c883f,_0x34bf58){await super['_set'](_0x1c883f,_0x34bf58),this['localCache'][_0x1c883f]=JSON['stringify'](_0x34bf58);}async['_get'](_0x522f09){const _0x70647=await super['_get'](_0x522f09);return this['localCache'][_0x522f09]=JSON['stringify'](_0x70647),_0x70647;}async['_remove'](_0x5b9172){await super['_remove'](_0x5b9172),delete this['localCache'][_0x5b9172];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x15262d,_0x3f8c6d){}['_removeListener'](_0x45cd4d,_0x4501ca){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x1a695f){return Promise['all'](_0x1a695f['map'](async _0x725a5d=>{try{return{'fulfilled':!0x0,'value':await _0x725a5d};}catch(_0x6ae8db){return{'fulfilled':!0x1,'reason':_0x6ae8db};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x24f00e){this['eventTarget']=_0x24f00e,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x507136){const _0x100d7e=this['receivers']['find'](_0x71a065=>_0x71a065['isListeningto'](_0x507136));if(_0x100d7e)return _0x100d7e;const _0xb90a80=new Kn(_0x507136);return this['receivers']['push'](_0xb90a80),_0xb90a80;}['isListeningto'](_0x111221){return this['eventTarget']===_0x111221;}async['handleEvent'](_0x17933f){const _0x737f0f=_0x17933f,{eventId:_0xb1a152,eventType:_0x219c8b,data:_0x534dbe}=_0x737f0f['data'],_0x45a53e=this['handlersMap'][_0x219c8b];if(!(_0x45a53e!=null&&_0x45a53e['size']))return;_0x737f0f['ports'][0x0]['postMessage']({'status':'ack','eventId':_0xb1a152,'eventType':_0x219c8b});const _0x1cca44=Array['from'](_0x45a53e)['map'](async _0x166cab=>_0x166cab(_0x737f0f['origin'],_0x534dbe)),_0x339bb8=await rp(_0x1cca44);_0x737f0f['ports'][0x0]['postMessage']({'status':'done','eventId':_0xb1a152,'eventType':_0x219c8b,'response':_0x339bb8});}['_subscribe'](_0x4e3885,_0x1360e2){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x4e3885]||(this['handlersMap'][_0x4e3885]=new Set()),this['handlersMap'][_0x4e3885]['add'](_0x1360e2);}['_unsubscribe'](_0x41f73a,_0x4e3815){this['handlersMap'][_0x41f73a]&&_0x4e3815&&this['handlersMap'][_0x41f73a]['delete'](_0x4e3815),(!_0x4e3815||this['handlersMap'][_0x41f73a]['size']===0x0)&&delete this['handlersMap'][_0x41f73a],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x258784='',_0x589454=0xa){let _0x103895='';for(let _0x36730b=0x0;_0x36730b<_0x589454;_0x36730b++)_0x103895+=Math['floor'](Math['random']()*0xa);return _0x258784+_0x103895;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x4021c4){this['target']=_0x4021c4,this['handlers']=new Set();}['removeMessageHandler'](_0xc73c0a){_0xc73c0a['messageChannel']&&(_0xc73c0a['messageChannel']['port1']['removeEventListener']('message',_0xc73c0a['onMessage']),_0xc73c0a['messageChannel']['port1']['close']()),this['handlers']['delete'](_0xc73c0a);}async['_send'](_0x2aa74b,_0x263948,_0x23aee5=0x32){const _0xfd040c=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0xfd040c)throw new Error('connection_unavailable');let _0x54eddb,_0x18eae3;return new Promise((_0x5bebba,_0x33a2f2)=>{const _0x482825=As('',0x14);_0xfd040c['port1']['start']();const _0x1c36e8=setTimeout(()=>{_0x33a2f2(new Error('unsupported_event'));},_0x23aee5);_0x18eae3={'messageChannel':_0xfd040c,'onMessage'(_0x3124cc){const _0x34eac5=_0x3124cc;if(_0x34eac5['data']['eventId']===_0x482825)switch(_0x34eac5['data']['status']){case'ack':clearTimeout(_0x1c36e8),_0x54eddb=setTimeout(()=>{_0x33a2f2(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x54eddb),_0x5bebba(_0x34eac5['data']['response']);break;default:clearTimeout(_0x1c36e8),clearTimeout(_0x54eddb),_0x33a2f2(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x18eae3),_0xfd040c['port1']['addEventListener']('message',_0x18eae3['onMessage']),this['target']['postMessage']({'eventType':_0x2aa74b,'eventId':_0x482825,'data':_0x263948},[_0xfd040c['port2']]);})['finally'](()=>{_0x18eae3&&this['removeMessageHandler'](_0x18eae3);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x3c4c54){Z()['location']['href']=_0x3c4c54;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0xc4145c;return((_0xc4145c=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0xc4145c['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x41decb){this['request']=_0x41decb;}['toPromise'](){return new Promise((_0x392b9c,_0x30210a)=>{this['request']['addEventListener']('success',()=>{_0x392b9c(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x30210a(this['request']['error']);});});}}function Yn(_0xdf56c7,_0x7bfab8){return _0xdf56c7['transaction']([Nn],_0x7bfab8?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0xf8aea8=indexedDB['deleteDatabase'](Ka);return new Xt(_0xf8aea8)['toPromise']();}function Mi(){const _0x170944=indexedDB['open'](Ka,up);return new Promise((_0x5289d0,_0x24f616)=>{_0x170944['addEventListener']('error',()=>{_0x24f616(_0x170944['error']);}),_0x170944['addEventListener']('upgradeneeded',()=>{const _0x1d3d2f=_0x170944['result'];try{_0x1d3d2f['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x42042e){_0x24f616(_0x42042e);}}),_0x170944['addEventListener']('success',async()=>{const _0x1d5396=_0x170944['result'];_0x1d5396['objectStoreNames']['contains'](Nn)?_0x5289d0(_0x1d5396):(_0x1d5396['close'](),await dp(),_0x5289d0(await Mi()));});});}async function Pr(_0x1ae455,_0x3e1cd8,_0x2e79f5){const _0x4d54df=Yn(_0x1ae455,!0x0)['put']({[Ya]:_0x3e1cd8,'value':_0x2e79f5});return new Xt(_0x4d54df)['toPromise']();}async function fp(_0x506980,_0x1ef6ef){const _0x3ca1c9=Yn(_0x506980,!0x1)['get'](_0x1ef6ef),_0x5a322a=await new Xt(_0x3ca1c9)['toPromise']();return _0x5a322a===void 0x0?null:_0x5a322a['value'];}function Or(_0x2d59fa,_0x5422e7){const _0x2d78b4=Yn(_0x2d59fa,!0x0)['delete'](_0x5422e7);return new Xt(_0x2d78b4)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0xdfbe85){let _0x31b970=0x0;for(;;)try{const _0x4108c4=await this['_openDb']();return await _0xdfbe85(_0x4108c4);}catch(_0x4f2e2a){if(_0x31b970++>_p)throw _0x4f2e2a;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x3fa086,_0x3e6ca0)=>({'keyProcessed':(await this['_poll']())['includes'](_0x3e6ca0['key'])})),this['receiver']['_subscribe']('ping',async(_0x4552bb,_0x15da73)=>['keyChanged']);}async['initializeSender'](){var _0x3673e4,_0x2fe5e5;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0xc63fdf=await this['sender']['_send']('ping',{},0x320);_0xc63fdf&&(_0x3673e4=_0xc63fdf[0x0])!=null&&_0x3673e4['fulfilled']&&(_0x2fe5e5=_0xc63fdf[0x0])!=null&&_0x2fe5e5['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x14d567){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x14d567},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x4159fb=await Mi();return await Pr(_0x4159fb,kn,'1'),await Or(_0x4159fb,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x3c9617){this['pendingWrites']++;try{await _0x3c9617();}finally{this['pendingWrites']--;}}async['_set'](_0x9a335b,_0x382200){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4b2619=>Pr(_0x4b2619,_0x9a335b,_0x382200)),this['localCache'][_0x9a335b]=_0x382200,this['notifyServiceWorker'](_0x9a335b)));}async['_get'](_0x591ffc){const _0xfd6c88=await this['_withRetries'](_0x3f47f5=>fp(_0x3f47f5,_0x591ffc));return this['localCache'][_0x591ffc]=_0xfd6c88,_0xfd6c88;}async['_remove'](_0x45c060){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x392742=>Or(_0x392742,_0x45c060)),delete this['localCache'][_0x45c060],this['notifyServiceWorker'](_0x45c060)));}async['_poll'](){const _0x4be64d=await this['_withRetries'](_0x4eadfb=>{const _0x1b926e=Yn(_0x4eadfb,!0x1)['getAll']();return new Xt(_0x1b926e)['toPromise']();});if(!_0x4be64d)return[];if(this['pendingWrites']!==0x0)return[];const _0xf6377a=[],_0x1c8e74=new Set();if(_0x4be64d['length']!==0x0){for(const {fbase_key:_0x10c785,value:_0xa8138d}of _0x4be64d)_0x1c8e74['add'](_0x10c785),JSON['stringify'](this['localCache'][_0x10c785])!==JSON['stringify'](_0xa8138d)&&(this['notifyListeners'](_0x10c785,_0xa8138d),_0xf6377a['push'](_0x10c785));}for(const _0x486d0e of Object['keys'](this['localCache']))this['localCache'][_0x486d0e]&&!_0x1c8e74['has'](_0x486d0e)&&(this['notifyListeners'](_0x486d0e,null),_0xf6377a['push'](_0x486d0e));return _0xf6377a;}['notifyListeners'](_0x255a98,_0x119951){this['localCache'][_0x255a98]=_0x119951;const _0x1a07b9=this['listeners'][_0x255a98];if(_0x1a07b9){for(const _0x313ea8 of Array['from'](_0x1a07b9))_0x313ea8(_0x119951);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x57404d,_0x4b3870){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x57404d]||(this['listeners'][_0x57404d]=new Set(),this['_get'](_0x57404d)),this['listeners'][_0x57404d]['add'](_0x4b3870);}['_removeListener'](_0x685300,_0x561aec){this['listeners'][_0x685300]&&(this['listeners'][_0x685300]['delete'](_0x561aec),this['listeners'][_0x685300]['size']===0x0&&delete this['listeners'][_0x685300]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x56c6aa,_0x3ad9b1){return _0x3ad9b1?ie(_0x3ad9b1):(m(_0x56c6aa['_popupRedirectResolver'],_0x56c6aa,'argument-error'),_0x56c6aa['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x383aa2){super('custom','custom'),this['params']=_0x383aa2;}['_getIdTokenResponse'](_0xb2c776){return Xe(_0xb2c776,this['_buildIdpRequest']());}['_linkToIdToken'](_0x5347f8,_0x38434d){return Xe(_0x5347f8,this['_buildIdpRequest'](_0x38434d));}['_getReauthenticationResolver'](_0x18054f){return Xe(_0x18054f,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x207dc8){const _0x676a9={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x207dc8&&(_0x676a9['idToken']=_0x207dc8),_0x676a9;}}function yp(_0x4cd8bb){return Va(_0x4cd8bb['auth'],new ks(_0x4cd8bb),_0x4cd8bb['bypassAuthState']);}function vp(_0x5138ca){const {auth:_0x3f4e57,user:_0x30b190}=_0x5138ca;return m(_0x30b190,_0x3f4e57,'internal-error'),Xf(_0x30b190,new ks(_0x5138ca),_0x5138ca['bypassAuthState']);}async function Ep(_0x165473){const {auth:_0x2efaef,user:_0x5ca04a}=_0x165473;return m(_0x5ca04a,_0x2efaef,'internal-error'),Jf(_0x5ca04a,new ks(_0x165473),_0x165473['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x126c4c,_0x4b78f5,_0x10edb1,_0x3ccaeb,_0x526ead=!0x1){this['auth']=_0x126c4c,this['resolver']=_0x10edb1,this['user']=_0x3ccaeb,this['bypassAuthState']=_0x526ead,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x4b78f5)?_0x4b78f5:[_0x4b78f5];}['execute'](){return new Promise(async(_0x381820,_0x2a0129)=>{this['pendingPromise']={'resolve':_0x381820,'reject':_0x2a0129};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0xa7e07a){this['reject'](_0xa7e07a);}});}async['onAuthEvent'](_0x2594f7){const {urlResponse:_0x288a3c,sessionId:_0x1b987b,postBody:_0x2e63cb,tenantId:_0xd2ac80,error:_0x5b5bc4,type:_0x3953ac}=_0x2594f7;if(_0x5b5bc4){this['reject'](_0x5b5bc4);return;}const _0x28794f={'auth':this['auth'],'requestUri':_0x288a3c,'sessionId':_0x1b987b,'tenantId':_0xd2ac80||void 0x0,'postBody':_0x2e63cb||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x3953ac)(_0x28794f));}catch(_0x3381ac){this['reject'](_0x3381ac);}}['onError'](_0x3e2e7e){this['reject'](_0x3e2e7e);}['getIdpTask'](_0x4e7316){switch(_0x4e7316){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x3bdffc){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x3bdffc),this['unregisterAndCleanUp']();}['reject'](_0x149651){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x149651),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x56a874,_0x4220a3,_0x356d03,_0x5743fe,_0x5a62b1){super(_0x56a874,_0x4220a3,_0x5743fe,_0x5a62b1),this['provider']=_0x356d03,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x4f81bd=await this['execute']();return m(_0x4f81bd,this['auth'],'internal-error'),_0x4f81bd;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x500318=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x500318),this['authWindow']['associatedEvent']=_0x500318,this['resolver']['_originValidation'](this['auth'])['catch'](_0xe3227f=>{this['reject'](_0xe3227f);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x3d53b3=>{_0x3d53b3||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x422d22;return((_0x422d22=this['authWindow'])==null?void 0x0:_0x422d22['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x3c8270=()=>{var _0x5d8724,_0x2c57ca;if((_0x2c57ca=(_0x5d8724=this['authWindow'])==null?void 0x0:_0x5d8724['window'])!=null&&_0x2c57ca['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x3c8270,Ip['get']());};_0x3c8270();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x5dcc6d,_0x5c54d7,_0x268a24=!0x1){super(_0x5dcc6d,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x5c54d7,void 0x0,_0x268a24),this['eventId']=null;}async['execute'](){let _0x20aaae=on['get'](this['auth']['_key']());if(!_0x20aaae){try{const _0x3beb94=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x20aaae=()=>Promise['resolve'](_0x3beb94);}catch(_0x173fe9){_0x20aaae=()=>Promise['reject'](_0x173fe9);}on['set'](this['auth']['_key'](),_0x20aaae);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x20aaae();}async['onAuthEvent'](_0x2ee730){if(_0x2ee730['type']==='signInViaRedirect')return super['onAuthEvent'](_0x2ee730);if(_0x2ee730['type']==='unknown'){this['resolve'](null);return;}if(_0x2ee730['eventId']){const _0x5a4617=await this['auth']['_redirectUserForId'](_0x2ee730['eventId']);if(_0x5a4617)return this['user']=_0x5a4617,super['onAuthEvent'](_0x2ee730);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x4c4240,_0x3c9b58){const _0x49e92a=Rp(_0x3c9b58),_0x1abda8=bp(_0x4c4240);if(!await _0x1abda8['_isAvailable']())return!0x1;const _0x956eb3=await _0x1abda8['_get'](_0x49e92a)==='true';return await _0x1abda8['_remove'](_0x49e92a),_0x956eb3;}function Sp(_0x173b11,_0x5bcb){on['set'](_0x173b11['_key'](),_0x5bcb);}function bp(_0x455b72){return ie(_0x455b72['_redirectPersistence']);}function Rp(_0x3cfe69){return rn(wp,_0x3cfe69['config']['apiKey'],_0x3cfe69['name']);}async function Ap(_0x5de2d2,_0x5110bd,_0x4c81f9=!0x1){if($(_0x5de2d2['app']))return Promise['reject'](re(_0x5de2d2));const _0x4347b8=qe(_0x5de2d2),_0x21da14=mp(_0x4347b8,_0x5110bd),_0x3834af=await new Cp(_0x4347b8,_0x21da14,_0x4c81f9)['execute']();return _0x3834af&&!_0x4c81f9&&(delete _0x3834af['user']['_redirectEventId'],await _0x4347b8['_persistUserIfCurrent'](_0x3834af['user']),await _0x4347b8['_setRedirectUser'](null,_0x5110bd)),_0x3834af;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x54fc02){this['auth']=_0x54fc02,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x34e407){this['consumers']['add'](_0x34e407),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x34e407)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x34e407),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x1b00f0){this['consumers']['delete'](_0x1b00f0);}['onEvent'](_0x11ae57){if(this['hasEventBeenHandled'](_0x11ae57))return!0x1;let _0x40b7f8=!0x1;return this['consumers']['forEach'](_0x4c7433=>{this['isEventForConsumer'](_0x11ae57,_0x4c7433)&&(_0x40b7f8=!0x0,this['sendToConsumer'](_0x11ae57,_0x4c7433),this['saveEventToCache'](_0x11ae57));}),this['hasHandledPotentialRedirect']||!Pp(_0x11ae57)||(this['hasHandledPotentialRedirect']=!0x0,_0x40b7f8||(this['queuedRedirectEvent']=_0x11ae57,_0x40b7f8=!0x0)),_0x40b7f8;}['sendToConsumer'](_0x2238f6,_0x191080){var _0x36c44d;if(_0x2238f6['error']&&!Xa(_0x2238f6)){const _0x4e3753=((_0x36c44d=_0x2238f6['error']['code'])==null?void 0x0:_0x36c44d['split']('auth/')[0x1])||'internal-error';_0x191080['onError'](X(this['auth'],_0x4e3753));}else _0x191080['onAuthEvent'](_0x2238f6);}['isEventForConsumer'](_0x407af5,_0x43be42){const _0x3ac2d9=_0x43be42['eventId']===null||!!_0x407af5['eventId']&&_0x407af5['eventId']===_0x43be42['eventId'];return _0x43be42['filter']['includes'](_0x407af5['type'])&&_0x3ac2d9;}['hasEventBeenHandled'](_0x5f5f77){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x5f5f77));}['saveEventToCache'](_0x211612){this['cachedEventUids']['add'](Dr(_0x211612)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x1f9da0){return[_0x1f9da0['type'],_0x1f9da0['eventId'],_0x1f9da0['sessionId'],_0x1f9da0['tenantId']]['filter'](_0x3e5b63=>_0x3e5b63)['join']('-');}function Xa({type:_0x18fd9b,error:_0x5b55d3}){return _0x18fd9b==='unknown'&&(_0x5b55d3==null?void 0x0:_0x5b55d3['code'])==='auth/no-auth-event';}function Pp(_0x5aeb2b){switch(_0x5aeb2b['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x5aeb2b);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x4aee34,_0x38b777={}){return Ae(_0x4aee34,'GET','/v1/projects',_0x38b777);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x5d2bca){if(_0x5d2bca['config']['emulator'])return;const {authorizedDomains:_0x1da11c}=await Op(_0x5d2bca);for(const _0xdd26cd of _0x1da11c)try{if(xp(_0xdd26cd))return;}catch{}Q(_0x5d2bca,'unauthorized-domain');}function xp(_0x59dd8d){const _0x3505a4=Pi(),{protocol:_0x7ec8ee,hostname:_0x276a33}=new URL(_0x3505a4);if(_0x59dd8d['startsWith']('chrome-extension://')){const _0x5a0ed2=new URL(_0x59dd8d);return _0x5a0ed2['hostname']===''&&_0x276a33===''?_0x7ec8ee==='chrome-extension:'&&_0x59dd8d['replace']('chrome-extension://','')===_0x3505a4['replace']('chrome-extension://',''):_0x7ec8ee==='chrome-extension:'&&_0x5a0ed2['hostname']===_0x276a33;}if(!Mp['test'](_0x7ec8ee))return!0x1;if(Dp['test'](_0x59dd8d))return _0x276a33===_0x59dd8d;const _0x1abd54=_0x59dd8d['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x1abd54+'|'+_0x1abd54+')$','i')['test'](_0x276a33);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x1a1bee=Z()['___jsl'];if(_0x1a1bee!=null&&_0x1a1bee['H']){for(const _0x33ce6b of Object['keys'](_0x1a1bee['H']))if(_0x1a1bee['H'][_0x33ce6b]['r']=_0x1a1bee['H'][_0x33ce6b]['r']||[],_0x1a1bee['H'][_0x33ce6b]['L']=_0x1a1bee['H'][_0x33ce6b]['L']||[],_0x1a1bee['H'][_0x33ce6b]['r']=[..._0x1a1bee['H'][_0x33ce6b]['L']],_0x1a1bee['CP']){for(let _0x11935b=0x0;_0x11935b<_0x1a1bee['CP']['length'];_0x11935b++)_0x1a1bee['CP'][_0x11935b]=null;}}}function Up(_0x33520b){return new Promise((_0x248e13,_0x474df0)=>{var _0x4889a2,_0x5273c6,_0x175f5e;function _0x18f398(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x248e13(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x474df0(X(_0x33520b,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x5273c6=(_0x4889a2=Z()['gapi'])==null?void 0x0:_0x4889a2['iframes'])!=null&&_0x5273c6['Iframe'])_0x248e13(gapi['iframes']['getContext']());else{if((_0x175f5e=Z()['gapi'])!=null&&_0x175f5e['load'])_0x18f398();else{const _0x8e955a=Df('iframefcb');return Z()[_0x8e955a]=()=>{gapi['load']?_0x18f398():_0x474df0(X(_0x33520b,'network-request-failed'));},xa(Of()+'?onload='+_0x8e955a)['catch'](_0x5227f7=>_0x474df0(_0x5227f7));}}})['catch'](_0x16f433=>{throw an=null,_0x16f433;});}let an=null;function Wp(_0x472589){return an=an||Up(_0x472589),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x2a282b){const _0x295401=_0x2a282b['config'];m(_0x295401['authDomain'],_0x2a282b,'auth-domain-config-required');const _0x5f54c3=_0x295401['emulator']?Cs(_0x295401,Hp):'https://'+_0x2a282b['config']['authDomain']+'/'+Vp,_0x569022={'apiKey':_0x295401['apiKey'],'appName':_0x2a282b['name'],'v':lt},_0x19fcc3=Gp['get'](_0x2a282b['config']['apiHost']);_0x19fcc3&&(_0x569022['eid']=_0x19fcc3);const _0x4e885c=_0x2a282b['_getFrameworks']();return _0x4e885c['length']&&(_0x569022['fw']=_0x4e885c['join'](',')),_0x5f54c3+'?'+ct(_0x569022)['slice'](0x1);}async function zp(_0x58ad21){const _0x398c17=await Wp(_0x58ad21),_0x59402b=Z()['gapi'];return m(_0x59402b,_0x58ad21,'internal-error'),_0x398c17['open']({'where':document['body'],'url':qp(_0x58ad21),'messageHandlersFilter':_0x59402b['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x1442d6=>new Promise(async(_0x1b497e,_0x34c397)=>{await _0x1442d6['restyle']({'setHideOnLeave':!0x1});const _0x57c10d=X(_0x58ad21,'network-request-failed'),_0xb73c99=Z()['setTimeout'](()=>{_0x34c397(_0x57c10d);},Bp['get']());function _0x28f72(){Z()['clearTimeout'](_0xb73c99),_0x1b497e(_0x1442d6);}_0x1442d6['ping'](_0x28f72)['then'](_0x28f72,()=>{_0x34c397(_0x57c10d);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x1a4ac6){this['window']=_0x1a4ac6,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x162a58,_0x3984fb,_0x354c58,_0x10a81b=Kp,_0x121a13=Yp){const _0x5dfbab=Math['max']((window['screen']['availHeight']-_0x121a13)/0x2,0x0)['toString'](),_0x4d3428=Math['max']((window['screen']['availWidth']-_0x10a81b)/0x2,0x0)['toString']();let _0x220de9='';const _0x4b0665={...jp,'width':_0x10a81b['toString'](),'height':_0x121a13['toString'](),'top':_0x5dfbab,'left':_0x4d3428},_0xc5b792=W()['toLowerCase']();_0x354c58&&(_0x220de9=ka(_0xc5b792)?Qp:_0x354c58),Ra(_0xc5b792)&&(_0x3984fb=_0x3984fb||Jp,_0x4b0665['scrollbars']='yes');const _0xe7535a=Object['entries'](_0x4b0665)['reduce']((_0x32269b,[_0x164a07,_0x3390a3])=>''+_0x32269b+_0x164a07+'='+_0x3390a3+',','');if(Cf(_0xc5b792)&&_0x220de9!=='_self')return Zp(_0x3984fb||'',_0x220de9),new Lr(null);const _0x2b66e8=window['open'](_0x3984fb||'',_0x220de9,_0xe7535a);m(_0x2b66e8,_0x162a58,'popup-blocked');try{_0x2b66e8['focus']();}catch{}return new Lr(_0x2b66e8);}function Zp(_0x260fbd,_0x4ac9b2){const _0xcd948b=document['createElement']('a');_0xcd948b['href']=_0x260fbd,_0xcd948b['target']=_0x4ac9b2;const _0x743ce3=document['createEvent']('MouseEvent');_0x743ce3['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0xcd948b['dispatchEvent'](_0x743ce3);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x683be2,_0x35e816,_0x149853,_0x8959aa,_0x46be60,_0x595c7b){m(_0x683be2['config']['authDomain'],_0x683be2,'auth-domain-config-required'),m(_0x683be2['config']['apiKey'],_0x683be2,'invalid-api-key');const _0x161f20={'apiKey':_0x683be2['config']['apiKey'],'appName':_0x683be2['name'],'authType':_0x149853,'redirectUrl':_0x8959aa,'v':lt,'eventId':_0x46be60};if(_0x35e816 instanceof Wa){_0x35e816['setDefaultLanguage'](_0x683be2['languageCode']),_0x161f20['providerId']=_0x35e816['providerId']||'',ui(_0x35e816['getCustomParameters']())||(_0x161f20['customParameters']=JSON['stringify'](_0x35e816['getCustomParameters']()));for(const [_0x5811d5,_0x6d47bf]of Object['entries']({}))_0x161f20[_0x5811d5]=_0x6d47bf;}if(_0x35e816 instanceof Jt){const _0x107c7a=_0x35e816['getScopes']()['filter'](_0x222c1e=>_0x222c1e!=='');_0x107c7a['length']>0x0&&(_0x161f20['scopes']=_0x107c7a['join'](','));}_0x683be2['tenantId']&&(_0x161f20['tid']=_0x683be2['tenantId']);const _0x21073c=_0x161f20;for(const _0x624c91 of Object['keys'](_0x21073c))_0x21073c[_0x624c91]===void 0x0&&delete _0x21073c[_0x624c91];const _0x508042=await _0x683be2['_getAppCheckToken'](),_0x28d03b=_0x508042?'#'+n_+'='+encodeURIComponent(_0x508042):'';return i_(_0x683be2)+'?'+ct(_0x21073c)['slice'](0x1)+_0x28d03b;}function i_({config:_0x12bb7d}){return _0x12bb7d['emulator']?Cs(_0x12bb7d,t_):'https://'+_0x12bb7d['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x169217,_0x5a7958,_0x1cac80,_0xf81365){var _0x4e03bc;ce((_0x4e03bc=this['eventManagers'][_0x169217['_key']()])==null?void 0x0:_0x4e03bc['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x227ff8=await xr(_0x169217,_0x5a7958,_0x1cac80,Pi(),_0xf81365);return Xp(_0x169217,_0x227ff8,As());}async['_openRedirect'](_0x48d6f9,_0x199127,_0x1754ca,_0xbb6fe1){await this['_originValidation'](_0x48d6f9);const _0x2b4cf1=await xr(_0x48d6f9,_0x199127,_0x1754ca,Pi(),_0xbb6fe1);return ap(_0x2b4cf1),new Promise(()=>{});}['_initialize'](_0x2c87f4){const _0x1dede0=_0x2c87f4['_key']();if(this['eventManagers'][_0x1dede0]){const {manager:_0x59a21f,promise:_0x1253c5}=this['eventManagers'][_0x1dede0];return _0x59a21f?Promise['resolve'](_0x59a21f):(ce(_0x1253c5,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x1253c5);}const _0x3b4b0d=this['initAndGetManager'](_0x2c87f4);return this['eventManagers'][_0x1dede0]={'promise':_0x3b4b0d},_0x3b4b0d['catch'](()=>{delete this['eventManagers'][_0x1dede0];}),_0x3b4b0d;}async['initAndGetManager'](_0x5e74b6){const _0x25b28f=await zp(_0x5e74b6),_0x2a4236=new Np(_0x5e74b6);return _0x25b28f['register']('authEvent',_0x538a19=>(m(_0x538a19==null?void 0x0:_0x538a19['authEvent'],_0x5e74b6,'invalid-auth-event'),{'status':_0x2a4236['onEvent'](_0x538a19['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x5e74b6['_key']()]={'manager':_0x2a4236},this['iframes'][_0x5e74b6['_key']()]=_0x25b28f,_0x2a4236;}['_isIframeWebStorageSupported'](_0x1affb8,_0x50526a){this['iframes'][_0x1affb8['_key']()]['send'](hi,{'type':hi},_0x157ce7=>{var _0x4f226e;const _0x11ff2a=(_0x4f226e=_0x157ce7==null?void 0x0:_0x157ce7[0x0])==null?void 0x0:_0x4f226e[hi];_0x11ff2a!==void 0x0&&_0x50526a(!!_0x11ff2a),Q(_0x1affb8,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x4702d7){const _0x59a113=_0x4702d7['_key']();return this['originValidationPromises'][_0x59a113]||(this['originValidationPromises'][_0x59a113]=Lp(_0x4702d7)),this['originValidationPromises'][_0x59a113];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0xbbe7e){this['auth']=_0xbbe7e,this['internalListeners']=new Map();}['getUid'](){var _0x311d10;return this['assertAuthConfigured'](),((_0x311d10=this['auth']['currentUser'])==null?void 0x0:_0x311d10['uid'])||null;}async['getToken'](_0x5c66e7){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x5c66e7)}:null;}['addAuthTokenListener'](_0xfef110){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0xfef110))return;const _0x4114bc=this['auth']['onIdTokenChanged'](_0x1678dc=>{_0xfef110((_0x1678dc==null?void 0x0:_0x1678dc['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0xfef110,_0x4114bc),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x374597){this['assertAuthConfigured']();const _0x15f16e=this['internalListeners']['get'](_0x374597);_0x15f16e&&(this['internalListeners']['delete'](_0x374597),_0x15f16e(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x2ad3b7){switch(_0x2ad3b7){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x3e8478){Ze(new Le('auth',(_0x5da119,{options:_0x2d7b27})=>{const _0x14f6fd=_0x5da119['getProvider']('app')['getImmediate'](),_0x23d555=_0x5da119['getProvider']('heartbeat'),_0x5e4a55=_0x5da119['getProvider']('app-check-internal'),{apiKey:_0x1165ad,authDomain:_0x2cfb09}=_0x14f6fd['options'];m(_0x1165ad&&!_0x1165ad['includes'](':'),'invalid-api-key',{'appName':_0x14f6fd['name']});const _0x2b09fc={'apiKey':_0x1165ad,'authDomain':_0x2cfb09,'clientPlatform':_0x3e8478,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x3e8478)},_0x278c74=new kf(_0x14f6fd,_0x23d555,_0x5e4a55,_0x2b09fc);return Wf(_0x278c74,_0x2d7b27),_0x278c74;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x3f85e6,_0x5487f1,_0x3a5cdc)=>{_0x3f85e6['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x2dac20=>{const _0x5ea881=qe(_0x2dac20['getProvider']('auth')['getImmediate']());return(_0x5ff164=>new o_(_0x5ff164))(_0x5ea881);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x3e8478)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x4dc5d7=>async _0x1af3c5=>{const _0x18e932=_0x1af3c5&&await _0x1af3c5['getIdTokenResult'](),_0x2fbe51=_0x18e932&&(new Date()['getTime']()-Date['parse'](_0x18e932['issuedAtTime']))/0x3e8;if(_0x2fbe51&&_0x2fbe51>h_)return;const _0x442bdf=_0x18e932==null?void 0x0:_0x18e932['token'];Wr!==_0x442bdf&&(Wr=_0x442bdf,await fetch(_0x4dc5d7,{'method':_0x442bdf?'POST':'DELETE','headers':_0x442bdf?{'Authorization':'Bearer\x20'+_0x442bdf}:{}}));};function x_(_0x4f6e15=Zr()){const _0xc68645=Bi(_0x4f6e15,'auth');if(_0xc68645['isInitialized']())return _0xc68645['getImmediate']();const _0x468a11=Uf(_0x4f6e15,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x10985c=zr('authTokenSyncURL');if(_0x10985c&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x16e688=new URL(_0x10985c,location['origin']);if(location['origin']===_0x16e688['origin']){const _0x44d0f2=u_(_0x16e688['toString']());tp(_0x468a11,_0x44d0f2,()=>_0x44d0f2(_0x468a11['currentUser'])),ep(_0x468a11,_0xbdf64c=>_0x44d0f2(_0xbdf64c));}}const _0x28c784=Gr('auth');return _0x28c784&&Bf(_0x468a11,'http://'+_0x28c784),_0x468a11;}function d_(){var _0x332ab7;return((_0x332ab7=document['getElementsByTagName']('head'))==null?void 0x0:_0x332ab7[0x0])??document;}Nf({'loadJS'(_0xb24b93){return new Promise((_0x2bc72f,_0x3ef658)=>{const _0x2b2b79=document['createElement']('script');_0x2b2b79['setAttribute']('src',_0xb24b93),_0x2b2b79['onload']=_0x2bc72f,_0x2b2b79['onerror']=_0xa7f8bb=>{const _0x5ba2c7=X('internal-error');_0x5ba2c7['customData']=_0xa7f8bb,_0x3ef658(_0x5ba2c7);},_0x2b2b79['type']='text/javascript',_0x2b2b79['charset']='UTF-8',d_()['appendChild'](_0x2b2b79);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};