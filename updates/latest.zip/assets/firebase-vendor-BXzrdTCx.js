const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x5e7798,_0x5d8563){if(!_0x5e7798)throw rt(_0x5d8563);},rt=function(_0x130111){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x130111);},Vr=function(_0x22af7d){const _0x4ecfae=[];let _0x490d29=0x0;for(let _0x3e5b5c=0x0;_0x3e5b5c<_0x22af7d['length'];_0x3e5b5c++){let _0x4c417f=_0x22af7d['charCodeAt'](_0x3e5b5c);_0x4c417f<0x80?_0x4ecfae[_0x490d29++]=_0x4c417f:_0x4c417f<0x800?(_0x4ecfae[_0x490d29++]=_0x4c417f>>0x6|0xc0,_0x4ecfae[_0x490d29++]=_0x4c417f&0x3f|0x80):(_0x4c417f&0xfc00)===0xd800&&_0x3e5b5c+0x1<_0x22af7d['length']&&(_0x22af7d['charCodeAt'](_0x3e5b5c+0x1)&0xfc00)===0xdc00?(_0x4c417f=0x10000+((_0x4c417f&0x3ff)<<0xa)+(_0x22af7d['charCodeAt'](++_0x3e5b5c)&0x3ff),_0x4ecfae[_0x490d29++]=_0x4c417f>>0x12|0xf0,_0x4ecfae[_0x490d29++]=_0x4c417f>>0xc&0x3f|0x80,_0x4ecfae[_0x490d29++]=_0x4c417f>>0x6&0x3f|0x80,_0x4ecfae[_0x490d29++]=_0x4c417f&0x3f|0x80):(_0x4ecfae[_0x490d29++]=_0x4c417f>>0xc|0xe0,_0x4ecfae[_0x490d29++]=_0x4c417f>>0x6&0x3f|0x80,_0x4ecfae[_0x490d29++]=_0x4c417f&0x3f|0x80);}return _0x4ecfae;},ec=function(_0x5570a6){const _0x49b8bb=[];let _0x3ca6c9=0x0,_0x561209=0x0;for(;_0x3ca6c9<_0x5570a6['length'];){const _0x36b561=_0x5570a6[_0x3ca6c9++];if(_0x36b561<0x80)_0x49b8bb[_0x561209++]=String['fromCharCode'](_0x36b561);else{if(_0x36b561>0xbf&&_0x36b561<0xe0){const _0x4d9dfb=_0x5570a6[_0x3ca6c9++];_0x49b8bb[_0x561209++]=String['fromCharCode']((_0x36b561&0x1f)<<0x6|_0x4d9dfb&0x3f);}else{if(_0x36b561>0xef&&_0x36b561<0x16d){const _0x30d2cf=_0x5570a6[_0x3ca6c9++],_0x36a39a=_0x5570a6[_0x3ca6c9++],_0x1f8360=_0x5570a6[_0x3ca6c9++],_0x2ad473=((_0x36b561&0x7)<<0x12|(_0x30d2cf&0x3f)<<0xc|(_0x36a39a&0x3f)<<0x6|_0x1f8360&0x3f)-0x10000;_0x49b8bb[_0x561209++]=String['fromCharCode'](0xd800+(_0x2ad473>>0xa)),_0x49b8bb[_0x561209++]=String['fromCharCode'](0xdc00+(_0x2ad473&0x3ff));}else{const _0x53ab40=_0x5570a6[_0x3ca6c9++],_0x57069f=_0x5570a6[_0x3ca6c9++];_0x49b8bb[_0x561209++]=String['fromCharCode']((_0x36b561&0xf)<<0xc|(_0x53ab40&0x3f)<<0x6|_0x57069f&0x3f);}}}}return _0x49b8bb['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x555c36,_0x1d593a){if(!Array['isArray'](_0x555c36))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x46cfab=_0x1d593a?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x5ec40e=[];for(let _0xde419b=0x0;_0xde419b<_0x555c36['length'];_0xde419b+=0x3){const _0x4b6c49=_0x555c36[_0xde419b],_0x5eed10=_0xde419b+0x1<_0x555c36['length'],_0x55b6b6=_0x5eed10?_0x555c36[_0xde419b+0x1]:0x0,_0x2f8b2b=_0xde419b+0x2<_0x555c36['length'],_0x3e8021=_0x2f8b2b?_0x555c36[_0xde419b+0x2]:0x0,_0x19a6e9=_0x4b6c49>>0x2,_0x26fffa=(_0x4b6c49&0x3)<<0x4|_0x55b6b6>>0x4;let _0x3bac5d=(_0x55b6b6&0xf)<<0x2|_0x3e8021>>0x6,_0x459482=_0x3e8021&0x3f;_0x2f8b2b||(_0x459482=0x40,_0x5eed10||(_0x3bac5d=0x40)),_0x5ec40e['push'](_0x46cfab[_0x19a6e9],_0x46cfab[_0x26fffa],_0x46cfab[_0x3bac5d],_0x46cfab[_0x459482]);}return _0x5ec40e['join']('');},'encodeString'(_0x227520,_0x1eaa3c){return this['HAS_NATIVE_SUPPORT']&&!_0x1eaa3c?btoa(_0x227520):this['encodeByteArray'](Vr(_0x227520),_0x1eaa3c);},'decodeString'(_0x2b8efb,_0x45fefd){return this['HAS_NATIVE_SUPPORT']&&!_0x45fefd?atob(_0x2b8efb):ec(this['decodeStringToByteArray'](_0x2b8efb,_0x45fefd));},'decodeStringToByteArray'(_0xb2f251,_0x2cb6f2){this['init_']();const _0x35f7e8=_0x2cb6f2?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x5b9bdb=[];for(let _0xbae3f3=0x0;_0xbae3f3<_0xb2f251['length'];){const _0x527f82=_0x35f7e8[_0xb2f251['charAt'](_0xbae3f3++)],_0x751e30=_0xbae3f3<_0xb2f251['length']?_0x35f7e8[_0xb2f251['charAt'](_0xbae3f3)]:0x0;++_0xbae3f3;const _0x104786=_0xbae3f3<_0xb2f251['length']?_0x35f7e8[_0xb2f251['charAt'](_0xbae3f3)]:0x40;++_0xbae3f3;const _0x4fcca6=_0xbae3f3<_0xb2f251['length']?_0x35f7e8[_0xb2f251['charAt'](_0xbae3f3)]:0x40;if(++_0xbae3f3,_0x527f82==null||_0x751e30==null||_0x104786==null||_0x4fcca6==null)throw new tc();const _0x24f43a=_0x527f82<<0x2|_0x751e30>>0x4;if(_0x5b9bdb['push'](_0x24f43a),_0x104786!==0x40){const _0x5208bf=_0x751e30<<0x4&0xf0|_0x104786>>0x2;if(_0x5b9bdb['push'](_0x5208bf),_0x4fcca6!==0x40){const _0x32bf9a=_0x104786<<0x6&0xc0|_0x4fcca6;_0x5b9bdb['push'](_0x32bf9a);}}}return _0x5b9bdb;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x35d88e=0x0;_0x35d88e<this['ENCODED_VALS']['length'];_0x35d88e++)this['byteToCharMap_'][_0x35d88e]=this['ENCODED_VALS']['charAt'](_0x35d88e),this['charToByteMap_'][this['byteToCharMap_'][_0x35d88e]]=_0x35d88e,this['byteToCharMapWebSafe_'][_0x35d88e]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x35d88e),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x35d88e]]=_0x35d88e,_0x35d88e>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x35d88e)]=_0x35d88e,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x35d88e)]=_0x35d88e);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x509f3d){const _0x39a77b=Vr(_0x509f3d);return Li['encodeByteArray'](_0x39a77b,!0x0);},cn=function(_0x1dd1a1){return Hr(_0x1dd1a1)['replace'](/\./g,'');},ln=function(_0x2c0eb2){try{return Li['decodeString'](_0x2c0eb2,!0x0);}catch(_0x4e0a9d){console['error']('base64Decode\x20failed:\x20',_0x4e0a9d);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x31d568){return $r(void 0x0,_0x31d568);}function $r(_0x19cceb,_0x9a216){if(!(_0x9a216 instanceof Object))return _0x9a216;switch(_0x9a216['constructor']){case Date:const _0x525977=_0x9a216;return new Date(_0x525977['getTime']());case Object:_0x19cceb===void 0x0&&(_0x19cceb={});break;case Array:_0x19cceb=[];break;default:return _0x9a216;}for(const _0x47644c in _0x9a216)!_0x9a216['hasOwnProperty'](_0x47644c)||!ic(_0x47644c)||(_0x19cceb[_0x47644c]=$r(_0x19cceb[_0x47644c],_0x9a216[_0x47644c]));return _0x19cceb;}function ic(_0x790961){return _0x790961!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x33d027=Ns['__FIREBASE_DEFAULTS__'];if(_0x33d027)return JSON['parse'](_0x33d027);},ac=()=>{if(typeof document>'u')return;let _0x272afe;try{_0x272afe=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x664afd=_0x272afe&&ln(_0x272afe[0x1]);return _0x664afd&&JSON['parse'](_0x664afd);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x406a93){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x406a93);return;}},Gr=_0xc03c7e=>{var _0x345a68,_0x40498c;return(_0x40498c=(_0x345a68=xi())==null?void 0x0:_0x345a68['emulatorHosts'])==null?void 0x0:_0x40498c[_0xc03c7e];},cc=_0xddc92f=>{const _0x2c7617=Gr(_0xddc92f);if(!_0x2c7617)return;const _0x1ef37b=_0x2c7617['lastIndexOf'](':');if(_0x1ef37b<=0x0||_0x1ef37b+0x1===_0x2c7617['length'])throw new Error('Invalid\x20host\x20'+_0x2c7617+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x144259=parseInt(_0x2c7617['substring'](_0x1ef37b+0x1),0xa);return _0x2c7617[0x0]==='['?[_0x2c7617['substring'](0x1,_0x1ef37b-0x1),_0x144259]:[_0x2c7617['substring'](0x0,_0x1ef37b),_0x144259];},qr=()=>{var _0x57003c;return(_0x57003c=xi())==null?void 0x0:_0x57003c['config'];},zr=_0x2c12ca=>{var _0x1bd32e;return(_0x1bd32e=xi())==null?void 0x0:_0x1bd32e['_'+_0x2c12ca];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x141ed6,_0x3a29a7)=>{this['resolve']=_0x141ed6,this['reject']=_0x3a29a7;});}['wrapCallback'](_0x104045){return(_0x4c1867,_0x2066d1)=>{_0x4c1867?this['reject'](_0x4c1867):this['resolve'](_0x2066d1),typeof _0x104045=='function'&&(this['promise']['catch'](()=>{}),_0x104045['length']===0x1?_0x104045(_0x4c1867):_0x104045(_0x4c1867,_0x2066d1));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0xc201f7){try{return(_0xc201f7['startsWith']('http://')||_0xc201f7['startsWith']('https://')?new URL(_0xc201f7)['hostname']:_0xc201f7)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x4ccc73){return(await fetch(_0x4ccc73,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x820b1b,_0xc727f3){if(_0x820b1b['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x25d824={'alg':'none','type':'JWT'},_0x176523=_0xc727f3||'demo-project',_0xbe977=_0x820b1b['iat']||0x0,_0xd71d6a=_0x820b1b['sub']||_0x820b1b['user_id'];if(!_0xd71d6a)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x4b2e12={'iss':'https://securetoken.google.com/'+_0x176523,'aud':_0x176523,'iat':_0xbe977,'exp':_0xbe977+0xe10,'auth_time':_0xbe977,'sub':_0xd71d6a,'user_id':_0xd71d6a,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x820b1b};return[cn(JSON['stringify'](_0x25d824)),cn(JSON['stringify'](_0x4b2e12)),'']['join']('.');}const It={};function hc(){const _0x198360={'prod':[],'emulator':[]};for(const _0x294826 of Object['keys'](It))It[_0x294826]?_0x198360['emulator']['push'](_0x294826):_0x198360['prod']['push'](_0x294826);return _0x198360;}function uc(_0x1f8c47){let _0x416ee4=document['getElementById'](_0x1f8c47),_0x4f5307=!0x1;return _0x416ee4||(_0x416ee4=document['createElement']('div'),_0x416ee4['setAttribute']('id',_0x1f8c47),_0x4f5307=!0x0),{'created':_0x4f5307,'element':_0x416ee4};}let Ps=!0x1;function Kr(_0x4c2491,_0x3c8ef9){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x4c2491]===_0x3c8ef9||It[_0x4c2491]||Ps)return;It[_0x4c2491]=_0x3c8ef9;function _0x309757(_0xf7b42f){return'__firebase__banner__'+_0xf7b42f;}const _0x36fbc3='__firebase__banner',_0xd3d5a5=hc()['prod']['length']>0x0;function _0x2d10b9(){const _0x6b239=document['getElementById'](_0x36fbc3);_0x6b239&&_0x6b239['remove']();}function _0x2a466e(_0x2d53e7){_0x2d53e7['style']['display']='flex',_0x2d53e7['style']['background']='#7faaf0',_0x2d53e7['style']['position']='fixed',_0x2d53e7['style']['bottom']='5px',_0x2d53e7['style']['left']='5px',_0x2d53e7['style']['padding']='.5em',_0x2d53e7['style']['borderRadius']='5px',_0x2d53e7['style']['alignItems']='center';}function _0x3db02e(_0x35fe10,_0x47c3ee){_0x35fe10['setAttribute']('width','24'),_0x35fe10['setAttribute']('id',_0x47c3ee),_0x35fe10['setAttribute']('height','24'),_0x35fe10['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x35fe10['setAttribute']('fill','none'),_0x35fe10['style']['marginLeft']='-6px';}function _0x16a0ca(){const _0xd2f607=document['createElement']('span');return _0xd2f607['style']['cursor']='pointer',_0xd2f607['style']['marginLeft']='16px',_0xd2f607['style']['fontSize']='24px',_0xd2f607['innerHTML']='\x20&times;',_0xd2f607['onclick']=()=>{Ps=!0x0,_0x2d10b9();},_0xd2f607;}function _0x4d7538(_0x43c0be,_0x15e633){_0x43c0be['setAttribute']('id',_0x15e633),_0x43c0be['innerText']='Learn\x20more',_0x43c0be['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x43c0be['setAttribute']('target','__blank'),_0x43c0be['style']['paddingLeft']='5px',_0x43c0be['style']['textDecoration']='underline';}function _0x228b8f(){const _0x15e33b=uc(_0x36fbc3),_0x32561a=_0x309757('text'),_0x21d185=document['getElementById'](_0x32561a)||document['createElement']('span'),_0x329fe5=_0x309757('learnmore'),_0x5b4391=document['getElementById'](_0x329fe5)||document['createElement']('a'),_0x1ddf79=_0x309757('preprendIcon'),_0x48a0a4=document['getElementById'](_0x1ddf79)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x15e33b['created']){const _0x1da9f9=_0x15e33b['element'];_0x2a466e(_0x1da9f9),_0x4d7538(_0x5b4391,_0x329fe5);const _0x57e419=_0x16a0ca();_0x3db02e(_0x48a0a4,_0x1ddf79),_0x1da9f9['append'](_0x48a0a4,_0x21d185,_0x5b4391,_0x57e419),document['body']['appendChild'](_0x1da9f9);}_0xd3d5a5?(_0x21d185['innerText']='Preview\x20backend\x20disconnected.',_0x48a0a4['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x48a0a4['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x21d185['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x21d185['setAttribute']('id',_0x32561a);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x228b8f):_0x228b8f();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x40d890=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x40d890=='object'&&_0x40d890['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x2b2763=W();return _0x2b2763['indexOf']('MSIE\x20')>=0x0||_0x2b2763['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0xed0aa4,_0x2232dd)=>{try{let _0x3b2879=!0x0;const _0x146221='validate-browser-context-for-indexeddb-analytics-module',_0x14e77b=self['indexedDB']['open'](_0x146221);_0x14e77b['onsuccess']=()=>{_0x14e77b['result']['close'](),_0x3b2879||self['indexedDB']['deleteDatabase'](_0x146221),_0xed0aa4(!0x0);},_0x14e77b['onupgradeneeded']=()=>{_0x3b2879=!0x1;},_0x14e77b['onerror']=()=>{var _0x37715b;_0x2232dd(((_0x37715b=_0x14e77b['error'])==null?void 0x0:_0x37715b['message'])||'');};}catch(_0xb62fe0){_0x2232dd(_0xb62fe0);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x96aa1c,_0x169862,_0x3b5f48){super(_0x169862),this['code']=_0x96aa1c,this['customData']=_0x3b5f48,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x3120eb,_0x3172d6,_0x153836){this['service']=_0x3120eb,this['serviceName']=_0x3172d6,this['errors']=_0x153836;}['create'](_0x27962f,..._0x37b912){const _0x57057b=_0x37b912[0x0]||{},_0x351aa7=this['service']+'/'+_0x27962f,_0x4b4715=this['errors'][_0x27962f],_0x50e34a=_0x4b4715?vc(_0x4b4715,_0x57057b):'Error',_0x53b04d=this['serviceName']+':\x20'+_0x50e34a+'\x20('+_0x351aa7+').';return new Se(_0x351aa7,_0x53b04d,_0x57057b);}}function vc(_0x2752de,_0x28c0b4){return _0x2752de['replace'](Ec,(_0x5ec648,_0x4bf6eb)=>{const _0x12832a=_0x28c0b4[_0x4bf6eb];return _0x12832a!=null?String(_0x12832a):'<'+_0x4bf6eb+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x3031d4){return JSON['parse'](_0x3031d4);}function O(_0x1b0a56){return JSON['stringify'](_0x1b0a56);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x4a02f2){let _0x128201={},_0x3bffca={},_0x4de2b2={},_0x4c694e='';try{const _0x3b95e0=_0x4a02f2['split']('.');_0x128201=At(ln(_0x3b95e0[0x0])||''),_0x3bffca=At(ln(_0x3b95e0[0x1])||''),_0x4c694e=_0x3b95e0[0x2],_0x4de2b2=_0x3bffca['d']||{},delete _0x3bffca['d'];}catch{}return{'header':_0x128201,'claims':_0x3bffca,'data':_0x4de2b2,'signature':_0x4c694e};},Ic=function(_0x3a5aed){const _0x31c68b=Qr(_0x3a5aed),_0x12ed29=_0x31c68b['claims'];return!!_0x12ed29&&typeof _0x12ed29=='object'&&_0x12ed29['hasOwnProperty']('iat');},wc=function(_0x14bee3){const _0x52b881=Qr(_0x14bee3)['claims'];return typeof _0x52b881=='object'&&_0x52b881['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x382e52,_0x525642){return Object['prototype']['hasOwnProperty']['call'](_0x382e52,_0x525642);}function De(_0x14d5d5,_0x305a2a){if(Object['prototype']['hasOwnProperty']['call'](_0x14d5d5,_0x305a2a))return _0x14d5d5[_0x305a2a];}function ui(_0x1dddf2){for(const _0x2748f8 in _0x1dddf2)if(Object['prototype']['hasOwnProperty']['call'](_0x1dddf2,_0x2748f8))return!0x1;return!0x0;}function hn(_0x27b7c4,_0x1e8d76,_0x3f0078){const _0x548800={};for(const _0x5e34d5 in _0x27b7c4)Object['prototype']['hasOwnProperty']['call'](_0x27b7c4,_0x5e34d5)&&(_0x548800[_0x5e34d5]=_0x1e8d76['call'](_0x3f0078,_0x27b7c4[_0x5e34d5],_0x5e34d5,_0x27b7c4));return _0x548800;}function Me(_0x562399,_0x2c988e){if(_0x562399===_0x2c988e)return!0x0;const _0x110927=Object['keys'](_0x562399),_0xafb6e=Object['keys'](_0x2c988e);for(const _0x2285fb of _0x110927){if(!_0xafb6e['includes'](_0x2285fb))return!0x1;const _0x6bade4=_0x562399[_0x2285fb],_0x2e4028=_0x2c988e[_0x2285fb];if(Os(_0x6bade4)&&Os(_0x2e4028)){if(!Me(_0x6bade4,_0x2e4028))return!0x1;}else{if(_0x6bade4!==_0x2e4028)return!0x1;}}for(const _0x3d426b of _0xafb6e)if(!_0x110927['includes'](_0x3d426b))return!0x1;return!0x0;}function Os(_0x4374a0){return _0x4374a0!==null&&typeof _0x4374a0=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x57816b){const _0x5025b5=[];for(const [_0x58c2af,_0x437e16]of Object['entries'](_0x57816b))Array['isArray'](_0x437e16)?_0x437e16['forEach'](_0x19a837=>{_0x5025b5['push'](encodeURIComponent(_0x58c2af)+'='+encodeURIComponent(_0x19a837));}):_0x5025b5['push'](encodeURIComponent(_0x58c2af)+'='+encodeURIComponent(_0x437e16));return _0x5025b5['length']?'&'+_0x5025b5['join']('&'):'';}function vt(_0x493d4a){const _0x7991eb={};return _0x493d4a['replace'](/^\?/,'')['split']('&')['forEach'](_0x59d64a=>{if(_0x59d64a){const [_0x404df9,_0x47c737]=_0x59d64a['split']('=');_0x7991eb[decodeURIComponent(_0x404df9)]=decodeURIComponent(_0x47c737);}}),_0x7991eb;}function Et(_0x5ed57c){const _0x467d93=_0x5ed57c['indexOf']('?');if(!_0x467d93)return'';const _0x419181=_0x5ed57c['indexOf']('#',_0x467d93);return _0x5ed57c['substring'](_0x467d93,_0x419181>0x0?_0x419181:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x4257ee=0x1;_0x4257ee<this['blockSize'];++_0x4257ee)this['pad_'][_0x4257ee]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1ae1fb,_0x29a2bb){_0x29a2bb||(_0x29a2bb=0x0);const _0x5b7be9=this['W_'];if(typeof _0x1ae1fb=='string'){for(let _0x5726a8=0x0;_0x5726a8<0x10;_0x5726a8++)_0x5b7be9[_0x5726a8]=_0x1ae1fb['charCodeAt'](_0x29a2bb)<<0x18|_0x1ae1fb['charCodeAt'](_0x29a2bb+0x1)<<0x10|_0x1ae1fb['charCodeAt'](_0x29a2bb+0x2)<<0x8|_0x1ae1fb['charCodeAt'](_0x29a2bb+0x3),_0x29a2bb+=0x4;}else{for(let _0x323b03=0x0;_0x323b03<0x10;_0x323b03++)_0x5b7be9[_0x323b03]=_0x1ae1fb[_0x29a2bb]<<0x18|_0x1ae1fb[_0x29a2bb+0x1]<<0x10|_0x1ae1fb[_0x29a2bb+0x2]<<0x8|_0x1ae1fb[_0x29a2bb+0x3],_0x29a2bb+=0x4;}for(let _0x211c2c=0x10;_0x211c2c<0x50;_0x211c2c++){const _0x1d52ab=_0x5b7be9[_0x211c2c-0x3]^_0x5b7be9[_0x211c2c-0x8]^_0x5b7be9[_0x211c2c-0xe]^_0x5b7be9[_0x211c2c-0x10];_0x5b7be9[_0x211c2c]=(_0x1d52ab<<0x1|_0x1d52ab>>>0x1f)&0xffffffff;}let _0x1ac833=this['chain_'][0x0],_0x400eea=this['chain_'][0x1],_0xa279f1=this['chain_'][0x2],_0x10ea36=this['chain_'][0x3],_0x41ec0f=this['chain_'][0x4],_0x1ab70c,_0x462722;for(let _0x57c942=0x0;_0x57c942<0x50;_0x57c942++){_0x57c942<0x28?_0x57c942<0x14?(_0x1ab70c=_0x10ea36^_0x400eea&(_0xa279f1^_0x10ea36),_0x462722=0x5a827999):(_0x1ab70c=_0x400eea^_0xa279f1^_0x10ea36,_0x462722=0x6ed9eba1):_0x57c942<0x3c?(_0x1ab70c=_0x400eea&_0xa279f1|_0x10ea36&(_0x400eea|_0xa279f1),_0x462722=0x8f1bbcdc):(_0x1ab70c=_0x400eea^_0xa279f1^_0x10ea36,_0x462722=0xca62c1d6);const _0x1c9d16=(_0x1ac833<<0x5|_0x1ac833>>>0x1b)+_0x1ab70c+_0x41ec0f+_0x462722+_0x5b7be9[_0x57c942]&0xffffffff;_0x41ec0f=_0x10ea36,_0x10ea36=_0xa279f1,_0xa279f1=(_0x400eea<<0x1e|_0x400eea>>>0x2)&0xffffffff,_0x400eea=_0x1ac833,_0x1ac833=_0x1c9d16;}this['chain_'][0x0]=this['chain_'][0x0]+_0x1ac833&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x400eea&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0xa279f1&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x10ea36&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x41ec0f&0xffffffff;}['update'](_0x5bb79a,_0x59d7df){if(_0x5bb79a==null)return;_0x59d7df===void 0x0&&(_0x59d7df=_0x5bb79a['length']);const _0x5b8150=_0x59d7df-this['blockSize'];let _0x3f0534=0x0;const _0x34d926=this['buf_'];let _0x786d0a=this['inbuf_'];for(;_0x3f0534<_0x59d7df;){if(_0x786d0a===0x0){for(;_0x3f0534<=_0x5b8150;)this['compress_'](_0x5bb79a,_0x3f0534),_0x3f0534+=this['blockSize'];}if(typeof _0x5bb79a=='string'){for(;_0x3f0534<_0x59d7df;)if(_0x34d926[_0x786d0a]=_0x5bb79a['charCodeAt'](_0x3f0534),++_0x786d0a,++_0x3f0534,_0x786d0a===this['blockSize']){this['compress_'](_0x34d926),_0x786d0a=0x0;break;}}else{for(;_0x3f0534<_0x59d7df;)if(_0x34d926[_0x786d0a]=_0x5bb79a[_0x3f0534],++_0x786d0a,++_0x3f0534,_0x786d0a===this['blockSize']){this['compress_'](_0x34d926),_0x786d0a=0x0;break;}}}this['inbuf_']=_0x786d0a,this['total_']+=_0x59d7df;}['digest'](){const _0x262ad9=[];let _0x247308=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x2f9dd8=this['blockSize']-0x1;_0x2f9dd8>=0x38;_0x2f9dd8--)this['buf_'][_0x2f9dd8]=_0x247308&0xff,_0x247308/=0x100;this['compress_'](this['buf_']);let _0x59ee26=0x0;for(let _0x24d900=0x0;_0x24d900<0x5;_0x24d900++)for(let _0x539ac4=0x18;_0x539ac4>=0x0;_0x539ac4-=0x8)_0x262ad9[_0x59ee26]=this['chain_'][_0x24d900]>>_0x539ac4&0xff,++_0x59ee26;return _0x262ad9;}}function Tc(_0x5a6d95,_0x467eb2){const _0x57159f=new Sc(_0x5a6d95,_0x467eb2);return _0x57159f['subscribe']['bind'](_0x57159f);}class Sc{constructor(_0x59c4cc,_0x4feeaf){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x4feeaf,this['task']['then'](()=>{_0x59c4cc(this);})['catch'](_0x17ed45=>{this['error'](_0x17ed45);});}['next'](_0x1c5aca){this['forEachObserver'](_0x49478c=>{_0x49478c['next'](_0x1c5aca);});}['error'](_0x18aaad){this['forEachObserver'](_0x74c459=>{_0x74c459['error'](_0x18aaad);}),this['close'](_0x18aaad);}['complete'](){this['forEachObserver'](_0x59d24c=>{_0x59d24c['complete']();}),this['close']();}['subscribe'](_0x191b2a,_0x5b0942,_0x39e841){let _0x5c14b9;if(_0x191b2a===void 0x0&&_0x5b0942===void 0x0&&_0x39e841===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x191b2a,['next','error','complete'])?_0x5c14b9=_0x191b2a:_0x5c14b9={'next':_0x191b2a,'error':_0x5b0942,'complete':_0x39e841},_0x5c14b9['next']===void 0x0&&(_0x5c14b9['next']=Jn),_0x5c14b9['error']===void 0x0&&(_0x5c14b9['error']=Jn),_0x5c14b9['complete']===void 0x0&&(_0x5c14b9['complete']=Jn);const _0x516d05=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x5c14b9['error'](this['finalError']):_0x5c14b9['complete']();}catch{}}),this['observers']['push'](_0x5c14b9),_0x516d05;}['unsubscribeOne'](_0x3997e6){this['observers']===void 0x0||this['observers'][_0x3997e6]===void 0x0||(delete this['observers'][_0x3997e6],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x3ec98e){if(!this['finalized']){for(let _0x35a058=0x0;_0x35a058<this['observers']['length'];_0x35a058++)this['sendOne'](_0x35a058,_0x3ec98e);}}['sendOne'](_0xc83d53,_0x52674d){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0xc83d53]!==void 0x0)try{_0x52674d(this['observers'][_0xc83d53]);}catch(_0x51de5b){typeof console<'u'&&console['error']&&console['error'](_0x51de5b);}});}['close'](_0x43bc7f){this['finalized']||(this['finalized']=!0x0,_0x43bc7f!==void 0x0&&(this['finalError']=_0x43bc7f),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x48014b,_0x548866){if(typeof _0x48014b!='object'||_0x48014b===null)return!0x1;for(const _0x351355 of _0x548866)if(_0x351355 in _0x48014b&&typeof _0x48014b[_0x351355]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x9f6fa1,_0xce0737){return _0x9f6fa1+'\x20failed:\x20'+_0xce0737+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x2682c1){const _0x35ddfb=[];let _0x1ab2cc=0x0;for(let _0x449d05=0x0;_0x449d05<_0x2682c1['length'];_0x449d05++){let _0x11dbb1=_0x2682c1['charCodeAt'](_0x449d05);if(_0x11dbb1>=0xd800&&_0x11dbb1<=0xdbff){const _0x37c819=_0x11dbb1-0xd800;_0x449d05++,f(_0x449d05<_0x2682c1['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x59761c=_0x2682c1['charCodeAt'](_0x449d05)-0xdc00;_0x11dbb1=0x10000+(_0x37c819<<0xa)+_0x59761c;}_0x11dbb1<0x80?_0x35ddfb[_0x1ab2cc++]=_0x11dbb1:_0x11dbb1<0x800?(_0x35ddfb[_0x1ab2cc++]=_0x11dbb1>>0x6|0xc0,_0x35ddfb[_0x1ab2cc++]=_0x11dbb1&0x3f|0x80):_0x11dbb1<0x10000?(_0x35ddfb[_0x1ab2cc++]=_0x11dbb1>>0xc|0xe0,_0x35ddfb[_0x1ab2cc++]=_0x11dbb1>>0x6&0x3f|0x80,_0x35ddfb[_0x1ab2cc++]=_0x11dbb1&0x3f|0x80):(_0x35ddfb[_0x1ab2cc++]=_0x11dbb1>>0x12|0xf0,_0x35ddfb[_0x1ab2cc++]=_0x11dbb1>>0xc&0x3f|0x80,_0x35ddfb[_0x1ab2cc++]=_0x11dbb1>>0x6&0x3f|0x80,_0x35ddfb[_0x1ab2cc++]=_0x11dbb1&0x3f|0x80);}return _0x35ddfb;},On=function(_0x12f50a){let _0xf61341=0x0;for(let _0x249e2e=0x0;_0x249e2e<_0x12f50a['length'];_0x249e2e++){const _0x138b53=_0x12f50a['charCodeAt'](_0x249e2e);_0x138b53<0x80?_0xf61341++:_0x138b53<0x800?_0xf61341+=0x2:_0x138b53>=0xd800&&_0x138b53<=0xdbff?(_0xf61341+=0x4,_0x249e2e++):_0xf61341+=0x3;}return _0xf61341;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x59c189){return _0x59c189&&_0x59c189['_delegate']?_0x59c189['_delegate']:_0x59c189;}class Le{constructor(_0x28e3ab,_0x4d4ed5,_0xc2a319){this['name']=_0x28e3ab,this['instanceFactory']=_0x4d4ed5,this['type']=_0xc2a319,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x1e4cd7){return this['instantiationMode']=_0x1e4cd7,this;}['setMultipleInstances'](_0x19cc0d){return this['multipleInstances']=_0x19cc0d,this;}['setServiceProps'](_0xfbe219){return this['serviceProps']=_0xfbe219,this;}['setInstanceCreatedCallback'](_0x476307){return this['onInstanceCreated']=_0x476307,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x44705f,_0x3ae286){this['name']=_0x44705f,this['container']=_0x3ae286,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x333f56){const _0x22ab1f=this['normalizeInstanceIdentifier'](_0x333f56);if(!this['instancesDeferred']['has'](_0x22ab1f)){const _0x587f40=new ot();if(this['instancesDeferred']['set'](_0x22ab1f,_0x587f40),this['isInitialized'](_0x22ab1f)||this['shouldAutoInitialize']())try{const _0x2defa2=this['getOrInitializeService']({'instanceIdentifier':_0x22ab1f});_0x2defa2&&_0x587f40['resolve'](_0x2defa2);}catch{}}return this['instancesDeferred']['get'](_0x22ab1f)['promise'];}['getImmediate'](_0x2f110c){const _0x4d7d09=this['normalizeInstanceIdentifier'](_0x2f110c==null?void 0x0:_0x2f110c['identifier']),_0x6040cb=(_0x2f110c==null?void 0x0:_0x2f110c['optional'])??!0x1;if(this['isInitialized'](_0x4d7d09)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4d7d09});}catch(_0x50fc35){if(_0x6040cb)return null;throw _0x50fc35;}else{if(_0x6040cb)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x372b13){if(_0x372b13['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x372b13['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x372b13,!!this['shouldAutoInitialize']()){if(Nc(_0x372b13))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x12d651,_0x158557]of this['instancesDeferred']['entries']()){const _0x2394d4=this['normalizeInstanceIdentifier'](_0x12d651);try{const _0x465dc2=this['getOrInitializeService']({'instanceIdentifier':_0x2394d4});_0x158557['resolve'](_0x465dc2);}catch{}}}}['clearInstance'](_0x1dd4b8=Ne){this['instancesDeferred']['delete'](_0x1dd4b8),this['instancesOptions']['delete'](_0x1dd4b8),this['instances']['delete'](_0x1dd4b8);}async['delete'](){const _0x28c337=Array['from'](this['instances']['values']());await Promise['all']([..._0x28c337['filter'](_0x161403=>'INTERNAL'in _0x161403)['map'](_0x4703ef=>_0x4703ef['INTERNAL']['delete']()),..._0x28c337['filter'](_0x1ae292=>'_delete'in _0x1ae292)['map'](_0x244d01=>_0x244d01['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x41a9d5=Ne){return this['instances']['has'](_0x41a9d5);}['getOptions'](_0x370a30=Ne){return this['instancesOptions']['get'](_0x370a30)||{};}['initialize'](_0x5c8167={}){const {options:_0x26325a={}}=_0x5c8167,_0x264bef=this['normalizeInstanceIdentifier'](_0x5c8167['instanceIdentifier']);if(this['isInitialized'](_0x264bef))throw Error(this['name']+'('+_0x264bef+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x171470=this['getOrInitializeService']({'instanceIdentifier':_0x264bef,'options':_0x26325a});for(const [_0x5d9bee,_0x1ae589]of this['instancesDeferred']['entries']()){const _0x317a1a=this['normalizeInstanceIdentifier'](_0x5d9bee);_0x264bef===_0x317a1a&&_0x1ae589['resolve'](_0x171470);}return _0x171470;}['onInit'](_0x1a9011,_0x5245e5){const _0x4f4fe5=this['normalizeInstanceIdentifier'](_0x5245e5),_0x23403c=this['onInitCallbacks']['get'](_0x4f4fe5)??new Set();_0x23403c['add'](_0x1a9011),this['onInitCallbacks']['set'](_0x4f4fe5,_0x23403c);const _0x1c301f=this['instances']['get'](_0x4f4fe5);return _0x1c301f&&_0x1a9011(_0x1c301f,_0x4f4fe5),()=>{_0x23403c['delete'](_0x1a9011);};}['invokeOnInitCallbacks'](_0x4d036c,_0x30c860){const _0x4962bc=this['onInitCallbacks']['get'](_0x30c860);if(_0x4962bc){for(const _0x1d22a0 of _0x4962bc)try{_0x1d22a0(_0x4d036c,_0x30c860);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x230b19,options:_0x30c5ad={}}){let _0x32bf5a=this['instances']['get'](_0x230b19);if(!_0x32bf5a&&this['component']&&(_0x32bf5a=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x230b19),'options':_0x30c5ad}),this['instances']['set'](_0x230b19,_0x32bf5a),this['instancesOptions']['set'](_0x230b19,_0x30c5ad),this['invokeOnInitCallbacks'](_0x32bf5a,_0x230b19),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x230b19,_0x32bf5a);}catch{}return _0x32bf5a||null;}['normalizeInstanceIdentifier'](_0x53ea59=Ne){return this['component']?this['component']['multipleInstances']?_0x53ea59:Ne:_0x53ea59;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x5d48cf){return _0x5d48cf===Ne?void 0x0:_0x5d48cf;}function Nc(_0x48b5b7){return _0x48b5b7['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x2d8990){this['name']=_0x2d8990,this['providers']=new Map();}['addComponent'](_0x1d2949){const _0x1ddae9=this['getProvider'](_0x1d2949['name']);if(_0x1ddae9['isComponentSet']())throw new Error('Component\x20'+_0x1d2949['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x1ddae9['setComponent'](_0x1d2949);}['addOrOverwriteComponent'](_0x6dbf88){this['getProvider'](_0x6dbf88['name'])['isComponentSet']()&&this['providers']['delete'](_0x6dbf88['name']),this['addComponent'](_0x6dbf88);}['getProvider'](_0x4ec6cc){if(this['providers']['has'](_0x4ec6cc))return this['providers']['get'](_0x4ec6cc);const _0xed1ac5=new Ac(_0x4ec6cc,this);return this['providers']['set'](_0x4ec6cc,_0xed1ac5),_0xed1ac5;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x59eb09){_0x59eb09[_0x59eb09['DEBUG']=0x0]='DEBUG',_0x59eb09[_0x59eb09['VERBOSE']=0x1]='VERBOSE',_0x59eb09[_0x59eb09['INFO']=0x2]='INFO',_0x59eb09[_0x59eb09['WARN']=0x3]='WARN',_0x59eb09[_0x59eb09['ERROR']=0x4]='ERROR',_0x59eb09[_0x59eb09['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x3c9d7a,_0xf0b736,..._0x26e69e)=>{if(_0xf0b736<_0x3c9d7a['logLevel'])return;const _0x555548=new Date()['toISOString'](),_0xf80ff5=Mc[_0xf0b736];if(_0xf80ff5)console[_0xf80ff5]('['+_0x555548+']\x20\x20'+_0x3c9d7a['name']+':',..._0x26e69e);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0xf0b736+')');};class Ui{constructor(_0x24fca6){this['name']=_0x24fca6,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x1382e6){if(!(_0x1382e6 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x1382e6+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x1382e6;}['setLogLevel'](_0x1f60b0){this['_logLevel']=typeof _0x1f60b0=='string'?Oc[_0x1f60b0]:_0x1f60b0;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x1fc3e5){if(typeof _0x1fc3e5!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x1fc3e5;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x1491ff){this['_userLogHandler']=_0x1491ff;}['debug'](..._0x2354b8){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x2354b8),this['_logHandler'](this,T['DEBUG'],..._0x2354b8);}['log'](..._0x272bdc){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x272bdc),this['_logHandler'](this,T['VERBOSE'],..._0x272bdc);}['info'](..._0x1f3d04){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x1f3d04),this['_logHandler'](this,T['INFO'],..._0x1f3d04);}['warn'](..._0x272ed7){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x272ed7),this['_logHandler'](this,T['WARN'],..._0x272ed7);}['error'](..._0x536e91){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x536e91),this['_logHandler'](this,T['ERROR'],..._0x536e91);}}const xc=(_0x3833cb,_0x24fec0)=>_0x24fec0['some'](_0x2eb96c=>_0x3833cb instanceof _0x2eb96c);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0xe2f8b3){const _0x330a10=new Promise((_0x34af81,_0xd811d0)=>{const _0x8ed680=()=>{_0xe2f8b3['removeEventListener']('success',_0x8908eb),_0xe2f8b3['removeEventListener']('error',_0x5151c4);},_0x8908eb=()=>{_0x34af81(_e(_0xe2f8b3['result'])),_0x8ed680();},_0x5151c4=()=>{_0xd811d0(_0xe2f8b3['error']),_0x8ed680();};_0xe2f8b3['addEventListener']('success',_0x8908eb),_0xe2f8b3['addEventListener']('error',_0x5151c4);});return _0x330a10['then'](_0x21f63c=>{_0x21f63c instanceof IDBCursor&&Jr['set'](_0x21f63c,_0xe2f8b3);})['catch'](()=>{}),Wi['set'](_0x330a10,_0xe2f8b3),_0x330a10;}function Bc(_0x56b30){if(di['has'](_0x56b30))return;const _0x121e03=new Promise((_0x2128f4,_0x4da07b)=>{const _0x2788ef=()=>{_0x56b30['removeEventListener']('complete',_0x37052f),_0x56b30['removeEventListener']('error',_0x5cb1bf),_0x56b30['removeEventListener']('abort',_0x5cb1bf);},_0x37052f=()=>{_0x2128f4(),_0x2788ef();},_0x5cb1bf=()=>{_0x4da07b(_0x56b30['error']||new DOMException('AbortError','AbortError')),_0x2788ef();};_0x56b30['addEventListener']('complete',_0x37052f),_0x56b30['addEventListener']('error',_0x5cb1bf),_0x56b30['addEventListener']('abort',_0x5cb1bf);});di['set'](_0x56b30,_0x121e03);}let fi={'get'(_0x5ad629,_0x37111c,_0x3f0268){if(_0x5ad629 instanceof IDBTransaction){if(_0x37111c==='done')return di['get'](_0x5ad629);if(_0x37111c==='objectStoreNames')return _0x5ad629['objectStoreNames']||Xr['get'](_0x5ad629);if(_0x37111c==='store')return _0x3f0268['objectStoreNames'][0x1]?void 0x0:_0x3f0268['objectStore'](_0x3f0268['objectStoreNames'][0x0]);}return _e(_0x5ad629[_0x37111c]);},'set'(_0x539678,_0x510b58,_0x48cf00){return _0x539678[_0x510b58]=_0x48cf00,!0x0;},'has'(_0x464aa0,_0x491195){return _0x464aa0 instanceof IDBTransaction&&(_0x491195==='done'||_0x491195==='store')?!0x0:_0x491195 in _0x464aa0;}};function Vc(_0x429c75){fi=_0x429c75(fi);}function Hc(_0x518a94){return _0x518a94===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x3ec570,..._0x1837a5){const _0xcb6e1a=_0x518a94['call'](Zn(this),_0x3ec570,..._0x1837a5);return Xr['set'](_0xcb6e1a,_0x3ec570['sort']?_0x3ec570['sort']():[_0x3ec570]),_e(_0xcb6e1a);}:Uc()['includes'](_0x518a94)?function(..._0x3cb8b6){return _0x518a94['apply'](Zn(this),_0x3cb8b6),_e(Jr['get'](this));}:function(..._0xa6c10e){return _e(_0x518a94['apply'](Zn(this),_0xa6c10e));};}function $c(_0x663ecc){return typeof _0x663ecc=='function'?Hc(_0x663ecc):(_0x663ecc instanceof IDBTransaction&&Bc(_0x663ecc),xc(_0x663ecc,Fc())?new Proxy(_0x663ecc,fi):_0x663ecc);}function _e(_0x242ca4){if(_0x242ca4 instanceof IDBRequest)return Wc(_0x242ca4);if(Xn['has'](_0x242ca4))return Xn['get'](_0x242ca4);const _0x7058c0=$c(_0x242ca4);return _0x7058c0!==_0x242ca4&&(Xn['set'](_0x242ca4,_0x7058c0),Wi['set'](_0x7058c0,_0x242ca4)),_0x7058c0;}const Zn=_0x1a30a5=>Wi['get'](_0x1a30a5);function Gc(_0x3c5b9c,_0xb9ffbb,{blocked:_0x3a2cd8,upgrade:_0x4792d8,blocking:_0x4f109f,terminated:_0x230638}={}){const _0xced1d5=indexedDB['open'](_0x3c5b9c,_0xb9ffbb),_0x4415e7=_e(_0xced1d5);return _0x4792d8&&_0xced1d5['addEventListener']('upgradeneeded',_0x4ed2d0=>{_0x4792d8(_e(_0xced1d5['result']),_0x4ed2d0['oldVersion'],_0x4ed2d0['newVersion'],_e(_0xced1d5['transaction']),_0x4ed2d0);}),_0x3a2cd8&&_0xced1d5['addEventListener']('blocked',_0x1fd25a=>_0x3a2cd8(_0x1fd25a['oldVersion'],_0x1fd25a['newVersion'],_0x1fd25a)),_0x4415e7['then'](_0x21102f=>{_0x230638&&_0x21102f['addEventListener']('close',()=>_0x230638()),_0x4f109f&&_0x21102f['addEventListener']('versionchange',_0x29d91f=>_0x4f109f(_0x29d91f['oldVersion'],_0x29d91f['newVersion'],_0x29d91f));})['catch'](()=>{}),_0x4415e7;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x49cebd,_0x3c26ae){if(!(_0x49cebd instanceof IDBDatabase&&!(_0x3c26ae in _0x49cebd)&&typeof _0x3c26ae=='string'))return;if(ei['get'](_0x3c26ae))return ei['get'](_0x3c26ae);const _0x2e6c6b=_0x3c26ae['replace'](/FromIndex$/,''),_0x789e15=_0x3c26ae!==_0x2e6c6b,_0x4e6cb7=zc['includes'](_0x2e6c6b);if(!(_0x2e6c6b in(_0x789e15?IDBIndex:IDBObjectStore)['prototype'])||!(_0x4e6cb7||qc['includes'](_0x2e6c6b)))return;const _0x193c43=async function(_0x596682,..._0x4e5b43){const _0x306667=this['transaction'](_0x596682,_0x4e6cb7?'readwrite':'readonly');let _0x13c4ce=_0x306667['store'];return _0x789e15&&(_0x13c4ce=_0x13c4ce['index'](_0x4e5b43['shift']())),(await Promise['all']([_0x13c4ce[_0x2e6c6b](..._0x4e5b43),_0x4e6cb7&&_0x306667['done']]))[0x0];};return ei['set'](_0x3c26ae,_0x193c43),_0x193c43;}Vc(_0x14c32c=>({..._0x14c32c,'get':(_0x56e0b0,_0xf0d7fe,_0x5c5079)=>Ls(_0x56e0b0,_0xf0d7fe)||_0x14c32c['get'](_0x56e0b0,_0xf0d7fe,_0x5c5079),'has':(_0x2862c2,_0x11643e)=>!!Ls(_0x2862c2,_0x11643e)||_0x14c32c['has'](_0x2862c2,_0x11643e)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x56877c){this['container']=_0x56877c;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0xb1160d=>{if(Kc(_0xb1160d)){const _0x4f1f6d=_0xb1160d['getImmediate']();return _0x4f1f6d['library']+'/'+_0x4f1f6d['version'];}else return null;})['filter'](_0x267296=>_0x267296)['join']('\x20');}}function Kc(_0x385499){const _0x125220=_0x385499['getComponent']();return(_0x125220==null?void 0x0:_0x125220['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x49b30c,_0x424074){try{_0x49b30c['container']['addComponent'](_0x424074);}catch(_0x3227ea){oe['debug']('Component\x20'+_0x424074['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x49b30c['name'],_0x3227ea);}}function Ze(_0x1667fe){const _0x535882=_0x1667fe['name'];if(mi['has'](_0x535882))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x535882+'.'),!0x1;mi['set'](_0x535882,_0x1667fe);for(const _0x593ce0 of xe['values']())Fs(_0x593ce0,_0x1667fe);for(const _0x13b2f0 of gi['values']())Fs(_0x13b2f0,_0x1667fe);return!0x0;}function Bi(_0x1ced8e,_0x5c1dd5){const _0x5bd347=_0x1ced8e['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x5bd347&&_0x5bd347['triggerHeartbeat'](),_0x1ced8e['container']['getProvider'](_0x5c1dd5);}function $(_0x5dbdbd){return _0x5dbdbd==null?!0x1:_0x5dbdbd['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x51fd40,_0x699d38,_0x17cab0){this['_isDeleted']=!0x1,this['_options']={..._0x51fd40},this['_config']={..._0x699d38},this['_name']=_0x699d38['name'],this['_automaticDataCollectionEnabled']=_0x699d38['automaticDataCollectionEnabled'],this['_container']=_0x17cab0,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x100573){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x100573;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x5235f1){this['_isDeleted']=_0x5235f1;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x185025,_0x23c335={}){let _0x2b43de=_0x185025;typeof _0x23c335!='object'&&(_0x23c335={'name':_0x23c335});const _0x11b6ad={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x23c335},_0x58152b=_0x11b6ad['name'];if(typeof _0x58152b!='string'||!_0x58152b)throw ge['create']('bad-app-name',{'appName':String(_0x58152b)});if(_0x2b43de||(_0x2b43de=qr()),!_0x2b43de)throw ge['create']('no-options');const _0x493741=xe['get'](_0x58152b);if(_0x493741){if(Me(_0x2b43de,_0x493741['options'])&&Me(_0x11b6ad,_0x493741['config']))return _0x493741;throw ge['create']('duplicate-app',{'appName':_0x58152b});}const _0x59e3ca=new Pc(_0x58152b);for(const _0x1c97df of mi['values']())_0x59e3ca['addComponent'](_0x1c97df);const _0x560e14=new Tl(_0x2b43de,_0x11b6ad,_0x59e3ca);return xe['set'](_0x58152b,_0x560e14),_0x560e14;}function Zr(_0xbafd28=_i){const _0x4238e6=xe['get'](_0xbafd28);if(!_0x4238e6&&_0xbafd28===_i&&qr())return Sl();if(!_0x4238e6)throw ge['create']('no-app',{'appName':_0xbafd28});return _0x4238e6;}function f_(){return Array['from'](xe['values']());}async function p_(_0x427011){let _0x47b059=!0x1;const _0x1eef9c=_0x427011['name'];xe['has'](_0x1eef9c)?(_0x47b059=!0x0,xe['delete'](_0x1eef9c)):gi['has'](_0x1eef9c)&&_0x427011['decRefCount']()<=0x0&&(gi['delete'](_0x1eef9c),_0x47b059=!0x0),_0x47b059&&(await Promise['all'](_0x427011['container']['getProviders']()['map'](_0x22a5e3=>_0x22a5e3['delete']())),_0x427011['isDeleted']=!0x0);}function me(_0x5b6879,_0x1a3374,_0x3fcb44){let _0x50e76d=wl[_0x5b6879]??_0x5b6879;_0x3fcb44&&(_0x50e76d+='-'+_0x3fcb44);const _0x178a37=_0x50e76d['match'](/\s|\//),_0x3d72a0=_0x1a3374['match'](/\s|\//);if(_0x178a37||_0x3d72a0){const _0x139695=['Unable\x20to\x20register\x20library\x20\x22'+_0x50e76d+'\x22\x20with\x20version\x20\x22'+_0x1a3374+'\x22:'];_0x178a37&&_0x139695['push']('library\x20name\x20\x22'+_0x50e76d+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x178a37&&_0x3d72a0&&_0x139695['push']('and'),_0x3d72a0&&_0x139695['push']('version\x20name\x20\x22'+_0x1a3374+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x139695['join']('\x20'));return;}Ze(new Le(_0x50e76d+'-version',()=>({'library':_0x50e76d,'version':_0x1a3374}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x2b6a58,_0x322640)=>{switch(_0x322640){case 0x0:try{_0x2b6a58['createObjectStore'](kt);}catch(_0x540d9e){console['warn'](_0x540d9e);}}}})['catch'](_0x3f6dbe=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x3f6dbe['message']});})),ti;}async function Al(_0x32d824){try{const _0x54c607=(await eo())['transaction'](kt),_0x1aa9e6=await _0x54c607['objectStore'](kt)['get'](to(_0x32d824));return await _0x54c607['done'],_0x1aa9e6;}catch(_0xf922c6){if(_0xf922c6 instanceof Se)oe['warn'](_0xf922c6['message']);else{const _0x4ee4c2=ge['create']('idb-get',{'originalErrorMessage':_0xf922c6==null?void 0x0:_0xf922c6['message']});oe['warn'](_0x4ee4c2['message']);}}}async function Us(_0x378723,_0x28d170){try{const _0x4ba836=(await eo())['transaction'](kt,'readwrite');await _0x4ba836['objectStore'](kt)['put'](_0x28d170,to(_0x378723)),await _0x4ba836['done'];}catch(_0xdfda6f){if(_0xdfda6f instanceof Se)oe['warn'](_0xdfda6f['message']);else{const _0x2a1f20=ge['create']('idb-set',{'originalErrorMessage':_0xdfda6f==null?void 0x0:_0xdfda6f['message']});oe['warn'](_0x2a1f20['message']);}}}function to(_0x406f8c){return _0x406f8c['name']+'!'+_0x406f8c['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x25277b){this['container']=_0x25277b,this['_heartbeatsCache']=null;const _0x282e51=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x282e51),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x1543bc=>(this['_heartbeatsCache']=_0x1543bc,_0x1543bc));}async['triggerHeartbeat'](){var _0x3c2add,_0x63b273;try{const _0x70ebc9=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x413c1d=Ws();if(((_0x3c2add=this['_heartbeatsCache'])==null?void 0x0:_0x3c2add['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x63b273=this['_heartbeatsCache'])==null?void 0x0:_0x63b273['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x413c1d||this['_heartbeatsCache']['heartbeats']['some'](_0x4967cb=>_0x4967cb['date']===_0x413c1d))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x413c1d,'agent':_0x70ebc9}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x1aff27=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x1aff27,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x4cec0a){oe['warn'](_0x4cec0a);}}async['getHeartbeatsHeader'](){var _0x4acb87;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x4acb87=this['_heartbeatsCache'])==null?void 0x0:_0x4acb87['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x1037bc=Ws(),{heartbeatsToSend:_0x1decb8,unsentEntries:_0x456409}=Ol(this['_heartbeatsCache']['heartbeats']),_0x4642c2=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x1decb8}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x1037bc,_0x456409['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x456409,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x4642c2;}catch(_0x35fce6){return oe['warn'](_0x35fce6),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x2ad38d,_0x33f4e7=kl){const _0x226f3c=[];let _0x21638e=_0x2ad38d['slice']();for(const _0x293a17 of _0x2ad38d){const _0x385d4e=_0x226f3c['find'](_0x1d4920=>_0x1d4920['agent']===_0x293a17['agent']);if(_0x385d4e){if(_0x385d4e['dates']['push'](_0x293a17['date']),Bs(_0x226f3c)>_0x33f4e7){_0x385d4e['dates']['pop']();break;}}else{if(_0x226f3c['push']({'agent':_0x293a17['agent'],'dates':[_0x293a17['date']]}),Bs(_0x226f3c)>_0x33f4e7){_0x226f3c['pop']();break;}}_0x21638e=_0x21638e['slice'](0x1);}return{'heartbeatsToSend':_0x226f3c,'unsentEntries':_0x21638e};}class Dl{constructor(_0x1d047e){this['app']=_0x1d047e,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x354ffd=await Al(this['app']);return _0x354ffd!=null&&_0x354ffd['heartbeats']?_0x354ffd:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x280c2a){if(await this['_canUseIndexedDBPromise']){const _0x36d1d7=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x280c2a['lastSentHeartbeatDate']??_0x36d1d7['lastSentHeartbeatDate'],'heartbeats':_0x280c2a['heartbeats']});}else return;}async['add'](_0x1d9628){if(await this['_canUseIndexedDBPromise']){const _0x390650=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x1d9628['lastSentHeartbeatDate']??_0x390650['lastSentHeartbeatDate'],'heartbeats':[..._0x390650['heartbeats'],..._0x1d9628['heartbeats']]});}else return;}}function Bs(_0x78053a){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x78053a}))['length'];}function Ml(_0x4b0e19){if(_0x4b0e19['length']===0x0)return-0x1;let _0x1846ce=0x0,_0xa6c996=_0x4b0e19[0x0]['date'];for(let _0x149302=0x1;_0x149302<_0x4b0e19['length'];_0x149302++)_0x4b0e19[_0x149302]['date']<_0xa6c996&&(_0xa6c996=_0x4b0e19[_0x149302]['date'],_0x1846ce=_0x149302);return _0x1846ce;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x159072){Ze(new Le('platform-logger',_0x37d8c8=>new jc(_0x37d8c8),'PRIVATE')),Ze(new Le('heartbeat',_0x3d2d3e=>new Pl(_0x3d2d3e),'PRIVATE')),me(pi,xs,_0x159072),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x218975){no=_0x218975;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x3bff94){this['domStorage_']=_0x3bff94,this['prefix_']='firebase:';}['set'](_0x32654c,_0x3f9f3c){_0x3f9f3c==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x32654c)):this['domStorage_']['setItem'](this['prefixedName_'](_0x32654c),O(_0x3f9f3c));}['get'](_0x20c7fe){const _0x300046=this['domStorage_']['getItem'](this['prefixedName_'](_0x20c7fe));return _0x300046==null?null:At(_0x300046);}['remove'](_0x5a73e5){this['domStorage_']['removeItem'](this['prefixedName_'](_0x5a73e5));}['prefixedName_'](_0xe0c818){return this['prefix_']+_0xe0c818;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x26c01f,_0x13de75){_0x13de75==null?delete this['cache_'][_0x26c01f]:this['cache_'][_0x26c01f]=_0x13de75;}['get'](_0x3c62d5){return J(this['cache_'],_0x3c62d5)?this['cache_'][_0x3c62d5]:null;}['remove'](_0x2232ec){delete this['cache_'][_0x2232ec];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0xfc5f68){try{if(typeof window<'u'&&typeof window[_0xfc5f68]<'u'){const _0x181722=window[_0xfc5f68];return _0x181722['setItem']('firebase:sentinel','cache'),_0x181722['removeItem']('firebase:sentinel'),new Wl(_0x181722);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x13e196=0x1;return function(){return _0x13e196++;};}()),ro=function(_0x5e22b4){const _0x101c9b=Rc(_0x5e22b4),_0x23ac1d=new Cc();_0x23ac1d['update'](_0x101c9b);const _0x50eefe=_0x23ac1d['digest']();return Li['encodeByteArray'](_0x50eefe);},Vt=function(..._0x43477b){let _0x3703a3='';for(let _0x26743e=0x0;_0x26743e<_0x43477b['length'];_0x26743e++){const _0x51c6bb=_0x43477b[_0x26743e];Array['isArray'](_0x51c6bb)||_0x51c6bb&&typeof _0x51c6bb=='object'&&typeof _0x51c6bb['length']=='number'?_0x3703a3+=Vt['apply'](null,_0x51c6bb):typeof _0x51c6bb=='object'?_0x3703a3+=O(_0x51c6bb):_0x3703a3+=_0x51c6bb,_0x3703a3+='\x20';}return _0x3703a3;};let wt=null,Gs=!0x0;const Hl=function(_0x9d7ea,_0x572a36){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x28f69b){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x3c3776=Vt['apply'](null,_0x28f69b);wt(_0x3c3776);}},Ht=function(_0x1aefed){return function(..._0x51f890){L(_0x1aefed,..._0x51f890);};},yi=function(..._0x9bf5f4){const _0x14e6b3='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x9bf5f4);Ye['error'](_0x14e6b3);},ae=function(..._0x5b3c49){const _0x3da88a='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x5b3c49);throw Ye['error'](_0x3da88a),new Error(_0x3da88a);},U=function(..._0x3175da){const _0x2c4cfd='FIREBASE\x20WARNING:\x20'+Vt(..._0x3175da);Ye['warn'](_0x2c4cfd);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x128758){return typeof _0x128758=='number'&&(_0x128758!==_0x128758||_0x128758===Number['POSITIVE_INFINITY']||_0x128758===Number['NEGATIVE_INFINITY']);},Gl=function(_0x426326){if(document['readyState']==='complete')_0x426326();else{let _0x5758e2=!0x1;const _0x1cd95d=function(){if(!document['body']){setTimeout(_0x1cd95d,Math['floor'](0xa));return;}_0x5758e2||(_0x5758e2=!0x0,_0x426326());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x1cd95d,!0x1),window['addEventListener']('load',_0x1cd95d,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x1cd95d();}),window['attachEvent']('onload',_0x1cd95d));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0xbda642,_0x415684){if(_0xbda642===_0x415684)return 0x0;if(_0xbda642===Fe||_0x415684===Ie)return-0x1;if(_0x415684===Fe||_0xbda642===Ie)return 0x1;{const _0x34e3cb=qs(_0xbda642),_0x5c82bf=qs(_0x415684);return _0x34e3cb!==null?_0x5c82bf!==null?_0x34e3cb-_0x5c82bf===0x0?_0xbda642['length']-_0x415684['length']:_0x34e3cb-_0x5c82bf:-0x1:_0x5c82bf!==null?0x1:_0xbda642<_0x415684?-0x1:0x1;}},ql=function(_0x35f430,_0x44a718){return _0x35f430===_0x44a718?0x0:_0x35f430<_0x44a718?-0x1:0x1;},_t=function(_0xce0111,_0xd54691){if(_0xd54691&&_0xce0111 in _0xd54691)return _0xd54691[_0xce0111];throw new Error('Missing\x20required\x20key\x20('+_0xce0111+')\x20in\x20object:\x20'+O(_0xd54691));},Hi=function(_0x8f3f06){if(typeof _0x8f3f06!='object'||_0x8f3f06===null)return O(_0x8f3f06);const _0x4ce674=[];for(const _0x4232e in _0x8f3f06)_0x4ce674['push'](_0x4232e);_0x4ce674['sort']();let _0x250599='{';for(let _0x3196c1=0x0;_0x3196c1<_0x4ce674['length'];_0x3196c1++)_0x3196c1!==0x0&&(_0x250599+=','),_0x250599+=O(_0x4ce674[_0x3196c1]),_0x250599+=':',_0x250599+=Hi(_0x8f3f06[_0x4ce674[_0x3196c1]]);return _0x250599+='}',_0x250599;},oo=function(_0x13a99c,_0x5785c7){const _0x28d9d6=_0x13a99c['length'];if(_0x28d9d6<=_0x5785c7)return[_0x13a99c];const _0x378a31=[];for(let _0x47df03=0x0;_0x47df03<_0x28d9d6;_0x47df03+=_0x5785c7)_0x47df03+_0x5785c7>_0x28d9d6?_0x378a31['push'](_0x13a99c['substring'](_0x47df03,_0x28d9d6)):_0x378a31['push'](_0x13a99c['substring'](_0x47df03,_0x47df03+_0x5785c7));return _0x378a31;};function x(_0x4ce345,_0x64d52d){for(const _0x28ea59 in _0x4ce345)_0x4ce345['hasOwnProperty'](_0x28ea59)&&_0x64d52d(_0x28ea59,_0x4ce345[_0x28ea59]);}const ao=function(_0x113475){f(!Vi(_0x113475),'Invalid\x20JSON\x20number');const _0x35b250=0xb,_0x105cff=0x34,_0x5465e5=(0x1<<_0x35b250-0x1)-0x1;let _0xdade50,_0x52f2b5,_0x32b9e8,_0x254255,_0x53873d;_0x113475===0x0?(_0x52f2b5=0x0,_0x32b9e8=0x0,_0xdade50=0x1/_0x113475===-0x1/0x0?0x1:0x0):(_0xdade50=_0x113475<0x0,_0x113475=Math['abs'](_0x113475),_0x113475>=Math['pow'](0x2,0x1-_0x5465e5)?(_0x254255=Math['min'](Math['floor'](Math['log'](_0x113475)/Math['LN2']),_0x5465e5),_0x52f2b5=_0x254255+_0x5465e5,_0x32b9e8=Math['round'](_0x113475*Math['pow'](0x2,_0x105cff-_0x254255)-Math['pow'](0x2,_0x105cff))):(_0x52f2b5=0x0,_0x32b9e8=Math['round'](_0x113475/Math['pow'](0x2,0x1-_0x5465e5-_0x105cff))));const _0x5336d8=[];for(_0x53873d=_0x105cff;_0x53873d;_0x53873d-=0x1)_0x5336d8['push'](_0x32b9e8%0x2?0x1:0x0),_0x32b9e8=Math['floor'](_0x32b9e8/0x2);for(_0x53873d=_0x35b250;_0x53873d;_0x53873d-=0x1)_0x5336d8['push'](_0x52f2b5%0x2?0x1:0x0),_0x52f2b5=Math['floor'](_0x52f2b5/0x2);_0x5336d8['push'](_0xdade50?0x1:0x0),_0x5336d8['reverse']();const _0x5f5b24=_0x5336d8['join']('');let _0x297e2a='';for(_0x53873d=0x0;_0x53873d<0x40;_0x53873d+=0x8){let _0x162856=parseInt(_0x5f5b24['substr'](_0x53873d,0x8),0x2)['toString'](0x10);_0x162856['length']===0x1&&(_0x162856='0'+_0x162856),_0x297e2a=_0x297e2a+_0x162856;}return _0x297e2a['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x41ea81,_0xfffb47){let _0x1f2645='Unknown\x20Error';_0x41ea81==='too_big'?_0x1f2645='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x41ea81==='permission_denied'?_0x1f2645='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x41ea81==='unavailable'&&(_0x1f2645='The\x20service\x20is\x20unavailable');const _0x341b74=new Error(_0x41ea81+'\x20at\x20'+_0xfffb47['_path']['toString']()+':\x20'+_0x1f2645);return _0x341b74['code']=_0x41ea81['toUpperCase'](),_0x341b74;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x592e67){if(Yl['test'](_0x592e67)){const _0x6f5dff=Number(_0x592e67);if(_0x6f5dff>=Ql&&_0x6f5dff<=Jl)return _0x6f5dff;}return null;},ht=function(_0x17bb7a){try{_0x17bb7a();}catch(_0x488372){setTimeout(()=>{const _0x4171c2=_0x488372['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x4171c2),_0x488372;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x2a7401,_0x4d6096){const _0x1f4569=setTimeout(_0x2a7401,_0x4d6096);return typeof _0x1f4569=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x1f4569):typeof _0x1f4569=='object'&&_0x1f4569['unref']&&_0x1f4569['unref'](),_0x1f4569;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x2fce32,_0x27b228){this['appCheckProvider']=_0x27b228,this['appName']=_0x2fce32['name'],$(_0x2fce32)&&_0x2fce32['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x2fce32['settings']['appCheckToken']),this['appCheck']=_0x27b228==null?void 0x0:_0x27b228['getImmediate']({'optional':!0x0}),this['appCheck']||_0x27b228==null||_0x27b228['get']()['then'](_0xac0584=>this['appCheck']=_0xac0584);}['getToken'](_0x57d4f5){if(this['serverAppAppCheckToken']){if(_0x57d4f5)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x57d4f5):new Promise((_0x5cb11d,_0x14c45d)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x57d4f5)['then'](_0x5cb11d,_0x14c45d):_0x5cb11d(null);},0x0);});}['addTokenChangeListener'](_0x5d10ce){var _0x2de3e9;(_0x2de3e9=this['appCheckProvider'])==null||_0x2de3e9['get']()['then'](_0x1ef98b=>_0x1ef98b['addTokenListener'](_0x5d10ce));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x26ea3c,_0x4f340e,_0x27937c){this['appName_']=_0x26ea3c,this['firebaseOptions_']=_0x4f340e,this['authProvider_']=_0x27937c,this['auth_']=null,this['auth_']=_0x27937c['getImmediate']({'optional':!0x0}),this['auth_']||_0x27937c['onInit'](_0x156d66=>this['auth_']=_0x156d66);}['getToken'](_0x32c1d6){return this['auth_']?this['auth_']['getToken'](_0x32c1d6)['catch'](_0x4ce18d=>_0x4ce18d&&_0x4ce18d['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x4ce18d)):new Promise((_0x5b2cf6,_0x5e5ed3)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x32c1d6)['then'](_0x5b2cf6,_0x5e5ed3):_0x5b2cf6(null);},0x0);});}['addTokenChangeListener'](_0x59a001){this['auth_']?this['auth_']['addAuthTokenListener'](_0x59a001):this['authProvider_']['get']()['then'](_0x177ca6=>_0x177ca6['addAuthTokenListener'](_0x59a001));}['removeTokenChangeListener'](_0x2f0adb){this['authProvider_']['get']()['then'](_0x155521=>_0x155521['removeAuthTokenListener'](_0x2f0adb));}['notifyForInvalidToken'](){let _0x3eb693='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x3eb693+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x3eb693+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x3eb693+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x3eb693);}}class nn{constructor(_0x2c87b7){this['accessToken']=_0x2c87b7;}['getToken'](_0x29c136){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x33d30a){_0x33d30a(this['accessToken']);}['removeTokenChangeListener'](_0x6befc4){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x33a680,_0x23e638,_0x4f19d7,_0x30ca16,_0x5a1a82=!0x1,_0x50c90='',_0x37d934=!0x1,_0x576487=!0x1,_0x1f3c88=null){this['secure']=_0x23e638,this['namespace']=_0x4f19d7,this['webSocketOnly']=_0x30ca16,this['nodeAdmin']=_0x5a1a82,this['persistenceKey']=_0x50c90,this['includeNamespaceInQueryParams']=_0x37d934,this['isUsingEmulator']=_0x576487,this['emulatorOptions']=_0x1f3c88,this['_host']=_0x33a680['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x33a680)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x2e7453){_0x2e7453!==this['internalHost']&&(this['internalHost']=_0x2e7453,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x48e6d2=this['toURLString']();return this['persistenceKey']&&(_0x48e6d2+='<'+this['persistenceKey']+'>'),_0x48e6d2;}['toURLString'](){const _0x46f003=this['secure']?'https://':'http://',_0x2a8381=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x46f003+this['host']+'/'+_0x2a8381;}}function th(_0x806de4){return _0x806de4['host']!==_0x806de4['internalHost']||_0x806de4['isCustomHost']()||_0x806de4['includeNamespaceInQueryParams'];}function vo(_0x37f6f8,_0x5d4605,_0x1aafd8){f(typeof _0x5d4605=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x1aafd8=='object','typeof\x20params\x20must\x20==\x20object');let _0x407efd;if(_0x5d4605===go)_0x407efd=(_0x37f6f8['secure']?'wss://':'ws://')+_0x37f6f8['internalHost']+'/.ws?';else{if(_0x5d4605===mo)_0x407efd=(_0x37f6f8['secure']?'https://':'http://')+_0x37f6f8['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x5d4605);}th(_0x37f6f8)&&(_0x1aafd8['ns']=_0x37f6f8['namespace']);const _0x16d8b4=[];return x(_0x1aafd8,(_0x1805bc,_0x3224d3)=>{_0x16d8b4['push'](_0x1805bc+'='+_0x3224d3);}),_0x407efd+_0x16d8b4['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x72aa6f,_0x3e0101=0x1){J(this['counters_'],_0x72aa6f)||(this['counters_'][_0x72aa6f]=0x0),this['counters_'][_0x72aa6f]+=_0x3e0101;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x19c35a){const _0x1b5f32=_0x19c35a['toString']();return ni[_0x1b5f32]||(ni[_0x1b5f32]=new nh()),ni[_0x1b5f32];}function ih(_0x33509d,_0x6c75e2){const _0x281fee=_0x33509d['toString']();return ii[_0x281fee]||(ii[_0x281fee]=_0x6c75e2()),ii[_0x281fee];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x390576){this['onMessage_']=_0x390576,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x857bfb,_0x698bb6){this['closeAfterResponse']=_0x857bfb,this['onClose']=_0x698bb6,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x361b11,_0x53edec){for(this['pendingResponses'][_0x361b11]=_0x53edec;this['pendingResponses'][this['currentResponseNum']];){const _0x2d038d=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x1b8cfa=0x0;_0x1b8cfa<_0x2d038d['length'];++_0x1b8cfa)_0x2d038d[_0x1b8cfa]&&ht(()=>{this['onMessage_'](_0x2d038d[_0x1b8cfa]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x3c0f3b,_0x238346,_0x18af3f,_0x269bcc,_0x16edaa,_0x34b22c,_0x5591d8){this['connId']=_0x3c0f3b,this['repoInfo']=_0x238346,this['applicationId']=_0x18af3f,this['appCheckToken']=_0x269bcc,this['authToken']=_0x16edaa,this['transportSessionId']=_0x34b22c,this['lastSessionId']=_0x5591d8,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x3c0f3b),this['stats_']=Gi(_0x238346),this['urlFn']=_0x29b5de=>(this['appCheckToken']&&(_0x29b5de[vi]=this['appCheckToken']),vo(_0x238346,mo,_0x29b5de));}['open'](_0x46a7f6,_0x2cb41e){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x2cb41e,this['myPacketOrderer']=new sh(_0x46a7f6),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x479b47)=>{const [_0x59867e,_0x56bec5,_0x4a07f2,_0x580341,_0x1f29b4]=_0x479b47;if(this['incrementIncomingBytes_'](_0x479b47),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x59867e===zs)this['id']=_0x56bec5,this['password']=_0x4a07f2;else{if(_0x59867e===rh)_0x56bec5?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x56bec5,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x59867e);}}},(..._0x3584d7)=>{const [_0xbc905c,_0x154e47]=_0x3584d7;this['incrementIncomingBytes_'](_0x3584d7),this['myPacketOrderer']['handleResponse'](_0xbc905c,_0x154e47);},()=>{this['onClosed_']();},this['urlFn']);const _0x14ffbf={};_0x14ffbf[zs]='t',_0x14ffbf[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x14ffbf[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x14ffbf[co]=$i,this['transportSessionId']&&(_0x14ffbf[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x14ffbf[po]=this['lastSessionId']),this['applicationId']&&(_0x14ffbf[_o]=this['applicationId']),this['appCheckToken']&&(_0x14ffbf[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x14ffbf[ho]=uo);const _0x3e997c=this['urlFn'](_0x14ffbf);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x3e997c),this['scriptTagHolder']['addTag'](_0x3e997c,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x2d4899){const _0x3b8700=O(_0x2d4899);this['bytesSent']+=_0x3b8700['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3b8700['length']);const _0x315c0c=Hr(_0x3b8700),_0x30ee0f=oo(_0x315c0c,fh);for(let _0x1c1a6b=0x0;_0x1c1a6b<_0x30ee0f['length'];_0x1c1a6b++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x30ee0f['length'],_0x30ee0f[_0x1c1a6b]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x2c97fb,_0x5d5da7){this['myDisconnFrame']=document['createElement']('iframe');const _0x1e0c9e={};_0x1e0c9e[dh]='t',_0x1e0c9e[Eo]=_0x2c97fb,_0x1e0c9e[Io]=_0x5d5da7,this['myDisconnFrame']['src']=this['urlFn'](_0x1e0c9e),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x5c759a){const _0x2f6517=O(_0x5c759a)['length'];this['bytesReceived']+=_0x2f6517,this['stats_']['incrementCounter']('bytes_received',_0x2f6517);}}class qi{constructor(_0x50bfb0,_0x44fa5b,_0x36774d,_0x43f43d){this['onDisconnect']=_0x36774d,this['urlFn']=_0x43f43d,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x50bfb0,window[ah+this['uniqueCallbackIdentifier']]=_0x44fa5b,this['myIFrame']=qi['createIFrame_']();let _0x1b6d3f='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x1b6d3f='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x24265='<html><body>'+_0x1b6d3f+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x24265),this['myIFrame']['doc']['close']();}catch(_0x4cb47d){L('frame\x20writing\x20exception'),_0x4cb47d['stack']&&L(_0x4cb47d['stack']),L(_0x4cb47d);}}}static['createIFrame_'](){const _0x7e6a98=document['createElement']('iframe');if(_0x7e6a98['style']['display']='none',document['body']){document['body']['appendChild'](_0x7e6a98);try{_0x7e6a98['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x50260b=document['domain'];_0x7e6a98['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x50260b+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x7e6a98['contentDocument']?_0x7e6a98['doc']=_0x7e6a98['contentDocument']:_0x7e6a98['contentWindow']?_0x7e6a98['doc']=_0x7e6a98['contentWindow']['document']:_0x7e6a98['document']&&(_0x7e6a98['doc']=_0x7e6a98['document']),_0x7e6a98;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x29a6d5=this['onDisconnect'];_0x29a6d5&&(this['onDisconnect']=null,_0x29a6d5());}['startLongPoll'](_0x50a94c,_0x1fee27){for(this['myID']=_0x50a94c,this['myPW']=_0x1fee27,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x3fb5f2={};_0x3fb5f2[Eo]=this['myID'],_0x3fb5f2[Io]=this['myPW'],_0x3fb5f2[wo]=this['currentSerial'];let _0x27db1a=this['urlFn'](_0x3fb5f2),_0xd067dd='',_0x2a55d6=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0xd067dd['length']<=Co;){const _0x37943e=this['pendingSegs']['shift']();_0xd067dd=_0xd067dd+'&'+lh+_0x2a55d6+'='+_0x37943e['seg']+'&'+hh+_0x2a55d6+'='+_0x37943e['ts']+'&'+uh+_0x2a55d6+'='+_0x37943e['d'],_0x2a55d6++;}return _0x27db1a=_0x27db1a+_0xd067dd,this['addLongPollTag_'](_0x27db1a,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x1689dd,_0x2c483e,_0x5dccfd){this['pendingSegs']['push']({'seg':_0x1689dd,'ts':_0x2c483e,'d':_0x5dccfd}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1b5938,_0x105b01){this['outstandingRequests']['add'](_0x105b01);const _0x13d03c=()=>{this['outstandingRequests']['delete'](_0x105b01),this['newRequest_']();},_0x2b1e3f=setTimeout(_0x13d03c,Math['floor'](ph)),_0x37160a=()=>{clearTimeout(_0x2b1e3f),_0x13d03c();};this['addTag'](_0x1b5938,_0x37160a);}['addTag'](_0x2271d8,_0x232611){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x3f120a=this['myIFrame']['doc']['createElement']('script');_0x3f120a['type']='text/javascript',_0x3f120a['async']=!0x0,_0x3f120a['src']=_0x2271d8,_0x3f120a['onload']=_0x3f120a['onreadystatechange']=function(){const _0x1e6d3e=_0x3f120a['readyState'];(!_0x1e6d3e||_0x1e6d3e==='loaded'||_0x1e6d3e==='complete')&&(_0x3f120a['onload']=_0x3f120a['onreadystatechange']=null,_0x3f120a['parentNode']&&_0x3f120a['parentNode']['removeChild'](_0x3f120a),_0x232611());},_0x3f120a['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x2271d8),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x3f120a);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x20a89,_0x14eb22,_0x15cf60,_0x31dce0,_0x109026,_0x483915,_0xdaec4b){this['connId']=_0x20a89,this['applicationId']=_0x15cf60,this['appCheckToken']=_0x31dce0,this['authToken']=_0x109026,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x14eb22),this['connURL']=z['connectionURL_'](_0x14eb22,_0x483915,_0xdaec4b,_0x31dce0,_0x15cf60),this['nodeAdmin']=_0x14eb22['nodeAdmin'];}static['connectionURL_'](_0x5786db,_0xc12352,_0x310a56,_0x15c895,_0x48c6be){const _0xb95b8f={};return _0xb95b8f[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0xb95b8f[ho]=uo),_0xc12352&&(_0xb95b8f[lo]=_0xc12352),_0x310a56&&(_0xb95b8f[po]=_0x310a56),_0x15c895&&(_0xb95b8f[vi]=_0x15c895),_0x48c6be&&(_0xb95b8f[_o]=_0x48c6be),vo(_0x5786db,go,_0xb95b8f);}['open'](_0x5ed50b,_0x2f192e){this['onDisconnect']=_0x2f192e,this['onMessage']=_0x5ed50b,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x1a3b5b;_c(),this['mySock']=new un(this['connURL'],[],_0x1a3b5b);}catch(_0x1fc3ac){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x5a0770=_0x1fc3ac['message']||_0x1fc3ac['data'];_0x5a0770&&this['log_'](_0x5a0770),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x444400=>{this['handleIncomingFrame'](_0x444400);},this['mySock']['onerror']=_0x2f9f09=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x27e02b=_0x2f9f09['message']||_0x2f9f09['data'];_0x27e02b&&this['log_'](_0x27e02b),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x249e90=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x4b3cec=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x1e94bf=navigator['userAgent']['match'](_0x4b3cec);_0x1e94bf&&_0x1e94bf['length']>0x1&&parseFloat(_0x1e94bf[0x1])<4.4&&(_0x249e90=!0x0);}return!_0x249e90&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x18d8cb){if(this['frames']['push'](_0x18d8cb),this['frames']['length']===this['totalFrames']){const _0x1bec81=this['frames']['join']('');this['frames']=null;const _0xc54c54=At(_0x1bec81);this['onMessage'](_0xc54c54);}}['handleNewFrameCount_'](_0x1462dc){this['totalFrames']=_0x1462dc,this['frames']=[];}['extractFrameCount_'](_0x4ef2a4){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x4ef2a4['length']<=0x6){const _0x52d5f6=Number(_0x4ef2a4);if(!isNaN(_0x52d5f6))return this['handleNewFrameCount_'](_0x52d5f6),null;}return this['handleNewFrameCount_'](0x1),_0x4ef2a4;}['handleIncomingFrame'](_0x33779f){if(this['mySock']===null)return;const _0x3826c3=_0x33779f['data'];if(this['bytesReceived']+=_0x3826c3['length'],this['stats_']['incrementCounter']('bytes_received',_0x3826c3['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x3826c3);else{const _0x1c9864=this['extractFrameCount_'](_0x3826c3);_0x1c9864!==null&&this['appendFrame_'](_0x1c9864);}}['send'](_0x189ddb){this['resetKeepAlive']();const _0x2ef7a9=O(_0x189ddb);this['bytesSent']+=_0x2ef7a9['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2ef7a9['length']);const _0x9afddd=oo(_0x2ef7a9,gh);_0x9afddd['length']>0x1&&this['sendString_'](String(_0x9afddd['length']));for(let _0x237f22=0x0;_0x237f22<_0x9afddd['length'];_0x237f22++)this['sendString_'](_0x9afddd[_0x237f22]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x1bc47c){try{this['mySock']['send'](_0x1bc47c);}catch(_0xe0415a){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0xe0415a['message']||_0xe0415a['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5b53b0){this['initTransports_'](_0x5b53b0);}['initTransports_'](_0x1fa3bd){const _0x278b64=z&&z['isAvailable']();let _0x1f65ef=_0x278b64&&!z['previouslyFailed']();if(_0x1fa3bd['webSocketOnly']&&(_0x278b64||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x1f65ef=!0x0),_0x1f65ef)this['transports_']=[z];else{const _0x12e006=this['transports_']=[];for(const _0x520893 of Nt['ALL_TRANSPORTS'])_0x520893&&_0x520893['isAvailable']()&&_0x12e006['push'](_0x520893);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x14f033,_0x56f4f4,_0x4b71e2,_0x52ad60,_0x18fe35,_0x56a616,_0x560ea3,_0x191e7c,_0x500a02,_0x2eba94){this['id']=_0x14f033,this['repoInfo_']=_0x56f4f4,this['applicationId_']=_0x4b71e2,this['appCheckToken_']=_0x52ad60,this['authToken_']=_0x18fe35,this['onMessage_']=_0x56a616,this['onReady_']=_0x560ea3,this['onDisconnect_']=_0x191e7c,this['onKill_']=_0x500a02,this['lastSessionId']=_0x2eba94,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x56f4f4),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x3328f2=this['transportManager_']['initialTransport']();this['conn_']=new _0x3328f2(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x3328f2['responsesRequiredToBeHealthy']||0x0;const _0xf44b7f=this['connReceiver_'](this['conn_']),_0x15d059=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0xf44b7f,_0x15d059);},Math['floor'](0x0));const _0x5cd40e=_0x3328f2['healthyTimeout']||0x0;_0x5cd40e>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x5cd40e)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x483c9d){return _0xca7704=>{_0x483c9d===this['conn_']?this['onConnectionLost_'](_0xca7704):_0x483c9d===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x269591){return _0x2002d5=>{this['state_']!==0x2&&(_0x269591===this['rx_']?this['onPrimaryMessageReceived_'](_0x2002d5):_0x269591===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x2002d5):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x4f6ec7){const _0x23585b={'t':'d','d':_0x4f6ec7};this['sendData_'](_0x23585b);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x105b16){if(si in _0x105b16){const _0x3fd7ab=_0x105b16[si];_0x3fd7ab===Qs?this['upgradeIfSecondaryHealthy_']():_0x3fd7ab===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x3fd7ab===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x1dc25c){const _0x5b8f0b=_t('t',_0x1dc25c),_0x1318be=_t('d',_0x1dc25c);if(_0x5b8f0b==='c')this['onSecondaryControl_'](_0x1318be);else{if(_0x5b8f0b==='d')this['pendingDataMessages']['push'](_0x1318be);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x5b8f0b);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x405d8a){const _0x1cdeeb=_t('t',_0x405d8a),_0x5e082f=_t('d',_0x405d8a);_0x1cdeeb==='c'?this['onControl_'](_0x5e082f):_0x1cdeeb==='d'&&this['onDataMessage_'](_0x5e082f);}['onDataMessage_'](_0xad7432){this['onPrimaryResponse_'](),this['onMessage_'](_0xad7432);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x2d064a){const _0x34bd54=_t(si,_0x2d064a);if(js in _0x2d064a){const _0x46d8ab=_0x2d064a[js];if(_0x34bd54===Th){const _0x55e51d={..._0x46d8ab};this['repoInfo_']['isUsingEmulator']&&(_0x55e51d['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x55e51d);}else{if(_0x34bd54===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x314316=0x0;_0x314316<this['pendingDataMessages']['length'];++_0x314316)this['onDataMessage_'](this['pendingDataMessages'][_0x314316]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x34bd54===wh?this['onConnectionShutdown_'](_0x46d8ab):_0x34bd54===Ks?this['onReset_'](_0x46d8ab):_0x34bd54===Ch?yi('Server\x20Error:\x20'+_0x46d8ab):_0x34bd54===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x34bd54);}}}['onHandshake_'](_0x3e1f31){const _0x5728c6=_0x3e1f31['ts'],_0x49ea70=_0x3e1f31['v'],_0x3f9630=_0x3e1f31['h'];this['sessionId']=_0x3e1f31['s'],this['repoInfo_']['host']=_0x3f9630,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x5728c6),$i!==_0x49ea70&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x4bcc70=this['transportManager_']['upgradeTransport']();_0x4bcc70&&this['startUpgrade_'](_0x4bcc70);}['startUpgrade_'](_0x35c165){this['secondaryConn_']=new _0x35c165(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x35c165['responsesRequiredToBeHealthy']||0x0;const _0x6e903f=this['connReceiver_'](this['secondaryConn_']),_0x3b2392=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x6e903f,_0x3b2392),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x3eba55){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x3eba55),this['repoInfo_']['host']=_0x3eba55,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x4cae09,_0xa2dcbd){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x4cae09,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0xa2dcbd,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x482215=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x482215||this['rx_']===_0x482215)&&this['close']();}['onConnectionLost_'](_0x81dbd2){this['conn_']=null,!_0x81dbd2&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x42194c){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x42194c),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x11268a){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x11268a);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0xa42140,_0x114198,_0x6e27f7,_0x4a5c53){}['merge'](_0x1c7678,_0x3bd657,_0x2ac76a,_0x5f4854){}['refreshAuthToken'](_0x3a5c0c){}['refreshAppCheckToken'](_0x5a06da){}['onDisconnectPut'](_0x8c4b85,_0xcf99e,_0x61d2cb){}['onDisconnectMerge'](_0x2762c1,_0x5afdf7,_0x3f52b9){}['onDisconnectCancel'](_0x47e92d,_0x4560ea){}['reportStats'](_0x1fa014){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x64e70d){this['allowedEvents_']=_0x64e70d,this['listeners_']={},f(Array['isArray'](_0x64e70d)&&_0x64e70d['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x546b83,..._0x122a09){if(Array['isArray'](this['listeners_'][_0x546b83])){const _0x43e68e=[...this['listeners_'][_0x546b83]];for(let _0xcd7802=0x0;_0xcd7802<_0x43e68e['length'];_0xcd7802++)_0x43e68e[_0xcd7802]['callback']['apply'](_0x43e68e[_0xcd7802]['context'],_0x122a09);}}['on'](_0x336cba,_0x9d449f,_0x178858){this['validateEventType_'](_0x336cba),this['listeners_'][_0x336cba]=this['listeners_'][_0x336cba]||[],this['listeners_'][_0x336cba]['push']({'callback':_0x9d449f,'context':_0x178858});const _0x4a8671=this['getInitialEvent'](_0x336cba);_0x4a8671&&_0x9d449f['apply'](_0x178858,_0x4a8671);}['off'](_0x21283f,_0x2704fb,_0x19a77b){this['validateEventType_'](_0x21283f);const _0x51bc12=this['listeners_'][_0x21283f]||[];for(let _0x3dac2b=0x0;_0x3dac2b<_0x51bc12['length'];_0x3dac2b++)if(_0x51bc12[_0x3dac2b]['callback']===_0x2704fb&&(!_0x19a77b||_0x19a77b===_0x51bc12[_0x3dac2b]['context'])){_0x51bc12['splice'](_0x3dac2b,0x1);return;}}['validateEventType_'](_0x442e16){f(this['allowedEvents_']['find'](_0x5c3a52=>_0x5c3a52===_0x442e16),'Unknown\x20event:\x20'+_0x442e16);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x366c90){return f(_0x366c90==='online','Unknown\x20event\x20type:\x20'+_0x366c90),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x4b88e7,_0x3907ab){if(_0x3907ab===void 0x0){this['pieces_']=_0x4b88e7['split']('/');let _0x2f32ed=0x0;for(let _0x433a42=0x0;_0x433a42<this['pieces_']['length'];_0x433a42++)this['pieces_'][_0x433a42]['length']>0x0&&(this['pieces_'][_0x2f32ed]=this['pieces_'][_0x433a42],_0x2f32ed++);this['pieces_']['length']=_0x2f32ed,this['pieceNum_']=0x0;}else this['pieces_']=_0x4b88e7,this['pieceNum_']=_0x3907ab;}['toString'](){let _0x3decb3='';for(let _0x410290=this['pieceNum_'];_0x410290<this['pieces_']['length'];_0x410290++)this['pieces_'][_0x410290]!==''&&(_0x3decb3+='/'+this['pieces_'][_0x410290]);return _0x3decb3||'/';}}function w(){return new C('');}function y(_0x3fce3a){return _0x3fce3a['pieceNum_']>=_0x3fce3a['pieces_']['length']?null:_0x3fce3a['pieces_'][_0x3fce3a['pieceNum_']];}function we(_0x284255){return _0x284255['pieces_']['length']-_0x284255['pieceNum_'];}function b(_0x491c88){let _0x1ac384=_0x491c88['pieceNum_'];return _0x1ac384<_0x491c88['pieces_']['length']&&_0x1ac384++,new C(_0x491c88['pieces_'],_0x1ac384);}function zi(_0x4ea986){return _0x4ea986['pieceNum_']<_0x4ea986['pieces_']['length']?_0x4ea986['pieces_'][_0x4ea986['pieces_']['length']-0x1]:null;}function bh(_0x4f9d4a){let _0xaa7840='';for(let _0x1da54a=_0x4f9d4a['pieceNum_'];_0x1da54a<_0x4f9d4a['pieces_']['length'];_0x1da54a++)_0x4f9d4a['pieces_'][_0x1da54a]!==''&&(_0xaa7840+='/'+encodeURIComponent(String(_0x4f9d4a['pieces_'][_0x1da54a])));return _0xaa7840||'/';}function Pt(_0x2b0f8a,_0x5368ca=0x0){return _0x2b0f8a['pieces_']['slice'](_0x2b0f8a['pieceNum_']+_0x5368ca);}function Ro(_0x79e10e){if(_0x79e10e['pieceNum_']>=_0x79e10e['pieces_']['length'])return null;const _0x1d3bab=[];for(let _0x312d74=_0x79e10e['pieceNum_'];_0x312d74<_0x79e10e['pieces_']['length']-0x1;_0x312d74++)_0x1d3bab['push'](_0x79e10e['pieces_'][_0x312d74]);return new C(_0x1d3bab,0x0);}function k(_0x1a6710,_0x11d704){const _0x43423d=[];for(let _0x2dbd08=_0x1a6710['pieceNum_'];_0x2dbd08<_0x1a6710['pieces_']['length'];_0x2dbd08++)_0x43423d['push'](_0x1a6710['pieces_'][_0x2dbd08]);if(_0x11d704 instanceof C){for(let _0x2acc32=_0x11d704['pieceNum_'];_0x2acc32<_0x11d704['pieces_']['length'];_0x2acc32++)_0x43423d['push'](_0x11d704['pieces_'][_0x2acc32]);}else{const _0x5c937e=_0x11d704['split']('/');for(let _0x494f4b=0x0;_0x494f4b<_0x5c937e['length'];_0x494f4b++)_0x5c937e[_0x494f4b]['length']>0x0&&_0x43423d['push'](_0x5c937e[_0x494f4b]);}return new C(_0x43423d,0x0);}function v(_0xb1c278){return _0xb1c278['pieceNum_']>=_0xb1c278['pieces_']['length'];}function F(_0x2b69bf,_0x3fc906){const _0x49f9e4=y(_0x2b69bf),_0x41c9bf=y(_0x3fc906);if(_0x49f9e4===null)return _0x3fc906;if(_0x49f9e4===_0x41c9bf)return F(b(_0x2b69bf),b(_0x3fc906));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x3fc906+')\x20is\x20not\x20within\x20outerPath\x20('+_0x2b69bf+')');}function Rh(_0x524cfe,_0x5ad08a){const _0x370d0b=Pt(_0x524cfe,0x0),_0x41f426=Pt(_0x5ad08a,0x0);for(let _0x34283d=0x0;_0x34283d<_0x370d0b['length']&&_0x34283d<_0x41f426['length'];_0x34283d++){const _0x5d677b=He(_0x370d0b[_0x34283d],_0x41f426[_0x34283d]);if(_0x5d677b!==0x0)return _0x5d677b;}return _0x370d0b['length']===_0x41f426['length']?0x0:_0x370d0b['length']<_0x41f426['length']?-0x1:0x1;}function ji(_0x374488,_0x16155f){if(we(_0x374488)!==we(_0x16155f))return!0x1;for(let _0x51f381=_0x374488['pieceNum_'],_0x6d7ab9=_0x16155f['pieceNum_'];_0x51f381<=_0x374488['pieces_']['length'];_0x51f381++,_0x6d7ab9++)if(_0x374488['pieces_'][_0x51f381]!==_0x16155f['pieces_'][_0x6d7ab9])return!0x1;return!0x0;}function G(_0x5eaf85,_0x112686){let _0x350cd6=_0x5eaf85['pieceNum_'],_0x7e0c9=_0x112686['pieceNum_'];if(we(_0x5eaf85)>we(_0x112686))return!0x1;for(;_0x350cd6<_0x5eaf85['pieces_']['length'];){if(_0x5eaf85['pieces_'][_0x350cd6]!==_0x112686['pieces_'][_0x7e0c9])return!0x1;++_0x350cd6,++_0x7e0c9;}return!0x0;}class Ah{constructor(_0x2616b0,_0x40cf31){this['errorPrefix_']=_0x40cf31,this['parts_']=Pt(_0x2616b0,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x2a84c7=0x0;_0x2a84c7<this['parts_']['length'];_0x2a84c7++)this['byteLength_']+=On(this['parts_'][_0x2a84c7]);Ao(this);}}function kh(_0x16809a,_0x4739d4){_0x16809a['parts_']['length']>0x0&&(_0x16809a['byteLength_']+=0x1),_0x16809a['parts_']['push'](_0x4739d4),_0x16809a['byteLength_']+=On(_0x4739d4),Ao(_0x16809a);}function Nh(_0x555cf5){const _0x5b91b4=_0x555cf5['parts_']['pop']();_0x555cf5['byteLength_']-=On(_0x5b91b4),_0x555cf5['parts_']['length']>0x0&&(_0x555cf5['byteLength_']-=0x1);}function Ao(_0x42d126){if(_0x42d126['byteLength_']>er)throw new Error(_0x42d126['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x42d126['byteLength_']+').');if(_0x42d126['parts_']['length']>Zs)throw new Error(_0x42d126['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x42d126));}function Pe(_0x45fba1){return _0x45fba1['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x45fba1['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0xca6a7b,_0x91e181;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x91e181='visibilitychange',_0xca6a7b='hidden'):typeof document['mozHidden']<'u'?(_0x91e181='mozvisibilitychange',_0xca6a7b='mozHidden'):typeof document['msHidden']<'u'?(_0x91e181='msvisibilitychange',_0xca6a7b='msHidden'):typeof document['webkitHidden']<'u'&&(_0x91e181='webkitvisibilitychange',_0xca6a7b='webkitHidden')),this['visible_']=!0x0,_0x91e181&&document['addEventListener'](_0x91e181,()=>{const _0x5726b9=!document[_0xca6a7b];_0x5726b9!==this['visible_']&&(this['visible_']=_0x5726b9,this['trigger']('visible',_0x5726b9));},!0x1);}['getInitialEvent'](_0x58d6d0){return f(_0x58d6d0==='visible','Unknown\x20event\x20type:\x20'+_0x58d6d0),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x48d20f,_0x3bdec5,_0x55f258,_0x4bce0c,_0x558301,_0x23faea,_0x25ebfe,_0x18d054){if(super(),this['repoInfo_']=_0x48d20f,this['applicationId_']=_0x3bdec5,this['onDataUpdate_']=_0x55f258,this['onConnectStatus_']=_0x4bce0c,this['onServerInfoUpdate_']=_0x558301,this['authTokenProvider_']=_0x23faea,this['appCheckTokenProvider_']=_0x25ebfe,this['authOverride_']=_0x18d054,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x18d054)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x48d20f['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x499b5f,_0x102e7c,_0x13bcfd){const _0x57af60=++this['requestNumber_'],_0xbeb501={'r':_0x57af60,'a':_0x499b5f,'b':_0x102e7c};this['log_'](O(_0xbeb501)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0xbeb501),_0x13bcfd&&(this['requestCBHash_'][_0x57af60]=_0x13bcfd);}['get'](_0x18ab36){this['initConnection_']();const _0x1f0f45=new ot(),_0x34e2d4={'action':'g','request':{'p':_0x18ab36['_path']['toString'](),'q':_0x18ab36['_queryObject']},'onComplete':_0x57d1d1=>{const _0x482e37=_0x57d1d1['d'];_0x57d1d1['s']==='ok'?_0x1f0f45['resolve'](_0x482e37):_0x1f0f45['reject'](_0x482e37);}};this['outstandingGets_']['push'](_0x34e2d4),this['outstandingGetCount_']++;const _0x16644f=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x16644f),_0x1f0f45['promise'];}['listen'](_0x59afad,_0xfac705,_0x3a9070,_0x9c40ea){this['initConnection_']();const _0x45b86f=_0x59afad['_queryIdentifier'],_0x577daa=_0x59afad['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x577daa+'\x20'+_0x45b86f),this['listens']['has'](_0x577daa)||this['listens']['set'](_0x577daa,new Map()),f(_0x59afad['_queryParams']['isDefault']()||!_0x59afad['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x577daa)['has'](_0x45b86f),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x2c7998={'onComplete':_0x9c40ea,'hashFn':_0xfac705,'query':_0x59afad,'tag':_0x3a9070};this['listens']['get'](_0x577daa)['set'](_0x45b86f,_0x2c7998),this['connected_']&&this['sendListen_'](_0x2c7998);}['sendGet_'](_0x3679ef){const _0x1d69c8=this['outstandingGets_'][_0x3679ef];this['sendRequest']('g',_0x1d69c8['request'],_0x55032a=>{delete this['outstandingGets_'][_0x3679ef],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1d69c8['onComplete']&&_0x1d69c8['onComplete'](_0x55032a);});}['sendListen_'](_0x8283aa){const _0x53a4a0=_0x8283aa['query'],_0x5b64dd=_0x53a4a0['_path']['toString'](),_0x3f6c8b=_0x53a4a0['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x5b64dd+'\x20for\x20'+_0x3f6c8b);const _0x3e3c6c={'p':_0x5b64dd},_0x9db123='q';_0x8283aa['tag']&&(_0x3e3c6c['q']=_0x53a4a0['_queryObject'],_0x3e3c6c['t']=_0x8283aa['tag']),_0x3e3c6c['h']=_0x8283aa['hashFn'](),this['sendRequest'](_0x9db123,_0x3e3c6c,_0xa5cb3a=>{const _0x1fc4e9=_0xa5cb3a['d'],_0x483a95=_0xa5cb3a['s'];se['warnOnListenWarnings_'](_0x1fc4e9,_0x53a4a0),(this['listens']['get'](_0x5b64dd)&&this['listens']['get'](_0x5b64dd)['get'](_0x3f6c8b))===_0x8283aa&&(this['log_']('listen\x20response',_0xa5cb3a),_0x483a95!=='ok'&&this['removeListen_'](_0x5b64dd,_0x3f6c8b),_0x8283aa['onComplete']&&_0x8283aa['onComplete'](_0x483a95,_0x1fc4e9));});}static['warnOnListenWarnings_'](_0x1d9323,_0x1f0377){if(_0x1d9323&&typeof _0x1d9323=='object'&&J(_0x1d9323,'w')){const _0x36a9eb=De(_0x1d9323,'w');if(Array['isArray'](_0x36a9eb)&&~_0x36a9eb['indexOf']('no_index')){const _0x3938a8='\x22.indexOn\x22:\x20\x22'+_0x1f0377['_queryParams']['getIndex']()['toString']()+'\x22',_0x539cc0=_0x1f0377['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x3938a8+'\x20at\x20'+_0x539cc0+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x1e9bd1){this['authToken_']=_0x1e9bd1,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x1e9bd1);}['reduceReconnectDelayIfAdminCredential_'](_0x3fa00a){(_0x3fa00a&&_0x3fa00a['length']===0x28||wc(_0x3fa00a))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x39df94){this['appCheckToken_']=_0x39df94,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x2e0492=this['authToken_'],_0x3f3cdb=Ic(_0x2e0492)?'auth':'gauth',_0x39fcd3={'cred':_0x2e0492};this['authOverride_']===null?_0x39fcd3['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x39fcd3['authvar']=this['authOverride_']),this['sendRequest'](_0x3f3cdb,_0x39fcd3,_0x225d25=>{const _0x492616=_0x225d25['s'],_0x471b52=_0x225d25['d']||'error';this['authToken_']===_0x2e0492&&(_0x492616==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x492616,_0x471b52));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x525aa9=>{const _0x559a95=_0x525aa9['s'],_0x3122c8=_0x525aa9['d']||'error';_0x559a95==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x559a95,_0x3122c8);});}['unlisten'](_0x447c52,_0x5df2cc){const _0x1a46a6=_0x447c52['_path']['toString'](),_0x1145b8=_0x447c52['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x1a46a6+'\x20'+_0x1145b8),f(_0x447c52['_queryParams']['isDefault']()||!_0x447c52['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x1a46a6,_0x1145b8)&&this['connected_']&&this['sendUnlisten_'](_0x1a46a6,_0x1145b8,_0x447c52['_queryObject'],_0x5df2cc);}['sendUnlisten_'](_0x723bca,_0x43c8b9,_0x49c6ff,_0x2f8f7e){this['log_']('Unlisten\x20on\x20'+_0x723bca+'\x20for\x20'+_0x43c8b9);const _0x339048={'p':_0x723bca},_0xa02194='n';_0x2f8f7e&&(_0x339048['q']=_0x49c6ff,_0x339048['t']=_0x2f8f7e),this['sendRequest'](_0xa02194,_0x339048);}['onDisconnectPut'](_0x6106b5,_0x4b06c1,_0x4f68cb){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x6106b5,_0x4b06c1,_0x4f68cb):this['onDisconnectRequestQueue_']['push']({'pathString':_0x6106b5,'action':'o','data':_0x4b06c1,'onComplete':_0x4f68cb});}['onDisconnectMerge'](_0x3bf803,_0x4c0ae7,_0x4113af){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x3bf803,_0x4c0ae7,_0x4113af):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3bf803,'action':'om','data':_0x4c0ae7,'onComplete':_0x4113af});}['onDisconnectCancel'](_0x1d1b6b,_0x4c5220){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x1d1b6b,null,_0x4c5220):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1d1b6b,'action':'oc','data':null,'onComplete':_0x4c5220});}['sendOnDisconnect_'](_0x160b9e,_0x1d7a0d,_0x435f9e,_0x4b2910){const _0x9d9a5b={'p':_0x1d7a0d,'d':_0x435f9e};this['log_']('onDisconnect\x20'+_0x160b9e,_0x9d9a5b),this['sendRequest'](_0x160b9e,_0x9d9a5b,_0x24c61a=>{_0x4b2910&&setTimeout(()=>{_0x4b2910(_0x24c61a['s'],_0x24c61a['d']);},Math['floor'](0x0));});}['put'](_0x93c518,_0x503d2d,_0x57e1e1,_0x33bc82){this['putInternal']('p',_0x93c518,_0x503d2d,_0x57e1e1,_0x33bc82);}['merge'](_0x4a61e5,_0x3dba2e,_0x32815b,_0x54b2c1){this['putInternal']('m',_0x4a61e5,_0x3dba2e,_0x32815b,_0x54b2c1);}['putInternal'](_0x1d3b9d,_0x372d90,_0x1aebcc,_0x8e564c,_0x3eeab4){this['initConnection_']();const _0x11a15a={'p':_0x372d90,'d':_0x1aebcc};_0x3eeab4!==void 0x0&&(_0x11a15a['h']=_0x3eeab4),this['outstandingPuts_']['push']({'action':_0x1d3b9d,'request':_0x11a15a,'onComplete':_0x8e564c}),this['outstandingPutCount_']++;const _0x4c0e31=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x4c0e31):this['log_']('Buffering\x20put:\x20'+_0x372d90);}['sendPut_'](_0x21ad91){const _0x396d9b=this['outstandingPuts_'][_0x21ad91]['action'],_0x4911cc=this['outstandingPuts_'][_0x21ad91]['request'],_0x3c2635=this['outstandingPuts_'][_0x21ad91]['onComplete'];this['outstandingPuts_'][_0x21ad91]['queued']=this['connected_'],this['sendRequest'](_0x396d9b,_0x4911cc,_0x8daf28=>{this['log_'](_0x396d9b+'\x20response',_0x8daf28),delete this['outstandingPuts_'][_0x21ad91],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x3c2635&&_0x3c2635(_0x8daf28['s'],_0x8daf28['d']);});}['reportStats'](_0x4c2534){if(this['connected_']){const _0x3289fe={'c':_0x4c2534};this['log_']('reportStats',_0x3289fe),this['sendRequest']('s',_0x3289fe,_0x2c7947=>{if(_0x2c7947['s']!=='ok'){const _0xcd9a09=_0x2c7947['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0xcd9a09);}});}}['onDataMessage_'](_0x5ac834){if('r'in _0x5ac834){this['log_']('from\x20server:\x20'+O(_0x5ac834));const _0x5e2c41=_0x5ac834['r'],_0x533b3e=this['requestCBHash_'][_0x5e2c41];_0x533b3e&&(delete this['requestCBHash_'][_0x5e2c41],_0x533b3e(_0x5ac834['b']));}else{if('error'in _0x5ac834)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x5ac834['error'];'a'in _0x5ac834&&this['onDataPush_'](_0x5ac834['a'],_0x5ac834['b']);}}['onDataPush_'](_0x4236bc,_0x388022){this['log_']('handleServerMessage',_0x4236bc,_0x388022),_0x4236bc==='d'?this['onDataUpdate_'](_0x388022['p'],_0x388022['d'],!0x1,_0x388022['t']):_0x4236bc==='m'?this['onDataUpdate_'](_0x388022['p'],_0x388022['d'],!0x0,_0x388022['t']):_0x4236bc==='c'?this['onListenRevoked_'](_0x388022['p'],_0x388022['q']):_0x4236bc==='ac'?this['onAuthRevoked_'](_0x388022['s'],_0x388022['d']):_0x4236bc==='apc'?this['onAppCheckRevoked_'](_0x388022['s'],_0x388022['d']):_0x4236bc==='sd'?this['onSecurityDebugPacket_'](_0x388022):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x4236bc)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x4700e7,_0x22794e){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x4700e7),this['lastSessionId']=_0x22794e,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x1354c2){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x1354c2));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x2a015c){_0x2a015c&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x2a015c;}['onOnline_'](_0x547b53){_0x547b53?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0xbe3a55=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x4057c9=Math['max'](0x0,this['reconnectDelay_']-_0xbe3a55);_0x4057c9=Math['random']()*_0x4057c9,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x4057c9+'ms'),this['scheduleConnect_'](_0x4057c9),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0xa2ed1d=this['onDataMessage_']['bind'](this),_0x2c3cc6=this['onReady_']['bind'](this),_0x5b03c3=this['onRealtimeDisconnect_']['bind'](this),_0x22164e=this['id']+':'+se['nextConnectionId_']++,_0xad1b0=this['lastSessionId'];let _0x4a333f=!0x1,_0x12480a=null;const _0x4e768b=function(){_0x12480a?_0x12480a['close']():(_0x4a333f=!0x0,_0x5b03c3());},_0x565acc=function(_0x16d1e4){f(_0x12480a,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x12480a['sendRequest'](_0x16d1e4);};this['realtime_']={'close':_0x4e768b,'sendRequest':_0x565acc};const _0x54eef6=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x2f1ee4,_0x4388e6]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x54eef6),this['appCheckTokenProvider_']['getToken'](_0x54eef6)]);_0x4a333f?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x2f1ee4&&_0x2f1ee4['accessToken'],this['appCheckToken_']=_0x4388e6&&_0x4388e6['token'],_0x12480a=new Sh(_0x22164e,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0xa2ed1d,_0x2c3cc6,_0x5b03c3,_0x4f843c=>{U(_0x4f843c+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0xad1b0));}catch(_0x2a886e){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x2a886e),_0x4a333f||(this['repoInfo_']['nodeAdmin']&&U(_0x2a886e),_0x4e768b());}}}['interrupt'](_0x2d111c){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x2d111c),this['interruptReasons_'][_0x2d111c]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0xaea02e){L('Resuming\x20connection\x20for\x20reason:\x20'+_0xaea02e),delete this['interruptReasons_'][_0xaea02e],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x1b9bb4){const _0x456ab6=_0x1b9bb4-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x456ab6});}['cancelSentTransactions_'](){for(let _0xd15906=0x0;_0xd15906<this['outstandingPuts_']['length'];_0xd15906++){const _0x5654d2=this['outstandingPuts_'][_0xd15906];_0x5654d2&&'h'in _0x5654d2['request']&&_0x5654d2['queued']&&(_0x5654d2['onComplete']&&_0x5654d2['onComplete']('disconnect'),delete this['outstandingPuts_'][_0xd15906],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x3e2adb,_0x18eece){let _0x51841b;_0x18eece?_0x51841b=_0x18eece['map'](_0x11f60c=>Hi(_0x11f60c))['join']('$'):_0x51841b='default';const _0x4076f0=this['removeListen_'](_0x3e2adb,_0x51841b);_0x4076f0&&_0x4076f0['onComplete']&&_0x4076f0['onComplete']('permission_denied');}['removeListen_'](_0x23fbd,_0x16d3ef){const _0x1af02b=new C(_0x23fbd)['toString']();let _0x4d069e;if(this['listens']['has'](_0x1af02b)){const _0x3e4289=this['listens']['get'](_0x1af02b);_0x4d069e=_0x3e4289['get'](_0x16d3ef),_0x3e4289['delete'](_0x16d3ef),_0x3e4289['size']===0x0&&this['listens']['delete'](_0x1af02b);}else _0x4d069e=void 0x0;return _0x4d069e;}['onAuthRevoked_'](_0x45c60c,_0x14419d){L('Auth\x20token\x20revoked:\x20'+_0x45c60c+'/'+_0x14419d),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x45c60c==='invalid_token'||_0x45c60c==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x26db49,_0x19d471){L('App\x20check\x20token\x20revoked:\x20'+_0x26db49+'/'+_0x19d471),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x26db49==='invalid_token'||_0x26db49==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x2d6a62){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x2d6a62):'msg'in _0x2d6a62&&console['log']('FIREBASE:\x20'+_0x2d6a62['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x4ce1d3 of this['listens']['values']())for(const _0x31ee99 of _0x4ce1d3['values']())this['sendListen_'](_0x31ee99);for(let _0x161805=0x0;_0x161805<this['outstandingPuts_']['length'];_0x161805++)this['outstandingPuts_'][_0x161805]&&this['sendPut_'](_0x161805);for(;this['onDisconnectRequestQueue_']['length'];){const _0x4ccf6d=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x4ccf6d['action'],_0x4ccf6d['pathString'],_0x4ccf6d['data'],_0x4ccf6d['onComplete']);}for(let _0x431a0c=0x0;_0x431a0c<this['outstandingGets_']['length'];_0x431a0c++)this['outstandingGets_'][_0x431a0c]&&this['sendGet_'](_0x431a0c);}['sendConnectStats_'](){const _0x85bc80={};let _0xa3dc93='js';_0x85bc80['sdk.'+_0xa3dc93+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x85bc80['framework.cordova']=0x1:Yr()&&(_0x85bc80['framework.reactnative']=0x1),this['reportStats'](_0x85bc80);}['shouldReconnect_'](){const _0x5f1770=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x5f1770;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x4c585d,_0x31d0be){this['name']=_0x4c585d,this['node']=_0x31d0be;}static['Wrap'](_0x27ac36,_0x7eaede){return new E(_0x27ac36,_0x7eaede);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x56eedc,_0x3d5e24){const _0x1af0e7=new E(Fe,_0x56eedc),_0x21c997=new E(Fe,_0x3d5e24);return this['compare'](_0x1af0e7,_0x21c997)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x5102c5){Zt=_0x5102c5;}['compare'](_0x162da2,_0x4a7277){return He(_0x162da2['name'],_0x4a7277['name']);}['isDefinedOn'](_0x52fddb){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x1e3a6f,_0x3a643d){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x12ae09,_0x4c7666){return f(typeof _0x12ae09=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x12ae09,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x39d772,_0x24d394,_0x25e9d9,_0x5af07e,_0x1fb831=null){this['isReverse_']=_0x5af07e,this['resultGenerator_']=_0x1fb831,this['nodeStack_']=[];let _0xe7e34=0x1;for(;!_0x39d772['isEmpty']();)if(_0x39d772=_0x39d772,_0xe7e34=_0x24d394?_0x25e9d9(_0x39d772['key'],_0x24d394):0x1,_0x5af07e&&(_0xe7e34*=-0x1),_0xe7e34<0x0)this['isReverse_']?_0x39d772=_0x39d772['left']:_0x39d772=_0x39d772['right'];else{if(_0xe7e34===0x0){this['nodeStack_']['push'](_0x39d772);break;}else this['nodeStack_']['push'](_0x39d772),this['isReverse_']?_0x39d772=_0x39d772['right']:_0x39d772=_0x39d772['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x4cfdc1=this['nodeStack_']['pop'](),_0x2dc45e;if(this['resultGenerator_']?_0x2dc45e=this['resultGenerator_'](_0x4cfdc1['key'],_0x4cfdc1['value']):_0x2dc45e={'key':_0x4cfdc1['key'],'value':_0x4cfdc1['value']},this['isReverse_']){for(_0x4cfdc1=_0x4cfdc1['left'];!_0x4cfdc1['isEmpty']();)this['nodeStack_']['push'](_0x4cfdc1),_0x4cfdc1=_0x4cfdc1['right'];}else{for(_0x4cfdc1=_0x4cfdc1['right'];!_0x4cfdc1['isEmpty']();)this['nodeStack_']['push'](_0x4cfdc1),_0x4cfdc1=_0x4cfdc1['left'];}return _0x2dc45e;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x33ecb9=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x33ecb9['key'],_0x33ecb9['value']):{'key':_0x33ecb9['key'],'value':_0x33ecb9['value']};}}class M{constructor(_0x2c2f8c,_0x5d7fc,_0x6628b,_0x5ba1ac,_0x3193d6){this['key']=_0x2c2f8c,this['value']=_0x5d7fc,this['color']=_0x6628b??M['RED'],this['left']=_0x5ba1ac??B['EMPTY_NODE'],this['right']=_0x3193d6??B['EMPTY_NODE'];}['copy'](_0x52be5d,_0x59ae8d,_0x56b79b,_0x3bbcd1,_0xffe7a4){return new M(_0x52be5d??this['key'],_0x59ae8d??this['value'],_0x56b79b??this['color'],_0x3bbcd1??this['left'],_0xffe7a4??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x4b46aa){return this['left']['inorderTraversal'](_0x4b46aa)||!!_0x4b46aa(this['key'],this['value'])||this['right']['inorderTraversal'](_0x4b46aa);}['reverseTraversal'](_0xb339f4){return this['right']['reverseTraversal'](_0xb339f4)||_0xb339f4(this['key'],this['value'])||this['left']['reverseTraversal'](_0xb339f4);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x5eb757,_0x5f35f8,_0x2609c5){let _0x38deae=this;const _0x3ca4d9=_0x2609c5(_0x5eb757,_0x38deae['key']);return _0x3ca4d9<0x0?_0x38deae=_0x38deae['copy'](null,null,null,_0x38deae['left']['insert'](_0x5eb757,_0x5f35f8,_0x2609c5),null):_0x3ca4d9===0x0?_0x38deae=_0x38deae['copy'](null,_0x5f35f8,null,null,null):_0x38deae=_0x38deae['copy'](null,null,null,null,_0x38deae['right']['insert'](_0x5eb757,_0x5f35f8,_0x2609c5)),_0x38deae['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x38807a=this;return!_0x38807a['left']['isRed_']()&&!_0x38807a['left']['left']['isRed_']()&&(_0x38807a=_0x38807a['moveRedLeft_']()),_0x38807a=_0x38807a['copy'](null,null,null,_0x38807a['left']['removeMin_'](),null),_0x38807a['fixUp_']();}['remove'](_0x192450,_0x19f188){let _0x45d533,_0xde0180;if(_0x45d533=this,_0x19f188(_0x192450,_0x45d533['key'])<0x0)!_0x45d533['left']['isEmpty']()&&!_0x45d533['left']['isRed_']()&&!_0x45d533['left']['left']['isRed_']()&&(_0x45d533=_0x45d533['moveRedLeft_']()),_0x45d533=_0x45d533['copy'](null,null,null,_0x45d533['left']['remove'](_0x192450,_0x19f188),null);else{if(_0x45d533['left']['isRed_']()&&(_0x45d533=_0x45d533['rotateRight_']()),!_0x45d533['right']['isEmpty']()&&!_0x45d533['right']['isRed_']()&&!_0x45d533['right']['left']['isRed_']()&&(_0x45d533=_0x45d533['moveRedRight_']()),_0x19f188(_0x192450,_0x45d533['key'])===0x0){if(_0x45d533['right']['isEmpty']())return B['EMPTY_NODE'];_0xde0180=_0x45d533['right']['min_'](),_0x45d533=_0x45d533['copy'](_0xde0180['key'],_0xde0180['value'],null,null,_0x45d533['right']['removeMin_']());}_0x45d533=_0x45d533['copy'](null,null,null,null,_0x45d533['right']['remove'](_0x192450,_0x19f188));}return _0x45d533['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x16f3c1=this;return _0x16f3c1['right']['isRed_']()&&!_0x16f3c1['left']['isRed_']()&&(_0x16f3c1=_0x16f3c1['rotateLeft_']()),_0x16f3c1['left']['isRed_']()&&_0x16f3c1['left']['left']['isRed_']()&&(_0x16f3c1=_0x16f3c1['rotateRight_']()),_0x16f3c1['left']['isRed_']()&&_0x16f3c1['right']['isRed_']()&&(_0x16f3c1=_0x16f3c1['colorFlip_']()),_0x16f3c1;}['moveRedLeft_'](){let _0x4c557c=this['colorFlip_']();return _0x4c557c['right']['left']['isRed_']()&&(_0x4c557c=_0x4c557c['copy'](null,null,null,null,_0x4c557c['right']['rotateRight_']()),_0x4c557c=_0x4c557c['rotateLeft_'](),_0x4c557c=_0x4c557c['colorFlip_']()),_0x4c557c;}['moveRedRight_'](){let _0x57dc77=this['colorFlip_']();return _0x57dc77['left']['left']['isRed_']()&&(_0x57dc77=_0x57dc77['rotateRight_'](),_0x57dc77=_0x57dc77['colorFlip_']()),_0x57dc77;}['rotateLeft_'](){const _0x37c7e1=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x37c7e1,null);}['rotateRight_'](){const _0xbfcd42=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0xbfcd42);}['colorFlip_'](){const _0x2ac59e=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x23b8e5=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x2ac59e,_0x23b8e5);}['checkMaxDepth_'](){const _0x383b93=this['check_']();return Math['pow'](0x2,_0x383b93)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x116239=this['left']['check_']();if(_0x116239!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x116239+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x424c2c,_0x3ed95d,_0x3047e0,_0x30949a,_0x206d28){return this;}['insert'](_0x46f82d,_0x2638a9,_0xbaadd6){return new M(_0x46f82d,_0x2638a9,null);}['remove'](_0xcf54f5,_0x1b194d){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x13fe56){return!0x1;}['reverseTraversal'](_0x3ea7bb){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x5b67ed,_0x333733=B['EMPTY_NODE']){this['comparator_']=_0x5b67ed,this['root_']=_0x333733;}['insert'](_0x357881,_0x123c4d){return new B(this['comparator_'],this['root_']['insert'](_0x357881,_0x123c4d,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x2f5050){return new B(this['comparator_'],this['root_']['remove'](_0x2f5050,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x422296){let _0x1d39b7,_0x2ab159=this['root_'];for(;!_0x2ab159['isEmpty']();){if(_0x1d39b7=this['comparator_'](_0x422296,_0x2ab159['key']),_0x1d39b7===0x0)return _0x2ab159['value'];_0x1d39b7<0x0?_0x2ab159=_0x2ab159['left']:_0x1d39b7>0x0&&(_0x2ab159=_0x2ab159['right']);}return null;}['getPredecessorKey'](_0x15b328){let _0x5c4fe6,_0x4aa37a=this['root_'],_0x47166e=null;for(;!_0x4aa37a['isEmpty']();)if(_0x5c4fe6=this['comparator_'](_0x15b328,_0x4aa37a['key']),_0x5c4fe6===0x0){if(_0x4aa37a['left']['isEmpty']())return _0x47166e?_0x47166e['key']:null;for(_0x4aa37a=_0x4aa37a['left'];!_0x4aa37a['right']['isEmpty']();)_0x4aa37a=_0x4aa37a['right'];return _0x4aa37a['key'];}else _0x5c4fe6<0x0?_0x4aa37a=_0x4aa37a['left']:_0x5c4fe6>0x0&&(_0x47166e=_0x4aa37a,_0x4aa37a=_0x4aa37a['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x4b5ba6){return this['root_']['inorderTraversal'](_0x4b5ba6);}['reverseTraversal'](_0x543084){return this['root_']['reverseTraversal'](_0x543084);}['getIterator'](_0x1fde12){return new en(this['root_'],null,this['comparator_'],!0x1,_0x1fde12);}['getIteratorFrom'](_0x45c0db,_0x4fb33d){return new en(this['root_'],_0x45c0db,this['comparator_'],!0x1,_0x4fb33d);}['getReverseIteratorFrom'](_0x4d5d4f,_0x1f90cb){return new en(this['root_'],_0x4d5d4f,this['comparator_'],!0x0,_0x1f90cb);}['getReverseIterator'](_0x309cee){return new en(this['root_'],null,this['comparator_'],!0x0,_0x309cee);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x5b237c,_0x191cd1){return He(_0x5b237c['name'],_0x191cd1['name']);}function Yi(_0x31be2a,_0x4bcb8f){return He(_0x31be2a,_0x4bcb8f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x1636ca){Ei=_0x1636ca;}const No=function(_0x1aa232){return typeof _0x1aa232=='number'?'number:'+ao(_0x1aa232):'string:'+_0x1aa232;},Po=function(_0x584e74){if(_0x584e74['isLeafNode']()){const _0x18e8ac=_0x584e74['val']();f(typeof _0x18e8ac=='string'||typeof _0x18e8ac=='number'||typeof _0x18e8ac=='object'&&J(_0x18e8ac,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x584e74===Ei||_0x584e74['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x584e74===Ei||_0x584e74['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x2e4419){ir=_0x2e4419;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x37b354,_0x2fd726=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x37b354,this['priorityNode_']=_0x2fd726,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1ff879){return new D(this['value_'],_0x1ff879);}['getImmediateChild'](_0x3fe707){return _0x3fe707==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x246445){return v(_0x246445)?this:y(_0x246445)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x2a0c69,_0x14cc04){return null;}['updateImmediateChild'](_0x370bda,_0x2e0a40){return _0x370bda==='.priority'?this['updatePriority'](_0x2e0a40):_0x2e0a40['isEmpty']()&&_0x370bda!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x370bda,_0x2e0a40)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x3e955d,_0x3f3189){const _0xa787a1=y(_0x3e955d);return _0xa787a1===null?_0x3f3189:_0x3f3189['isEmpty']()&&_0xa787a1!=='.priority'?this:(f(_0xa787a1!=='.priority'||we(_0x3e955d)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0xa787a1,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x3e955d),_0x3f3189)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x45280f,_0x54a78e){return!0x1;}['val'](_0x284bd6){return _0x284bd6&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0xf57d3d='';this['priorityNode_']['isEmpty']()||(_0xf57d3d+='priority:'+No(this['priorityNode_']['val']())+':');const _0x22c215=typeof this['value_'];_0xf57d3d+=_0x22c215+':',_0x22c215==='number'?_0xf57d3d+=ao(this['value_']):_0xf57d3d+=this['value_'],this['lazyHash_']=ro(_0xf57d3d);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x58a73f){return _0x58a73f===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x58a73f instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x58a73f['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x58a73f));}['compareToLeafNode_'](_0x2738e8){const _0x5bfdb1=typeof _0x2738e8['value_'],_0x3584a0=typeof this['value_'],_0x401fd5=D['VALUE_TYPE_ORDER']['indexOf'](_0x5bfdb1),_0x78a1f2=D['VALUE_TYPE_ORDER']['indexOf'](_0x3584a0);return f(_0x401fd5>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5bfdb1),f(_0x78a1f2>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x3584a0),_0x401fd5===_0x78a1f2?_0x3584a0==='object'?0x0:this['value_']<_0x2738e8['value_']?-0x1:this['value_']===_0x2738e8['value_']?0x0:0x1:_0x78a1f2-_0x401fd5;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x1ec7dd){if(_0x1ec7dd===this)return!0x0;if(_0x1ec7dd['isLeafNode']()){const _0x163a02=_0x1ec7dd;return this['value_']===_0x163a02['value_']&&this['priorityNode_']['equals'](_0x163a02['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x55485d){Oo=_0x55485d;}function Wh(_0x1e2e3b){Do=_0x1e2e3b;}class Bh extends Dn{['compare'](_0x5f3462,_0x14242e){const _0x28d834=_0x5f3462['node']['getPriority'](),_0x158fc1=_0x14242e['node']['getPriority'](),_0x2dbe6e=_0x28d834['compareTo'](_0x158fc1);return _0x2dbe6e===0x0?He(_0x5f3462['name'],_0x14242e['name']):_0x2dbe6e;}['isDefinedOn'](_0x5099ba){return!_0x5099ba['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x97c8ea,_0x32dd74){return!_0x97c8ea['getPriority']()['equals'](_0x32dd74['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x4059d5,_0xe27d6b){const _0x5e52af=Oo(_0x4059d5);return new E(_0xe27d6b,new D('[PRIORITY-POST]',_0x5e52af));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x14a0a3){const _0x16cc16=_0x393473=>parseInt(Math['log'](_0x393473)/Vh,0xa),_0x586d2c=_0x322338=>parseInt(Array(_0x322338+0x1)['join']('1'),0x2);this['count']=_0x16cc16(_0x14a0a3+0x1),this['current_']=this['count']-0x1;const _0x2499ae=_0x586d2c(this['count']);this['bits_']=_0x14a0a3+0x1&_0x2499ae;}['nextBitIsOne'](){const _0x482d2c=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x482d2c;}}const fn=function(_0x1e481d,_0x552d18,_0x234157,_0x140827){_0x1e481d['sort'](_0x552d18);const _0x343580=function(_0x12b0d5,_0x350d42){const _0x58f020=_0x350d42-_0x12b0d5;let _0x2d5cbb,_0x402388;if(_0x58f020===0x0)return null;if(_0x58f020===0x1)return _0x2d5cbb=_0x1e481d[_0x12b0d5],_0x402388=_0x234157?_0x234157(_0x2d5cbb):_0x2d5cbb,new M(_0x402388,_0x2d5cbb['node'],M['BLACK'],null,null);{const _0x4034ea=parseInt(_0x58f020/0x2,0xa)+_0x12b0d5,_0x5d869a=_0x343580(_0x12b0d5,_0x4034ea),_0x3dc60a=_0x343580(_0x4034ea+0x1,_0x350d42);return _0x2d5cbb=_0x1e481d[_0x4034ea],_0x402388=_0x234157?_0x234157(_0x2d5cbb):_0x2d5cbb,new M(_0x402388,_0x2d5cbb['node'],M['BLACK'],_0x5d869a,_0x3dc60a);}},_0x563a47=function(_0xb1f309){let _0xad851e=null,_0x4ec74d=null,_0x111ba2=_0x1e481d['length'];const _0x30ed2b=function(_0x24079c,_0x48c365){const _0x28885f=_0x111ba2-_0x24079c,_0x186067=_0x111ba2;_0x111ba2-=_0x24079c;const _0x1d6a07=_0x343580(_0x28885f+0x1,_0x186067),_0x308a4b=_0x1e481d[_0x28885f],_0x3abf51=_0x234157?_0x234157(_0x308a4b):_0x308a4b;_0x2467d9(new M(_0x3abf51,_0x308a4b['node'],_0x48c365,null,_0x1d6a07));},_0x2467d9=function(_0x37e27b){_0xad851e?(_0xad851e['left']=_0x37e27b,_0xad851e=_0x37e27b):(_0x4ec74d=_0x37e27b,_0xad851e=_0x37e27b);};for(let _0x1bd2f6=0x0;_0x1bd2f6<_0xb1f309['count'];++_0x1bd2f6){const _0x9bc1b8=_0xb1f309['nextBitIsOne'](),_0x2d1212=Math['pow'](0x2,_0xb1f309['count']-(_0x1bd2f6+0x1));_0x9bc1b8?_0x30ed2b(_0x2d1212,M['BLACK']):(_0x30ed2b(_0x2d1212,M['BLACK']),_0x30ed2b(_0x2d1212,M['RED']));}return _0x4ec74d;},_0x1d7c0c=new Hh(_0x1e481d['length']),_0x99655d=_0x563a47(_0x1d7c0c);return new B(_0x140827||_0x552d18,_0x99655d);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x59dddd,_0x43296c){this['indexes_']=_0x59dddd,this['indexSet_']=_0x43296c;}['get'](_0x1cc2d1){const _0x2ef887=De(this['indexes_'],_0x1cc2d1);if(!_0x2ef887)throw new Error('No\x20index\x20defined\x20for\x20'+_0x1cc2d1);return _0x2ef887 instanceof B?_0x2ef887:null;}['hasIndex'](_0x2b25b7){return J(this['indexSet_'],_0x2b25b7['toString']());}['addIndex'](_0x5941b3,_0x2371bc){f(_0x5941b3!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x471df7=[];let _0x2ee0c7=!0x1;const _0x542765=_0x2371bc['getIterator'](E['Wrap']);let _0x5d77ae=_0x542765['getNext']();for(;_0x5d77ae;)_0x2ee0c7=_0x2ee0c7||_0x5941b3['isDefinedOn'](_0x5d77ae['node']),_0x471df7['push'](_0x5d77ae),_0x5d77ae=_0x542765['getNext']();let _0x31d397;_0x2ee0c7?_0x31d397=fn(_0x471df7,_0x5941b3['getCompare']()):_0x31d397=ze;const _0x295abe=_0x5941b3['toString'](),_0x28db1e={...this['indexSet_']};_0x28db1e[_0x295abe]=_0x5941b3;const _0x16a805={...this['indexes_']};return _0x16a805[_0x295abe]=_0x31d397,new te(_0x16a805,_0x28db1e);}['addToIndexes'](_0x4960a8,_0x4e1626){const _0xe0f4f=hn(this['indexes_'],(_0xdf73bf,_0x2e3a27)=>{const _0x5cf3db=De(this['indexSet_'],_0x2e3a27);if(f(_0x5cf3db,'Missing\x20index\x20implementation\x20for\x20'+_0x2e3a27),_0xdf73bf===ze){if(_0x5cf3db['isDefinedOn'](_0x4960a8['node'])){const _0x391c43=[],_0x11cf91=_0x4e1626['getIterator'](E['Wrap']);let _0x283be2=_0x11cf91['getNext']();for(;_0x283be2;)_0x283be2['name']!==_0x4960a8['name']&&_0x391c43['push'](_0x283be2),_0x283be2=_0x11cf91['getNext']();return _0x391c43['push'](_0x4960a8),fn(_0x391c43,_0x5cf3db['getCompare']());}else return ze;}else{const _0x516647=_0x4e1626['get'](_0x4960a8['name']);let _0x173315=_0xdf73bf;return _0x516647&&(_0x173315=_0x173315['remove'](new E(_0x4960a8['name'],_0x516647))),_0x173315['insert'](_0x4960a8,_0x4960a8['node']);}});return new te(_0xe0f4f,this['indexSet_']);}['removeFromIndexes'](_0x17d6a2,_0x111ba4){const _0x198b57=hn(this['indexes_'],_0x48c2fc=>{if(_0x48c2fc===ze)return _0x48c2fc;{const _0x90baf6=_0x111ba4['get'](_0x17d6a2['name']);return _0x90baf6?_0x48c2fc['remove'](new E(_0x17d6a2['name'],_0x90baf6)):_0x48c2fc;}});return new te(_0x198b57,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x254e06,_0x45aeb5,_0xdf7eed){this['children_']=_0x254e06,this['priorityNode_']=_0x45aeb5,this['indexMap_']=_0xdf7eed,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x140f5d){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x140f5d,this['indexMap_']);}['getImmediateChild'](_0x4dcb0f){if(_0x4dcb0f==='.priority')return this['getPriority']();{const _0x300262=this['children_']['get'](_0x4dcb0f);return _0x300262===null?mt:_0x300262;}}['getChild'](_0x40b008){const _0x587a5f=y(_0x40b008);return _0x587a5f===null?this:this['getImmediateChild'](_0x587a5f)['getChild'](b(_0x40b008));}['hasChild'](_0x578ae6){return this['children_']['get'](_0x578ae6)!==null;}['updateImmediateChild'](_0x1961af,_0x575c10){if(f(_0x575c10,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x1961af==='.priority')return this['updatePriority'](_0x575c10);{const _0x29239b=new E(_0x1961af,_0x575c10);let _0x55a519,_0x383094;_0x575c10['isEmpty']()?(_0x55a519=this['children_']['remove'](_0x1961af),_0x383094=this['indexMap_']['removeFromIndexes'](_0x29239b,this['children_'])):(_0x55a519=this['children_']['insert'](_0x1961af,_0x575c10),_0x383094=this['indexMap_']['addToIndexes'](_0x29239b,this['children_']));const _0xc300ec=_0x55a519['isEmpty']()?mt:this['priorityNode_'];return new g(_0x55a519,_0xc300ec,_0x383094);}}['updateChild'](_0x1febae,_0x455589){const _0x1f4de3=y(_0x1febae);if(_0x1f4de3===null)return _0x455589;{f(y(_0x1febae)!=='.priority'||we(_0x1febae)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x1fdf1d=this['getImmediateChild'](_0x1f4de3)['updateChild'](b(_0x1febae),_0x455589);return this['updateImmediateChild'](_0x1f4de3,_0x1fdf1d);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x296a1b){if(this['isEmpty']())return null;const _0x4d6811={};let _0x5ed119=0x0,_0x2f2d9d=0x0,_0x38d19c=!0x0;if(this['forEachChild'](R,(_0x3b788f,_0x42b6ab)=>{_0x4d6811[_0x3b788f]=_0x42b6ab['val'](_0x296a1b),_0x5ed119++,_0x38d19c&&g['INTEGER_REGEXP_']['test'](_0x3b788f)?_0x2f2d9d=Math['max'](_0x2f2d9d,Number(_0x3b788f)):_0x38d19c=!0x1;}),!_0x296a1b&&_0x38d19c&&_0x2f2d9d<0x2*_0x5ed119){const _0x475256=[];for(const _0x4668a0 in _0x4d6811)_0x475256[_0x4668a0]=_0x4d6811[_0x4668a0];return _0x475256;}else return _0x296a1b&&!this['getPriority']()['isEmpty']()&&(_0x4d6811['.priority']=this['getPriority']()['val']()),_0x4d6811;}['hash'](){if(this['lazyHash_']===null){let _0x2debb8='';this['getPriority']()['isEmpty']()||(_0x2debb8+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x53867b,_0x342012)=>{const _0x10c9a5=_0x342012['hash']();_0x10c9a5!==''&&(_0x2debb8+=':'+_0x53867b+':'+_0x10c9a5);}),this['lazyHash_']=_0x2debb8===''?'':ro(_0x2debb8);}return this['lazyHash_'];}['getPredecessorChildName'](_0x13ea71,_0x1b04df,_0x3ab6e1){const _0x519723=this['resolveIndex_'](_0x3ab6e1);if(_0x519723){const _0x337a4c=_0x519723['getPredecessorKey'](new E(_0x13ea71,_0x1b04df));return _0x337a4c?_0x337a4c['name']:null;}else return this['children_']['getPredecessorKey'](_0x13ea71);}['getFirstChildName'](_0x36e333){const _0xd47397=this['resolveIndex_'](_0x36e333);if(_0xd47397){const _0x5b62bf=_0xd47397['minKey']();return _0x5b62bf&&_0x5b62bf['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x151309){const _0x3cb484=this['getFirstChildName'](_0x151309);return _0x3cb484?new E(_0x3cb484,this['children_']['get'](_0x3cb484)):null;}['getLastChildName'](_0x57d8d7){const _0x1efc5a=this['resolveIndex_'](_0x57d8d7);if(_0x1efc5a){const _0x17c423=_0x1efc5a['maxKey']();return _0x17c423&&_0x17c423['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x35d1bd){const _0x566e78=this['getLastChildName'](_0x35d1bd);return _0x566e78?new E(_0x566e78,this['children_']['get'](_0x566e78)):null;}['forEachChild'](_0xd14291,_0x2684da){const _0x130b2c=this['resolveIndex_'](_0xd14291);return _0x130b2c?_0x130b2c['inorderTraversal'](_0x19afe0=>_0x2684da(_0x19afe0['name'],_0x19afe0['node'])):this['children_']['inorderTraversal'](_0x2684da);}['getIterator'](_0x21a7e5){return this['getIteratorFrom'](_0x21a7e5['minPost'](),_0x21a7e5);}['getIteratorFrom'](_0x394873,_0x21a91d){const _0x2eaf27=this['resolveIndex_'](_0x21a91d);if(_0x2eaf27)return _0x2eaf27['getIteratorFrom'](_0x394873,_0x53262c=>_0x53262c);{const _0x545459=this['children_']['getIteratorFrom'](_0x394873['name'],E['Wrap']);let _0xa1b0d2=_0x545459['peek']();for(;_0xa1b0d2!=null&&_0x21a91d['compare'](_0xa1b0d2,_0x394873)<0x0;)_0x545459['getNext'](),_0xa1b0d2=_0x545459['peek']();return _0x545459;}}['getReverseIterator'](_0x2ce361){return this['getReverseIteratorFrom'](_0x2ce361['maxPost'](),_0x2ce361);}['getReverseIteratorFrom'](_0x19d5e0,_0x21b98f){const _0x47ff12=this['resolveIndex_'](_0x21b98f);if(_0x47ff12)return _0x47ff12['getReverseIteratorFrom'](_0x19d5e0,_0x1e5080=>_0x1e5080);{const _0x4c83e4=this['children_']['getReverseIteratorFrom'](_0x19d5e0['name'],E['Wrap']);let _0x20e085=_0x4c83e4['peek']();for(;_0x20e085!=null&&_0x21b98f['compare'](_0x20e085,_0x19d5e0)>0x0;)_0x4c83e4['getNext'](),_0x20e085=_0x4c83e4['peek']();return _0x4c83e4;}}['compareTo'](_0x266771){return this['isEmpty']()?_0x266771['isEmpty']()?0x0:-0x1:_0x266771['isLeafNode']()||_0x266771['isEmpty']()?0x1:_0x266771===$t?-0x1:0x0;}['withIndex'](_0x384732){if(_0x384732===ye||this['indexMap_']['hasIndex'](_0x384732))return this;{const _0x3d2a3d=this['indexMap_']['addIndex'](_0x384732,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x3d2a3d);}}['isIndexed'](_0x4b9dfe){return _0x4b9dfe===ye||this['indexMap_']['hasIndex'](_0x4b9dfe);}['equals'](_0x12b824){if(_0x12b824===this)return!0x0;if(_0x12b824['isLeafNode']())return!0x1;{const _0x46b71f=_0x12b824;if(this['getPriority']()['equals'](_0x46b71f['getPriority']())){if(this['children_']['count']()===_0x46b71f['children_']['count']()){const _0x5abbae=this['getIterator'](R),_0x32b510=_0x46b71f['getIterator'](R);let _0x4f3ba6=_0x5abbae['getNext'](),_0xcdb6a5=_0x32b510['getNext']();for(;_0x4f3ba6&&_0xcdb6a5;){if(_0x4f3ba6['name']!==_0xcdb6a5['name']||!_0x4f3ba6['node']['equals'](_0xcdb6a5['node']))return!0x1;_0x4f3ba6=_0x5abbae['getNext'](),_0xcdb6a5=_0x32b510['getNext']();}return _0x4f3ba6===null&&_0xcdb6a5===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0xc64460){return _0xc64460===ye?null:this['indexMap_']['get'](_0xc64460['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x17ebf6){return _0x17ebf6===this?0x0:0x1;}['equals'](_0x381436){return _0x381436===this;}['getPriority'](){return this;}['getImmediateChild'](_0x20190b){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x3cff89,_0x23c208=null){if(_0x3cff89===null)return g['EMPTY_NODE'];if(typeof _0x3cff89=='object'&&'.priority'in _0x3cff89&&(_0x23c208=_0x3cff89['.priority']),f(_0x23c208===null||typeof _0x23c208=='string'||typeof _0x23c208=='number'||typeof _0x23c208=='object'&&'.sv'in _0x23c208,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x23c208),typeof _0x3cff89=='object'&&'.value'in _0x3cff89&&_0x3cff89['.value']!==null&&(_0x3cff89=_0x3cff89['.value']),typeof _0x3cff89!='object'||'.sv'in _0x3cff89){const _0x142ee3=_0x3cff89;return new D(_0x142ee3,P(_0x23c208));}if(!(_0x3cff89 instanceof Array)&&Gh){const _0x1b56c2=[];let _0x40c362=!0x1;if(x(_0x3cff89,(_0x1609aa,_0xfdb651)=>{if(_0x1609aa['substring'](0x0,0x1)!=='.'){const _0x1765bd=P(_0xfdb651);_0x1765bd['isEmpty']()||(_0x40c362=_0x40c362||!_0x1765bd['getPriority']()['isEmpty'](),_0x1b56c2['push'](new E(_0x1609aa,_0x1765bd)));}}),_0x1b56c2['length']===0x0)return g['EMPTY_NODE'];const _0x4d1c2e=fn(_0x1b56c2,xh,_0x2db35f=>_0x2db35f['name'],Yi);if(_0x40c362){const _0x4b30f7=fn(_0x1b56c2,R['getCompare']());return new g(_0x4d1c2e,P(_0x23c208),new te({'.priority':_0x4b30f7},{'.priority':R}));}else return new g(_0x4d1c2e,P(_0x23c208),te['Default']);}else{let _0x4063b3=g['EMPTY_NODE'];return x(_0x3cff89,(_0x256fae,_0x5e335a)=>{if(J(_0x3cff89,_0x256fae)&&_0x256fae['substring'](0x0,0x1)!=='.'){const _0x4d6a75=P(_0x5e335a);(_0x4d6a75['isLeafNode']()||!_0x4d6a75['isEmpty']())&&(_0x4063b3=_0x4063b3['updateImmediateChild'](_0x256fae,_0x4d6a75));}}),_0x4063b3['updatePriority'](P(_0x23c208));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x1d7304){super(),this['indexPath_']=_0x1d7304,f(!v(_0x1d7304)&&y(_0x1d7304)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x567a26){return _0x567a26['getChild'](this['indexPath_']);}['isDefinedOn'](_0x13387e){return!_0x13387e['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0xf563d3,_0x1bbef7){const _0x327c06=this['extractChild'](_0xf563d3['node']),_0x3df11a=this['extractChild'](_0x1bbef7['node']),_0x33ed7a=_0x327c06['compareTo'](_0x3df11a);return _0x33ed7a===0x0?He(_0xf563d3['name'],_0x1bbef7['name']):_0x33ed7a;}['makePost'](_0x424403,_0x5cb080){const _0x9a0896=P(_0x424403),_0x38be79=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x9a0896);return new E(_0x5cb080,_0x38be79);}['maxPost'](){const _0x513299=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x513299);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x5fa089,_0x14b500){const _0x1ff66b=_0x5fa089['node']['compareTo'](_0x14b500['node']);return _0x1ff66b===0x0?He(_0x5fa089['name'],_0x14b500['name']):_0x1ff66b;}['isDefinedOn'](_0x2d239e){return!0x0;}['indexedValueChanged'](_0x212075,_0xb0601e){return!_0x212075['equals'](_0xb0601e);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x37f124,_0x16b13a){const _0x37fb95=P(_0x37f124);return new E(_0x16b13a,_0x37fb95);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x4470a1){return{'type':'value','snapshotNode':_0x4470a1};}function et(_0x13e331,_0x52702b){return{'type':'child_added','snapshotNode':_0x52702b,'childName':_0x13e331};}function Ot(_0x4a9683,_0xef10c2){return{'type':'child_removed','snapshotNode':_0xef10c2,'childName':_0x4a9683};}function Dt(_0x3ab7d9,_0x212646,_0x53a96e){return{'type':'child_changed','snapshotNode':_0x212646,'childName':_0x3ab7d9,'oldSnap':_0x53a96e};}function zh(_0x2a79ff,_0x1c5fa8){return{'type':'child_moved','snapshotNode':_0x1c5fa8,'childName':_0x2a79ff};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x233577){this['index_']=_0x233577;}['updateChild'](_0x478ed9,_0x5954f4,_0x259165,_0x12509b,_0x4a26c3,_0x4ab68c){f(_0x478ed9['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x20474f=_0x478ed9['getImmediateChild'](_0x5954f4);return _0x20474f['getChild'](_0x12509b)['equals'](_0x259165['getChild'](_0x12509b))&&_0x20474f['isEmpty']()===_0x259165['isEmpty']()||(_0x4ab68c!=null&&(_0x259165['isEmpty']()?_0x478ed9['hasChild'](_0x5954f4)?_0x4ab68c['trackChildChange'](Ot(_0x5954f4,_0x20474f)):f(_0x478ed9['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x20474f['isEmpty']()?_0x4ab68c['trackChildChange'](et(_0x5954f4,_0x259165)):_0x4ab68c['trackChildChange'](Dt(_0x5954f4,_0x259165,_0x20474f))),_0x478ed9['isLeafNode']()&&_0x259165['isEmpty']())?_0x478ed9:_0x478ed9['updateImmediateChild'](_0x5954f4,_0x259165)['withIndex'](this['index_']);}['updateFullNode'](_0x4020b1,_0x2e1478,_0x37a340){return _0x37a340!=null&&(_0x4020b1['isLeafNode']()||_0x4020b1['forEachChild'](R,(_0x1fbec1,_0x28e1e8)=>{_0x2e1478['hasChild'](_0x1fbec1)||_0x37a340['trackChildChange'](Ot(_0x1fbec1,_0x28e1e8));}),_0x2e1478['isLeafNode']()||_0x2e1478['forEachChild'](R,(_0x287df6,_0x3dbfc7)=>{if(_0x4020b1['hasChild'](_0x287df6)){const _0x426f01=_0x4020b1['getImmediateChild'](_0x287df6);_0x426f01['equals'](_0x3dbfc7)||_0x37a340['trackChildChange'](Dt(_0x287df6,_0x3dbfc7,_0x426f01));}else _0x37a340['trackChildChange'](et(_0x287df6,_0x3dbfc7));})),_0x2e1478['withIndex'](this['index_']);}['updatePriority'](_0x1701b0,_0x2afcd4){return _0x1701b0['isEmpty']()?g['EMPTY_NODE']:_0x1701b0['updatePriority'](_0x2afcd4);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x530c5d){this['indexedFilter_']=new Ji(_0x530c5d['getIndex']()),this['index_']=_0x530c5d['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x530c5d),this['endPost_']=Mt['getEndPost_'](_0x530c5d),this['startIsInclusive_']=!_0x530c5d['startAfterSet_'],this['endIsInclusive_']=!_0x530c5d['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x32d913){const _0x205644=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x32d913)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x32d913)<0x0,_0x4afdfc=this['endIsInclusive_']?this['index_']['compare'](_0x32d913,this['getEndPost']())<=0x0:this['index_']['compare'](_0x32d913,this['getEndPost']())<0x0;return _0x205644&&_0x4afdfc;}['updateChild'](_0x159c90,_0x511768,_0x3ea1da,_0x53d023,_0xa6cfe0,_0x25a1ad){return this['matches'](new E(_0x511768,_0x3ea1da))||(_0x3ea1da=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x159c90,_0x511768,_0x3ea1da,_0x53d023,_0xa6cfe0,_0x25a1ad);}['updateFullNode'](_0x47c6c6,_0x52ee71,_0xaf8246){_0x52ee71['isLeafNode']()&&(_0x52ee71=g['EMPTY_NODE']);let _0x3e0438=_0x52ee71['withIndex'](this['index_']);_0x3e0438=_0x3e0438['updatePriority'](g['EMPTY_NODE']);const _0x290ccc=this;return _0x52ee71['forEachChild'](R,(_0x14b05c,_0x5b4bc3)=>{_0x290ccc['matches'](new E(_0x14b05c,_0x5b4bc3))||(_0x3e0438=_0x3e0438['updateImmediateChild'](_0x14b05c,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x47c6c6,_0x3e0438,_0xaf8246);}['updatePriority'](_0x380dbe,_0x58f076){return _0x380dbe;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x64f6ca){if(_0x64f6ca['hasStart']()){const _0x2969a9=_0x64f6ca['getIndexStartName']();return _0x64f6ca['getIndex']()['makePost'](_0x64f6ca['getIndexStartValue'](),_0x2969a9);}else return _0x64f6ca['getIndex']()['minPost']();}static['getEndPost_'](_0x192fdd){if(_0x192fdd['hasEnd']()){const _0x2951ec=_0x192fdd['getIndexEndName']();return _0x192fdd['getIndex']()['makePost'](_0x192fdd['getIndexEndValue'](),_0x2951ec);}else return _0x192fdd['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x1967de){this['withinDirectionalStart']=_0x277a1a=>this['reverse_']?this['withinEndPost'](_0x277a1a):this['withinStartPost'](_0x277a1a),this['withinDirectionalEnd']=_0x438464=>this['reverse_']?this['withinStartPost'](_0x438464):this['withinEndPost'](_0x438464),this['withinStartPost']=_0x5eca9d=>{const _0x33dddf=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x5eca9d);return this['startIsInclusive_']?_0x33dddf<=0x0:_0x33dddf<0x0;},this['withinEndPost']=_0x5c25f7=>{const _0x1e841e=this['index_']['compare'](_0x5c25f7,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x1e841e<=0x0:_0x1e841e<0x0;},this['rangedFilter_']=new Mt(_0x1967de),this['index_']=_0x1967de['getIndex'](),this['limit_']=_0x1967de['getLimit'](),this['reverse_']=!_0x1967de['isViewFromLeft'](),this['startIsInclusive_']=!_0x1967de['startAfterSet_'],this['endIsInclusive_']=!_0x1967de['endBeforeSet_'];}['updateChild'](_0x353a9d,_0x794277,_0x2901ef,_0x400807,_0x2a7fdb,_0x214e60){return this['rangedFilter_']['matches'](new E(_0x794277,_0x2901ef))||(_0x2901ef=g['EMPTY_NODE']),_0x353a9d['getImmediateChild'](_0x794277)['equals'](_0x2901ef)?_0x353a9d:_0x353a9d['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x353a9d,_0x794277,_0x2901ef,_0x400807,_0x2a7fdb,_0x214e60):this['fullLimitUpdateChild_'](_0x353a9d,_0x794277,_0x2901ef,_0x2a7fdb,_0x214e60);}['updateFullNode'](_0xfd6292,_0x289c1a,_0x18cca2){let _0x1ec01f;if(_0x289c1a['isLeafNode']()||_0x289c1a['isEmpty']())_0x1ec01f=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x289c1a['numChildren']()&&_0x289c1a['isIndexed'](this['index_'])){_0x1ec01f=g['EMPTY_NODE']['withIndex'](this['index_']);let _0xf6ea8f;this['reverse_']?_0xf6ea8f=_0x289c1a['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0xf6ea8f=_0x289c1a['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x2f306c=0x0;for(;_0xf6ea8f['hasNext']()&&_0x2f306c<this['limit_'];){const _0x4940ab=_0xf6ea8f['getNext']();if(this['withinDirectionalStart'](_0x4940ab)){if(this['withinDirectionalEnd'](_0x4940ab))_0x1ec01f=_0x1ec01f['updateImmediateChild'](_0x4940ab['name'],_0x4940ab['node']),_0x2f306c++;else break;}else continue;}}else{_0x1ec01f=_0x289c1a['withIndex'](this['index_']),_0x1ec01f=_0x1ec01f['updatePriority'](g['EMPTY_NODE']);let _0x56465f;this['reverse_']?_0x56465f=_0x1ec01f['getReverseIterator'](this['index_']):_0x56465f=_0x1ec01f['getIterator'](this['index_']);let _0x43de2c=0x0;for(;_0x56465f['hasNext']();){const _0x5ee5f4=_0x56465f['getNext']();_0x43de2c<this['limit_']&&this['withinDirectionalStart'](_0x5ee5f4)&&this['withinDirectionalEnd'](_0x5ee5f4)?_0x43de2c++:_0x1ec01f=_0x1ec01f['updateImmediateChild'](_0x5ee5f4['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0xfd6292,_0x1ec01f,_0x18cca2);}['updatePriority'](_0x219e4f,_0x3c14a0){return _0x219e4f;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x15ba6c,_0xf2c4c3,_0x271bb7,_0x365898,_0x11a4a3){let _0x2bc628;if(this['reverse_']){const _0x537105=this['index_']['getCompare']();_0x2bc628=(_0x17e0b4,_0x42fe3d)=>_0x537105(_0x42fe3d,_0x17e0b4);}else _0x2bc628=this['index_']['getCompare']();const _0x1c75f7=_0x15ba6c;f(_0x1c75f7['numChildren']()===this['limit_'],'');const _0x262dbd=new E(_0xf2c4c3,_0x271bb7),_0xc752e2=this['reverse_']?_0x1c75f7['getFirstChild'](this['index_']):_0x1c75f7['getLastChild'](this['index_']),_0x5b5802=this['rangedFilter_']['matches'](_0x262dbd);if(_0x1c75f7['hasChild'](_0xf2c4c3)){const _0x5f2f99=_0x1c75f7['getImmediateChild'](_0xf2c4c3);let _0x59ec99=_0x365898['getChildAfterChild'](this['index_'],_0xc752e2,this['reverse_']);for(;_0x59ec99!=null&&(_0x59ec99['name']===_0xf2c4c3||_0x1c75f7['hasChild'](_0x59ec99['name']));)_0x59ec99=_0x365898['getChildAfterChild'](this['index_'],_0x59ec99,this['reverse_']);const _0x3a2a98=_0x59ec99==null?0x1:_0x2bc628(_0x59ec99,_0x262dbd);if(_0x5b5802&&!_0x271bb7['isEmpty']()&&_0x3a2a98>=0x0)return _0x11a4a3!=null&&_0x11a4a3['trackChildChange'](Dt(_0xf2c4c3,_0x271bb7,_0x5f2f99)),_0x1c75f7['updateImmediateChild'](_0xf2c4c3,_0x271bb7);{_0x11a4a3!=null&&_0x11a4a3['trackChildChange'](Ot(_0xf2c4c3,_0x5f2f99));const _0x41654f=_0x1c75f7['updateImmediateChild'](_0xf2c4c3,g['EMPTY_NODE']);return _0x59ec99!=null&&this['rangedFilter_']['matches'](_0x59ec99)?(_0x11a4a3!=null&&_0x11a4a3['trackChildChange'](et(_0x59ec99['name'],_0x59ec99['node'])),_0x41654f['updateImmediateChild'](_0x59ec99['name'],_0x59ec99['node'])):_0x41654f;}}else return _0x271bb7['isEmpty']()?_0x15ba6c:_0x5b5802&&_0x2bc628(_0xc752e2,_0x262dbd)>=0x0?(_0x11a4a3!=null&&(_0x11a4a3['trackChildChange'](Ot(_0xc752e2['name'],_0xc752e2['node'])),_0x11a4a3['trackChildChange'](et(_0xf2c4c3,_0x271bb7))),_0x1c75f7['updateImmediateChild'](_0xf2c4c3,_0x271bb7)['updateImmediateChild'](_0xc752e2['name'],g['EMPTY_NODE'])):_0x15ba6c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x574494=new Xi();return _0x574494['limitSet_']=this['limitSet_'],_0x574494['limit_']=this['limit_'],_0x574494['startSet_']=this['startSet_'],_0x574494['startAfterSet_']=this['startAfterSet_'],_0x574494['indexStartValue_']=this['indexStartValue_'],_0x574494['startNameSet_']=this['startNameSet_'],_0x574494['indexStartName_']=this['indexStartName_'],_0x574494['endSet_']=this['endSet_'],_0x574494['endBeforeSet_']=this['endBeforeSet_'],_0x574494['indexEndValue_']=this['indexEndValue_'],_0x574494['endNameSet_']=this['endNameSet_'],_0x574494['indexEndName_']=this['indexEndName_'],_0x574494['index_']=this['index_'],_0x574494['viewFrom_']=this['viewFrom_'],_0x574494;}}function Kh(_0x3f321a){return _0x3f321a['loadsAllData']()?new Ji(_0x3f321a['getIndex']()):_0x3f321a['hasLimit']()?new jh(_0x3f321a):new Mt(_0x3f321a);}function Yh(_0x16164e,_0x4dc28e){const _0xdbf45=_0x16164e['copy']();return _0xdbf45['limitSet_']=!0x0,_0xdbf45['limit_']=_0x4dc28e,_0xdbf45['viewFrom_']='l',_0xdbf45;}function Qh(_0x5dd6cd,_0x389b09,_0x2632e6){const _0x16a723=_0x5dd6cd['copy']();return _0x16a723['startSet_']=!0x0,_0x389b09===void 0x0&&(_0x389b09=null),_0x16a723['indexStartValue_']=_0x389b09,_0x2632e6!=null?(_0x16a723['startNameSet_']=!0x0,_0x16a723['indexStartName_']=_0x2632e6):(_0x16a723['startNameSet_']=!0x1,_0x16a723['indexStartName_']=''),_0x16a723;}function Jh(_0x2e83e9,_0x3de99f,_0x1ef66a){const _0x239283=_0x2e83e9['copy']();return _0x239283['endSet_']=!0x0,_0x3de99f===void 0x0&&(_0x3de99f=null),_0x239283['indexEndValue_']=_0x3de99f,_0x1ef66a!==void 0x0?(_0x239283['endNameSet_']=!0x0,_0x239283['indexEndName_']=_0x1ef66a):(_0x239283['endNameSet_']=!0x1,_0x239283['indexEndName_']=''),_0x239283;}function xo(_0x77bbc1,_0x40f7a0){const _0x47245f=_0x77bbc1['copy']();return _0x47245f['index_']=_0x40f7a0,_0x47245f;}function sr(_0x3b5484){const _0x4a20f3={};if(_0x3b5484['isDefault']())return _0x4a20f3;let _0x55b998;if(_0x3b5484['index_']===R?_0x55b998='$priority':_0x3b5484['index_']===Mo?_0x55b998='$value':_0x3b5484['index_']===ye?_0x55b998='$key':(f(_0x3b5484['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x55b998=_0x3b5484['index_']['toString']()),_0x4a20f3['orderBy']=O(_0x55b998),_0x3b5484['startSet_']){const _0x2a748f=_0x3b5484['startAfterSet_']?'startAfter':'startAt';_0x4a20f3[_0x2a748f]=O(_0x3b5484['indexStartValue_']),_0x3b5484['startNameSet_']&&(_0x4a20f3[_0x2a748f]+=','+O(_0x3b5484['indexStartName_']));}if(_0x3b5484['endSet_']){const _0x141697=_0x3b5484['endBeforeSet_']?'endBefore':'endAt';_0x4a20f3[_0x141697]=O(_0x3b5484['indexEndValue_']),_0x3b5484['endNameSet_']&&(_0x4a20f3[_0x141697]+=','+O(_0x3b5484['indexEndName_']));}return _0x3b5484['limitSet_']&&(_0x3b5484['isViewFromLeft']()?_0x4a20f3['limitToFirst']=_0x3b5484['limit_']:_0x4a20f3['limitToLast']=_0x3b5484['limit_']),_0x4a20f3;}function rr(_0x21710f){const _0x24afa9={};if(_0x21710f['startSet_']&&(_0x24afa9['sp']=_0x21710f['indexStartValue_'],_0x21710f['startNameSet_']&&(_0x24afa9['sn']=_0x21710f['indexStartName_']),_0x24afa9['sin']=!_0x21710f['startAfterSet_']),_0x21710f['endSet_']&&(_0x24afa9['ep']=_0x21710f['indexEndValue_'],_0x21710f['endNameSet_']&&(_0x24afa9['en']=_0x21710f['indexEndName_']),_0x24afa9['ein']=!_0x21710f['endBeforeSet_']),_0x21710f['limitSet_']){_0x24afa9['l']=_0x21710f['limit_'];let _0x1da42a=_0x21710f['viewFrom_'];_0x1da42a===''&&(_0x21710f['isViewFromLeft']()?_0x1da42a='l':_0x1da42a='r'),_0x24afa9['vf']=_0x1da42a;}return _0x21710f['index_']!==R&&(_0x24afa9['i']=_0x21710f['index_']['toString']()),_0x24afa9;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x2d3bb8){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x2e8c42,_0x15ac99){return _0x15ac99!==void 0x0?'tag$'+_0x15ac99:(f(_0x2e8c42['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x2e8c42['_path']['toString']());}constructor(_0x30e7f4,_0x49302d,_0x18c344,_0xdd70f3){super(),this['repoInfo_']=_0x30e7f4,this['onDataUpdate_']=_0x49302d,this['authTokenProvider_']=_0x18c344,this['appCheckTokenProvider_']=_0xdd70f3,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x30d030,_0x46ad3d,_0x5ae038,_0x5c6ab8){const _0x2ffb75=_0x30d030['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2ffb75+'\x20'+_0x30d030['_queryIdentifier']);const _0x1f5038=pn['getListenId_'](_0x30d030,_0x5ae038),_0x4be9bd={};this['listens_'][_0x1f5038]=_0x4be9bd;const _0x1d8435=sr(_0x30d030['_queryParams']);this['restRequest_'](_0x2ffb75+'.json',_0x1d8435,(_0x1c4218,_0x434122)=>{let _0x4e5dbe=_0x434122;if(_0x1c4218===0x194&&(_0x4e5dbe=null,_0x1c4218=null),_0x1c4218===null&&this['onDataUpdate_'](_0x2ffb75,_0x4e5dbe,!0x1,_0x5ae038),De(this['listens_'],_0x1f5038)===_0x4be9bd){let _0x5eb043;_0x1c4218?_0x1c4218===0x191?_0x5eb043='permission_denied':_0x5eb043='rest_error:'+_0x1c4218:_0x5eb043='ok',_0x5c6ab8(_0x5eb043,null);}});}['unlisten'](_0x44f08a,_0x585872){const _0x30946e=pn['getListenId_'](_0x44f08a,_0x585872);delete this['listens_'][_0x30946e];}['get'](_0x53ff2a){const _0x219f87=sr(_0x53ff2a['_queryParams']),_0x43b9a7=_0x53ff2a['_path']['toString'](),_0x14a56c=new ot();return this['restRequest_'](_0x43b9a7+'.json',_0x219f87,(_0x4ff4a4,_0x2386e0)=>{let _0x499ad3=_0x2386e0;_0x4ff4a4===0x194&&(_0x499ad3=null,_0x4ff4a4=null),_0x4ff4a4===null?(this['onDataUpdate_'](_0x43b9a7,_0x499ad3,!0x1,null),_0x14a56c['resolve'](_0x499ad3)):_0x14a56c['reject'](new Error(_0x499ad3));}),_0x14a56c['promise'];}['refreshAuthToken'](_0x52f16b){}['restRequest_'](_0x245000,_0x53ec91={},_0x3c4eac){return _0x53ec91['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x5bd696,_0x15ab36])=>{_0x5bd696&&_0x5bd696['accessToken']&&(_0x53ec91['auth']=_0x5bd696['accessToken']),_0x15ab36&&_0x15ab36['token']&&(_0x53ec91['ac']=_0x15ab36['token']);const _0x5e0d95=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x245000+'?ns='+this['repoInfo_']['namespace']+ct(_0x53ec91);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x5e0d95);const _0x2cf9a9=new XMLHttpRequest();_0x2cf9a9['onreadystatechange']=()=>{if(_0x3c4eac&&_0x2cf9a9['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x5e0d95+'\x20received.\x20status:',_0x2cf9a9['status'],'response:',_0x2cf9a9['responseText']);let _0x43ad37=null;if(_0x2cf9a9['status']>=0xc8&&_0x2cf9a9['status']<0x12c){try{_0x43ad37=At(_0x2cf9a9['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x5e0d95+':\x20'+_0x2cf9a9['responseText']);}_0x3c4eac(null,_0x43ad37);}else _0x2cf9a9['status']!==0x191&&_0x2cf9a9['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x5e0d95+'\x20Status:\x20'+_0x2cf9a9['status']),_0x3c4eac(_0x2cf9a9['status']);_0x3c4eac=null;}},_0x2cf9a9['open']('GET',_0x5e0d95,!0x0),_0x2cf9a9['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x78aa92){return this['rootNode_']['getChild'](_0x78aa92);}['updateSnapshot'](_0x51b68f,_0x32e4d7){this['rootNode_']=this['rootNode_']['updateChild'](_0x51b68f,_0x32e4d7);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0xd5ee6a,_0x5db216,_0x30daee){if(v(_0x5db216))_0xd5ee6a['value']=_0x30daee,_0xd5ee6a['children']['clear']();else{if(_0xd5ee6a['value']!==null)_0xd5ee6a['value']=_0xd5ee6a['value']['updateChild'](_0x5db216,_0x30daee);else{const _0x31b4cd=y(_0x5db216);_0xd5ee6a['children']['has'](_0x31b4cd)||_0xd5ee6a['children']['set'](_0x31b4cd,_n());const _0x29367b=_0xd5ee6a['children']['get'](_0x31b4cd);_0x5db216=b(_0x5db216),Fo(_0x29367b,_0x5db216,_0x30daee);}}}function Ii(_0x51da56,_0x30fcc8,_0x1ee748){_0x51da56['value']!==null?_0x1ee748(_0x30fcc8,_0x51da56['value']):Zh(_0x51da56,(_0x7b534c,_0x569006)=>{const _0x146f79=new C(_0x30fcc8['toString']()+'/'+_0x7b534c);Ii(_0x569006,_0x146f79,_0x1ee748);});}function Zh(_0x21b636,_0x119754){_0x21b636['children']['forEach']((_0x2cd1c6,_0x21a629)=>{_0x119754(_0x21a629,_0x2cd1c6);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x4d571b){this['collection_']=_0x4d571b,this['last_']=null;}['get'](){const _0x3975fe=this['collection_']['get'](),_0x1b3566={..._0x3975fe};return this['last_']&&x(this['last_'],(_0x40a329,_0x4f9767)=>{_0x1b3566[_0x40a329]=_0x1b3566[_0x40a329]-_0x4f9767;}),this['last_']=_0x3975fe,_0x1b3566;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x26c30f,_0x528ec7){this['server_']=_0x528ec7,this['statsToReport_']={},this['statsListener_']=new eu(_0x26c30f);const _0x3dbbd3=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x3dbbd3));}['reportStats_'](){const _0x1935ce=this['statsListener_']['get'](),_0x387c29={};let _0x159cb1=!0x1;x(_0x1935ce,(_0x11c798,_0x568cd9)=>{_0x568cd9>0x0&&J(this['statsToReport_'],_0x11c798)&&(_0x387c29[_0x11c798]=_0x568cd9,_0x159cb1=!0x0);}),_0x159cb1&&this['server_']['reportStats'](_0x387c29),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x107a88){_0x107a88[_0x107a88['OVERWRITE']=0x0]='OVERWRITE',_0x107a88[_0x107a88['MERGE']=0x1]='MERGE',_0x107a88[_0x107a88['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x107a88[_0x107a88['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x463cac){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x463cac,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x1affe6,_0x500130,_0x4d37dc){this['path']=_0x1affe6,this['affectedTree']=_0x500130,this['revert']=_0x4d37dc,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x51f1f8){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x170952=this['affectedTree']['subtree'](new C(_0x51f1f8));return new gn(w(),_0x170952,this['revert']);}}else return f(y(this['path'])===_0x51f1f8,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0xc6f4e,_0x4ef1da){this['source']=_0xc6f4e,this['path']=_0x4ef1da,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x19379f){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x196bb6,_0x47fd7f,_0x1bc609){this['source']=_0x196bb6,this['path']=_0x47fd7f,this['snap']=_0x1bc609,this['type']=j['OVERWRITE'];}['operationForChild'](_0x4336e6){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x4336e6)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x562b57,_0x389325,_0x17294a){this['source']=_0x562b57,this['path']=_0x389325,this['children']=_0x17294a,this['type']=j['MERGE'];}['operationForChild'](_0x21c320){if(v(this['path'])){const _0x499b9c=this['children']['subtree'](new C(_0x21c320));return _0x499b9c['isEmpty']()?null:_0x499b9c['value']?new Ue(this['source'],w(),_0x499b9c['value']):new tt(this['source'],w(),_0x499b9c);}else return f(y(this['path'])===_0x21c320,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x175f8c,_0x33588e,_0x125728){this['node_']=_0x175f8c,this['fullyInitialized_']=_0x33588e,this['filtered_']=_0x125728;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x344c80){if(v(_0x344c80))return this['isFullyInitialized']()&&!this['filtered_'];const _0x309358=y(_0x344c80);return this['isCompleteForChild'](_0x309358);}['isCompleteForChild'](_0x206436){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x206436);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x31d412){this['query_']=_0x31d412,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0xc8d05a,_0x3ad8ca,_0x10be30,_0x28092e){const _0x1cc703=[],_0x4f849a=[];return _0x3ad8ca['forEach'](_0x40fa6b=>{_0x40fa6b['type']==='child_changed'&&_0xc8d05a['index_']['indexedValueChanged'](_0x40fa6b['oldSnap'],_0x40fa6b['snapshotNode'])&&_0x4f849a['push'](zh(_0x40fa6b['childName'],_0x40fa6b['snapshotNode']));}),yt(_0xc8d05a,_0x1cc703,'child_removed',_0x3ad8ca,_0x28092e,_0x10be30),yt(_0xc8d05a,_0x1cc703,'child_added',_0x3ad8ca,_0x28092e,_0x10be30),yt(_0xc8d05a,_0x1cc703,'child_moved',_0x4f849a,_0x28092e,_0x10be30),yt(_0xc8d05a,_0x1cc703,'child_changed',_0x3ad8ca,_0x28092e,_0x10be30),yt(_0xc8d05a,_0x1cc703,'value',_0x3ad8ca,_0x28092e,_0x10be30),_0x1cc703;}function yt(_0x34b7ea,_0x469f6d,_0x4f14ab,_0x2c009c,_0x5ca97a,_0x5bb5e6){const _0x3d7919=_0x2c009c['filter'](_0x11c337=>_0x11c337['type']===_0x4f14ab);_0x3d7919['sort']((_0x53f7f0,_0x915ab8)=>au(_0x34b7ea,_0x53f7f0,_0x915ab8)),_0x3d7919['forEach'](_0x498cae=>{const _0x2e4fac=ou(_0x34b7ea,_0x498cae,_0x5bb5e6);_0x5ca97a['forEach'](_0x14129e=>{_0x14129e['respondsTo'](_0x498cae['type'])&&_0x469f6d['push'](_0x14129e['createEvent'](_0x2e4fac,_0x34b7ea['query_']));});});}function ou(_0x36c15b,_0x1cf46d,_0x183a1d){return _0x1cf46d['type']==='value'||_0x1cf46d['type']==='child_removed'||(_0x1cf46d['prevName']=_0x183a1d['getPredecessorChildName'](_0x1cf46d['childName'],_0x1cf46d['snapshotNode'],_0x36c15b['index_'])),_0x1cf46d;}function au(_0x1d4652,_0x4df34b,_0x5b5f0b){if(_0x4df34b['childName']==null||_0x5b5f0b['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x5ecd6e=new E(_0x4df34b['childName'],_0x4df34b['snapshotNode']),_0x589f3b=new E(_0x5b5f0b['childName'],_0x5b5f0b['snapshotNode']);return _0x1d4652['index_']['compare'](_0x5ecd6e,_0x589f3b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x5d917a,_0x3e81b2){return{'eventCache':_0x5d917a,'serverCache':_0x3e81b2};}function Tt(_0xa71b2,_0x1013c7,_0x342602,_0x150814){return Mn(new Ce(_0x1013c7,_0x342602,_0x150814),_0xa71b2['serverCache']);}function Uo(_0x152b0b,_0xef0d75,_0x1c2ba0,_0x2e13d2){return Mn(_0x152b0b['eventCache'],new Ce(_0xef0d75,_0x1c2ba0,_0x2e13d2));}function mn(_0x5d64c9){return _0x5d64c9['eventCache']['isFullyInitialized']()?_0x5d64c9['eventCache']['getNode']():null;}function We(_0x27ca9c){return _0x27ca9c['serverCache']['isFullyInitialized']()?_0x27ca9c['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0xe4815f){let _0x1f2901=new S(null);return x(_0xe4815f,(_0x6fac1a,_0x487ac7)=>{_0x1f2901=_0x1f2901['set'](new C(_0x6fac1a),_0x487ac7);}),_0x1f2901;}constructor(_0x5c8eb9,_0xff421=cu()){this['value']=_0x5c8eb9,this['children']=_0xff421;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x4f9781,_0x416842){if(this['value']!=null&&_0x416842(this['value']))return{'path':w(),'value':this['value']};if(v(_0x4f9781))return null;{const _0x53baec=y(_0x4f9781),_0x4e08f6=this['children']['get'](_0x53baec);if(_0x4e08f6!==null){const _0x1e3a85=_0x4e08f6['findRootMostMatchingPathAndValue'](b(_0x4f9781),_0x416842);return _0x1e3a85!=null?{'path':k(new C(_0x53baec),_0x1e3a85['path']),'value':_0x1e3a85['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x406b02){return this['findRootMostMatchingPathAndValue'](_0x406b02,()=>!0x0);}['subtree'](_0x1d8475){if(v(_0x1d8475))return this;{const _0x483b08=y(_0x1d8475),_0x2178bb=this['children']['get'](_0x483b08);return _0x2178bb!==null?_0x2178bb['subtree'](b(_0x1d8475)):new S(null);}}['set'](_0x4e9757,_0x1b3d2c){if(v(_0x4e9757))return new S(_0x1b3d2c,this['children']);{const _0x292c92=y(_0x4e9757),_0x4089ab=(this['children']['get'](_0x292c92)||new S(null))['set'](b(_0x4e9757),_0x1b3d2c),_0x5e06f3=this['children']['insert'](_0x292c92,_0x4089ab);return new S(this['value'],_0x5e06f3);}}['remove'](_0x1bf892){if(v(_0x1bf892))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x1b0cf5=y(_0x1bf892),_0x3fe814=this['children']['get'](_0x1b0cf5);if(_0x3fe814){const _0x44687b=_0x3fe814['remove'](b(_0x1bf892));let _0x4d70e9;return _0x44687b['isEmpty']()?_0x4d70e9=this['children']['remove'](_0x1b0cf5):_0x4d70e9=this['children']['insert'](_0x1b0cf5,_0x44687b),this['value']===null&&_0x4d70e9['isEmpty']()?new S(null):new S(this['value'],_0x4d70e9);}else return this;}}['get'](_0x38d074){if(v(_0x38d074))return this['value'];{const _0x5c8657=y(_0x38d074),_0x121bba=this['children']['get'](_0x5c8657);return _0x121bba?_0x121bba['get'](b(_0x38d074)):null;}}['setTree'](_0x1a95db,_0x575a1f){if(v(_0x1a95db))return _0x575a1f;{const _0x54bb54=y(_0x1a95db),_0x3855c1=(this['children']['get'](_0x54bb54)||new S(null))['setTree'](b(_0x1a95db),_0x575a1f);let _0x16e1a2;return _0x3855c1['isEmpty']()?_0x16e1a2=this['children']['remove'](_0x54bb54):_0x16e1a2=this['children']['insert'](_0x54bb54,_0x3855c1),new S(this['value'],_0x16e1a2);}}['fold'](_0x2043a7){return this['fold_'](w(),_0x2043a7);}['fold_'](_0x34d4ab,_0x2d21e6){const _0x42b89c={};return this['children']['inorderTraversal']((_0xb6aa98,_0x3879a7)=>{_0x42b89c[_0xb6aa98]=_0x3879a7['fold_'](k(_0x34d4ab,_0xb6aa98),_0x2d21e6);}),_0x2d21e6(_0x34d4ab,this['value'],_0x42b89c);}['findOnPath'](_0x167546,_0x4829b4){return this['findOnPath_'](_0x167546,w(),_0x4829b4);}['findOnPath_'](_0x3f7b2f,_0x1fb95f,_0x332b5b){const _0x292097=this['value']?_0x332b5b(_0x1fb95f,this['value']):!0x1;if(_0x292097)return _0x292097;if(v(_0x3f7b2f))return null;{const _0x5ce713=y(_0x3f7b2f),_0xfd9c06=this['children']['get'](_0x5ce713);return _0xfd9c06?_0xfd9c06['findOnPath_'](b(_0x3f7b2f),k(_0x1fb95f,_0x5ce713),_0x332b5b):null;}}['foreachOnPath'](_0x802d83,_0x230b02){return this['foreachOnPath_'](_0x802d83,w(),_0x230b02);}['foreachOnPath_'](_0x1fd695,_0x1f2ce9,_0x45a151){if(v(_0x1fd695))return this;{this['value']&&_0x45a151(_0x1f2ce9,this['value']);const _0x4886d6=y(_0x1fd695),_0x348468=this['children']['get'](_0x4886d6);return _0x348468?_0x348468['foreachOnPath_'](b(_0x1fd695),k(_0x1f2ce9,_0x4886d6),_0x45a151):new S(null);}}['foreach'](_0x445224){this['foreach_'](w(),_0x445224);}['foreach_'](_0x5eda1b,_0x21187d){this['children']['inorderTraversal']((_0x7440d8,_0xb1d768)=>{_0xb1d768['foreach_'](k(_0x5eda1b,_0x7440d8),_0x21187d);}),this['value']&&_0x21187d(_0x5eda1b,this['value']);}['foreachChild'](_0xd7cffd){this['children']['inorderTraversal']((_0x277709,_0x17f985)=>{_0x17f985['value']&&_0xd7cffd(_0x277709,_0x17f985['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x4ff3f0){this['writeTree_']=_0x4ff3f0;}static['empty'](){return new Y(new S(null));}}function St(_0x2b384e,_0x3b3544,_0x337e56){if(v(_0x3b3544))return new Y(new S(_0x337e56));{const _0x51aba0=_0x2b384e['writeTree_']['findRootMostValueAndPath'](_0x3b3544);if(_0x51aba0!=null){const _0x5e7f95=_0x51aba0['path'];let _0x5b0947=_0x51aba0['value'];const _0xb08132=F(_0x5e7f95,_0x3b3544);return _0x5b0947=_0x5b0947['updateChild'](_0xb08132,_0x337e56),new Y(_0x2b384e['writeTree_']['set'](_0x5e7f95,_0x5b0947));}else{const _0x3ca4f0=new S(_0x337e56),_0x9ceda6=_0x2b384e['writeTree_']['setTree'](_0x3b3544,_0x3ca4f0);return new Y(_0x9ceda6);}}}function wi(_0x5b47b8,_0x14ec15,_0x2d1554){let _0x13fc73=_0x5b47b8;return x(_0x2d1554,(_0x3239b9,_0x17778c)=>{_0x13fc73=St(_0x13fc73,k(_0x14ec15,_0x3239b9),_0x17778c);}),_0x13fc73;}function ar(_0x3f3c61,_0x373cfd){if(v(_0x373cfd))return Y['empty']();{const _0x5d4d9f=_0x3f3c61['writeTree_']['setTree'](_0x373cfd,new S(null));return new Y(_0x5d4d9f);}}function Ci(_0x25cc85,_0x28e274){return $e(_0x25cc85,_0x28e274)!=null;}function $e(_0x13c2dc,_0x474e5c){const _0x537063=_0x13c2dc['writeTree_']['findRootMostValueAndPath'](_0x474e5c);return _0x537063!=null?_0x13c2dc['writeTree_']['get'](_0x537063['path'])['getChild'](F(_0x537063['path'],_0x474e5c)):null;}function cr(_0x4fa9a0){const _0xb61755=[],_0x19dfb1=_0x4fa9a0['writeTree_']['value'];return _0x19dfb1!=null?_0x19dfb1['isLeafNode']()||_0x19dfb1['forEachChild'](R,(_0x1f0ee7,_0x5d1a0e)=>{_0xb61755['push'](new E(_0x1f0ee7,_0x5d1a0e));}):_0x4fa9a0['writeTree_']['children']['inorderTraversal']((_0x45b70b,_0x2d5f70)=>{_0x2d5f70['value']!=null&&_0xb61755['push'](new E(_0x45b70b,_0x2d5f70['value']));}),_0xb61755;}function ve(_0x12cb0f,_0x3a24c1){if(v(_0x3a24c1))return _0x12cb0f;{const _0x5b3c44=$e(_0x12cb0f,_0x3a24c1);return _0x5b3c44!=null?new Y(new S(_0x5b3c44)):new Y(_0x12cb0f['writeTree_']['subtree'](_0x3a24c1));}}function Ti(_0x4303b2){return _0x4303b2['writeTree_']['isEmpty']();}function nt(_0x4c1b8c,_0x4f5402){return Wo(w(),_0x4c1b8c['writeTree_'],_0x4f5402);}function Wo(_0x3b00d7,_0xf409ac,_0x181644){if(_0xf409ac['value']!=null)return _0x181644['updateChild'](_0x3b00d7,_0xf409ac['value']);{let _0x21952d=null;return _0xf409ac['children']['inorderTraversal']((_0x35a6e5,_0x4b77e9)=>{_0x35a6e5==='.priority'?(f(_0x4b77e9['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x21952d=_0x4b77e9['value']):_0x181644=Wo(k(_0x3b00d7,_0x35a6e5),_0x4b77e9,_0x181644);}),!_0x181644['getChild'](_0x3b00d7)['isEmpty']()&&_0x21952d!==null&&(_0x181644=_0x181644['updateChild'](k(_0x3b00d7,'.priority'),_0x21952d)),_0x181644;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x582af3,_0x168215){return $o(_0x168215,_0x582af3);}function lu(_0x6bbd3a,_0x5417c7,_0x54bbe2,_0x4350c5,_0x4a14a2){f(_0x4350c5>_0x6bbd3a['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x4a14a2===void 0x0&&(_0x4a14a2=!0x0),_0x6bbd3a['allWrites']['push']({'path':_0x5417c7,'snap':_0x54bbe2,'writeId':_0x4350c5,'visible':_0x4a14a2}),_0x4a14a2&&(_0x6bbd3a['visibleWrites']=St(_0x6bbd3a['visibleWrites'],_0x5417c7,_0x54bbe2)),_0x6bbd3a['lastWriteId']=_0x4350c5;}function hu(_0x361373,_0x524ea6,_0x1b3508,_0x254547){f(_0x254547>_0x361373['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x361373['allWrites']['push']({'path':_0x524ea6,'children':_0x1b3508,'writeId':_0x254547,'visible':!0x0}),_0x361373['visibleWrites']=wi(_0x361373['visibleWrites'],_0x524ea6,_0x1b3508),_0x361373['lastWriteId']=_0x254547;}function uu(_0x55a4bc,_0x3a838a){for(let _0x32a324=0x0;_0x32a324<_0x55a4bc['allWrites']['length'];_0x32a324++){const _0x24a5ef=_0x55a4bc['allWrites'][_0x32a324];if(_0x24a5ef['writeId']===_0x3a838a)return _0x24a5ef;}return null;}function du(_0x5f3c71,_0x2f995f){const _0x2a0706=_0x5f3c71['allWrites']['findIndex'](_0xa49b5b=>_0xa49b5b['writeId']===_0x2f995f);f(_0x2a0706>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x4e1ee0=_0x5f3c71['allWrites'][_0x2a0706];_0x5f3c71['allWrites']['splice'](_0x2a0706,0x1);let _0x208a52=_0x4e1ee0['visible'],_0x126ee6=!0x1,_0x859443=_0x5f3c71['allWrites']['length']-0x1;for(;_0x208a52&&_0x859443>=0x0;){const _0x3fa5b7=_0x5f3c71['allWrites'][_0x859443];_0x3fa5b7['visible']&&(_0x859443>=_0x2a0706&&fu(_0x3fa5b7,_0x4e1ee0['path'])?_0x208a52=!0x1:G(_0x4e1ee0['path'],_0x3fa5b7['path'])&&(_0x126ee6=!0x0)),_0x859443--;}if(_0x208a52){if(_0x126ee6)return pu(_0x5f3c71),!0x0;if(_0x4e1ee0['snap'])_0x5f3c71['visibleWrites']=ar(_0x5f3c71['visibleWrites'],_0x4e1ee0['path']);else{const _0x34dfd4=_0x4e1ee0['children'];x(_0x34dfd4,_0x4a2b20=>{_0x5f3c71['visibleWrites']=ar(_0x5f3c71['visibleWrites'],k(_0x4e1ee0['path'],_0x4a2b20));});}return!0x0;}else return!0x1;}function fu(_0x175233,_0x54fb0b){if(_0x175233['snap'])return G(_0x175233['path'],_0x54fb0b);for(const _0x29d66f in _0x175233['children'])if(_0x175233['children']['hasOwnProperty'](_0x29d66f)&&G(k(_0x175233['path'],_0x29d66f),_0x54fb0b))return!0x0;return!0x1;}function pu(_0x104736){_0x104736['visibleWrites']=Bo(_0x104736['allWrites'],_u,w()),_0x104736['allWrites']['length']>0x0?_0x104736['lastWriteId']=_0x104736['allWrites'][_0x104736['allWrites']['length']-0x1]['writeId']:_0x104736['lastWriteId']=-0x1;}function _u(_0x5c0488){return _0x5c0488['visible'];}function Bo(_0x5e8276,_0x507f2e,_0x3c8069){let _0x6978bc=Y['empty']();for(let _0x27adc1=0x0;_0x27adc1<_0x5e8276['length'];++_0x27adc1){const _0x2c431a=_0x5e8276[_0x27adc1];if(_0x507f2e(_0x2c431a)){const _0x51c69f=_0x2c431a['path'];let _0x44e384;if(_0x2c431a['snap'])G(_0x3c8069,_0x51c69f)?(_0x44e384=F(_0x3c8069,_0x51c69f),_0x6978bc=St(_0x6978bc,_0x44e384,_0x2c431a['snap'])):G(_0x51c69f,_0x3c8069)&&(_0x44e384=F(_0x51c69f,_0x3c8069),_0x6978bc=St(_0x6978bc,w(),_0x2c431a['snap']['getChild'](_0x44e384)));else{if(_0x2c431a['children']){if(G(_0x3c8069,_0x51c69f))_0x44e384=F(_0x3c8069,_0x51c69f),_0x6978bc=wi(_0x6978bc,_0x44e384,_0x2c431a['children']);else{if(G(_0x51c69f,_0x3c8069)){if(_0x44e384=F(_0x51c69f,_0x3c8069),v(_0x44e384))_0x6978bc=wi(_0x6978bc,w(),_0x2c431a['children']);else{const _0x272cfa=De(_0x2c431a['children'],y(_0x44e384));if(_0x272cfa){const _0x24dad4=_0x272cfa['getChild'](b(_0x44e384));_0x6978bc=St(_0x6978bc,w(),_0x24dad4);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x6978bc;}function Vo(_0x34a5e3,_0x4da40f,_0x4fb7d1,_0x588fa4,_0x560ab6){if(!_0x588fa4&&!_0x560ab6){const _0x2dddd6=$e(_0x34a5e3['visibleWrites'],_0x4da40f);if(_0x2dddd6!=null)return _0x2dddd6;{const _0x5b84c6=ve(_0x34a5e3['visibleWrites'],_0x4da40f);if(Ti(_0x5b84c6))return _0x4fb7d1;if(_0x4fb7d1==null&&!Ci(_0x5b84c6,w()))return null;{const _0xa2a545=_0x4fb7d1||g['EMPTY_NODE'];return nt(_0x5b84c6,_0xa2a545);}}}else{const _0x339ae5=ve(_0x34a5e3['visibleWrites'],_0x4da40f);if(!_0x560ab6&&Ti(_0x339ae5))return _0x4fb7d1;if(!_0x560ab6&&_0x4fb7d1==null&&!Ci(_0x339ae5,w()))return null;{const _0x3b0891=function(_0x31ce25){return(_0x31ce25['visible']||_0x560ab6)&&(!_0x588fa4||!~_0x588fa4['indexOf'](_0x31ce25['writeId']))&&(G(_0x31ce25['path'],_0x4da40f)||G(_0x4da40f,_0x31ce25['path']));},_0x16735e=Bo(_0x34a5e3['allWrites'],_0x3b0891,_0x4da40f),_0x5cbf3b=_0x4fb7d1||g['EMPTY_NODE'];return nt(_0x16735e,_0x5cbf3b);}}}function gu(_0x4e5a3d,_0x79088,_0x4ecf3e){let _0x3ff49a=g['EMPTY_NODE'];const _0x14ead9=$e(_0x4e5a3d['visibleWrites'],_0x79088);if(_0x14ead9)return _0x14ead9['isLeafNode']()||_0x14ead9['forEachChild'](R,(_0x96fef7,_0x591f28)=>{_0x3ff49a=_0x3ff49a['updateImmediateChild'](_0x96fef7,_0x591f28);}),_0x3ff49a;if(_0x4ecf3e){const _0x5e0eb0=ve(_0x4e5a3d['visibleWrites'],_0x79088);return _0x4ecf3e['forEachChild'](R,(_0x2de579,_0x240d3b)=>{const _0xe2e031=nt(ve(_0x5e0eb0,new C(_0x2de579)),_0x240d3b);_0x3ff49a=_0x3ff49a['updateImmediateChild'](_0x2de579,_0xe2e031);}),cr(_0x5e0eb0)['forEach'](_0xb871b=>{_0x3ff49a=_0x3ff49a['updateImmediateChild'](_0xb871b['name'],_0xb871b['node']);}),_0x3ff49a;}else{const _0x2f7bee=ve(_0x4e5a3d['visibleWrites'],_0x79088);return cr(_0x2f7bee)['forEach'](_0x7e662d=>{_0x3ff49a=_0x3ff49a['updateImmediateChild'](_0x7e662d['name'],_0x7e662d['node']);}),_0x3ff49a;}}function mu(_0x29fa12,_0xbc4a2,_0x4d7d61,_0x57428f,_0xc851a7){f(_0x57428f||_0xc851a7,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x171854=k(_0xbc4a2,_0x4d7d61);if(Ci(_0x29fa12['visibleWrites'],_0x171854))return null;{const _0x2d4e20=ve(_0x29fa12['visibleWrites'],_0x171854);return Ti(_0x2d4e20)?_0xc851a7['getChild'](_0x4d7d61):nt(_0x2d4e20,_0xc851a7['getChild'](_0x4d7d61));}}function yu(_0x36da65,_0x3564cc,_0x5479da,_0x1e9c43){const _0x18cc51=k(_0x3564cc,_0x5479da),_0x48b6e8=$e(_0x36da65['visibleWrites'],_0x18cc51);if(_0x48b6e8!=null)return _0x48b6e8;if(_0x1e9c43['isCompleteForChild'](_0x5479da)){const _0x5efecf=ve(_0x36da65['visibleWrites'],_0x18cc51);return nt(_0x5efecf,_0x1e9c43['getNode']()['getImmediateChild'](_0x5479da));}else return null;}function vu(_0x53821e,_0x2d00e1){return $e(_0x53821e['visibleWrites'],_0x2d00e1);}function Eu(_0x4d57bb,_0x1a43aa,_0xc6c1fe,_0x3230ed,_0x1b27b9,_0xe32321,_0x1b0e11){let _0x575bb8;const _0x48e6d9=ve(_0x4d57bb['visibleWrites'],_0x1a43aa),_0x5d630c=$e(_0x48e6d9,w());if(_0x5d630c!=null)_0x575bb8=_0x5d630c;else{if(_0xc6c1fe!=null)_0x575bb8=nt(_0x48e6d9,_0xc6c1fe);else return[];}if(_0x575bb8=_0x575bb8['withIndex'](_0x1b0e11),!_0x575bb8['isEmpty']()&&!_0x575bb8['isLeafNode']()){const _0x3749df=[],_0x1fc43b=_0x1b0e11['getCompare'](),_0x5f2480=_0xe32321?_0x575bb8['getReverseIteratorFrom'](_0x3230ed,_0x1b0e11):_0x575bb8['getIteratorFrom'](_0x3230ed,_0x1b0e11);let _0x1a9355=_0x5f2480['getNext']();for(;_0x1a9355&&_0x3749df['length']<_0x1b27b9;)_0x1fc43b(_0x1a9355,_0x3230ed)!==0x0&&_0x3749df['push'](_0x1a9355),_0x1a9355=_0x5f2480['getNext']();return _0x3749df;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x863887,_0x94ae1e,_0x12fbf9,_0xd883c2){return Vo(_0x863887['writeTree'],_0x863887['treePath'],_0x94ae1e,_0x12fbf9,_0xd883c2);}function ns(_0x584366,_0x4b22b3){return gu(_0x584366['writeTree'],_0x584366['treePath'],_0x4b22b3);}function lr(_0x58ebda,_0x29e94b,_0x3d7b6b,_0x20df13){return mu(_0x58ebda['writeTree'],_0x58ebda['treePath'],_0x29e94b,_0x3d7b6b,_0x20df13);}function vn(_0x3a2479,_0x13cb9e){return vu(_0x3a2479['writeTree'],k(_0x3a2479['treePath'],_0x13cb9e));}function wu(_0x6e8ace,_0x17adbb,_0xd3250d,_0x4243d5,_0x5475d6,_0x441d08){return Eu(_0x6e8ace['writeTree'],_0x6e8ace['treePath'],_0x17adbb,_0xd3250d,_0x4243d5,_0x5475d6,_0x441d08);}function is(_0x5d2d4,_0x145bdd,_0x2719fe){return yu(_0x5d2d4['writeTree'],_0x5d2d4['treePath'],_0x145bdd,_0x2719fe);}function Ho(_0x4d7efe,_0x340f2b){return $o(k(_0x4d7efe['treePath'],_0x340f2b),_0x4d7efe['writeTree']);}function $o(_0x5f8e2d,_0x297ade){return{'treePath':_0x5f8e2d,'writeTree':_0x297ade};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x11f260){const _0x58091b=_0x11f260['type'],_0x37b88c=_0x11f260['childName'];f(_0x58091b==='child_added'||_0x58091b==='child_changed'||_0x58091b==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x37b88c!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x6024ea=this['changeMap']['get'](_0x37b88c);if(_0x6024ea){const _0x850885=_0x6024ea['type'];if(_0x58091b==='child_added'&&_0x850885==='child_removed')this['changeMap']['set'](_0x37b88c,Dt(_0x37b88c,_0x11f260['snapshotNode'],_0x6024ea['snapshotNode']));else{if(_0x58091b==='child_removed'&&_0x850885==='child_added')this['changeMap']['delete'](_0x37b88c);else{if(_0x58091b==='child_removed'&&_0x850885==='child_changed')this['changeMap']['set'](_0x37b88c,Ot(_0x37b88c,_0x6024ea['oldSnap']));else{if(_0x58091b==='child_changed'&&_0x850885==='child_added')this['changeMap']['set'](_0x37b88c,et(_0x37b88c,_0x11f260['snapshotNode']));else{if(_0x58091b==='child_changed'&&_0x850885==='child_changed')this['changeMap']['set'](_0x37b88c,Dt(_0x37b88c,_0x11f260['snapshotNode'],_0x6024ea['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x11f260+'\x20occurred\x20after\x20'+_0x6024ea);}}}}}else this['changeMap']['set'](_0x37b88c,_0x11f260);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x48eaa8){return null;}['getChildAfterChild'](_0x25e712,_0x1db996,_0x364da0){return null;}}const Go=new Tu();class ss{constructor(_0x3f50f1,_0x4c7ef9,_0x45d334=null){this['writes_']=_0x3f50f1,this['viewCache_']=_0x4c7ef9,this['optCompleteServerCache_']=_0x45d334;}['getCompleteChild'](_0x28efaa){const _0x10763c=this['viewCache_']['eventCache'];if(_0x10763c['isCompleteForChild'](_0x28efaa))return _0x10763c['getNode']()['getImmediateChild'](_0x28efaa);{const _0x5d684e=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x28efaa,_0x5d684e);}}['getChildAfterChild'](_0x4082e1,_0x4fac75,_0x8c11fe){const _0x3c490a=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x2d7e97=wu(this['writes_'],_0x3c490a,_0x4fac75,0x1,_0x8c11fe,_0x4082e1);return _0x2d7e97['length']===0x0?null:_0x2d7e97[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x5a1910){return{'filter':_0x5a1910};}function bu(_0x5aa281,_0x2a77d6){f(_0x2a77d6['eventCache']['getNode']()['isIndexed'](_0x5aa281['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x2a77d6['serverCache']['getNode']()['isIndexed'](_0x5aa281['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x15e9fe,_0x1f9628,_0xa1bc5c,_0x3c07ff,_0x3dea68){const _0x31b59f=new Cu();let _0x3b87de,_0x338dcb;if(_0xa1bc5c['type']===j['OVERWRITE']){const _0x15d5b1=_0xa1bc5c;_0x15d5b1['source']['fromUser']?_0x3b87de=Si(_0x15e9fe,_0x1f9628,_0x15d5b1['path'],_0x15d5b1['snap'],_0x3c07ff,_0x3dea68,_0x31b59f):(f(_0x15d5b1['source']['fromServer'],'Unknown\x20source.'),_0x338dcb=_0x15d5b1['source']['tagged']||_0x1f9628['serverCache']['isFiltered']()&&!v(_0x15d5b1['path']),_0x3b87de=En(_0x15e9fe,_0x1f9628,_0x15d5b1['path'],_0x15d5b1['snap'],_0x3c07ff,_0x3dea68,_0x338dcb,_0x31b59f));}else{if(_0xa1bc5c['type']===j['MERGE']){const _0x1e45d8=_0xa1bc5c;_0x1e45d8['source']['fromUser']?_0x3b87de=ku(_0x15e9fe,_0x1f9628,_0x1e45d8['path'],_0x1e45d8['children'],_0x3c07ff,_0x3dea68,_0x31b59f):(f(_0x1e45d8['source']['fromServer'],'Unknown\x20source.'),_0x338dcb=_0x1e45d8['source']['tagged']||_0x1f9628['serverCache']['isFiltered'](),_0x3b87de=bi(_0x15e9fe,_0x1f9628,_0x1e45d8['path'],_0x1e45d8['children'],_0x3c07ff,_0x3dea68,_0x338dcb,_0x31b59f));}else{if(_0xa1bc5c['type']===j['ACK_USER_WRITE']){const _0x57ec6b=_0xa1bc5c;_0x57ec6b['revert']?_0x3b87de=Ou(_0x15e9fe,_0x1f9628,_0x57ec6b['path'],_0x3c07ff,_0x3dea68,_0x31b59f):_0x3b87de=Nu(_0x15e9fe,_0x1f9628,_0x57ec6b['path'],_0x57ec6b['affectedTree'],_0x3c07ff,_0x3dea68,_0x31b59f);}else{if(_0xa1bc5c['type']===j['LISTEN_COMPLETE'])_0x3b87de=Pu(_0x15e9fe,_0x1f9628,_0xa1bc5c['path'],_0x3c07ff,_0x31b59f);else throw rt('Unknown\x20operation\x20type:\x20'+_0xa1bc5c['type']);}}}const _0x564d09=_0x31b59f['getChanges']();return Au(_0x1f9628,_0x3b87de,_0x564d09),{'viewCache':_0x3b87de,'changes':_0x564d09};}function Au(_0x4e66c7,_0x284cfb,_0x3e730e){const _0x1448f4=_0x284cfb['eventCache'];if(_0x1448f4['isFullyInitialized']()){const _0x3c2de6=_0x1448f4['getNode']()['isLeafNode']()||_0x1448f4['getNode']()['isEmpty'](),_0x355433=mn(_0x4e66c7);(_0x3e730e['length']>0x0||!_0x4e66c7['eventCache']['isFullyInitialized']()||_0x3c2de6&&!_0x1448f4['getNode']()['equals'](_0x355433)||!_0x1448f4['getNode']()['getPriority']()['equals'](_0x355433['getPriority']()))&&_0x3e730e['push'](Lo(mn(_0x284cfb)));}}function qo(_0x300d6b,_0x1f8f40,_0x16a00e,_0x3ed795,_0x4306a9,_0x41342d){const _0x1b71f5=_0x1f8f40['eventCache'];if(vn(_0x3ed795,_0x16a00e)!=null)return _0x1f8f40;{let _0x173f3f,_0x5479d5;if(v(_0x16a00e)){if(f(_0x1f8f40['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x1f8f40['serverCache']['isFiltered']()){const _0x2fb25f=We(_0x1f8f40),_0x363363=_0x2fb25f instanceof g?_0x2fb25f:g['EMPTY_NODE'],_0x5efe17=ns(_0x3ed795,_0x363363);_0x173f3f=_0x300d6b['filter']['updateFullNode'](_0x1f8f40['eventCache']['getNode'](),_0x5efe17,_0x41342d);}else{const _0x2935b9=yn(_0x3ed795,We(_0x1f8f40));_0x173f3f=_0x300d6b['filter']['updateFullNode'](_0x1f8f40['eventCache']['getNode'](),_0x2935b9,_0x41342d);}}else{const _0x11e004=y(_0x16a00e);if(_0x11e004==='.priority'){f(we(_0x16a00e)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x4d392e=_0x1b71f5['getNode']();_0x5479d5=_0x1f8f40['serverCache']['getNode']();const _0x543ac7=lr(_0x3ed795,_0x16a00e,_0x4d392e,_0x5479d5);_0x543ac7!=null?_0x173f3f=_0x300d6b['filter']['updatePriority'](_0x4d392e,_0x543ac7):_0x173f3f=_0x1b71f5['getNode']();}else{const _0x304448=b(_0x16a00e);let _0x189349;if(_0x1b71f5['isCompleteForChild'](_0x11e004)){_0x5479d5=_0x1f8f40['serverCache']['getNode']();const _0x195d36=lr(_0x3ed795,_0x16a00e,_0x1b71f5['getNode'](),_0x5479d5);_0x195d36!=null?_0x189349=_0x1b71f5['getNode']()['getImmediateChild'](_0x11e004)['updateChild'](_0x304448,_0x195d36):_0x189349=_0x1b71f5['getNode']()['getImmediateChild'](_0x11e004);}else _0x189349=is(_0x3ed795,_0x11e004,_0x1f8f40['serverCache']);_0x189349!=null?_0x173f3f=_0x300d6b['filter']['updateChild'](_0x1b71f5['getNode'](),_0x11e004,_0x189349,_0x304448,_0x4306a9,_0x41342d):_0x173f3f=_0x1b71f5['getNode']();}}return Tt(_0x1f8f40,_0x173f3f,_0x1b71f5['isFullyInitialized']()||v(_0x16a00e),_0x300d6b['filter']['filtersNodes']());}}function En(_0x16288d,_0x387121,_0xd4ddc4,_0x1d25bb,_0x2bc1aa,_0x4c4ba4,_0x36667b,_0x5c2a8d){const _0x3496eb=_0x387121['serverCache'];let _0x477ed0;const _0x9e6abb=_0x36667b?_0x16288d['filter']:_0x16288d['filter']['getIndexedFilter']();if(v(_0xd4ddc4))_0x477ed0=_0x9e6abb['updateFullNode'](_0x3496eb['getNode'](),_0x1d25bb,null);else{if(_0x9e6abb['filtersNodes']()&&!_0x3496eb['isFiltered']()){const _0x58fdb5=_0x3496eb['getNode']()['updateChild'](_0xd4ddc4,_0x1d25bb);_0x477ed0=_0x9e6abb['updateFullNode'](_0x3496eb['getNode'](),_0x58fdb5,null);}else{const _0x1ab552=y(_0xd4ddc4);if(!_0x3496eb['isCompleteForPath'](_0xd4ddc4)&&we(_0xd4ddc4)>0x1)return _0x387121;const _0x3a6ab7=b(_0xd4ddc4),_0x3f50f4=_0x3496eb['getNode']()['getImmediateChild'](_0x1ab552)['updateChild'](_0x3a6ab7,_0x1d25bb);_0x1ab552==='.priority'?_0x477ed0=_0x9e6abb['updatePriority'](_0x3496eb['getNode'](),_0x3f50f4):_0x477ed0=_0x9e6abb['updateChild'](_0x3496eb['getNode'](),_0x1ab552,_0x3f50f4,_0x3a6ab7,Go,null);}}const _0x978c2a=Uo(_0x387121,_0x477ed0,_0x3496eb['isFullyInitialized']()||v(_0xd4ddc4),_0x9e6abb['filtersNodes']()),_0x470987=new ss(_0x2bc1aa,_0x978c2a,_0x4c4ba4);return qo(_0x16288d,_0x978c2a,_0xd4ddc4,_0x2bc1aa,_0x470987,_0x5c2a8d);}function Si(_0x15bd91,_0x232e35,_0x54b47b,_0x1a32af,_0x4115bb,_0x257c09,_0x25f79a){const _0x300dde=_0x232e35['eventCache'];let _0x70c272,_0x1548c2;const _0x3ee0d9=new ss(_0x4115bb,_0x232e35,_0x257c09);if(v(_0x54b47b))_0x1548c2=_0x15bd91['filter']['updateFullNode'](_0x232e35['eventCache']['getNode'](),_0x1a32af,_0x25f79a),_0x70c272=Tt(_0x232e35,_0x1548c2,!0x0,_0x15bd91['filter']['filtersNodes']());else{const _0x32c3e5=y(_0x54b47b);if(_0x32c3e5==='.priority')_0x1548c2=_0x15bd91['filter']['updatePriority'](_0x232e35['eventCache']['getNode'](),_0x1a32af),_0x70c272=Tt(_0x232e35,_0x1548c2,_0x300dde['isFullyInitialized'](),_0x300dde['isFiltered']());else{const _0x4d3a27=b(_0x54b47b),_0xf9658c=_0x300dde['getNode']()['getImmediateChild'](_0x32c3e5);let _0x476d54;if(v(_0x4d3a27))_0x476d54=_0x1a32af;else{const _0xbfb836=_0x3ee0d9['getCompleteChild'](_0x32c3e5);_0xbfb836!=null?zi(_0x4d3a27)==='.priority'&&_0xbfb836['getChild'](Ro(_0x4d3a27))['isEmpty']()?_0x476d54=_0xbfb836:_0x476d54=_0xbfb836['updateChild'](_0x4d3a27,_0x1a32af):_0x476d54=g['EMPTY_NODE'];}if(_0xf9658c['equals'](_0x476d54))_0x70c272=_0x232e35;else{const _0xf3e16f=_0x15bd91['filter']['updateChild'](_0x300dde['getNode'](),_0x32c3e5,_0x476d54,_0x4d3a27,_0x3ee0d9,_0x25f79a);_0x70c272=Tt(_0x232e35,_0xf3e16f,_0x300dde['isFullyInitialized'](),_0x15bd91['filter']['filtersNodes']());}}}return _0x70c272;}function hr(_0x1fa6fc,_0x3837fd){return _0x1fa6fc['eventCache']['isCompleteForChild'](_0x3837fd);}function ku(_0x1bac1e,_0xb435db,_0x4fc3bc,_0x4b1ef0,_0x903f90,_0x2aa7e0,_0x53bc4a){let _0x40f819=_0xb435db;return _0x4b1ef0['foreach']((_0x5f36c0,_0x20d8c5)=>{const _0x28504c=k(_0x4fc3bc,_0x5f36c0);hr(_0xb435db,y(_0x28504c))&&(_0x40f819=Si(_0x1bac1e,_0x40f819,_0x28504c,_0x20d8c5,_0x903f90,_0x2aa7e0,_0x53bc4a));}),_0x4b1ef0['foreach']((_0x2ca54f,_0x5d5f6c)=>{const _0x58e6fc=k(_0x4fc3bc,_0x2ca54f);hr(_0xb435db,y(_0x58e6fc))||(_0x40f819=Si(_0x1bac1e,_0x40f819,_0x58e6fc,_0x5d5f6c,_0x903f90,_0x2aa7e0,_0x53bc4a));}),_0x40f819;}function ur(_0x4b8986,_0x29956f,_0x5103db){return _0x5103db['foreach']((_0x27eafa,_0x4b4626)=>{_0x29956f=_0x29956f['updateChild'](_0x27eafa,_0x4b4626);}),_0x29956f;}function bi(_0x16af8c,_0x2e70b3,_0x1f2f8b,_0x3aadff,_0x57b006,_0x3ea578,_0x4c6d68,_0x321c1f){if(_0x2e70b3['serverCache']['getNode']()['isEmpty']()&&!_0x2e70b3['serverCache']['isFullyInitialized']())return _0x2e70b3;let _0x3bf662=_0x2e70b3,_0x6e2ce4;v(_0x1f2f8b)?_0x6e2ce4=_0x3aadff:_0x6e2ce4=new S(null)['setTree'](_0x1f2f8b,_0x3aadff);const _0xeb7cf1=_0x2e70b3['serverCache']['getNode']();return _0x6e2ce4['children']['inorderTraversal']((_0x231aa2,_0x44f6e3)=>{if(_0xeb7cf1['hasChild'](_0x231aa2)){const _0x4fa5ad=_0x2e70b3['serverCache']['getNode']()['getImmediateChild'](_0x231aa2),_0x35de0f=ur(_0x16af8c,_0x4fa5ad,_0x44f6e3);_0x3bf662=En(_0x16af8c,_0x3bf662,new C(_0x231aa2),_0x35de0f,_0x57b006,_0x3ea578,_0x4c6d68,_0x321c1f);}}),_0x6e2ce4['children']['inorderTraversal']((_0x585ddc,_0x270aff)=>{const _0x56f5ac=!_0x2e70b3['serverCache']['isCompleteForChild'](_0x585ddc)&&_0x270aff['value']===null;if(!_0xeb7cf1['hasChild'](_0x585ddc)&&!_0x56f5ac){const _0x57e3d1=_0x2e70b3['serverCache']['getNode']()['getImmediateChild'](_0x585ddc),_0x42b35e=ur(_0x16af8c,_0x57e3d1,_0x270aff);_0x3bf662=En(_0x16af8c,_0x3bf662,new C(_0x585ddc),_0x42b35e,_0x57b006,_0x3ea578,_0x4c6d68,_0x321c1f);}}),_0x3bf662;}function Nu(_0x589f12,_0xdb2063,_0x5b905d,_0xf5317c,_0x136c3a,_0x22ab2b,_0x1ea9c9){if(vn(_0x136c3a,_0x5b905d)!=null)return _0xdb2063;const _0x66b8c2=_0xdb2063['serverCache']['isFiltered'](),_0x4f4c32=_0xdb2063['serverCache'];if(_0xf5317c['value']!=null){if(v(_0x5b905d)&&_0x4f4c32['isFullyInitialized']()||_0x4f4c32['isCompleteForPath'](_0x5b905d))return En(_0x589f12,_0xdb2063,_0x5b905d,_0x4f4c32['getNode']()['getChild'](_0x5b905d),_0x136c3a,_0x22ab2b,_0x66b8c2,_0x1ea9c9);if(v(_0x5b905d)){let _0x5e5ee0=new S(null);return _0x4f4c32['getNode']()['forEachChild'](ye,(_0x37379c,_0x1924a2)=>{_0x5e5ee0=_0x5e5ee0['set'](new C(_0x37379c),_0x1924a2);}),bi(_0x589f12,_0xdb2063,_0x5b905d,_0x5e5ee0,_0x136c3a,_0x22ab2b,_0x66b8c2,_0x1ea9c9);}else return _0xdb2063;}else{let _0x53f31c=new S(null);return _0xf5317c['foreach']((_0x2b1300,_0x3517ee)=>{const _0xc6260a=k(_0x5b905d,_0x2b1300);_0x4f4c32['isCompleteForPath'](_0xc6260a)&&(_0x53f31c=_0x53f31c['set'](_0x2b1300,_0x4f4c32['getNode']()['getChild'](_0xc6260a)));}),bi(_0x589f12,_0xdb2063,_0x5b905d,_0x53f31c,_0x136c3a,_0x22ab2b,_0x66b8c2,_0x1ea9c9);}}function Pu(_0x5ebb28,_0x1dfc3b,_0x46f91c,_0x287447,_0x1040fb){const _0x525a6e=_0x1dfc3b['serverCache'],_0x3ec956=Uo(_0x1dfc3b,_0x525a6e['getNode'](),_0x525a6e['isFullyInitialized']()||v(_0x46f91c),_0x525a6e['isFiltered']());return qo(_0x5ebb28,_0x3ec956,_0x46f91c,_0x287447,Go,_0x1040fb);}function Ou(_0x4fdc9b,_0x172439,_0x24952c,_0x1caa65,_0x4afe39,_0x819405){let _0x441d55;if(vn(_0x1caa65,_0x24952c)!=null)return _0x172439;{const _0x3ef64a=new ss(_0x1caa65,_0x172439,_0x4afe39),_0x4a1fcc=_0x172439['eventCache']['getNode']();let _0x9930f8;if(v(_0x24952c)||y(_0x24952c)==='.priority'){let _0x20b78f;if(_0x172439['serverCache']['isFullyInitialized']())_0x20b78f=yn(_0x1caa65,We(_0x172439));else{const _0x326ed1=_0x172439['serverCache']['getNode']();f(_0x326ed1 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x20b78f=ns(_0x1caa65,_0x326ed1);}_0x20b78f=_0x20b78f,_0x9930f8=_0x4fdc9b['filter']['updateFullNode'](_0x4a1fcc,_0x20b78f,_0x819405);}else{const _0x202a55=y(_0x24952c);let _0x31bfae=is(_0x1caa65,_0x202a55,_0x172439['serverCache']);_0x31bfae==null&&_0x172439['serverCache']['isCompleteForChild'](_0x202a55)&&(_0x31bfae=_0x4a1fcc['getImmediateChild'](_0x202a55)),_0x31bfae!=null?_0x9930f8=_0x4fdc9b['filter']['updateChild'](_0x4a1fcc,_0x202a55,_0x31bfae,b(_0x24952c),_0x3ef64a,_0x819405):_0x172439['eventCache']['getNode']()['hasChild'](_0x202a55)?_0x9930f8=_0x4fdc9b['filter']['updateChild'](_0x4a1fcc,_0x202a55,g['EMPTY_NODE'],b(_0x24952c),_0x3ef64a,_0x819405):_0x9930f8=_0x4a1fcc,_0x9930f8['isEmpty']()&&_0x172439['serverCache']['isFullyInitialized']()&&(_0x441d55=yn(_0x1caa65,We(_0x172439)),_0x441d55['isLeafNode']()&&(_0x9930f8=_0x4fdc9b['filter']['updateFullNode'](_0x9930f8,_0x441d55,_0x819405)));}return _0x441d55=_0x172439['serverCache']['isFullyInitialized']()||vn(_0x1caa65,w())!=null,Tt(_0x172439,_0x9930f8,_0x441d55,_0x4fdc9b['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x4f3e0c,_0x403da1){this['query_']=_0x4f3e0c,this['eventRegistrations_']=[];const _0x7eb453=this['query_']['_queryParams'],_0x38e1a0=new Ji(_0x7eb453['getIndex']()),_0x1deae7=Kh(_0x7eb453);this['processor_']=Su(_0x1deae7);const _0x281c6c=_0x403da1['serverCache'],_0xb9e0a0=_0x403da1['eventCache'],_0x450795=_0x38e1a0['updateFullNode'](g['EMPTY_NODE'],_0x281c6c['getNode'](),null),_0x297bcd=_0x1deae7['updateFullNode'](g['EMPTY_NODE'],_0xb9e0a0['getNode'](),null),_0x47c996=new Ce(_0x450795,_0x281c6c['isFullyInitialized'](),_0x38e1a0['filtersNodes']()),_0x252993=new Ce(_0x297bcd,_0xb9e0a0['isFullyInitialized'](),_0x1deae7['filtersNodes']());this['viewCache_']=Mn(_0x252993,_0x47c996),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x1d78c4){return _0x1d78c4['viewCache_']['serverCache']['getNode']();}function Lu(_0x5cb8b3){return mn(_0x5cb8b3['viewCache_']);}function xu(_0x4ffe08,_0x4f5b4b){const _0x202f7f=We(_0x4ffe08['viewCache_']);return _0x202f7f&&(_0x4ffe08['query']['_queryParams']['loadsAllData']()||!v(_0x4f5b4b)&&!_0x202f7f['getImmediateChild'](y(_0x4f5b4b))['isEmpty']())?_0x202f7f['getChild'](_0x4f5b4b):null;}function dr(_0x47043e){return _0x47043e['eventRegistrations_']['length']===0x0;}function Fu(_0x52cc8b,_0x3b49d2){_0x52cc8b['eventRegistrations_']['push'](_0x3b49d2);}function fr(_0x5a8520,_0x173b30,_0x549008){const _0x4b2916=[];if(_0x549008){f(_0x173b30==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x67ec36=_0x5a8520['query']['_path'];_0x5a8520['eventRegistrations_']['forEach'](_0x588fbc=>{const _0x399c7f=_0x588fbc['createCancelEvent'](_0x549008,_0x67ec36);_0x399c7f&&_0x4b2916['push'](_0x399c7f);});}if(_0x173b30){let _0x33d61d=[];for(let _0x587615=0x0;_0x587615<_0x5a8520['eventRegistrations_']['length'];++_0x587615){const _0x294037=_0x5a8520['eventRegistrations_'][_0x587615];if(!_0x294037['matches'](_0x173b30))_0x33d61d['push'](_0x294037);else{if(_0x173b30['hasAnyCallback']()){_0x33d61d=_0x33d61d['concat'](_0x5a8520['eventRegistrations_']['slice'](_0x587615+0x1));break;}}}_0x5a8520['eventRegistrations_']=_0x33d61d;}else _0x5a8520['eventRegistrations_']=[];return _0x4b2916;}function pr(_0x16c66d,_0x2c6f5d,_0x1e4718,_0x5c9218){_0x2c6f5d['type']===j['MERGE']&&_0x2c6f5d['source']['queryId']!==null&&(f(We(_0x16c66d['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x16c66d['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x5306aa=_0x16c66d['viewCache_'],_0x38e69f=Ru(_0x16c66d['processor_'],_0x5306aa,_0x2c6f5d,_0x1e4718,_0x5c9218);return bu(_0x16c66d['processor_'],_0x38e69f['viewCache']),f(_0x38e69f['viewCache']['serverCache']['isFullyInitialized']()||!_0x5306aa['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x16c66d['viewCache_']=_0x38e69f['viewCache'],zo(_0x16c66d,_0x38e69f['changes'],_0x38e69f['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x805b19,_0x2409fb){const _0xae5717=_0x805b19['viewCache_']['eventCache'],_0x16b0ee=[];return _0xae5717['getNode']()['isLeafNode']()||_0xae5717['getNode']()['forEachChild'](R,(_0x5ee8ee,_0xa22765)=>{_0x16b0ee['push'](et(_0x5ee8ee,_0xa22765));}),_0xae5717['isFullyInitialized']()&&_0x16b0ee['push'](Lo(_0xae5717['getNode']())),zo(_0x805b19,_0x16b0ee,_0xae5717['getNode'](),_0x2409fb);}function zo(_0x5a57f1,_0x21a7e9,_0x52476b,_0x4eb8cd){const _0x5b263d=_0x4eb8cd?[_0x4eb8cd]:_0x5a57f1['eventRegistrations_'];return ru(_0x5a57f1['eventGenerator_'],_0x21a7e9,_0x52476b,_0x5b263d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x335b67){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x335b67;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x94953f){return _0x94953f['views']['size']===0x0;}function rs(_0x160c29,_0x4bb552,_0x838403,_0x4282da){const _0x3d970c=_0x4bb552['source']['queryId'];if(_0x3d970c!==null){const _0x29efae=_0x160c29['views']['get'](_0x3d970c);return f(_0x29efae!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x29efae,_0x4bb552,_0x838403,_0x4282da);}else{let _0x2c214a=[];for(const _0xb371cc of _0x160c29['views']['values']())_0x2c214a=_0x2c214a['concat'](pr(_0xb371cc,_0x4bb552,_0x838403,_0x4282da));return _0x2c214a;}}function Ko(_0x5cc76c,_0x15db3a,_0x1cf265,_0x558604,_0x3cc56e){const _0x2e35c3=_0x15db3a['_queryIdentifier'],_0x82f64f=_0x5cc76c['views']['get'](_0x2e35c3);if(!_0x82f64f){let _0xad5bc0=yn(_0x1cf265,_0x3cc56e?_0x558604:null),_0x46feac=!0x1;_0xad5bc0?_0x46feac=!0x0:_0x558604 instanceof g?(_0xad5bc0=ns(_0x1cf265,_0x558604),_0x46feac=!0x1):(_0xad5bc0=g['EMPTY_NODE'],_0x46feac=!0x1);const _0x2fa9ea=Mn(new Ce(_0xad5bc0,_0x46feac,!0x1),new Ce(_0x558604,_0x3cc56e,!0x1));return new Du(_0x15db3a,_0x2fa9ea);}return _0x82f64f;}function Hu(_0x434436,_0x590724,_0x8a35e1,_0x242e05,_0xd9ef68,_0x4ff305){const _0x2ab776=Ko(_0x434436,_0x590724,_0x242e05,_0xd9ef68,_0x4ff305);return _0x434436['views']['has'](_0x590724['_queryIdentifier'])||_0x434436['views']['set'](_0x590724['_queryIdentifier'],_0x2ab776),Fu(_0x2ab776,_0x8a35e1),Uu(_0x2ab776,_0x8a35e1);}function $u(_0x831335,_0x51e3ea,_0x39b7b6,_0x5a92c6){const _0xf51a2a=_0x51e3ea['_queryIdentifier'],_0x767910=[];let _0x4a085c=[];const _0x5795a9=Te(_0x831335);if(_0xf51a2a==='default'){for(const [_0x4e7df3,_0x921047]of _0x831335['views']['entries']())_0x4a085c=_0x4a085c['concat'](fr(_0x921047,_0x39b7b6,_0x5a92c6)),dr(_0x921047)&&(_0x831335['views']['delete'](_0x4e7df3),_0x921047['query']['_queryParams']['loadsAllData']()||_0x767910['push'](_0x921047['query']));}else{const _0x18abd7=_0x831335['views']['get'](_0xf51a2a);_0x18abd7&&(_0x4a085c=_0x4a085c['concat'](fr(_0x18abd7,_0x39b7b6,_0x5a92c6)),dr(_0x18abd7)&&(_0x831335['views']['delete'](_0xf51a2a),_0x18abd7['query']['_queryParams']['loadsAllData']()||_0x767910['push'](_0x18abd7['query'])));}return _0x5795a9&&!Te(_0x831335)&&_0x767910['push'](new(Bu())(_0x51e3ea['_repo'],_0x51e3ea['_path'])),{'removed':_0x767910,'events':_0x4a085c};}function Yo(_0x5c330e){const _0x8ad010=[];for(const _0x2200d2 of _0x5c330e['views']['values']())_0x2200d2['query']['_queryParams']['loadsAllData']()||_0x8ad010['push'](_0x2200d2);return _0x8ad010;}function Ee(_0x470a10,_0x103713){let _0x4254c4=null;for(const _0x14b96e of _0x470a10['views']['values']())_0x4254c4=_0x4254c4||xu(_0x14b96e,_0x103713);return _0x4254c4;}function Qo(_0x4facff,_0x5d4a7b){if(_0x5d4a7b['_queryParams']['loadsAllData']())return xn(_0x4facff);{const _0x241c09=_0x5d4a7b['_queryIdentifier'];return _0x4facff['views']['get'](_0x241c09);}}function Jo(_0x1aaea3,_0x90219d){return Qo(_0x1aaea3,_0x90219d)!=null;}function Te(_0x123e83){return xn(_0x123e83)!=null;}function xn(_0x5bfe41){for(const _0x4e0a50 of _0x5bfe41['views']['values']())if(_0x4e0a50['query']['_queryParams']['loadsAllData']())return _0x4e0a50;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x1126ae){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x1126ae;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x54fc47){this['listenProvider_']=_0x54fc47,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x2154ce,_0x174594,_0x53a814,_0x3abc40,_0x388bad){return lu(_0x2154ce['pendingWriteTree_'],_0x174594,_0x53a814,_0x3abc40,_0x388bad),_0x388bad?ut(_0x2154ce,new Ue(Zi(),_0x174594,_0x53a814)):[];}function ju(_0x4ec822,_0x252909,_0x1fe438,_0x4f1b14){hu(_0x4ec822['pendingWriteTree_'],_0x252909,_0x1fe438,_0x4f1b14);const _0xe8c7b=S['fromObject'](_0x1fe438);return ut(_0x4ec822,new tt(Zi(),_0x252909,_0xe8c7b));}function pe(_0x815ecf,_0x10d22b,_0x218f55=!0x1){const _0x28fafe=uu(_0x815ecf['pendingWriteTree_'],_0x10d22b);if(du(_0x815ecf['pendingWriteTree_'],_0x10d22b)){let _0x404d98=new S(null);return _0x28fafe['snap']!=null?_0x404d98=_0x404d98['set'](w(),!0x0):x(_0x28fafe['children'],_0x571928=>{_0x404d98=_0x404d98['set'](new C(_0x571928),!0x0);}),ut(_0x815ecf,new gn(_0x28fafe['path'],_0x404d98,_0x218f55));}else return[];}function Gt(_0x388f82,_0x35b32b,_0x5549cb){return ut(_0x388f82,new Ue(es(),_0x35b32b,_0x5549cb));}function Ku(_0x122e47,_0x201e60,_0x3ab5d4){const _0x1770f2=S['fromObject'](_0x3ab5d4);return ut(_0x122e47,new tt(es(),_0x201e60,_0x1770f2));}function Yu(_0x58e703,_0x25a042){return ut(_0x58e703,new Lt(es(),_0x25a042));}function Qu(_0x4f5236,_0x356b6d,_0x5212de){const _0x2c26bf=as(_0x4f5236,_0x5212de);if(_0x2c26bf){const _0x53f9d6=cs(_0x2c26bf),_0x272e96=_0x53f9d6['path'],_0x414e95=_0x53f9d6['queryId'],_0x47a79d=F(_0x272e96,_0x356b6d),_0x12dfde=new Lt(ts(_0x414e95),_0x47a79d);return ls(_0x4f5236,_0x272e96,_0x12dfde);}else return[];}function Cn(_0x348dc0,_0x210694,_0x139889,_0x4bb260,_0x8061b4=!0x1){const _0x435630=_0x210694['_path'],_0x38b70a=_0x348dc0['syncPointTree_']['get'](_0x435630);let _0x31ed0e=[];if(_0x38b70a&&(_0x210694['_queryIdentifier']==='default'||Jo(_0x38b70a,_0x210694))){const _0x258c71=$u(_0x38b70a,_0x210694,_0x139889,_0x4bb260);Vu(_0x38b70a)&&(_0x348dc0['syncPointTree_']=_0x348dc0['syncPointTree_']['remove'](_0x435630));const _0x4e8ff1=_0x258c71['removed'];if(_0x31ed0e=_0x258c71['events'],!_0x8061b4){const _0x3adc5e=_0x4e8ff1['findIndex'](_0x1efc91=>_0x1efc91['_queryParams']['loadsAllData']())!==-0x1,_0x57cd24=_0x348dc0['syncPointTree_']['findOnPath'](_0x435630,(_0x2a3de0,_0x485286)=>Te(_0x485286));if(_0x3adc5e&&!_0x57cd24){const _0x3c8d2a=_0x348dc0['syncPointTree_']['subtree'](_0x435630);if(!_0x3c8d2a['isEmpty']()){const _0x9533b7=Zu(_0x3c8d2a);for(let _0x581aa6=0x0;_0x581aa6<_0x9533b7['length'];++_0x581aa6){const _0x51b1bf=_0x9533b7[_0x581aa6],_0x2c9048=_0x51b1bf['query'],_0x2190b=ta(_0x348dc0,_0x51b1bf);_0x348dc0['listenProvider_']['startListening'](bt(_0x2c9048),xt(_0x348dc0,_0x2c9048),_0x2190b['hashFn'],_0x2190b['onComplete']);}}}!_0x57cd24&&_0x4e8ff1['length']>0x0&&!_0x4bb260&&(_0x3adc5e?_0x348dc0['listenProvider_']['stopListening'](bt(_0x210694),null):_0x4e8ff1['forEach'](_0x3392e4=>{const _0x4ec5b8=_0x348dc0['queryToTagMap']['get'](Un(_0x3392e4));_0x348dc0['listenProvider_']['stopListening'](bt(_0x3392e4),_0x4ec5b8);}));}ed(_0x348dc0,_0x4e8ff1);}return _0x31ed0e;}function Xo(_0x17da9e,_0x32e1cb,_0x5c6a4c,_0x2c8af5){const _0x33b598=as(_0x17da9e,_0x2c8af5);if(_0x33b598!=null){const _0x19fbe2=cs(_0x33b598),_0x599ba8=_0x19fbe2['path'],_0x5b37bb=_0x19fbe2['queryId'],_0xbab039=F(_0x599ba8,_0x32e1cb),_0x47dd23=new Ue(ts(_0x5b37bb),_0xbab039,_0x5c6a4c);return ls(_0x17da9e,_0x599ba8,_0x47dd23);}else return[];}function Ju(_0x1c1d72,_0x1467dc,_0x10887c,_0x1033e5){const _0xa7bd19=as(_0x1c1d72,_0x1033e5);if(_0xa7bd19){const _0xd7b62f=cs(_0xa7bd19),_0xf7a8ef=_0xd7b62f['path'],_0x125eab=_0xd7b62f['queryId'],_0x267a5f=F(_0xf7a8ef,_0x1467dc),_0x3c4acd=S['fromObject'](_0x10887c),_0x3c8f1f=new tt(ts(_0x125eab),_0x267a5f,_0x3c4acd);return ls(_0x1c1d72,_0xf7a8ef,_0x3c8f1f);}else return[];}function Ri(_0x1289e4,_0x7f413,_0xc3ca06,_0x118f98=!0x1){const _0xeadb31=_0x7f413['_path'];let _0x22cb8e=null,_0x5eca71=!0x1;_0x1289e4['syncPointTree_']['foreachOnPath'](_0xeadb31,(_0x300b74,_0x376208)=>{const _0x2f4b1a=F(_0x300b74,_0xeadb31);_0x22cb8e=_0x22cb8e||Ee(_0x376208,_0x2f4b1a),_0x5eca71=_0x5eca71||Te(_0x376208);});let _0x1b1664=_0x1289e4['syncPointTree_']['get'](_0xeadb31);_0x1b1664?(_0x5eca71=_0x5eca71||Te(_0x1b1664),_0x22cb8e=_0x22cb8e||Ee(_0x1b1664,w())):(_0x1b1664=new jo(),_0x1289e4['syncPointTree_']=_0x1289e4['syncPointTree_']['set'](_0xeadb31,_0x1b1664));let _0x186d12;_0x22cb8e!=null?_0x186d12=!0x0:(_0x186d12=!0x1,_0x22cb8e=g['EMPTY_NODE'],_0x1289e4['syncPointTree_']['subtree'](_0xeadb31)['foreachChild']((_0x415a5c,_0x58d7e5)=>{const _0x5ec807=Ee(_0x58d7e5,w());_0x5ec807&&(_0x22cb8e=_0x22cb8e['updateImmediateChild'](_0x415a5c,_0x5ec807));}));const _0x38acb2=Jo(_0x1b1664,_0x7f413);if(!_0x38acb2&&!_0x7f413['_queryParams']['loadsAllData']()){const _0x52de55=Un(_0x7f413);f(!_0x1289e4['queryToTagMap']['has'](_0x52de55),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x418685=td();_0x1289e4['queryToTagMap']['set'](_0x52de55,_0x418685),_0x1289e4['tagToQueryMap']['set'](_0x418685,_0x52de55);}const _0x43dd10=Ln(_0x1289e4['pendingWriteTree_'],_0xeadb31);let _0xb70c35=Hu(_0x1b1664,_0x7f413,_0xc3ca06,_0x43dd10,_0x22cb8e,_0x186d12);if(!_0x38acb2&&!_0x5eca71&&!_0x118f98){const _0x5e58cd=Qo(_0x1b1664,_0x7f413);_0xb70c35=_0xb70c35['concat'](nd(_0x1289e4,_0x7f413,_0x5e58cd));}return _0xb70c35;}function Fn(_0x178edc,_0x1a8ae7,_0x41ee71){const _0x2c1fbc=_0x178edc['pendingWriteTree_'],_0x15c9eb=_0x178edc['syncPointTree_']['findOnPath'](_0x1a8ae7,(_0x2a7675,_0x23f8a8)=>{const _0x5aa7ac=F(_0x2a7675,_0x1a8ae7),_0x1b0618=Ee(_0x23f8a8,_0x5aa7ac);if(_0x1b0618)return _0x1b0618;});return Vo(_0x2c1fbc,_0x1a8ae7,_0x15c9eb,_0x41ee71,!0x0);}function Xu(_0x2c2b37,_0x38ac69){const _0x14d68b=_0x38ac69['_path'];let _0xb5ea4f=null;_0x2c2b37['syncPointTree_']['foreachOnPath'](_0x14d68b,(_0x1d7f08,_0x4b4f9e)=>{const _0x48a9c0=F(_0x1d7f08,_0x14d68b);_0xb5ea4f=_0xb5ea4f||Ee(_0x4b4f9e,_0x48a9c0);});let _0x220258=_0x2c2b37['syncPointTree_']['get'](_0x14d68b);_0x220258?_0xb5ea4f=_0xb5ea4f||Ee(_0x220258,w()):(_0x220258=new jo(),_0x2c2b37['syncPointTree_']=_0x2c2b37['syncPointTree_']['set'](_0x14d68b,_0x220258));const _0x181698=_0xb5ea4f!=null,_0x5d560d=_0x181698?new Ce(_0xb5ea4f,!0x0,!0x1):null,_0xcd581=Ln(_0x2c2b37['pendingWriteTree_'],_0x38ac69['_path']),_0x637634=Ko(_0x220258,_0x38ac69,_0xcd581,_0x181698?_0x5d560d['getNode']():g['EMPTY_NODE'],_0x181698);return Lu(_0x637634);}function ut(_0x4c12c6,_0x5d0f34){return Zo(_0x5d0f34,_0x4c12c6['syncPointTree_'],null,Ln(_0x4c12c6['pendingWriteTree_'],w()));}function Zo(_0x24805c,_0x2218d7,_0x573064,_0x52eb1d){if(v(_0x24805c['path']))return ea(_0x24805c,_0x2218d7,_0x573064,_0x52eb1d);{const _0x15ea8c=_0x2218d7['get'](w());_0x573064==null&&_0x15ea8c!=null&&(_0x573064=Ee(_0x15ea8c,w()));let _0x5c22cf=[];const _0x47f72c=y(_0x24805c['path']),_0x338470=_0x24805c['operationForChild'](_0x47f72c),_0x524f2c=_0x2218d7['children']['get'](_0x47f72c);if(_0x524f2c&&_0x338470){const _0x3fc7b2=_0x573064?_0x573064['getImmediateChild'](_0x47f72c):null,_0x439f99=Ho(_0x52eb1d,_0x47f72c);_0x5c22cf=_0x5c22cf['concat'](Zo(_0x338470,_0x524f2c,_0x3fc7b2,_0x439f99));}return _0x15ea8c&&(_0x5c22cf=_0x5c22cf['concat'](rs(_0x15ea8c,_0x24805c,_0x52eb1d,_0x573064))),_0x5c22cf;}}function ea(_0x1584e4,_0x43ae20,_0x1c929b,_0x1a9386){const _0x383478=_0x43ae20['get'](w());_0x1c929b==null&&_0x383478!=null&&(_0x1c929b=Ee(_0x383478,w()));let _0x4cbf60=[];return _0x43ae20['children']['inorderTraversal']((_0x13402e,_0x2f2bbd)=>{const _0xb46350=_0x1c929b?_0x1c929b['getImmediateChild'](_0x13402e):null,_0x4dcd11=Ho(_0x1a9386,_0x13402e),_0xaa19d3=_0x1584e4['operationForChild'](_0x13402e);_0xaa19d3&&(_0x4cbf60=_0x4cbf60['concat'](ea(_0xaa19d3,_0x2f2bbd,_0xb46350,_0x4dcd11)));}),_0x383478&&(_0x4cbf60=_0x4cbf60['concat'](rs(_0x383478,_0x1584e4,_0x1a9386,_0x1c929b))),_0x4cbf60;}function ta(_0x129e8f,_0x36b1dc){const _0x4de097=_0x36b1dc['query'],_0x1f6488=xt(_0x129e8f,_0x4de097);return{'hashFn':()=>(Mu(_0x36b1dc)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x5cb00b=>{if(_0x5cb00b==='ok')return _0x1f6488?Qu(_0x129e8f,_0x4de097['_path'],_0x1f6488):Yu(_0x129e8f,_0x4de097['_path']);{const _0x4161be=Kl(_0x5cb00b,_0x4de097);return Cn(_0x129e8f,_0x4de097,null,_0x4161be);}}};}function xt(_0x137629,_0x4a8ab2){const _0x5b86b5=Un(_0x4a8ab2);return _0x137629['queryToTagMap']['get'](_0x5b86b5);}function Un(_0x4824d0){return _0x4824d0['_path']['toString']()+'$'+_0x4824d0['_queryIdentifier'];}function as(_0x35ab47,_0x35c708){return _0x35ab47['tagToQueryMap']['get'](_0x35c708);}function cs(_0xcd7863){const _0x21e647=_0xcd7863['indexOf']('$');return f(_0x21e647!==-0x1&&_0x21e647<_0xcd7863['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0xcd7863['substr'](_0x21e647+0x1),'path':new C(_0xcd7863['substr'](0x0,_0x21e647))};}function ls(_0x26eb09,_0x14b5f2,_0xfe15ea){const _0x4c104e=_0x26eb09['syncPointTree_']['get'](_0x14b5f2);f(_0x4c104e,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x43e208=Ln(_0x26eb09['pendingWriteTree_'],_0x14b5f2);return rs(_0x4c104e,_0xfe15ea,_0x43e208,null);}function Zu(_0x432f21){return _0x432f21['fold']((_0x197cc9,_0x264414,_0xbfb673)=>{if(_0x264414&&Te(_0x264414))return[xn(_0x264414)];{let _0x365e26=[];return _0x264414&&(_0x365e26=Yo(_0x264414)),x(_0xbfb673,(_0x7cc36d,_0x2c2dce)=>{_0x365e26=_0x365e26['concat'](_0x2c2dce);}),_0x365e26;}});}function bt(_0x2db0e9){return _0x2db0e9['_queryParams']['loadsAllData']()&&!_0x2db0e9['_queryParams']['isDefault']()?new(qu())(_0x2db0e9['_repo'],_0x2db0e9['_path']):_0x2db0e9;}function ed(_0x4d3966,_0x1154f0){for(let _0xf52422=0x0;_0xf52422<_0x1154f0['length'];++_0xf52422){const _0x7c7e95=_0x1154f0[_0xf52422];if(!_0x7c7e95['_queryParams']['loadsAllData']()){const _0x4bd067=Un(_0x7c7e95),_0x5f4a8f=_0x4d3966['queryToTagMap']['get'](_0x4bd067);_0x4d3966['queryToTagMap']['delete'](_0x4bd067),_0x4d3966['tagToQueryMap']['delete'](_0x5f4a8f);}}}function td(){return zu++;}function nd(_0x562ae2,_0x2f7362,_0x195aec){const _0x31d3d4=_0x2f7362['_path'],_0x26596d=xt(_0x562ae2,_0x2f7362),_0xba219a=ta(_0x562ae2,_0x195aec),_0x1de3d1=_0x562ae2['listenProvider_']['startListening'](bt(_0x2f7362),_0x26596d,_0xba219a['hashFn'],_0xba219a['onComplete']),_0x3b3d17=_0x562ae2['syncPointTree_']['subtree'](_0x31d3d4);if(_0x26596d)f(!Te(_0x3b3d17['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x2ea2f0=_0x3b3d17['fold']((_0x53795e,_0x232eeb,_0x528f54)=>{if(!v(_0x53795e)&&_0x232eeb&&Te(_0x232eeb))return[xn(_0x232eeb)['query']];{let _0x2c5495=[];return _0x232eeb&&(_0x2c5495=_0x2c5495['concat'](Yo(_0x232eeb)['map'](_0x2f0c79=>_0x2f0c79['query']))),x(_0x528f54,(_0x37e37a,_0x4dd781)=>{_0x2c5495=_0x2c5495['concat'](_0x4dd781);}),_0x2c5495;}});for(let _0x372869=0x0;_0x372869<_0x2ea2f0['length'];++_0x372869){const _0x1fa49d=_0x2ea2f0[_0x372869];_0x562ae2['listenProvider_']['stopListening'](bt(_0x1fa49d),xt(_0x562ae2,_0x1fa49d));}}return _0x1de3d1;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x296247){this['node_']=_0x296247;}['getImmediateChild'](_0x52a48f){const _0x44bf56=this['node_']['getImmediateChild'](_0x52a48f);return new hs(_0x44bf56);}['node'](){return this['node_'];}}class us{constructor(_0x32a7fa,_0x16c42b){this['syncTree_']=_0x32a7fa,this['path_']=_0x16c42b;}['getImmediateChild'](_0x3329cd){const _0x1be882=k(this['path_'],_0x3329cd);return new us(this['syncTree_'],_0x1be882);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0xbb2eb5){return _0xbb2eb5=_0xbb2eb5||{},_0xbb2eb5['timestamp']=_0xbb2eb5['timestamp']||new Date()['getTime'](),_0xbb2eb5;},gr=function(_0x2d2c64,_0x527401,_0x435a99){if(!_0x2d2c64||typeof _0x2d2c64!='object')return _0x2d2c64;if(f('.sv'in _0x2d2c64,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x2d2c64['.sv']=='string')return sd(_0x2d2c64['.sv'],_0x527401,_0x435a99);if(typeof _0x2d2c64['.sv']=='object')return rd(_0x2d2c64['.sv'],_0x527401);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x2d2c64,null,0x2));},sd=function(_0x2afdc2,_0x4df81c,_0x1f4683){switch(_0x2afdc2){case'timestamp':return _0x1f4683['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x2afdc2);}},rd=function(_0x6a5808,_0x571691,_0x55d182){_0x6a5808['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x6a5808,null,0x2));const _0x4c7bb1=_0x6a5808['increment'];typeof _0x4c7bb1!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x4c7bb1);const _0x4cbc6a=_0x571691['node']();if(f(_0x4cbc6a!==null&&typeof _0x4cbc6a<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x4cbc6a['isLeafNode']())return _0x4c7bb1;const _0x4652c3=_0x4cbc6a['getValue']();return typeof _0x4652c3!='number'?_0x4c7bb1:_0x4652c3+_0x4c7bb1;},na=function(_0x33d72b,_0x4552a6,_0x2e2fbf,_0x269796){return fs(_0x4552a6,new us(_0x2e2fbf,_0x33d72b),_0x269796);},ds=function(_0x33c403,_0x5efc3c,_0x3c6fb0){return fs(_0x33c403,new hs(_0x5efc3c),_0x3c6fb0);};function fs(_0x107e01,_0x216b65,_0x148003){const _0x33e589=_0x107e01['getPriority']()['val'](),_0x2dd76d=gr(_0x33e589,_0x216b65['getImmediateChild']('.priority'),_0x148003);let _0x20f696;if(_0x107e01['isLeafNode']()){const _0x41806c=_0x107e01,_0x18f4ef=gr(_0x41806c['getValue'](),_0x216b65,_0x148003);return _0x18f4ef!==_0x41806c['getValue']()||_0x2dd76d!==_0x41806c['getPriority']()['val']()?new D(_0x18f4ef,P(_0x2dd76d)):_0x107e01;}else{const _0x13fe14=_0x107e01;return _0x20f696=_0x13fe14,_0x2dd76d!==_0x13fe14['getPriority']()['val']()&&(_0x20f696=_0x20f696['updatePriority'](new D(_0x2dd76d))),_0x13fe14['forEachChild'](R,(_0x5f1e17,_0x3c2f89)=>{const _0x50b4cd=fs(_0x3c2f89,_0x216b65['getImmediateChild'](_0x5f1e17),_0x148003);_0x50b4cd!==_0x3c2f89&&(_0x20f696=_0x20f696['updateImmediateChild'](_0x5f1e17,_0x50b4cd));}),_0x20f696;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x1c65a1='',_0x5c02e2=null,_0xa88f67={'children':{},'childCount':0x0}){this['name']=_0x1c65a1,this['parent']=_0x5c02e2,this['node']=_0xa88f67;}}function Wn(_0xe2c2ef,_0xf923da){let _0x16de11=_0xf923da instanceof C?_0xf923da:new C(_0xf923da),_0x1c3c53=_0xe2c2ef,_0xa56a23=y(_0x16de11);for(;_0xa56a23!==null;){const _0x392f8e=De(_0x1c3c53['node']['children'],_0xa56a23)||{'children':{},'childCount':0x0};_0x1c3c53=new ps(_0xa56a23,_0x1c3c53,_0x392f8e),_0x16de11=b(_0x16de11),_0xa56a23=y(_0x16de11);}return _0x1c3c53;}function Ge(_0x568cf3){return _0x568cf3['node']['value'];}function _s(_0x14e078,_0x43452e){_0x14e078['node']['value']=_0x43452e,Ai(_0x14e078);}function ia(_0x446cb7){return _0x446cb7['node']['childCount']>0x0;}function od(_0x27fae7){return Ge(_0x27fae7)===void 0x0&&!ia(_0x27fae7);}function Bn(_0x372a4a,_0x54deac){x(_0x372a4a['node']['children'],(_0x1385ff,_0x4c4cd5)=>{_0x54deac(new ps(_0x1385ff,_0x372a4a,_0x4c4cd5));});}function sa(_0x51123e,_0xea9d13,_0x2a912e,_0x59eb85){_0x2a912e&&_0xea9d13(_0x51123e),Bn(_0x51123e,_0x15933e=>{sa(_0x15933e,_0xea9d13,!0x0);});}function ad(_0x4ab08a,_0x28bbb2,_0x3d3ee9){let _0x1cf3f1=_0x4ab08a['parent'];for(;_0x1cf3f1!==null;){if(_0x28bbb2(_0x1cf3f1))return!0x0;_0x1cf3f1=_0x1cf3f1['parent'];}return!0x1;}function qt(_0x471a37){return new C(_0x471a37['parent']===null?_0x471a37['name']:qt(_0x471a37['parent'])+'/'+_0x471a37['name']);}function Ai(_0x22ea61){_0x22ea61['parent']!==null&&cd(_0x22ea61['parent'],_0x22ea61['name'],_0x22ea61);}function cd(_0x11e8b6,_0x294b87,_0x6a22b7){const _0x4cc7cb=od(_0x6a22b7),_0x10eb35=J(_0x11e8b6['node']['children'],_0x294b87);_0x4cc7cb&&_0x10eb35?(delete _0x11e8b6['node']['children'][_0x294b87],_0x11e8b6['node']['childCount']--,Ai(_0x11e8b6)):!_0x4cc7cb&&!_0x10eb35&&(_0x11e8b6['node']['children'][_0x294b87]=_0x6a22b7['node'],_0x11e8b6['node']['childCount']++,Ai(_0x11e8b6));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x1ec657){return typeof _0x1ec657=='string'&&_0x1ec657['length']!==0x0&&!ld['test'](_0x1ec657);},ra=function(_0x3bec77){return typeof _0x3bec77=='string'&&_0x3bec77['length']!==0x0&&!hd['test'](_0x3bec77);},ud=function(_0x3bb15b){return _0x3bb15b&&(_0x3bb15b=_0x3bb15b['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x3bb15b);},Tn=function(_0x3439f2){return _0x3439f2===null||typeof _0x3439f2=='string'||typeof _0x3439f2=='number'&&!Vi(_0x3439f2)||_0x3439f2&&typeof _0x3439f2=='object'&&J(_0x3439f2,'.sv');},zt=function(_0x21d551,_0x4a7281,_0xbe9eb9,_0x5abb36){_0x5abb36&&_0x4a7281===void 0x0||jt(Pn(_0x21d551,'value'),_0x4a7281,_0xbe9eb9);},jt=function(_0x59eb62,_0x367ec8,_0x35f78e){const _0x384805=_0x35f78e instanceof C?new Ah(_0x35f78e,_0x59eb62):_0x35f78e;if(_0x367ec8===void 0x0)throw new Error(_0x59eb62+'contains\x20undefined\x20'+Pe(_0x384805));if(typeof _0x367ec8=='function')throw new Error(_0x59eb62+'contains\x20a\x20function\x20'+Pe(_0x384805)+'\x20with\x20contents\x20=\x20'+_0x367ec8['toString']());if(Vi(_0x367ec8))throw new Error(_0x59eb62+'contains\x20'+_0x367ec8['toString']()+'\x20'+Pe(_0x384805));if(typeof _0x367ec8=='string'&&_0x367ec8['length']>ai/0x3&&On(_0x367ec8)>ai)throw new Error(_0x59eb62+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x384805)+'\x20(\x27'+_0x367ec8['substring'](0x0,0x32)+'...\x27)');if(_0x367ec8&&typeof _0x367ec8=='object'){let _0x56666b=!0x1,_0xfc72f2=!0x1;if(x(_0x367ec8,(_0x56ed63,_0x3cfe3e)=>{if(_0x56ed63==='.value')_0x56666b=!0x0;else{if(_0x56ed63!=='.priority'&&_0x56ed63!=='.sv'&&(_0xfc72f2=!0x0,!gs(_0x56ed63)))throw new Error(_0x59eb62+'\x20contains\x20an\x20invalid\x20key\x20('+_0x56ed63+')\x20'+Pe(_0x384805)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x384805,_0x56ed63),jt(_0x59eb62,_0x3cfe3e,_0x384805),Nh(_0x384805);}),_0x56666b&&_0xfc72f2)throw new Error(_0x59eb62+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x384805)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x1d67f7,_0x256289){let _0x1d101d,_0x566b7f;for(_0x1d101d=0x0;_0x1d101d<_0x256289['length'];_0x1d101d++){_0x566b7f=_0x256289[_0x1d101d];const _0x3a3ff3=Pt(_0x566b7f);for(let _0x55de51=0x0;_0x55de51<_0x3a3ff3['length'];_0x55de51++)if(!(_0x3a3ff3[_0x55de51]==='.priority'&&_0x55de51===_0x3a3ff3['length']-0x1)){if(!gs(_0x3a3ff3[_0x55de51]))throw new Error(_0x1d67f7+'contains\x20an\x20invalid\x20key\x20('+_0x3a3ff3[_0x55de51]+')\x20in\x20path\x20'+_0x566b7f['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x256289['sort'](Rh);let _0x3c01a6=null;for(_0x1d101d=0x0;_0x1d101d<_0x256289['length'];_0x1d101d++){if(_0x566b7f=_0x256289[_0x1d101d],_0x3c01a6!==null&&G(_0x3c01a6,_0x566b7f))throw new Error(_0x1d67f7+'contains\x20a\x20path\x20'+_0x3c01a6['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x566b7f['toString']());_0x3c01a6=_0x566b7f;}},fd=function(_0x303b3b,_0x309ac9,_0x358618,_0x5e42e7){const _0x23a96a=Pn(_0x303b3b,'values');if(!(_0x309ac9&&typeof _0x309ac9=='object')||Array['isArray'](_0x309ac9))throw new Error(_0x23a96a+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x4620ef=[];x(_0x309ac9,(_0x1c699c,_0x3bfe85)=>{const _0x2c9603=new C(_0x1c699c);if(jt(_0x23a96a,_0x3bfe85,k(_0x358618,_0x2c9603)),zi(_0x2c9603)==='.priority'&&!Tn(_0x3bfe85))throw new Error(_0x23a96a+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x2c9603['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x4620ef['push'](_0x2c9603);}),dd(_0x23a96a,_0x4620ef);},ms=function(_0x2d166d,_0x40b404,_0x5b7e5d,_0x46fc99){if(!ra(_0x5b7e5d))throw new Error(Pn(_0x2d166d,_0x40b404)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x5b7e5d+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x30d27a,_0xd6dba3,_0x10c041,_0x375c57){_0x10c041&&(_0x10c041=_0x10c041['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x30d27a,_0xd6dba3,_0x10c041);},ys=function(_0x4ce590,_0x14f936){if(y(_0x14f936)==='.info')throw new Error(_0x4ce590+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0xb0b30,_0x203d02){const _0x90e4dd=_0x203d02['path']['toString']();if(typeof _0x203d02['repoInfo']['host']!='string'||_0x203d02['repoInfo']['host']['length']===0x0||!gs(_0x203d02['repoInfo']['namespace'])&&_0x203d02['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x90e4dd['length']!==0x0&&!ud(_0x90e4dd))throw new Error(Pn(_0xb0b30,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x3d15f8,_0x4e2784){let _0x8c903d=null;for(let _0x97d062=0x0;_0x97d062<_0x4e2784['length'];_0x97d062++){const _0x162f2f=_0x4e2784[_0x97d062],_0x2f3db1=_0x162f2f['getPath']();_0x8c903d!==null&&!ji(_0x2f3db1,_0x8c903d['path'])&&(_0x3d15f8['eventLists_']['push'](_0x8c903d),_0x8c903d=null),_0x8c903d===null&&(_0x8c903d={'events':[],'path':_0x2f3db1}),_0x8c903d['events']['push'](_0x162f2f);}_0x8c903d&&_0x3d15f8['eventLists_']['push'](_0x8c903d);}function oa(_0x3a91e7,_0x3772d3,_0x1f4322){Vn(_0x3a91e7,_0x1f4322),aa(_0x3a91e7,_0x4d7ad9=>ji(_0x4d7ad9,_0x3772d3));}function H(_0x20d2b8,_0x3e6892,_0x51627c){Vn(_0x20d2b8,_0x51627c),aa(_0x20d2b8,_0x3f07fa=>G(_0x3f07fa,_0x3e6892)||G(_0x3e6892,_0x3f07fa));}function aa(_0x46a7cb,_0x3bbfd6){_0x46a7cb['recursionDepth_']++;let _0x3e7da8=!0x0;for(let _0xf93df3=0x0;_0xf93df3<_0x46a7cb['eventLists_']['length'];_0xf93df3++){const _0x2be654=_0x46a7cb['eventLists_'][_0xf93df3];if(_0x2be654){const _0x442440=_0x2be654['path'];_0x3bbfd6(_0x442440)?(md(_0x46a7cb['eventLists_'][_0xf93df3]),_0x46a7cb['eventLists_'][_0xf93df3]=null):_0x3e7da8=!0x1;}}_0x3e7da8&&(_0x46a7cb['eventLists_']=[]),_0x46a7cb['recursionDepth_']--;}function md(_0x57ec4b){for(let _0x2a1dab=0x0;_0x2a1dab<_0x57ec4b['events']['length'];_0x2a1dab++){const _0x21a359=_0x57ec4b['events'][_0x2a1dab];if(_0x21a359!==null){_0x57ec4b['events'][_0x2a1dab]=null;const _0x2ebc72=_0x21a359['getEventRunner']();wt&&L('event:\x20'+_0x21a359['toString']()),ht(_0x2ebc72);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x52c8f6,_0x113391,_0x2d9ab1,_0x44cf81){this['repoInfo_']=_0x52c8f6,this['forceRestClient_']=_0x113391,this['authTokenProvider_']=_0x2d9ab1,this['appCheckProvider_']=_0x44cf81,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x380ac1,_0x34adef,_0x2227af){if(_0x380ac1['stats_']=Gi(_0x380ac1['repoInfo_']),_0x380ac1['forceRestClient_']||Xl())_0x380ac1['server_']=new pn(_0x380ac1['repoInfo_'],(_0x19eed6,_0x57d237,_0x343dfd,_0x33f3b1)=>{mr(_0x380ac1,_0x19eed6,_0x57d237,_0x343dfd,_0x33f3b1);},_0x380ac1['authTokenProvider_'],_0x380ac1['appCheckProvider_']),setTimeout(()=>yr(_0x380ac1,!0x0),0x0);else{if(typeof _0x2227af<'u'&&_0x2227af!==null){if(typeof _0x2227af!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x2227af);}catch(_0xe643bf){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0xe643bf);}}_0x380ac1['persistentConnection_']=new se(_0x380ac1['repoInfo_'],_0x34adef,(_0xf863f0,_0xbad05f,_0x506fba,_0x761aff)=>{mr(_0x380ac1,_0xf863f0,_0xbad05f,_0x506fba,_0x761aff);},_0x63c4c8=>{yr(_0x380ac1,_0x63c4c8);},_0x1085a9=>{Id(_0x380ac1,_0x1085a9);},_0x380ac1['authTokenProvider_'],_0x380ac1['appCheckProvider_'],_0x2227af),_0x380ac1['server_']=_0x380ac1['persistentConnection_'];}_0x380ac1['authTokenProvider_']['addTokenChangeListener'](_0xcf850b=>{_0x380ac1['server_']['refreshAuthToken'](_0xcf850b);}),_0x380ac1['appCheckProvider_']['addTokenChangeListener'](_0x3b0af6=>{_0x380ac1['server_']['refreshAppCheckToken'](_0x3b0af6['token']);}),_0x380ac1['statsReporter_']=ih(_0x380ac1['repoInfo_'],()=>new iu(_0x380ac1['stats_'],_0x380ac1['server_'])),_0x380ac1['infoData_']=new Xh(),_0x380ac1['infoSyncTree_']=new _r({'startListening':(_0x3e784e,_0x2ae1b0,_0x58f8ad,_0x41c706)=>{let _0x152c44=[];const _0x78c610=_0x380ac1['infoData_']['getNode'](_0x3e784e['_path']);return _0x78c610['isEmpty']()||(_0x152c44=Gt(_0x380ac1['infoSyncTree_'],_0x3e784e['_path'],_0x78c610),setTimeout(()=>{_0x41c706('ok');},0x0)),_0x152c44;},'stopListening':()=>{}}),vs(_0x380ac1,'connected',!0x1),_0x380ac1['serverSyncTree_']=new _r({'startListening':(_0x84be46,_0x5bc5f1,_0x1799ca,_0x2c9dbc)=>(_0x380ac1['server_']['listen'](_0x84be46,_0x1799ca,_0x5bc5f1,(_0x16950f,_0x420f89)=>{const _0x2ffa0f=_0x2c9dbc(_0x16950f,_0x420f89);H(_0x380ac1['eventQueue_'],_0x84be46['_path'],_0x2ffa0f);}),[]),'stopListening':(_0x560d57,_0x2e519b)=>{_0x380ac1['server_']['unlisten'](_0x560d57,_0x2e519b);}});}function la(_0x1230f4){const _0x82e9a0=_0x1230f4['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x82e9a0;}function Kt(_0x1bafa0){return id({'timestamp':la(_0x1bafa0)});}function mr(_0x247d64,_0x5519a4,_0x13240f,_0x1a26da,_0xafe37e){_0x247d64['dataUpdateCount']++;const _0x3648c8=new C(_0x5519a4);_0x13240f=_0x247d64['interceptServerDataCallback_']?_0x247d64['interceptServerDataCallback_'](_0x5519a4,_0x13240f):_0x13240f;let _0x4dddf8=[];if(_0xafe37e){if(_0x1a26da){const _0x30a83b=hn(_0x13240f,_0xf9fcb7=>P(_0xf9fcb7));_0x4dddf8=Ju(_0x247d64['serverSyncTree_'],_0x3648c8,_0x30a83b,_0xafe37e);}else{const _0x446702=P(_0x13240f);_0x4dddf8=Xo(_0x247d64['serverSyncTree_'],_0x3648c8,_0x446702,_0xafe37e);}}else{if(_0x1a26da){const _0x5aad19=hn(_0x13240f,_0x469ade=>P(_0x469ade));_0x4dddf8=Ku(_0x247d64['serverSyncTree_'],_0x3648c8,_0x5aad19);}else{const _0x1e07c6=P(_0x13240f);_0x4dddf8=Gt(_0x247d64['serverSyncTree_'],_0x3648c8,_0x1e07c6);}}let _0x989476=_0x3648c8;_0x4dddf8['length']>0x0&&(_0x989476=it(_0x247d64,_0x3648c8)),H(_0x247d64['eventQueue_'],_0x989476,_0x4dddf8);}function yr(_0x4fcb6,_0x3ec581){vs(_0x4fcb6,'connected',_0x3ec581),_0x3ec581===!0x1&&Sd(_0x4fcb6);}function Id(_0x57e51e,_0x3eba9e){x(_0x3eba9e,(_0x179906,_0x34f1c5)=>{vs(_0x57e51e,_0x179906,_0x34f1c5);});}function vs(_0x5c47c2,_0xa15cf5,_0x5c3ddf){const _0x5624ec=new C('/.info/'+_0xa15cf5),_0x58ac84=P(_0x5c3ddf);_0x5c47c2['infoData_']['updateSnapshot'](_0x5624ec,_0x58ac84);const _0x59c421=Gt(_0x5c47c2['infoSyncTree_'],_0x5624ec,_0x58ac84);H(_0x5c47c2['eventQueue_'],_0x5624ec,_0x59c421);}function Hn(_0x2bdadb){return _0x2bdadb['nextWriteId_']++;}function wd(_0x5b74b3,_0xd5b977,_0x353ec6){const _0x2993f7=Xu(_0x5b74b3['serverSyncTree_'],_0xd5b977);return _0x2993f7!=null?Promise['resolve'](_0x2993f7):_0x5b74b3['server_']['get'](_0xd5b977)['then'](_0x2cd96c=>{const _0x37528d=P(_0x2cd96c)['withIndex'](_0xd5b977['_queryParams']['getIndex']());Ri(_0x5b74b3['serverSyncTree_'],_0xd5b977,_0x353ec6,!0x0);let _0x5a196d;if(_0xd5b977['_queryParams']['loadsAllData']())_0x5a196d=Gt(_0x5b74b3['serverSyncTree_'],_0xd5b977['_path'],_0x37528d);else{const _0x4edc1d=xt(_0x5b74b3['serverSyncTree_'],_0xd5b977);_0x5a196d=Xo(_0x5b74b3['serverSyncTree_'],_0xd5b977['_path'],_0x37528d,_0x4edc1d);}return H(_0x5b74b3['eventQueue_'],_0xd5b977['_path'],_0x5a196d),Cn(_0x5b74b3['serverSyncTree_'],_0xd5b977,_0x353ec6,null,!0x0),_0x37528d;},_0x19a6aa=>(dt(_0x5b74b3,'get\x20for\x20query\x20'+O(_0xd5b977)+'\x20failed:\x20'+_0x19a6aa),Promise['reject'](new Error(_0x19a6aa))));}function Cd(_0xf58aa2,_0x267ed4,_0x37a660,_0x36e576,_0x1b4651){dt(_0xf58aa2,'set',{'path':_0x267ed4['toString'](),'value':_0x37a660,'priority':_0x36e576});const _0x3b37ed=Kt(_0xf58aa2),_0x133ad7=P(_0x37a660,_0x36e576),_0x2349b3=Fn(_0xf58aa2['serverSyncTree_'],_0x267ed4),_0x187bd8=ds(_0x133ad7,_0x2349b3,_0x3b37ed),_0x4ecb8a=Hn(_0xf58aa2),_0x4107bf=os(_0xf58aa2['serverSyncTree_'],_0x267ed4,_0x187bd8,_0x4ecb8a,!0x0);Vn(_0xf58aa2['eventQueue_'],_0x4107bf),_0xf58aa2['server_']['put'](_0x267ed4['toString'](),_0x133ad7['val'](!0x0),(_0x3171a7,_0x4b1087)=>{const _0x12b86a=_0x3171a7==='ok';_0x12b86a||U('set\x20at\x20'+_0x267ed4+'\x20failed:\x20'+_0x3171a7);const _0x33eb76=pe(_0xf58aa2['serverSyncTree_'],_0x4ecb8a,!_0x12b86a);H(_0xf58aa2['eventQueue_'],_0x267ed4,_0x33eb76),ki(_0xf58aa2,_0x1b4651,_0x3171a7,_0x4b1087);});const _0xf55221=Is(_0xf58aa2,_0x267ed4);it(_0xf58aa2,_0xf55221),H(_0xf58aa2['eventQueue_'],_0xf55221,[]);}function Td(_0x251ffa,_0xe0fdc4,_0x8459db,_0x3d6d67){dt(_0x251ffa,'update',{'path':_0xe0fdc4['toString'](),'value':_0x8459db});let _0x4169dd=!0x0;const _0x43495d=Kt(_0x251ffa),_0x539caa={};if(x(_0x8459db,(_0x2bdb8e,_0xf6dea6)=>{_0x4169dd=!0x1,_0x539caa[_0x2bdb8e]=na(k(_0xe0fdc4,_0x2bdb8e),P(_0xf6dea6),_0x251ffa['serverSyncTree_'],_0x43495d);}),_0x4169dd)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x251ffa,_0x3d6d67,'ok',void 0x0);else{const _0x1e37ae=Hn(_0x251ffa),_0x1d4db5=ju(_0x251ffa['serverSyncTree_'],_0xe0fdc4,_0x539caa,_0x1e37ae);Vn(_0x251ffa['eventQueue_'],_0x1d4db5),_0x251ffa['server_']['merge'](_0xe0fdc4['toString'](),_0x8459db,(_0x2e0ce7,_0x81a10e)=>{const _0x2eed7f=_0x2e0ce7==='ok';_0x2eed7f||U('update\x20at\x20'+_0xe0fdc4+'\x20failed:\x20'+_0x2e0ce7);const _0x2ff354=pe(_0x251ffa['serverSyncTree_'],_0x1e37ae,!_0x2eed7f),_0x5259ba=_0x2ff354['length']>0x0?it(_0x251ffa,_0xe0fdc4):_0xe0fdc4;H(_0x251ffa['eventQueue_'],_0x5259ba,_0x2ff354),ki(_0x251ffa,_0x3d6d67,_0x2e0ce7,_0x81a10e);}),x(_0x8459db,_0x176615=>{const _0x272869=Is(_0x251ffa,k(_0xe0fdc4,_0x176615));it(_0x251ffa,_0x272869);}),H(_0x251ffa['eventQueue_'],_0xe0fdc4,[]);}}function Sd(_0x1f6fa4){dt(_0x1f6fa4,'onDisconnectEvents');const _0x5a6e8f=Kt(_0x1f6fa4),_0x4a4026=_n();Ii(_0x1f6fa4['onDisconnect_'],w(),(_0x4fd9bf,_0x2d5dfd)=>{const _0x3b8128=na(_0x4fd9bf,_0x2d5dfd,_0x1f6fa4['serverSyncTree_'],_0x5a6e8f);Fo(_0x4a4026,_0x4fd9bf,_0x3b8128);});let _0x500498=[];Ii(_0x4a4026,w(),(_0x366a7d,_0x4b5b73)=>{_0x500498=_0x500498['concat'](Gt(_0x1f6fa4['serverSyncTree_'],_0x366a7d,_0x4b5b73));const _0x5a4378=Is(_0x1f6fa4,_0x366a7d);it(_0x1f6fa4,_0x5a4378);}),_0x1f6fa4['onDisconnect_']=_n(),H(_0x1f6fa4['eventQueue_'],w(),_0x500498);}function bd(_0x118c01,_0x38f705,_0x382675){let _0x3eb136;y(_0x38f705['_path'])==='.info'?_0x3eb136=Ri(_0x118c01['infoSyncTree_'],_0x38f705,_0x382675):_0x3eb136=Ri(_0x118c01['serverSyncTree_'],_0x38f705,_0x382675),oa(_0x118c01['eventQueue_'],_0x38f705['_path'],_0x3eb136);}function Rd(_0x1e29d0,_0x4cdfab,_0x111ecd){let _0x33adfc;y(_0x4cdfab['_path'])==='.info'?_0x33adfc=Cn(_0x1e29d0['infoSyncTree_'],_0x4cdfab,_0x111ecd):_0x33adfc=Cn(_0x1e29d0['serverSyncTree_'],_0x4cdfab,_0x111ecd),oa(_0x1e29d0['eventQueue_'],_0x4cdfab['_path'],_0x33adfc);}function ha(_0x4dfbaf){_0x4dfbaf['persistentConnection_']&&_0x4dfbaf['persistentConnection_']['interrupt'](ca);}function Ad(_0x543895){_0x543895['persistentConnection_']&&_0x543895['persistentConnection_']['resume'](ca);}function dt(_0x283027,..._0x3f1cb5){let _0x4c5733='';_0x283027['persistentConnection_']&&(_0x4c5733=_0x283027['persistentConnection_']['id']+':'),L(_0x4c5733,..._0x3f1cb5);}function ki(_0x2e2697,_0x2a078d,_0x3c30b8,_0x4abc3a){_0x2a078d&&ht(()=>{if(_0x3c30b8==='ok')_0x2a078d(null);else{const _0x87cce9=(_0x3c30b8||'error')['toUpperCase']();let _0x16c76f=_0x87cce9;_0x4abc3a&&(_0x16c76f+=':\x20'+_0x4abc3a);const _0x318329=new Error(_0x16c76f);_0x318329['code']=_0x87cce9,_0x2a078d(_0x318329);}});}function kd(_0x544973,_0x3c4066,_0x49ae6e,_0x5ed085,_0x24668f,_0x3bcecb){dt(_0x544973,'transaction\x20on\x20'+_0x3c4066);const _0x365708={'path':_0x3c4066,'update':_0x49ae6e,'onComplete':_0x5ed085,'status':null,'order':so(),'applyLocally':_0x3bcecb,'retryCount':0x0,'unwatcher':_0x24668f,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x27a8ea=Es(_0x544973,_0x3c4066,void 0x0);_0x365708['currentInputSnapshot']=_0x27a8ea;const _0x95d937=_0x365708['update'](_0x27a8ea['val']());if(_0x95d937===void 0x0)_0x365708['unwatcher'](),_0x365708['currentOutputSnapshotRaw']=null,_0x365708['currentOutputSnapshotResolved']=null,_0x365708['onComplete']&&_0x365708['onComplete'](null,!0x1,_0x365708['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x95d937,_0x365708['path']),_0x365708['status']=0x0;const _0xe4e142=Wn(_0x544973['transactionQueueTree_'],_0x3c4066),_0x2274d1=Ge(_0xe4e142)||[];_0x2274d1['push'](_0x365708),_s(_0xe4e142,_0x2274d1);let _0x110605;typeof _0x95d937=='object'&&_0x95d937!==null&&J(_0x95d937,'.priority')?(_0x110605=De(_0x95d937,'.priority'),f(Tn(_0x110605),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x110605=(Fn(_0x544973['serverSyncTree_'],_0x3c4066)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x4a7f51=Kt(_0x544973),_0x3f053f=P(_0x95d937,_0x110605),_0x42a7ad=ds(_0x3f053f,_0x27a8ea,_0x4a7f51);_0x365708['currentOutputSnapshotRaw']=_0x3f053f,_0x365708['currentOutputSnapshotResolved']=_0x42a7ad,_0x365708['currentWriteId']=Hn(_0x544973);const _0x355363=os(_0x544973['serverSyncTree_'],_0x3c4066,_0x42a7ad,_0x365708['currentWriteId'],_0x365708['applyLocally']);H(_0x544973['eventQueue_'],_0x3c4066,_0x355363),$n(_0x544973,_0x544973['transactionQueueTree_']);}}function Es(_0x3bde81,_0x424758,_0x294e32){return Fn(_0x3bde81['serverSyncTree_'],_0x424758,_0x294e32)||g['EMPTY_NODE'];}function $n(_0x39ac91,_0x3f2214=_0x39ac91['transactionQueueTree_']){if(_0x3f2214||Gn(_0x39ac91,_0x3f2214),Ge(_0x3f2214)){const _0x598509=da(_0x39ac91,_0x3f2214);f(_0x598509['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x598509['every'](_0x329e9a=>_0x329e9a['status']===0x0)&&Nd(_0x39ac91,qt(_0x3f2214),_0x598509);}else ia(_0x3f2214)&&Bn(_0x3f2214,_0x57669e=>{$n(_0x39ac91,_0x57669e);});}function Nd(_0x352940,_0x2be5e4,_0x2977ee){const _0x104e0d=_0x2977ee['map'](_0x23b2d4=>_0x23b2d4['currentWriteId']),_0x4633e7=Es(_0x352940,_0x2be5e4,_0x104e0d);let _0x1d7338=_0x4633e7;const _0x106f4d=_0x4633e7['hash']();for(let _0x491a27=0x0;_0x491a27<_0x2977ee['length'];_0x491a27++){const _0x59add7=_0x2977ee[_0x491a27];f(_0x59add7['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x59add7['status']=0x1,_0x59add7['retryCount']++;const _0x7a0fe8=F(_0x2be5e4,_0x59add7['path']);_0x1d7338=_0x1d7338['updateChild'](_0x7a0fe8,_0x59add7['currentOutputSnapshotRaw']);}const _0x4dd4fd=_0x1d7338['val'](!0x0),_0x59769c=_0x2be5e4;_0x352940['server_']['put'](_0x59769c['toString'](),_0x4dd4fd,_0x2aa580=>{dt(_0x352940,'transaction\x20put\x20response',{'path':_0x59769c['toString'](),'status':_0x2aa580});let _0x1a9a48=[];if(_0x2aa580==='ok'){const _0x1e3dad=[];for(let _0x492219=0x0;_0x492219<_0x2977ee['length'];_0x492219++)_0x2977ee[_0x492219]['status']=0x2,_0x1a9a48=_0x1a9a48['concat'](pe(_0x352940['serverSyncTree_'],_0x2977ee[_0x492219]['currentWriteId'])),_0x2977ee[_0x492219]['onComplete']&&_0x1e3dad['push'](()=>_0x2977ee[_0x492219]['onComplete'](null,!0x0,_0x2977ee[_0x492219]['currentOutputSnapshotResolved'])),_0x2977ee[_0x492219]['unwatcher']();Gn(_0x352940,Wn(_0x352940['transactionQueueTree_'],_0x2be5e4)),$n(_0x352940,_0x352940['transactionQueueTree_']),H(_0x352940['eventQueue_'],_0x2be5e4,_0x1a9a48);for(let _0x57931f=0x0;_0x57931f<_0x1e3dad['length'];_0x57931f++)ht(_0x1e3dad[_0x57931f]);}else{if(_0x2aa580==='datastale'){for(let _0x14c193=0x0;_0x14c193<_0x2977ee['length'];_0x14c193++)_0x2977ee[_0x14c193]['status']===0x3?_0x2977ee[_0x14c193]['status']=0x4:_0x2977ee[_0x14c193]['status']=0x0;}else{U('transaction\x20at\x20'+_0x59769c['toString']()+'\x20failed:\x20'+_0x2aa580);for(let _0x33683f=0x0;_0x33683f<_0x2977ee['length'];_0x33683f++)_0x2977ee[_0x33683f]['status']=0x4,_0x2977ee[_0x33683f]['abortReason']=_0x2aa580;}it(_0x352940,_0x2be5e4);}},_0x106f4d);}function it(_0x2b3aee,_0x54fa50){const _0x5e47e5=ua(_0x2b3aee,_0x54fa50),_0x425033=qt(_0x5e47e5),_0x1574d0=da(_0x2b3aee,_0x5e47e5);return Pd(_0x2b3aee,_0x1574d0,_0x425033),_0x425033;}function Pd(_0x381477,_0x3d8207,_0x3ae861){if(_0x3d8207['length']===0x0)return;const _0x5b2d9c=[];let _0x1c55c7=[];const _0x1b8618=_0x3d8207['filter'](_0x407b2e=>_0x407b2e['status']===0x0)['map'](_0x27de51=>_0x27de51['currentWriteId']);for(let _0x2f7711=0x0;_0x2f7711<_0x3d8207['length'];_0x2f7711++){const _0x1a482c=_0x3d8207[_0x2f7711],_0x3b8e1b=F(_0x3ae861,_0x1a482c['path']);let _0x3fd949=!0x1,_0x587162;if(f(_0x3b8e1b!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x1a482c['status']===0x4)_0x3fd949=!0x0,_0x587162=_0x1a482c['abortReason'],_0x1c55c7=_0x1c55c7['concat'](pe(_0x381477['serverSyncTree_'],_0x1a482c['currentWriteId'],!0x0));else{if(_0x1a482c['status']===0x0){if(_0x1a482c['retryCount']>=yd)_0x3fd949=!0x0,_0x587162='maxretry',_0x1c55c7=_0x1c55c7['concat'](pe(_0x381477['serverSyncTree_'],_0x1a482c['currentWriteId'],!0x0));else{const _0x2ac617=Es(_0x381477,_0x1a482c['path'],_0x1b8618);_0x1a482c['currentInputSnapshot']=_0x2ac617;const _0x9e0ccf=_0x3d8207[_0x2f7711]['update'](_0x2ac617['val']());if(_0x9e0ccf!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x9e0ccf,_0x1a482c['path']);let _0x33043d=P(_0x9e0ccf);typeof _0x9e0ccf=='object'&&_0x9e0ccf!=null&&J(_0x9e0ccf,'.priority')||(_0x33043d=_0x33043d['updatePriority'](_0x2ac617['getPriority']()));const _0x154994=_0x1a482c['currentWriteId'],_0xa43c6a=Kt(_0x381477),_0x1fed14=ds(_0x33043d,_0x2ac617,_0xa43c6a);_0x1a482c['currentOutputSnapshotRaw']=_0x33043d,_0x1a482c['currentOutputSnapshotResolved']=_0x1fed14,_0x1a482c['currentWriteId']=Hn(_0x381477),_0x1b8618['splice'](_0x1b8618['indexOf'](_0x154994),0x1),_0x1c55c7=_0x1c55c7['concat'](os(_0x381477['serverSyncTree_'],_0x1a482c['path'],_0x1fed14,_0x1a482c['currentWriteId'],_0x1a482c['applyLocally'])),_0x1c55c7=_0x1c55c7['concat'](pe(_0x381477['serverSyncTree_'],_0x154994,!0x0));}else _0x3fd949=!0x0,_0x587162='nodata',_0x1c55c7=_0x1c55c7['concat'](pe(_0x381477['serverSyncTree_'],_0x1a482c['currentWriteId'],!0x0));}}}H(_0x381477['eventQueue_'],_0x3ae861,_0x1c55c7),_0x1c55c7=[],_0x3fd949&&(_0x3d8207[_0x2f7711]['status']=0x2,function(_0x1f3aa9){setTimeout(_0x1f3aa9,Math['floor'](0x0));}(_0x3d8207[_0x2f7711]['unwatcher']),_0x3d8207[_0x2f7711]['onComplete']&&(_0x587162==='nodata'?_0x5b2d9c['push'](()=>_0x3d8207[_0x2f7711]['onComplete'](null,!0x1,_0x3d8207[_0x2f7711]['currentInputSnapshot'])):_0x5b2d9c['push'](()=>_0x3d8207[_0x2f7711]['onComplete'](new Error(_0x587162),!0x1,null))));}Gn(_0x381477,_0x381477['transactionQueueTree_']);for(let _0x253fa3=0x0;_0x253fa3<_0x5b2d9c['length'];_0x253fa3++)ht(_0x5b2d9c[_0x253fa3]);$n(_0x381477,_0x381477['transactionQueueTree_']);}function ua(_0x824ace,_0x1a5875){let _0x3ab54d,_0x586887=_0x824ace['transactionQueueTree_'];for(_0x3ab54d=y(_0x1a5875);_0x3ab54d!==null&&Ge(_0x586887)===void 0x0;)_0x586887=Wn(_0x586887,_0x3ab54d),_0x1a5875=b(_0x1a5875),_0x3ab54d=y(_0x1a5875);return _0x586887;}function da(_0x1fb127,_0x219f95){const _0x44a914=[];return fa(_0x1fb127,_0x219f95,_0x44a914),_0x44a914['sort']((_0x380f26,_0x58260e)=>_0x380f26['order']-_0x58260e['order']),_0x44a914;}function fa(_0x374fda,_0x1f9b18,_0x16f624){const _0x316435=Ge(_0x1f9b18);if(_0x316435){for(let _0xea382a=0x0;_0xea382a<_0x316435['length'];_0xea382a++)_0x16f624['push'](_0x316435[_0xea382a]);}Bn(_0x1f9b18,_0x182259=>{fa(_0x374fda,_0x182259,_0x16f624);});}function Gn(_0x3fc59f,_0x35819b){const _0xb047e0=Ge(_0x35819b);if(_0xb047e0){let _0x2e8d96=0x0;for(let _0x22a872=0x0;_0x22a872<_0xb047e0['length'];_0x22a872++)_0xb047e0[_0x22a872]['status']!==0x2&&(_0xb047e0[_0x2e8d96]=_0xb047e0[_0x22a872],_0x2e8d96++);_0xb047e0['length']=_0x2e8d96,_s(_0x35819b,_0xb047e0['length']>0x0?_0xb047e0:void 0x0);}Bn(_0x35819b,_0xe1cf51=>{Gn(_0x3fc59f,_0xe1cf51);});}function Is(_0x547c8d,_0x158ee9){const _0x2f3819=qt(ua(_0x547c8d,_0x158ee9)),_0x499d98=Wn(_0x547c8d['transactionQueueTree_'],_0x158ee9);return ad(_0x499d98,_0x425932=>{ci(_0x547c8d,_0x425932);}),ci(_0x547c8d,_0x499d98),sa(_0x499d98,_0x1acb7c=>{ci(_0x547c8d,_0x1acb7c);}),_0x2f3819;}function ci(_0x447ba4,_0x5a9a14){const _0x38d23a=Ge(_0x5a9a14);if(_0x38d23a){const _0x2bbff3=[];let _0x14e6e4=[],_0x58cadb=-0x1;for(let _0x3279cd=0x0;_0x3279cd<_0x38d23a['length'];_0x3279cd++)_0x38d23a[_0x3279cd]['status']===0x3||(_0x38d23a[_0x3279cd]['status']===0x1?(f(_0x58cadb===_0x3279cd-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x58cadb=_0x3279cd,_0x38d23a[_0x3279cd]['status']=0x3,_0x38d23a[_0x3279cd]['abortReason']='set'):(f(_0x38d23a[_0x3279cd]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x38d23a[_0x3279cd]['unwatcher'](),_0x14e6e4=_0x14e6e4['concat'](pe(_0x447ba4['serverSyncTree_'],_0x38d23a[_0x3279cd]['currentWriteId'],!0x0)),_0x38d23a[_0x3279cd]['onComplete']&&_0x2bbff3['push'](_0x38d23a[_0x3279cd]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x58cadb===-0x1?_s(_0x5a9a14,void 0x0):_0x38d23a['length']=_0x58cadb+0x1,H(_0x447ba4['eventQueue_'],qt(_0x5a9a14),_0x14e6e4);for(let _0x2a3491=0x0;_0x2a3491<_0x2bbff3['length'];_0x2a3491++)ht(_0x2bbff3[_0x2a3491]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0xf65657){let _0x5c2a63='';const _0x9b89a0=_0xf65657['split']('/');for(let _0x477824=0x0;_0x477824<_0x9b89a0['length'];_0x477824++)if(_0x9b89a0[_0x477824]['length']>0x0){let _0x46926f=_0x9b89a0[_0x477824];try{_0x46926f=decodeURIComponent(_0x46926f['replace'](/\+/g,'\x20'));}catch{}_0x5c2a63+='/'+_0x46926f;}return _0x5c2a63;}function Dd(_0x36a768){const _0x4fd91b={};_0x36a768['charAt'](0x0)==='?'&&(_0x36a768=_0x36a768['substring'](0x1));for(const _0x3e8688 of _0x36a768['split']('&')){if(_0x3e8688['length']===0x0)continue;const _0x38f003=_0x3e8688['split']('=');_0x38f003['length']===0x2?_0x4fd91b[decodeURIComponent(_0x38f003[0x0])]=decodeURIComponent(_0x38f003[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x3e8688+'\x27\x20in\x20query\x20\x27'+_0x36a768+'\x27');}return _0x4fd91b;}const vr=function(_0x5e1616,_0x2398d6){const _0x2ad242=Md(_0x5e1616),_0x4d5cf3=_0x2ad242['namespace'];_0x2ad242['domain']==='firebase.com'&&ae(_0x2ad242['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x4d5cf3||_0x4d5cf3==='undefined')&&_0x2ad242['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x2ad242['secure']||$l();const _0xe2624b=_0x2ad242['scheme']==='ws'||_0x2ad242['scheme']==='wss';return{'repoInfo':new yo(_0x2ad242['host'],_0x2ad242['secure'],_0x4d5cf3,_0xe2624b,_0x2398d6,'',_0x4d5cf3!==_0x2ad242['subdomain']),'path':new C(_0x2ad242['pathString'])};},Md=function(_0x5ce8be){let _0x48e99b='',_0x124824='',_0x116e24='',_0x14c24c='',_0x5a29cc='',_0x496e10=!0x0,_0xf0cca3='https',_0x3a72e3=0x1bb;if(typeof _0x5ce8be=='string'){let _0x4b3f23=_0x5ce8be['indexOf']('//');_0x4b3f23>=0x0&&(_0xf0cca3=_0x5ce8be['substring'](0x0,_0x4b3f23-0x1),_0x5ce8be=_0x5ce8be['substring'](_0x4b3f23+0x2));let _0x1f504a=_0x5ce8be['indexOf']('/');_0x1f504a===-0x1&&(_0x1f504a=_0x5ce8be['length']);let _0x1c634b=_0x5ce8be['indexOf']('?');_0x1c634b===-0x1&&(_0x1c634b=_0x5ce8be['length']),_0x48e99b=_0x5ce8be['substring'](0x0,Math['min'](_0x1f504a,_0x1c634b)),_0x1f504a<_0x1c634b&&(_0x14c24c=Od(_0x5ce8be['substring'](_0x1f504a,_0x1c634b)));const _0xbaf928=Dd(_0x5ce8be['substring'](Math['min'](_0x5ce8be['length'],_0x1c634b)));_0x4b3f23=_0x48e99b['indexOf'](':'),_0x4b3f23>=0x0?(_0x496e10=_0xf0cca3==='https'||_0xf0cca3==='wss',_0x3a72e3=parseInt(_0x48e99b['substring'](_0x4b3f23+0x1),0xa)):_0x4b3f23=_0x48e99b['length'];const _0x380b85=_0x48e99b['slice'](0x0,_0x4b3f23);if(_0x380b85['toLowerCase']()==='localhost')_0x124824='localhost';else{if(_0x380b85['split']('.')['length']<=0x2)_0x124824=_0x380b85;else{const _0x124cdd=_0x48e99b['indexOf']('.');_0x116e24=_0x48e99b['substring'](0x0,_0x124cdd)['toLowerCase'](),_0x124824=_0x48e99b['substring'](_0x124cdd+0x1),_0x5a29cc=_0x116e24;}}'ns'in _0xbaf928&&(_0x5a29cc=_0xbaf928['ns']);}return{'host':_0x48e99b,'port':_0x3a72e3,'domain':_0x124824,'subdomain':_0x116e24,'secure':_0x496e10,'scheme':_0xf0cca3,'pathString':_0x14c24c,'namespace':_0x5a29cc};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x50efa0=0x0;const _0x4d4b79=[];return function(_0x1561ea){const _0x2a015d=_0x1561ea===_0x50efa0;_0x50efa0=_0x1561ea;let _0x56ac21;const _0x461019=new Array(0x8);for(_0x56ac21=0x7;_0x56ac21>=0x0;_0x56ac21--)_0x461019[_0x56ac21]=Er['charAt'](_0x1561ea%0x40),_0x1561ea=Math['floor'](_0x1561ea/0x40);f(_0x1561ea===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x2ce83c=_0x461019['join']('');if(_0x2a015d){for(_0x56ac21=0xb;_0x56ac21>=0x0&&_0x4d4b79[_0x56ac21]===0x3f;_0x56ac21--)_0x4d4b79[_0x56ac21]=0x0;_0x4d4b79[_0x56ac21]++;}else{for(_0x56ac21=0x0;_0x56ac21<0xc;_0x56ac21++)_0x4d4b79[_0x56ac21]=Math['floor'](Math['random']()*0x40);}for(_0x56ac21=0x0;_0x56ac21<0xc;_0x56ac21++)_0x2ce83c+=Er['charAt'](_0x4d4b79[_0x56ac21]);return f(_0x2ce83c['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x2ce83c;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x1efe92,_0x25e6c4,_0x1ba036,_0x5e0e18){this['eventType']=_0x1efe92,this['eventRegistration']=_0x25e6c4,this['snapshot']=_0x1ba036,this['prevName']=_0x5e0e18;}['getPath'](){const _0x4136e2=this['snapshot']['ref'];return this['eventType']==='value'?_0x4136e2['_path']:_0x4136e2['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x45a561,_0x38b44f,_0x59a205){this['eventRegistration']=_0x45a561,this['error']=_0x38b44f,this['path']=_0x59a205;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x3af59c,_0x4863cc){this['snapshotCallback']=_0x3af59c,this['cancelCallback']=_0x4863cc;}['onValue'](_0x1aa7b4,_0x109e5b){this['snapshotCallback']['call'](null,_0x1aa7b4,_0x109e5b);}['onCancel'](_0x19a0b0){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x19a0b0);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x5f88e3){return this['snapshotCallback']===_0x5f88e3['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x5f88e3['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x5f88e3['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x17b180,_0x42ed90,_0x4e45b6,_0x4ab07f){this['_repo']=_0x17b180,this['_path']=_0x42ed90,this['_queryParams']=_0x4e45b6,this['_orderByCalled']=_0x4ab07f;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x85a99f=rr(this['_queryParams']),_0x1e45fc=Hi(_0x85a99f);return _0x1e45fc==='{}'?'default':_0x1e45fc;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0xad5e13){if(_0xad5e13=N(_0xad5e13),!(_0xad5e13 instanceof be))return!0x1;const _0x459797=this['_repo']===_0xad5e13['_repo'],_0x53a864=ji(this['_path'],_0xad5e13['_path']),_0x203a5b=this['_queryIdentifier']===_0xad5e13['_queryIdentifier'];return _0x459797&&_0x53a864&&_0x203a5b;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x264bfd,_0x3a4a6d){if(_0x264bfd['_orderByCalled']===!0x0)throw new Error(_0x3a4a6d+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x54bbc){let _0x434c57=null,_0x9ec5eb=null;if(_0x54bbc['hasStart']()&&(_0x434c57=_0x54bbc['getIndexStartValue']()),_0x54bbc['hasEnd']()&&(_0x9ec5eb=_0x54bbc['getIndexEndValue']()),_0x54bbc['getIndex']()===ye){const _0xea9e05='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x327b72='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x54bbc['hasStart']()){if(_0x54bbc['getIndexStartName']()!==Fe)throw new Error(_0xea9e05);if(typeof _0x434c57!='string')throw new Error(_0x327b72);}if(_0x54bbc['hasEnd']()){if(_0x54bbc['getIndexEndName']()!==Ie)throw new Error(_0xea9e05);if(typeof _0x9ec5eb!='string')throw new Error(_0x327b72);}}else{if(_0x54bbc['getIndex']()===R){if(_0x434c57!=null&&!Tn(_0x434c57)||_0x9ec5eb!=null&&!Tn(_0x9ec5eb))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x54bbc['getIndex']()instanceof Qi||_0x54bbc['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x434c57!=null&&typeof _0x434c57=='object'||_0x9ec5eb!=null&&typeof _0x9ec5eb=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x242147){if(_0x242147['hasStart']()&&_0x242147['hasEnd']()&&_0x242147['hasLimit']()&&!_0x242147['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x3b69fb,_0x88d1e0){super(_0x3b69fb,_0x88d1e0,new Xi(),!0x1);}get['parent'](){const _0x2ca1b0=Ro(this['_path']);return _0x2ca1b0===null?null:new ee(this['_repo'],_0x2ca1b0);}get['root'](){let _0x259e4a=this;for(;_0x259e4a['parent']!==null;)_0x259e4a=_0x259e4a['parent'];return _0x259e4a;}}class st{constructor(_0x2790b2,_0x730ba1,_0x3fec19){this['_node']=_0x2790b2,this['ref']=_0x730ba1,this['_index']=_0x3fec19;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x48ecf1){const _0x4625ef=new C(_0x48ecf1),_0x4ff95a=Ft(this['ref'],_0x48ecf1);return new st(this['_node']['getChild'](_0x4625ef),_0x4ff95a,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x9d6a6){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x4ffdf6,_0x16cb87)=>_0x9d6a6(new st(_0x16cb87,Ft(this['ref'],_0x4ffdf6),R)));}['hasChild'](_0x561ef9){const _0x142db9=new C(_0x561ef9);return!this['_node']['getChild'](_0x142db9)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x472e17,_0x46b6fd){return _0x472e17=N(_0x472e17),_0x472e17['_checkNotDeleted']('ref'),_0x46b6fd!==void 0x0?Ft(_0x472e17['_root'],_0x46b6fd):_0x472e17['_root'];}function Ft(_0x577b9e,_0x3e1268){return _0x577b9e=N(_0x577b9e),y(_0x577b9e['_path'])===null?pd('child','path',_0x3e1268):ms('child','path',_0x3e1268),new ee(_0x577b9e['_repo'],k(_0x577b9e['_path'],_0x3e1268));}function g_(_0x43bafc,_0x2879a6){_0x43bafc=N(_0x43bafc),ys('push',_0x43bafc['_path']),zt('push',_0x2879a6,_0x43bafc['_path'],!0x0);const _0x6968a1=la(_0x43bafc['_repo']),_0x4c11ad=Ld(_0x6968a1),_0xe84a63=Ft(_0x43bafc,_0x4c11ad),_0x3bf6cc=Ft(_0x43bafc,_0x4c11ad);let _0x26c1a8;return _0x2879a6!=null?_0x26c1a8=Ud(_0x3bf6cc,_0x2879a6)['then'](()=>_0x3bf6cc):_0x26c1a8=Promise['resolve'](_0x3bf6cc),_0xe84a63['then']=_0x26c1a8['then']['bind'](_0x26c1a8),_0xe84a63['catch']=_0x26c1a8['then']['bind'](_0x26c1a8,void 0x0),_0xe84a63;}function Ud(_0x190492,_0x17c16f){_0x190492=N(_0x190492),ys('set',_0x190492['_path']),zt('set',_0x17c16f,_0x190492['_path'],!0x1);const _0x361c23=new ot();return Cd(_0x190492['_repo'],_0x190492['_path'],_0x17c16f,null,_0x361c23['wrapCallback'](()=>{})),_0x361c23['promise'];}function m_(_0x3b871d,_0xbcb2b6){fd('update',_0xbcb2b6,_0x3b871d['_path']);const _0x190568=new ot();return Td(_0x3b871d['_repo'],_0x3b871d['_path'],_0xbcb2b6,_0x190568['wrapCallback'](()=>{})),_0x190568['promise'];}function y_(_0x52d548){_0x52d548=N(_0x52d548);const _0x276fad=new pa(()=>{}),_0x3a0cf1=new zn(_0x276fad);return wd(_0x52d548['_repo'],_0x52d548,_0x3a0cf1)['then'](_0x2fd143=>new st(_0x2fd143,new ee(_0x52d548['_repo'],_0x52d548['_path']),_0x52d548['_queryParams']['getIndex']()));}class zn{constructor(_0x2792b7){this['callbackContext']=_0x2792b7;}['respondsTo'](_0x51a34f){return _0x51a34f==='value';}['createEvent'](_0xe208a2,_0x5dd65d){const _0x20b35e=_0x5dd65d['_queryParams']['getIndex']();return new xd('value',this,new st(_0xe208a2['snapshotNode'],new ee(_0x5dd65d['_repo'],_0x5dd65d['_path']),_0x20b35e));}['getEventRunner'](_0x17938a){return _0x17938a['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x17938a['error']):()=>this['callbackContext']['onValue'](_0x17938a['snapshot'],null);}['createCancelEvent'](_0x3abbf1,_0x13ad71){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x3abbf1,_0x13ad71):null;}['matches'](_0x1b2f7d){return _0x1b2f7d instanceof zn?!_0x1b2f7d['callbackContext']||!this['callbackContext']?!0x0:_0x1b2f7d['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x21c899,_0x233a3e,_0x1b149e,_0x3368b8,_0x5d0783){const _0x210d19=new pa(_0x1b149e,void 0x0),_0x3ad26c=new zn(_0x210d19);return bd(_0x21c899['_repo'],_0x21c899,_0x3ad26c),()=>Rd(_0x21c899['_repo'],_0x21c899,_0x3ad26c);}function Bd(_0x1a7ee9,_0x4d92ca,_0x123350,_0x2ad5b4){return Wd(_0x1a7ee9,'value',_0x4d92ca);}class ft{}class ma extends ft{constructor(_0x46d292,_0x55d3e5){super(),this['_value']=_0x46d292,this['_key']=_0x55d3e5,this['type']='endAt';}['_apply'](_0x4a7b63){zt('endAt',this['_value'],_0x4a7b63['_path'],!0x0);const _0x20e157=Jh(_0x4a7b63['_queryParams'],this['_value'],this['_key']);if(ga(_0x20e157),qn(_0x20e157),_0x4a7b63['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x4a7b63['_repo'],_0x4a7b63['_path'],_0x20e157,_0x4a7b63['_orderByCalled']);}}function v_(_0x1df29f,_0x22c775){return new ma(_0x1df29f,_0x22c775);}class ya extends ft{constructor(_0x26d9bc,_0xaaf4cf){super(),this['_value']=_0x26d9bc,this['_key']=_0xaaf4cf,this['type']='startAt';}['_apply'](_0x544d6a){zt('startAt',this['_value'],_0x544d6a['_path'],!0x0);const _0x2232f1=Qh(_0x544d6a['_queryParams'],this['_value'],this['_key']);if(ga(_0x2232f1),qn(_0x2232f1),_0x544d6a['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x544d6a['_repo'],_0x544d6a['_path'],_0x2232f1,_0x544d6a['_orderByCalled']);}}function E_(_0x2ce293=null,_0x534f19){return new ya(_0x2ce293,_0x534f19);}class Vd extends ft{constructor(_0x11344b){super(),this['_limit']=_0x11344b,this['type']='limitToFirst';}['_apply'](_0x4afac8){if(_0x4afac8['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x4afac8['_repo'],_0x4afac8['_path'],Yh(_0x4afac8['_queryParams'],this['_limit']),_0x4afac8['_orderByCalled']);}}function I_(_0x56a28d){if(Math['floor'](_0x56a28d)!==_0x56a28d||_0x56a28d<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x56a28d);}class Hd extends ft{constructor(_0x5ea449){super(),this['_path']=_0x5ea449,this['type']='orderByChild';}['_apply'](_0x3437b9){_a(_0x3437b9,'orderByChild');const _0x29e7ad=new C(this['_path']);if(v(_0x29e7ad))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x3f1cc0=new Qi(_0x29e7ad),_0x1d8fa2=xo(_0x3437b9['_queryParams'],_0x3f1cc0);return qn(_0x1d8fa2),new be(_0x3437b9['_repo'],_0x3437b9['_path'],_0x1d8fa2,!0x0);}}function w_(_0x431437){if(_0x431437==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x431437==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x431437==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x431437),new Hd(_0x431437);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x186e86){_a(_0x186e86,'orderByKey');const _0x14897b=xo(_0x186e86['_queryParams'],ye);return qn(_0x14897b),new be(_0x186e86['_repo'],_0x186e86['_path'],_0x14897b,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x4d4e66,_0xced670){super(),this['_value']=_0x4d4e66,this['_key']=_0xced670,this['type']='equalTo';}['_apply'](_0x2f4e0b){if(zt('equalTo',this['_value'],_0x2f4e0b['_path'],!0x1),_0x2f4e0b['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x2f4e0b['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x2f4e0b));}}function T_(_0x16285c,_0x581ca0){return new Gd(_0x16285c,_0x581ca0);}function S_(_0x4607c6,..._0x134078){let _0x43bc7e=N(_0x4607c6);for(const _0x171665 of _0x134078)_0x43bc7e=_0x171665['_apply'](_0x43bc7e);return _0x43bc7e;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x5843ae,_0x3c2532,_0x109a68,_0x1e72e0){const _0x107fb0=_0x3c2532['lastIndexOf'](':'),_0xf0e42e=_0x3c2532['substring'](0x0,_0x107fb0),_0xeb17e6=at(_0xf0e42e);_0x5843ae['repoInfo_']=new yo(_0x3c2532,_0xeb17e6,_0x5843ae['repoInfo_']['namespace'],_0x5843ae['repoInfo_']['webSocketOnly'],_0x5843ae['repoInfo_']['nodeAdmin'],_0x5843ae['repoInfo_']['persistenceKey'],_0x5843ae['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x109a68),_0x1e72e0&&(_0x5843ae['authTokenProvider_']=_0x1e72e0);}function Kd(_0x49d8eb,_0xf8cb97,_0x62a75a,_0x832d2d,_0x3aba0e){let _0x521182=_0x832d2d||_0x49d8eb['options']['databaseURL'];_0x521182===void 0x0&&(_0x49d8eb['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x49d8eb['options']['projectId']),_0x521182=_0x49d8eb['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x36d780=vr(_0x521182,_0x3aba0e),_0x3942e2=_0x36d780['repoInfo'],_0x411a50;typeof process<'u'&&Vs&&(_0x411a50=Vs[qd]),_0x411a50?(_0x521182='http://'+_0x411a50+'?ns='+_0x3942e2['namespace'],_0x36d780=vr(_0x521182,_0x3aba0e),_0x3942e2=_0x36d780['repoInfo']):_0x36d780['repoInfo']['secure'];const _0x4cdbe6=new eh(_0x49d8eb['name'],_0x49d8eb['options'],_0xf8cb97);_d('Invalid\x20Firebase\x20Database\x20URL',_0x36d780),v(_0x36d780['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x361ab9=Qd(_0x3942e2,_0x49d8eb,_0x4cdbe6,new Zl(_0x49d8eb,_0x62a75a));return new Jd(_0x361ab9,_0x49d8eb);}function Yd(_0x550662,_0x4f3d1c){const _0x77622e=Ni[_0x4f3d1c];(!_0x77622e||_0x77622e[_0x550662['key']]!==_0x550662)&&ae('Database\x20'+_0x4f3d1c+'('+_0x550662['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x550662),delete _0x77622e[_0x550662['key']];}function Qd(_0xc10145,_0x1d33cb,_0x4b1816,_0x416aa0){let _0x27d547=Ni[_0x1d33cb['name']];_0x27d547||(_0x27d547={},Ni[_0x1d33cb['name']]=_0x27d547);let _0x568f3f=_0x27d547[_0xc10145['toURLString']()];return _0x568f3f&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x568f3f=new vd(_0xc10145,zd,_0x4b1816,_0x416aa0),_0x27d547[_0xc10145['toURLString']()]=_0x568f3f,_0x568f3f;}class Jd{constructor(_0x12a403,_0x1aca1c){this['_repoInternal']=_0x12a403,this['app']=_0x1aca1c,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x393a8d){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x393a8d+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x48db48=Zr(),_0x49eb02){const _0x592d72=Bi(_0x48db48,'database')['getImmediate']({'identifier':_0x49eb02});if(!_0x592d72['_instanceStarted']){const _0x3df6bb=cc('database');_0x3df6bb&&Xd(_0x592d72,..._0x3df6bb);}return _0x592d72;}function Xd(_0x1a9e66,_0x10b5e5,_0x5655e6,_0x48c016={}){_0x1a9e66=N(_0x1a9e66),_0x1a9e66['_checkNotDeleted']('useEmulator');const _0x291ebc=_0x10b5e5+':'+_0x5655e6,_0xed0953=_0x1a9e66['_repoInternal'];if(_0x1a9e66['_instanceStarted']){if(_0x291ebc===_0x1a9e66['_repoInternal']['repoInfo_']['host']&&Me(_0x48c016,_0xed0953['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x5a5add;if(_0xed0953['repoInfo_']['nodeAdmin'])_0x48c016['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x5a5add=new nn(nn['OWNER']);else{if(_0x48c016['mockUserToken']){const _0x4527f2=typeof _0x48c016['mockUserToken']=='string'?_0x48c016['mockUserToken']:lc(_0x48c016['mockUserToken'],_0x1a9e66['app']['options']['projectId']);_0x5a5add=new nn(_0x4527f2);}}at(_0x10b5e5)&&(jr(_0x10b5e5),Kr('Database',!0x0)),jd(_0xed0953,_0x291ebc,_0x48c016,_0x5a5add);}function R_(_0x1f3971){_0x1f3971=N(_0x1f3971),_0x1f3971['_checkNotDeleted']('goOffline'),ha(_0x1f3971['_repo']);}function A_(_0x18542e){_0x18542e=N(_0x18542e),_0x18542e['_checkNotDeleted']('goOnline'),Ad(_0x18542e['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x5352cf){Ul(lt),Ze(new Le('database',(_0x64a5d7,{instanceIdentifier:_0x10ff57})=>{const _0x40f7cc=_0x64a5d7['getProvider']('app')['getImmediate'](),_0x239eaa=_0x64a5d7['getProvider']('auth-internal'),_0x3a6633=_0x64a5d7['getProvider']('app-check-internal');return Kd(_0x40f7cc,_0x239eaa,_0x3a6633,_0x10ff57);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x5352cf),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x26bc76,_0xeac850){this['committed']=_0x26bc76,this['snapshot']=_0xeac850;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x1ec204,_0xf66d8f,_0x138cb5){if(_0x1ec204=N(_0x1ec204),ys('Reference.transaction',_0x1ec204['_path']),_0x1ec204['key']==='.length'||_0x1ec204['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x1ec204['key']+'\x20is\x20a\x20read-only\x20object.';const _0x1d2b7f=!0x0,_0xa99f1a=new ot(),_0x35ac1a=(_0x371d64,_0x1c7499,_0x589321)=>{let _0x232a38=null;_0x371d64?_0xa99f1a['reject'](_0x371d64):(_0x232a38=new st(_0x589321,new ee(_0x1ec204['_repo'],_0x1ec204['_path']),R),_0xa99f1a['resolve'](new tf(_0x1c7499,_0x232a38)));},_0x411478=Bd(_0x1ec204,()=>{});return kd(_0x1ec204['_repo'],_0x1ec204['_path'],_0xf66d8f,_0x35ac1a,_0x411478,_0x1d2b7f),_0xa99f1a['promise'];}se['prototype']['simpleListen']=function(_0x24088d,_0xb18331){this['sendRequest']('q',{'p':_0x24088d},_0xb18331);},se['prototype']['echo']=function(_0x3ec5d6,_0x44ccb9){this['sendRequest']('echo',{'d':_0x3ec5d6},_0x44ccb9);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x774375,..._0x4faa46){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x774375,..._0x4faa46);}function sn(_0x5d3a8f,..._0x27dd34){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x5d3a8f,..._0x27dd34);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x5a618c,..._0x396b9e){throw ws(_0x5a618c,..._0x396b9e);}function X(_0x505704,..._0x1c7de8){return ws(_0x505704,..._0x1c7de8);}function Ia(_0x1ceb64,_0x3878c4,_0x171dfe){const _0x285259={...nf(),[_0x3878c4]:_0x171dfe};return new Bt('auth','Firebase',_0x285259)['create'](_0x3878c4,{'appName':_0x1ceb64['name']});}function re(_0xe4d127){return Ia(_0xe4d127,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x56e7f5,..._0x1ca3ea){if(typeof _0x56e7f5!='string'){const _0x15d79e=_0x1ca3ea[0x0],_0xf2644f=[..._0x1ca3ea['slice'](0x1)];return _0xf2644f[0x0]&&(_0xf2644f[0x0]['appName']=_0x56e7f5['name']),_0x56e7f5['_errorFactory']['create'](_0x15d79e,..._0xf2644f);}return Ea['create'](_0x56e7f5,..._0x1ca3ea);}function m(_0x4674d4,_0x24c625,..._0xa6d483){if(!_0x4674d4)throw ws(_0x24c625,..._0xa6d483);}function ne(_0x465313){const _0x49791d='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x465313;throw sn(_0x49791d),new Error(_0x49791d);}function ce(_0x45a2f4,_0x581ce0){_0x45a2f4||ne(_0x581ce0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0xbf2ecb;return typeof self<'u'&&((_0xbf2ecb=self['location'])==null?void 0x0:_0xbf2ecb['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x3a6bc6;return typeof self<'u'&&((_0x3a6bc6=self['location'])==null?void 0x0:_0x3a6bc6['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0xb63996=navigator;return _0xb63996['languages']&&_0xb63996['languages'][0x0]||_0xb63996['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x582f08,_0x275058){this['shortDelay']=_0x582f08,this['longDelay']=_0x275058,ce(_0x275058>_0x582f08,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x2fe27a,_0x30f304){ce(_0x2fe27a['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x172b9c}=_0x2fe27a['emulator'];return _0x30f304?''+_0x172b9c+(_0x30f304['startsWith']('/')?_0x30f304['slice'](0x1):_0x30f304):_0x172b9c;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x2722b6,_0x3a8ed1,_0x2f3544){this['fetchImpl']=_0x2722b6,_0x3a8ed1&&(this['headersImpl']=_0x3a8ed1),_0x2f3544&&(this['responseImpl']=_0x2f3544);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x55eeda,_0x5e2199){return _0x55eeda['tenantId']&&!_0x5e2199['tenantId']?{..._0x5e2199,'tenantId':_0x55eeda['tenantId']}:_0x5e2199;}async function Ae(_0x1d7150,_0x253c06,_0x1461c3,_0x2cae3a,_0x20f0ec={}){return Ca(_0x1d7150,_0x20f0ec,async()=>{let _0x20528a={},_0x300da2={};_0x2cae3a&&(_0x253c06==='GET'?_0x300da2=_0x2cae3a:_0x20528a={'body':JSON['stringify'](_0x2cae3a)});const _0x620eb=ct({'key':_0x1d7150['config']['apiKey'],..._0x300da2})['slice'](0x1),_0xfed87b=await _0x1d7150['_getAdditionalHeaders']();_0xfed87b['Content-Type']='application/json',_0x1d7150['languageCode']&&(_0xfed87b['X-Firebase-Locale']=_0x1d7150['languageCode']);const _0x5aae5a={'method':_0x253c06,'headers':_0xfed87b,..._0x20528a};return dc()||(_0x5aae5a['referrerPolicy']='no-referrer'),_0x1d7150['emulatorConfig']&&at(_0x1d7150['emulatorConfig']['host'])&&(_0x5aae5a['credentials']='include'),wa['fetch']()(await Ta(_0x1d7150,_0x1d7150['config']['apiHost'],_0x1461c3,_0x620eb),_0x5aae5a);});}async function Ca(_0x4b0d6b,_0x58ccbd,_0x5dc23e){_0x4b0d6b['_canInitEmulator']=!0x1;const _0x2dae76={...cf,..._0x58ccbd};try{const _0x3c77ae=new df(_0x4b0d6b),_0x303482=await Promise['race']([_0x5dc23e(),_0x3c77ae['promise']]);_0x3c77ae['clearNetworkTimeout']();const _0xe84802=await _0x303482['json']();if('needConfirmation'in _0xe84802)throw tn(_0x4b0d6b,'account-exists-with-different-credential',_0xe84802);if(_0x303482['ok']&&!('errorMessage'in _0xe84802))return _0xe84802;{const _0x44732f=_0x303482['ok']?_0xe84802['errorMessage']:_0xe84802['error']['message'],[_0x42d03f,_0x2e9a8f]=_0x44732f['split']('\x20:\x20');if(_0x42d03f==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x4b0d6b,'credential-already-in-use',_0xe84802);if(_0x42d03f==='EMAIL_EXISTS')throw tn(_0x4b0d6b,'email-already-in-use',_0xe84802);if(_0x42d03f==='USER_DISABLED')throw tn(_0x4b0d6b,'user-disabled',_0xe84802);const _0x166df9=_0x2dae76[_0x42d03f]||_0x42d03f['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x2e9a8f)throw Ia(_0x4b0d6b,_0x166df9,_0x2e9a8f);Q(_0x4b0d6b,_0x166df9);}}catch(_0x2576a5){if(_0x2576a5 instanceof Se)throw _0x2576a5;Q(_0x4b0d6b,'network-request-failed',{'message':String(_0x2576a5)});}}async function Qt(_0x3d526f,_0x216b36,_0x4c28a2,_0x1c67fe,_0x533e5a={}){const _0x429e98=await Ae(_0x3d526f,_0x216b36,_0x4c28a2,_0x1c67fe,_0x533e5a);return'mfaPendingCredential'in _0x429e98&&Q(_0x3d526f,'multi-factor-auth-required',{'_serverResponse':_0x429e98}),_0x429e98;}async function Ta(_0x4f7975,_0x425d74,_0x5f535f,_0x5c1b56){const _0xc71eb7=''+_0x425d74+_0x5f535f+'?'+_0x5c1b56,_0x235f86=_0x4f7975,_0x10d0a1=_0x235f86['config']['emulator']?Cs(_0x4f7975['config'],_0xc71eb7):_0x4f7975['config']['apiScheme']+'://'+_0xc71eb7;return lf['includes'](_0x5f535f)&&(await _0x235f86['_persistenceManagerAvailable'],_0x235f86['_getPersistenceType']()==='COOKIE')?_0x235f86['_getPersistence']()['_getFinalTarget'](_0x10d0a1)['toString']():_0x10d0a1;}function uf(_0x449a11){switch(_0x449a11){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x8dc44f){this['auth']=_0x8dc44f,this['timer']=null,this['promise']=new Promise((_0x46b88a,_0x58adb4)=>{this['timer']=setTimeout(()=>_0x58adb4(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x2f7d4a,_0x425b1e,_0x3b4cf8){const _0x360e89={'appName':_0x2f7d4a['name']};_0x3b4cf8['email']&&(_0x360e89['email']=_0x3b4cf8['email']),_0x3b4cf8['phoneNumber']&&(_0x360e89['phoneNumber']=_0x3b4cf8['phoneNumber']);const _0x34c973=X(_0x2f7d4a,_0x425b1e,_0x360e89);return _0x34c973['customData']['_tokenResponse']=_0x3b4cf8,_0x34c973;}function wr(_0x3ea108){return _0x3ea108!==void 0x0&&_0x3ea108['enterprise']!==void 0x0;}class ff{constructor(_0x388f00){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x388f00['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x388f00['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x388f00['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x153945){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x5f25fd of this['recaptchaEnforcementState'])if(_0x5f25fd['provider']&&_0x5f25fd['provider']===_0x153945)return uf(_0x5f25fd['enforcementState']);return null;}['isProviderEnabled'](_0x3be531){return this['getProviderEnforcementState'](_0x3be531)==='ENFORCE'||this['getProviderEnforcementState'](_0x3be531)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x2dac85,_0x585e60){return Ae(_0x2dac85,'GET','/v2/recaptchaConfig',Re(_0x2dac85,_0x585e60));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0xfcf39b,_0x474806){return Ae(_0xfcf39b,'POST','/v1/accounts:delete',_0x474806);}async function bn(_0x2bb5ea,_0x4170f3){return Ae(_0x2bb5ea,'POST','/v1/accounts:lookup',_0x4170f3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x1f95a3){if(_0x1f95a3)try{const _0x100dcb=new Date(Number(_0x1f95a3));if(!isNaN(_0x100dcb['getTime']()))return _0x100dcb['toUTCString']();}catch{}}async function gf(_0x244c9f,_0x47177d=!0x1){const _0xe03033=N(_0x244c9f),_0x290aab=await _0xe03033['getIdToken'](_0x47177d),_0x406ebd=Ts(_0x290aab);m(_0x406ebd&&_0x406ebd['exp']&&_0x406ebd['auth_time']&&_0x406ebd['iat'],_0xe03033['auth'],'internal-error');const _0x5d3386=typeof _0x406ebd['firebase']=='object'?_0x406ebd['firebase']:void 0x0,_0x4fe347=_0x5d3386==null?void 0x0:_0x5d3386['sign_in_provider'];return{'claims':_0x406ebd,'token':_0x290aab,'authTime':Rt(li(_0x406ebd['auth_time'])),'issuedAtTime':Rt(li(_0x406ebd['iat'])),'expirationTime':Rt(li(_0x406ebd['exp'])),'signInProvider':_0x4fe347||null,'signInSecondFactor':(_0x5d3386==null?void 0x0:_0x5d3386['sign_in_second_factor'])||null};}function li(_0x2d8d06){return Number(_0x2d8d06)*0x3e8;}function Ts(_0x84d29f){const [_0x5a36b6,_0x388f13,_0xb61f7f]=_0x84d29f['split']('.');if(_0x5a36b6===void 0x0||_0x388f13===void 0x0||_0xb61f7f===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x45cdec=ln(_0x388f13);return _0x45cdec?JSON['parse'](_0x45cdec):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x245fde){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x245fde==null?void 0x0:_0x245fde['toString']()),null;}}function Cr(_0x2846c5){const _0x5849fe=Ts(_0x2846c5);return m(_0x5849fe,'internal-error'),m(typeof _0x5849fe['exp']<'u','internal-error'),m(typeof _0x5849fe['iat']<'u','internal-error'),Number(_0x5849fe['exp'])-Number(_0x5849fe['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x498852,_0xcf2733,_0x2e4d70=!0x1){if(_0x2e4d70)return _0xcf2733;try{return await _0xcf2733;}catch(_0xdc6a75){throw _0xdc6a75 instanceof Se&&mf(_0xdc6a75)&&_0x498852['auth']['currentUser']===_0x498852&&await _0x498852['auth']['signOut'](),_0xdc6a75;}}function mf({code:_0xfe8eb3}){return _0xfe8eb3==='auth/user-disabled'||_0xfe8eb3==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x3516cc){this['user']=_0x3516cc,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x20aa24){if(_0x20aa24){const _0x4c42d3=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x4c42d3;}else{this['errorBackoff']=0x7530;const _0x1d23f8=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x1d23f8);}}['schedule'](_0x23c01f=!0x1){if(!this['isRunning'])return;const _0x4b8990=this['getInterval'](_0x23c01f);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x4b8990);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x45e256){(_0x45e256==null?void 0x0:_0x45e256['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x2274c2,_0x391524){this['createdAt']=_0x2274c2,this['lastLoginAt']=_0x391524,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x5f2c82){this['createdAt']=_0x5f2c82['createdAt'],this['lastLoginAt']=_0x5f2c82['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x3fa537){var _0x522b1e;const _0x1bc59f=_0x3fa537['auth'],_0x214405=await _0x3fa537['getIdToken'](),_0x5de86e=await Ut(_0x3fa537,bn(_0x1bc59f,{'idToken':_0x214405}));m(_0x5de86e==null?void 0x0:_0x5de86e['users']['length'],_0x1bc59f,'internal-error');const _0x1f70cd=_0x5de86e['users'][0x0];_0x3fa537['_notifyReloadListener'](_0x1f70cd);const _0x4ef21d=(_0x522b1e=_0x1f70cd['providerUserInfo'])!=null&&_0x522b1e['length']?Sa(_0x1f70cd['providerUserInfo']):[],_0x2d2f61=Ef(_0x3fa537['providerData'],_0x4ef21d),_0x5d3c8a=_0x3fa537['isAnonymous'],_0x34a854=!(_0x3fa537['email']&&_0x1f70cd['passwordHash'])&&!(_0x2d2f61!=null&&_0x2d2f61['length']),_0x26ac12=_0x5d3c8a?_0x34a854:!0x1,_0x24737e={'uid':_0x1f70cd['localId'],'displayName':_0x1f70cd['displayName']||null,'photoURL':_0x1f70cd['photoUrl']||null,'email':_0x1f70cd['email']||null,'emailVerified':_0x1f70cd['emailVerified']||!0x1,'phoneNumber':_0x1f70cd['phoneNumber']||null,'tenantId':_0x1f70cd['tenantId']||null,'providerData':_0x2d2f61,'metadata':new Oi(_0x1f70cd['createdAt'],_0x1f70cd['lastLoginAt']),'isAnonymous':_0x26ac12};Object['assign'](_0x3fa537,_0x24737e);}async function vf(_0x123e5c){const _0x53eead=N(_0x123e5c);await Rn(_0x53eead),await _0x53eead['auth']['_persistUserIfCurrent'](_0x53eead),_0x53eead['auth']['_notifyListenersIfCurrent'](_0x53eead);}function Ef(_0x41e23e,_0x3deb23){return[..._0x41e23e['filter'](_0xb3e876=>!_0x3deb23['some'](_0x29f1ee=>_0x29f1ee['providerId']===_0xb3e876['providerId'])),..._0x3deb23];}function Sa(_0x51140b){return _0x51140b['map'](({providerId:_0x3e9f36,..._0x4b0982})=>({'providerId':_0x3e9f36,'uid':_0x4b0982['rawId']||'','displayName':_0x4b0982['displayName']||null,'email':_0x4b0982['email']||null,'phoneNumber':_0x4b0982['phoneNumber']||null,'photoURL':_0x4b0982['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x4d67fc,_0x41a6d7){const _0x22bb03=await Ca(_0x4d67fc,{},async()=>{const _0x26d6e9=ct({'grant_type':'refresh_token','refresh_token':_0x41a6d7})['slice'](0x1),{tokenApiHost:_0x211b64,apiKey:_0x48cb65}=_0x4d67fc['config'],_0x58afa2=await Ta(_0x4d67fc,_0x211b64,'/v1/token','key='+_0x48cb65),_0x53941b=await _0x4d67fc['_getAdditionalHeaders']();_0x53941b['Content-Type']='application/x-www-form-urlencoded';const _0xb74866={'method':'POST','headers':_0x53941b,'body':_0x26d6e9};return _0x4d67fc['emulatorConfig']&&at(_0x4d67fc['emulatorConfig']['host'])&&(_0xb74866['credentials']='include'),wa['fetch']()(_0x58afa2,_0xb74866);});return{'accessToken':_0x22bb03['access_token'],'expiresIn':_0x22bb03['expires_in'],'refreshToken':_0x22bb03['refresh_token']};}async function wf(_0x1ae230,_0x5f2398){return Ae(_0x1ae230,'POST','/v2/accounts:revokeToken',Re(_0x1ae230,_0x5f2398));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x5cb5cc){m(_0x5cb5cc['idToken'],'internal-error'),m(typeof _0x5cb5cc['idToken']<'u','internal-error'),m(typeof _0x5cb5cc['refreshToken']<'u','internal-error');const _0x3de9ed='expiresIn'in _0x5cb5cc&&typeof _0x5cb5cc['expiresIn']<'u'?Number(_0x5cb5cc['expiresIn']):Cr(_0x5cb5cc['idToken']);this['updateTokensAndExpiration'](_0x5cb5cc['idToken'],_0x5cb5cc['refreshToken'],_0x3de9ed);}['updateFromIdToken'](_0x1d0c3b){m(_0x1d0c3b['length']!==0x0,'internal-error');const _0x1122da=Cr(_0x1d0c3b);this['updateTokensAndExpiration'](_0x1d0c3b,null,_0x1122da);}async['getToken'](_0x4bb36b,_0x114ec7=!0x1){return!_0x114ec7&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x4bb36b,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x4bb36b,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x20513b,_0x1a27b9){const {accessToken:_0xdd4363,refreshToken:_0x1d7b52,expiresIn:_0x3c8e2f}=await If(_0x20513b,_0x1a27b9);this['updateTokensAndExpiration'](_0xdd4363,_0x1d7b52,Number(_0x3c8e2f));}['updateTokensAndExpiration'](_0x47f8c0,_0x114c9d,_0x5d2f7c){this['refreshToken']=_0x114c9d||null,this['accessToken']=_0x47f8c0||null,this['expirationTime']=Date['now']()+_0x5d2f7c*0x3e8;}static['fromJSON'](_0xba419,_0x483ec3){const {refreshToken:_0x19420c,accessToken:_0x58d703,expirationTime:_0x5ee332}=_0x483ec3,_0x7c1b05=new Qe();return _0x19420c&&(m(typeof _0x19420c=='string','internal-error',{'appName':_0xba419}),_0x7c1b05['refreshToken']=_0x19420c),_0x58d703&&(m(typeof _0x58d703=='string','internal-error',{'appName':_0xba419}),_0x7c1b05['accessToken']=_0x58d703),_0x5ee332&&(m(typeof _0x5ee332=='number','internal-error',{'appName':_0xba419}),_0x7c1b05['expirationTime']=_0x5ee332),_0x7c1b05;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x7cd601){this['accessToken']=_0x7cd601['accessToken'],this['refreshToken']=_0x7cd601['refreshToken'],this['expirationTime']=_0x7cd601['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0xfb0347,_0x47db0e){m(typeof _0xfb0347=='string'||typeof _0xfb0347>'u','internal-error',{'appName':_0x47db0e});}class K{constructor({uid:_0x23e971,auth:_0x464af9,stsTokenManager:_0x54d028,..._0x83596b}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x23e971,this['auth']=_0x464af9,this['stsTokenManager']=_0x54d028,this['accessToken']=_0x54d028['accessToken'],this['displayName']=_0x83596b['displayName']||null,this['email']=_0x83596b['email']||null,this['emailVerified']=_0x83596b['emailVerified']||!0x1,this['phoneNumber']=_0x83596b['phoneNumber']||null,this['photoURL']=_0x83596b['photoURL']||null,this['isAnonymous']=_0x83596b['isAnonymous']||!0x1,this['tenantId']=_0x83596b['tenantId']||null,this['providerData']=_0x83596b['providerData']?[..._0x83596b['providerData']]:[],this['metadata']=new Oi(_0x83596b['createdAt']||void 0x0,_0x83596b['lastLoginAt']||void 0x0);}async['getIdToken'](_0x5c738a){const _0x4ab514=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x5c738a));return m(_0x4ab514,this['auth'],'internal-error'),this['accessToken']!==_0x4ab514&&(this['accessToken']=_0x4ab514,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x4ab514;}['getIdTokenResult'](_0x3781a1){return gf(this,_0x3781a1);}['reload'](){return vf(this);}['_assign'](_0x2b92a4){this!==_0x2b92a4&&(m(this['uid']===_0x2b92a4['uid'],this['auth'],'internal-error'),this['displayName']=_0x2b92a4['displayName'],this['photoURL']=_0x2b92a4['photoURL'],this['email']=_0x2b92a4['email'],this['emailVerified']=_0x2b92a4['emailVerified'],this['phoneNumber']=_0x2b92a4['phoneNumber'],this['isAnonymous']=_0x2b92a4['isAnonymous'],this['tenantId']=_0x2b92a4['tenantId'],this['providerData']=_0x2b92a4['providerData']['map'](_0x23d4cf=>({..._0x23d4cf})),this['metadata']['_copy'](_0x2b92a4['metadata']),this['stsTokenManager']['_assign'](_0x2b92a4['stsTokenManager']));}['_clone'](_0x275050){const _0x1e043a=new K({...this,'auth':_0x275050,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x1e043a['metadata']['_copy'](this['metadata']),_0x1e043a;}['_onReload'](_0x4c6419){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x4c6419,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x9debf6){this['reloadListener']?this['reloadListener'](_0x9debf6):this['reloadUserInfo']=_0x9debf6;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x3a67d4,_0x39facc=!0x1){let _0xee181=!0x1;_0x3a67d4['idToken']&&_0x3a67d4['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x3a67d4),_0xee181=!0x0),_0x39facc&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0xee181&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x3b7308=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x3b7308})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x2cc14a=>({..._0x2cc14a})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x2ecc9d,_0xe2e406){const _0x5d4242=_0xe2e406['displayName']??void 0x0,_0x27a33c=_0xe2e406['email']??void 0x0,_0x18ca13=_0xe2e406['phoneNumber']??void 0x0,_0x154c30=_0xe2e406['photoURL']??void 0x0,_0x361e2b=_0xe2e406['tenantId']??void 0x0,_0x190e71=_0xe2e406['_redirectEventId']??void 0x0,_0x55258e=_0xe2e406['createdAt']??void 0x0,_0x2b02ad=_0xe2e406['lastLoginAt']??void 0x0,{uid:_0x1d6fe3,emailVerified:_0x44d682,isAnonymous:_0x3190cc,providerData:_0x3887fb,stsTokenManager:_0x19058f}=_0xe2e406;m(_0x1d6fe3&&_0x19058f,_0x2ecc9d,'internal-error');const _0x336d52=Qe['fromJSON'](this['name'],_0x19058f);m(typeof _0x1d6fe3=='string',_0x2ecc9d,'internal-error'),le(_0x5d4242,_0x2ecc9d['name']),le(_0x27a33c,_0x2ecc9d['name']),m(typeof _0x44d682=='boolean',_0x2ecc9d,'internal-error'),m(typeof _0x3190cc=='boolean',_0x2ecc9d,'internal-error'),le(_0x18ca13,_0x2ecc9d['name']),le(_0x154c30,_0x2ecc9d['name']),le(_0x361e2b,_0x2ecc9d['name']),le(_0x190e71,_0x2ecc9d['name']),le(_0x55258e,_0x2ecc9d['name']),le(_0x2b02ad,_0x2ecc9d['name']);const _0x3890d1=new K({'uid':_0x1d6fe3,'auth':_0x2ecc9d,'email':_0x27a33c,'emailVerified':_0x44d682,'displayName':_0x5d4242,'isAnonymous':_0x3190cc,'photoURL':_0x154c30,'phoneNumber':_0x18ca13,'tenantId':_0x361e2b,'stsTokenManager':_0x336d52,'createdAt':_0x55258e,'lastLoginAt':_0x2b02ad});return _0x3887fb&&Array['isArray'](_0x3887fb)&&(_0x3890d1['providerData']=_0x3887fb['map'](_0x452692=>({..._0x452692}))),_0x190e71&&(_0x3890d1['_redirectEventId']=_0x190e71),_0x3890d1;}static async['_fromIdTokenResponse'](_0x31f1d4,_0xfdf80,_0x532052=!0x1){const _0x30857c=new Qe();_0x30857c['updateFromServerResponse'](_0xfdf80);const _0x1aed3c=new K({'uid':_0xfdf80['localId'],'auth':_0x31f1d4,'stsTokenManager':_0x30857c,'isAnonymous':_0x532052});return await Rn(_0x1aed3c),_0x1aed3c;}static async['_fromGetAccountInfoResponse'](_0x36400d,_0x261f66,_0x19ab4b){const _0x452efd=_0x261f66['users'][0x0];m(_0x452efd['localId']!==void 0x0,'internal-error');const _0x29b414=_0x452efd['providerUserInfo']!==void 0x0?Sa(_0x452efd['providerUserInfo']):[],_0x165d22=!(_0x452efd['email']&&_0x452efd['passwordHash'])&&!(_0x29b414!=null&&_0x29b414['length']),_0x20826f=new Qe();_0x20826f['updateFromIdToken'](_0x19ab4b);const _0x5daf6d=new K({'uid':_0x452efd['localId'],'auth':_0x36400d,'stsTokenManager':_0x20826f,'isAnonymous':_0x165d22}),_0x7d3d3b={'uid':_0x452efd['localId'],'displayName':_0x452efd['displayName']||null,'photoURL':_0x452efd['photoUrl']||null,'email':_0x452efd['email']||null,'emailVerified':_0x452efd['emailVerified']||!0x1,'phoneNumber':_0x452efd['phoneNumber']||null,'tenantId':_0x452efd['tenantId']||null,'providerData':_0x29b414,'metadata':new Oi(_0x452efd['createdAt'],_0x452efd['lastLoginAt']),'isAnonymous':!(_0x452efd['email']&&_0x452efd['passwordHash'])&&!(_0x29b414!=null&&_0x29b414['length'])};return Object['assign'](_0x5daf6d,_0x7d3d3b),_0x5daf6d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x5a1782){ce(_0x5a1782 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x4cd8a3=Tr['get'](_0x5a1782);return _0x4cd8a3?(ce(_0x4cd8a3 instanceof _0x5a1782,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x4cd8a3):(_0x4cd8a3=new _0x5a1782(),Tr['set'](_0x5a1782,_0x4cd8a3),_0x4cd8a3);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x381d48,_0x4f802c){this['storage'][_0x381d48]=_0x4f802c;}async['_get'](_0x281148){const _0x29cda4=this['storage'][_0x281148];return _0x29cda4===void 0x0?null:_0x29cda4;}async['_remove'](_0xc0e7){delete this['storage'][_0xc0e7];}['_addListener'](_0x4c807b,_0x1c542f){}['_removeListener'](_0x37a548,_0x295141){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x17c196,_0x2142c4,_0x234022){return'firebase:'+_0x17c196+':'+_0x2142c4+':'+_0x234022;}class Je{constructor(_0x427d1d,_0x2cb012,_0x3c37fa){this['persistence']=_0x427d1d,this['auth']=_0x2cb012,this['userKey']=_0x3c37fa;const {config:_0xd4f77d,name:_0x37b184}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0xd4f77d['apiKey'],_0x37b184),this['fullPersistenceKey']=rn('persistence',_0xd4f77d['apiKey'],_0x37b184),this['boundEventHandler']=_0x2cb012['_onStorageEvent']['bind'](_0x2cb012),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x4d7dc8){return this['persistence']['_set'](this['fullUserKey'],_0x4d7dc8['toJSON']());}async['getCurrentUser'](){const _0x2cad08=await this['persistence']['_get'](this['fullUserKey']);if(!_0x2cad08)return null;if(typeof _0x2cad08=='string'){const _0x4333a8=await bn(this['auth'],{'idToken':_0x2cad08})['catch'](()=>{});return _0x4333a8?K['_fromGetAccountInfoResponse'](this['auth'],_0x4333a8,_0x2cad08):null;}return K['_fromJSON'](this['auth'],_0x2cad08);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x38e359){if(this['persistence']===_0x38e359)return;const _0x2c51dc=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x38e359,_0x2c51dc)return this['setCurrentUser'](_0x2c51dc);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x212f91,_0x227d05,_0x39f4ab='authUser'){if(!_0x227d05['length'])return new Je(ie(Sr),_0x212f91,_0x39f4ab);const _0x131742=(await Promise['all'](_0x227d05['map'](async _0x5f5b7c=>{if(await _0x5f5b7c['_isAvailable']())return _0x5f5b7c;})))['filter'](_0x51a8f3=>_0x51a8f3);let _0x10d881=_0x131742[0x0]||ie(Sr);const _0x13880e=rn(_0x39f4ab,_0x212f91['config']['apiKey'],_0x212f91['name']);let _0x4dad3f=null;for(const _0x3d9671 of _0x227d05)try{const _0xdcf8dc=await _0x3d9671['_get'](_0x13880e);if(_0xdcf8dc){let _0x3414f2;if(typeof _0xdcf8dc=='string'){const _0x2d29a6=await bn(_0x212f91,{'idToken':_0xdcf8dc})['catch'](()=>{});if(!_0x2d29a6)break;_0x3414f2=await K['_fromGetAccountInfoResponse'](_0x212f91,_0x2d29a6,_0xdcf8dc);}else _0x3414f2=K['_fromJSON'](_0x212f91,_0xdcf8dc);_0x3d9671!==_0x10d881&&(_0x4dad3f=_0x3414f2),_0x10d881=_0x3d9671;break;}}catch{}const _0x58b908=_0x131742['filter'](_0x133107=>_0x133107['_shouldAllowMigration']);return!_0x10d881['_shouldAllowMigration']||!_0x58b908['length']?new Je(_0x10d881,_0x212f91,_0x39f4ab):(_0x10d881=_0x58b908[0x0],_0x4dad3f&&await _0x10d881['_set'](_0x13880e,_0x4dad3f['toJSON']()),await Promise['all'](_0x227d05['map'](async _0x623bd3=>{if(_0x623bd3!==_0x10d881)try{await _0x623bd3['_remove'](_0x13880e);}catch{}})),new Je(_0x10d881,_0x212f91,_0x39f4ab));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x465041){const _0x1026ca=_0x465041['toLowerCase']();if(_0x1026ca['includes']('opera/')||_0x1026ca['includes']('opr/')||_0x1026ca['includes']('opios/'))return'Opera';if(Na(_0x1026ca))return'IEMobile';if(_0x1026ca['includes']('msie')||_0x1026ca['includes']('trident/'))return'IE';if(_0x1026ca['includes']('edge/'))return'Edge';if(Ra(_0x1026ca))return'Firefox';if(_0x1026ca['includes']('silk/'))return'Silk';if(Oa(_0x1026ca))return'Blackberry';if(Da(_0x1026ca))return'Webos';if(Aa(_0x1026ca))return'Safari';if((_0x1026ca['includes']('chrome/')||ka(_0x1026ca))&&!_0x1026ca['includes']('edge/'))return'Chrome';if(Pa(_0x1026ca))return'Android';{const _0x15d291=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x86eefb=_0x465041['match'](_0x15d291);if((_0x86eefb==null?void 0x0:_0x86eefb['length'])===0x2)return _0x86eefb[0x1];}return'Other';}function Ra(_0x47e8d8=W()){return/firefox\//i['test'](_0x47e8d8);}function Aa(_0x532eca=W()){const _0x24cffd=_0x532eca['toLowerCase']();return _0x24cffd['includes']('safari/')&&!_0x24cffd['includes']('chrome/')&&!_0x24cffd['includes']('crios/')&&!_0x24cffd['includes']('android');}function ka(_0x3187c6=W()){return/crios\//i['test'](_0x3187c6);}function Na(_0x42a9b1=W()){return/iemobile/i['test'](_0x42a9b1);}function Pa(_0x23dc62=W()){return/android/i['test'](_0x23dc62);}function Oa(_0x2ba8bb=W()){return/blackberry/i['test'](_0x2ba8bb);}function Da(_0x430a31=W()){return/webos/i['test'](_0x430a31);}function Ss(_0x342368=W()){return/iphone|ipad|ipod/i['test'](_0x342368)||/macintosh/i['test'](_0x342368)&&/mobile/i['test'](_0x342368);}function Cf(_0x19ea26=W()){var _0x264d28;return Ss(_0x19ea26)&&!!((_0x264d28=window['navigator'])!=null&&_0x264d28['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x164b1f=W()){return Ss(_0x164b1f)||Pa(_0x164b1f)||Da(_0x164b1f)||Oa(_0x164b1f)||/windows phone/i['test'](_0x164b1f)||Na(_0x164b1f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x461498,_0x4e1fb8=[]){let _0x58bd4d;switch(_0x461498){case'Browser':_0x58bd4d=br(W());break;case'Worker':_0x58bd4d=br(W())+'-'+_0x461498;break;default:_0x58bd4d=_0x461498;}const _0x4adc6e=_0x4e1fb8['length']?_0x4e1fb8['join'](','):'FirebaseCore-web';return _0x58bd4d+'/JsCore/'+lt+'/'+_0x4adc6e;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0xbbd3ea){this['auth']=_0xbbd3ea,this['queue']=[];}['pushCallback'](_0xb15883,_0x3d4af7){const _0x1a6e5c=_0x15cfcf=>new Promise((_0x4a50df,_0x33b3c5)=>{try{const _0x5c8fc6=_0xb15883(_0x15cfcf);_0x4a50df(_0x5c8fc6);}catch(_0x8f6549){_0x33b3c5(_0x8f6549);}});_0x1a6e5c['onAbort']=_0x3d4af7,this['queue']['push'](_0x1a6e5c);const _0x4c26b7=this['queue']['length']-0x1;return()=>{this['queue'][_0x4c26b7]=()=>Promise['resolve']();};}async['runMiddleware'](_0x485bec){if(this['auth']['currentUser']===_0x485bec)return;const _0x31943c=[];try{for(const _0x3fb5d7 of this['queue'])await _0x3fb5d7(_0x485bec),_0x3fb5d7['onAbort']&&_0x31943c['push'](_0x3fb5d7['onAbort']);}catch(_0x4f9cae){_0x31943c['reverse']();for(const _0x351bba of _0x31943c)try{_0x351bba();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x4f9cae==null?void 0x0:_0x4f9cae['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x1e5027,_0x4d68d6={}){return Ae(_0x1e5027,'GET','/v2/passwordPolicy',Re(_0x1e5027,_0x4d68d6));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x14cf69){var _0x35d27c;const _0x578fb4=_0x14cf69['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x578fb4['minPasswordLength']??Rf,_0x578fb4['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x578fb4['maxPasswordLength']),_0x578fb4['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x578fb4['containsLowercaseCharacter']),_0x578fb4['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x578fb4['containsUppercaseCharacter']),_0x578fb4['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x578fb4['containsNumericCharacter']),_0x578fb4['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x578fb4['containsNonAlphanumericCharacter']),this['enforcementState']=_0x14cf69['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x35d27c=_0x14cf69['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x35d27c['join'](''))??'',this['forceUpgradeOnSignin']=_0x14cf69['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x14cf69['schemaVersion'];}['validatePassword'](_0x25d04b){const _0x4bfdd9={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x25d04b,_0x4bfdd9),this['validatePasswordCharacterOptions'](_0x25d04b,_0x4bfdd9),_0x4bfdd9['isValid']&&(_0x4bfdd9['isValid']=_0x4bfdd9['meetsMinPasswordLength']??!0x0),_0x4bfdd9['isValid']&&(_0x4bfdd9['isValid']=_0x4bfdd9['meetsMaxPasswordLength']??!0x0),_0x4bfdd9['isValid']&&(_0x4bfdd9['isValid']=_0x4bfdd9['containsLowercaseLetter']??!0x0),_0x4bfdd9['isValid']&&(_0x4bfdd9['isValid']=_0x4bfdd9['containsUppercaseLetter']??!0x0),_0x4bfdd9['isValid']&&(_0x4bfdd9['isValid']=_0x4bfdd9['containsNumericCharacter']??!0x0),_0x4bfdd9['isValid']&&(_0x4bfdd9['isValid']=_0x4bfdd9['containsNonAlphanumericCharacter']??!0x0),_0x4bfdd9;}['validatePasswordLengthOptions'](_0x38806d,_0x189e32){const _0x24c34f=this['customStrengthOptions']['minPasswordLength'],_0x56ae94=this['customStrengthOptions']['maxPasswordLength'];_0x24c34f&&(_0x189e32['meetsMinPasswordLength']=_0x38806d['length']>=_0x24c34f),_0x56ae94&&(_0x189e32['meetsMaxPasswordLength']=_0x38806d['length']<=_0x56ae94);}['validatePasswordCharacterOptions'](_0x2ac45a,_0x4f3fda){this['updatePasswordCharacterOptionsStatuses'](_0x4f3fda,!0x1,!0x1,!0x1,!0x1);let _0x3ba2cd;for(let _0xaeb4ec=0x0;_0xaeb4ec<_0x2ac45a['length'];_0xaeb4ec++)_0x3ba2cd=_0x2ac45a['charAt'](_0xaeb4ec),this['updatePasswordCharacterOptionsStatuses'](_0x4f3fda,_0x3ba2cd>='a'&&_0x3ba2cd<='z',_0x3ba2cd>='A'&&_0x3ba2cd<='Z',_0x3ba2cd>='0'&&_0x3ba2cd<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x3ba2cd));}['updatePasswordCharacterOptionsStatuses'](_0x210899,_0x4ef926,_0x3b2bf2,_0x1dec71,_0x3fa2c8){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x210899['containsLowercaseLetter']||(_0x210899['containsLowercaseLetter']=_0x4ef926)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x210899['containsUppercaseLetter']||(_0x210899['containsUppercaseLetter']=_0x3b2bf2)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x210899['containsNumericCharacter']||(_0x210899['containsNumericCharacter']=_0x1dec71)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x210899['containsNonAlphanumericCharacter']||(_0x210899['containsNonAlphanumericCharacter']=_0x3fa2c8));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0xb8399b,_0x25671d,_0x4bc73c,_0x36a200){this['app']=_0xb8399b,this['heartbeatServiceProvider']=_0x25671d,this['appCheckServiceProvider']=_0x4bc73c,this['config']=_0x36a200,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0xb8399b['name'],this['clientVersion']=_0x36a200['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x4813f4=>this['_resolvePersistenceManagerAvailable']=_0x4813f4);}['_initializeWithPersistence'](_0x1b6e2b,_0x5a5c91){return _0x5a5c91&&(this['_popupRedirectResolver']=ie(_0x5a5c91)),this['_initializationPromise']=this['queue'](async()=>{var _0x91124e,_0x4d6d0e,_0xed8d05;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x1b6e2b),(_0x91124e=this['_resolvePersistenceManagerAvailable'])==null||_0x91124e['call'](this),!this['_deleted'])){if((_0x4d6d0e=this['_popupRedirectResolver'])!=null&&_0x4d6d0e['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x5a5c91),this['lastNotifiedUid']=((_0xed8d05=this['currentUser'])==null?void 0x0:_0xed8d05['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x38a104=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x38a104)){if(this['currentUser']&&_0x38a104&&this['currentUser']['uid']===_0x38a104['uid']){this['_currentUser']['_assign'](_0x38a104),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x38a104,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x280bd8){try{const _0x3a5a89=await bn(this,{'idToken':_0x280bd8}),_0x33201e=await K['_fromGetAccountInfoResponse'](this,_0x3a5a89,_0x280bd8);await this['directlySetCurrentUser'](_0x33201e);}catch(_0x5c9ed0){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x5c9ed0),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x1be756){var _0x87e874;if($(this['app'])){const _0x2c559a=this['app']['settings']['authIdToken'];return _0x2c559a?new Promise(_0x1ced9b=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2c559a)['then'](_0x1ced9b,_0x1ced9b));}):this['directlySetCurrentUser'](null);}const _0x1ef433=await this['assertedPersistence']['getCurrentUser']();let _0x65fdc2=_0x1ef433,_0x13fa91=!0x1;if(_0x1be756&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x3bbfbc=(_0x87e874=this['redirectUser'])==null?void 0x0:_0x87e874['_redirectEventId'],_0x2fcf7b=_0x65fdc2==null?void 0x0:_0x65fdc2['_redirectEventId'],_0xd00bf8=await this['tryRedirectSignIn'](_0x1be756);(!_0x3bbfbc||_0x3bbfbc===_0x2fcf7b)&&(_0xd00bf8!=null&&_0xd00bf8['user'])&&(_0x65fdc2=_0xd00bf8['user'],_0x13fa91=!0x0);}if(!_0x65fdc2)return this['directlySetCurrentUser'](null);if(!_0x65fdc2['_redirectEventId']){if(_0x13fa91)try{await this['beforeStateQueue']['runMiddleware'](_0x65fdc2);}catch(_0x43b52c){_0x65fdc2=_0x1ef433,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x43b52c));}return _0x65fdc2?this['reloadAndSetCurrentUserOrClear'](_0x65fdc2):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x65fdc2['_redirectEventId']?this['directlySetCurrentUser'](_0x65fdc2):this['reloadAndSetCurrentUserOrClear'](_0x65fdc2);}async['tryRedirectSignIn'](_0x59e4e4){let _0x396e76=null;try{_0x396e76=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x59e4e4,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x396e76;}async['reloadAndSetCurrentUserOrClear'](_0x337459){try{await Rn(_0x337459);}catch(_0xe73cc3){if((_0xe73cc3==null?void 0x0:_0xe73cc3['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x337459);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x32fea){if($(this['app']))return Promise['reject'](re(this));const _0x110020=_0x32fea?N(_0x32fea):null;return _0x110020&&m(_0x110020['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x110020&&_0x110020['_clone'](this));}async['_updateCurrentUser'](_0xd5b058,_0x256ed1=!0x1){if(!this['_deleted'])return _0xd5b058&&m(this['tenantId']===_0xd5b058['tenantId'],this,'tenant-id-mismatch'),_0x256ed1||await this['beforeStateQueue']['runMiddleware'](_0xd5b058),this['queue'](async()=>{await this['directlySetCurrentUser'](_0xd5b058),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x4b55a4){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x4b55a4));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x13dc51){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x40ac35=this['_getPasswordPolicyInternal']();return _0x40ac35['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x40ac35['validatePassword'](_0x13dc51);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x827081=await bf(this),_0xb278f=new Af(_0x827081);this['tenantId']===null?this['_projectPasswordPolicy']=_0xb278f:this['_tenantPasswordPolicies'][this['tenantId']]=_0xb278f;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x2ea6b5){this['_errorFactory']=new Bt('auth','Firebase',_0x2ea6b5());}['onAuthStateChanged'](_0x58bb9e,_0x40e307,_0x2e2e0){return this['registerStateListener'](this['authStateSubscription'],_0x58bb9e,_0x40e307,_0x2e2e0);}['beforeAuthStateChanged'](_0x574d81,_0xae2ad8){return this['beforeStateQueue']['pushCallback'](_0x574d81,_0xae2ad8);}['onIdTokenChanged'](_0x26036e,_0x366974,_0x20b5f5){return this['registerStateListener'](this['idTokenSubscription'],_0x26036e,_0x366974,_0x20b5f5);}['authStateReady'](){return new Promise((_0x49cbf6,_0xcbb040)=>{if(this['currentUser'])_0x49cbf6();else{const _0x2c48ac=this['onAuthStateChanged'](()=>{_0x2c48ac(),_0x49cbf6();},_0xcbb040);}});}async['revokeAccessToken'](_0x29c1f8){if(this['currentUser']){const _0x20e06d=await this['currentUser']['getIdToken'](),_0x198c0a={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x29c1f8,'idToken':_0x20e06d};this['tenantId']!=null&&(_0x198c0a['tenantId']=this['tenantId']),await wf(this,_0x198c0a);}}['toJSON'](){var _0x6d5be6;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x6d5be6=this['_currentUser'])==null?void 0x0:_0x6d5be6['toJSON']()};}async['_setRedirectUser'](_0x4a7ccf,_0x329a05){const _0x4503e0=await this['getOrInitRedirectPersistenceManager'](_0x329a05);return _0x4a7ccf===null?_0x4503e0['removeCurrentUser']():_0x4503e0['setCurrentUser'](_0x4a7ccf);}async['getOrInitRedirectPersistenceManager'](_0x4c4596){if(!this['redirectPersistenceManager']){const _0xc86f26=_0x4c4596&&ie(_0x4c4596)||this['_popupRedirectResolver'];m(_0xc86f26,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0xc86f26['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x4e40bf){var _0x3a843f,_0x376679;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3a843f=this['_currentUser'])==null?void 0x0:_0x3a843f['_redirectEventId'])===_0x4e40bf?this['_currentUser']:((_0x376679=this['redirectUser'])==null?void 0x0:_0x376679['_redirectEventId'])===_0x4e40bf?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0xc98dd4){if(_0xc98dd4===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0xc98dd4));}['_notifyListenersIfCurrent'](_0x3d3fe6){_0x3d3fe6===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x2b1f3b;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x386eb5=((_0x2b1f3b=this['currentUser'])==null?void 0x0:_0x2b1f3b['uid'])??null;this['lastNotifiedUid']!==_0x386eb5&&(this['lastNotifiedUid']=_0x386eb5,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x2babc6,_0x599159,_0x5189f9,_0x13188a){if(this['_deleted'])return()=>{};const _0x2fdd9d=typeof _0x599159=='function'?_0x599159:_0x599159['next']['bind'](_0x599159);let _0x3110c7=!0x1;const _0x2bc882=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x2bc882,this,'internal-error'),_0x2bc882['then'](()=>{_0x3110c7||_0x2fdd9d(this['currentUser']);}),typeof _0x599159=='function'){const _0x12a1bd=_0x2babc6['addObserver'](_0x599159,_0x5189f9,_0x13188a);return()=>{_0x3110c7=!0x0,_0x12a1bd();};}else{const _0x2cbb07=_0x2babc6['addObserver'](_0x599159);return()=>{_0x3110c7=!0x0,_0x2cbb07();};}}async['directlySetCurrentUser'](_0x246d5d){this['currentUser']&&this['currentUser']!==_0x246d5d&&this['_currentUser']['_stopProactiveRefresh'](),_0x246d5d&&this['isProactiveRefreshEnabled']&&_0x246d5d['_startProactiveRefresh'](),this['currentUser']=_0x246d5d,_0x246d5d?await this['assertedPersistence']['setCurrentUser'](_0x246d5d):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0xc4322c){return this['operations']=this['operations']['then'](_0xc4322c,_0xc4322c),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x35de40){!_0x35de40||this['frameworks']['includes'](_0x35de40)||(this['frameworks']['push'](_0x35de40),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x4f1a5a;const _0x41f43b={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x41f43b['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x6bf009=await((_0x4f1a5a=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x4f1a5a['getHeartbeatsHeader']());_0x6bf009&&(_0x41f43b['X-Firebase-Client']=_0x6bf009);const _0x194efd=await this['_getAppCheckToken']();return _0x194efd&&(_0x41f43b['X-Firebase-AppCheck']=_0x194efd),_0x41f43b;}async['_getAppCheckToken'](){var _0x29de43;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x2a05a1=await((_0x29de43=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x29de43['getToken']());return _0x2a05a1!=null&&_0x2a05a1['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x2a05a1['error']),_0x2a05a1==null?void 0x0:_0x2a05a1['token'];}}function qe(_0x18d161){return N(_0x18d161);}class Rr{constructor(_0x385350){this['auth']=_0x385350,this['observer']=null,this['addObserver']=Tc(_0x3b51f9=>this['observer']=_0x3b51f9);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x22fcda){jn=_0x22fcda;}function xa(_0x2df6c5){return jn['loadJS'](_0x2df6c5);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x5f05f8){return'__'+_0x5f05f8+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x1de0a0){_0x1de0a0();}['execute'](_0x190992,_0x52bb2b){return Promise['resolve']('token');}['render'](_0x162964,_0x3822d8){return'';}}class Lf{['ready'](_0x576a27){_0x576a27();}['execute'](_0x47277f,_0x24fd07){return Promise['resolve']('token');}['render'](_0x4a8bdd,_0x3a6e17){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x332b8f){this['type']=xf,this['auth']=qe(_0x332b8f);}async['verify'](_0x150ebc='verify',_0x232ae3=!0x1){async function _0x50d9be(_0x5b9b2b){if(!_0x232ae3){if(_0x5b9b2b['tenantId']==null&&_0x5b9b2b['_agentRecaptchaConfig']!=null)return _0x5b9b2b['_agentRecaptchaConfig']['siteKey'];if(_0x5b9b2b['tenantId']!=null&&_0x5b9b2b['_tenantRecaptchaConfigs'][_0x5b9b2b['tenantId']]!==void 0x0)return _0x5b9b2b['_tenantRecaptchaConfigs'][_0x5b9b2b['tenantId']]['siteKey'];}return new Promise(async(_0x1a8f4f,_0x1ca016)=>{pf(_0x5b9b2b,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x32313a=>{if(_0x32313a['recaptchaKey']===void 0x0)_0x1ca016(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x26e869=new ff(_0x32313a);return _0x5b9b2b['tenantId']==null?_0x5b9b2b['_agentRecaptchaConfig']=_0x26e869:_0x5b9b2b['_tenantRecaptchaConfigs'][_0x5b9b2b['tenantId']]=_0x26e869,_0x1a8f4f(_0x26e869['siteKey']);}})['catch'](_0x1e72d4=>{_0x1ca016(_0x1e72d4);});});}function _0x309820(_0x3a892c,_0x4ea2d6,_0xf699f2){const _0x588140=window['grecaptcha'];wr(_0x588140)?_0x588140['enterprise']['ready'](()=>{_0x588140['enterprise']['execute'](_0x3a892c,{'action':_0x150ebc})['then'](_0x23aa7d=>{_0x4ea2d6(_0x23aa7d);})['catch'](()=>{_0x4ea2d6(Fa);});}):_0xf699f2(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x3618b9,_0x7330ce)=>{_0x50d9be(this['auth'])['then'](_0x545c95=>{if(!_0x232ae3&&wr(window['grecaptcha']))_0x309820(_0x545c95,_0x3618b9,_0x7330ce);else{if(typeof window>'u'){_0x7330ce(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x27ac78=Pf();_0x27ac78['length']!==0x0&&(_0x27ac78+=_0x545c95),xa(_0x27ac78)['then'](()=>{_0x309820(_0x545c95,_0x3618b9,_0x7330ce);})['catch'](_0x2a1dd3=>{_0x7330ce(_0x2a1dd3);});}})['catch'](_0x20f160=>{_0x7330ce(_0x20f160);});});}}async function Ar(_0x463038,_0xf60080,_0x2ee6fa,_0x2517b4=!0x1,_0x4a4e4e=!0x1){const _0x433eea=new Ff(_0x463038);let _0x3009c5;if(_0x4a4e4e)_0x3009c5=Fa;else try{_0x3009c5=await _0x433eea['verify'](_0x2ee6fa);}catch{_0x3009c5=await _0x433eea['verify'](_0x2ee6fa,!0x0);}const _0x8d1a80={..._0xf60080};if(_0x2ee6fa==='mfaSmsEnrollment'||_0x2ee6fa==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x8d1a80){const _0x10b120=_0x8d1a80['phoneEnrollmentInfo']['phoneNumber'],_0x247d01=_0x8d1a80['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x8d1a80,{'phoneEnrollmentInfo':{'phoneNumber':_0x10b120,'recaptchaToken':_0x247d01,'captchaResponse':_0x3009c5,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x8d1a80){const _0x15ce65=_0x8d1a80['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x8d1a80,{'phoneSignInInfo':{'recaptchaToken':_0x15ce65,'captchaResponse':_0x3009c5,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x8d1a80;}return _0x2517b4?Object['assign'](_0x8d1a80,{'captchaResp':_0x3009c5}):Object['assign'](_0x8d1a80,{'captchaResponse':_0x3009c5}),Object['assign'](_0x8d1a80,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x8d1a80,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x8d1a80;}async function Di(_0x2ccc09,_0xe41957,_0x1cf15a,_0x1d36d6,_0x167461){var _0x333bf1;if((_0x333bf1=_0x2ccc09['_getRecaptchaConfig']())!=null&&_0x333bf1['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0xf07d6a=await Ar(_0x2ccc09,_0xe41957,_0x1cf15a,_0x1cf15a==='getOobCode');return _0x1d36d6(_0x2ccc09,_0xf07d6a);}else return _0x1d36d6(_0x2ccc09,_0xe41957)['catch'](async _0x20177e=>{if(_0x20177e['code']==='auth/missing-recaptcha-token'){console['log'](_0x1cf15a+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0xed10e6=await Ar(_0x2ccc09,_0xe41957,_0x1cf15a,_0x1cf15a==='getOobCode');return _0x1d36d6(_0x2ccc09,_0xed10e6);}else return Promise['reject'](_0x20177e);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x5d7c16,_0x39dbdd){const _0x10ea7d=Bi(_0x5d7c16,'auth');if(_0x10ea7d['isInitialized']()){const _0x1c6f42=_0x10ea7d['getImmediate'](),_0x42231b=_0x10ea7d['getOptions']();if(Me(_0x42231b,_0x39dbdd??{}))return _0x1c6f42;Q(_0x1c6f42,'already-initialized');}return _0x10ea7d['initialize']({'options':_0x39dbdd});}function Wf(_0x57f2db,_0x4bba8f){const _0x3b764f=(_0x4bba8f==null?void 0x0:_0x4bba8f['persistence'])||[],_0x3949dd=(Array['isArray'](_0x3b764f)?_0x3b764f:[_0x3b764f])['map'](ie);_0x4bba8f!=null&&_0x4bba8f['errorMap']&&_0x57f2db['_updateErrorMap'](_0x4bba8f['errorMap']),_0x57f2db['_initializeWithPersistence'](_0x3949dd,_0x4bba8f==null?void 0x0:_0x4bba8f['popupRedirectResolver']);}function Bf(_0x1a996f,_0x18e8a6,_0x575c46){const _0x421a71=qe(_0x1a996f);m(/^https?:\/\//['test'](_0x18e8a6),_0x421a71,'invalid-emulator-scheme');const _0x5e788b=!0x1,_0x5e765e=Ua(_0x18e8a6),{host:_0x2ea7b7,port:_0x4b9e50}=Vf(_0x18e8a6),_0x122aa7=_0x4b9e50===null?'':':'+_0x4b9e50,_0x5f045d={'url':_0x5e765e+'//'+_0x2ea7b7+_0x122aa7+'/'},_0xb1c91e=Object['freeze']({'host':_0x2ea7b7,'port':_0x4b9e50,'protocol':_0x5e765e['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x5e788b})});if(!_0x421a71['_canInitEmulator']){m(_0x421a71['config']['emulator']&&_0x421a71['emulatorConfig'],_0x421a71,'emulator-config-failed'),m(Me(_0x5f045d,_0x421a71['config']['emulator'])&&Me(_0xb1c91e,_0x421a71['emulatorConfig']),_0x421a71,'emulator-config-failed');return;}_0x421a71['config']['emulator']=_0x5f045d,_0x421a71['emulatorConfig']=_0xb1c91e,_0x421a71['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x2ea7b7)?(jr(_0x5e765e+'//'+_0x2ea7b7+_0x122aa7),Kr('Auth',!0x0)):Hf();}function Ua(_0x1005ce){const _0x4f1e30=_0x1005ce['indexOf'](':');return _0x4f1e30<0x0?'':_0x1005ce['substr'](0x0,_0x4f1e30+0x1);}function Vf(_0x4229b2){const _0x1b27de=Ua(_0x4229b2),_0x42aeb0=/(\/\/)?([^?#/]+)/['exec'](_0x4229b2['substr'](_0x1b27de['length']));if(!_0x42aeb0)return{'host':'','port':null};const _0x3c570f=_0x42aeb0[0x2]['split']('@')['pop']()||'',_0x4ed6ca=/^(\[[^\]]+\])(:|$)/['exec'](_0x3c570f);if(_0x4ed6ca){const _0x1fa556=_0x4ed6ca[0x1];return{'host':_0x1fa556,'port':kr(_0x3c570f['substr'](_0x1fa556['length']+0x1))};}else{const [_0x8c72e,_0x56eb31]=_0x3c570f['split'](':');return{'host':_0x8c72e,'port':kr(_0x56eb31)};}}function kr(_0xdd5af){if(!_0xdd5af)return null;const _0x14606d=Number(_0xdd5af);return isNaN(_0x14606d)?null:_0x14606d;}function Hf(){function _0x1fa194(){const _0x505fa3=document['createElement']('p'),_0x53b3d9=_0x505fa3['style'];_0x505fa3['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x53b3d9['position']='fixed',_0x53b3d9['width']='100%',_0x53b3d9['backgroundColor']='#ffffff',_0x53b3d9['border']='.1em\x20solid\x20#000000',_0x53b3d9['color']='#b50000',_0x53b3d9['bottom']='0px',_0x53b3d9['left']='0px',_0x53b3d9['margin']='0px',_0x53b3d9['zIndex']='10000',_0x53b3d9['textAlign']='center',_0x505fa3['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x505fa3);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1fa194):_0x1fa194());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x30f323,_0x6fec53){this['providerId']=_0x30f323,this['signInMethod']=_0x6fec53;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x414005){return ne('not\x20implemented');}['_linkToIdToken'](_0x2b9759,_0x2111cb){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x46bd00){return ne('not\x20implemented');}}async function $f(_0x15775f,_0x1c905a){return Ae(_0x15775f,'POST','/v1/accounts:signUp',_0x1c905a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x4cfa9b,_0x272574){return Qt(_0x4cfa9b,'POST','/v1/accounts:signInWithPassword',Re(_0x4cfa9b,_0x272574));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x55174a,_0x633ce3){return Qt(_0x55174a,'POST','/v1/accounts:signInWithEmailLink',Re(_0x55174a,_0x633ce3));}async function zf(_0x62e978,_0x15c21c){return Qt(_0x62e978,'POST','/v1/accounts:signInWithEmailLink',Re(_0x62e978,_0x15c21c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0xe4fd35,_0x392d67,_0x19a34e,_0x4df504=null){super('password',_0x19a34e),this['_email']=_0xe4fd35,this['_password']=_0x392d67,this['_tenantId']=_0x4df504;}static['_fromEmailAndPassword'](_0x5496f0,_0x592fbd){return new Wt(_0x5496f0,_0x592fbd,'password');}static['_fromEmailAndCode'](_0x4b1686,_0x1f042e,_0x427d22=null){return new Wt(_0x4b1686,_0x1f042e,'emailLink',_0x427d22);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x5d90a3){const _0x3bc465=typeof _0x5d90a3=='string'?JSON['parse'](_0x5d90a3):_0x5d90a3;if(_0x3bc465!=null&&_0x3bc465['email']&&(_0x3bc465!=null&&_0x3bc465['password'])){if(_0x3bc465['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x3bc465['email'],_0x3bc465['password']);if(_0x3bc465['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x3bc465['email'],_0x3bc465['password'],_0x3bc465['tenantId']);}return null;}async['_getIdTokenResponse'](_0x1bceac){switch(this['signInMethod']){case'password':const _0x30c80d={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x1bceac,_0x30c80d,'signInWithPassword',Gf);case'emailLink':return qf(_0x1bceac,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x1bceac,'internal-error');}}async['_linkToIdToken'](_0x1a1a6d,_0x1b2d0f){switch(this['signInMethod']){case'password':const _0xe3278f={'idToken':_0x1b2d0f,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x1a1a6d,_0xe3278f,'signUpPassword',$f);case'emailLink':return zf(_0x1a1a6d,{'idToken':_0x1b2d0f,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x1a1a6d,'internal-error');}}['_getReauthenticationResolver'](_0x3d1508){return this['_getIdTokenResponse'](_0x3d1508);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x37afc8,_0x392ccf){return Qt(_0x37afc8,'POST','/v1/accounts:signInWithIdp',Re(_0x37afc8,_0x392ccf));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x311c2d){const _0x1a517c=new Be(_0x311c2d['providerId'],_0x311c2d['signInMethod']);return _0x311c2d['idToken']||_0x311c2d['accessToken']?(_0x311c2d['idToken']&&(_0x1a517c['idToken']=_0x311c2d['idToken']),_0x311c2d['accessToken']&&(_0x1a517c['accessToken']=_0x311c2d['accessToken']),_0x311c2d['nonce']&&!_0x311c2d['pendingToken']&&(_0x1a517c['nonce']=_0x311c2d['nonce']),_0x311c2d['pendingToken']&&(_0x1a517c['pendingToken']=_0x311c2d['pendingToken'])):_0x311c2d['oauthToken']&&_0x311c2d['oauthTokenSecret']?(_0x1a517c['accessToken']=_0x311c2d['oauthToken'],_0x1a517c['secret']=_0x311c2d['oauthTokenSecret']):Q('argument-error'),_0x1a517c;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x9eb9f3){const _0xfa7945=typeof _0x9eb9f3=='string'?JSON['parse'](_0x9eb9f3):_0x9eb9f3,{providerId:_0x349999,signInMethod:_0x1f2d7d,..._0x10e4f4}=_0xfa7945;if(!_0x349999||!_0x1f2d7d)return null;const _0x4aa593=new Be(_0x349999,_0x1f2d7d);return _0x4aa593['idToken']=_0x10e4f4['idToken']||void 0x0,_0x4aa593['accessToken']=_0x10e4f4['accessToken']||void 0x0,_0x4aa593['secret']=_0x10e4f4['secret'],_0x4aa593['nonce']=_0x10e4f4['nonce'],_0x4aa593['pendingToken']=_0x10e4f4['pendingToken']||null,_0x4aa593;}['_getIdTokenResponse'](_0x16a2c1){const _0x57b1e6=this['buildRequest']();return Xe(_0x16a2c1,_0x57b1e6);}['_linkToIdToken'](_0xef5291,_0x12333c){const _0x397835=this['buildRequest']();return _0x397835['idToken']=_0x12333c,Xe(_0xef5291,_0x397835);}['_getReauthenticationResolver'](_0x41d8ee){const _0x40873b=this['buildRequest']();return _0x40873b['autoCreate']=!0x1,Xe(_0x41d8ee,_0x40873b);}['buildRequest'](){const _0x246efd={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x246efd['pendingToken']=this['pendingToken'];else{const _0x4393b8={};this['idToken']&&(_0x4393b8['id_token']=this['idToken']),this['accessToken']&&(_0x4393b8['access_token']=this['accessToken']),this['secret']&&(_0x4393b8['oauth_token_secret']=this['secret']),_0x4393b8['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x4393b8['nonce']=this['nonce']),_0x246efd['postBody']=ct(_0x4393b8);}return _0x246efd;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x238c4a){switch(_0x238c4a){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x309250){const _0x54d066=vt(Et(_0x309250))['link'],_0x4dfca2=_0x54d066?vt(Et(_0x54d066))['deep_link_id']:null,_0x427353=vt(Et(_0x309250))['deep_link_id'];return(_0x427353?vt(Et(_0x427353))['link']:null)||_0x427353||_0x4dfca2||_0x54d066||_0x309250;}class Rs{constructor(_0x1d0970){const _0x4f9aa9=vt(Et(_0x1d0970)),_0xb35b0e=_0x4f9aa9['apiKey']??null,_0xc37fff=_0x4f9aa9['oobCode']??null,_0x1530ec=Kf(_0x4f9aa9['mode']??null);m(_0xb35b0e&&_0xc37fff&&_0x1530ec,'argument-error'),this['apiKey']=_0xb35b0e,this['operation']=_0x1530ec,this['code']=_0xc37fff,this['continueUrl']=_0x4f9aa9['continueUrl']??null,this['languageCode']=_0x4f9aa9['lang']??null,this['tenantId']=_0x4f9aa9['tenantId']??null;}static['parseLink'](_0x404cec){const _0x20b2c6=Yf(_0x404cec);try{return new Rs(_0x20b2c6);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x48dd33,_0x4431fe){return Wt['_fromEmailAndPassword'](_0x48dd33,_0x4431fe);}static['credentialWithLink'](_0x4d3a50,_0x1d147a){const _0x34a1eb=Rs['parseLink'](_0x1d147a);return m(_0x34a1eb,'argument-error'),Wt['_fromEmailAndCode'](_0x4d3a50,_0x34a1eb['code'],_0x34a1eb['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x3cd3e1){this['providerId']=_0x3cd3e1,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x1cc5d0){this['defaultLanguageCode']=_0x1cc5d0;}['setCustomParameters'](_0x12bec7){return this['customParameters']=_0x12bec7,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x56268){return this['scopes']['includes'](_0x56268)||this['scopes']['push'](_0x56268),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x32d4ba){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x32d4ba});}static['credentialFromResult'](_0x286ee0){return he['credentialFromTaggedObject'](_0x286ee0);}static['credentialFromError'](_0x11f5c1){return he['credentialFromTaggedObject'](_0x11f5c1['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4417c9}){if(!_0x4417c9||!('oauthAccessToken'in _0x4417c9)||!_0x4417c9['oauthAccessToken'])return null;try{return he['credential'](_0x4417c9['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x198a6c,_0xdf38d4){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x198a6c,'accessToken':_0xdf38d4});}static['credentialFromResult'](_0xa21d09){return ue['credentialFromTaggedObject'](_0xa21d09);}static['credentialFromError'](_0x4d2453){return ue['credentialFromTaggedObject'](_0x4d2453['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x208b4d}){if(!_0x208b4d)return null;const {oauthIdToken:_0x4da649,oauthAccessToken:_0x149beb}=_0x208b4d;if(!_0x4da649&&!_0x149beb)return null;try{return ue['credential'](_0x4da649,_0x149beb);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x1c0b7d){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x1c0b7d});}static['credentialFromResult'](_0x5a1bb9){return de['credentialFromTaggedObject'](_0x5a1bb9);}static['credentialFromError'](_0xd7b4e5){return de['credentialFromTaggedObject'](_0xd7b4e5['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1696fd}){if(!_0x1696fd||!('oauthAccessToken'in _0x1696fd)||!_0x1696fd['oauthAccessToken'])return null;try{return de['credential'](_0x1696fd['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x47669c,_0x35c04b){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x47669c,'oauthTokenSecret':_0x35c04b});}static['credentialFromResult'](_0x3d5353){return fe['credentialFromTaggedObject'](_0x3d5353);}static['credentialFromError'](_0x21bf37){return fe['credentialFromTaggedObject'](_0x21bf37['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x204591}){if(!_0x204591)return null;const {oauthAccessToken:_0x1eb426,oauthTokenSecret:_0xdd46f1}=_0x204591;if(!_0x1eb426||!_0xdd46f1)return null;try{return fe['credential'](_0x1eb426,_0xdd46f1);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x5053b8,_0x2cab9b){return Qt(_0x5053b8,'POST','/v1/accounts:signUp',Re(_0x5053b8,_0x2cab9b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x3192f9){this['user']=_0x3192f9['user'],this['providerId']=_0x3192f9['providerId'],this['_tokenResponse']=_0x3192f9['_tokenResponse'],this['operationType']=_0x3192f9['operationType'];}static async['_fromIdTokenResponse'](_0x3d79fa,_0x2f137a,_0x342cc7,_0x107cd4=!0x1){const _0xaf12bb=await K['_fromIdTokenResponse'](_0x3d79fa,_0x342cc7,_0x107cd4),_0x3d8268=Nr(_0x342cc7);return new Ve({'user':_0xaf12bb,'providerId':_0x3d8268,'_tokenResponse':_0x342cc7,'operationType':_0x2f137a});}static async['_forOperation'](_0x5b2773,_0xd22e82,_0x19fc55){await _0x5b2773['_updateTokensIfNecessary'](_0x19fc55,!0x0);const _0x2387a9=Nr(_0x19fc55);return new Ve({'user':_0x5b2773,'providerId':_0x2387a9,'_tokenResponse':_0x19fc55,'operationType':_0xd22e82});}}function Nr(_0x242abf){return _0x242abf['providerId']?_0x242abf['providerId']:'phoneNumber'in _0x242abf?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x362dd9,_0x11d393,_0x25271a,_0x220b3f){super(_0x11d393['code'],_0x11d393['message']),this['operationType']=_0x25271a,this['user']=_0x220b3f,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x362dd9['name'],'tenantId':_0x362dd9['tenantId']??void 0x0,'_serverResponse':_0x11d393['customData']['_serverResponse'],'operationType':_0x25271a};}static['_fromErrorAndOperation'](_0x12a97d,_0x2a9761,_0x853e94,_0x37ec71){return new An(_0x12a97d,_0x2a9761,_0x853e94,_0x37ec71);}}function Ba(_0x5b3e72,_0x235d50,_0x3502aa,_0x2df8e6){return(_0x235d50==='reauthenticate'?_0x3502aa['_getReauthenticationResolver'](_0x5b3e72):_0x3502aa['_getIdTokenResponse'](_0x5b3e72))['catch'](_0x41a5e4=>{throw _0x41a5e4['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x5b3e72,_0x41a5e4,_0x235d50,_0x2df8e6):_0x41a5e4;});}async function Jf(_0x2f4ba8,_0x41aebc,_0x4d3406=!0x1){const _0x5b7e47=await Ut(_0x2f4ba8,_0x41aebc['_linkToIdToken'](_0x2f4ba8['auth'],await _0x2f4ba8['getIdToken']()),_0x4d3406);return Ve['_forOperation'](_0x2f4ba8,'link',_0x5b7e47);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x45f50e,_0x1a1ea9,_0x55bb59=!0x1){const {auth:_0x2fd5f5}=_0x45f50e;if($(_0x2fd5f5['app']))return Promise['reject'](re(_0x2fd5f5));const _0x3d0b15='reauthenticate';try{const _0x187ac4=await Ut(_0x45f50e,Ba(_0x2fd5f5,_0x3d0b15,_0x1a1ea9,_0x45f50e),_0x55bb59);m(_0x187ac4['idToken'],_0x2fd5f5,'internal-error');const _0x7a6420=Ts(_0x187ac4['idToken']);m(_0x7a6420,_0x2fd5f5,'internal-error');const {sub:_0x2408e7}=_0x7a6420;return m(_0x45f50e['uid']===_0x2408e7,_0x2fd5f5,'user-mismatch'),Ve['_forOperation'](_0x45f50e,_0x3d0b15,_0x187ac4);}catch(_0x56fb8d){throw(_0x56fb8d==null?void 0x0:_0x56fb8d['code'])==='auth/user-not-found'&&Q(_0x2fd5f5,'user-mismatch'),_0x56fb8d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0xde7650,_0x211aa5,_0x3f63dd=!0x1){if($(_0xde7650['app']))return Promise['reject'](re(_0xde7650));const _0x1b9246='signIn',_0x4d67eb=await Ba(_0xde7650,_0x1b9246,_0x211aa5),_0x375708=await Ve['_fromIdTokenResponse'](_0xde7650,_0x1b9246,_0x4d67eb);return _0x3f63dd||await _0xde7650['_updateCurrentUser'](_0x375708['user']),_0x375708;}async function Zf(_0x5abcf2,_0x5109db){return Va(qe(_0x5abcf2),_0x5109db);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x3cb8cb){const _0x327b37=qe(_0x3cb8cb);_0x327b37['_getPasswordPolicyInternal']()&&await _0x327b37['_updatePasswordPolicy']();}async function P_(_0x5e15f5,_0x1323af,_0x165a16){if($(_0x5e15f5['app']))return Promise['reject'](re(_0x5e15f5));const _0x2c572d=qe(_0x5e15f5),_0x3536b1=await Di(_0x2c572d,{'returnSecureToken':!0x0,'email':_0x1323af,'password':_0x165a16,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x545eae=>{throw _0x545eae['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x5e15f5),_0x545eae;}),_0x1aa61b=await Ve['_fromIdTokenResponse'](_0x2c572d,'signIn',_0x3536b1);return await _0x2c572d['_updateCurrentUser'](_0x1aa61b['user']),_0x1aa61b;}function O_(_0x2baaca,_0x1f850b,_0x51a98f){return $(_0x2baaca['app'])?Promise['reject'](re(_0x2baaca)):Zf(N(_0x2baaca),pt['credential'](_0x1f850b,_0x51a98f))['catch'](async _0x1cf2ee=>{throw _0x1cf2ee['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x2baaca),_0x1cf2ee;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x597877,_0x2ae93c){return N(_0x597877)['setPersistence'](_0x2ae93c);}function ep(_0x1cc931,_0x535908,_0x52ab71,_0x3afc87){return N(_0x1cc931)['onIdTokenChanged'](_0x535908,_0x52ab71,_0x3afc87);}function tp(_0x270bd1,_0xf37a7,_0x250bb7){return N(_0x270bd1)['beforeAuthStateChanged'](_0xf37a7,_0x250bb7);}function M_(_0x19b0e8,_0x67f7b,_0x183fd7,_0xd4a60b){return N(_0x19b0e8)['onAuthStateChanged'](_0x67f7b,_0x183fd7,_0xd4a60b);}function L_(_0x1d40a0){return N(_0x1d40a0)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x747bc,_0x3a3fbf){this['storageRetriever']=_0x747bc,this['type']=_0x3a3fbf;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x56d58d,_0xecad5c){return this['storage']['setItem'](_0x56d58d,JSON['stringify'](_0xecad5c)),Promise['resolve']();}['_get'](_0x121d67){const _0x423108=this['storage']['getItem'](_0x121d67);return Promise['resolve'](_0x423108?JSON['parse'](_0x423108):null);}['_remove'](_0x3030fa){return this['storage']['removeItem'](_0x3030fa),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x49787e,_0x3a25c3)=>this['onStorageEvent'](_0x49787e,_0x3a25c3),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0xa1ed14){for(const _0x1ae77e of Object['keys'](this['listeners'])){const _0x5c74c8=this['storage']['getItem'](_0x1ae77e),_0x1bff8a=this['localCache'][_0x1ae77e];_0x5c74c8!==_0x1bff8a&&_0xa1ed14(_0x1ae77e,_0x1bff8a,_0x5c74c8);}}['onStorageEvent'](_0x248ed5,_0x2c2f42=!0x1){if(!_0x248ed5['key']){this['forAllChangedKeys']((_0x4ceac2,_0x5a4e58,_0x1e6cef)=>{this['notifyListeners'](_0x4ceac2,_0x1e6cef);});return;}const _0x4cfed0=_0x248ed5['key'];_0x2c2f42?this['detachListener']():this['stopPolling']();const _0x456b39=()=>{const _0x18324b=this['storage']['getItem'](_0x4cfed0);!_0x2c2f42&&this['localCache'][_0x4cfed0]===_0x18324b||this['notifyListeners'](_0x4cfed0,_0x18324b);},_0x21f0f9=this['storage']['getItem'](_0x4cfed0);Tf()&&_0x21f0f9!==_0x248ed5['newValue']&&_0x248ed5['newValue']!==_0x248ed5['oldValue']?setTimeout(_0x456b39,ip):_0x456b39();}['notifyListeners'](_0x272485,_0x50e4d9){this['localCache'][_0x272485]=_0x50e4d9;const _0x222a5c=this['listeners'][_0x272485];if(_0x222a5c){for(const _0x34c924 of Array['from'](_0x222a5c))_0x34c924(_0x50e4d9&&JSON['parse'](_0x50e4d9));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x2fd51f,_0xab4395,_0x12b023)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x2fd51f,'oldValue':_0xab4395,'newValue':_0x12b023}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x538c93,_0x146cf3){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x538c93]||(this['listeners'][_0x538c93]=new Set(),this['localCache'][_0x538c93]=this['storage']['getItem'](_0x538c93)),this['listeners'][_0x538c93]['add'](_0x146cf3);}['_removeListener'](_0x291c73,_0x1fcc6a){this['listeners'][_0x291c73]&&(this['listeners'][_0x291c73]['delete'](_0x1fcc6a),this['listeners'][_0x291c73]['size']===0x0&&delete this['listeners'][_0x291c73]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x3192e8,_0xd533f6){await super['_set'](_0x3192e8,_0xd533f6),this['localCache'][_0x3192e8]=JSON['stringify'](_0xd533f6);}async['_get'](_0x591d13){const _0x3d710a=await super['_get'](_0x591d13);return this['localCache'][_0x591d13]=JSON['stringify'](_0x3d710a),_0x3d710a;}async['_remove'](_0x5c6b65){await super['_remove'](_0x5c6b65),delete this['localCache'][_0x5c6b65];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x4eaf15,_0x36246f){}['_removeListener'](_0x18f3d2,_0x199b98){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x1ef053){return Promise['all'](_0x1ef053['map'](async _0x16990a=>{try{return{'fulfilled':!0x0,'value':await _0x16990a};}catch(_0x3bb8aa){return{'fulfilled':!0x1,'reason':_0x3bb8aa};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x400221){this['eventTarget']=_0x400221,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x9af057){const _0x9b1fb9=this['receivers']['find'](_0x175e42=>_0x175e42['isListeningto'](_0x9af057));if(_0x9b1fb9)return _0x9b1fb9;const _0x1cfc75=new Kn(_0x9af057);return this['receivers']['push'](_0x1cfc75),_0x1cfc75;}['isListeningto'](_0x264682){return this['eventTarget']===_0x264682;}async['handleEvent'](_0x5495ff){const _0xfb643b=_0x5495ff,{eventId:_0x2f843c,eventType:_0x3f3d4b,data:_0x539f28}=_0xfb643b['data'],_0x32abd8=this['handlersMap'][_0x3f3d4b];if(!(_0x32abd8!=null&&_0x32abd8['size']))return;_0xfb643b['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x2f843c,'eventType':_0x3f3d4b});const _0x339f13=Array['from'](_0x32abd8)['map'](async _0x43e7e2=>_0x43e7e2(_0xfb643b['origin'],_0x539f28)),_0x3439b3=await rp(_0x339f13);_0xfb643b['ports'][0x0]['postMessage']({'status':'done','eventId':_0x2f843c,'eventType':_0x3f3d4b,'response':_0x3439b3});}['_subscribe'](_0x3c9540,_0x31160d){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x3c9540]||(this['handlersMap'][_0x3c9540]=new Set()),this['handlersMap'][_0x3c9540]['add'](_0x31160d);}['_unsubscribe'](_0xc2033,_0x36c0e9){this['handlersMap'][_0xc2033]&&_0x36c0e9&&this['handlersMap'][_0xc2033]['delete'](_0x36c0e9),(!_0x36c0e9||this['handlersMap'][_0xc2033]['size']===0x0)&&delete this['handlersMap'][_0xc2033],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0xe2d934='',_0x3c869e=0xa){let _0x2f6496='';for(let _0x1b0c42=0x0;_0x1b0c42<_0x3c869e;_0x1b0c42++)_0x2f6496+=Math['floor'](Math['random']()*0xa);return _0xe2d934+_0x2f6496;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x3a9343){this['target']=_0x3a9343,this['handlers']=new Set();}['removeMessageHandler'](_0x156513){_0x156513['messageChannel']&&(_0x156513['messageChannel']['port1']['removeEventListener']('message',_0x156513['onMessage']),_0x156513['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x156513);}async['_send'](_0x1b9e3e,_0x3b844a,_0x40c6fc=0x32){const _0xa8b188=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0xa8b188)throw new Error('connection_unavailable');let _0x2c776f,_0x393a6a;return new Promise((_0x497863,_0x4cff5b)=>{const _0x2bfd81=As('',0x14);_0xa8b188['port1']['start']();const _0x27074f=setTimeout(()=>{_0x4cff5b(new Error('unsupported_event'));},_0x40c6fc);_0x393a6a={'messageChannel':_0xa8b188,'onMessage'(_0xa538f0){const _0x5636b9=_0xa538f0;if(_0x5636b9['data']['eventId']===_0x2bfd81)switch(_0x5636b9['data']['status']){case'ack':clearTimeout(_0x27074f),_0x2c776f=setTimeout(()=>{_0x4cff5b(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x2c776f),_0x497863(_0x5636b9['data']['response']);break;default:clearTimeout(_0x27074f),clearTimeout(_0x2c776f),_0x4cff5b(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x393a6a),_0xa8b188['port1']['addEventListener']('message',_0x393a6a['onMessage']),this['target']['postMessage']({'eventType':_0x1b9e3e,'eventId':_0x2bfd81,'data':_0x3b844a},[_0xa8b188['port2']]);})['finally'](()=>{_0x393a6a&&this['removeMessageHandler'](_0x393a6a);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x518c6e){Z()['location']['href']=_0x518c6e;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x27ebb4;return((_0x27ebb4=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x27ebb4['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x4307f5){this['request']=_0x4307f5;}['toPromise'](){return new Promise((_0x5768dc,_0x469b73)=>{this['request']['addEventListener']('success',()=>{_0x5768dc(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x469b73(this['request']['error']);});});}}function Yn(_0x5f30b6,_0x3558b2){return _0x5f30b6['transaction']([Nn],_0x3558b2?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x18938c=indexedDB['deleteDatabase'](Ka);return new Xt(_0x18938c)['toPromise']();}function Mi(){const _0x3379bd=indexedDB['open'](Ka,up);return new Promise((_0x214f84,_0x56b3ad)=>{_0x3379bd['addEventListener']('error',()=>{_0x56b3ad(_0x3379bd['error']);}),_0x3379bd['addEventListener']('upgradeneeded',()=>{const _0x570955=_0x3379bd['result'];try{_0x570955['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x294e07){_0x56b3ad(_0x294e07);}}),_0x3379bd['addEventListener']('success',async()=>{const _0xe0ff34=_0x3379bd['result'];_0xe0ff34['objectStoreNames']['contains'](Nn)?_0x214f84(_0xe0ff34):(_0xe0ff34['close'](),await dp(),_0x214f84(await Mi()));});});}async function Pr(_0xcb498f,_0x51ae48,_0x2bc4bb){const _0x183858=Yn(_0xcb498f,!0x0)['put']({[Ya]:_0x51ae48,'value':_0x2bc4bb});return new Xt(_0x183858)['toPromise']();}async function fp(_0x325881,_0x47dbff){const _0x102741=Yn(_0x325881,!0x1)['get'](_0x47dbff),_0x31d590=await new Xt(_0x102741)['toPromise']();return _0x31d590===void 0x0?null:_0x31d590['value'];}function Or(_0x425d89,_0x500935){const _0x8596e4=Yn(_0x425d89,!0x0)['delete'](_0x500935);return new Xt(_0x8596e4)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x19379b){let _0x690d60=0x0;for(;;)try{const _0x1588a5=await this['_openDb']();return await _0x19379b(_0x1588a5);}catch(_0x5e5e35){if(_0x690d60++>_p)throw _0x5e5e35;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x43a4a5,_0x1e89a1)=>({'keyProcessed':(await this['_poll']())['includes'](_0x1e89a1['key'])})),this['receiver']['_subscribe']('ping',async(_0x1a3b7f,_0x4892b6)=>['keyChanged']);}async['initializeSender'](){var _0x3e453d,_0x40c845;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x1a6431=await this['sender']['_send']('ping',{},0x320);_0x1a6431&&(_0x3e453d=_0x1a6431[0x0])!=null&&_0x3e453d['fulfilled']&&(_0x40c845=_0x1a6431[0x0])!=null&&_0x40c845['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x4b989e){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x4b989e},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x363126=await Mi();return await Pr(_0x363126,kn,'1'),await Or(_0x363126,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x133fa3){this['pendingWrites']++;try{await _0x133fa3();}finally{this['pendingWrites']--;}}async['_set'](_0x53553d,_0x408510){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5314a6=>Pr(_0x5314a6,_0x53553d,_0x408510)),this['localCache'][_0x53553d]=_0x408510,this['notifyServiceWorker'](_0x53553d)));}async['_get'](_0x1e8499){const _0x331cd9=await this['_withRetries'](_0x1e635d=>fp(_0x1e635d,_0x1e8499));return this['localCache'][_0x1e8499]=_0x331cd9,_0x331cd9;}async['_remove'](_0x803e26){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x54619c=>Or(_0x54619c,_0x803e26)),delete this['localCache'][_0x803e26],this['notifyServiceWorker'](_0x803e26)));}async['_poll'](){const _0x5d3b5d=await this['_withRetries'](_0x51e0ac=>{const _0x457396=Yn(_0x51e0ac,!0x1)['getAll']();return new Xt(_0x457396)['toPromise']();});if(!_0x5d3b5d)return[];if(this['pendingWrites']!==0x0)return[];const _0x4a4c8e=[],_0x1cf34e=new Set();if(_0x5d3b5d['length']!==0x0){for(const {fbase_key:_0x2b19b8,value:_0x696934}of _0x5d3b5d)_0x1cf34e['add'](_0x2b19b8),JSON['stringify'](this['localCache'][_0x2b19b8])!==JSON['stringify'](_0x696934)&&(this['notifyListeners'](_0x2b19b8,_0x696934),_0x4a4c8e['push'](_0x2b19b8));}for(const _0x1c0a1f of Object['keys'](this['localCache']))this['localCache'][_0x1c0a1f]&&!_0x1cf34e['has'](_0x1c0a1f)&&(this['notifyListeners'](_0x1c0a1f,null),_0x4a4c8e['push'](_0x1c0a1f));return _0x4a4c8e;}['notifyListeners'](_0x52c334,_0x18594f){this['localCache'][_0x52c334]=_0x18594f;const _0x1fd62e=this['listeners'][_0x52c334];if(_0x1fd62e){for(const _0x28b6c3 of Array['from'](_0x1fd62e))_0x28b6c3(_0x18594f);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x48a66a,_0x21c838){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x48a66a]||(this['listeners'][_0x48a66a]=new Set(),this['_get'](_0x48a66a)),this['listeners'][_0x48a66a]['add'](_0x21c838);}['_removeListener'](_0x1ba105,_0x5459cc){this['listeners'][_0x1ba105]&&(this['listeners'][_0x1ba105]['delete'](_0x5459cc),this['listeners'][_0x1ba105]['size']===0x0&&delete this['listeners'][_0x1ba105]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x987b33,_0x111744){return _0x111744?ie(_0x111744):(m(_0x987b33['_popupRedirectResolver'],_0x987b33,'argument-error'),_0x987b33['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x3f25b9){super('custom','custom'),this['params']=_0x3f25b9;}['_getIdTokenResponse'](_0x254c8e){return Xe(_0x254c8e,this['_buildIdpRequest']());}['_linkToIdToken'](_0x70876f,_0x81bd7f){return Xe(_0x70876f,this['_buildIdpRequest'](_0x81bd7f));}['_getReauthenticationResolver'](_0x2d56ae){return Xe(_0x2d56ae,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x5dbc58){const _0x34760e={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x5dbc58&&(_0x34760e['idToken']=_0x5dbc58),_0x34760e;}}function yp(_0x13ad88){return Va(_0x13ad88['auth'],new ks(_0x13ad88),_0x13ad88['bypassAuthState']);}function vp(_0x1a2394){const {auth:_0xcb00c0,user:_0x5bf882}=_0x1a2394;return m(_0x5bf882,_0xcb00c0,'internal-error'),Xf(_0x5bf882,new ks(_0x1a2394),_0x1a2394['bypassAuthState']);}async function Ep(_0xa30cc9){const {auth:_0xf933db,user:_0x62850e}=_0xa30cc9;return m(_0x62850e,_0xf933db,'internal-error'),Jf(_0x62850e,new ks(_0xa30cc9),_0xa30cc9['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x2b9483,_0x345719,_0xf5f6fd,_0x3b2e7d,_0x3553ad=!0x1){this['auth']=_0x2b9483,this['resolver']=_0xf5f6fd,this['user']=_0x3b2e7d,this['bypassAuthState']=_0x3553ad,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x345719)?_0x345719:[_0x345719];}['execute'](){return new Promise(async(_0x262a88,_0x24bd9f)=>{this['pendingPromise']={'resolve':_0x262a88,'reject':_0x24bd9f};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x6cb4d4){this['reject'](_0x6cb4d4);}});}async['onAuthEvent'](_0x52906c){const {urlResponse:_0xafa017,sessionId:_0x451d1b,postBody:_0x3bb0dc,tenantId:_0x4a3efb,error:_0xfc9151,type:_0x12e41b}=_0x52906c;if(_0xfc9151){this['reject'](_0xfc9151);return;}const _0x2c0948={'auth':this['auth'],'requestUri':_0xafa017,'sessionId':_0x451d1b,'tenantId':_0x4a3efb||void 0x0,'postBody':_0x3bb0dc||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x12e41b)(_0x2c0948));}catch(_0x3608fe){this['reject'](_0x3608fe);}}['onError'](_0x491aa9){this['reject'](_0x491aa9);}['getIdpTask'](_0x3ad756){switch(_0x3ad756){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x4cddf1){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x4cddf1),this['unregisterAndCleanUp']();}['reject'](_0x180ecf){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x180ecf),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x24f2ae,_0x2267f6,_0x3f7f64,_0x5442a6,_0x3e4026){super(_0x24f2ae,_0x2267f6,_0x5442a6,_0x3e4026),this['provider']=_0x3f7f64,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x3375e1=await this['execute']();return m(_0x3375e1,this['auth'],'internal-error'),_0x3375e1;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x59aa71=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x59aa71),this['authWindow']['associatedEvent']=_0x59aa71,this['resolver']['_originValidation'](this['auth'])['catch'](_0x110ee4=>{this['reject'](_0x110ee4);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x33d039=>{_0x33d039||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x3216ca;return((_0x3216ca=this['authWindow'])==null?void 0x0:_0x3216ca['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x2977b7=()=>{var _0x590614,_0x4b26f2;if((_0x4b26f2=(_0x590614=this['authWindow'])==null?void 0x0:_0x590614['window'])!=null&&_0x4b26f2['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x2977b7,Ip['get']());};_0x2977b7();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x413bb9,_0xf85863,_0x5f1553=!0x1){super(_0x413bb9,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0xf85863,void 0x0,_0x5f1553),this['eventId']=null;}async['execute'](){let _0xdd39eb=on['get'](this['auth']['_key']());if(!_0xdd39eb){try{const _0x4b0fcb=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0xdd39eb=()=>Promise['resolve'](_0x4b0fcb);}catch(_0x478dfb){_0xdd39eb=()=>Promise['reject'](_0x478dfb);}on['set'](this['auth']['_key'](),_0xdd39eb);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0xdd39eb();}async['onAuthEvent'](_0x46f1cf){if(_0x46f1cf['type']==='signInViaRedirect')return super['onAuthEvent'](_0x46f1cf);if(_0x46f1cf['type']==='unknown'){this['resolve'](null);return;}if(_0x46f1cf['eventId']){const _0x5e6440=await this['auth']['_redirectUserForId'](_0x46f1cf['eventId']);if(_0x5e6440)return this['user']=_0x5e6440,super['onAuthEvent'](_0x46f1cf);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x23d7ff,_0x23b662){const _0x56adfe=Rp(_0x23b662),_0x3ec87c=bp(_0x23d7ff);if(!await _0x3ec87c['_isAvailable']())return!0x1;const _0x5e3cf6=await _0x3ec87c['_get'](_0x56adfe)==='true';return await _0x3ec87c['_remove'](_0x56adfe),_0x5e3cf6;}function Sp(_0x2ac046,_0x5e4062){on['set'](_0x2ac046['_key'](),_0x5e4062);}function bp(_0x29018b){return ie(_0x29018b['_redirectPersistence']);}function Rp(_0x4358df){return rn(wp,_0x4358df['config']['apiKey'],_0x4358df['name']);}async function Ap(_0xc348a8,_0x3365ab,_0x261838=!0x1){if($(_0xc348a8['app']))return Promise['reject'](re(_0xc348a8));const _0x817f35=qe(_0xc348a8),_0x266631=mp(_0x817f35,_0x3365ab),_0x5c108f=await new Cp(_0x817f35,_0x266631,_0x261838)['execute']();return _0x5c108f&&!_0x261838&&(delete _0x5c108f['user']['_redirectEventId'],await _0x817f35['_persistUserIfCurrent'](_0x5c108f['user']),await _0x817f35['_setRedirectUser'](null,_0x3365ab)),_0x5c108f;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x4f1a8d){this['auth']=_0x4f1a8d,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x2fd05a){this['consumers']['add'](_0x2fd05a),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x2fd05a)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x2fd05a),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x55fa69){this['consumers']['delete'](_0x55fa69);}['onEvent'](_0x4cf7de){if(this['hasEventBeenHandled'](_0x4cf7de))return!0x1;let _0x38ce54=!0x1;return this['consumers']['forEach'](_0x101d27=>{this['isEventForConsumer'](_0x4cf7de,_0x101d27)&&(_0x38ce54=!0x0,this['sendToConsumer'](_0x4cf7de,_0x101d27),this['saveEventToCache'](_0x4cf7de));}),this['hasHandledPotentialRedirect']||!Pp(_0x4cf7de)||(this['hasHandledPotentialRedirect']=!0x0,_0x38ce54||(this['queuedRedirectEvent']=_0x4cf7de,_0x38ce54=!0x0)),_0x38ce54;}['sendToConsumer'](_0x36a289,_0xc79ad7){var _0x30d9df;if(_0x36a289['error']&&!Xa(_0x36a289)){const _0x5bebb5=((_0x30d9df=_0x36a289['error']['code'])==null?void 0x0:_0x30d9df['split']('auth/')[0x1])||'internal-error';_0xc79ad7['onError'](X(this['auth'],_0x5bebb5));}else _0xc79ad7['onAuthEvent'](_0x36a289);}['isEventForConsumer'](_0x35201c,_0x1f604b){const _0x2cb01b=_0x1f604b['eventId']===null||!!_0x35201c['eventId']&&_0x35201c['eventId']===_0x1f604b['eventId'];return _0x1f604b['filter']['includes'](_0x35201c['type'])&&_0x2cb01b;}['hasEventBeenHandled'](_0x415aeb){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x415aeb));}['saveEventToCache'](_0x598234){this['cachedEventUids']['add'](Dr(_0x598234)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x10a527){return[_0x10a527['type'],_0x10a527['eventId'],_0x10a527['sessionId'],_0x10a527['tenantId']]['filter'](_0x4b4c30=>_0x4b4c30)['join']('-');}function Xa({type:_0x197b52,error:_0x24ae9a}){return _0x197b52==='unknown'&&(_0x24ae9a==null?void 0x0:_0x24ae9a['code'])==='auth/no-auth-event';}function Pp(_0x375e8b){switch(_0x375e8b['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x375e8b);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x47aea2,_0x41e077={}){return Ae(_0x47aea2,'GET','/v1/projects',_0x41e077);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x52fa18){if(_0x52fa18['config']['emulator'])return;const {authorizedDomains:_0x5890a6}=await Op(_0x52fa18);for(const _0x224bb1 of _0x5890a6)try{if(xp(_0x224bb1))return;}catch{}Q(_0x52fa18,'unauthorized-domain');}function xp(_0xfa42d1){const _0x29c4ad=Pi(),{protocol:_0x1abc7f,hostname:_0x13ffb5}=new URL(_0x29c4ad);if(_0xfa42d1['startsWith']('chrome-extension://')){const _0x8e69b9=new URL(_0xfa42d1);return _0x8e69b9['hostname']===''&&_0x13ffb5===''?_0x1abc7f==='chrome-extension:'&&_0xfa42d1['replace']('chrome-extension://','')===_0x29c4ad['replace']('chrome-extension://',''):_0x1abc7f==='chrome-extension:'&&_0x8e69b9['hostname']===_0x13ffb5;}if(!Mp['test'](_0x1abc7f))return!0x1;if(Dp['test'](_0xfa42d1))return _0x13ffb5===_0xfa42d1;const _0x3d1d27=_0xfa42d1['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x3d1d27+'|'+_0x3d1d27+')$','i')['test'](_0x13ffb5);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x3919dd=Z()['___jsl'];if(_0x3919dd!=null&&_0x3919dd['H']){for(const _0x5adfd2 of Object['keys'](_0x3919dd['H']))if(_0x3919dd['H'][_0x5adfd2]['r']=_0x3919dd['H'][_0x5adfd2]['r']||[],_0x3919dd['H'][_0x5adfd2]['L']=_0x3919dd['H'][_0x5adfd2]['L']||[],_0x3919dd['H'][_0x5adfd2]['r']=[..._0x3919dd['H'][_0x5adfd2]['L']],_0x3919dd['CP']){for(let _0x19cae8=0x0;_0x19cae8<_0x3919dd['CP']['length'];_0x19cae8++)_0x3919dd['CP'][_0x19cae8]=null;}}}function Up(_0x21fcab){return new Promise((_0x3d207c,_0x1104e1)=>{var _0x3d5714,_0x245864,_0x5f3a2c;function _0x44235d(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x3d207c(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x1104e1(X(_0x21fcab,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x245864=(_0x3d5714=Z()['gapi'])==null?void 0x0:_0x3d5714['iframes'])!=null&&_0x245864['Iframe'])_0x3d207c(gapi['iframes']['getContext']());else{if((_0x5f3a2c=Z()['gapi'])!=null&&_0x5f3a2c['load'])_0x44235d();else{const _0x13e771=Df('iframefcb');return Z()[_0x13e771]=()=>{gapi['load']?_0x44235d():_0x1104e1(X(_0x21fcab,'network-request-failed'));},xa(Of()+'?onload='+_0x13e771)['catch'](_0x157381=>_0x1104e1(_0x157381));}}})['catch'](_0x3c2cfa=>{throw an=null,_0x3c2cfa;});}let an=null;function Wp(_0x39fe42){return an=an||Up(_0x39fe42),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x524190){const _0x246dcb=_0x524190['config'];m(_0x246dcb['authDomain'],_0x524190,'auth-domain-config-required');const _0x18bb1f=_0x246dcb['emulator']?Cs(_0x246dcb,Hp):'https://'+_0x524190['config']['authDomain']+'/'+Vp,_0x23ca53={'apiKey':_0x246dcb['apiKey'],'appName':_0x524190['name'],'v':lt},_0x86b256=Gp['get'](_0x524190['config']['apiHost']);_0x86b256&&(_0x23ca53['eid']=_0x86b256);const _0x29f8ba=_0x524190['_getFrameworks']();return _0x29f8ba['length']&&(_0x23ca53['fw']=_0x29f8ba['join'](',')),_0x18bb1f+'?'+ct(_0x23ca53)['slice'](0x1);}async function zp(_0x4c6c8d){const _0x54e072=await Wp(_0x4c6c8d),_0x437655=Z()['gapi'];return m(_0x437655,_0x4c6c8d,'internal-error'),_0x54e072['open']({'where':document['body'],'url':qp(_0x4c6c8d),'messageHandlersFilter':_0x437655['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x27da88=>new Promise(async(_0x100620,_0x3c7c3b)=>{await _0x27da88['restyle']({'setHideOnLeave':!0x1});const _0x49c6e7=X(_0x4c6c8d,'network-request-failed'),_0x164f09=Z()['setTimeout'](()=>{_0x3c7c3b(_0x49c6e7);},Bp['get']());function _0x1d6d1a(){Z()['clearTimeout'](_0x164f09),_0x100620(_0x27da88);}_0x27da88['ping'](_0x1d6d1a)['then'](_0x1d6d1a,()=>{_0x3c7c3b(_0x49c6e7);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x3b1434){this['window']=_0x3b1434,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x27d146,_0x1f60c1,_0x35fcd1,_0x5e813f=Kp,_0x36bfce=Yp){const _0x338150=Math['max']((window['screen']['availHeight']-_0x36bfce)/0x2,0x0)['toString'](),_0x38cf21=Math['max']((window['screen']['availWidth']-_0x5e813f)/0x2,0x0)['toString']();let _0x267ea7='';const _0x5d518f={...jp,'width':_0x5e813f['toString'](),'height':_0x36bfce['toString'](),'top':_0x338150,'left':_0x38cf21},_0x4c5e17=W()['toLowerCase']();_0x35fcd1&&(_0x267ea7=ka(_0x4c5e17)?Qp:_0x35fcd1),Ra(_0x4c5e17)&&(_0x1f60c1=_0x1f60c1||Jp,_0x5d518f['scrollbars']='yes');const _0x23483f=Object['entries'](_0x5d518f)['reduce']((_0x4d2a4a,[_0x3a6165,_0x3839d1])=>''+_0x4d2a4a+_0x3a6165+'='+_0x3839d1+',','');if(Cf(_0x4c5e17)&&_0x267ea7!=='_self')return Zp(_0x1f60c1||'',_0x267ea7),new Lr(null);const _0x470dff=window['open'](_0x1f60c1||'',_0x267ea7,_0x23483f);m(_0x470dff,_0x27d146,'popup-blocked');try{_0x470dff['focus']();}catch{}return new Lr(_0x470dff);}function Zp(_0x4cf70f,_0x4326ae){const _0x8dcdc4=document['createElement']('a');_0x8dcdc4['href']=_0x4cf70f,_0x8dcdc4['target']=_0x4326ae;const _0xaf1f3a=document['createEvent']('MouseEvent');_0xaf1f3a['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x8dcdc4['dispatchEvent'](_0xaf1f3a);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x29af4b,_0x272650,_0xc49253,_0x5c3d49,_0x137610,_0x5a0303){m(_0x29af4b['config']['authDomain'],_0x29af4b,'auth-domain-config-required'),m(_0x29af4b['config']['apiKey'],_0x29af4b,'invalid-api-key');const _0x113339={'apiKey':_0x29af4b['config']['apiKey'],'appName':_0x29af4b['name'],'authType':_0xc49253,'redirectUrl':_0x5c3d49,'v':lt,'eventId':_0x137610};if(_0x272650 instanceof Wa){_0x272650['setDefaultLanguage'](_0x29af4b['languageCode']),_0x113339['providerId']=_0x272650['providerId']||'',ui(_0x272650['getCustomParameters']())||(_0x113339['customParameters']=JSON['stringify'](_0x272650['getCustomParameters']()));for(const [_0x38617b,_0x1c509f]of Object['entries']({}))_0x113339[_0x38617b]=_0x1c509f;}if(_0x272650 instanceof Jt){const _0x55a7a2=_0x272650['getScopes']()['filter'](_0x64e86d=>_0x64e86d!=='');_0x55a7a2['length']>0x0&&(_0x113339['scopes']=_0x55a7a2['join'](','));}_0x29af4b['tenantId']&&(_0x113339['tid']=_0x29af4b['tenantId']);const _0x266fb0=_0x113339;for(const _0x204bee of Object['keys'](_0x266fb0))_0x266fb0[_0x204bee]===void 0x0&&delete _0x266fb0[_0x204bee];const _0x3ee863=await _0x29af4b['_getAppCheckToken'](),_0x146a87=_0x3ee863?'#'+n_+'='+encodeURIComponent(_0x3ee863):'';return i_(_0x29af4b)+'?'+ct(_0x266fb0)['slice'](0x1)+_0x146a87;}function i_({config:_0x5ed319}){return _0x5ed319['emulator']?Cs(_0x5ed319,t_):'https://'+_0x5ed319['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x65a4c3,_0x5c68c1,_0x43ebfd,_0x546f89){var _0x1e3960;ce((_0x1e3960=this['eventManagers'][_0x65a4c3['_key']()])==null?void 0x0:_0x1e3960['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x407ef9=await xr(_0x65a4c3,_0x5c68c1,_0x43ebfd,Pi(),_0x546f89);return Xp(_0x65a4c3,_0x407ef9,As());}async['_openRedirect'](_0x1cd352,_0x2244cb,_0x5ec5c3,_0x322d00){await this['_originValidation'](_0x1cd352);const _0x2ea6fa=await xr(_0x1cd352,_0x2244cb,_0x5ec5c3,Pi(),_0x322d00);return ap(_0x2ea6fa),new Promise(()=>{});}['_initialize'](_0x252d3f){const _0x4b7122=_0x252d3f['_key']();if(this['eventManagers'][_0x4b7122]){const {manager:_0x2facd2,promise:_0x34a11c}=this['eventManagers'][_0x4b7122];return _0x2facd2?Promise['resolve'](_0x2facd2):(ce(_0x34a11c,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x34a11c);}const _0x2b0613=this['initAndGetManager'](_0x252d3f);return this['eventManagers'][_0x4b7122]={'promise':_0x2b0613},_0x2b0613['catch'](()=>{delete this['eventManagers'][_0x4b7122];}),_0x2b0613;}async['initAndGetManager'](_0x1d034b){const _0x53910e=await zp(_0x1d034b),_0x5bb0b5=new Np(_0x1d034b);return _0x53910e['register']('authEvent',_0x3e3212=>(m(_0x3e3212==null?void 0x0:_0x3e3212['authEvent'],_0x1d034b,'invalid-auth-event'),{'status':_0x5bb0b5['onEvent'](_0x3e3212['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x1d034b['_key']()]={'manager':_0x5bb0b5},this['iframes'][_0x1d034b['_key']()]=_0x53910e,_0x5bb0b5;}['_isIframeWebStorageSupported'](_0xcd6226,_0x41f129){this['iframes'][_0xcd6226['_key']()]['send'](hi,{'type':hi},_0xdda95c=>{var _0x5ea249;const _0x2533f0=(_0x5ea249=_0xdda95c==null?void 0x0:_0xdda95c[0x0])==null?void 0x0:_0x5ea249[hi];_0x2533f0!==void 0x0&&_0x41f129(!!_0x2533f0),Q(_0xcd6226,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x21bc0c){const _0x3a5583=_0x21bc0c['_key']();return this['originValidationPromises'][_0x3a5583]||(this['originValidationPromises'][_0x3a5583]=Lp(_0x21bc0c)),this['originValidationPromises'][_0x3a5583];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x4a8b43){this['auth']=_0x4a8b43,this['internalListeners']=new Map();}['getUid'](){var _0x16df2f;return this['assertAuthConfigured'](),((_0x16df2f=this['auth']['currentUser'])==null?void 0x0:_0x16df2f['uid'])||null;}async['getToken'](_0xd8ee71){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0xd8ee71)}:null;}['addAuthTokenListener'](_0x67d6b4){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x67d6b4))return;const _0x492609=this['auth']['onIdTokenChanged'](_0x6ecfcb=>{_0x67d6b4((_0x6ecfcb==null?void 0x0:_0x6ecfcb['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x67d6b4,_0x492609),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x5efe89){this['assertAuthConfigured']();const _0x15982d=this['internalListeners']['get'](_0x5efe89);_0x15982d&&(this['internalListeners']['delete'](_0x5efe89),_0x15982d(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x5e82aa){switch(_0x5e82aa){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x29fa45){Ze(new Le('auth',(_0x501dfc,{options:_0x39dd20})=>{const _0x138225=_0x501dfc['getProvider']('app')['getImmediate'](),_0x2998d7=_0x501dfc['getProvider']('heartbeat'),_0x401f04=_0x501dfc['getProvider']('app-check-internal'),{apiKey:_0x2cb17b,authDomain:_0x2cebfe}=_0x138225['options'];m(_0x2cb17b&&!_0x2cb17b['includes'](':'),'invalid-api-key',{'appName':_0x138225['name']});const _0x2f7790={'apiKey':_0x2cb17b,'authDomain':_0x2cebfe,'clientPlatform':_0x29fa45,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x29fa45)},_0x3cfbd0=new kf(_0x138225,_0x2998d7,_0x401f04,_0x2f7790);return Wf(_0x3cfbd0,_0x39dd20),_0x3cfbd0;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x2ffad5,_0x5d8867,_0x7a17fa)=>{_0x2ffad5['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x37722f=>{const _0xfb0e06=qe(_0x37722f['getProvider']('auth')['getImmediate']());return(_0x310478=>new o_(_0x310478))(_0xfb0e06);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x29fa45)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x32a694=>async _0x47daf0=>{const _0x3f2975=_0x47daf0&&await _0x47daf0['getIdTokenResult'](),_0x377da6=_0x3f2975&&(new Date()['getTime']()-Date['parse'](_0x3f2975['issuedAtTime']))/0x3e8;if(_0x377da6&&_0x377da6>h_)return;const _0x588ded=_0x3f2975==null?void 0x0:_0x3f2975['token'];Wr!==_0x588ded&&(Wr=_0x588ded,await fetch(_0x32a694,{'method':_0x588ded?'POST':'DELETE','headers':_0x588ded?{'Authorization':'Bearer\x20'+_0x588ded}:{}}));};function x_(_0x1ee547=Zr()){const _0x1142b8=Bi(_0x1ee547,'auth');if(_0x1142b8['isInitialized']())return _0x1142b8['getImmediate']();const _0x1f5493=Uf(_0x1ee547,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x3f800e=zr('authTokenSyncURL');if(_0x3f800e&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x5598a9=new URL(_0x3f800e,location['origin']);if(location['origin']===_0x5598a9['origin']){const _0x24212c=u_(_0x5598a9['toString']());tp(_0x1f5493,_0x24212c,()=>_0x24212c(_0x1f5493['currentUser'])),ep(_0x1f5493,_0x37f798=>_0x24212c(_0x37f798));}}const _0x31d2ff=Gr('auth');return _0x31d2ff&&Bf(_0x1f5493,'http://'+_0x31d2ff),_0x1f5493;}function d_(){var _0x2f08bf;return((_0x2f08bf=document['getElementsByTagName']('head'))==null?void 0x0:_0x2f08bf[0x0])??document;}Nf({'loadJS'(_0x5b0b6b){return new Promise((_0xff29b4,_0x2a607f)=>{const _0x8cfb16=document['createElement']('script');_0x8cfb16['setAttribute']('src',_0x5b0b6b),_0x8cfb16['onload']=_0xff29b4,_0x8cfb16['onerror']=_0x14c363=>{const _0x38baeb=X('internal-error');_0x38baeb['customData']=_0x14c363,_0x2a607f(_0x38baeb);},_0x8cfb16['type']='text/javascript',_0x8cfb16['charset']='UTF-8',d_()['appendChild'](_0x8cfb16);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};