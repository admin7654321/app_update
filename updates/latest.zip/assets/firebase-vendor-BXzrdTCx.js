const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0xe0d674,_0x35bd19){if(!_0xe0d674)throw rt(_0x35bd19);},rt=function(_0x597ed8){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x597ed8);},Vr=function(_0x390387){const _0x6a8ea=[];let _0x1c6bb1=0x0;for(let _0x142cec=0x0;_0x142cec<_0x390387['length'];_0x142cec++){let _0x5be1da=_0x390387['charCodeAt'](_0x142cec);_0x5be1da<0x80?_0x6a8ea[_0x1c6bb1++]=_0x5be1da:_0x5be1da<0x800?(_0x6a8ea[_0x1c6bb1++]=_0x5be1da>>0x6|0xc0,_0x6a8ea[_0x1c6bb1++]=_0x5be1da&0x3f|0x80):(_0x5be1da&0xfc00)===0xd800&&_0x142cec+0x1<_0x390387['length']&&(_0x390387['charCodeAt'](_0x142cec+0x1)&0xfc00)===0xdc00?(_0x5be1da=0x10000+((_0x5be1da&0x3ff)<<0xa)+(_0x390387['charCodeAt'](++_0x142cec)&0x3ff),_0x6a8ea[_0x1c6bb1++]=_0x5be1da>>0x12|0xf0,_0x6a8ea[_0x1c6bb1++]=_0x5be1da>>0xc&0x3f|0x80,_0x6a8ea[_0x1c6bb1++]=_0x5be1da>>0x6&0x3f|0x80,_0x6a8ea[_0x1c6bb1++]=_0x5be1da&0x3f|0x80):(_0x6a8ea[_0x1c6bb1++]=_0x5be1da>>0xc|0xe0,_0x6a8ea[_0x1c6bb1++]=_0x5be1da>>0x6&0x3f|0x80,_0x6a8ea[_0x1c6bb1++]=_0x5be1da&0x3f|0x80);}return _0x6a8ea;},ec=function(_0x2bc81b){const _0x538071=[];let _0x206bb3=0x0,_0x5b17dd=0x0;for(;_0x206bb3<_0x2bc81b['length'];){const _0x48b1da=_0x2bc81b[_0x206bb3++];if(_0x48b1da<0x80)_0x538071[_0x5b17dd++]=String['fromCharCode'](_0x48b1da);else{if(_0x48b1da>0xbf&&_0x48b1da<0xe0){const _0x4af6c8=_0x2bc81b[_0x206bb3++];_0x538071[_0x5b17dd++]=String['fromCharCode']((_0x48b1da&0x1f)<<0x6|_0x4af6c8&0x3f);}else{if(_0x48b1da>0xef&&_0x48b1da<0x16d){const _0x5ee7e8=_0x2bc81b[_0x206bb3++],_0x45a982=_0x2bc81b[_0x206bb3++],_0x5083b6=_0x2bc81b[_0x206bb3++],_0x5cd4a9=((_0x48b1da&0x7)<<0x12|(_0x5ee7e8&0x3f)<<0xc|(_0x45a982&0x3f)<<0x6|_0x5083b6&0x3f)-0x10000;_0x538071[_0x5b17dd++]=String['fromCharCode'](0xd800+(_0x5cd4a9>>0xa)),_0x538071[_0x5b17dd++]=String['fromCharCode'](0xdc00+(_0x5cd4a9&0x3ff));}else{const _0x4bf5af=_0x2bc81b[_0x206bb3++],_0x347d60=_0x2bc81b[_0x206bb3++];_0x538071[_0x5b17dd++]=String['fromCharCode']((_0x48b1da&0xf)<<0xc|(_0x4bf5af&0x3f)<<0x6|_0x347d60&0x3f);}}}}return _0x538071['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x425494,_0x30d850){if(!Array['isArray'](_0x425494))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x36bfd2=_0x30d850?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x1efb29=[];for(let _0x24d64f=0x0;_0x24d64f<_0x425494['length'];_0x24d64f+=0x3){const _0x7fe68c=_0x425494[_0x24d64f],_0x3439bd=_0x24d64f+0x1<_0x425494['length'],_0xfd70d1=_0x3439bd?_0x425494[_0x24d64f+0x1]:0x0,_0x33693f=_0x24d64f+0x2<_0x425494['length'],_0x57c601=_0x33693f?_0x425494[_0x24d64f+0x2]:0x0,_0x2db254=_0x7fe68c>>0x2,_0xd5d03a=(_0x7fe68c&0x3)<<0x4|_0xfd70d1>>0x4;let _0x8579e7=(_0xfd70d1&0xf)<<0x2|_0x57c601>>0x6,_0x5b45d8=_0x57c601&0x3f;_0x33693f||(_0x5b45d8=0x40,_0x3439bd||(_0x8579e7=0x40)),_0x1efb29['push'](_0x36bfd2[_0x2db254],_0x36bfd2[_0xd5d03a],_0x36bfd2[_0x8579e7],_0x36bfd2[_0x5b45d8]);}return _0x1efb29['join']('');},'encodeString'(_0x3d0924,_0x51f727){return this['HAS_NATIVE_SUPPORT']&&!_0x51f727?btoa(_0x3d0924):this['encodeByteArray'](Vr(_0x3d0924),_0x51f727);},'decodeString'(_0x158e96,_0x565e72){return this['HAS_NATIVE_SUPPORT']&&!_0x565e72?atob(_0x158e96):ec(this['decodeStringToByteArray'](_0x158e96,_0x565e72));},'decodeStringToByteArray'(_0x37d623,_0x1672e8){this['init_']();const _0x1518d9=_0x1672e8?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x28a567=[];for(let _0x377f61=0x0;_0x377f61<_0x37d623['length'];){const _0x271b8c=_0x1518d9[_0x37d623['charAt'](_0x377f61++)],_0x12508c=_0x377f61<_0x37d623['length']?_0x1518d9[_0x37d623['charAt'](_0x377f61)]:0x0;++_0x377f61;const _0x34bbcb=_0x377f61<_0x37d623['length']?_0x1518d9[_0x37d623['charAt'](_0x377f61)]:0x40;++_0x377f61;const _0x39a82f=_0x377f61<_0x37d623['length']?_0x1518d9[_0x37d623['charAt'](_0x377f61)]:0x40;if(++_0x377f61,_0x271b8c==null||_0x12508c==null||_0x34bbcb==null||_0x39a82f==null)throw new tc();const _0x2820d8=_0x271b8c<<0x2|_0x12508c>>0x4;if(_0x28a567['push'](_0x2820d8),_0x34bbcb!==0x40){const _0x20074f=_0x12508c<<0x4&0xf0|_0x34bbcb>>0x2;if(_0x28a567['push'](_0x20074f),_0x39a82f!==0x40){const _0x3c6612=_0x34bbcb<<0x6&0xc0|_0x39a82f;_0x28a567['push'](_0x3c6612);}}}return _0x28a567;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x36a726=0x0;_0x36a726<this['ENCODED_VALS']['length'];_0x36a726++)this['byteToCharMap_'][_0x36a726]=this['ENCODED_VALS']['charAt'](_0x36a726),this['charToByteMap_'][this['byteToCharMap_'][_0x36a726]]=_0x36a726,this['byteToCharMapWebSafe_'][_0x36a726]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x36a726),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x36a726]]=_0x36a726,_0x36a726>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x36a726)]=_0x36a726,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x36a726)]=_0x36a726);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x697547){const _0x1265af=Vr(_0x697547);return Li['encodeByteArray'](_0x1265af,!0x0);},cn=function(_0x58393f){return Hr(_0x58393f)['replace'](/\./g,'');},ln=function(_0x38be48){try{return Li['decodeString'](_0x38be48,!0x0);}catch(_0x552a92){console['error']('base64Decode\x20failed:\x20',_0x552a92);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x5dabce){return $r(void 0x0,_0x5dabce);}function $r(_0x3c5062,_0x3b982b){if(!(_0x3b982b instanceof Object))return _0x3b982b;switch(_0x3b982b['constructor']){case Date:const _0x144daf=_0x3b982b;return new Date(_0x144daf['getTime']());case Object:_0x3c5062===void 0x0&&(_0x3c5062={});break;case Array:_0x3c5062=[];break;default:return _0x3b982b;}for(const _0x5bcb8f in _0x3b982b)!_0x3b982b['hasOwnProperty'](_0x5bcb8f)||!ic(_0x5bcb8f)||(_0x3c5062[_0x5bcb8f]=$r(_0x3c5062[_0x5bcb8f],_0x3b982b[_0x5bcb8f]));return _0x3c5062;}function ic(_0x217ef0){return _0x217ef0!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0xa8a12d=Ns['__FIREBASE_DEFAULTS__'];if(_0xa8a12d)return JSON['parse'](_0xa8a12d);},ac=()=>{if(typeof document>'u')return;let _0xc67cba;try{_0xc67cba=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x48eb1f=_0xc67cba&&ln(_0xc67cba[0x1]);return _0x48eb1f&&JSON['parse'](_0x48eb1f);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x11b638){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x11b638);return;}},Gr=_0x489b88=>{var _0x51251d,_0x57d9be;return(_0x57d9be=(_0x51251d=xi())==null?void 0x0:_0x51251d['emulatorHosts'])==null?void 0x0:_0x57d9be[_0x489b88];},cc=_0x461937=>{const _0x562893=Gr(_0x461937);if(!_0x562893)return;const _0x563f50=_0x562893['lastIndexOf'](':');if(_0x563f50<=0x0||_0x563f50+0x1===_0x562893['length'])throw new Error('Invalid\x20host\x20'+_0x562893+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x4fbe23=parseInt(_0x562893['substring'](_0x563f50+0x1),0xa);return _0x562893[0x0]==='['?[_0x562893['substring'](0x1,_0x563f50-0x1),_0x4fbe23]:[_0x562893['substring'](0x0,_0x563f50),_0x4fbe23];},qr=()=>{var _0x4d7b16;return(_0x4d7b16=xi())==null?void 0x0:_0x4d7b16['config'];},zr=_0x3508fe=>{var _0x3f8225;return(_0x3f8225=xi())==null?void 0x0:_0x3f8225['_'+_0x3508fe];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x31ef9e,_0x59d31b)=>{this['resolve']=_0x31ef9e,this['reject']=_0x59d31b;});}['wrapCallback'](_0x53b964){return(_0x30b6ed,_0xe78add)=>{_0x30b6ed?this['reject'](_0x30b6ed):this['resolve'](_0xe78add),typeof _0x53b964=='function'&&(this['promise']['catch'](()=>{}),_0x53b964['length']===0x1?_0x53b964(_0x30b6ed):_0x53b964(_0x30b6ed,_0xe78add));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x3b7f79){try{return(_0x3b7f79['startsWith']('http://')||_0x3b7f79['startsWith']('https://')?new URL(_0x3b7f79)['hostname']:_0x3b7f79)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0xbed7dc){return(await fetch(_0xbed7dc,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x2006df,_0x411837){if(_0x2006df['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x5e64ad={'alg':'none','type':'JWT'},_0x2f3031=_0x411837||'demo-project',_0x146db8=_0x2006df['iat']||0x0,_0x576dce=_0x2006df['sub']||_0x2006df['user_id'];if(!_0x576dce)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x55d3d0={'iss':'https://securetoken.google.com/'+_0x2f3031,'aud':_0x2f3031,'iat':_0x146db8,'exp':_0x146db8+0xe10,'auth_time':_0x146db8,'sub':_0x576dce,'user_id':_0x576dce,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x2006df};return[cn(JSON['stringify'](_0x5e64ad)),cn(JSON['stringify'](_0x55d3d0)),'']['join']('.');}const It={};function hc(){const _0x16a588={'prod':[],'emulator':[]};for(const _0x49b3f3 of Object['keys'](It))It[_0x49b3f3]?_0x16a588['emulator']['push'](_0x49b3f3):_0x16a588['prod']['push'](_0x49b3f3);return _0x16a588;}function uc(_0x6fde4c){let _0x28e590=document['getElementById'](_0x6fde4c),_0x30a19e=!0x1;return _0x28e590||(_0x28e590=document['createElement']('div'),_0x28e590['setAttribute']('id',_0x6fde4c),_0x30a19e=!0x0),{'created':_0x30a19e,'element':_0x28e590};}let Ps=!0x1;function Kr(_0x3c5975,_0x3c2179){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x3c5975]===_0x3c2179||It[_0x3c5975]||Ps)return;It[_0x3c5975]=_0x3c2179;function _0x70b361(_0x457462){return'__firebase__banner__'+_0x457462;}const _0x3d908e='__firebase__banner',_0x583931=hc()['prod']['length']>0x0;function _0x37144e(){const _0x2f80cc=document['getElementById'](_0x3d908e);_0x2f80cc&&_0x2f80cc['remove']();}function _0x541bf9(_0x501564){_0x501564['style']['display']='flex',_0x501564['style']['background']='#7faaf0',_0x501564['style']['position']='fixed',_0x501564['style']['bottom']='5px',_0x501564['style']['left']='5px',_0x501564['style']['padding']='.5em',_0x501564['style']['borderRadius']='5px',_0x501564['style']['alignItems']='center';}function _0x4e04b9(_0x8b9fe1,_0x75cd52){_0x8b9fe1['setAttribute']('width','24'),_0x8b9fe1['setAttribute']('id',_0x75cd52),_0x8b9fe1['setAttribute']('height','24'),_0x8b9fe1['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x8b9fe1['setAttribute']('fill','none'),_0x8b9fe1['style']['marginLeft']='-6px';}function _0x1c3350(){const _0x2e98e3=document['createElement']('span');return _0x2e98e3['style']['cursor']='pointer',_0x2e98e3['style']['marginLeft']='16px',_0x2e98e3['style']['fontSize']='24px',_0x2e98e3['innerHTML']='\x20&times;',_0x2e98e3['onclick']=()=>{Ps=!0x0,_0x37144e();},_0x2e98e3;}function _0x46a36c(_0x49c5f2,_0x243a84){_0x49c5f2['setAttribute']('id',_0x243a84),_0x49c5f2['innerText']='Learn\x20more',_0x49c5f2['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x49c5f2['setAttribute']('target','__blank'),_0x49c5f2['style']['paddingLeft']='5px',_0x49c5f2['style']['textDecoration']='underline';}function _0x459bc5(){const _0x41bb6f=uc(_0x3d908e),_0x55ed09=_0x70b361('text'),_0x204275=document['getElementById'](_0x55ed09)||document['createElement']('span'),_0x59a61b=_0x70b361('learnmore'),_0x435eea=document['getElementById'](_0x59a61b)||document['createElement']('a'),_0x2ac029=_0x70b361('preprendIcon'),_0x404cf7=document['getElementById'](_0x2ac029)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x41bb6f['created']){const _0x2d23fb=_0x41bb6f['element'];_0x541bf9(_0x2d23fb),_0x46a36c(_0x435eea,_0x59a61b);const _0xb0bbf0=_0x1c3350();_0x4e04b9(_0x404cf7,_0x2ac029),_0x2d23fb['append'](_0x404cf7,_0x204275,_0x435eea,_0xb0bbf0),document['body']['appendChild'](_0x2d23fb);}_0x583931?(_0x204275['innerText']='Preview\x20backend\x20disconnected.',_0x404cf7['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x404cf7['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x204275['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x204275['setAttribute']('id',_0x55ed09);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x459bc5):_0x459bc5();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x33e160=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x33e160=='object'&&_0x33e160['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x1f4525=W();return _0x1f4525['indexOf']('MSIE\x20')>=0x0||_0x1f4525['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x1ea62b,_0x4caede)=>{try{let _0x24e1a0=!0x0;const _0xc55908='validate-browser-context-for-indexeddb-analytics-module',_0x4b075c=self['indexedDB']['open'](_0xc55908);_0x4b075c['onsuccess']=()=>{_0x4b075c['result']['close'](),_0x24e1a0||self['indexedDB']['deleteDatabase'](_0xc55908),_0x1ea62b(!0x0);},_0x4b075c['onupgradeneeded']=()=>{_0x24e1a0=!0x1;},_0x4b075c['onerror']=()=>{var _0xb4eb4d;_0x4caede(((_0xb4eb4d=_0x4b075c['error'])==null?void 0x0:_0xb4eb4d['message'])||'');};}catch(_0x3e6aff){_0x4caede(_0x3e6aff);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x18206d,_0x620dc0,_0x49196a){super(_0x620dc0),this['code']=_0x18206d,this['customData']=_0x49196a,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x55d57d,_0x4241ce,_0x4f5ba6){this['service']=_0x55d57d,this['serviceName']=_0x4241ce,this['errors']=_0x4f5ba6;}['create'](_0x1437f2,..._0x3021e1){const _0x4340f9=_0x3021e1[0x0]||{},_0x434d9b=this['service']+'/'+_0x1437f2,_0xfe5f8b=this['errors'][_0x1437f2],_0x582c97=_0xfe5f8b?vc(_0xfe5f8b,_0x4340f9):'Error',_0x2ff44b=this['serviceName']+':\x20'+_0x582c97+'\x20('+_0x434d9b+').';return new Se(_0x434d9b,_0x2ff44b,_0x4340f9);}}function vc(_0x3b9436,_0x13d884){return _0x3b9436['replace'](Ec,(_0xc8b6c1,_0x12dda0)=>{const _0x346a7a=_0x13d884[_0x12dda0];return _0x346a7a!=null?String(_0x346a7a):'<'+_0x12dda0+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x52a756){return JSON['parse'](_0x52a756);}function O(_0x121160){return JSON['stringify'](_0x121160);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x353ce6){let _0x4f6383={},_0xb36f6={},_0x5791a9={},_0x9eb757='';try{const _0x4405b9=_0x353ce6['split']('.');_0x4f6383=At(ln(_0x4405b9[0x0])||''),_0xb36f6=At(ln(_0x4405b9[0x1])||''),_0x9eb757=_0x4405b9[0x2],_0x5791a9=_0xb36f6['d']||{},delete _0xb36f6['d'];}catch{}return{'header':_0x4f6383,'claims':_0xb36f6,'data':_0x5791a9,'signature':_0x9eb757};},Ic=function(_0x3945a1){const _0x992b70=Qr(_0x3945a1),_0xe6877a=_0x992b70['claims'];return!!_0xe6877a&&typeof _0xe6877a=='object'&&_0xe6877a['hasOwnProperty']('iat');},wc=function(_0x5831f5){const _0x390cc1=Qr(_0x5831f5)['claims'];return typeof _0x390cc1=='object'&&_0x390cc1['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x1412a6,_0x549aec){return Object['prototype']['hasOwnProperty']['call'](_0x1412a6,_0x549aec);}function De(_0x1ea5c9,_0x4dd343){if(Object['prototype']['hasOwnProperty']['call'](_0x1ea5c9,_0x4dd343))return _0x1ea5c9[_0x4dd343];}function ui(_0x54a7fd){for(const _0x2e0e35 in _0x54a7fd)if(Object['prototype']['hasOwnProperty']['call'](_0x54a7fd,_0x2e0e35))return!0x1;return!0x0;}function hn(_0x52faed,_0xf615e2,_0x13dcc0){const _0x53bd53={};for(const _0x14b393 in _0x52faed)Object['prototype']['hasOwnProperty']['call'](_0x52faed,_0x14b393)&&(_0x53bd53[_0x14b393]=_0xf615e2['call'](_0x13dcc0,_0x52faed[_0x14b393],_0x14b393,_0x52faed));return _0x53bd53;}function Me(_0x59c14f,_0x179268){if(_0x59c14f===_0x179268)return!0x0;const _0x50be1d=Object['keys'](_0x59c14f),_0x323d2f=Object['keys'](_0x179268);for(const _0x5acd2f of _0x50be1d){if(!_0x323d2f['includes'](_0x5acd2f))return!0x1;const _0x4a77e1=_0x59c14f[_0x5acd2f],_0x562164=_0x179268[_0x5acd2f];if(Os(_0x4a77e1)&&Os(_0x562164)){if(!Me(_0x4a77e1,_0x562164))return!0x1;}else{if(_0x4a77e1!==_0x562164)return!0x1;}}for(const _0x5a3e2a of _0x323d2f)if(!_0x50be1d['includes'](_0x5a3e2a))return!0x1;return!0x0;}function Os(_0x3ad3be){return _0x3ad3be!==null&&typeof _0x3ad3be=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x325bc1){const _0x4bbd6a=[];for(const [_0x4cb7ab,_0x35f04c]of Object['entries'](_0x325bc1))Array['isArray'](_0x35f04c)?_0x35f04c['forEach'](_0x4b461d=>{_0x4bbd6a['push'](encodeURIComponent(_0x4cb7ab)+'='+encodeURIComponent(_0x4b461d));}):_0x4bbd6a['push'](encodeURIComponent(_0x4cb7ab)+'='+encodeURIComponent(_0x35f04c));return _0x4bbd6a['length']?'&'+_0x4bbd6a['join']('&'):'';}function vt(_0x170b7d){const _0x12b194={};return _0x170b7d['replace'](/^\?/,'')['split']('&')['forEach'](_0x342256=>{if(_0x342256){const [_0x385f76,_0x3ad3b4]=_0x342256['split']('=');_0x12b194[decodeURIComponent(_0x385f76)]=decodeURIComponent(_0x3ad3b4);}}),_0x12b194;}function Et(_0x26f9fe){const _0x26e910=_0x26f9fe['indexOf']('?');if(!_0x26e910)return'';const _0x14fe0f=_0x26f9fe['indexOf']('#',_0x26e910);return _0x26f9fe['substring'](_0x26e910,_0x14fe0f>0x0?_0x14fe0f:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x28e61e=0x1;_0x28e61e<this['blockSize'];++_0x28e61e)this['pad_'][_0x28e61e]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x30a954,_0x156408){_0x156408||(_0x156408=0x0);const _0x5dcfe4=this['W_'];if(typeof _0x30a954=='string'){for(let _0x54bdf0=0x0;_0x54bdf0<0x10;_0x54bdf0++)_0x5dcfe4[_0x54bdf0]=_0x30a954['charCodeAt'](_0x156408)<<0x18|_0x30a954['charCodeAt'](_0x156408+0x1)<<0x10|_0x30a954['charCodeAt'](_0x156408+0x2)<<0x8|_0x30a954['charCodeAt'](_0x156408+0x3),_0x156408+=0x4;}else{for(let _0x1fe518=0x0;_0x1fe518<0x10;_0x1fe518++)_0x5dcfe4[_0x1fe518]=_0x30a954[_0x156408]<<0x18|_0x30a954[_0x156408+0x1]<<0x10|_0x30a954[_0x156408+0x2]<<0x8|_0x30a954[_0x156408+0x3],_0x156408+=0x4;}for(let _0x3c80d0=0x10;_0x3c80d0<0x50;_0x3c80d0++){const _0x44ee4b=_0x5dcfe4[_0x3c80d0-0x3]^_0x5dcfe4[_0x3c80d0-0x8]^_0x5dcfe4[_0x3c80d0-0xe]^_0x5dcfe4[_0x3c80d0-0x10];_0x5dcfe4[_0x3c80d0]=(_0x44ee4b<<0x1|_0x44ee4b>>>0x1f)&0xffffffff;}let _0x2334a1=this['chain_'][0x0],_0x292a63=this['chain_'][0x1],_0x46be97=this['chain_'][0x2],_0x49e297=this['chain_'][0x3],_0x2741db=this['chain_'][0x4],_0x5ccf6c,_0x4028d0;for(let _0xe52550=0x0;_0xe52550<0x50;_0xe52550++){_0xe52550<0x28?_0xe52550<0x14?(_0x5ccf6c=_0x49e297^_0x292a63&(_0x46be97^_0x49e297),_0x4028d0=0x5a827999):(_0x5ccf6c=_0x292a63^_0x46be97^_0x49e297,_0x4028d0=0x6ed9eba1):_0xe52550<0x3c?(_0x5ccf6c=_0x292a63&_0x46be97|_0x49e297&(_0x292a63|_0x46be97),_0x4028d0=0x8f1bbcdc):(_0x5ccf6c=_0x292a63^_0x46be97^_0x49e297,_0x4028d0=0xca62c1d6);const _0x5dd6a6=(_0x2334a1<<0x5|_0x2334a1>>>0x1b)+_0x5ccf6c+_0x2741db+_0x4028d0+_0x5dcfe4[_0xe52550]&0xffffffff;_0x2741db=_0x49e297,_0x49e297=_0x46be97,_0x46be97=(_0x292a63<<0x1e|_0x292a63>>>0x2)&0xffffffff,_0x292a63=_0x2334a1,_0x2334a1=_0x5dd6a6;}this['chain_'][0x0]=this['chain_'][0x0]+_0x2334a1&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x292a63&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x46be97&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x49e297&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x2741db&0xffffffff;}['update'](_0x40f3bc,_0x4494ca){if(_0x40f3bc==null)return;_0x4494ca===void 0x0&&(_0x4494ca=_0x40f3bc['length']);const _0x28a467=_0x4494ca-this['blockSize'];let _0x3a9c1a=0x0;const _0x34dadd=this['buf_'];let _0x3c52ff=this['inbuf_'];for(;_0x3a9c1a<_0x4494ca;){if(_0x3c52ff===0x0){for(;_0x3a9c1a<=_0x28a467;)this['compress_'](_0x40f3bc,_0x3a9c1a),_0x3a9c1a+=this['blockSize'];}if(typeof _0x40f3bc=='string'){for(;_0x3a9c1a<_0x4494ca;)if(_0x34dadd[_0x3c52ff]=_0x40f3bc['charCodeAt'](_0x3a9c1a),++_0x3c52ff,++_0x3a9c1a,_0x3c52ff===this['blockSize']){this['compress_'](_0x34dadd),_0x3c52ff=0x0;break;}}else{for(;_0x3a9c1a<_0x4494ca;)if(_0x34dadd[_0x3c52ff]=_0x40f3bc[_0x3a9c1a],++_0x3c52ff,++_0x3a9c1a,_0x3c52ff===this['blockSize']){this['compress_'](_0x34dadd),_0x3c52ff=0x0;break;}}}this['inbuf_']=_0x3c52ff,this['total_']+=_0x4494ca;}['digest'](){const _0x5a536a=[];let _0x12a028=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x3c1caa=this['blockSize']-0x1;_0x3c1caa>=0x38;_0x3c1caa--)this['buf_'][_0x3c1caa]=_0x12a028&0xff,_0x12a028/=0x100;this['compress_'](this['buf_']);let _0xf52db9=0x0;for(let _0x491f38=0x0;_0x491f38<0x5;_0x491f38++)for(let _0x29d5b7=0x18;_0x29d5b7>=0x0;_0x29d5b7-=0x8)_0x5a536a[_0xf52db9]=this['chain_'][_0x491f38]>>_0x29d5b7&0xff,++_0xf52db9;return _0x5a536a;}}function Tc(_0x1e418d,_0x368c68){const _0x52aec7=new Sc(_0x1e418d,_0x368c68);return _0x52aec7['subscribe']['bind'](_0x52aec7);}class Sc{constructor(_0x49a61d,_0x55af83){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x55af83,this['task']['then'](()=>{_0x49a61d(this);})['catch'](_0x15bc68=>{this['error'](_0x15bc68);});}['next'](_0x181c75){this['forEachObserver'](_0x22743d=>{_0x22743d['next'](_0x181c75);});}['error'](_0x2cf15b){this['forEachObserver'](_0x3b9508=>{_0x3b9508['error'](_0x2cf15b);}),this['close'](_0x2cf15b);}['complete'](){this['forEachObserver'](_0x6c1855=>{_0x6c1855['complete']();}),this['close']();}['subscribe'](_0x243dd3,_0x9c057,_0x448572){let _0x5094e0;if(_0x243dd3===void 0x0&&_0x9c057===void 0x0&&_0x448572===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x243dd3,['next','error','complete'])?_0x5094e0=_0x243dd3:_0x5094e0={'next':_0x243dd3,'error':_0x9c057,'complete':_0x448572},_0x5094e0['next']===void 0x0&&(_0x5094e0['next']=Jn),_0x5094e0['error']===void 0x0&&(_0x5094e0['error']=Jn),_0x5094e0['complete']===void 0x0&&(_0x5094e0['complete']=Jn);const _0x2b6bfc=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x5094e0['error'](this['finalError']):_0x5094e0['complete']();}catch{}}),this['observers']['push'](_0x5094e0),_0x2b6bfc;}['unsubscribeOne'](_0x3b8fdc){this['observers']===void 0x0||this['observers'][_0x3b8fdc]===void 0x0||(delete this['observers'][_0x3b8fdc],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x6aa3c1){if(!this['finalized']){for(let _0x5ae135=0x0;_0x5ae135<this['observers']['length'];_0x5ae135++)this['sendOne'](_0x5ae135,_0x6aa3c1);}}['sendOne'](_0x162acc,_0x3f5202){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x162acc]!==void 0x0)try{_0x3f5202(this['observers'][_0x162acc]);}catch(_0x2fcf85){typeof console<'u'&&console['error']&&console['error'](_0x2fcf85);}});}['close'](_0xf360f1){this['finalized']||(this['finalized']=!0x0,_0xf360f1!==void 0x0&&(this['finalError']=_0xf360f1),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x286b6e,_0x286d45){if(typeof _0x286b6e!='object'||_0x286b6e===null)return!0x1;for(const _0x5537d9 of _0x286d45)if(_0x5537d9 in _0x286b6e&&typeof _0x286b6e[_0x5537d9]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x237f13,_0x390761){return _0x237f13+'\x20failed:\x20'+_0x390761+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x197372){const _0x1b5b60=[];let _0x4e6479=0x0;for(let _0x2bbef6=0x0;_0x2bbef6<_0x197372['length'];_0x2bbef6++){let _0x141ace=_0x197372['charCodeAt'](_0x2bbef6);if(_0x141ace>=0xd800&&_0x141ace<=0xdbff){const _0x379965=_0x141ace-0xd800;_0x2bbef6++,f(_0x2bbef6<_0x197372['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x187ee3=_0x197372['charCodeAt'](_0x2bbef6)-0xdc00;_0x141ace=0x10000+(_0x379965<<0xa)+_0x187ee3;}_0x141ace<0x80?_0x1b5b60[_0x4e6479++]=_0x141ace:_0x141ace<0x800?(_0x1b5b60[_0x4e6479++]=_0x141ace>>0x6|0xc0,_0x1b5b60[_0x4e6479++]=_0x141ace&0x3f|0x80):_0x141ace<0x10000?(_0x1b5b60[_0x4e6479++]=_0x141ace>>0xc|0xe0,_0x1b5b60[_0x4e6479++]=_0x141ace>>0x6&0x3f|0x80,_0x1b5b60[_0x4e6479++]=_0x141ace&0x3f|0x80):(_0x1b5b60[_0x4e6479++]=_0x141ace>>0x12|0xf0,_0x1b5b60[_0x4e6479++]=_0x141ace>>0xc&0x3f|0x80,_0x1b5b60[_0x4e6479++]=_0x141ace>>0x6&0x3f|0x80,_0x1b5b60[_0x4e6479++]=_0x141ace&0x3f|0x80);}return _0x1b5b60;},On=function(_0x3098e2){let _0xfe0e25=0x0;for(let _0x1484e8=0x0;_0x1484e8<_0x3098e2['length'];_0x1484e8++){const _0x32348f=_0x3098e2['charCodeAt'](_0x1484e8);_0x32348f<0x80?_0xfe0e25++:_0x32348f<0x800?_0xfe0e25+=0x2:_0x32348f>=0xd800&&_0x32348f<=0xdbff?(_0xfe0e25+=0x4,_0x1484e8++):_0xfe0e25+=0x3;}return _0xfe0e25;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x1bb0f7){return _0x1bb0f7&&_0x1bb0f7['_delegate']?_0x1bb0f7['_delegate']:_0x1bb0f7;}class Le{constructor(_0x469a2e,_0x6fecc8,_0xb2f8b2){this['name']=_0x469a2e,this['instanceFactory']=_0x6fecc8,this['type']=_0xb2f8b2,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x569f63){return this['instantiationMode']=_0x569f63,this;}['setMultipleInstances'](_0x58f6a2){return this['multipleInstances']=_0x58f6a2,this;}['setServiceProps'](_0x45d74a){return this['serviceProps']=_0x45d74a,this;}['setInstanceCreatedCallback'](_0x3775da){return this['onInstanceCreated']=_0x3775da,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x3f0a2f,_0x25ed08){this['name']=_0x3f0a2f,this['container']=_0x25ed08,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0xf84136){const _0x37018c=this['normalizeInstanceIdentifier'](_0xf84136);if(!this['instancesDeferred']['has'](_0x37018c)){const _0x4a8895=new ot();if(this['instancesDeferred']['set'](_0x37018c,_0x4a8895),this['isInitialized'](_0x37018c)||this['shouldAutoInitialize']())try{const _0x558384=this['getOrInitializeService']({'instanceIdentifier':_0x37018c});_0x558384&&_0x4a8895['resolve'](_0x558384);}catch{}}return this['instancesDeferred']['get'](_0x37018c)['promise'];}['getImmediate'](_0x4e876f){const _0x44b6fa=this['normalizeInstanceIdentifier'](_0x4e876f==null?void 0x0:_0x4e876f['identifier']),_0x2e5305=(_0x4e876f==null?void 0x0:_0x4e876f['optional'])??!0x1;if(this['isInitialized'](_0x44b6fa)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x44b6fa});}catch(_0x2b5b3b){if(_0x2e5305)return null;throw _0x2b5b3b;}else{if(_0x2e5305)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x1bc00d){if(_0x1bc00d['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x1bc00d['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x1bc00d,!!this['shouldAutoInitialize']()){if(Nc(_0x1bc00d))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x4c92fc,_0x208590]of this['instancesDeferred']['entries']()){const _0x42e10a=this['normalizeInstanceIdentifier'](_0x4c92fc);try{const _0x29fa83=this['getOrInitializeService']({'instanceIdentifier':_0x42e10a});_0x208590['resolve'](_0x29fa83);}catch{}}}}['clearInstance'](_0x4b1b2e=Ne){this['instancesDeferred']['delete'](_0x4b1b2e),this['instancesOptions']['delete'](_0x4b1b2e),this['instances']['delete'](_0x4b1b2e);}async['delete'](){const _0x3cdecf=Array['from'](this['instances']['values']());await Promise['all']([..._0x3cdecf['filter'](_0x2e01ae=>'INTERNAL'in _0x2e01ae)['map'](_0x5721a1=>_0x5721a1['INTERNAL']['delete']()),..._0x3cdecf['filter'](_0x34a3dc=>'_delete'in _0x34a3dc)['map'](_0x5bf558=>_0x5bf558['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x2bede6=Ne){return this['instances']['has'](_0x2bede6);}['getOptions'](_0x2695c0=Ne){return this['instancesOptions']['get'](_0x2695c0)||{};}['initialize'](_0x1802cc={}){const {options:_0x5eb710={}}=_0x1802cc,_0x3ad35d=this['normalizeInstanceIdentifier'](_0x1802cc['instanceIdentifier']);if(this['isInitialized'](_0x3ad35d))throw Error(this['name']+'('+_0x3ad35d+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x19418d=this['getOrInitializeService']({'instanceIdentifier':_0x3ad35d,'options':_0x5eb710});for(const [_0x542766,_0x4e2ec2]of this['instancesDeferred']['entries']()){const _0x52f8b6=this['normalizeInstanceIdentifier'](_0x542766);_0x3ad35d===_0x52f8b6&&_0x4e2ec2['resolve'](_0x19418d);}return _0x19418d;}['onInit'](_0x1cb359,_0x179242){const _0x517d17=this['normalizeInstanceIdentifier'](_0x179242),_0xd36d9=this['onInitCallbacks']['get'](_0x517d17)??new Set();_0xd36d9['add'](_0x1cb359),this['onInitCallbacks']['set'](_0x517d17,_0xd36d9);const _0x55d62b=this['instances']['get'](_0x517d17);return _0x55d62b&&_0x1cb359(_0x55d62b,_0x517d17),()=>{_0xd36d9['delete'](_0x1cb359);};}['invokeOnInitCallbacks'](_0x541b51,_0x33a9c2){const _0x1c7d91=this['onInitCallbacks']['get'](_0x33a9c2);if(_0x1c7d91){for(const _0x2fdb53 of _0x1c7d91)try{_0x2fdb53(_0x541b51,_0x33a9c2);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x4f8c7d,options:_0x354d5d={}}){let _0x4e5ec2=this['instances']['get'](_0x4f8c7d);if(!_0x4e5ec2&&this['component']&&(_0x4e5ec2=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x4f8c7d),'options':_0x354d5d}),this['instances']['set'](_0x4f8c7d,_0x4e5ec2),this['instancesOptions']['set'](_0x4f8c7d,_0x354d5d),this['invokeOnInitCallbacks'](_0x4e5ec2,_0x4f8c7d),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x4f8c7d,_0x4e5ec2);}catch{}return _0x4e5ec2||null;}['normalizeInstanceIdentifier'](_0x47d695=Ne){return this['component']?this['component']['multipleInstances']?_0x47d695:Ne:_0x47d695;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x3d62c9){return _0x3d62c9===Ne?void 0x0:_0x3d62c9;}function Nc(_0x3f96bd){return _0x3f96bd['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x18f69a){this['name']=_0x18f69a,this['providers']=new Map();}['addComponent'](_0x19381a){const _0x29bab4=this['getProvider'](_0x19381a['name']);if(_0x29bab4['isComponentSet']())throw new Error('Component\x20'+_0x19381a['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x29bab4['setComponent'](_0x19381a);}['addOrOverwriteComponent'](_0x249057){this['getProvider'](_0x249057['name'])['isComponentSet']()&&this['providers']['delete'](_0x249057['name']),this['addComponent'](_0x249057);}['getProvider'](_0x131abc){if(this['providers']['has'](_0x131abc))return this['providers']['get'](_0x131abc);const _0x55e0ef=new Ac(_0x131abc,this);return this['providers']['set'](_0x131abc,_0x55e0ef),_0x55e0ef;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x2331bc){_0x2331bc[_0x2331bc['DEBUG']=0x0]='DEBUG',_0x2331bc[_0x2331bc['VERBOSE']=0x1]='VERBOSE',_0x2331bc[_0x2331bc['INFO']=0x2]='INFO',_0x2331bc[_0x2331bc['WARN']=0x3]='WARN',_0x2331bc[_0x2331bc['ERROR']=0x4]='ERROR',_0x2331bc[_0x2331bc['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x115431,_0x3871f3,..._0x10c58f)=>{if(_0x3871f3<_0x115431['logLevel'])return;const _0x4587d1=new Date()['toISOString'](),_0x1c076c=Mc[_0x3871f3];if(_0x1c076c)console[_0x1c076c]('['+_0x4587d1+']\x20\x20'+_0x115431['name']+':',..._0x10c58f);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x3871f3+')');};class Ui{constructor(_0x104933){this['name']=_0x104933,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x40c1d9){if(!(_0x40c1d9 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x40c1d9+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x40c1d9;}['setLogLevel'](_0x2140ed){this['_logLevel']=typeof _0x2140ed=='string'?Oc[_0x2140ed]:_0x2140ed;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x4471c5){if(typeof _0x4471c5!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x4471c5;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x4ff788){this['_userLogHandler']=_0x4ff788;}['debug'](..._0x167674){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x167674),this['_logHandler'](this,T['DEBUG'],..._0x167674);}['log'](..._0x1b63ec){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x1b63ec),this['_logHandler'](this,T['VERBOSE'],..._0x1b63ec);}['info'](..._0x527d01){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x527d01),this['_logHandler'](this,T['INFO'],..._0x527d01);}['warn'](..._0x5af1a5){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x5af1a5),this['_logHandler'](this,T['WARN'],..._0x5af1a5);}['error'](..._0x53aad6){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x53aad6),this['_logHandler'](this,T['ERROR'],..._0x53aad6);}}const xc=(_0x56888f,_0x1c55aa)=>_0x1c55aa['some'](_0x4ad0a6=>_0x56888f instanceof _0x4ad0a6);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x5c7641){const _0x4d6209=new Promise((_0x1e0d03,_0x2f88ef)=>{const _0x57f0de=()=>{_0x5c7641['removeEventListener']('success',_0x499e10),_0x5c7641['removeEventListener']('error',_0x144996);},_0x499e10=()=>{_0x1e0d03(_e(_0x5c7641['result'])),_0x57f0de();},_0x144996=()=>{_0x2f88ef(_0x5c7641['error']),_0x57f0de();};_0x5c7641['addEventListener']('success',_0x499e10),_0x5c7641['addEventListener']('error',_0x144996);});return _0x4d6209['then'](_0x19a77a=>{_0x19a77a instanceof IDBCursor&&Jr['set'](_0x19a77a,_0x5c7641);})['catch'](()=>{}),Wi['set'](_0x4d6209,_0x5c7641),_0x4d6209;}function Bc(_0x4aaaaf){if(di['has'](_0x4aaaaf))return;const _0x3edf8b=new Promise((_0x17f980,_0x563fa4)=>{const _0x2a5077=()=>{_0x4aaaaf['removeEventListener']('complete',_0x1f7ab8),_0x4aaaaf['removeEventListener']('error',_0x1a7fce),_0x4aaaaf['removeEventListener']('abort',_0x1a7fce);},_0x1f7ab8=()=>{_0x17f980(),_0x2a5077();},_0x1a7fce=()=>{_0x563fa4(_0x4aaaaf['error']||new DOMException('AbortError','AbortError')),_0x2a5077();};_0x4aaaaf['addEventListener']('complete',_0x1f7ab8),_0x4aaaaf['addEventListener']('error',_0x1a7fce),_0x4aaaaf['addEventListener']('abort',_0x1a7fce);});di['set'](_0x4aaaaf,_0x3edf8b);}let fi={'get'(_0x49eaed,_0x1343b8,_0x3e6951){if(_0x49eaed instanceof IDBTransaction){if(_0x1343b8==='done')return di['get'](_0x49eaed);if(_0x1343b8==='objectStoreNames')return _0x49eaed['objectStoreNames']||Xr['get'](_0x49eaed);if(_0x1343b8==='store')return _0x3e6951['objectStoreNames'][0x1]?void 0x0:_0x3e6951['objectStore'](_0x3e6951['objectStoreNames'][0x0]);}return _e(_0x49eaed[_0x1343b8]);},'set'(_0x296969,_0x4ce72d,_0x3771fe){return _0x296969[_0x4ce72d]=_0x3771fe,!0x0;},'has'(_0x4b5652,_0x35cee5){return _0x4b5652 instanceof IDBTransaction&&(_0x35cee5==='done'||_0x35cee5==='store')?!0x0:_0x35cee5 in _0x4b5652;}};function Vc(_0x5e0aa0){fi=_0x5e0aa0(fi);}function Hc(_0x14a030){return _0x14a030===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x206ffb,..._0x2d9ead){const _0x18d0cd=_0x14a030['call'](Zn(this),_0x206ffb,..._0x2d9ead);return Xr['set'](_0x18d0cd,_0x206ffb['sort']?_0x206ffb['sort']():[_0x206ffb]),_e(_0x18d0cd);}:Uc()['includes'](_0x14a030)?function(..._0x4b8f68){return _0x14a030['apply'](Zn(this),_0x4b8f68),_e(Jr['get'](this));}:function(..._0x1d7afc){return _e(_0x14a030['apply'](Zn(this),_0x1d7afc));};}function $c(_0x538dcf){return typeof _0x538dcf=='function'?Hc(_0x538dcf):(_0x538dcf instanceof IDBTransaction&&Bc(_0x538dcf),xc(_0x538dcf,Fc())?new Proxy(_0x538dcf,fi):_0x538dcf);}function _e(_0x4c4c7d){if(_0x4c4c7d instanceof IDBRequest)return Wc(_0x4c4c7d);if(Xn['has'](_0x4c4c7d))return Xn['get'](_0x4c4c7d);const _0x522e77=$c(_0x4c4c7d);return _0x522e77!==_0x4c4c7d&&(Xn['set'](_0x4c4c7d,_0x522e77),Wi['set'](_0x522e77,_0x4c4c7d)),_0x522e77;}const Zn=_0x407166=>Wi['get'](_0x407166);function Gc(_0xeb45bc,_0x8dc064,{blocked:_0x71e776,upgrade:_0x2335ed,blocking:_0x1a70c2,terminated:_0x30612d}={}){const _0x2ee420=indexedDB['open'](_0xeb45bc,_0x8dc064),_0xf557c1=_e(_0x2ee420);return _0x2335ed&&_0x2ee420['addEventListener']('upgradeneeded',_0x2d8fe2=>{_0x2335ed(_e(_0x2ee420['result']),_0x2d8fe2['oldVersion'],_0x2d8fe2['newVersion'],_e(_0x2ee420['transaction']),_0x2d8fe2);}),_0x71e776&&_0x2ee420['addEventListener']('blocked',_0x33f4ed=>_0x71e776(_0x33f4ed['oldVersion'],_0x33f4ed['newVersion'],_0x33f4ed)),_0xf557c1['then'](_0x753e58=>{_0x30612d&&_0x753e58['addEventListener']('close',()=>_0x30612d()),_0x1a70c2&&_0x753e58['addEventListener']('versionchange',_0x18ae32=>_0x1a70c2(_0x18ae32['oldVersion'],_0x18ae32['newVersion'],_0x18ae32));})['catch'](()=>{}),_0xf557c1;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x55e3ad,_0xe65ef3){if(!(_0x55e3ad instanceof IDBDatabase&&!(_0xe65ef3 in _0x55e3ad)&&typeof _0xe65ef3=='string'))return;if(ei['get'](_0xe65ef3))return ei['get'](_0xe65ef3);const _0x29bd8f=_0xe65ef3['replace'](/FromIndex$/,''),_0x1e696a=_0xe65ef3!==_0x29bd8f,_0x1a54fc=zc['includes'](_0x29bd8f);if(!(_0x29bd8f in(_0x1e696a?IDBIndex:IDBObjectStore)['prototype'])||!(_0x1a54fc||qc['includes'](_0x29bd8f)))return;const _0x49d672=async function(_0x7a0229,..._0x3b079d){const _0x29a1f5=this['transaction'](_0x7a0229,_0x1a54fc?'readwrite':'readonly');let _0x5d0381=_0x29a1f5['store'];return _0x1e696a&&(_0x5d0381=_0x5d0381['index'](_0x3b079d['shift']())),(await Promise['all']([_0x5d0381[_0x29bd8f](..._0x3b079d),_0x1a54fc&&_0x29a1f5['done']]))[0x0];};return ei['set'](_0xe65ef3,_0x49d672),_0x49d672;}Vc(_0x13509a=>({..._0x13509a,'get':(_0xdf577f,_0x53118d,_0x29ca3a)=>Ls(_0xdf577f,_0x53118d)||_0x13509a['get'](_0xdf577f,_0x53118d,_0x29ca3a),'has':(_0x320a8a,_0xdc3a1d)=>!!Ls(_0x320a8a,_0xdc3a1d)||_0x13509a['has'](_0x320a8a,_0xdc3a1d)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0xce7fbe){this['container']=_0xce7fbe;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x566c14=>{if(Kc(_0x566c14)){const _0x16f086=_0x566c14['getImmediate']();return _0x16f086['library']+'/'+_0x16f086['version'];}else return null;})['filter'](_0x449819=>_0x449819)['join']('\x20');}}function Kc(_0x21111f){const _0x243513=_0x21111f['getComponent']();return(_0x243513==null?void 0x0:_0x243513['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x30fa2d,_0x4bc2a4){try{_0x30fa2d['container']['addComponent'](_0x4bc2a4);}catch(_0x11188e){oe['debug']('Component\x20'+_0x4bc2a4['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x30fa2d['name'],_0x11188e);}}function Ze(_0x107946){const _0x17f317=_0x107946['name'];if(mi['has'](_0x17f317))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x17f317+'.'),!0x1;mi['set'](_0x17f317,_0x107946);for(const _0x2c7cdc of xe['values']())Fs(_0x2c7cdc,_0x107946);for(const _0x5d9ef2 of gi['values']())Fs(_0x5d9ef2,_0x107946);return!0x0;}function Bi(_0xee09b9,_0x586b5b){const _0x4b7467=_0xee09b9['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x4b7467&&_0x4b7467['triggerHeartbeat'](),_0xee09b9['container']['getProvider'](_0x586b5b);}function $(_0x3e6cee){return _0x3e6cee==null?!0x1:_0x3e6cee['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x314ef3,_0x410647,_0x10476e){this['_isDeleted']=!0x1,this['_options']={..._0x314ef3},this['_config']={..._0x410647},this['_name']=_0x410647['name'],this['_automaticDataCollectionEnabled']=_0x410647['automaticDataCollectionEnabled'],this['_container']=_0x10476e,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x3aef1c){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x3aef1c;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x40d22a){this['_isDeleted']=_0x40d22a;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x565d73,_0x6e7141={}){let _0x8ef6ec=_0x565d73;typeof _0x6e7141!='object'&&(_0x6e7141={'name':_0x6e7141});const _0x1ed53f={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x6e7141},_0x143457=_0x1ed53f['name'];if(typeof _0x143457!='string'||!_0x143457)throw ge['create']('bad-app-name',{'appName':String(_0x143457)});if(_0x8ef6ec||(_0x8ef6ec=qr()),!_0x8ef6ec)throw ge['create']('no-options');const _0x2a86cc=xe['get'](_0x143457);if(_0x2a86cc){if(Me(_0x8ef6ec,_0x2a86cc['options'])&&Me(_0x1ed53f,_0x2a86cc['config']))return _0x2a86cc;throw ge['create']('duplicate-app',{'appName':_0x143457});}const _0x416508=new Pc(_0x143457);for(const _0x1ff774 of mi['values']())_0x416508['addComponent'](_0x1ff774);const _0x5f18cb=new Tl(_0x8ef6ec,_0x1ed53f,_0x416508);return xe['set'](_0x143457,_0x5f18cb),_0x5f18cb;}function Zr(_0x12ae6e=_i){const _0x25229b=xe['get'](_0x12ae6e);if(!_0x25229b&&_0x12ae6e===_i&&qr())return Sl();if(!_0x25229b)throw ge['create']('no-app',{'appName':_0x12ae6e});return _0x25229b;}function f_(){return Array['from'](xe['values']());}async function p_(_0xb151f){let _0xf184bd=!0x1;const _0x12cf11=_0xb151f['name'];xe['has'](_0x12cf11)?(_0xf184bd=!0x0,xe['delete'](_0x12cf11)):gi['has'](_0x12cf11)&&_0xb151f['decRefCount']()<=0x0&&(gi['delete'](_0x12cf11),_0xf184bd=!0x0),_0xf184bd&&(await Promise['all'](_0xb151f['container']['getProviders']()['map'](_0x4bb049=>_0x4bb049['delete']())),_0xb151f['isDeleted']=!0x0);}function me(_0x4c414a,_0x498a7f,_0x5c9ec2){let _0x24e850=wl[_0x4c414a]??_0x4c414a;_0x5c9ec2&&(_0x24e850+='-'+_0x5c9ec2);const _0x5439ba=_0x24e850['match'](/\s|\//),_0xfecb4e=_0x498a7f['match'](/\s|\//);if(_0x5439ba||_0xfecb4e){const _0x1283ff=['Unable\x20to\x20register\x20library\x20\x22'+_0x24e850+'\x22\x20with\x20version\x20\x22'+_0x498a7f+'\x22:'];_0x5439ba&&_0x1283ff['push']('library\x20name\x20\x22'+_0x24e850+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x5439ba&&_0xfecb4e&&_0x1283ff['push']('and'),_0xfecb4e&&_0x1283ff['push']('version\x20name\x20\x22'+_0x498a7f+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x1283ff['join']('\x20'));return;}Ze(new Le(_0x24e850+'-version',()=>({'library':_0x24e850,'version':_0x498a7f}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x264766,_0x47c1c2)=>{switch(_0x47c1c2){case 0x0:try{_0x264766['createObjectStore'](kt);}catch(_0x4b3e9e){console['warn'](_0x4b3e9e);}}}})['catch'](_0x221c34=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x221c34['message']});})),ti;}async function Al(_0x2c89f5){try{const _0x1ac2ae=(await eo())['transaction'](kt),_0x504632=await _0x1ac2ae['objectStore'](kt)['get'](to(_0x2c89f5));return await _0x1ac2ae['done'],_0x504632;}catch(_0x17c6ff){if(_0x17c6ff instanceof Se)oe['warn'](_0x17c6ff['message']);else{const _0x3727b1=ge['create']('idb-get',{'originalErrorMessage':_0x17c6ff==null?void 0x0:_0x17c6ff['message']});oe['warn'](_0x3727b1['message']);}}}async function Us(_0x114b3a,_0x182d1b){try{const _0x1537c7=(await eo())['transaction'](kt,'readwrite');await _0x1537c7['objectStore'](kt)['put'](_0x182d1b,to(_0x114b3a)),await _0x1537c7['done'];}catch(_0x492e73){if(_0x492e73 instanceof Se)oe['warn'](_0x492e73['message']);else{const _0x78f284=ge['create']('idb-set',{'originalErrorMessage':_0x492e73==null?void 0x0:_0x492e73['message']});oe['warn'](_0x78f284['message']);}}}function to(_0x3e5630){return _0x3e5630['name']+'!'+_0x3e5630['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x586836){this['container']=_0x586836,this['_heartbeatsCache']=null;const _0x5c7202=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x5c7202),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x151fe8=>(this['_heartbeatsCache']=_0x151fe8,_0x151fe8));}async['triggerHeartbeat'](){var _0x14858e,_0x4129ca;try{const _0x122314=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x503c13=Ws();if(((_0x14858e=this['_heartbeatsCache'])==null?void 0x0:_0x14858e['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x4129ca=this['_heartbeatsCache'])==null?void 0x0:_0x4129ca['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x503c13||this['_heartbeatsCache']['heartbeats']['some'](_0x44b236=>_0x44b236['date']===_0x503c13))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x503c13,'agent':_0x122314}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x2294a7=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x2294a7,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0xb2acb7){oe['warn'](_0xb2acb7);}}async['getHeartbeatsHeader'](){var _0x7e422b;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x7e422b=this['_heartbeatsCache'])==null?void 0x0:_0x7e422b['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x11070b=Ws(),{heartbeatsToSend:_0x41e4e1,unsentEntries:_0x2d8b35}=Ol(this['_heartbeatsCache']['heartbeats']),_0x263363=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x41e4e1}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x11070b,_0x2d8b35['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x2d8b35,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x263363;}catch(_0xe46e6){return oe['warn'](_0xe46e6),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x4ab4d3,_0x493213=kl){const _0x540d56=[];let _0x5795ab=_0x4ab4d3['slice']();for(const _0x12f8d3 of _0x4ab4d3){const _0xd5623f=_0x540d56['find'](_0x33c9c4=>_0x33c9c4['agent']===_0x12f8d3['agent']);if(_0xd5623f){if(_0xd5623f['dates']['push'](_0x12f8d3['date']),Bs(_0x540d56)>_0x493213){_0xd5623f['dates']['pop']();break;}}else{if(_0x540d56['push']({'agent':_0x12f8d3['agent'],'dates':[_0x12f8d3['date']]}),Bs(_0x540d56)>_0x493213){_0x540d56['pop']();break;}}_0x5795ab=_0x5795ab['slice'](0x1);}return{'heartbeatsToSend':_0x540d56,'unsentEntries':_0x5795ab};}class Dl{constructor(_0x34daa1){this['app']=_0x34daa1,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x2cecae=await Al(this['app']);return _0x2cecae!=null&&_0x2cecae['heartbeats']?_0x2cecae:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x1de179){if(await this['_canUseIndexedDBPromise']){const _0x36fb3f=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x1de179['lastSentHeartbeatDate']??_0x36fb3f['lastSentHeartbeatDate'],'heartbeats':_0x1de179['heartbeats']});}else return;}async['add'](_0x9a88e5){if(await this['_canUseIndexedDBPromise']){const _0x500c06=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x9a88e5['lastSentHeartbeatDate']??_0x500c06['lastSentHeartbeatDate'],'heartbeats':[..._0x500c06['heartbeats'],..._0x9a88e5['heartbeats']]});}else return;}}function Bs(_0x21bc11){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x21bc11}))['length'];}function Ml(_0x49c75d){if(_0x49c75d['length']===0x0)return-0x1;let _0x5553df=0x0,_0x325b4b=_0x49c75d[0x0]['date'];for(let _0x5655c8=0x1;_0x5655c8<_0x49c75d['length'];_0x5655c8++)_0x49c75d[_0x5655c8]['date']<_0x325b4b&&(_0x325b4b=_0x49c75d[_0x5655c8]['date'],_0x5553df=_0x5655c8);return _0x5553df;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x4fcd49){Ze(new Le('platform-logger',_0x38be72=>new jc(_0x38be72),'PRIVATE')),Ze(new Le('heartbeat',_0x3c4ce0=>new Pl(_0x3c4ce0),'PRIVATE')),me(pi,xs,_0x4fcd49),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0xc853ed){no=_0xc853ed;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x466610){this['domStorage_']=_0x466610,this['prefix_']='firebase:';}['set'](_0x759d44,_0x508ead){_0x508ead==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x759d44)):this['domStorage_']['setItem'](this['prefixedName_'](_0x759d44),O(_0x508ead));}['get'](_0x27d99d){const _0x3131a2=this['domStorage_']['getItem'](this['prefixedName_'](_0x27d99d));return _0x3131a2==null?null:At(_0x3131a2);}['remove'](_0x5000c2){this['domStorage_']['removeItem'](this['prefixedName_'](_0x5000c2));}['prefixedName_'](_0x3f150c){return this['prefix_']+_0x3f150c;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x5ec449,_0x577603){_0x577603==null?delete this['cache_'][_0x5ec449]:this['cache_'][_0x5ec449]=_0x577603;}['get'](_0x5d2a6e){return J(this['cache_'],_0x5d2a6e)?this['cache_'][_0x5d2a6e]:null;}['remove'](_0x2c33d3){delete this['cache_'][_0x2c33d3];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x132b95){try{if(typeof window<'u'&&typeof window[_0x132b95]<'u'){const _0x1a5104=window[_0x132b95];return _0x1a5104['setItem']('firebase:sentinel','cache'),_0x1a5104['removeItem']('firebase:sentinel'),new Wl(_0x1a5104);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x10d005=0x1;return function(){return _0x10d005++;};}()),ro=function(_0xac730a){const _0x4097a7=Rc(_0xac730a),_0x293619=new Cc();_0x293619['update'](_0x4097a7);const _0x1648c6=_0x293619['digest']();return Li['encodeByteArray'](_0x1648c6);},Vt=function(..._0x36c99e){let _0x3f6718='';for(let _0x643ea6=0x0;_0x643ea6<_0x36c99e['length'];_0x643ea6++){const _0x18c9ed=_0x36c99e[_0x643ea6];Array['isArray'](_0x18c9ed)||_0x18c9ed&&typeof _0x18c9ed=='object'&&typeof _0x18c9ed['length']=='number'?_0x3f6718+=Vt['apply'](null,_0x18c9ed):typeof _0x18c9ed=='object'?_0x3f6718+=O(_0x18c9ed):_0x3f6718+=_0x18c9ed,_0x3f6718+='\x20';}return _0x3f6718;};let wt=null,Gs=!0x0;const Hl=function(_0x3507cf,_0x19c6ec){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x39092a){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0xcb62f5=Vt['apply'](null,_0x39092a);wt(_0xcb62f5);}},Ht=function(_0x265a88){return function(..._0x27000e){L(_0x265a88,..._0x27000e);};},yi=function(..._0x572d3d){const _0x33d20f='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x572d3d);Ye['error'](_0x33d20f);},ae=function(..._0x3c4914){const _0x1cda0d='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x3c4914);throw Ye['error'](_0x1cda0d),new Error(_0x1cda0d);},U=function(..._0x475c1c){const _0x57803c='FIREBASE\x20WARNING:\x20'+Vt(..._0x475c1c);Ye['warn'](_0x57803c);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x4b8d06){return typeof _0x4b8d06=='number'&&(_0x4b8d06!==_0x4b8d06||_0x4b8d06===Number['POSITIVE_INFINITY']||_0x4b8d06===Number['NEGATIVE_INFINITY']);},Gl=function(_0x55ab71){if(document['readyState']==='complete')_0x55ab71();else{let _0xf47ae1=!0x1;const _0x2ba59d=function(){if(!document['body']){setTimeout(_0x2ba59d,Math['floor'](0xa));return;}_0xf47ae1||(_0xf47ae1=!0x0,_0x55ab71());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x2ba59d,!0x1),window['addEventListener']('load',_0x2ba59d,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x2ba59d();}),window['attachEvent']('onload',_0x2ba59d));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x8a925f,_0x11416e){if(_0x8a925f===_0x11416e)return 0x0;if(_0x8a925f===Fe||_0x11416e===Ie)return-0x1;if(_0x11416e===Fe||_0x8a925f===Ie)return 0x1;{const _0x1f3ba4=qs(_0x8a925f),_0xf00f27=qs(_0x11416e);return _0x1f3ba4!==null?_0xf00f27!==null?_0x1f3ba4-_0xf00f27===0x0?_0x8a925f['length']-_0x11416e['length']:_0x1f3ba4-_0xf00f27:-0x1:_0xf00f27!==null?0x1:_0x8a925f<_0x11416e?-0x1:0x1;}},ql=function(_0x412aab,_0x542749){return _0x412aab===_0x542749?0x0:_0x412aab<_0x542749?-0x1:0x1;},_t=function(_0x54cd56,_0x1c6b4a){if(_0x1c6b4a&&_0x54cd56 in _0x1c6b4a)return _0x1c6b4a[_0x54cd56];throw new Error('Missing\x20required\x20key\x20('+_0x54cd56+')\x20in\x20object:\x20'+O(_0x1c6b4a));},Hi=function(_0x6eb207){if(typeof _0x6eb207!='object'||_0x6eb207===null)return O(_0x6eb207);const _0x2b4e25=[];for(const _0xa61ad4 in _0x6eb207)_0x2b4e25['push'](_0xa61ad4);_0x2b4e25['sort']();let _0x2feda8='{';for(let _0x2a6ec9=0x0;_0x2a6ec9<_0x2b4e25['length'];_0x2a6ec9++)_0x2a6ec9!==0x0&&(_0x2feda8+=','),_0x2feda8+=O(_0x2b4e25[_0x2a6ec9]),_0x2feda8+=':',_0x2feda8+=Hi(_0x6eb207[_0x2b4e25[_0x2a6ec9]]);return _0x2feda8+='}',_0x2feda8;},oo=function(_0xd27ff7,_0x5e86a8){const _0x377dec=_0xd27ff7['length'];if(_0x377dec<=_0x5e86a8)return[_0xd27ff7];const _0xc9f001=[];for(let _0x425546=0x0;_0x425546<_0x377dec;_0x425546+=_0x5e86a8)_0x425546+_0x5e86a8>_0x377dec?_0xc9f001['push'](_0xd27ff7['substring'](_0x425546,_0x377dec)):_0xc9f001['push'](_0xd27ff7['substring'](_0x425546,_0x425546+_0x5e86a8));return _0xc9f001;};function x(_0x37b323,_0x30f975){for(const _0x1ae17e in _0x37b323)_0x37b323['hasOwnProperty'](_0x1ae17e)&&_0x30f975(_0x1ae17e,_0x37b323[_0x1ae17e]);}const ao=function(_0x5965de){f(!Vi(_0x5965de),'Invalid\x20JSON\x20number');const _0x1ae5a5=0xb,_0x5d5f0e=0x34,_0xe10e71=(0x1<<_0x1ae5a5-0x1)-0x1;let _0x2c3ded,_0x120d2d,_0x496af2,_0x2e190f,_0x398bd7;_0x5965de===0x0?(_0x120d2d=0x0,_0x496af2=0x0,_0x2c3ded=0x1/_0x5965de===-0x1/0x0?0x1:0x0):(_0x2c3ded=_0x5965de<0x0,_0x5965de=Math['abs'](_0x5965de),_0x5965de>=Math['pow'](0x2,0x1-_0xe10e71)?(_0x2e190f=Math['min'](Math['floor'](Math['log'](_0x5965de)/Math['LN2']),_0xe10e71),_0x120d2d=_0x2e190f+_0xe10e71,_0x496af2=Math['round'](_0x5965de*Math['pow'](0x2,_0x5d5f0e-_0x2e190f)-Math['pow'](0x2,_0x5d5f0e))):(_0x120d2d=0x0,_0x496af2=Math['round'](_0x5965de/Math['pow'](0x2,0x1-_0xe10e71-_0x5d5f0e))));const _0x3cf514=[];for(_0x398bd7=_0x5d5f0e;_0x398bd7;_0x398bd7-=0x1)_0x3cf514['push'](_0x496af2%0x2?0x1:0x0),_0x496af2=Math['floor'](_0x496af2/0x2);for(_0x398bd7=_0x1ae5a5;_0x398bd7;_0x398bd7-=0x1)_0x3cf514['push'](_0x120d2d%0x2?0x1:0x0),_0x120d2d=Math['floor'](_0x120d2d/0x2);_0x3cf514['push'](_0x2c3ded?0x1:0x0),_0x3cf514['reverse']();const _0xae2dca=_0x3cf514['join']('');let _0x4d1d32='';for(_0x398bd7=0x0;_0x398bd7<0x40;_0x398bd7+=0x8){let _0xbcdcc8=parseInt(_0xae2dca['substr'](_0x398bd7,0x8),0x2)['toString'](0x10);_0xbcdcc8['length']===0x1&&(_0xbcdcc8='0'+_0xbcdcc8),_0x4d1d32=_0x4d1d32+_0xbcdcc8;}return _0x4d1d32['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x2ee0df,_0x47e5e7){let _0x3b122b='Unknown\x20Error';_0x2ee0df==='too_big'?_0x3b122b='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x2ee0df==='permission_denied'?_0x3b122b='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x2ee0df==='unavailable'&&(_0x3b122b='The\x20service\x20is\x20unavailable');const _0x9e73e4=new Error(_0x2ee0df+'\x20at\x20'+_0x47e5e7['_path']['toString']()+':\x20'+_0x3b122b);return _0x9e73e4['code']=_0x2ee0df['toUpperCase'](),_0x9e73e4;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x303723){if(Yl['test'](_0x303723)){const _0x7059e2=Number(_0x303723);if(_0x7059e2>=Ql&&_0x7059e2<=Jl)return _0x7059e2;}return null;},ht=function(_0x21434e){try{_0x21434e();}catch(_0x54b97c){setTimeout(()=>{const _0x9ea2e=_0x54b97c['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x9ea2e),_0x54b97c;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x1270d2,_0x30df42){const _0x58ccc7=setTimeout(_0x1270d2,_0x30df42);return typeof _0x58ccc7=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x58ccc7):typeof _0x58ccc7=='object'&&_0x58ccc7['unref']&&_0x58ccc7['unref'](),_0x58ccc7;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x562cd1,_0x4cc9f5){this['appCheckProvider']=_0x4cc9f5,this['appName']=_0x562cd1['name'],$(_0x562cd1)&&_0x562cd1['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x562cd1['settings']['appCheckToken']),this['appCheck']=_0x4cc9f5==null?void 0x0:_0x4cc9f5['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4cc9f5==null||_0x4cc9f5['get']()['then'](_0x4969d6=>this['appCheck']=_0x4969d6);}['getToken'](_0x90de){if(this['serverAppAppCheckToken']){if(_0x90de)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x90de):new Promise((_0x4595df,_0x4c2e0d)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x90de)['then'](_0x4595df,_0x4c2e0d):_0x4595df(null);},0x0);});}['addTokenChangeListener'](_0x109cd6){var _0x4be413;(_0x4be413=this['appCheckProvider'])==null||_0x4be413['get']()['then'](_0x1d068c=>_0x1d068c['addTokenListener'](_0x109cd6));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x5b28fb,_0x2c69dd,_0x2c53ae){this['appName_']=_0x5b28fb,this['firebaseOptions_']=_0x2c69dd,this['authProvider_']=_0x2c53ae,this['auth_']=null,this['auth_']=_0x2c53ae['getImmediate']({'optional':!0x0}),this['auth_']||_0x2c53ae['onInit'](_0x1cc68e=>this['auth_']=_0x1cc68e);}['getToken'](_0x5c7cb9){return this['auth_']?this['auth_']['getToken'](_0x5c7cb9)['catch'](_0x5600f8=>_0x5600f8&&_0x5600f8['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x5600f8)):new Promise((_0x323f50,_0x51f06a)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x5c7cb9)['then'](_0x323f50,_0x51f06a):_0x323f50(null);},0x0);});}['addTokenChangeListener'](_0x2e453d){this['auth_']?this['auth_']['addAuthTokenListener'](_0x2e453d):this['authProvider_']['get']()['then'](_0x1fd5ba=>_0x1fd5ba['addAuthTokenListener'](_0x2e453d));}['removeTokenChangeListener'](_0x5f0d86){this['authProvider_']['get']()['then'](_0x550852=>_0x550852['removeAuthTokenListener'](_0x5f0d86));}['notifyForInvalidToken'](){let _0x29402f='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x29402f+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x29402f+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x29402f+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x29402f);}}class nn{constructor(_0x1522ad){this['accessToken']=_0x1522ad;}['getToken'](_0x1b9078){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x264cc3){_0x264cc3(this['accessToken']);}['removeTokenChangeListener'](_0x2a42c1){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x34cf7f,_0x56fe06,_0x2f1852,_0x46b881,_0x4cdf67=!0x1,_0x5d808b='',_0x1cc28a=!0x1,_0x41fcf4=!0x1,_0x362d9b=null){this['secure']=_0x56fe06,this['namespace']=_0x2f1852,this['webSocketOnly']=_0x46b881,this['nodeAdmin']=_0x4cdf67,this['persistenceKey']=_0x5d808b,this['includeNamespaceInQueryParams']=_0x1cc28a,this['isUsingEmulator']=_0x41fcf4,this['emulatorOptions']=_0x362d9b,this['_host']=_0x34cf7f['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x34cf7f)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x32852e){_0x32852e!==this['internalHost']&&(this['internalHost']=_0x32852e,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x1caa12=this['toURLString']();return this['persistenceKey']&&(_0x1caa12+='<'+this['persistenceKey']+'>'),_0x1caa12;}['toURLString'](){const _0x380b21=this['secure']?'https://':'http://',_0xf6c51e=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x380b21+this['host']+'/'+_0xf6c51e;}}function th(_0x560dee){return _0x560dee['host']!==_0x560dee['internalHost']||_0x560dee['isCustomHost']()||_0x560dee['includeNamespaceInQueryParams'];}function vo(_0x1ad1f4,_0x3d9360,_0x3545bf){f(typeof _0x3d9360=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x3545bf=='object','typeof\x20params\x20must\x20==\x20object');let _0x1bfe27;if(_0x3d9360===go)_0x1bfe27=(_0x1ad1f4['secure']?'wss://':'ws://')+_0x1ad1f4['internalHost']+'/.ws?';else{if(_0x3d9360===mo)_0x1bfe27=(_0x1ad1f4['secure']?'https://':'http://')+_0x1ad1f4['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x3d9360);}th(_0x1ad1f4)&&(_0x3545bf['ns']=_0x1ad1f4['namespace']);const _0x378315=[];return x(_0x3545bf,(_0x1baabd,_0x1f1df6)=>{_0x378315['push'](_0x1baabd+'='+_0x1f1df6);}),_0x1bfe27+_0x378315['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x2b1abc,_0x4e70fb=0x1){J(this['counters_'],_0x2b1abc)||(this['counters_'][_0x2b1abc]=0x0),this['counters_'][_0x2b1abc]+=_0x4e70fb;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x4284f8){const _0x28f8f7=_0x4284f8['toString']();return ni[_0x28f8f7]||(ni[_0x28f8f7]=new nh()),ni[_0x28f8f7];}function ih(_0x58310e,_0x30819c){const _0x227cf6=_0x58310e['toString']();return ii[_0x227cf6]||(ii[_0x227cf6]=_0x30819c()),ii[_0x227cf6];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x38bfea){this['onMessage_']=_0x38bfea,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x330cac,_0x5dbf09){this['closeAfterResponse']=_0x330cac,this['onClose']=_0x5dbf09,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0xf2fe1c,_0x1e9224){for(this['pendingResponses'][_0xf2fe1c]=_0x1e9224;this['pendingResponses'][this['currentResponseNum']];){const _0x4289a6=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x358139=0x0;_0x358139<_0x4289a6['length'];++_0x358139)_0x4289a6[_0x358139]&&ht(()=>{this['onMessage_'](_0x4289a6[_0x358139]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x2d3304,_0x255d91,_0x4c4f4c,_0x53c1c6,_0x23bd86,_0x46a649,_0x10919a){this['connId']=_0x2d3304,this['repoInfo']=_0x255d91,this['applicationId']=_0x4c4f4c,this['appCheckToken']=_0x53c1c6,this['authToken']=_0x23bd86,this['transportSessionId']=_0x46a649,this['lastSessionId']=_0x10919a,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x2d3304),this['stats_']=Gi(_0x255d91),this['urlFn']=_0x2bd4a3=>(this['appCheckToken']&&(_0x2bd4a3[vi]=this['appCheckToken']),vo(_0x255d91,mo,_0x2bd4a3));}['open'](_0x48c9f3,_0x4baa96){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x4baa96,this['myPacketOrderer']=new sh(_0x48c9f3),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0xb8aeb9)=>{const [_0xdfa315,_0x5b668a,_0x38515f,_0x21d699,_0x2f3486]=_0xb8aeb9;if(this['incrementIncomingBytes_'](_0xb8aeb9),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0xdfa315===zs)this['id']=_0x5b668a,this['password']=_0x38515f;else{if(_0xdfa315===rh)_0x5b668a?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x5b668a,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0xdfa315);}}},(..._0xcd5b34)=>{const [_0x24450d,_0x331e30]=_0xcd5b34;this['incrementIncomingBytes_'](_0xcd5b34),this['myPacketOrderer']['handleResponse'](_0x24450d,_0x331e30);},()=>{this['onClosed_']();},this['urlFn']);const _0x1f659d={};_0x1f659d[zs]='t',_0x1f659d[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x1f659d[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x1f659d[co]=$i,this['transportSessionId']&&(_0x1f659d[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x1f659d[po]=this['lastSessionId']),this['applicationId']&&(_0x1f659d[_o]=this['applicationId']),this['appCheckToken']&&(_0x1f659d[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x1f659d[ho]=uo);const _0x1e18c1=this['urlFn'](_0x1f659d);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x1e18c1),this['scriptTagHolder']['addTag'](_0x1e18c1,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x4e6bca){const _0x279517=O(_0x4e6bca);this['bytesSent']+=_0x279517['length'],this['stats_']['incrementCounter']('bytes_sent',_0x279517['length']);const _0x5ed9f7=Hr(_0x279517),_0x5d0c51=oo(_0x5ed9f7,fh);for(let _0x6e8e24=0x0;_0x6e8e24<_0x5d0c51['length'];_0x6e8e24++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x5d0c51['length'],_0x5d0c51[_0x6e8e24]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0xe9d54e,_0x3ed243){this['myDisconnFrame']=document['createElement']('iframe');const _0x5658ce={};_0x5658ce[dh]='t',_0x5658ce[Eo]=_0xe9d54e,_0x5658ce[Io]=_0x3ed243,this['myDisconnFrame']['src']=this['urlFn'](_0x5658ce),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x15676b){const _0x58c2b8=O(_0x15676b)['length'];this['bytesReceived']+=_0x58c2b8,this['stats_']['incrementCounter']('bytes_received',_0x58c2b8);}}class qi{constructor(_0x159748,_0x3fdf88,_0x77f161,_0x5e03b4){this['onDisconnect']=_0x77f161,this['urlFn']=_0x5e03b4,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x159748,window[ah+this['uniqueCallbackIdentifier']]=_0x3fdf88,this['myIFrame']=qi['createIFrame_']();let _0x1fa884='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x1fa884='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x1b3ffe='<html><body>'+_0x1fa884+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x1b3ffe),this['myIFrame']['doc']['close']();}catch(_0x4a79d4){L('frame\x20writing\x20exception'),_0x4a79d4['stack']&&L(_0x4a79d4['stack']),L(_0x4a79d4);}}}static['createIFrame_'](){const _0x4f8d8a=document['createElement']('iframe');if(_0x4f8d8a['style']['display']='none',document['body']){document['body']['appendChild'](_0x4f8d8a);try{_0x4f8d8a['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x3bb527=document['domain'];_0x4f8d8a['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x3bb527+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x4f8d8a['contentDocument']?_0x4f8d8a['doc']=_0x4f8d8a['contentDocument']:_0x4f8d8a['contentWindow']?_0x4f8d8a['doc']=_0x4f8d8a['contentWindow']['document']:_0x4f8d8a['document']&&(_0x4f8d8a['doc']=_0x4f8d8a['document']),_0x4f8d8a;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x282dd2=this['onDisconnect'];_0x282dd2&&(this['onDisconnect']=null,_0x282dd2());}['startLongPoll'](_0x4a85ba,_0x48c2e7){for(this['myID']=_0x4a85ba,this['myPW']=_0x48c2e7,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x364f8e={};_0x364f8e[Eo]=this['myID'],_0x364f8e[Io]=this['myPW'],_0x364f8e[wo]=this['currentSerial'];let _0x4bffa1=this['urlFn'](_0x364f8e),_0xd2893d='',_0xd56f20=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0xd2893d['length']<=Co;){const _0x300439=this['pendingSegs']['shift']();_0xd2893d=_0xd2893d+'&'+lh+_0xd56f20+'='+_0x300439['seg']+'&'+hh+_0xd56f20+'='+_0x300439['ts']+'&'+uh+_0xd56f20+'='+_0x300439['d'],_0xd56f20++;}return _0x4bffa1=_0x4bffa1+_0xd2893d,this['addLongPollTag_'](_0x4bffa1,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x4eb207,_0x2290f1,_0x566121){this['pendingSegs']['push']({'seg':_0x4eb207,'ts':_0x2290f1,'d':_0x566121}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0xfaf293,_0x3d186e){this['outstandingRequests']['add'](_0x3d186e);const _0x4eb14a=()=>{this['outstandingRequests']['delete'](_0x3d186e),this['newRequest_']();},_0x4a40b8=setTimeout(_0x4eb14a,Math['floor'](ph)),_0x4a3bef=()=>{clearTimeout(_0x4a40b8),_0x4eb14a();};this['addTag'](_0xfaf293,_0x4a3bef);}['addTag'](_0x503c52,_0x70276f){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0xd8945b=this['myIFrame']['doc']['createElement']('script');_0xd8945b['type']='text/javascript',_0xd8945b['async']=!0x0,_0xd8945b['src']=_0x503c52,_0xd8945b['onload']=_0xd8945b['onreadystatechange']=function(){const _0xa3be05=_0xd8945b['readyState'];(!_0xa3be05||_0xa3be05==='loaded'||_0xa3be05==='complete')&&(_0xd8945b['onload']=_0xd8945b['onreadystatechange']=null,_0xd8945b['parentNode']&&_0xd8945b['parentNode']['removeChild'](_0xd8945b),_0x70276f());},_0xd8945b['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x503c52),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0xd8945b);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x1f30d2,_0x151603,_0x4157e9,_0xa17800,_0x37c865,_0x18b442,_0x3e4d76){this['connId']=_0x1f30d2,this['applicationId']=_0x4157e9,this['appCheckToken']=_0xa17800,this['authToken']=_0x37c865,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x151603),this['connURL']=z['connectionURL_'](_0x151603,_0x18b442,_0x3e4d76,_0xa17800,_0x4157e9),this['nodeAdmin']=_0x151603['nodeAdmin'];}static['connectionURL_'](_0x1f6ee3,_0x3d804f,_0x3fd14f,_0x44e5ea,_0x5061cf){const _0xce09cb={};return _0xce09cb[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0xce09cb[ho]=uo),_0x3d804f&&(_0xce09cb[lo]=_0x3d804f),_0x3fd14f&&(_0xce09cb[po]=_0x3fd14f),_0x44e5ea&&(_0xce09cb[vi]=_0x44e5ea),_0x5061cf&&(_0xce09cb[_o]=_0x5061cf),vo(_0x1f6ee3,go,_0xce09cb);}['open'](_0x31178b,_0x302efe){this['onDisconnect']=_0x302efe,this['onMessage']=_0x31178b,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0xdde09e;_c(),this['mySock']=new un(this['connURL'],[],_0xdde09e);}catch(_0x5a8eab){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x10455a=_0x5a8eab['message']||_0x5a8eab['data'];_0x10455a&&this['log_'](_0x10455a),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x5e8d5a=>{this['handleIncomingFrame'](_0x5e8d5a);},this['mySock']['onerror']=_0x2f571e=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x1d4c3c=_0x2f571e['message']||_0x2f571e['data'];_0x1d4c3c&&this['log_'](_0x1d4c3c),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x4ade50=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x2f1bae=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x29be27=navigator['userAgent']['match'](_0x2f1bae);_0x29be27&&_0x29be27['length']>0x1&&parseFloat(_0x29be27[0x1])<4.4&&(_0x4ade50=!0x0);}return!_0x4ade50&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x408aff){if(this['frames']['push'](_0x408aff),this['frames']['length']===this['totalFrames']){const _0x5d75ae=this['frames']['join']('');this['frames']=null;const _0x15d16f=At(_0x5d75ae);this['onMessage'](_0x15d16f);}}['handleNewFrameCount_'](_0xf8eb86){this['totalFrames']=_0xf8eb86,this['frames']=[];}['extractFrameCount_'](_0x4badc1){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x4badc1['length']<=0x6){const _0x4e4619=Number(_0x4badc1);if(!isNaN(_0x4e4619))return this['handleNewFrameCount_'](_0x4e4619),null;}return this['handleNewFrameCount_'](0x1),_0x4badc1;}['handleIncomingFrame'](_0x28f379){if(this['mySock']===null)return;const _0x3acbfa=_0x28f379['data'];if(this['bytesReceived']+=_0x3acbfa['length'],this['stats_']['incrementCounter']('bytes_received',_0x3acbfa['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x3acbfa);else{const _0x84cbda=this['extractFrameCount_'](_0x3acbfa);_0x84cbda!==null&&this['appendFrame_'](_0x84cbda);}}['send'](_0x5e82e7){this['resetKeepAlive']();const _0x589e80=O(_0x5e82e7);this['bytesSent']+=_0x589e80['length'],this['stats_']['incrementCounter']('bytes_sent',_0x589e80['length']);const _0x1b9116=oo(_0x589e80,gh);_0x1b9116['length']>0x1&&this['sendString_'](String(_0x1b9116['length']));for(let _0xd2a729=0x0;_0xd2a729<_0x1b9116['length'];_0xd2a729++)this['sendString_'](_0x1b9116[_0xd2a729]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x4c6011){try{this['mySock']['send'](_0x4c6011);}catch(_0x250e9a){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x250e9a['message']||_0x250e9a['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x264b2a){this['initTransports_'](_0x264b2a);}['initTransports_'](_0x805996){const _0x34927a=z&&z['isAvailable']();let _0x32598e=_0x34927a&&!z['previouslyFailed']();if(_0x805996['webSocketOnly']&&(_0x34927a||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x32598e=!0x0),_0x32598e)this['transports_']=[z];else{const _0xcdb8ee=this['transports_']=[];for(const _0x976fd9 of Nt['ALL_TRANSPORTS'])_0x976fd9&&_0x976fd9['isAvailable']()&&_0xcdb8ee['push'](_0x976fd9);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x570e29,_0xed0197,_0x19dc57,_0x3bd16c,_0x28e71a,_0xa7208b,_0x4d46fa,_0x597a8e,_0x1d1191,_0x5602f9){this['id']=_0x570e29,this['repoInfo_']=_0xed0197,this['applicationId_']=_0x19dc57,this['appCheckToken_']=_0x3bd16c,this['authToken_']=_0x28e71a,this['onMessage_']=_0xa7208b,this['onReady_']=_0x4d46fa,this['onDisconnect_']=_0x597a8e,this['onKill_']=_0x1d1191,this['lastSessionId']=_0x5602f9,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0xed0197),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x31d9ab=this['transportManager_']['initialTransport']();this['conn_']=new _0x31d9ab(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x31d9ab['responsesRequiredToBeHealthy']||0x0;const _0x1d12b3=this['connReceiver_'](this['conn_']),_0x545e1f=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x1d12b3,_0x545e1f);},Math['floor'](0x0));const _0x398d5b=_0x31d9ab['healthyTimeout']||0x0;_0x398d5b>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x398d5b)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x8343){return _0x32b2ee=>{_0x8343===this['conn_']?this['onConnectionLost_'](_0x32b2ee):_0x8343===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x5e6ff3){return _0xcc7a70=>{this['state_']!==0x2&&(_0x5e6ff3===this['rx_']?this['onPrimaryMessageReceived_'](_0xcc7a70):_0x5e6ff3===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0xcc7a70):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x4f7502){const _0x2eb40f={'t':'d','d':_0x4f7502};this['sendData_'](_0x2eb40f);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x48639e){if(si in _0x48639e){const _0x276252=_0x48639e[si];_0x276252===Qs?this['upgradeIfSecondaryHealthy_']():_0x276252===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x276252===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x13c713){const _0x4a9dfc=_t('t',_0x13c713),_0x5ac141=_t('d',_0x13c713);if(_0x4a9dfc==='c')this['onSecondaryControl_'](_0x5ac141);else{if(_0x4a9dfc==='d')this['pendingDataMessages']['push'](_0x5ac141);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x4a9dfc);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x395911){const _0xba20ca=_t('t',_0x395911),_0x549c39=_t('d',_0x395911);_0xba20ca==='c'?this['onControl_'](_0x549c39):_0xba20ca==='d'&&this['onDataMessage_'](_0x549c39);}['onDataMessage_'](_0x567abc){this['onPrimaryResponse_'](),this['onMessage_'](_0x567abc);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x40f678){const _0x3b7603=_t(si,_0x40f678);if(js in _0x40f678){const _0x5ac7da=_0x40f678[js];if(_0x3b7603===Th){const _0x4c7b07={..._0x5ac7da};this['repoInfo_']['isUsingEmulator']&&(_0x4c7b07['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x4c7b07);}else{if(_0x3b7603===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0xb145a=0x0;_0xb145a<this['pendingDataMessages']['length'];++_0xb145a)this['onDataMessage_'](this['pendingDataMessages'][_0xb145a]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x3b7603===wh?this['onConnectionShutdown_'](_0x5ac7da):_0x3b7603===Ks?this['onReset_'](_0x5ac7da):_0x3b7603===Ch?yi('Server\x20Error:\x20'+_0x5ac7da):_0x3b7603===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x3b7603);}}}['onHandshake_'](_0x5249c3){const _0x1ce403=_0x5249c3['ts'],_0x2ebb29=_0x5249c3['v'],_0x2d4e95=_0x5249c3['h'];this['sessionId']=_0x5249c3['s'],this['repoInfo_']['host']=_0x2d4e95,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x1ce403),$i!==_0x2ebb29&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0xcd036e=this['transportManager_']['upgradeTransport']();_0xcd036e&&this['startUpgrade_'](_0xcd036e);}['startUpgrade_'](_0x5f4de0){this['secondaryConn_']=new _0x5f4de0(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x5f4de0['responsesRequiredToBeHealthy']||0x0;const _0xaf496c=this['connReceiver_'](this['secondaryConn_']),_0x863687=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0xaf496c,_0x863687),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x5df97c){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x5df97c),this['repoInfo_']['host']=_0x5df97c,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x493aa2,_0x319837){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x493aa2,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x319837,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x39c06e=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x39c06e||this['rx_']===_0x39c06e)&&this['close']();}['onConnectionLost_'](_0x3ef9f1){this['conn_']=null,!_0x3ef9f1&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x3ab95b){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x3ab95b),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x219400){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x219400);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x5e82b9,_0xd6a96,_0x3e04c7,_0x4b6d42){}['merge'](_0x17163e,_0x3a6a39,_0x436eea,_0x3fd54c){}['refreshAuthToken'](_0x5c0bda){}['refreshAppCheckToken'](_0x13f24c){}['onDisconnectPut'](_0x5ba25b,_0x5879c5,_0x481298){}['onDisconnectMerge'](_0x3b198e,_0x38556c,_0x1e7f8f){}['onDisconnectCancel'](_0x4e0cf0,_0x2a6cb){}['reportStats'](_0x27800a){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x1fd4dd){this['allowedEvents_']=_0x1fd4dd,this['listeners_']={},f(Array['isArray'](_0x1fd4dd)&&_0x1fd4dd['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x372bb8,..._0x377e0c){if(Array['isArray'](this['listeners_'][_0x372bb8])){const _0x5d3a7a=[...this['listeners_'][_0x372bb8]];for(let _0x54fde3=0x0;_0x54fde3<_0x5d3a7a['length'];_0x54fde3++)_0x5d3a7a[_0x54fde3]['callback']['apply'](_0x5d3a7a[_0x54fde3]['context'],_0x377e0c);}}['on'](_0x5eef0d,_0x7c1409,_0x2398c3){this['validateEventType_'](_0x5eef0d),this['listeners_'][_0x5eef0d]=this['listeners_'][_0x5eef0d]||[],this['listeners_'][_0x5eef0d]['push']({'callback':_0x7c1409,'context':_0x2398c3});const _0x5cb5e3=this['getInitialEvent'](_0x5eef0d);_0x5cb5e3&&_0x7c1409['apply'](_0x2398c3,_0x5cb5e3);}['off'](_0x4f3839,_0x1e5ed0,_0x5f3ac5){this['validateEventType_'](_0x4f3839);const _0x51cb20=this['listeners_'][_0x4f3839]||[];for(let _0x1048f3=0x0;_0x1048f3<_0x51cb20['length'];_0x1048f3++)if(_0x51cb20[_0x1048f3]['callback']===_0x1e5ed0&&(!_0x5f3ac5||_0x5f3ac5===_0x51cb20[_0x1048f3]['context'])){_0x51cb20['splice'](_0x1048f3,0x1);return;}}['validateEventType_'](_0x23a6c7){f(this['allowedEvents_']['find'](_0x1376d7=>_0x1376d7===_0x23a6c7),'Unknown\x20event:\x20'+_0x23a6c7);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x440188){return f(_0x440188==='online','Unknown\x20event\x20type:\x20'+_0x440188),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x11d0ec,_0xf4022d){if(_0xf4022d===void 0x0){this['pieces_']=_0x11d0ec['split']('/');let _0x576dcf=0x0;for(let _0x505993=0x0;_0x505993<this['pieces_']['length'];_0x505993++)this['pieces_'][_0x505993]['length']>0x0&&(this['pieces_'][_0x576dcf]=this['pieces_'][_0x505993],_0x576dcf++);this['pieces_']['length']=_0x576dcf,this['pieceNum_']=0x0;}else this['pieces_']=_0x11d0ec,this['pieceNum_']=_0xf4022d;}['toString'](){let _0x5ccae0='';for(let _0x3ec8fd=this['pieceNum_'];_0x3ec8fd<this['pieces_']['length'];_0x3ec8fd++)this['pieces_'][_0x3ec8fd]!==''&&(_0x5ccae0+='/'+this['pieces_'][_0x3ec8fd]);return _0x5ccae0||'/';}}function w(){return new C('');}function y(_0x3a3231){return _0x3a3231['pieceNum_']>=_0x3a3231['pieces_']['length']?null:_0x3a3231['pieces_'][_0x3a3231['pieceNum_']];}function we(_0x1c2e70){return _0x1c2e70['pieces_']['length']-_0x1c2e70['pieceNum_'];}function b(_0x24a786){let _0x3a5ed9=_0x24a786['pieceNum_'];return _0x3a5ed9<_0x24a786['pieces_']['length']&&_0x3a5ed9++,new C(_0x24a786['pieces_'],_0x3a5ed9);}function zi(_0x57ad7a){return _0x57ad7a['pieceNum_']<_0x57ad7a['pieces_']['length']?_0x57ad7a['pieces_'][_0x57ad7a['pieces_']['length']-0x1]:null;}function bh(_0x18410f){let _0xf904a7='';for(let _0xc4bcf6=_0x18410f['pieceNum_'];_0xc4bcf6<_0x18410f['pieces_']['length'];_0xc4bcf6++)_0x18410f['pieces_'][_0xc4bcf6]!==''&&(_0xf904a7+='/'+encodeURIComponent(String(_0x18410f['pieces_'][_0xc4bcf6])));return _0xf904a7||'/';}function Pt(_0x1e423b,_0x5bb480=0x0){return _0x1e423b['pieces_']['slice'](_0x1e423b['pieceNum_']+_0x5bb480);}function Ro(_0x2b5ea3){if(_0x2b5ea3['pieceNum_']>=_0x2b5ea3['pieces_']['length'])return null;const _0x3c048e=[];for(let _0x5b2013=_0x2b5ea3['pieceNum_'];_0x5b2013<_0x2b5ea3['pieces_']['length']-0x1;_0x5b2013++)_0x3c048e['push'](_0x2b5ea3['pieces_'][_0x5b2013]);return new C(_0x3c048e,0x0);}function k(_0x24ce8f,_0x1a905a){const _0x166212=[];for(let _0x24393d=_0x24ce8f['pieceNum_'];_0x24393d<_0x24ce8f['pieces_']['length'];_0x24393d++)_0x166212['push'](_0x24ce8f['pieces_'][_0x24393d]);if(_0x1a905a instanceof C){for(let _0xdfa38b=_0x1a905a['pieceNum_'];_0xdfa38b<_0x1a905a['pieces_']['length'];_0xdfa38b++)_0x166212['push'](_0x1a905a['pieces_'][_0xdfa38b]);}else{const _0x43365f=_0x1a905a['split']('/');for(let _0x583301=0x0;_0x583301<_0x43365f['length'];_0x583301++)_0x43365f[_0x583301]['length']>0x0&&_0x166212['push'](_0x43365f[_0x583301]);}return new C(_0x166212,0x0);}function v(_0x123744){return _0x123744['pieceNum_']>=_0x123744['pieces_']['length'];}function F(_0x231123,_0xbe19e8){const _0x57447c=y(_0x231123),_0x43e302=y(_0xbe19e8);if(_0x57447c===null)return _0xbe19e8;if(_0x57447c===_0x43e302)return F(b(_0x231123),b(_0xbe19e8));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0xbe19e8+')\x20is\x20not\x20within\x20outerPath\x20('+_0x231123+')');}function Rh(_0x1ea50d,_0x500806){const _0x394575=Pt(_0x1ea50d,0x0),_0x1933ea=Pt(_0x500806,0x0);for(let _0x4e68f8=0x0;_0x4e68f8<_0x394575['length']&&_0x4e68f8<_0x1933ea['length'];_0x4e68f8++){const _0x6d98b8=He(_0x394575[_0x4e68f8],_0x1933ea[_0x4e68f8]);if(_0x6d98b8!==0x0)return _0x6d98b8;}return _0x394575['length']===_0x1933ea['length']?0x0:_0x394575['length']<_0x1933ea['length']?-0x1:0x1;}function ji(_0x2ba429,_0x417ef1){if(we(_0x2ba429)!==we(_0x417ef1))return!0x1;for(let _0x450330=_0x2ba429['pieceNum_'],_0x33c990=_0x417ef1['pieceNum_'];_0x450330<=_0x2ba429['pieces_']['length'];_0x450330++,_0x33c990++)if(_0x2ba429['pieces_'][_0x450330]!==_0x417ef1['pieces_'][_0x33c990])return!0x1;return!0x0;}function G(_0x249307,_0xc4c7a4){let _0x1323ed=_0x249307['pieceNum_'],_0x31f96f=_0xc4c7a4['pieceNum_'];if(we(_0x249307)>we(_0xc4c7a4))return!0x1;for(;_0x1323ed<_0x249307['pieces_']['length'];){if(_0x249307['pieces_'][_0x1323ed]!==_0xc4c7a4['pieces_'][_0x31f96f])return!0x1;++_0x1323ed,++_0x31f96f;}return!0x0;}class Ah{constructor(_0x331979,_0x166936){this['errorPrefix_']=_0x166936,this['parts_']=Pt(_0x331979,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x3f1028=0x0;_0x3f1028<this['parts_']['length'];_0x3f1028++)this['byteLength_']+=On(this['parts_'][_0x3f1028]);Ao(this);}}function kh(_0x33e9e0,_0x296a89){_0x33e9e0['parts_']['length']>0x0&&(_0x33e9e0['byteLength_']+=0x1),_0x33e9e0['parts_']['push'](_0x296a89),_0x33e9e0['byteLength_']+=On(_0x296a89),Ao(_0x33e9e0);}function Nh(_0xa01b75){const _0x47c589=_0xa01b75['parts_']['pop']();_0xa01b75['byteLength_']-=On(_0x47c589),_0xa01b75['parts_']['length']>0x0&&(_0xa01b75['byteLength_']-=0x1);}function Ao(_0xe63429){if(_0xe63429['byteLength_']>er)throw new Error(_0xe63429['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0xe63429['byteLength_']+').');if(_0xe63429['parts_']['length']>Zs)throw new Error(_0xe63429['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0xe63429));}function Pe(_0x41b784){return _0x41b784['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x41b784['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x48e637,_0x3b45fe;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x3b45fe='visibilitychange',_0x48e637='hidden'):typeof document['mozHidden']<'u'?(_0x3b45fe='mozvisibilitychange',_0x48e637='mozHidden'):typeof document['msHidden']<'u'?(_0x3b45fe='msvisibilitychange',_0x48e637='msHidden'):typeof document['webkitHidden']<'u'&&(_0x3b45fe='webkitvisibilitychange',_0x48e637='webkitHidden')),this['visible_']=!0x0,_0x3b45fe&&document['addEventListener'](_0x3b45fe,()=>{const _0x386abc=!document[_0x48e637];_0x386abc!==this['visible_']&&(this['visible_']=_0x386abc,this['trigger']('visible',_0x386abc));},!0x1);}['getInitialEvent'](_0x391762){return f(_0x391762==='visible','Unknown\x20event\x20type:\x20'+_0x391762),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x24a8c4,_0x274500,_0xc5153f,_0x584e25,_0x59ea47,_0x4d1ebd,_0x5d7d2c,_0xaebebd){if(super(),this['repoInfo_']=_0x24a8c4,this['applicationId_']=_0x274500,this['onDataUpdate_']=_0xc5153f,this['onConnectStatus_']=_0x584e25,this['onServerInfoUpdate_']=_0x59ea47,this['authTokenProvider_']=_0x4d1ebd,this['appCheckTokenProvider_']=_0x5d7d2c,this['authOverride_']=_0xaebebd,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0xaebebd)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x24a8c4['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x4a1104,_0x2bf362,_0x4e2ac4){const _0x41eb63=++this['requestNumber_'],_0x43c10d={'r':_0x41eb63,'a':_0x4a1104,'b':_0x2bf362};this['log_'](O(_0x43c10d)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x43c10d),_0x4e2ac4&&(this['requestCBHash_'][_0x41eb63]=_0x4e2ac4);}['get'](_0x978252){this['initConnection_']();const _0x21e019=new ot(),_0x27ab83={'action':'g','request':{'p':_0x978252['_path']['toString'](),'q':_0x978252['_queryObject']},'onComplete':_0x215fe1=>{const _0x3c9c5c=_0x215fe1['d'];_0x215fe1['s']==='ok'?_0x21e019['resolve'](_0x3c9c5c):_0x21e019['reject'](_0x3c9c5c);}};this['outstandingGets_']['push'](_0x27ab83),this['outstandingGetCount_']++;const _0x1b1616=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x1b1616),_0x21e019['promise'];}['listen'](_0xe5cd1,_0x428483,_0x27b3e4,_0x5c4552){this['initConnection_']();const _0x144c77=_0xe5cd1['_queryIdentifier'],_0x1fbe76=_0xe5cd1['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1fbe76+'\x20'+_0x144c77),this['listens']['has'](_0x1fbe76)||this['listens']['set'](_0x1fbe76,new Map()),f(_0xe5cd1['_queryParams']['isDefault']()||!_0xe5cd1['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x1fbe76)['has'](_0x144c77),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x4fe834={'onComplete':_0x5c4552,'hashFn':_0x428483,'query':_0xe5cd1,'tag':_0x27b3e4};this['listens']['get'](_0x1fbe76)['set'](_0x144c77,_0x4fe834),this['connected_']&&this['sendListen_'](_0x4fe834);}['sendGet_'](_0x24c86d){const _0x58ff46=this['outstandingGets_'][_0x24c86d];this['sendRequest']('g',_0x58ff46['request'],_0x1bf492=>{delete this['outstandingGets_'][_0x24c86d],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x58ff46['onComplete']&&_0x58ff46['onComplete'](_0x1bf492);});}['sendListen_'](_0x448b8a){const _0x18a2cd=_0x448b8a['query'],_0xc3c480=_0x18a2cd['_path']['toString'](),_0x595f10=_0x18a2cd['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0xc3c480+'\x20for\x20'+_0x595f10);const _0x46ad97={'p':_0xc3c480},_0x146cc1='q';_0x448b8a['tag']&&(_0x46ad97['q']=_0x18a2cd['_queryObject'],_0x46ad97['t']=_0x448b8a['tag']),_0x46ad97['h']=_0x448b8a['hashFn'](),this['sendRequest'](_0x146cc1,_0x46ad97,_0x3b833e=>{const _0x5ec52d=_0x3b833e['d'],_0x460efb=_0x3b833e['s'];se['warnOnListenWarnings_'](_0x5ec52d,_0x18a2cd),(this['listens']['get'](_0xc3c480)&&this['listens']['get'](_0xc3c480)['get'](_0x595f10))===_0x448b8a&&(this['log_']('listen\x20response',_0x3b833e),_0x460efb!=='ok'&&this['removeListen_'](_0xc3c480,_0x595f10),_0x448b8a['onComplete']&&_0x448b8a['onComplete'](_0x460efb,_0x5ec52d));});}static['warnOnListenWarnings_'](_0x1a728f,_0x13de9b){if(_0x1a728f&&typeof _0x1a728f=='object'&&J(_0x1a728f,'w')){const _0x765dc4=De(_0x1a728f,'w');if(Array['isArray'](_0x765dc4)&&~_0x765dc4['indexOf']('no_index')){const _0x4bcc61='\x22.indexOn\x22:\x20\x22'+_0x13de9b['_queryParams']['getIndex']()['toString']()+'\x22',_0xd98996=_0x13de9b['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x4bcc61+'\x20at\x20'+_0xd98996+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x1a3fd9){this['authToken_']=_0x1a3fd9,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x1a3fd9);}['reduceReconnectDelayIfAdminCredential_'](_0xfa5e0d){(_0xfa5e0d&&_0xfa5e0d['length']===0x28||wc(_0xfa5e0d))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0xbd96a0){this['appCheckToken_']=_0xbd96a0,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x492ef7=this['authToken_'],_0x3e1461=Ic(_0x492ef7)?'auth':'gauth',_0x302e17={'cred':_0x492ef7};this['authOverride_']===null?_0x302e17['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x302e17['authvar']=this['authOverride_']),this['sendRequest'](_0x3e1461,_0x302e17,_0x1bd5ab=>{const _0x2a172f=_0x1bd5ab['s'],_0x3291f2=_0x1bd5ab['d']||'error';this['authToken_']===_0x492ef7&&(_0x2a172f==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x2a172f,_0x3291f2));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x2c7176=>{const _0x3c9df1=_0x2c7176['s'],_0x850d0b=_0x2c7176['d']||'error';_0x3c9df1==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x3c9df1,_0x850d0b);});}['unlisten'](_0x21ccf4,_0x19d7ab){const _0x1fa069=_0x21ccf4['_path']['toString'](),_0x259968=_0x21ccf4['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x1fa069+'\x20'+_0x259968),f(_0x21ccf4['_queryParams']['isDefault']()||!_0x21ccf4['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x1fa069,_0x259968)&&this['connected_']&&this['sendUnlisten_'](_0x1fa069,_0x259968,_0x21ccf4['_queryObject'],_0x19d7ab);}['sendUnlisten_'](_0xafa508,_0x19a7a1,_0x24e17a,_0x35ba73){this['log_']('Unlisten\x20on\x20'+_0xafa508+'\x20for\x20'+_0x19a7a1);const _0x3f8f9e={'p':_0xafa508},_0x36ef45='n';_0x35ba73&&(_0x3f8f9e['q']=_0x24e17a,_0x3f8f9e['t']=_0x35ba73),this['sendRequest'](_0x36ef45,_0x3f8f9e);}['onDisconnectPut'](_0x2574af,_0x118d99,_0x5cb9f1){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x2574af,_0x118d99,_0x5cb9f1):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2574af,'action':'o','data':_0x118d99,'onComplete':_0x5cb9f1});}['onDisconnectMerge'](_0x1c0667,_0x36218f,_0x343759){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x1c0667,_0x36218f,_0x343759):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1c0667,'action':'om','data':_0x36218f,'onComplete':_0x343759});}['onDisconnectCancel'](_0x525d64,_0x3d61d5){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x525d64,null,_0x3d61d5):this['onDisconnectRequestQueue_']['push']({'pathString':_0x525d64,'action':'oc','data':null,'onComplete':_0x3d61d5});}['sendOnDisconnect_'](_0x356a12,_0xdd43d1,_0x46e199,_0x47b865){const _0x2a20b8={'p':_0xdd43d1,'d':_0x46e199};this['log_']('onDisconnect\x20'+_0x356a12,_0x2a20b8),this['sendRequest'](_0x356a12,_0x2a20b8,_0x549a53=>{_0x47b865&&setTimeout(()=>{_0x47b865(_0x549a53['s'],_0x549a53['d']);},Math['floor'](0x0));});}['put'](_0x29c31d,_0x422b43,_0x3cde2a,_0x55dc0d){this['putInternal']('p',_0x29c31d,_0x422b43,_0x3cde2a,_0x55dc0d);}['merge'](_0x5abac9,_0x2ac42d,_0x3ba215,_0x5714ed){this['putInternal']('m',_0x5abac9,_0x2ac42d,_0x3ba215,_0x5714ed);}['putInternal'](_0x120a2f,_0x1e87f5,_0x23b335,_0x128d96,_0x179653){this['initConnection_']();const _0x5e10bb={'p':_0x1e87f5,'d':_0x23b335};_0x179653!==void 0x0&&(_0x5e10bb['h']=_0x179653),this['outstandingPuts_']['push']({'action':_0x120a2f,'request':_0x5e10bb,'onComplete':_0x128d96}),this['outstandingPutCount_']++;const _0x1b8e56=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x1b8e56):this['log_']('Buffering\x20put:\x20'+_0x1e87f5);}['sendPut_'](_0x1e1a76){const _0x4b008e=this['outstandingPuts_'][_0x1e1a76]['action'],_0x1c6785=this['outstandingPuts_'][_0x1e1a76]['request'],_0x3217f5=this['outstandingPuts_'][_0x1e1a76]['onComplete'];this['outstandingPuts_'][_0x1e1a76]['queued']=this['connected_'],this['sendRequest'](_0x4b008e,_0x1c6785,_0x3a6301=>{this['log_'](_0x4b008e+'\x20response',_0x3a6301),delete this['outstandingPuts_'][_0x1e1a76],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x3217f5&&_0x3217f5(_0x3a6301['s'],_0x3a6301['d']);});}['reportStats'](_0x25dbc7){if(this['connected_']){const _0x568434={'c':_0x25dbc7};this['log_']('reportStats',_0x568434),this['sendRequest']('s',_0x568434,_0xe9b082=>{if(_0xe9b082['s']!=='ok'){const _0x425e24=_0xe9b082['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x425e24);}});}}['onDataMessage_'](_0x257be9){if('r'in _0x257be9){this['log_']('from\x20server:\x20'+O(_0x257be9));const _0x143820=_0x257be9['r'],_0x2fca7c=this['requestCBHash_'][_0x143820];_0x2fca7c&&(delete this['requestCBHash_'][_0x143820],_0x2fca7c(_0x257be9['b']));}else{if('error'in _0x257be9)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x257be9['error'];'a'in _0x257be9&&this['onDataPush_'](_0x257be9['a'],_0x257be9['b']);}}['onDataPush_'](_0x35ad44,_0x326696){this['log_']('handleServerMessage',_0x35ad44,_0x326696),_0x35ad44==='d'?this['onDataUpdate_'](_0x326696['p'],_0x326696['d'],!0x1,_0x326696['t']):_0x35ad44==='m'?this['onDataUpdate_'](_0x326696['p'],_0x326696['d'],!0x0,_0x326696['t']):_0x35ad44==='c'?this['onListenRevoked_'](_0x326696['p'],_0x326696['q']):_0x35ad44==='ac'?this['onAuthRevoked_'](_0x326696['s'],_0x326696['d']):_0x35ad44==='apc'?this['onAppCheckRevoked_'](_0x326696['s'],_0x326696['d']):_0x35ad44==='sd'?this['onSecurityDebugPacket_'](_0x326696):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x35ad44)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x1c9b01,_0x839dd9){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x1c9b01),this['lastSessionId']=_0x839dd9,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x8c814a){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x8c814a));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x223c63){_0x223c63&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x223c63;}['onOnline_'](_0x23cfbe){_0x23cfbe?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x17990d=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x11093e=Math['max'](0x0,this['reconnectDelay_']-_0x17990d);_0x11093e=Math['random']()*_0x11093e,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x11093e+'ms'),this['scheduleConnect_'](_0x11093e),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x5b432d=this['onDataMessage_']['bind'](this),_0xe10dc0=this['onReady_']['bind'](this),_0x33f1cd=this['onRealtimeDisconnect_']['bind'](this),_0x39cf99=this['id']+':'+se['nextConnectionId_']++,_0x1eb797=this['lastSessionId'];let _0x3e440c=!0x1,_0x427a9d=null;const _0x5f13eb=function(){_0x427a9d?_0x427a9d['close']():(_0x3e440c=!0x0,_0x33f1cd());},_0x544848=function(_0x104f65){f(_0x427a9d,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x427a9d['sendRequest'](_0x104f65);};this['realtime_']={'close':_0x5f13eb,'sendRequest':_0x544848};const _0x5c3ddf=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x3272b2,_0x1bd952]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x5c3ddf),this['appCheckTokenProvider_']['getToken'](_0x5c3ddf)]);_0x3e440c?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x3272b2&&_0x3272b2['accessToken'],this['appCheckToken_']=_0x1bd952&&_0x1bd952['token'],_0x427a9d=new Sh(_0x39cf99,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x5b432d,_0xe10dc0,_0x33f1cd,_0x27ebd5=>{U(_0x27ebd5+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x1eb797));}catch(_0x3c94bd){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x3c94bd),_0x3e440c||(this['repoInfo_']['nodeAdmin']&&U(_0x3c94bd),_0x5f13eb());}}}['interrupt'](_0x233fc7){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x233fc7),this['interruptReasons_'][_0x233fc7]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x2bfcfe){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x2bfcfe),delete this['interruptReasons_'][_0x2bfcfe],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x17dd66){const _0x1e5c2e=_0x17dd66-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x1e5c2e});}['cancelSentTransactions_'](){for(let _0x13b1ba=0x0;_0x13b1ba<this['outstandingPuts_']['length'];_0x13b1ba++){const _0x21648a=this['outstandingPuts_'][_0x13b1ba];_0x21648a&&'h'in _0x21648a['request']&&_0x21648a['queued']&&(_0x21648a['onComplete']&&_0x21648a['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x13b1ba],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x1f1e0e,_0x4865ca){let _0xf707cf;_0x4865ca?_0xf707cf=_0x4865ca['map'](_0x5b83f7=>Hi(_0x5b83f7))['join']('$'):_0xf707cf='default';const _0x3e4a19=this['removeListen_'](_0x1f1e0e,_0xf707cf);_0x3e4a19&&_0x3e4a19['onComplete']&&_0x3e4a19['onComplete']('permission_denied');}['removeListen_'](_0x5d518b,_0x1eff1b){const _0x280bf7=new C(_0x5d518b)['toString']();let _0x44f1b9;if(this['listens']['has'](_0x280bf7)){const _0xaeccaf=this['listens']['get'](_0x280bf7);_0x44f1b9=_0xaeccaf['get'](_0x1eff1b),_0xaeccaf['delete'](_0x1eff1b),_0xaeccaf['size']===0x0&&this['listens']['delete'](_0x280bf7);}else _0x44f1b9=void 0x0;return _0x44f1b9;}['onAuthRevoked_'](_0x17a148,_0x1ea36e){L('Auth\x20token\x20revoked:\x20'+_0x17a148+'/'+_0x1ea36e),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x17a148==='invalid_token'||_0x17a148==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x40f537,_0x2717b8){L('App\x20check\x20token\x20revoked:\x20'+_0x40f537+'/'+_0x2717b8),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x40f537==='invalid_token'||_0x40f537==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x536385){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x536385):'msg'in _0x536385&&console['log']('FIREBASE:\x20'+_0x536385['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x13681f of this['listens']['values']())for(const _0x56ae49 of _0x13681f['values']())this['sendListen_'](_0x56ae49);for(let _0x18eead=0x0;_0x18eead<this['outstandingPuts_']['length'];_0x18eead++)this['outstandingPuts_'][_0x18eead]&&this['sendPut_'](_0x18eead);for(;this['onDisconnectRequestQueue_']['length'];){const _0x58856c=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x58856c['action'],_0x58856c['pathString'],_0x58856c['data'],_0x58856c['onComplete']);}for(let _0x32b76d=0x0;_0x32b76d<this['outstandingGets_']['length'];_0x32b76d++)this['outstandingGets_'][_0x32b76d]&&this['sendGet_'](_0x32b76d);}['sendConnectStats_'](){const _0x2c6b2a={};let _0xf19dc4='js';_0x2c6b2a['sdk.'+_0xf19dc4+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x2c6b2a['framework.cordova']=0x1:Yr()&&(_0x2c6b2a['framework.reactnative']=0x1),this['reportStats'](_0x2c6b2a);}['shouldReconnect_'](){const _0xa4efa6=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0xa4efa6;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x522e7c,_0xacd448){this['name']=_0x522e7c,this['node']=_0xacd448;}static['Wrap'](_0x50df6a,_0x98c1d){return new E(_0x50df6a,_0x98c1d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x36cc1a,_0x15eb3b){const _0x17eabb=new E(Fe,_0x36cc1a),_0x1eeab5=new E(Fe,_0x15eb3b);return this['compare'](_0x17eabb,_0x1eeab5)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x43d4a1){Zt=_0x43d4a1;}['compare'](_0xc9e2fc,_0x543ad3){return He(_0xc9e2fc['name'],_0x543ad3['name']);}['isDefinedOn'](_0x3ea64c){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x20eb78,_0x224cd5){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x476acf,_0x2e0b4d){return f(typeof _0x476acf=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x476acf,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x1b93ea,_0x2199c8,_0x203be5,_0x15b0bf,_0xd90009=null){this['isReverse_']=_0x15b0bf,this['resultGenerator_']=_0xd90009,this['nodeStack_']=[];let _0x42506f=0x1;for(;!_0x1b93ea['isEmpty']();)if(_0x1b93ea=_0x1b93ea,_0x42506f=_0x2199c8?_0x203be5(_0x1b93ea['key'],_0x2199c8):0x1,_0x15b0bf&&(_0x42506f*=-0x1),_0x42506f<0x0)this['isReverse_']?_0x1b93ea=_0x1b93ea['left']:_0x1b93ea=_0x1b93ea['right'];else{if(_0x42506f===0x0){this['nodeStack_']['push'](_0x1b93ea);break;}else this['nodeStack_']['push'](_0x1b93ea),this['isReverse_']?_0x1b93ea=_0x1b93ea['right']:_0x1b93ea=_0x1b93ea['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x222e8e=this['nodeStack_']['pop'](),_0x155f10;if(this['resultGenerator_']?_0x155f10=this['resultGenerator_'](_0x222e8e['key'],_0x222e8e['value']):_0x155f10={'key':_0x222e8e['key'],'value':_0x222e8e['value']},this['isReverse_']){for(_0x222e8e=_0x222e8e['left'];!_0x222e8e['isEmpty']();)this['nodeStack_']['push'](_0x222e8e),_0x222e8e=_0x222e8e['right'];}else{for(_0x222e8e=_0x222e8e['right'];!_0x222e8e['isEmpty']();)this['nodeStack_']['push'](_0x222e8e),_0x222e8e=_0x222e8e['left'];}return _0x155f10;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x2444b3=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x2444b3['key'],_0x2444b3['value']):{'key':_0x2444b3['key'],'value':_0x2444b3['value']};}}class M{constructor(_0x149478,_0x27831d,_0x40588a,_0x14cf0e,_0x433403){this['key']=_0x149478,this['value']=_0x27831d,this['color']=_0x40588a??M['RED'],this['left']=_0x14cf0e??B['EMPTY_NODE'],this['right']=_0x433403??B['EMPTY_NODE'];}['copy'](_0x1118c7,_0x39b129,_0x3670b6,_0x32e8c7,_0x4246fb){return new M(_0x1118c7??this['key'],_0x39b129??this['value'],_0x3670b6??this['color'],_0x32e8c7??this['left'],_0x4246fb??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x1b74a6){return this['left']['inorderTraversal'](_0x1b74a6)||!!_0x1b74a6(this['key'],this['value'])||this['right']['inorderTraversal'](_0x1b74a6);}['reverseTraversal'](_0x3b9ce5){return this['right']['reverseTraversal'](_0x3b9ce5)||_0x3b9ce5(this['key'],this['value'])||this['left']['reverseTraversal'](_0x3b9ce5);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0xfca85c,_0x4d9cf1,_0x16d00c){let _0x3e07e7=this;const _0x20d94a=_0x16d00c(_0xfca85c,_0x3e07e7['key']);return _0x20d94a<0x0?_0x3e07e7=_0x3e07e7['copy'](null,null,null,_0x3e07e7['left']['insert'](_0xfca85c,_0x4d9cf1,_0x16d00c),null):_0x20d94a===0x0?_0x3e07e7=_0x3e07e7['copy'](null,_0x4d9cf1,null,null,null):_0x3e07e7=_0x3e07e7['copy'](null,null,null,null,_0x3e07e7['right']['insert'](_0xfca85c,_0x4d9cf1,_0x16d00c)),_0x3e07e7['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x1a5316=this;return!_0x1a5316['left']['isRed_']()&&!_0x1a5316['left']['left']['isRed_']()&&(_0x1a5316=_0x1a5316['moveRedLeft_']()),_0x1a5316=_0x1a5316['copy'](null,null,null,_0x1a5316['left']['removeMin_'](),null),_0x1a5316['fixUp_']();}['remove'](_0x481603,_0x280c6b){let _0x769864,_0x1872f3;if(_0x769864=this,_0x280c6b(_0x481603,_0x769864['key'])<0x0)!_0x769864['left']['isEmpty']()&&!_0x769864['left']['isRed_']()&&!_0x769864['left']['left']['isRed_']()&&(_0x769864=_0x769864['moveRedLeft_']()),_0x769864=_0x769864['copy'](null,null,null,_0x769864['left']['remove'](_0x481603,_0x280c6b),null);else{if(_0x769864['left']['isRed_']()&&(_0x769864=_0x769864['rotateRight_']()),!_0x769864['right']['isEmpty']()&&!_0x769864['right']['isRed_']()&&!_0x769864['right']['left']['isRed_']()&&(_0x769864=_0x769864['moveRedRight_']()),_0x280c6b(_0x481603,_0x769864['key'])===0x0){if(_0x769864['right']['isEmpty']())return B['EMPTY_NODE'];_0x1872f3=_0x769864['right']['min_'](),_0x769864=_0x769864['copy'](_0x1872f3['key'],_0x1872f3['value'],null,null,_0x769864['right']['removeMin_']());}_0x769864=_0x769864['copy'](null,null,null,null,_0x769864['right']['remove'](_0x481603,_0x280c6b));}return _0x769864['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x54bfa6=this;return _0x54bfa6['right']['isRed_']()&&!_0x54bfa6['left']['isRed_']()&&(_0x54bfa6=_0x54bfa6['rotateLeft_']()),_0x54bfa6['left']['isRed_']()&&_0x54bfa6['left']['left']['isRed_']()&&(_0x54bfa6=_0x54bfa6['rotateRight_']()),_0x54bfa6['left']['isRed_']()&&_0x54bfa6['right']['isRed_']()&&(_0x54bfa6=_0x54bfa6['colorFlip_']()),_0x54bfa6;}['moveRedLeft_'](){let _0x437913=this['colorFlip_']();return _0x437913['right']['left']['isRed_']()&&(_0x437913=_0x437913['copy'](null,null,null,null,_0x437913['right']['rotateRight_']()),_0x437913=_0x437913['rotateLeft_'](),_0x437913=_0x437913['colorFlip_']()),_0x437913;}['moveRedRight_'](){let _0x3e3f83=this['colorFlip_']();return _0x3e3f83['left']['left']['isRed_']()&&(_0x3e3f83=_0x3e3f83['rotateRight_'](),_0x3e3f83=_0x3e3f83['colorFlip_']()),_0x3e3f83;}['rotateLeft_'](){const _0x346088=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x346088,null);}['rotateRight_'](){const _0x5a6418=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x5a6418);}['colorFlip_'](){const _0x3e4e8b=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x3066d7=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x3e4e8b,_0x3066d7);}['checkMaxDepth_'](){const _0x4e6050=this['check_']();return Math['pow'](0x2,_0x4e6050)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x52d5d6=this['left']['check_']();if(_0x52d5d6!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x52d5d6+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x4576de,_0x1be6b0,_0x41d3a8,_0x1ec677,_0x4ddeb8){return this;}['insert'](_0x3a2514,_0x32f24b,_0x26989d){return new M(_0x3a2514,_0x32f24b,null);}['remove'](_0x3f7571,_0x2cce56){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x29daef){return!0x1;}['reverseTraversal'](_0x45c038){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x47b4c8,_0x2803d1=B['EMPTY_NODE']){this['comparator_']=_0x47b4c8,this['root_']=_0x2803d1;}['insert'](_0x4019e2,_0x1e628e){return new B(this['comparator_'],this['root_']['insert'](_0x4019e2,_0x1e628e,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x1f548f){return new B(this['comparator_'],this['root_']['remove'](_0x1f548f,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x29da71){let _0x4cdd2b,_0xc013a2=this['root_'];for(;!_0xc013a2['isEmpty']();){if(_0x4cdd2b=this['comparator_'](_0x29da71,_0xc013a2['key']),_0x4cdd2b===0x0)return _0xc013a2['value'];_0x4cdd2b<0x0?_0xc013a2=_0xc013a2['left']:_0x4cdd2b>0x0&&(_0xc013a2=_0xc013a2['right']);}return null;}['getPredecessorKey'](_0x1d73d3){let _0x5ac377,_0x632e4e=this['root_'],_0x4f96ef=null;for(;!_0x632e4e['isEmpty']();)if(_0x5ac377=this['comparator_'](_0x1d73d3,_0x632e4e['key']),_0x5ac377===0x0){if(_0x632e4e['left']['isEmpty']())return _0x4f96ef?_0x4f96ef['key']:null;for(_0x632e4e=_0x632e4e['left'];!_0x632e4e['right']['isEmpty']();)_0x632e4e=_0x632e4e['right'];return _0x632e4e['key'];}else _0x5ac377<0x0?_0x632e4e=_0x632e4e['left']:_0x5ac377>0x0&&(_0x4f96ef=_0x632e4e,_0x632e4e=_0x632e4e['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x5b0d0c){return this['root_']['inorderTraversal'](_0x5b0d0c);}['reverseTraversal'](_0x587665){return this['root_']['reverseTraversal'](_0x587665);}['getIterator'](_0x533a4d){return new en(this['root_'],null,this['comparator_'],!0x1,_0x533a4d);}['getIteratorFrom'](_0x334dd7,_0x1bb3a4){return new en(this['root_'],_0x334dd7,this['comparator_'],!0x1,_0x1bb3a4);}['getReverseIteratorFrom'](_0x237600,_0x1eafa0){return new en(this['root_'],_0x237600,this['comparator_'],!0x0,_0x1eafa0);}['getReverseIterator'](_0xedc6f0){return new en(this['root_'],null,this['comparator_'],!0x0,_0xedc6f0);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x577d21,_0x1be3fb){return He(_0x577d21['name'],_0x1be3fb['name']);}function Yi(_0x43796b,_0x20d9d1){return He(_0x43796b,_0x20d9d1);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x264853){Ei=_0x264853;}const No=function(_0x2fb78f){return typeof _0x2fb78f=='number'?'number:'+ao(_0x2fb78f):'string:'+_0x2fb78f;},Po=function(_0x3b3b49){if(_0x3b3b49['isLeafNode']()){const _0x244a1a=_0x3b3b49['val']();f(typeof _0x244a1a=='string'||typeof _0x244a1a=='number'||typeof _0x244a1a=='object'&&J(_0x244a1a,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x3b3b49===Ei||_0x3b3b49['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x3b3b49===Ei||_0x3b3b49['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x595025){ir=_0x595025;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x552546,_0x34847=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x552546,this['priorityNode_']=_0x34847,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x67eab2){return new D(this['value_'],_0x67eab2);}['getImmediateChild'](_0x1f6287){return _0x1f6287==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x38ad26){return v(_0x38ad26)?this:y(_0x38ad26)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x4ec0fc,_0x28f0e5){return null;}['updateImmediateChild'](_0x280d01,_0x2cd44f){return _0x280d01==='.priority'?this['updatePriority'](_0x2cd44f):_0x2cd44f['isEmpty']()&&_0x280d01!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x280d01,_0x2cd44f)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x3907e7,_0x153c82){const _0x410315=y(_0x3907e7);return _0x410315===null?_0x153c82:_0x153c82['isEmpty']()&&_0x410315!=='.priority'?this:(f(_0x410315!=='.priority'||we(_0x3907e7)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x410315,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x3907e7),_0x153c82)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x4edc34,_0x19a870){return!0x1;}['val'](_0x2bac24){return _0x2bac24&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x4f76c5='';this['priorityNode_']['isEmpty']()||(_0x4f76c5+='priority:'+No(this['priorityNode_']['val']())+':');const _0x5f424d=typeof this['value_'];_0x4f76c5+=_0x5f424d+':',_0x5f424d==='number'?_0x4f76c5+=ao(this['value_']):_0x4f76c5+=this['value_'],this['lazyHash_']=ro(_0x4f76c5);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x569783){return _0x569783===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x569783 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x569783['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x569783));}['compareToLeafNode_'](_0x343e5a){const _0x54f342=typeof _0x343e5a['value_'],_0x21c4ab=typeof this['value_'],_0x5b7c9c=D['VALUE_TYPE_ORDER']['indexOf'](_0x54f342),_0x1a302e=D['VALUE_TYPE_ORDER']['indexOf'](_0x21c4ab);return f(_0x5b7c9c>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x54f342),f(_0x1a302e>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x21c4ab),_0x5b7c9c===_0x1a302e?_0x21c4ab==='object'?0x0:this['value_']<_0x343e5a['value_']?-0x1:this['value_']===_0x343e5a['value_']?0x0:0x1:_0x1a302e-_0x5b7c9c;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x61a96b){if(_0x61a96b===this)return!0x0;if(_0x61a96b['isLeafNode']()){const _0x54b55a=_0x61a96b;return this['value_']===_0x54b55a['value_']&&this['priorityNode_']['equals'](_0x54b55a['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x3e6eaf){Oo=_0x3e6eaf;}function Wh(_0x219952){Do=_0x219952;}class Bh extends Dn{['compare'](_0x5f0a7c,_0x573e85){const _0x13432c=_0x5f0a7c['node']['getPriority'](),_0x16a0a3=_0x573e85['node']['getPriority'](),_0x1dc2c7=_0x13432c['compareTo'](_0x16a0a3);return _0x1dc2c7===0x0?He(_0x5f0a7c['name'],_0x573e85['name']):_0x1dc2c7;}['isDefinedOn'](_0x826ee9){return!_0x826ee9['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x2abf6e,_0x125ffa){return!_0x2abf6e['getPriority']()['equals'](_0x125ffa['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x21921a,_0x550123){const _0x32770c=Oo(_0x21921a);return new E(_0x550123,new D('[PRIORITY-POST]',_0x32770c));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x33d2a6){const _0x346819=_0x56d21b=>parseInt(Math['log'](_0x56d21b)/Vh,0xa),_0x411511=_0x37d6e5=>parseInt(Array(_0x37d6e5+0x1)['join']('1'),0x2);this['count']=_0x346819(_0x33d2a6+0x1),this['current_']=this['count']-0x1;const _0x56b423=_0x411511(this['count']);this['bits_']=_0x33d2a6+0x1&_0x56b423;}['nextBitIsOne'](){const _0x2690ea=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x2690ea;}}const fn=function(_0x32fa85,_0x150835,_0x540307,_0x2f75ff){_0x32fa85['sort'](_0x150835);const _0x1d2c96=function(_0x1b9b16,_0x3471bb){const _0x3862c8=_0x3471bb-_0x1b9b16;let _0x205b4d,_0x18158b;if(_0x3862c8===0x0)return null;if(_0x3862c8===0x1)return _0x205b4d=_0x32fa85[_0x1b9b16],_0x18158b=_0x540307?_0x540307(_0x205b4d):_0x205b4d,new M(_0x18158b,_0x205b4d['node'],M['BLACK'],null,null);{const _0x508920=parseInt(_0x3862c8/0x2,0xa)+_0x1b9b16,_0x418174=_0x1d2c96(_0x1b9b16,_0x508920),_0x5278ff=_0x1d2c96(_0x508920+0x1,_0x3471bb);return _0x205b4d=_0x32fa85[_0x508920],_0x18158b=_0x540307?_0x540307(_0x205b4d):_0x205b4d,new M(_0x18158b,_0x205b4d['node'],M['BLACK'],_0x418174,_0x5278ff);}},_0x1d7ebd=function(_0x48071a){let _0x54f20f=null,_0x5f1648=null,_0xae7f7f=_0x32fa85['length'];const _0x45a46a=function(_0x515e73,_0x27ee7e){const _0x245818=_0xae7f7f-_0x515e73,_0x33e391=_0xae7f7f;_0xae7f7f-=_0x515e73;const _0x2c7562=_0x1d2c96(_0x245818+0x1,_0x33e391),_0x2e6f29=_0x32fa85[_0x245818],_0x5b0ee2=_0x540307?_0x540307(_0x2e6f29):_0x2e6f29;_0x463da6(new M(_0x5b0ee2,_0x2e6f29['node'],_0x27ee7e,null,_0x2c7562));},_0x463da6=function(_0x4d540a){_0x54f20f?(_0x54f20f['left']=_0x4d540a,_0x54f20f=_0x4d540a):(_0x5f1648=_0x4d540a,_0x54f20f=_0x4d540a);};for(let _0x32be69=0x0;_0x32be69<_0x48071a['count'];++_0x32be69){const _0x147981=_0x48071a['nextBitIsOne'](),_0x5b1301=Math['pow'](0x2,_0x48071a['count']-(_0x32be69+0x1));_0x147981?_0x45a46a(_0x5b1301,M['BLACK']):(_0x45a46a(_0x5b1301,M['BLACK']),_0x45a46a(_0x5b1301,M['RED']));}return _0x5f1648;},_0x4c1b67=new Hh(_0x32fa85['length']),_0x4d2130=_0x1d7ebd(_0x4c1b67);return new B(_0x2f75ff||_0x150835,_0x4d2130);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x45a70a,_0x4fc696){this['indexes_']=_0x45a70a,this['indexSet_']=_0x4fc696;}['get'](_0x54a8cc){const _0x5dcddb=De(this['indexes_'],_0x54a8cc);if(!_0x5dcddb)throw new Error('No\x20index\x20defined\x20for\x20'+_0x54a8cc);return _0x5dcddb instanceof B?_0x5dcddb:null;}['hasIndex'](_0x3f98b2){return J(this['indexSet_'],_0x3f98b2['toString']());}['addIndex'](_0x2ea9e0,_0x41a282){f(_0x2ea9e0!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x4e2606=[];let _0x544f87=!0x1;const _0x3ff353=_0x41a282['getIterator'](E['Wrap']);let _0x1136a8=_0x3ff353['getNext']();for(;_0x1136a8;)_0x544f87=_0x544f87||_0x2ea9e0['isDefinedOn'](_0x1136a8['node']),_0x4e2606['push'](_0x1136a8),_0x1136a8=_0x3ff353['getNext']();let _0x1efaa6;_0x544f87?_0x1efaa6=fn(_0x4e2606,_0x2ea9e0['getCompare']()):_0x1efaa6=ze;const _0x8e0243=_0x2ea9e0['toString'](),_0x1bb112={...this['indexSet_']};_0x1bb112[_0x8e0243]=_0x2ea9e0;const _0x596895={...this['indexes_']};return _0x596895[_0x8e0243]=_0x1efaa6,new te(_0x596895,_0x1bb112);}['addToIndexes'](_0x33cefa,_0x9030e2){const _0x444f8c=hn(this['indexes_'],(_0x38fe8c,_0x5b7b42)=>{const _0x2adc00=De(this['indexSet_'],_0x5b7b42);if(f(_0x2adc00,'Missing\x20index\x20implementation\x20for\x20'+_0x5b7b42),_0x38fe8c===ze){if(_0x2adc00['isDefinedOn'](_0x33cefa['node'])){const _0x3cacaf=[],_0x398925=_0x9030e2['getIterator'](E['Wrap']);let _0x12715d=_0x398925['getNext']();for(;_0x12715d;)_0x12715d['name']!==_0x33cefa['name']&&_0x3cacaf['push'](_0x12715d),_0x12715d=_0x398925['getNext']();return _0x3cacaf['push'](_0x33cefa),fn(_0x3cacaf,_0x2adc00['getCompare']());}else return ze;}else{const _0x52ed94=_0x9030e2['get'](_0x33cefa['name']);let _0x53e8ee=_0x38fe8c;return _0x52ed94&&(_0x53e8ee=_0x53e8ee['remove'](new E(_0x33cefa['name'],_0x52ed94))),_0x53e8ee['insert'](_0x33cefa,_0x33cefa['node']);}});return new te(_0x444f8c,this['indexSet_']);}['removeFromIndexes'](_0x3f1256,_0x43c299){const _0x2b2a9c=hn(this['indexes_'],_0x3f19d1=>{if(_0x3f19d1===ze)return _0x3f19d1;{const _0x258ec7=_0x43c299['get'](_0x3f1256['name']);return _0x258ec7?_0x3f19d1['remove'](new E(_0x3f1256['name'],_0x258ec7)):_0x3f19d1;}});return new te(_0x2b2a9c,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x47bf5c,_0x30f182,_0x454c88){this['children_']=_0x47bf5c,this['priorityNode_']=_0x30f182,this['indexMap_']=_0x454c88,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x113dd7){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x113dd7,this['indexMap_']);}['getImmediateChild'](_0x854718){if(_0x854718==='.priority')return this['getPriority']();{const _0x3260c6=this['children_']['get'](_0x854718);return _0x3260c6===null?mt:_0x3260c6;}}['getChild'](_0x56345c){const _0x103241=y(_0x56345c);return _0x103241===null?this:this['getImmediateChild'](_0x103241)['getChild'](b(_0x56345c));}['hasChild'](_0x3720e0){return this['children_']['get'](_0x3720e0)!==null;}['updateImmediateChild'](_0x50a124,_0x5e991f){if(f(_0x5e991f,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x50a124==='.priority')return this['updatePriority'](_0x5e991f);{const _0x4f4947=new E(_0x50a124,_0x5e991f);let _0x2be09b,_0xd67657;_0x5e991f['isEmpty']()?(_0x2be09b=this['children_']['remove'](_0x50a124),_0xd67657=this['indexMap_']['removeFromIndexes'](_0x4f4947,this['children_'])):(_0x2be09b=this['children_']['insert'](_0x50a124,_0x5e991f),_0xd67657=this['indexMap_']['addToIndexes'](_0x4f4947,this['children_']));const _0x3bae8d=_0x2be09b['isEmpty']()?mt:this['priorityNode_'];return new g(_0x2be09b,_0x3bae8d,_0xd67657);}}['updateChild'](_0x46e335,_0x34f886){const _0x3cb27d=y(_0x46e335);if(_0x3cb27d===null)return _0x34f886;{f(y(_0x46e335)!=='.priority'||we(_0x46e335)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x81bdf3=this['getImmediateChild'](_0x3cb27d)['updateChild'](b(_0x46e335),_0x34f886);return this['updateImmediateChild'](_0x3cb27d,_0x81bdf3);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x4aa257){if(this['isEmpty']())return null;const _0x4fc244={};let _0x3e8e0f=0x0,_0x468b89=0x0,_0xce67fb=!0x0;if(this['forEachChild'](R,(_0x42c30d,_0x42da93)=>{_0x4fc244[_0x42c30d]=_0x42da93['val'](_0x4aa257),_0x3e8e0f++,_0xce67fb&&g['INTEGER_REGEXP_']['test'](_0x42c30d)?_0x468b89=Math['max'](_0x468b89,Number(_0x42c30d)):_0xce67fb=!0x1;}),!_0x4aa257&&_0xce67fb&&_0x468b89<0x2*_0x3e8e0f){const _0x155fbf=[];for(const _0x3c41f9 in _0x4fc244)_0x155fbf[_0x3c41f9]=_0x4fc244[_0x3c41f9];return _0x155fbf;}else return _0x4aa257&&!this['getPriority']()['isEmpty']()&&(_0x4fc244['.priority']=this['getPriority']()['val']()),_0x4fc244;}['hash'](){if(this['lazyHash_']===null){let _0x11cb4a='';this['getPriority']()['isEmpty']()||(_0x11cb4a+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x18b608,_0x39dd59)=>{const _0x4bd8f7=_0x39dd59['hash']();_0x4bd8f7!==''&&(_0x11cb4a+=':'+_0x18b608+':'+_0x4bd8f7);}),this['lazyHash_']=_0x11cb4a===''?'':ro(_0x11cb4a);}return this['lazyHash_'];}['getPredecessorChildName'](_0x3b707d,_0x261078,_0xa1f981){const _0x17f232=this['resolveIndex_'](_0xa1f981);if(_0x17f232){const _0x2facc6=_0x17f232['getPredecessorKey'](new E(_0x3b707d,_0x261078));return _0x2facc6?_0x2facc6['name']:null;}else return this['children_']['getPredecessorKey'](_0x3b707d);}['getFirstChildName'](_0x240c72){const _0x49848a=this['resolveIndex_'](_0x240c72);if(_0x49848a){const _0x348dcf=_0x49848a['minKey']();return _0x348dcf&&_0x348dcf['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x11e886){const _0x37fd82=this['getFirstChildName'](_0x11e886);return _0x37fd82?new E(_0x37fd82,this['children_']['get'](_0x37fd82)):null;}['getLastChildName'](_0x32ccab){const _0x40d379=this['resolveIndex_'](_0x32ccab);if(_0x40d379){const _0x1eeedf=_0x40d379['maxKey']();return _0x1eeedf&&_0x1eeedf['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x2c6018){const _0x45d2ff=this['getLastChildName'](_0x2c6018);return _0x45d2ff?new E(_0x45d2ff,this['children_']['get'](_0x45d2ff)):null;}['forEachChild'](_0x9267bc,_0x26c4a6){const _0xa7f79b=this['resolveIndex_'](_0x9267bc);return _0xa7f79b?_0xa7f79b['inorderTraversal'](_0x2cf335=>_0x26c4a6(_0x2cf335['name'],_0x2cf335['node'])):this['children_']['inorderTraversal'](_0x26c4a6);}['getIterator'](_0xd8f3d6){return this['getIteratorFrom'](_0xd8f3d6['minPost'](),_0xd8f3d6);}['getIteratorFrom'](_0x4a349d,_0x1ae13c){const _0x101440=this['resolveIndex_'](_0x1ae13c);if(_0x101440)return _0x101440['getIteratorFrom'](_0x4a349d,_0x205978=>_0x205978);{const _0x4e316a=this['children_']['getIteratorFrom'](_0x4a349d['name'],E['Wrap']);let _0x4bd0ae=_0x4e316a['peek']();for(;_0x4bd0ae!=null&&_0x1ae13c['compare'](_0x4bd0ae,_0x4a349d)<0x0;)_0x4e316a['getNext'](),_0x4bd0ae=_0x4e316a['peek']();return _0x4e316a;}}['getReverseIterator'](_0x4aa5e7){return this['getReverseIteratorFrom'](_0x4aa5e7['maxPost'](),_0x4aa5e7);}['getReverseIteratorFrom'](_0xdacaf8,_0x12c547){const _0xd37f45=this['resolveIndex_'](_0x12c547);if(_0xd37f45)return _0xd37f45['getReverseIteratorFrom'](_0xdacaf8,_0x1abf96=>_0x1abf96);{const _0xb903f7=this['children_']['getReverseIteratorFrom'](_0xdacaf8['name'],E['Wrap']);let _0x3a361d=_0xb903f7['peek']();for(;_0x3a361d!=null&&_0x12c547['compare'](_0x3a361d,_0xdacaf8)>0x0;)_0xb903f7['getNext'](),_0x3a361d=_0xb903f7['peek']();return _0xb903f7;}}['compareTo'](_0x39c4b2){return this['isEmpty']()?_0x39c4b2['isEmpty']()?0x0:-0x1:_0x39c4b2['isLeafNode']()||_0x39c4b2['isEmpty']()?0x1:_0x39c4b2===$t?-0x1:0x0;}['withIndex'](_0x1046f9){if(_0x1046f9===ye||this['indexMap_']['hasIndex'](_0x1046f9))return this;{const _0x61fab1=this['indexMap_']['addIndex'](_0x1046f9,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x61fab1);}}['isIndexed'](_0x3043ac){return _0x3043ac===ye||this['indexMap_']['hasIndex'](_0x3043ac);}['equals'](_0x54563c){if(_0x54563c===this)return!0x0;if(_0x54563c['isLeafNode']())return!0x1;{const _0x5056d4=_0x54563c;if(this['getPriority']()['equals'](_0x5056d4['getPriority']())){if(this['children_']['count']()===_0x5056d4['children_']['count']()){const _0x4298a4=this['getIterator'](R),_0x2be688=_0x5056d4['getIterator'](R);let _0x643375=_0x4298a4['getNext'](),_0xa9ea68=_0x2be688['getNext']();for(;_0x643375&&_0xa9ea68;){if(_0x643375['name']!==_0xa9ea68['name']||!_0x643375['node']['equals'](_0xa9ea68['node']))return!0x1;_0x643375=_0x4298a4['getNext'](),_0xa9ea68=_0x2be688['getNext']();}return _0x643375===null&&_0xa9ea68===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x47f00c){return _0x47f00c===ye?null:this['indexMap_']['get'](_0x47f00c['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x6bc181){return _0x6bc181===this?0x0:0x1;}['equals'](_0x13ffda){return _0x13ffda===this;}['getPriority'](){return this;}['getImmediateChild'](_0x4e75bb){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x34bdb5,_0x9a05bc=null){if(_0x34bdb5===null)return g['EMPTY_NODE'];if(typeof _0x34bdb5=='object'&&'.priority'in _0x34bdb5&&(_0x9a05bc=_0x34bdb5['.priority']),f(_0x9a05bc===null||typeof _0x9a05bc=='string'||typeof _0x9a05bc=='number'||typeof _0x9a05bc=='object'&&'.sv'in _0x9a05bc,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x9a05bc),typeof _0x34bdb5=='object'&&'.value'in _0x34bdb5&&_0x34bdb5['.value']!==null&&(_0x34bdb5=_0x34bdb5['.value']),typeof _0x34bdb5!='object'||'.sv'in _0x34bdb5){const _0x41dd18=_0x34bdb5;return new D(_0x41dd18,P(_0x9a05bc));}if(!(_0x34bdb5 instanceof Array)&&Gh){const _0x2fb829=[];let _0x1dcde0=!0x1;if(x(_0x34bdb5,(_0x4bae28,_0x341d8d)=>{if(_0x4bae28['substring'](0x0,0x1)!=='.'){const _0x34849f=P(_0x341d8d);_0x34849f['isEmpty']()||(_0x1dcde0=_0x1dcde0||!_0x34849f['getPriority']()['isEmpty'](),_0x2fb829['push'](new E(_0x4bae28,_0x34849f)));}}),_0x2fb829['length']===0x0)return g['EMPTY_NODE'];const _0x595bf2=fn(_0x2fb829,xh,_0x1e6766=>_0x1e6766['name'],Yi);if(_0x1dcde0){const _0x3d6cfb=fn(_0x2fb829,R['getCompare']());return new g(_0x595bf2,P(_0x9a05bc),new te({'.priority':_0x3d6cfb},{'.priority':R}));}else return new g(_0x595bf2,P(_0x9a05bc),te['Default']);}else{let _0x2320a9=g['EMPTY_NODE'];return x(_0x34bdb5,(_0x89f73b,_0x994052)=>{if(J(_0x34bdb5,_0x89f73b)&&_0x89f73b['substring'](0x0,0x1)!=='.'){const _0x214a81=P(_0x994052);(_0x214a81['isLeafNode']()||!_0x214a81['isEmpty']())&&(_0x2320a9=_0x2320a9['updateImmediateChild'](_0x89f73b,_0x214a81));}}),_0x2320a9['updatePriority'](P(_0x9a05bc));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x38370a){super(),this['indexPath_']=_0x38370a,f(!v(_0x38370a)&&y(_0x38370a)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x5ebd9d){return _0x5ebd9d['getChild'](this['indexPath_']);}['isDefinedOn'](_0x49a9aa){return!_0x49a9aa['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x551c64,_0x498d7c){const _0x2525ca=this['extractChild'](_0x551c64['node']),_0x23ea24=this['extractChild'](_0x498d7c['node']),_0x18c04b=_0x2525ca['compareTo'](_0x23ea24);return _0x18c04b===0x0?He(_0x551c64['name'],_0x498d7c['name']):_0x18c04b;}['makePost'](_0x251ee0,_0x16cc6f){const _0x3f055c=P(_0x251ee0),_0x43f829=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x3f055c);return new E(_0x16cc6f,_0x43f829);}['maxPost'](){const _0x25a005=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x25a005);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x199419,_0x2f3f41){const _0x148b9b=_0x199419['node']['compareTo'](_0x2f3f41['node']);return _0x148b9b===0x0?He(_0x199419['name'],_0x2f3f41['name']):_0x148b9b;}['isDefinedOn'](_0x37d210){return!0x0;}['indexedValueChanged'](_0x1dd203,_0x57b294){return!_0x1dd203['equals'](_0x57b294);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x29f569,_0xcbe71f){const _0x2fe521=P(_0x29f569);return new E(_0xcbe71f,_0x2fe521);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x276932){return{'type':'value','snapshotNode':_0x276932};}function et(_0x4fb39f,_0x526a9a){return{'type':'child_added','snapshotNode':_0x526a9a,'childName':_0x4fb39f};}function Ot(_0x40d570,_0x5b0ffa){return{'type':'child_removed','snapshotNode':_0x5b0ffa,'childName':_0x40d570};}function Dt(_0x3d07ab,_0x55d727,_0x5bf4d6){return{'type':'child_changed','snapshotNode':_0x55d727,'childName':_0x3d07ab,'oldSnap':_0x5bf4d6};}function zh(_0x48fa2a,_0x429cd7){return{'type':'child_moved','snapshotNode':_0x429cd7,'childName':_0x48fa2a};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x551bef){this['index_']=_0x551bef;}['updateChild'](_0x2cc12f,_0x2cbf4a,_0xecacad,_0x222659,_0x4dfa6a,_0x1ad841){f(_0x2cc12f['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x3a381e=_0x2cc12f['getImmediateChild'](_0x2cbf4a);return _0x3a381e['getChild'](_0x222659)['equals'](_0xecacad['getChild'](_0x222659))&&_0x3a381e['isEmpty']()===_0xecacad['isEmpty']()||(_0x1ad841!=null&&(_0xecacad['isEmpty']()?_0x2cc12f['hasChild'](_0x2cbf4a)?_0x1ad841['trackChildChange'](Ot(_0x2cbf4a,_0x3a381e)):f(_0x2cc12f['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x3a381e['isEmpty']()?_0x1ad841['trackChildChange'](et(_0x2cbf4a,_0xecacad)):_0x1ad841['trackChildChange'](Dt(_0x2cbf4a,_0xecacad,_0x3a381e))),_0x2cc12f['isLeafNode']()&&_0xecacad['isEmpty']())?_0x2cc12f:_0x2cc12f['updateImmediateChild'](_0x2cbf4a,_0xecacad)['withIndex'](this['index_']);}['updateFullNode'](_0x55ee95,_0x30ea7e,_0x4db198){return _0x4db198!=null&&(_0x55ee95['isLeafNode']()||_0x55ee95['forEachChild'](R,(_0xb5393f,_0x548e80)=>{_0x30ea7e['hasChild'](_0xb5393f)||_0x4db198['trackChildChange'](Ot(_0xb5393f,_0x548e80));}),_0x30ea7e['isLeafNode']()||_0x30ea7e['forEachChild'](R,(_0x462e57,_0x39d89a)=>{if(_0x55ee95['hasChild'](_0x462e57)){const _0x213299=_0x55ee95['getImmediateChild'](_0x462e57);_0x213299['equals'](_0x39d89a)||_0x4db198['trackChildChange'](Dt(_0x462e57,_0x39d89a,_0x213299));}else _0x4db198['trackChildChange'](et(_0x462e57,_0x39d89a));})),_0x30ea7e['withIndex'](this['index_']);}['updatePriority'](_0x56790a,_0x194dbb){return _0x56790a['isEmpty']()?g['EMPTY_NODE']:_0x56790a['updatePriority'](_0x194dbb);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x1d746e){this['indexedFilter_']=new Ji(_0x1d746e['getIndex']()),this['index_']=_0x1d746e['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x1d746e),this['endPost_']=Mt['getEndPost_'](_0x1d746e),this['startIsInclusive_']=!_0x1d746e['startAfterSet_'],this['endIsInclusive_']=!_0x1d746e['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x5c9f58){const _0x4495d4=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x5c9f58)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x5c9f58)<0x0,_0x5ebbf1=this['endIsInclusive_']?this['index_']['compare'](_0x5c9f58,this['getEndPost']())<=0x0:this['index_']['compare'](_0x5c9f58,this['getEndPost']())<0x0;return _0x4495d4&&_0x5ebbf1;}['updateChild'](_0x5691a1,_0x53b951,_0x5a41f6,_0x431c22,_0x2181e6,_0x42e6ff){return this['matches'](new E(_0x53b951,_0x5a41f6))||(_0x5a41f6=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x5691a1,_0x53b951,_0x5a41f6,_0x431c22,_0x2181e6,_0x42e6ff);}['updateFullNode'](_0x565533,_0x3018a6,_0x375924){_0x3018a6['isLeafNode']()&&(_0x3018a6=g['EMPTY_NODE']);let _0x370a7c=_0x3018a6['withIndex'](this['index_']);_0x370a7c=_0x370a7c['updatePriority'](g['EMPTY_NODE']);const _0x400cd5=this;return _0x3018a6['forEachChild'](R,(_0x2245c5,_0x333bc8)=>{_0x400cd5['matches'](new E(_0x2245c5,_0x333bc8))||(_0x370a7c=_0x370a7c['updateImmediateChild'](_0x2245c5,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x565533,_0x370a7c,_0x375924);}['updatePriority'](_0x588b65,_0x50072e){return _0x588b65;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x438f6f){if(_0x438f6f['hasStart']()){const _0x8e4832=_0x438f6f['getIndexStartName']();return _0x438f6f['getIndex']()['makePost'](_0x438f6f['getIndexStartValue'](),_0x8e4832);}else return _0x438f6f['getIndex']()['minPost']();}static['getEndPost_'](_0x3f5960){if(_0x3f5960['hasEnd']()){const _0x5f2383=_0x3f5960['getIndexEndName']();return _0x3f5960['getIndex']()['makePost'](_0x3f5960['getIndexEndValue'](),_0x5f2383);}else return _0x3f5960['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x36ac53){this['withinDirectionalStart']=_0x29bc9b=>this['reverse_']?this['withinEndPost'](_0x29bc9b):this['withinStartPost'](_0x29bc9b),this['withinDirectionalEnd']=_0x292295=>this['reverse_']?this['withinStartPost'](_0x292295):this['withinEndPost'](_0x292295),this['withinStartPost']=_0x1d18c8=>{const _0x41f822=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x1d18c8);return this['startIsInclusive_']?_0x41f822<=0x0:_0x41f822<0x0;},this['withinEndPost']=_0x33c41e=>{const _0x444551=this['index_']['compare'](_0x33c41e,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x444551<=0x0:_0x444551<0x0;},this['rangedFilter_']=new Mt(_0x36ac53),this['index_']=_0x36ac53['getIndex'](),this['limit_']=_0x36ac53['getLimit'](),this['reverse_']=!_0x36ac53['isViewFromLeft'](),this['startIsInclusive_']=!_0x36ac53['startAfterSet_'],this['endIsInclusive_']=!_0x36ac53['endBeforeSet_'];}['updateChild'](_0x494757,_0x3c96de,_0x3ca904,_0x481465,_0x5a58b0,_0x6b93cc){return this['rangedFilter_']['matches'](new E(_0x3c96de,_0x3ca904))||(_0x3ca904=g['EMPTY_NODE']),_0x494757['getImmediateChild'](_0x3c96de)['equals'](_0x3ca904)?_0x494757:_0x494757['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x494757,_0x3c96de,_0x3ca904,_0x481465,_0x5a58b0,_0x6b93cc):this['fullLimitUpdateChild_'](_0x494757,_0x3c96de,_0x3ca904,_0x5a58b0,_0x6b93cc);}['updateFullNode'](_0x57589d,_0x543478,_0xf0fd22){let _0x8d5fb1;if(_0x543478['isLeafNode']()||_0x543478['isEmpty']())_0x8d5fb1=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x543478['numChildren']()&&_0x543478['isIndexed'](this['index_'])){_0x8d5fb1=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x552dcf;this['reverse_']?_0x552dcf=_0x543478['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x552dcf=_0x543478['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x2d4fda=0x0;for(;_0x552dcf['hasNext']()&&_0x2d4fda<this['limit_'];){const _0x4ae883=_0x552dcf['getNext']();if(this['withinDirectionalStart'](_0x4ae883)){if(this['withinDirectionalEnd'](_0x4ae883))_0x8d5fb1=_0x8d5fb1['updateImmediateChild'](_0x4ae883['name'],_0x4ae883['node']),_0x2d4fda++;else break;}else continue;}}else{_0x8d5fb1=_0x543478['withIndex'](this['index_']),_0x8d5fb1=_0x8d5fb1['updatePriority'](g['EMPTY_NODE']);let _0x4ba8ce;this['reverse_']?_0x4ba8ce=_0x8d5fb1['getReverseIterator'](this['index_']):_0x4ba8ce=_0x8d5fb1['getIterator'](this['index_']);let _0xbfd3df=0x0;for(;_0x4ba8ce['hasNext']();){const _0x2fbad3=_0x4ba8ce['getNext']();_0xbfd3df<this['limit_']&&this['withinDirectionalStart'](_0x2fbad3)&&this['withinDirectionalEnd'](_0x2fbad3)?_0xbfd3df++:_0x8d5fb1=_0x8d5fb1['updateImmediateChild'](_0x2fbad3['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x57589d,_0x8d5fb1,_0xf0fd22);}['updatePriority'](_0xd280f3,_0x212cd5){return _0xd280f3;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x5a974a,_0xbdb677,_0x5b2dea,_0x5e28f7,_0x3d1409){let _0x32e18b;if(this['reverse_']){const _0x17ed0c=this['index_']['getCompare']();_0x32e18b=(_0x17309d,_0x4f9525)=>_0x17ed0c(_0x4f9525,_0x17309d);}else _0x32e18b=this['index_']['getCompare']();const _0x1c0a2c=_0x5a974a;f(_0x1c0a2c['numChildren']()===this['limit_'],'');const _0x49b5d8=new E(_0xbdb677,_0x5b2dea),_0x3543f2=this['reverse_']?_0x1c0a2c['getFirstChild'](this['index_']):_0x1c0a2c['getLastChild'](this['index_']),_0x440ce5=this['rangedFilter_']['matches'](_0x49b5d8);if(_0x1c0a2c['hasChild'](_0xbdb677)){const _0x544920=_0x1c0a2c['getImmediateChild'](_0xbdb677);let _0x44b72a=_0x5e28f7['getChildAfterChild'](this['index_'],_0x3543f2,this['reverse_']);for(;_0x44b72a!=null&&(_0x44b72a['name']===_0xbdb677||_0x1c0a2c['hasChild'](_0x44b72a['name']));)_0x44b72a=_0x5e28f7['getChildAfterChild'](this['index_'],_0x44b72a,this['reverse_']);const _0x1c37e5=_0x44b72a==null?0x1:_0x32e18b(_0x44b72a,_0x49b5d8);if(_0x440ce5&&!_0x5b2dea['isEmpty']()&&_0x1c37e5>=0x0)return _0x3d1409!=null&&_0x3d1409['trackChildChange'](Dt(_0xbdb677,_0x5b2dea,_0x544920)),_0x1c0a2c['updateImmediateChild'](_0xbdb677,_0x5b2dea);{_0x3d1409!=null&&_0x3d1409['trackChildChange'](Ot(_0xbdb677,_0x544920));const _0xcc5648=_0x1c0a2c['updateImmediateChild'](_0xbdb677,g['EMPTY_NODE']);return _0x44b72a!=null&&this['rangedFilter_']['matches'](_0x44b72a)?(_0x3d1409!=null&&_0x3d1409['trackChildChange'](et(_0x44b72a['name'],_0x44b72a['node'])),_0xcc5648['updateImmediateChild'](_0x44b72a['name'],_0x44b72a['node'])):_0xcc5648;}}else return _0x5b2dea['isEmpty']()?_0x5a974a:_0x440ce5&&_0x32e18b(_0x3543f2,_0x49b5d8)>=0x0?(_0x3d1409!=null&&(_0x3d1409['trackChildChange'](Ot(_0x3543f2['name'],_0x3543f2['node'])),_0x3d1409['trackChildChange'](et(_0xbdb677,_0x5b2dea))),_0x1c0a2c['updateImmediateChild'](_0xbdb677,_0x5b2dea)['updateImmediateChild'](_0x3543f2['name'],g['EMPTY_NODE'])):_0x5a974a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x391d6d=new Xi();return _0x391d6d['limitSet_']=this['limitSet_'],_0x391d6d['limit_']=this['limit_'],_0x391d6d['startSet_']=this['startSet_'],_0x391d6d['startAfterSet_']=this['startAfterSet_'],_0x391d6d['indexStartValue_']=this['indexStartValue_'],_0x391d6d['startNameSet_']=this['startNameSet_'],_0x391d6d['indexStartName_']=this['indexStartName_'],_0x391d6d['endSet_']=this['endSet_'],_0x391d6d['endBeforeSet_']=this['endBeforeSet_'],_0x391d6d['indexEndValue_']=this['indexEndValue_'],_0x391d6d['endNameSet_']=this['endNameSet_'],_0x391d6d['indexEndName_']=this['indexEndName_'],_0x391d6d['index_']=this['index_'],_0x391d6d['viewFrom_']=this['viewFrom_'],_0x391d6d;}}function Kh(_0x17e255){return _0x17e255['loadsAllData']()?new Ji(_0x17e255['getIndex']()):_0x17e255['hasLimit']()?new jh(_0x17e255):new Mt(_0x17e255);}function Yh(_0x5cffbc,_0x1a96dc){const _0x52c00f=_0x5cffbc['copy']();return _0x52c00f['limitSet_']=!0x0,_0x52c00f['limit_']=_0x1a96dc,_0x52c00f['viewFrom_']='l',_0x52c00f;}function Qh(_0x2bad4f,_0x10cdef,_0xefa5a3){const _0x1e76ef=_0x2bad4f['copy']();return _0x1e76ef['startSet_']=!0x0,_0x10cdef===void 0x0&&(_0x10cdef=null),_0x1e76ef['indexStartValue_']=_0x10cdef,_0xefa5a3!=null?(_0x1e76ef['startNameSet_']=!0x0,_0x1e76ef['indexStartName_']=_0xefa5a3):(_0x1e76ef['startNameSet_']=!0x1,_0x1e76ef['indexStartName_']=''),_0x1e76ef;}function Jh(_0x3eef5b,_0x3bfdc8,_0x589165){const _0x103f3f=_0x3eef5b['copy']();return _0x103f3f['endSet_']=!0x0,_0x3bfdc8===void 0x0&&(_0x3bfdc8=null),_0x103f3f['indexEndValue_']=_0x3bfdc8,_0x589165!==void 0x0?(_0x103f3f['endNameSet_']=!0x0,_0x103f3f['indexEndName_']=_0x589165):(_0x103f3f['endNameSet_']=!0x1,_0x103f3f['indexEndName_']=''),_0x103f3f;}function xo(_0x32250f,_0x19c310){const _0x74b109=_0x32250f['copy']();return _0x74b109['index_']=_0x19c310,_0x74b109;}function sr(_0x10ed4a){const _0x4d468d={};if(_0x10ed4a['isDefault']())return _0x4d468d;let _0x13cc88;if(_0x10ed4a['index_']===R?_0x13cc88='$priority':_0x10ed4a['index_']===Mo?_0x13cc88='$value':_0x10ed4a['index_']===ye?_0x13cc88='$key':(f(_0x10ed4a['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x13cc88=_0x10ed4a['index_']['toString']()),_0x4d468d['orderBy']=O(_0x13cc88),_0x10ed4a['startSet_']){const _0x3e42ff=_0x10ed4a['startAfterSet_']?'startAfter':'startAt';_0x4d468d[_0x3e42ff]=O(_0x10ed4a['indexStartValue_']),_0x10ed4a['startNameSet_']&&(_0x4d468d[_0x3e42ff]+=','+O(_0x10ed4a['indexStartName_']));}if(_0x10ed4a['endSet_']){const _0x3936fd=_0x10ed4a['endBeforeSet_']?'endBefore':'endAt';_0x4d468d[_0x3936fd]=O(_0x10ed4a['indexEndValue_']),_0x10ed4a['endNameSet_']&&(_0x4d468d[_0x3936fd]+=','+O(_0x10ed4a['indexEndName_']));}return _0x10ed4a['limitSet_']&&(_0x10ed4a['isViewFromLeft']()?_0x4d468d['limitToFirst']=_0x10ed4a['limit_']:_0x4d468d['limitToLast']=_0x10ed4a['limit_']),_0x4d468d;}function rr(_0xdb0154){const _0x5e26c9={};if(_0xdb0154['startSet_']&&(_0x5e26c9['sp']=_0xdb0154['indexStartValue_'],_0xdb0154['startNameSet_']&&(_0x5e26c9['sn']=_0xdb0154['indexStartName_']),_0x5e26c9['sin']=!_0xdb0154['startAfterSet_']),_0xdb0154['endSet_']&&(_0x5e26c9['ep']=_0xdb0154['indexEndValue_'],_0xdb0154['endNameSet_']&&(_0x5e26c9['en']=_0xdb0154['indexEndName_']),_0x5e26c9['ein']=!_0xdb0154['endBeforeSet_']),_0xdb0154['limitSet_']){_0x5e26c9['l']=_0xdb0154['limit_'];let _0x29a65b=_0xdb0154['viewFrom_'];_0x29a65b===''&&(_0xdb0154['isViewFromLeft']()?_0x29a65b='l':_0x29a65b='r'),_0x5e26c9['vf']=_0x29a65b;}return _0xdb0154['index_']!==R&&(_0x5e26c9['i']=_0xdb0154['index_']['toString']()),_0x5e26c9;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x18b022){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x369461,_0x5dc3de){return _0x5dc3de!==void 0x0?'tag$'+_0x5dc3de:(f(_0x369461['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x369461['_path']['toString']());}constructor(_0x24e449,_0x50d7ca,_0x885115,_0x8acd62){super(),this['repoInfo_']=_0x24e449,this['onDataUpdate_']=_0x50d7ca,this['authTokenProvider_']=_0x885115,this['appCheckTokenProvider_']=_0x8acd62,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x134898,_0x4f0367,_0x21fe7f,_0x10a492){const _0x4b57b6=_0x134898['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4b57b6+'\x20'+_0x134898['_queryIdentifier']);const _0x48d457=pn['getListenId_'](_0x134898,_0x21fe7f),_0x12e463={};this['listens_'][_0x48d457]=_0x12e463;const _0x41b033=sr(_0x134898['_queryParams']);this['restRequest_'](_0x4b57b6+'.json',_0x41b033,(_0x3b4b47,_0x2777dc)=>{let _0x3c813f=_0x2777dc;if(_0x3b4b47===0x194&&(_0x3c813f=null,_0x3b4b47=null),_0x3b4b47===null&&this['onDataUpdate_'](_0x4b57b6,_0x3c813f,!0x1,_0x21fe7f),De(this['listens_'],_0x48d457)===_0x12e463){let _0x29f59d;_0x3b4b47?_0x3b4b47===0x191?_0x29f59d='permission_denied':_0x29f59d='rest_error:'+_0x3b4b47:_0x29f59d='ok',_0x10a492(_0x29f59d,null);}});}['unlisten'](_0x3a3456,_0x529930){const _0x23bf55=pn['getListenId_'](_0x3a3456,_0x529930);delete this['listens_'][_0x23bf55];}['get'](_0xdfe14a){const _0xd1ce7b=sr(_0xdfe14a['_queryParams']),_0x49080c=_0xdfe14a['_path']['toString'](),_0x22ccdf=new ot();return this['restRequest_'](_0x49080c+'.json',_0xd1ce7b,(_0x1bf1bd,_0x33263e)=>{let _0x475596=_0x33263e;_0x1bf1bd===0x194&&(_0x475596=null,_0x1bf1bd=null),_0x1bf1bd===null?(this['onDataUpdate_'](_0x49080c,_0x475596,!0x1,null),_0x22ccdf['resolve'](_0x475596)):_0x22ccdf['reject'](new Error(_0x475596));}),_0x22ccdf['promise'];}['refreshAuthToken'](_0x480221){}['restRequest_'](_0x3bd9b2,_0x2216d4={},_0x30c128){return _0x2216d4['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x4815cc,_0x9e1dc9])=>{_0x4815cc&&_0x4815cc['accessToken']&&(_0x2216d4['auth']=_0x4815cc['accessToken']),_0x9e1dc9&&_0x9e1dc9['token']&&(_0x2216d4['ac']=_0x9e1dc9['token']);const _0x23ef8c=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x3bd9b2+'?ns='+this['repoInfo_']['namespace']+ct(_0x2216d4);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x23ef8c);const _0x24e453=new XMLHttpRequest();_0x24e453['onreadystatechange']=()=>{if(_0x30c128&&_0x24e453['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x23ef8c+'\x20received.\x20status:',_0x24e453['status'],'response:',_0x24e453['responseText']);let _0x23f1f3=null;if(_0x24e453['status']>=0xc8&&_0x24e453['status']<0x12c){try{_0x23f1f3=At(_0x24e453['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x23ef8c+':\x20'+_0x24e453['responseText']);}_0x30c128(null,_0x23f1f3);}else _0x24e453['status']!==0x191&&_0x24e453['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x23ef8c+'\x20Status:\x20'+_0x24e453['status']),_0x30c128(_0x24e453['status']);_0x30c128=null;}},_0x24e453['open']('GET',_0x23ef8c,!0x0),_0x24e453['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x25c677){return this['rootNode_']['getChild'](_0x25c677);}['updateSnapshot'](_0x79b90f,_0x5be5c9){this['rootNode_']=this['rootNode_']['updateChild'](_0x79b90f,_0x5be5c9);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x542cf4,_0x257a10,_0x5adebe){if(v(_0x257a10))_0x542cf4['value']=_0x5adebe,_0x542cf4['children']['clear']();else{if(_0x542cf4['value']!==null)_0x542cf4['value']=_0x542cf4['value']['updateChild'](_0x257a10,_0x5adebe);else{const _0xc7bcaa=y(_0x257a10);_0x542cf4['children']['has'](_0xc7bcaa)||_0x542cf4['children']['set'](_0xc7bcaa,_n());const _0x412120=_0x542cf4['children']['get'](_0xc7bcaa);_0x257a10=b(_0x257a10),Fo(_0x412120,_0x257a10,_0x5adebe);}}}function Ii(_0x2561b2,_0x93ba5d,_0x3f0aeb){_0x2561b2['value']!==null?_0x3f0aeb(_0x93ba5d,_0x2561b2['value']):Zh(_0x2561b2,(_0x46c41e,_0x240f6c)=>{const _0x3e54cf=new C(_0x93ba5d['toString']()+'/'+_0x46c41e);Ii(_0x240f6c,_0x3e54cf,_0x3f0aeb);});}function Zh(_0x254566,_0x46fc9b){_0x254566['children']['forEach']((_0x1f51b8,_0x18bf93)=>{_0x46fc9b(_0x18bf93,_0x1f51b8);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x2acb56){this['collection_']=_0x2acb56,this['last_']=null;}['get'](){const _0x1727be=this['collection_']['get'](),_0x237263={..._0x1727be};return this['last_']&&x(this['last_'],(_0x58312f,_0x2a962b)=>{_0x237263[_0x58312f]=_0x237263[_0x58312f]-_0x2a962b;}),this['last_']=_0x1727be,_0x237263;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0xff63c,_0x1b1c9a){this['server_']=_0x1b1c9a,this['statsToReport_']={},this['statsListener_']=new eu(_0xff63c);const _0x20e329=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x20e329));}['reportStats_'](){const _0x28c3a9=this['statsListener_']['get'](),_0x56045b={};let _0x48a85a=!0x1;x(_0x28c3a9,(_0xf28005,_0x2131f7)=>{_0x2131f7>0x0&&J(this['statsToReport_'],_0xf28005)&&(_0x56045b[_0xf28005]=_0x2131f7,_0x48a85a=!0x0);}),_0x48a85a&&this['server_']['reportStats'](_0x56045b),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x4807d9){_0x4807d9[_0x4807d9['OVERWRITE']=0x0]='OVERWRITE',_0x4807d9[_0x4807d9['MERGE']=0x1]='MERGE',_0x4807d9[_0x4807d9['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x4807d9[_0x4807d9['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x1ebb9a){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x1ebb9a,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x5c6c44,_0x11ed09,_0x5728f0){this['path']=_0x5c6c44,this['affectedTree']=_0x11ed09,this['revert']=_0x5728f0,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x3afbc3){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x15a17f=this['affectedTree']['subtree'](new C(_0x3afbc3));return new gn(w(),_0x15a17f,this['revert']);}}else return f(y(this['path'])===_0x3afbc3,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x1f76cd,_0x10b745){this['source']=_0x1f76cd,this['path']=_0x10b745,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0xb25fa6){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x5cb5a6,_0x342474,_0x38523e){this['source']=_0x5cb5a6,this['path']=_0x342474,this['snap']=_0x38523e,this['type']=j['OVERWRITE'];}['operationForChild'](_0x5b98a8){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x5b98a8)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x3b9f3a,_0x180e31,_0x47da83){this['source']=_0x3b9f3a,this['path']=_0x180e31,this['children']=_0x47da83,this['type']=j['MERGE'];}['operationForChild'](_0x429343){if(v(this['path'])){const _0x7c8ca1=this['children']['subtree'](new C(_0x429343));return _0x7c8ca1['isEmpty']()?null:_0x7c8ca1['value']?new Ue(this['source'],w(),_0x7c8ca1['value']):new tt(this['source'],w(),_0x7c8ca1);}else return f(y(this['path'])===_0x429343,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0xff9c29,_0x421f67,_0x59f6c5){this['node_']=_0xff9c29,this['fullyInitialized_']=_0x421f67,this['filtered_']=_0x59f6c5;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x29beb1){if(v(_0x29beb1))return this['isFullyInitialized']()&&!this['filtered_'];const _0xb600d5=y(_0x29beb1);return this['isCompleteForChild'](_0xb600d5);}['isCompleteForChild'](_0x2ba8ec){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x2ba8ec);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x4df4cf){this['query_']=_0x4df4cf,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x206ec6,_0x4da9bc,_0x54faee,_0x19a399){const _0x51d224=[],_0x14226c=[];return _0x4da9bc['forEach'](_0x2e1ee5=>{_0x2e1ee5['type']==='child_changed'&&_0x206ec6['index_']['indexedValueChanged'](_0x2e1ee5['oldSnap'],_0x2e1ee5['snapshotNode'])&&_0x14226c['push'](zh(_0x2e1ee5['childName'],_0x2e1ee5['snapshotNode']));}),yt(_0x206ec6,_0x51d224,'child_removed',_0x4da9bc,_0x19a399,_0x54faee),yt(_0x206ec6,_0x51d224,'child_added',_0x4da9bc,_0x19a399,_0x54faee),yt(_0x206ec6,_0x51d224,'child_moved',_0x14226c,_0x19a399,_0x54faee),yt(_0x206ec6,_0x51d224,'child_changed',_0x4da9bc,_0x19a399,_0x54faee),yt(_0x206ec6,_0x51d224,'value',_0x4da9bc,_0x19a399,_0x54faee),_0x51d224;}function yt(_0x1839df,_0x4fa574,_0x3b1452,_0xb11fb9,_0x21f9db,_0x346b2a){const _0x4397be=_0xb11fb9['filter'](_0x43efcf=>_0x43efcf['type']===_0x3b1452);_0x4397be['sort']((_0x293dee,_0x368a3d)=>au(_0x1839df,_0x293dee,_0x368a3d)),_0x4397be['forEach'](_0x1308ca=>{const _0x1704ab=ou(_0x1839df,_0x1308ca,_0x346b2a);_0x21f9db['forEach'](_0x1e35b2=>{_0x1e35b2['respondsTo'](_0x1308ca['type'])&&_0x4fa574['push'](_0x1e35b2['createEvent'](_0x1704ab,_0x1839df['query_']));});});}function ou(_0x363284,_0x56aff9,_0x29d545){return _0x56aff9['type']==='value'||_0x56aff9['type']==='child_removed'||(_0x56aff9['prevName']=_0x29d545['getPredecessorChildName'](_0x56aff9['childName'],_0x56aff9['snapshotNode'],_0x363284['index_'])),_0x56aff9;}function au(_0x2c76e8,_0xaa4061,_0x5dce4c){if(_0xaa4061['childName']==null||_0x5dce4c['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x6f9a=new E(_0xaa4061['childName'],_0xaa4061['snapshotNode']),_0x124d07=new E(_0x5dce4c['childName'],_0x5dce4c['snapshotNode']);return _0x2c76e8['index_']['compare'](_0x6f9a,_0x124d07);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x23d8b2,_0x3727f7){return{'eventCache':_0x23d8b2,'serverCache':_0x3727f7};}function Tt(_0x2541ea,_0x34263d,_0x1ee67c,_0x2ecb22){return Mn(new Ce(_0x34263d,_0x1ee67c,_0x2ecb22),_0x2541ea['serverCache']);}function Uo(_0x4ec640,_0x1f4ae4,_0x19d1fc,_0x18ab89){return Mn(_0x4ec640['eventCache'],new Ce(_0x1f4ae4,_0x19d1fc,_0x18ab89));}function mn(_0x4ad855){return _0x4ad855['eventCache']['isFullyInitialized']()?_0x4ad855['eventCache']['getNode']():null;}function We(_0x28f9ed){return _0x28f9ed['serverCache']['isFullyInitialized']()?_0x28f9ed['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x562208){let _0x3da602=new S(null);return x(_0x562208,(_0x1a6d35,_0x22821e)=>{_0x3da602=_0x3da602['set'](new C(_0x1a6d35),_0x22821e);}),_0x3da602;}constructor(_0x34340d,_0x40871d=cu()){this['value']=_0x34340d,this['children']=_0x40871d;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x37fb78,_0x4fcec8){if(this['value']!=null&&_0x4fcec8(this['value']))return{'path':w(),'value':this['value']};if(v(_0x37fb78))return null;{const _0x476610=y(_0x37fb78),_0x17761d=this['children']['get'](_0x476610);if(_0x17761d!==null){const _0xc48188=_0x17761d['findRootMostMatchingPathAndValue'](b(_0x37fb78),_0x4fcec8);return _0xc48188!=null?{'path':k(new C(_0x476610),_0xc48188['path']),'value':_0xc48188['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x1ce726){return this['findRootMostMatchingPathAndValue'](_0x1ce726,()=>!0x0);}['subtree'](_0xc0844f){if(v(_0xc0844f))return this;{const _0x283af7=y(_0xc0844f),_0x513bab=this['children']['get'](_0x283af7);return _0x513bab!==null?_0x513bab['subtree'](b(_0xc0844f)):new S(null);}}['set'](_0xa05f95,_0x379ff3){if(v(_0xa05f95))return new S(_0x379ff3,this['children']);{const _0x24666c=y(_0xa05f95),_0x3a963a=(this['children']['get'](_0x24666c)||new S(null))['set'](b(_0xa05f95),_0x379ff3),_0x36cb63=this['children']['insert'](_0x24666c,_0x3a963a);return new S(this['value'],_0x36cb63);}}['remove'](_0x5a856c){if(v(_0x5a856c))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x3ff372=y(_0x5a856c),_0x101fa2=this['children']['get'](_0x3ff372);if(_0x101fa2){const _0x4c54d2=_0x101fa2['remove'](b(_0x5a856c));let _0x2138de;return _0x4c54d2['isEmpty']()?_0x2138de=this['children']['remove'](_0x3ff372):_0x2138de=this['children']['insert'](_0x3ff372,_0x4c54d2),this['value']===null&&_0x2138de['isEmpty']()?new S(null):new S(this['value'],_0x2138de);}else return this;}}['get'](_0x578747){if(v(_0x578747))return this['value'];{const _0x14744d=y(_0x578747),_0x5e0475=this['children']['get'](_0x14744d);return _0x5e0475?_0x5e0475['get'](b(_0x578747)):null;}}['setTree'](_0x560412,_0x1f00d5){if(v(_0x560412))return _0x1f00d5;{const _0x2c8ab0=y(_0x560412),_0x47c6fd=(this['children']['get'](_0x2c8ab0)||new S(null))['setTree'](b(_0x560412),_0x1f00d5);let _0x549152;return _0x47c6fd['isEmpty']()?_0x549152=this['children']['remove'](_0x2c8ab0):_0x549152=this['children']['insert'](_0x2c8ab0,_0x47c6fd),new S(this['value'],_0x549152);}}['fold'](_0x4533ed){return this['fold_'](w(),_0x4533ed);}['fold_'](_0x2b9ffc,_0x16cd7b){const _0xf64f85={};return this['children']['inorderTraversal']((_0x10bfba,_0x23a627)=>{_0xf64f85[_0x10bfba]=_0x23a627['fold_'](k(_0x2b9ffc,_0x10bfba),_0x16cd7b);}),_0x16cd7b(_0x2b9ffc,this['value'],_0xf64f85);}['findOnPath'](_0x5bc496,_0x218ef7){return this['findOnPath_'](_0x5bc496,w(),_0x218ef7);}['findOnPath_'](_0x109403,_0x4b1dd0,_0x38a1fe){const _0x11eb14=this['value']?_0x38a1fe(_0x4b1dd0,this['value']):!0x1;if(_0x11eb14)return _0x11eb14;if(v(_0x109403))return null;{const _0x176c54=y(_0x109403),_0x2b51e9=this['children']['get'](_0x176c54);return _0x2b51e9?_0x2b51e9['findOnPath_'](b(_0x109403),k(_0x4b1dd0,_0x176c54),_0x38a1fe):null;}}['foreachOnPath'](_0x16fccc,_0xa7c5a){return this['foreachOnPath_'](_0x16fccc,w(),_0xa7c5a);}['foreachOnPath_'](_0x122446,_0x24553c,_0x51edb5){if(v(_0x122446))return this;{this['value']&&_0x51edb5(_0x24553c,this['value']);const _0x16e3b2=y(_0x122446),_0x8cc1d7=this['children']['get'](_0x16e3b2);return _0x8cc1d7?_0x8cc1d7['foreachOnPath_'](b(_0x122446),k(_0x24553c,_0x16e3b2),_0x51edb5):new S(null);}}['foreach'](_0x20b620){this['foreach_'](w(),_0x20b620);}['foreach_'](_0x48a278,_0x439689){this['children']['inorderTraversal']((_0xb0a68b,_0x6459b5)=>{_0x6459b5['foreach_'](k(_0x48a278,_0xb0a68b),_0x439689);}),this['value']&&_0x439689(_0x48a278,this['value']);}['foreachChild'](_0x2659a1){this['children']['inorderTraversal']((_0x52fb13,_0x30ebc3)=>{_0x30ebc3['value']&&_0x2659a1(_0x52fb13,_0x30ebc3['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x5c7435){this['writeTree_']=_0x5c7435;}static['empty'](){return new Y(new S(null));}}function St(_0x4f4f6a,_0x275760,_0x4c2dfa){if(v(_0x275760))return new Y(new S(_0x4c2dfa));{const _0x2b47ec=_0x4f4f6a['writeTree_']['findRootMostValueAndPath'](_0x275760);if(_0x2b47ec!=null){const _0x19d9a1=_0x2b47ec['path'];let _0xebdc92=_0x2b47ec['value'];const _0x2755e6=F(_0x19d9a1,_0x275760);return _0xebdc92=_0xebdc92['updateChild'](_0x2755e6,_0x4c2dfa),new Y(_0x4f4f6a['writeTree_']['set'](_0x19d9a1,_0xebdc92));}else{const _0x16e3de=new S(_0x4c2dfa),_0x22d2b1=_0x4f4f6a['writeTree_']['setTree'](_0x275760,_0x16e3de);return new Y(_0x22d2b1);}}}function wi(_0x414d8d,_0xb42bc9,_0x3f2167){let _0x1cdeed=_0x414d8d;return x(_0x3f2167,(_0x4a5770,_0x4c5421)=>{_0x1cdeed=St(_0x1cdeed,k(_0xb42bc9,_0x4a5770),_0x4c5421);}),_0x1cdeed;}function ar(_0x5515ac,_0x3c8ba0){if(v(_0x3c8ba0))return Y['empty']();{const _0x211305=_0x5515ac['writeTree_']['setTree'](_0x3c8ba0,new S(null));return new Y(_0x211305);}}function Ci(_0x3e9f71,_0x4051ad){return $e(_0x3e9f71,_0x4051ad)!=null;}function $e(_0x1b8f4d,_0x841441){const _0x268ae3=_0x1b8f4d['writeTree_']['findRootMostValueAndPath'](_0x841441);return _0x268ae3!=null?_0x1b8f4d['writeTree_']['get'](_0x268ae3['path'])['getChild'](F(_0x268ae3['path'],_0x841441)):null;}function cr(_0x56cc47){const _0x3baa0b=[],_0x3f1e94=_0x56cc47['writeTree_']['value'];return _0x3f1e94!=null?_0x3f1e94['isLeafNode']()||_0x3f1e94['forEachChild'](R,(_0x491627,_0x364b52)=>{_0x3baa0b['push'](new E(_0x491627,_0x364b52));}):_0x56cc47['writeTree_']['children']['inorderTraversal']((_0x5d3e67,_0x2fc1c7)=>{_0x2fc1c7['value']!=null&&_0x3baa0b['push'](new E(_0x5d3e67,_0x2fc1c7['value']));}),_0x3baa0b;}function ve(_0x1b2176,_0x3f5815){if(v(_0x3f5815))return _0x1b2176;{const _0x413bd3=$e(_0x1b2176,_0x3f5815);return _0x413bd3!=null?new Y(new S(_0x413bd3)):new Y(_0x1b2176['writeTree_']['subtree'](_0x3f5815));}}function Ti(_0x11a6e0){return _0x11a6e0['writeTree_']['isEmpty']();}function nt(_0x295e3c,_0x3f50fc){return Wo(w(),_0x295e3c['writeTree_'],_0x3f50fc);}function Wo(_0x5528f3,_0x5b5e7c,_0x52a652){if(_0x5b5e7c['value']!=null)return _0x52a652['updateChild'](_0x5528f3,_0x5b5e7c['value']);{let _0x469e26=null;return _0x5b5e7c['children']['inorderTraversal']((_0x256cc9,_0x543bbd)=>{_0x256cc9==='.priority'?(f(_0x543bbd['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x469e26=_0x543bbd['value']):_0x52a652=Wo(k(_0x5528f3,_0x256cc9),_0x543bbd,_0x52a652);}),!_0x52a652['getChild'](_0x5528f3)['isEmpty']()&&_0x469e26!==null&&(_0x52a652=_0x52a652['updateChild'](k(_0x5528f3,'.priority'),_0x469e26)),_0x52a652;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x2ed636,_0x1a84d8){return $o(_0x1a84d8,_0x2ed636);}function lu(_0x84f71b,_0x56ebee,_0x3d3750,_0x1beaff,_0x523b07){f(_0x1beaff>_0x84f71b['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x523b07===void 0x0&&(_0x523b07=!0x0),_0x84f71b['allWrites']['push']({'path':_0x56ebee,'snap':_0x3d3750,'writeId':_0x1beaff,'visible':_0x523b07}),_0x523b07&&(_0x84f71b['visibleWrites']=St(_0x84f71b['visibleWrites'],_0x56ebee,_0x3d3750)),_0x84f71b['lastWriteId']=_0x1beaff;}function hu(_0x110a11,_0x13e79a,_0x5056aa,_0x5c5ad9){f(_0x5c5ad9>_0x110a11['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x110a11['allWrites']['push']({'path':_0x13e79a,'children':_0x5056aa,'writeId':_0x5c5ad9,'visible':!0x0}),_0x110a11['visibleWrites']=wi(_0x110a11['visibleWrites'],_0x13e79a,_0x5056aa),_0x110a11['lastWriteId']=_0x5c5ad9;}function uu(_0x379804,_0x5049a2){for(let _0x55df7c=0x0;_0x55df7c<_0x379804['allWrites']['length'];_0x55df7c++){const _0x24eeac=_0x379804['allWrites'][_0x55df7c];if(_0x24eeac['writeId']===_0x5049a2)return _0x24eeac;}return null;}function du(_0x58ca8d,_0x36bc3c){const _0x5868f9=_0x58ca8d['allWrites']['findIndex'](_0x566e39=>_0x566e39['writeId']===_0x36bc3c);f(_0x5868f9>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x4ee0b4=_0x58ca8d['allWrites'][_0x5868f9];_0x58ca8d['allWrites']['splice'](_0x5868f9,0x1);let _0x2806ba=_0x4ee0b4['visible'],_0x4d070e=!0x1,_0x477b96=_0x58ca8d['allWrites']['length']-0x1;for(;_0x2806ba&&_0x477b96>=0x0;){const _0x2e3d0b=_0x58ca8d['allWrites'][_0x477b96];_0x2e3d0b['visible']&&(_0x477b96>=_0x5868f9&&fu(_0x2e3d0b,_0x4ee0b4['path'])?_0x2806ba=!0x1:G(_0x4ee0b4['path'],_0x2e3d0b['path'])&&(_0x4d070e=!0x0)),_0x477b96--;}if(_0x2806ba){if(_0x4d070e)return pu(_0x58ca8d),!0x0;if(_0x4ee0b4['snap'])_0x58ca8d['visibleWrites']=ar(_0x58ca8d['visibleWrites'],_0x4ee0b4['path']);else{const _0x2c7c4f=_0x4ee0b4['children'];x(_0x2c7c4f,_0x1983d9=>{_0x58ca8d['visibleWrites']=ar(_0x58ca8d['visibleWrites'],k(_0x4ee0b4['path'],_0x1983d9));});}return!0x0;}else return!0x1;}function fu(_0x52751c,_0x47cc6f){if(_0x52751c['snap'])return G(_0x52751c['path'],_0x47cc6f);for(const _0x50e101 in _0x52751c['children'])if(_0x52751c['children']['hasOwnProperty'](_0x50e101)&&G(k(_0x52751c['path'],_0x50e101),_0x47cc6f))return!0x0;return!0x1;}function pu(_0x3c0fce){_0x3c0fce['visibleWrites']=Bo(_0x3c0fce['allWrites'],_u,w()),_0x3c0fce['allWrites']['length']>0x0?_0x3c0fce['lastWriteId']=_0x3c0fce['allWrites'][_0x3c0fce['allWrites']['length']-0x1]['writeId']:_0x3c0fce['lastWriteId']=-0x1;}function _u(_0x1fbb45){return _0x1fbb45['visible'];}function Bo(_0x4c65d5,_0x855519,_0x4dff79){let _0x4b346c=Y['empty']();for(let _0x5f1984=0x0;_0x5f1984<_0x4c65d5['length'];++_0x5f1984){const _0x164910=_0x4c65d5[_0x5f1984];if(_0x855519(_0x164910)){const _0x4c9911=_0x164910['path'];let _0xcf14a4;if(_0x164910['snap'])G(_0x4dff79,_0x4c9911)?(_0xcf14a4=F(_0x4dff79,_0x4c9911),_0x4b346c=St(_0x4b346c,_0xcf14a4,_0x164910['snap'])):G(_0x4c9911,_0x4dff79)&&(_0xcf14a4=F(_0x4c9911,_0x4dff79),_0x4b346c=St(_0x4b346c,w(),_0x164910['snap']['getChild'](_0xcf14a4)));else{if(_0x164910['children']){if(G(_0x4dff79,_0x4c9911))_0xcf14a4=F(_0x4dff79,_0x4c9911),_0x4b346c=wi(_0x4b346c,_0xcf14a4,_0x164910['children']);else{if(G(_0x4c9911,_0x4dff79)){if(_0xcf14a4=F(_0x4c9911,_0x4dff79),v(_0xcf14a4))_0x4b346c=wi(_0x4b346c,w(),_0x164910['children']);else{const _0x444084=De(_0x164910['children'],y(_0xcf14a4));if(_0x444084){const _0x3da55d=_0x444084['getChild'](b(_0xcf14a4));_0x4b346c=St(_0x4b346c,w(),_0x3da55d);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x4b346c;}function Vo(_0xad9503,_0x13b7ec,_0x281445,_0x30bf46,_0x2ae7f0){if(!_0x30bf46&&!_0x2ae7f0){const _0x57a445=$e(_0xad9503['visibleWrites'],_0x13b7ec);if(_0x57a445!=null)return _0x57a445;{const _0x114fff=ve(_0xad9503['visibleWrites'],_0x13b7ec);if(Ti(_0x114fff))return _0x281445;if(_0x281445==null&&!Ci(_0x114fff,w()))return null;{const _0x2c838a=_0x281445||g['EMPTY_NODE'];return nt(_0x114fff,_0x2c838a);}}}else{const _0x1fc44d=ve(_0xad9503['visibleWrites'],_0x13b7ec);if(!_0x2ae7f0&&Ti(_0x1fc44d))return _0x281445;if(!_0x2ae7f0&&_0x281445==null&&!Ci(_0x1fc44d,w()))return null;{const _0x43d338=function(_0x11dd6a){return(_0x11dd6a['visible']||_0x2ae7f0)&&(!_0x30bf46||!~_0x30bf46['indexOf'](_0x11dd6a['writeId']))&&(G(_0x11dd6a['path'],_0x13b7ec)||G(_0x13b7ec,_0x11dd6a['path']));},_0x22ed64=Bo(_0xad9503['allWrites'],_0x43d338,_0x13b7ec),_0x582a52=_0x281445||g['EMPTY_NODE'];return nt(_0x22ed64,_0x582a52);}}}function gu(_0x3e3f8b,_0x16f329,_0x17476d){let _0x1fb5cd=g['EMPTY_NODE'];const _0x4b1fda=$e(_0x3e3f8b['visibleWrites'],_0x16f329);if(_0x4b1fda)return _0x4b1fda['isLeafNode']()||_0x4b1fda['forEachChild'](R,(_0x1c7efe,_0x3c76a5)=>{_0x1fb5cd=_0x1fb5cd['updateImmediateChild'](_0x1c7efe,_0x3c76a5);}),_0x1fb5cd;if(_0x17476d){const _0x4a48f4=ve(_0x3e3f8b['visibleWrites'],_0x16f329);return _0x17476d['forEachChild'](R,(_0xba866d,_0x4d1263)=>{const _0xca0e50=nt(ve(_0x4a48f4,new C(_0xba866d)),_0x4d1263);_0x1fb5cd=_0x1fb5cd['updateImmediateChild'](_0xba866d,_0xca0e50);}),cr(_0x4a48f4)['forEach'](_0x37fcd5=>{_0x1fb5cd=_0x1fb5cd['updateImmediateChild'](_0x37fcd5['name'],_0x37fcd5['node']);}),_0x1fb5cd;}else{const _0x24d730=ve(_0x3e3f8b['visibleWrites'],_0x16f329);return cr(_0x24d730)['forEach'](_0x439745=>{_0x1fb5cd=_0x1fb5cd['updateImmediateChild'](_0x439745['name'],_0x439745['node']);}),_0x1fb5cd;}}function mu(_0xa85dcc,_0x5b0b08,_0x1d449e,_0x452a27,_0x567b4a){f(_0x452a27||_0x567b4a,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x59fc75=k(_0x5b0b08,_0x1d449e);if(Ci(_0xa85dcc['visibleWrites'],_0x59fc75))return null;{const _0x80da47=ve(_0xa85dcc['visibleWrites'],_0x59fc75);return Ti(_0x80da47)?_0x567b4a['getChild'](_0x1d449e):nt(_0x80da47,_0x567b4a['getChild'](_0x1d449e));}}function yu(_0x27ac3e,_0x207471,_0x4dba58,_0xf8a816){const _0x6cd0c0=k(_0x207471,_0x4dba58),_0x3b0ea4=$e(_0x27ac3e['visibleWrites'],_0x6cd0c0);if(_0x3b0ea4!=null)return _0x3b0ea4;if(_0xf8a816['isCompleteForChild'](_0x4dba58)){const _0x1112ec=ve(_0x27ac3e['visibleWrites'],_0x6cd0c0);return nt(_0x1112ec,_0xf8a816['getNode']()['getImmediateChild'](_0x4dba58));}else return null;}function vu(_0x2b5542,_0x2bff56){return $e(_0x2b5542['visibleWrites'],_0x2bff56);}function Eu(_0x2e10e,_0x12fc36,_0x3f28a2,_0x56e91a,_0xf0960c,_0x43df6a,_0x51ffe6){let _0x4ec504;const _0x57266e=ve(_0x2e10e['visibleWrites'],_0x12fc36),_0x3107d9=$e(_0x57266e,w());if(_0x3107d9!=null)_0x4ec504=_0x3107d9;else{if(_0x3f28a2!=null)_0x4ec504=nt(_0x57266e,_0x3f28a2);else return[];}if(_0x4ec504=_0x4ec504['withIndex'](_0x51ffe6),!_0x4ec504['isEmpty']()&&!_0x4ec504['isLeafNode']()){const _0xf45f4c=[],_0x44afc8=_0x51ffe6['getCompare'](),_0x1e7e28=_0x43df6a?_0x4ec504['getReverseIteratorFrom'](_0x56e91a,_0x51ffe6):_0x4ec504['getIteratorFrom'](_0x56e91a,_0x51ffe6);let _0x2eaa46=_0x1e7e28['getNext']();for(;_0x2eaa46&&_0xf45f4c['length']<_0xf0960c;)_0x44afc8(_0x2eaa46,_0x56e91a)!==0x0&&_0xf45f4c['push'](_0x2eaa46),_0x2eaa46=_0x1e7e28['getNext']();return _0xf45f4c;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x104eff,_0x249714,_0x3c548b,_0x33c2f0){return Vo(_0x104eff['writeTree'],_0x104eff['treePath'],_0x249714,_0x3c548b,_0x33c2f0);}function ns(_0x460d0e,_0x5585fa){return gu(_0x460d0e['writeTree'],_0x460d0e['treePath'],_0x5585fa);}function lr(_0x57d8e7,_0x375c8e,_0x210d81,_0x51d568){return mu(_0x57d8e7['writeTree'],_0x57d8e7['treePath'],_0x375c8e,_0x210d81,_0x51d568);}function vn(_0x32ad16,_0x448a0a){return vu(_0x32ad16['writeTree'],k(_0x32ad16['treePath'],_0x448a0a));}function wu(_0x4a51e4,_0x5266d3,_0x4f660c,_0x5d8b88,_0x508783,_0x5cc202){return Eu(_0x4a51e4['writeTree'],_0x4a51e4['treePath'],_0x5266d3,_0x4f660c,_0x5d8b88,_0x508783,_0x5cc202);}function is(_0x286267,_0x41b9b9,_0x59f9fa){return yu(_0x286267['writeTree'],_0x286267['treePath'],_0x41b9b9,_0x59f9fa);}function Ho(_0xcdf789,_0x2a32e1){return $o(k(_0xcdf789['treePath'],_0x2a32e1),_0xcdf789['writeTree']);}function $o(_0x534c6b,_0x867ff7){return{'treePath':_0x534c6b,'writeTree':_0x867ff7};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x5abefc){const _0x231c2d=_0x5abefc['type'],_0xc7739f=_0x5abefc['childName'];f(_0x231c2d==='child_added'||_0x231c2d==='child_changed'||_0x231c2d==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0xc7739f!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x13966e=this['changeMap']['get'](_0xc7739f);if(_0x13966e){const _0x2b65bb=_0x13966e['type'];if(_0x231c2d==='child_added'&&_0x2b65bb==='child_removed')this['changeMap']['set'](_0xc7739f,Dt(_0xc7739f,_0x5abefc['snapshotNode'],_0x13966e['snapshotNode']));else{if(_0x231c2d==='child_removed'&&_0x2b65bb==='child_added')this['changeMap']['delete'](_0xc7739f);else{if(_0x231c2d==='child_removed'&&_0x2b65bb==='child_changed')this['changeMap']['set'](_0xc7739f,Ot(_0xc7739f,_0x13966e['oldSnap']));else{if(_0x231c2d==='child_changed'&&_0x2b65bb==='child_added')this['changeMap']['set'](_0xc7739f,et(_0xc7739f,_0x5abefc['snapshotNode']));else{if(_0x231c2d==='child_changed'&&_0x2b65bb==='child_changed')this['changeMap']['set'](_0xc7739f,Dt(_0xc7739f,_0x5abefc['snapshotNode'],_0x13966e['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x5abefc+'\x20occurred\x20after\x20'+_0x13966e);}}}}}else this['changeMap']['set'](_0xc7739f,_0x5abefc);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x56a3f7){return null;}['getChildAfterChild'](_0x462740,_0x4439b2,_0x131cf9){return null;}}const Go=new Tu();class ss{constructor(_0x580410,_0xd82ab4,_0x18d0fc=null){this['writes_']=_0x580410,this['viewCache_']=_0xd82ab4,this['optCompleteServerCache_']=_0x18d0fc;}['getCompleteChild'](_0x470484){const _0x3af4dd=this['viewCache_']['eventCache'];if(_0x3af4dd['isCompleteForChild'](_0x470484))return _0x3af4dd['getNode']()['getImmediateChild'](_0x470484);{const _0x5a2c79=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x470484,_0x5a2c79);}}['getChildAfterChild'](_0x20927a,_0x521b52,_0x16235c){const _0x14dd6a=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x562cb7=wu(this['writes_'],_0x14dd6a,_0x521b52,0x1,_0x16235c,_0x20927a);return _0x562cb7['length']===0x0?null:_0x562cb7[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x47c024){return{'filter':_0x47c024};}function bu(_0x17b848,_0xc2674d){f(_0xc2674d['eventCache']['getNode']()['isIndexed'](_0x17b848['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0xc2674d['serverCache']['getNode']()['isIndexed'](_0x17b848['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x57872d,_0x1bd196,_0x541882,_0xa94eb7,_0x2d92ad){const _0x51d7d8=new Cu();let _0x4999f6,_0x5854d7;if(_0x541882['type']===j['OVERWRITE']){const _0x579364=_0x541882;_0x579364['source']['fromUser']?_0x4999f6=Si(_0x57872d,_0x1bd196,_0x579364['path'],_0x579364['snap'],_0xa94eb7,_0x2d92ad,_0x51d7d8):(f(_0x579364['source']['fromServer'],'Unknown\x20source.'),_0x5854d7=_0x579364['source']['tagged']||_0x1bd196['serverCache']['isFiltered']()&&!v(_0x579364['path']),_0x4999f6=En(_0x57872d,_0x1bd196,_0x579364['path'],_0x579364['snap'],_0xa94eb7,_0x2d92ad,_0x5854d7,_0x51d7d8));}else{if(_0x541882['type']===j['MERGE']){const _0x3d4fe0=_0x541882;_0x3d4fe0['source']['fromUser']?_0x4999f6=ku(_0x57872d,_0x1bd196,_0x3d4fe0['path'],_0x3d4fe0['children'],_0xa94eb7,_0x2d92ad,_0x51d7d8):(f(_0x3d4fe0['source']['fromServer'],'Unknown\x20source.'),_0x5854d7=_0x3d4fe0['source']['tagged']||_0x1bd196['serverCache']['isFiltered'](),_0x4999f6=bi(_0x57872d,_0x1bd196,_0x3d4fe0['path'],_0x3d4fe0['children'],_0xa94eb7,_0x2d92ad,_0x5854d7,_0x51d7d8));}else{if(_0x541882['type']===j['ACK_USER_WRITE']){const _0x56dc8c=_0x541882;_0x56dc8c['revert']?_0x4999f6=Ou(_0x57872d,_0x1bd196,_0x56dc8c['path'],_0xa94eb7,_0x2d92ad,_0x51d7d8):_0x4999f6=Nu(_0x57872d,_0x1bd196,_0x56dc8c['path'],_0x56dc8c['affectedTree'],_0xa94eb7,_0x2d92ad,_0x51d7d8);}else{if(_0x541882['type']===j['LISTEN_COMPLETE'])_0x4999f6=Pu(_0x57872d,_0x1bd196,_0x541882['path'],_0xa94eb7,_0x51d7d8);else throw rt('Unknown\x20operation\x20type:\x20'+_0x541882['type']);}}}const _0x59791d=_0x51d7d8['getChanges']();return Au(_0x1bd196,_0x4999f6,_0x59791d),{'viewCache':_0x4999f6,'changes':_0x59791d};}function Au(_0x2a0ea1,_0x14b106,_0x366fd4){const _0x17abc9=_0x14b106['eventCache'];if(_0x17abc9['isFullyInitialized']()){const _0x14d61c=_0x17abc9['getNode']()['isLeafNode']()||_0x17abc9['getNode']()['isEmpty'](),_0xcb417a=mn(_0x2a0ea1);(_0x366fd4['length']>0x0||!_0x2a0ea1['eventCache']['isFullyInitialized']()||_0x14d61c&&!_0x17abc9['getNode']()['equals'](_0xcb417a)||!_0x17abc9['getNode']()['getPriority']()['equals'](_0xcb417a['getPriority']()))&&_0x366fd4['push'](Lo(mn(_0x14b106)));}}function qo(_0x548223,_0x50b81f,_0xe3e44f,_0x154fb4,_0x500582,_0x781cc3){const _0x4ff205=_0x50b81f['eventCache'];if(vn(_0x154fb4,_0xe3e44f)!=null)return _0x50b81f;{let _0x44779c,_0x57a537;if(v(_0xe3e44f)){if(f(_0x50b81f['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x50b81f['serverCache']['isFiltered']()){const _0xc318b8=We(_0x50b81f),_0x4b9c0a=_0xc318b8 instanceof g?_0xc318b8:g['EMPTY_NODE'],_0x4dec2c=ns(_0x154fb4,_0x4b9c0a);_0x44779c=_0x548223['filter']['updateFullNode'](_0x50b81f['eventCache']['getNode'](),_0x4dec2c,_0x781cc3);}else{const _0x5cb896=yn(_0x154fb4,We(_0x50b81f));_0x44779c=_0x548223['filter']['updateFullNode'](_0x50b81f['eventCache']['getNode'](),_0x5cb896,_0x781cc3);}}else{const _0x1a1b86=y(_0xe3e44f);if(_0x1a1b86==='.priority'){f(we(_0xe3e44f)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0xb5774a=_0x4ff205['getNode']();_0x57a537=_0x50b81f['serverCache']['getNode']();const _0x5d2be9=lr(_0x154fb4,_0xe3e44f,_0xb5774a,_0x57a537);_0x5d2be9!=null?_0x44779c=_0x548223['filter']['updatePriority'](_0xb5774a,_0x5d2be9):_0x44779c=_0x4ff205['getNode']();}else{const _0x353e4f=b(_0xe3e44f);let _0x3971ee;if(_0x4ff205['isCompleteForChild'](_0x1a1b86)){_0x57a537=_0x50b81f['serverCache']['getNode']();const _0x4e394d=lr(_0x154fb4,_0xe3e44f,_0x4ff205['getNode'](),_0x57a537);_0x4e394d!=null?_0x3971ee=_0x4ff205['getNode']()['getImmediateChild'](_0x1a1b86)['updateChild'](_0x353e4f,_0x4e394d):_0x3971ee=_0x4ff205['getNode']()['getImmediateChild'](_0x1a1b86);}else _0x3971ee=is(_0x154fb4,_0x1a1b86,_0x50b81f['serverCache']);_0x3971ee!=null?_0x44779c=_0x548223['filter']['updateChild'](_0x4ff205['getNode'](),_0x1a1b86,_0x3971ee,_0x353e4f,_0x500582,_0x781cc3):_0x44779c=_0x4ff205['getNode']();}}return Tt(_0x50b81f,_0x44779c,_0x4ff205['isFullyInitialized']()||v(_0xe3e44f),_0x548223['filter']['filtersNodes']());}}function En(_0x9df775,_0x348083,_0x25344e,_0xf7e48d,_0x1ee9df,_0x2a5f79,_0x4960fc,_0x479fb6){const _0x29f00d=_0x348083['serverCache'];let _0x5ddb02;const _0x4e768a=_0x4960fc?_0x9df775['filter']:_0x9df775['filter']['getIndexedFilter']();if(v(_0x25344e))_0x5ddb02=_0x4e768a['updateFullNode'](_0x29f00d['getNode'](),_0xf7e48d,null);else{if(_0x4e768a['filtersNodes']()&&!_0x29f00d['isFiltered']()){const _0xdb45f3=_0x29f00d['getNode']()['updateChild'](_0x25344e,_0xf7e48d);_0x5ddb02=_0x4e768a['updateFullNode'](_0x29f00d['getNode'](),_0xdb45f3,null);}else{const _0x2bf159=y(_0x25344e);if(!_0x29f00d['isCompleteForPath'](_0x25344e)&&we(_0x25344e)>0x1)return _0x348083;const _0x3215b2=b(_0x25344e),_0x1b82ad=_0x29f00d['getNode']()['getImmediateChild'](_0x2bf159)['updateChild'](_0x3215b2,_0xf7e48d);_0x2bf159==='.priority'?_0x5ddb02=_0x4e768a['updatePriority'](_0x29f00d['getNode'](),_0x1b82ad):_0x5ddb02=_0x4e768a['updateChild'](_0x29f00d['getNode'](),_0x2bf159,_0x1b82ad,_0x3215b2,Go,null);}}const _0x504111=Uo(_0x348083,_0x5ddb02,_0x29f00d['isFullyInitialized']()||v(_0x25344e),_0x4e768a['filtersNodes']()),_0x27523d=new ss(_0x1ee9df,_0x504111,_0x2a5f79);return qo(_0x9df775,_0x504111,_0x25344e,_0x1ee9df,_0x27523d,_0x479fb6);}function Si(_0x12cf45,_0x337ee4,_0x410dd0,_0x405c35,_0xe7e483,_0x14f8b3,_0x219e0c){const _0x5db42c=_0x337ee4['eventCache'];let _0x26a8ea,_0x19dbe0;const _0x4eee18=new ss(_0xe7e483,_0x337ee4,_0x14f8b3);if(v(_0x410dd0))_0x19dbe0=_0x12cf45['filter']['updateFullNode'](_0x337ee4['eventCache']['getNode'](),_0x405c35,_0x219e0c),_0x26a8ea=Tt(_0x337ee4,_0x19dbe0,!0x0,_0x12cf45['filter']['filtersNodes']());else{const _0x3f3c9d=y(_0x410dd0);if(_0x3f3c9d==='.priority')_0x19dbe0=_0x12cf45['filter']['updatePriority'](_0x337ee4['eventCache']['getNode'](),_0x405c35),_0x26a8ea=Tt(_0x337ee4,_0x19dbe0,_0x5db42c['isFullyInitialized'](),_0x5db42c['isFiltered']());else{const _0x236b5d=b(_0x410dd0),_0x487e9e=_0x5db42c['getNode']()['getImmediateChild'](_0x3f3c9d);let _0x5ef912;if(v(_0x236b5d))_0x5ef912=_0x405c35;else{const _0x4ec45f=_0x4eee18['getCompleteChild'](_0x3f3c9d);_0x4ec45f!=null?zi(_0x236b5d)==='.priority'&&_0x4ec45f['getChild'](Ro(_0x236b5d))['isEmpty']()?_0x5ef912=_0x4ec45f:_0x5ef912=_0x4ec45f['updateChild'](_0x236b5d,_0x405c35):_0x5ef912=g['EMPTY_NODE'];}if(_0x487e9e['equals'](_0x5ef912))_0x26a8ea=_0x337ee4;else{const _0x43ddfe=_0x12cf45['filter']['updateChild'](_0x5db42c['getNode'](),_0x3f3c9d,_0x5ef912,_0x236b5d,_0x4eee18,_0x219e0c);_0x26a8ea=Tt(_0x337ee4,_0x43ddfe,_0x5db42c['isFullyInitialized'](),_0x12cf45['filter']['filtersNodes']());}}}return _0x26a8ea;}function hr(_0x3e48e7,_0x2478f7){return _0x3e48e7['eventCache']['isCompleteForChild'](_0x2478f7);}function ku(_0x572554,_0x544055,_0x3b15c8,_0x455d75,_0x55bd33,_0x345d99,_0x37d6ce){let _0x5dbb9c=_0x544055;return _0x455d75['foreach']((_0x532efb,_0x375ad)=>{const _0x2ef846=k(_0x3b15c8,_0x532efb);hr(_0x544055,y(_0x2ef846))&&(_0x5dbb9c=Si(_0x572554,_0x5dbb9c,_0x2ef846,_0x375ad,_0x55bd33,_0x345d99,_0x37d6ce));}),_0x455d75['foreach']((_0x28a5ed,_0xa9da40)=>{const _0x5ef06c=k(_0x3b15c8,_0x28a5ed);hr(_0x544055,y(_0x5ef06c))||(_0x5dbb9c=Si(_0x572554,_0x5dbb9c,_0x5ef06c,_0xa9da40,_0x55bd33,_0x345d99,_0x37d6ce));}),_0x5dbb9c;}function ur(_0xd6d24a,_0x361203,_0x3f7ae9){return _0x3f7ae9['foreach']((_0x52a0ea,_0x371717)=>{_0x361203=_0x361203['updateChild'](_0x52a0ea,_0x371717);}),_0x361203;}function bi(_0x411a63,_0x3dff7e,_0x3f4517,_0x5d9bdd,_0x39a00f,_0x414e93,_0xc7c904,_0xf92ed9){if(_0x3dff7e['serverCache']['getNode']()['isEmpty']()&&!_0x3dff7e['serverCache']['isFullyInitialized']())return _0x3dff7e;let _0x26abae=_0x3dff7e,_0x10fe6d;v(_0x3f4517)?_0x10fe6d=_0x5d9bdd:_0x10fe6d=new S(null)['setTree'](_0x3f4517,_0x5d9bdd);const _0x33e32a=_0x3dff7e['serverCache']['getNode']();return _0x10fe6d['children']['inorderTraversal']((_0x52d97c,_0x36e73f)=>{if(_0x33e32a['hasChild'](_0x52d97c)){const _0xcb03b7=_0x3dff7e['serverCache']['getNode']()['getImmediateChild'](_0x52d97c),_0xf7e9e8=ur(_0x411a63,_0xcb03b7,_0x36e73f);_0x26abae=En(_0x411a63,_0x26abae,new C(_0x52d97c),_0xf7e9e8,_0x39a00f,_0x414e93,_0xc7c904,_0xf92ed9);}}),_0x10fe6d['children']['inorderTraversal']((_0x494860,_0x1097a0)=>{const _0x132e2b=!_0x3dff7e['serverCache']['isCompleteForChild'](_0x494860)&&_0x1097a0['value']===null;if(!_0x33e32a['hasChild'](_0x494860)&&!_0x132e2b){const _0x3e680f=_0x3dff7e['serverCache']['getNode']()['getImmediateChild'](_0x494860),_0x388301=ur(_0x411a63,_0x3e680f,_0x1097a0);_0x26abae=En(_0x411a63,_0x26abae,new C(_0x494860),_0x388301,_0x39a00f,_0x414e93,_0xc7c904,_0xf92ed9);}}),_0x26abae;}function Nu(_0x5d3756,_0x31eaa4,_0x2c22a5,_0x509b9c,_0x1b015a,_0x1f605c,_0x555f05){if(vn(_0x1b015a,_0x2c22a5)!=null)return _0x31eaa4;const _0x5768c5=_0x31eaa4['serverCache']['isFiltered'](),_0x35c3d0=_0x31eaa4['serverCache'];if(_0x509b9c['value']!=null){if(v(_0x2c22a5)&&_0x35c3d0['isFullyInitialized']()||_0x35c3d0['isCompleteForPath'](_0x2c22a5))return En(_0x5d3756,_0x31eaa4,_0x2c22a5,_0x35c3d0['getNode']()['getChild'](_0x2c22a5),_0x1b015a,_0x1f605c,_0x5768c5,_0x555f05);if(v(_0x2c22a5)){let _0x38018f=new S(null);return _0x35c3d0['getNode']()['forEachChild'](ye,(_0x2f0589,_0x53e3f7)=>{_0x38018f=_0x38018f['set'](new C(_0x2f0589),_0x53e3f7);}),bi(_0x5d3756,_0x31eaa4,_0x2c22a5,_0x38018f,_0x1b015a,_0x1f605c,_0x5768c5,_0x555f05);}else return _0x31eaa4;}else{let _0x245209=new S(null);return _0x509b9c['foreach']((_0x58f649,_0x30c53c)=>{const _0x277026=k(_0x2c22a5,_0x58f649);_0x35c3d0['isCompleteForPath'](_0x277026)&&(_0x245209=_0x245209['set'](_0x58f649,_0x35c3d0['getNode']()['getChild'](_0x277026)));}),bi(_0x5d3756,_0x31eaa4,_0x2c22a5,_0x245209,_0x1b015a,_0x1f605c,_0x5768c5,_0x555f05);}}function Pu(_0x41bd86,_0x565a3a,_0x4ad9ca,_0x18f8ae,_0x1d4de2){const _0x4635c9=_0x565a3a['serverCache'],_0x178003=Uo(_0x565a3a,_0x4635c9['getNode'](),_0x4635c9['isFullyInitialized']()||v(_0x4ad9ca),_0x4635c9['isFiltered']());return qo(_0x41bd86,_0x178003,_0x4ad9ca,_0x18f8ae,Go,_0x1d4de2);}function Ou(_0x1065cd,_0x129dc2,_0x13e419,_0x510da6,_0x1f4528,_0x393979){let _0x12fcb1;if(vn(_0x510da6,_0x13e419)!=null)return _0x129dc2;{const _0x24f21c=new ss(_0x510da6,_0x129dc2,_0x1f4528),_0x412c20=_0x129dc2['eventCache']['getNode']();let _0xbab030;if(v(_0x13e419)||y(_0x13e419)==='.priority'){let _0x5462e1;if(_0x129dc2['serverCache']['isFullyInitialized']())_0x5462e1=yn(_0x510da6,We(_0x129dc2));else{const _0x396215=_0x129dc2['serverCache']['getNode']();f(_0x396215 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x5462e1=ns(_0x510da6,_0x396215);}_0x5462e1=_0x5462e1,_0xbab030=_0x1065cd['filter']['updateFullNode'](_0x412c20,_0x5462e1,_0x393979);}else{const _0x46497d=y(_0x13e419);let _0x99d7c3=is(_0x510da6,_0x46497d,_0x129dc2['serverCache']);_0x99d7c3==null&&_0x129dc2['serverCache']['isCompleteForChild'](_0x46497d)&&(_0x99d7c3=_0x412c20['getImmediateChild'](_0x46497d)),_0x99d7c3!=null?_0xbab030=_0x1065cd['filter']['updateChild'](_0x412c20,_0x46497d,_0x99d7c3,b(_0x13e419),_0x24f21c,_0x393979):_0x129dc2['eventCache']['getNode']()['hasChild'](_0x46497d)?_0xbab030=_0x1065cd['filter']['updateChild'](_0x412c20,_0x46497d,g['EMPTY_NODE'],b(_0x13e419),_0x24f21c,_0x393979):_0xbab030=_0x412c20,_0xbab030['isEmpty']()&&_0x129dc2['serverCache']['isFullyInitialized']()&&(_0x12fcb1=yn(_0x510da6,We(_0x129dc2)),_0x12fcb1['isLeafNode']()&&(_0xbab030=_0x1065cd['filter']['updateFullNode'](_0xbab030,_0x12fcb1,_0x393979)));}return _0x12fcb1=_0x129dc2['serverCache']['isFullyInitialized']()||vn(_0x510da6,w())!=null,Tt(_0x129dc2,_0xbab030,_0x12fcb1,_0x1065cd['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x16abc6,_0x463ab0){this['query_']=_0x16abc6,this['eventRegistrations_']=[];const _0x38db0e=this['query_']['_queryParams'],_0x3044fa=new Ji(_0x38db0e['getIndex']()),_0x496a34=Kh(_0x38db0e);this['processor_']=Su(_0x496a34);const _0x8e69d0=_0x463ab0['serverCache'],_0x57b645=_0x463ab0['eventCache'],_0x51c630=_0x3044fa['updateFullNode'](g['EMPTY_NODE'],_0x8e69d0['getNode'](),null),_0x40bfdc=_0x496a34['updateFullNode'](g['EMPTY_NODE'],_0x57b645['getNode'](),null),_0x4d1c70=new Ce(_0x51c630,_0x8e69d0['isFullyInitialized'](),_0x3044fa['filtersNodes']()),_0x249e00=new Ce(_0x40bfdc,_0x57b645['isFullyInitialized'](),_0x496a34['filtersNodes']());this['viewCache_']=Mn(_0x249e00,_0x4d1c70),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x5212d5){return _0x5212d5['viewCache_']['serverCache']['getNode']();}function Lu(_0x1323d8){return mn(_0x1323d8['viewCache_']);}function xu(_0x149b01,_0x36b0fb){const _0x5c65cb=We(_0x149b01['viewCache_']);return _0x5c65cb&&(_0x149b01['query']['_queryParams']['loadsAllData']()||!v(_0x36b0fb)&&!_0x5c65cb['getImmediateChild'](y(_0x36b0fb))['isEmpty']())?_0x5c65cb['getChild'](_0x36b0fb):null;}function dr(_0x5df65b){return _0x5df65b['eventRegistrations_']['length']===0x0;}function Fu(_0x35a6a2,_0x43b211){_0x35a6a2['eventRegistrations_']['push'](_0x43b211);}function fr(_0x43b51c,_0x5768cf,_0x34d218){const _0x504a09=[];if(_0x34d218){f(_0x5768cf==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x4cc140=_0x43b51c['query']['_path'];_0x43b51c['eventRegistrations_']['forEach'](_0x2471a2=>{const _0x531b3c=_0x2471a2['createCancelEvent'](_0x34d218,_0x4cc140);_0x531b3c&&_0x504a09['push'](_0x531b3c);});}if(_0x5768cf){let _0x326e8f=[];for(let _0x17bb56=0x0;_0x17bb56<_0x43b51c['eventRegistrations_']['length'];++_0x17bb56){const _0x58b74f=_0x43b51c['eventRegistrations_'][_0x17bb56];if(!_0x58b74f['matches'](_0x5768cf))_0x326e8f['push'](_0x58b74f);else{if(_0x5768cf['hasAnyCallback']()){_0x326e8f=_0x326e8f['concat'](_0x43b51c['eventRegistrations_']['slice'](_0x17bb56+0x1));break;}}}_0x43b51c['eventRegistrations_']=_0x326e8f;}else _0x43b51c['eventRegistrations_']=[];return _0x504a09;}function pr(_0x17578a,_0x429db0,_0xfb051,_0x27f5be){_0x429db0['type']===j['MERGE']&&_0x429db0['source']['queryId']!==null&&(f(We(_0x17578a['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x17578a['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x10e06a=_0x17578a['viewCache_'],_0x41b3e1=Ru(_0x17578a['processor_'],_0x10e06a,_0x429db0,_0xfb051,_0x27f5be);return bu(_0x17578a['processor_'],_0x41b3e1['viewCache']),f(_0x41b3e1['viewCache']['serverCache']['isFullyInitialized']()||!_0x10e06a['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x17578a['viewCache_']=_0x41b3e1['viewCache'],zo(_0x17578a,_0x41b3e1['changes'],_0x41b3e1['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x35f823,_0x5be36b){const _0x3dc1a9=_0x35f823['viewCache_']['eventCache'],_0x346d74=[];return _0x3dc1a9['getNode']()['isLeafNode']()||_0x3dc1a9['getNode']()['forEachChild'](R,(_0x185a19,_0x29e219)=>{_0x346d74['push'](et(_0x185a19,_0x29e219));}),_0x3dc1a9['isFullyInitialized']()&&_0x346d74['push'](Lo(_0x3dc1a9['getNode']())),zo(_0x35f823,_0x346d74,_0x3dc1a9['getNode'](),_0x5be36b);}function zo(_0x2f4fd0,_0x869db1,_0x402d86,_0x5c2758){const _0x1b69e0=_0x5c2758?[_0x5c2758]:_0x2f4fd0['eventRegistrations_'];return ru(_0x2f4fd0['eventGenerator_'],_0x869db1,_0x402d86,_0x1b69e0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x352746){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x352746;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x362b5b){return _0x362b5b['views']['size']===0x0;}function rs(_0x12f2b2,_0x4cdc4a,_0x3747e5,_0xf5c527){const _0x3e4006=_0x4cdc4a['source']['queryId'];if(_0x3e4006!==null){const _0x151e78=_0x12f2b2['views']['get'](_0x3e4006);return f(_0x151e78!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x151e78,_0x4cdc4a,_0x3747e5,_0xf5c527);}else{let _0x175535=[];for(const _0x5432d4 of _0x12f2b2['views']['values']())_0x175535=_0x175535['concat'](pr(_0x5432d4,_0x4cdc4a,_0x3747e5,_0xf5c527));return _0x175535;}}function Ko(_0x3bedcc,_0x4369c1,_0x5b7613,_0x3b351b,_0x4c2f2d){const _0x2a8191=_0x4369c1['_queryIdentifier'],_0x31a665=_0x3bedcc['views']['get'](_0x2a8191);if(!_0x31a665){let _0x379a71=yn(_0x5b7613,_0x4c2f2d?_0x3b351b:null),_0x1ad090=!0x1;_0x379a71?_0x1ad090=!0x0:_0x3b351b instanceof g?(_0x379a71=ns(_0x5b7613,_0x3b351b),_0x1ad090=!0x1):(_0x379a71=g['EMPTY_NODE'],_0x1ad090=!0x1);const _0x7d378b=Mn(new Ce(_0x379a71,_0x1ad090,!0x1),new Ce(_0x3b351b,_0x4c2f2d,!0x1));return new Du(_0x4369c1,_0x7d378b);}return _0x31a665;}function Hu(_0x11fe02,_0x7e881e,_0x1a1998,_0x4ff1ea,_0xc980f,_0x4ca58b){const _0x40aecf=Ko(_0x11fe02,_0x7e881e,_0x4ff1ea,_0xc980f,_0x4ca58b);return _0x11fe02['views']['has'](_0x7e881e['_queryIdentifier'])||_0x11fe02['views']['set'](_0x7e881e['_queryIdentifier'],_0x40aecf),Fu(_0x40aecf,_0x1a1998),Uu(_0x40aecf,_0x1a1998);}function $u(_0x13e973,_0x24e31c,_0x190450,_0x24d0e5){const _0x2b7445=_0x24e31c['_queryIdentifier'],_0x37d814=[];let _0x448c86=[];const _0x177cd3=Te(_0x13e973);if(_0x2b7445==='default'){for(const [_0x11f516,_0x42fae7]of _0x13e973['views']['entries']())_0x448c86=_0x448c86['concat'](fr(_0x42fae7,_0x190450,_0x24d0e5)),dr(_0x42fae7)&&(_0x13e973['views']['delete'](_0x11f516),_0x42fae7['query']['_queryParams']['loadsAllData']()||_0x37d814['push'](_0x42fae7['query']));}else{const _0x50e779=_0x13e973['views']['get'](_0x2b7445);_0x50e779&&(_0x448c86=_0x448c86['concat'](fr(_0x50e779,_0x190450,_0x24d0e5)),dr(_0x50e779)&&(_0x13e973['views']['delete'](_0x2b7445),_0x50e779['query']['_queryParams']['loadsAllData']()||_0x37d814['push'](_0x50e779['query'])));}return _0x177cd3&&!Te(_0x13e973)&&_0x37d814['push'](new(Bu())(_0x24e31c['_repo'],_0x24e31c['_path'])),{'removed':_0x37d814,'events':_0x448c86};}function Yo(_0x3a7734){const _0x29f35d=[];for(const _0x16929e of _0x3a7734['views']['values']())_0x16929e['query']['_queryParams']['loadsAllData']()||_0x29f35d['push'](_0x16929e);return _0x29f35d;}function Ee(_0x488935,_0x8015bb){let _0x494ccb=null;for(const _0x20d9f4 of _0x488935['views']['values']())_0x494ccb=_0x494ccb||xu(_0x20d9f4,_0x8015bb);return _0x494ccb;}function Qo(_0xa93b77,_0x3c5064){if(_0x3c5064['_queryParams']['loadsAllData']())return xn(_0xa93b77);{const _0x1cb0d0=_0x3c5064['_queryIdentifier'];return _0xa93b77['views']['get'](_0x1cb0d0);}}function Jo(_0x26c2ff,_0x479f2c){return Qo(_0x26c2ff,_0x479f2c)!=null;}function Te(_0x3b2a){return xn(_0x3b2a)!=null;}function xn(_0x563771){for(const _0x51cc07 of _0x563771['views']['values']())if(_0x51cc07['query']['_queryParams']['loadsAllData']())return _0x51cc07;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x13c1a2){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x13c1a2;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x1ef184){this['listenProvider_']=_0x1ef184,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x3b64ab,_0x25ee6b,_0x2f5874,_0x3269cf,_0x499d3d){return lu(_0x3b64ab['pendingWriteTree_'],_0x25ee6b,_0x2f5874,_0x3269cf,_0x499d3d),_0x499d3d?ut(_0x3b64ab,new Ue(Zi(),_0x25ee6b,_0x2f5874)):[];}function ju(_0x165475,_0x1ee178,_0x134a1f,_0x2e7a9c){hu(_0x165475['pendingWriteTree_'],_0x1ee178,_0x134a1f,_0x2e7a9c);const _0x40f61a=S['fromObject'](_0x134a1f);return ut(_0x165475,new tt(Zi(),_0x1ee178,_0x40f61a));}function pe(_0x3a35f2,_0x12ba6b,_0x36e665=!0x1){const _0x378038=uu(_0x3a35f2['pendingWriteTree_'],_0x12ba6b);if(du(_0x3a35f2['pendingWriteTree_'],_0x12ba6b)){let _0x1fa724=new S(null);return _0x378038['snap']!=null?_0x1fa724=_0x1fa724['set'](w(),!0x0):x(_0x378038['children'],_0xb2c51f=>{_0x1fa724=_0x1fa724['set'](new C(_0xb2c51f),!0x0);}),ut(_0x3a35f2,new gn(_0x378038['path'],_0x1fa724,_0x36e665));}else return[];}function Gt(_0x333cf9,_0x3f7754,_0xc842f2){return ut(_0x333cf9,new Ue(es(),_0x3f7754,_0xc842f2));}function Ku(_0x24844e,_0x168cdc,_0x2502fa){const _0x304f08=S['fromObject'](_0x2502fa);return ut(_0x24844e,new tt(es(),_0x168cdc,_0x304f08));}function Yu(_0x407b21,_0x44882b){return ut(_0x407b21,new Lt(es(),_0x44882b));}function Qu(_0x2fe850,_0x3c8a39,_0x5992ca){const _0x38c263=as(_0x2fe850,_0x5992ca);if(_0x38c263){const _0xde6b5e=cs(_0x38c263),_0x5c0422=_0xde6b5e['path'],_0x15b17e=_0xde6b5e['queryId'],_0x49a61c=F(_0x5c0422,_0x3c8a39),_0x583d36=new Lt(ts(_0x15b17e),_0x49a61c);return ls(_0x2fe850,_0x5c0422,_0x583d36);}else return[];}function Cn(_0x33be2b,_0x777f18,_0x47e896,_0x49a01f,_0x5cd6eb=!0x1){const _0x448b80=_0x777f18['_path'],_0x4cf5ea=_0x33be2b['syncPointTree_']['get'](_0x448b80);let _0x354cf4=[];if(_0x4cf5ea&&(_0x777f18['_queryIdentifier']==='default'||Jo(_0x4cf5ea,_0x777f18))){const _0x4f36dc=$u(_0x4cf5ea,_0x777f18,_0x47e896,_0x49a01f);Vu(_0x4cf5ea)&&(_0x33be2b['syncPointTree_']=_0x33be2b['syncPointTree_']['remove'](_0x448b80));const _0x40e908=_0x4f36dc['removed'];if(_0x354cf4=_0x4f36dc['events'],!_0x5cd6eb){const _0x2cd89c=_0x40e908['findIndex'](_0x58b2ba=>_0x58b2ba['_queryParams']['loadsAllData']())!==-0x1,_0x2b32ae=_0x33be2b['syncPointTree_']['findOnPath'](_0x448b80,(_0x488c07,_0x2ca6f1)=>Te(_0x2ca6f1));if(_0x2cd89c&&!_0x2b32ae){const _0x42274f=_0x33be2b['syncPointTree_']['subtree'](_0x448b80);if(!_0x42274f['isEmpty']()){const _0x1b8aa5=Zu(_0x42274f);for(let _0x570b4d=0x0;_0x570b4d<_0x1b8aa5['length'];++_0x570b4d){const _0x27547c=_0x1b8aa5[_0x570b4d],_0x2c2706=_0x27547c['query'],_0x4c7a8e=ta(_0x33be2b,_0x27547c);_0x33be2b['listenProvider_']['startListening'](bt(_0x2c2706),xt(_0x33be2b,_0x2c2706),_0x4c7a8e['hashFn'],_0x4c7a8e['onComplete']);}}}!_0x2b32ae&&_0x40e908['length']>0x0&&!_0x49a01f&&(_0x2cd89c?_0x33be2b['listenProvider_']['stopListening'](bt(_0x777f18),null):_0x40e908['forEach'](_0x41b783=>{const _0xbd3c7c=_0x33be2b['queryToTagMap']['get'](Un(_0x41b783));_0x33be2b['listenProvider_']['stopListening'](bt(_0x41b783),_0xbd3c7c);}));}ed(_0x33be2b,_0x40e908);}return _0x354cf4;}function Xo(_0x2ae400,_0xb72733,_0x4bc7fd,_0x474b1c){const _0x50e9ba=as(_0x2ae400,_0x474b1c);if(_0x50e9ba!=null){const _0x28ef13=cs(_0x50e9ba),_0x519af8=_0x28ef13['path'],_0x29598d=_0x28ef13['queryId'],_0x417b32=F(_0x519af8,_0xb72733),_0x305ba5=new Ue(ts(_0x29598d),_0x417b32,_0x4bc7fd);return ls(_0x2ae400,_0x519af8,_0x305ba5);}else return[];}function Ju(_0x4fd241,_0x5419f8,_0x5df224,_0x44f0dc){const _0x52c2ff=as(_0x4fd241,_0x44f0dc);if(_0x52c2ff){const _0x31cfea=cs(_0x52c2ff),_0x300eeb=_0x31cfea['path'],_0x1f1314=_0x31cfea['queryId'],_0x40192b=F(_0x300eeb,_0x5419f8),_0x7f69f5=S['fromObject'](_0x5df224),_0x23661e=new tt(ts(_0x1f1314),_0x40192b,_0x7f69f5);return ls(_0x4fd241,_0x300eeb,_0x23661e);}else return[];}function Ri(_0x301dd8,_0x557431,_0x1953a9,_0x5c9b51=!0x1){const _0x4bdb82=_0x557431['_path'];let _0xeaa06e=null,_0xe64fda=!0x1;_0x301dd8['syncPointTree_']['foreachOnPath'](_0x4bdb82,(_0x216dbc,_0x420cd3)=>{const _0x52607c=F(_0x216dbc,_0x4bdb82);_0xeaa06e=_0xeaa06e||Ee(_0x420cd3,_0x52607c),_0xe64fda=_0xe64fda||Te(_0x420cd3);});let _0x4c9b35=_0x301dd8['syncPointTree_']['get'](_0x4bdb82);_0x4c9b35?(_0xe64fda=_0xe64fda||Te(_0x4c9b35),_0xeaa06e=_0xeaa06e||Ee(_0x4c9b35,w())):(_0x4c9b35=new jo(),_0x301dd8['syncPointTree_']=_0x301dd8['syncPointTree_']['set'](_0x4bdb82,_0x4c9b35));let _0x31c3b3;_0xeaa06e!=null?_0x31c3b3=!0x0:(_0x31c3b3=!0x1,_0xeaa06e=g['EMPTY_NODE'],_0x301dd8['syncPointTree_']['subtree'](_0x4bdb82)['foreachChild']((_0x4d996a,_0x59bfac)=>{const _0x30c121=Ee(_0x59bfac,w());_0x30c121&&(_0xeaa06e=_0xeaa06e['updateImmediateChild'](_0x4d996a,_0x30c121));}));const _0x1604fd=Jo(_0x4c9b35,_0x557431);if(!_0x1604fd&&!_0x557431['_queryParams']['loadsAllData']()){const _0x1244cd=Un(_0x557431);f(!_0x301dd8['queryToTagMap']['has'](_0x1244cd),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x57221f=td();_0x301dd8['queryToTagMap']['set'](_0x1244cd,_0x57221f),_0x301dd8['tagToQueryMap']['set'](_0x57221f,_0x1244cd);}const _0xcdfdca=Ln(_0x301dd8['pendingWriteTree_'],_0x4bdb82);let _0xd13921=Hu(_0x4c9b35,_0x557431,_0x1953a9,_0xcdfdca,_0xeaa06e,_0x31c3b3);if(!_0x1604fd&&!_0xe64fda&&!_0x5c9b51){const _0x462a9d=Qo(_0x4c9b35,_0x557431);_0xd13921=_0xd13921['concat'](nd(_0x301dd8,_0x557431,_0x462a9d));}return _0xd13921;}function Fn(_0x68827,_0x908a0b,_0x590372){const _0x48d9fa=_0x68827['pendingWriteTree_'],_0x221b1e=_0x68827['syncPointTree_']['findOnPath'](_0x908a0b,(_0x45a4b0,_0x127ef6)=>{const _0x3a7e62=F(_0x45a4b0,_0x908a0b),_0x59e3bd=Ee(_0x127ef6,_0x3a7e62);if(_0x59e3bd)return _0x59e3bd;});return Vo(_0x48d9fa,_0x908a0b,_0x221b1e,_0x590372,!0x0);}function Xu(_0x35a649,_0x2416c3){const _0x5b1da8=_0x2416c3['_path'];let _0x191d29=null;_0x35a649['syncPointTree_']['foreachOnPath'](_0x5b1da8,(_0x5c05fb,_0x470dfa)=>{const _0x22e215=F(_0x5c05fb,_0x5b1da8);_0x191d29=_0x191d29||Ee(_0x470dfa,_0x22e215);});let _0x3534e9=_0x35a649['syncPointTree_']['get'](_0x5b1da8);_0x3534e9?_0x191d29=_0x191d29||Ee(_0x3534e9,w()):(_0x3534e9=new jo(),_0x35a649['syncPointTree_']=_0x35a649['syncPointTree_']['set'](_0x5b1da8,_0x3534e9));const _0x502bd1=_0x191d29!=null,_0x57ee49=_0x502bd1?new Ce(_0x191d29,!0x0,!0x1):null,_0x43b7d9=Ln(_0x35a649['pendingWriteTree_'],_0x2416c3['_path']),_0x1cd1c8=Ko(_0x3534e9,_0x2416c3,_0x43b7d9,_0x502bd1?_0x57ee49['getNode']():g['EMPTY_NODE'],_0x502bd1);return Lu(_0x1cd1c8);}function ut(_0x2a2e32,_0x3fd0aa){return Zo(_0x3fd0aa,_0x2a2e32['syncPointTree_'],null,Ln(_0x2a2e32['pendingWriteTree_'],w()));}function Zo(_0x47dc16,_0x57a993,_0x1c7787,_0x4e9563){if(v(_0x47dc16['path']))return ea(_0x47dc16,_0x57a993,_0x1c7787,_0x4e9563);{const _0x2d7899=_0x57a993['get'](w());_0x1c7787==null&&_0x2d7899!=null&&(_0x1c7787=Ee(_0x2d7899,w()));let _0x421e32=[];const _0x1bb523=y(_0x47dc16['path']),_0x49471a=_0x47dc16['operationForChild'](_0x1bb523),_0x217d62=_0x57a993['children']['get'](_0x1bb523);if(_0x217d62&&_0x49471a){const _0x4d1c94=_0x1c7787?_0x1c7787['getImmediateChild'](_0x1bb523):null,_0x3ed023=Ho(_0x4e9563,_0x1bb523);_0x421e32=_0x421e32['concat'](Zo(_0x49471a,_0x217d62,_0x4d1c94,_0x3ed023));}return _0x2d7899&&(_0x421e32=_0x421e32['concat'](rs(_0x2d7899,_0x47dc16,_0x4e9563,_0x1c7787))),_0x421e32;}}function ea(_0xaf7bec,_0x3e5ec5,_0x166c21,_0x4b41da){const _0x38f183=_0x3e5ec5['get'](w());_0x166c21==null&&_0x38f183!=null&&(_0x166c21=Ee(_0x38f183,w()));let _0x7af74f=[];return _0x3e5ec5['children']['inorderTraversal']((_0x481c3d,_0x40ec7c)=>{const _0x5697a=_0x166c21?_0x166c21['getImmediateChild'](_0x481c3d):null,_0x4618d7=Ho(_0x4b41da,_0x481c3d),_0x2be1e5=_0xaf7bec['operationForChild'](_0x481c3d);_0x2be1e5&&(_0x7af74f=_0x7af74f['concat'](ea(_0x2be1e5,_0x40ec7c,_0x5697a,_0x4618d7)));}),_0x38f183&&(_0x7af74f=_0x7af74f['concat'](rs(_0x38f183,_0xaf7bec,_0x4b41da,_0x166c21))),_0x7af74f;}function ta(_0x2f056,_0x19cc44){const _0x3ec864=_0x19cc44['query'],_0x6d486c=xt(_0x2f056,_0x3ec864);return{'hashFn':()=>(Mu(_0x19cc44)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x376b7d=>{if(_0x376b7d==='ok')return _0x6d486c?Qu(_0x2f056,_0x3ec864['_path'],_0x6d486c):Yu(_0x2f056,_0x3ec864['_path']);{const _0x5edd7b=Kl(_0x376b7d,_0x3ec864);return Cn(_0x2f056,_0x3ec864,null,_0x5edd7b);}}};}function xt(_0x5cec17,_0x55c966){const _0x546682=Un(_0x55c966);return _0x5cec17['queryToTagMap']['get'](_0x546682);}function Un(_0xebfd16){return _0xebfd16['_path']['toString']()+'$'+_0xebfd16['_queryIdentifier'];}function as(_0x3e7b26,_0x3b8b44){return _0x3e7b26['tagToQueryMap']['get'](_0x3b8b44);}function cs(_0x574adb){const _0x27af22=_0x574adb['indexOf']('$');return f(_0x27af22!==-0x1&&_0x27af22<_0x574adb['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x574adb['substr'](_0x27af22+0x1),'path':new C(_0x574adb['substr'](0x0,_0x27af22))};}function ls(_0x228c7e,_0xf2a3c6,_0x58f8e1){const _0xf0734e=_0x228c7e['syncPointTree_']['get'](_0xf2a3c6);f(_0xf0734e,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x11edd0=Ln(_0x228c7e['pendingWriteTree_'],_0xf2a3c6);return rs(_0xf0734e,_0x58f8e1,_0x11edd0,null);}function Zu(_0x335cd6){return _0x335cd6['fold']((_0x42e254,_0xe02548,_0x509b51)=>{if(_0xe02548&&Te(_0xe02548))return[xn(_0xe02548)];{let _0x105ec5=[];return _0xe02548&&(_0x105ec5=Yo(_0xe02548)),x(_0x509b51,(_0x4d6221,_0x78e336)=>{_0x105ec5=_0x105ec5['concat'](_0x78e336);}),_0x105ec5;}});}function bt(_0x552565){return _0x552565['_queryParams']['loadsAllData']()&&!_0x552565['_queryParams']['isDefault']()?new(qu())(_0x552565['_repo'],_0x552565['_path']):_0x552565;}function ed(_0x38bfa8,_0x569d8b){for(let _0xae4926=0x0;_0xae4926<_0x569d8b['length'];++_0xae4926){const _0x5264d0=_0x569d8b[_0xae4926];if(!_0x5264d0['_queryParams']['loadsAllData']()){const _0x3fcac1=Un(_0x5264d0),_0xadf098=_0x38bfa8['queryToTagMap']['get'](_0x3fcac1);_0x38bfa8['queryToTagMap']['delete'](_0x3fcac1),_0x38bfa8['tagToQueryMap']['delete'](_0xadf098);}}}function td(){return zu++;}function nd(_0xbc486b,_0x35654e,_0x1cf8c5){const _0x24d46f=_0x35654e['_path'],_0x29a042=xt(_0xbc486b,_0x35654e),_0x4f30dc=ta(_0xbc486b,_0x1cf8c5),_0x55e7f7=_0xbc486b['listenProvider_']['startListening'](bt(_0x35654e),_0x29a042,_0x4f30dc['hashFn'],_0x4f30dc['onComplete']),_0x5d957e=_0xbc486b['syncPointTree_']['subtree'](_0x24d46f);if(_0x29a042)f(!Te(_0x5d957e['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x52816a=_0x5d957e['fold']((_0x539de5,_0x41fc71,_0x1328c0)=>{if(!v(_0x539de5)&&_0x41fc71&&Te(_0x41fc71))return[xn(_0x41fc71)['query']];{let _0x3d8898=[];return _0x41fc71&&(_0x3d8898=_0x3d8898['concat'](Yo(_0x41fc71)['map'](_0x41e510=>_0x41e510['query']))),x(_0x1328c0,(_0x21479f,_0xa7aaf1)=>{_0x3d8898=_0x3d8898['concat'](_0xa7aaf1);}),_0x3d8898;}});for(let _0x4c00f2=0x0;_0x4c00f2<_0x52816a['length'];++_0x4c00f2){const _0x3a0fac=_0x52816a[_0x4c00f2];_0xbc486b['listenProvider_']['stopListening'](bt(_0x3a0fac),xt(_0xbc486b,_0x3a0fac));}}return _0x55e7f7;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x28a8d4){this['node_']=_0x28a8d4;}['getImmediateChild'](_0x481e16){const _0x1777ec=this['node_']['getImmediateChild'](_0x481e16);return new hs(_0x1777ec);}['node'](){return this['node_'];}}class us{constructor(_0x2630e2,_0xbbba4a){this['syncTree_']=_0x2630e2,this['path_']=_0xbbba4a;}['getImmediateChild'](_0x575904){const _0x142dd9=k(this['path_'],_0x575904);return new us(this['syncTree_'],_0x142dd9);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x617290){return _0x617290=_0x617290||{},_0x617290['timestamp']=_0x617290['timestamp']||new Date()['getTime'](),_0x617290;},gr=function(_0x5dd737,_0x5401e9,_0x2c6a82){if(!_0x5dd737||typeof _0x5dd737!='object')return _0x5dd737;if(f('.sv'in _0x5dd737,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x5dd737['.sv']=='string')return sd(_0x5dd737['.sv'],_0x5401e9,_0x2c6a82);if(typeof _0x5dd737['.sv']=='object')return rd(_0x5dd737['.sv'],_0x5401e9);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5dd737,null,0x2));},sd=function(_0x456833,_0x4393b7,_0x857594){switch(_0x456833){case'timestamp':return _0x857594['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x456833);}},rd=function(_0xc668e3,_0xaefe56,_0x444cb4){_0xc668e3['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xc668e3,null,0x2));const _0x153198=_0xc668e3['increment'];typeof _0x153198!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x153198);const _0xbe0621=_0xaefe56['node']();if(f(_0xbe0621!==null&&typeof _0xbe0621<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0xbe0621['isLeafNode']())return _0x153198;const _0x1425e8=_0xbe0621['getValue']();return typeof _0x1425e8!='number'?_0x153198:_0x1425e8+_0x153198;},na=function(_0x3642aa,_0x16bb28,_0x4b4b04,_0x5bd954){return fs(_0x16bb28,new us(_0x4b4b04,_0x3642aa),_0x5bd954);},ds=function(_0x2fa04c,_0x8cfdc4,_0x1e1390){return fs(_0x2fa04c,new hs(_0x8cfdc4),_0x1e1390);};function fs(_0x13d70f,_0x502759,_0x162f24){const _0x3b0358=_0x13d70f['getPriority']()['val'](),_0x54b70c=gr(_0x3b0358,_0x502759['getImmediateChild']('.priority'),_0x162f24);let _0x185bbd;if(_0x13d70f['isLeafNode']()){const _0x17edb4=_0x13d70f,_0x54e095=gr(_0x17edb4['getValue'](),_0x502759,_0x162f24);return _0x54e095!==_0x17edb4['getValue']()||_0x54b70c!==_0x17edb4['getPriority']()['val']()?new D(_0x54e095,P(_0x54b70c)):_0x13d70f;}else{const _0x67dbd=_0x13d70f;return _0x185bbd=_0x67dbd,_0x54b70c!==_0x67dbd['getPriority']()['val']()&&(_0x185bbd=_0x185bbd['updatePriority'](new D(_0x54b70c))),_0x67dbd['forEachChild'](R,(_0x121d72,_0x48beb2)=>{const _0xf5ff0e=fs(_0x48beb2,_0x502759['getImmediateChild'](_0x121d72),_0x162f24);_0xf5ff0e!==_0x48beb2&&(_0x185bbd=_0x185bbd['updateImmediateChild'](_0x121d72,_0xf5ff0e));}),_0x185bbd;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x380875='',_0x5d3667=null,_0x3dd030={'children':{},'childCount':0x0}){this['name']=_0x380875,this['parent']=_0x5d3667,this['node']=_0x3dd030;}}function Wn(_0x1da151,_0x722e40){let _0x4d26c0=_0x722e40 instanceof C?_0x722e40:new C(_0x722e40),_0x2d7056=_0x1da151,_0x3708ee=y(_0x4d26c0);for(;_0x3708ee!==null;){const _0x3849e0=De(_0x2d7056['node']['children'],_0x3708ee)||{'children':{},'childCount':0x0};_0x2d7056=new ps(_0x3708ee,_0x2d7056,_0x3849e0),_0x4d26c0=b(_0x4d26c0),_0x3708ee=y(_0x4d26c0);}return _0x2d7056;}function Ge(_0x23395f){return _0x23395f['node']['value'];}function _s(_0x92835a,_0x43fbca){_0x92835a['node']['value']=_0x43fbca,Ai(_0x92835a);}function ia(_0x3c0896){return _0x3c0896['node']['childCount']>0x0;}function od(_0x17a2ef){return Ge(_0x17a2ef)===void 0x0&&!ia(_0x17a2ef);}function Bn(_0x25d677,_0x3490eb){x(_0x25d677['node']['children'],(_0x290f68,_0xafd48e)=>{_0x3490eb(new ps(_0x290f68,_0x25d677,_0xafd48e));});}function sa(_0x35e824,_0x1c484c,_0x36f56a,_0x24dd9b){_0x36f56a&&_0x1c484c(_0x35e824),Bn(_0x35e824,_0x480ef7=>{sa(_0x480ef7,_0x1c484c,!0x0);});}function ad(_0x4509b8,_0x34cf50,_0x378dab){let _0x5ab728=_0x4509b8['parent'];for(;_0x5ab728!==null;){if(_0x34cf50(_0x5ab728))return!0x0;_0x5ab728=_0x5ab728['parent'];}return!0x1;}function qt(_0x3e382c){return new C(_0x3e382c['parent']===null?_0x3e382c['name']:qt(_0x3e382c['parent'])+'/'+_0x3e382c['name']);}function Ai(_0x195a6d){_0x195a6d['parent']!==null&&cd(_0x195a6d['parent'],_0x195a6d['name'],_0x195a6d);}function cd(_0x5ca6cd,_0x5f1316,_0x4975bb){const _0x4f3137=od(_0x4975bb),_0x39d33f=J(_0x5ca6cd['node']['children'],_0x5f1316);_0x4f3137&&_0x39d33f?(delete _0x5ca6cd['node']['children'][_0x5f1316],_0x5ca6cd['node']['childCount']--,Ai(_0x5ca6cd)):!_0x4f3137&&!_0x39d33f&&(_0x5ca6cd['node']['children'][_0x5f1316]=_0x4975bb['node'],_0x5ca6cd['node']['childCount']++,Ai(_0x5ca6cd));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x2d056e){return typeof _0x2d056e=='string'&&_0x2d056e['length']!==0x0&&!ld['test'](_0x2d056e);},ra=function(_0x3b6832){return typeof _0x3b6832=='string'&&_0x3b6832['length']!==0x0&&!hd['test'](_0x3b6832);},ud=function(_0x1c1782){return _0x1c1782&&(_0x1c1782=_0x1c1782['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x1c1782);},Tn=function(_0x190ce8){return _0x190ce8===null||typeof _0x190ce8=='string'||typeof _0x190ce8=='number'&&!Vi(_0x190ce8)||_0x190ce8&&typeof _0x190ce8=='object'&&J(_0x190ce8,'.sv');},zt=function(_0x5a66f0,_0x573238,_0xefe86,_0x28ea10){_0x28ea10&&_0x573238===void 0x0||jt(Pn(_0x5a66f0,'value'),_0x573238,_0xefe86);},jt=function(_0x3856e7,_0x2b7304,_0x849a02){const _0x282fd7=_0x849a02 instanceof C?new Ah(_0x849a02,_0x3856e7):_0x849a02;if(_0x2b7304===void 0x0)throw new Error(_0x3856e7+'contains\x20undefined\x20'+Pe(_0x282fd7));if(typeof _0x2b7304=='function')throw new Error(_0x3856e7+'contains\x20a\x20function\x20'+Pe(_0x282fd7)+'\x20with\x20contents\x20=\x20'+_0x2b7304['toString']());if(Vi(_0x2b7304))throw new Error(_0x3856e7+'contains\x20'+_0x2b7304['toString']()+'\x20'+Pe(_0x282fd7));if(typeof _0x2b7304=='string'&&_0x2b7304['length']>ai/0x3&&On(_0x2b7304)>ai)throw new Error(_0x3856e7+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x282fd7)+'\x20(\x27'+_0x2b7304['substring'](0x0,0x32)+'...\x27)');if(_0x2b7304&&typeof _0x2b7304=='object'){let _0x1a5481=!0x1,_0x5d3730=!0x1;if(x(_0x2b7304,(_0x3c07da,_0x33374b)=>{if(_0x3c07da==='.value')_0x1a5481=!0x0;else{if(_0x3c07da!=='.priority'&&_0x3c07da!=='.sv'&&(_0x5d3730=!0x0,!gs(_0x3c07da)))throw new Error(_0x3856e7+'\x20contains\x20an\x20invalid\x20key\x20('+_0x3c07da+')\x20'+Pe(_0x282fd7)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x282fd7,_0x3c07da),jt(_0x3856e7,_0x33374b,_0x282fd7),Nh(_0x282fd7);}),_0x1a5481&&_0x5d3730)throw new Error(_0x3856e7+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x282fd7)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x52d9d7,_0x44c6e8){let _0x113c54,_0x13488d;for(_0x113c54=0x0;_0x113c54<_0x44c6e8['length'];_0x113c54++){_0x13488d=_0x44c6e8[_0x113c54];const _0x5528f4=Pt(_0x13488d);for(let _0x989652=0x0;_0x989652<_0x5528f4['length'];_0x989652++)if(!(_0x5528f4[_0x989652]==='.priority'&&_0x989652===_0x5528f4['length']-0x1)){if(!gs(_0x5528f4[_0x989652]))throw new Error(_0x52d9d7+'contains\x20an\x20invalid\x20key\x20('+_0x5528f4[_0x989652]+')\x20in\x20path\x20'+_0x13488d['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x44c6e8['sort'](Rh);let _0x446dca=null;for(_0x113c54=0x0;_0x113c54<_0x44c6e8['length'];_0x113c54++){if(_0x13488d=_0x44c6e8[_0x113c54],_0x446dca!==null&&G(_0x446dca,_0x13488d))throw new Error(_0x52d9d7+'contains\x20a\x20path\x20'+_0x446dca['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x13488d['toString']());_0x446dca=_0x13488d;}},fd=function(_0x4d6b61,_0xc9fa42,_0x1be422,_0x535405){const _0x308910=Pn(_0x4d6b61,'values');if(!(_0xc9fa42&&typeof _0xc9fa42=='object')||Array['isArray'](_0xc9fa42))throw new Error(_0x308910+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x149bee=[];x(_0xc9fa42,(_0x50c4f5,_0x2a6a4b)=>{const _0x5350d2=new C(_0x50c4f5);if(jt(_0x308910,_0x2a6a4b,k(_0x1be422,_0x5350d2)),zi(_0x5350d2)==='.priority'&&!Tn(_0x2a6a4b))throw new Error(_0x308910+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x5350d2['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x149bee['push'](_0x5350d2);}),dd(_0x308910,_0x149bee);},ms=function(_0x4199a0,_0x1da9cf,_0x3cd49a,_0x6f0765){if(!ra(_0x3cd49a))throw new Error(Pn(_0x4199a0,_0x1da9cf)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x3cd49a+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x14c281,_0x2280a2,_0x308131,_0x147d0d){_0x308131&&(_0x308131=_0x308131['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x14c281,_0x2280a2,_0x308131);},ys=function(_0x5569d3,_0x494a20){if(y(_0x494a20)==='.info')throw new Error(_0x5569d3+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x2177db,_0x161967){const _0x58f0c2=_0x161967['path']['toString']();if(typeof _0x161967['repoInfo']['host']!='string'||_0x161967['repoInfo']['host']['length']===0x0||!gs(_0x161967['repoInfo']['namespace'])&&_0x161967['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x58f0c2['length']!==0x0&&!ud(_0x58f0c2))throw new Error(Pn(_0x2177db,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x21ea25,_0x182fba){let _0x5e12d9=null;for(let _0x2918e3=0x0;_0x2918e3<_0x182fba['length'];_0x2918e3++){const _0x2f3241=_0x182fba[_0x2918e3],_0x22dae8=_0x2f3241['getPath']();_0x5e12d9!==null&&!ji(_0x22dae8,_0x5e12d9['path'])&&(_0x21ea25['eventLists_']['push'](_0x5e12d9),_0x5e12d9=null),_0x5e12d9===null&&(_0x5e12d9={'events':[],'path':_0x22dae8}),_0x5e12d9['events']['push'](_0x2f3241);}_0x5e12d9&&_0x21ea25['eventLists_']['push'](_0x5e12d9);}function oa(_0x171c14,_0x2348dd,_0x32235c){Vn(_0x171c14,_0x32235c),aa(_0x171c14,_0xbf2d53=>ji(_0xbf2d53,_0x2348dd));}function H(_0x10987c,_0x5abc6a,_0xf4dc02){Vn(_0x10987c,_0xf4dc02),aa(_0x10987c,_0x31d3b0=>G(_0x31d3b0,_0x5abc6a)||G(_0x5abc6a,_0x31d3b0));}function aa(_0x34ee18,_0x28abed){_0x34ee18['recursionDepth_']++;let _0x1bead5=!0x0;for(let _0x31343b=0x0;_0x31343b<_0x34ee18['eventLists_']['length'];_0x31343b++){const _0x5cb1af=_0x34ee18['eventLists_'][_0x31343b];if(_0x5cb1af){const _0x3a0adb=_0x5cb1af['path'];_0x28abed(_0x3a0adb)?(md(_0x34ee18['eventLists_'][_0x31343b]),_0x34ee18['eventLists_'][_0x31343b]=null):_0x1bead5=!0x1;}}_0x1bead5&&(_0x34ee18['eventLists_']=[]),_0x34ee18['recursionDepth_']--;}function md(_0x4abe75){for(let _0x5363f6=0x0;_0x5363f6<_0x4abe75['events']['length'];_0x5363f6++){const _0x3fa2c7=_0x4abe75['events'][_0x5363f6];if(_0x3fa2c7!==null){_0x4abe75['events'][_0x5363f6]=null;const _0x103e76=_0x3fa2c7['getEventRunner']();wt&&L('event:\x20'+_0x3fa2c7['toString']()),ht(_0x103e76);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x59f377,_0x1d8e75,_0x5b586c,_0x398e05){this['repoInfo_']=_0x59f377,this['forceRestClient_']=_0x1d8e75,this['authTokenProvider_']=_0x5b586c,this['appCheckProvider_']=_0x398e05,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x30c56f,_0x5596f9,_0x1d9a52){if(_0x30c56f['stats_']=Gi(_0x30c56f['repoInfo_']),_0x30c56f['forceRestClient_']||Xl())_0x30c56f['server_']=new pn(_0x30c56f['repoInfo_'],(_0xbda9e8,_0x3e4fda,_0x31f76a,_0x309855)=>{mr(_0x30c56f,_0xbda9e8,_0x3e4fda,_0x31f76a,_0x309855);},_0x30c56f['authTokenProvider_'],_0x30c56f['appCheckProvider_']),setTimeout(()=>yr(_0x30c56f,!0x0),0x0);else{if(typeof _0x1d9a52<'u'&&_0x1d9a52!==null){if(typeof _0x1d9a52!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x1d9a52);}catch(_0x469dee){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x469dee);}}_0x30c56f['persistentConnection_']=new se(_0x30c56f['repoInfo_'],_0x5596f9,(_0x1a1c55,_0xb2da37,_0xcd4b4d,_0x51cf80)=>{mr(_0x30c56f,_0x1a1c55,_0xb2da37,_0xcd4b4d,_0x51cf80);},_0x3ef5c3=>{yr(_0x30c56f,_0x3ef5c3);},_0x1b55dd=>{Id(_0x30c56f,_0x1b55dd);},_0x30c56f['authTokenProvider_'],_0x30c56f['appCheckProvider_'],_0x1d9a52),_0x30c56f['server_']=_0x30c56f['persistentConnection_'];}_0x30c56f['authTokenProvider_']['addTokenChangeListener'](_0x2708a9=>{_0x30c56f['server_']['refreshAuthToken'](_0x2708a9);}),_0x30c56f['appCheckProvider_']['addTokenChangeListener'](_0xf9350a=>{_0x30c56f['server_']['refreshAppCheckToken'](_0xf9350a['token']);}),_0x30c56f['statsReporter_']=ih(_0x30c56f['repoInfo_'],()=>new iu(_0x30c56f['stats_'],_0x30c56f['server_'])),_0x30c56f['infoData_']=new Xh(),_0x30c56f['infoSyncTree_']=new _r({'startListening':(_0x17ed3c,_0x336d22,_0x4e0c95,_0x462b7f)=>{let _0x501f94=[];const _0x3cbefe=_0x30c56f['infoData_']['getNode'](_0x17ed3c['_path']);return _0x3cbefe['isEmpty']()||(_0x501f94=Gt(_0x30c56f['infoSyncTree_'],_0x17ed3c['_path'],_0x3cbefe),setTimeout(()=>{_0x462b7f('ok');},0x0)),_0x501f94;},'stopListening':()=>{}}),vs(_0x30c56f,'connected',!0x1),_0x30c56f['serverSyncTree_']=new _r({'startListening':(_0x3b8935,_0x206919,_0x2a430a,_0x3b5690)=>(_0x30c56f['server_']['listen'](_0x3b8935,_0x2a430a,_0x206919,(_0x4f6582,_0x3ba4af)=>{const _0x5e1dde=_0x3b5690(_0x4f6582,_0x3ba4af);H(_0x30c56f['eventQueue_'],_0x3b8935['_path'],_0x5e1dde);}),[]),'stopListening':(_0x3bfbaf,_0x5b5185)=>{_0x30c56f['server_']['unlisten'](_0x3bfbaf,_0x5b5185);}});}function la(_0x6d464e){const _0x41cf27=_0x6d464e['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x41cf27;}function Kt(_0x4edace){return id({'timestamp':la(_0x4edace)});}function mr(_0x12a859,_0xdb4b60,_0x3074a0,_0x2b0928,_0x292b59){_0x12a859['dataUpdateCount']++;const _0x3569b2=new C(_0xdb4b60);_0x3074a0=_0x12a859['interceptServerDataCallback_']?_0x12a859['interceptServerDataCallback_'](_0xdb4b60,_0x3074a0):_0x3074a0;let _0x40df66=[];if(_0x292b59){if(_0x2b0928){const _0x10c29d=hn(_0x3074a0,_0x55cab7=>P(_0x55cab7));_0x40df66=Ju(_0x12a859['serverSyncTree_'],_0x3569b2,_0x10c29d,_0x292b59);}else{const _0x4d1ed8=P(_0x3074a0);_0x40df66=Xo(_0x12a859['serverSyncTree_'],_0x3569b2,_0x4d1ed8,_0x292b59);}}else{if(_0x2b0928){const _0x1c2fb4=hn(_0x3074a0,_0x2c3780=>P(_0x2c3780));_0x40df66=Ku(_0x12a859['serverSyncTree_'],_0x3569b2,_0x1c2fb4);}else{const _0x19c9b1=P(_0x3074a0);_0x40df66=Gt(_0x12a859['serverSyncTree_'],_0x3569b2,_0x19c9b1);}}let _0x390e72=_0x3569b2;_0x40df66['length']>0x0&&(_0x390e72=it(_0x12a859,_0x3569b2)),H(_0x12a859['eventQueue_'],_0x390e72,_0x40df66);}function yr(_0x3fba43,_0x3a6938){vs(_0x3fba43,'connected',_0x3a6938),_0x3a6938===!0x1&&Sd(_0x3fba43);}function Id(_0x4a625d,_0x23a7ca){x(_0x23a7ca,(_0x415438,_0x3be9e8)=>{vs(_0x4a625d,_0x415438,_0x3be9e8);});}function vs(_0xb51f91,_0x2e0894,_0x5dc16d){const _0x53d18c=new C('/.info/'+_0x2e0894),_0x24f2f8=P(_0x5dc16d);_0xb51f91['infoData_']['updateSnapshot'](_0x53d18c,_0x24f2f8);const _0x355ef5=Gt(_0xb51f91['infoSyncTree_'],_0x53d18c,_0x24f2f8);H(_0xb51f91['eventQueue_'],_0x53d18c,_0x355ef5);}function Hn(_0x5f4cc5){return _0x5f4cc5['nextWriteId_']++;}function wd(_0x25cda7,_0x5d7911,_0x4dcd8e){const _0x3329e4=Xu(_0x25cda7['serverSyncTree_'],_0x5d7911);return _0x3329e4!=null?Promise['resolve'](_0x3329e4):_0x25cda7['server_']['get'](_0x5d7911)['then'](_0x5f554d=>{const _0x522301=P(_0x5f554d)['withIndex'](_0x5d7911['_queryParams']['getIndex']());Ri(_0x25cda7['serverSyncTree_'],_0x5d7911,_0x4dcd8e,!0x0);let _0x458d4d;if(_0x5d7911['_queryParams']['loadsAllData']())_0x458d4d=Gt(_0x25cda7['serverSyncTree_'],_0x5d7911['_path'],_0x522301);else{const _0x357ae5=xt(_0x25cda7['serverSyncTree_'],_0x5d7911);_0x458d4d=Xo(_0x25cda7['serverSyncTree_'],_0x5d7911['_path'],_0x522301,_0x357ae5);}return H(_0x25cda7['eventQueue_'],_0x5d7911['_path'],_0x458d4d),Cn(_0x25cda7['serverSyncTree_'],_0x5d7911,_0x4dcd8e,null,!0x0),_0x522301;},_0x14bfb3=>(dt(_0x25cda7,'get\x20for\x20query\x20'+O(_0x5d7911)+'\x20failed:\x20'+_0x14bfb3),Promise['reject'](new Error(_0x14bfb3))));}function Cd(_0x358c7f,_0x595d70,_0x2c3e74,_0xa01610,_0x251a2a){dt(_0x358c7f,'set',{'path':_0x595d70['toString'](),'value':_0x2c3e74,'priority':_0xa01610});const _0x83aae9=Kt(_0x358c7f),_0x4bb53d=P(_0x2c3e74,_0xa01610),_0x2737ae=Fn(_0x358c7f['serverSyncTree_'],_0x595d70),_0x373d1b=ds(_0x4bb53d,_0x2737ae,_0x83aae9),_0x2851dc=Hn(_0x358c7f),_0xf9a6d8=os(_0x358c7f['serverSyncTree_'],_0x595d70,_0x373d1b,_0x2851dc,!0x0);Vn(_0x358c7f['eventQueue_'],_0xf9a6d8),_0x358c7f['server_']['put'](_0x595d70['toString'](),_0x4bb53d['val'](!0x0),(_0x25f5f4,_0x5cb5c6)=>{const _0x3b25a7=_0x25f5f4==='ok';_0x3b25a7||U('set\x20at\x20'+_0x595d70+'\x20failed:\x20'+_0x25f5f4);const _0x1731a1=pe(_0x358c7f['serverSyncTree_'],_0x2851dc,!_0x3b25a7);H(_0x358c7f['eventQueue_'],_0x595d70,_0x1731a1),ki(_0x358c7f,_0x251a2a,_0x25f5f4,_0x5cb5c6);});const _0x3ff72e=Is(_0x358c7f,_0x595d70);it(_0x358c7f,_0x3ff72e),H(_0x358c7f['eventQueue_'],_0x3ff72e,[]);}function Td(_0x235d29,_0x2415f3,_0xbc5d38,_0x4e0cbb){dt(_0x235d29,'update',{'path':_0x2415f3['toString'](),'value':_0xbc5d38});let _0x360274=!0x0;const _0x4e96c4=Kt(_0x235d29),_0x3064ac={};if(x(_0xbc5d38,(_0x2f4bf4,_0x3e2f57)=>{_0x360274=!0x1,_0x3064ac[_0x2f4bf4]=na(k(_0x2415f3,_0x2f4bf4),P(_0x3e2f57),_0x235d29['serverSyncTree_'],_0x4e96c4);}),_0x360274)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x235d29,_0x4e0cbb,'ok',void 0x0);else{const _0x9063fd=Hn(_0x235d29),_0x2685ce=ju(_0x235d29['serverSyncTree_'],_0x2415f3,_0x3064ac,_0x9063fd);Vn(_0x235d29['eventQueue_'],_0x2685ce),_0x235d29['server_']['merge'](_0x2415f3['toString'](),_0xbc5d38,(_0x539a2d,_0x2ee3ff)=>{const _0x2885ee=_0x539a2d==='ok';_0x2885ee||U('update\x20at\x20'+_0x2415f3+'\x20failed:\x20'+_0x539a2d);const _0x35d1bb=pe(_0x235d29['serverSyncTree_'],_0x9063fd,!_0x2885ee),_0x5e84f8=_0x35d1bb['length']>0x0?it(_0x235d29,_0x2415f3):_0x2415f3;H(_0x235d29['eventQueue_'],_0x5e84f8,_0x35d1bb),ki(_0x235d29,_0x4e0cbb,_0x539a2d,_0x2ee3ff);}),x(_0xbc5d38,_0x2e0d6e=>{const _0x5170e3=Is(_0x235d29,k(_0x2415f3,_0x2e0d6e));it(_0x235d29,_0x5170e3);}),H(_0x235d29['eventQueue_'],_0x2415f3,[]);}}function Sd(_0x362d19){dt(_0x362d19,'onDisconnectEvents');const _0x4e7b7a=Kt(_0x362d19),_0x1d37f7=_n();Ii(_0x362d19['onDisconnect_'],w(),(_0x4791b3,_0x5db891)=>{const _0x3e38b1=na(_0x4791b3,_0x5db891,_0x362d19['serverSyncTree_'],_0x4e7b7a);Fo(_0x1d37f7,_0x4791b3,_0x3e38b1);});let _0x2fd362=[];Ii(_0x1d37f7,w(),(_0x46de53,_0x49bc79)=>{_0x2fd362=_0x2fd362['concat'](Gt(_0x362d19['serverSyncTree_'],_0x46de53,_0x49bc79));const _0x251513=Is(_0x362d19,_0x46de53);it(_0x362d19,_0x251513);}),_0x362d19['onDisconnect_']=_n(),H(_0x362d19['eventQueue_'],w(),_0x2fd362);}function bd(_0x5b8db8,_0x1f6909,_0x39057c){let _0x4b53d3;y(_0x1f6909['_path'])==='.info'?_0x4b53d3=Ri(_0x5b8db8['infoSyncTree_'],_0x1f6909,_0x39057c):_0x4b53d3=Ri(_0x5b8db8['serverSyncTree_'],_0x1f6909,_0x39057c),oa(_0x5b8db8['eventQueue_'],_0x1f6909['_path'],_0x4b53d3);}function Rd(_0xdae181,_0x22e14f,_0x1899e5){let _0x1b64d5;y(_0x22e14f['_path'])==='.info'?_0x1b64d5=Cn(_0xdae181['infoSyncTree_'],_0x22e14f,_0x1899e5):_0x1b64d5=Cn(_0xdae181['serverSyncTree_'],_0x22e14f,_0x1899e5),oa(_0xdae181['eventQueue_'],_0x22e14f['_path'],_0x1b64d5);}function ha(_0x29f927){_0x29f927['persistentConnection_']&&_0x29f927['persistentConnection_']['interrupt'](ca);}function Ad(_0x397ec1){_0x397ec1['persistentConnection_']&&_0x397ec1['persistentConnection_']['resume'](ca);}function dt(_0x3dd01c,..._0xeaf6a0){let _0x91838a='';_0x3dd01c['persistentConnection_']&&(_0x91838a=_0x3dd01c['persistentConnection_']['id']+':'),L(_0x91838a,..._0xeaf6a0);}function ki(_0x351b6c,_0x3e85d8,_0x5a5732,_0x52ba8a){_0x3e85d8&&ht(()=>{if(_0x5a5732==='ok')_0x3e85d8(null);else{const _0x27db45=(_0x5a5732||'error')['toUpperCase']();let _0x3898fc=_0x27db45;_0x52ba8a&&(_0x3898fc+=':\x20'+_0x52ba8a);const _0x56f694=new Error(_0x3898fc);_0x56f694['code']=_0x27db45,_0x3e85d8(_0x56f694);}});}function kd(_0x5a5160,_0xdc8c26,_0x3d8b02,_0xc59053,_0x5ec218,_0x436016){dt(_0x5a5160,'transaction\x20on\x20'+_0xdc8c26);const _0x4fde77={'path':_0xdc8c26,'update':_0x3d8b02,'onComplete':_0xc59053,'status':null,'order':so(),'applyLocally':_0x436016,'retryCount':0x0,'unwatcher':_0x5ec218,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x47cc15=Es(_0x5a5160,_0xdc8c26,void 0x0);_0x4fde77['currentInputSnapshot']=_0x47cc15;const _0x575439=_0x4fde77['update'](_0x47cc15['val']());if(_0x575439===void 0x0)_0x4fde77['unwatcher'](),_0x4fde77['currentOutputSnapshotRaw']=null,_0x4fde77['currentOutputSnapshotResolved']=null,_0x4fde77['onComplete']&&_0x4fde77['onComplete'](null,!0x1,_0x4fde77['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x575439,_0x4fde77['path']),_0x4fde77['status']=0x0;const _0x5943d0=Wn(_0x5a5160['transactionQueueTree_'],_0xdc8c26),_0x2c1306=Ge(_0x5943d0)||[];_0x2c1306['push'](_0x4fde77),_s(_0x5943d0,_0x2c1306);let _0x44c554;typeof _0x575439=='object'&&_0x575439!==null&&J(_0x575439,'.priority')?(_0x44c554=De(_0x575439,'.priority'),f(Tn(_0x44c554),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x44c554=(Fn(_0x5a5160['serverSyncTree_'],_0xdc8c26)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x37b82a=Kt(_0x5a5160),_0x5f57d6=P(_0x575439,_0x44c554),_0x3d8c2b=ds(_0x5f57d6,_0x47cc15,_0x37b82a);_0x4fde77['currentOutputSnapshotRaw']=_0x5f57d6,_0x4fde77['currentOutputSnapshotResolved']=_0x3d8c2b,_0x4fde77['currentWriteId']=Hn(_0x5a5160);const _0x3ca164=os(_0x5a5160['serverSyncTree_'],_0xdc8c26,_0x3d8c2b,_0x4fde77['currentWriteId'],_0x4fde77['applyLocally']);H(_0x5a5160['eventQueue_'],_0xdc8c26,_0x3ca164),$n(_0x5a5160,_0x5a5160['transactionQueueTree_']);}}function Es(_0x336287,_0x29f8a3,_0x29423b){return Fn(_0x336287['serverSyncTree_'],_0x29f8a3,_0x29423b)||g['EMPTY_NODE'];}function $n(_0x412413,_0x3be4a1=_0x412413['transactionQueueTree_']){if(_0x3be4a1||Gn(_0x412413,_0x3be4a1),Ge(_0x3be4a1)){const _0x91b9cd=da(_0x412413,_0x3be4a1);f(_0x91b9cd['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x91b9cd['every'](_0x2eb84f=>_0x2eb84f['status']===0x0)&&Nd(_0x412413,qt(_0x3be4a1),_0x91b9cd);}else ia(_0x3be4a1)&&Bn(_0x3be4a1,_0x5ded16=>{$n(_0x412413,_0x5ded16);});}function Nd(_0x47ab57,_0x740e16,_0x21372a){const _0x2a6258=_0x21372a['map'](_0xd96aba=>_0xd96aba['currentWriteId']),_0x2da9db=Es(_0x47ab57,_0x740e16,_0x2a6258);let _0x54d90f=_0x2da9db;const _0x52eedf=_0x2da9db['hash']();for(let _0x389bc6=0x0;_0x389bc6<_0x21372a['length'];_0x389bc6++){const _0x1c1177=_0x21372a[_0x389bc6];f(_0x1c1177['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x1c1177['status']=0x1,_0x1c1177['retryCount']++;const _0x296f30=F(_0x740e16,_0x1c1177['path']);_0x54d90f=_0x54d90f['updateChild'](_0x296f30,_0x1c1177['currentOutputSnapshotRaw']);}const _0x544e7a=_0x54d90f['val'](!0x0),_0x3cf7f3=_0x740e16;_0x47ab57['server_']['put'](_0x3cf7f3['toString'](),_0x544e7a,_0x24e40d=>{dt(_0x47ab57,'transaction\x20put\x20response',{'path':_0x3cf7f3['toString'](),'status':_0x24e40d});let _0x21d5dc=[];if(_0x24e40d==='ok'){const _0x4a04bf=[];for(let _0x3224a0=0x0;_0x3224a0<_0x21372a['length'];_0x3224a0++)_0x21372a[_0x3224a0]['status']=0x2,_0x21d5dc=_0x21d5dc['concat'](pe(_0x47ab57['serverSyncTree_'],_0x21372a[_0x3224a0]['currentWriteId'])),_0x21372a[_0x3224a0]['onComplete']&&_0x4a04bf['push'](()=>_0x21372a[_0x3224a0]['onComplete'](null,!0x0,_0x21372a[_0x3224a0]['currentOutputSnapshotResolved'])),_0x21372a[_0x3224a0]['unwatcher']();Gn(_0x47ab57,Wn(_0x47ab57['transactionQueueTree_'],_0x740e16)),$n(_0x47ab57,_0x47ab57['transactionQueueTree_']),H(_0x47ab57['eventQueue_'],_0x740e16,_0x21d5dc);for(let _0x3dbdc2=0x0;_0x3dbdc2<_0x4a04bf['length'];_0x3dbdc2++)ht(_0x4a04bf[_0x3dbdc2]);}else{if(_0x24e40d==='datastale'){for(let _0x36b76f=0x0;_0x36b76f<_0x21372a['length'];_0x36b76f++)_0x21372a[_0x36b76f]['status']===0x3?_0x21372a[_0x36b76f]['status']=0x4:_0x21372a[_0x36b76f]['status']=0x0;}else{U('transaction\x20at\x20'+_0x3cf7f3['toString']()+'\x20failed:\x20'+_0x24e40d);for(let _0x55ab98=0x0;_0x55ab98<_0x21372a['length'];_0x55ab98++)_0x21372a[_0x55ab98]['status']=0x4,_0x21372a[_0x55ab98]['abortReason']=_0x24e40d;}it(_0x47ab57,_0x740e16);}},_0x52eedf);}function it(_0x4400ef,_0x2cac97){const _0x2060c1=ua(_0x4400ef,_0x2cac97),_0x43d6d3=qt(_0x2060c1),_0x1e190d=da(_0x4400ef,_0x2060c1);return Pd(_0x4400ef,_0x1e190d,_0x43d6d3),_0x43d6d3;}function Pd(_0x695e86,_0x43530a,_0x188cd4){if(_0x43530a['length']===0x0)return;const _0x50ee2c=[];let _0x2f489a=[];const _0x4a480d=_0x43530a['filter'](_0x547e07=>_0x547e07['status']===0x0)['map'](_0x214be6=>_0x214be6['currentWriteId']);for(let _0x124fad=0x0;_0x124fad<_0x43530a['length'];_0x124fad++){const _0x53339b=_0x43530a[_0x124fad],_0x3b40ed=F(_0x188cd4,_0x53339b['path']);let _0x3284dd=!0x1,_0x16abaa;if(f(_0x3b40ed!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x53339b['status']===0x4)_0x3284dd=!0x0,_0x16abaa=_0x53339b['abortReason'],_0x2f489a=_0x2f489a['concat'](pe(_0x695e86['serverSyncTree_'],_0x53339b['currentWriteId'],!0x0));else{if(_0x53339b['status']===0x0){if(_0x53339b['retryCount']>=yd)_0x3284dd=!0x0,_0x16abaa='maxretry',_0x2f489a=_0x2f489a['concat'](pe(_0x695e86['serverSyncTree_'],_0x53339b['currentWriteId'],!0x0));else{const _0x536c8a=Es(_0x695e86,_0x53339b['path'],_0x4a480d);_0x53339b['currentInputSnapshot']=_0x536c8a;const _0x57d2bc=_0x43530a[_0x124fad]['update'](_0x536c8a['val']());if(_0x57d2bc!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x57d2bc,_0x53339b['path']);let _0x5d6f09=P(_0x57d2bc);typeof _0x57d2bc=='object'&&_0x57d2bc!=null&&J(_0x57d2bc,'.priority')||(_0x5d6f09=_0x5d6f09['updatePriority'](_0x536c8a['getPriority']()));const _0x203409=_0x53339b['currentWriteId'],_0x233fcb=Kt(_0x695e86),_0x320dc8=ds(_0x5d6f09,_0x536c8a,_0x233fcb);_0x53339b['currentOutputSnapshotRaw']=_0x5d6f09,_0x53339b['currentOutputSnapshotResolved']=_0x320dc8,_0x53339b['currentWriteId']=Hn(_0x695e86),_0x4a480d['splice'](_0x4a480d['indexOf'](_0x203409),0x1),_0x2f489a=_0x2f489a['concat'](os(_0x695e86['serverSyncTree_'],_0x53339b['path'],_0x320dc8,_0x53339b['currentWriteId'],_0x53339b['applyLocally'])),_0x2f489a=_0x2f489a['concat'](pe(_0x695e86['serverSyncTree_'],_0x203409,!0x0));}else _0x3284dd=!0x0,_0x16abaa='nodata',_0x2f489a=_0x2f489a['concat'](pe(_0x695e86['serverSyncTree_'],_0x53339b['currentWriteId'],!0x0));}}}H(_0x695e86['eventQueue_'],_0x188cd4,_0x2f489a),_0x2f489a=[],_0x3284dd&&(_0x43530a[_0x124fad]['status']=0x2,function(_0x261e35){setTimeout(_0x261e35,Math['floor'](0x0));}(_0x43530a[_0x124fad]['unwatcher']),_0x43530a[_0x124fad]['onComplete']&&(_0x16abaa==='nodata'?_0x50ee2c['push'](()=>_0x43530a[_0x124fad]['onComplete'](null,!0x1,_0x43530a[_0x124fad]['currentInputSnapshot'])):_0x50ee2c['push'](()=>_0x43530a[_0x124fad]['onComplete'](new Error(_0x16abaa),!0x1,null))));}Gn(_0x695e86,_0x695e86['transactionQueueTree_']);for(let _0x16c7fc=0x0;_0x16c7fc<_0x50ee2c['length'];_0x16c7fc++)ht(_0x50ee2c[_0x16c7fc]);$n(_0x695e86,_0x695e86['transactionQueueTree_']);}function ua(_0x4b2b4f,_0x17f438){let _0x2a8858,_0x197e4e=_0x4b2b4f['transactionQueueTree_'];for(_0x2a8858=y(_0x17f438);_0x2a8858!==null&&Ge(_0x197e4e)===void 0x0;)_0x197e4e=Wn(_0x197e4e,_0x2a8858),_0x17f438=b(_0x17f438),_0x2a8858=y(_0x17f438);return _0x197e4e;}function da(_0x2f1963,_0xd89634){const _0x3fe3f7=[];return fa(_0x2f1963,_0xd89634,_0x3fe3f7),_0x3fe3f7['sort']((_0x37689a,_0x3cb249)=>_0x37689a['order']-_0x3cb249['order']),_0x3fe3f7;}function fa(_0x14540d,_0x5dc253,_0x12d41f){const _0x42903b=Ge(_0x5dc253);if(_0x42903b){for(let _0x537cf8=0x0;_0x537cf8<_0x42903b['length'];_0x537cf8++)_0x12d41f['push'](_0x42903b[_0x537cf8]);}Bn(_0x5dc253,_0x11113b=>{fa(_0x14540d,_0x11113b,_0x12d41f);});}function Gn(_0xcdb3b8,_0x10a2db){const _0x1380d2=Ge(_0x10a2db);if(_0x1380d2){let _0x242efb=0x0;for(let _0x1067a7=0x0;_0x1067a7<_0x1380d2['length'];_0x1067a7++)_0x1380d2[_0x1067a7]['status']!==0x2&&(_0x1380d2[_0x242efb]=_0x1380d2[_0x1067a7],_0x242efb++);_0x1380d2['length']=_0x242efb,_s(_0x10a2db,_0x1380d2['length']>0x0?_0x1380d2:void 0x0);}Bn(_0x10a2db,_0x5b1082=>{Gn(_0xcdb3b8,_0x5b1082);});}function Is(_0x29e388,_0x519227){const _0x501fd5=qt(ua(_0x29e388,_0x519227)),_0x402389=Wn(_0x29e388['transactionQueueTree_'],_0x519227);return ad(_0x402389,_0x312682=>{ci(_0x29e388,_0x312682);}),ci(_0x29e388,_0x402389),sa(_0x402389,_0x1e696e=>{ci(_0x29e388,_0x1e696e);}),_0x501fd5;}function ci(_0x320fac,_0x5189fc){const _0x4cf336=Ge(_0x5189fc);if(_0x4cf336){const _0xbc122e=[];let _0x2e029d=[],_0x276558=-0x1;for(let _0xa18201=0x0;_0xa18201<_0x4cf336['length'];_0xa18201++)_0x4cf336[_0xa18201]['status']===0x3||(_0x4cf336[_0xa18201]['status']===0x1?(f(_0x276558===_0xa18201-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x276558=_0xa18201,_0x4cf336[_0xa18201]['status']=0x3,_0x4cf336[_0xa18201]['abortReason']='set'):(f(_0x4cf336[_0xa18201]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x4cf336[_0xa18201]['unwatcher'](),_0x2e029d=_0x2e029d['concat'](pe(_0x320fac['serverSyncTree_'],_0x4cf336[_0xa18201]['currentWriteId'],!0x0)),_0x4cf336[_0xa18201]['onComplete']&&_0xbc122e['push'](_0x4cf336[_0xa18201]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x276558===-0x1?_s(_0x5189fc,void 0x0):_0x4cf336['length']=_0x276558+0x1,H(_0x320fac['eventQueue_'],qt(_0x5189fc),_0x2e029d);for(let _0x96abd0=0x0;_0x96abd0<_0xbc122e['length'];_0x96abd0++)ht(_0xbc122e[_0x96abd0]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x1603db){let _0x314249='';const _0x17148b=_0x1603db['split']('/');for(let _0x2d04c9=0x0;_0x2d04c9<_0x17148b['length'];_0x2d04c9++)if(_0x17148b[_0x2d04c9]['length']>0x0){let _0x20a1dd=_0x17148b[_0x2d04c9];try{_0x20a1dd=decodeURIComponent(_0x20a1dd['replace'](/\+/g,'\x20'));}catch{}_0x314249+='/'+_0x20a1dd;}return _0x314249;}function Dd(_0x5c2753){const _0x4daf6c={};_0x5c2753['charAt'](0x0)==='?'&&(_0x5c2753=_0x5c2753['substring'](0x1));for(const _0x3bc5fc of _0x5c2753['split']('&')){if(_0x3bc5fc['length']===0x0)continue;const _0x12acae=_0x3bc5fc['split']('=');_0x12acae['length']===0x2?_0x4daf6c[decodeURIComponent(_0x12acae[0x0])]=decodeURIComponent(_0x12acae[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x3bc5fc+'\x27\x20in\x20query\x20\x27'+_0x5c2753+'\x27');}return _0x4daf6c;}const vr=function(_0xc58454,_0x11a91f){const _0x1493f1=Md(_0xc58454),_0x2c27a7=_0x1493f1['namespace'];_0x1493f1['domain']==='firebase.com'&&ae(_0x1493f1['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x2c27a7||_0x2c27a7==='undefined')&&_0x1493f1['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x1493f1['secure']||$l();const _0x1df825=_0x1493f1['scheme']==='ws'||_0x1493f1['scheme']==='wss';return{'repoInfo':new yo(_0x1493f1['host'],_0x1493f1['secure'],_0x2c27a7,_0x1df825,_0x11a91f,'',_0x2c27a7!==_0x1493f1['subdomain']),'path':new C(_0x1493f1['pathString'])};},Md=function(_0x23adf1){let _0x499b62='',_0x1d33cc='',_0x553c7b='',_0x54e5e6='',_0x2da868='',_0x496e8a=!0x0,_0x2ae91c='https',_0x533127=0x1bb;if(typeof _0x23adf1=='string'){let _0x4ee071=_0x23adf1['indexOf']('//');_0x4ee071>=0x0&&(_0x2ae91c=_0x23adf1['substring'](0x0,_0x4ee071-0x1),_0x23adf1=_0x23adf1['substring'](_0x4ee071+0x2));let _0x3671cc=_0x23adf1['indexOf']('/');_0x3671cc===-0x1&&(_0x3671cc=_0x23adf1['length']);let _0x54eab6=_0x23adf1['indexOf']('?');_0x54eab6===-0x1&&(_0x54eab6=_0x23adf1['length']),_0x499b62=_0x23adf1['substring'](0x0,Math['min'](_0x3671cc,_0x54eab6)),_0x3671cc<_0x54eab6&&(_0x54e5e6=Od(_0x23adf1['substring'](_0x3671cc,_0x54eab6)));const _0x163676=Dd(_0x23adf1['substring'](Math['min'](_0x23adf1['length'],_0x54eab6)));_0x4ee071=_0x499b62['indexOf'](':'),_0x4ee071>=0x0?(_0x496e8a=_0x2ae91c==='https'||_0x2ae91c==='wss',_0x533127=parseInt(_0x499b62['substring'](_0x4ee071+0x1),0xa)):_0x4ee071=_0x499b62['length'];const _0x3733ce=_0x499b62['slice'](0x0,_0x4ee071);if(_0x3733ce['toLowerCase']()==='localhost')_0x1d33cc='localhost';else{if(_0x3733ce['split']('.')['length']<=0x2)_0x1d33cc=_0x3733ce;else{const _0x22a305=_0x499b62['indexOf']('.');_0x553c7b=_0x499b62['substring'](0x0,_0x22a305)['toLowerCase'](),_0x1d33cc=_0x499b62['substring'](_0x22a305+0x1),_0x2da868=_0x553c7b;}}'ns'in _0x163676&&(_0x2da868=_0x163676['ns']);}return{'host':_0x499b62,'port':_0x533127,'domain':_0x1d33cc,'subdomain':_0x553c7b,'secure':_0x496e8a,'scheme':_0x2ae91c,'pathString':_0x54e5e6,'namespace':_0x2da868};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x535ebd=0x0;const _0x163507=[];return function(_0x500c3b){const _0x560177=_0x500c3b===_0x535ebd;_0x535ebd=_0x500c3b;let _0xaa628d;const _0x3eae44=new Array(0x8);for(_0xaa628d=0x7;_0xaa628d>=0x0;_0xaa628d--)_0x3eae44[_0xaa628d]=Er['charAt'](_0x500c3b%0x40),_0x500c3b=Math['floor'](_0x500c3b/0x40);f(_0x500c3b===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x46e872=_0x3eae44['join']('');if(_0x560177){for(_0xaa628d=0xb;_0xaa628d>=0x0&&_0x163507[_0xaa628d]===0x3f;_0xaa628d--)_0x163507[_0xaa628d]=0x0;_0x163507[_0xaa628d]++;}else{for(_0xaa628d=0x0;_0xaa628d<0xc;_0xaa628d++)_0x163507[_0xaa628d]=Math['floor'](Math['random']()*0x40);}for(_0xaa628d=0x0;_0xaa628d<0xc;_0xaa628d++)_0x46e872+=Er['charAt'](_0x163507[_0xaa628d]);return f(_0x46e872['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x46e872;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x42c524,_0x251c4e,_0x40077e,_0x1e1f34){this['eventType']=_0x42c524,this['eventRegistration']=_0x251c4e,this['snapshot']=_0x40077e,this['prevName']=_0x1e1f34;}['getPath'](){const _0x240901=this['snapshot']['ref'];return this['eventType']==='value'?_0x240901['_path']:_0x240901['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0xa65020,_0xd24c0c,_0x2fce50){this['eventRegistration']=_0xa65020,this['error']=_0xd24c0c,this['path']=_0x2fce50;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x42f192,_0x3c2d09){this['snapshotCallback']=_0x42f192,this['cancelCallback']=_0x3c2d09;}['onValue'](_0x3156e5,_0x50e3a4){this['snapshotCallback']['call'](null,_0x3156e5,_0x50e3a4);}['onCancel'](_0x3c2dd5){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x3c2dd5);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x456bfb){return this['snapshotCallback']===_0x456bfb['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x456bfb['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x456bfb['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x5647d3,_0x550d34,_0x48ff50,_0x131a24){this['_repo']=_0x5647d3,this['_path']=_0x550d34,this['_queryParams']=_0x48ff50,this['_orderByCalled']=_0x131a24;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x137363=rr(this['_queryParams']),_0x53d5f9=Hi(_0x137363);return _0x53d5f9==='{}'?'default':_0x53d5f9;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0xce63cf){if(_0xce63cf=N(_0xce63cf),!(_0xce63cf instanceof be))return!0x1;const _0x2c610c=this['_repo']===_0xce63cf['_repo'],_0x3faa5e=ji(this['_path'],_0xce63cf['_path']),_0x5aded7=this['_queryIdentifier']===_0xce63cf['_queryIdentifier'];return _0x2c610c&&_0x3faa5e&&_0x5aded7;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x509b49,_0x15bc91){if(_0x509b49['_orderByCalled']===!0x0)throw new Error(_0x15bc91+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x5df598){let _0x407b80=null,_0x5de5ee=null;if(_0x5df598['hasStart']()&&(_0x407b80=_0x5df598['getIndexStartValue']()),_0x5df598['hasEnd']()&&(_0x5de5ee=_0x5df598['getIndexEndValue']()),_0x5df598['getIndex']()===ye){const _0x5b64f3='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x57bedc='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x5df598['hasStart']()){if(_0x5df598['getIndexStartName']()!==Fe)throw new Error(_0x5b64f3);if(typeof _0x407b80!='string')throw new Error(_0x57bedc);}if(_0x5df598['hasEnd']()){if(_0x5df598['getIndexEndName']()!==Ie)throw new Error(_0x5b64f3);if(typeof _0x5de5ee!='string')throw new Error(_0x57bedc);}}else{if(_0x5df598['getIndex']()===R){if(_0x407b80!=null&&!Tn(_0x407b80)||_0x5de5ee!=null&&!Tn(_0x5de5ee))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x5df598['getIndex']()instanceof Qi||_0x5df598['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x407b80!=null&&typeof _0x407b80=='object'||_0x5de5ee!=null&&typeof _0x5de5ee=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x20663e){if(_0x20663e['hasStart']()&&_0x20663e['hasEnd']()&&_0x20663e['hasLimit']()&&!_0x20663e['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x59b78c,_0x1d3d78){super(_0x59b78c,_0x1d3d78,new Xi(),!0x1);}get['parent'](){const _0x12253f=Ro(this['_path']);return _0x12253f===null?null:new ee(this['_repo'],_0x12253f);}get['root'](){let _0x30c1e5=this;for(;_0x30c1e5['parent']!==null;)_0x30c1e5=_0x30c1e5['parent'];return _0x30c1e5;}}class st{constructor(_0x28d8a4,_0x582875,_0x4cf1c2){this['_node']=_0x28d8a4,this['ref']=_0x582875,this['_index']=_0x4cf1c2;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x51f374){const _0x44f98b=new C(_0x51f374),_0x129ed7=Ft(this['ref'],_0x51f374);return new st(this['_node']['getChild'](_0x44f98b),_0x129ed7,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x2b7979){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x20b3be,_0xb34e4f)=>_0x2b7979(new st(_0xb34e4f,Ft(this['ref'],_0x20b3be),R)));}['hasChild'](_0x1fb90f){const _0x573ad4=new C(_0x1fb90f);return!this['_node']['getChild'](_0x573ad4)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x1e1a1a,_0x511334){return _0x1e1a1a=N(_0x1e1a1a),_0x1e1a1a['_checkNotDeleted']('ref'),_0x511334!==void 0x0?Ft(_0x1e1a1a['_root'],_0x511334):_0x1e1a1a['_root'];}function Ft(_0x19b36b,_0x5dcab1){return _0x19b36b=N(_0x19b36b),y(_0x19b36b['_path'])===null?pd('child','path',_0x5dcab1):ms('child','path',_0x5dcab1),new ee(_0x19b36b['_repo'],k(_0x19b36b['_path'],_0x5dcab1));}function g_(_0x275eab,_0x43f02c){_0x275eab=N(_0x275eab),ys('push',_0x275eab['_path']),zt('push',_0x43f02c,_0x275eab['_path'],!0x0);const _0x34d3c4=la(_0x275eab['_repo']),_0x44609f=Ld(_0x34d3c4),_0x3a704a=Ft(_0x275eab,_0x44609f),_0x2335ad=Ft(_0x275eab,_0x44609f);let _0x38de12;return _0x43f02c!=null?_0x38de12=Ud(_0x2335ad,_0x43f02c)['then'](()=>_0x2335ad):_0x38de12=Promise['resolve'](_0x2335ad),_0x3a704a['then']=_0x38de12['then']['bind'](_0x38de12),_0x3a704a['catch']=_0x38de12['then']['bind'](_0x38de12,void 0x0),_0x3a704a;}function Ud(_0x5d4ed8,_0x5b26fd){_0x5d4ed8=N(_0x5d4ed8),ys('set',_0x5d4ed8['_path']),zt('set',_0x5b26fd,_0x5d4ed8['_path'],!0x1);const _0x587c94=new ot();return Cd(_0x5d4ed8['_repo'],_0x5d4ed8['_path'],_0x5b26fd,null,_0x587c94['wrapCallback'](()=>{})),_0x587c94['promise'];}function m_(_0x1deda3,_0x14c46e){fd('update',_0x14c46e,_0x1deda3['_path']);const _0x544949=new ot();return Td(_0x1deda3['_repo'],_0x1deda3['_path'],_0x14c46e,_0x544949['wrapCallback'](()=>{})),_0x544949['promise'];}function y_(_0x418f27){_0x418f27=N(_0x418f27);const _0x344abd=new pa(()=>{}),_0x4941c5=new zn(_0x344abd);return wd(_0x418f27['_repo'],_0x418f27,_0x4941c5)['then'](_0x41a5ae=>new st(_0x41a5ae,new ee(_0x418f27['_repo'],_0x418f27['_path']),_0x418f27['_queryParams']['getIndex']()));}class zn{constructor(_0x219152){this['callbackContext']=_0x219152;}['respondsTo'](_0x149673){return _0x149673==='value';}['createEvent'](_0x653e88,_0x12a3de){const _0x685212=_0x12a3de['_queryParams']['getIndex']();return new xd('value',this,new st(_0x653e88['snapshotNode'],new ee(_0x12a3de['_repo'],_0x12a3de['_path']),_0x685212));}['getEventRunner'](_0x4f3aef){return _0x4f3aef['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x4f3aef['error']):()=>this['callbackContext']['onValue'](_0x4f3aef['snapshot'],null);}['createCancelEvent'](_0x12b7e2,_0x2d21bf){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x12b7e2,_0x2d21bf):null;}['matches'](_0x4e38ce){return _0x4e38ce instanceof zn?!_0x4e38ce['callbackContext']||!this['callbackContext']?!0x0:_0x4e38ce['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x182d7a,_0x2de2d1,_0x4b3e2c,_0xc4c8dc,_0x912be3){const _0xc00d3c=new pa(_0x4b3e2c,void 0x0),_0x41a710=new zn(_0xc00d3c);return bd(_0x182d7a['_repo'],_0x182d7a,_0x41a710),()=>Rd(_0x182d7a['_repo'],_0x182d7a,_0x41a710);}function Bd(_0x13d910,_0x2283e4,_0x378cb8,_0x28c0d9){return Wd(_0x13d910,'value',_0x2283e4);}class ft{}class ma extends ft{constructor(_0x38abc9,_0x110fa7){super(),this['_value']=_0x38abc9,this['_key']=_0x110fa7,this['type']='endAt';}['_apply'](_0x2e9bea){zt('endAt',this['_value'],_0x2e9bea['_path'],!0x0);const _0x57d81c=Jh(_0x2e9bea['_queryParams'],this['_value'],this['_key']);if(ga(_0x57d81c),qn(_0x57d81c),_0x2e9bea['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x2e9bea['_repo'],_0x2e9bea['_path'],_0x57d81c,_0x2e9bea['_orderByCalled']);}}function v_(_0x5bec22,_0x492f90){return new ma(_0x5bec22,_0x492f90);}class ya extends ft{constructor(_0x51156e,_0x4796dc){super(),this['_value']=_0x51156e,this['_key']=_0x4796dc,this['type']='startAt';}['_apply'](_0x2fde32){zt('startAt',this['_value'],_0x2fde32['_path'],!0x0);const _0x4cba6a=Qh(_0x2fde32['_queryParams'],this['_value'],this['_key']);if(ga(_0x4cba6a),qn(_0x4cba6a),_0x2fde32['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x2fde32['_repo'],_0x2fde32['_path'],_0x4cba6a,_0x2fde32['_orderByCalled']);}}function E_(_0x15eddd=null,_0x2a7c65){return new ya(_0x15eddd,_0x2a7c65);}class Vd extends ft{constructor(_0x315742){super(),this['_limit']=_0x315742,this['type']='limitToFirst';}['_apply'](_0x55059b){if(_0x55059b['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x55059b['_repo'],_0x55059b['_path'],Yh(_0x55059b['_queryParams'],this['_limit']),_0x55059b['_orderByCalled']);}}function I_(_0x567ad0){if(Math['floor'](_0x567ad0)!==_0x567ad0||_0x567ad0<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x567ad0);}class Hd extends ft{constructor(_0x304c6e){super(),this['_path']=_0x304c6e,this['type']='orderByChild';}['_apply'](_0x335394){_a(_0x335394,'orderByChild');const _0x512d57=new C(this['_path']);if(v(_0x512d57))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x1fd9bf=new Qi(_0x512d57),_0x3026b3=xo(_0x335394['_queryParams'],_0x1fd9bf);return qn(_0x3026b3),new be(_0x335394['_repo'],_0x335394['_path'],_0x3026b3,!0x0);}}function w_(_0x1dce70){if(_0x1dce70==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x1dce70==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x1dce70==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x1dce70),new Hd(_0x1dce70);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x5a33bf){_a(_0x5a33bf,'orderByKey');const _0xe7a1a0=xo(_0x5a33bf['_queryParams'],ye);return qn(_0xe7a1a0),new be(_0x5a33bf['_repo'],_0x5a33bf['_path'],_0xe7a1a0,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x332977,_0x41dbcb){super(),this['_value']=_0x332977,this['_key']=_0x41dbcb,this['type']='equalTo';}['_apply'](_0x3a708e){if(zt('equalTo',this['_value'],_0x3a708e['_path'],!0x1),_0x3a708e['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x3a708e['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x3a708e));}}function T_(_0x40a4c6,_0x4a5266){return new Gd(_0x40a4c6,_0x4a5266);}function S_(_0x5e87e5,..._0x5f4efa){let _0xd071b1=N(_0x5e87e5);for(const _0x2ecb7d of _0x5f4efa)_0xd071b1=_0x2ecb7d['_apply'](_0xd071b1);return _0xd071b1;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x1f41ab,_0x31aa16,_0x10f2f6,_0x1a5725){const _0x12639b=_0x31aa16['lastIndexOf'](':'),_0x227156=_0x31aa16['substring'](0x0,_0x12639b),_0x1046d8=at(_0x227156);_0x1f41ab['repoInfo_']=new yo(_0x31aa16,_0x1046d8,_0x1f41ab['repoInfo_']['namespace'],_0x1f41ab['repoInfo_']['webSocketOnly'],_0x1f41ab['repoInfo_']['nodeAdmin'],_0x1f41ab['repoInfo_']['persistenceKey'],_0x1f41ab['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x10f2f6),_0x1a5725&&(_0x1f41ab['authTokenProvider_']=_0x1a5725);}function Kd(_0x4c0ec7,_0x4e6a91,_0x2f3700,_0x364ddf,_0x9d2e5){let _0x255c24=_0x364ddf||_0x4c0ec7['options']['databaseURL'];_0x255c24===void 0x0&&(_0x4c0ec7['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x4c0ec7['options']['projectId']),_0x255c24=_0x4c0ec7['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x3678fa=vr(_0x255c24,_0x9d2e5),_0x500c30=_0x3678fa['repoInfo'],_0xa66573;typeof process<'u'&&Vs&&(_0xa66573=Vs[qd]),_0xa66573?(_0x255c24='http://'+_0xa66573+'?ns='+_0x500c30['namespace'],_0x3678fa=vr(_0x255c24,_0x9d2e5),_0x500c30=_0x3678fa['repoInfo']):_0x3678fa['repoInfo']['secure'];const _0x44d226=new eh(_0x4c0ec7['name'],_0x4c0ec7['options'],_0x4e6a91);_d('Invalid\x20Firebase\x20Database\x20URL',_0x3678fa),v(_0x3678fa['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x26a830=Qd(_0x500c30,_0x4c0ec7,_0x44d226,new Zl(_0x4c0ec7,_0x2f3700));return new Jd(_0x26a830,_0x4c0ec7);}function Yd(_0x21357b,_0x39a5b9){const _0x27feb3=Ni[_0x39a5b9];(!_0x27feb3||_0x27feb3[_0x21357b['key']]!==_0x21357b)&&ae('Database\x20'+_0x39a5b9+'('+_0x21357b['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x21357b),delete _0x27feb3[_0x21357b['key']];}function Qd(_0x2a6667,_0x2c4b9b,_0x33e684,_0x142b00){let _0x11625c=Ni[_0x2c4b9b['name']];_0x11625c||(_0x11625c={},Ni[_0x2c4b9b['name']]=_0x11625c);let _0x29812f=_0x11625c[_0x2a6667['toURLString']()];return _0x29812f&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x29812f=new vd(_0x2a6667,zd,_0x33e684,_0x142b00),_0x11625c[_0x2a6667['toURLString']()]=_0x29812f,_0x29812f;}class Jd{constructor(_0x26f267,_0x457926){this['_repoInternal']=_0x26f267,this['app']=_0x457926,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x9dc97c){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x9dc97c+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x1cf5a4=Zr(),_0x2c33ed){const _0xc24811=Bi(_0x1cf5a4,'database')['getImmediate']({'identifier':_0x2c33ed});if(!_0xc24811['_instanceStarted']){const _0x176ba0=cc('database');_0x176ba0&&Xd(_0xc24811,..._0x176ba0);}return _0xc24811;}function Xd(_0xfb240e,_0xb9a36c,_0x2f6379,_0x3c0852={}){_0xfb240e=N(_0xfb240e),_0xfb240e['_checkNotDeleted']('useEmulator');const _0x115f8f=_0xb9a36c+':'+_0x2f6379,_0x28689c=_0xfb240e['_repoInternal'];if(_0xfb240e['_instanceStarted']){if(_0x115f8f===_0xfb240e['_repoInternal']['repoInfo_']['host']&&Me(_0x3c0852,_0x28689c['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x259c62;if(_0x28689c['repoInfo_']['nodeAdmin'])_0x3c0852['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x259c62=new nn(nn['OWNER']);else{if(_0x3c0852['mockUserToken']){const _0x2a3267=typeof _0x3c0852['mockUserToken']=='string'?_0x3c0852['mockUserToken']:lc(_0x3c0852['mockUserToken'],_0xfb240e['app']['options']['projectId']);_0x259c62=new nn(_0x2a3267);}}at(_0xb9a36c)&&(jr(_0xb9a36c),Kr('Database',!0x0)),jd(_0x28689c,_0x115f8f,_0x3c0852,_0x259c62);}function R_(_0x88059d){_0x88059d=N(_0x88059d),_0x88059d['_checkNotDeleted']('goOffline'),ha(_0x88059d['_repo']);}function A_(_0x35dae4){_0x35dae4=N(_0x35dae4),_0x35dae4['_checkNotDeleted']('goOnline'),Ad(_0x35dae4['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x19012b){Ul(lt),Ze(new Le('database',(_0x391c88,{instanceIdentifier:_0x5139f6})=>{const _0x21a8bc=_0x391c88['getProvider']('app')['getImmediate'](),_0x4d41e0=_0x391c88['getProvider']('auth-internal'),_0x14b1d0=_0x391c88['getProvider']('app-check-internal');return Kd(_0x21a8bc,_0x4d41e0,_0x14b1d0,_0x5139f6);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x19012b),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x37bac6,_0x426c3d){this['committed']=_0x37bac6,this['snapshot']=_0x426c3d;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x5291ed,_0x99a64b,_0x134255){if(_0x5291ed=N(_0x5291ed),ys('Reference.transaction',_0x5291ed['_path']),_0x5291ed['key']==='.length'||_0x5291ed['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x5291ed['key']+'\x20is\x20a\x20read-only\x20object.';const _0x308690=!0x0,_0x1d675a=new ot(),_0x2e8f19=(_0x33c6ca,_0x210d00,_0x43fab2)=>{let _0x4388ae=null;_0x33c6ca?_0x1d675a['reject'](_0x33c6ca):(_0x4388ae=new st(_0x43fab2,new ee(_0x5291ed['_repo'],_0x5291ed['_path']),R),_0x1d675a['resolve'](new tf(_0x210d00,_0x4388ae)));},_0x199bf3=Bd(_0x5291ed,()=>{});return kd(_0x5291ed['_repo'],_0x5291ed['_path'],_0x99a64b,_0x2e8f19,_0x199bf3,_0x308690),_0x1d675a['promise'];}se['prototype']['simpleListen']=function(_0xc32437,_0x4368d6){this['sendRequest']('q',{'p':_0xc32437},_0x4368d6);},se['prototype']['echo']=function(_0x2ddf96,_0x396528){this['sendRequest']('echo',{'d':_0x2ddf96},_0x396528);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x2c3c2a,..._0x28c714){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x2c3c2a,..._0x28c714);}function sn(_0x349ad5,..._0x14ed3d){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x349ad5,..._0x14ed3d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0xf98aaf,..._0xb096f1){throw ws(_0xf98aaf,..._0xb096f1);}function X(_0x57ccfd,..._0x161872){return ws(_0x57ccfd,..._0x161872);}function Ia(_0x2eb887,_0x1f9bca,_0x453ffa){const _0x23d101={...nf(),[_0x1f9bca]:_0x453ffa};return new Bt('auth','Firebase',_0x23d101)['create'](_0x1f9bca,{'appName':_0x2eb887['name']});}function re(_0x4b9f04){return Ia(_0x4b9f04,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x57297b,..._0x5e71e7){if(typeof _0x57297b!='string'){const _0x46019e=_0x5e71e7[0x0],_0x29255b=[..._0x5e71e7['slice'](0x1)];return _0x29255b[0x0]&&(_0x29255b[0x0]['appName']=_0x57297b['name']),_0x57297b['_errorFactory']['create'](_0x46019e,..._0x29255b);}return Ea['create'](_0x57297b,..._0x5e71e7);}function m(_0x5b14d3,_0x580683,..._0x25202f){if(!_0x5b14d3)throw ws(_0x580683,..._0x25202f);}function ne(_0x28556c){const _0x260358='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x28556c;throw sn(_0x260358),new Error(_0x260358);}function ce(_0x28da69,_0x3f9df4){_0x28da69||ne(_0x3f9df4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x37488f;return typeof self<'u'&&((_0x37488f=self['location'])==null?void 0x0:_0x37488f['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x26d0a3;return typeof self<'u'&&((_0x26d0a3=self['location'])==null?void 0x0:_0x26d0a3['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x1e439b=navigator;return _0x1e439b['languages']&&_0x1e439b['languages'][0x0]||_0x1e439b['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x26cc4d,_0x2b94d8){this['shortDelay']=_0x26cc4d,this['longDelay']=_0x2b94d8,ce(_0x2b94d8>_0x26cc4d,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x3d834a,_0x35a78f){ce(_0x3d834a['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x479d00}=_0x3d834a['emulator'];return _0x35a78f?''+_0x479d00+(_0x35a78f['startsWith']('/')?_0x35a78f['slice'](0x1):_0x35a78f):_0x479d00;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0xc952cb,_0x181607,_0x6c461e){this['fetchImpl']=_0xc952cb,_0x181607&&(this['headersImpl']=_0x181607),_0x6c461e&&(this['responseImpl']=_0x6c461e);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x4e6eb3,_0xfd35b){return _0x4e6eb3['tenantId']&&!_0xfd35b['tenantId']?{..._0xfd35b,'tenantId':_0x4e6eb3['tenantId']}:_0xfd35b;}async function Ae(_0x1de116,_0x3e5e92,_0x11bd35,_0x24e855,_0x1158b1={}){return Ca(_0x1de116,_0x1158b1,async()=>{let _0x22a532={},_0x2ef564={};_0x24e855&&(_0x3e5e92==='GET'?_0x2ef564=_0x24e855:_0x22a532={'body':JSON['stringify'](_0x24e855)});const _0x2486e3=ct({'key':_0x1de116['config']['apiKey'],..._0x2ef564})['slice'](0x1),_0x2fc453=await _0x1de116['_getAdditionalHeaders']();_0x2fc453['Content-Type']='application/json',_0x1de116['languageCode']&&(_0x2fc453['X-Firebase-Locale']=_0x1de116['languageCode']);const _0x2d6608={'method':_0x3e5e92,'headers':_0x2fc453,..._0x22a532};return dc()||(_0x2d6608['referrerPolicy']='no-referrer'),_0x1de116['emulatorConfig']&&at(_0x1de116['emulatorConfig']['host'])&&(_0x2d6608['credentials']='include'),wa['fetch']()(await Ta(_0x1de116,_0x1de116['config']['apiHost'],_0x11bd35,_0x2486e3),_0x2d6608);});}async function Ca(_0x102ed7,_0xf0e485,_0x1e88da){_0x102ed7['_canInitEmulator']=!0x1;const _0x41ab88={...cf,..._0xf0e485};try{const _0x5358d6=new df(_0x102ed7),_0x3f58bc=await Promise['race']([_0x1e88da(),_0x5358d6['promise']]);_0x5358d6['clearNetworkTimeout']();const _0x45c030=await _0x3f58bc['json']();if('needConfirmation'in _0x45c030)throw tn(_0x102ed7,'account-exists-with-different-credential',_0x45c030);if(_0x3f58bc['ok']&&!('errorMessage'in _0x45c030))return _0x45c030;{const _0x362935=_0x3f58bc['ok']?_0x45c030['errorMessage']:_0x45c030['error']['message'],[_0xe09b1c,_0x4c6911]=_0x362935['split']('\x20:\x20');if(_0xe09b1c==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x102ed7,'credential-already-in-use',_0x45c030);if(_0xe09b1c==='EMAIL_EXISTS')throw tn(_0x102ed7,'email-already-in-use',_0x45c030);if(_0xe09b1c==='USER_DISABLED')throw tn(_0x102ed7,'user-disabled',_0x45c030);const _0x26ea49=_0x41ab88[_0xe09b1c]||_0xe09b1c['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x4c6911)throw Ia(_0x102ed7,_0x26ea49,_0x4c6911);Q(_0x102ed7,_0x26ea49);}}catch(_0x2dd1e8){if(_0x2dd1e8 instanceof Se)throw _0x2dd1e8;Q(_0x102ed7,'network-request-failed',{'message':String(_0x2dd1e8)});}}async function Qt(_0x1d82d1,_0x5d2f72,_0x47bfe9,_0x400a4f,_0x2dc0a6={}){const _0x7cb62d=await Ae(_0x1d82d1,_0x5d2f72,_0x47bfe9,_0x400a4f,_0x2dc0a6);return'mfaPendingCredential'in _0x7cb62d&&Q(_0x1d82d1,'multi-factor-auth-required',{'_serverResponse':_0x7cb62d}),_0x7cb62d;}async function Ta(_0x2213ef,_0x1bcf9f,_0x42d946,_0x2bbeac){const _0x514f81=''+_0x1bcf9f+_0x42d946+'?'+_0x2bbeac,_0x24aed3=_0x2213ef,_0x1995ef=_0x24aed3['config']['emulator']?Cs(_0x2213ef['config'],_0x514f81):_0x2213ef['config']['apiScheme']+'://'+_0x514f81;return lf['includes'](_0x42d946)&&(await _0x24aed3['_persistenceManagerAvailable'],_0x24aed3['_getPersistenceType']()==='COOKIE')?_0x24aed3['_getPersistence']()['_getFinalTarget'](_0x1995ef)['toString']():_0x1995ef;}function uf(_0x1b53bd){switch(_0x1b53bd){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x511e68){this['auth']=_0x511e68,this['timer']=null,this['promise']=new Promise((_0x370c40,_0x152e6c)=>{this['timer']=setTimeout(()=>_0x152e6c(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x3e77fa,_0x1aa07b,_0x3d08ae){const _0x18905b={'appName':_0x3e77fa['name']};_0x3d08ae['email']&&(_0x18905b['email']=_0x3d08ae['email']),_0x3d08ae['phoneNumber']&&(_0x18905b['phoneNumber']=_0x3d08ae['phoneNumber']);const _0x412e2f=X(_0x3e77fa,_0x1aa07b,_0x18905b);return _0x412e2f['customData']['_tokenResponse']=_0x3d08ae,_0x412e2f;}function wr(_0x2e8c40){return _0x2e8c40!==void 0x0&&_0x2e8c40['enterprise']!==void 0x0;}class ff{constructor(_0x59859b){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x59859b['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x59859b['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x59859b['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x3b2bb6){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x218233 of this['recaptchaEnforcementState'])if(_0x218233['provider']&&_0x218233['provider']===_0x3b2bb6)return uf(_0x218233['enforcementState']);return null;}['isProviderEnabled'](_0x2489a4){return this['getProviderEnforcementState'](_0x2489a4)==='ENFORCE'||this['getProviderEnforcementState'](_0x2489a4)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x181dd0,_0x271a0b){return Ae(_0x181dd0,'GET','/v2/recaptchaConfig',Re(_0x181dd0,_0x271a0b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x8ff9e9,_0x417245){return Ae(_0x8ff9e9,'POST','/v1/accounts:delete',_0x417245);}async function bn(_0x1043fc,_0x2b4ff9){return Ae(_0x1043fc,'POST','/v1/accounts:lookup',_0x2b4ff9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x56e60e){if(_0x56e60e)try{const _0x353c4c=new Date(Number(_0x56e60e));if(!isNaN(_0x353c4c['getTime']()))return _0x353c4c['toUTCString']();}catch{}}async function gf(_0x4ccb1e,_0x4f4728=!0x1){const _0x389e38=N(_0x4ccb1e),_0x372c17=await _0x389e38['getIdToken'](_0x4f4728),_0x1bcb70=Ts(_0x372c17);m(_0x1bcb70&&_0x1bcb70['exp']&&_0x1bcb70['auth_time']&&_0x1bcb70['iat'],_0x389e38['auth'],'internal-error');const _0xe5209d=typeof _0x1bcb70['firebase']=='object'?_0x1bcb70['firebase']:void 0x0,_0x58cc0a=_0xe5209d==null?void 0x0:_0xe5209d['sign_in_provider'];return{'claims':_0x1bcb70,'token':_0x372c17,'authTime':Rt(li(_0x1bcb70['auth_time'])),'issuedAtTime':Rt(li(_0x1bcb70['iat'])),'expirationTime':Rt(li(_0x1bcb70['exp'])),'signInProvider':_0x58cc0a||null,'signInSecondFactor':(_0xe5209d==null?void 0x0:_0xe5209d['sign_in_second_factor'])||null};}function li(_0x44a8c3){return Number(_0x44a8c3)*0x3e8;}function Ts(_0x465f40){const [_0x253737,_0x3f969a,_0x5470ed]=_0x465f40['split']('.');if(_0x253737===void 0x0||_0x3f969a===void 0x0||_0x5470ed===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x389eb5=ln(_0x3f969a);return _0x389eb5?JSON['parse'](_0x389eb5):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x217f8a){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x217f8a==null?void 0x0:_0x217f8a['toString']()),null;}}function Cr(_0xcb0c48){const _0x2c0971=Ts(_0xcb0c48);return m(_0x2c0971,'internal-error'),m(typeof _0x2c0971['exp']<'u','internal-error'),m(typeof _0x2c0971['iat']<'u','internal-error'),Number(_0x2c0971['exp'])-Number(_0x2c0971['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x3fcf07,_0x57b9d2,_0x200d5b=!0x1){if(_0x200d5b)return _0x57b9d2;try{return await _0x57b9d2;}catch(_0x25f982){throw _0x25f982 instanceof Se&&mf(_0x25f982)&&_0x3fcf07['auth']['currentUser']===_0x3fcf07&&await _0x3fcf07['auth']['signOut'](),_0x25f982;}}function mf({code:_0x21f225}){return _0x21f225==='auth/user-disabled'||_0x21f225==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x53c572){this['user']=_0x53c572,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x4387fa){if(_0x4387fa){const _0x4d9503=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x4d9503;}else{this['errorBackoff']=0x7530;const _0x2f873d=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x2f873d);}}['schedule'](_0x3809b5=!0x1){if(!this['isRunning'])return;const _0x279646=this['getInterval'](_0x3809b5);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x279646);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x81a548){(_0x81a548==null?void 0x0:_0x81a548['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x2cbe61,_0x2b48a7){this['createdAt']=_0x2cbe61,this['lastLoginAt']=_0x2b48a7,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x441c2d){this['createdAt']=_0x441c2d['createdAt'],this['lastLoginAt']=_0x441c2d['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x50722b){var _0x5e11c6;const _0x4644d4=_0x50722b['auth'],_0x4f6807=await _0x50722b['getIdToken'](),_0x3b95ad=await Ut(_0x50722b,bn(_0x4644d4,{'idToken':_0x4f6807}));m(_0x3b95ad==null?void 0x0:_0x3b95ad['users']['length'],_0x4644d4,'internal-error');const _0x449898=_0x3b95ad['users'][0x0];_0x50722b['_notifyReloadListener'](_0x449898);const _0x2502d8=(_0x5e11c6=_0x449898['providerUserInfo'])!=null&&_0x5e11c6['length']?Sa(_0x449898['providerUserInfo']):[],_0x3969ef=Ef(_0x50722b['providerData'],_0x2502d8),_0x6a2bc8=_0x50722b['isAnonymous'],_0x4b66d3=!(_0x50722b['email']&&_0x449898['passwordHash'])&&!(_0x3969ef!=null&&_0x3969ef['length']),_0x5636ec=_0x6a2bc8?_0x4b66d3:!0x1,_0x2b67a9={'uid':_0x449898['localId'],'displayName':_0x449898['displayName']||null,'photoURL':_0x449898['photoUrl']||null,'email':_0x449898['email']||null,'emailVerified':_0x449898['emailVerified']||!0x1,'phoneNumber':_0x449898['phoneNumber']||null,'tenantId':_0x449898['tenantId']||null,'providerData':_0x3969ef,'metadata':new Oi(_0x449898['createdAt'],_0x449898['lastLoginAt']),'isAnonymous':_0x5636ec};Object['assign'](_0x50722b,_0x2b67a9);}async function vf(_0x2d7c9b){const _0x4c7d69=N(_0x2d7c9b);await Rn(_0x4c7d69),await _0x4c7d69['auth']['_persistUserIfCurrent'](_0x4c7d69),_0x4c7d69['auth']['_notifyListenersIfCurrent'](_0x4c7d69);}function Ef(_0x3dd230,_0x1ce049){return[..._0x3dd230['filter'](_0x574018=>!_0x1ce049['some'](_0x26d3c1=>_0x26d3c1['providerId']===_0x574018['providerId'])),..._0x1ce049];}function Sa(_0x26b9f3){return _0x26b9f3['map'](({providerId:_0x46b20b,..._0x4140ae})=>({'providerId':_0x46b20b,'uid':_0x4140ae['rawId']||'','displayName':_0x4140ae['displayName']||null,'email':_0x4140ae['email']||null,'phoneNumber':_0x4140ae['phoneNumber']||null,'photoURL':_0x4140ae['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x538f34,_0x33bd6b){const _0x16fd88=await Ca(_0x538f34,{},async()=>{const _0xf56a37=ct({'grant_type':'refresh_token','refresh_token':_0x33bd6b})['slice'](0x1),{tokenApiHost:_0x10f34c,apiKey:_0x5c39dd}=_0x538f34['config'],_0x32a29c=await Ta(_0x538f34,_0x10f34c,'/v1/token','key='+_0x5c39dd),_0x417409=await _0x538f34['_getAdditionalHeaders']();_0x417409['Content-Type']='application/x-www-form-urlencoded';const _0x51100a={'method':'POST','headers':_0x417409,'body':_0xf56a37};return _0x538f34['emulatorConfig']&&at(_0x538f34['emulatorConfig']['host'])&&(_0x51100a['credentials']='include'),wa['fetch']()(_0x32a29c,_0x51100a);});return{'accessToken':_0x16fd88['access_token'],'expiresIn':_0x16fd88['expires_in'],'refreshToken':_0x16fd88['refresh_token']};}async function wf(_0x2c2c69,_0x47259d){return Ae(_0x2c2c69,'POST','/v2/accounts:revokeToken',Re(_0x2c2c69,_0x47259d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x419646){m(_0x419646['idToken'],'internal-error'),m(typeof _0x419646['idToken']<'u','internal-error'),m(typeof _0x419646['refreshToken']<'u','internal-error');const _0x1945ab='expiresIn'in _0x419646&&typeof _0x419646['expiresIn']<'u'?Number(_0x419646['expiresIn']):Cr(_0x419646['idToken']);this['updateTokensAndExpiration'](_0x419646['idToken'],_0x419646['refreshToken'],_0x1945ab);}['updateFromIdToken'](_0x24b69d){m(_0x24b69d['length']!==0x0,'internal-error');const _0x11e889=Cr(_0x24b69d);this['updateTokensAndExpiration'](_0x24b69d,null,_0x11e889);}async['getToken'](_0x47501f,_0x2313dc=!0x1){return!_0x2313dc&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x47501f,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x47501f,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x8d04bf,_0x3b022a){const {accessToken:_0x408a7a,refreshToken:_0x3a846c,expiresIn:_0x511788}=await If(_0x8d04bf,_0x3b022a);this['updateTokensAndExpiration'](_0x408a7a,_0x3a846c,Number(_0x511788));}['updateTokensAndExpiration'](_0x35a322,_0xe62d8b,_0x271300){this['refreshToken']=_0xe62d8b||null,this['accessToken']=_0x35a322||null,this['expirationTime']=Date['now']()+_0x271300*0x3e8;}static['fromJSON'](_0x3c86a4,_0x2cd621){const {refreshToken:_0x103a01,accessToken:_0x2a97ab,expirationTime:_0x327d81}=_0x2cd621,_0x252667=new Qe();return _0x103a01&&(m(typeof _0x103a01=='string','internal-error',{'appName':_0x3c86a4}),_0x252667['refreshToken']=_0x103a01),_0x2a97ab&&(m(typeof _0x2a97ab=='string','internal-error',{'appName':_0x3c86a4}),_0x252667['accessToken']=_0x2a97ab),_0x327d81&&(m(typeof _0x327d81=='number','internal-error',{'appName':_0x3c86a4}),_0x252667['expirationTime']=_0x327d81),_0x252667;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x22a850){this['accessToken']=_0x22a850['accessToken'],this['refreshToken']=_0x22a850['refreshToken'],this['expirationTime']=_0x22a850['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x501ba1,_0x2ec2f8){m(typeof _0x501ba1=='string'||typeof _0x501ba1>'u','internal-error',{'appName':_0x2ec2f8});}class K{constructor({uid:_0x430397,auth:_0x5b4dfe,stsTokenManager:_0x2ea67c,..._0x4cb802}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x430397,this['auth']=_0x5b4dfe,this['stsTokenManager']=_0x2ea67c,this['accessToken']=_0x2ea67c['accessToken'],this['displayName']=_0x4cb802['displayName']||null,this['email']=_0x4cb802['email']||null,this['emailVerified']=_0x4cb802['emailVerified']||!0x1,this['phoneNumber']=_0x4cb802['phoneNumber']||null,this['photoURL']=_0x4cb802['photoURL']||null,this['isAnonymous']=_0x4cb802['isAnonymous']||!0x1,this['tenantId']=_0x4cb802['tenantId']||null,this['providerData']=_0x4cb802['providerData']?[..._0x4cb802['providerData']]:[],this['metadata']=new Oi(_0x4cb802['createdAt']||void 0x0,_0x4cb802['lastLoginAt']||void 0x0);}async['getIdToken'](_0x26cebf){const _0x163db3=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x26cebf));return m(_0x163db3,this['auth'],'internal-error'),this['accessToken']!==_0x163db3&&(this['accessToken']=_0x163db3,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x163db3;}['getIdTokenResult'](_0x567ef2){return gf(this,_0x567ef2);}['reload'](){return vf(this);}['_assign'](_0x3e5369){this!==_0x3e5369&&(m(this['uid']===_0x3e5369['uid'],this['auth'],'internal-error'),this['displayName']=_0x3e5369['displayName'],this['photoURL']=_0x3e5369['photoURL'],this['email']=_0x3e5369['email'],this['emailVerified']=_0x3e5369['emailVerified'],this['phoneNumber']=_0x3e5369['phoneNumber'],this['isAnonymous']=_0x3e5369['isAnonymous'],this['tenantId']=_0x3e5369['tenantId'],this['providerData']=_0x3e5369['providerData']['map'](_0x11a012=>({..._0x11a012})),this['metadata']['_copy'](_0x3e5369['metadata']),this['stsTokenManager']['_assign'](_0x3e5369['stsTokenManager']));}['_clone'](_0x19ecd0){const _0x4490ba=new K({...this,'auth':_0x19ecd0,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x4490ba['metadata']['_copy'](this['metadata']),_0x4490ba;}['_onReload'](_0x45de4d){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x45de4d,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x34ef5f){this['reloadListener']?this['reloadListener'](_0x34ef5f):this['reloadUserInfo']=_0x34ef5f;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x43e6ff,_0x405ef7=!0x1){let _0x240b46=!0x1;_0x43e6ff['idToken']&&_0x43e6ff['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x43e6ff),_0x240b46=!0x0),_0x405ef7&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x240b46&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x4957b3=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x4957b3})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x95e296=>({..._0x95e296})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x492dbf,_0x22eaf8){const _0x16ac9d=_0x22eaf8['displayName']??void 0x0,_0x3f7ad1=_0x22eaf8['email']??void 0x0,_0x3b45ec=_0x22eaf8['phoneNumber']??void 0x0,_0x2d5e84=_0x22eaf8['photoURL']??void 0x0,_0x5d9af4=_0x22eaf8['tenantId']??void 0x0,_0x3b9bfc=_0x22eaf8['_redirectEventId']??void 0x0,_0x476f1a=_0x22eaf8['createdAt']??void 0x0,_0x5c6921=_0x22eaf8['lastLoginAt']??void 0x0,{uid:_0x592a4f,emailVerified:_0x4658eb,isAnonymous:_0x2c13a2,providerData:_0x4562da,stsTokenManager:_0x4724f6}=_0x22eaf8;m(_0x592a4f&&_0x4724f6,_0x492dbf,'internal-error');const _0x5f45ca=Qe['fromJSON'](this['name'],_0x4724f6);m(typeof _0x592a4f=='string',_0x492dbf,'internal-error'),le(_0x16ac9d,_0x492dbf['name']),le(_0x3f7ad1,_0x492dbf['name']),m(typeof _0x4658eb=='boolean',_0x492dbf,'internal-error'),m(typeof _0x2c13a2=='boolean',_0x492dbf,'internal-error'),le(_0x3b45ec,_0x492dbf['name']),le(_0x2d5e84,_0x492dbf['name']),le(_0x5d9af4,_0x492dbf['name']),le(_0x3b9bfc,_0x492dbf['name']),le(_0x476f1a,_0x492dbf['name']),le(_0x5c6921,_0x492dbf['name']);const _0x55a8cd=new K({'uid':_0x592a4f,'auth':_0x492dbf,'email':_0x3f7ad1,'emailVerified':_0x4658eb,'displayName':_0x16ac9d,'isAnonymous':_0x2c13a2,'photoURL':_0x2d5e84,'phoneNumber':_0x3b45ec,'tenantId':_0x5d9af4,'stsTokenManager':_0x5f45ca,'createdAt':_0x476f1a,'lastLoginAt':_0x5c6921});return _0x4562da&&Array['isArray'](_0x4562da)&&(_0x55a8cd['providerData']=_0x4562da['map'](_0x4fd753=>({..._0x4fd753}))),_0x3b9bfc&&(_0x55a8cd['_redirectEventId']=_0x3b9bfc),_0x55a8cd;}static async['_fromIdTokenResponse'](_0x4bccfe,_0x30229b,_0x28c846=!0x1){const _0x2d26ca=new Qe();_0x2d26ca['updateFromServerResponse'](_0x30229b);const _0x3b688b=new K({'uid':_0x30229b['localId'],'auth':_0x4bccfe,'stsTokenManager':_0x2d26ca,'isAnonymous':_0x28c846});return await Rn(_0x3b688b),_0x3b688b;}static async['_fromGetAccountInfoResponse'](_0x588ab1,_0x2ceb0e,_0x155a2b){const _0x74daae=_0x2ceb0e['users'][0x0];m(_0x74daae['localId']!==void 0x0,'internal-error');const _0x20d0b7=_0x74daae['providerUserInfo']!==void 0x0?Sa(_0x74daae['providerUserInfo']):[],_0x54ad67=!(_0x74daae['email']&&_0x74daae['passwordHash'])&&!(_0x20d0b7!=null&&_0x20d0b7['length']),_0x10d041=new Qe();_0x10d041['updateFromIdToken'](_0x155a2b);const _0x23c306=new K({'uid':_0x74daae['localId'],'auth':_0x588ab1,'stsTokenManager':_0x10d041,'isAnonymous':_0x54ad67}),_0x30ef0c={'uid':_0x74daae['localId'],'displayName':_0x74daae['displayName']||null,'photoURL':_0x74daae['photoUrl']||null,'email':_0x74daae['email']||null,'emailVerified':_0x74daae['emailVerified']||!0x1,'phoneNumber':_0x74daae['phoneNumber']||null,'tenantId':_0x74daae['tenantId']||null,'providerData':_0x20d0b7,'metadata':new Oi(_0x74daae['createdAt'],_0x74daae['lastLoginAt']),'isAnonymous':!(_0x74daae['email']&&_0x74daae['passwordHash'])&&!(_0x20d0b7!=null&&_0x20d0b7['length'])};return Object['assign'](_0x23c306,_0x30ef0c),_0x23c306;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x27ac4a){ce(_0x27ac4a instanceof Function,'Expected\x20a\x20class\x20definition');let _0x16dd18=Tr['get'](_0x27ac4a);return _0x16dd18?(ce(_0x16dd18 instanceof _0x27ac4a,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x16dd18):(_0x16dd18=new _0x27ac4a(),Tr['set'](_0x27ac4a,_0x16dd18),_0x16dd18);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x1c9551,_0x5d7513){this['storage'][_0x1c9551]=_0x5d7513;}async['_get'](_0x4448c0){const _0x469231=this['storage'][_0x4448c0];return _0x469231===void 0x0?null:_0x469231;}async['_remove'](_0x4a948f){delete this['storage'][_0x4a948f];}['_addListener'](_0xe094a1,_0x22afff){}['_removeListener'](_0xa070cf,_0x62e421){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x35da91,_0x43ed88,_0x1b60ce){return'firebase:'+_0x35da91+':'+_0x43ed88+':'+_0x1b60ce;}class Je{constructor(_0x393ea5,_0x138f94,_0x3e7bd5){this['persistence']=_0x393ea5,this['auth']=_0x138f94,this['userKey']=_0x3e7bd5;const {config:_0x2a933b,name:_0x3fce51}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x2a933b['apiKey'],_0x3fce51),this['fullPersistenceKey']=rn('persistence',_0x2a933b['apiKey'],_0x3fce51),this['boundEventHandler']=_0x138f94['_onStorageEvent']['bind'](_0x138f94),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x3975e5){return this['persistence']['_set'](this['fullUserKey'],_0x3975e5['toJSON']());}async['getCurrentUser'](){const _0x53fb28=await this['persistence']['_get'](this['fullUserKey']);if(!_0x53fb28)return null;if(typeof _0x53fb28=='string'){const _0x4fd881=await bn(this['auth'],{'idToken':_0x53fb28})['catch'](()=>{});return _0x4fd881?K['_fromGetAccountInfoResponse'](this['auth'],_0x4fd881,_0x53fb28):null;}return K['_fromJSON'](this['auth'],_0x53fb28);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0xb4adb1){if(this['persistence']===_0xb4adb1)return;const _0x298609=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0xb4adb1,_0x298609)return this['setCurrentUser'](_0x298609);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x46e0a8,_0x4a15c4,_0x1be4c5='authUser'){if(!_0x4a15c4['length'])return new Je(ie(Sr),_0x46e0a8,_0x1be4c5);const _0x567a68=(await Promise['all'](_0x4a15c4['map'](async _0x562849=>{if(await _0x562849['_isAvailable']())return _0x562849;})))['filter'](_0x50e6ff=>_0x50e6ff);let _0x22ee1d=_0x567a68[0x0]||ie(Sr);const _0xe89101=rn(_0x1be4c5,_0x46e0a8['config']['apiKey'],_0x46e0a8['name']);let _0x4b6a38=null;for(const _0x2f9210 of _0x4a15c4)try{const _0x2b401f=await _0x2f9210['_get'](_0xe89101);if(_0x2b401f){let _0x12bee8;if(typeof _0x2b401f=='string'){const _0x1c4792=await bn(_0x46e0a8,{'idToken':_0x2b401f})['catch'](()=>{});if(!_0x1c4792)break;_0x12bee8=await K['_fromGetAccountInfoResponse'](_0x46e0a8,_0x1c4792,_0x2b401f);}else _0x12bee8=K['_fromJSON'](_0x46e0a8,_0x2b401f);_0x2f9210!==_0x22ee1d&&(_0x4b6a38=_0x12bee8),_0x22ee1d=_0x2f9210;break;}}catch{}const _0x2e587e=_0x567a68['filter'](_0xb9dae7=>_0xb9dae7['_shouldAllowMigration']);return!_0x22ee1d['_shouldAllowMigration']||!_0x2e587e['length']?new Je(_0x22ee1d,_0x46e0a8,_0x1be4c5):(_0x22ee1d=_0x2e587e[0x0],_0x4b6a38&&await _0x22ee1d['_set'](_0xe89101,_0x4b6a38['toJSON']()),await Promise['all'](_0x4a15c4['map'](async _0x524738=>{if(_0x524738!==_0x22ee1d)try{await _0x524738['_remove'](_0xe89101);}catch{}})),new Je(_0x22ee1d,_0x46e0a8,_0x1be4c5));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x5abdf9){const _0x36fd79=_0x5abdf9['toLowerCase']();if(_0x36fd79['includes']('opera/')||_0x36fd79['includes']('opr/')||_0x36fd79['includes']('opios/'))return'Opera';if(Na(_0x36fd79))return'IEMobile';if(_0x36fd79['includes']('msie')||_0x36fd79['includes']('trident/'))return'IE';if(_0x36fd79['includes']('edge/'))return'Edge';if(Ra(_0x36fd79))return'Firefox';if(_0x36fd79['includes']('silk/'))return'Silk';if(Oa(_0x36fd79))return'Blackberry';if(Da(_0x36fd79))return'Webos';if(Aa(_0x36fd79))return'Safari';if((_0x36fd79['includes']('chrome/')||ka(_0x36fd79))&&!_0x36fd79['includes']('edge/'))return'Chrome';if(Pa(_0x36fd79))return'Android';{const _0x26e8e1=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x59dc3f=_0x5abdf9['match'](_0x26e8e1);if((_0x59dc3f==null?void 0x0:_0x59dc3f['length'])===0x2)return _0x59dc3f[0x1];}return'Other';}function Ra(_0x25e4a1=W()){return/firefox\//i['test'](_0x25e4a1);}function Aa(_0x3a4ed8=W()){const _0x5623e0=_0x3a4ed8['toLowerCase']();return _0x5623e0['includes']('safari/')&&!_0x5623e0['includes']('chrome/')&&!_0x5623e0['includes']('crios/')&&!_0x5623e0['includes']('android');}function ka(_0x45add2=W()){return/crios\//i['test'](_0x45add2);}function Na(_0x3edeb7=W()){return/iemobile/i['test'](_0x3edeb7);}function Pa(_0x490199=W()){return/android/i['test'](_0x490199);}function Oa(_0x4fac2d=W()){return/blackberry/i['test'](_0x4fac2d);}function Da(_0xcb347b=W()){return/webos/i['test'](_0xcb347b);}function Ss(_0xa2da60=W()){return/iphone|ipad|ipod/i['test'](_0xa2da60)||/macintosh/i['test'](_0xa2da60)&&/mobile/i['test'](_0xa2da60);}function Cf(_0x273599=W()){var _0x57d20d;return Ss(_0x273599)&&!!((_0x57d20d=window['navigator'])!=null&&_0x57d20d['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x3173ec=W()){return Ss(_0x3173ec)||Pa(_0x3173ec)||Da(_0x3173ec)||Oa(_0x3173ec)||/windows phone/i['test'](_0x3173ec)||Na(_0x3173ec);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x2b2305,_0x1e1ba2=[]){let _0x104690;switch(_0x2b2305){case'Browser':_0x104690=br(W());break;case'Worker':_0x104690=br(W())+'-'+_0x2b2305;break;default:_0x104690=_0x2b2305;}const _0x75b1c8=_0x1e1ba2['length']?_0x1e1ba2['join'](','):'FirebaseCore-web';return _0x104690+'/JsCore/'+lt+'/'+_0x75b1c8;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x11abfe){this['auth']=_0x11abfe,this['queue']=[];}['pushCallback'](_0x3e837e,_0x311165){const _0x36fa81=_0x354b79=>new Promise((_0x549f17,_0x5ce638)=>{try{const _0x1ab32e=_0x3e837e(_0x354b79);_0x549f17(_0x1ab32e);}catch(_0x2cfdb3){_0x5ce638(_0x2cfdb3);}});_0x36fa81['onAbort']=_0x311165,this['queue']['push'](_0x36fa81);const _0x496981=this['queue']['length']-0x1;return()=>{this['queue'][_0x496981]=()=>Promise['resolve']();};}async['runMiddleware'](_0x2a6b9c){if(this['auth']['currentUser']===_0x2a6b9c)return;const _0x12093d=[];try{for(const _0x191f4d of this['queue'])await _0x191f4d(_0x2a6b9c),_0x191f4d['onAbort']&&_0x12093d['push'](_0x191f4d['onAbort']);}catch(_0x41d673){_0x12093d['reverse']();for(const _0x475188 of _0x12093d)try{_0x475188();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x41d673==null?void 0x0:_0x41d673['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x49043f,_0x5a7da1={}){return Ae(_0x49043f,'GET','/v2/passwordPolicy',Re(_0x49043f,_0x5a7da1));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x5cad6f){var _0x5a22d2;const _0x1d0c24=_0x5cad6f['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x1d0c24['minPasswordLength']??Rf,_0x1d0c24['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x1d0c24['maxPasswordLength']),_0x1d0c24['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x1d0c24['containsLowercaseCharacter']),_0x1d0c24['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x1d0c24['containsUppercaseCharacter']),_0x1d0c24['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x1d0c24['containsNumericCharacter']),_0x1d0c24['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x1d0c24['containsNonAlphanumericCharacter']),this['enforcementState']=_0x5cad6f['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x5a22d2=_0x5cad6f['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x5a22d2['join'](''))??'',this['forceUpgradeOnSignin']=_0x5cad6f['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x5cad6f['schemaVersion'];}['validatePassword'](_0x39e2c4){const _0x5148f0={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x39e2c4,_0x5148f0),this['validatePasswordCharacterOptions'](_0x39e2c4,_0x5148f0),_0x5148f0['isValid']&&(_0x5148f0['isValid']=_0x5148f0['meetsMinPasswordLength']??!0x0),_0x5148f0['isValid']&&(_0x5148f0['isValid']=_0x5148f0['meetsMaxPasswordLength']??!0x0),_0x5148f0['isValid']&&(_0x5148f0['isValid']=_0x5148f0['containsLowercaseLetter']??!0x0),_0x5148f0['isValid']&&(_0x5148f0['isValid']=_0x5148f0['containsUppercaseLetter']??!0x0),_0x5148f0['isValid']&&(_0x5148f0['isValid']=_0x5148f0['containsNumericCharacter']??!0x0),_0x5148f0['isValid']&&(_0x5148f0['isValid']=_0x5148f0['containsNonAlphanumericCharacter']??!0x0),_0x5148f0;}['validatePasswordLengthOptions'](_0x11e61c,_0x493a56){const _0x2b2313=this['customStrengthOptions']['minPasswordLength'],_0x1ebcf2=this['customStrengthOptions']['maxPasswordLength'];_0x2b2313&&(_0x493a56['meetsMinPasswordLength']=_0x11e61c['length']>=_0x2b2313),_0x1ebcf2&&(_0x493a56['meetsMaxPasswordLength']=_0x11e61c['length']<=_0x1ebcf2);}['validatePasswordCharacterOptions'](_0x5306b9,_0x1ccf31){this['updatePasswordCharacterOptionsStatuses'](_0x1ccf31,!0x1,!0x1,!0x1,!0x1);let _0x33f9c0;for(let _0x481bf5=0x0;_0x481bf5<_0x5306b9['length'];_0x481bf5++)_0x33f9c0=_0x5306b9['charAt'](_0x481bf5),this['updatePasswordCharacterOptionsStatuses'](_0x1ccf31,_0x33f9c0>='a'&&_0x33f9c0<='z',_0x33f9c0>='A'&&_0x33f9c0<='Z',_0x33f9c0>='0'&&_0x33f9c0<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x33f9c0));}['updatePasswordCharacterOptionsStatuses'](_0x2af595,_0x532ce5,_0x3fbfc3,_0x222ea2,_0x349ac7){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x2af595['containsLowercaseLetter']||(_0x2af595['containsLowercaseLetter']=_0x532ce5)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x2af595['containsUppercaseLetter']||(_0x2af595['containsUppercaseLetter']=_0x3fbfc3)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x2af595['containsNumericCharacter']||(_0x2af595['containsNumericCharacter']=_0x222ea2)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x2af595['containsNonAlphanumericCharacter']||(_0x2af595['containsNonAlphanumericCharacter']=_0x349ac7));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x4b37ee,_0x18a3c7,_0x42bcb1,_0x10ad50){this['app']=_0x4b37ee,this['heartbeatServiceProvider']=_0x18a3c7,this['appCheckServiceProvider']=_0x42bcb1,this['config']=_0x10ad50,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x4b37ee['name'],this['clientVersion']=_0x10ad50['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x10ce03=>this['_resolvePersistenceManagerAvailable']=_0x10ce03);}['_initializeWithPersistence'](_0x38b527,_0x497188){return _0x497188&&(this['_popupRedirectResolver']=ie(_0x497188)),this['_initializationPromise']=this['queue'](async()=>{var _0x22d4a4,_0x2e8b7b,_0x1b8fac;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x38b527),(_0x22d4a4=this['_resolvePersistenceManagerAvailable'])==null||_0x22d4a4['call'](this),!this['_deleted'])){if((_0x2e8b7b=this['_popupRedirectResolver'])!=null&&_0x2e8b7b['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x497188),this['lastNotifiedUid']=((_0x1b8fac=this['currentUser'])==null?void 0x0:_0x1b8fac['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x37aec7=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x37aec7)){if(this['currentUser']&&_0x37aec7&&this['currentUser']['uid']===_0x37aec7['uid']){this['_currentUser']['_assign'](_0x37aec7),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x37aec7,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x2a1114){try{const _0x2894ad=await bn(this,{'idToken':_0x2a1114}),_0xd0f4bd=await K['_fromGetAccountInfoResponse'](this,_0x2894ad,_0x2a1114);await this['directlySetCurrentUser'](_0xd0f4bd);}catch(_0x48c1a2){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x48c1a2),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x2a6e56){var _0x58edaa;if($(this['app'])){const _0x4d67e4=this['app']['settings']['authIdToken'];return _0x4d67e4?new Promise(_0x473adc=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x4d67e4)['then'](_0x473adc,_0x473adc));}):this['directlySetCurrentUser'](null);}const _0x10b87d=await this['assertedPersistence']['getCurrentUser']();let _0x441ecf=_0x10b87d,_0x177659=!0x1;if(_0x2a6e56&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x2017ce=(_0x58edaa=this['redirectUser'])==null?void 0x0:_0x58edaa['_redirectEventId'],_0x558011=_0x441ecf==null?void 0x0:_0x441ecf['_redirectEventId'],_0x17b304=await this['tryRedirectSignIn'](_0x2a6e56);(!_0x2017ce||_0x2017ce===_0x558011)&&(_0x17b304!=null&&_0x17b304['user'])&&(_0x441ecf=_0x17b304['user'],_0x177659=!0x0);}if(!_0x441ecf)return this['directlySetCurrentUser'](null);if(!_0x441ecf['_redirectEventId']){if(_0x177659)try{await this['beforeStateQueue']['runMiddleware'](_0x441ecf);}catch(_0x879804){_0x441ecf=_0x10b87d,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x879804));}return _0x441ecf?this['reloadAndSetCurrentUserOrClear'](_0x441ecf):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x441ecf['_redirectEventId']?this['directlySetCurrentUser'](_0x441ecf):this['reloadAndSetCurrentUserOrClear'](_0x441ecf);}async['tryRedirectSignIn'](_0xc649c5){let _0x5f3a71=null;try{_0x5f3a71=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0xc649c5,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x5f3a71;}async['reloadAndSetCurrentUserOrClear'](_0x43b5dc){try{await Rn(_0x43b5dc);}catch(_0x15ca46){if((_0x15ca46==null?void 0x0:_0x15ca46['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x43b5dc);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x27fc6f){if($(this['app']))return Promise['reject'](re(this));const _0x3809ea=_0x27fc6f?N(_0x27fc6f):null;return _0x3809ea&&m(_0x3809ea['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x3809ea&&_0x3809ea['_clone'](this));}async['_updateCurrentUser'](_0x4a38d5,_0x3bb42d=!0x1){if(!this['_deleted'])return _0x4a38d5&&m(this['tenantId']===_0x4a38d5['tenantId'],this,'tenant-id-mismatch'),_0x3bb42d||await this['beforeStateQueue']['runMiddleware'](_0x4a38d5),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x4a38d5),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x151997){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x151997));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x385f38){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x2a0642=this['_getPasswordPolicyInternal']();return _0x2a0642['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x2a0642['validatePassword'](_0x385f38);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x34e5be=await bf(this),_0x4a092d=new Af(_0x34e5be);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4a092d:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4a092d;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x4e28be){this['_errorFactory']=new Bt('auth','Firebase',_0x4e28be());}['onAuthStateChanged'](_0x2976c7,_0x3e183c,_0x123056){return this['registerStateListener'](this['authStateSubscription'],_0x2976c7,_0x3e183c,_0x123056);}['beforeAuthStateChanged'](_0x387e9f,_0x412516){return this['beforeStateQueue']['pushCallback'](_0x387e9f,_0x412516);}['onIdTokenChanged'](_0x5b9fb0,_0xbbf6d0,_0x359159){return this['registerStateListener'](this['idTokenSubscription'],_0x5b9fb0,_0xbbf6d0,_0x359159);}['authStateReady'](){return new Promise((_0x2ce8c0,_0x2b4657)=>{if(this['currentUser'])_0x2ce8c0();else{const _0x4c50c4=this['onAuthStateChanged'](()=>{_0x4c50c4(),_0x2ce8c0();},_0x2b4657);}});}async['revokeAccessToken'](_0x1d6c07){if(this['currentUser']){const _0x9abd50=await this['currentUser']['getIdToken'](),_0xfdc2f7={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x1d6c07,'idToken':_0x9abd50};this['tenantId']!=null&&(_0xfdc2f7['tenantId']=this['tenantId']),await wf(this,_0xfdc2f7);}}['toJSON'](){var _0x3cc8d3;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x3cc8d3=this['_currentUser'])==null?void 0x0:_0x3cc8d3['toJSON']()};}async['_setRedirectUser'](_0x4d6005,_0x533dae){const _0x13d69c=await this['getOrInitRedirectPersistenceManager'](_0x533dae);return _0x4d6005===null?_0x13d69c['removeCurrentUser']():_0x13d69c['setCurrentUser'](_0x4d6005);}async['getOrInitRedirectPersistenceManager'](_0x202c90){if(!this['redirectPersistenceManager']){const _0x4b97b1=_0x202c90&&ie(_0x202c90)||this['_popupRedirectResolver'];m(_0x4b97b1,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x4b97b1['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x56f814){var _0x10659a,_0x81520c;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x10659a=this['_currentUser'])==null?void 0x0:_0x10659a['_redirectEventId'])===_0x56f814?this['_currentUser']:((_0x81520c=this['redirectUser'])==null?void 0x0:_0x81520c['_redirectEventId'])===_0x56f814?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x1396a2){if(_0x1396a2===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x1396a2));}['_notifyListenersIfCurrent'](_0x374e54){_0x374e54===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x453b49;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x48c723=((_0x453b49=this['currentUser'])==null?void 0x0:_0x453b49['uid'])??null;this['lastNotifiedUid']!==_0x48c723&&(this['lastNotifiedUid']=_0x48c723,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0xf70de0,_0xd9cea3,_0x5d2438,_0x75df01){if(this['_deleted'])return()=>{};const _0xd3a074=typeof _0xd9cea3=='function'?_0xd9cea3:_0xd9cea3['next']['bind'](_0xd9cea3);let _0x2a81ee=!0x1;const _0x13b666=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x13b666,this,'internal-error'),_0x13b666['then'](()=>{_0x2a81ee||_0xd3a074(this['currentUser']);}),typeof _0xd9cea3=='function'){const _0x345cf8=_0xf70de0['addObserver'](_0xd9cea3,_0x5d2438,_0x75df01);return()=>{_0x2a81ee=!0x0,_0x345cf8();};}else{const _0x29dba2=_0xf70de0['addObserver'](_0xd9cea3);return()=>{_0x2a81ee=!0x0,_0x29dba2();};}}async['directlySetCurrentUser'](_0x12f441){this['currentUser']&&this['currentUser']!==_0x12f441&&this['_currentUser']['_stopProactiveRefresh'](),_0x12f441&&this['isProactiveRefreshEnabled']&&_0x12f441['_startProactiveRefresh'](),this['currentUser']=_0x12f441,_0x12f441?await this['assertedPersistence']['setCurrentUser'](_0x12f441):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0xd853ef){return this['operations']=this['operations']['then'](_0xd853ef,_0xd853ef),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x277b47){!_0x277b47||this['frameworks']['includes'](_0x277b47)||(this['frameworks']['push'](_0x277b47),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x347bad;const _0x12a166={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x12a166['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x4598dc=await((_0x347bad=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x347bad['getHeartbeatsHeader']());_0x4598dc&&(_0x12a166['X-Firebase-Client']=_0x4598dc);const _0x303f31=await this['_getAppCheckToken']();return _0x303f31&&(_0x12a166['X-Firebase-AppCheck']=_0x303f31),_0x12a166;}async['_getAppCheckToken'](){var _0x49de69;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x4007e1=await((_0x49de69=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x49de69['getToken']());return _0x4007e1!=null&&_0x4007e1['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x4007e1['error']),_0x4007e1==null?void 0x0:_0x4007e1['token'];}}function qe(_0x556641){return N(_0x556641);}class Rr{constructor(_0x191800){this['auth']=_0x191800,this['observer']=null,this['addObserver']=Tc(_0x47d8ea=>this['observer']=_0x47d8ea);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x5f2e55){jn=_0x5f2e55;}function xa(_0x51f2df){return jn['loadJS'](_0x51f2df);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x711cf7){return'__'+_0x711cf7+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x1cbc14){_0x1cbc14();}['execute'](_0x711da5,_0x4ec7a6){return Promise['resolve']('token');}['render'](_0x10d1dd,_0x3109a4){return'';}}class Lf{['ready'](_0x2028fa){_0x2028fa();}['execute'](_0xd394d9,_0x1e8190){return Promise['resolve']('token');}['render'](_0x1f1cdc,_0x4254e2){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x5d1a90){this['type']=xf,this['auth']=qe(_0x5d1a90);}async['verify'](_0x583827='verify',_0x261d3c=!0x1){async function _0x44e93c(_0x4e3b86){if(!_0x261d3c){if(_0x4e3b86['tenantId']==null&&_0x4e3b86['_agentRecaptchaConfig']!=null)return _0x4e3b86['_agentRecaptchaConfig']['siteKey'];if(_0x4e3b86['tenantId']!=null&&_0x4e3b86['_tenantRecaptchaConfigs'][_0x4e3b86['tenantId']]!==void 0x0)return _0x4e3b86['_tenantRecaptchaConfigs'][_0x4e3b86['tenantId']]['siteKey'];}return new Promise(async(_0x49e6ed,_0xaaaaec)=>{pf(_0x4e3b86,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x54f4f0=>{if(_0x54f4f0['recaptchaKey']===void 0x0)_0xaaaaec(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x3d7048=new ff(_0x54f4f0);return _0x4e3b86['tenantId']==null?_0x4e3b86['_agentRecaptchaConfig']=_0x3d7048:_0x4e3b86['_tenantRecaptchaConfigs'][_0x4e3b86['tenantId']]=_0x3d7048,_0x49e6ed(_0x3d7048['siteKey']);}})['catch'](_0x4a700b=>{_0xaaaaec(_0x4a700b);});});}function _0xaaaf6b(_0x50a365,_0x13ea48,_0x5dfaf8){const _0x5a59b0=window['grecaptcha'];wr(_0x5a59b0)?_0x5a59b0['enterprise']['ready'](()=>{_0x5a59b0['enterprise']['execute'](_0x50a365,{'action':_0x583827})['then'](_0x1e33a1=>{_0x13ea48(_0x1e33a1);})['catch'](()=>{_0x13ea48(Fa);});}):_0x5dfaf8(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x45cfc8,_0x1b620e)=>{_0x44e93c(this['auth'])['then'](_0x14b774=>{if(!_0x261d3c&&wr(window['grecaptcha']))_0xaaaf6b(_0x14b774,_0x45cfc8,_0x1b620e);else{if(typeof window>'u'){_0x1b620e(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x3164b1=Pf();_0x3164b1['length']!==0x0&&(_0x3164b1+=_0x14b774),xa(_0x3164b1)['then'](()=>{_0xaaaf6b(_0x14b774,_0x45cfc8,_0x1b620e);})['catch'](_0x23c55f=>{_0x1b620e(_0x23c55f);});}})['catch'](_0x39fecd=>{_0x1b620e(_0x39fecd);});});}}async function Ar(_0x5227ce,_0xc97d63,_0xc2e7c,_0x2b748f=!0x1,_0x5b97a9=!0x1){const _0x39a4fb=new Ff(_0x5227ce);let _0x4a38e4;if(_0x5b97a9)_0x4a38e4=Fa;else try{_0x4a38e4=await _0x39a4fb['verify'](_0xc2e7c);}catch{_0x4a38e4=await _0x39a4fb['verify'](_0xc2e7c,!0x0);}const _0x377075={..._0xc97d63};if(_0xc2e7c==='mfaSmsEnrollment'||_0xc2e7c==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x377075){const _0x366974=_0x377075['phoneEnrollmentInfo']['phoneNumber'],_0x1cc1c7=_0x377075['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x377075,{'phoneEnrollmentInfo':{'phoneNumber':_0x366974,'recaptchaToken':_0x1cc1c7,'captchaResponse':_0x4a38e4,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x377075){const _0x2e817b=_0x377075['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x377075,{'phoneSignInInfo':{'recaptchaToken':_0x2e817b,'captchaResponse':_0x4a38e4,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x377075;}return _0x2b748f?Object['assign'](_0x377075,{'captchaResp':_0x4a38e4}):Object['assign'](_0x377075,{'captchaResponse':_0x4a38e4}),Object['assign'](_0x377075,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x377075,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x377075;}async function Di(_0x16480a,_0x2e8630,_0x295d9e,_0x29ebed,_0x26ac0e){var _0x4de396;if((_0x4de396=_0x16480a['_getRecaptchaConfig']())!=null&&_0x4de396['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x13f6f7=await Ar(_0x16480a,_0x2e8630,_0x295d9e,_0x295d9e==='getOobCode');return _0x29ebed(_0x16480a,_0x13f6f7);}else return _0x29ebed(_0x16480a,_0x2e8630)['catch'](async _0x2ef592=>{if(_0x2ef592['code']==='auth/missing-recaptcha-token'){console['log'](_0x295d9e+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x1d9d7d=await Ar(_0x16480a,_0x2e8630,_0x295d9e,_0x295d9e==='getOobCode');return _0x29ebed(_0x16480a,_0x1d9d7d);}else return Promise['reject'](_0x2ef592);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x4e4d4b,_0x42b21e){const _0x1ea208=Bi(_0x4e4d4b,'auth');if(_0x1ea208['isInitialized']()){const _0x5e5f80=_0x1ea208['getImmediate'](),_0x5e278d=_0x1ea208['getOptions']();if(Me(_0x5e278d,_0x42b21e??{}))return _0x5e5f80;Q(_0x5e5f80,'already-initialized');}return _0x1ea208['initialize']({'options':_0x42b21e});}function Wf(_0x27b398,_0x468227){const _0x1c3d13=(_0x468227==null?void 0x0:_0x468227['persistence'])||[],_0x3e05ee=(Array['isArray'](_0x1c3d13)?_0x1c3d13:[_0x1c3d13])['map'](ie);_0x468227!=null&&_0x468227['errorMap']&&_0x27b398['_updateErrorMap'](_0x468227['errorMap']),_0x27b398['_initializeWithPersistence'](_0x3e05ee,_0x468227==null?void 0x0:_0x468227['popupRedirectResolver']);}function Bf(_0x1df9cf,_0x153984,_0xd5c329){const _0x26d671=qe(_0x1df9cf);m(/^https?:\/\//['test'](_0x153984),_0x26d671,'invalid-emulator-scheme');const _0x5d5990=!0x1,_0x369438=Ua(_0x153984),{host:_0x510b67,port:_0x4b0f64}=Vf(_0x153984),_0x44b7fe=_0x4b0f64===null?'':':'+_0x4b0f64,_0x3b64cb={'url':_0x369438+'//'+_0x510b67+_0x44b7fe+'/'},_0x2d82a9=Object['freeze']({'host':_0x510b67,'port':_0x4b0f64,'protocol':_0x369438['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x5d5990})});if(!_0x26d671['_canInitEmulator']){m(_0x26d671['config']['emulator']&&_0x26d671['emulatorConfig'],_0x26d671,'emulator-config-failed'),m(Me(_0x3b64cb,_0x26d671['config']['emulator'])&&Me(_0x2d82a9,_0x26d671['emulatorConfig']),_0x26d671,'emulator-config-failed');return;}_0x26d671['config']['emulator']=_0x3b64cb,_0x26d671['emulatorConfig']=_0x2d82a9,_0x26d671['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x510b67)?(jr(_0x369438+'//'+_0x510b67+_0x44b7fe),Kr('Auth',!0x0)):Hf();}function Ua(_0x16d57f){const _0x4231ac=_0x16d57f['indexOf'](':');return _0x4231ac<0x0?'':_0x16d57f['substr'](0x0,_0x4231ac+0x1);}function Vf(_0x453fd8){const _0xad6f93=Ua(_0x453fd8),_0x14b42e=/(\/\/)?([^?#/]+)/['exec'](_0x453fd8['substr'](_0xad6f93['length']));if(!_0x14b42e)return{'host':'','port':null};const _0x168282=_0x14b42e[0x2]['split']('@')['pop']()||'',_0x46b0df=/^(\[[^\]]+\])(:|$)/['exec'](_0x168282);if(_0x46b0df){const _0x3ad072=_0x46b0df[0x1];return{'host':_0x3ad072,'port':kr(_0x168282['substr'](_0x3ad072['length']+0x1))};}else{const [_0x1c93df,_0x1a2c9e]=_0x168282['split'](':');return{'host':_0x1c93df,'port':kr(_0x1a2c9e)};}}function kr(_0x29d5ad){if(!_0x29d5ad)return null;const _0x52f636=Number(_0x29d5ad);return isNaN(_0x52f636)?null:_0x52f636;}function Hf(){function _0x34f104(){const _0x32f828=document['createElement']('p'),_0x550185=_0x32f828['style'];_0x32f828['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x550185['position']='fixed',_0x550185['width']='100%',_0x550185['backgroundColor']='#ffffff',_0x550185['border']='.1em\x20solid\x20#000000',_0x550185['color']='#b50000',_0x550185['bottom']='0px',_0x550185['left']='0px',_0x550185['margin']='0px',_0x550185['zIndex']='10000',_0x550185['textAlign']='center',_0x32f828['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x32f828);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x34f104):_0x34f104());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x30180a,_0x370b28){this['providerId']=_0x30180a,this['signInMethod']=_0x370b28;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x59280e){return ne('not\x20implemented');}['_linkToIdToken'](_0x3572e2,_0x47b2a8){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x588300){return ne('not\x20implemented');}}async function $f(_0x2d6685,_0x54b076){return Ae(_0x2d6685,'POST','/v1/accounts:signUp',_0x54b076);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x38dd92,_0xcf387f){return Qt(_0x38dd92,'POST','/v1/accounts:signInWithPassword',Re(_0x38dd92,_0xcf387f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x1f8089,_0x248cdc){return Qt(_0x1f8089,'POST','/v1/accounts:signInWithEmailLink',Re(_0x1f8089,_0x248cdc));}async function zf(_0x382948,_0x90fb21){return Qt(_0x382948,'POST','/v1/accounts:signInWithEmailLink',Re(_0x382948,_0x90fb21));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x44b1e3,_0x22a558,_0x1d1a0f,_0x24b2d2=null){super('password',_0x1d1a0f),this['_email']=_0x44b1e3,this['_password']=_0x22a558,this['_tenantId']=_0x24b2d2;}static['_fromEmailAndPassword'](_0x9208f2,_0x1b49a6){return new Wt(_0x9208f2,_0x1b49a6,'password');}static['_fromEmailAndCode'](_0x182f12,_0x531f45,_0x38590d=null){return new Wt(_0x182f12,_0x531f45,'emailLink',_0x38590d);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x8f016d){const _0x318297=typeof _0x8f016d=='string'?JSON['parse'](_0x8f016d):_0x8f016d;if(_0x318297!=null&&_0x318297['email']&&(_0x318297!=null&&_0x318297['password'])){if(_0x318297['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x318297['email'],_0x318297['password']);if(_0x318297['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x318297['email'],_0x318297['password'],_0x318297['tenantId']);}return null;}async['_getIdTokenResponse'](_0x28b362){switch(this['signInMethod']){case'password':const _0x5235eb={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x28b362,_0x5235eb,'signInWithPassword',Gf);case'emailLink':return qf(_0x28b362,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x28b362,'internal-error');}}async['_linkToIdToken'](_0x135080,_0x54bf24){switch(this['signInMethod']){case'password':const _0x983f90={'idToken':_0x54bf24,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x135080,_0x983f90,'signUpPassword',$f);case'emailLink':return zf(_0x135080,{'idToken':_0x54bf24,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x135080,'internal-error');}}['_getReauthenticationResolver'](_0x516681){return this['_getIdTokenResponse'](_0x516681);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x3f7643,_0x59a8b5){return Qt(_0x3f7643,'POST','/v1/accounts:signInWithIdp',Re(_0x3f7643,_0x59a8b5));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x467508){const _0x351ef2=new Be(_0x467508['providerId'],_0x467508['signInMethod']);return _0x467508['idToken']||_0x467508['accessToken']?(_0x467508['idToken']&&(_0x351ef2['idToken']=_0x467508['idToken']),_0x467508['accessToken']&&(_0x351ef2['accessToken']=_0x467508['accessToken']),_0x467508['nonce']&&!_0x467508['pendingToken']&&(_0x351ef2['nonce']=_0x467508['nonce']),_0x467508['pendingToken']&&(_0x351ef2['pendingToken']=_0x467508['pendingToken'])):_0x467508['oauthToken']&&_0x467508['oauthTokenSecret']?(_0x351ef2['accessToken']=_0x467508['oauthToken'],_0x351ef2['secret']=_0x467508['oauthTokenSecret']):Q('argument-error'),_0x351ef2;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x427621){const _0x1a7afa=typeof _0x427621=='string'?JSON['parse'](_0x427621):_0x427621,{providerId:_0xe89704,signInMethod:_0x1eefff,..._0x4715be}=_0x1a7afa;if(!_0xe89704||!_0x1eefff)return null;const _0x49e861=new Be(_0xe89704,_0x1eefff);return _0x49e861['idToken']=_0x4715be['idToken']||void 0x0,_0x49e861['accessToken']=_0x4715be['accessToken']||void 0x0,_0x49e861['secret']=_0x4715be['secret'],_0x49e861['nonce']=_0x4715be['nonce'],_0x49e861['pendingToken']=_0x4715be['pendingToken']||null,_0x49e861;}['_getIdTokenResponse'](_0x1afa7f){const _0xed3852=this['buildRequest']();return Xe(_0x1afa7f,_0xed3852);}['_linkToIdToken'](_0x1c9dd1,_0x591b56){const _0x4ac0fe=this['buildRequest']();return _0x4ac0fe['idToken']=_0x591b56,Xe(_0x1c9dd1,_0x4ac0fe);}['_getReauthenticationResolver'](_0x367afb){const _0x25fce8=this['buildRequest']();return _0x25fce8['autoCreate']=!0x1,Xe(_0x367afb,_0x25fce8);}['buildRequest'](){const _0x540510={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x540510['pendingToken']=this['pendingToken'];else{const _0x41dfc2={};this['idToken']&&(_0x41dfc2['id_token']=this['idToken']),this['accessToken']&&(_0x41dfc2['access_token']=this['accessToken']),this['secret']&&(_0x41dfc2['oauth_token_secret']=this['secret']),_0x41dfc2['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x41dfc2['nonce']=this['nonce']),_0x540510['postBody']=ct(_0x41dfc2);}return _0x540510;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x233147){switch(_0x233147){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x1f71b4){const _0x1cccf8=vt(Et(_0x1f71b4))['link'],_0x116a3f=_0x1cccf8?vt(Et(_0x1cccf8))['deep_link_id']:null,_0x3f1666=vt(Et(_0x1f71b4))['deep_link_id'];return(_0x3f1666?vt(Et(_0x3f1666))['link']:null)||_0x3f1666||_0x116a3f||_0x1cccf8||_0x1f71b4;}class Rs{constructor(_0x202b57){const _0xe0c872=vt(Et(_0x202b57)),_0x33f531=_0xe0c872['apiKey']??null,_0x3eda83=_0xe0c872['oobCode']??null,_0x4dd9cc=Kf(_0xe0c872['mode']??null);m(_0x33f531&&_0x3eda83&&_0x4dd9cc,'argument-error'),this['apiKey']=_0x33f531,this['operation']=_0x4dd9cc,this['code']=_0x3eda83,this['continueUrl']=_0xe0c872['continueUrl']??null,this['languageCode']=_0xe0c872['lang']??null,this['tenantId']=_0xe0c872['tenantId']??null;}static['parseLink'](_0x2d7b3d){const _0x12da4d=Yf(_0x2d7b3d);try{return new Rs(_0x12da4d);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x214566,_0x37befa){return Wt['_fromEmailAndPassword'](_0x214566,_0x37befa);}static['credentialWithLink'](_0x3029a7,_0x439c9e){const _0x5354d8=Rs['parseLink'](_0x439c9e);return m(_0x5354d8,'argument-error'),Wt['_fromEmailAndCode'](_0x3029a7,_0x5354d8['code'],_0x5354d8['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x279ce4){this['providerId']=_0x279ce4,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x3db70d){this['defaultLanguageCode']=_0x3db70d;}['setCustomParameters'](_0x4bc04b){return this['customParameters']=_0x4bc04b,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x4320f7){return this['scopes']['includes'](_0x4320f7)||this['scopes']['push'](_0x4320f7),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0xdcf28e){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0xdcf28e});}static['credentialFromResult'](_0x2bbe62){return he['credentialFromTaggedObject'](_0x2bbe62);}static['credentialFromError'](_0x19f1a0){return he['credentialFromTaggedObject'](_0x19f1a0['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4fe69a}){if(!_0x4fe69a||!('oauthAccessToken'in _0x4fe69a)||!_0x4fe69a['oauthAccessToken'])return null;try{return he['credential'](_0x4fe69a['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x11197c,_0x234e15){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x11197c,'accessToken':_0x234e15});}static['credentialFromResult'](_0x27baa3){return ue['credentialFromTaggedObject'](_0x27baa3);}static['credentialFromError'](_0x22e8e0){return ue['credentialFromTaggedObject'](_0x22e8e0['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3c95db}){if(!_0x3c95db)return null;const {oauthIdToken:_0x410703,oauthAccessToken:_0x497335}=_0x3c95db;if(!_0x410703&&!_0x497335)return null;try{return ue['credential'](_0x410703,_0x497335);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x24ee45){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x24ee45});}static['credentialFromResult'](_0xa3d9e9){return de['credentialFromTaggedObject'](_0xa3d9e9);}static['credentialFromError'](_0x40e607){return de['credentialFromTaggedObject'](_0x40e607['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4e3c82}){if(!_0x4e3c82||!('oauthAccessToken'in _0x4e3c82)||!_0x4e3c82['oauthAccessToken'])return null;try{return de['credential'](_0x4e3c82['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x3bfc6e,_0x466414){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x3bfc6e,'oauthTokenSecret':_0x466414});}static['credentialFromResult'](_0x5e58f7){return fe['credentialFromTaggedObject'](_0x5e58f7);}static['credentialFromError'](_0x3e364d){return fe['credentialFromTaggedObject'](_0x3e364d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3af170}){if(!_0x3af170)return null;const {oauthAccessToken:_0x33cbac,oauthTokenSecret:_0x5541f2}=_0x3af170;if(!_0x33cbac||!_0x5541f2)return null;try{return fe['credential'](_0x33cbac,_0x5541f2);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x171470,_0x393cb9){return Qt(_0x171470,'POST','/v1/accounts:signUp',Re(_0x171470,_0x393cb9));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x2701a8){this['user']=_0x2701a8['user'],this['providerId']=_0x2701a8['providerId'],this['_tokenResponse']=_0x2701a8['_tokenResponse'],this['operationType']=_0x2701a8['operationType'];}static async['_fromIdTokenResponse'](_0x51892f,_0x5310bb,_0x1dc0e5,_0x451cc8=!0x1){const _0x4e1dc9=await K['_fromIdTokenResponse'](_0x51892f,_0x1dc0e5,_0x451cc8),_0x41ec1b=Nr(_0x1dc0e5);return new Ve({'user':_0x4e1dc9,'providerId':_0x41ec1b,'_tokenResponse':_0x1dc0e5,'operationType':_0x5310bb});}static async['_forOperation'](_0x5bae61,_0x509b98,_0x25149c){await _0x5bae61['_updateTokensIfNecessary'](_0x25149c,!0x0);const _0x519566=Nr(_0x25149c);return new Ve({'user':_0x5bae61,'providerId':_0x519566,'_tokenResponse':_0x25149c,'operationType':_0x509b98});}}function Nr(_0x308adf){return _0x308adf['providerId']?_0x308adf['providerId']:'phoneNumber'in _0x308adf?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x3e7518,_0x419a92,_0x1216b1,_0x5d406e){super(_0x419a92['code'],_0x419a92['message']),this['operationType']=_0x1216b1,this['user']=_0x5d406e,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x3e7518['name'],'tenantId':_0x3e7518['tenantId']??void 0x0,'_serverResponse':_0x419a92['customData']['_serverResponse'],'operationType':_0x1216b1};}static['_fromErrorAndOperation'](_0x4e4ebc,_0x5446b3,_0x3187ca,_0x2b1f22){return new An(_0x4e4ebc,_0x5446b3,_0x3187ca,_0x2b1f22);}}function Ba(_0x5d3b97,_0x2f632d,_0x14cc26,_0x4ba0e2){return(_0x2f632d==='reauthenticate'?_0x14cc26['_getReauthenticationResolver'](_0x5d3b97):_0x14cc26['_getIdTokenResponse'](_0x5d3b97))['catch'](_0x4414be=>{throw _0x4414be['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x5d3b97,_0x4414be,_0x2f632d,_0x4ba0e2):_0x4414be;});}async function Jf(_0x476eed,_0x28c814,_0x5baa01=!0x1){const _0x5a01fe=await Ut(_0x476eed,_0x28c814['_linkToIdToken'](_0x476eed['auth'],await _0x476eed['getIdToken']()),_0x5baa01);return Ve['_forOperation'](_0x476eed,'link',_0x5a01fe);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x4c02d8,_0x1f653a,_0x33c9aa=!0x1){const {auth:_0x58d849}=_0x4c02d8;if($(_0x58d849['app']))return Promise['reject'](re(_0x58d849));const _0x213cdb='reauthenticate';try{const _0x56f37b=await Ut(_0x4c02d8,Ba(_0x58d849,_0x213cdb,_0x1f653a,_0x4c02d8),_0x33c9aa);m(_0x56f37b['idToken'],_0x58d849,'internal-error');const _0x5496db=Ts(_0x56f37b['idToken']);m(_0x5496db,_0x58d849,'internal-error');const {sub:_0x4ee4b8}=_0x5496db;return m(_0x4c02d8['uid']===_0x4ee4b8,_0x58d849,'user-mismatch'),Ve['_forOperation'](_0x4c02d8,_0x213cdb,_0x56f37b);}catch(_0x479196){throw(_0x479196==null?void 0x0:_0x479196['code'])==='auth/user-not-found'&&Q(_0x58d849,'user-mismatch'),_0x479196;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x58cb41,_0x5b0997,_0xce6fb6=!0x1){if($(_0x58cb41['app']))return Promise['reject'](re(_0x58cb41));const _0x2d438b='signIn',_0x230c2e=await Ba(_0x58cb41,_0x2d438b,_0x5b0997),_0x200ec6=await Ve['_fromIdTokenResponse'](_0x58cb41,_0x2d438b,_0x230c2e);return _0xce6fb6||await _0x58cb41['_updateCurrentUser'](_0x200ec6['user']),_0x200ec6;}async function Zf(_0x375351,_0x3db5ce){return Va(qe(_0x375351),_0x3db5ce);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x5c3bf4){const _0x2a64f0=qe(_0x5c3bf4);_0x2a64f0['_getPasswordPolicyInternal']()&&await _0x2a64f0['_updatePasswordPolicy']();}async function P_(_0x3279b6,_0x15f4ce,_0x20ab59){if($(_0x3279b6['app']))return Promise['reject'](re(_0x3279b6));const _0x5b6ad3=qe(_0x3279b6),_0x466071=await Di(_0x5b6ad3,{'returnSecureToken':!0x0,'email':_0x15f4ce,'password':_0x20ab59,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x1d3d16=>{throw _0x1d3d16['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x3279b6),_0x1d3d16;}),_0x4457d0=await Ve['_fromIdTokenResponse'](_0x5b6ad3,'signIn',_0x466071);return await _0x5b6ad3['_updateCurrentUser'](_0x4457d0['user']),_0x4457d0;}function O_(_0x4f1c07,_0x53c068,_0x107f17){return $(_0x4f1c07['app'])?Promise['reject'](re(_0x4f1c07)):Zf(N(_0x4f1c07),pt['credential'](_0x53c068,_0x107f17))['catch'](async _0x4cb5c8=>{throw _0x4cb5c8['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x4f1c07),_0x4cb5c8;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x54ef0f,_0x39a541){return N(_0x54ef0f)['setPersistence'](_0x39a541);}function ep(_0xc6a6c5,_0x3b622b,_0x18bcf2,_0xca4219){return N(_0xc6a6c5)['onIdTokenChanged'](_0x3b622b,_0x18bcf2,_0xca4219);}function tp(_0x430642,_0x45a77c,_0x46a6d6){return N(_0x430642)['beforeAuthStateChanged'](_0x45a77c,_0x46a6d6);}function M_(_0x31e8de,_0x5466aa,_0x2aa1d8,_0x4f601d){return N(_0x31e8de)['onAuthStateChanged'](_0x5466aa,_0x2aa1d8,_0x4f601d);}function L_(_0x200bb9){return N(_0x200bb9)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x47546a,_0x5af5e3){this['storageRetriever']=_0x47546a,this['type']=_0x5af5e3;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x1cc9bb,_0x1cc580){return this['storage']['setItem'](_0x1cc9bb,JSON['stringify'](_0x1cc580)),Promise['resolve']();}['_get'](_0xc713a){const _0x36c73d=this['storage']['getItem'](_0xc713a);return Promise['resolve'](_0x36c73d?JSON['parse'](_0x36c73d):null);}['_remove'](_0x2656f0){return this['storage']['removeItem'](_0x2656f0),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x23bf22,_0x361f52)=>this['onStorageEvent'](_0x23bf22,_0x361f52),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x68087c){for(const _0x16fd02 of Object['keys'](this['listeners'])){const _0x2c8a08=this['storage']['getItem'](_0x16fd02),_0x1fa9a3=this['localCache'][_0x16fd02];_0x2c8a08!==_0x1fa9a3&&_0x68087c(_0x16fd02,_0x1fa9a3,_0x2c8a08);}}['onStorageEvent'](_0x4e6d71,_0x14a692=!0x1){if(!_0x4e6d71['key']){this['forAllChangedKeys']((_0x3d8925,_0x114f1b,_0x55bb34)=>{this['notifyListeners'](_0x3d8925,_0x55bb34);});return;}const _0x2ae5f1=_0x4e6d71['key'];_0x14a692?this['detachListener']():this['stopPolling']();const _0x361829=()=>{const _0x4a5c91=this['storage']['getItem'](_0x2ae5f1);!_0x14a692&&this['localCache'][_0x2ae5f1]===_0x4a5c91||this['notifyListeners'](_0x2ae5f1,_0x4a5c91);},_0x2747d4=this['storage']['getItem'](_0x2ae5f1);Tf()&&_0x2747d4!==_0x4e6d71['newValue']&&_0x4e6d71['newValue']!==_0x4e6d71['oldValue']?setTimeout(_0x361829,ip):_0x361829();}['notifyListeners'](_0x1595c1,_0x4981ea){this['localCache'][_0x1595c1]=_0x4981ea;const _0x4721d7=this['listeners'][_0x1595c1];if(_0x4721d7){for(const _0xe0f581 of Array['from'](_0x4721d7))_0xe0f581(_0x4981ea&&JSON['parse'](_0x4981ea));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x42f40a,_0x4b423e,_0x4e2807)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x42f40a,'oldValue':_0x4b423e,'newValue':_0x4e2807}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x414b69,_0xfc872c){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x414b69]||(this['listeners'][_0x414b69]=new Set(),this['localCache'][_0x414b69]=this['storage']['getItem'](_0x414b69)),this['listeners'][_0x414b69]['add'](_0xfc872c);}['_removeListener'](_0x591353,_0x53ff24){this['listeners'][_0x591353]&&(this['listeners'][_0x591353]['delete'](_0x53ff24),this['listeners'][_0x591353]['size']===0x0&&delete this['listeners'][_0x591353]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x40abff,_0x6c7ba6){await super['_set'](_0x40abff,_0x6c7ba6),this['localCache'][_0x40abff]=JSON['stringify'](_0x6c7ba6);}async['_get'](_0x2a13b1){const _0x4ea6f9=await super['_get'](_0x2a13b1);return this['localCache'][_0x2a13b1]=JSON['stringify'](_0x4ea6f9),_0x4ea6f9;}async['_remove'](_0x1ea5e7){await super['_remove'](_0x1ea5e7),delete this['localCache'][_0x1ea5e7];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x15de8a,_0x1a2841){}['_removeListener'](_0x9495e7,_0x3476db){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x18937b){return Promise['all'](_0x18937b['map'](async _0x32693b=>{try{return{'fulfilled':!0x0,'value':await _0x32693b};}catch(_0x281509){return{'fulfilled':!0x1,'reason':_0x281509};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x13cf85){this['eventTarget']=_0x13cf85,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x3209a1){const _0x4659d7=this['receivers']['find'](_0x840fa7=>_0x840fa7['isListeningto'](_0x3209a1));if(_0x4659d7)return _0x4659d7;const _0x3af452=new Kn(_0x3209a1);return this['receivers']['push'](_0x3af452),_0x3af452;}['isListeningto'](_0x4bc15a){return this['eventTarget']===_0x4bc15a;}async['handleEvent'](_0x493cf8){const _0x472aeb=_0x493cf8,{eventId:_0x3393fd,eventType:_0x3902fc,data:_0x11ab97}=_0x472aeb['data'],_0x4f1358=this['handlersMap'][_0x3902fc];if(!(_0x4f1358!=null&&_0x4f1358['size']))return;_0x472aeb['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x3393fd,'eventType':_0x3902fc});const _0x3ae00a=Array['from'](_0x4f1358)['map'](async _0x1846de=>_0x1846de(_0x472aeb['origin'],_0x11ab97)),_0x50a74e=await rp(_0x3ae00a);_0x472aeb['ports'][0x0]['postMessage']({'status':'done','eventId':_0x3393fd,'eventType':_0x3902fc,'response':_0x50a74e});}['_subscribe'](_0x568089,_0x4158a4){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x568089]||(this['handlersMap'][_0x568089]=new Set()),this['handlersMap'][_0x568089]['add'](_0x4158a4);}['_unsubscribe'](_0x1d1d9d,_0x404f30){this['handlersMap'][_0x1d1d9d]&&_0x404f30&&this['handlersMap'][_0x1d1d9d]['delete'](_0x404f30),(!_0x404f30||this['handlersMap'][_0x1d1d9d]['size']===0x0)&&delete this['handlersMap'][_0x1d1d9d],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x5551be='',_0x6aa9c8=0xa){let _0x5f352d='';for(let _0x4f4816=0x0;_0x4f4816<_0x6aa9c8;_0x4f4816++)_0x5f352d+=Math['floor'](Math['random']()*0xa);return _0x5551be+_0x5f352d;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x41c10c){this['target']=_0x41c10c,this['handlers']=new Set();}['removeMessageHandler'](_0x2b030d){_0x2b030d['messageChannel']&&(_0x2b030d['messageChannel']['port1']['removeEventListener']('message',_0x2b030d['onMessage']),_0x2b030d['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x2b030d);}async['_send'](_0x5de5f8,_0x4cb038,_0x544f7f=0x32){const _0x30c573=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x30c573)throw new Error('connection_unavailable');let _0x6209e7,_0x5b5f5b;return new Promise((_0x5a260b,_0x51b6ba)=>{const _0x1a0096=As('',0x14);_0x30c573['port1']['start']();const _0x364522=setTimeout(()=>{_0x51b6ba(new Error('unsupported_event'));},_0x544f7f);_0x5b5f5b={'messageChannel':_0x30c573,'onMessage'(_0x5b25a9){const _0x546e32=_0x5b25a9;if(_0x546e32['data']['eventId']===_0x1a0096)switch(_0x546e32['data']['status']){case'ack':clearTimeout(_0x364522),_0x6209e7=setTimeout(()=>{_0x51b6ba(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x6209e7),_0x5a260b(_0x546e32['data']['response']);break;default:clearTimeout(_0x364522),clearTimeout(_0x6209e7),_0x51b6ba(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x5b5f5b),_0x30c573['port1']['addEventListener']('message',_0x5b5f5b['onMessage']),this['target']['postMessage']({'eventType':_0x5de5f8,'eventId':_0x1a0096,'data':_0x4cb038},[_0x30c573['port2']]);})['finally'](()=>{_0x5b5f5b&&this['removeMessageHandler'](_0x5b5f5b);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x3423ec){Z()['location']['href']=_0x3423ec;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x4ca593;return((_0x4ca593=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x4ca593['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x28dedd){this['request']=_0x28dedd;}['toPromise'](){return new Promise((_0x22f952,_0x1f1416)=>{this['request']['addEventListener']('success',()=>{_0x22f952(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x1f1416(this['request']['error']);});});}}function Yn(_0x1f607e,_0x56e252){return _0x1f607e['transaction']([Nn],_0x56e252?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x221a11=indexedDB['deleteDatabase'](Ka);return new Xt(_0x221a11)['toPromise']();}function Mi(){const _0xde452a=indexedDB['open'](Ka,up);return new Promise((_0x38290c,_0x582e2f)=>{_0xde452a['addEventListener']('error',()=>{_0x582e2f(_0xde452a['error']);}),_0xde452a['addEventListener']('upgradeneeded',()=>{const _0x25d1f4=_0xde452a['result'];try{_0x25d1f4['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x29fd2a){_0x582e2f(_0x29fd2a);}}),_0xde452a['addEventListener']('success',async()=>{const _0x36a965=_0xde452a['result'];_0x36a965['objectStoreNames']['contains'](Nn)?_0x38290c(_0x36a965):(_0x36a965['close'](),await dp(),_0x38290c(await Mi()));});});}async function Pr(_0x35e57,_0x4b28cd,_0x53adb4){const _0x14d132=Yn(_0x35e57,!0x0)['put']({[Ya]:_0x4b28cd,'value':_0x53adb4});return new Xt(_0x14d132)['toPromise']();}async function fp(_0xa929cf,_0x358705){const _0x37cdf8=Yn(_0xa929cf,!0x1)['get'](_0x358705),_0x55bc2e=await new Xt(_0x37cdf8)['toPromise']();return _0x55bc2e===void 0x0?null:_0x55bc2e['value'];}function Or(_0x3159d6,_0xfe909c){const _0x6fa36d=Yn(_0x3159d6,!0x0)['delete'](_0xfe909c);return new Xt(_0x6fa36d)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x29433d){let _0x566719=0x0;for(;;)try{const _0x5bef07=await this['_openDb']();return await _0x29433d(_0x5bef07);}catch(_0x3c7b1c){if(_0x566719++>_p)throw _0x3c7b1c;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x21772b,_0x125b3e)=>({'keyProcessed':(await this['_poll']())['includes'](_0x125b3e['key'])})),this['receiver']['_subscribe']('ping',async(_0x4de5be,_0x5b8111)=>['keyChanged']);}async['initializeSender'](){var _0x5737d1,_0x1c5b6f;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x1a6af3=await this['sender']['_send']('ping',{},0x320);_0x1a6af3&&(_0x5737d1=_0x1a6af3[0x0])!=null&&_0x5737d1['fulfilled']&&(_0x1c5b6f=_0x1a6af3[0x0])!=null&&_0x1c5b6f['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x4a9324){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x4a9324},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x14ad38=await Mi();return await Pr(_0x14ad38,kn,'1'),await Or(_0x14ad38,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x5d508e){this['pendingWrites']++;try{await _0x5d508e();}finally{this['pendingWrites']--;}}async['_set'](_0x5ce265,_0x4464c8){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2b5347=>Pr(_0x2b5347,_0x5ce265,_0x4464c8)),this['localCache'][_0x5ce265]=_0x4464c8,this['notifyServiceWorker'](_0x5ce265)));}async['_get'](_0x178747){const _0x291ab5=await this['_withRetries'](_0x29cac5=>fp(_0x29cac5,_0x178747));return this['localCache'][_0x178747]=_0x291ab5,_0x291ab5;}async['_remove'](_0x44c9e7){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x38041b=>Or(_0x38041b,_0x44c9e7)),delete this['localCache'][_0x44c9e7],this['notifyServiceWorker'](_0x44c9e7)));}async['_poll'](){const _0x3bfd08=await this['_withRetries'](_0x23a8f7=>{const _0x4fb0f1=Yn(_0x23a8f7,!0x1)['getAll']();return new Xt(_0x4fb0f1)['toPromise']();});if(!_0x3bfd08)return[];if(this['pendingWrites']!==0x0)return[];const _0x308c56=[],_0x169b7b=new Set();if(_0x3bfd08['length']!==0x0){for(const {fbase_key:_0x394939,value:_0x102bd8}of _0x3bfd08)_0x169b7b['add'](_0x394939),JSON['stringify'](this['localCache'][_0x394939])!==JSON['stringify'](_0x102bd8)&&(this['notifyListeners'](_0x394939,_0x102bd8),_0x308c56['push'](_0x394939));}for(const _0x416fc3 of Object['keys'](this['localCache']))this['localCache'][_0x416fc3]&&!_0x169b7b['has'](_0x416fc3)&&(this['notifyListeners'](_0x416fc3,null),_0x308c56['push'](_0x416fc3));return _0x308c56;}['notifyListeners'](_0x48e5a9,_0x1197da){this['localCache'][_0x48e5a9]=_0x1197da;const _0x56dbc4=this['listeners'][_0x48e5a9];if(_0x56dbc4){for(const _0x5b3c52 of Array['from'](_0x56dbc4))_0x5b3c52(_0x1197da);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x5cb8e0,_0x443fc1){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x5cb8e0]||(this['listeners'][_0x5cb8e0]=new Set(),this['_get'](_0x5cb8e0)),this['listeners'][_0x5cb8e0]['add'](_0x443fc1);}['_removeListener'](_0x6983b5,_0x53b87b){this['listeners'][_0x6983b5]&&(this['listeners'][_0x6983b5]['delete'](_0x53b87b),this['listeners'][_0x6983b5]['size']===0x0&&delete this['listeners'][_0x6983b5]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x1b83c6,_0x3e5d67){return _0x3e5d67?ie(_0x3e5d67):(m(_0x1b83c6['_popupRedirectResolver'],_0x1b83c6,'argument-error'),_0x1b83c6['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x2d98e5){super('custom','custom'),this['params']=_0x2d98e5;}['_getIdTokenResponse'](_0x36e1e3){return Xe(_0x36e1e3,this['_buildIdpRequest']());}['_linkToIdToken'](_0x2eade4,_0x59d40c){return Xe(_0x2eade4,this['_buildIdpRequest'](_0x59d40c));}['_getReauthenticationResolver'](_0x5854c3){return Xe(_0x5854c3,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x102ee9){const _0x398810={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x102ee9&&(_0x398810['idToken']=_0x102ee9),_0x398810;}}function yp(_0x10c4e9){return Va(_0x10c4e9['auth'],new ks(_0x10c4e9),_0x10c4e9['bypassAuthState']);}function vp(_0x1a9a19){const {auth:_0x76f169,user:_0x2239d7}=_0x1a9a19;return m(_0x2239d7,_0x76f169,'internal-error'),Xf(_0x2239d7,new ks(_0x1a9a19),_0x1a9a19['bypassAuthState']);}async function Ep(_0x40cb62){const {auth:_0x4bcce9,user:_0x78cfb2}=_0x40cb62;return m(_0x78cfb2,_0x4bcce9,'internal-error'),Jf(_0x78cfb2,new ks(_0x40cb62),_0x40cb62['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x16be89,_0x5d4180,_0x52c626,_0x2fc479,_0x4d0f1d=!0x1){this['auth']=_0x16be89,this['resolver']=_0x52c626,this['user']=_0x2fc479,this['bypassAuthState']=_0x4d0f1d,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x5d4180)?_0x5d4180:[_0x5d4180];}['execute'](){return new Promise(async(_0x4441f2,_0x39a6ea)=>{this['pendingPromise']={'resolve':_0x4441f2,'reject':_0x39a6ea};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x151dab){this['reject'](_0x151dab);}});}async['onAuthEvent'](_0xad5b82){const {urlResponse:_0x96c37b,sessionId:_0x35f15c,postBody:_0x3783e9,tenantId:_0x1712c9,error:_0x358baf,type:_0x46d4fd}=_0xad5b82;if(_0x358baf){this['reject'](_0x358baf);return;}const _0x1a0127={'auth':this['auth'],'requestUri':_0x96c37b,'sessionId':_0x35f15c,'tenantId':_0x1712c9||void 0x0,'postBody':_0x3783e9||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x46d4fd)(_0x1a0127));}catch(_0x3954df){this['reject'](_0x3954df);}}['onError'](_0x506c9d){this['reject'](_0x506c9d);}['getIdpTask'](_0x5d5079){switch(_0x5d5079){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x351a58){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x351a58),this['unregisterAndCleanUp']();}['reject'](_0x4e3aca){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x4e3aca),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x49b4f7,_0x1929a5,_0x47883e,_0x2f103a,_0x4ceeea){super(_0x49b4f7,_0x1929a5,_0x2f103a,_0x4ceeea),this['provider']=_0x47883e,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x5b6ecd=await this['execute']();return m(_0x5b6ecd,this['auth'],'internal-error'),_0x5b6ecd;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0xa2a1b8=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0xa2a1b8),this['authWindow']['associatedEvent']=_0xa2a1b8,this['resolver']['_originValidation'](this['auth'])['catch'](_0x1374da=>{this['reject'](_0x1374da);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x317e58=>{_0x317e58||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x19168e;return((_0x19168e=this['authWindow'])==null?void 0x0:_0x19168e['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0xccd5ec=()=>{var _0x4178ed,_0x2d6794;if((_0x2d6794=(_0x4178ed=this['authWindow'])==null?void 0x0:_0x4178ed['window'])!=null&&_0x2d6794['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0xccd5ec,Ip['get']());};_0xccd5ec();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x35ef01,_0x189d86,_0x18b86a=!0x1){super(_0x35ef01,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x189d86,void 0x0,_0x18b86a),this['eventId']=null;}async['execute'](){let _0x191874=on['get'](this['auth']['_key']());if(!_0x191874){try{const _0x69c2d0=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x191874=()=>Promise['resolve'](_0x69c2d0);}catch(_0x1338a1){_0x191874=()=>Promise['reject'](_0x1338a1);}on['set'](this['auth']['_key'](),_0x191874);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x191874();}async['onAuthEvent'](_0x18ea7b){if(_0x18ea7b['type']==='signInViaRedirect')return super['onAuthEvent'](_0x18ea7b);if(_0x18ea7b['type']==='unknown'){this['resolve'](null);return;}if(_0x18ea7b['eventId']){const _0xa0569f=await this['auth']['_redirectUserForId'](_0x18ea7b['eventId']);if(_0xa0569f)return this['user']=_0xa0569f,super['onAuthEvent'](_0x18ea7b);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x264759,_0x29abaf){const _0x20d3d4=Rp(_0x29abaf),_0x2affa8=bp(_0x264759);if(!await _0x2affa8['_isAvailable']())return!0x1;const _0x5de6e8=await _0x2affa8['_get'](_0x20d3d4)==='true';return await _0x2affa8['_remove'](_0x20d3d4),_0x5de6e8;}function Sp(_0x425ab3,_0x32a1a4){on['set'](_0x425ab3['_key'](),_0x32a1a4);}function bp(_0x32a178){return ie(_0x32a178['_redirectPersistence']);}function Rp(_0x15052a){return rn(wp,_0x15052a['config']['apiKey'],_0x15052a['name']);}async function Ap(_0x25bb41,_0x3ade3e,_0x1e843a=!0x1){if($(_0x25bb41['app']))return Promise['reject'](re(_0x25bb41));const _0x519751=qe(_0x25bb41),_0x33f61c=mp(_0x519751,_0x3ade3e),_0x1b1685=await new Cp(_0x519751,_0x33f61c,_0x1e843a)['execute']();return _0x1b1685&&!_0x1e843a&&(delete _0x1b1685['user']['_redirectEventId'],await _0x519751['_persistUserIfCurrent'](_0x1b1685['user']),await _0x519751['_setRedirectUser'](null,_0x3ade3e)),_0x1b1685;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x48c171){this['auth']=_0x48c171,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x2ce4fe){this['consumers']['add'](_0x2ce4fe),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x2ce4fe)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x2ce4fe),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x24d31d){this['consumers']['delete'](_0x24d31d);}['onEvent'](_0x7cdd95){if(this['hasEventBeenHandled'](_0x7cdd95))return!0x1;let _0x5c91cb=!0x1;return this['consumers']['forEach'](_0x5bfe44=>{this['isEventForConsumer'](_0x7cdd95,_0x5bfe44)&&(_0x5c91cb=!0x0,this['sendToConsumer'](_0x7cdd95,_0x5bfe44),this['saveEventToCache'](_0x7cdd95));}),this['hasHandledPotentialRedirect']||!Pp(_0x7cdd95)||(this['hasHandledPotentialRedirect']=!0x0,_0x5c91cb||(this['queuedRedirectEvent']=_0x7cdd95,_0x5c91cb=!0x0)),_0x5c91cb;}['sendToConsumer'](_0x5881da,_0x281aeb){var _0x520639;if(_0x5881da['error']&&!Xa(_0x5881da)){const _0x38d4e0=((_0x520639=_0x5881da['error']['code'])==null?void 0x0:_0x520639['split']('auth/')[0x1])||'internal-error';_0x281aeb['onError'](X(this['auth'],_0x38d4e0));}else _0x281aeb['onAuthEvent'](_0x5881da);}['isEventForConsumer'](_0x451392,_0x4df4f8){const _0x34f0c8=_0x4df4f8['eventId']===null||!!_0x451392['eventId']&&_0x451392['eventId']===_0x4df4f8['eventId'];return _0x4df4f8['filter']['includes'](_0x451392['type'])&&_0x34f0c8;}['hasEventBeenHandled'](_0x4bbc31){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x4bbc31));}['saveEventToCache'](_0xfe07a8){this['cachedEventUids']['add'](Dr(_0xfe07a8)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x465086){return[_0x465086['type'],_0x465086['eventId'],_0x465086['sessionId'],_0x465086['tenantId']]['filter'](_0x17338b=>_0x17338b)['join']('-');}function Xa({type:_0x23cb29,error:_0x8dac52}){return _0x23cb29==='unknown'&&(_0x8dac52==null?void 0x0:_0x8dac52['code'])==='auth/no-auth-event';}function Pp(_0x3d7c14){switch(_0x3d7c14['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x3d7c14);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x4c7d0c,_0x580bcb={}){return Ae(_0x4c7d0c,'GET','/v1/projects',_0x580bcb);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x481450){if(_0x481450['config']['emulator'])return;const {authorizedDomains:_0x1a5f27}=await Op(_0x481450);for(const _0x17b77e of _0x1a5f27)try{if(xp(_0x17b77e))return;}catch{}Q(_0x481450,'unauthorized-domain');}function xp(_0xea9743){const _0x72b3f9=Pi(),{protocol:_0x235acc,hostname:_0x5a8655}=new URL(_0x72b3f9);if(_0xea9743['startsWith']('chrome-extension://')){const _0x3e5ada=new URL(_0xea9743);return _0x3e5ada['hostname']===''&&_0x5a8655===''?_0x235acc==='chrome-extension:'&&_0xea9743['replace']('chrome-extension://','')===_0x72b3f9['replace']('chrome-extension://',''):_0x235acc==='chrome-extension:'&&_0x3e5ada['hostname']===_0x5a8655;}if(!Mp['test'](_0x235acc))return!0x1;if(Dp['test'](_0xea9743))return _0x5a8655===_0xea9743;const _0x2ced3d=_0xea9743['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x2ced3d+'|'+_0x2ced3d+')$','i')['test'](_0x5a8655);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x222da3=Z()['___jsl'];if(_0x222da3!=null&&_0x222da3['H']){for(const _0x49f276 of Object['keys'](_0x222da3['H']))if(_0x222da3['H'][_0x49f276]['r']=_0x222da3['H'][_0x49f276]['r']||[],_0x222da3['H'][_0x49f276]['L']=_0x222da3['H'][_0x49f276]['L']||[],_0x222da3['H'][_0x49f276]['r']=[..._0x222da3['H'][_0x49f276]['L']],_0x222da3['CP']){for(let _0x3e4d49=0x0;_0x3e4d49<_0x222da3['CP']['length'];_0x3e4d49++)_0x222da3['CP'][_0x3e4d49]=null;}}}function Up(_0x59fbb1){return new Promise((_0x10bcd6,_0x1c2ec6)=>{var _0x1106f8,_0x5f1009,_0x469581;function _0x5b96af(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x10bcd6(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x1c2ec6(X(_0x59fbb1,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x5f1009=(_0x1106f8=Z()['gapi'])==null?void 0x0:_0x1106f8['iframes'])!=null&&_0x5f1009['Iframe'])_0x10bcd6(gapi['iframes']['getContext']());else{if((_0x469581=Z()['gapi'])!=null&&_0x469581['load'])_0x5b96af();else{const _0x34f0be=Df('iframefcb');return Z()[_0x34f0be]=()=>{gapi['load']?_0x5b96af():_0x1c2ec6(X(_0x59fbb1,'network-request-failed'));},xa(Of()+'?onload='+_0x34f0be)['catch'](_0x315aec=>_0x1c2ec6(_0x315aec));}}})['catch'](_0x189ef9=>{throw an=null,_0x189ef9;});}let an=null;function Wp(_0x2c9d0d){return an=an||Up(_0x2c9d0d),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x4c86a2){const _0x48bba6=_0x4c86a2['config'];m(_0x48bba6['authDomain'],_0x4c86a2,'auth-domain-config-required');const _0x5abaf1=_0x48bba6['emulator']?Cs(_0x48bba6,Hp):'https://'+_0x4c86a2['config']['authDomain']+'/'+Vp,_0x23df1e={'apiKey':_0x48bba6['apiKey'],'appName':_0x4c86a2['name'],'v':lt},_0x3f0d49=Gp['get'](_0x4c86a2['config']['apiHost']);_0x3f0d49&&(_0x23df1e['eid']=_0x3f0d49);const _0x1193f6=_0x4c86a2['_getFrameworks']();return _0x1193f6['length']&&(_0x23df1e['fw']=_0x1193f6['join'](',')),_0x5abaf1+'?'+ct(_0x23df1e)['slice'](0x1);}async function zp(_0x5cc8e5){const _0x3adeeb=await Wp(_0x5cc8e5),_0x3d5cc9=Z()['gapi'];return m(_0x3d5cc9,_0x5cc8e5,'internal-error'),_0x3adeeb['open']({'where':document['body'],'url':qp(_0x5cc8e5),'messageHandlersFilter':_0x3d5cc9['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x355108=>new Promise(async(_0x4b5470,_0x244e36)=>{await _0x355108['restyle']({'setHideOnLeave':!0x1});const _0x4d82fa=X(_0x5cc8e5,'network-request-failed'),_0x5a51f0=Z()['setTimeout'](()=>{_0x244e36(_0x4d82fa);},Bp['get']());function _0x2761cd(){Z()['clearTimeout'](_0x5a51f0),_0x4b5470(_0x355108);}_0x355108['ping'](_0x2761cd)['then'](_0x2761cd,()=>{_0x244e36(_0x4d82fa);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x3ae1b9){this['window']=_0x3ae1b9,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x448f97,_0x1b7b39,_0x5980b7,_0x9ca5a3=Kp,_0x169b3d=Yp){const _0x10087b=Math['max']((window['screen']['availHeight']-_0x169b3d)/0x2,0x0)['toString'](),_0x723d58=Math['max']((window['screen']['availWidth']-_0x9ca5a3)/0x2,0x0)['toString']();let _0x48463='';const _0x24b846={...jp,'width':_0x9ca5a3['toString'](),'height':_0x169b3d['toString'](),'top':_0x10087b,'left':_0x723d58},_0x16b86c=W()['toLowerCase']();_0x5980b7&&(_0x48463=ka(_0x16b86c)?Qp:_0x5980b7),Ra(_0x16b86c)&&(_0x1b7b39=_0x1b7b39||Jp,_0x24b846['scrollbars']='yes');const _0x2c7bdb=Object['entries'](_0x24b846)['reduce']((_0x5db0f6,[_0x4bff1a,_0x1a21e5])=>''+_0x5db0f6+_0x4bff1a+'='+_0x1a21e5+',','');if(Cf(_0x16b86c)&&_0x48463!=='_self')return Zp(_0x1b7b39||'',_0x48463),new Lr(null);const _0x5ade62=window['open'](_0x1b7b39||'',_0x48463,_0x2c7bdb);m(_0x5ade62,_0x448f97,'popup-blocked');try{_0x5ade62['focus']();}catch{}return new Lr(_0x5ade62);}function Zp(_0xb6fd05,_0x3e7d84){const _0x195342=document['createElement']('a');_0x195342['href']=_0xb6fd05,_0x195342['target']=_0x3e7d84;const _0x1c3b76=document['createEvent']('MouseEvent');_0x1c3b76['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x195342['dispatchEvent'](_0x1c3b76);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x4136e2,_0xe2e418,_0x299bb4,_0x56cfbb,_0x248546,_0x274a1e){m(_0x4136e2['config']['authDomain'],_0x4136e2,'auth-domain-config-required'),m(_0x4136e2['config']['apiKey'],_0x4136e2,'invalid-api-key');const _0x13e653={'apiKey':_0x4136e2['config']['apiKey'],'appName':_0x4136e2['name'],'authType':_0x299bb4,'redirectUrl':_0x56cfbb,'v':lt,'eventId':_0x248546};if(_0xe2e418 instanceof Wa){_0xe2e418['setDefaultLanguage'](_0x4136e2['languageCode']),_0x13e653['providerId']=_0xe2e418['providerId']||'',ui(_0xe2e418['getCustomParameters']())||(_0x13e653['customParameters']=JSON['stringify'](_0xe2e418['getCustomParameters']()));for(const [_0x4e45d5,_0x3bacce]of Object['entries']({}))_0x13e653[_0x4e45d5]=_0x3bacce;}if(_0xe2e418 instanceof Jt){const _0x1e1dad=_0xe2e418['getScopes']()['filter'](_0x40f0be=>_0x40f0be!=='');_0x1e1dad['length']>0x0&&(_0x13e653['scopes']=_0x1e1dad['join'](','));}_0x4136e2['tenantId']&&(_0x13e653['tid']=_0x4136e2['tenantId']);const _0x45c0fd=_0x13e653;for(const _0x12568c of Object['keys'](_0x45c0fd))_0x45c0fd[_0x12568c]===void 0x0&&delete _0x45c0fd[_0x12568c];const _0x3b7420=await _0x4136e2['_getAppCheckToken'](),_0x43ac5d=_0x3b7420?'#'+n_+'='+encodeURIComponent(_0x3b7420):'';return i_(_0x4136e2)+'?'+ct(_0x45c0fd)['slice'](0x1)+_0x43ac5d;}function i_({config:_0x257a8c}){return _0x257a8c['emulator']?Cs(_0x257a8c,t_):'https://'+_0x257a8c['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x379a66,_0x1c5ea9,_0x32e783,_0x2274c6){var _0x195f31;ce((_0x195f31=this['eventManagers'][_0x379a66['_key']()])==null?void 0x0:_0x195f31['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x4600e1=await xr(_0x379a66,_0x1c5ea9,_0x32e783,Pi(),_0x2274c6);return Xp(_0x379a66,_0x4600e1,As());}async['_openRedirect'](_0x42a23a,_0x54eb50,_0x6042b9,_0xae4bf4){await this['_originValidation'](_0x42a23a);const _0x4f8717=await xr(_0x42a23a,_0x54eb50,_0x6042b9,Pi(),_0xae4bf4);return ap(_0x4f8717),new Promise(()=>{});}['_initialize'](_0xd4dc18){const _0x218969=_0xd4dc18['_key']();if(this['eventManagers'][_0x218969]){const {manager:_0x182c16,promise:_0x268df0}=this['eventManagers'][_0x218969];return _0x182c16?Promise['resolve'](_0x182c16):(ce(_0x268df0,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x268df0);}const _0x1f5061=this['initAndGetManager'](_0xd4dc18);return this['eventManagers'][_0x218969]={'promise':_0x1f5061},_0x1f5061['catch'](()=>{delete this['eventManagers'][_0x218969];}),_0x1f5061;}async['initAndGetManager'](_0x2a164e){const _0x2f202b=await zp(_0x2a164e),_0x1416da=new Np(_0x2a164e);return _0x2f202b['register']('authEvent',_0x32b6c2=>(m(_0x32b6c2==null?void 0x0:_0x32b6c2['authEvent'],_0x2a164e,'invalid-auth-event'),{'status':_0x1416da['onEvent'](_0x32b6c2['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x2a164e['_key']()]={'manager':_0x1416da},this['iframes'][_0x2a164e['_key']()]=_0x2f202b,_0x1416da;}['_isIframeWebStorageSupported'](_0x3efaf5,_0x2f5724){this['iframes'][_0x3efaf5['_key']()]['send'](hi,{'type':hi},_0x29ea28=>{var _0x53cf9d;const _0x1b2a4c=(_0x53cf9d=_0x29ea28==null?void 0x0:_0x29ea28[0x0])==null?void 0x0:_0x53cf9d[hi];_0x1b2a4c!==void 0x0&&_0x2f5724(!!_0x1b2a4c),Q(_0x3efaf5,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x327f57){const _0x163646=_0x327f57['_key']();return this['originValidationPromises'][_0x163646]||(this['originValidationPromises'][_0x163646]=Lp(_0x327f57)),this['originValidationPromises'][_0x163646];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x5997d1){this['auth']=_0x5997d1,this['internalListeners']=new Map();}['getUid'](){var _0x1fe510;return this['assertAuthConfigured'](),((_0x1fe510=this['auth']['currentUser'])==null?void 0x0:_0x1fe510['uid'])||null;}async['getToken'](_0x2c7c62){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x2c7c62)}:null;}['addAuthTokenListener'](_0x14f805){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x14f805))return;const _0x36ffa2=this['auth']['onIdTokenChanged'](_0xdb2b9=>{_0x14f805((_0xdb2b9==null?void 0x0:_0xdb2b9['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x14f805,_0x36ffa2),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x1e56f7){this['assertAuthConfigured']();const _0x6128b8=this['internalListeners']['get'](_0x1e56f7);_0x6128b8&&(this['internalListeners']['delete'](_0x1e56f7),_0x6128b8(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x395c7e){switch(_0x395c7e){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x22d3a8){Ze(new Le('auth',(_0x19a5cf,{options:_0x3ca447})=>{const _0x3b434e=_0x19a5cf['getProvider']('app')['getImmediate'](),_0x530aaa=_0x19a5cf['getProvider']('heartbeat'),_0x56a40a=_0x19a5cf['getProvider']('app-check-internal'),{apiKey:_0x4f391b,authDomain:_0x1be26d}=_0x3b434e['options'];m(_0x4f391b&&!_0x4f391b['includes'](':'),'invalid-api-key',{'appName':_0x3b434e['name']});const _0x59d97a={'apiKey':_0x4f391b,'authDomain':_0x1be26d,'clientPlatform':_0x22d3a8,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x22d3a8)},_0x54721f=new kf(_0x3b434e,_0x530aaa,_0x56a40a,_0x59d97a);return Wf(_0x54721f,_0x3ca447),_0x54721f;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x53969e,_0x50a3bc,_0x2c85f9)=>{_0x53969e['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x531055=>{const _0x474fde=qe(_0x531055['getProvider']('auth')['getImmediate']());return(_0x4db513=>new o_(_0x4db513))(_0x474fde);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x22d3a8)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x1ad372=>async _0x5081b0=>{const _0x4212ed=_0x5081b0&&await _0x5081b0['getIdTokenResult'](),_0x1c57e8=_0x4212ed&&(new Date()['getTime']()-Date['parse'](_0x4212ed['issuedAtTime']))/0x3e8;if(_0x1c57e8&&_0x1c57e8>h_)return;const _0x5c6914=_0x4212ed==null?void 0x0:_0x4212ed['token'];Wr!==_0x5c6914&&(Wr=_0x5c6914,await fetch(_0x1ad372,{'method':_0x5c6914?'POST':'DELETE','headers':_0x5c6914?{'Authorization':'Bearer\x20'+_0x5c6914}:{}}));};function x_(_0x3449de=Zr()){const _0x42f089=Bi(_0x3449de,'auth');if(_0x42f089['isInitialized']())return _0x42f089['getImmediate']();const _0x148f5f=Uf(_0x3449de,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x157bf3=zr('authTokenSyncURL');if(_0x157bf3&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x2668c0=new URL(_0x157bf3,location['origin']);if(location['origin']===_0x2668c0['origin']){const _0x2b5c98=u_(_0x2668c0['toString']());tp(_0x148f5f,_0x2b5c98,()=>_0x2b5c98(_0x148f5f['currentUser'])),ep(_0x148f5f,_0x183d3=>_0x2b5c98(_0x183d3));}}const _0x5bc6fc=Gr('auth');return _0x5bc6fc&&Bf(_0x148f5f,'http://'+_0x5bc6fc),_0x148f5f;}function d_(){var _0x2e22b7;return((_0x2e22b7=document['getElementsByTagName']('head'))==null?void 0x0:_0x2e22b7[0x0])??document;}Nf({'loadJS'(_0x25892b){return new Promise((_0x4594a8,_0x2874dd)=>{const _0x2e3323=document['createElement']('script');_0x2e3323['setAttribute']('src',_0x25892b),_0x2e3323['onload']=_0x4594a8,_0x2e3323['onerror']=_0x1e6392=>{const _0x1825c1=X('internal-error');_0x1825c1['customData']=_0x1e6392,_0x2874dd(_0x1825c1);},_0x2e3323['type']='text/javascript',_0x2e3323['charset']='UTF-8',d_()['appendChild'](_0x2e3323);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};