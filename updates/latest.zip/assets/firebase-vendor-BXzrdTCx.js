const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x23eb2f,_0x1e45b9){if(!_0x23eb2f)throw rt(_0x1e45b9);},rt=function(_0x239776){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x239776);},Vr=function(_0x5436b1){const _0x1b4e4b=[];let _0x2a8c0f=0x0;for(let _0x15e8ac=0x0;_0x15e8ac<_0x5436b1['length'];_0x15e8ac++){let _0x230346=_0x5436b1['charCodeAt'](_0x15e8ac);_0x230346<0x80?_0x1b4e4b[_0x2a8c0f++]=_0x230346:_0x230346<0x800?(_0x1b4e4b[_0x2a8c0f++]=_0x230346>>0x6|0xc0,_0x1b4e4b[_0x2a8c0f++]=_0x230346&0x3f|0x80):(_0x230346&0xfc00)===0xd800&&_0x15e8ac+0x1<_0x5436b1['length']&&(_0x5436b1['charCodeAt'](_0x15e8ac+0x1)&0xfc00)===0xdc00?(_0x230346=0x10000+((_0x230346&0x3ff)<<0xa)+(_0x5436b1['charCodeAt'](++_0x15e8ac)&0x3ff),_0x1b4e4b[_0x2a8c0f++]=_0x230346>>0x12|0xf0,_0x1b4e4b[_0x2a8c0f++]=_0x230346>>0xc&0x3f|0x80,_0x1b4e4b[_0x2a8c0f++]=_0x230346>>0x6&0x3f|0x80,_0x1b4e4b[_0x2a8c0f++]=_0x230346&0x3f|0x80):(_0x1b4e4b[_0x2a8c0f++]=_0x230346>>0xc|0xe0,_0x1b4e4b[_0x2a8c0f++]=_0x230346>>0x6&0x3f|0x80,_0x1b4e4b[_0x2a8c0f++]=_0x230346&0x3f|0x80);}return _0x1b4e4b;},ec=function(_0x5ed5ac){const _0x501267=[];let _0x60dcfa=0x0,_0x343094=0x0;for(;_0x60dcfa<_0x5ed5ac['length'];){const _0xf9a921=_0x5ed5ac[_0x60dcfa++];if(_0xf9a921<0x80)_0x501267[_0x343094++]=String['fromCharCode'](_0xf9a921);else{if(_0xf9a921>0xbf&&_0xf9a921<0xe0){const _0x428d43=_0x5ed5ac[_0x60dcfa++];_0x501267[_0x343094++]=String['fromCharCode']((_0xf9a921&0x1f)<<0x6|_0x428d43&0x3f);}else{if(_0xf9a921>0xef&&_0xf9a921<0x16d){const _0x59f359=_0x5ed5ac[_0x60dcfa++],_0x410f8c=_0x5ed5ac[_0x60dcfa++],_0x25cc9f=_0x5ed5ac[_0x60dcfa++],_0x38541e=((_0xf9a921&0x7)<<0x12|(_0x59f359&0x3f)<<0xc|(_0x410f8c&0x3f)<<0x6|_0x25cc9f&0x3f)-0x10000;_0x501267[_0x343094++]=String['fromCharCode'](0xd800+(_0x38541e>>0xa)),_0x501267[_0x343094++]=String['fromCharCode'](0xdc00+(_0x38541e&0x3ff));}else{const _0xef706e=_0x5ed5ac[_0x60dcfa++],_0x45ea44=_0x5ed5ac[_0x60dcfa++];_0x501267[_0x343094++]=String['fromCharCode']((_0xf9a921&0xf)<<0xc|(_0xef706e&0x3f)<<0x6|_0x45ea44&0x3f);}}}}return _0x501267['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x12d992,_0x3938a6){if(!Array['isArray'](_0x12d992))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x4ec4d0=_0x3938a6?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x52c2df=[];for(let _0x494b7d=0x0;_0x494b7d<_0x12d992['length'];_0x494b7d+=0x3){const _0x1a7071=_0x12d992[_0x494b7d],_0x1644d4=_0x494b7d+0x1<_0x12d992['length'],_0x36590f=_0x1644d4?_0x12d992[_0x494b7d+0x1]:0x0,_0x13e536=_0x494b7d+0x2<_0x12d992['length'],_0x46d637=_0x13e536?_0x12d992[_0x494b7d+0x2]:0x0,_0x9ab0d2=_0x1a7071>>0x2,_0x52cdf9=(_0x1a7071&0x3)<<0x4|_0x36590f>>0x4;let _0x1d7df3=(_0x36590f&0xf)<<0x2|_0x46d637>>0x6,_0x1472e5=_0x46d637&0x3f;_0x13e536||(_0x1472e5=0x40,_0x1644d4||(_0x1d7df3=0x40)),_0x52c2df['push'](_0x4ec4d0[_0x9ab0d2],_0x4ec4d0[_0x52cdf9],_0x4ec4d0[_0x1d7df3],_0x4ec4d0[_0x1472e5]);}return _0x52c2df['join']('');},'encodeString'(_0x19aea3,_0x1e7fbf){return this['HAS_NATIVE_SUPPORT']&&!_0x1e7fbf?btoa(_0x19aea3):this['encodeByteArray'](Vr(_0x19aea3),_0x1e7fbf);},'decodeString'(_0x58b85e,_0x46e261){return this['HAS_NATIVE_SUPPORT']&&!_0x46e261?atob(_0x58b85e):ec(this['decodeStringToByteArray'](_0x58b85e,_0x46e261));},'decodeStringToByteArray'(_0x4c1c35,_0x83d414){this['init_']();const _0x5d6c2d=_0x83d414?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x5c47ac=[];for(let _0x4ab879=0x0;_0x4ab879<_0x4c1c35['length'];){const _0x435e6b=_0x5d6c2d[_0x4c1c35['charAt'](_0x4ab879++)],_0x10f8af=_0x4ab879<_0x4c1c35['length']?_0x5d6c2d[_0x4c1c35['charAt'](_0x4ab879)]:0x0;++_0x4ab879;const _0x195d8f=_0x4ab879<_0x4c1c35['length']?_0x5d6c2d[_0x4c1c35['charAt'](_0x4ab879)]:0x40;++_0x4ab879;const _0x1a9c73=_0x4ab879<_0x4c1c35['length']?_0x5d6c2d[_0x4c1c35['charAt'](_0x4ab879)]:0x40;if(++_0x4ab879,_0x435e6b==null||_0x10f8af==null||_0x195d8f==null||_0x1a9c73==null)throw new tc();const _0x1e8d55=_0x435e6b<<0x2|_0x10f8af>>0x4;if(_0x5c47ac['push'](_0x1e8d55),_0x195d8f!==0x40){const _0x82f94b=_0x10f8af<<0x4&0xf0|_0x195d8f>>0x2;if(_0x5c47ac['push'](_0x82f94b),_0x1a9c73!==0x40){const _0x23b161=_0x195d8f<<0x6&0xc0|_0x1a9c73;_0x5c47ac['push'](_0x23b161);}}}return _0x5c47ac;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x431f4a=0x0;_0x431f4a<this['ENCODED_VALS']['length'];_0x431f4a++)this['byteToCharMap_'][_0x431f4a]=this['ENCODED_VALS']['charAt'](_0x431f4a),this['charToByteMap_'][this['byteToCharMap_'][_0x431f4a]]=_0x431f4a,this['byteToCharMapWebSafe_'][_0x431f4a]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x431f4a),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x431f4a]]=_0x431f4a,_0x431f4a>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x431f4a)]=_0x431f4a,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x431f4a)]=_0x431f4a);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x121c5b){const _0x4e6c3c=Vr(_0x121c5b);return Li['encodeByteArray'](_0x4e6c3c,!0x0);},cn=function(_0x439ae4){return Hr(_0x439ae4)['replace'](/\./g,'');},ln=function(_0x2f2279){try{return Li['decodeString'](_0x2f2279,!0x0);}catch(_0x52beb0){console['error']('base64Decode\x20failed:\x20',_0x52beb0);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x118f57){return $r(void 0x0,_0x118f57);}function $r(_0xdc8411,_0x294dab){if(!(_0x294dab instanceof Object))return _0x294dab;switch(_0x294dab['constructor']){case Date:const _0x31578c=_0x294dab;return new Date(_0x31578c['getTime']());case Object:_0xdc8411===void 0x0&&(_0xdc8411={});break;case Array:_0xdc8411=[];break;default:return _0x294dab;}for(const _0x5c0936 in _0x294dab)!_0x294dab['hasOwnProperty'](_0x5c0936)||!ic(_0x5c0936)||(_0xdc8411[_0x5c0936]=$r(_0xdc8411[_0x5c0936],_0x294dab[_0x5c0936]));return _0xdc8411;}function ic(_0x18609b){return _0x18609b!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x26ae28=Ns['__FIREBASE_DEFAULTS__'];if(_0x26ae28)return JSON['parse'](_0x26ae28);},ac=()=>{if(typeof document>'u')return;let _0x1f33ec;try{_0x1f33ec=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x2189e9=_0x1f33ec&&ln(_0x1f33ec[0x1]);return _0x2189e9&&JSON['parse'](_0x2189e9);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x4b6cc2){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4b6cc2);return;}},Gr=_0x1ca484=>{var _0x430775,_0xbdc5e8;return(_0xbdc5e8=(_0x430775=xi())==null?void 0x0:_0x430775['emulatorHosts'])==null?void 0x0:_0xbdc5e8[_0x1ca484];},cc=_0xda92cb=>{const _0x9ac67=Gr(_0xda92cb);if(!_0x9ac67)return;const _0x1eb1e7=_0x9ac67['lastIndexOf'](':');if(_0x1eb1e7<=0x0||_0x1eb1e7+0x1===_0x9ac67['length'])throw new Error('Invalid\x20host\x20'+_0x9ac67+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x23c055=parseInt(_0x9ac67['substring'](_0x1eb1e7+0x1),0xa);return _0x9ac67[0x0]==='['?[_0x9ac67['substring'](0x1,_0x1eb1e7-0x1),_0x23c055]:[_0x9ac67['substring'](0x0,_0x1eb1e7),_0x23c055];},qr=()=>{var _0x13371c;return(_0x13371c=xi())==null?void 0x0:_0x13371c['config'];},zr=_0x16dbc4=>{var _0x3a1e8f;return(_0x3a1e8f=xi())==null?void 0x0:_0x3a1e8f['_'+_0x16dbc4];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x1de92c,_0xffeb8f)=>{this['resolve']=_0x1de92c,this['reject']=_0xffeb8f;});}['wrapCallback'](_0x4d83b7){return(_0x586a8b,_0x493b96)=>{_0x586a8b?this['reject'](_0x586a8b):this['resolve'](_0x493b96),typeof _0x4d83b7=='function'&&(this['promise']['catch'](()=>{}),_0x4d83b7['length']===0x1?_0x4d83b7(_0x586a8b):_0x4d83b7(_0x586a8b,_0x493b96));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x2aa249){try{return(_0x2aa249['startsWith']('http://')||_0x2aa249['startsWith']('https://')?new URL(_0x2aa249)['hostname']:_0x2aa249)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x1a9cc0){return(await fetch(_0x1a9cc0,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x15fab1,_0x41761b){if(_0x15fab1['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x1bdb68={'alg':'none','type':'JWT'},_0x252b9c=_0x41761b||'demo-project',_0x48bd13=_0x15fab1['iat']||0x0,_0x55b52d=_0x15fab1['sub']||_0x15fab1['user_id'];if(!_0x55b52d)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x5c3773={'iss':'https://securetoken.google.com/'+_0x252b9c,'aud':_0x252b9c,'iat':_0x48bd13,'exp':_0x48bd13+0xe10,'auth_time':_0x48bd13,'sub':_0x55b52d,'user_id':_0x55b52d,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x15fab1};return[cn(JSON['stringify'](_0x1bdb68)),cn(JSON['stringify'](_0x5c3773)),'']['join']('.');}const It={};function hc(){const _0x476b60={'prod':[],'emulator':[]};for(const _0x1283c4 of Object['keys'](It))It[_0x1283c4]?_0x476b60['emulator']['push'](_0x1283c4):_0x476b60['prod']['push'](_0x1283c4);return _0x476b60;}function uc(_0x19e1ab){let _0x422008=document['getElementById'](_0x19e1ab),_0x226b0b=!0x1;return _0x422008||(_0x422008=document['createElement']('div'),_0x422008['setAttribute']('id',_0x19e1ab),_0x226b0b=!0x0),{'created':_0x226b0b,'element':_0x422008};}let Ps=!0x1;function Kr(_0x3bfbdc,_0x168e4f){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x3bfbdc]===_0x168e4f||It[_0x3bfbdc]||Ps)return;It[_0x3bfbdc]=_0x168e4f;function _0x18c42d(_0xafde87){return'__firebase__banner__'+_0xafde87;}const _0x4d905a='__firebase__banner',_0x3a0b2c=hc()['prod']['length']>0x0;function _0x158d57(){const _0x4a6fde=document['getElementById'](_0x4d905a);_0x4a6fde&&_0x4a6fde['remove']();}function _0xab8970(_0x48af39){_0x48af39['style']['display']='flex',_0x48af39['style']['background']='#7faaf0',_0x48af39['style']['position']='fixed',_0x48af39['style']['bottom']='5px',_0x48af39['style']['left']='5px',_0x48af39['style']['padding']='.5em',_0x48af39['style']['borderRadius']='5px',_0x48af39['style']['alignItems']='center';}function _0xba7fdc(_0x12aa56,_0x50df6){_0x12aa56['setAttribute']('width','24'),_0x12aa56['setAttribute']('id',_0x50df6),_0x12aa56['setAttribute']('height','24'),_0x12aa56['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x12aa56['setAttribute']('fill','none'),_0x12aa56['style']['marginLeft']='-6px';}function _0x1f2cf9(){const _0x127b7f=document['createElement']('span');return _0x127b7f['style']['cursor']='pointer',_0x127b7f['style']['marginLeft']='16px',_0x127b7f['style']['fontSize']='24px',_0x127b7f['innerHTML']='\x20&times;',_0x127b7f['onclick']=()=>{Ps=!0x0,_0x158d57();},_0x127b7f;}function _0x11bf22(_0x3213b7,_0x44aadf){_0x3213b7['setAttribute']('id',_0x44aadf),_0x3213b7['innerText']='Learn\x20more',_0x3213b7['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x3213b7['setAttribute']('target','__blank'),_0x3213b7['style']['paddingLeft']='5px',_0x3213b7['style']['textDecoration']='underline';}function _0x2d7288(){const _0x1ce1ed=uc(_0x4d905a),_0x18027f=_0x18c42d('text'),_0x3ca987=document['getElementById'](_0x18027f)||document['createElement']('span'),_0x452fcf=_0x18c42d('learnmore'),_0x1bd89a=document['getElementById'](_0x452fcf)||document['createElement']('a'),_0x3fcd6a=_0x18c42d('preprendIcon'),_0x2b6220=document['getElementById'](_0x3fcd6a)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x1ce1ed['created']){const _0x30dfb0=_0x1ce1ed['element'];_0xab8970(_0x30dfb0),_0x11bf22(_0x1bd89a,_0x452fcf);const _0x52b580=_0x1f2cf9();_0xba7fdc(_0x2b6220,_0x3fcd6a),_0x30dfb0['append'](_0x2b6220,_0x3ca987,_0x1bd89a,_0x52b580),document['body']['appendChild'](_0x30dfb0);}_0x3a0b2c?(_0x3ca987['innerText']='Preview\x20backend\x20disconnected.',_0x2b6220['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x2b6220['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x3ca987['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x3ca987['setAttribute']('id',_0x18027f);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x2d7288):_0x2d7288();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0xbe4d41=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0xbe4d41=='object'&&_0xbe4d41['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x356247=W();return _0x356247['indexOf']('MSIE\x20')>=0x0||_0x356247['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x566c27,_0x469673)=>{try{let _0x2ac241=!0x0;const _0x429ba7='validate-browser-context-for-indexeddb-analytics-module',_0x4f3aed=self['indexedDB']['open'](_0x429ba7);_0x4f3aed['onsuccess']=()=>{_0x4f3aed['result']['close'](),_0x2ac241||self['indexedDB']['deleteDatabase'](_0x429ba7),_0x566c27(!0x0);},_0x4f3aed['onupgradeneeded']=()=>{_0x2ac241=!0x1;},_0x4f3aed['onerror']=()=>{var _0x393bdb;_0x469673(((_0x393bdb=_0x4f3aed['error'])==null?void 0x0:_0x393bdb['message'])||'');};}catch(_0x4ebf6a){_0x469673(_0x4ebf6a);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x196ada,_0x3892a8,_0x2c7577){super(_0x3892a8),this['code']=_0x196ada,this['customData']=_0x2c7577,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x476b20,_0x6d84a,_0x3fbb46){this['service']=_0x476b20,this['serviceName']=_0x6d84a,this['errors']=_0x3fbb46;}['create'](_0x15f856,..._0x2242f1){const _0x1485f7=_0x2242f1[0x0]||{},_0x292890=this['service']+'/'+_0x15f856,_0x25d6ba=this['errors'][_0x15f856],_0x209212=_0x25d6ba?vc(_0x25d6ba,_0x1485f7):'Error',_0x5b05f9=this['serviceName']+':\x20'+_0x209212+'\x20('+_0x292890+').';return new Se(_0x292890,_0x5b05f9,_0x1485f7);}}function vc(_0x30b1a6,_0x507271){return _0x30b1a6['replace'](Ec,(_0x46324e,_0x265f90)=>{const _0x46cf02=_0x507271[_0x265f90];return _0x46cf02!=null?String(_0x46cf02):'<'+_0x265f90+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x38c3d6){return JSON['parse'](_0x38c3d6);}function O(_0x1e5f50){return JSON['stringify'](_0x1e5f50);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x36a234){let _0x446e26={},_0x333484={},_0x391a1d={},_0x5c4343='';try{const _0x2ec768=_0x36a234['split']('.');_0x446e26=At(ln(_0x2ec768[0x0])||''),_0x333484=At(ln(_0x2ec768[0x1])||''),_0x5c4343=_0x2ec768[0x2],_0x391a1d=_0x333484['d']||{},delete _0x333484['d'];}catch{}return{'header':_0x446e26,'claims':_0x333484,'data':_0x391a1d,'signature':_0x5c4343};},Ic=function(_0x1b0b85){const _0x4e3283=Qr(_0x1b0b85),_0xefddea=_0x4e3283['claims'];return!!_0xefddea&&typeof _0xefddea=='object'&&_0xefddea['hasOwnProperty']('iat');},wc=function(_0x143d8d){const _0x55b020=Qr(_0x143d8d)['claims'];return typeof _0x55b020=='object'&&_0x55b020['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x40c908,_0x166b4e){return Object['prototype']['hasOwnProperty']['call'](_0x40c908,_0x166b4e);}function De(_0x550ecc,_0x243d36){if(Object['prototype']['hasOwnProperty']['call'](_0x550ecc,_0x243d36))return _0x550ecc[_0x243d36];}function ui(_0x4a1faf){for(const _0x460f05 in _0x4a1faf)if(Object['prototype']['hasOwnProperty']['call'](_0x4a1faf,_0x460f05))return!0x1;return!0x0;}function hn(_0x1fdea0,_0x532324,_0x4ec065){const _0x124d12={};for(const _0x5b1b6f in _0x1fdea0)Object['prototype']['hasOwnProperty']['call'](_0x1fdea0,_0x5b1b6f)&&(_0x124d12[_0x5b1b6f]=_0x532324['call'](_0x4ec065,_0x1fdea0[_0x5b1b6f],_0x5b1b6f,_0x1fdea0));return _0x124d12;}function Me(_0x3fae19,_0x4a4ac9){if(_0x3fae19===_0x4a4ac9)return!0x0;const _0xd9413d=Object['keys'](_0x3fae19),_0x47d0d0=Object['keys'](_0x4a4ac9);for(const _0x1fd330 of _0xd9413d){if(!_0x47d0d0['includes'](_0x1fd330))return!0x1;const _0x5a3bb1=_0x3fae19[_0x1fd330],_0x509f7e=_0x4a4ac9[_0x1fd330];if(Os(_0x5a3bb1)&&Os(_0x509f7e)){if(!Me(_0x5a3bb1,_0x509f7e))return!0x1;}else{if(_0x5a3bb1!==_0x509f7e)return!0x1;}}for(const _0xe09703 of _0x47d0d0)if(!_0xd9413d['includes'](_0xe09703))return!0x1;return!0x0;}function Os(_0x4ddfaf){return _0x4ddfaf!==null&&typeof _0x4ddfaf=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x35f415){const _0x5c248a=[];for(const [_0x584f46,_0x51dfe0]of Object['entries'](_0x35f415))Array['isArray'](_0x51dfe0)?_0x51dfe0['forEach'](_0x1b3d0b=>{_0x5c248a['push'](encodeURIComponent(_0x584f46)+'='+encodeURIComponent(_0x1b3d0b));}):_0x5c248a['push'](encodeURIComponent(_0x584f46)+'='+encodeURIComponent(_0x51dfe0));return _0x5c248a['length']?'&'+_0x5c248a['join']('&'):'';}function vt(_0x374771){const _0x6589ab={};return _0x374771['replace'](/^\?/,'')['split']('&')['forEach'](_0x34f18f=>{if(_0x34f18f){const [_0x3bfb22,_0x3e8638]=_0x34f18f['split']('=');_0x6589ab[decodeURIComponent(_0x3bfb22)]=decodeURIComponent(_0x3e8638);}}),_0x6589ab;}function Et(_0x3624f1){const _0xc20933=_0x3624f1['indexOf']('?');if(!_0xc20933)return'';const _0x1dcb79=_0x3624f1['indexOf']('#',_0xc20933);return _0x3624f1['substring'](_0xc20933,_0x1dcb79>0x0?_0x1dcb79:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x2ff171=0x1;_0x2ff171<this['blockSize'];++_0x2ff171)this['pad_'][_0x2ff171]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x42ada9,_0x5d059a){_0x5d059a||(_0x5d059a=0x0);const _0x11cd90=this['W_'];if(typeof _0x42ada9=='string'){for(let _0x16d590=0x0;_0x16d590<0x10;_0x16d590++)_0x11cd90[_0x16d590]=_0x42ada9['charCodeAt'](_0x5d059a)<<0x18|_0x42ada9['charCodeAt'](_0x5d059a+0x1)<<0x10|_0x42ada9['charCodeAt'](_0x5d059a+0x2)<<0x8|_0x42ada9['charCodeAt'](_0x5d059a+0x3),_0x5d059a+=0x4;}else{for(let _0x49a644=0x0;_0x49a644<0x10;_0x49a644++)_0x11cd90[_0x49a644]=_0x42ada9[_0x5d059a]<<0x18|_0x42ada9[_0x5d059a+0x1]<<0x10|_0x42ada9[_0x5d059a+0x2]<<0x8|_0x42ada9[_0x5d059a+0x3],_0x5d059a+=0x4;}for(let _0x44f980=0x10;_0x44f980<0x50;_0x44f980++){const _0x542407=_0x11cd90[_0x44f980-0x3]^_0x11cd90[_0x44f980-0x8]^_0x11cd90[_0x44f980-0xe]^_0x11cd90[_0x44f980-0x10];_0x11cd90[_0x44f980]=(_0x542407<<0x1|_0x542407>>>0x1f)&0xffffffff;}let _0xf52881=this['chain_'][0x0],_0x5a1d96=this['chain_'][0x1],_0x57526c=this['chain_'][0x2],_0x437495=this['chain_'][0x3],_0x1baace=this['chain_'][0x4],_0x2ae53e,_0x55fa99;for(let _0x477b69=0x0;_0x477b69<0x50;_0x477b69++){_0x477b69<0x28?_0x477b69<0x14?(_0x2ae53e=_0x437495^_0x5a1d96&(_0x57526c^_0x437495),_0x55fa99=0x5a827999):(_0x2ae53e=_0x5a1d96^_0x57526c^_0x437495,_0x55fa99=0x6ed9eba1):_0x477b69<0x3c?(_0x2ae53e=_0x5a1d96&_0x57526c|_0x437495&(_0x5a1d96|_0x57526c),_0x55fa99=0x8f1bbcdc):(_0x2ae53e=_0x5a1d96^_0x57526c^_0x437495,_0x55fa99=0xca62c1d6);const _0xca60a3=(_0xf52881<<0x5|_0xf52881>>>0x1b)+_0x2ae53e+_0x1baace+_0x55fa99+_0x11cd90[_0x477b69]&0xffffffff;_0x1baace=_0x437495,_0x437495=_0x57526c,_0x57526c=(_0x5a1d96<<0x1e|_0x5a1d96>>>0x2)&0xffffffff,_0x5a1d96=_0xf52881,_0xf52881=_0xca60a3;}this['chain_'][0x0]=this['chain_'][0x0]+_0xf52881&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5a1d96&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x57526c&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x437495&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x1baace&0xffffffff;}['update'](_0x29b055,_0x50ba8d){if(_0x29b055==null)return;_0x50ba8d===void 0x0&&(_0x50ba8d=_0x29b055['length']);const _0x522bb3=_0x50ba8d-this['blockSize'];let _0x5efbc9=0x0;const _0x12aec6=this['buf_'];let _0x3f9a7c=this['inbuf_'];for(;_0x5efbc9<_0x50ba8d;){if(_0x3f9a7c===0x0){for(;_0x5efbc9<=_0x522bb3;)this['compress_'](_0x29b055,_0x5efbc9),_0x5efbc9+=this['blockSize'];}if(typeof _0x29b055=='string'){for(;_0x5efbc9<_0x50ba8d;)if(_0x12aec6[_0x3f9a7c]=_0x29b055['charCodeAt'](_0x5efbc9),++_0x3f9a7c,++_0x5efbc9,_0x3f9a7c===this['blockSize']){this['compress_'](_0x12aec6),_0x3f9a7c=0x0;break;}}else{for(;_0x5efbc9<_0x50ba8d;)if(_0x12aec6[_0x3f9a7c]=_0x29b055[_0x5efbc9],++_0x3f9a7c,++_0x5efbc9,_0x3f9a7c===this['blockSize']){this['compress_'](_0x12aec6),_0x3f9a7c=0x0;break;}}}this['inbuf_']=_0x3f9a7c,this['total_']+=_0x50ba8d;}['digest'](){const _0x33e7ac=[];let _0x352836=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x29b88d=this['blockSize']-0x1;_0x29b88d>=0x38;_0x29b88d--)this['buf_'][_0x29b88d]=_0x352836&0xff,_0x352836/=0x100;this['compress_'](this['buf_']);let _0xd71272=0x0;for(let _0x235fd4=0x0;_0x235fd4<0x5;_0x235fd4++)for(let _0x155672=0x18;_0x155672>=0x0;_0x155672-=0x8)_0x33e7ac[_0xd71272]=this['chain_'][_0x235fd4]>>_0x155672&0xff,++_0xd71272;return _0x33e7ac;}}function Tc(_0x629235,_0x52bb54){const _0x486f1c=new Sc(_0x629235,_0x52bb54);return _0x486f1c['subscribe']['bind'](_0x486f1c);}class Sc{constructor(_0xd7c005,_0x57da99){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x57da99,this['task']['then'](()=>{_0xd7c005(this);})['catch'](_0x4215e8=>{this['error'](_0x4215e8);});}['next'](_0x3c1c93){this['forEachObserver'](_0x46f55b=>{_0x46f55b['next'](_0x3c1c93);});}['error'](_0x5a8cd2){this['forEachObserver'](_0x57e7f1=>{_0x57e7f1['error'](_0x5a8cd2);}),this['close'](_0x5a8cd2);}['complete'](){this['forEachObserver'](_0x18ba24=>{_0x18ba24['complete']();}),this['close']();}['subscribe'](_0x52addb,_0x4b77e3,_0x2e1c75){let _0xe9886d;if(_0x52addb===void 0x0&&_0x4b77e3===void 0x0&&_0x2e1c75===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x52addb,['next','error','complete'])?_0xe9886d=_0x52addb:_0xe9886d={'next':_0x52addb,'error':_0x4b77e3,'complete':_0x2e1c75},_0xe9886d['next']===void 0x0&&(_0xe9886d['next']=Jn),_0xe9886d['error']===void 0x0&&(_0xe9886d['error']=Jn),_0xe9886d['complete']===void 0x0&&(_0xe9886d['complete']=Jn);const _0x45a909=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0xe9886d['error'](this['finalError']):_0xe9886d['complete']();}catch{}}),this['observers']['push'](_0xe9886d),_0x45a909;}['unsubscribeOne'](_0x3653a3){this['observers']===void 0x0||this['observers'][_0x3653a3]===void 0x0||(delete this['observers'][_0x3653a3],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x4eaad0){if(!this['finalized']){for(let _0x168442=0x0;_0x168442<this['observers']['length'];_0x168442++)this['sendOne'](_0x168442,_0x4eaad0);}}['sendOne'](_0x510064,_0x18efbb){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x510064]!==void 0x0)try{_0x18efbb(this['observers'][_0x510064]);}catch(_0x2f36c1){typeof console<'u'&&console['error']&&console['error'](_0x2f36c1);}});}['close'](_0x4df3ff){this['finalized']||(this['finalized']=!0x0,_0x4df3ff!==void 0x0&&(this['finalError']=_0x4df3ff),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x5d3436,_0x4d0eea){if(typeof _0x5d3436!='object'||_0x5d3436===null)return!0x1;for(const _0x19184f of _0x4d0eea)if(_0x19184f in _0x5d3436&&typeof _0x5d3436[_0x19184f]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0xf1a271,_0x5ad444){return _0xf1a271+'\x20failed:\x20'+_0x5ad444+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x20c7bf){const _0x3b1438=[];let _0x3429ba=0x0;for(let _0x37f03f=0x0;_0x37f03f<_0x20c7bf['length'];_0x37f03f++){let _0x4069bb=_0x20c7bf['charCodeAt'](_0x37f03f);if(_0x4069bb>=0xd800&&_0x4069bb<=0xdbff){const _0x441735=_0x4069bb-0xd800;_0x37f03f++,f(_0x37f03f<_0x20c7bf['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x189f20=_0x20c7bf['charCodeAt'](_0x37f03f)-0xdc00;_0x4069bb=0x10000+(_0x441735<<0xa)+_0x189f20;}_0x4069bb<0x80?_0x3b1438[_0x3429ba++]=_0x4069bb:_0x4069bb<0x800?(_0x3b1438[_0x3429ba++]=_0x4069bb>>0x6|0xc0,_0x3b1438[_0x3429ba++]=_0x4069bb&0x3f|0x80):_0x4069bb<0x10000?(_0x3b1438[_0x3429ba++]=_0x4069bb>>0xc|0xe0,_0x3b1438[_0x3429ba++]=_0x4069bb>>0x6&0x3f|0x80,_0x3b1438[_0x3429ba++]=_0x4069bb&0x3f|0x80):(_0x3b1438[_0x3429ba++]=_0x4069bb>>0x12|0xf0,_0x3b1438[_0x3429ba++]=_0x4069bb>>0xc&0x3f|0x80,_0x3b1438[_0x3429ba++]=_0x4069bb>>0x6&0x3f|0x80,_0x3b1438[_0x3429ba++]=_0x4069bb&0x3f|0x80);}return _0x3b1438;},On=function(_0x58dcf2){let _0x3d5173=0x0;for(let _0x43adb3=0x0;_0x43adb3<_0x58dcf2['length'];_0x43adb3++){const _0x366308=_0x58dcf2['charCodeAt'](_0x43adb3);_0x366308<0x80?_0x3d5173++:_0x366308<0x800?_0x3d5173+=0x2:_0x366308>=0xd800&&_0x366308<=0xdbff?(_0x3d5173+=0x4,_0x43adb3++):_0x3d5173+=0x3;}return _0x3d5173;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x2ff93c){return _0x2ff93c&&_0x2ff93c['_delegate']?_0x2ff93c['_delegate']:_0x2ff93c;}class Le{constructor(_0x28c0c5,_0x1294ce,_0x58eeba){this['name']=_0x28c0c5,this['instanceFactory']=_0x1294ce,this['type']=_0x58eeba,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x4dc45c){return this['instantiationMode']=_0x4dc45c,this;}['setMultipleInstances'](_0x1bf8f){return this['multipleInstances']=_0x1bf8f,this;}['setServiceProps'](_0xb965ab){return this['serviceProps']=_0xb965ab,this;}['setInstanceCreatedCallback'](_0x3c9357){return this['onInstanceCreated']=_0x3c9357,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x545925,_0x9f5294){this['name']=_0x545925,this['container']=_0x9f5294,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x1f4dc9){const _0x398bf1=this['normalizeInstanceIdentifier'](_0x1f4dc9);if(!this['instancesDeferred']['has'](_0x398bf1)){const _0xe36583=new ot();if(this['instancesDeferred']['set'](_0x398bf1,_0xe36583),this['isInitialized'](_0x398bf1)||this['shouldAutoInitialize']())try{const _0x4493a1=this['getOrInitializeService']({'instanceIdentifier':_0x398bf1});_0x4493a1&&_0xe36583['resolve'](_0x4493a1);}catch{}}return this['instancesDeferred']['get'](_0x398bf1)['promise'];}['getImmediate'](_0x200299){const _0xe1baac=this['normalizeInstanceIdentifier'](_0x200299==null?void 0x0:_0x200299['identifier']),_0x1f2a8c=(_0x200299==null?void 0x0:_0x200299['optional'])??!0x1;if(this['isInitialized'](_0xe1baac)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0xe1baac});}catch(_0x242647){if(_0x1f2a8c)return null;throw _0x242647;}else{if(_0x1f2a8c)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x422b52){if(_0x422b52['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x422b52['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x422b52,!!this['shouldAutoInitialize']()){if(Nc(_0x422b52))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x3b2540,_0x34774f]of this['instancesDeferred']['entries']()){const _0x15c5e3=this['normalizeInstanceIdentifier'](_0x3b2540);try{const _0x4d8aff=this['getOrInitializeService']({'instanceIdentifier':_0x15c5e3});_0x34774f['resolve'](_0x4d8aff);}catch{}}}}['clearInstance'](_0x2b964e=Ne){this['instancesDeferred']['delete'](_0x2b964e),this['instancesOptions']['delete'](_0x2b964e),this['instances']['delete'](_0x2b964e);}async['delete'](){const _0x1e3dbb=Array['from'](this['instances']['values']());await Promise['all']([..._0x1e3dbb['filter'](_0x22f9d7=>'INTERNAL'in _0x22f9d7)['map'](_0x1871b4=>_0x1871b4['INTERNAL']['delete']()),..._0x1e3dbb['filter'](_0x59b6e7=>'_delete'in _0x59b6e7)['map'](_0x4e337b=>_0x4e337b['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x4a80a1=Ne){return this['instances']['has'](_0x4a80a1);}['getOptions'](_0x4673db=Ne){return this['instancesOptions']['get'](_0x4673db)||{};}['initialize'](_0x339a62={}){const {options:_0xa38326={}}=_0x339a62,_0x495497=this['normalizeInstanceIdentifier'](_0x339a62['instanceIdentifier']);if(this['isInitialized'](_0x495497))throw Error(this['name']+'('+_0x495497+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x53ca69=this['getOrInitializeService']({'instanceIdentifier':_0x495497,'options':_0xa38326});for(const [_0x4b9e94,_0x188989]of this['instancesDeferred']['entries']()){const _0x3ba677=this['normalizeInstanceIdentifier'](_0x4b9e94);_0x495497===_0x3ba677&&_0x188989['resolve'](_0x53ca69);}return _0x53ca69;}['onInit'](_0x3e856c,_0x4c537e){const _0x51e913=this['normalizeInstanceIdentifier'](_0x4c537e),_0x1e35c8=this['onInitCallbacks']['get'](_0x51e913)??new Set();_0x1e35c8['add'](_0x3e856c),this['onInitCallbacks']['set'](_0x51e913,_0x1e35c8);const _0x47bfd3=this['instances']['get'](_0x51e913);return _0x47bfd3&&_0x3e856c(_0x47bfd3,_0x51e913),()=>{_0x1e35c8['delete'](_0x3e856c);};}['invokeOnInitCallbacks'](_0x17407d,_0x21adcb){const _0x38b330=this['onInitCallbacks']['get'](_0x21adcb);if(_0x38b330){for(const _0x1f1be3 of _0x38b330)try{_0x1f1be3(_0x17407d,_0x21adcb);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x22110a,options:_0x3b1111={}}){let _0x3cc822=this['instances']['get'](_0x22110a);if(!_0x3cc822&&this['component']&&(_0x3cc822=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x22110a),'options':_0x3b1111}),this['instances']['set'](_0x22110a,_0x3cc822),this['instancesOptions']['set'](_0x22110a,_0x3b1111),this['invokeOnInitCallbacks'](_0x3cc822,_0x22110a),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x22110a,_0x3cc822);}catch{}return _0x3cc822||null;}['normalizeInstanceIdentifier'](_0x2cf225=Ne){return this['component']?this['component']['multipleInstances']?_0x2cf225:Ne:_0x2cf225;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x39d112){return _0x39d112===Ne?void 0x0:_0x39d112;}function Nc(_0x2517f8){return _0x2517f8['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x12e31e){this['name']=_0x12e31e,this['providers']=new Map();}['addComponent'](_0x7158c6){const _0x2e446e=this['getProvider'](_0x7158c6['name']);if(_0x2e446e['isComponentSet']())throw new Error('Component\x20'+_0x7158c6['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x2e446e['setComponent'](_0x7158c6);}['addOrOverwriteComponent'](_0x15688c){this['getProvider'](_0x15688c['name'])['isComponentSet']()&&this['providers']['delete'](_0x15688c['name']),this['addComponent'](_0x15688c);}['getProvider'](_0xca031d){if(this['providers']['has'](_0xca031d))return this['providers']['get'](_0xca031d);const _0x2c3691=new Ac(_0xca031d,this);return this['providers']['set'](_0xca031d,_0x2c3691),_0x2c3691;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x1797d4){_0x1797d4[_0x1797d4['DEBUG']=0x0]='DEBUG',_0x1797d4[_0x1797d4['VERBOSE']=0x1]='VERBOSE',_0x1797d4[_0x1797d4['INFO']=0x2]='INFO',_0x1797d4[_0x1797d4['WARN']=0x3]='WARN',_0x1797d4[_0x1797d4['ERROR']=0x4]='ERROR',_0x1797d4[_0x1797d4['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x4f67cf,_0x8426c3,..._0x5773e8)=>{if(_0x8426c3<_0x4f67cf['logLevel'])return;const _0x522b29=new Date()['toISOString'](),_0x2a6be7=Mc[_0x8426c3];if(_0x2a6be7)console[_0x2a6be7]('['+_0x522b29+']\x20\x20'+_0x4f67cf['name']+':',..._0x5773e8);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x8426c3+')');};class Ui{constructor(_0x5b44bd){this['name']=_0x5b44bd,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x482103){if(!(_0x482103 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x482103+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x482103;}['setLogLevel'](_0x12a111){this['_logLevel']=typeof _0x12a111=='string'?Oc[_0x12a111]:_0x12a111;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x239789){if(typeof _0x239789!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x239789;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x580e72){this['_userLogHandler']=_0x580e72;}['debug'](..._0x2da2fd){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x2da2fd),this['_logHandler'](this,T['DEBUG'],..._0x2da2fd);}['log'](..._0x435b35){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x435b35),this['_logHandler'](this,T['VERBOSE'],..._0x435b35);}['info'](..._0x5d27b1){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x5d27b1),this['_logHandler'](this,T['INFO'],..._0x5d27b1);}['warn'](..._0x262613){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x262613),this['_logHandler'](this,T['WARN'],..._0x262613);}['error'](..._0x43d93a){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x43d93a),this['_logHandler'](this,T['ERROR'],..._0x43d93a);}}const xc=(_0x2900a,_0x449630)=>_0x449630['some'](_0x2fdfe4=>_0x2900a instanceof _0x2fdfe4);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x2132db){const _0x3c7b8f=new Promise((_0x26eaf8,_0x157f95)=>{const _0x283cd0=()=>{_0x2132db['removeEventListener']('success',_0x2ed04c),_0x2132db['removeEventListener']('error',_0x4b717b);},_0x2ed04c=()=>{_0x26eaf8(_e(_0x2132db['result'])),_0x283cd0();},_0x4b717b=()=>{_0x157f95(_0x2132db['error']),_0x283cd0();};_0x2132db['addEventListener']('success',_0x2ed04c),_0x2132db['addEventListener']('error',_0x4b717b);});return _0x3c7b8f['then'](_0x55c36d=>{_0x55c36d instanceof IDBCursor&&Jr['set'](_0x55c36d,_0x2132db);})['catch'](()=>{}),Wi['set'](_0x3c7b8f,_0x2132db),_0x3c7b8f;}function Bc(_0x2f603e){if(di['has'](_0x2f603e))return;const _0xc8535d=new Promise((_0x483a25,_0x4178e8)=>{const _0x389e55=()=>{_0x2f603e['removeEventListener']('complete',_0x2c36f5),_0x2f603e['removeEventListener']('error',_0x40a058),_0x2f603e['removeEventListener']('abort',_0x40a058);},_0x2c36f5=()=>{_0x483a25(),_0x389e55();},_0x40a058=()=>{_0x4178e8(_0x2f603e['error']||new DOMException('AbortError','AbortError')),_0x389e55();};_0x2f603e['addEventListener']('complete',_0x2c36f5),_0x2f603e['addEventListener']('error',_0x40a058),_0x2f603e['addEventListener']('abort',_0x40a058);});di['set'](_0x2f603e,_0xc8535d);}let fi={'get'(_0x205db4,_0x31dd53,_0x38b264){if(_0x205db4 instanceof IDBTransaction){if(_0x31dd53==='done')return di['get'](_0x205db4);if(_0x31dd53==='objectStoreNames')return _0x205db4['objectStoreNames']||Xr['get'](_0x205db4);if(_0x31dd53==='store')return _0x38b264['objectStoreNames'][0x1]?void 0x0:_0x38b264['objectStore'](_0x38b264['objectStoreNames'][0x0]);}return _e(_0x205db4[_0x31dd53]);},'set'(_0x1a7d36,_0x30332d,_0x69de90){return _0x1a7d36[_0x30332d]=_0x69de90,!0x0;},'has'(_0x32077d,_0x97cf25){return _0x32077d instanceof IDBTransaction&&(_0x97cf25==='done'||_0x97cf25==='store')?!0x0:_0x97cf25 in _0x32077d;}};function Vc(_0x21011a){fi=_0x21011a(fi);}function Hc(_0x132fdd){return _0x132fdd===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x16c3a6,..._0x9feff1){const _0x2fa665=_0x132fdd['call'](Zn(this),_0x16c3a6,..._0x9feff1);return Xr['set'](_0x2fa665,_0x16c3a6['sort']?_0x16c3a6['sort']():[_0x16c3a6]),_e(_0x2fa665);}:Uc()['includes'](_0x132fdd)?function(..._0x62f35f){return _0x132fdd['apply'](Zn(this),_0x62f35f),_e(Jr['get'](this));}:function(..._0xc9cc2b){return _e(_0x132fdd['apply'](Zn(this),_0xc9cc2b));};}function $c(_0x5c33f4){return typeof _0x5c33f4=='function'?Hc(_0x5c33f4):(_0x5c33f4 instanceof IDBTransaction&&Bc(_0x5c33f4),xc(_0x5c33f4,Fc())?new Proxy(_0x5c33f4,fi):_0x5c33f4);}function _e(_0x17cce2){if(_0x17cce2 instanceof IDBRequest)return Wc(_0x17cce2);if(Xn['has'](_0x17cce2))return Xn['get'](_0x17cce2);const _0x21adb7=$c(_0x17cce2);return _0x21adb7!==_0x17cce2&&(Xn['set'](_0x17cce2,_0x21adb7),Wi['set'](_0x21adb7,_0x17cce2)),_0x21adb7;}const Zn=_0x2f2090=>Wi['get'](_0x2f2090);function Gc(_0x3b4a7e,_0x19c111,{blocked:_0x12e4d5,upgrade:_0x336367,blocking:_0xc85891,terminated:_0x430704}={}){const _0x286331=indexedDB['open'](_0x3b4a7e,_0x19c111),_0x330dc1=_e(_0x286331);return _0x336367&&_0x286331['addEventListener']('upgradeneeded',_0x51cdc8=>{_0x336367(_e(_0x286331['result']),_0x51cdc8['oldVersion'],_0x51cdc8['newVersion'],_e(_0x286331['transaction']),_0x51cdc8);}),_0x12e4d5&&_0x286331['addEventListener']('blocked',_0x25db0a=>_0x12e4d5(_0x25db0a['oldVersion'],_0x25db0a['newVersion'],_0x25db0a)),_0x330dc1['then'](_0x591412=>{_0x430704&&_0x591412['addEventListener']('close',()=>_0x430704()),_0xc85891&&_0x591412['addEventListener']('versionchange',_0xff6def=>_0xc85891(_0xff6def['oldVersion'],_0xff6def['newVersion'],_0xff6def));})['catch'](()=>{}),_0x330dc1;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x2e4125,_0x4fbdb2){if(!(_0x2e4125 instanceof IDBDatabase&&!(_0x4fbdb2 in _0x2e4125)&&typeof _0x4fbdb2=='string'))return;if(ei['get'](_0x4fbdb2))return ei['get'](_0x4fbdb2);const _0x7846dc=_0x4fbdb2['replace'](/FromIndex$/,''),_0x3b494e=_0x4fbdb2!==_0x7846dc,_0x4f9242=zc['includes'](_0x7846dc);if(!(_0x7846dc in(_0x3b494e?IDBIndex:IDBObjectStore)['prototype'])||!(_0x4f9242||qc['includes'](_0x7846dc)))return;const _0x1aa320=async function(_0x1c491d,..._0x999c0d){const _0x558e2d=this['transaction'](_0x1c491d,_0x4f9242?'readwrite':'readonly');let _0x5d68b5=_0x558e2d['store'];return _0x3b494e&&(_0x5d68b5=_0x5d68b5['index'](_0x999c0d['shift']())),(await Promise['all']([_0x5d68b5[_0x7846dc](..._0x999c0d),_0x4f9242&&_0x558e2d['done']]))[0x0];};return ei['set'](_0x4fbdb2,_0x1aa320),_0x1aa320;}Vc(_0x255c46=>({..._0x255c46,'get':(_0x2ce50d,_0x2892dd,_0x2c61ea)=>Ls(_0x2ce50d,_0x2892dd)||_0x255c46['get'](_0x2ce50d,_0x2892dd,_0x2c61ea),'has':(_0x5e8bca,_0x3041de)=>!!Ls(_0x5e8bca,_0x3041de)||_0x255c46['has'](_0x5e8bca,_0x3041de)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x58ba09){this['container']=_0x58ba09;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x38439f=>{if(Kc(_0x38439f)){const _0x189266=_0x38439f['getImmediate']();return _0x189266['library']+'/'+_0x189266['version'];}else return null;})['filter'](_0x362346=>_0x362346)['join']('\x20');}}function Kc(_0x5dac56){const _0x11b390=_0x5dac56['getComponent']();return(_0x11b390==null?void 0x0:_0x11b390['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0xdf40fb,_0x344a7d){try{_0xdf40fb['container']['addComponent'](_0x344a7d);}catch(_0x99d9de){oe['debug']('Component\x20'+_0x344a7d['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0xdf40fb['name'],_0x99d9de);}}function Ze(_0x47286c){const _0x18bf5e=_0x47286c['name'];if(mi['has'](_0x18bf5e))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x18bf5e+'.'),!0x1;mi['set'](_0x18bf5e,_0x47286c);for(const _0x38819d of xe['values']())Fs(_0x38819d,_0x47286c);for(const _0x39c1ab of gi['values']())Fs(_0x39c1ab,_0x47286c);return!0x0;}function Bi(_0x59b63a,_0x1f6ef7){const _0x52b4d1=_0x59b63a['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x52b4d1&&_0x52b4d1['triggerHeartbeat'](),_0x59b63a['container']['getProvider'](_0x1f6ef7);}function $(_0x371640){return _0x371640==null?!0x1:_0x371640['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x30de69,_0x18a78c,_0x1845fd){this['_isDeleted']=!0x1,this['_options']={..._0x30de69},this['_config']={..._0x18a78c},this['_name']=_0x18a78c['name'],this['_automaticDataCollectionEnabled']=_0x18a78c['automaticDataCollectionEnabled'],this['_container']=_0x1845fd,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x4e33a0){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x4e33a0;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x25661c){this['_isDeleted']=_0x25661c;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x18dc5d,_0x360cd5={}){let _0x325a2a=_0x18dc5d;typeof _0x360cd5!='object'&&(_0x360cd5={'name':_0x360cd5});const _0x4ce93a={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x360cd5},_0x28ab6c=_0x4ce93a['name'];if(typeof _0x28ab6c!='string'||!_0x28ab6c)throw ge['create']('bad-app-name',{'appName':String(_0x28ab6c)});if(_0x325a2a||(_0x325a2a=qr()),!_0x325a2a)throw ge['create']('no-options');const _0x285781=xe['get'](_0x28ab6c);if(_0x285781){if(Me(_0x325a2a,_0x285781['options'])&&Me(_0x4ce93a,_0x285781['config']))return _0x285781;throw ge['create']('duplicate-app',{'appName':_0x28ab6c});}const _0x438835=new Pc(_0x28ab6c);for(const _0x119fcd of mi['values']())_0x438835['addComponent'](_0x119fcd);const _0x4717e7=new Tl(_0x325a2a,_0x4ce93a,_0x438835);return xe['set'](_0x28ab6c,_0x4717e7),_0x4717e7;}function Zr(_0x2513bf=_i){const _0xc6fc21=xe['get'](_0x2513bf);if(!_0xc6fc21&&_0x2513bf===_i&&qr())return Sl();if(!_0xc6fc21)throw ge['create']('no-app',{'appName':_0x2513bf});return _0xc6fc21;}function f_(){return Array['from'](xe['values']());}async function p_(_0x4fc0fc){let _0x4c8d45=!0x1;const _0x5994a1=_0x4fc0fc['name'];xe['has'](_0x5994a1)?(_0x4c8d45=!0x0,xe['delete'](_0x5994a1)):gi['has'](_0x5994a1)&&_0x4fc0fc['decRefCount']()<=0x0&&(gi['delete'](_0x5994a1),_0x4c8d45=!0x0),_0x4c8d45&&(await Promise['all'](_0x4fc0fc['container']['getProviders']()['map'](_0x259491=>_0x259491['delete']())),_0x4fc0fc['isDeleted']=!0x0);}function me(_0x381819,_0x2752ce,_0x2d475f){let _0x491b4f=wl[_0x381819]??_0x381819;_0x2d475f&&(_0x491b4f+='-'+_0x2d475f);const _0x3baaf4=_0x491b4f['match'](/\s|\//),_0x2339d1=_0x2752ce['match'](/\s|\//);if(_0x3baaf4||_0x2339d1){const _0x561688=['Unable\x20to\x20register\x20library\x20\x22'+_0x491b4f+'\x22\x20with\x20version\x20\x22'+_0x2752ce+'\x22:'];_0x3baaf4&&_0x561688['push']('library\x20name\x20\x22'+_0x491b4f+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x3baaf4&&_0x2339d1&&_0x561688['push']('and'),_0x2339d1&&_0x561688['push']('version\x20name\x20\x22'+_0x2752ce+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x561688['join']('\x20'));return;}Ze(new Le(_0x491b4f+'-version',()=>({'library':_0x491b4f,'version':_0x2752ce}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x24309d,_0x3657d3)=>{switch(_0x3657d3){case 0x0:try{_0x24309d['createObjectStore'](kt);}catch(_0x3afbde){console['warn'](_0x3afbde);}}}})['catch'](_0xea8b51=>{throw ge['create']('idb-open',{'originalErrorMessage':_0xea8b51['message']});})),ti;}async function Al(_0x2ed291){try{const _0x51c640=(await eo())['transaction'](kt),_0x9acd62=await _0x51c640['objectStore'](kt)['get'](to(_0x2ed291));return await _0x51c640['done'],_0x9acd62;}catch(_0x2b67e7){if(_0x2b67e7 instanceof Se)oe['warn'](_0x2b67e7['message']);else{const _0x211f80=ge['create']('idb-get',{'originalErrorMessage':_0x2b67e7==null?void 0x0:_0x2b67e7['message']});oe['warn'](_0x211f80['message']);}}}async function Us(_0x7baff5,_0x711b6b){try{const _0x49e74d=(await eo())['transaction'](kt,'readwrite');await _0x49e74d['objectStore'](kt)['put'](_0x711b6b,to(_0x7baff5)),await _0x49e74d['done'];}catch(_0x2fe88e){if(_0x2fe88e instanceof Se)oe['warn'](_0x2fe88e['message']);else{const _0x34a847=ge['create']('idb-set',{'originalErrorMessage':_0x2fe88e==null?void 0x0:_0x2fe88e['message']});oe['warn'](_0x34a847['message']);}}}function to(_0x5ae0db){return _0x5ae0db['name']+'!'+_0x5ae0db['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x590f1c){this['container']=_0x590f1c,this['_heartbeatsCache']=null;const _0x24aa78=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x24aa78),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x3a4f16=>(this['_heartbeatsCache']=_0x3a4f16,_0x3a4f16));}async['triggerHeartbeat'](){var _0x3ece26,_0xaaf731;try{const _0x5288c5=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0xb5129=Ws();if(((_0x3ece26=this['_heartbeatsCache'])==null?void 0x0:_0x3ece26['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0xaaf731=this['_heartbeatsCache'])==null?void 0x0:_0xaaf731['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0xb5129||this['_heartbeatsCache']['heartbeats']['some'](_0x45f17e=>_0x45f17e['date']===_0xb5129))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0xb5129,'agent':_0x5288c5}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0xde7dbd=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0xde7dbd,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x35ceb4){oe['warn'](_0x35ceb4);}}async['getHeartbeatsHeader'](){var _0x493de0;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x493de0=this['_heartbeatsCache'])==null?void 0x0:_0x493de0['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x1b95f4=Ws(),{heartbeatsToSend:_0x205eef,unsentEntries:_0x388051}=Ol(this['_heartbeatsCache']['heartbeats']),_0xb75eba=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x205eef}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x1b95f4,_0x388051['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x388051,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0xb75eba;}catch(_0x35b1a1){return oe['warn'](_0x35b1a1),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x169950,_0x1aecbd=kl){const _0x19779c=[];let _0x4ed44d=_0x169950['slice']();for(const _0x148663 of _0x169950){const _0x565c0f=_0x19779c['find'](_0x3b4b38=>_0x3b4b38['agent']===_0x148663['agent']);if(_0x565c0f){if(_0x565c0f['dates']['push'](_0x148663['date']),Bs(_0x19779c)>_0x1aecbd){_0x565c0f['dates']['pop']();break;}}else{if(_0x19779c['push']({'agent':_0x148663['agent'],'dates':[_0x148663['date']]}),Bs(_0x19779c)>_0x1aecbd){_0x19779c['pop']();break;}}_0x4ed44d=_0x4ed44d['slice'](0x1);}return{'heartbeatsToSend':_0x19779c,'unsentEntries':_0x4ed44d};}class Dl{constructor(_0x548591){this['app']=_0x548591,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x30d84f=await Al(this['app']);return _0x30d84f!=null&&_0x30d84f['heartbeats']?_0x30d84f:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x79a6f){if(await this['_canUseIndexedDBPromise']){const _0x4a1256=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x79a6f['lastSentHeartbeatDate']??_0x4a1256['lastSentHeartbeatDate'],'heartbeats':_0x79a6f['heartbeats']});}else return;}async['add'](_0x3fd881){if(await this['_canUseIndexedDBPromise']){const _0x5bf510=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x3fd881['lastSentHeartbeatDate']??_0x5bf510['lastSentHeartbeatDate'],'heartbeats':[..._0x5bf510['heartbeats'],..._0x3fd881['heartbeats']]});}else return;}}function Bs(_0x28bc51){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x28bc51}))['length'];}function Ml(_0x34fa20){if(_0x34fa20['length']===0x0)return-0x1;let _0x1074ef=0x0,_0x1ac1f2=_0x34fa20[0x0]['date'];for(let _0x4b70b4=0x1;_0x4b70b4<_0x34fa20['length'];_0x4b70b4++)_0x34fa20[_0x4b70b4]['date']<_0x1ac1f2&&(_0x1ac1f2=_0x34fa20[_0x4b70b4]['date'],_0x1074ef=_0x4b70b4);return _0x1074ef;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x45bb76){Ze(new Le('platform-logger',_0x4877ff=>new jc(_0x4877ff),'PRIVATE')),Ze(new Le('heartbeat',_0x412ba2=>new Pl(_0x412ba2),'PRIVATE')),me(pi,xs,_0x45bb76),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x5a1b57){no=_0x5a1b57;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x229e52){this['domStorage_']=_0x229e52,this['prefix_']='firebase:';}['set'](_0x1b17dd,_0x17f663){_0x17f663==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x1b17dd)):this['domStorage_']['setItem'](this['prefixedName_'](_0x1b17dd),O(_0x17f663));}['get'](_0x11eb0b){const _0x4fe474=this['domStorage_']['getItem'](this['prefixedName_'](_0x11eb0b));return _0x4fe474==null?null:At(_0x4fe474);}['remove'](_0x350cdb){this['domStorage_']['removeItem'](this['prefixedName_'](_0x350cdb));}['prefixedName_'](_0x1b6ebe){return this['prefix_']+_0x1b6ebe;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x3cd520,_0x207b4a){_0x207b4a==null?delete this['cache_'][_0x3cd520]:this['cache_'][_0x3cd520]=_0x207b4a;}['get'](_0x39142f){return J(this['cache_'],_0x39142f)?this['cache_'][_0x39142f]:null;}['remove'](_0x3d1e3b){delete this['cache_'][_0x3d1e3b];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x1a74d4){try{if(typeof window<'u'&&typeof window[_0x1a74d4]<'u'){const _0xb919b0=window[_0x1a74d4];return _0xb919b0['setItem']('firebase:sentinel','cache'),_0xb919b0['removeItem']('firebase:sentinel'),new Wl(_0xb919b0);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x180e5a=0x1;return function(){return _0x180e5a++;};}()),ro=function(_0x3dc3cd){const _0x17630c=Rc(_0x3dc3cd),_0x43ab15=new Cc();_0x43ab15['update'](_0x17630c);const _0x2b2222=_0x43ab15['digest']();return Li['encodeByteArray'](_0x2b2222);},Vt=function(..._0x3d28ea){let _0x5e9805='';for(let _0x5b1e58=0x0;_0x5b1e58<_0x3d28ea['length'];_0x5b1e58++){const _0x3b35d1=_0x3d28ea[_0x5b1e58];Array['isArray'](_0x3b35d1)||_0x3b35d1&&typeof _0x3b35d1=='object'&&typeof _0x3b35d1['length']=='number'?_0x5e9805+=Vt['apply'](null,_0x3b35d1):typeof _0x3b35d1=='object'?_0x5e9805+=O(_0x3b35d1):_0x5e9805+=_0x3b35d1,_0x5e9805+='\x20';}return _0x5e9805;};let wt=null,Gs=!0x0;const Hl=function(_0x3af594,_0x1abf9b){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0xfc7e35){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x332f15=Vt['apply'](null,_0xfc7e35);wt(_0x332f15);}},Ht=function(_0x3b5bb9){return function(..._0x3f2d7e){L(_0x3b5bb9,..._0x3f2d7e);};},yi=function(..._0x492e5b){const _0x3b1e0c='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x492e5b);Ye['error'](_0x3b1e0c);},ae=function(..._0x2092f2){const _0x65574e='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x2092f2);throw Ye['error'](_0x65574e),new Error(_0x65574e);},U=function(..._0x385db9){const _0x34d774='FIREBASE\x20WARNING:\x20'+Vt(..._0x385db9);Ye['warn'](_0x34d774);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0xc17e71){return typeof _0xc17e71=='number'&&(_0xc17e71!==_0xc17e71||_0xc17e71===Number['POSITIVE_INFINITY']||_0xc17e71===Number['NEGATIVE_INFINITY']);},Gl=function(_0x3d3054){if(document['readyState']==='complete')_0x3d3054();else{let _0x3a9a94=!0x1;const _0x589944=function(){if(!document['body']){setTimeout(_0x589944,Math['floor'](0xa));return;}_0x3a9a94||(_0x3a9a94=!0x0,_0x3d3054());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x589944,!0x1),window['addEventListener']('load',_0x589944,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x589944();}),window['attachEvent']('onload',_0x589944));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x3b1b15,_0x45aa46){if(_0x3b1b15===_0x45aa46)return 0x0;if(_0x3b1b15===Fe||_0x45aa46===Ie)return-0x1;if(_0x45aa46===Fe||_0x3b1b15===Ie)return 0x1;{const _0x363301=qs(_0x3b1b15),_0x131311=qs(_0x45aa46);return _0x363301!==null?_0x131311!==null?_0x363301-_0x131311===0x0?_0x3b1b15['length']-_0x45aa46['length']:_0x363301-_0x131311:-0x1:_0x131311!==null?0x1:_0x3b1b15<_0x45aa46?-0x1:0x1;}},ql=function(_0x32a9aa,_0xb46194){return _0x32a9aa===_0xb46194?0x0:_0x32a9aa<_0xb46194?-0x1:0x1;},_t=function(_0x592b2b,_0x75e29a){if(_0x75e29a&&_0x592b2b in _0x75e29a)return _0x75e29a[_0x592b2b];throw new Error('Missing\x20required\x20key\x20('+_0x592b2b+')\x20in\x20object:\x20'+O(_0x75e29a));},Hi=function(_0x584926){if(typeof _0x584926!='object'||_0x584926===null)return O(_0x584926);const _0x4a5a45=[];for(const _0x1748b1 in _0x584926)_0x4a5a45['push'](_0x1748b1);_0x4a5a45['sort']();let _0x2cbe84='{';for(let _0x5ac376=0x0;_0x5ac376<_0x4a5a45['length'];_0x5ac376++)_0x5ac376!==0x0&&(_0x2cbe84+=','),_0x2cbe84+=O(_0x4a5a45[_0x5ac376]),_0x2cbe84+=':',_0x2cbe84+=Hi(_0x584926[_0x4a5a45[_0x5ac376]]);return _0x2cbe84+='}',_0x2cbe84;},oo=function(_0x4198cd,_0x3b45b8){const _0x1ba08a=_0x4198cd['length'];if(_0x1ba08a<=_0x3b45b8)return[_0x4198cd];const _0x4203d2=[];for(let _0x474b13=0x0;_0x474b13<_0x1ba08a;_0x474b13+=_0x3b45b8)_0x474b13+_0x3b45b8>_0x1ba08a?_0x4203d2['push'](_0x4198cd['substring'](_0x474b13,_0x1ba08a)):_0x4203d2['push'](_0x4198cd['substring'](_0x474b13,_0x474b13+_0x3b45b8));return _0x4203d2;};function x(_0x295b11,_0x471b0a){for(const _0x3c14c6 in _0x295b11)_0x295b11['hasOwnProperty'](_0x3c14c6)&&_0x471b0a(_0x3c14c6,_0x295b11[_0x3c14c6]);}const ao=function(_0x56b888){f(!Vi(_0x56b888),'Invalid\x20JSON\x20number');const _0x54032a=0xb,_0x554f63=0x34,_0x25d25e=(0x1<<_0x54032a-0x1)-0x1;let _0x215887,_0x1abb0a,_0x3d1cc9,_0x340e48,_0x2379d9;_0x56b888===0x0?(_0x1abb0a=0x0,_0x3d1cc9=0x0,_0x215887=0x1/_0x56b888===-0x1/0x0?0x1:0x0):(_0x215887=_0x56b888<0x0,_0x56b888=Math['abs'](_0x56b888),_0x56b888>=Math['pow'](0x2,0x1-_0x25d25e)?(_0x340e48=Math['min'](Math['floor'](Math['log'](_0x56b888)/Math['LN2']),_0x25d25e),_0x1abb0a=_0x340e48+_0x25d25e,_0x3d1cc9=Math['round'](_0x56b888*Math['pow'](0x2,_0x554f63-_0x340e48)-Math['pow'](0x2,_0x554f63))):(_0x1abb0a=0x0,_0x3d1cc9=Math['round'](_0x56b888/Math['pow'](0x2,0x1-_0x25d25e-_0x554f63))));const _0x277205=[];for(_0x2379d9=_0x554f63;_0x2379d9;_0x2379d9-=0x1)_0x277205['push'](_0x3d1cc9%0x2?0x1:0x0),_0x3d1cc9=Math['floor'](_0x3d1cc9/0x2);for(_0x2379d9=_0x54032a;_0x2379d9;_0x2379d9-=0x1)_0x277205['push'](_0x1abb0a%0x2?0x1:0x0),_0x1abb0a=Math['floor'](_0x1abb0a/0x2);_0x277205['push'](_0x215887?0x1:0x0),_0x277205['reverse']();const _0x3ea659=_0x277205['join']('');let _0x1b44f5='';for(_0x2379d9=0x0;_0x2379d9<0x40;_0x2379d9+=0x8){let _0x31cb82=parseInt(_0x3ea659['substr'](_0x2379d9,0x8),0x2)['toString'](0x10);_0x31cb82['length']===0x1&&(_0x31cb82='0'+_0x31cb82),_0x1b44f5=_0x1b44f5+_0x31cb82;}return _0x1b44f5['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x2ab9f2,_0x1b3c39){let _0x431ddf='Unknown\x20Error';_0x2ab9f2==='too_big'?_0x431ddf='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x2ab9f2==='permission_denied'?_0x431ddf='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x2ab9f2==='unavailable'&&(_0x431ddf='The\x20service\x20is\x20unavailable');const _0x2ed0db=new Error(_0x2ab9f2+'\x20at\x20'+_0x1b3c39['_path']['toString']()+':\x20'+_0x431ddf);return _0x2ed0db['code']=_0x2ab9f2['toUpperCase'](),_0x2ed0db;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x49986e){if(Yl['test'](_0x49986e)){const _0x26d605=Number(_0x49986e);if(_0x26d605>=Ql&&_0x26d605<=Jl)return _0x26d605;}return null;},ht=function(_0x330289){try{_0x330289();}catch(_0xbeafaa){setTimeout(()=>{const _0x5a87fb=_0xbeafaa['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x5a87fb),_0xbeafaa;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x4917c0,_0x3d4b20){const _0x86d862=setTimeout(_0x4917c0,_0x3d4b20);return typeof _0x86d862=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x86d862):typeof _0x86d862=='object'&&_0x86d862['unref']&&_0x86d862['unref'](),_0x86d862;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x49cff1,_0x2fb881){this['appCheckProvider']=_0x2fb881,this['appName']=_0x49cff1['name'],$(_0x49cff1)&&_0x49cff1['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x49cff1['settings']['appCheckToken']),this['appCheck']=_0x2fb881==null?void 0x0:_0x2fb881['getImmediate']({'optional':!0x0}),this['appCheck']||_0x2fb881==null||_0x2fb881['get']()['then'](_0x5ac35e=>this['appCheck']=_0x5ac35e);}['getToken'](_0x33af53){if(this['serverAppAppCheckToken']){if(_0x33af53)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x33af53):new Promise((_0x4d7788,_0x266c03)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x33af53)['then'](_0x4d7788,_0x266c03):_0x4d7788(null);},0x0);});}['addTokenChangeListener'](_0x106778){var _0x40ab02;(_0x40ab02=this['appCheckProvider'])==null||_0x40ab02['get']()['then'](_0x595db8=>_0x595db8['addTokenListener'](_0x106778));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x13786e,_0x3bd24e,_0x447618){this['appName_']=_0x13786e,this['firebaseOptions_']=_0x3bd24e,this['authProvider_']=_0x447618,this['auth_']=null,this['auth_']=_0x447618['getImmediate']({'optional':!0x0}),this['auth_']||_0x447618['onInit'](_0x38bf9e=>this['auth_']=_0x38bf9e);}['getToken'](_0x11cbcb){return this['auth_']?this['auth_']['getToken'](_0x11cbcb)['catch'](_0x1c765b=>_0x1c765b&&_0x1c765b['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x1c765b)):new Promise((_0x29652e,_0xc70434)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x11cbcb)['then'](_0x29652e,_0xc70434):_0x29652e(null);},0x0);});}['addTokenChangeListener'](_0x46a85a){this['auth_']?this['auth_']['addAuthTokenListener'](_0x46a85a):this['authProvider_']['get']()['then'](_0x4d644c=>_0x4d644c['addAuthTokenListener'](_0x46a85a));}['removeTokenChangeListener'](_0x453830){this['authProvider_']['get']()['then'](_0x1d3ef3=>_0x1d3ef3['removeAuthTokenListener'](_0x453830));}['notifyForInvalidToken'](){let _0x95270f='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x95270f+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x95270f+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x95270f+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x95270f);}}class nn{constructor(_0x16aa29){this['accessToken']=_0x16aa29;}['getToken'](_0x43f8dd){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x1825b2){_0x1825b2(this['accessToken']);}['removeTokenChangeListener'](_0x2f5376){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x230399,_0x1423b4,_0x23f8d5,_0x1d47ba,_0x3f8e91=!0x1,_0x6ac429='',_0x5e7547=!0x1,_0x4fd1d5=!0x1,_0x2454b7=null){this['secure']=_0x1423b4,this['namespace']=_0x23f8d5,this['webSocketOnly']=_0x1d47ba,this['nodeAdmin']=_0x3f8e91,this['persistenceKey']=_0x6ac429,this['includeNamespaceInQueryParams']=_0x5e7547,this['isUsingEmulator']=_0x4fd1d5,this['emulatorOptions']=_0x2454b7,this['_host']=_0x230399['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x230399)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x4272d9){_0x4272d9!==this['internalHost']&&(this['internalHost']=_0x4272d9,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x43acdf=this['toURLString']();return this['persistenceKey']&&(_0x43acdf+='<'+this['persistenceKey']+'>'),_0x43acdf;}['toURLString'](){const _0x3aa606=this['secure']?'https://':'http://',_0x21bb96=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x3aa606+this['host']+'/'+_0x21bb96;}}function th(_0x523095){return _0x523095['host']!==_0x523095['internalHost']||_0x523095['isCustomHost']()||_0x523095['includeNamespaceInQueryParams'];}function vo(_0x5f576b,_0x51e9ff,_0xe2de8f){f(typeof _0x51e9ff=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0xe2de8f=='object','typeof\x20params\x20must\x20==\x20object');let _0x3bbc34;if(_0x51e9ff===go)_0x3bbc34=(_0x5f576b['secure']?'wss://':'ws://')+_0x5f576b['internalHost']+'/.ws?';else{if(_0x51e9ff===mo)_0x3bbc34=(_0x5f576b['secure']?'https://':'http://')+_0x5f576b['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x51e9ff);}th(_0x5f576b)&&(_0xe2de8f['ns']=_0x5f576b['namespace']);const _0x2ed70c=[];return x(_0xe2de8f,(_0x2f9776,_0x2cdfad)=>{_0x2ed70c['push'](_0x2f9776+'='+_0x2cdfad);}),_0x3bbc34+_0x2ed70c['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x490151,_0x22699a=0x1){J(this['counters_'],_0x490151)||(this['counters_'][_0x490151]=0x0),this['counters_'][_0x490151]+=_0x22699a;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0xcb1d9a){const _0x5a81f2=_0xcb1d9a['toString']();return ni[_0x5a81f2]||(ni[_0x5a81f2]=new nh()),ni[_0x5a81f2];}function ih(_0x52eb6b,_0x5298f4){const _0x46132a=_0x52eb6b['toString']();return ii[_0x46132a]||(ii[_0x46132a]=_0x5298f4()),ii[_0x46132a];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x170c8d){this['onMessage_']=_0x170c8d,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x245aff,_0x55495b){this['closeAfterResponse']=_0x245aff,this['onClose']=_0x55495b,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x39c5b8,_0x3ce85a){for(this['pendingResponses'][_0x39c5b8]=_0x3ce85a;this['pendingResponses'][this['currentResponseNum']];){const _0x1e4d03=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x5ae0c7=0x0;_0x5ae0c7<_0x1e4d03['length'];++_0x5ae0c7)_0x1e4d03[_0x5ae0c7]&&ht(()=>{this['onMessage_'](_0x1e4d03[_0x5ae0c7]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x45caf1,_0xe10b90,_0x208999,_0x4c780a,_0x1709c2,_0x36930d,_0x27f960){this['connId']=_0x45caf1,this['repoInfo']=_0xe10b90,this['applicationId']=_0x208999,this['appCheckToken']=_0x4c780a,this['authToken']=_0x1709c2,this['transportSessionId']=_0x36930d,this['lastSessionId']=_0x27f960,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x45caf1),this['stats_']=Gi(_0xe10b90),this['urlFn']=_0x2d8a4e=>(this['appCheckToken']&&(_0x2d8a4e[vi]=this['appCheckToken']),vo(_0xe10b90,mo,_0x2d8a4e));}['open'](_0x62bbe7,_0x4b7bb0){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x4b7bb0,this['myPacketOrderer']=new sh(_0x62bbe7),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x54ba0a)=>{const [_0xdcebd2,_0x21c31e,_0x5d1038,_0x5231a9,_0x395ed4]=_0x54ba0a;if(this['incrementIncomingBytes_'](_0x54ba0a),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0xdcebd2===zs)this['id']=_0x21c31e,this['password']=_0x5d1038;else{if(_0xdcebd2===rh)_0x21c31e?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x21c31e,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0xdcebd2);}}},(..._0x53d7a7)=>{const [_0x49e1f5,_0x3111a8]=_0x53d7a7;this['incrementIncomingBytes_'](_0x53d7a7),this['myPacketOrderer']['handleResponse'](_0x49e1f5,_0x3111a8);},()=>{this['onClosed_']();},this['urlFn']);const _0x513428={};_0x513428[zs]='t',_0x513428[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x513428[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x513428[co]=$i,this['transportSessionId']&&(_0x513428[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x513428[po]=this['lastSessionId']),this['applicationId']&&(_0x513428[_o]=this['applicationId']),this['appCheckToken']&&(_0x513428[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x513428[ho]=uo);const _0x3aed79=this['urlFn'](_0x513428);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x3aed79),this['scriptTagHolder']['addTag'](_0x3aed79,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x5d5a21){const _0x131fc7=O(_0x5d5a21);this['bytesSent']+=_0x131fc7['length'],this['stats_']['incrementCounter']('bytes_sent',_0x131fc7['length']);const _0x5e10af=Hr(_0x131fc7),_0x111fa7=oo(_0x5e10af,fh);for(let _0x1ffb1d=0x0;_0x1ffb1d<_0x111fa7['length'];_0x1ffb1d++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x111fa7['length'],_0x111fa7[_0x1ffb1d]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x16a0c6,_0x450d3d){this['myDisconnFrame']=document['createElement']('iframe');const _0x20bd5f={};_0x20bd5f[dh]='t',_0x20bd5f[Eo]=_0x16a0c6,_0x20bd5f[Io]=_0x450d3d,this['myDisconnFrame']['src']=this['urlFn'](_0x20bd5f),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x7b1a96){const _0x3af838=O(_0x7b1a96)['length'];this['bytesReceived']+=_0x3af838,this['stats_']['incrementCounter']('bytes_received',_0x3af838);}}class qi{constructor(_0x537c9e,_0x8cc47f,_0x4a7840,_0x590708){this['onDisconnect']=_0x4a7840,this['urlFn']=_0x590708,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x537c9e,window[ah+this['uniqueCallbackIdentifier']]=_0x8cc47f,this['myIFrame']=qi['createIFrame_']();let _0x21ef87='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x21ef87='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x38c467='<html><body>'+_0x21ef87+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x38c467),this['myIFrame']['doc']['close']();}catch(_0x3ccf03){L('frame\x20writing\x20exception'),_0x3ccf03['stack']&&L(_0x3ccf03['stack']),L(_0x3ccf03);}}}static['createIFrame_'](){const _0x64c2ee=document['createElement']('iframe');if(_0x64c2ee['style']['display']='none',document['body']){document['body']['appendChild'](_0x64c2ee);try{_0x64c2ee['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x224ed8=document['domain'];_0x64c2ee['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x224ed8+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x64c2ee['contentDocument']?_0x64c2ee['doc']=_0x64c2ee['contentDocument']:_0x64c2ee['contentWindow']?_0x64c2ee['doc']=_0x64c2ee['contentWindow']['document']:_0x64c2ee['document']&&(_0x64c2ee['doc']=_0x64c2ee['document']),_0x64c2ee;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x1f5815=this['onDisconnect'];_0x1f5815&&(this['onDisconnect']=null,_0x1f5815());}['startLongPoll'](_0x2ab954,_0x3152fa){for(this['myID']=_0x2ab954,this['myPW']=_0x3152fa,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0xc994db={};_0xc994db[Eo]=this['myID'],_0xc994db[Io]=this['myPW'],_0xc994db[wo]=this['currentSerial'];let _0x273d6b=this['urlFn'](_0xc994db),_0xa802af='',_0x178c04=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0xa802af['length']<=Co;){const _0x5b9238=this['pendingSegs']['shift']();_0xa802af=_0xa802af+'&'+lh+_0x178c04+'='+_0x5b9238['seg']+'&'+hh+_0x178c04+'='+_0x5b9238['ts']+'&'+uh+_0x178c04+'='+_0x5b9238['d'],_0x178c04++;}return _0x273d6b=_0x273d6b+_0xa802af,this['addLongPollTag_'](_0x273d6b,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x204e4a,_0xaed0af,_0x166532){this['pendingSegs']['push']({'seg':_0x204e4a,'ts':_0xaed0af,'d':_0x166532}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1914ab,_0x4c80d1){this['outstandingRequests']['add'](_0x4c80d1);const _0x5ec06b=()=>{this['outstandingRequests']['delete'](_0x4c80d1),this['newRequest_']();},_0x5b67a4=setTimeout(_0x5ec06b,Math['floor'](ph)),_0x5c5983=()=>{clearTimeout(_0x5b67a4),_0x5ec06b();};this['addTag'](_0x1914ab,_0x5c5983);}['addTag'](_0x4f7c57,_0x40f706){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x15f35c=this['myIFrame']['doc']['createElement']('script');_0x15f35c['type']='text/javascript',_0x15f35c['async']=!0x0,_0x15f35c['src']=_0x4f7c57,_0x15f35c['onload']=_0x15f35c['onreadystatechange']=function(){const _0x5ec335=_0x15f35c['readyState'];(!_0x5ec335||_0x5ec335==='loaded'||_0x5ec335==='complete')&&(_0x15f35c['onload']=_0x15f35c['onreadystatechange']=null,_0x15f35c['parentNode']&&_0x15f35c['parentNode']['removeChild'](_0x15f35c),_0x40f706());},_0x15f35c['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x4f7c57),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x15f35c);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x4181cf,_0x468d24,_0xe42fbe,_0x50ab8b,_0x131292,_0x3f785a,_0x197305){this['connId']=_0x4181cf,this['applicationId']=_0xe42fbe,this['appCheckToken']=_0x50ab8b,this['authToken']=_0x131292,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x468d24),this['connURL']=z['connectionURL_'](_0x468d24,_0x3f785a,_0x197305,_0x50ab8b,_0xe42fbe),this['nodeAdmin']=_0x468d24['nodeAdmin'];}static['connectionURL_'](_0x507c82,_0x5af6dc,_0x389967,_0x5845ce,_0x32b6af){const _0x51733d={};return _0x51733d[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x51733d[ho]=uo),_0x5af6dc&&(_0x51733d[lo]=_0x5af6dc),_0x389967&&(_0x51733d[po]=_0x389967),_0x5845ce&&(_0x51733d[vi]=_0x5845ce),_0x32b6af&&(_0x51733d[_o]=_0x32b6af),vo(_0x507c82,go,_0x51733d);}['open'](_0x2ad075,_0x256f4e){this['onDisconnect']=_0x256f4e,this['onMessage']=_0x2ad075,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x3dcfd4;_c(),this['mySock']=new un(this['connURL'],[],_0x3dcfd4);}catch(_0xf1b84d){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x500262=_0xf1b84d['message']||_0xf1b84d['data'];_0x500262&&this['log_'](_0x500262),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0xdba20b=>{this['handleIncomingFrame'](_0xdba20b);},this['mySock']['onerror']=_0x2f6c13=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x3f8e0e=_0x2f6c13['message']||_0x2f6c13['data'];_0x3f8e0e&&this['log_'](_0x3f8e0e),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x10bf7a=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x1f6120=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x2f8d4f=navigator['userAgent']['match'](_0x1f6120);_0x2f8d4f&&_0x2f8d4f['length']>0x1&&parseFloat(_0x2f8d4f[0x1])<4.4&&(_0x10bf7a=!0x0);}return!_0x10bf7a&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0xed60c9){if(this['frames']['push'](_0xed60c9),this['frames']['length']===this['totalFrames']){const _0x39c2e9=this['frames']['join']('');this['frames']=null;const _0x116430=At(_0x39c2e9);this['onMessage'](_0x116430);}}['handleNewFrameCount_'](_0x17b6a0){this['totalFrames']=_0x17b6a0,this['frames']=[];}['extractFrameCount_'](_0x126651){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x126651['length']<=0x6){const _0x309d1f=Number(_0x126651);if(!isNaN(_0x309d1f))return this['handleNewFrameCount_'](_0x309d1f),null;}return this['handleNewFrameCount_'](0x1),_0x126651;}['handleIncomingFrame'](_0x168434){if(this['mySock']===null)return;const _0x364c0d=_0x168434['data'];if(this['bytesReceived']+=_0x364c0d['length'],this['stats_']['incrementCounter']('bytes_received',_0x364c0d['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x364c0d);else{const _0x148d60=this['extractFrameCount_'](_0x364c0d);_0x148d60!==null&&this['appendFrame_'](_0x148d60);}}['send'](_0x1910eb){this['resetKeepAlive']();const _0x49c8aa=O(_0x1910eb);this['bytesSent']+=_0x49c8aa['length'],this['stats_']['incrementCounter']('bytes_sent',_0x49c8aa['length']);const _0x1741b4=oo(_0x49c8aa,gh);_0x1741b4['length']>0x1&&this['sendString_'](String(_0x1741b4['length']));for(let _0x4f9737=0x0;_0x4f9737<_0x1741b4['length'];_0x4f9737++)this['sendString_'](_0x1741b4[_0x4f9737]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x3ee79f){try{this['mySock']['send'](_0x3ee79f);}catch(_0x8058b0){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x8058b0['message']||_0x8058b0['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x22c839){this['initTransports_'](_0x22c839);}['initTransports_'](_0x1673a6){const _0x136e07=z&&z['isAvailable']();let _0x50e2f6=_0x136e07&&!z['previouslyFailed']();if(_0x1673a6['webSocketOnly']&&(_0x136e07||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x50e2f6=!0x0),_0x50e2f6)this['transports_']=[z];else{const _0x1ae70e=this['transports_']=[];for(const _0x47a1b9 of Nt['ALL_TRANSPORTS'])_0x47a1b9&&_0x47a1b9['isAvailable']()&&_0x1ae70e['push'](_0x47a1b9);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x21bd4e,_0x678ea7,_0x40149f,_0x24e426,_0x17160a,_0x434d82,_0x22e152,_0x912e7e,_0x13e1c8,_0xd7d8ff){this['id']=_0x21bd4e,this['repoInfo_']=_0x678ea7,this['applicationId_']=_0x40149f,this['appCheckToken_']=_0x24e426,this['authToken_']=_0x17160a,this['onMessage_']=_0x434d82,this['onReady_']=_0x22e152,this['onDisconnect_']=_0x912e7e,this['onKill_']=_0x13e1c8,this['lastSessionId']=_0xd7d8ff,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x678ea7),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x5ba45c=this['transportManager_']['initialTransport']();this['conn_']=new _0x5ba45c(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x5ba45c['responsesRequiredToBeHealthy']||0x0;const _0x1f59b3=this['connReceiver_'](this['conn_']),_0x35e3a8=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x1f59b3,_0x35e3a8);},Math['floor'](0x0));const _0x35f56f=_0x5ba45c['healthyTimeout']||0x0;_0x35f56f>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x35f56f)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x5132dd){return _0x4ab49d=>{_0x5132dd===this['conn_']?this['onConnectionLost_'](_0x4ab49d):_0x5132dd===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x57a949){return _0x475645=>{this['state_']!==0x2&&(_0x57a949===this['rx_']?this['onPrimaryMessageReceived_'](_0x475645):_0x57a949===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x475645):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x3ac892){const _0xd5defd={'t':'d','d':_0x3ac892};this['sendData_'](_0xd5defd);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x2e5a64){if(si in _0x2e5a64){const _0x238954=_0x2e5a64[si];_0x238954===Qs?this['upgradeIfSecondaryHealthy_']():_0x238954===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x238954===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0xc46c02){const _0x38c61a=_t('t',_0xc46c02),_0x48ee2e=_t('d',_0xc46c02);if(_0x38c61a==='c')this['onSecondaryControl_'](_0x48ee2e);else{if(_0x38c61a==='d')this['pendingDataMessages']['push'](_0x48ee2e);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x38c61a);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x2d8909){const _0x17fd7f=_t('t',_0x2d8909),_0x4160a9=_t('d',_0x2d8909);_0x17fd7f==='c'?this['onControl_'](_0x4160a9):_0x17fd7f==='d'&&this['onDataMessage_'](_0x4160a9);}['onDataMessage_'](_0x321256){this['onPrimaryResponse_'](),this['onMessage_'](_0x321256);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x4703fa){const _0x3f324d=_t(si,_0x4703fa);if(js in _0x4703fa){const _0x1fb170=_0x4703fa[js];if(_0x3f324d===Th){const _0x3b588c={..._0x1fb170};this['repoInfo_']['isUsingEmulator']&&(_0x3b588c['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x3b588c);}else{if(_0x3f324d===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x21ba13=0x0;_0x21ba13<this['pendingDataMessages']['length'];++_0x21ba13)this['onDataMessage_'](this['pendingDataMessages'][_0x21ba13]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x3f324d===wh?this['onConnectionShutdown_'](_0x1fb170):_0x3f324d===Ks?this['onReset_'](_0x1fb170):_0x3f324d===Ch?yi('Server\x20Error:\x20'+_0x1fb170):_0x3f324d===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x3f324d);}}}['onHandshake_'](_0x3b80d5){const _0x4c8a7c=_0x3b80d5['ts'],_0x53e594=_0x3b80d5['v'],_0x34e820=_0x3b80d5['h'];this['sessionId']=_0x3b80d5['s'],this['repoInfo_']['host']=_0x34e820,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x4c8a7c),$i!==_0x53e594&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x46d73a=this['transportManager_']['upgradeTransport']();_0x46d73a&&this['startUpgrade_'](_0x46d73a);}['startUpgrade_'](_0x315484){this['secondaryConn_']=new _0x315484(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x315484['responsesRequiredToBeHealthy']||0x0;const _0x4c0943=this['connReceiver_'](this['secondaryConn_']),_0x6cb6b6=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x4c0943,_0x6cb6b6),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x4d3870){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x4d3870),this['repoInfo_']['host']=_0x4d3870,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0xb466b1,_0x231042){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0xb466b1,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x231042,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0xca3e97=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0xca3e97||this['rx_']===_0xca3e97)&&this['close']();}['onConnectionLost_'](_0x187ab4){this['conn_']=null,!_0x187ab4&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x4a03f0){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x4a03f0),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x3eb1bc){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x3eb1bc);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x4ba30c,_0x2a5747,_0x392399,_0x11b4fc){}['merge'](_0x5e8ccc,_0x48513a,_0x5d3f32,_0x9de7a8){}['refreshAuthToken'](_0xe080dd){}['refreshAppCheckToken'](_0x32cf43){}['onDisconnectPut'](_0x28afd1,_0x2cd1c0,_0x587b75){}['onDisconnectMerge'](_0x15d726,_0x4688f0,_0x278203){}['onDisconnectCancel'](_0x2335d1,_0x111353){}['reportStats'](_0x14db54){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x3639e2){this['allowedEvents_']=_0x3639e2,this['listeners_']={},f(Array['isArray'](_0x3639e2)&&_0x3639e2['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x3190f7,..._0x46ea6f){if(Array['isArray'](this['listeners_'][_0x3190f7])){const _0x39c86d=[...this['listeners_'][_0x3190f7]];for(let _0x10faaa=0x0;_0x10faaa<_0x39c86d['length'];_0x10faaa++)_0x39c86d[_0x10faaa]['callback']['apply'](_0x39c86d[_0x10faaa]['context'],_0x46ea6f);}}['on'](_0x409826,_0x38f2b6,_0x5276ae){this['validateEventType_'](_0x409826),this['listeners_'][_0x409826]=this['listeners_'][_0x409826]||[],this['listeners_'][_0x409826]['push']({'callback':_0x38f2b6,'context':_0x5276ae});const _0x2f296e=this['getInitialEvent'](_0x409826);_0x2f296e&&_0x38f2b6['apply'](_0x5276ae,_0x2f296e);}['off'](_0x32c7ae,_0x361bbc,_0x397344){this['validateEventType_'](_0x32c7ae);const _0x7a1db1=this['listeners_'][_0x32c7ae]||[];for(let _0x417c32=0x0;_0x417c32<_0x7a1db1['length'];_0x417c32++)if(_0x7a1db1[_0x417c32]['callback']===_0x361bbc&&(!_0x397344||_0x397344===_0x7a1db1[_0x417c32]['context'])){_0x7a1db1['splice'](_0x417c32,0x1);return;}}['validateEventType_'](_0x298731){f(this['allowedEvents_']['find'](_0x398892=>_0x398892===_0x298731),'Unknown\x20event:\x20'+_0x298731);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x3005dd){return f(_0x3005dd==='online','Unknown\x20event\x20type:\x20'+_0x3005dd),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x59e0af,_0x25b942){if(_0x25b942===void 0x0){this['pieces_']=_0x59e0af['split']('/');let _0x2fd8dc=0x0;for(let _0x55ff43=0x0;_0x55ff43<this['pieces_']['length'];_0x55ff43++)this['pieces_'][_0x55ff43]['length']>0x0&&(this['pieces_'][_0x2fd8dc]=this['pieces_'][_0x55ff43],_0x2fd8dc++);this['pieces_']['length']=_0x2fd8dc,this['pieceNum_']=0x0;}else this['pieces_']=_0x59e0af,this['pieceNum_']=_0x25b942;}['toString'](){let _0x7f3d14='';for(let _0x253a1b=this['pieceNum_'];_0x253a1b<this['pieces_']['length'];_0x253a1b++)this['pieces_'][_0x253a1b]!==''&&(_0x7f3d14+='/'+this['pieces_'][_0x253a1b]);return _0x7f3d14||'/';}}function w(){return new C('');}function y(_0x504295){return _0x504295['pieceNum_']>=_0x504295['pieces_']['length']?null:_0x504295['pieces_'][_0x504295['pieceNum_']];}function we(_0x2f5c88){return _0x2f5c88['pieces_']['length']-_0x2f5c88['pieceNum_'];}function b(_0xd45224){let _0x18678b=_0xd45224['pieceNum_'];return _0x18678b<_0xd45224['pieces_']['length']&&_0x18678b++,new C(_0xd45224['pieces_'],_0x18678b);}function zi(_0xcf4ad2){return _0xcf4ad2['pieceNum_']<_0xcf4ad2['pieces_']['length']?_0xcf4ad2['pieces_'][_0xcf4ad2['pieces_']['length']-0x1]:null;}function bh(_0x411d57){let _0x378c00='';for(let _0x493ddc=_0x411d57['pieceNum_'];_0x493ddc<_0x411d57['pieces_']['length'];_0x493ddc++)_0x411d57['pieces_'][_0x493ddc]!==''&&(_0x378c00+='/'+encodeURIComponent(String(_0x411d57['pieces_'][_0x493ddc])));return _0x378c00||'/';}function Pt(_0x222f9c,_0x7d598f=0x0){return _0x222f9c['pieces_']['slice'](_0x222f9c['pieceNum_']+_0x7d598f);}function Ro(_0x3c29b9){if(_0x3c29b9['pieceNum_']>=_0x3c29b9['pieces_']['length'])return null;const _0x3e6f9c=[];for(let _0x535daa=_0x3c29b9['pieceNum_'];_0x535daa<_0x3c29b9['pieces_']['length']-0x1;_0x535daa++)_0x3e6f9c['push'](_0x3c29b9['pieces_'][_0x535daa]);return new C(_0x3e6f9c,0x0);}function k(_0x5aceea,_0x38c09a){const _0x296d75=[];for(let _0x3c5f3a=_0x5aceea['pieceNum_'];_0x3c5f3a<_0x5aceea['pieces_']['length'];_0x3c5f3a++)_0x296d75['push'](_0x5aceea['pieces_'][_0x3c5f3a]);if(_0x38c09a instanceof C){for(let _0x2b0741=_0x38c09a['pieceNum_'];_0x2b0741<_0x38c09a['pieces_']['length'];_0x2b0741++)_0x296d75['push'](_0x38c09a['pieces_'][_0x2b0741]);}else{const _0x5f2025=_0x38c09a['split']('/');for(let _0x4c24ac=0x0;_0x4c24ac<_0x5f2025['length'];_0x4c24ac++)_0x5f2025[_0x4c24ac]['length']>0x0&&_0x296d75['push'](_0x5f2025[_0x4c24ac]);}return new C(_0x296d75,0x0);}function v(_0x127714){return _0x127714['pieceNum_']>=_0x127714['pieces_']['length'];}function F(_0x237665,_0xac6637){const _0x3ddb52=y(_0x237665),_0x1d54a4=y(_0xac6637);if(_0x3ddb52===null)return _0xac6637;if(_0x3ddb52===_0x1d54a4)return F(b(_0x237665),b(_0xac6637));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0xac6637+')\x20is\x20not\x20within\x20outerPath\x20('+_0x237665+')');}function Rh(_0x378859,_0x3d310d){const _0x332779=Pt(_0x378859,0x0),_0x204e69=Pt(_0x3d310d,0x0);for(let _0x28331b=0x0;_0x28331b<_0x332779['length']&&_0x28331b<_0x204e69['length'];_0x28331b++){const _0x2fc3c6=He(_0x332779[_0x28331b],_0x204e69[_0x28331b]);if(_0x2fc3c6!==0x0)return _0x2fc3c6;}return _0x332779['length']===_0x204e69['length']?0x0:_0x332779['length']<_0x204e69['length']?-0x1:0x1;}function ji(_0x1eee92,_0x1b8f38){if(we(_0x1eee92)!==we(_0x1b8f38))return!0x1;for(let _0x16b5a2=_0x1eee92['pieceNum_'],_0x196fb6=_0x1b8f38['pieceNum_'];_0x16b5a2<=_0x1eee92['pieces_']['length'];_0x16b5a2++,_0x196fb6++)if(_0x1eee92['pieces_'][_0x16b5a2]!==_0x1b8f38['pieces_'][_0x196fb6])return!0x1;return!0x0;}function G(_0x4d9a0b,_0x7cef9a){let _0x1fc336=_0x4d9a0b['pieceNum_'],_0xb69fe9=_0x7cef9a['pieceNum_'];if(we(_0x4d9a0b)>we(_0x7cef9a))return!0x1;for(;_0x1fc336<_0x4d9a0b['pieces_']['length'];){if(_0x4d9a0b['pieces_'][_0x1fc336]!==_0x7cef9a['pieces_'][_0xb69fe9])return!0x1;++_0x1fc336,++_0xb69fe9;}return!0x0;}class Ah{constructor(_0x485176,_0x4f32ee){this['errorPrefix_']=_0x4f32ee,this['parts_']=Pt(_0x485176,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x2fef02=0x0;_0x2fef02<this['parts_']['length'];_0x2fef02++)this['byteLength_']+=On(this['parts_'][_0x2fef02]);Ao(this);}}function kh(_0x1f7a79,_0x5298da){_0x1f7a79['parts_']['length']>0x0&&(_0x1f7a79['byteLength_']+=0x1),_0x1f7a79['parts_']['push'](_0x5298da),_0x1f7a79['byteLength_']+=On(_0x5298da),Ao(_0x1f7a79);}function Nh(_0x3601f6){const _0x470454=_0x3601f6['parts_']['pop']();_0x3601f6['byteLength_']-=On(_0x470454),_0x3601f6['parts_']['length']>0x0&&(_0x3601f6['byteLength_']-=0x1);}function Ao(_0x38435a){if(_0x38435a['byteLength_']>er)throw new Error(_0x38435a['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x38435a['byteLength_']+').');if(_0x38435a['parts_']['length']>Zs)throw new Error(_0x38435a['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x38435a));}function Pe(_0x2c3b26){return _0x2c3b26['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x2c3b26['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x50e250,_0xa8df99;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0xa8df99='visibilitychange',_0x50e250='hidden'):typeof document['mozHidden']<'u'?(_0xa8df99='mozvisibilitychange',_0x50e250='mozHidden'):typeof document['msHidden']<'u'?(_0xa8df99='msvisibilitychange',_0x50e250='msHidden'):typeof document['webkitHidden']<'u'&&(_0xa8df99='webkitvisibilitychange',_0x50e250='webkitHidden')),this['visible_']=!0x0,_0xa8df99&&document['addEventListener'](_0xa8df99,()=>{const _0x1a288f=!document[_0x50e250];_0x1a288f!==this['visible_']&&(this['visible_']=_0x1a288f,this['trigger']('visible',_0x1a288f));},!0x1);}['getInitialEvent'](_0x309dc2){return f(_0x309dc2==='visible','Unknown\x20event\x20type:\x20'+_0x309dc2),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x24bd66,_0x1f3e18,_0x342772,_0x3ed7f7,_0x2b790a,_0x367a2a,_0x1f37ea,_0x4ffbaf){if(super(),this['repoInfo_']=_0x24bd66,this['applicationId_']=_0x1f3e18,this['onDataUpdate_']=_0x342772,this['onConnectStatus_']=_0x3ed7f7,this['onServerInfoUpdate_']=_0x2b790a,this['authTokenProvider_']=_0x367a2a,this['appCheckTokenProvider_']=_0x1f37ea,this['authOverride_']=_0x4ffbaf,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x4ffbaf)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x24bd66['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x185129,_0x15769d,_0x3958ef){const _0x28316b=++this['requestNumber_'],_0x30b44e={'r':_0x28316b,'a':_0x185129,'b':_0x15769d};this['log_'](O(_0x30b44e)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x30b44e),_0x3958ef&&(this['requestCBHash_'][_0x28316b]=_0x3958ef);}['get'](_0x3dd3b8){this['initConnection_']();const _0xa60223=new ot(),_0x17c0c6={'action':'g','request':{'p':_0x3dd3b8['_path']['toString'](),'q':_0x3dd3b8['_queryObject']},'onComplete':_0x283827=>{const _0x1536cb=_0x283827['d'];_0x283827['s']==='ok'?_0xa60223['resolve'](_0x1536cb):_0xa60223['reject'](_0x1536cb);}};this['outstandingGets_']['push'](_0x17c0c6),this['outstandingGetCount_']++;const _0x48ce67=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x48ce67),_0xa60223['promise'];}['listen'](_0x34ef50,_0x5c1da2,_0x22415e,_0x329b56){this['initConnection_']();const _0xf4d17e=_0x34ef50['_queryIdentifier'],_0x2efee4=_0x34ef50['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2efee4+'\x20'+_0xf4d17e),this['listens']['has'](_0x2efee4)||this['listens']['set'](_0x2efee4,new Map()),f(_0x34ef50['_queryParams']['isDefault']()||!_0x34ef50['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x2efee4)['has'](_0xf4d17e),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x4854c0={'onComplete':_0x329b56,'hashFn':_0x5c1da2,'query':_0x34ef50,'tag':_0x22415e};this['listens']['get'](_0x2efee4)['set'](_0xf4d17e,_0x4854c0),this['connected_']&&this['sendListen_'](_0x4854c0);}['sendGet_'](_0x57d5c5){const _0x3019be=this['outstandingGets_'][_0x57d5c5];this['sendRequest']('g',_0x3019be['request'],_0x10bcd1=>{delete this['outstandingGets_'][_0x57d5c5],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x3019be['onComplete']&&_0x3019be['onComplete'](_0x10bcd1);});}['sendListen_'](_0x1d6862){const _0x210733=_0x1d6862['query'],_0x3136ad=_0x210733['_path']['toString'](),_0x1f9b5c=_0x210733['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x3136ad+'\x20for\x20'+_0x1f9b5c);const _0x123030={'p':_0x3136ad},_0x22e1a9='q';_0x1d6862['tag']&&(_0x123030['q']=_0x210733['_queryObject'],_0x123030['t']=_0x1d6862['tag']),_0x123030['h']=_0x1d6862['hashFn'](),this['sendRequest'](_0x22e1a9,_0x123030,_0x2c1789=>{const _0x48ce6d=_0x2c1789['d'],_0xb0fe39=_0x2c1789['s'];se['warnOnListenWarnings_'](_0x48ce6d,_0x210733),(this['listens']['get'](_0x3136ad)&&this['listens']['get'](_0x3136ad)['get'](_0x1f9b5c))===_0x1d6862&&(this['log_']('listen\x20response',_0x2c1789),_0xb0fe39!=='ok'&&this['removeListen_'](_0x3136ad,_0x1f9b5c),_0x1d6862['onComplete']&&_0x1d6862['onComplete'](_0xb0fe39,_0x48ce6d));});}static['warnOnListenWarnings_'](_0x40e250,_0x30e191){if(_0x40e250&&typeof _0x40e250=='object'&&J(_0x40e250,'w')){const _0x36f8ac=De(_0x40e250,'w');if(Array['isArray'](_0x36f8ac)&&~_0x36f8ac['indexOf']('no_index')){const _0x46a4b5='\x22.indexOn\x22:\x20\x22'+_0x30e191['_queryParams']['getIndex']()['toString']()+'\x22',_0x2e245c=_0x30e191['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x46a4b5+'\x20at\x20'+_0x2e245c+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x452660){this['authToken_']=_0x452660,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x452660);}['reduceReconnectDelayIfAdminCredential_'](_0x205d41){(_0x205d41&&_0x205d41['length']===0x28||wc(_0x205d41))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x5322dd){this['appCheckToken_']=_0x5322dd,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x4959b7=this['authToken_'],_0x4431ef=Ic(_0x4959b7)?'auth':'gauth',_0x1e9f36={'cred':_0x4959b7};this['authOverride_']===null?_0x1e9f36['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x1e9f36['authvar']=this['authOverride_']),this['sendRequest'](_0x4431ef,_0x1e9f36,_0x246750=>{const _0x4a7908=_0x246750['s'],_0x1fd688=_0x246750['d']||'error';this['authToken_']===_0x4959b7&&(_0x4a7908==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x4a7908,_0x1fd688));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x5ca7ef=>{const _0x54b00f=_0x5ca7ef['s'],_0x490b0e=_0x5ca7ef['d']||'error';_0x54b00f==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x54b00f,_0x490b0e);});}['unlisten'](_0x4d9ea7,_0x5a4c56){const _0x57db04=_0x4d9ea7['_path']['toString'](),_0x39c670=_0x4d9ea7['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x57db04+'\x20'+_0x39c670),f(_0x4d9ea7['_queryParams']['isDefault']()||!_0x4d9ea7['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x57db04,_0x39c670)&&this['connected_']&&this['sendUnlisten_'](_0x57db04,_0x39c670,_0x4d9ea7['_queryObject'],_0x5a4c56);}['sendUnlisten_'](_0x118d07,_0x397c7b,_0x517258,_0x188e62){this['log_']('Unlisten\x20on\x20'+_0x118d07+'\x20for\x20'+_0x397c7b);const _0x32a65a={'p':_0x118d07},_0x2447ca='n';_0x188e62&&(_0x32a65a['q']=_0x517258,_0x32a65a['t']=_0x188e62),this['sendRequest'](_0x2447ca,_0x32a65a);}['onDisconnectPut'](_0x1c2dbf,_0x5eaf7b,_0x4646ab){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x1c2dbf,_0x5eaf7b,_0x4646ab):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1c2dbf,'action':'o','data':_0x5eaf7b,'onComplete':_0x4646ab});}['onDisconnectMerge'](_0x3a253e,_0x5958d7,_0x4b5dd0){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x3a253e,_0x5958d7,_0x4b5dd0):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3a253e,'action':'om','data':_0x5958d7,'onComplete':_0x4b5dd0});}['onDisconnectCancel'](_0x418ebf,_0x2ed283){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x418ebf,null,_0x2ed283):this['onDisconnectRequestQueue_']['push']({'pathString':_0x418ebf,'action':'oc','data':null,'onComplete':_0x2ed283});}['sendOnDisconnect_'](_0x1186a6,_0x4299bf,_0x49c850,_0x3671e5){const _0x3f619f={'p':_0x4299bf,'d':_0x49c850};this['log_']('onDisconnect\x20'+_0x1186a6,_0x3f619f),this['sendRequest'](_0x1186a6,_0x3f619f,_0x248344=>{_0x3671e5&&setTimeout(()=>{_0x3671e5(_0x248344['s'],_0x248344['d']);},Math['floor'](0x0));});}['put'](_0x7456f7,_0x2434d9,_0x564934,_0x287b7c){this['putInternal']('p',_0x7456f7,_0x2434d9,_0x564934,_0x287b7c);}['merge'](_0x4716dc,_0x8a39df,_0x2af975,_0xb27ec2){this['putInternal']('m',_0x4716dc,_0x8a39df,_0x2af975,_0xb27ec2);}['putInternal'](_0x28897c,_0x15095c,_0x3c289d,_0xdf0ae5,_0x3cbfd3){this['initConnection_']();const _0x1224bf={'p':_0x15095c,'d':_0x3c289d};_0x3cbfd3!==void 0x0&&(_0x1224bf['h']=_0x3cbfd3),this['outstandingPuts_']['push']({'action':_0x28897c,'request':_0x1224bf,'onComplete':_0xdf0ae5}),this['outstandingPutCount_']++;const _0x80740b=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x80740b):this['log_']('Buffering\x20put:\x20'+_0x15095c);}['sendPut_'](_0x356a73){const _0x2a26b1=this['outstandingPuts_'][_0x356a73]['action'],_0x6a0faf=this['outstandingPuts_'][_0x356a73]['request'],_0x510d49=this['outstandingPuts_'][_0x356a73]['onComplete'];this['outstandingPuts_'][_0x356a73]['queued']=this['connected_'],this['sendRequest'](_0x2a26b1,_0x6a0faf,_0x1259e6=>{this['log_'](_0x2a26b1+'\x20response',_0x1259e6),delete this['outstandingPuts_'][_0x356a73],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x510d49&&_0x510d49(_0x1259e6['s'],_0x1259e6['d']);});}['reportStats'](_0x358a44){if(this['connected_']){const _0x87b213={'c':_0x358a44};this['log_']('reportStats',_0x87b213),this['sendRequest']('s',_0x87b213,_0x1ea038=>{if(_0x1ea038['s']!=='ok'){const _0x200f34=_0x1ea038['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x200f34);}});}}['onDataMessage_'](_0x1479f1){if('r'in _0x1479f1){this['log_']('from\x20server:\x20'+O(_0x1479f1));const _0x285662=_0x1479f1['r'],_0x2e3ca7=this['requestCBHash_'][_0x285662];_0x2e3ca7&&(delete this['requestCBHash_'][_0x285662],_0x2e3ca7(_0x1479f1['b']));}else{if('error'in _0x1479f1)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x1479f1['error'];'a'in _0x1479f1&&this['onDataPush_'](_0x1479f1['a'],_0x1479f1['b']);}}['onDataPush_'](_0x2e62d6,_0xf55c83){this['log_']('handleServerMessage',_0x2e62d6,_0xf55c83),_0x2e62d6==='d'?this['onDataUpdate_'](_0xf55c83['p'],_0xf55c83['d'],!0x1,_0xf55c83['t']):_0x2e62d6==='m'?this['onDataUpdate_'](_0xf55c83['p'],_0xf55c83['d'],!0x0,_0xf55c83['t']):_0x2e62d6==='c'?this['onListenRevoked_'](_0xf55c83['p'],_0xf55c83['q']):_0x2e62d6==='ac'?this['onAuthRevoked_'](_0xf55c83['s'],_0xf55c83['d']):_0x2e62d6==='apc'?this['onAppCheckRevoked_'](_0xf55c83['s'],_0xf55c83['d']):_0x2e62d6==='sd'?this['onSecurityDebugPacket_'](_0xf55c83):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x2e62d6)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x167c14,_0x416b1e){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x167c14),this['lastSessionId']=_0x416b1e,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0xb6405e){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0xb6405e));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x5411cc){_0x5411cc&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x5411cc;}['onOnline_'](_0x21dd30){_0x21dd30?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x47a214=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x2a6b8c=Math['max'](0x0,this['reconnectDelay_']-_0x47a214);_0x2a6b8c=Math['random']()*_0x2a6b8c,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x2a6b8c+'ms'),this['scheduleConnect_'](_0x2a6b8c),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x4bcad8=this['onDataMessage_']['bind'](this),_0x414fa9=this['onReady_']['bind'](this),_0x414606=this['onRealtimeDisconnect_']['bind'](this),_0x92dd9d=this['id']+':'+se['nextConnectionId_']++,_0x47386e=this['lastSessionId'];let _0x39c16d=!0x1,_0x105bc6=null;const _0x192fe2=function(){_0x105bc6?_0x105bc6['close']():(_0x39c16d=!0x0,_0x414606());},_0x118147=function(_0x4dbabf){f(_0x105bc6,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x105bc6['sendRequest'](_0x4dbabf);};this['realtime_']={'close':_0x192fe2,'sendRequest':_0x118147};const _0xea023=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x265cb9,_0x154703]=await Promise['all']([this['authTokenProvider_']['getToken'](_0xea023),this['appCheckTokenProvider_']['getToken'](_0xea023)]);_0x39c16d?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x265cb9&&_0x265cb9['accessToken'],this['appCheckToken_']=_0x154703&&_0x154703['token'],_0x105bc6=new Sh(_0x92dd9d,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x4bcad8,_0x414fa9,_0x414606,_0x43ca0f=>{U(_0x43ca0f+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x47386e));}catch(_0x24f0fa){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x24f0fa),_0x39c16d||(this['repoInfo_']['nodeAdmin']&&U(_0x24f0fa),_0x192fe2());}}}['interrupt'](_0x1c7a50){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x1c7a50),this['interruptReasons_'][_0x1c7a50]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x588835){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x588835),delete this['interruptReasons_'][_0x588835],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x53d412){const _0x38f45b=_0x53d412-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x38f45b});}['cancelSentTransactions_'](){for(let _0x28579f=0x0;_0x28579f<this['outstandingPuts_']['length'];_0x28579f++){const _0x17038e=this['outstandingPuts_'][_0x28579f];_0x17038e&&'h'in _0x17038e['request']&&_0x17038e['queued']&&(_0x17038e['onComplete']&&_0x17038e['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x28579f],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x4b0ea6,_0x59274f){let _0x202318;_0x59274f?_0x202318=_0x59274f['map'](_0x23d73a=>Hi(_0x23d73a))['join']('$'):_0x202318='default';const _0x5f2c8f=this['removeListen_'](_0x4b0ea6,_0x202318);_0x5f2c8f&&_0x5f2c8f['onComplete']&&_0x5f2c8f['onComplete']('permission_denied');}['removeListen_'](_0x3e08dc,_0x412ada){const _0x5eeea1=new C(_0x3e08dc)['toString']();let _0x1dc524;if(this['listens']['has'](_0x5eeea1)){const _0x3d5982=this['listens']['get'](_0x5eeea1);_0x1dc524=_0x3d5982['get'](_0x412ada),_0x3d5982['delete'](_0x412ada),_0x3d5982['size']===0x0&&this['listens']['delete'](_0x5eeea1);}else _0x1dc524=void 0x0;return _0x1dc524;}['onAuthRevoked_'](_0x341b04,_0x11275b){L('Auth\x20token\x20revoked:\x20'+_0x341b04+'/'+_0x11275b),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x341b04==='invalid_token'||_0x341b04==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x105e92,_0x29981b){L('App\x20check\x20token\x20revoked:\x20'+_0x105e92+'/'+_0x29981b),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x105e92==='invalid_token'||_0x105e92==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x246c27){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x246c27):'msg'in _0x246c27&&console['log']('FIREBASE:\x20'+_0x246c27['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x6c4a00 of this['listens']['values']())for(const _0x21c830 of _0x6c4a00['values']())this['sendListen_'](_0x21c830);for(let _0x1cf9e9=0x0;_0x1cf9e9<this['outstandingPuts_']['length'];_0x1cf9e9++)this['outstandingPuts_'][_0x1cf9e9]&&this['sendPut_'](_0x1cf9e9);for(;this['onDisconnectRequestQueue_']['length'];){const _0x27f182=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x27f182['action'],_0x27f182['pathString'],_0x27f182['data'],_0x27f182['onComplete']);}for(let _0x149c68=0x0;_0x149c68<this['outstandingGets_']['length'];_0x149c68++)this['outstandingGets_'][_0x149c68]&&this['sendGet_'](_0x149c68);}['sendConnectStats_'](){const _0x56e4ef={};let _0x101c5a='js';_0x56e4ef['sdk.'+_0x101c5a+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x56e4ef['framework.cordova']=0x1:Yr()&&(_0x56e4ef['framework.reactnative']=0x1),this['reportStats'](_0x56e4ef);}['shouldReconnect_'](){const _0x59ecf1=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x59ecf1;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x2a3877,_0x24782e){this['name']=_0x2a3877,this['node']=_0x24782e;}static['Wrap'](_0x149552,_0x31a519){return new E(_0x149552,_0x31a519);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x57e333,_0x3f3eed){const _0x2a4075=new E(Fe,_0x57e333),_0x53f54a=new E(Fe,_0x3f3eed);return this['compare'](_0x2a4075,_0x53f54a)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x165dd3){Zt=_0x165dd3;}['compare'](_0x3bdd4f,_0x456219){return He(_0x3bdd4f['name'],_0x456219['name']);}['isDefinedOn'](_0x2eaf8f){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x45147c,_0x41a0c5){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x26f440,_0x52b2c9){return f(typeof _0x26f440=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x26f440,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x43e83a,_0x386147,_0x39f03f,_0x1116e9,_0x99df1a=null){this['isReverse_']=_0x1116e9,this['resultGenerator_']=_0x99df1a,this['nodeStack_']=[];let _0x4c717c=0x1;for(;!_0x43e83a['isEmpty']();)if(_0x43e83a=_0x43e83a,_0x4c717c=_0x386147?_0x39f03f(_0x43e83a['key'],_0x386147):0x1,_0x1116e9&&(_0x4c717c*=-0x1),_0x4c717c<0x0)this['isReverse_']?_0x43e83a=_0x43e83a['left']:_0x43e83a=_0x43e83a['right'];else{if(_0x4c717c===0x0){this['nodeStack_']['push'](_0x43e83a);break;}else this['nodeStack_']['push'](_0x43e83a),this['isReverse_']?_0x43e83a=_0x43e83a['right']:_0x43e83a=_0x43e83a['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x8fb016=this['nodeStack_']['pop'](),_0x33dd62;if(this['resultGenerator_']?_0x33dd62=this['resultGenerator_'](_0x8fb016['key'],_0x8fb016['value']):_0x33dd62={'key':_0x8fb016['key'],'value':_0x8fb016['value']},this['isReverse_']){for(_0x8fb016=_0x8fb016['left'];!_0x8fb016['isEmpty']();)this['nodeStack_']['push'](_0x8fb016),_0x8fb016=_0x8fb016['right'];}else{for(_0x8fb016=_0x8fb016['right'];!_0x8fb016['isEmpty']();)this['nodeStack_']['push'](_0x8fb016),_0x8fb016=_0x8fb016['left'];}return _0x33dd62;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x2ac8ab=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x2ac8ab['key'],_0x2ac8ab['value']):{'key':_0x2ac8ab['key'],'value':_0x2ac8ab['value']};}}class M{constructor(_0x329db6,_0x4d1976,_0x47ae56,_0x1d94ff,_0x4ef444){this['key']=_0x329db6,this['value']=_0x4d1976,this['color']=_0x47ae56??M['RED'],this['left']=_0x1d94ff??B['EMPTY_NODE'],this['right']=_0x4ef444??B['EMPTY_NODE'];}['copy'](_0x2cc3a0,_0x1d378f,_0x90db98,_0x24f55d,_0x2b752e){return new M(_0x2cc3a0??this['key'],_0x1d378f??this['value'],_0x90db98??this['color'],_0x24f55d??this['left'],_0x2b752e??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x4e6b3c){return this['left']['inorderTraversal'](_0x4e6b3c)||!!_0x4e6b3c(this['key'],this['value'])||this['right']['inorderTraversal'](_0x4e6b3c);}['reverseTraversal'](_0x4495f2){return this['right']['reverseTraversal'](_0x4495f2)||_0x4495f2(this['key'],this['value'])||this['left']['reverseTraversal'](_0x4495f2);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x5628a8,_0x276281,_0x27300b){let _0x2204ef=this;const _0x1c6976=_0x27300b(_0x5628a8,_0x2204ef['key']);return _0x1c6976<0x0?_0x2204ef=_0x2204ef['copy'](null,null,null,_0x2204ef['left']['insert'](_0x5628a8,_0x276281,_0x27300b),null):_0x1c6976===0x0?_0x2204ef=_0x2204ef['copy'](null,_0x276281,null,null,null):_0x2204ef=_0x2204ef['copy'](null,null,null,null,_0x2204ef['right']['insert'](_0x5628a8,_0x276281,_0x27300b)),_0x2204ef['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x162028=this;return!_0x162028['left']['isRed_']()&&!_0x162028['left']['left']['isRed_']()&&(_0x162028=_0x162028['moveRedLeft_']()),_0x162028=_0x162028['copy'](null,null,null,_0x162028['left']['removeMin_'](),null),_0x162028['fixUp_']();}['remove'](_0x41a294,_0x1657fa){let _0x126275,_0x22a313;if(_0x126275=this,_0x1657fa(_0x41a294,_0x126275['key'])<0x0)!_0x126275['left']['isEmpty']()&&!_0x126275['left']['isRed_']()&&!_0x126275['left']['left']['isRed_']()&&(_0x126275=_0x126275['moveRedLeft_']()),_0x126275=_0x126275['copy'](null,null,null,_0x126275['left']['remove'](_0x41a294,_0x1657fa),null);else{if(_0x126275['left']['isRed_']()&&(_0x126275=_0x126275['rotateRight_']()),!_0x126275['right']['isEmpty']()&&!_0x126275['right']['isRed_']()&&!_0x126275['right']['left']['isRed_']()&&(_0x126275=_0x126275['moveRedRight_']()),_0x1657fa(_0x41a294,_0x126275['key'])===0x0){if(_0x126275['right']['isEmpty']())return B['EMPTY_NODE'];_0x22a313=_0x126275['right']['min_'](),_0x126275=_0x126275['copy'](_0x22a313['key'],_0x22a313['value'],null,null,_0x126275['right']['removeMin_']());}_0x126275=_0x126275['copy'](null,null,null,null,_0x126275['right']['remove'](_0x41a294,_0x1657fa));}return _0x126275['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x3ad8b7=this;return _0x3ad8b7['right']['isRed_']()&&!_0x3ad8b7['left']['isRed_']()&&(_0x3ad8b7=_0x3ad8b7['rotateLeft_']()),_0x3ad8b7['left']['isRed_']()&&_0x3ad8b7['left']['left']['isRed_']()&&(_0x3ad8b7=_0x3ad8b7['rotateRight_']()),_0x3ad8b7['left']['isRed_']()&&_0x3ad8b7['right']['isRed_']()&&(_0x3ad8b7=_0x3ad8b7['colorFlip_']()),_0x3ad8b7;}['moveRedLeft_'](){let _0x2cc327=this['colorFlip_']();return _0x2cc327['right']['left']['isRed_']()&&(_0x2cc327=_0x2cc327['copy'](null,null,null,null,_0x2cc327['right']['rotateRight_']()),_0x2cc327=_0x2cc327['rotateLeft_'](),_0x2cc327=_0x2cc327['colorFlip_']()),_0x2cc327;}['moveRedRight_'](){let _0x3c77df=this['colorFlip_']();return _0x3c77df['left']['left']['isRed_']()&&(_0x3c77df=_0x3c77df['rotateRight_'](),_0x3c77df=_0x3c77df['colorFlip_']()),_0x3c77df;}['rotateLeft_'](){const _0xeac0eb=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0xeac0eb,null);}['rotateRight_'](){const _0x1485f5=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x1485f5);}['colorFlip_'](){const _0x48c6ed=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x5af21f=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x48c6ed,_0x5af21f);}['checkMaxDepth_'](){const _0x27b2e2=this['check_']();return Math['pow'](0x2,_0x27b2e2)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x127787=this['left']['check_']();if(_0x127787!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x127787+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0xd2b384,_0x19ab58,_0x24d2e9,_0xcfb4d0,_0x1c4fe7){return this;}['insert'](_0x4724b5,_0x15b29b,_0x141448){return new M(_0x4724b5,_0x15b29b,null);}['remove'](_0x35695c,_0x1d9bb0){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x4f9870){return!0x1;}['reverseTraversal'](_0x34732c){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x971beb,_0x1b7c71=B['EMPTY_NODE']){this['comparator_']=_0x971beb,this['root_']=_0x1b7c71;}['insert'](_0x1bc7a6,_0x41d960){return new B(this['comparator_'],this['root_']['insert'](_0x1bc7a6,_0x41d960,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x4db603){return new B(this['comparator_'],this['root_']['remove'](_0x4db603,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x45576e){let _0x1f009d,_0x3d9a7a=this['root_'];for(;!_0x3d9a7a['isEmpty']();){if(_0x1f009d=this['comparator_'](_0x45576e,_0x3d9a7a['key']),_0x1f009d===0x0)return _0x3d9a7a['value'];_0x1f009d<0x0?_0x3d9a7a=_0x3d9a7a['left']:_0x1f009d>0x0&&(_0x3d9a7a=_0x3d9a7a['right']);}return null;}['getPredecessorKey'](_0xd2761c){let _0x30ccdd,_0x41dd2b=this['root_'],_0x46a148=null;for(;!_0x41dd2b['isEmpty']();)if(_0x30ccdd=this['comparator_'](_0xd2761c,_0x41dd2b['key']),_0x30ccdd===0x0){if(_0x41dd2b['left']['isEmpty']())return _0x46a148?_0x46a148['key']:null;for(_0x41dd2b=_0x41dd2b['left'];!_0x41dd2b['right']['isEmpty']();)_0x41dd2b=_0x41dd2b['right'];return _0x41dd2b['key'];}else _0x30ccdd<0x0?_0x41dd2b=_0x41dd2b['left']:_0x30ccdd>0x0&&(_0x46a148=_0x41dd2b,_0x41dd2b=_0x41dd2b['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x412864){return this['root_']['inorderTraversal'](_0x412864);}['reverseTraversal'](_0x30efc5){return this['root_']['reverseTraversal'](_0x30efc5);}['getIterator'](_0x288697){return new en(this['root_'],null,this['comparator_'],!0x1,_0x288697);}['getIteratorFrom'](_0x2ae674,_0x345c9f){return new en(this['root_'],_0x2ae674,this['comparator_'],!0x1,_0x345c9f);}['getReverseIteratorFrom'](_0x3dac2a,_0x42d358){return new en(this['root_'],_0x3dac2a,this['comparator_'],!0x0,_0x42d358);}['getReverseIterator'](_0x22cccf){return new en(this['root_'],null,this['comparator_'],!0x0,_0x22cccf);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x3695c2,_0x3bfc69){return He(_0x3695c2['name'],_0x3bfc69['name']);}function Yi(_0x469fe5,_0x5bd778){return He(_0x469fe5,_0x5bd778);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x316a37){Ei=_0x316a37;}const No=function(_0x69020f){return typeof _0x69020f=='number'?'number:'+ao(_0x69020f):'string:'+_0x69020f;},Po=function(_0x2ef8b7){if(_0x2ef8b7['isLeafNode']()){const _0x4e04a9=_0x2ef8b7['val']();f(typeof _0x4e04a9=='string'||typeof _0x4e04a9=='number'||typeof _0x4e04a9=='object'&&J(_0x4e04a9,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x2ef8b7===Ei||_0x2ef8b7['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x2ef8b7===Ei||_0x2ef8b7['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x177402){ir=_0x177402;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0xb93824,_0x4f50e0=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0xb93824,this['priorityNode_']=_0x4f50e0,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x7ebd41){return new D(this['value_'],_0x7ebd41);}['getImmediateChild'](_0x1f24ce){return _0x1f24ce==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x39f60c){return v(_0x39f60c)?this:y(_0x39f60c)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x26580c,_0x4af3d7){return null;}['updateImmediateChild'](_0x1fac10,_0x3e99ca){return _0x1fac10==='.priority'?this['updatePriority'](_0x3e99ca):_0x3e99ca['isEmpty']()&&_0x1fac10!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x1fac10,_0x3e99ca)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x478fbc,_0x5d8720){const _0x325462=y(_0x478fbc);return _0x325462===null?_0x5d8720:_0x5d8720['isEmpty']()&&_0x325462!=='.priority'?this:(f(_0x325462!=='.priority'||we(_0x478fbc)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x325462,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x478fbc),_0x5d8720)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x5da172,_0x4c172e){return!0x1;}['val'](_0x11ce55){return _0x11ce55&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x526ad4='';this['priorityNode_']['isEmpty']()||(_0x526ad4+='priority:'+No(this['priorityNode_']['val']())+':');const _0x2697a4=typeof this['value_'];_0x526ad4+=_0x2697a4+':',_0x2697a4==='number'?_0x526ad4+=ao(this['value_']):_0x526ad4+=this['value_'],this['lazyHash_']=ro(_0x526ad4);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x2b30e9){return _0x2b30e9===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x2b30e9 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x2b30e9['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x2b30e9));}['compareToLeafNode_'](_0x5ad049){const _0x352241=typeof _0x5ad049['value_'],_0x478055=typeof this['value_'],_0x5aec8=D['VALUE_TYPE_ORDER']['indexOf'](_0x352241),_0x1b507d=D['VALUE_TYPE_ORDER']['indexOf'](_0x478055);return f(_0x5aec8>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x352241),f(_0x1b507d>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x478055),_0x5aec8===_0x1b507d?_0x478055==='object'?0x0:this['value_']<_0x5ad049['value_']?-0x1:this['value_']===_0x5ad049['value_']?0x0:0x1:_0x1b507d-_0x5aec8;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0xba2493){if(_0xba2493===this)return!0x0;if(_0xba2493['isLeafNode']()){const _0x1b01a1=_0xba2493;return this['value_']===_0x1b01a1['value_']&&this['priorityNode_']['equals'](_0x1b01a1['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x538fc5){Oo=_0x538fc5;}function Wh(_0x4cb3bf){Do=_0x4cb3bf;}class Bh extends Dn{['compare'](_0x488a62,_0x1f94a7){const _0x545cf5=_0x488a62['node']['getPriority'](),_0x2bb261=_0x1f94a7['node']['getPriority'](),_0x3e84ef=_0x545cf5['compareTo'](_0x2bb261);return _0x3e84ef===0x0?He(_0x488a62['name'],_0x1f94a7['name']):_0x3e84ef;}['isDefinedOn'](_0x3f023e){return!_0x3f023e['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x154da2,_0xd4ac5a){return!_0x154da2['getPriority']()['equals'](_0xd4ac5a['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x3a2fc0,_0x15b2f0){const _0x4d5cae=Oo(_0x3a2fc0);return new E(_0x15b2f0,new D('[PRIORITY-POST]',_0x4d5cae));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x5b2ad9){const _0x18eeca=_0x25b160=>parseInt(Math['log'](_0x25b160)/Vh,0xa),_0x598502=_0x208184=>parseInt(Array(_0x208184+0x1)['join']('1'),0x2);this['count']=_0x18eeca(_0x5b2ad9+0x1),this['current_']=this['count']-0x1;const _0x1089c2=_0x598502(this['count']);this['bits_']=_0x5b2ad9+0x1&_0x1089c2;}['nextBitIsOne'](){const _0x556639=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x556639;}}const fn=function(_0x19f892,_0x1a17af,_0x4838bf,_0x567c74){_0x19f892['sort'](_0x1a17af);const _0x114c07=function(_0x6be61c,_0x584eb4){const _0x51e3e1=_0x584eb4-_0x6be61c;let _0x42b4ec,_0x1f9604;if(_0x51e3e1===0x0)return null;if(_0x51e3e1===0x1)return _0x42b4ec=_0x19f892[_0x6be61c],_0x1f9604=_0x4838bf?_0x4838bf(_0x42b4ec):_0x42b4ec,new M(_0x1f9604,_0x42b4ec['node'],M['BLACK'],null,null);{const _0x4f6139=parseInt(_0x51e3e1/0x2,0xa)+_0x6be61c,_0x1321f9=_0x114c07(_0x6be61c,_0x4f6139),_0x43b57d=_0x114c07(_0x4f6139+0x1,_0x584eb4);return _0x42b4ec=_0x19f892[_0x4f6139],_0x1f9604=_0x4838bf?_0x4838bf(_0x42b4ec):_0x42b4ec,new M(_0x1f9604,_0x42b4ec['node'],M['BLACK'],_0x1321f9,_0x43b57d);}},_0xa8c769=function(_0x476ec0){let _0x2035ca=null,_0x523a35=null,_0x267163=_0x19f892['length'];const _0x368ff4=function(_0x5a5547,_0x25ecc2){const _0x5bc1f9=_0x267163-_0x5a5547,_0x1f25dd=_0x267163;_0x267163-=_0x5a5547;const _0x329688=_0x114c07(_0x5bc1f9+0x1,_0x1f25dd),_0x6f17ad=_0x19f892[_0x5bc1f9],_0x68b4e4=_0x4838bf?_0x4838bf(_0x6f17ad):_0x6f17ad;_0x45f845(new M(_0x68b4e4,_0x6f17ad['node'],_0x25ecc2,null,_0x329688));},_0x45f845=function(_0x1fb6df){_0x2035ca?(_0x2035ca['left']=_0x1fb6df,_0x2035ca=_0x1fb6df):(_0x523a35=_0x1fb6df,_0x2035ca=_0x1fb6df);};for(let _0x25966d=0x0;_0x25966d<_0x476ec0['count'];++_0x25966d){const _0x586e0a=_0x476ec0['nextBitIsOne'](),_0x3bcbbe=Math['pow'](0x2,_0x476ec0['count']-(_0x25966d+0x1));_0x586e0a?_0x368ff4(_0x3bcbbe,M['BLACK']):(_0x368ff4(_0x3bcbbe,M['BLACK']),_0x368ff4(_0x3bcbbe,M['RED']));}return _0x523a35;},_0x3f557c=new Hh(_0x19f892['length']),_0x4f051d=_0xa8c769(_0x3f557c);return new B(_0x567c74||_0x1a17af,_0x4f051d);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x3553ba,_0x1bb0fb){this['indexes_']=_0x3553ba,this['indexSet_']=_0x1bb0fb;}['get'](_0x4933b2){const _0x485a76=De(this['indexes_'],_0x4933b2);if(!_0x485a76)throw new Error('No\x20index\x20defined\x20for\x20'+_0x4933b2);return _0x485a76 instanceof B?_0x485a76:null;}['hasIndex'](_0x277dba){return J(this['indexSet_'],_0x277dba['toString']());}['addIndex'](_0x52043a,_0x1ec70c){f(_0x52043a!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x301eb4=[];let _0x1742c2=!0x1;const _0x4b4d19=_0x1ec70c['getIterator'](E['Wrap']);let _0x3405bd=_0x4b4d19['getNext']();for(;_0x3405bd;)_0x1742c2=_0x1742c2||_0x52043a['isDefinedOn'](_0x3405bd['node']),_0x301eb4['push'](_0x3405bd),_0x3405bd=_0x4b4d19['getNext']();let _0x43ed72;_0x1742c2?_0x43ed72=fn(_0x301eb4,_0x52043a['getCompare']()):_0x43ed72=ze;const _0x3bc956=_0x52043a['toString'](),_0x5c46cc={...this['indexSet_']};_0x5c46cc[_0x3bc956]=_0x52043a;const _0x4bbee9={...this['indexes_']};return _0x4bbee9[_0x3bc956]=_0x43ed72,new te(_0x4bbee9,_0x5c46cc);}['addToIndexes'](_0x220de9,_0x13733d){const _0x1cc764=hn(this['indexes_'],(_0x30443e,_0x36b72a)=>{const _0x5dd6ee=De(this['indexSet_'],_0x36b72a);if(f(_0x5dd6ee,'Missing\x20index\x20implementation\x20for\x20'+_0x36b72a),_0x30443e===ze){if(_0x5dd6ee['isDefinedOn'](_0x220de9['node'])){const _0x3c60d6=[],_0x30aee6=_0x13733d['getIterator'](E['Wrap']);let _0x22dcf7=_0x30aee6['getNext']();for(;_0x22dcf7;)_0x22dcf7['name']!==_0x220de9['name']&&_0x3c60d6['push'](_0x22dcf7),_0x22dcf7=_0x30aee6['getNext']();return _0x3c60d6['push'](_0x220de9),fn(_0x3c60d6,_0x5dd6ee['getCompare']());}else return ze;}else{const _0x4643cf=_0x13733d['get'](_0x220de9['name']);let _0x2a15eb=_0x30443e;return _0x4643cf&&(_0x2a15eb=_0x2a15eb['remove'](new E(_0x220de9['name'],_0x4643cf))),_0x2a15eb['insert'](_0x220de9,_0x220de9['node']);}});return new te(_0x1cc764,this['indexSet_']);}['removeFromIndexes'](_0x4247e6,_0x5e50ba){const _0x55fe8c=hn(this['indexes_'],_0x45e951=>{if(_0x45e951===ze)return _0x45e951;{const _0x3b5a36=_0x5e50ba['get'](_0x4247e6['name']);return _0x3b5a36?_0x45e951['remove'](new E(_0x4247e6['name'],_0x3b5a36)):_0x45e951;}});return new te(_0x55fe8c,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x426adc,_0x52fa64,_0x51ae4b){this['children_']=_0x426adc,this['priorityNode_']=_0x52fa64,this['indexMap_']=_0x51ae4b,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x2e631c){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x2e631c,this['indexMap_']);}['getImmediateChild'](_0x163bae){if(_0x163bae==='.priority')return this['getPriority']();{const _0x57ed45=this['children_']['get'](_0x163bae);return _0x57ed45===null?mt:_0x57ed45;}}['getChild'](_0x46110f){const _0x4c1cf7=y(_0x46110f);return _0x4c1cf7===null?this:this['getImmediateChild'](_0x4c1cf7)['getChild'](b(_0x46110f));}['hasChild'](_0x28bf8d){return this['children_']['get'](_0x28bf8d)!==null;}['updateImmediateChild'](_0x2430a5,_0x54b03d){if(f(_0x54b03d,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x2430a5==='.priority')return this['updatePriority'](_0x54b03d);{const _0x172c02=new E(_0x2430a5,_0x54b03d);let _0x3eb471,_0x93a1a;_0x54b03d['isEmpty']()?(_0x3eb471=this['children_']['remove'](_0x2430a5),_0x93a1a=this['indexMap_']['removeFromIndexes'](_0x172c02,this['children_'])):(_0x3eb471=this['children_']['insert'](_0x2430a5,_0x54b03d),_0x93a1a=this['indexMap_']['addToIndexes'](_0x172c02,this['children_']));const _0x5403c6=_0x3eb471['isEmpty']()?mt:this['priorityNode_'];return new g(_0x3eb471,_0x5403c6,_0x93a1a);}}['updateChild'](_0x2f98e4,_0x25c394){const _0x10e39f=y(_0x2f98e4);if(_0x10e39f===null)return _0x25c394;{f(y(_0x2f98e4)!=='.priority'||we(_0x2f98e4)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x7e811c=this['getImmediateChild'](_0x10e39f)['updateChild'](b(_0x2f98e4),_0x25c394);return this['updateImmediateChild'](_0x10e39f,_0x7e811c);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x12dbad){if(this['isEmpty']())return null;const _0x338176={};let _0x1d314d=0x0,_0x578b83=0x0,_0x4cf493=!0x0;if(this['forEachChild'](R,(_0x2896a5,_0x442398)=>{_0x338176[_0x2896a5]=_0x442398['val'](_0x12dbad),_0x1d314d++,_0x4cf493&&g['INTEGER_REGEXP_']['test'](_0x2896a5)?_0x578b83=Math['max'](_0x578b83,Number(_0x2896a5)):_0x4cf493=!0x1;}),!_0x12dbad&&_0x4cf493&&_0x578b83<0x2*_0x1d314d){const _0x4d8688=[];for(const _0x4facd7 in _0x338176)_0x4d8688[_0x4facd7]=_0x338176[_0x4facd7];return _0x4d8688;}else return _0x12dbad&&!this['getPriority']()['isEmpty']()&&(_0x338176['.priority']=this['getPriority']()['val']()),_0x338176;}['hash'](){if(this['lazyHash_']===null){let _0x54f9c2='';this['getPriority']()['isEmpty']()||(_0x54f9c2+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x28f5bb,_0x565f4f)=>{const _0x50b800=_0x565f4f['hash']();_0x50b800!==''&&(_0x54f9c2+=':'+_0x28f5bb+':'+_0x50b800);}),this['lazyHash_']=_0x54f9c2===''?'':ro(_0x54f9c2);}return this['lazyHash_'];}['getPredecessorChildName'](_0x38240b,_0x2184d3,_0x174d46){const _0x399291=this['resolveIndex_'](_0x174d46);if(_0x399291){const _0x1574fd=_0x399291['getPredecessorKey'](new E(_0x38240b,_0x2184d3));return _0x1574fd?_0x1574fd['name']:null;}else return this['children_']['getPredecessorKey'](_0x38240b);}['getFirstChildName'](_0x3a0e5a){const _0x3d216e=this['resolveIndex_'](_0x3a0e5a);if(_0x3d216e){const _0x2371d9=_0x3d216e['minKey']();return _0x2371d9&&_0x2371d9['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x44f408){const _0x3cdcfe=this['getFirstChildName'](_0x44f408);return _0x3cdcfe?new E(_0x3cdcfe,this['children_']['get'](_0x3cdcfe)):null;}['getLastChildName'](_0x43d60a){const _0x318d37=this['resolveIndex_'](_0x43d60a);if(_0x318d37){const _0x210ee9=_0x318d37['maxKey']();return _0x210ee9&&_0x210ee9['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x5d9ca3){const _0x2caed6=this['getLastChildName'](_0x5d9ca3);return _0x2caed6?new E(_0x2caed6,this['children_']['get'](_0x2caed6)):null;}['forEachChild'](_0x56af29,_0x307660){const _0x2b2cb0=this['resolveIndex_'](_0x56af29);return _0x2b2cb0?_0x2b2cb0['inorderTraversal'](_0x21aac2=>_0x307660(_0x21aac2['name'],_0x21aac2['node'])):this['children_']['inorderTraversal'](_0x307660);}['getIterator'](_0x343bf0){return this['getIteratorFrom'](_0x343bf0['minPost'](),_0x343bf0);}['getIteratorFrom'](_0x58815e,_0x28158d){const _0x5ec8ec=this['resolveIndex_'](_0x28158d);if(_0x5ec8ec)return _0x5ec8ec['getIteratorFrom'](_0x58815e,_0x6e8a55=>_0x6e8a55);{const _0x8d16f1=this['children_']['getIteratorFrom'](_0x58815e['name'],E['Wrap']);let _0x608cc0=_0x8d16f1['peek']();for(;_0x608cc0!=null&&_0x28158d['compare'](_0x608cc0,_0x58815e)<0x0;)_0x8d16f1['getNext'](),_0x608cc0=_0x8d16f1['peek']();return _0x8d16f1;}}['getReverseIterator'](_0x16a889){return this['getReverseIteratorFrom'](_0x16a889['maxPost'](),_0x16a889);}['getReverseIteratorFrom'](_0x2c9b5e,_0xc33b2e){const _0x2bc574=this['resolveIndex_'](_0xc33b2e);if(_0x2bc574)return _0x2bc574['getReverseIteratorFrom'](_0x2c9b5e,_0x55a441=>_0x55a441);{const _0x1b3af4=this['children_']['getReverseIteratorFrom'](_0x2c9b5e['name'],E['Wrap']);let _0x2e9c21=_0x1b3af4['peek']();for(;_0x2e9c21!=null&&_0xc33b2e['compare'](_0x2e9c21,_0x2c9b5e)>0x0;)_0x1b3af4['getNext'](),_0x2e9c21=_0x1b3af4['peek']();return _0x1b3af4;}}['compareTo'](_0x47440d){return this['isEmpty']()?_0x47440d['isEmpty']()?0x0:-0x1:_0x47440d['isLeafNode']()||_0x47440d['isEmpty']()?0x1:_0x47440d===$t?-0x1:0x0;}['withIndex'](_0x138f15){if(_0x138f15===ye||this['indexMap_']['hasIndex'](_0x138f15))return this;{const _0xbe6516=this['indexMap_']['addIndex'](_0x138f15,this['children_']);return new g(this['children_'],this['priorityNode_'],_0xbe6516);}}['isIndexed'](_0x127316){return _0x127316===ye||this['indexMap_']['hasIndex'](_0x127316);}['equals'](_0x31deed){if(_0x31deed===this)return!0x0;if(_0x31deed['isLeafNode']())return!0x1;{const _0x512030=_0x31deed;if(this['getPriority']()['equals'](_0x512030['getPriority']())){if(this['children_']['count']()===_0x512030['children_']['count']()){const _0x3d4143=this['getIterator'](R),_0x1b0602=_0x512030['getIterator'](R);let _0x4acd8b=_0x3d4143['getNext'](),_0x52cdd1=_0x1b0602['getNext']();for(;_0x4acd8b&&_0x52cdd1;){if(_0x4acd8b['name']!==_0x52cdd1['name']||!_0x4acd8b['node']['equals'](_0x52cdd1['node']))return!0x1;_0x4acd8b=_0x3d4143['getNext'](),_0x52cdd1=_0x1b0602['getNext']();}return _0x4acd8b===null&&_0x52cdd1===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x4df5e6){return _0x4df5e6===ye?null:this['indexMap_']['get'](_0x4df5e6['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x412f9d){return _0x412f9d===this?0x0:0x1;}['equals'](_0x14263f){return _0x14263f===this;}['getPriority'](){return this;}['getImmediateChild'](_0x3c6488){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x2c4910,_0x5585c9=null){if(_0x2c4910===null)return g['EMPTY_NODE'];if(typeof _0x2c4910=='object'&&'.priority'in _0x2c4910&&(_0x5585c9=_0x2c4910['.priority']),f(_0x5585c9===null||typeof _0x5585c9=='string'||typeof _0x5585c9=='number'||typeof _0x5585c9=='object'&&'.sv'in _0x5585c9,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x5585c9),typeof _0x2c4910=='object'&&'.value'in _0x2c4910&&_0x2c4910['.value']!==null&&(_0x2c4910=_0x2c4910['.value']),typeof _0x2c4910!='object'||'.sv'in _0x2c4910){const _0xfb20b5=_0x2c4910;return new D(_0xfb20b5,P(_0x5585c9));}if(!(_0x2c4910 instanceof Array)&&Gh){const _0x477072=[];let _0x1210c9=!0x1;if(x(_0x2c4910,(_0x4fbf12,_0x1035f0)=>{if(_0x4fbf12['substring'](0x0,0x1)!=='.'){const _0x4f262a=P(_0x1035f0);_0x4f262a['isEmpty']()||(_0x1210c9=_0x1210c9||!_0x4f262a['getPriority']()['isEmpty'](),_0x477072['push'](new E(_0x4fbf12,_0x4f262a)));}}),_0x477072['length']===0x0)return g['EMPTY_NODE'];const _0x41ba13=fn(_0x477072,xh,_0x41eb4d=>_0x41eb4d['name'],Yi);if(_0x1210c9){const _0x4233d0=fn(_0x477072,R['getCompare']());return new g(_0x41ba13,P(_0x5585c9),new te({'.priority':_0x4233d0},{'.priority':R}));}else return new g(_0x41ba13,P(_0x5585c9),te['Default']);}else{let _0x4e8d7e=g['EMPTY_NODE'];return x(_0x2c4910,(_0x3c3a85,_0x5d09e0)=>{if(J(_0x2c4910,_0x3c3a85)&&_0x3c3a85['substring'](0x0,0x1)!=='.'){const _0x29cbc7=P(_0x5d09e0);(_0x29cbc7['isLeafNode']()||!_0x29cbc7['isEmpty']())&&(_0x4e8d7e=_0x4e8d7e['updateImmediateChild'](_0x3c3a85,_0x29cbc7));}}),_0x4e8d7e['updatePriority'](P(_0x5585c9));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x3e2193){super(),this['indexPath_']=_0x3e2193,f(!v(_0x3e2193)&&y(_0x3e2193)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x48c99a){return _0x48c99a['getChild'](this['indexPath_']);}['isDefinedOn'](_0x24108c){return!_0x24108c['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x4602bd,_0x512d9e){const _0x3acd19=this['extractChild'](_0x4602bd['node']),_0x559d6c=this['extractChild'](_0x512d9e['node']),_0xaa27a9=_0x3acd19['compareTo'](_0x559d6c);return _0xaa27a9===0x0?He(_0x4602bd['name'],_0x512d9e['name']):_0xaa27a9;}['makePost'](_0x16fa78,_0x2fd139){const _0x439451=P(_0x16fa78),_0x2dbd66=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x439451);return new E(_0x2fd139,_0x2dbd66);}['maxPost'](){const _0x40b74f=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x40b74f);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x43afbf,_0x105560){const _0x5ba324=_0x43afbf['node']['compareTo'](_0x105560['node']);return _0x5ba324===0x0?He(_0x43afbf['name'],_0x105560['name']):_0x5ba324;}['isDefinedOn'](_0x4cc014){return!0x0;}['indexedValueChanged'](_0x392d29,_0x4d3f9f){return!_0x392d29['equals'](_0x4d3f9f);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x248074,_0x473c28){const _0x446778=P(_0x248074);return new E(_0x473c28,_0x446778);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x4279d4){return{'type':'value','snapshotNode':_0x4279d4};}function et(_0x36e38a,_0x337692){return{'type':'child_added','snapshotNode':_0x337692,'childName':_0x36e38a};}function Ot(_0x4c7aab,_0xafd270){return{'type':'child_removed','snapshotNode':_0xafd270,'childName':_0x4c7aab};}function Dt(_0xf706c2,_0x4a2ece,_0x41da88){return{'type':'child_changed','snapshotNode':_0x4a2ece,'childName':_0xf706c2,'oldSnap':_0x41da88};}function zh(_0x54632c,_0x14b5fb){return{'type':'child_moved','snapshotNode':_0x14b5fb,'childName':_0x54632c};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x3daad9){this['index_']=_0x3daad9;}['updateChild'](_0x2e0ac8,_0x37dc89,_0x354a5e,_0x22706b,_0x43c247,_0x531756){f(_0x2e0ac8['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x59c908=_0x2e0ac8['getImmediateChild'](_0x37dc89);return _0x59c908['getChild'](_0x22706b)['equals'](_0x354a5e['getChild'](_0x22706b))&&_0x59c908['isEmpty']()===_0x354a5e['isEmpty']()||(_0x531756!=null&&(_0x354a5e['isEmpty']()?_0x2e0ac8['hasChild'](_0x37dc89)?_0x531756['trackChildChange'](Ot(_0x37dc89,_0x59c908)):f(_0x2e0ac8['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x59c908['isEmpty']()?_0x531756['trackChildChange'](et(_0x37dc89,_0x354a5e)):_0x531756['trackChildChange'](Dt(_0x37dc89,_0x354a5e,_0x59c908))),_0x2e0ac8['isLeafNode']()&&_0x354a5e['isEmpty']())?_0x2e0ac8:_0x2e0ac8['updateImmediateChild'](_0x37dc89,_0x354a5e)['withIndex'](this['index_']);}['updateFullNode'](_0x3b40d1,_0x3b2706,_0x4adf59){return _0x4adf59!=null&&(_0x3b40d1['isLeafNode']()||_0x3b40d1['forEachChild'](R,(_0x12851e,_0x43f25c)=>{_0x3b2706['hasChild'](_0x12851e)||_0x4adf59['trackChildChange'](Ot(_0x12851e,_0x43f25c));}),_0x3b2706['isLeafNode']()||_0x3b2706['forEachChild'](R,(_0x19c7ee,_0x538bd0)=>{if(_0x3b40d1['hasChild'](_0x19c7ee)){const _0x169a8c=_0x3b40d1['getImmediateChild'](_0x19c7ee);_0x169a8c['equals'](_0x538bd0)||_0x4adf59['trackChildChange'](Dt(_0x19c7ee,_0x538bd0,_0x169a8c));}else _0x4adf59['trackChildChange'](et(_0x19c7ee,_0x538bd0));})),_0x3b2706['withIndex'](this['index_']);}['updatePriority'](_0x1a0cb2,_0x2ae93b){return _0x1a0cb2['isEmpty']()?g['EMPTY_NODE']:_0x1a0cb2['updatePriority'](_0x2ae93b);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0xd2916c){this['indexedFilter_']=new Ji(_0xd2916c['getIndex']()),this['index_']=_0xd2916c['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0xd2916c),this['endPost_']=Mt['getEndPost_'](_0xd2916c),this['startIsInclusive_']=!_0xd2916c['startAfterSet_'],this['endIsInclusive_']=!_0xd2916c['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0xc069ae){const _0x533a31=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0xc069ae)<=0x0:this['index_']['compare'](this['getStartPost'](),_0xc069ae)<0x0,_0x317310=this['endIsInclusive_']?this['index_']['compare'](_0xc069ae,this['getEndPost']())<=0x0:this['index_']['compare'](_0xc069ae,this['getEndPost']())<0x0;return _0x533a31&&_0x317310;}['updateChild'](_0x268524,_0x9ae4a9,_0x1b0807,_0x1629de,_0xebecf6,_0x69657c){return this['matches'](new E(_0x9ae4a9,_0x1b0807))||(_0x1b0807=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x268524,_0x9ae4a9,_0x1b0807,_0x1629de,_0xebecf6,_0x69657c);}['updateFullNode'](_0x1efa2a,_0x10a66a,_0x5bd802){_0x10a66a['isLeafNode']()&&(_0x10a66a=g['EMPTY_NODE']);let _0x1ee3b4=_0x10a66a['withIndex'](this['index_']);_0x1ee3b4=_0x1ee3b4['updatePriority'](g['EMPTY_NODE']);const _0x5a4f4d=this;return _0x10a66a['forEachChild'](R,(_0x25412b,_0x6bccd8)=>{_0x5a4f4d['matches'](new E(_0x25412b,_0x6bccd8))||(_0x1ee3b4=_0x1ee3b4['updateImmediateChild'](_0x25412b,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1efa2a,_0x1ee3b4,_0x5bd802);}['updatePriority'](_0x157098,_0x3393c4){return _0x157098;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0xc1b4e){if(_0xc1b4e['hasStart']()){const _0x491262=_0xc1b4e['getIndexStartName']();return _0xc1b4e['getIndex']()['makePost'](_0xc1b4e['getIndexStartValue'](),_0x491262);}else return _0xc1b4e['getIndex']()['minPost']();}static['getEndPost_'](_0x5657fc){if(_0x5657fc['hasEnd']()){const _0x49e29a=_0x5657fc['getIndexEndName']();return _0x5657fc['getIndex']()['makePost'](_0x5657fc['getIndexEndValue'](),_0x49e29a);}else return _0x5657fc['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x437de0){this['withinDirectionalStart']=_0x25baa4=>this['reverse_']?this['withinEndPost'](_0x25baa4):this['withinStartPost'](_0x25baa4),this['withinDirectionalEnd']=_0xb3ee5c=>this['reverse_']?this['withinStartPost'](_0xb3ee5c):this['withinEndPost'](_0xb3ee5c),this['withinStartPost']=_0x33f76e=>{const _0x31f751=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x33f76e);return this['startIsInclusive_']?_0x31f751<=0x0:_0x31f751<0x0;},this['withinEndPost']=_0x18eea5=>{const _0x3b8906=this['index_']['compare'](_0x18eea5,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x3b8906<=0x0:_0x3b8906<0x0;},this['rangedFilter_']=new Mt(_0x437de0),this['index_']=_0x437de0['getIndex'](),this['limit_']=_0x437de0['getLimit'](),this['reverse_']=!_0x437de0['isViewFromLeft'](),this['startIsInclusive_']=!_0x437de0['startAfterSet_'],this['endIsInclusive_']=!_0x437de0['endBeforeSet_'];}['updateChild'](_0x3b3d4b,_0x146e71,_0x13d06d,_0x52ca28,_0x548cf4,_0x426468){return this['rangedFilter_']['matches'](new E(_0x146e71,_0x13d06d))||(_0x13d06d=g['EMPTY_NODE']),_0x3b3d4b['getImmediateChild'](_0x146e71)['equals'](_0x13d06d)?_0x3b3d4b:_0x3b3d4b['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x3b3d4b,_0x146e71,_0x13d06d,_0x52ca28,_0x548cf4,_0x426468):this['fullLimitUpdateChild_'](_0x3b3d4b,_0x146e71,_0x13d06d,_0x548cf4,_0x426468);}['updateFullNode'](_0x3e2ae5,_0x2e7a65,_0xc3c705){let _0xf32aa9;if(_0x2e7a65['isLeafNode']()||_0x2e7a65['isEmpty']())_0xf32aa9=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x2e7a65['numChildren']()&&_0x2e7a65['isIndexed'](this['index_'])){_0xf32aa9=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x22a0b3;this['reverse_']?_0x22a0b3=_0x2e7a65['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x22a0b3=_0x2e7a65['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x5aec82=0x0;for(;_0x22a0b3['hasNext']()&&_0x5aec82<this['limit_'];){const _0x317985=_0x22a0b3['getNext']();if(this['withinDirectionalStart'](_0x317985)){if(this['withinDirectionalEnd'](_0x317985))_0xf32aa9=_0xf32aa9['updateImmediateChild'](_0x317985['name'],_0x317985['node']),_0x5aec82++;else break;}else continue;}}else{_0xf32aa9=_0x2e7a65['withIndex'](this['index_']),_0xf32aa9=_0xf32aa9['updatePriority'](g['EMPTY_NODE']);let _0x386404;this['reverse_']?_0x386404=_0xf32aa9['getReverseIterator'](this['index_']):_0x386404=_0xf32aa9['getIterator'](this['index_']);let _0x9dddef=0x0;for(;_0x386404['hasNext']();){const _0xa1a336=_0x386404['getNext']();_0x9dddef<this['limit_']&&this['withinDirectionalStart'](_0xa1a336)&&this['withinDirectionalEnd'](_0xa1a336)?_0x9dddef++:_0xf32aa9=_0xf32aa9['updateImmediateChild'](_0xa1a336['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x3e2ae5,_0xf32aa9,_0xc3c705);}['updatePriority'](_0x3c37ff,_0xcc5d39){return _0x3c37ff;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x525d9d,_0xe1c933,_0x4cb79b,_0x25dfb0,_0x1ea658){let _0x120a9f;if(this['reverse_']){const _0x36eab8=this['index_']['getCompare']();_0x120a9f=(_0x4a66d6,_0x336729)=>_0x36eab8(_0x336729,_0x4a66d6);}else _0x120a9f=this['index_']['getCompare']();const _0x31034c=_0x525d9d;f(_0x31034c['numChildren']()===this['limit_'],'');const _0x4041d4=new E(_0xe1c933,_0x4cb79b),_0x5bda88=this['reverse_']?_0x31034c['getFirstChild'](this['index_']):_0x31034c['getLastChild'](this['index_']),_0x1d2e66=this['rangedFilter_']['matches'](_0x4041d4);if(_0x31034c['hasChild'](_0xe1c933)){const _0x3424d0=_0x31034c['getImmediateChild'](_0xe1c933);let _0x2727c5=_0x25dfb0['getChildAfterChild'](this['index_'],_0x5bda88,this['reverse_']);for(;_0x2727c5!=null&&(_0x2727c5['name']===_0xe1c933||_0x31034c['hasChild'](_0x2727c5['name']));)_0x2727c5=_0x25dfb0['getChildAfterChild'](this['index_'],_0x2727c5,this['reverse_']);const _0x2a074d=_0x2727c5==null?0x1:_0x120a9f(_0x2727c5,_0x4041d4);if(_0x1d2e66&&!_0x4cb79b['isEmpty']()&&_0x2a074d>=0x0)return _0x1ea658!=null&&_0x1ea658['trackChildChange'](Dt(_0xe1c933,_0x4cb79b,_0x3424d0)),_0x31034c['updateImmediateChild'](_0xe1c933,_0x4cb79b);{_0x1ea658!=null&&_0x1ea658['trackChildChange'](Ot(_0xe1c933,_0x3424d0));const _0x425285=_0x31034c['updateImmediateChild'](_0xe1c933,g['EMPTY_NODE']);return _0x2727c5!=null&&this['rangedFilter_']['matches'](_0x2727c5)?(_0x1ea658!=null&&_0x1ea658['trackChildChange'](et(_0x2727c5['name'],_0x2727c5['node'])),_0x425285['updateImmediateChild'](_0x2727c5['name'],_0x2727c5['node'])):_0x425285;}}else return _0x4cb79b['isEmpty']()?_0x525d9d:_0x1d2e66&&_0x120a9f(_0x5bda88,_0x4041d4)>=0x0?(_0x1ea658!=null&&(_0x1ea658['trackChildChange'](Ot(_0x5bda88['name'],_0x5bda88['node'])),_0x1ea658['trackChildChange'](et(_0xe1c933,_0x4cb79b))),_0x31034c['updateImmediateChild'](_0xe1c933,_0x4cb79b)['updateImmediateChild'](_0x5bda88['name'],g['EMPTY_NODE'])):_0x525d9d;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x24c863=new Xi();return _0x24c863['limitSet_']=this['limitSet_'],_0x24c863['limit_']=this['limit_'],_0x24c863['startSet_']=this['startSet_'],_0x24c863['startAfterSet_']=this['startAfterSet_'],_0x24c863['indexStartValue_']=this['indexStartValue_'],_0x24c863['startNameSet_']=this['startNameSet_'],_0x24c863['indexStartName_']=this['indexStartName_'],_0x24c863['endSet_']=this['endSet_'],_0x24c863['endBeforeSet_']=this['endBeforeSet_'],_0x24c863['indexEndValue_']=this['indexEndValue_'],_0x24c863['endNameSet_']=this['endNameSet_'],_0x24c863['indexEndName_']=this['indexEndName_'],_0x24c863['index_']=this['index_'],_0x24c863['viewFrom_']=this['viewFrom_'],_0x24c863;}}function Kh(_0x2a86de){return _0x2a86de['loadsAllData']()?new Ji(_0x2a86de['getIndex']()):_0x2a86de['hasLimit']()?new jh(_0x2a86de):new Mt(_0x2a86de);}function Yh(_0x3a40ab,_0x5be5d0){const _0x5cccab=_0x3a40ab['copy']();return _0x5cccab['limitSet_']=!0x0,_0x5cccab['limit_']=_0x5be5d0,_0x5cccab['viewFrom_']='l',_0x5cccab;}function Qh(_0x3121d5,_0x2178bc,_0x264168){const _0x23743a=_0x3121d5['copy']();return _0x23743a['startSet_']=!0x0,_0x2178bc===void 0x0&&(_0x2178bc=null),_0x23743a['indexStartValue_']=_0x2178bc,_0x264168!=null?(_0x23743a['startNameSet_']=!0x0,_0x23743a['indexStartName_']=_0x264168):(_0x23743a['startNameSet_']=!0x1,_0x23743a['indexStartName_']=''),_0x23743a;}function Jh(_0x1efa37,_0x2efd0d,_0x22c1d5){const _0x4a076c=_0x1efa37['copy']();return _0x4a076c['endSet_']=!0x0,_0x2efd0d===void 0x0&&(_0x2efd0d=null),_0x4a076c['indexEndValue_']=_0x2efd0d,_0x22c1d5!==void 0x0?(_0x4a076c['endNameSet_']=!0x0,_0x4a076c['indexEndName_']=_0x22c1d5):(_0x4a076c['endNameSet_']=!0x1,_0x4a076c['indexEndName_']=''),_0x4a076c;}function xo(_0x2e359e,_0xd3a00e){const _0x58420a=_0x2e359e['copy']();return _0x58420a['index_']=_0xd3a00e,_0x58420a;}function sr(_0x1ac98b){const _0x14da66={};if(_0x1ac98b['isDefault']())return _0x14da66;let _0x36dc49;if(_0x1ac98b['index_']===R?_0x36dc49='$priority':_0x1ac98b['index_']===Mo?_0x36dc49='$value':_0x1ac98b['index_']===ye?_0x36dc49='$key':(f(_0x1ac98b['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x36dc49=_0x1ac98b['index_']['toString']()),_0x14da66['orderBy']=O(_0x36dc49),_0x1ac98b['startSet_']){const _0x5cdfc8=_0x1ac98b['startAfterSet_']?'startAfter':'startAt';_0x14da66[_0x5cdfc8]=O(_0x1ac98b['indexStartValue_']),_0x1ac98b['startNameSet_']&&(_0x14da66[_0x5cdfc8]+=','+O(_0x1ac98b['indexStartName_']));}if(_0x1ac98b['endSet_']){const _0x41892a=_0x1ac98b['endBeforeSet_']?'endBefore':'endAt';_0x14da66[_0x41892a]=O(_0x1ac98b['indexEndValue_']),_0x1ac98b['endNameSet_']&&(_0x14da66[_0x41892a]+=','+O(_0x1ac98b['indexEndName_']));}return _0x1ac98b['limitSet_']&&(_0x1ac98b['isViewFromLeft']()?_0x14da66['limitToFirst']=_0x1ac98b['limit_']:_0x14da66['limitToLast']=_0x1ac98b['limit_']),_0x14da66;}function rr(_0x3f7a09){const _0x543f38={};if(_0x3f7a09['startSet_']&&(_0x543f38['sp']=_0x3f7a09['indexStartValue_'],_0x3f7a09['startNameSet_']&&(_0x543f38['sn']=_0x3f7a09['indexStartName_']),_0x543f38['sin']=!_0x3f7a09['startAfterSet_']),_0x3f7a09['endSet_']&&(_0x543f38['ep']=_0x3f7a09['indexEndValue_'],_0x3f7a09['endNameSet_']&&(_0x543f38['en']=_0x3f7a09['indexEndName_']),_0x543f38['ein']=!_0x3f7a09['endBeforeSet_']),_0x3f7a09['limitSet_']){_0x543f38['l']=_0x3f7a09['limit_'];let _0x2b6be5=_0x3f7a09['viewFrom_'];_0x2b6be5===''&&(_0x3f7a09['isViewFromLeft']()?_0x2b6be5='l':_0x2b6be5='r'),_0x543f38['vf']=_0x2b6be5;}return _0x3f7a09['index_']!==R&&(_0x543f38['i']=_0x3f7a09['index_']['toString']()),_0x543f38;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x3040be){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x10df5d,_0x1a8ca8){return _0x1a8ca8!==void 0x0?'tag$'+_0x1a8ca8:(f(_0x10df5d['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x10df5d['_path']['toString']());}constructor(_0x58873c,_0x9689a3,_0x526df4,_0x47c81c){super(),this['repoInfo_']=_0x58873c,this['onDataUpdate_']=_0x9689a3,this['authTokenProvider_']=_0x526df4,this['appCheckTokenProvider_']=_0x47c81c,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x435453,_0x137eb1,_0x423243,_0x1c0b44){const _0x251408=_0x435453['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x251408+'\x20'+_0x435453['_queryIdentifier']);const _0x34d9c3=pn['getListenId_'](_0x435453,_0x423243),_0x348b6d={};this['listens_'][_0x34d9c3]=_0x348b6d;const _0xa4817e=sr(_0x435453['_queryParams']);this['restRequest_'](_0x251408+'.json',_0xa4817e,(_0x143e89,_0x5b54e0)=>{let _0x23ec1b=_0x5b54e0;if(_0x143e89===0x194&&(_0x23ec1b=null,_0x143e89=null),_0x143e89===null&&this['onDataUpdate_'](_0x251408,_0x23ec1b,!0x1,_0x423243),De(this['listens_'],_0x34d9c3)===_0x348b6d){let _0x5a1518;_0x143e89?_0x143e89===0x191?_0x5a1518='permission_denied':_0x5a1518='rest_error:'+_0x143e89:_0x5a1518='ok',_0x1c0b44(_0x5a1518,null);}});}['unlisten'](_0x31b355,_0x4300cd){const _0x5b0878=pn['getListenId_'](_0x31b355,_0x4300cd);delete this['listens_'][_0x5b0878];}['get'](_0x2744bc){const _0x2d2325=sr(_0x2744bc['_queryParams']),_0x51a710=_0x2744bc['_path']['toString'](),_0x31ffd3=new ot();return this['restRequest_'](_0x51a710+'.json',_0x2d2325,(_0x1caae6,_0x140b3)=>{let _0xc26989=_0x140b3;_0x1caae6===0x194&&(_0xc26989=null,_0x1caae6=null),_0x1caae6===null?(this['onDataUpdate_'](_0x51a710,_0xc26989,!0x1,null),_0x31ffd3['resolve'](_0xc26989)):_0x31ffd3['reject'](new Error(_0xc26989));}),_0x31ffd3['promise'];}['refreshAuthToken'](_0x1134ba){}['restRequest_'](_0x500bb4,_0xfaec0={},_0x56eec9){return _0xfaec0['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x1e53de,_0x37353c])=>{_0x1e53de&&_0x1e53de['accessToken']&&(_0xfaec0['auth']=_0x1e53de['accessToken']),_0x37353c&&_0x37353c['token']&&(_0xfaec0['ac']=_0x37353c['token']);const _0x19bc35=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x500bb4+'?ns='+this['repoInfo_']['namespace']+ct(_0xfaec0);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x19bc35);const _0x583b70=new XMLHttpRequest();_0x583b70['onreadystatechange']=()=>{if(_0x56eec9&&_0x583b70['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x19bc35+'\x20received.\x20status:',_0x583b70['status'],'response:',_0x583b70['responseText']);let _0x2bd4fd=null;if(_0x583b70['status']>=0xc8&&_0x583b70['status']<0x12c){try{_0x2bd4fd=At(_0x583b70['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x19bc35+':\x20'+_0x583b70['responseText']);}_0x56eec9(null,_0x2bd4fd);}else _0x583b70['status']!==0x191&&_0x583b70['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x19bc35+'\x20Status:\x20'+_0x583b70['status']),_0x56eec9(_0x583b70['status']);_0x56eec9=null;}},_0x583b70['open']('GET',_0x19bc35,!0x0),_0x583b70['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x2afef6){return this['rootNode_']['getChild'](_0x2afef6);}['updateSnapshot'](_0x149681,_0xa4e3e8){this['rootNode_']=this['rootNode_']['updateChild'](_0x149681,_0xa4e3e8);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x223597,_0x2b069f,_0x48a615){if(v(_0x2b069f))_0x223597['value']=_0x48a615,_0x223597['children']['clear']();else{if(_0x223597['value']!==null)_0x223597['value']=_0x223597['value']['updateChild'](_0x2b069f,_0x48a615);else{const _0x5a8054=y(_0x2b069f);_0x223597['children']['has'](_0x5a8054)||_0x223597['children']['set'](_0x5a8054,_n());const _0x440847=_0x223597['children']['get'](_0x5a8054);_0x2b069f=b(_0x2b069f),Fo(_0x440847,_0x2b069f,_0x48a615);}}}function Ii(_0xfcde3d,_0x22a43e,_0x26586f){_0xfcde3d['value']!==null?_0x26586f(_0x22a43e,_0xfcde3d['value']):Zh(_0xfcde3d,(_0x1c6ed6,_0x2ee283)=>{const _0x13d49f=new C(_0x22a43e['toString']()+'/'+_0x1c6ed6);Ii(_0x2ee283,_0x13d49f,_0x26586f);});}function Zh(_0xe995d0,_0xb27e7b){_0xe995d0['children']['forEach']((_0x598600,_0x5d8ed9)=>{_0xb27e7b(_0x5d8ed9,_0x598600);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x139602){this['collection_']=_0x139602,this['last_']=null;}['get'](){const _0x2ada38=this['collection_']['get'](),_0xaf3812={..._0x2ada38};return this['last_']&&x(this['last_'],(_0x2b1b4f,_0x47693a)=>{_0xaf3812[_0x2b1b4f]=_0xaf3812[_0x2b1b4f]-_0x47693a;}),this['last_']=_0x2ada38,_0xaf3812;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x564387,_0x30bf3f){this['server_']=_0x30bf3f,this['statsToReport_']={},this['statsListener_']=new eu(_0x564387);const _0x50a26d=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x50a26d));}['reportStats_'](){const _0x763bb1=this['statsListener_']['get'](),_0x11b90b={};let _0x452e8b=!0x1;x(_0x763bb1,(_0x18a39e,_0x44e20a)=>{_0x44e20a>0x0&&J(this['statsToReport_'],_0x18a39e)&&(_0x11b90b[_0x18a39e]=_0x44e20a,_0x452e8b=!0x0);}),_0x452e8b&&this['server_']['reportStats'](_0x11b90b),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x49e467){_0x49e467[_0x49e467['OVERWRITE']=0x0]='OVERWRITE',_0x49e467[_0x49e467['MERGE']=0x1]='MERGE',_0x49e467[_0x49e467['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x49e467[_0x49e467['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x19a14a){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x19a14a,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x1ff4b3,_0x5bbce1,_0x1c8c5d){this['path']=_0x1ff4b3,this['affectedTree']=_0x5bbce1,this['revert']=_0x1c8c5d,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x2b4154){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x3ade25=this['affectedTree']['subtree'](new C(_0x2b4154));return new gn(w(),_0x3ade25,this['revert']);}}else return f(y(this['path'])===_0x2b4154,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x21511d,_0x7f961d){this['source']=_0x21511d,this['path']=_0x7f961d,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x180de2){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x5aa954,_0x2785db,_0xa78a67){this['source']=_0x5aa954,this['path']=_0x2785db,this['snap']=_0xa78a67,this['type']=j['OVERWRITE'];}['operationForChild'](_0xdc688d){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0xdc688d)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x10b16d,_0x67539a,_0x4071ad){this['source']=_0x10b16d,this['path']=_0x67539a,this['children']=_0x4071ad,this['type']=j['MERGE'];}['operationForChild'](_0x46aaa8){if(v(this['path'])){const _0x343177=this['children']['subtree'](new C(_0x46aaa8));return _0x343177['isEmpty']()?null:_0x343177['value']?new Ue(this['source'],w(),_0x343177['value']):new tt(this['source'],w(),_0x343177);}else return f(y(this['path'])===_0x46aaa8,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x50d245,_0x247cc9,_0x6f2497){this['node_']=_0x50d245,this['fullyInitialized_']=_0x247cc9,this['filtered_']=_0x6f2497;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x4868c3){if(v(_0x4868c3))return this['isFullyInitialized']()&&!this['filtered_'];const _0x5be7e1=y(_0x4868c3);return this['isCompleteForChild'](_0x5be7e1);}['isCompleteForChild'](_0x32c743){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x32c743);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x22da0e){this['query_']=_0x22da0e,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x55593c,_0x29a933,_0x11c184,_0x57a972){const _0x198428=[],_0x3de055=[];return _0x29a933['forEach'](_0x36409c=>{_0x36409c['type']==='child_changed'&&_0x55593c['index_']['indexedValueChanged'](_0x36409c['oldSnap'],_0x36409c['snapshotNode'])&&_0x3de055['push'](zh(_0x36409c['childName'],_0x36409c['snapshotNode']));}),yt(_0x55593c,_0x198428,'child_removed',_0x29a933,_0x57a972,_0x11c184),yt(_0x55593c,_0x198428,'child_added',_0x29a933,_0x57a972,_0x11c184),yt(_0x55593c,_0x198428,'child_moved',_0x3de055,_0x57a972,_0x11c184),yt(_0x55593c,_0x198428,'child_changed',_0x29a933,_0x57a972,_0x11c184),yt(_0x55593c,_0x198428,'value',_0x29a933,_0x57a972,_0x11c184),_0x198428;}function yt(_0x3bb0ce,_0x7ebf91,_0x1505ea,_0x5af3dd,_0xd23acd,_0x876c75){const _0x52a1a4=_0x5af3dd['filter'](_0x17c587=>_0x17c587['type']===_0x1505ea);_0x52a1a4['sort']((_0x40fb74,_0x4983be)=>au(_0x3bb0ce,_0x40fb74,_0x4983be)),_0x52a1a4['forEach'](_0x131e7e=>{const _0x1fda0a=ou(_0x3bb0ce,_0x131e7e,_0x876c75);_0xd23acd['forEach'](_0x448e1a=>{_0x448e1a['respondsTo'](_0x131e7e['type'])&&_0x7ebf91['push'](_0x448e1a['createEvent'](_0x1fda0a,_0x3bb0ce['query_']));});});}function ou(_0x13c15c,_0x1e8f6c,_0x23c6bc){return _0x1e8f6c['type']==='value'||_0x1e8f6c['type']==='child_removed'||(_0x1e8f6c['prevName']=_0x23c6bc['getPredecessorChildName'](_0x1e8f6c['childName'],_0x1e8f6c['snapshotNode'],_0x13c15c['index_'])),_0x1e8f6c;}function au(_0x19afd6,_0x1ad84a,_0x54b1a9){if(_0x1ad84a['childName']==null||_0x54b1a9['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x2d4876=new E(_0x1ad84a['childName'],_0x1ad84a['snapshotNode']),_0x7a585f=new E(_0x54b1a9['childName'],_0x54b1a9['snapshotNode']);return _0x19afd6['index_']['compare'](_0x2d4876,_0x7a585f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x370e8a,_0x58da30){return{'eventCache':_0x370e8a,'serverCache':_0x58da30};}function Tt(_0x4c4234,_0x4acd98,_0xda19db,_0x5649ab){return Mn(new Ce(_0x4acd98,_0xda19db,_0x5649ab),_0x4c4234['serverCache']);}function Uo(_0x34bc7,_0x59e003,_0x5e6e76,_0x2b8eb4){return Mn(_0x34bc7['eventCache'],new Ce(_0x59e003,_0x5e6e76,_0x2b8eb4));}function mn(_0x29a917){return _0x29a917['eventCache']['isFullyInitialized']()?_0x29a917['eventCache']['getNode']():null;}function We(_0x45337b){return _0x45337b['serverCache']['isFullyInitialized']()?_0x45337b['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x5094d5){let _0x4a98db=new S(null);return x(_0x5094d5,(_0x55fcb8,_0x3863a5)=>{_0x4a98db=_0x4a98db['set'](new C(_0x55fcb8),_0x3863a5);}),_0x4a98db;}constructor(_0x19011c,_0x1027bf=cu()){this['value']=_0x19011c,this['children']=_0x1027bf;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x5077f4,_0x27456f){if(this['value']!=null&&_0x27456f(this['value']))return{'path':w(),'value':this['value']};if(v(_0x5077f4))return null;{const _0x5b08ac=y(_0x5077f4),_0x197661=this['children']['get'](_0x5b08ac);if(_0x197661!==null){const _0x51c306=_0x197661['findRootMostMatchingPathAndValue'](b(_0x5077f4),_0x27456f);return _0x51c306!=null?{'path':k(new C(_0x5b08ac),_0x51c306['path']),'value':_0x51c306['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x91c694){return this['findRootMostMatchingPathAndValue'](_0x91c694,()=>!0x0);}['subtree'](_0x5ca6df){if(v(_0x5ca6df))return this;{const _0x4f9b81=y(_0x5ca6df),_0x290e7e=this['children']['get'](_0x4f9b81);return _0x290e7e!==null?_0x290e7e['subtree'](b(_0x5ca6df)):new S(null);}}['set'](_0x3a3768,_0x3cb78d){if(v(_0x3a3768))return new S(_0x3cb78d,this['children']);{const _0x9c0513=y(_0x3a3768),_0x1892a1=(this['children']['get'](_0x9c0513)||new S(null))['set'](b(_0x3a3768),_0x3cb78d),_0x5b3ebc=this['children']['insert'](_0x9c0513,_0x1892a1);return new S(this['value'],_0x5b3ebc);}}['remove'](_0x4ea8b3){if(v(_0x4ea8b3))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x3429e3=y(_0x4ea8b3),_0x29b472=this['children']['get'](_0x3429e3);if(_0x29b472){const _0x3786ad=_0x29b472['remove'](b(_0x4ea8b3));let _0x1a7fee;return _0x3786ad['isEmpty']()?_0x1a7fee=this['children']['remove'](_0x3429e3):_0x1a7fee=this['children']['insert'](_0x3429e3,_0x3786ad),this['value']===null&&_0x1a7fee['isEmpty']()?new S(null):new S(this['value'],_0x1a7fee);}else return this;}}['get'](_0x58c1a0){if(v(_0x58c1a0))return this['value'];{const _0x1ba5bd=y(_0x58c1a0),_0x53ee59=this['children']['get'](_0x1ba5bd);return _0x53ee59?_0x53ee59['get'](b(_0x58c1a0)):null;}}['setTree'](_0x1c82fd,_0x2c1696){if(v(_0x1c82fd))return _0x2c1696;{const _0x2dd57c=y(_0x1c82fd),_0x41736f=(this['children']['get'](_0x2dd57c)||new S(null))['setTree'](b(_0x1c82fd),_0x2c1696);let _0x5a9ead;return _0x41736f['isEmpty']()?_0x5a9ead=this['children']['remove'](_0x2dd57c):_0x5a9ead=this['children']['insert'](_0x2dd57c,_0x41736f),new S(this['value'],_0x5a9ead);}}['fold'](_0x10b0aa){return this['fold_'](w(),_0x10b0aa);}['fold_'](_0x1bdba2,_0x13d51b){const _0x1c3dbc={};return this['children']['inorderTraversal']((_0x4cca0b,_0x1dc4b1)=>{_0x1c3dbc[_0x4cca0b]=_0x1dc4b1['fold_'](k(_0x1bdba2,_0x4cca0b),_0x13d51b);}),_0x13d51b(_0x1bdba2,this['value'],_0x1c3dbc);}['findOnPath'](_0x5cfce5,_0x47d003){return this['findOnPath_'](_0x5cfce5,w(),_0x47d003);}['findOnPath_'](_0x22fbb6,_0x5e7b26,_0x850535){const _0x1421c0=this['value']?_0x850535(_0x5e7b26,this['value']):!0x1;if(_0x1421c0)return _0x1421c0;if(v(_0x22fbb6))return null;{const _0x13f2d5=y(_0x22fbb6),_0x5b5956=this['children']['get'](_0x13f2d5);return _0x5b5956?_0x5b5956['findOnPath_'](b(_0x22fbb6),k(_0x5e7b26,_0x13f2d5),_0x850535):null;}}['foreachOnPath'](_0x3e7828,_0xc18d8){return this['foreachOnPath_'](_0x3e7828,w(),_0xc18d8);}['foreachOnPath_'](_0x25ccdd,_0x8c5d5e,_0x1d3988){if(v(_0x25ccdd))return this;{this['value']&&_0x1d3988(_0x8c5d5e,this['value']);const _0x3e6c7e=y(_0x25ccdd),_0x3fe570=this['children']['get'](_0x3e6c7e);return _0x3fe570?_0x3fe570['foreachOnPath_'](b(_0x25ccdd),k(_0x8c5d5e,_0x3e6c7e),_0x1d3988):new S(null);}}['foreach'](_0x4b8628){this['foreach_'](w(),_0x4b8628);}['foreach_'](_0x17c842,_0x5e7192){this['children']['inorderTraversal']((_0x43978d,_0x47a6b7)=>{_0x47a6b7['foreach_'](k(_0x17c842,_0x43978d),_0x5e7192);}),this['value']&&_0x5e7192(_0x17c842,this['value']);}['foreachChild'](_0xa2ede0){this['children']['inorderTraversal']((_0x214bee,_0x219a6e)=>{_0x219a6e['value']&&_0xa2ede0(_0x214bee,_0x219a6e['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x2f906f){this['writeTree_']=_0x2f906f;}static['empty'](){return new Y(new S(null));}}function St(_0x61017d,_0x32f0bf,_0x2bcc85){if(v(_0x32f0bf))return new Y(new S(_0x2bcc85));{const _0x42f8b9=_0x61017d['writeTree_']['findRootMostValueAndPath'](_0x32f0bf);if(_0x42f8b9!=null){const _0x5258ad=_0x42f8b9['path'];let _0x270177=_0x42f8b9['value'];const _0x401dad=F(_0x5258ad,_0x32f0bf);return _0x270177=_0x270177['updateChild'](_0x401dad,_0x2bcc85),new Y(_0x61017d['writeTree_']['set'](_0x5258ad,_0x270177));}else{const _0x3a9325=new S(_0x2bcc85),_0xab208b=_0x61017d['writeTree_']['setTree'](_0x32f0bf,_0x3a9325);return new Y(_0xab208b);}}}function wi(_0x1273e6,_0x16661f,_0x17c09a){let _0x44658b=_0x1273e6;return x(_0x17c09a,(_0x492aaf,_0xb2115d)=>{_0x44658b=St(_0x44658b,k(_0x16661f,_0x492aaf),_0xb2115d);}),_0x44658b;}function ar(_0x49eaf1,_0x54c9fd){if(v(_0x54c9fd))return Y['empty']();{const _0x25018a=_0x49eaf1['writeTree_']['setTree'](_0x54c9fd,new S(null));return new Y(_0x25018a);}}function Ci(_0x556b3e,_0x1ba56a){return $e(_0x556b3e,_0x1ba56a)!=null;}function $e(_0x134a94,_0x1f0f6a){const _0xe50223=_0x134a94['writeTree_']['findRootMostValueAndPath'](_0x1f0f6a);return _0xe50223!=null?_0x134a94['writeTree_']['get'](_0xe50223['path'])['getChild'](F(_0xe50223['path'],_0x1f0f6a)):null;}function cr(_0x32e526){const _0x16ef03=[],_0x17a968=_0x32e526['writeTree_']['value'];return _0x17a968!=null?_0x17a968['isLeafNode']()||_0x17a968['forEachChild'](R,(_0x187651,_0x345178)=>{_0x16ef03['push'](new E(_0x187651,_0x345178));}):_0x32e526['writeTree_']['children']['inorderTraversal']((_0x1bb0cb,_0x496e85)=>{_0x496e85['value']!=null&&_0x16ef03['push'](new E(_0x1bb0cb,_0x496e85['value']));}),_0x16ef03;}function ve(_0x546178,_0x4d1c45){if(v(_0x4d1c45))return _0x546178;{const _0x4288db=$e(_0x546178,_0x4d1c45);return _0x4288db!=null?new Y(new S(_0x4288db)):new Y(_0x546178['writeTree_']['subtree'](_0x4d1c45));}}function Ti(_0x272de2){return _0x272de2['writeTree_']['isEmpty']();}function nt(_0xef88f9,_0x11821d){return Wo(w(),_0xef88f9['writeTree_'],_0x11821d);}function Wo(_0x4fb94c,_0x26bb59,_0x52a5df){if(_0x26bb59['value']!=null)return _0x52a5df['updateChild'](_0x4fb94c,_0x26bb59['value']);{let _0x4c45ba=null;return _0x26bb59['children']['inorderTraversal']((_0x653afb,_0x304e4d)=>{_0x653afb==='.priority'?(f(_0x304e4d['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x4c45ba=_0x304e4d['value']):_0x52a5df=Wo(k(_0x4fb94c,_0x653afb),_0x304e4d,_0x52a5df);}),!_0x52a5df['getChild'](_0x4fb94c)['isEmpty']()&&_0x4c45ba!==null&&(_0x52a5df=_0x52a5df['updateChild'](k(_0x4fb94c,'.priority'),_0x4c45ba)),_0x52a5df;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x3fcb7c,_0xf5d9f0){return $o(_0xf5d9f0,_0x3fcb7c);}function lu(_0x23e26f,_0x361055,_0x1f0365,_0x53b37a,_0x1660a1){f(_0x53b37a>_0x23e26f['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x1660a1===void 0x0&&(_0x1660a1=!0x0),_0x23e26f['allWrites']['push']({'path':_0x361055,'snap':_0x1f0365,'writeId':_0x53b37a,'visible':_0x1660a1}),_0x1660a1&&(_0x23e26f['visibleWrites']=St(_0x23e26f['visibleWrites'],_0x361055,_0x1f0365)),_0x23e26f['lastWriteId']=_0x53b37a;}function hu(_0x1f6082,_0x395ffd,_0x75acfd,_0x2eef5d){f(_0x2eef5d>_0x1f6082['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x1f6082['allWrites']['push']({'path':_0x395ffd,'children':_0x75acfd,'writeId':_0x2eef5d,'visible':!0x0}),_0x1f6082['visibleWrites']=wi(_0x1f6082['visibleWrites'],_0x395ffd,_0x75acfd),_0x1f6082['lastWriteId']=_0x2eef5d;}function uu(_0x2df05d,_0xd6ea4e){for(let _0x3d8c97=0x0;_0x3d8c97<_0x2df05d['allWrites']['length'];_0x3d8c97++){const _0xf9fb34=_0x2df05d['allWrites'][_0x3d8c97];if(_0xf9fb34['writeId']===_0xd6ea4e)return _0xf9fb34;}return null;}function du(_0x5b987e,_0x139cd3){const _0x5dbf3=_0x5b987e['allWrites']['findIndex'](_0x1661bf=>_0x1661bf['writeId']===_0x139cd3);f(_0x5dbf3>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x378fce=_0x5b987e['allWrites'][_0x5dbf3];_0x5b987e['allWrites']['splice'](_0x5dbf3,0x1);let _0x292cf0=_0x378fce['visible'],_0x5c28a3=!0x1,_0xd22d5=_0x5b987e['allWrites']['length']-0x1;for(;_0x292cf0&&_0xd22d5>=0x0;){const _0xcf6a44=_0x5b987e['allWrites'][_0xd22d5];_0xcf6a44['visible']&&(_0xd22d5>=_0x5dbf3&&fu(_0xcf6a44,_0x378fce['path'])?_0x292cf0=!0x1:G(_0x378fce['path'],_0xcf6a44['path'])&&(_0x5c28a3=!0x0)),_0xd22d5--;}if(_0x292cf0){if(_0x5c28a3)return pu(_0x5b987e),!0x0;if(_0x378fce['snap'])_0x5b987e['visibleWrites']=ar(_0x5b987e['visibleWrites'],_0x378fce['path']);else{const _0x1a0fbf=_0x378fce['children'];x(_0x1a0fbf,_0x1e676b=>{_0x5b987e['visibleWrites']=ar(_0x5b987e['visibleWrites'],k(_0x378fce['path'],_0x1e676b));});}return!0x0;}else return!0x1;}function fu(_0x11dff3,_0x61ee32){if(_0x11dff3['snap'])return G(_0x11dff3['path'],_0x61ee32);for(const _0x28969b in _0x11dff3['children'])if(_0x11dff3['children']['hasOwnProperty'](_0x28969b)&&G(k(_0x11dff3['path'],_0x28969b),_0x61ee32))return!0x0;return!0x1;}function pu(_0x5c3bec){_0x5c3bec['visibleWrites']=Bo(_0x5c3bec['allWrites'],_u,w()),_0x5c3bec['allWrites']['length']>0x0?_0x5c3bec['lastWriteId']=_0x5c3bec['allWrites'][_0x5c3bec['allWrites']['length']-0x1]['writeId']:_0x5c3bec['lastWriteId']=-0x1;}function _u(_0x1e7dfc){return _0x1e7dfc['visible'];}function Bo(_0x20a81b,_0x320167,_0x4da9f0){let _0x522d32=Y['empty']();for(let _0x3f78f0=0x0;_0x3f78f0<_0x20a81b['length'];++_0x3f78f0){const _0x461dcf=_0x20a81b[_0x3f78f0];if(_0x320167(_0x461dcf)){const _0xb2ea47=_0x461dcf['path'];let _0x588ef0;if(_0x461dcf['snap'])G(_0x4da9f0,_0xb2ea47)?(_0x588ef0=F(_0x4da9f0,_0xb2ea47),_0x522d32=St(_0x522d32,_0x588ef0,_0x461dcf['snap'])):G(_0xb2ea47,_0x4da9f0)&&(_0x588ef0=F(_0xb2ea47,_0x4da9f0),_0x522d32=St(_0x522d32,w(),_0x461dcf['snap']['getChild'](_0x588ef0)));else{if(_0x461dcf['children']){if(G(_0x4da9f0,_0xb2ea47))_0x588ef0=F(_0x4da9f0,_0xb2ea47),_0x522d32=wi(_0x522d32,_0x588ef0,_0x461dcf['children']);else{if(G(_0xb2ea47,_0x4da9f0)){if(_0x588ef0=F(_0xb2ea47,_0x4da9f0),v(_0x588ef0))_0x522d32=wi(_0x522d32,w(),_0x461dcf['children']);else{const _0x587020=De(_0x461dcf['children'],y(_0x588ef0));if(_0x587020){const _0x33170f=_0x587020['getChild'](b(_0x588ef0));_0x522d32=St(_0x522d32,w(),_0x33170f);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x522d32;}function Vo(_0x2e48b6,_0x805fd0,_0x4fca5d,_0xe8e3cd,_0x6cc47){if(!_0xe8e3cd&&!_0x6cc47){const _0xed4522=$e(_0x2e48b6['visibleWrites'],_0x805fd0);if(_0xed4522!=null)return _0xed4522;{const _0x5b2c9d=ve(_0x2e48b6['visibleWrites'],_0x805fd0);if(Ti(_0x5b2c9d))return _0x4fca5d;if(_0x4fca5d==null&&!Ci(_0x5b2c9d,w()))return null;{const _0x5dc753=_0x4fca5d||g['EMPTY_NODE'];return nt(_0x5b2c9d,_0x5dc753);}}}else{const _0x4e4d9d=ve(_0x2e48b6['visibleWrites'],_0x805fd0);if(!_0x6cc47&&Ti(_0x4e4d9d))return _0x4fca5d;if(!_0x6cc47&&_0x4fca5d==null&&!Ci(_0x4e4d9d,w()))return null;{const _0x32adcf=function(_0x5b25bc){return(_0x5b25bc['visible']||_0x6cc47)&&(!_0xe8e3cd||!~_0xe8e3cd['indexOf'](_0x5b25bc['writeId']))&&(G(_0x5b25bc['path'],_0x805fd0)||G(_0x805fd0,_0x5b25bc['path']));},_0x3ba110=Bo(_0x2e48b6['allWrites'],_0x32adcf,_0x805fd0),_0xcf53d6=_0x4fca5d||g['EMPTY_NODE'];return nt(_0x3ba110,_0xcf53d6);}}}function gu(_0x735a9e,_0x4ad337,_0x1c7b16){let _0x3a60b6=g['EMPTY_NODE'];const _0x480d30=$e(_0x735a9e['visibleWrites'],_0x4ad337);if(_0x480d30)return _0x480d30['isLeafNode']()||_0x480d30['forEachChild'](R,(_0x21a2dc,_0x3f98e7)=>{_0x3a60b6=_0x3a60b6['updateImmediateChild'](_0x21a2dc,_0x3f98e7);}),_0x3a60b6;if(_0x1c7b16){const _0x462f43=ve(_0x735a9e['visibleWrites'],_0x4ad337);return _0x1c7b16['forEachChild'](R,(_0x42a9df,_0x2efbce)=>{const _0x28f734=nt(ve(_0x462f43,new C(_0x42a9df)),_0x2efbce);_0x3a60b6=_0x3a60b6['updateImmediateChild'](_0x42a9df,_0x28f734);}),cr(_0x462f43)['forEach'](_0x16cb4e=>{_0x3a60b6=_0x3a60b6['updateImmediateChild'](_0x16cb4e['name'],_0x16cb4e['node']);}),_0x3a60b6;}else{const _0xbb79d3=ve(_0x735a9e['visibleWrites'],_0x4ad337);return cr(_0xbb79d3)['forEach'](_0x53dffc=>{_0x3a60b6=_0x3a60b6['updateImmediateChild'](_0x53dffc['name'],_0x53dffc['node']);}),_0x3a60b6;}}function mu(_0x361643,_0x10a4c4,_0x4cbc58,_0x4b28e1,_0x428a07){f(_0x4b28e1||_0x428a07,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x5352ae=k(_0x10a4c4,_0x4cbc58);if(Ci(_0x361643['visibleWrites'],_0x5352ae))return null;{const _0x53bcbb=ve(_0x361643['visibleWrites'],_0x5352ae);return Ti(_0x53bcbb)?_0x428a07['getChild'](_0x4cbc58):nt(_0x53bcbb,_0x428a07['getChild'](_0x4cbc58));}}function yu(_0x2fe93d,_0x57d746,_0x98dc48,_0x5cd2a3){const _0x4d6c02=k(_0x57d746,_0x98dc48),_0x43cf63=$e(_0x2fe93d['visibleWrites'],_0x4d6c02);if(_0x43cf63!=null)return _0x43cf63;if(_0x5cd2a3['isCompleteForChild'](_0x98dc48)){const _0x349a85=ve(_0x2fe93d['visibleWrites'],_0x4d6c02);return nt(_0x349a85,_0x5cd2a3['getNode']()['getImmediateChild'](_0x98dc48));}else return null;}function vu(_0x4ee501,_0x180299){return $e(_0x4ee501['visibleWrites'],_0x180299);}function Eu(_0x5072b6,_0x5ac543,_0x185edf,_0x52df13,_0x52a93f,_0x375d7b,_0xd99cae){let _0x5af256;const _0x43aa66=ve(_0x5072b6['visibleWrites'],_0x5ac543),_0x21494e=$e(_0x43aa66,w());if(_0x21494e!=null)_0x5af256=_0x21494e;else{if(_0x185edf!=null)_0x5af256=nt(_0x43aa66,_0x185edf);else return[];}if(_0x5af256=_0x5af256['withIndex'](_0xd99cae),!_0x5af256['isEmpty']()&&!_0x5af256['isLeafNode']()){const _0x5acef1=[],_0x1e035a=_0xd99cae['getCompare'](),_0x31cad4=_0x375d7b?_0x5af256['getReverseIteratorFrom'](_0x52df13,_0xd99cae):_0x5af256['getIteratorFrom'](_0x52df13,_0xd99cae);let _0x2c835d=_0x31cad4['getNext']();for(;_0x2c835d&&_0x5acef1['length']<_0x52a93f;)_0x1e035a(_0x2c835d,_0x52df13)!==0x0&&_0x5acef1['push'](_0x2c835d),_0x2c835d=_0x31cad4['getNext']();return _0x5acef1;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x4b8080,_0x43cad7,_0x119bdb,_0x5b0328){return Vo(_0x4b8080['writeTree'],_0x4b8080['treePath'],_0x43cad7,_0x119bdb,_0x5b0328);}function ns(_0x32b9b0,_0x227cae){return gu(_0x32b9b0['writeTree'],_0x32b9b0['treePath'],_0x227cae);}function lr(_0x2d5d94,_0x3e2b6b,_0x35b359,_0x2a7553){return mu(_0x2d5d94['writeTree'],_0x2d5d94['treePath'],_0x3e2b6b,_0x35b359,_0x2a7553);}function vn(_0x22d88a,_0x3f6086){return vu(_0x22d88a['writeTree'],k(_0x22d88a['treePath'],_0x3f6086));}function wu(_0x4f47e0,_0x493555,_0x3a9b76,_0x25b0bc,_0x5d8450,_0x33ff5c){return Eu(_0x4f47e0['writeTree'],_0x4f47e0['treePath'],_0x493555,_0x3a9b76,_0x25b0bc,_0x5d8450,_0x33ff5c);}function is(_0x5de638,_0x4a6a17,_0x5d6ae4){return yu(_0x5de638['writeTree'],_0x5de638['treePath'],_0x4a6a17,_0x5d6ae4);}function Ho(_0x4ba853,_0x45fe85){return $o(k(_0x4ba853['treePath'],_0x45fe85),_0x4ba853['writeTree']);}function $o(_0x3f118f,_0x27a34d){return{'treePath':_0x3f118f,'writeTree':_0x27a34d};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x1a1e70){const _0x24e781=_0x1a1e70['type'],_0x4dd5e1=_0x1a1e70['childName'];f(_0x24e781==='child_added'||_0x24e781==='child_changed'||_0x24e781==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x4dd5e1!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x9d008=this['changeMap']['get'](_0x4dd5e1);if(_0x9d008){const _0x4e2bc0=_0x9d008['type'];if(_0x24e781==='child_added'&&_0x4e2bc0==='child_removed')this['changeMap']['set'](_0x4dd5e1,Dt(_0x4dd5e1,_0x1a1e70['snapshotNode'],_0x9d008['snapshotNode']));else{if(_0x24e781==='child_removed'&&_0x4e2bc0==='child_added')this['changeMap']['delete'](_0x4dd5e1);else{if(_0x24e781==='child_removed'&&_0x4e2bc0==='child_changed')this['changeMap']['set'](_0x4dd5e1,Ot(_0x4dd5e1,_0x9d008['oldSnap']));else{if(_0x24e781==='child_changed'&&_0x4e2bc0==='child_added')this['changeMap']['set'](_0x4dd5e1,et(_0x4dd5e1,_0x1a1e70['snapshotNode']));else{if(_0x24e781==='child_changed'&&_0x4e2bc0==='child_changed')this['changeMap']['set'](_0x4dd5e1,Dt(_0x4dd5e1,_0x1a1e70['snapshotNode'],_0x9d008['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x1a1e70+'\x20occurred\x20after\x20'+_0x9d008);}}}}}else this['changeMap']['set'](_0x4dd5e1,_0x1a1e70);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x538fef){return null;}['getChildAfterChild'](_0x1ce778,_0x449d2e,_0x2884e4){return null;}}const Go=new Tu();class ss{constructor(_0x4f0477,_0x38fa7c,_0x30055f=null){this['writes_']=_0x4f0477,this['viewCache_']=_0x38fa7c,this['optCompleteServerCache_']=_0x30055f;}['getCompleteChild'](_0x5d96b2){const _0x51721c=this['viewCache_']['eventCache'];if(_0x51721c['isCompleteForChild'](_0x5d96b2))return _0x51721c['getNode']()['getImmediateChild'](_0x5d96b2);{const _0x35efd9=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x5d96b2,_0x35efd9);}}['getChildAfterChild'](_0xc24849,_0x2a3743,_0xc0a91c){const _0x43b54d=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0xb66c37=wu(this['writes_'],_0x43b54d,_0x2a3743,0x1,_0xc0a91c,_0xc24849);return _0xb66c37['length']===0x0?null:_0xb66c37[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x8f34){return{'filter':_0x8f34};}function bu(_0x4a1fee,_0x46d1f9){f(_0x46d1f9['eventCache']['getNode']()['isIndexed'](_0x4a1fee['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x46d1f9['serverCache']['getNode']()['isIndexed'](_0x4a1fee['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x4cde58,_0x21df4d,_0x14346f,_0x186b8d,_0x583fcc){const _0x2fa4b4=new Cu();let _0xb8bfba,_0x54e1fd;if(_0x14346f['type']===j['OVERWRITE']){const _0x144a31=_0x14346f;_0x144a31['source']['fromUser']?_0xb8bfba=Si(_0x4cde58,_0x21df4d,_0x144a31['path'],_0x144a31['snap'],_0x186b8d,_0x583fcc,_0x2fa4b4):(f(_0x144a31['source']['fromServer'],'Unknown\x20source.'),_0x54e1fd=_0x144a31['source']['tagged']||_0x21df4d['serverCache']['isFiltered']()&&!v(_0x144a31['path']),_0xb8bfba=En(_0x4cde58,_0x21df4d,_0x144a31['path'],_0x144a31['snap'],_0x186b8d,_0x583fcc,_0x54e1fd,_0x2fa4b4));}else{if(_0x14346f['type']===j['MERGE']){const _0xde38a6=_0x14346f;_0xde38a6['source']['fromUser']?_0xb8bfba=ku(_0x4cde58,_0x21df4d,_0xde38a6['path'],_0xde38a6['children'],_0x186b8d,_0x583fcc,_0x2fa4b4):(f(_0xde38a6['source']['fromServer'],'Unknown\x20source.'),_0x54e1fd=_0xde38a6['source']['tagged']||_0x21df4d['serverCache']['isFiltered'](),_0xb8bfba=bi(_0x4cde58,_0x21df4d,_0xde38a6['path'],_0xde38a6['children'],_0x186b8d,_0x583fcc,_0x54e1fd,_0x2fa4b4));}else{if(_0x14346f['type']===j['ACK_USER_WRITE']){const _0x1eec73=_0x14346f;_0x1eec73['revert']?_0xb8bfba=Ou(_0x4cde58,_0x21df4d,_0x1eec73['path'],_0x186b8d,_0x583fcc,_0x2fa4b4):_0xb8bfba=Nu(_0x4cde58,_0x21df4d,_0x1eec73['path'],_0x1eec73['affectedTree'],_0x186b8d,_0x583fcc,_0x2fa4b4);}else{if(_0x14346f['type']===j['LISTEN_COMPLETE'])_0xb8bfba=Pu(_0x4cde58,_0x21df4d,_0x14346f['path'],_0x186b8d,_0x2fa4b4);else throw rt('Unknown\x20operation\x20type:\x20'+_0x14346f['type']);}}}const _0x45d4cd=_0x2fa4b4['getChanges']();return Au(_0x21df4d,_0xb8bfba,_0x45d4cd),{'viewCache':_0xb8bfba,'changes':_0x45d4cd};}function Au(_0x14b9cb,_0x276eed,_0x34be41){const _0x4dff07=_0x276eed['eventCache'];if(_0x4dff07['isFullyInitialized']()){const _0x530562=_0x4dff07['getNode']()['isLeafNode']()||_0x4dff07['getNode']()['isEmpty'](),_0xac39eb=mn(_0x14b9cb);(_0x34be41['length']>0x0||!_0x14b9cb['eventCache']['isFullyInitialized']()||_0x530562&&!_0x4dff07['getNode']()['equals'](_0xac39eb)||!_0x4dff07['getNode']()['getPriority']()['equals'](_0xac39eb['getPriority']()))&&_0x34be41['push'](Lo(mn(_0x276eed)));}}function qo(_0x1a0cb,_0x513fc4,_0x40dd02,_0x39086e,_0x129d84,_0x14a4b2){const _0x370409=_0x513fc4['eventCache'];if(vn(_0x39086e,_0x40dd02)!=null)return _0x513fc4;{let _0x4a3334,_0x2f455a;if(v(_0x40dd02)){if(f(_0x513fc4['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x513fc4['serverCache']['isFiltered']()){const _0x38e2e4=We(_0x513fc4),_0x612a9b=_0x38e2e4 instanceof g?_0x38e2e4:g['EMPTY_NODE'],_0x33b640=ns(_0x39086e,_0x612a9b);_0x4a3334=_0x1a0cb['filter']['updateFullNode'](_0x513fc4['eventCache']['getNode'](),_0x33b640,_0x14a4b2);}else{const _0x427765=yn(_0x39086e,We(_0x513fc4));_0x4a3334=_0x1a0cb['filter']['updateFullNode'](_0x513fc4['eventCache']['getNode'](),_0x427765,_0x14a4b2);}}else{const _0x3ba468=y(_0x40dd02);if(_0x3ba468==='.priority'){f(we(_0x40dd02)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x5bb363=_0x370409['getNode']();_0x2f455a=_0x513fc4['serverCache']['getNode']();const _0x4201de=lr(_0x39086e,_0x40dd02,_0x5bb363,_0x2f455a);_0x4201de!=null?_0x4a3334=_0x1a0cb['filter']['updatePriority'](_0x5bb363,_0x4201de):_0x4a3334=_0x370409['getNode']();}else{const _0x1a0231=b(_0x40dd02);let _0xb2ed4a;if(_0x370409['isCompleteForChild'](_0x3ba468)){_0x2f455a=_0x513fc4['serverCache']['getNode']();const _0x3410d6=lr(_0x39086e,_0x40dd02,_0x370409['getNode'](),_0x2f455a);_0x3410d6!=null?_0xb2ed4a=_0x370409['getNode']()['getImmediateChild'](_0x3ba468)['updateChild'](_0x1a0231,_0x3410d6):_0xb2ed4a=_0x370409['getNode']()['getImmediateChild'](_0x3ba468);}else _0xb2ed4a=is(_0x39086e,_0x3ba468,_0x513fc4['serverCache']);_0xb2ed4a!=null?_0x4a3334=_0x1a0cb['filter']['updateChild'](_0x370409['getNode'](),_0x3ba468,_0xb2ed4a,_0x1a0231,_0x129d84,_0x14a4b2):_0x4a3334=_0x370409['getNode']();}}return Tt(_0x513fc4,_0x4a3334,_0x370409['isFullyInitialized']()||v(_0x40dd02),_0x1a0cb['filter']['filtersNodes']());}}function En(_0x3d8a89,_0x5c0a56,_0x591898,_0x5c6419,_0x43ae65,_0x38d71c,_0x45f059,_0x3bd865){const _0x53bbd3=_0x5c0a56['serverCache'];let _0xb5a7f5;const _0x507630=_0x45f059?_0x3d8a89['filter']:_0x3d8a89['filter']['getIndexedFilter']();if(v(_0x591898))_0xb5a7f5=_0x507630['updateFullNode'](_0x53bbd3['getNode'](),_0x5c6419,null);else{if(_0x507630['filtersNodes']()&&!_0x53bbd3['isFiltered']()){const _0x5d096f=_0x53bbd3['getNode']()['updateChild'](_0x591898,_0x5c6419);_0xb5a7f5=_0x507630['updateFullNode'](_0x53bbd3['getNode'](),_0x5d096f,null);}else{const _0x250444=y(_0x591898);if(!_0x53bbd3['isCompleteForPath'](_0x591898)&&we(_0x591898)>0x1)return _0x5c0a56;const _0x1621e0=b(_0x591898),_0x4356db=_0x53bbd3['getNode']()['getImmediateChild'](_0x250444)['updateChild'](_0x1621e0,_0x5c6419);_0x250444==='.priority'?_0xb5a7f5=_0x507630['updatePriority'](_0x53bbd3['getNode'](),_0x4356db):_0xb5a7f5=_0x507630['updateChild'](_0x53bbd3['getNode'](),_0x250444,_0x4356db,_0x1621e0,Go,null);}}const _0x5cc23e=Uo(_0x5c0a56,_0xb5a7f5,_0x53bbd3['isFullyInitialized']()||v(_0x591898),_0x507630['filtersNodes']()),_0x4dd16f=new ss(_0x43ae65,_0x5cc23e,_0x38d71c);return qo(_0x3d8a89,_0x5cc23e,_0x591898,_0x43ae65,_0x4dd16f,_0x3bd865);}function Si(_0x14c50f,_0x29e48f,_0x59f0d5,_0xd53927,_0x4ed5c9,_0xc8d246,_0x45931d){const _0x1d3889=_0x29e48f['eventCache'];let _0x574dd1,_0x5c8598;const _0x579a08=new ss(_0x4ed5c9,_0x29e48f,_0xc8d246);if(v(_0x59f0d5))_0x5c8598=_0x14c50f['filter']['updateFullNode'](_0x29e48f['eventCache']['getNode'](),_0xd53927,_0x45931d),_0x574dd1=Tt(_0x29e48f,_0x5c8598,!0x0,_0x14c50f['filter']['filtersNodes']());else{const _0x4de4f5=y(_0x59f0d5);if(_0x4de4f5==='.priority')_0x5c8598=_0x14c50f['filter']['updatePriority'](_0x29e48f['eventCache']['getNode'](),_0xd53927),_0x574dd1=Tt(_0x29e48f,_0x5c8598,_0x1d3889['isFullyInitialized'](),_0x1d3889['isFiltered']());else{const _0x3e4c1d=b(_0x59f0d5),_0x3dd5f6=_0x1d3889['getNode']()['getImmediateChild'](_0x4de4f5);let _0x8ee401;if(v(_0x3e4c1d))_0x8ee401=_0xd53927;else{const _0x360209=_0x579a08['getCompleteChild'](_0x4de4f5);_0x360209!=null?zi(_0x3e4c1d)==='.priority'&&_0x360209['getChild'](Ro(_0x3e4c1d))['isEmpty']()?_0x8ee401=_0x360209:_0x8ee401=_0x360209['updateChild'](_0x3e4c1d,_0xd53927):_0x8ee401=g['EMPTY_NODE'];}if(_0x3dd5f6['equals'](_0x8ee401))_0x574dd1=_0x29e48f;else{const _0x444976=_0x14c50f['filter']['updateChild'](_0x1d3889['getNode'](),_0x4de4f5,_0x8ee401,_0x3e4c1d,_0x579a08,_0x45931d);_0x574dd1=Tt(_0x29e48f,_0x444976,_0x1d3889['isFullyInitialized'](),_0x14c50f['filter']['filtersNodes']());}}}return _0x574dd1;}function hr(_0x5d39b5,_0x13dfb0){return _0x5d39b5['eventCache']['isCompleteForChild'](_0x13dfb0);}function ku(_0xdfdbd7,_0x44f0a7,_0x3e8f22,_0x37a285,_0x5502ab,_0x367316,_0x400e96){let _0x4f7d8c=_0x44f0a7;return _0x37a285['foreach']((_0x4319b5,_0x123830)=>{const _0x1f69f7=k(_0x3e8f22,_0x4319b5);hr(_0x44f0a7,y(_0x1f69f7))&&(_0x4f7d8c=Si(_0xdfdbd7,_0x4f7d8c,_0x1f69f7,_0x123830,_0x5502ab,_0x367316,_0x400e96));}),_0x37a285['foreach']((_0xaa4c9c,_0x21c14a)=>{const _0x47d772=k(_0x3e8f22,_0xaa4c9c);hr(_0x44f0a7,y(_0x47d772))||(_0x4f7d8c=Si(_0xdfdbd7,_0x4f7d8c,_0x47d772,_0x21c14a,_0x5502ab,_0x367316,_0x400e96));}),_0x4f7d8c;}function ur(_0x3b9314,_0x3f2ed4,_0x55d596){return _0x55d596['foreach']((_0x49b34c,_0x503f44)=>{_0x3f2ed4=_0x3f2ed4['updateChild'](_0x49b34c,_0x503f44);}),_0x3f2ed4;}function bi(_0x35e65f,_0x3259b5,_0x3dcea4,_0x3680e5,_0x115848,_0x2f5bec,_0xc7a06a,_0x3e171d){if(_0x3259b5['serverCache']['getNode']()['isEmpty']()&&!_0x3259b5['serverCache']['isFullyInitialized']())return _0x3259b5;let _0x5eac04=_0x3259b5,_0xf04ac5;v(_0x3dcea4)?_0xf04ac5=_0x3680e5:_0xf04ac5=new S(null)['setTree'](_0x3dcea4,_0x3680e5);const _0x5c6bd0=_0x3259b5['serverCache']['getNode']();return _0xf04ac5['children']['inorderTraversal']((_0x5fc8da,_0x471872)=>{if(_0x5c6bd0['hasChild'](_0x5fc8da)){const _0x1cee1e=_0x3259b5['serverCache']['getNode']()['getImmediateChild'](_0x5fc8da),_0x5ae8da=ur(_0x35e65f,_0x1cee1e,_0x471872);_0x5eac04=En(_0x35e65f,_0x5eac04,new C(_0x5fc8da),_0x5ae8da,_0x115848,_0x2f5bec,_0xc7a06a,_0x3e171d);}}),_0xf04ac5['children']['inorderTraversal']((_0xa064ec,_0x1991ed)=>{const _0x19c4de=!_0x3259b5['serverCache']['isCompleteForChild'](_0xa064ec)&&_0x1991ed['value']===null;if(!_0x5c6bd0['hasChild'](_0xa064ec)&&!_0x19c4de){const _0x5e6ad7=_0x3259b5['serverCache']['getNode']()['getImmediateChild'](_0xa064ec),_0xf23aa5=ur(_0x35e65f,_0x5e6ad7,_0x1991ed);_0x5eac04=En(_0x35e65f,_0x5eac04,new C(_0xa064ec),_0xf23aa5,_0x115848,_0x2f5bec,_0xc7a06a,_0x3e171d);}}),_0x5eac04;}function Nu(_0x4cddee,_0x567606,_0x55c830,_0x28a82d,_0x404f13,_0xb85d44,_0x561e2d){if(vn(_0x404f13,_0x55c830)!=null)return _0x567606;const _0x3ed4e8=_0x567606['serverCache']['isFiltered'](),_0x5b7370=_0x567606['serverCache'];if(_0x28a82d['value']!=null){if(v(_0x55c830)&&_0x5b7370['isFullyInitialized']()||_0x5b7370['isCompleteForPath'](_0x55c830))return En(_0x4cddee,_0x567606,_0x55c830,_0x5b7370['getNode']()['getChild'](_0x55c830),_0x404f13,_0xb85d44,_0x3ed4e8,_0x561e2d);if(v(_0x55c830)){let _0x37d843=new S(null);return _0x5b7370['getNode']()['forEachChild'](ye,(_0x177c04,_0x494ae0)=>{_0x37d843=_0x37d843['set'](new C(_0x177c04),_0x494ae0);}),bi(_0x4cddee,_0x567606,_0x55c830,_0x37d843,_0x404f13,_0xb85d44,_0x3ed4e8,_0x561e2d);}else return _0x567606;}else{let _0x42d555=new S(null);return _0x28a82d['foreach']((_0x393787,_0xac048d)=>{const _0x273ef1=k(_0x55c830,_0x393787);_0x5b7370['isCompleteForPath'](_0x273ef1)&&(_0x42d555=_0x42d555['set'](_0x393787,_0x5b7370['getNode']()['getChild'](_0x273ef1)));}),bi(_0x4cddee,_0x567606,_0x55c830,_0x42d555,_0x404f13,_0xb85d44,_0x3ed4e8,_0x561e2d);}}function Pu(_0x33ebf5,_0x5c816e,_0x2b95dd,_0x52fb12,_0x1733cb){const _0x2579a4=_0x5c816e['serverCache'],_0xfe6e75=Uo(_0x5c816e,_0x2579a4['getNode'](),_0x2579a4['isFullyInitialized']()||v(_0x2b95dd),_0x2579a4['isFiltered']());return qo(_0x33ebf5,_0xfe6e75,_0x2b95dd,_0x52fb12,Go,_0x1733cb);}function Ou(_0x14b6f7,_0x23239c,_0x3a7be1,_0x381a5c,_0x346255,_0x2b933c){let _0x1fb06c;if(vn(_0x381a5c,_0x3a7be1)!=null)return _0x23239c;{const _0x987f5b=new ss(_0x381a5c,_0x23239c,_0x346255),_0x222a5d=_0x23239c['eventCache']['getNode']();let _0x4710b5;if(v(_0x3a7be1)||y(_0x3a7be1)==='.priority'){let _0x14dd96;if(_0x23239c['serverCache']['isFullyInitialized']())_0x14dd96=yn(_0x381a5c,We(_0x23239c));else{const _0xfafa1c=_0x23239c['serverCache']['getNode']();f(_0xfafa1c instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x14dd96=ns(_0x381a5c,_0xfafa1c);}_0x14dd96=_0x14dd96,_0x4710b5=_0x14b6f7['filter']['updateFullNode'](_0x222a5d,_0x14dd96,_0x2b933c);}else{const _0x327155=y(_0x3a7be1);let _0x2ab35c=is(_0x381a5c,_0x327155,_0x23239c['serverCache']);_0x2ab35c==null&&_0x23239c['serverCache']['isCompleteForChild'](_0x327155)&&(_0x2ab35c=_0x222a5d['getImmediateChild'](_0x327155)),_0x2ab35c!=null?_0x4710b5=_0x14b6f7['filter']['updateChild'](_0x222a5d,_0x327155,_0x2ab35c,b(_0x3a7be1),_0x987f5b,_0x2b933c):_0x23239c['eventCache']['getNode']()['hasChild'](_0x327155)?_0x4710b5=_0x14b6f7['filter']['updateChild'](_0x222a5d,_0x327155,g['EMPTY_NODE'],b(_0x3a7be1),_0x987f5b,_0x2b933c):_0x4710b5=_0x222a5d,_0x4710b5['isEmpty']()&&_0x23239c['serverCache']['isFullyInitialized']()&&(_0x1fb06c=yn(_0x381a5c,We(_0x23239c)),_0x1fb06c['isLeafNode']()&&(_0x4710b5=_0x14b6f7['filter']['updateFullNode'](_0x4710b5,_0x1fb06c,_0x2b933c)));}return _0x1fb06c=_0x23239c['serverCache']['isFullyInitialized']()||vn(_0x381a5c,w())!=null,Tt(_0x23239c,_0x4710b5,_0x1fb06c,_0x14b6f7['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x9b9de8,_0x4e394b){this['query_']=_0x9b9de8,this['eventRegistrations_']=[];const _0x59964d=this['query_']['_queryParams'],_0x9bb8a7=new Ji(_0x59964d['getIndex']()),_0x489147=Kh(_0x59964d);this['processor_']=Su(_0x489147);const _0x502f60=_0x4e394b['serverCache'],_0x27fd0e=_0x4e394b['eventCache'],_0x275da3=_0x9bb8a7['updateFullNode'](g['EMPTY_NODE'],_0x502f60['getNode'](),null),_0x39dd90=_0x489147['updateFullNode'](g['EMPTY_NODE'],_0x27fd0e['getNode'](),null),_0x12ce29=new Ce(_0x275da3,_0x502f60['isFullyInitialized'](),_0x9bb8a7['filtersNodes']()),_0x4d5bb3=new Ce(_0x39dd90,_0x27fd0e['isFullyInitialized'](),_0x489147['filtersNodes']());this['viewCache_']=Mn(_0x4d5bb3,_0x12ce29),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x559693){return _0x559693['viewCache_']['serverCache']['getNode']();}function Lu(_0x3f7c85){return mn(_0x3f7c85['viewCache_']);}function xu(_0x5f4bcd,_0xa28a14){const _0x473f19=We(_0x5f4bcd['viewCache_']);return _0x473f19&&(_0x5f4bcd['query']['_queryParams']['loadsAllData']()||!v(_0xa28a14)&&!_0x473f19['getImmediateChild'](y(_0xa28a14))['isEmpty']())?_0x473f19['getChild'](_0xa28a14):null;}function dr(_0x47a6f8){return _0x47a6f8['eventRegistrations_']['length']===0x0;}function Fu(_0x3445ad,_0x45b682){_0x3445ad['eventRegistrations_']['push'](_0x45b682);}function fr(_0x562ea3,_0x96cbd4,_0x2400bf){const _0x5ab9e2=[];if(_0x2400bf){f(_0x96cbd4==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x43a78a=_0x562ea3['query']['_path'];_0x562ea3['eventRegistrations_']['forEach'](_0x1f3e71=>{const _0x78aa39=_0x1f3e71['createCancelEvent'](_0x2400bf,_0x43a78a);_0x78aa39&&_0x5ab9e2['push'](_0x78aa39);});}if(_0x96cbd4){let _0x44264b=[];for(let _0x1808ed=0x0;_0x1808ed<_0x562ea3['eventRegistrations_']['length'];++_0x1808ed){const _0x5757e6=_0x562ea3['eventRegistrations_'][_0x1808ed];if(!_0x5757e6['matches'](_0x96cbd4))_0x44264b['push'](_0x5757e6);else{if(_0x96cbd4['hasAnyCallback']()){_0x44264b=_0x44264b['concat'](_0x562ea3['eventRegistrations_']['slice'](_0x1808ed+0x1));break;}}}_0x562ea3['eventRegistrations_']=_0x44264b;}else _0x562ea3['eventRegistrations_']=[];return _0x5ab9e2;}function pr(_0x35a75d,_0x475b52,_0x5a1872,_0x695a3e){_0x475b52['type']===j['MERGE']&&_0x475b52['source']['queryId']!==null&&(f(We(_0x35a75d['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x35a75d['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x4bbf74=_0x35a75d['viewCache_'],_0x570f46=Ru(_0x35a75d['processor_'],_0x4bbf74,_0x475b52,_0x5a1872,_0x695a3e);return bu(_0x35a75d['processor_'],_0x570f46['viewCache']),f(_0x570f46['viewCache']['serverCache']['isFullyInitialized']()||!_0x4bbf74['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x35a75d['viewCache_']=_0x570f46['viewCache'],zo(_0x35a75d,_0x570f46['changes'],_0x570f46['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x254a75,_0x4fb355){const _0x203d6e=_0x254a75['viewCache_']['eventCache'],_0x281096=[];return _0x203d6e['getNode']()['isLeafNode']()||_0x203d6e['getNode']()['forEachChild'](R,(_0x19bb9a,_0x5eaed2)=>{_0x281096['push'](et(_0x19bb9a,_0x5eaed2));}),_0x203d6e['isFullyInitialized']()&&_0x281096['push'](Lo(_0x203d6e['getNode']())),zo(_0x254a75,_0x281096,_0x203d6e['getNode'](),_0x4fb355);}function zo(_0x8e1bdb,_0x413331,_0x2b42a3,_0x5f4122){const _0x1a99bf=_0x5f4122?[_0x5f4122]:_0x8e1bdb['eventRegistrations_'];return ru(_0x8e1bdb['eventGenerator_'],_0x413331,_0x2b42a3,_0x1a99bf);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x27bdfe){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x27bdfe;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x5cb7b7){return _0x5cb7b7['views']['size']===0x0;}function rs(_0x550c4a,_0x30f4c8,_0x51bb1e,_0x2edf70){const _0x4c8bfe=_0x30f4c8['source']['queryId'];if(_0x4c8bfe!==null){const _0x330aa8=_0x550c4a['views']['get'](_0x4c8bfe);return f(_0x330aa8!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x330aa8,_0x30f4c8,_0x51bb1e,_0x2edf70);}else{let _0x49ac7d=[];for(const _0x2015f6 of _0x550c4a['views']['values']())_0x49ac7d=_0x49ac7d['concat'](pr(_0x2015f6,_0x30f4c8,_0x51bb1e,_0x2edf70));return _0x49ac7d;}}function Ko(_0xf5554a,_0x4fb9ad,_0x22fd36,_0x52118b,_0x1d4256){const _0xddc45d=_0x4fb9ad['_queryIdentifier'],_0x464387=_0xf5554a['views']['get'](_0xddc45d);if(!_0x464387){let _0x12f337=yn(_0x22fd36,_0x1d4256?_0x52118b:null),_0x1d8ab7=!0x1;_0x12f337?_0x1d8ab7=!0x0:_0x52118b instanceof g?(_0x12f337=ns(_0x22fd36,_0x52118b),_0x1d8ab7=!0x1):(_0x12f337=g['EMPTY_NODE'],_0x1d8ab7=!0x1);const _0x284fd0=Mn(new Ce(_0x12f337,_0x1d8ab7,!0x1),new Ce(_0x52118b,_0x1d4256,!0x1));return new Du(_0x4fb9ad,_0x284fd0);}return _0x464387;}function Hu(_0x4bee81,_0x5f56bd,_0x210585,_0x44e348,_0x61530d,_0x5e0dc5){const _0x482144=Ko(_0x4bee81,_0x5f56bd,_0x44e348,_0x61530d,_0x5e0dc5);return _0x4bee81['views']['has'](_0x5f56bd['_queryIdentifier'])||_0x4bee81['views']['set'](_0x5f56bd['_queryIdentifier'],_0x482144),Fu(_0x482144,_0x210585),Uu(_0x482144,_0x210585);}function $u(_0x48876f,_0x261e7a,_0x1521fb,_0x416b39){const _0x3a4f96=_0x261e7a['_queryIdentifier'],_0x312ded=[];let _0x3db2cf=[];const _0x1f3473=Te(_0x48876f);if(_0x3a4f96==='default'){for(const [_0x71b84c,_0x63e6a9]of _0x48876f['views']['entries']())_0x3db2cf=_0x3db2cf['concat'](fr(_0x63e6a9,_0x1521fb,_0x416b39)),dr(_0x63e6a9)&&(_0x48876f['views']['delete'](_0x71b84c),_0x63e6a9['query']['_queryParams']['loadsAllData']()||_0x312ded['push'](_0x63e6a9['query']));}else{const _0x33fed8=_0x48876f['views']['get'](_0x3a4f96);_0x33fed8&&(_0x3db2cf=_0x3db2cf['concat'](fr(_0x33fed8,_0x1521fb,_0x416b39)),dr(_0x33fed8)&&(_0x48876f['views']['delete'](_0x3a4f96),_0x33fed8['query']['_queryParams']['loadsAllData']()||_0x312ded['push'](_0x33fed8['query'])));}return _0x1f3473&&!Te(_0x48876f)&&_0x312ded['push'](new(Bu())(_0x261e7a['_repo'],_0x261e7a['_path'])),{'removed':_0x312ded,'events':_0x3db2cf};}function Yo(_0x1ed27d){const _0x3e795c=[];for(const _0x4ff3da of _0x1ed27d['views']['values']())_0x4ff3da['query']['_queryParams']['loadsAllData']()||_0x3e795c['push'](_0x4ff3da);return _0x3e795c;}function Ee(_0xb13c10,_0x26daaa){let _0x2425ee=null;for(const _0x2dbe9d of _0xb13c10['views']['values']())_0x2425ee=_0x2425ee||xu(_0x2dbe9d,_0x26daaa);return _0x2425ee;}function Qo(_0x3403cc,_0x2797ae){if(_0x2797ae['_queryParams']['loadsAllData']())return xn(_0x3403cc);{const _0x1338f0=_0x2797ae['_queryIdentifier'];return _0x3403cc['views']['get'](_0x1338f0);}}function Jo(_0x3db49a,_0x481f55){return Qo(_0x3db49a,_0x481f55)!=null;}function Te(_0x4ab043){return xn(_0x4ab043)!=null;}function xn(_0x378ebc){for(const _0x1f746a of _0x378ebc['views']['values']())if(_0x1f746a['query']['_queryParams']['loadsAllData']())return _0x1f746a;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x4f091d){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x4f091d;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x5dbfa2){this['listenProvider_']=_0x5dbfa2,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x222114,_0x176b91,_0x5c546a,_0x228a58,_0x192896){return lu(_0x222114['pendingWriteTree_'],_0x176b91,_0x5c546a,_0x228a58,_0x192896),_0x192896?ut(_0x222114,new Ue(Zi(),_0x176b91,_0x5c546a)):[];}function ju(_0x8e0d24,_0x6ad00c,_0x4d01cb,_0x4ff87c){hu(_0x8e0d24['pendingWriteTree_'],_0x6ad00c,_0x4d01cb,_0x4ff87c);const _0x46c949=S['fromObject'](_0x4d01cb);return ut(_0x8e0d24,new tt(Zi(),_0x6ad00c,_0x46c949));}function pe(_0x4e171a,_0x162bb7,_0x3497c3=!0x1){const _0x5de728=uu(_0x4e171a['pendingWriteTree_'],_0x162bb7);if(du(_0x4e171a['pendingWriteTree_'],_0x162bb7)){let _0x52f961=new S(null);return _0x5de728['snap']!=null?_0x52f961=_0x52f961['set'](w(),!0x0):x(_0x5de728['children'],_0x5f35bf=>{_0x52f961=_0x52f961['set'](new C(_0x5f35bf),!0x0);}),ut(_0x4e171a,new gn(_0x5de728['path'],_0x52f961,_0x3497c3));}else return[];}function Gt(_0x2a9fbd,_0x4688d8,_0x67e83c){return ut(_0x2a9fbd,new Ue(es(),_0x4688d8,_0x67e83c));}function Ku(_0x325922,_0x3ee4e2,_0x46ac56){const _0x102d2b=S['fromObject'](_0x46ac56);return ut(_0x325922,new tt(es(),_0x3ee4e2,_0x102d2b));}function Yu(_0x21cf4f,_0x2421cb){return ut(_0x21cf4f,new Lt(es(),_0x2421cb));}function Qu(_0x48861a,_0x4f28e4,_0x2c7e3c){const _0x2517f3=as(_0x48861a,_0x2c7e3c);if(_0x2517f3){const _0x11da5b=cs(_0x2517f3),_0x313b6c=_0x11da5b['path'],_0x19d70d=_0x11da5b['queryId'],_0x47d61c=F(_0x313b6c,_0x4f28e4),_0x18a5d3=new Lt(ts(_0x19d70d),_0x47d61c);return ls(_0x48861a,_0x313b6c,_0x18a5d3);}else return[];}function Cn(_0x3c0548,_0x279969,_0x1b882c,_0x51e730,_0x1da9fb=!0x1){const _0x55049e=_0x279969['_path'],_0x49341b=_0x3c0548['syncPointTree_']['get'](_0x55049e);let _0x3181f3=[];if(_0x49341b&&(_0x279969['_queryIdentifier']==='default'||Jo(_0x49341b,_0x279969))){const _0x6dae1f=$u(_0x49341b,_0x279969,_0x1b882c,_0x51e730);Vu(_0x49341b)&&(_0x3c0548['syncPointTree_']=_0x3c0548['syncPointTree_']['remove'](_0x55049e));const _0x36a729=_0x6dae1f['removed'];if(_0x3181f3=_0x6dae1f['events'],!_0x1da9fb){const _0x58f374=_0x36a729['findIndex'](_0x23cd63=>_0x23cd63['_queryParams']['loadsAllData']())!==-0x1,_0x15f66b=_0x3c0548['syncPointTree_']['findOnPath'](_0x55049e,(_0xcf9aeb,_0x4f917d)=>Te(_0x4f917d));if(_0x58f374&&!_0x15f66b){const _0x434f02=_0x3c0548['syncPointTree_']['subtree'](_0x55049e);if(!_0x434f02['isEmpty']()){const _0x1bc583=Zu(_0x434f02);for(let _0x4b824c=0x0;_0x4b824c<_0x1bc583['length'];++_0x4b824c){const _0x3bc622=_0x1bc583[_0x4b824c],_0xf5b025=_0x3bc622['query'],_0x140f62=ta(_0x3c0548,_0x3bc622);_0x3c0548['listenProvider_']['startListening'](bt(_0xf5b025),xt(_0x3c0548,_0xf5b025),_0x140f62['hashFn'],_0x140f62['onComplete']);}}}!_0x15f66b&&_0x36a729['length']>0x0&&!_0x51e730&&(_0x58f374?_0x3c0548['listenProvider_']['stopListening'](bt(_0x279969),null):_0x36a729['forEach'](_0x4fccc6=>{const _0x5d8d87=_0x3c0548['queryToTagMap']['get'](Un(_0x4fccc6));_0x3c0548['listenProvider_']['stopListening'](bt(_0x4fccc6),_0x5d8d87);}));}ed(_0x3c0548,_0x36a729);}return _0x3181f3;}function Xo(_0x35f234,_0x445b97,_0xd9b979,_0x172b54){const _0x3ea7db=as(_0x35f234,_0x172b54);if(_0x3ea7db!=null){const _0x216849=cs(_0x3ea7db),_0x4549de=_0x216849['path'],_0x5a6f3a=_0x216849['queryId'],_0x177df6=F(_0x4549de,_0x445b97),_0x551d9=new Ue(ts(_0x5a6f3a),_0x177df6,_0xd9b979);return ls(_0x35f234,_0x4549de,_0x551d9);}else return[];}function Ju(_0x2c8a2f,_0x2d484f,_0x13af93,_0x38766c){const _0x4d52bb=as(_0x2c8a2f,_0x38766c);if(_0x4d52bb){const _0x59a357=cs(_0x4d52bb),_0x17fb6c=_0x59a357['path'],_0xc8e9e4=_0x59a357['queryId'],_0x4b4acb=F(_0x17fb6c,_0x2d484f),_0x3d83ca=S['fromObject'](_0x13af93),_0xa05fd=new tt(ts(_0xc8e9e4),_0x4b4acb,_0x3d83ca);return ls(_0x2c8a2f,_0x17fb6c,_0xa05fd);}else return[];}function Ri(_0x3456aa,_0x3bf49b,_0x27d019,_0xbb1423=!0x1){const _0x4b82cd=_0x3bf49b['_path'];let _0x150657=null,_0x74f223=!0x1;_0x3456aa['syncPointTree_']['foreachOnPath'](_0x4b82cd,(_0x957367,_0x2ab95d)=>{const _0x37c86d=F(_0x957367,_0x4b82cd);_0x150657=_0x150657||Ee(_0x2ab95d,_0x37c86d),_0x74f223=_0x74f223||Te(_0x2ab95d);});let _0x5dc31f=_0x3456aa['syncPointTree_']['get'](_0x4b82cd);_0x5dc31f?(_0x74f223=_0x74f223||Te(_0x5dc31f),_0x150657=_0x150657||Ee(_0x5dc31f,w())):(_0x5dc31f=new jo(),_0x3456aa['syncPointTree_']=_0x3456aa['syncPointTree_']['set'](_0x4b82cd,_0x5dc31f));let _0x21f09f;_0x150657!=null?_0x21f09f=!0x0:(_0x21f09f=!0x1,_0x150657=g['EMPTY_NODE'],_0x3456aa['syncPointTree_']['subtree'](_0x4b82cd)['foreachChild']((_0x18e6b0,_0x1a4511)=>{const _0x40c4ab=Ee(_0x1a4511,w());_0x40c4ab&&(_0x150657=_0x150657['updateImmediateChild'](_0x18e6b0,_0x40c4ab));}));const _0x48293b=Jo(_0x5dc31f,_0x3bf49b);if(!_0x48293b&&!_0x3bf49b['_queryParams']['loadsAllData']()){const _0x10f667=Un(_0x3bf49b);f(!_0x3456aa['queryToTagMap']['has'](_0x10f667),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x560968=td();_0x3456aa['queryToTagMap']['set'](_0x10f667,_0x560968),_0x3456aa['tagToQueryMap']['set'](_0x560968,_0x10f667);}const _0x156143=Ln(_0x3456aa['pendingWriteTree_'],_0x4b82cd);let _0x2ceeba=Hu(_0x5dc31f,_0x3bf49b,_0x27d019,_0x156143,_0x150657,_0x21f09f);if(!_0x48293b&&!_0x74f223&&!_0xbb1423){const _0x571fb8=Qo(_0x5dc31f,_0x3bf49b);_0x2ceeba=_0x2ceeba['concat'](nd(_0x3456aa,_0x3bf49b,_0x571fb8));}return _0x2ceeba;}function Fn(_0x26ba5e,_0x440474,_0xe60394){const _0x435f84=_0x26ba5e['pendingWriteTree_'],_0x325ba5=_0x26ba5e['syncPointTree_']['findOnPath'](_0x440474,(_0x3e21ec,_0x1ed3ac)=>{const _0x1cee9e=F(_0x3e21ec,_0x440474),_0x963520=Ee(_0x1ed3ac,_0x1cee9e);if(_0x963520)return _0x963520;});return Vo(_0x435f84,_0x440474,_0x325ba5,_0xe60394,!0x0);}function Xu(_0x5ab31a,_0x37b006){const _0x2b523e=_0x37b006['_path'];let _0x3d84e0=null;_0x5ab31a['syncPointTree_']['foreachOnPath'](_0x2b523e,(_0x3ffbe7,_0x393c3b)=>{const _0x6acd0f=F(_0x3ffbe7,_0x2b523e);_0x3d84e0=_0x3d84e0||Ee(_0x393c3b,_0x6acd0f);});let _0x2fa8a3=_0x5ab31a['syncPointTree_']['get'](_0x2b523e);_0x2fa8a3?_0x3d84e0=_0x3d84e0||Ee(_0x2fa8a3,w()):(_0x2fa8a3=new jo(),_0x5ab31a['syncPointTree_']=_0x5ab31a['syncPointTree_']['set'](_0x2b523e,_0x2fa8a3));const _0x4da44e=_0x3d84e0!=null,_0x25d040=_0x4da44e?new Ce(_0x3d84e0,!0x0,!0x1):null,_0x3dc8aa=Ln(_0x5ab31a['pendingWriteTree_'],_0x37b006['_path']),_0x2b63d2=Ko(_0x2fa8a3,_0x37b006,_0x3dc8aa,_0x4da44e?_0x25d040['getNode']():g['EMPTY_NODE'],_0x4da44e);return Lu(_0x2b63d2);}function ut(_0x4c96d5,_0x235961){return Zo(_0x235961,_0x4c96d5['syncPointTree_'],null,Ln(_0x4c96d5['pendingWriteTree_'],w()));}function Zo(_0x46778d,_0x1c788e,_0xad4b13,_0x69e7d7){if(v(_0x46778d['path']))return ea(_0x46778d,_0x1c788e,_0xad4b13,_0x69e7d7);{const _0xb2a666=_0x1c788e['get'](w());_0xad4b13==null&&_0xb2a666!=null&&(_0xad4b13=Ee(_0xb2a666,w()));let _0x41c9ba=[];const _0x3519d0=y(_0x46778d['path']),_0x3067ee=_0x46778d['operationForChild'](_0x3519d0),_0x45aa67=_0x1c788e['children']['get'](_0x3519d0);if(_0x45aa67&&_0x3067ee){const _0x35bd50=_0xad4b13?_0xad4b13['getImmediateChild'](_0x3519d0):null,_0x23cb40=Ho(_0x69e7d7,_0x3519d0);_0x41c9ba=_0x41c9ba['concat'](Zo(_0x3067ee,_0x45aa67,_0x35bd50,_0x23cb40));}return _0xb2a666&&(_0x41c9ba=_0x41c9ba['concat'](rs(_0xb2a666,_0x46778d,_0x69e7d7,_0xad4b13))),_0x41c9ba;}}function ea(_0x2947d0,_0x8163ce,_0x58084b,_0x1ea3a0){const _0x5eafff=_0x8163ce['get'](w());_0x58084b==null&&_0x5eafff!=null&&(_0x58084b=Ee(_0x5eafff,w()));let _0x3e03c6=[];return _0x8163ce['children']['inorderTraversal']((_0x541d34,_0x488abf)=>{const _0x7a89a0=_0x58084b?_0x58084b['getImmediateChild'](_0x541d34):null,_0x519c1f=Ho(_0x1ea3a0,_0x541d34),_0x3052f3=_0x2947d0['operationForChild'](_0x541d34);_0x3052f3&&(_0x3e03c6=_0x3e03c6['concat'](ea(_0x3052f3,_0x488abf,_0x7a89a0,_0x519c1f)));}),_0x5eafff&&(_0x3e03c6=_0x3e03c6['concat'](rs(_0x5eafff,_0x2947d0,_0x1ea3a0,_0x58084b))),_0x3e03c6;}function ta(_0x2597cb,_0x6fc636){const _0x38ffe8=_0x6fc636['query'],_0x12d0f6=xt(_0x2597cb,_0x38ffe8);return{'hashFn':()=>(Mu(_0x6fc636)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x121113=>{if(_0x121113==='ok')return _0x12d0f6?Qu(_0x2597cb,_0x38ffe8['_path'],_0x12d0f6):Yu(_0x2597cb,_0x38ffe8['_path']);{const _0x3f76b5=Kl(_0x121113,_0x38ffe8);return Cn(_0x2597cb,_0x38ffe8,null,_0x3f76b5);}}};}function xt(_0xd98c33,_0x57c727){const _0x5bd05c=Un(_0x57c727);return _0xd98c33['queryToTagMap']['get'](_0x5bd05c);}function Un(_0x1948e2){return _0x1948e2['_path']['toString']()+'$'+_0x1948e2['_queryIdentifier'];}function as(_0x216518,_0x9bcdb){return _0x216518['tagToQueryMap']['get'](_0x9bcdb);}function cs(_0x52f5ee){const _0x12b536=_0x52f5ee['indexOf']('$');return f(_0x12b536!==-0x1&&_0x12b536<_0x52f5ee['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x52f5ee['substr'](_0x12b536+0x1),'path':new C(_0x52f5ee['substr'](0x0,_0x12b536))};}function ls(_0x4677a5,_0x23a20c,_0x1d9996){const _0x1d3b30=_0x4677a5['syncPointTree_']['get'](_0x23a20c);f(_0x1d3b30,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x1cdf62=Ln(_0x4677a5['pendingWriteTree_'],_0x23a20c);return rs(_0x1d3b30,_0x1d9996,_0x1cdf62,null);}function Zu(_0x5ec133){return _0x5ec133['fold']((_0x5c3899,_0x4b532e,_0x5bd585)=>{if(_0x4b532e&&Te(_0x4b532e))return[xn(_0x4b532e)];{let _0x394cf8=[];return _0x4b532e&&(_0x394cf8=Yo(_0x4b532e)),x(_0x5bd585,(_0x54ea73,_0xcfea5f)=>{_0x394cf8=_0x394cf8['concat'](_0xcfea5f);}),_0x394cf8;}});}function bt(_0x4097f9){return _0x4097f9['_queryParams']['loadsAllData']()&&!_0x4097f9['_queryParams']['isDefault']()?new(qu())(_0x4097f9['_repo'],_0x4097f9['_path']):_0x4097f9;}function ed(_0x5d234d,_0x346116){for(let _0x57dc78=0x0;_0x57dc78<_0x346116['length'];++_0x57dc78){const _0x124721=_0x346116[_0x57dc78];if(!_0x124721['_queryParams']['loadsAllData']()){const _0x38f083=Un(_0x124721),_0x5329e1=_0x5d234d['queryToTagMap']['get'](_0x38f083);_0x5d234d['queryToTagMap']['delete'](_0x38f083),_0x5d234d['tagToQueryMap']['delete'](_0x5329e1);}}}function td(){return zu++;}function nd(_0x460c4b,_0x362335,_0x305b1d){const _0x4883fc=_0x362335['_path'],_0x10597e=xt(_0x460c4b,_0x362335),_0x3dd747=ta(_0x460c4b,_0x305b1d),_0x1843a1=_0x460c4b['listenProvider_']['startListening'](bt(_0x362335),_0x10597e,_0x3dd747['hashFn'],_0x3dd747['onComplete']),_0x2bafdf=_0x460c4b['syncPointTree_']['subtree'](_0x4883fc);if(_0x10597e)f(!Te(_0x2bafdf['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x272ec8=_0x2bafdf['fold']((_0x14abe3,_0x373326,_0x53c3c4)=>{if(!v(_0x14abe3)&&_0x373326&&Te(_0x373326))return[xn(_0x373326)['query']];{let _0x19d164=[];return _0x373326&&(_0x19d164=_0x19d164['concat'](Yo(_0x373326)['map'](_0x23caa9=>_0x23caa9['query']))),x(_0x53c3c4,(_0x59b467,_0x48450c)=>{_0x19d164=_0x19d164['concat'](_0x48450c);}),_0x19d164;}});for(let _0x5ae7ef=0x0;_0x5ae7ef<_0x272ec8['length'];++_0x5ae7ef){const _0x540d61=_0x272ec8[_0x5ae7ef];_0x460c4b['listenProvider_']['stopListening'](bt(_0x540d61),xt(_0x460c4b,_0x540d61));}}return _0x1843a1;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x459c6c){this['node_']=_0x459c6c;}['getImmediateChild'](_0x10cb7b){const _0x286225=this['node_']['getImmediateChild'](_0x10cb7b);return new hs(_0x286225);}['node'](){return this['node_'];}}class us{constructor(_0x1f42a2,_0x2ef757){this['syncTree_']=_0x1f42a2,this['path_']=_0x2ef757;}['getImmediateChild'](_0x215926){const _0x229d32=k(this['path_'],_0x215926);return new us(this['syncTree_'],_0x229d32);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x5f52ef){return _0x5f52ef=_0x5f52ef||{},_0x5f52ef['timestamp']=_0x5f52ef['timestamp']||new Date()['getTime'](),_0x5f52ef;},gr=function(_0x325332,_0xeb5162,_0x13da1f){if(!_0x325332||typeof _0x325332!='object')return _0x325332;if(f('.sv'in _0x325332,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x325332['.sv']=='string')return sd(_0x325332['.sv'],_0xeb5162,_0x13da1f);if(typeof _0x325332['.sv']=='object')return rd(_0x325332['.sv'],_0xeb5162);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x325332,null,0x2));},sd=function(_0xd83a35,_0x20fabb,_0x1b9a21){switch(_0xd83a35){case'timestamp':return _0x1b9a21['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0xd83a35);}},rd=function(_0x8a3a67,_0x313cbe,_0x3525b5){_0x8a3a67['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x8a3a67,null,0x2));const _0x181b54=_0x8a3a67['increment'];typeof _0x181b54!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x181b54);const _0x360a04=_0x313cbe['node']();if(f(_0x360a04!==null&&typeof _0x360a04<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x360a04['isLeafNode']())return _0x181b54;const _0x30918f=_0x360a04['getValue']();return typeof _0x30918f!='number'?_0x181b54:_0x30918f+_0x181b54;},na=function(_0x581394,_0x14f86a,_0x9504f6,_0x136967){return fs(_0x14f86a,new us(_0x9504f6,_0x581394),_0x136967);},ds=function(_0x105a38,_0x590973,_0xc8f26a){return fs(_0x105a38,new hs(_0x590973),_0xc8f26a);};function fs(_0x977ffc,_0x378085,_0x55e9fe){const _0x56f39b=_0x977ffc['getPriority']()['val'](),_0x40ddd9=gr(_0x56f39b,_0x378085['getImmediateChild']('.priority'),_0x55e9fe);let _0x5a1f01;if(_0x977ffc['isLeafNode']()){const _0xbcb076=_0x977ffc,_0x26e475=gr(_0xbcb076['getValue'](),_0x378085,_0x55e9fe);return _0x26e475!==_0xbcb076['getValue']()||_0x40ddd9!==_0xbcb076['getPriority']()['val']()?new D(_0x26e475,P(_0x40ddd9)):_0x977ffc;}else{const _0x13deb2=_0x977ffc;return _0x5a1f01=_0x13deb2,_0x40ddd9!==_0x13deb2['getPriority']()['val']()&&(_0x5a1f01=_0x5a1f01['updatePriority'](new D(_0x40ddd9))),_0x13deb2['forEachChild'](R,(_0x16ef6d,_0x192fd1)=>{const _0x70e86=fs(_0x192fd1,_0x378085['getImmediateChild'](_0x16ef6d),_0x55e9fe);_0x70e86!==_0x192fd1&&(_0x5a1f01=_0x5a1f01['updateImmediateChild'](_0x16ef6d,_0x70e86));}),_0x5a1f01;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x5b9ae5='',_0x41b2ff=null,_0x118c07={'children':{},'childCount':0x0}){this['name']=_0x5b9ae5,this['parent']=_0x41b2ff,this['node']=_0x118c07;}}function Wn(_0x26f8be,_0x274ade){let _0x1d53ee=_0x274ade instanceof C?_0x274ade:new C(_0x274ade),_0x52ce35=_0x26f8be,_0xcb0fdb=y(_0x1d53ee);for(;_0xcb0fdb!==null;){const _0x17d1a2=De(_0x52ce35['node']['children'],_0xcb0fdb)||{'children':{},'childCount':0x0};_0x52ce35=new ps(_0xcb0fdb,_0x52ce35,_0x17d1a2),_0x1d53ee=b(_0x1d53ee),_0xcb0fdb=y(_0x1d53ee);}return _0x52ce35;}function Ge(_0x3fbac2){return _0x3fbac2['node']['value'];}function _s(_0xec67e,_0xfd8fe2){_0xec67e['node']['value']=_0xfd8fe2,Ai(_0xec67e);}function ia(_0x4c8870){return _0x4c8870['node']['childCount']>0x0;}function od(_0x251fc0){return Ge(_0x251fc0)===void 0x0&&!ia(_0x251fc0);}function Bn(_0x19ac82,_0x3c5003){x(_0x19ac82['node']['children'],(_0x2917f5,_0x42d97f)=>{_0x3c5003(new ps(_0x2917f5,_0x19ac82,_0x42d97f));});}function sa(_0x350d6f,_0x464847,_0x3b5b9f,_0x180838){_0x3b5b9f&&_0x464847(_0x350d6f),Bn(_0x350d6f,_0x233380=>{sa(_0x233380,_0x464847,!0x0);});}function ad(_0x153c07,_0x5e2518,_0x530267){let _0xb1cc0a=_0x153c07['parent'];for(;_0xb1cc0a!==null;){if(_0x5e2518(_0xb1cc0a))return!0x0;_0xb1cc0a=_0xb1cc0a['parent'];}return!0x1;}function qt(_0x28fd28){return new C(_0x28fd28['parent']===null?_0x28fd28['name']:qt(_0x28fd28['parent'])+'/'+_0x28fd28['name']);}function Ai(_0x14db4f){_0x14db4f['parent']!==null&&cd(_0x14db4f['parent'],_0x14db4f['name'],_0x14db4f);}function cd(_0x1ef163,_0x3c0748,_0x6f259c){const _0x39327b=od(_0x6f259c),_0x232d37=J(_0x1ef163['node']['children'],_0x3c0748);_0x39327b&&_0x232d37?(delete _0x1ef163['node']['children'][_0x3c0748],_0x1ef163['node']['childCount']--,Ai(_0x1ef163)):!_0x39327b&&!_0x232d37&&(_0x1ef163['node']['children'][_0x3c0748]=_0x6f259c['node'],_0x1ef163['node']['childCount']++,Ai(_0x1ef163));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x380ee4){return typeof _0x380ee4=='string'&&_0x380ee4['length']!==0x0&&!ld['test'](_0x380ee4);},ra=function(_0xfdb6fd){return typeof _0xfdb6fd=='string'&&_0xfdb6fd['length']!==0x0&&!hd['test'](_0xfdb6fd);},ud=function(_0x5ae48e){return _0x5ae48e&&(_0x5ae48e=_0x5ae48e['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x5ae48e);},Tn=function(_0x31c828){return _0x31c828===null||typeof _0x31c828=='string'||typeof _0x31c828=='number'&&!Vi(_0x31c828)||_0x31c828&&typeof _0x31c828=='object'&&J(_0x31c828,'.sv');},zt=function(_0x111454,_0x1376be,_0x23eb5e,_0x49bff9){_0x49bff9&&_0x1376be===void 0x0||jt(Pn(_0x111454,'value'),_0x1376be,_0x23eb5e);},jt=function(_0x18793d,_0x3d828f,_0x25f379){const _0x4f195c=_0x25f379 instanceof C?new Ah(_0x25f379,_0x18793d):_0x25f379;if(_0x3d828f===void 0x0)throw new Error(_0x18793d+'contains\x20undefined\x20'+Pe(_0x4f195c));if(typeof _0x3d828f=='function')throw new Error(_0x18793d+'contains\x20a\x20function\x20'+Pe(_0x4f195c)+'\x20with\x20contents\x20=\x20'+_0x3d828f['toString']());if(Vi(_0x3d828f))throw new Error(_0x18793d+'contains\x20'+_0x3d828f['toString']()+'\x20'+Pe(_0x4f195c));if(typeof _0x3d828f=='string'&&_0x3d828f['length']>ai/0x3&&On(_0x3d828f)>ai)throw new Error(_0x18793d+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x4f195c)+'\x20(\x27'+_0x3d828f['substring'](0x0,0x32)+'...\x27)');if(_0x3d828f&&typeof _0x3d828f=='object'){let _0xb1d138=!0x1,_0x48a9f9=!0x1;if(x(_0x3d828f,(_0x1f1fdf,_0x5bb7b3)=>{if(_0x1f1fdf==='.value')_0xb1d138=!0x0;else{if(_0x1f1fdf!=='.priority'&&_0x1f1fdf!=='.sv'&&(_0x48a9f9=!0x0,!gs(_0x1f1fdf)))throw new Error(_0x18793d+'\x20contains\x20an\x20invalid\x20key\x20('+_0x1f1fdf+')\x20'+Pe(_0x4f195c)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x4f195c,_0x1f1fdf),jt(_0x18793d,_0x5bb7b3,_0x4f195c),Nh(_0x4f195c);}),_0xb1d138&&_0x48a9f9)throw new Error(_0x18793d+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x4f195c)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x4db701,_0x2b0a33){let _0x23aab9,_0x47cd7e;for(_0x23aab9=0x0;_0x23aab9<_0x2b0a33['length'];_0x23aab9++){_0x47cd7e=_0x2b0a33[_0x23aab9];const _0x2522a7=Pt(_0x47cd7e);for(let _0x34a4f8=0x0;_0x34a4f8<_0x2522a7['length'];_0x34a4f8++)if(!(_0x2522a7[_0x34a4f8]==='.priority'&&_0x34a4f8===_0x2522a7['length']-0x1)){if(!gs(_0x2522a7[_0x34a4f8]))throw new Error(_0x4db701+'contains\x20an\x20invalid\x20key\x20('+_0x2522a7[_0x34a4f8]+')\x20in\x20path\x20'+_0x47cd7e['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x2b0a33['sort'](Rh);let _0x44d88a=null;for(_0x23aab9=0x0;_0x23aab9<_0x2b0a33['length'];_0x23aab9++){if(_0x47cd7e=_0x2b0a33[_0x23aab9],_0x44d88a!==null&&G(_0x44d88a,_0x47cd7e))throw new Error(_0x4db701+'contains\x20a\x20path\x20'+_0x44d88a['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x47cd7e['toString']());_0x44d88a=_0x47cd7e;}},fd=function(_0x49e4b1,_0x3e3f6d,_0x2679ad,_0x1b9f32){const _0x2056e5=Pn(_0x49e4b1,'values');if(!(_0x3e3f6d&&typeof _0x3e3f6d=='object')||Array['isArray'](_0x3e3f6d))throw new Error(_0x2056e5+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x5de0c8=[];x(_0x3e3f6d,(_0x542b93,_0x1bc5b8)=>{const _0xd7d81c=new C(_0x542b93);if(jt(_0x2056e5,_0x1bc5b8,k(_0x2679ad,_0xd7d81c)),zi(_0xd7d81c)==='.priority'&&!Tn(_0x1bc5b8))throw new Error(_0x2056e5+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0xd7d81c['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x5de0c8['push'](_0xd7d81c);}),dd(_0x2056e5,_0x5de0c8);},ms=function(_0x525492,_0x539829,_0x14ab2e,_0x12b719){if(!ra(_0x14ab2e))throw new Error(Pn(_0x525492,_0x539829)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x14ab2e+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x2d8c22,_0x57af25,_0x3ee85e,_0x2914ab){_0x3ee85e&&(_0x3ee85e=_0x3ee85e['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x2d8c22,_0x57af25,_0x3ee85e);},ys=function(_0x16f9bf,_0x3181a2){if(y(_0x3181a2)==='.info')throw new Error(_0x16f9bf+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x3f3d22,_0x57c589){const _0x43a0ad=_0x57c589['path']['toString']();if(typeof _0x57c589['repoInfo']['host']!='string'||_0x57c589['repoInfo']['host']['length']===0x0||!gs(_0x57c589['repoInfo']['namespace'])&&_0x57c589['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x43a0ad['length']!==0x0&&!ud(_0x43a0ad))throw new Error(Pn(_0x3f3d22,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0xd6368e,_0x331c97){let _0x35bb70=null;for(let _0x4aedbd=0x0;_0x4aedbd<_0x331c97['length'];_0x4aedbd++){const _0x615cdd=_0x331c97[_0x4aedbd],_0x110739=_0x615cdd['getPath']();_0x35bb70!==null&&!ji(_0x110739,_0x35bb70['path'])&&(_0xd6368e['eventLists_']['push'](_0x35bb70),_0x35bb70=null),_0x35bb70===null&&(_0x35bb70={'events':[],'path':_0x110739}),_0x35bb70['events']['push'](_0x615cdd);}_0x35bb70&&_0xd6368e['eventLists_']['push'](_0x35bb70);}function oa(_0x53c7f8,_0x10a8a3,_0x136578){Vn(_0x53c7f8,_0x136578),aa(_0x53c7f8,_0xfada53=>ji(_0xfada53,_0x10a8a3));}function H(_0x478767,_0x3b575e,_0x47e928){Vn(_0x478767,_0x47e928),aa(_0x478767,_0x2b3ac7=>G(_0x2b3ac7,_0x3b575e)||G(_0x3b575e,_0x2b3ac7));}function aa(_0x1fd3d2,_0x4bd0b7){_0x1fd3d2['recursionDepth_']++;let _0x2086af=!0x0;for(let _0x263e09=0x0;_0x263e09<_0x1fd3d2['eventLists_']['length'];_0x263e09++){const _0xa734b2=_0x1fd3d2['eventLists_'][_0x263e09];if(_0xa734b2){const _0x307cc4=_0xa734b2['path'];_0x4bd0b7(_0x307cc4)?(md(_0x1fd3d2['eventLists_'][_0x263e09]),_0x1fd3d2['eventLists_'][_0x263e09]=null):_0x2086af=!0x1;}}_0x2086af&&(_0x1fd3d2['eventLists_']=[]),_0x1fd3d2['recursionDepth_']--;}function md(_0x1675e5){for(let _0xa7b459=0x0;_0xa7b459<_0x1675e5['events']['length'];_0xa7b459++){const _0x21f5a5=_0x1675e5['events'][_0xa7b459];if(_0x21f5a5!==null){_0x1675e5['events'][_0xa7b459]=null;const _0x4518e7=_0x21f5a5['getEventRunner']();wt&&L('event:\x20'+_0x21f5a5['toString']()),ht(_0x4518e7);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x51f6ee,_0x917821,_0x24a5a5,_0x326066){this['repoInfo_']=_0x51f6ee,this['forceRestClient_']=_0x917821,this['authTokenProvider_']=_0x24a5a5,this['appCheckProvider_']=_0x326066,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x21254f,_0x34fe55,_0xf63e4d){if(_0x21254f['stats_']=Gi(_0x21254f['repoInfo_']),_0x21254f['forceRestClient_']||Xl())_0x21254f['server_']=new pn(_0x21254f['repoInfo_'],(_0x5e6c09,_0x140162,_0x83cf5a,_0xdfc63e)=>{mr(_0x21254f,_0x5e6c09,_0x140162,_0x83cf5a,_0xdfc63e);},_0x21254f['authTokenProvider_'],_0x21254f['appCheckProvider_']),setTimeout(()=>yr(_0x21254f,!0x0),0x0);else{if(typeof _0xf63e4d<'u'&&_0xf63e4d!==null){if(typeof _0xf63e4d!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0xf63e4d);}catch(_0x3ca9b0){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x3ca9b0);}}_0x21254f['persistentConnection_']=new se(_0x21254f['repoInfo_'],_0x34fe55,(_0x2ca033,_0x498c8f,_0x121987,_0x18a3dc)=>{mr(_0x21254f,_0x2ca033,_0x498c8f,_0x121987,_0x18a3dc);},_0x5c4983=>{yr(_0x21254f,_0x5c4983);},_0x6edbab=>{Id(_0x21254f,_0x6edbab);},_0x21254f['authTokenProvider_'],_0x21254f['appCheckProvider_'],_0xf63e4d),_0x21254f['server_']=_0x21254f['persistentConnection_'];}_0x21254f['authTokenProvider_']['addTokenChangeListener'](_0x5b5c28=>{_0x21254f['server_']['refreshAuthToken'](_0x5b5c28);}),_0x21254f['appCheckProvider_']['addTokenChangeListener'](_0x539396=>{_0x21254f['server_']['refreshAppCheckToken'](_0x539396['token']);}),_0x21254f['statsReporter_']=ih(_0x21254f['repoInfo_'],()=>new iu(_0x21254f['stats_'],_0x21254f['server_'])),_0x21254f['infoData_']=new Xh(),_0x21254f['infoSyncTree_']=new _r({'startListening':(_0x5c264e,_0x4218f0,_0x48273f,_0x1433e0)=>{let _0x45eb42=[];const _0x321697=_0x21254f['infoData_']['getNode'](_0x5c264e['_path']);return _0x321697['isEmpty']()||(_0x45eb42=Gt(_0x21254f['infoSyncTree_'],_0x5c264e['_path'],_0x321697),setTimeout(()=>{_0x1433e0('ok');},0x0)),_0x45eb42;},'stopListening':()=>{}}),vs(_0x21254f,'connected',!0x1),_0x21254f['serverSyncTree_']=new _r({'startListening':(_0x3aadc9,_0x22cf1a,_0x3a537c,_0x445f95)=>(_0x21254f['server_']['listen'](_0x3aadc9,_0x3a537c,_0x22cf1a,(_0x282e21,_0x5218a6)=>{const _0x83955f=_0x445f95(_0x282e21,_0x5218a6);H(_0x21254f['eventQueue_'],_0x3aadc9['_path'],_0x83955f);}),[]),'stopListening':(_0x1c7c03,_0x519ee7)=>{_0x21254f['server_']['unlisten'](_0x1c7c03,_0x519ee7);}});}function la(_0x2bb1fd){const _0x56a70b=_0x2bb1fd['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x56a70b;}function Kt(_0x55a93e){return id({'timestamp':la(_0x55a93e)});}function mr(_0x273686,_0x337288,_0x198d2e,_0x312c48,_0x18f5d0){_0x273686['dataUpdateCount']++;const _0x49ecc9=new C(_0x337288);_0x198d2e=_0x273686['interceptServerDataCallback_']?_0x273686['interceptServerDataCallback_'](_0x337288,_0x198d2e):_0x198d2e;let _0x96e018=[];if(_0x18f5d0){if(_0x312c48){const _0x587267=hn(_0x198d2e,_0x4c0ad4=>P(_0x4c0ad4));_0x96e018=Ju(_0x273686['serverSyncTree_'],_0x49ecc9,_0x587267,_0x18f5d0);}else{const _0x1c7b6f=P(_0x198d2e);_0x96e018=Xo(_0x273686['serverSyncTree_'],_0x49ecc9,_0x1c7b6f,_0x18f5d0);}}else{if(_0x312c48){const _0x4cabc0=hn(_0x198d2e,_0xd0b8d6=>P(_0xd0b8d6));_0x96e018=Ku(_0x273686['serverSyncTree_'],_0x49ecc9,_0x4cabc0);}else{const _0x26edc5=P(_0x198d2e);_0x96e018=Gt(_0x273686['serverSyncTree_'],_0x49ecc9,_0x26edc5);}}let _0x1a3762=_0x49ecc9;_0x96e018['length']>0x0&&(_0x1a3762=it(_0x273686,_0x49ecc9)),H(_0x273686['eventQueue_'],_0x1a3762,_0x96e018);}function yr(_0x14adac,_0x78c95a){vs(_0x14adac,'connected',_0x78c95a),_0x78c95a===!0x1&&Sd(_0x14adac);}function Id(_0x43ff61,_0x4de67f){x(_0x4de67f,(_0x5d7f68,_0x13b0e4)=>{vs(_0x43ff61,_0x5d7f68,_0x13b0e4);});}function vs(_0x156004,_0x4d2d2c,_0x48d569){const _0xeccfa=new C('/.info/'+_0x4d2d2c),_0x3442e2=P(_0x48d569);_0x156004['infoData_']['updateSnapshot'](_0xeccfa,_0x3442e2);const _0x41149a=Gt(_0x156004['infoSyncTree_'],_0xeccfa,_0x3442e2);H(_0x156004['eventQueue_'],_0xeccfa,_0x41149a);}function Hn(_0x105ffc){return _0x105ffc['nextWriteId_']++;}function wd(_0x3effcc,_0x226ccc,_0x32ee8d){const _0x706857=Xu(_0x3effcc['serverSyncTree_'],_0x226ccc);return _0x706857!=null?Promise['resolve'](_0x706857):_0x3effcc['server_']['get'](_0x226ccc)['then'](_0x47f5e8=>{const _0x494e05=P(_0x47f5e8)['withIndex'](_0x226ccc['_queryParams']['getIndex']());Ri(_0x3effcc['serverSyncTree_'],_0x226ccc,_0x32ee8d,!0x0);let _0x1f4576;if(_0x226ccc['_queryParams']['loadsAllData']())_0x1f4576=Gt(_0x3effcc['serverSyncTree_'],_0x226ccc['_path'],_0x494e05);else{const _0x9fa365=xt(_0x3effcc['serverSyncTree_'],_0x226ccc);_0x1f4576=Xo(_0x3effcc['serverSyncTree_'],_0x226ccc['_path'],_0x494e05,_0x9fa365);}return H(_0x3effcc['eventQueue_'],_0x226ccc['_path'],_0x1f4576),Cn(_0x3effcc['serverSyncTree_'],_0x226ccc,_0x32ee8d,null,!0x0),_0x494e05;},_0x36a836=>(dt(_0x3effcc,'get\x20for\x20query\x20'+O(_0x226ccc)+'\x20failed:\x20'+_0x36a836),Promise['reject'](new Error(_0x36a836))));}function Cd(_0x336d2b,_0x367cfd,_0x1c0291,_0x4c1144,_0x3af2ef){dt(_0x336d2b,'set',{'path':_0x367cfd['toString'](),'value':_0x1c0291,'priority':_0x4c1144});const _0x2ab5ac=Kt(_0x336d2b),_0x169209=P(_0x1c0291,_0x4c1144),_0x19b297=Fn(_0x336d2b['serverSyncTree_'],_0x367cfd),_0x161ca9=ds(_0x169209,_0x19b297,_0x2ab5ac),_0x136baa=Hn(_0x336d2b),_0x35f6d9=os(_0x336d2b['serverSyncTree_'],_0x367cfd,_0x161ca9,_0x136baa,!0x0);Vn(_0x336d2b['eventQueue_'],_0x35f6d9),_0x336d2b['server_']['put'](_0x367cfd['toString'](),_0x169209['val'](!0x0),(_0x1dfc79,_0x2a305)=>{const _0x1799b3=_0x1dfc79==='ok';_0x1799b3||U('set\x20at\x20'+_0x367cfd+'\x20failed:\x20'+_0x1dfc79);const _0x13e1a1=pe(_0x336d2b['serverSyncTree_'],_0x136baa,!_0x1799b3);H(_0x336d2b['eventQueue_'],_0x367cfd,_0x13e1a1),ki(_0x336d2b,_0x3af2ef,_0x1dfc79,_0x2a305);});const _0x10b94e=Is(_0x336d2b,_0x367cfd);it(_0x336d2b,_0x10b94e),H(_0x336d2b['eventQueue_'],_0x10b94e,[]);}function Td(_0x450170,_0x1e8d9b,_0x108a4c,_0x4340fc){dt(_0x450170,'update',{'path':_0x1e8d9b['toString'](),'value':_0x108a4c});let _0x1d7682=!0x0;const _0x46a9b3=Kt(_0x450170),_0x4361f9={};if(x(_0x108a4c,(_0x2dc8c4,_0x1363fb)=>{_0x1d7682=!0x1,_0x4361f9[_0x2dc8c4]=na(k(_0x1e8d9b,_0x2dc8c4),P(_0x1363fb),_0x450170['serverSyncTree_'],_0x46a9b3);}),_0x1d7682)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x450170,_0x4340fc,'ok',void 0x0);else{const _0x59ff4d=Hn(_0x450170),_0x2d87d9=ju(_0x450170['serverSyncTree_'],_0x1e8d9b,_0x4361f9,_0x59ff4d);Vn(_0x450170['eventQueue_'],_0x2d87d9),_0x450170['server_']['merge'](_0x1e8d9b['toString'](),_0x108a4c,(_0x15bef0,_0x31cf32)=>{const _0xe24de2=_0x15bef0==='ok';_0xe24de2||U('update\x20at\x20'+_0x1e8d9b+'\x20failed:\x20'+_0x15bef0);const _0x4a77f1=pe(_0x450170['serverSyncTree_'],_0x59ff4d,!_0xe24de2),_0x7c12b8=_0x4a77f1['length']>0x0?it(_0x450170,_0x1e8d9b):_0x1e8d9b;H(_0x450170['eventQueue_'],_0x7c12b8,_0x4a77f1),ki(_0x450170,_0x4340fc,_0x15bef0,_0x31cf32);}),x(_0x108a4c,_0x3a2fcd=>{const _0x790024=Is(_0x450170,k(_0x1e8d9b,_0x3a2fcd));it(_0x450170,_0x790024);}),H(_0x450170['eventQueue_'],_0x1e8d9b,[]);}}function Sd(_0x413d74){dt(_0x413d74,'onDisconnectEvents');const _0x2f5468=Kt(_0x413d74),_0x176033=_n();Ii(_0x413d74['onDisconnect_'],w(),(_0x1e0f4a,_0x14e9fd)=>{const _0x8d390f=na(_0x1e0f4a,_0x14e9fd,_0x413d74['serverSyncTree_'],_0x2f5468);Fo(_0x176033,_0x1e0f4a,_0x8d390f);});let _0x26c707=[];Ii(_0x176033,w(),(_0x34e4f0,_0x387f1e)=>{_0x26c707=_0x26c707['concat'](Gt(_0x413d74['serverSyncTree_'],_0x34e4f0,_0x387f1e));const _0x2e0542=Is(_0x413d74,_0x34e4f0);it(_0x413d74,_0x2e0542);}),_0x413d74['onDisconnect_']=_n(),H(_0x413d74['eventQueue_'],w(),_0x26c707);}function bd(_0x4bc7e7,_0x30e972,_0x42c1e6){let _0x4e8cd7;y(_0x30e972['_path'])==='.info'?_0x4e8cd7=Ri(_0x4bc7e7['infoSyncTree_'],_0x30e972,_0x42c1e6):_0x4e8cd7=Ri(_0x4bc7e7['serverSyncTree_'],_0x30e972,_0x42c1e6),oa(_0x4bc7e7['eventQueue_'],_0x30e972['_path'],_0x4e8cd7);}function Rd(_0x264e6e,_0x2b04fc,_0x575059){let _0x28f694;y(_0x2b04fc['_path'])==='.info'?_0x28f694=Cn(_0x264e6e['infoSyncTree_'],_0x2b04fc,_0x575059):_0x28f694=Cn(_0x264e6e['serverSyncTree_'],_0x2b04fc,_0x575059),oa(_0x264e6e['eventQueue_'],_0x2b04fc['_path'],_0x28f694);}function ha(_0x3d4e0b){_0x3d4e0b['persistentConnection_']&&_0x3d4e0b['persistentConnection_']['interrupt'](ca);}function Ad(_0x36a442){_0x36a442['persistentConnection_']&&_0x36a442['persistentConnection_']['resume'](ca);}function dt(_0x5a9253,..._0x4a8c09){let _0x2c91f3='';_0x5a9253['persistentConnection_']&&(_0x2c91f3=_0x5a9253['persistentConnection_']['id']+':'),L(_0x2c91f3,..._0x4a8c09);}function ki(_0x58b4b1,_0x236705,_0x531c95,_0x5a0610){_0x236705&&ht(()=>{if(_0x531c95==='ok')_0x236705(null);else{const _0x574d95=(_0x531c95||'error')['toUpperCase']();let _0x32f460=_0x574d95;_0x5a0610&&(_0x32f460+=':\x20'+_0x5a0610);const _0x5a0148=new Error(_0x32f460);_0x5a0148['code']=_0x574d95,_0x236705(_0x5a0148);}});}function kd(_0x3a6d5e,_0x304a7e,_0x140ef6,_0x5dfa73,_0x374554,_0x15d02c){dt(_0x3a6d5e,'transaction\x20on\x20'+_0x304a7e);const _0x2c68a4={'path':_0x304a7e,'update':_0x140ef6,'onComplete':_0x5dfa73,'status':null,'order':so(),'applyLocally':_0x15d02c,'retryCount':0x0,'unwatcher':_0x374554,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x3d785a=Es(_0x3a6d5e,_0x304a7e,void 0x0);_0x2c68a4['currentInputSnapshot']=_0x3d785a;const _0x400328=_0x2c68a4['update'](_0x3d785a['val']());if(_0x400328===void 0x0)_0x2c68a4['unwatcher'](),_0x2c68a4['currentOutputSnapshotRaw']=null,_0x2c68a4['currentOutputSnapshotResolved']=null,_0x2c68a4['onComplete']&&_0x2c68a4['onComplete'](null,!0x1,_0x2c68a4['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x400328,_0x2c68a4['path']),_0x2c68a4['status']=0x0;const _0x27ae55=Wn(_0x3a6d5e['transactionQueueTree_'],_0x304a7e),_0x1f15d5=Ge(_0x27ae55)||[];_0x1f15d5['push'](_0x2c68a4),_s(_0x27ae55,_0x1f15d5);let _0x3f3aea;typeof _0x400328=='object'&&_0x400328!==null&&J(_0x400328,'.priority')?(_0x3f3aea=De(_0x400328,'.priority'),f(Tn(_0x3f3aea),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x3f3aea=(Fn(_0x3a6d5e['serverSyncTree_'],_0x304a7e)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x575ddb=Kt(_0x3a6d5e),_0x6cab29=P(_0x400328,_0x3f3aea),_0x320ece=ds(_0x6cab29,_0x3d785a,_0x575ddb);_0x2c68a4['currentOutputSnapshotRaw']=_0x6cab29,_0x2c68a4['currentOutputSnapshotResolved']=_0x320ece,_0x2c68a4['currentWriteId']=Hn(_0x3a6d5e);const _0x120a17=os(_0x3a6d5e['serverSyncTree_'],_0x304a7e,_0x320ece,_0x2c68a4['currentWriteId'],_0x2c68a4['applyLocally']);H(_0x3a6d5e['eventQueue_'],_0x304a7e,_0x120a17),$n(_0x3a6d5e,_0x3a6d5e['transactionQueueTree_']);}}function Es(_0x13ed88,_0x198dcc,_0x278d41){return Fn(_0x13ed88['serverSyncTree_'],_0x198dcc,_0x278d41)||g['EMPTY_NODE'];}function $n(_0xa1df97,_0x2f961f=_0xa1df97['transactionQueueTree_']){if(_0x2f961f||Gn(_0xa1df97,_0x2f961f),Ge(_0x2f961f)){const _0x536591=da(_0xa1df97,_0x2f961f);f(_0x536591['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x536591['every'](_0x4324f8=>_0x4324f8['status']===0x0)&&Nd(_0xa1df97,qt(_0x2f961f),_0x536591);}else ia(_0x2f961f)&&Bn(_0x2f961f,_0x810aa5=>{$n(_0xa1df97,_0x810aa5);});}function Nd(_0x96b53a,_0x585db4,_0x15832b){const _0x36c5a2=_0x15832b['map'](_0x584691=>_0x584691['currentWriteId']),_0x380105=Es(_0x96b53a,_0x585db4,_0x36c5a2);let _0x3ca539=_0x380105;const _0x37584d=_0x380105['hash']();for(let _0x2d5ca3=0x0;_0x2d5ca3<_0x15832b['length'];_0x2d5ca3++){const _0x4501d5=_0x15832b[_0x2d5ca3];f(_0x4501d5['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x4501d5['status']=0x1,_0x4501d5['retryCount']++;const _0x4f5f6d=F(_0x585db4,_0x4501d5['path']);_0x3ca539=_0x3ca539['updateChild'](_0x4f5f6d,_0x4501d5['currentOutputSnapshotRaw']);}const _0x252920=_0x3ca539['val'](!0x0),_0x22b931=_0x585db4;_0x96b53a['server_']['put'](_0x22b931['toString'](),_0x252920,_0x49c9b5=>{dt(_0x96b53a,'transaction\x20put\x20response',{'path':_0x22b931['toString'](),'status':_0x49c9b5});let _0x5f7011=[];if(_0x49c9b5==='ok'){const _0x180bb2=[];for(let _0x3b8af4=0x0;_0x3b8af4<_0x15832b['length'];_0x3b8af4++)_0x15832b[_0x3b8af4]['status']=0x2,_0x5f7011=_0x5f7011['concat'](pe(_0x96b53a['serverSyncTree_'],_0x15832b[_0x3b8af4]['currentWriteId'])),_0x15832b[_0x3b8af4]['onComplete']&&_0x180bb2['push'](()=>_0x15832b[_0x3b8af4]['onComplete'](null,!0x0,_0x15832b[_0x3b8af4]['currentOutputSnapshotResolved'])),_0x15832b[_0x3b8af4]['unwatcher']();Gn(_0x96b53a,Wn(_0x96b53a['transactionQueueTree_'],_0x585db4)),$n(_0x96b53a,_0x96b53a['transactionQueueTree_']),H(_0x96b53a['eventQueue_'],_0x585db4,_0x5f7011);for(let _0x1e7cb8=0x0;_0x1e7cb8<_0x180bb2['length'];_0x1e7cb8++)ht(_0x180bb2[_0x1e7cb8]);}else{if(_0x49c9b5==='datastale'){for(let _0x4b2175=0x0;_0x4b2175<_0x15832b['length'];_0x4b2175++)_0x15832b[_0x4b2175]['status']===0x3?_0x15832b[_0x4b2175]['status']=0x4:_0x15832b[_0x4b2175]['status']=0x0;}else{U('transaction\x20at\x20'+_0x22b931['toString']()+'\x20failed:\x20'+_0x49c9b5);for(let _0x8f26e9=0x0;_0x8f26e9<_0x15832b['length'];_0x8f26e9++)_0x15832b[_0x8f26e9]['status']=0x4,_0x15832b[_0x8f26e9]['abortReason']=_0x49c9b5;}it(_0x96b53a,_0x585db4);}},_0x37584d);}function it(_0x3684ec,_0x3a0446){const _0x922bee=ua(_0x3684ec,_0x3a0446),_0x4ecc13=qt(_0x922bee),_0x42dbf5=da(_0x3684ec,_0x922bee);return Pd(_0x3684ec,_0x42dbf5,_0x4ecc13),_0x4ecc13;}function Pd(_0x4f5d0e,_0x3cc85d,_0x2870c0){if(_0x3cc85d['length']===0x0)return;const _0x429794=[];let _0x291619=[];const _0xb3e6f9=_0x3cc85d['filter'](_0x55e952=>_0x55e952['status']===0x0)['map'](_0x6afa7d=>_0x6afa7d['currentWriteId']);for(let _0x7460ed=0x0;_0x7460ed<_0x3cc85d['length'];_0x7460ed++){const _0x43a640=_0x3cc85d[_0x7460ed],_0xc50433=F(_0x2870c0,_0x43a640['path']);let _0x46546b=!0x1,_0xb02d00;if(f(_0xc50433!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x43a640['status']===0x4)_0x46546b=!0x0,_0xb02d00=_0x43a640['abortReason'],_0x291619=_0x291619['concat'](pe(_0x4f5d0e['serverSyncTree_'],_0x43a640['currentWriteId'],!0x0));else{if(_0x43a640['status']===0x0){if(_0x43a640['retryCount']>=yd)_0x46546b=!0x0,_0xb02d00='maxretry',_0x291619=_0x291619['concat'](pe(_0x4f5d0e['serverSyncTree_'],_0x43a640['currentWriteId'],!0x0));else{const _0x238d8d=Es(_0x4f5d0e,_0x43a640['path'],_0xb3e6f9);_0x43a640['currentInputSnapshot']=_0x238d8d;const _0x3c37e0=_0x3cc85d[_0x7460ed]['update'](_0x238d8d['val']());if(_0x3c37e0!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x3c37e0,_0x43a640['path']);let _0x1d4bcf=P(_0x3c37e0);typeof _0x3c37e0=='object'&&_0x3c37e0!=null&&J(_0x3c37e0,'.priority')||(_0x1d4bcf=_0x1d4bcf['updatePriority'](_0x238d8d['getPriority']()));const _0xfe03ad=_0x43a640['currentWriteId'],_0x22ab5e=Kt(_0x4f5d0e),_0x173519=ds(_0x1d4bcf,_0x238d8d,_0x22ab5e);_0x43a640['currentOutputSnapshotRaw']=_0x1d4bcf,_0x43a640['currentOutputSnapshotResolved']=_0x173519,_0x43a640['currentWriteId']=Hn(_0x4f5d0e),_0xb3e6f9['splice'](_0xb3e6f9['indexOf'](_0xfe03ad),0x1),_0x291619=_0x291619['concat'](os(_0x4f5d0e['serverSyncTree_'],_0x43a640['path'],_0x173519,_0x43a640['currentWriteId'],_0x43a640['applyLocally'])),_0x291619=_0x291619['concat'](pe(_0x4f5d0e['serverSyncTree_'],_0xfe03ad,!0x0));}else _0x46546b=!0x0,_0xb02d00='nodata',_0x291619=_0x291619['concat'](pe(_0x4f5d0e['serverSyncTree_'],_0x43a640['currentWriteId'],!0x0));}}}H(_0x4f5d0e['eventQueue_'],_0x2870c0,_0x291619),_0x291619=[],_0x46546b&&(_0x3cc85d[_0x7460ed]['status']=0x2,function(_0xb1e04b){setTimeout(_0xb1e04b,Math['floor'](0x0));}(_0x3cc85d[_0x7460ed]['unwatcher']),_0x3cc85d[_0x7460ed]['onComplete']&&(_0xb02d00==='nodata'?_0x429794['push'](()=>_0x3cc85d[_0x7460ed]['onComplete'](null,!0x1,_0x3cc85d[_0x7460ed]['currentInputSnapshot'])):_0x429794['push'](()=>_0x3cc85d[_0x7460ed]['onComplete'](new Error(_0xb02d00),!0x1,null))));}Gn(_0x4f5d0e,_0x4f5d0e['transactionQueueTree_']);for(let _0x32c934=0x0;_0x32c934<_0x429794['length'];_0x32c934++)ht(_0x429794[_0x32c934]);$n(_0x4f5d0e,_0x4f5d0e['transactionQueueTree_']);}function ua(_0x327641,_0x45c6a1){let _0x52ccba,_0x34d007=_0x327641['transactionQueueTree_'];for(_0x52ccba=y(_0x45c6a1);_0x52ccba!==null&&Ge(_0x34d007)===void 0x0;)_0x34d007=Wn(_0x34d007,_0x52ccba),_0x45c6a1=b(_0x45c6a1),_0x52ccba=y(_0x45c6a1);return _0x34d007;}function da(_0x17da72,_0x4eca6a){const _0x499c60=[];return fa(_0x17da72,_0x4eca6a,_0x499c60),_0x499c60['sort']((_0x397056,_0x25af0c)=>_0x397056['order']-_0x25af0c['order']),_0x499c60;}function fa(_0x235189,_0x112c91,_0x4bb379){const _0x1fda7b=Ge(_0x112c91);if(_0x1fda7b){for(let _0x1a9a1e=0x0;_0x1a9a1e<_0x1fda7b['length'];_0x1a9a1e++)_0x4bb379['push'](_0x1fda7b[_0x1a9a1e]);}Bn(_0x112c91,_0x54ce40=>{fa(_0x235189,_0x54ce40,_0x4bb379);});}function Gn(_0x29ba26,_0x4d73d5){const _0x47520d=Ge(_0x4d73d5);if(_0x47520d){let _0x4a85eb=0x0;for(let _0x9dc46f=0x0;_0x9dc46f<_0x47520d['length'];_0x9dc46f++)_0x47520d[_0x9dc46f]['status']!==0x2&&(_0x47520d[_0x4a85eb]=_0x47520d[_0x9dc46f],_0x4a85eb++);_0x47520d['length']=_0x4a85eb,_s(_0x4d73d5,_0x47520d['length']>0x0?_0x47520d:void 0x0);}Bn(_0x4d73d5,_0x434311=>{Gn(_0x29ba26,_0x434311);});}function Is(_0x44c03c,_0x21a0b2){const _0x5ce3ba=qt(ua(_0x44c03c,_0x21a0b2)),_0x149e6b=Wn(_0x44c03c['transactionQueueTree_'],_0x21a0b2);return ad(_0x149e6b,_0x58904c=>{ci(_0x44c03c,_0x58904c);}),ci(_0x44c03c,_0x149e6b),sa(_0x149e6b,_0x209135=>{ci(_0x44c03c,_0x209135);}),_0x5ce3ba;}function ci(_0x4221cb,_0x513966){const _0x38dceb=Ge(_0x513966);if(_0x38dceb){const _0xa19909=[];let _0x386881=[],_0x32fd48=-0x1;for(let _0x2775ad=0x0;_0x2775ad<_0x38dceb['length'];_0x2775ad++)_0x38dceb[_0x2775ad]['status']===0x3||(_0x38dceb[_0x2775ad]['status']===0x1?(f(_0x32fd48===_0x2775ad-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x32fd48=_0x2775ad,_0x38dceb[_0x2775ad]['status']=0x3,_0x38dceb[_0x2775ad]['abortReason']='set'):(f(_0x38dceb[_0x2775ad]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x38dceb[_0x2775ad]['unwatcher'](),_0x386881=_0x386881['concat'](pe(_0x4221cb['serverSyncTree_'],_0x38dceb[_0x2775ad]['currentWriteId'],!0x0)),_0x38dceb[_0x2775ad]['onComplete']&&_0xa19909['push'](_0x38dceb[_0x2775ad]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x32fd48===-0x1?_s(_0x513966,void 0x0):_0x38dceb['length']=_0x32fd48+0x1,H(_0x4221cb['eventQueue_'],qt(_0x513966),_0x386881);for(let _0x56bfed=0x0;_0x56bfed<_0xa19909['length'];_0x56bfed++)ht(_0xa19909[_0x56bfed]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x2661fa){let _0x5265f5='';const _0x5696d6=_0x2661fa['split']('/');for(let _0x9cdd7b=0x0;_0x9cdd7b<_0x5696d6['length'];_0x9cdd7b++)if(_0x5696d6[_0x9cdd7b]['length']>0x0){let _0x4bda4d=_0x5696d6[_0x9cdd7b];try{_0x4bda4d=decodeURIComponent(_0x4bda4d['replace'](/\+/g,'\x20'));}catch{}_0x5265f5+='/'+_0x4bda4d;}return _0x5265f5;}function Dd(_0x4426f9){const _0xb1ed7e={};_0x4426f9['charAt'](0x0)==='?'&&(_0x4426f9=_0x4426f9['substring'](0x1));for(const _0x1c8e15 of _0x4426f9['split']('&')){if(_0x1c8e15['length']===0x0)continue;const _0x178c18=_0x1c8e15['split']('=');_0x178c18['length']===0x2?_0xb1ed7e[decodeURIComponent(_0x178c18[0x0])]=decodeURIComponent(_0x178c18[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x1c8e15+'\x27\x20in\x20query\x20\x27'+_0x4426f9+'\x27');}return _0xb1ed7e;}const vr=function(_0x8e48a0,_0x4a99d4){const _0x2df892=Md(_0x8e48a0),_0x7c6d65=_0x2df892['namespace'];_0x2df892['domain']==='firebase.com'&&ae(_0x2df892['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x7c6d65||_0x7c6d65==='undefined')&&_0x2df892['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x2df892['secure']||$l();const _0x3cb3ba=_0x2df892['scheme']==='ws'||_0x2df892['scheme']==='wss';return{'repoInfo':new yo(_0x2df892['host'],_0x2df892['secure'],_0x7c6d65,_0x3cb3ba,_0x4a99d4,'',_0x7c6d65!==_0x2df892['subdomain']),'path':new C(_0x2df892['pathString'])};},Md=function(_0x154099){let _0x5b3e40='',_0x3b71ce='',_0x3e3243='',_0x32511d='',_0x291a3f='',_0x4f32c7=!0x0,_0x387888='https',_0x5f0d31=0x1bb;if(typeof _0x154099=='string'){let _0x34eb81=_0x154099['indexOf']('//');_0x34eb81>=0x0&&(_0x387888=_0x154099['substring'](0x0,_0x34eb81-0x1),_0x154099=_0x154099['substring'](_0x34eb81+0x2));let _0xa38f2c=_0x154099['indexOf']('/');_0xa38f2c===-0x1&&(_0xa38f2c=_0x154099['length']);let _0xe3bb73=_0x154099['indexOf']('?');_0xe3bb73===-0x1&&(_0xe3bb73=_0x154099['length']),_0x5b3e40=_0x154099['substring'](0x0,Math['min'](_0xa38f2c,_0xe3bb73)),_0xa38f2c<_0xe3bb73&&(_0x32511d=Od(_0x154099['substring'](_0xa38f2c,_0xe3bb73)));const _0x2fd9c4=Dd(_0x154099['substring'](Math['min'](_0x154099['length'],_0xe3bb73)));_0x34eb81=_0x5b3e40['indexOf'](':'),_0x34eb81>=0x0?(_0x4f32c7=_0x387888==='https'||_0x387888==='wss',_0x5f0d31=parseInt(_0x5b3e40['substring'](_0x34eb81+0x1),0xa)):_0x34eb81=_0x5b3e40['length'];const _0x36f754=_0x5b3e40['slice'](0x0,_0x34eb81);if(_0x36f754['toLowerCase']()==='localhost')_0x3b71ce='localhost';else{if(_0x36f754['split']('.')['length']<=0x2)_0x3b71ce=_0x36f754;else{const _0x2550c1=_0x5b3e40['indexOf']('.');_0x3e3243=_0x5b3e40['substring'](0x0,_0x2550c1)['toLowerCase'](),_0x3b71ce=_0x5b3e40['substring'](_0x2550c1+0x1),_0x291a3f=_0x3e3243;}}'ns'in _0x2fd9c4&&(_0x291a3f=_0x2fd9c4['ns']);}return{'host':_0x5b3e40,'port':_0x5f0d31,'domain':_0x3b71ce,'subdomain':_0x3e3243,'secure':_0x4f32c7,'scheme':_0x387888,'pathString':_0x32511d,'namespace':_0x291a3f};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x34785a=0x0;const _0x500e22=[];return function(_0x3529cb){const _0xe6c28b=_0x3529cb===_0x34785a;_0x34785a=_0x3529cb;let _0x5a6658;const _0x3edbd6=new Array(0x8);for(_0x5a6658=0x7;_0x5a6658>=0x0;_0x5a6658--)_0x3edbd6[_0x5a6658]=Er['charAt'](_0x3529cb%0x40),_0x3529cb=Math['floor'](_0x3529cb/0x40);f(_0x3529cb===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x312556=_0x3edbd6['join']('');if(_0xe6c28b){for(_0x5a6658=0xb;_0x5a6658>=0x0&&_0x500e22[_0x5a6658]===0x3f;_0x5a6658--)_0x500e22[_0x5a6658]=0x0;_0x500e22[_0x5a6658]++;}else{for(_0x5a6658=0x0;_0x5a6658<0xc;_0x5a6658++)_0x500e22[_0x5a6658]=Math['floor'](Math['random']()*0x40);}for(_0x5a6658=0x0;_0x5a6658<0xc;_0x5a6658++)_0x312556+=Er['charAt'](_0x500e22[_0x5a6658]);return f(_0x312556['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x312556;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x5116d4,_0x1046d4,_0x145563,_0xaf8768){this['eventType']=_0x5116d4,this['eventRegistration']=_0x1046d4,this['snapshot']=_0x145563,this['prevName']=_0xaf8768;}['getPath'](){const _0x584606=this['snapshot']['ref'];return this['eventType']==='value'?_0x584606['_path']:_0x584606['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x47827f,_0x315783,_0xb19e7d){this['eventRegistration']=_0x47827f,this['error']=_0x315783,this['path']=_0xb19e7d;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x954b91,_0x5af369){this['snapshotCallback']=_0x954b91,this['cancelCallback']=_0x5af369;}['onValue'](_0x3e71c9,_0x441ef3){this['snapshotCallback']['call'](null,_0x3e71c9,_0x441ef3);}['onCancel'](_0x60cae){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x60cae);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x272538){return this['snapshotCallback']===_0x272538['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x272538['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x272538['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x4601ec,_0x247c4a,_0x15463a,_0x41ca84){this['_repo']=_0x4601ec,this['_path']=_0x247c4a,this['_queryParams']=_0x15463a,this['_orderByCalled']=_0x41ca84;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x44847d=rr(this['_queryParams']),_0x18fac2=Hi(_0x44847d);return _0x18fac2==='{}'?'default':_0x18fac2;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x25e64a){if(_0x25e64a=N(_0x25e64a),!(_0x25e64a instanceof be))return!0x1;const _0x4d8539=this['_repo']===_0x25e64a['_repo'],_0x2dc94d=ji(this['_path'],_0x25e64a['_path']),_0x28840e=this['_queryIdentifier']===_0x25e64a['_queryIdentifier'];return _0x4d8539&&_0x2dc94d&&_0x28840e;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0xaaca20,_0x404b73){if(_0xaaca20['_orderByCalled']===!0x0)throw new Error(_0x404b73+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x59fbc1){let _0x16294b=null,_0x56b9a9=null;if(_0x59fbc1['hasStart']()&&(_0x16294b=_0x59fbc1['getIndexStartValue']()),_0x59fbc1['hasEnd']()&&(_0x56b9a9=_0x59fbc1['getIndexEndValue']()),_0x59fbc1['getIndex']()===ye){const _0x47f4f1='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x5027f1='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x59fbc1['hasStart']()){if(_0x59fbc1['getIndexStartName']()!==Fe)throw new Error(_0x47f4f1);if(typeof _0x16294b!='string')throw new Error(_0x5027f1);}if(_0x59fbc1['hasEnd']()){if(_0x59fbc1['getIndexEndName']()!==Ie)throw new Error(_0x47f4f1);if(typeof _0x56b9a9!='string')throw new Error(_0x5027f1);}}else{if(_0x59fbc1['getIndex']()===R){if(_0x16294b!=null&&!Tn(_0x16294b)||_0x56b9a9!=null&&!Tn(_0x56b9a9))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x59fbc1['getIndex']()instanceof Qi||_0x59fbc1['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x16294b!=null&&typeof _0x16294b=='object'||_0x56b9a9!=null&&typeof _0x56b9a9=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x37a2af){if(_0x37a2af['hasStart']()&&_0x37a2af['hasEnd']()&&_0x37a2af['hasLimit']()&&!_0x37a2af['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0xfd8b18,_0x2eab9d){super(_0xfd8b18,_0x2eab9d,new Xi(),!0x1);}get['parent'](){const _0x4624f2=Ro(this['_path']);return _0x4624f2===null?null:new ee(this['_repo'],_0x4624f2);}get['root'](){let _0x1bbe71=this;for(;_0x1bbe71['parent']!==null;)_0x1bbe71=_0x1bbe71['parent'];return _0x1bbe71;}}class st{constructor(_0x1bebb3,_0x2c5eb8,_0x47a07a){this['_node']=_0x1bebb3,this['ref']=_0x2c5eb8,this['_index']=_0x47a07a;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x4f58b5){const _0x46c3bc=new C(_0x4f58b5),_0x2f9b34=Ft(this['ref'],_0x4f58b5);return new st(this['_node']['getChild'](_0x46c3bc),_0x2f9b34,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x57f100){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x72eeda,_0x29a633)=>_0x57f100(new st(_0x29a633,Ft(this['ref'],_0x72eeda),R)));}['hasChild'](_0x4d8248){const _0x2c5e7a=new C(_0x4d8248);return!this['_node']['getChild'](_0x2c5e7a)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x4ca0c6,_0x454b39){return _0x4ca0c6=N(_0x4ca0c6),_0x4ca0c6['_checkNotDeleted']('ref'),_0x454b39!==void 0x0?Ft(_0x4ca0c6['_root'],_0x454b39):_0x4ca0c6['_root'];}function Ft(_0x51114c,_0x10aba3){return _0x51114c=N(_0x51114c),y(_0x51114c['_path'])===null?pd('child','path',_0x10aba3):ms('child','path',_0x10aba3),new ee(_0x51114c['_repo'],k(_0x51114c['_path'],_0x10aba3));}function g_(_0x5d4a45,_0x13c7fc){_0x5d4a45=N(_0x5d4a45),ys('push',_0x5d4a45['_path']),zt('push',_0x13c7fc,_0x5d4a45['_path'],!0x0);const _0x3d55d4=la(_0x5d4a45['_repo']),_0x1392aa=Ld(_0x3d55d4),_0x1c8e86=Ft(_0x5d4a45,_0x1392aa),_0x3864d6=Ft(_0x5d4a45,_0x1392aa);let _0x6ff033;return _0x13c7fc!=null?_0x6ff033=Ud(_0x3864d6,_0x13c7fc)['then'](()=>_0x3864d6):_0x6ff033=Promise['resolve'](_0x3864d6),_0x1c8e86['then']=_0x6ff033['then']['bind'](_0x6ff033),_0x1c8e86['catch']=_0x6ff033['then']['bind'](_0x6ff033,void 0x0),_0x1c8e86;}function Ud(_0x15a03c,_0x44cf3b){_0x15a03c=N(_0x15a03c),ys('set',_0x15a03c['_path']),zt('set',_0x44cf3b,_0x15a03c['_path'],!0x1);const _0x3aff1e=new ot();return Cd(_0x15a03c['_repo'],_0x15a03c['_path'],_0x44cf3b,null,_0x3aff1e['wrapCallback'](()=>{})),_0x3aff1e['promise'];}function m_(_0xc2734c,_0x581893){fd('update',_0x581893,_0xc2734c['_path']);const _0x16eb5d=new ot();return Td(_0xc2734c['_repo'],_0xc2734c['_path'],_0x581893,_0x16eb5d['wrapCallback'](()=>{})),_0x16eb5d['promise'];}function y_(_0x9a22e4){_0x9a22e4=N(_0x9a22e4);const _0x20a7a9=new pa(()=>{}),_0x5ca753=new zn(_0x20a7a9);return wd(_0x9a22e4['_repo'],_0x9a22e4,_0x5ca753)['then'](_0x485858=>new st(_0x485858,new ee(_0x9a22e4['_repo'],_0x9a22e4['_path']),_0x9a22e4['_queryParams']['getIndex']()));}class zn{constructor(_0x4b0d36){this['callbackContext']=_0x4b0d36;}['respondsTo'](_0x30996d){return _0x30996d==='value';}['createEvent'](_0x493cbc,_0x4f36c6){const _0x41ae3a=_0x4f36c6['_queryParams']['getIndex']();return new xd('value',this,new st(_0x493cbc['snapshotNode'],new ee(_0x4f36c6['_repo'],_0x4f36c6['_path']),_0x41ae3a));}['getEventRunner'](_0x174666){return _0x174666['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x174666['error']):()=>this['callbackContext']['onValue'](_0x174666['snapshot'],null);}['createCancelEvent'](_0x5c2467,_0x5ccd13){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x5c2467,_0x5ccd13):null;}['matches'](_0x448935){return _0x448935 instanceof zn?!_0x448935['callbackContext']||!this['callbackContext']?!0x0:_0x448935['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x58fefd,_0x3dcbd6,_0x141b96,_0x4d0e9d,_0x9f4df7){const _0x5147f5=new pa(_0x141b96,void 0x0),_0x5208e1=new zn(_0x5147f5);return bd(_0x58fefd['_repo'],_0x58fefd,_0x5208e1),()=>Rd(_0x58fefd['_repo'],_0x58fefd,_0x5208e1);}function Bd(_0x1e39f2,_0x912292,_0x29aad8,_0x29ded8){return Wd(_0x1e39f2,'value',_0x912292);}class ft{}class ma extends ft{constructor(_0x1d5c3e,_0x5cb122){super(),this['_value']=_0x1d5c3e,this['_key']=_0x5cb122,this['type']='endAt';}['_apply'](_0x7ef6d5){zt('endAt',this['_value'],_0x7ef6d5['_path'],!0x0);const _0x3b7221=Jh(_0x7ef6d5['_queryParams'],this['_value'],this['_key']);if(ga(_0x3b7221),qn(_0x3b7221),_0x7ef6d5['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x7ef6d5['_repo'],_0x7ef6d5['_path'],_0x3b7221,_0x7ef6d5['_orderByCalled']);}}function v_(_0x3561e0,_0x347cbb){return new ma(_0x3561e0,_0x347cbb);}class ya extends ft{constructor(_0x3e8821,_0xb9d95){super(),this['_value']=_0x3e8821,this['_key']=_0xb9d95,this['type']='startAt';}['_apply'](_0x5d1cd1){zt('startAt',this['_value'],_0x5d1cd1['_path'],!0x0);const _0x3d492a=Qh(_0x5d1cd1['_queryParams'],this['_value'],this['_key']);if(ga(_0x3d492a),qn(_0x3d492a),_0x5d1cd1['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x5d1cd1['_repo'],_0x5d1cd1['_path'],_0x3d492a,_0x5d1cd1['_orderByCalled']);}}function E_(_0x1a31c7=null,_0x12ae98){return new ya(_0x1a31c7,_0x12ae98);}class Vd extends ft{constructor(_0x37d67b){super(),this['_limit']=_0x37d67b,this['type']='limitToFirst';}['_apply'](_0x3c4ec7){if(_0x3c4ec7['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x3c4ec7['_repo'],_0x3c4ec7['_path'],Yh(_0x3c4ec7['_queryParams'],this['_limit']),_0x3c4ec7['_orderByCalled']);}}function I_(_0x27e59e){if(Math['floor'](_0x27e59e)!==_0x27e59e||_0x27e59e<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x27e59e);}class Hd extends ft{constructor(_0x215512){super(),this['_path']=_0x215512,this['type']='orderByChild';}['_apply'](_0x4636ac){_a(_0x4636ac,'orderByChild');const _0x4dc8e2=new C(this['_path']);if(v(_0x4dc8e2))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x5ba4ff=new Qi(_0x4dc8e2),_0x44702f=xo(_0x4636ac['_queryParams'],_0x5ba4ff);return qn(_0x44702f),new be(_0x4636ac['_repo'],_0x4636ac['_path'],_0x44702f,!0x0);}}function w_(_0x2ce3f1){if(_0x2ce3f1==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x2ce3f1==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x2ce3f1==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x2ce3f1),new Hd(_0x2ce3f1);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x5573d5){_a(_0x5573d5,'orderByKey');const _0x4332f3=xo(_0x5573d5['_queryParams'],ye);return qn(_0x4332f3),new be(_0x5573d5['_repo'],_0x5573d5['_path'],_0x4332f3,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x4a62e2,_0x3a9d46){super(),this['_value']=_0x4a62e2,this['_key']=_0x3a9d46,this['type']='equalTo';}['_apply'](_0x1921eb){if(zt('equalTo',this['_value'],_0x1921eb['_path'],!0x1),_0x1921eb['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x1921eb['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x1921eb));}}function T_(_0x16c411,_0x2e5fd1){return new Gd(_0x16c411,_0x2e5fd1);}function S_(_0x1d289e,..._0x37e870){let _0x51fb43=N(_0x1d289e);for(const _0x4be31a of _0x37e870)_0x51fb43=_0x4be31a['_apply'](_0x51fb43);return _0x51fb43;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x5db72f,_0x4b7a2d,_0x44c49c,_0x29c2af){const _0x1565e5=_0x4b7a2d['lastIndexOf'](':'),_0x30d1ec=_0x4b7a2d['substring'](0x0,_0x1565e5),_0x5714fa=at(_0x30d1ec);_0x5db72f['repoInfo_']=new yo(_0x4b7a2d,_0x5714fa,_0x5db72f['repoInfo_']['namespace'],_0x5db72f['repoInfo_']['webSocketOnly'],_0x5db72f['repoInfo_']['nodeAdmin'],_0x5db72f['repoInfo_']['persistenceKey'],_0x5db72f['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x44c49c),_0x29c2af&&(_0x5db72f['authTokenProvider_']=_0x29c2af);}function Kd(_0x4a75d3,_0x3db20b,_0x1787ae,_0x23ce24,_0x11f7ad){let _0x12fce5=_0x23ce24||_0x4a75d3['options']['databaseURL'];_0x12fce5===void 0x0&&(_0x4a75d3['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x4a75d3['options']['projectId']),_0x12fce5=_0x4a75d3['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x288335=vr(_0x12fce5,_0x11f7ad),_0x560647=_0x288335['repoInfo'],_0x26e7e9;typeof process<'u'&&Vs&&(_0x26e7e9=Vs[qd]),_0x26e7e9?(_0x12fce5='http://'+_0x26e7e9+'?ns='+_0x560647['namespace'],_0x288335=vr(_0x12fce5,_0x11f7ad),_0x560647=_0x288335['repoInfo']):_0x288335['repoInfo']['secure'];const _0x5cfda6=new eh(_0x4a75d3['name'],_0x4a75d3['options'],_0x3db20b);_d('Invalid\x20Firebase\x20Database\x20URL',_0x288335),v(_0x288335['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x200f49=Qd(_0x560647,_0x4a75d3,_0x5cfda6,new Zl(_0x4a75d3,_0x1787ae));return new Jd(_0x200f49,_0x4a75d3);}function Yd(_0xac936c,_0x52e7e1){const _0x132267=Ni[_0x52e7e1];(!_0x132267||_0x132267[_0xac936c['key']]!==_0xac936c)&&ae('Database\x20'+_0x52e7e1+'('+_0xac936c['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0xac936c),delete _0x132267[_0xac936c['key']];}function Qd(_0x33e8a3,_0x542c1c,_0x3924d3,_0x29a21e){let _0x177908=Ni[_0x542c1c['name']];_0x177908||(_0x177908={},Ni[_0x542c1c['name']]=_0x177908);let _0x34ff93=_0x177908[_0x33e8a3['toURLString']()];return _0x34ff93&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x34ff93=new vd(_0x33e8a3,zd,_0x3924d3,_0x29a21e),_0x177908[_0x33e8a3['toURLString']()]=_0x34ff93,_0x34ff93;}class Jd{constructor(_0x14c6da,_0x28fdf0){this['_repoInternal']=_0x14c6da,this['app']=_0x28fdf0,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0xe379dd){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0xe379dd+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x55ed5b=Zr(),_0x3f9ea8){const _0x35de4=Bi(_0x55ed5b,'database')['getImmediate']({'identifier':_0x3f9ea8});if(!_0x35de4['_instanceStarted']){const _0x30b1cf=cc('database');_0x30b1cf&&Xd(_0x35de4,..._0x30b1cf);}return _0x35de4;}function Xd(_0xf1737b,_0x15cab8,_0x5b823a,_0x3b7435={}){_0xf1737b=N(_0xf1737b),_0xf1737b['_checkNotDeleted']('useEmulator');const _0x21ec37=_0x15cab8+':'+_0x5b823a,_0x254a55=_0xf1737b['_repoInternal'];if(_0xf1737b['_instanceStarted']){if(_0x21ec37===_0xf1737b['_repoInternal']['repoInfo_']['host']&&Me(_0x3b7435,_0x254a55['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x44385d;if(_0x254a55['repoInfo_']['nodeAdmin'])_0x3b7435['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x44385d=new nn(nn['OWNER']);else{if(_0x3b7435['mockUserToken']){const _0x595fef=typeof _0x3b7435['mockUserToken']=='string'?_0x3b7435['mockUserToken']:lc(_0x3b7435['mockUserToken'],_0xf1737b['app']['options']['projectId']);_0x44385d=new nn(_0x595fef);}}at(_0x15cab8)&&(jr(_0x15cab8),Kr('Database',!0x0)),jd(_0x254a55,_0x21ec37,_0x3b7435,_0x44385d);}function R_(_0x5ef7f3){_0x5ef7f3=N(_0x5ef7f3),_0x5ef7f3['_checkNotDeleted']('goOffline'),ha(_0x5ef7f3['_repo']);}function A_(_0x1798cc){_0x1798cc=N(_0x1798cc),_0x1798cc['_checkNotDeleted']('goOnline'),Ad(_0x1798cc['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x483ff1){Ul(lt),Ze(new Le('database',(_0x21a954,{instanceIdentifier:_0x171fae})=>{const _0x40e52d=_0x21a954['getProvider']('app')['getImmediate'](),_0x35c400=_0x21a954['getProvider']('auth-internal'),_0x1ebad5=_0x21a954['getProvider']('app-check-internal');return Kd(_0x40e52d,_0x35c400,_0x1ebad5,_0x171fae);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x483ff1),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x9ff7c0,_0xd53d32){this['committed']=_0x9ff7c0,this['snapshot']=_0xd53d32;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x3a1df4,_0x1f5159,_0x2f756b){if(_0x3a1df4=N(_0x3a1df4),ys('Reference.transaction',_0x3a1df4['_path']),_0x3a1df4['key']==='.length'||_0x3a1df4['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x3a1df4['key']+'\x20is\x20a\x20read-only\x20object.';const _0x1e3d85=!0x0,_0x410920=new ot(),_0x144bb2=(_0x1cafbe,_0x12eb4f,_0x39db51)=>{let _0x2ec5cd=null;_0x1cafbe?_0x410920['reject'](_0x1cafbe):(_0x2ec5cd=new st(_0x39db51,new ee(_0x3a1df4['_repo'],_0x3a1df4['_path']),R),_0x410920['resolve'](new tf(_0x12eb4f,_0x2ec5cd)));},_0x55457e=Bd(_0x3a1df4,()=>{});return kd(_0x3a1df4['_repo'],_0x3a1df4['_path'],_0x1f5159,_0x144bb2,_0x55457e,_0x1e3d85),_0x410920['promise'];}se['prototype']['simpleListen']=function(_0x1f8c00,_0x1642ee){this['sendRequest']('q',{'p':_0x1f8c00},_0x1642ee);},se['prototype']['echo']=function(_0x3ca161,_0x2484d8){this['sendRequest']('echo',{'d':_0x3ca161},_0x2484d8);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0xc162fd,..._0x472692){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0xc162fd,..._0x472692);}function sn(_0x2464cf,..._0x2cc3ca){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x2464cf,..._0x2cc3ca);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0xd114e1,..._0x66e7d3){throw ws(_0xd114e1,..._0x66e7d3);}function X(_0xf1c2ec,..._0x5a1c51){return ws(_0xf1c2ec,..._0x5a1c51);}function Ia(_0x450332,_0x2c8712,_0x3911ac){const _0xdce23f={...nf(),[_0x2c8712]:_0x3911ac};return new Bt('auth','Firebase',_0xdce23f)['create'](_0x2c8712,{'appName':_0x450332['name']});}function re(_0x23fd7e){return Ia(_0x23fd7e,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x2a20c3,..._0x5b3120){if(typeof _0x2a20c3!='string'){const _0x570488=_0x5b3120[0x0],_0x3c81fe=[..._0x5b3120['slice'](0x1)];return _0x3c81fe[0x0]&&(_0x3c81fe[0x0]['appName']=_0x2a20c3['name']),_0x2a20c3['_errorFactory']['create'](_0x570488,..._0x3c81fe);}return Ea['create'](_0x2a20c3,..._0x5b3120);}function m(_0x544666,_0x12f834,..._0x3506b8){if(!_0x544666)throw ws(_0x12f834,..._0x3506b8);}function ne(_0x2678c6){const _0x2bc3a1='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x2678c6;throw sn(_0x2bc3a1),new Error(_0x2bc3a1);}function ce(_0x529243,_0x374e49){_0x529243||ne(_0x374e49);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x8eb68e;return typeof self<'u'&&((_0x8eb68e=self['location'])==null?void 0x0:_0x8eb68e['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x1b5c90;return typeof self<'u'&&((_0x1b5c90=self['location'])==null?void 0x0:_0x1b5c90['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x28f6e3=navigator;return _0x28f6e3['languages']&&_0x28f6e3['languages'][0x0]||_0x28f6e3['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x4624aa,_0xc0d879){this['shortDelay']=_0x4624aa,this['longDelay']=_0xc0d879,ce(_0xc0d879>_0x4624aa,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x269339,_0x15d72c){ce(_0x269339['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x2763cd}=_0x269339['emulator'];return _0x15d72c?''+_0x2763cd+(_0x15d72c['startsWith']('/')?_0x15d72c['slice'](0x1):_0x15d72c):_0x2763cd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x378081,_0x315ac4,_0x2b7b8e){this['fetchImpl']=_0x378081,_0x315ac4&&(this['headersImpl']=_0x315ac4),_0x2b7b8e&&(this['responseImpl']=_0x2b7b8e);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x50cc08,_0x437ef5){return _0x50cc08['tenantId']&&!_0x437ef5['tenantId']?{..._0x437ef5,'tenantId':_0x50cc08['tenantId']}:_0x437ef5;}async function Ae(_0x1ec851,_0x4fad29,_0x56d965,_0x4a3e24,_0x299a29={}){return Ca(_0x1ec851,_0x299a29,async()=>{let _0x15599e={},_0x10094d={};_0x4a3e24&&(_0x4fad29==='GET'?_0x10094d=_0x4a3e24:_0x15599e={'body':JSON['stringify'](_0x4a3e24)});const _0x55c6bb=ct({'key':_0x1ec851['config']['apiKey'],..._0x10094d})['slice'](0x1),_0x5b5889=await _0x1ec851['_getAdditionalHeaders']();_0x5b5889['Content-Type']='application/json',_0x1ec851['languageCode']&&(_0x5b5889['X-Firebase-Locale']=_0x1ec851['languageCode']);const _0x21ef7b={'method':_0x4fad29,'headers':_0x5b5889,..._0x15599e};return dc()||(_0x21ef7b['referrerPolicy']='no-referrer'),_0x1ec851['emulatorConfig']&&at(_0x1ec851['emulatorConfig']['host'])&&(_0x21ef7b['credentials']='include'),wa['fetch']()(await Ta(_0x1ec851,_0x1ec851['config']['apiHost'],_0x56d965,_0x55c6bb),_0x21ef7b);});}async function Ca(_0x41a30d,_0x21b8fe,_0x5340d6){_0x41a30d['_canInitEmulator']=!0x1;const _0x354974={...cf,..._0x21b8fe};try{const _0x195c70=new df(_0x41a30d),_0xb1146e=await Promise['race']([_0x5340d6(),_0x195c70['promise']]);_0x195c70['clearNetworkTimeout']();const _0x3774db=await _0xb1146e['json']();if('needConfirmation'in _0x3774db)throw tn(_0x41a30d,'account-exists-with-different-credential',_0x3774db);if(_0xb1146e['ok']&&!('errorMessage'in _0x3774db))return _0x3774db;{const _0x40a3f6=_0xb1146e['ok']?_0x3774db['errorMessage']:_0x3774db['error']['message'],[_0x20dda7,_0x11320c]=_0x40a3f6['split']('\x20:\x20');if(_0x20dda7==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x41a30d,'credential-already-in-use',_0x3774db);if(_0x20dda7==='EMAIL_EXISTS')throw tn(_0x41a30d,'email-already-in-use',_0x3774db);if(_0x20dda7==='USER_DISABLED')throw tn(_0x41a30d,'user-disabled',_0x3774db);const _0x48f5fe=_0x354974[_0x20dda7]||_0x20dda7['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x11320c)throw Ia(_0x41a30d,_0x48f5fe,_0x11320c);Q(_0x41a30d,_0x48f5fe);}}catch(_0x1a989a){if(_0x1a989a instanceof Se)throw _0x1a989a;Q(_0x41a30d,'network-request-failed',{'message':String(_0x1a989a)});}}async function Qt(_0x2dd066,_0x4e84cb,_0x531a5c,_0x15f889,_0x3a5d64={}){const _0x303a7c=await Ae(_0x2dd066,_0x4e84cb,_0x531a5c,_0x15f889,_0x3a5d64);return'mfaPendingCredential'in _0x303a7c&&Q(_0x2dd066,'multi-factor-auth-required',{'_serverResponse':_0x303a7c}),_0x303a7c;}async function Ta(_0x704b02,_0x4ff209,_0x590b8c,_0x3639e1){const _0x202553=''+_0x4ff209+_0x590b8c+'?'+_0x3639e1,_0x508ff0=_0x704b02,_0x3c0352=_0x508ff0['config']['emulator']?Cs(_0x704b02['config'],_0x202553):_0x704b02['config']['apiScheme']+'://'+_0x202553;return lf['includes'](_0x590b8c)&&(await _0x508ff0['_persistenceManagerAvailable'],_0x508ff0['_getPersistenceType']()==='COOKIE')?_0x508ff0['_getPersistence']()['_getFinalTarget'](_0x3c0352)['toString']():_0x3c0352;}function uf(_0x39c3e5){switch(_0x39c3e5){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x298bda){this['auth']=_0x298bda,this['timer']=null,this['promise']=new Promise((_0x21e1b4,_0x1c25af)=>{this['timer']=setTimeout(()=>_0x1c25af(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x5cd240,_0x352f64,_0x304d3a){const _0x4a409f={'appName':_0x5cd240['name']};_0x304d3a['email']&&(_0x4a409f['email']=_0x304d3a['email']),_0x304d3a['phoneNumber']&&(_0x4a409f['phoneNumber']=_0x304d3a['phoneNumber']);const _0x3cdad3=X(_0x5cd240,_0x352f64,_0x4a409f);return _0x3cdad3['customData']['_tokenResponse']=_0x304d3a,_0x3cdad3;}function wr(_0x340248){return _0x340248!==void 0x0&&_0x340248['enterprise']!==void 0x0;}class ff{constructor(_0x40ca51){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x40ca51['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x40ca51['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x40ca51['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x2904ba){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x1c230a of this['recaptchaEnforcementState'])if(_0x1c230a['provider']&&_0x1c230a['provider']===_0x2904ba)return uf(_0x1c230a['enforcementState']);return null;}['isProviderEnabled'](_0x5a7cb1){return this['getProviderEnforcementState'](_0x5a7cb1)==='ENFORCE'||this['getProviderEnforcementState'](_0x5a7cb1)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x497727,_0x4d92ed){return Ae(_0x497727,'GET','/v2/recaptchaConfig',Re(_0x497727,_0x4d92ed));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x11ed90,_0x208935){return Ae(_0x11ed90,'POST','/v1/accounts:delete',_0x208935);}async function bn(_0xe3de68,_0x4f5ddf){return Ae(_0xe3de68,'POST','/v1/accounts:lookup',_0x4f5ddf);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0xadb468){if(_0xadb468)try{const _0x43bd52=new Date(Number(_0xadb468));if(!isNaN(_0x43bd52['getTime']()))return _0x43bd52['toUTCString']();}catch{}}async function gf(_0x59c03e,_0x81013b=!0x1){const _0x242841=N(_0x59c03e),_0x5baca0=await _0x242841['getIdToken'](_0x81013b),_0xc70df1=Ts(_0x5baca0);m(_0xc70df1&&_0xc70df1['exp']&&_0xc70df1['auth_time']&&_0xc70df1['iat'],_0x242841['auth'],'internal-error');const _0x52b6e9=typeof _0xc70df1['firebase']=='object'?_0xc70df1['firebase']:void 0x0,_0x387018=_0x52b6e9==null?void 0x0:_0x52b6e9['sign_in_provider'];return{'claims':_0xc70df1,'token':_0x5baca0,'authTime':Rt(li(_0xc70df1['auth_time'])),'issuedAtTime':Rt(li(_0xc70df1['iat'])),'expirationTime':Rt(li(_0xc70df1['exp'])),'signInProvider':_0x387018||null,'signInSecondFactor':(_0x52b6e9==null?void 0x0:_0x52b6e9['sign_in_second_factor'])||null};}function li(_0x11e756){return Number(_0x11e756)*0x3e8;}function Ts(_0x3cd2d4){const [_0x2ef817,_0x381734,_0x29848f]=_0x3cd2d4['split']('.');if(_0x2ef817===void 0x0||_0x381734===void 0x0||_0x29848f===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x5dc259=ln(_0x381734);return _0x5dc259?JSON['parse'](_0x5dc259):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x25121f){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x25121f==null?void 0x0:_0x25121f['toString']()),null;}}function Cr(_0x5e2474){const _0x1f2a2=Ts(_0x5e2474);return m(_0x1f2a2,'internal-error'),m(typeof _0x1f2a2['exp']<'u','internal-error'),m(typeof _0x1f2a2['iat']<'u','internal-error'),Number(_0x1f2a2['exp'])-Number(_0x1f2a2['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x7c949d,_0x3eddfd,_0x30123a=!0x1){if(_0x30123a)return _0x3eddfd;try{return await _0x3eddfd;}catch(_0x2be346){throw _0x2be346 instanceof Se&&mf(_0x2be346)&&_0x7c949d['auth']['currentUser']===_0x7c949d&&await _0x7c949d['auth']['signOut'](),_0x2be346;}}function mf({code:_0x448b2c}){return _0x448b2c==='auth/user-disabled'||_0x448b2c==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0xf8c96e){this['user']=_0xf8c96e,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x4aeed9){if(_0x4aeed9){const _0x305b38=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x305b38;}else{this['errorBackoff']=0x7530;const _0x5f513b=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x5f513b);}}['schedule'](_0x248bee=!0x1){if(!this['isRunning'])return;const _0x4ed578=this['getInterval'](_0x248bee);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x4ed578);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0xe59418){(_0xe59418==null?void 0x0:_0xe59418['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x241847,_0x512d3a){this['createdAt']=_0x241847,this['lastLoginAt']=_0x512d3a,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x4dd8b1){this['createdAt']=_0x4dd8b1['createdAt'],this['lastLoginAt']=_0x4dd8b1['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x165949){var _0x261bcf;const _0xb52aaa=_0x165949['auth'],_0x32f68b=await _0x165949['getIdToken'](),_0x4cf18e=await Ut(_0x165949,bn(_0xb52aaa,{'idToken':_0x32f68b}));m(_0x4cf18e==null?void 0x0:_0x4cf18e['users']['length'],_0xb52aaa,'internal-error');const _0x2c2113=_0x4cf18e['users'][0x0];_0x165949['_notifyReloadListener'](_0x2c2113);const _0x31103c=(_0x261bcf=_0x2c2113['providerUserInfo'])!=null&&_0x261bcf['length']?Sa(_0x2c2113['providerUserInfo']):[],_0x1fbc77=Ef(_0x165949['providerData'],_0x31103c),_0x40cc0e=_0x165949['isAnonymous'],_0x366523=!(_0x165949['email']&&_0x2c2113['passwordHash'])&&!(_0x1fbc77!=null&&_0x1fbc77['length']),_0x15b82c=_0x40cc0e?_0x366523:!0x1,_0x2ee36b={'uid':_0x2c2113['localId'],'displayName':_0x2c2113['displayName']||null,'photoURL':_0x2c2113['photoUrl']||null,'email':_0x2c2113['email']||null,'emailVerified':_0x2c2113['emailVerified']||!0x1,'phoneNumber':_0x2c2113['phoneNumber']||null,'tenantId':_0x2c2113['tenantId']||null,'providerData':_0x1fbc77,'metadata':new Oi(_0x2c2113['createdAt'],_0x2c2113['lastLoginAt']),'isAnonymous':_0x15b82c};Object['assign'](_0x165949,_0x2ee36b);}async function vf(_0x4601c2){const _0x564f78=N(_0x4601c2);await Rn(_0x564f78),await _0x564f78['auth']['_persistUserIfCurrent'](_0x564f78),_0x564f78['auth']['_notifyListenersIfCurrent'](_0x564f78);}function Ef(_0x3680c6,_0x427b55){return[..._0x3680c6['filter'](_0x14b91e=>!_0x427b55['some'](_0x295410=>_0x295410['providerId']===_0x14b91e['providerId'])),..._0x427b55];}function Sa(_0x51143e){return _0x51143e['map'](({providerId:_0x52ed7e,..._0x324925})=>({'providerId':_0x52ed7e,'uid':_0x324925['rawId']||'','displayName':_0x324925['displayName']||null,'email':_0x324925['email']||null,'phoneNumber':_0x324925['phoneNumber']||null,'photoURL':_0x324925['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x4dcc10,_0x300534){const _0x21e452=await Ca(_0x4dcc10,{},async()=>{const _0x176dc4=ct({'grant_type':'refresh_token','refresh_token':_0x300534})['slice'](0x1),{tokenApiHost:_0x456370,apiKey:_0x1015a3}=_0x4dcc10['config'],_0x4de551=await Ta(_0x4dcc10,_0x456370,'/v1/token','key='+_0x1015a3),_0x1f1ec8=await _0x4dcc10['_getAdditionalHeaders']();_0x1f1ec8['Content-Type']='application/x-www-form-urlencoded';const _0x1ba9c4={'method':'POST','headers':_0x1f1ec8,'body':_0x176dc4};return _0x4dcc10['emulatorConfig']&&at(_0x4dcc10['emulatorConfig']['host'])&&(_0x1ba9c4['credentials']='include'),wa['fetch']()(_0x4de551,_0x1ba9c4);});return{'accessToken':_0x21e452['access_token'],'expiresIn':_0x21e452['expires_in'],'refreshToken':_0x21e452['refresh_token']};}async function wf(_0x4093e8,_0x325e75){return Ae(_0x4093e8,'POST','/v2/accounts:revokeToken',Re(_0x4093e8,_0x325e75));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x3ba2a9){m(_0x3ba2a9['idToken'],'internal-error'),m(typeof _0x3ba2a9['idToken']<'u','internal-error'),m(typeof _0x3ba2a9['refreshToken']<'u','internal-error');const _0x3ec461='expiresIn'in _0x3ba2a9&&typeof _0x3ba2a9['expiresIn']<'u'?Number(_0x3ba2a9['expiresIn']):Cr(_0x3ba2a9['idToken']);this['updateTokensAndExpiration'](_0x3ba2a9['idToken'],_0x3ba2a9['refreshToken'],_0x3ec461);}['updateFromIdToken'](_0x5358d0){m(_0x5358d0['length']!==0x0,'internal-error');const _0xcbc854=Cr(_0x5358d0);this['updateTokensAndExpiration'](_0x5358d0,null,_0xcbc854);}async['getToken'](_0x18f2ee,_0xd636d2=!0x1){return!_0xd636d2&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x18f2ee,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x18f2ee,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x820f25,_0xb1bd1d){const {accessToken:_0x51050e,refreshToken:_0x40ceae,expiresIn:_0xf1f8fb}=await If(_0x820f25,_0xb1bd1d);this['updateTokensAndExpiration'](_0x51050e,_0x40ceae,Number(_0xf1f8fb));}['updateTokensAndExpiration'](_0x33dd6d,_0x5a798e,_0x986438){this['refreshToken']=_0x5a798e||null,this['accessToken']=_0x33dd6d||null,this['expirationTime']=Date['now']()+_0x986438*0x3e8;}static['fromJSON'](_0x96bb07,_0x367ed1){const {refreshToken:_0x193559,accessToken:_0x49fb24,expirationTime:_0x5f3676}=_0x367ed1,_0x30b013=new Qe();return _0x193559&&(m(typeof _0x193559=='string','internal-error',{'appName':_0x96bb07}),_0x30b013['refreshToken']=_0x193559),_0x49fb24&&(m(typeof _0x49fb24=='string','internal-error',{'appName':_0x96bb07}),_0x30b013['accessToken']=_0x49fb24),_0x5f3676&&(m(typeof _0x5f3676=='number','internal-error',{'appName':_0x96bb07}),_0x30b013['expirationTime']=_0x5f3676),_0x30b013;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x15ef17){this['accessToken']=_0x15ef17['accessToken'],this['refreshToken']=_0x15ef17['refreshToken'],this['expirationTime']=_0x15ef17['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x4fb52c,_0x3771fe){m(typeof _0x4fb52c=='string'||typeof _0x4fb52c>'u','internal-error',{'appName':_0x3771fe});}class K{constructor({uid:_0x4fb48e,auth:_0x3b924d,stsTokenManager:_0x22fa18,..._0x475bda}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x4fb48e,this['auth']=_0x3b924d,this['stsTokenManager']=_0x22fa18,this['accessToken']=_0x22fa18['accessToken'],this['displayName']=_0x475bda['displayName']||null,this['email']=_0x475bda['email']||null,this['emailVerified']=_0x475bda['emailVerified']||!0x1,this['phoneNumber']=_0x475bda['phoneNumber']||null,this['photoURL']=_0x475bda['photoURL']||null,this['isAnonymous']=_0x475bda['isAnonymous']||!0x1,this['tenantId']=_0x475bda['tenantId']||null,this['providerData']=_0x475bda['providerData']?[..._0x475bda['providerData']]:[],this['metadata']=new Oi(_0x475bda['createdAt']||void 0x0,_0x475bda['lastLoginAt']||void 0x0);}async['getIdToken'](_0x4983ba){const _0x3149f6=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x4983ba));return m(_0x3149f6,this['auth'],'internal-error'),this['accessToken']!==_0x3149f6&&(this['accessToken']=_0x3149f6,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x3149f6;}['getIdTokenResult'](_0x11b1e4){return gf(this,_0x11b1e4);}['reload'](){return vf(this);}['_assign'](_0x4e54d5){this!==_0x4e54d5&&(m(this['uid']===_0x4e54d5['uid'],this['auth'],'internal-error'),this['displayName']=_0x4e54d5['displayName'],this['photoURL']=_0x4e54d5['photoURL'],this['email']=_0x4e54d5['email'],this['emailVerified']=_0x4e54d5['emailVerified'],this['phoneNumber']=_0x4e54d5['phoneNumber'],this['isAnonymous']=_0x4e54d5['isAnonymous'],this['tenantId']=_0x4e54d5['tenantId'],this['providerData']=_0x4e54d5['providerData']['map'](_0x37aa12=>({..._0x37aa12})),this['metadata']['_copy'](_0x4e54d5['metadata']),this['stsTokenManager']['_assign'](_0x4e54d5['stsTokenManager']));}['_clone'](_0x981ce5){const _0x34b6c2=new K({...this,'auth':_0x981ce5,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x34b6c2['metadata']['_copy'](this['metadata']),_0x34b6c2;}['_onReload'](_0x173ac6){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x173ac6,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x1e3719){this['reloadListener']?this['reloadListener'](_0x1e3719):this['reloadUserInfo']=_0x1e3719;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x36a2e6,_0x489e5f=!0x1){let _0x1c27ae=!0x1;_0x36a2e6['idToken']&&_0x36a2e6['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x36a2e6),_0x1c27ae=!0x0),_0x489e5f&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x1c27ae&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x1b4678=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x1b4678})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x1755e5=>({..._0x1755e5})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x298120,_0x24bd6e){const _0x46bb87=_0x24bd6e['displayName']??void 0x0,_0x5cc00d=_0x24bd6e['email']??void 0x0,_0x1c120e=_0x24bd6e['phoneNumber']??void 0x0,_0x37479a=_0x24bd6e['photoURL']??void 0x0,_0x2300aa=_0x24bd6e['tenantId']??void 0x0,_0x54b3e4=_0x24bd6e['_redirectEventId']??void 0x0,_0x40c2ae=_0x24bd6e['createdAt']??void 0x0,_0x2889a2=_0x24bd6e['lastLoginAt']??void 0x0,{uid:_0x4865cb,emailVerified:_0x5538b0,isAnonymous:_0x462b73,providerData:_0x17675c,stsTokenManager:_0x5c0b3c}=_0x24bd6e;m(_0x4865cb&&_0x5c0b3c,_0x298120,'internal-error');const _0x24aeec=Qe['fromJSON'](this['name'],_0x5c0b3c);m(typeof _0x4865cb=='string',_0x298120,'internal-error'),le(_0x46bb87,_0x298120['name']),le(_0x5cc00d,_0x298120['name']),m(typeof _0x5538b0=='boolean',_0x298120,'internal-error'),m(typeof _0x462b73=='boolean',_0x298120,'internal-error'),le(_0x1c120e,_0x298120['name']),le(_0x37479a,_0x298120['name']),le(_0x2300aa,_0x298120['name']),le(_0x54b3e4,_0x298120['name']),le(_0x40c2ae,_0x298120['name']),le(_0x2889a2,_0x298120['name']);const _0x3c8960=new K({'uid':_0x4865cb,'auth':_0x298120,'email':_0x5cc00d,'emailVerified':_0x5538b0,'displayName':_0x46bb87,'isAnonymous':_0x462b73,'photoURL':_0x37479a,'phoneNumber':_0x1c120e,'tenantId':_0x2300aa,'stsTokenManager':_0x24aeec,'createdAt':_0x40c2ae,'lastLoginAt':_0x2889a2});return _0x17675c&&Array['isArray'](_0x17675c)&&(_0x3c8960['providerData']=_0x17675c['map'](_0x229e97=>({..._0x229e97}))),_0x54b3e4&&(_0x3c8960['_redirectEventId']=_0x54b3e4),_0x3c8960;}static async['_fromIdTokenResponse'](_0x2e0681,_0x271f85,_0x3468bf=!0x1){const _0x1fb2b1=new Qe();_0x1fb2b1['updateFromServerResponse'](_0x271f85);const _0x43c613=new K({'uid':_0x271f85['localId'],'auth':_0x2e0681,'stsTokenManager':_0x1fb2b1,'isAnonymous':_0x3468bf});return await Rn(_0x43c613),_0x43c613;}static async['_fromGetAccountInfoResponse'](_0x5db796,_0x52032d,_0x3dc980){const _0x1853c4=_0x52032d['users'][0x0];m(_0x1853c4['localId']!==void 0x0,'internal-error');const _0x20d7ec=_0x1853c4['providerUserInfo']!==void 0x0?Sa(_0x1853c4['providerUserInfo']):[],_0x51f411=!(_0x1853c4['email']&&_0x1853c4['passwordHash'])&&!(_0x20d7ec!=null&&_0x20d7ec['length']),_0x1d9d6a=new Qe();_0x1d9d6a['updateFromIdToken'](_0x3dc980);const _0x4c3c95=new K({'uid':_0x1853c4['localId'],'auth':_0x5db796,'stsTokenManager':_0x1d9d6a,'isAnonymous':_0x51f411}),_0x1b5276={'uid':_0x1853c4['localId'],'displayName':_0x1853c4['displayName']||null,'photoURL':_0x1853c4['photoUrl']||null,'email':_0x1853c4['email']||null,'emailVerified':_0x1853c4['emailVerified']||!0x1,'phoneNumber':_0x1853c4['phoneNumber']||null,'tenantId':_0x1853c4['tenantId']||null,'providerData':_0x20d7ec,'metadata':new Oi(_0x1853c4['createdAt'],_0x1853c4['lastLoginAt']),'isAnonymous':!(_0x1853c4['email']&&_0x1853c4['passwordHash'])&&!(_0x20d7ec!=null&&_0x20d7ec['length'])};return Object['assign'](_0x4c3c95,_0x1b5276),_0x4c3c95;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x201f7f){ce(_0x201f7f instanceof Function,'Expected\x20a\x20class\x20definition');let _0x3ab680=Tr['get'](_0x201f7f);return _0x3ab680?(ce(_0x3ab680 instanceof _0x201f7f,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x3ab680):(_0x3ab680=new _0x201f7f(),Tr['set'](_0x201f7f,_0x3ab680),_0x3ab680);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x3a321f,_0x4453de){this['storage'][_0x3a321f]=_0x4453de;}async['_get'](_0x1413f8){const _0x49878b=this['storage'][_0x1413f8];return _0x49878b===void 0x0?null:_0x49878b;}async['_remove'](_0x1278d0){delete this['storage'][_0x1278d0];}['_addListener'](_0x2e5ae2,_0x344ac8){}['_removeListener'](_0x9a9c95,_0x100929){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x3d4753,_0x5b293a,_0x546aab){return'firebase:'+_0x3d4753+':'+_0x5b293a+':'+_0x546aab;}class Je{constructor(_0x4fb23e,_0x584189,_0x13e4c3){this['persistence']=_0x4fb23e,this['auth']=_0x584189,this['userKey']=_0x13e4c3;const {config:_0x4e9d21,name:_0x2f184f}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x4e9d21['apiKey'],_0x2f184f),this['fullPersistenceKey']=rn('persistence',_0x4e9d21['apiKey'],_0x2f184f),this['boundEventHandler']=_0x584189['_onStorageEvent']['bind'](_0x584189),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x391b52){return this['persistence']['_set'](this['fullUserKey'],_0x391b52['toJSON']());}async['getCurrentUser'](){const _0x12aae7=await this['persistence']['_get'](this['fullUserKey']);if(!_0x12aae7)return null;if(typeof _0x12aae7=='string'){const _0x3f8435=await bn(this['auth'],{'idToken':_0x12aae7})['catch'](()=>{});return _0x3f8435?K['_fromGetAccountInfoResponse'](this['auth'],_0x3f8435,_0x12aae7):null;}return K['_fromJSON'](this['auth'],_0x12aae7);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x4fee6c){if(this['persistence']===_0x4fee6c)return;const _0x488938=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x4fee6c,_0x488938)return this['setCurrentUser'](_0x488938);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x1f12b9,_0x3cb41f,_0x327a22='authUser'){if(!_0x3cb41f['length'])return new Je(ie(Sr),_0x1f12b9,_0x327a22);const _0x5e26d7=(await Promise['all'](_0x3cb41f['map'](async _0x47ceb6=>{if(await _0x47ceb6['_isAvailable']())return _0x47ceb6;})))['filter'](_0x3f958d=>_0x3f958d);let _0x256e59=_0x5e26d7[0x0]||ie(Sr);const _0x24e953=rn(_0x327a22,_0x1f12b9['config']['apiKey'],_0x1f12b9['name']);let _0x1ab0ac=null;for(const _0x39da06 of _0x3cb41f)try{const _0x49492a=await _0x39da06['_get'](_0x24e953);if(_0x49492a){let _0x47039e;if(typeof _0x49492a=='string'){const _0xc4e362=await bn(_0x1f12b9,{'idToken':_0x49492a})['catch'](()=>{});if(!_0xc4e362)break;_0x47039e=await K['_fromGetAccountInfoResponse'](_0x1f12b9,_0xc4e362,_0x49492a);}else _0x47039e=K['_fromJSON'](_0x1f12b9,_0x49492a);_0x39da06!==_0x256e59&&(_0x1ab0ac=_0x47039e),_0x256e59=_0x39da06;break;}}catch{}const _0xde4ed5=_0x5e26d7['filter'](_0x126a13=>_0x126a13['_shouldAllowMigration']);return!_0x256e59['_shouldAllowMigration']||!_0xde4ed5['length']?new Je(_0x256e59,_0x1f12b9,_0x327a22):(_0x256e59=_0xde4ed5[0x0],_0x1ab0ac&&await _0x256e59['_set'](_0x24e953,_0x1ab0ac['toJSON']()),await Promise['all'](_0x3cb41f['map'](async _0x437bca=>{if(_0x437bca!==_0x256e59)try{await _0x437bca['_remove'](_0x24e953);}catch{}})),new Je(_0x256e59,_0x1f12b9,_0x327a22));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x5ce3f1){const _0x21453d=_0x5ce3f1['toLowerCase']();if(_0x21453d['includes']('opera/')||_0x21453d['includes']('opr/')||_0x21453d['includes']('opios/'))return'Opera';if(Na(_0x21453d))return'IEMobile';if(_0x21453d['includes']('msie')||_0x21453d['includes']('trident/'))return'IE';if(_0x21453d['includes']('edge/'))return'Edge';if(Ra(_0x21453d))return'Firefox';if(_0x21453d['includes']('silk/'))return'Silk';if(Oa(_0x21453d))return'Blackberry';if(Da(_0x21453d))return'Webos';if(Aa(_0x21453d))return'Safari';if((_0x21453d['includes']('chrome/')||ka(_0x21453d))&&!_0x21453d['includes']('edge/'))return'Chrome';if(Pa(_0x21453d))return'Android';{const _0xa75bc6=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x1f48fa=_0x5ce3f1['match'](_0xa75bc6);if((_0x1f48fa==null?void 0x0:_0x1f48fa['length'])===0x2)return _0x1f48fa[0x1];}return'Other';}function Ra(_0x5dbbff=W()){return/firefox\//i['test'](_0x5dbbff);}function Aa(_0x2cbbae=W()){const _0x40c895=_0x2cbbae['toLowerCase']();return _0x40c895['includes']('safari/')&&!_0x40c895['includes']('chrome/')&&!_0x40c895['includes']('crios/')&&!_0x40c895['includes']('android');}function ka(_0x28652b=W()){return/crios\//i['test'](_0x28652b);}function Na(_0x1db07f=W()){return/iemobile/i['test'](_0x1db07f);}function Pa(_0x8fa665=W()){return/android/i['test'](_0x8fa665);}function Oa(_0x164a40=W()){return/blackberry/i['test'](_0x164a40);}function Da(_0x127b41=W()){return/webos/i['test'](_0x127b41);}function Ss(_0x436574=W()){return/iphone|ipad|ipod/i['test'](_0x436574)||/macintosh/i['test'](_0x436574)&&/mobile/i['test'](_0x436574);}function Cf(_0x5de2d1=W()){var _0x5bbfbe;return Ss(_0x5de2d1)&&!!((_0x5bbfbe=window['navigator'])!=null&&_0x5bbfbe['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x1fb8ce=W()){return Ss(_0x1fb8ce)||Pa(_0x1fb8ce)||Da(_0x1fb8ce)||Oa(_0x1fb8ce)||/windows phone/i['test'](_0x1fb8ce)||Na(_0x1fb8ce);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x2a6251,_0x261683=[]){let _0x1103b6;switch(_0x2a6251){case'Browser':_0x1103b6=br(W());break;case'Worker':_0x1103b6=br(W())+'-'+_0x2a6251;break;default:_0x1103b6=_0x2a6251;}const _0x260b59=_0x261683['length']?_0x261683['join'](','):'FirebaseCore-web';return _0x1103b6+'/JsCore/'+lt+'/'+_0x260b59;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x50df41){this['auth']=_0x50df41,this['queue']=[];}['pushCallback'](_0x3e589d,_0x2c54f9){const _0x3f93fa=_0x35e5de=>new Promise((_0x5a768f,_0x5f49bd)=>{try{const _0x35a34f=_0x3e589d(_0x35e5de);_0x5a768f(_0x35a34f);}catch(_0x12dbfb){_0x5f49bd(_0x12dbfb);}});_0x3f93fa['onAbort']=_0x2c54f9,this['queue']['push'](_0x3f93fa);const _0x264ad8=this['queue']['length']-0x1;return()=>{this['queue'][_0x264ad8]=()=>Promise['resolve']();};}async['runMiddleware'](_0x444b73){if(this['auth']['currentUser']===_0x444b73)return;const _0x56d2ea=[];try{for(const _0x420e5f of this['queue'])await _0x420e5f(_0x444b73),_0x420e5f['onAbort']&&_0x56d2ea['push'](_0x420e5f['onAbort']);}catch(_0x2c4edd){_0x56d2ea['reverse']();for(const _0x392316 of _0x56d2ea)try{_0x392316();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x2c4edd==null?void 0x0:_0x2c4edd['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x4ac678,_0x3939c3={}){return Ae(_0x4ac678,'GET','/v2/passwordPolicy',Re(_0x4ac678,_0x3939c3));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x200fd4){var _0x35c6a3;const _0x2f1481=_0x200fd4['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x2f1481['minPasswordLength']??Rf,_0x2f1481['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x2f1481['maxPasswordLength']),_0x2f1481['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x2f1481['containsLowercaseCharacter']),_0x2f1481['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x2f1481['containsUppercaseCharacter']),_0x2f1481['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x2f1481['containsNumericCharacter']),_0x2f1481['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x2f1481['containsNonAlphanumericCharacter']),this['enforcementState']=_0x200fd4['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x35c6a3=_0x200fd4['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x35c6a3['join'](''))??'',this['forceUpgradeOnSignin']=_0x200fd4['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x200fd4['schemaVersion'];}['validatePassword'](_0x5e5fae){const _0x236757={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x5e5fae,_0x236757),this['validatePasswordCharacterOptions'](_0x5e5fae,_0x236757),_0x236757['isValid']&&(_0x236757['isValid']=_0x236757['meetsMinPasswordLength']??!0x0),_0x236757['isValid']&&(_0x236757['isValid']=_0x236757['meetsMaxPasswordLength']??!0x0),_0x236757['isValid']&&(_0x236757['isValid']=_0x236757['containsLowercaseLetter']??!0x0),_0x236757['isValid']&&(_0x236757['isValid']=_0x236757['containsUppercaseLetter']??!0x0),_0x236757['isValid']&&(_0x236757['isValid']=_0x236757['containsNumericCharacter']??!0x0),_0x236757['isValid']&&(_0x236757['isValid']=_0x236757['containsNonAlphanumericCharacter']??!0x0),_0x236757;}['validatePasswordLengthOptions'](_0x24569b,_0x39be8a){const _0x3b4479=this['customStrengthOptions']['minPasswordLength'],_0x5e0a5b=this['customStrengthOptions']['maxPasswordLength'];_0x3b4479&&(_0x39be8a['meetsMinPasswordLength']=_0x24569b['length']>=_0x3b4479),_0x5e0a5b&&(_0x39be8a['meetsMaxPasswordLength']=_0x24569b['length']<=_0x5e0a5b);}['validatePasswordCharacterOptions'](_0x3cc281,_0x437823){this['updatePasswordCharacterOptionsStatuses'](_0x437823,!0x1,!0x1,!0x1,!0x1);let _0x4330b8;for(let _0x3c556f=0x0;_0x3c556f<_0x3cc281['length'];_0x3c556f++)_0x4330b8=_0x3cc281['charAt'](_0x3c556f),this['updatePasswordCharacterOptionsStatuses'](_0x437823,_0x4330b8>='a'&&_0x4330b8<='z',_0x4330b8>='A'&&_0x4330b8<='Z',_0x4330b8>='0'&&_0x4330b8<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x4330b8));}['updatePasswordCharacterOptionsStatuses'](_0x3732f8,_0x5604eb,_0x36818f,_0x18d731,_0x484d1a){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x3732f8['containsLowercaseLetter']||(_0x3732f8['containsLowercaseLetter']=_0x5604eb)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x3732f8['containsUppercaseLetter']||(_0x3732f8['containsUppercaseLetter']=_0x36818f)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x3732f8['containsNumericCharacter']||(_0x3732f8['containsNumericCharacter']=_0x18d731)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x3732f8['containsNonAlphanumericCharacter']||(_0x3732f8['containsNonAlphanumericCharacter']=_0x484d1a));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x147302,_0x1288a2,_0x5f5a2d,_0x1f815f){this['app']=_0x147302,this['heartbeatServiceProvider']=_0x1288a2,this['appCheckServiceProvider']=_0x5f5a2d,this['config']=_0x1f815f,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x147302['name'],this['clientVersion']=_0x1f815f['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x50d904=>this['_resolvePersistenceManagerAvailable']=_0x50d904);}['_initializeWithPersistence'](_0x4c157b,_0x185d79){return _0x185d79&&(this['_popupRedirectResolver']=ie(_0x185d79)),this['_initializationPromise']=this['queue'](async()=>{var _0xc7584,_0x15cdb3,_0x52b4aa;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x4c157b),(_0xc7584=this['_resolvePersistenceManagerAvailable'])==null||_0xc7584['call'](this),!this['_deleted'])){if((_0x15cdb3=this['_popupRedirectResolver'])!=null&&_0x15cdb3['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x185d79),this['lastNotifiedUid']=((_0x52b4aa=this['currentUser'])==null?void 0x0:_0x52b4aa['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x57494e=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x57494e)){if(this['currentUser']&&_0x57494e&&this['currentUser']['uid']===_0x57494e['uid']){this['_currentUser']['_assign'](_0x57494e),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x57494e,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x5c1068){try{const _0x39ff51=await bn(this,{'idToken':_0x5c1068}),_0x13b367=await K['_fromGetAccountInfoResponse'](this,_0x39ff51,_0x5c1068);await this['directlySetCurrentUser'](_0x13b367);}catch(_0xb68d01){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0xb68d01),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x4d96ab){var _0x5327f3;if($(this['app'])){const _0x2ad36b=this['app']['settings']['authIdToken'];return _0x2ad36b?new Promise(_0x5c2ac5=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2ad36b)['then'](_0x5c2ac5,_0x5c2ac5));}):this['directlySetCurrentUser'](null);}const _0x25f40d=await this['assertedPersistence']['getCurrentUser']();let _0x30cf21=_0x25f40d,_0x216aa3=!0x1;if(_0x4d96ab&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x740077=(_0x5327f3=this['redirectUser'])==null?void 0x0:_0x5327f3['_redirectEventId'],_0x314b00=_0x30cf21==null?void 0x0:_0x30cf21['_redirectEventId'],_0x300705=await this['tryRedirectSignIn'](_0x4d96ab);(!_0x740077||_0x740077===_0x314b00)&&(_0x300705!=null&&_0x300705['user'])&&(_0x30cf21=_0x300705['user'],_0x216aa3=!0x0);}if(!_0x30cf21)return this['directlySetCurrentUser'](null);if(!_0x30cf21['_redirectEventId']){if(_0x216aa3)try{await this['beforeStateQueue']['runMiddleware'](_0x30cf21);}catch(_0x1dd44e){_0x30cf21=_0x25f40d,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x1dd44e));}return _0x30cf21?this['reloadAndSetCurrentUserOrClear'](_0x30cf21):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x30cf21['_redirectEventId']?this['directlySetCurrentUser'](_0x30cf21):this['reloadAndSetCurrentUserOrClear'](_0x30cf21);}async['tryRedirectSignIn'](_0x5699bd){let _0x2b627b=null;try{_0x2b627b=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x5699bd,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x2b627b;}async['reloadAndSetCurrentUserOrClear'](_0x533109){try{await Rn(_0x533109);}catch(_0xae327){if((_0xae327==null?void 0x0:_0xae327['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x533109);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x29b863){if($(this['app']))return Promise['reject'](re(this));const _0x21c8fd=_0x29b863?N(_0x29b863):null;return _0x21c8fd&&m(_0x21c8fd['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x21c8fd&&_0x21c8fd['_clone'](this));}async['_updateCurrentUser'](_0x59fca7,_0x1f1c4a=!0x1){if(!this['_deleted'])return _0x59fca7&&m(this['tenantId']===_0x59fca7['tenantId'],this,'tenant-id-mismatch'),_0x1f1c4a||await this['beforeStateQueue']['runMiddleware'](_0x59fca7),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x59fca7),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x3a307c){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x3a307c));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x39c59d){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0xa9f088=this['_getPasswordPolicyInternal']();return _0xa9f088['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0xa9f088['validatePassword'](_0x39c59d);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x4541e0=await bf(this),_0x5c63b8=new Af(_0x4541e0);this['tenantId']===null?this['_projectPasswordPolicy']=_0x5c63b8:this['_tenantPasswordPolicies'][this['tenantId']]=_0x5c63b8;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x27224a){this['_errorFactory']=new Bt('auth','Firebase',_0x27224a());}['onAuthStateChanged'](_0x489ad2,_0x51e568,_0x4458a3){return this['registerStateListener'](this['authStateSubscription'],_0x489ad2,_0x51e568,_0x4458a3);}['beforeAuthStateChanged'](_0x3f6c60,_0x20d71b){return this['beforeStateQueue']['pushCallback'](_0x3f6c60,_0x20d71b);}['onIdTokenChanged'](_0x4732d3,_0x24c9a0,_0x4ed179){return this['registerStateListener'](this['idTokenSubscription'],_0x4732d3,_0x24c9a0,_0x4ed179);}['authStateReady'](){return new Promise((_0x5108e6,_0x2b16df)=>{if(this['currentUser'])_0x5108e6();else{const _0x27a634=this['onAuthStateChanged'](()=>{_0x27a634(),_0x5108e6();},_0x2b16df);}});}async['revokeAccessToken'](_0x4203c5){if(this['currentUser']){const _0x5daf9b=await this['currentUser']['getIdToken'](),_0x398ca9={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x4203c5,'idToken':_0x5daf9b};this['tenantId']!=null&&(_0x398ca9['tenantId']=this['tenantId']),await wf(this,_0x398ca9);}}['toJSON'](){var _0x32d69a;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x32d69a=this['_currentUser'])==null?void 0x0:_0x32d69a['toJSON']()};}async['_setRedirectUser'](_0x45182f,_0x218197){const _0x2cb14c=await this['getOrInitRedirectPersistenceManager'](_0x218197);return _0x45182f===null?_0x2cb14c['removeCurrentUser']():_0x2cb14c['setCurrentUser'](_0x45182f);}async['getOrInitRedirectPersistenceManager'](_0x4f52ef){if(!this['redirectPersistenceManager']){const _0x3e32a4=_0x4f52ef&&ie(_0x4f52ef)||this['_popupRedirectResolver'];m(_0x3e32a4,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x3e32a4['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x5c35d7){var _0x116138,_0x3eed19;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x116138=this['_currentUser'])==null?void 0x0:_0x116138['_redirectEventId'])===_0x5c35d7?this['_currentUser']:((_0x3eed19=this['redirectUser'])==null?void 0x0:_0x3eed19['_redirectEventId'])===_0x5c35d7?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x3345f0){if(_0x3345f0===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x3345f0));}['_notifyListenersIfCurrent'](_0x4b0536){_0x4b0536===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x2e4693;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x3024f5=((_0x2e4693=this['currentUser'])==null?void 0x0:_0x2e4693['uid'])??null;this['lastNotifiedUid']!==_0x3024f5&&(this['lastNotifiedUid']=_0x3024f5,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x548e5e,_0x225ea6,_0x221a62,_0xe910ed){if(this['_deleted'])return()=>{};const _0x345447=typeof _0x225ea6=='function'?_0x225ea6:_0x225ea6['next']['bind'](_0x225ea6);let _0x5dd82f=!0x1;const _0x110a87=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x110a87,this,'internal-error'),_0x110a87['then'](()=>{_0x5dd82f||_0x345447(this['currentUser']);}),typeof _0x225ea6=='function'){const _0x154926=_0x548e5e['addObserver'](_0x225ea6,_0x221a62,_0xe910ed);return()=>{_0x5dd82f=!0x0,_0x154926();};}else{const _0x4fb34d=_0x548e5e['addObserver'](_0x225ea6);return()=>{_0x5dd82f=!0x0,_0x4fb34d();};}}async['directlySetCurrentUser'](_0x17aeb8){this['currentUser']&&this['currentUser']!==_0x17aeb8&&this['_currentUser']['_stopProactiveRefresh'](),_0x17aeb8&&this['isProactiveRefreshEnabled']&&_0x17aeb8['_startProactiveRefresh'](),this['currentUser']=_0x17aeb8,_0x17aeb8?await this['assertedPersistence']['setCurrentUser'](_0x17aeb8):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x1c5970){return this['operations']=this['operations']['then'](_0x1c5970,_0x1c5970),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x380ae5){!_0x380ae5||this['frameworks']['includes'](_0x380ae5)||(this['frameworks']['push'](_0x380ae5),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x9c02a6;const _0x565896={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x565896['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x864163=await((_0x9c02a6=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x9c02a6['getHeartbeatsHeader']());_0x864163&&(_0x565896['X-Firebase-Client']=_0x864163);const _0x4438e0=await this['_getAppCheckToken']();return _0x4438e0&&(_0x565896['X-Firebase-AppCheck']=_0x4438e0),_0x565896;}async['_getAppCheckToken'](){var _0x96b74e;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0xd204a5=await((_0x96b74e=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x96b74e['getToken']());return _0xd204a5!=null&&_0xd204a5['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0xd204a5['error']),_0xd204a5==null?void 0x0:_0xd204a5['token'];}}function qe(_0x488deb){return N(_0x488deb);}class Rr{constructor(_0x57a1b6){this['auth']=_0x57a1b6,this['observer']=null,this['addObserver']=Tc(_0xe395ce=>this['observer']=_0xe395ce);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x2ed350){jn=_0x2ed350;}function xa(_0x4b5201){return jn['loadJS'](_0x4b5201);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x1733ef){return'__'+_0x1733ef+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x4a2839){_0x4a2839();}['execute'](_0x48cd17,_0x432d6b){return Promise['resolve']('token');}['render'](_0x47081f,_0x1b537d){return'';}}class Lf{['ready'](_0x4462e9){_0x4462e9();}['execute'](_0x32c163,_0x519746){return Promise['resolve']('token');}['render'](_0x38d50e,_0x16dcc7){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x3e3601){this['type']=xf,this['auth']=qe(_0x3e3601);}async['verify'](_0x1e36b5='verify',_0x4378c5=!0x1){async function _0x543671(_0x3dea8b){if(!_0x4378c5){if(_0x3dea8b['tenantId']==null&&_0x3dea8b['_agentRecaptchaConfig']!=null)return _0x3dea8b['_agentRecaptchaConfig']['siteKey'];if(_0x3dea8b['tenantId']!=null&&_0x3dea8b['_tenantRecaptchaConfigs'][_0x3dea8b['tenantId']]!==void 0x0)return _0x3dea8b['_tenantRecaptchaConfigs'][_0x3dea8b['tenantId']]['siteKey'];}return new Promise(async(_0x40cc76,_0x219430)=>{pf(_0x3dea8b,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x255b6d=>{if(_0x255b6d['recaptchaKey']===void 0x0)_0x219430(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x316c29=new ff(_0x255b6d);return _0x3dea8b['tenantId']==null?_0x3dea8b['_agentRecaptchaConfig']=_0x316c29:_0x3dea8b['_tenantRecaptchaConfigs'][_0x3dea8b['tenantId']]=_0x316c29,_0x40cc76(_0x316c29['siteKey']);}})['catch'](_0x2e91f6=>{_0x219430(_0x2e91f6);});});}function _0x31a0cf(_0x2d57bb,_0xc80056,_0x127a8c){const _0x1f021f=window['grecaptcha'];wr(_0x1f021f)?_0x1f021f['enterprise']['ready'](()=>{_0x1f021f['enterprise']['execute'](_0x2d57bb,{'action':_0x1e36b5})['then'](_0x4422eb=>{_0xc80056(_0x4422eb);})['catch'](()=>{_0xc80056(Fa);});}):_0x127a8c(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0xdd91ac,_0x314f45)=>{_0x543671(this['auth'])['then'](_0x2281dc=>{if(!_0x4378c5&&wr(window['grecaptcha']))_0x31a0cf(_0x2281dc,_0xdd91ac,_0x314f45);else{if(typeof window>'u'){_0x314f45(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x2a8a90=Pf();_0x2a8a90['length']!==0x0&&(_0x2a8a90+=_0x2281dc),xa(_0x2a8a90)['then'](()=>{_0x31a0cf(_0x2281dc,_0xdd91ac,_0x314f45);})['catch'](_0x1d2d4c=>{_0x314f45(_0x1d2d4c);});}})['catch'](_0x22bfe7=>{_0x314f45(_0x22bfe7);});});}}async function Ar(_0x3c8150,_0x415591,_0x3acd77,_0x5c4c03=!0x1,_0x86d86b=!0x1){const _0x3ed873=new Ff(_0x3c8150);let _0x83e8bd;if(_0x86d86b)_0x83e8bd=Fa;else try{_0x83e8bd=await _0x3ed873['verify'](_0x3acd77);}catch{_0x83e8bd=await _0x3ed873['verify'](_0x3acd77,!0x0);}const _0x44f9ed={..._0x415591};if(_0x3acd77==='mfaSmsEnrollment'||_0x3acd77==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x44f9ed){const _0x4fab90=_0x44f9ed['phoneEnrollmentInfo']['phoneNumber'],_0x2f148a=_0x44f9ed['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x44f9ed,{'phoneEnrollmentInfo':{'phoneNumber':_0x4fab90,'recaptchaToken':_0x2f148a,'captchaResponse':_0x83e8bd,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x44f9ed){const _0x4dff84=_0x44f9ed['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x44f9ed,{'phoneSignInInfo':{'recaptchaToken':_0x4dff84,'captchaResponse':_0x83e8bd,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x44f9ed;}return _0x5c4c03?Object['assign'](_0x44f9ed,{'captchaResp':_0x83e8bd}):Object['assign'](_0x44f9ed,{'captchaResponse':_0x83e8bd}),Object['assign'](_0x44f9ed,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x44f9ed,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x44f9ed;}async function Di(_0xff5217,_0x43d9fa,_0x59dd07,_0x8c5ef7,_0x155b87){var _0x4f1bd1;if((_0x4f1bd1=_0xff5217['_getRecaptchaConfig']())!=null&&_0x4f1bd1['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x5c8589=await Ar(_0xff5217,_0x43d9fa,_0x59dd07,_0x59dd07==='getOobCode');return _0x8c5ef7(_0xff5217,_0x5c8589);}else return _0x8c5ef7(_0xff5217,_0x43d9fa)['catch'](async _0x4b54e4=>{if(_0x4b54e4['code']==='auth/missing-recaptcha-token'){console['log'](_0x59dd07+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x45fc0c=await Ar(_0xff5217,_0x43d9fa,_0x59dd07,_0x59dd07==='getOobCode');return _0x8c5ef7(_0xff5217,_0x45fc0c);}else return Promise['reject'](_0x4b54e4);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x121ebc,_0x293a7){const _0x25f401=Bi(_0x121ebc,'auth');if(_0x25f401['isInitialized']()){const _0x4e84a4=_0x25f401['getImmediate'](),_0x528d57=_0x25f401['getOptions']();if(Me(_0x528d57,_0x293a7??{}))return _0x4e84a4;Q(_0x4e84a4,'already-initialized');}return _0x25f401['initialize']({'options':_0x293a7});}function Wf(_0x580764,_0x2bc2bf){const _0x467f45=(_0x2bc2bf==null?void 0x0:_0x2bc2bf['persistence'])||[],_0x27a601=(Array['isArray'](_0x467f45)?_0x467f45:[_0x467f45])['map'](ie);_0x2bc2bf!=null&&_0x2bc2bf['errorMap']&&_0x580764['_updateErrorMap'](_0x2bc2bf['errorMap']),_0x580764['_initializeWithPersistence'](_0x27a601,_0x2bc2bf==null?void 0x0:_0x2bc2bf['popupRedirectResolver']);}function Bf(_0x26e44c,_0x54c55f,_0x13ec54){const _0xdcf04e=qe(_0x26e44c);m(/^https?:\/\//['test'](_0x54c55f),_0xdcf04e,'invalid-emulator-scheme');const _0x434ed3=!0x1,_0x442586=Ua(_0x54c55f),{host:_0x375787,port:_0x5c750d}=Vf(_0x54c55f),_0x5d4c09=_0x5c750d===null?'':':'+_0x5c750d,_0x43736e={'url':_0x442586+'//'+_0x375787+_0x5d4c09+'/'},_0x314753=Object['freeze']({'host':_0x375787,'port':_0x5c750d,'protocol':_0x442586['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x434ed3})});if(!_0xdcf04e['_canInitEmulator']){m(_0xdcf04e['config']['emulator']&&_0xdcf04e['emulatorConfig'],_0xdcf04e,'emulator-config-failed'),m(Me(_0x43736e,_0xdcf04e['config']['emulator'])&&Me(_0x314753,_0xdcf04e['emulatorConfig']),_0xdcf04e,'emulator-config-failed');return;}_0xdcf04e['config']['emulator']=_0x43736e,_0xdcf04e['emulatorConfig']=_0x314753,_0xdcf04e['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x375787)?(jr(_0x442586+'//'+_0x375787+_0x5d4c09),Kr('Auth',!0x0)):Hf();}function Ua(_0x12b6a3){const _0x1a753b=_0x12b6a3['indexOf'](':');return _0x1a753b<0x0?'':_0x12b6a3['substr'](0x0,_0x1a753b+0x1);}function Vf(_0x2ccb4b){const _0x349629=Ua(_0x2ccb4b),_0x7ed9d1=/(\/\/)?([^?#/]+)/['exec'](_0x2ccb4b['substr'](_0x349629['length']));if(!_0x7ed9d1)return{'host':'','port':null};const _0xc800fa=_0x7ed9d1[0x2]['split']('@')['pop']()||'',_0x1d3239=/^(\[[^\]]+\])(:|$)/['exec'](_0xc800fa);if(_0x1d3239){const _0x5446c7=_0x1d3239[0x1];return{'host':_0x5446c7,'port':kr(_0xc800fa['substr'](_0x5446c7['length']+0x1))};}else{const [_0x178cac,_0x5a1c95]=_0xc800fa['split'](':');return{'host':_0x178cac,'port':kr(_0x5a1c95)};}}function kr(_0x2dd18f){if(!_0x2dd18f)return null;const _0x4c8382=Number(_0x2dd18f);return isNaN(_0x4c8382)?null:_0x4c8382;}function Hf(){function _0x1818d2(){const _0x5595bf=document['createElement']('p'),_0x319da6=_0x5595bf['style'];_0x5595bf['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x319da6['position']='fixed',_0x319da6['width']='100%',_0x319da6['backgroundColor']='#ffffff',_0x319da6['border']='.1em\x20solid\x20#000000',_0x319da6['color']='#b50000',_0x319da6['bottom']='0px',_0x319da6['left']='0px',_0x319da6['margin']='0px',_0x319da6['zIndex']='10000',_0x319da6['textAlign']='center',_0x5595bf['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x5595bf);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1818d2):_0x1818d2());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x3c0b97,_0x4515a6){this['providerId']=_0x3c0b97,this['signInMethod']=_0x4515a6;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x2991e3){return ne('not\x20implemented');}['_linkToIdToken'](_0x49d57d,_0x49ffe8){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x440d85){return ne('not\x20implemented');}}async function $f(_0x2a5af7,_0x109213){return Ae(_0x2a5af7,'POST','/v1/accounts:signUp',_0x109213);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x5e9b1d,_0x5ea54e){return Qt(_0x5e9b1d,'POST','/v1/accounts:signInWithPassword',Re(_0x5e9b1d,_0x5ea54e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x2c15ae,_0x5297cd){return Qt(_0x2c15ae,'POST','/v1/accounts:signInWithEmailLink',Re(_0x2c15ae,_0x5297cd));}async function zf(_0xe667f0,_0x1d1440){return Qt(_0xe667f0,'POST','/v1/accounts:signInWithEmailLink',Re(_0xe667f0,_0x1d1440));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x45d564,_0x432f22,_0x18977c,_0x374591=null){super('password',_0x18977c),this['_email']=_0x45d564,this['_password']=_0x432f22,this['_tenantId']=_0x374591;}static['_fromEmailAndPassword'](_0x4fc2f7,_0x55cf29){return new Wt(_0x4fc2f7,_0x55cf29,'password');}static['_fromEmailAndCode'](_0x4799f3,_0x473da5,_0x23521d=null){return new Wt(_0x4799f3,_0x473da5,'emailLink',_0x23521d);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x1add64){const _0xd80299=typeof _0x1add64=='string'?JSON['parse'](_0x1add64):_0x1add64;if(_0xd80299!=null&&_0xd80299['email']&&(_0xd80299!=null&&_0xd80299['password'])){if(_0xd80299['signInMethod']==='password')return this['_fromEmailAndPassword'](_0xd80299['email'],_0xd80299['password']);if(_0xd80299['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0xd80299['email'],_0xd80299['password'],_0xd80299['tenantId']);}return null;}async['_getIdTokenResponse'](_0x4de2a7){switch(this['signInMethod']){case'password':const _0x9b8a3e={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x4de2a7,_0x9b8a3e,'signInWithPassword',Gf);case'emailLink':return qf(_0x4de2a7,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x4de2a7,'internal-error');}}async['_linkToIdToken'](_0x53fe21,_0x2415a0){switch(this['signInMethod']){case'password':const _0x2faf14={'idToken':_0x2415a0,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x53fe21,_0x2faf14,'signUpPassword',$f);case'emailLink':return zf(_0x53fe21,{'idToken':_0x2415a0,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x53fe21,'internal-error');}}['_getReauthenticationResolver'](_0x1e9e3e){return this['_getIdTokenResponse'](_0x1e9e3e);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x270a5f,_0x595a6e){return Qt(_0x270a5f,'POST','/v1/accounts:signInWithIdp',Re(_0x270a5f,_0x595a6e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x530e42){const _0x3f6161=new Be(_0x530e42['providerId'],_0x530e42['signInMethod']);return _0x530e42['idToken']||_0x530e42['accessToken']?(_0x530e42['idToken']&&(_0x3f6161['idToken']=_0x530e42['idToken']),_0x530e42['accessToken']&&(_0x3f6161['accessToken']=_0x530e42['accessToken']),_0x530e42['nonce']&&!_0x530e42['pendingToken']&&(_0x3f6161['nonce']=_0x530e42['nonce']),_0x530e42['pendingToken']&&(_0x3f6161['pendingToken']=_0x530e42['pendingToken'])):_0x530e42['oauthToken']&&_0x530e42['oauthTokenSecret']?(_0x3f6161['accessToken']=_0x530e42['oauthToken'],_0x3f6161['secret']=_0x530e42['oauthTokenSecret']):Q('argument-error'),_0x3f6161;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x671354){const _0x32d539=typeof _0x671354=='string'?JSON['parse'](_0x671354):_0x671354,{providerId:_0x23c38a,signInMethod:_0x1b2168,..._0x18c0aa}=_0x32d539;if(!_0x23c38a||!_0x1b2168)return null;const _0x4b2d24=new Be(_0x23c38a,_0x1b2168);return _0x4b2d24['idToken']=_0x18c0aa['idToken']||void 0x0,_0x4b2d24['accessToken']=_0x18c0aa['accessToken']||void 0x0,_0x4b2d24['secret']=_0x18c0aa['secret'],_0x4b2d24['nonce']=_0x18c0aa['nonce'],_0x4b2d24['pendingToken']=_0x18c0aa['pendingToken']||null,_0x4b2d24;}['_getIdTokenResponse'](_0x2d41b6){const _0x58f777=this['buildRequest']();return Xe(_0x2d41b6,_0x58f777);}['_linkToIdToken'](_0x3097a9,_0x39e359){const _0x564265=this['buildRequest']();return _0x564265['idToken']=_0x39e359,Xe(_0x3097a9,_0x564265);}['_getReauthenticationResolver'](_0x167b06){const _0x52c5b1=this['buildRequest']();return _0x52c5b1['autoCreate']=!0x1,Xe(_0x167b06,_0x52c5b1);}['buildRequest'](){const _0x1ec32f={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x1ec32f['pendingToken']=this['pendingToken'];else{const _0x183944={};this['idToken']&&(_0x183944['id_token']=this['idToken']),this['accessToken']&&(_0x183944['access_token']=this['accessToken']),this['secret']&&(_0x183944['oauth_token_secret']=this['secret']),_0x183944['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x183944['nonce']=this['nonce']),_0x1ec32f['postBody']=ct(_0x183944);}return _0x1ec32f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x564430){switch(_0x564430){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x1b3613){const _0x10a64b=vt(Et(_0x1b3613))['link'],_0x409a41=_0x10a64b?vt(Et(_0x10a64b))['deep_link_id']:null,_0x2b2363=vt(Et(_0x1b3613))['deep_link_id'];return(_0x2b2363?vt(Et(_0x2b2363))['link']:null)||_0x2b2363||_0x409a41||_0x10a64b||_0x1b3613;}class Rs{constructor(_0x2d4d2e){const _0x60d980=vt(Et(_0x2d4d2e)),_0x559c4c=_0x60d980['apiKey']??null,_0x432768=_0x60d980['oobCode']??null,_0x100e39=Kf(_0x60d980['mode']??null);m(_0x559c4c&&_0x432768&&_0x100e39,'argument-error'),this['apiKey']=_0x559c4c,this['operation']=_0x100e39,this['code']=_0x432768,this['continueUrl']=_0x60d980['continueUrl']??null,this['languageCode']=_0x60d980['lang']??null,this['tenantId']=_0x60d980['tenantId']??null;}static['parseLink'](_0x25f1db){const _0x39bbdc=Yf(_0x25f1db);try{return new Rs(_0x39bbdc);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x264ac4,_0x177045){return Wt['_fromEmailAndPassword'](_0x264ac4,_0x177045);}static['credentialWithLink'](_0x186db1,_0x56981c){const _0x48b61d=Rs['parseLink'](_0x56981c);return m(_0x48b61d,'argument-error'),Wt['_fromEmailAndCode'](_0x186db1,_0x48b61d['code'],_0x48b61d['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x38c368){this['providerId']=_0x38c368,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x16889f){this['defaultLanguageCode']=_0x16889f;}['setCustomParameters'](_0x4e675b){return this['customParameters']=_0x4e675b,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x3efea5){return this['scopes']['includes'](_0x3efea5)||this['scopes']['push'](_0x3efea5),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x44f093){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x44f093});}static['credentialFromResult'](_0x4eec50){return he['credentialFromTaggedObject'](_0x4eec50);}static['credentialFromError'](_0x490185){return he['credentialFromTaggedObject'](_0x490185['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x382cb0}){if(!_0x382cb0||!('oauthAccessToken'in _0x382cb0)||!_0x382cb0['oauthAccessToken'])return null;try{return he['credential'](_0x382cb0['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3246c1,_0x4f3cf0){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3246c1,'accessToken':_0x4f3cf0});}static['credentialFromResult'](_0x1911ee){return ue['credentialFromTaggedObject'](_0x1911ee);}static['credentialFromError'](_0x2bdb5c){return ue['credentialFromTaggedObject'](_0x2bdb5c['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x268c98}){if(!_0x268c98)return null;const {oauthIdToken:_0x2fb6e4,oauthAccessToken:_0x36a0c2}=_0x268c98;if(!_0x2fb6e4&&!_0x36a0c2)return null;try{return ue['credential'](_0x2fb6e4,_0x36a0c2);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x589ad9){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x589ad9});}static['credentialFromResult'](_0x54725e){return de['credentialFromTaggedObject'](_0x54725e);}static['credentialFromError'](_0x2c2e22){return de['credentialFromTaggedObject'](_0x2c2e22['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x519a3f}){if(!_0x519a3f||!('oauthAccessToken'in _0x519a3f)||!_0x519a3f['oauthAccessToken'])return null;try{return de['credential'](_0x519a3f['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x20eb5d,_0x131409){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x20eb5d,'oauthTokenSecret':_0x131409});}static['credentialFromResult'](_0x2474b3){return fe['credentialFromTaggedObject'](_0x2474b3);}static['credentialFromError'](_0x44e67d){return fe['credentialFromTaggedObject'](_0x44e67d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x476d98}){if(!_0x476d98)return null;const {oauthAccessToken:_0x372a7a,oauthTokenSecret:_0xf8ff90}=_0x476d98;if(!_0x372a7a||!_0xf8ff90)return null;try{return fe['credential'](_0x372a7a,_0xf8ff90);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0xf3b1f,_0x50910e){return Qt(_0xf3b1f,'POST','/v1/accounts:signUp',Re(_0xf3b1f,_0x50910e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x5d6f56){this['user']=_0x5d6f56['user'],this['providerId']=_0x5d6f56['providerId'],this['_tokenResponse']=_0x5d6f56['_tokenResponse'],this['operationType']=_0x5d6f56['operationType'];}static async['_fromIdTokenResponse'](_0x4faf30,_0x5634ed,_0x491735,_0x187d73=!0x1){const _0x1ea8b5=await K['_fromIdTokenResponse'](_0x4faf30,_0x491735,_0x187d73),_0x1fa921=Nr(_0x491735);return new Ve({'user':_0x1ea8b5,'providerId':_0x1fa921,'_tokenResponse':_0x491735,'operationType':_0x5634ed});}static async['_forOperation'](_0x2882fc,_0x305df5,_0x861f59){await _0x2882fc['_updateTokensIfNecessary'](_0x861f59,!0x0);const _0x1ca47d=Nr(_0x861f59);return new Ve({'user':_0x2882fc,'providerId':_0x1ca47d,'_tokenResponse':_0x861f59,'operationType':_0x305df5});}}function Nr(_0x4e89b4){return _0x4e89b4['providerId']?_0x4e89b4['providerId']:'phoneNumber'in _0x4e89b4?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x27443e,_0x3f0e4f,_0x26f241,_0x5f4a00){super(_0x3f0e4f['code'],_0x3f0e4f['message']),this['operationType']=_0x26f241,this['user']=_0x5f4a00,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x27443e['name'],'tenantId':_0x27443e['tenantId']??void 0x0,'_serverResponse':_0x3f0e4f['customData']['_serverResponse'],'operationType':_0x26f241};}static['_fromErrorAndOperation'](_0x1368cb,_0x434bdc,_0x506a58,_0x311e16){return new An(_0x1368cb,_0x434bdc,_0x506a58,_0x311e16);}}function Ba(_0x4dc7d6,_0x372762,_0xe5d345,_0x261c6f){return(_0x372762==='reauthenticate'?_0xe5d345['_getReauthenticationResolver'](_0x4dc7d6):_0xe5d345['_getIdTokenResponse'](_0x4dc7d6))['catch'](_0x2ccb07=>{throw _0x2ccb07['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x4dc7d6,_0x2ccb07,_0x372762,_0x261c6f):_0x2ccb07;});}async function Jf(_0x2a996c,_0x1337c5,_0x5b4641=!0x1){const _0x519f68=await Ut(_0x2a996c,_0x1337c5['_linkToIdToken'](_0x2a996c['auth'],await _0x2a996c['getIdToken']()),_0x5b4641);return Ve['_forOperation'](_0x2a996c,'link',_0x519f68);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x39476d,_0x3722ef,_0x48a5f4=!0x1){const {auth:_0x30d55a}=_0x39476d;if($(_0x30d55a['app']))return Promise['reject'](re(_0x30d55a));const _0x1328f0='reauthenticate';try{const _0x43d540=await Ut(_0x39476d,Ba(_0x30d55a,_0x1328f0,_0x3722ef,_0x39476d),_0x48a5f4);m(_0x43d540['idToken'],_0x30d55a,'internal-error');const _0x35d768=Ts(_0x43d540['idToken']);m(_0x35d768,_0x30d55a,'internal-error');const {sub:_0x215efd}=_0x35d768;return m(_0x39476d['uid']===_0x215efd,_0x30d55a,'user-mismatch'),Ve['_forOperation'](_0x39476d,_0x1328f0,_0x43d540);}catch(_0x37e893){throw(_0x37e893==null?void 0x0:_0x37e893['code'])==='auth/user-not-found'&&Q(_0x30d55a,'user-mismatch'),_0x37e893;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x481aa0,_0x4c72e5,_0x3329a1=!0x1){if($(_0x481aa0['app']))return Promise['reject'](re(_0x481aa0));const _0x3a2c72='signIn',_0x4400d3=await Ba(_0x481aa0,_0x3a2c72,_0x4c72e5),_0x4770a9=await Ve['_fromIdTokenResponse'](_0x481aa0,_0x3a2c72,_0x4400d3);return _0x3329a1||await _0x481aa0['_updateCurrentUser'](_0x4770a9['user']),_0x4770a9;}async function Zf(_0x35d23a,_0x2a2a66){return Va(qe(_0x35d23a),_0x2a2a66);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x54e97b){const _0x339ccf=qe(_0x54e97b);_0x339ccf['_getPasswordPolicyInternal']()&&await _0x339ccf['_updatePasswordPolicy']();}async function P_(_0x1dd12f,_0x2d2e46,_0x570f4e){if($(_0x1dd12f['app']))return Promise['reject'](re(_0x1dd12f));const _0x39f954=qe(_0x1dd12f),_0x7f3d4d=await Di(_0x39f954,{'returnSecureToken':!0x0,'email':_0x2d2e46,'password':_0x570f4e,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x34f080=>{throw _0x34f080['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x1dd12f),_0x34f080;}),_0xa3972f=await Ve['_fromIdTokenResponse'](_0x39f954,'signIn',_0x7f3d4d);return await _0x39f954['_updateCurrentUser'](_0xa3972f['user']),_0xa3972f;}function O_(_0x70b12e,_0x51787d,_0x1741d6){return $(_0x70b12e['app'])?Promise['reject'](re(_0x70b12e)):Zf(N(_0x70b12e),pt['credential'](_0x51787d,_0x1741d6))['catch'](async _0x159e87=>{throw _0x159e87['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x70b12e),_0x159e87;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x3dfaca,_0x92f353){return N(_0x3dfaca)['setPersistence'](_0x92f353);}function ep(_0x502622,_0x595144,_0x1ea37e,_0x22c891){return N(_0x502622)['onIdTokenChanged'](_0x595144,_0x1ea37e,_0x22c891);}function tp(_0x4a8ff9,_0x23d1b9,_0x18f092){return N(_0x4a8ff9)['beforeAuthStateChanged'](_0x23d1b9,_0x18f092);}function M_(_0x5696d1,_0x42fbe0,_0x236598,_0x47b89e){return N(_0x5696d1)['onAuthStateChanged'](_0x42fbe0,_0x236598,_0x47b89e);}function L_(_0xc37851){return N(_0xc37851)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x2fe35d,_0x3cef3b){this['storageRetriever']=_0x2fe35d,this['type']=_0x3cef3b;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x2ad15c,_0x408a34){return this['storage']['setItem'](_0x2ad15c,JSON['stringify'](_0x408a34)),Promise['resolve']();}['_get'](_0x3b09c6){const _0x2c7947=this['storage']['getItem'](_0x3b09c6);return Promise['resolve'](_0x2c7947?JSON['parse'](_0x2c7947):null);}['_remove'](_0x4e3375){return this['storage']['removeItem'](_0x4e3375),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x2ffbee,_0x1cf511)=>this['onStorageEvent'](_0x2ffbee,_0x1cf511),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x1729f2){for(const _0x588949 of Object['keys'](this['listeners'])){const _0x428e01=this['storage']['getItem'](_0x588949),_0x2b4e71=this['localCache'][_0x588949];_0x428e01!==_0x2b4e71&&_0x1729f2(_0x588949,_0x2b4e71,_0x428e01);}}['onStorageEvent'](_0x7b409c,_0x493140=!0x1){if(!_0x7b409c['key']){this['forAllChangedKeys']((_0x3a58fe,_0x30a6f6,_0x1029de)=>{this['notifyListeners'](_0x3a58fe,_0x1029de);});return;}const _0x45e4de=_0x7b409c['key'];_0x493140?this['detachListener']():this['stopPolling']();const _0x40e511=()=>{const _0x3a71fb=this['storage']['getItem'](_0x45e4de);!_0x493140&&this['localCache'][_0x45e4de]===_0x3a71fb||this['notifyListeners'](_0x45e4de,_0x3a71fb);},_0x256faf=this['storage']['getItem'](_0x45e4de);Tf()&&_0x256faf!==_0x7b409c['newValue']&&_0x7b409c['newValue']!==_0x7b409c['oldValue']?setTimeout(_0x40e511,ip):_0x40e511();}['notifyListeners'](_0x3cae06,_0x539e5b){this['localCache'][_0x3cae06]=_0x539e5b;const _0x9febc8=this['listeners'][_0x3cae06];if(_0x9febc8){for(const _0x31fe37 of Array['from'](_0x9febc8))_0x31fe37(_0x539e5b&&JSON['parse'](_0x539e5b));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x2f131e,_0x2a557f,_0x42f778)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x2f131e,'oldValue':_0x2a557f,'newValue':_0x42f778}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x349ed4,_0x8c5b13){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x349ed4]||(this['listeners'][_0x349ed4]=new Set(),this['localCache'][_0x349ed4]=this['storage']['getItem'](_0x349ed4)),this['listeners'][_0x349ed4]['add'](_0x8c5b13);}['_removeListener'](_0x37b2b2,_0x171e23){this['listeners'][_0x37b2b2]&&(this['listeners'][_0x37b2b2]['delete'](_0x171e23),this['listeners'][_0x37b2b2]['size']===0x0&&delete this['listeners'][_0x37b2b2]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0xd3f92,_0x3fff7a){await super['_set'](_0xd3f92,_0x3fff7a),this['localCache'][_0xd3f92]=JSON['stringify'](_0x3fff7a);}async['_get'](_0x21e431){const _0x2723a5=await super['_get'](_0x21e431);return this['localCache'][_0x21e431]=JSON['stringify'](_0x2723a5),_0x2723a5;}async['_remove'](_0x3c5520){await super['_remove'](_0x3c5520),delete this['localCache'][_0x3c5520];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x3f3592,_0x52242c){}['_removeListener'](_0x4cf077,_0x4fd7e5){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x56bac6){return Promise['all'](_0x56bac6['map'](async _0x1c81fb=>{try{return{'fulfilled':!0x0,'value':await _0x1c81fb};}catch(_0x4cf11f){return{'fulfilled':!0x1,'reason':_0x4cf11f};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x57e33b){this['eventTarget']=_0x57e33b,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x57e90c){const _0x5621bd=this['receivers']['find'](_0x338017=>_0x338017['isListeningto'](_0x57e90c));if(_0x5621bd)return _0x5621bd;const _0x21e469=new Kn(_0x57e90c);return this['receivers']['push'](_0x21e469),_0x21e469;}['isListeningto'](_0x4e840d){return this['eventTarget']===_0x4e840d;}async['handleEvent'](_0x35f2d4){const _0x29d72f=_0x35f2d4,{eventId:_0x59d329,eventType:_0x2bd025,data:_0x1ff739}=_0x29d72f['data'],_0x3dff1e=this['handlersMap'][_0x2bd025];if(!(_0x3dff1e!=null&&_0x3dff1e['size']))return;_0x29d72f['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x59d329,'eventType':_0x2bd025});const _0x28d0ca=Array['from'](_0x3dff1e)['map'](async _0x471ef7=>_0x471ef7(_0x29d72f['origin'],_0x1ff739)),_0x4879b2=await rp(_0x28d0ca);_0x29d72f['ports'][0x0]['postMessage']({'status':'done','eventId':_0x59d329,'eventType':_0x2bd025,'response':_0x4879b2});}['_subscribe'](_0x5aaa33,_0x514468){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x5aaa33]||(this['handlersMap'][_0x5aaa33]=new Set()),this['handlersMap'][_0x5aaa33]['add'](_0x514468);}['_unsubscribe'](_0x129926,_0x4b18b1){this['handlersMap'][_0x129926]&&_0x4b18b1&&this['handlersMap'][_0x129926]['delete'](_0x4b18b1),(!_0x4b18b1||this['handlersMap'][_0x129926]['size']===0x0)&&delete this['handlersMap'][_0x129926],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x18368f='',_0x266a64=0xa){let _0x2ef1a2='';for(let _0xe46cba=0x0;_0xe46cba<_0x266a64;_0xe46cba++)_0x2ef1a2+=Math['floor'](Math['random']()*0xa);return _0x18368f+_0x2ef1a2;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x488ffa){this['target']=_0x488ffa,this['handlers']=new Set();}['removeMessageHandler'](_0x314fb0){_0x314fb0['messageChannel']&&(_0x314fb0['messageChannel']['port1']['removeEventListener']('message',_0x314fb0['onMessage']),_0x314fb0['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x314fb0);}async['_send'](_0x51a413,_0x586eee,_0x29a0c8=0x32){const _0x20ec3f=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x20ec3f)throw new Error('connection_unavailable');let _0x1cb879,_0x1512a6;return new Promise((_0x1e1520,_0x4fa1c8)=>{const _0x2f46d6=As('',0x14);_0x20ec3f['port1']['start']();const _0x2a216c=setTimeout(()=>{_0x4fa1c8(new Error('unsupported_event'));},_0x29a0c8);_0x1512a6={'messageChannel':_0x20ec3f,'onMessage'(_0x498acc){const _0x190fa2=_0x498acc;if(_0x190fa2['data']['eventId']===_0x2f46d6)switch(_0x190fa2['data']['status']){case'ack':clearTimeout(_0x2a216c),_0x1cb879=setTimeout(()=>{_0x4fa1c8(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x1cb879),_0x1e1520(_0x190fa2['data']['response']);break;default:clearTimeout(_0x2a216c),clearTimeout(_0x1cb879),_0x4fa1c8(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x1512a6),_0x20ec3f['port1']['addEventListener']('message',_0x1512a6['onMessage']),this['target']['postMessage']({'eventType':_0x51a413,'eventId':_0x2f46d6,'data':_0x586eee},[_0x20ec3f['port2']]);})['finally'](()=>{_0x1512a6&&this['removeMessageHandler'](_0x1512a6);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x5e8c29){Z()['location']['href']=_0x5e8c29;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x15804e;return((_0x15804e=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x15804e['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x45a663){this['request']=_0x45a663;}['toPromise'](){return new Promise((_0x37cab4,_0x397718)=>{this['request']['addEventListener']('success',()=>{_0x37cab4(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x397718(this['request']['error']);});});}}function Yn(_0xd9b075,_0x40301a){return _0xd9b075['transaction']([Nn],_0x40301a?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x310198=indexedDB['deleteDatabase'](Ka);return new Xt(_0x310198)['toPromise']();}function Mi(){const _0x1c61e0=indexedDB['open'](Ka,up);return new Promise((_0x59ce99,_0x2b058d)=>{_0x1c61e0['addEventListener']('error',()=>{_0x2b058d(_0x1c61e0['error']);}),_0x1c61e0['addEventListener']('upgradeneeded',()=>{const _0x2c7042=_0x1c61e0['result'];try{_0x2c7042['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x56e2e6){_0x2b058d(_0x56e2e6);}}),_0x1c61e0['addEventListener']('success',async()=>{const _0x2df7b3=_0x1c61e0['result'];_0x2df7b3['objectStoreNames']['contains'](Nn)?_0x59ce99(_0x2df7b3):(_0x2df7b3['close'](),await dp(),_0x59ce99(await Mi()));});});}async function Pr(_0x37e614,_0x5ab296,_0x40f703){const _0x534c1f=Yn(_0x37e614,!0x0)['put']({[Ya]:_0x5ab296,'value':_0x40f703});return new Xt(_0x534c1f)['toPromise']();}async function fp(_0x52f1e9,_0x2b9a8f){const _0x4fefd6=Yn(_0x52f1e9,!0x1)['get'](_0x2b9a8f),_0x435939=await new Xt(_0x4fefd6)['toPromise']();return _0x435939===void 0x0?null:_0x435939['value'];}function Or(_0x31bd13,_0x193c16){const _0x526f08=Yn(_0x31bd13,!0x0)['delete'](_0x193c16);return new Xt(_0x526f08)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x42c407){let _0x1a2870=0x0;for(;;)try{const _0x4f80cf=await this['_openDb']();return await _0x42c407(_0x4f80cf);}catch(_0x186497){if(_0x1a2870++>_p)throw _0x186497;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x46b7e2,_0x30c88b)=>({'keyProcessed':(await this['_poll']())['includes'](_0x30c88b['key'])})),this['receiver']['_subscribe']('ping',async(_0x3e0a35,_0x8d2273)=>['keyChanged']);}async['initializeSender'](){var _0x194d0c,_0x3c0a4d;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x57ca3d=await this['sender']['_send']('ping',{},0x320);_0x57ca3d&&(_0x194d0c=_0x57ca3d[0x0])!=null&&_0x194d0c['fulfilled']&&(_0x3c0a4d=_0x57ca3d[0x0])!=null&&_0x3c0a4d['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x406f12){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x406f12},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x4d2004=await Mi();return await Pr(_0x4d2004,kn,'1'),await Or(_0x4d2004,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x47931a){this['pendingWrites']++;try{await _0x47931a();}finally{this['pendingWrites']--;}}async['_set'](_0x4c8bcb,_0x132e74){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xcd8bf7=>Pr(_0xcd8bf7,_0x4c8bcb,_0x132e74)),this['localCache'][_0x4c8bcb]=_0x132e74,this['notifyServiceWorker'](_0x4c8bcb)));}async['_get'](_0x38867d){const _0x3508c5=await this['_withRetries'](_0x384271=>fp(_0x384271,_0x38867d));return this['localCache'][_0x38867d]=_0x3508c5,_0x3508c5;}async['_remove'](_0x484203){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2a7a6c=>Or(_0x2a7a6c,_0x484203)),delete this['localCache'][_0x484203],this['notifyServiceWorker'](_0x484203)));}async['_poll'](){const _0x6f2302=await this['_withRetries'](_0x12c646=>{const _0x1e7fcd=Yn(_0x12c646,!0x1)['getAll']();return new Xt(_0x1e7fcd)['toPromise']();});if(!_0x6f2302)return[];if(this['pendingWrites']!==0x0)return[];const _0x3c7d7d=[],_0x3c5ead=new Set();if(_0x6f2302['length']!==0x0){for(const {fbase_key:_0x2c745f,value:_0x4c79f3}of _0x6f2302)_0x3c5ead['add'](_0x2c745f),JSON['stringify'](this['localCache'][_0x2c745f])!==JSON['stringify'](_0x4c79f3)&&(this['notifyListeners'](_0x2c745f,_0x4c79f3),_0x3c7d7d['push'](_0x2c745f));}for(const _0x38fef0 of Object['keys'](this['localCache']))this['localCache'][_0x38fef0]&&!_0x3c5ead['has'](_0x38fef0)&&(this['notifyListeners'](_0x38fef0,null),_0x3c7d7d['push'](_0x38fef0));return _0x3c7d7d;}['notifyListeners'](_0x49999b,_0xa01218){this['localCache'][_0x49999b]=_0xa01218;const _0x10091d=this['listeners'][_0x49999b];if(_0x10091d){for(const _0x2de8eb of Array['from'](_0x10091d))_0x2de8eb(_0xa01218);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x11a845,_0x3f7b1e){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x11a845]||(this['listeners'][_0x11a845]=new Set(),this['_get'](_0x11a845)),this['listeners'][_0x11a845]['add'](_0x3f7b1e);}['_removeListener'](_0x4d8b32,_0x483fb2){this['listeners'][_0x4d8b32]&&(this['listeners'][_0x4d8b32]['delete'](_0x483fb2),this['listeners'][_0x4d8b32]['size']===0x0&&delete this['listeners'][_0x4d8b32]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x231f46,_0x2245d5){return _0x2245d5?ie(_0x2245d5):(m(_0x231f46['_popupRedirectResolver'],_0x231f46,'argument-error'),_0x231f46['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x16c350){super('custom','custom'),this['params']=_0x16c350;}['_getIdTokenResponse'](_0x17b90d){return Xe(_0x17b90d,this['_buildIdpRequest']());}['_linkToIdToken'](_0x4214e8,_0x5a5153){return Xe(_0x4214e8,this['_buildIdpRequest'](_0x5a5153));}['_getReauthenticationResolver'](_0x4832a6){return Xe(_0x4832a6,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x53d5ef){const _0x5bd20e={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x53d5ef&&(_0x5bd20e['idToken']=_0x53d5ef),_0x5bd20e;}}function yp(_0x49a939){return Va(_0x49a939['auth'],new ks(_0x49a939),_0x49a939['bypassAuthState']);}function vp(_0x325d54){const {auth:_0x5d2ad1,user:_0x11d571}=_0x325d54;return m(_0x11d571,_0x5d2ad1,'internal-error'),Xf(_0x11d571,new ks(_0x325d54),_0x325d54['bypassAuthState']);}async function Ep(_0x360117){const {auth:_0x279419,user:_0xaf5c2c}=_0x360117;return m(_0xaf5c2c,_0x279419,'internal-error'),Jf(_0xaf5c2c,new ks(_0x360117),_0x360117['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x230ffe,_0xa049f,_0x170cfb,_0x13a514,_0x39044b=!0x1){this['auth']=_0x230ffe,this['resolver']=_0x170cfb,this['user']=_0x13a514,this['bypassAuthState']=_0x39044b,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0xa049f)?_0xa049f:[_0xa049f];}['execute'](){return new Promise(async(_0x490153,_0x568500)=>{this['pendingPromise']={'resolve':_0x490153,'reject':_0x568500};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x541795){this['reject'](_0x541795);}});}async['onAuthEvent'](_0x10db11){const {urlResponse:_0x4e2946,sessionId:_0x3e0093,postBody:_0x1debca,tenantId:_0x4a2136,error:_0xf4bf74,type:_0x13adbb}=_0x10db11;if(_0xf4bf74){this['reject'](_0xf4bf74);return;}const _0x58c5c3={'auth':this['auth'],'requestUri':_0x4e2946,'sessionId':_0x3e0093,'tenantId':_0x4a2136||void 0x0,'postBody':_0x1debca||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x13adbb)(_0x58c5c3));}catch(_0x42a9ab){this['reject'](_0x42a9ab);}}['onError'](_0x16708e){this['reject'](_0x16708e);}['getIdpTask'](_0xd9a6f8){switch(_0xd9a6f8){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x1e042b){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x1e042b),this['unregisterAndCleanUp']();}['reject'](_0x45a7ee){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x45a7ee),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x158856,_0x51e2de,_0x3e91e0,_0x483637,_0x596ab0){super(_0x158856,_0x51e2de,_0x483637,_0x596ab0),this['provider']=_0x3e91e0,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x5a414e=await this['execute']();return m(_0x5a414e,this['auth'],'internal-error'),_0x5a414e;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x397026=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x397026),this['authWindow']['associatedEvent']=_0x397026,this['resolver']['_originValidation'](this['auth'])['catch'](_0x11b730=>{this['reject'](_0x11b730);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x3c1e67=>{_0x3c1e67||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x4307d6;return((_0x4307d6=this['authWindow'])==null?void 0x0:_0x4307d6['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x3ea090=()=>{var _0x2da36c,_0x69d3e5;if((_0x69d3e5=(_0x2da36c=this['authWindow'])==null?void 0x0:_0x2da36c['window'])!=null&&_0x69d3e5['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x3ea090,Ip['get']());};_0x3ea090();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x3fb13e,_0x1297dc,_0x5834d4=!0x1){super(_0x3fb13e,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x1297dc,void 0x0,_0x5834d4),this['eventId']=null;}async['execute'](){let _0x3fdd87=on['get'](this['auth']['_key']());if(!_0x3fdd87){try{const _0x29a64b=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x3fdd87=()=>Promise['resolve'](_0x29a64b);}catch(_0x3c6465){_0x3fdd87=()=>Promise['reject'](_0x3c6465);}on['set'](this['auth']['_key'](),_0x3fdd87);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x3fdd87();}async['onAuthEvent'](_0x31ce4b){if(_0x31ce4b['type']==='signInViaRedirect')return super['onAuthEvent'](_0x31ce4b);if(_0x31ce4b['type']==='unknown'){this['resolve'](null);return;}if(_0x31ce4b['eventId']){const _0x3fa3f7=await this['auth']['_redirectUserForId'](_0x31ce4b['eventId']);if(_0x3fa3f7)return this['user']=_0x3fa3f7,super['onAuthEvent'](_0x31ce4b);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x2ad7ee,_0x4baf0c){const _0x46c6f1=Rp(_0x4baf0c),_0x159c65=bp(_0x2ad7ee);if(!await _0x159c65['_isAvailable']())return!0x1;const _0x46b158=await _0x159c65['_get'](_0x46c6f1)==='true';return await _0x159c65['_remove'](_0x46c6f1),_0x46b158;}function Sp(_0x24d4a3,_0x1edb13){on['set'](_0x24d4a3['_key'](),_0x1edb13);}function bp(_0x30e297){return ie(_0x30e297['_redirectPersistence']);}function Rp(_0x4ae7c0){return rn(wp,_0x4ae7c0['config']['apiKey'],_0x4ae7c0['name']);}async function Ap(_0x3b1c5b,_0x1d29a9,_0x3c3ac5=!0x1){if($(_0x3b1c5b['app']))return Promise['reject'](re(_0x3b1c5b));const _0x9c082e=qe(_0x3b1c5b),_0x41fa3e=mp(_0x9c082e,_0x1d29a9),_0x5e04e2=await new Cp(_0x9c082e,_0x41fa3e,_0x3c3ac5)['execute']();return _0x5e04e2&&!_0x3c3ac5&&(delete _0x5e04e2['user']['_redirectEventId'],await _0x9c082e['_persistUserIfCurrent'](_0x5e04e2['user']),await _0x9c082e['_setRedirectUser'](null,_0x1d29a9)),_0x5e04e2;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x1657ce){this['auth']=_0x1657ce,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x410f75){this['consumers']['add'](_0x410f75),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x410f75)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x410f75),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x3676c5){this['consumers']['delete'](_0x3676c5);}['onEvent'](_0x4f1042){if(this['hasEventBeenHandled'](_0x4f1042))return!0x1;let _0x427d5e=!0x1;return this['consumers']['forEach'](_0x2fdfec=>{this['isEventForConsumer'](_0x4f1042,_0x2fdfec)&&(_0x427d5e=!0x0,this['sendToConsumer'](_0x4f1042,_0x2fdfec),this['saveEventToCache'](_0x4f1042));}),this['hasHandledPotentialRedirect']||!Pp(_0x4f1042)||(this['hasHandledPotentialRedirect']=!0x0,_0x427d5e||(this['queuedRedirectEvent']=_0x4f1042,_0x427d5e=!0x0)),_0x427d5e;}['sendToConsumer'](_0x4e04ff,_0x59487d){var _0x20b14c;if(_0x4e04ff['error']&&!Xa(_0x4e04ff)){const _0x567784=((_0x20b14c=_0x4e04ff['error']['code'])==null?void 0x0:_0x20b14c['split']('auth/')[0x1])||'internal-error';_0x59487d['onError'](X(this['auth'],_0x567784));}else _0x59487d['onAuthEvent'](_0x4e04ff);}['isEventForConsumer'](_0x1d9043,_0xea578a){const _0x380f2f=_0xea578a['eventId']===null||!!_0x1d9043['eventId']&&_0x1d9043['eventId']===_0xea578a['eventId'];return _0xea578a['filter']['includes'](_0x1d9043['type'])&&_0x380f2f;}['hasEventBeenHandled'](_0x10b06b){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x10b06b));}['saveEventToCache'](_0x17b77f){this['cachedEventUids']['add'](Dr(_0x17b77f)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x426f86){return[_0x426f86['type'],_0x426f86['eventId'],_0x426f86['sessionId'],_0x426f86['tenantId']]['filter'](_0x58d715=>_0x58d715)['join']('-');}function Xa({type:_0x177458,error:_0x1caba4}){return _0x177458==='unknown'&&(_0x1caba4==null?void 0x0:_0x1caba4['code'])==='auth/no-auth-event';}function Pp(_0x3fee9c){switch(_0x3fee9c['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x3fee9c);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x29bcda,_0xce88a0={}){return Ae(_0x29bcda,'GET','/v1/projects',_0xce88a0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x3971dc){if(_0x3971dc['config']['emulator'])return;const {authorizedDomains:_0x51a262}=await Op(_0x3971dc);for(const _0x17bf98 of _0x51a262)try{if(xp(_0x17bf98))return;}catch{}Q(_0x3971dc,'unauthorized-domain');}function xp(_0x57b8c8){const _0x704102=Pi(),{protocol:_0x336252,hostname:_0x4e54f4}=new URL(_0x704102);if(_0x57b8c8['startsWith']('chrome-extension://')){const _0x164fb4=new URL(_0x57b8c8);return _0x164fb4['hostname']===''&&_0x4e54f4===''?_0x336252==='chrome-extension:'&&_0x57b8c8['replace']('chrome-extension://','')===_0x704102['replace']('chrome-extension://',''):_0x336252==='chrome-extension:'&&_0x164fb4['hostname']===_0x4e54f4;}if(!Mp['test'](_0x336252))return!0x1;if(Dp['test'](_0x57b8c8))return _0x4e54f4===_0x57b8c8;const _0x14df56=_0x57b8c8['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x14df56+'|'+_0x14df56+')$','i')['test'](_0x4e54f4);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0xa98725=Z()['___jsl'];if(_0xa98725!=null&&_0xa98725['H']){for(const _0x15f6cb of Object['keys'](_0xa98725['H']))if(_0xa98725['H'][_0x15f6cb]['r']=_0xa98725['H'][_0x15f6cb]['r']||[],_0xa98725['H'][_0x15f6cb]['L']=_0xa98725['H'][_0x15f6cb]['L']||[],_0xa98725['H'][_0x15f6cb]['r']=[..._0xa98725['H'][_0x15f6cb]['L']],_0xa98725['CP']){for(let _0x109707=0x0;_0x109707<_0xa98725['CP']['length'];_0x109707++)_0xa98725['CP'][_0x109707]=null;}}}function Up(_0x35a02c){return new Promise((_0x2aeb39,_0x3d4e1f)=>{var _0x547a64,_0x28381b,_0x1f696e;function _0x535d54(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x2aeb39(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x3d4e1f(X(_0x35a02c,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x28381b=(_0x547a64=Z()['gapi'])==null?void 0x0:_0x547a64['iframes'])!=null&&_0x28381b['Iframe'])_0x2aeb39(gapi['iframes']['getContext']());else{if((_0x1f696e=Z()['gapi'])!=null&&_0x1f696e['load'])_0x535d54();else{const _0x4cdc38=Df('iframefcb');return Z()[_0x4cdc38]=()=>{gapi['load']?_0x535d54():_0x3d4e1f(X(_0x35a02c,'network-request-failed'));},xa(Of()+'?onload='+_0x4cdc38)['catch'](_0xce7808=>_0x3d4e1f(_0xce7808));}}})['catch'](_0x30c974=>{throw an=null,_0x30c974;});}let an=null;function Wp(_0x1f8e76){return an=an||Up(_0x1f8e76),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x319b82){const _0x274687=_0x319b82['config'];m(_0x274687['authDomain'],_0x319b82,'auth-domain-config-required');const _0x52afbb=_0x274687['emulator']?Cs(_0x274687,Hp):'https://'+_0x319b82['config']['authDomain']+'/'+Vp,_0x4db05e={'apiKey':_0x274687['apiKey'],'appName':_0x319b82['name'],'v':lt},_0x4bcc5a=Gp['get'](_0x319b82['config']['apiHost']);_0x4bcc5a&&(_0x4db05e['eid']=_0x4bcc5a);const _0xd905de=_0x319b82['_getFrameworks']();return _0xd905de['length']&&(_0x4db05e['fw']=_0xd905de['join'](',')),_0x52afbb+'?'+ct(_0x4db05e)['slice'](0x1);}async function zp(_0x4b4fa5){const _0x4db9f9=await Wp(_0x4b4fa5),_0x437f24=Z()['gapi'];return m(_0x437f24,_0x4b4fa5,'internal-error'),_0x4db9f9['open']({'where':document['body'],'url':qp(_0x4b4fa5),'messageHandlersFilter':_0x437f24['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x192e6d=>new Promise(async(_0x25b15d,_0x289b5e)=>{await _0x192e6d['restyle']({'setHideOnLeave':!0x1});const _0x5a9a69=X(_0x4b4fa5,'network-request-failed'),_0x10d064=Z()['setTimeout'](()=>{_0x289b5e(_0x5a9a69);},Bp['get']());function _0xefd6af(){Z()['clearTimeout'](_0x10d064),_0x25b15d(_0x192e6d);}_0x192e6d['ping'](_0xefd6af)['then'](_0xefd6af,()=>{_0x289b5e(_0x5a9a69);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x4d1421){this['window']=_0x4d1421,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x11c583,_0x2f723d,_0x31c76f,_0x3fdfd4=Kp,_0x3e12d3=Yp){const _0x4c6883=Math['max']((window['screen']['availHeight']-_0x3e12d3)/0x2,0x0)['toString'](),_0xad9498=Math['max']((window['screen']['availWidth']-_0x3fdfd4)/0x2,0x0)['toString']();let _0x530588='';const _0x4e9ffe={...jp,'width':_0x3fdfd4['toString'](),'height':_0x3e12d3['toString'](),'top':_0x4c6883,'left':_0xad9498},_0xe50fbf=W()['toLowerCase']();_0x31c76f&&(_0x530588=ka(_0xe50fbf)?Qp:_0x31c76f),Ra(_0xe50fbf)&&(_0x2f723d=_0x2f723d||Jp,_0x4e9ffe['scrollbars']='yes');const _0x2ed988=Object['entries'](_0x4e9ffe)['reduce']((_0x48cba6,[_0xfcd382,_0x45308f])=>''+_0x48cba6+_0xfcd382+'='+_0x45308f+',','');if(Cf(_0xe50fbf)&&_0x530588!=='_self')return Zp(_0x2f723d||'',_0x530588),new Lr(null);const _0x4ab0bb=window['open'](_0x2f723d||'',_0x530588,_0x2ed988);m(_0x4ab0bb,_0x11c583,'popup-blocked');try{_0x4ab0bb['focus']();}catch{}return new Lr(_0x4ab0bb);}function Zp(_0x481cfd,_0x32bf1c){const _0x2d3204=document['createElement']('a');_0x2d3204['href']=_0x481cfd,_0x2d3204['target']=_0x32bf1c;const _0x43524f=document['createEvent']('MouseEvent');_0x43524f['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x2d3204['dispatchEvent'](_0x43524f);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x5625d4,_0x2da7bf,_0x1daed3,_0x4f346d,_0xd4d71e,_0x595c08){m(_0x5625d4['config']['authDomain'],_0x5625d4,'auth-domain-config-required'),m(_0x5625d4['config']['apiKey'],_0x5625d4,'invalid-api-key');const _0x53e2da={'apiKey':_0x5625d4['config']['apiKey'],'appName':_0x5625d4['name'],'authType':_0x1daed3,'redirectUrl':_0x4f346d,'v':lt,'eventId':_0xd4d71e};if(_0x2da7bf instanceof Wa){_0x2da7bf['setDefaultLanguage'](_0x5625d4['languageCode']),_0x53e2da['providerId']=_0x2da7bf['providerId']||'',ui(_0x2da7bf['getCustomParameters']())||(_0x53e2da['customParameters']=JSON['stringify'](_0x2da7bf['getCustomParameters']()));for(const [_0x4dbbbb,_0x27f2b8]of Object['entries']({}))_0x53e2da[_0x4dbbbb]=_0x27f2b8;}if(_0x2da7bf instanceof Jt){const _0x2fd070=_0x2da7bf['getScopes']()['filter'](_0x1bcdfe=>_0x1bcdfe!=='');_0x2fd070['length']>0x0&&(_0x53e2da['scopes']=_0x2fd070['join'](','));}_0x5625d4['tenantId']&&(_0x53e2da['tid']=_0x5625d4['tenantId']);const _0x5e1d75=_0x53e2da;for(const _0x126d2b of Object['keys'](_0x5e1d75))_0x5e1d75[_0x126d2b]===void 0x0&&delete _0x5e1d75[_0x126d2b];const _0x52ef70=await _0x5625d4['_getAppCheckToken'](),_0x18795c=_0x52ef70?'#'+n_+'='+encodeURIComponent(_0x52ef70):'';return i_(_0x5625d4)+'?'+ct(_0x5e1d75)['slice'](0x1)+_0x18795c;}function i_({config:_0x53a92d}){return _0x53a92d['emulator']?Cs(_0x53a92d,t_):'https://'+_0x53a92d['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x46081c,_0x3077b0,_0xff18f9,_0x8c9008){var _0x309f90;ce((_0x309f90=this['eventManagers'][_0x46081c['_key']()])==null?void 0x0:_0x309f90['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x5df03a=await xr(_0x46081c,_0x3077b0,_0xff18f9,Pi(),_0x8c9008);return Xp(_0x46081c,_0x5df03a,As());}async['_openRedirect'](_0x2bb17c,_0xc42d02,_0x16bc66,_0x1b6a29){await this['_originValidation'](_0x2bb17c);const _0x18e595=await xr(_0x2bb17c,_0xc42d02,_0x16bc66,Pi(),_0x1b6a29);return ap(_0x18e595),new Promise(()=>{});}['_initialize'](_0x30f3b1){const _0x31e11a=_0x30f3b1['_key']();if(this['eventManagers'][_0x31e11a]){const {manager:_0x174137,promise:_0x49e0f9}=this['eventManagers'][_0x31e11a];return _0x174137?Promise['resolve'](_0x174137):(ce(_0x49e0f9,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x49e0f9);}const _0x2262b0=this['initAndGetManager'](_0x30f3b1);return this['eventManagers'][_0x31e11a]={'promise':_0x2262b0},_0x2262b0['catch'](()=>{delete this['eventManagers'][_0x31e11a];}),_0x2262b0;}async['initAndGetManager'](_0x53c337){const _0x4d256b=await zp(_0x53c337),_0x2beb3c=new Np(_0x53c337);return _0x4d256b['register']('authEvent',_0xfd7451=>(m(_0xfd7451==null?void 0x0:_0xfd7451['authEvent'],_0x53c337,'invalid-auth-event'),{'status':_0x2beb3c['onEvent'](_0xfd7451['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x53c337['_key']()]={'manager':_0x2beb3c},this['iframes'][_0x53c337['_key']()]=_0x4d256b,_0x2beb3c;}['_isIframeWebStorageSupported'](_0x52227e,_0x561ca5){this['iframes'][_0x52227e['_key']()]['send'](hi,{'type':hi},_0x3b8c53=>{var _0x2c02f7;const _0x43cd31=(_0x2c02f7=_0x3b8c53==null?void 0x0:_0x3b8c53[0x0])==null?void 0x0:_0x2c02f7[hi];_0x43cd31!==void 0x0&&_0x561ca5(!!_0x43cd31),Q(_0x52227e,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x19118d){const _0x463fc6=_0x19118d['_key']();return this['originValidationPromises'][_0x463fc6]||(this['originValidationPromises'][_0x463fc6]=Lp(_0x19118d)),this['originValidationPromises'][_0x463fc6];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x3612ec){this['auth']=_0x3612ec,this['internalListeners']=new Map();}['getUid'](){var _0x2f72b9;return this['assertAuthConfigured'](),((_0x2f72b9=this['auth']['currentUser'])==null?void 0x0:_0x2f72b9['uid'])||null;}async['getToken'](_0x3af475){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x3af475)}:null;}['addAuthTokenListener'](_0x414c92){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x414c92))return;const _0x3642c8=this['auth']['onIdTokenChanged'](_0x43d83f=>{_0x414c92((_0x43d83f==null?void 0x0:_0x43d83f['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x414c92,_0x3642c8),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x5c5294){this['assertAuthConfigured']();const _0x13fb75=this['internalListeners']['get'](_0x5c5294);_0x13fb75&&(this['internalListeners']['delete'](_0x5c5294),_0x13fb75(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x13a0b7){switch(_0x13a0b7){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x141b32){Ze(new Le('auth',(_0x593300,{options:_0x18ebe3})=>{const _0x5b5f21=_0x593300['getProvider']('app')['getImmediate'](),_0xe660ab=_0x593300['getProvider']('heartbeat'),_0x2bf5e7=_0x593300['getProvider']('app-check-internal'),{apiKey:_0xd863c2,authDomain:_0x2fb968}=_0x5b5f21['options'];m(_0xd863c2&&!_0xd863c2['includes'](':'),'invalid-api-key',{'appName':_0x5b5f21['name']});const _0x588821={'apiKey':_0xd863c2,'authDomain':_0x2fb968,'clientPlatform':_0x141b32,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x141b32)},_0x5e2b9c=new kf(_0x5b5f21,_0xe660ab,_0x2bf5e7,_0x588821);return Wf(_0x5e2b9c,_0x18ebe3),_0x5e2b9c;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x16ec85,_0x2c672c,_0x24247e)=>{_0x16ec85['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x352c9a=>{const _0x59dc82=qe(_0x352c9a['getProvider']('auth')['getImmediate']());return(_0x38b151=>new o_(_0x38b151))(_0x59dc82);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x141b32)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x477787=>async _0x58ae13=>{const _0x18e636=_0x58ae13&&await _0x58ae13['getIdTokenResult'](),_0x1d15f1=_0x18e636&&(new Date()['getTime']()-Date['parse'](_0x18e636['issuedAtTime']))/0x3e8;if(_0x1d15f1&&_0x1d15f1>h_)return;const _0x2993da=_0x18e636==null?void 0x0:_0x18e636['token'];Wr!==_0x2993da&&(Wr=_0x2993da,await fetch(_0x477787,{'method':_0x2993da?'POST':'DELETE','headers':_0x2993da?{'Authorization':'Bearer\x20'+_0x2993da}:{}}));};function x_(_0xe77fae=Zr()){const _0x469bbd=Bi(_0xe77fae,'auth');if(_0x469bbd['isInitialized']())return _0x469bbd['getImmediate']();const _0x477e19=Uf(_0xe77fae,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x2d1d9b=zr('authTokenSyncURL');if(_0x2d1d9b&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x234a87=new URL(_0x2d1d9b,location['origin']);if(location['origin']===_0x234a87['origin']){const _0xff81c9=u_(_0x234a87['toString']());tp(_0x477e19,_0xff81c9,()=>_0xff81c9(_0x477e19['currentUser'])),ep(_0x477e19,_0x468c9d=>_0xff81c9(_0x468c9d));}}const _0xcd97d1=Gr('auth');return _0xcd97d1&&Bf(_0x477e19,'http://'+_0xcd97d1),_0x477e19;}function d_(){var _0x20c021;return((_0x20c021=document['getElementsByTagName']('head'))==null?void 0x0:_0x20c021[0x0])??document;}Nf({'loadJS'(_0x2a94d6){return new Promise((_0x2532b9,_0x352316)=>{const _0x1a7fe4=document['createElement']('script');_0x1a7fe4['setAttribute']('src',_0x2a94d6),_0x1a7fe4['onload']=_0x2532b9,_0x1a7fe4['onerror']=_0x253c92=>{const _0x146257=X('internal-error');_0x146257['customData']=_0x253c92,_0x352316(_0x146257);},_0x1a7fe4['type']='text/javascript',_0x1a7fe4['charset']='UTF-8',d_()['appendChild'](_0x1a7fe4);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};