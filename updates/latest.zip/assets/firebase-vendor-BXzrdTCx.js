const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x315fe6,_0x1dce0e){if(!_0x315fe6)throw rt(_0x1dce0e);},rt=function(_0x15416b){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x15416b);},Vr=function(_0x5344d0){const _0x2a57bf=[];let _0x1a5f67=0x0;for(let _0x2d1c07=0x0;_0x2d1c07<_0x5344d0['length'];_0x2d1c07++){let _0x35a57a=_0x5344d0['charCodeAt'](_0x2d1c07);_0x35a57a<0x80?_0x2a57bf[_0x1a5f67++]=_0x35a57a:_0x35a57a<0x800?(_0x2a57bf[_0x1a5f67++]=_0x35a57a>>0x6|0xc0,_0x2a57bf[_0x1a5f67++]=_0x35a57a&0x3f|0x80):(_0x35a57a&0xfc00)===0xd800&&_0x2d1c07+0x1<_0x5344d0['length']&&(_0x5344d0['charCodeAt'](_0x2d1c07+0x1)&0xfc00)===0xdc00?(_0x35a57a=0x10000+((_0x35a57a&0x3ff)<<0xa)+(_0x5344d0['charCodeAt'](++_0x2d1c07)&0x3ff),_0x2a57bf[_0x1a5f67++]=_0x35a57a>>0x12|0xf0,_0x2a57bf[_0x1a5f67++]=_0x35a57a>>0xc&0x3f|0x80,_0x2a57bf[_0x1a5f67++]=_0x35a57a>>0x6&0x3f|0x80,_0x2a57bf[_0x1a5f67++]=_0x35a57a&0x3f|0x80):(_0x2a57bf[_0x1a5f67++]=_0x35a57a>>0xc|0xe0,_0x2a57bf[_0x1a5f67++]=_0x35a57a>>0x6&0x3f|0x80,_0x2a57bf[_0x1a5f67++]=_0x35a57a&0x3f|0x80);}return _0x2a57bf;},ec=function(_0x188366){const _0x5ebaf1=[];let _0x10184c=0x0,_0x2dac19=0x0;for(;_0x10184c<_0x188366['length'];){const _0x295e75=_0x188366[_0x10184c++];if(_0x295e75<0x80)_0x5ebaf1[_0x2dac19++]=String['fromCharCode'](_0x295e75);else{if(_0x295e75>0xbf&&_0x295e75<0xe0){const _0x275e11=_0x188366[_0x10184c++];_0x5ebaf1[_0x2dac19++]=String['fromCharCode']((_0x295e75&0x1f)<<0x6|_0x275e11&0x3f);}else{if(_0x295e75>0xef&&_0x295e75<0x16d){const _0x4e5e58=_0x188366[_0x10184c++],_0x34b7e8=_0x188366[_0x10184c++],_0x20ef85=_0x188366[_0x10184c++],_0x3eb708=((_0x295e75&0x7)<<0x12|(_0x4e5e58&0x3f)<<0xc|(_0x34b7e8&0x3f)<<0x6|_0x20ef85&0x3f)-0x10000;_0x5ebaf1[_0x2dac19++]=String['fromCharCode'](0xd800+(_0x3eb708>>0xa)),_0x5ebaf1[_0x2dac19++]=String['fromCharCode'](0xdc00+(_0x3eb708&0x3ff));}else{const _0x2a4f03=_0x188366[_0x10184c++],_0x6a57f3=_0x188366[_0x10184c++];_0x5ebaf1[_0x2dac19++]=String['fromCharCode']((_0x295e75&0xf)<<0xc|(_0x2a4f03&0x3f)<<0x6|_0x6a57f3&0x3f);}}}}return _0x5ebaf1['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x1c2199,_0x3f175b){if(!Array['isArray'](_0x1c2199))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x62fe2c=_0x3f175b?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x58531e=[];for(let _0x8805c=0x0;_0x8805c<_0x1c2199['length'];_0x8805c+=0x3){const _0xef0f23=_0x1c2199[_0x8805c],_0x56ab15=_0x8805c+0x1<_0x1c2199['length'],_0x260020=_0x56ab15?_0x1c2199[_0x8805c+0x1]:0x0,_0x57dbe1=_0x8805c+0x2<_0x1c2199['length'],_0x1ba493=_0x57dbe1?_0x1c2199[_0x8805c+0x2]:0x0,_0x2fc087=_0xef0f23>>0x2,_0x2bb37e=(_0xef0f23&0x3)<<0x4|_0x260020>>0x4;let _0x1c594a=(_0x260020&0xf)<<0x2|_0x1ba493>>0x6,_0x420567=_0x1ba493&0x3f;_0x57dbe1||(_0x420567=0x40,_0x56ab15||(_0x1c594a=0x40)),_0x58531e['push'](_0x62fe2c[_0x2fc087],_0x62fe2c[_0x2bb37e],_0x62fe2c[_0x1c594a],_0x62fe2c[_0x420567]);}return _0x58531e['join']('');},'encodeString'(_0x43be0c,_0x5312e5){return this['HAS_NATIVE_SUPPORT']&&!_0x5312e5?btoa(_0x43be0c):this['encodeByteArray'](Vr(_0x43be0c),_0x5312e5);},'decodeString'(_0x1d2da2,_0x567671){return this['HAS_NATIVE_SUPPORT']&&!_0x567671?atob(_0x1d2da2):ec(this['decodeStringToByteArray'](_0x1d2da2,_0x567671));},'decodeStringToByteArray'(_0x5a6306,_0x2be7b1){this['init_']();const _0x5b2dcd=_0x2be7b1?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x51ae25=[];for(let _0xd22e4a=0x0;_0xd22e4a<_0x5a6306['length'];){const _0x1a6066=_0x5b2dcd[_0x5a6306['charAt'](_0xd22e4a++)],_0xe1bc1e=_0xd22e4a<_0x5a6306['length']?_0x5b2dcd[_0x5a6306['charAt'](_0xd22e4a)]:0x0;++_0xd22e4a;const _0x4c15da=_0xd22e4a<_0x5a6306['length']?_0x5b2dcd[_0x5a6306['charAt'](_0xd22e4a)]:0x40;++_0xd22e4a;const _0x3e677f=_0xd22e4a<_0x5a6306['length']?_0x5b2dcd[_0x5a6306['charAt'](_0xd22e4a)]:0x40;if(++_0xd22e4a,_0x1a6066==null||_0xe1bc1e==null||_0x4c15da==null||_0x3e677f==null)throw new tc();const _0x2e3cb6=_0x1a6066<<0x2|_0xe1bc1e>>0x4;if(_0x51ae25['push'](_0x2e3cb6),_0x4c15da!==0x40){const _0x328dd0=_0xe1bc1e<<0x4&0xf0|_0x4c15da>>0x2;if(_0x51ae25['push'](_0x328dd0),_0x3e677f!==0x40){const _0x7e89ec=_0x4c15da<<0x6&0xc0|_0x3e677f;_0x51ae25['push'](_0x7e89ec);}}}return _0x51ae25;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x16c2ec=0x0;_0x16c2ec<this['ENCODED_VALS']['length'];_0x16c2ec++)this['byteToCharMap_'][_0x16c2ec]=this['ENCODED_VALS']['charAt'](_0x16c2ec),this['charToByteMap_'][this['byteToCharMap_'][_0x16c2ec]]=_0x16c2ec,this['byteToCharMapWebSafe_'][_0x16c2ec]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x16c2ec),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x16c2ec]]=_0x16c2ec,_0x16c2ec>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x16c2ec)]=_0x16c2ec,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x16c2ec)]=_0x16c2ec);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x4536ed){const _0x496c17=Vr(_0x4536ed);return Li['encodeByteArray'](_0x496c17,!0x0);},cn=function(_0x574617){return Hr(_0x574617)['replace'](/\./g,'');},ln=function(_0x4b1791){try{return Li['decodeString'](_0x4b1791,!0x0);}catch(_0x57ad3b){console['error']('base64Decode\x20failed:\x20',_0x57ad3b);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x33143d){return $r(void 0x0,_0x33143d);}function $r(_0x366848,_0x49b117){if(!(_0x49b117 instanceof Object))return _0x49b117;switch(_0x49b117['constructor']){case Date:const _0xb94726=_0x49b117;return new Date(_0xb94726['getTime']());case Object:_0x366848===void 0x0&&(_0x366848={});break;case Array:_0x366848=[];break;default:return _0x49b117;}for(const _0x77ed72 in _0x49b117)!_0x49b117['hasOwnProperty'](_0x77ed72)||!ic(_0x77ed72)||(_0x366848[_0x77ed72]=$r(_0x366848[_0x77ed72],_0x49b117[_0x77ed72]));return _0x366848;}function ic(_0x4b4949){return _0x4b4949!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x1f95c1=Ns['__FIREBASE_DEFAULTS__'];if(_0x1f95c1)return JSON['parse'](_0x1f95c1);},ac=()=>{if(typeof document>'u')return;let _0x9d845c;try{_0x9d845c=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x3b0b29=_0x9d845c&&ln(_0x9d845c[0x1]);return _0x3b0b29&&JSON['parse'](_0x3b0b29);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x27297a){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x27297a);return;}},Gr=_0x4025d0=>{var _0x3b97b2,_0x2036fa;return(_0x2036fa=(_0x3b97b2=xi())==null?void 0x0:_0x3b97b2['emulatorHosts'])==null?void 0x0:_0x2036fa[_0x4025d0];},cc=_0x591c57=>{const _0x571b0=Gr(_0x591c57);if(!_0x571b0)return;const _0xfb69f5=_0x571b0['lastIndexOf'](':');if(_0xfb69f5<=0x0||_0xfb69f5+0x1===_0x571b0['length'])throw new Error('Invalid\x20host\x20'+_0x571b0+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x5b75e2=parseInt(_0x571b0['substring'](_0xfb69f5+0x1),0xa);return _0x571b0[0x0]==='['?[_0x571b0['substring'](0x1,_0xfb69f5-0x1),_0x5b75e2]:[_0x571b0['substring'](0x0,_0xfb69f5),_0x5b75e2];},qr=()=>{var _0x20aeba;return(_0x20aeba=xi())==null?void 0x0:_0x20aeba['config'];},zr=_0x335ea6=>{var _0x4bcb72;return(_0x4bcb72=xi())==null?void 0x0:_0x4bcb72['_'+_0x335ea6];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x34b3bc,_0x3c0e5e)=>{this['resolve']=_0x34b3bc,this['reject']=_0x3c0e5e;});}['wrapCallback'](_0x302192){return(_0xb57f15,_0x40b464)=>{_0xb57f15?this['reject'](_0xb57f15):this['resolve'](_0x40b464),typeof _0x302192=='function'&&(this['promise']['catch'](()=>{}),_0x302192['length']===0x1?_0x302192(_0xb57f15):_0x302192(_0xb57f15,_0x40b464));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x5f4804){try{return(_0x5f4804['startsWith']('http://')||_0x5f4804['startsWith']('https://')?new URL(_0x5f4804)['hostname']:_0x5f4804)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x282cff){return(await fetch(_0x282cff,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x17ba48,_0x52c008){if(_0x17ba48['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x105394={'alg':'none','type':'JWT'},_0x561eba=_0x52c008||'demo-project',_0x21bd9d=_0x17ba48['iat']||0x0,_0x429349=_0x17ba48['sub']||_0x17ba48['user_id'];if(!_0x429349)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x5303f8={'iss':'https://securetoken.google.com/'+_0x561eba,'aud':_0x561eba,'iat':_0x21bd9d,'exp':_0x21bd9d+0xe10,'auth_time':_0x21bd9d,'sub':_0x429349,'user_id':_0x429349,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x17ba48};return[cn(JSON['stringify'](_0x105394)),cn(JSON['stringify'](_0x5303f8)),'']['join']('.');}const It={};function hc(){const _0x4f12bb={'prod':[],'emulator':[]};for(const _0x2def40 of Object['keys'](It))It[_0x2def40]?_0x4f12bb['emulator']['push'](_0x2def40):_0x4f12bb['prod']['push'](_0x2def40);return _0x4f12bb;}function uc(_0x1231d5){let _0x190cbe=document['getElementById'](_0x1231d5),_0xa70c46=!0x1;return _0x190cbe||(_0x190cbe=document['createElement']('div'),_0x190cbe['setAttribute']('id',_0x1231d5),_0xa70c46=!0x0),{'created':_0xa70c46,'element':_0x190cbe};}let Ps=!0x1;function Kr(_0x4dbff8,_0x27ae66){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x4dbff8]===_0x27ae66||It[_0x4dbff8]||Ps)return;It[_0x4dbff8]=_0x27ae66;function _0x3ede27(_0x34163c){return'__firebase__banner__'+_0x34163c;}const _0x109888='__firebase__banner',_0x3d85a9=hc()['prod']['length']>0x0;function _0x4d6c99(){const _0x53eb92=document['getElementById'](_0x109888);_0x53eb92&&_0x53eb92['remove']();}function _0x4d6cc3(_0x499ff7){_0x499ff7['style']['display']='flex',_0x499ff7['style']['background']='#7faaf0',_0x499ff7['style']['position']='fixed',_0x499ff7['style']['bottom']='5px',_0x499ff7['style']['left']='5px',_0x499ff7['style']['padding']='.5em',_0x499ff7['style']['borderRadius']='5px',_0x499ff7['style']['alignItems']='center';}function _0x1933c4(_0x175249,_0x42feb8){_0x175249['setAttribute']('width','24'),_0x175249['setAttribute']('id',_0x42feb8),_0x175249['setAttribute']('height','24'),_0x175249['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x175249['setAttribute']('fill','none'),_0x175249['style']['marginLeft']='-6px';}function _0xb2784(){const _0x465993=document['createElement']('span');return _0x465993['style']['cursor']='pointer',_0x465993['style']['marginLeft']='16px',_0x465993['style']['fontSize']='24px',_0x465993['innerHTML']='\x20&times;',_0x465993['onclick']=()=>{Ps=!0x0,_0x4d6c99();},_0x465993;}function _0x68f3a2(_0xa17796,_0x12632e){_0xa17796['setAttribute']('id',_0x12632e),_0xa17796['innerText']='Learn\x20more',_0xa17796['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0xa17796['setAttribute']('target','__blank'),_0xa17796['style']['paddingLeft']='5px',_0xa17796['style']['textDecoration']='underline';}function _0x126d7b(){const _0x1d557d=uc(_0x109888),_0x188e12=_0x3ede27('text'),_0x2f5448=document['getElementById'](_0x188e12)||document['createElement']('span'),_0x493161=_0x3ede27('learnmore'),_0x10f85d=document['getElementById'](_0x493161)||document['createElement']('a'),_0x466e01=_0x3ede27('preprendIcon'),_0x24a86b=document['getElementById'](_0x466e01)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x1d557d['created']){const _0xc59ce4=_0x1d557d['element'];_0x4d6cc3(_0xc59ce4),_0x68f3a2(_0x10f85d,_0x493161);const _0x5bba28=_0xb2784();_0x1933c4(_0x24a86b,_0x466e01),_0xc59ce4['append'](_0x24a86b,_0x2f5448,_0x10f85d,_0x5bba28),document['body']['appendChild'](_0xc59ce4);}_0x3d85a9?(_0x2f5448['innerText']='Preview\x20backend\x20disconnected.',_0x24a86b['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x24a86b['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x2f5448['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x2f5448['setAttribute']('id',_0x188e12);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x126d7b):_0x126d7b();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x48fa13=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x48fa13=='object'&&_0x48fa13['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x1b266a=W();return _0x1b266a['indexOf']('MSIE\x20')>=0x0||_0x1b266a['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x80922f,_0x5e5b1c)=>{try{let _0xd933de=!0x0;const _0x440d7d='validate-browser-context-for-indexeddb-analytics-module',_0x4f1dd4=self['indexedDB']['open'](_0x440d7d);_0x4f1dd4['onsuccess']=()=>{_0x4f1dd4['result']['close'](),_0xd933de||self['indexedDB']['deleteDatabase'](_0x440d7d),_0x80922f(!0x0);},_0x4f1dd4['onupgradeneeded']=()=>{_0xd933de=!0x1;},_0x4f1dd4['onerror']=()=>{var _0xd810ac;_0x5e5b1c(((_0xd810ac=_0x4f1dd4['error'])==null?void 0x0:_0xd810ac['message'])||'');};}catch(_0x20e187){_0x5e5b1c(_0x20e187);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x144ccf,_0x1915a1,_0x53df4b){super(_0x1915a1),this['code']=_0x144ccf,this['customData']=_0x53df4b,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x49e7bb,_0x1acf05,_0xc90eae){this['service']=_0x49e7bb,this['serviceName']=_0x1acf05,this['errors']=_0xc90eae;}['create'](_0x2ebfdd,..._0x4359c2){const _0x448adc=_0x4359c2[0x0]||{},_0x3e50f9=this['service']+'/'+_0x2ebfdd,_0x195286=this['errors'][_0x2ebfdd],_0x229902=_0x195286?vc(_0x195286,_0x448adc):'Error',_0x1ca0eb=this['serviceName']+':\x20'+_0x229902+'\x20('+_0x3e50f9+').';return new Se(_0x3e50f9,_0x1ca0eb,_0x448adc);}}function vc(_0x180724,_0x20e719){return _0x180724['replace'](Ec,(_0xe64f27,_0x10f82b)=>{const _0x214486=_0x20e719[_0x10f82b];return _0x214486!=null?String(_0x214486):'<'+_0x10f82b+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x434330){return JSON['parse'](_0x434330);}function O(_0x18fdf9){return JSON['stringify'](_0x18fdf9);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x4b4c99){let _0x267b38={},_0x3fb2e9={},_0x18143c={},_0x5abe35='';try{const _0x10b82d=_0x4b4c99['split']('.');_0x267b38=At(ln(_0x10b82d[0x0])||''),_0x3fb2e9=At(ln(_0x10b82d[0x1])||''),_0x5abe35=_0x10b82d[0x2],_0x18143c=_0x3fb2e9['d']||{},delete _0x3fb2e9['d'];}catch{}return{'header':_0x267b38,'claims':_0x3fb2e9,'data':_0x18143c,'signature':_0x5abe35};},Ic=function(_0x350d34){const _0x582aa4=Qr(_0x350d34),_0x572ed8=_0x582aa4['claims'];return!!_0x572ed8&&typeof _0x572ed8=='object'&&_0x572ed8['hasOwnProperty']('iat');},wc=function(_0x25becc){const _0x1eb0bd=Qr(_0x25becc)['claims'];return typeof _0x1eb0bd=='object'&&_0x1eb0bd['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x34742d,_0x40830f){return Object['prototype']['hasOwnProperty']['call'](_0x34742d,_0x40830f);}function De(_0x24737a,_0x377111){if(Object['prototype']['hasOwnProperty']['call'](_0x24737a,_0x377111))return _0x24737a[_0x377111];}function ui(_0x287050){for(const _0x2753bd in _0x287050)if(Object['prototype']['hasOwnProperty']['call'](_0x287050,_0x2753bd))return!0x1;return!0x0;}function hn(_0x45385e,_0xf92945,_0x179870){const _0x284cd8={};for(const _0x34ff6f in _0x45385e)Object['prototype']['hasOwnProperty']['call'](_0x45385e,_0x34ff6f)&&(_0x284cd8[_0x34ff6f]=_0xf92945['call'](_0x179870,_0x45385e[_0x34ff6f],_0x34ff6f,_0x45385e));return _0x284cd8;}function Me(_0x2d2814,_0x118c6c){if(_0x2d2814===_0x118c6c)return!0x0;const _0x42742b=Object['keys'](_0x2d2814),_0x340695=Object['keys'](_0x118c6c);for(const _0x46b823 of _0x42742b){if(!_0x340695['includes'](_0x46b823))return!0x1;const _0x5dfb4a=_0x2d2814[_0x46b823],_0x5d3c88=_0x118c6c[_0x46b823];if(Os(_0x5dfb4a)&&Os(_0x5d3c88)){if(!Me(_0x5dfb4a,_0x5d3c88))return!0x1;}else{if(_0x5dfb4a!==_0x5d3c88)return!0x1;}}for(const _0x13be52 of _0x340695)if(!_0x42742b['includes'](_0x13be52))return!0x1;return!0x0;}function Os(_0x48cb8a){return _0x48cb8a!==null&&typeof _0x48cb8a=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x5d5204){const _0x4b9d55=[];for(const [_0x1c0f5f,_0x2d8f34]of Object['entries'](_0x5d5204))Array['isArray'](_0x2d8f34)?_0x2d8f34['forEach'](_0x411a0e=>{_0x4b9d55['push'](encodeURIComponent(_0x1c0f5f)+'='+encodeURIComponent(_0x411a0e));}):_0x4b9d55['push'](encodeURIComponent(_0x1c0f5f)+'='+encodeURIComponent(_0x2d8f34));return _0x4b9d55['length']?'&'+_0x4b9d55['join']('&'):'';}function vt(_0x5f483b){const _0x4d7586={};return _0x5f483b['replace'](/^\?/,'')['split']('&')['forEach'](_0x55b29b=>{if(_0x55b29b){const [_0x4378c7,_0x21f684]=_0x55b29b['split']('=');_0x4d7586[decodeURIComponent(_0x4378c7)]=decodeURIComponent(_0x21f684);}}),_0x4d7586;}function Et(_0x2b7290){const _0x4f2c99=_0x2b7290['indexOf']('?');if(!_0x4f2c99)return'';const _0x270560=_0x2b7290['indexOf']('#',_0x4f2c99);return _0x2b7290['substring'](_0x4f2c99,_0x270560>0x0?_0x270560:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x457404=0x1;_0x457404<this['blockSize'];++_0x457404)this['pad_'][_0x457404]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x350748,_0x5bddba){_0x5bddba||(_0x5bddba=0x0);const _0x2b9d04=this['W_'];if(typeof _0x350748=='string'){for(let _0x5ec620=0x0;_0x5ec620<0x10;_0x5ec620++)_0x2b9d04[_0x5ec620]=_0x350748['charCodeAt'](_0x5bddba)<<0x18|_0x350748['charCodeAt'](_0x5bddba+0x1)<<0x10|_0x350748['charCodeAt'](_0x5bddba+0x2)<<0x8|_0x350748['charCodeAt'](_0x5bddba+0x3),_0x5bddba+=0x4;}else{for(let _0x753ab=0x0;_0x753ab<0x10;_0x753ab++)_0x2b9d04[_0x753ab]=_0x350748[_0x5bddba]<<0x18|_0x350748[_0x5bddba+0x1]<<0x10|_0x350748[_0x5bddba+0x2]<<0x8|_0x350748[_0x5bddba+0x3],_0x5bddba+=0x4;}for(let _0x6ef62f=0x10;_0x6ef62f<0x50;_0x6ef62f++){const _0x7e9652=_0x2b9d04[_0x6ef62f-0x3]^_0x2b9d04[_0x6ef62f-0x8]^_0x2b9d04[_0x6ef62f-0xe]^_0x2b9d04[_0x6ef62f-0x10];_0x2b9d04[_0x6ef62f]=(_0x7e9652<<0x1|_0x7e9652>>>0x1f)&0xffffffff;}let _0x280caf=this['chain_'][0x0],_0x9d64a0=this['chain_'][0x1],_0xe4e01=this['chain_'][0x2],_0x208dd6=this['chain_'][0x3],_0x12fbcd=this['chain_'][0x4],_0x4f97f9,_0x29e71a;for(let _0x475944=0x0;_0x475944<0x50;_0x475944++){_0x475944<0x28?_0x475944<0x14?(_0x4f97f9=_0x208dd6^_0x9d64a0&(_0xe4e01^_0x208dd6),_0x29e71a=0x5a827999):(_0x4f97f9=_0x9d64a0^_0xe4e01^_0x208dd6,_0x29e71a=0x6ed9eba1):_0x475944<0x3c?(_0x4f97f9=_0x9d64a0&_0xe4e01|_0x208dd6&(_0x9d64a0|_0xe4e01),_0x29e71a=0x8f1bbcdc):(_0x4f97f9=_0x9d64a0^_0xe4e01^_0x208dd6,_0x29e71a=0xca62c1d6);const _0x578448=(_0x280caf<<0x5|_0x280caf>>>0x1b)+_0x4f97f9+_0x12fbcd+_0x29e71a+_0x2b9d04[_0x475944]&0xffffffff;_0x12fbcd=_0x208dd6,_0x208dd6=_0xe4e01,_0xe4e01=(_0x9d64a0<<0x1e|_0x9d64a0>>>0x2)&0xffffffff,_0x9d64a0=_0x280caf,_0x280caf=_0x578448;}this['chain_'][0x0]=this['chain_'][0x0]+_0x280caf&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x9d64a0&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0xe4e01&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x208dd6&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x12fbcd&0xffffffff;}['update'](_0x1ebb04,_0x52623a){if(_0x1ebb04==null)return;_0x52623a===void 0x0&&(_0x52623a=_0x1ebb04['length']);const _0x3c662b=_0x52623a-this['blockSize'];let _0x2b0d37=0x0;const _0x2dd7c2=this['buf_'];let _0x12878b=this['inbuf_'];for(;_0x2b0d37<_0x52623a;){if(_0x12878b===0x0){for(;_0x2b0d37<=_0x3c662b;)this['compress_'](_0x1ebb04,_0x2b0d37),_0x2b0d37+=this['blockSize'];}if(typeof _0x1ebb04=='string'){for(;_0x2b0d37<_0x52623a;)if(_0x2dd7c2[_0x12878b]=_0x1ebb04['charCodeAt'](_0x2b0d37),++_0x12878b,++_0x2b0d37,_0x12878b===this['blockSize']){this['compress_'](_0x2dd7c2),_0x12878b=0x0;break;}}else{for(;_0x2b0d37<_0x52623a;)if(_0x2dd7c2[_0x12878b]=_0x1ebb04[_0x2b0d37],++_0x12878b,++_0x2b0d37,_0x12878b===this['blockSize']){this['compress_'](_0x2dd7c2),_0x12878b=0x0;break;}}}this['inbuf_']=_0x12878b,this['total_']+=_0x52623a;}['digest'](){const _0x1f1cef=[];let _0x5613a6=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x163aeb=this['blockSize']-0x1;_0x163aeb>=0x38;_0x163aeb--)this['buf_'][_0x163aeb]=_0x5613a6&0xff,_0x5613a6/=0x100;this['compress_'](this['buf_']);let _0x367099=0x0;for(let _0x57724b=0x0;_0x57724b<0x5;_0x57724b++)for(let _0x1f40e1=0x18;_0x1f40e1>=0x0;_0x1f40e1-=0x8)_0x1f1cef[_0x367099]=this['chain_'][_0x57724b]>>_0x1f40e1&0xff,++_0x367099;return _0x1f1cef;}}function Tc(_0x6f9d4b,_0x50e504){const _0x1f7cfd=new Sc(_0x6f9d4b,_0x50e504);return _0x1f7cfd['subscribe']['bind'](_0x1f7cfd);}class Sc{constructor(_0x299d1a,_0xff9781){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0xff9781,this['task']['then'](()=>{_0x299d1a(this);})['catch'](_0xf5ac9=>{this['error'](_0xf5ac9);});}['next'](_0x3c2cdf){this['forEachObserver'](_0x42f4ca=>{_0x42f4ca['next'](_0x3c2cdf);});}['error'](_0x35136a){this['forEachObserver'](_0x49d988=>{_0x49d988['error'](_0x35136a);}),this['close'](_0x35136a);}['complete'](){this['forEachObserver'](_0x4dae7a=>{_0x4dae7a['complete']();}),this['close']();}['subscribe'](_0x434849,_0x17b453,_0x54cfc6){let _0x4cf505;if(_0x434849===void 0x0&&_0x17b453===void 0x0&&_0x54cfc6===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x434849,['next','error','complete'])?_0x4cf505=_0x434849:_0x4cf505={'next':_0x434849,'error':_0x17b453,'complete':_0x54cfc6},_0x4cf505['next']===void 0x0&&(_0x4cf505['next']=Jn),_0x4cf505['error']===void 0x0&&(_0x4cf505['error']=Jn),_0x4cf505['complete']===void 0x0&&(_0x4cf505['complete']=Jn);const _0xba275a=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x4cf505['error'](this['finalError']):_0x4cf505['complete']();}catch{}}),this['observers']['push'](_0x4cf505),_0xba275a;}['unsubscribeOne'](_0x29b784){this['observers']===void 0x0||this['observers'][_0x29b784]===void 0x0||(delete this['observers'][_0x29b784],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x3bd5fb){if(!this['finalized']){for(let _0x4610f2=0x0;_0x4610f2<this['observers']['length'];_0x4610f2++)this['sendOne'](_0x4610f2,_0x3bd5fb);}}['sendOne'](_0x525de0,_0x226045){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x525de0]!==void 0x0)try{_0x226045(this['observers'][_0x525de0]);}catch(_0x5d59af){typeof console<'u'&&console['error']&&console['error'](_0x5d59af);}});}['close'](_0x21d179){this['finalized']||(this['finalized']=!0x0,_0x21d179!==void 0x0&&(this['finalError']=_0x21d179),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0xae3eb0,_0xf2308e){if(typeof _0xae3eb0!='object'||_0xae3eb0===null)return!0x1;for(const _0xf4142c of _0xf2308e)if(_0xf4142c in _0xae3eb0&&typeof _0xae3eb0[_0xf4142c]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x5523d4,_0x23fa9d){return _0x5523d4+'\x20failed:\x20'+_0x23fa9d+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x3eca7e){const _0x52f77a=[];let _0x117f7e=0x0;for(let _0x19f1e7=0x0;_0x19f1e7<_0x3eca7e['length'];_0x19f1e7++){let _0x45f258=_0x3eca7e['charCodeAt'](_0x19f1e7);if(_0x45f258>=0xd800&&_0x45f258<=0xdbff){const _0x4b970b=_0x45f258-0xd800;_0x19f1e7++,f(_0x19f1e7<_0x3eca7e['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x57b5f3=_0x3eca7e['charCodeAt'](_0x19f1e7)-0xdc00;_0x45f258=0x10000+(_0x4b970b<<0xa)+_0x57b5f3;}_0x45f258<0x80?_0x52f77a[_0x117f7e++]=_0x45f258:_0x45f258<0x800?(_0x52f77a[_0x117f7e++]=_0x45f258>>0x6|0xc0,_0x52f77a[_0x117f7e++]=_0x45f258&0x3f|0x80):_0x45f258<0x10000?(_0x52f77a[_0x117f7e++]=_0x45f258>>0xc|0xe0,_0x52f77a[_0x117f7e++]=_0x45f258>>0x6&0x3f|0x80,_0x52f77a[_0x117f7e++]=_0x45f258&0x3f|0x80):(_0x52f77a[_0x117f7e++]=_0x45f258>>0x12|0xf0,_0x52f77a[_0x117f7e++]=_0x45f258>>0xc&0x3f|0x80,_0x52f77a[_0x117f7e++]=_0x45f258>>0x6&0x3f|0x80,_0x52f77a[_0x117f7e++]=_0x45f258&0x3f|0x80);}return _0x52f77a;},On=function(_0x218f07){let _0x3b5f72=0x0;for(let _0x56b772=0x0;_0x56b772<_0x218f07['length'];_0x56b772++){const _0x5bec85=_0x218f07['charCodeAt'](_0x56b772);_0x5bec85<0x80?_0x3b5f72++:_0x5bec85<0x800?_0x3b5f72+=0x2:_0x5bec85>=0xd800&&_0x5bec85<=0xdbff?(_0x3b5f72+=0x4,_0x56b772++):_0x3b5f72+=0x3;}return _0x3b5f72;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x22501f){return _0x22501f&&_0x22501f['_delegate']?_0x22501f['_delegate']:_0x22501f;}class Le{constructor(_0x56f999,_0x587fa1,_0x4df998){this['name']=_0x56f999,this['instanceFactory']=_0x587fa1,this['type']=_0x4df998,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x5c54e0){return this['instantiationMode']=_0x5c54e0,this;}['setMultipleInstances'](_0x2cce27){return this['multipleInstances']=_0x2cce27,this;}['setServiceProps'](_0x3f0780){return this['serviceProps']=_0x3f0780,this;}['setInstanceCreatedCallback'](_0x40116b){return this['onInstanceCreated']=_0x40116b,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x39ad38,_0x55ef56){this['name']=_0x39ad38,this['container']=_0x55ef56,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0xf33075){const _0xd961a=this['normalizeInstanceIdentifier'](_0xf33075);if(!this['instancesDeferred']['has'](_0xd961a)){const _0x5479b3=new ot();if(this['instancesDeferred']['set'](_0xd961a,_0x5479b3),this['isInitialized'](_0xd961a)||this['shouldAutoInitialize']())try{const _0x415e07=this['getOrInitializeService']({'instanceIdentifier':_0xd961a});_0x415e07&&_0x5479b3['resolve'](_0x415e07);}catch{}}return this['instancesDeferred']['get'](_0xd961a)['promise'];}['getImmediate'](_0xf7dece){const _0x2e5050=this['normalizeInstanceIdentifier'](_0xf7dece==null?void 0x0:_0xf7dece['identifier']),_0x60e023=(_0xf7dece==null?void 0x0:_0xf7dece['optional'])??!0x1;if(this['isInitialized'](_0x2e5050)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x2e5050});}catch(_0x5c2dae){if(_0x60e023)return null;throw _0x5c2dae;}else{if(_0x60e023)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x2cd547){if(_0x2cd547['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x2cd547['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x2cd547,!!this['shouldAutoInitialize']()){if(Nc(_0x2cd547))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x371198,_0x560729]of this['instancesDeferred']['entries']()){const _0x27ee03=this['normalizeInstanceIdentifier'](_0x371198);try{const _0x58bb92=this['getOrInitializeService']({'instanceIdentifier':_0x27ee03});_0x560729['resolve'](_0x58bb92);}catch{}}}}['clearInstance'](_0x28d2b3=Ne){this['instancesDeferred']['delete'](_0x28d2b3),this['instancesOptions']['delete'](_0x28d2b3),this['instances']['delete'](_0x28d2b3);}async['delete'](){const _0x4ea20d=Array['from'](this['instances']['values']());await Promise['all']([..._0x4ea20d['filter'](_0x5e3ae5=>'INTERNAL'in _0x5e3ae5)['map'](_0x397a77=>_0x397a77['INTERNAL']['delete']()),..._0x4ea20d['filter'](_0x7daad1=>'_delete'in _0x7daad1)['map'](_0x59f7bd=>_0x59f7bd['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x48f3bd=Ne){return this['instances']['has'](_0x48f3bd);}['getOptions'](_0x25923d=Ne){return this['instancesOptions']['get'](_0x25923d)||{};}['initialize'](_0x1a57d5={}){const {options:_0xc42312={}}=_0x1a57d5,_0x42839f=this['normalizeInstanceIdentifier'](_0x1a57d5['instanceIdentifier']);if(this['isInitialized'](_0x42839f))throw Error(this['name']+'('+_0x42839f+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x358deb=this['getOrInitializeService']({'instanceIdentifier':_0x42839f,'options':_0xc42312});for(const [_0x40e825,_0x1ede25]of this['instancesDeferred']['entries']()){const _0x37a341=this['normalizeInstanceIdentifier'](_0x40e825);_0x42839f===_0x37a341&&_0x1ede25['resolve'](_0x358deb);}return _0x358deb;}['onInit'](_0x540755,_0xe1dcc){const _0x2f4908=this['normalizeInstanceIdentifier'](_0xe1dcc),_0x2f626d=this['onInitCallbacks']['get'](_0x2f4908)??new Set();_0x2f626d['add'](_0x540755),this['onInitCallbacks']['set'](_0x2f4908,_0x2f626d);const _0x188d2a=this['instances']['get'](_0x2f4908);return _0x188d2a&&_0x540755(_0x188d2a,_0x2f4908),()=>{_0x2f626d['delete'](_0x540755);};}['invokeOnInitCallbacks'](_0x4ae9c4,_0x41bba9){const _0x3aa681=this['onInitCallbacks']['get'](_0x41bba9);if(_0x3aa681){for(const _0x5a7e9b of _0x3aa681)try{_0x5a7e9b(_0x4ae9c4,_0x41bba9);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x55e2bb,options:_0xa098d2={}}){let _0x5c4714=this['instances']['get'](_0x55e2bb);if(!_0x5c4714&&this['component']&&(_0x5c4714=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x55e2bb),'options':_0xa098d2}),this['instances']['set'](_0x55e2bb,_0x5c4714),this['instancesOptions']['set'](_0x55e2bb,_0xa098d2),this['invokeOnInitCallbacks'](_0x5c4714,_0x55e2bb),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x55e2bb,_0x5c4714);}catch{}return _0x5c4714||null;}['normalizeInstanceIdentifier'](_0x12200e=Ne){return this['component']?this['component']['multipleInstances']?_0x12200e:Ne:_0x12200e;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x201b09){return _0x201b09===Ne?void 0x0:_0x201b09;}function Nc(_0x39a5d8){return _0x39a5d8['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x443bc9){this['name']=_0x443bc9,this['providers']=new Map();}['addComponent'](_0x2a4f37){const _0x11cb02=this['getProvider'](_0x2a4f37['name']);if(_0x11cb02['isComponentSet']())throw new Error('Component\x20'+_0x2a4f37['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x11cb02['setComponent'](_0x2a4f37);}['addOrOverwriteComponent'](_0x37452d){this['getProvider'](_0x37452d['name'])['isComponentSet']()&&this['providers']['delete'](_0x37452d['name']),this['addComponent'](_0x37452d);}['getProvider'](_0x2d15ae){if(this['providers']['has'](_0x2d15ae))return this['providers']['get'](_0x2d15ae);const _0x1f43b1=new Ac(_0x2d15ae,this);return this['providers']['set'](_0x2d15ae,_0x1f43b1),_0x1f43b1;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x3fd54f){_0x3fd54f[_0x3fd54f['DEBUG']=0x0]='DEBUG',_0x3fd54f[_0x3fd54f['VERBOSE']=0x1]='VERBOSE',_0x3fd54f[_0x3fd54f['INFO']=0x2]='INFO',_0x3fd54f[_0x3fd54f['WARN']=0x3]='WARN',_0x3fd54f[_0x3fd54f['ERROR']=0x4]='ERROR',_0x3fd54f[_0x3fd54f['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x53e293,_0x20777f,..._0x4b2122)=>{if(_0x20777f<_0x53e293['logLevel'])return;const _0x33dac3=new Date()['toISOString'](),_0x203744=Mc[_0x20777f];if(_0x203744)console[_0x203744]('['+_0x33dac3+']\x20\x20'+_0x53e293['name']+':',..._0x4b2122);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x20777f+')');};class Ui{constructor(_0x2e0b67){this['name']=_0x2e0b67,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x577806){if(!(_0x577806 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x577806+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x577806;}['setLogLevel'](_0x23335b){this['_logLevel']=typeof _0x23335b=='string'?Oc[_0x23335b]:_0x23335b;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0xfa13b6){if(typeof _0xfa13b6!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0xfa13b6;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x24c9e6){this['_userLogHandler']=_0x24c9e6;}['debug'](..._0x13be41){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x13be41),this['_logHandler'](this,T['DEBUG'],..._0x13be41);}['log'](..._0xd57227){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0xd57227),this['_logHandler'](this,T['VERBOSE'],..._0xd57227);}['info'](..._0x35b65b){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x35b65b),this['_logHandler'](this,T['INFO'],..._0x35b65b);}['warn'](..._0x111d37){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x111d37),this['_logHandler'](this,T['WARN'],..._0x111d37);}['error'](..._0xb49862){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0xb49862),this['_logHandler'](this,T['ERROR'],..._0xb49862);}}const xc=(_0x57918c,_0x3f67aa)=>_0x3f67aa['some'](_0x428552=>_0x57918c instanceof _0x428552);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x335295){const _0x19fe7b=new Promise((_0x2e08c0,_0x4558db)=>{const _0x5e9a7e=()=>{_0x335295['removeEventListener']('success',_0x33cabc),_0x335295['removeEventListener']('error',_0x29f38b);},_0x33cabc=()=>{_0x2e08c0(_e(_0x335295['result'])),_0x5e9a7e();},_0x29f38b=()=>{_0x4558db(_0x335295['error']),_0x5e9a7e();};_0x335295['addEventListener']('success',_0x33cabc),_0x335295['addEventListener']('error',_0x29f38b);});return _0x19fe7b['then'](_0xacbfdc=>{_0xacbfdc instanceof IDBCursor&&Jr['set'](_0xacbfdc,_0x335295);})['catch'](()=>{}),Wi['set'](_0x19fe7b,_0x335295),_0x19fe7b;}function Bc(_0x47b0ac){if(di['has'](_0x47b0ac))return;const _0x1fa328=new Promise((_0x276b19,_0x592dec)=>{const _0x19e885=()=>{_0x47b0ac['removeEventListener']('complete',_0x1d4561),_0x47b0ac['removeEventListener']('error',_0x2aef72),_0x47b0ac['removeEventListener']('abort',_0x2aef72);},_0x1d4561=()=>{_0x276b19(),_0x19e885();},_0x2aef72=()=>{_0x592dec(_0x47b0ac['error']||new DOMException('AbortError','AbortError')),_0x19e885();};_0x47b0ac['addEventListener']('complete',_0x1d4561),_0x47b0ac['addEventListener']('error',_0x2aef72),_0x47b0ac['addEventListener']('abort',_0x2aef72);});di['set'](_0x47b0ac,_0x1fa328);}let fi={'get'(_0x2a4a15,_0x2850b5,_0x1cae28){if(_0x2a4a15 instanceof IDBTransaction){if(_0x2850b5==='done')return di['get'](_0x2a4a15);if(_0x2850b5==='objectStoreNames')return _0x2a4a15['objectStoreNames']||Xr['get'](_0x2a4a15);if(_0x2850b5==='store')return _0x1cae28['objectStoreNames'][0x1]?void 0x0:_0x1cae28['objectStore'](_0x1cae28['objectStoreNames'][0x0]);}return _e(_0x2a4a15[_0x2850b5]);},'set'(_0x1e582f,_0x568486,_0xfb204e){return _0x1e582f[_0x568486]=_0xfb204e,!0x0;},'has'(_0x1c16b3,_0x42d439){return _0x1c16b3 instanceof IDBTransaction&&(_0x42d439==='done'||_0x42d439==='store')?!0x0:_0x42d439 in _0x1c16b3;}};function Vc(_0xcf7845){fi=_0xcf7845(fi);}function Hc(_0x2e8af8){return _0x2e8af8===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0xa0e739,..._0x74a1b2){const _0x40d5c1=_0x2e8af8['call'](Zn(this),_0xa0e739,..._0x74a1b2);return Xr['set'](_0x40d5c1,_0xa0e739['sort']?_0xa0e739['sort']():[_0xa0e739]),_e(_0x40d5c1);}:Uc()['includes'](_0x2e8af8)?function(..._0x5e4a0e){return _0x2e8af8['apply'](Zn(this),_0x5e4a0e),_e(Jr['get'](this));}:function(..._0x1ad667){return _e(_0x2e8af8['apply'](Zn(this),_0x1ad667));};}function $c(_0xc09fe3){return typeof _0xc09fe3=='function'?Hc(_0xc09fe3):(_0xc09fe3 instanceof IDBTransaction&&Bc(_0xc09fe3),xc(_0xc09fe3,Fc())?new Proxy(_0xc09fe3,fi):_0xc09fe3);}function _e(_0x3f8764){if(_0x3f8764 instanceof IDBRequest)return Wc(_0x3f8764);if(Xn['has'](_0x3f8764))return Xn['get'](_0x3f8764);const _0x484e54=$c(_0x3f8764);return _0x484e54!==_0x3f8764&&(Xn['set'](_0x3f8764,_0x484e54),Wi['set'](_0x484e54,_0x3f8764)),_0x484e54;}const Zn=_0x42f9d3=>Wi['get'](_0x42f9d3);function Gc(_0x1dd28b,_0x4ccfac,{blocked:_0x597bbc,upgrade:_0x390db5,blocking:_0x251ab1,terminated:_0x2dcd6a}={}){const _0x39c8e2=indexedDB['open'](_0x1dd28b,_0x4ccfac),_0x4cd341=_e(_0x39c8e2);return _0x390db5&&_0x39c8e2['addEventListener']('upgradeneeded',_0x4a7539=>{_0x390db5(_e(_0x39c8e2['result']),_0x4a7539['oldVersion'],_0x4a7539['newVersion'],_e(_0x39c8e2['transaction']),_0x4a7539);}),_0x597bbc&&_0x39c8e2['addEventListener']('blocked',_0x4f35ff=>_0x597bbc(_0x4f35ff['oldVersion'],_0x4f35ff['newVersion'],_0x4f35ff)),_0x4cd341['then'](_0x429664=>{_0x2dcd6a&&_0x429664['addEventListener']('close',()=>_0x2dcd6a()),_0x251ab1&&_0x429664['addEventListener']('versionchange',_0x50efdf=>_0x251ab1(_0x50efdf['oldVersion'],_0x50efdf['newVersion'],_0x50efdf));})['catch'](()=>{}),_0x4cd341;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x39cf11,_0x1a408d){if(!(_0x39cf11 instanceof IDBDatabase&&!(_0x1a408d in _0x39cf11)&&typeof _0x1a408d=='string'))return;if(ei['get'](_0x1a408d))return ei['get'](_0x1a408d);const _0x4800fd=_0x1a408d['replace'](/FromIndex$/,''),_0x4acabe=_0x1a408d!==_0x4800fd,_0x2850a2=zc['includes'](_0x4800fd);if(!(_0x4800fd in(_0x4acabe?IDBIndex:IDBObjectStore)['prototype'])||!(_0x2850a2||qc['includes'](_0x4800fd)))return;const _0x68cb9e=async function(_0x5b524a,..._0x5d5ff9){const _0x2cef90=this['transaction'](_0x5b524a,_0x2850a2?'readwrite':'readonly');let _0x41e61a=_0x2cef90['store'];return _0x4acabe&&(_0x41e61a=_0x41e61a['index'](_0x5d5ff9['shift']())),(await Promise['all']([_0x41e61a[_0x4800fd](..._0x5d5ff9),_0x2850a2&&_0x2cef90['done']]))[0x0];};return ei['set'](_0x1a408d,_0x68cb9e),_0x68cb9e;}Vc(_0x3fbbe0=>({..._0x3fbbe0,'get':(_0x364285,_0x867540,_0x472505)=>Ls(_0x364285,_0x867540)||_0x3fbbe0['get'](_0x364285,_0x867540,_0x472505),'has':(_0x558d46,_0x1ad4aa)=>!!Ls(_0x558d46,_0x1ad4aa)||_0x3fbbe0['has'](_0x558d46,_0x1ad4aa)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x5e6171){this['container']=_0x5e6171;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x183435=>{if(Kc(_0x183435)){const _0x4b1ffc=_0x183435['getImmediate']();return _0x4b1ffc['library']+'/'+_0x4b1ffc['version'];}else return null;})['filter'](_0xaac82=>_0xaac82)['join']('\x20');}}function Kc(_0x2377c3){const _0x437953=_0x2377c3['getComponent']();return(_0x437953==null?void 0x0:_0x437953['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0xc0cbb0,_0x228aae){try{_0xc0cbb0['container']['addComponent'](_0x228aae);}catch(_0x8b9619){oe['debug']('Component\x20'+_0x228aae['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0xc0cbb0['name'],_0x8b9619);}}function Ze(_0x223437){const _0x568e9b=_0x223437['name'];if(mi['has'](_0x568e9b))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x568e9b+'.'),!0x1;mi['set'](_0x568e9b,_0x223437);for(const _0x5eb051 of xe['values']())Fs(_0x5eb051,_0x223437);for(const _0x1c3f18 of gi['values']())Fs(_0x1c3f18,_0x223437);return!0x0;}function Bi(_0x1f65bb,_0x5e005d){const _0x53c032=_0x1f65bb['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x53c032&&_0x53c032['triggerHeartbeat'](),_0x1f65bb['container']['getProvider'](_0x5e005d);}function $(_0x1c9edc){return _0x1c9edc==null?!0x1:_0x1c9edc['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x362759,_0x627441,_0x445eb5){this['_isDeleted']=!0x1,this['_options']={..._0x362759},this['_config']={..._0x627441},this['_name']=_0x627441['name'],this['_automaticDataCollectionEnabled']=_0x627441['automaticDataCollectionEnabled'],this['_container']=_0x445eb5,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x41fc75){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x41fc75;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x14a93b){this['_isDeleted']=_0x14a93b;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x53ea2b,_0x244af9={}){let _0x44bc60=_0x53ea2b;typeof _0x244af9!='object'&&(_0x244af9={'name':_0x244af9});const _0x578cc0={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x244af9},_0x1b2a8f=_0x578cc0['name'];if(typeof _0x1b2a8f!='string'||!_0x1b2a8f)throw ge['create']('bad-app-name',{'appName':String(_0x1b2a8f)});if(_0x44bc60||(_0x44bc60=qr()),!_0x44bc60)throw ge['create']('no-options');const _0x4eec2f=xe['get'](_0x1b2a8f);if(_0x4eec2f){if(Me(_0x44bc60,_0x4eec2f['options'])&&Me(_0x578cc0,_0x4eec2f['config']))return _0x4eec2f;throw ge['create']('duplicate-app',{'appName':_0x1b2a8f});}const _0x1e7fb1=new Pc(_0x1b2a8f);for(const _0x447cb5 of mi['values']())_0x1e7fb1['addComponent'](_0x447cb5);const _0x3845f2=new Tl(_0x44bc60,_0x578cc0,_0x1e7fb1);return xe['set'](_0x1b2a8f,_0x3845f2),_0x3845f2;}function Zr(_0x45a471=_i){const _0x43af4f=xe['get'](_0x45a471);if(!_0x43af4f&&_0x45a471===_i&&qr())return Sl();if(!_0x43af4f)throw ge['create']('no-app',{'appName':_0x45a471});return _0x43af4f;}function f_(){return Array['from'](xe['values']());}async function p_(_0x26ed64){let _0x1bb4a0=!0x1;const _0x56d170=_0x26ed64['name'];xe['has'](_0x56d170)?(_0x1bb4a0=!0x0,xe['delete'](_0x56d170)):gi['has'](_0x56d170)&&_0x26ed64['decRefCount']()<=0x0&&(gi['delete'](_0x56d170),_0x1bb4a0=!0x0),_0x1bb4a0&&(await Promise['all'](_0x26ed64['container']['getProviders']()['map'](_0x441f79=>_0x441f79['delete']())),_0x26ed64['isDeleted']=!0x0);}function me(_0x332095,_0x545a9d,_0x2afc96){let _0x402d9b=wl[_0x332095]??_0x332095;_0x2afc96&&(_0x402d9b+='-'+_0x2afc96);const _0x1ad571=_0x402d9b['match'](/\s|\//),_0x263197=_0x545a9d['match'](/\s|\//);if(_0x1ad571||_0x263197){const _0x466c29=['Unable\x20to\x20register\x20library\x20\x22'+_0x402d9b+'\x22\x20with\x20version\x20\x22'+_0x545a9d+'\x22:'];_0x1ad571&&_0x466c29['push']('library\x20name\x20\x22'+_0x402d9b+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x1ad571&&_0x263197&&_0x466c29['push']('and'),_0x263197&&_0x466c29['push']('version\x20name\x20\x22'+_0x545a9d+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x466c29['join']('\x20'));return;}Ze(new Le(_0x402d9b+'-version',()=>({'library':_0x402d9b,'version':_0x545a9d}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x588345,_0x189dd0)=>{switch(_0x189dd0){case 0x0:try{_0x588345['createObjectStore'](kt);}catch(_0x168ee3){console['warn'](_0x168ee3);}}}})['catch'](_0x32284c=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x32284c['message']});})),ti;}async function Al(_0x184fb4){try{const _0x3e621b=(await eo())['transaction'](kt),_0x5d24a3=await _0x3e621b['objectStore'](kt)['get'](to(_0x184fb4));return await _0x3e621b['done'],_0x5d24a3;}catch(_0x3bb3ed){if(_0x3bb3ed instanceof Se)oe['warn'](_0x3bb3ed['message']);else{const _0x59711d=ge['create']('idb-get',{'originalErrorMessage':_0x3bb3ed==null?void 0x0:_0x3bb3ed['message']});oe['warn'](_0x59711d['message']);}}}async function Us(_0x2bd6c0,_0x24b48f){try{const _0x39ce9a=(await eo())['transaction'](kt,'readwrite');await _0x39ce9a['objectStore'](kt)['put'](_0x24b48f,to(_0x2bd6c0)),await _0x39ce9a['done'];}catch(_0x730a27){if(_0x730a27 instanceof Se)oe['warn'](_0x730a27['message']);else{const _0x951683=ge['create']('idb-set',{'originalErrorMessage':_0x730a27==null?void 0x0:_0x730a27['message']});oe['warn'](_0x951683['message']);}}}function to(_0x5be713){return _0x5be713['name']+'!'+_0x5be713['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x28bb63){this['container']=_0x28bb63,this['_heartbeatsCache']=null;const _0x18f655=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x18f655),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x1f22d2=>(this['_heartbeatsCache']=_0x1f22d2,_0x1f22d2));}async['triggerHeartbeat'](){var _0x2300fd,_0x50aab5;try{const _0x277e16=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x46ed20=Ws();if(((_0x2300fd=this['_heartbeatsCache'])==null?void 0x0:_0x2300fd['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x50aab5=this['_heartbeatsCache'])==null?void 0x0:_0x50aab5['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x46ed20||this['_heartbeatsCache']['heartbeats']['some'](_0x42882f=>_0x42882f['date']===_0x46ed20))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x46ed20,'agent':_0x277e16}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x49c372=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x49c372,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x2d9e4f){oe['warn'](_0x2d9e4f);}}async['getHeartbeatsHeader'](){var _0x505f1f;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x505f1f=this['_heartbeatsCache'])==null?void 0x0:_0x505f1f['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x714a3f=Ws(),{heartbeatsToSend:_0x38dd4a,unsentEntries:_0x50de50}=Ol(this['_heartbeatsCache']['heartbeats']),_0x4b0d7b=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x38dd4a}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x714a3f,_0x50de50['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x50de50,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x4b0d7b;}catch(_0x35695b){return oe['warn'](_0x35695b),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x43aafe,_0x460f0c=kl){const _0x1b263e=[];let _0x441d9f=_0x43aafe['slice']();for(const _0x5b7278 of _0x43aafe){const _0x56cbda=_0x1b263e['find'](_0x3c0a5c=>_0x3c0a5c['agent']===_0x5b7278['agent']);if(_0x56cbda){if(_0x56cbda['dates']['push'](_0x5b7278['date']),Bs(_0x1b263e)>_0x460f0c){_0x56cbda['dates']['pop']();break;}}else{if(_0x1b263e['push']({'agent':_0x5b7278['agent'],'dates':[_0x5b7278['date']]}),Bs(_0x1b263e)>_0x460f0c){_0x1b263e['pop']();break;}}_0x441d9f=_0x441d9f['slice'](0x1);}return{'heartbeatsToSend':_0x1b263e,'unsentEntries':_0x441d9f};}class Dl{constructor(_0x4d60fc){this['app']=_0x4d60fc,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x375851=await Al(this['app']);return _0x375851!=null&&_0x375851['heartbeats']?_0x375851:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x4fc94c){if(await this['_canUseIndexedDBPromise']){const _0x10646a=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x4fc94c['lastSentHeartbeatDate']??_0x10646a['lastSentHeartbeatDate'],'heartbeats':_0x4fc94c['heartbeats']});}else return;}async['add'](_0x41d69f){if(await this['_canUseIndexedDBPromise']){const _0x27f157=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x41d69f['lastSentHeartbeatDate']??_0x27f157['lastSentHeartbeatDate'],'heartbeats':[..._0x27f157['heartbeats'],..._0x41d69f['heartbeats']]});}else return;}}function Bs(_0x33c929){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x33c929}))['length'];}function Ml(_0x59d233){if(_0x59d233['length']===0x0)return-0x1;let _0x31e79b=0x0,_0x543bd0=_0x59d233[0x0]['date'];for(let _0x5e95f9=0x1;_0x5e95f9<_0x59d233['length'];_0x5e95f9++)_0x59d233[_0x5e95f9]['date']<_0x543bd0&&(_0x543bd0=_0x59d233[_0x5e95f9]['date'],_0x31e79b=_0x5e95f9);return _0x31e79b;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x1a4d73){Ze(new Le('platform-logger',_0x2c24a1=>new jc(_0x2c24a1),'PRIVATE')),Ze(new Le('heartbeat',_0x593800=>new Pl(_0x593800),'PRIVATE')),me(pi,xs,_0x1a4d73),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0xd51766){no=_0xd51766;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x3852a8){this['domStorage_']=_0x3852a8,this['prefix_']='firebase:';}['set'](_0x556f72,_0x2e27f1){_0x2e27f1==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x556f72)):this['domStorage_']['setItem'](this['prefixedName_'](_0x556f72),O(_0x2e27f1));}['get'](_0x3bac8e){const _0x55f8d1=this['domStorage_']['getItem'](this['prefixedName_'](_0x3bac8e));return _0x55f8d1==null?null:At(_0x55f8d1);}['remove'](_0x21b478){this['domStorage_']['removeItem'](this['prefixedName_'](_0x21b478));}['prefixedName_'](_0x2c7659){return this['prefix_']+_0x2c7659;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x3a6c57,_0x414865){_0x414865==null?delete this['cache_'][_0x3a6c57]:this['cache_'][_0x3a6c57]=_0x414865;}['get'](_0x49d62b){return J(this['cache_'],_0x49d62b)?this['cache_'][_0x49d62b]:null;}['remove'](_0x142537){delete this['cache_'][_0x142537];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x322200){try{if(typeof window<'u'&&typeof window[_0x322200]<'u'){const _0x2b3a4a=window[_0x322200];return _0x2b3a4a['setItem']('firebase:sentinel','cache'),_0x2b3a4a['removeItem']('firebase:sentinel'),new Wl(_0x2b3a4a);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x2e3bd0=0x1;return function(){return _0x2e3bd0++;};}()),ro=function(_0x3b58f2){const _0x3f7c35=Rc(_0x3b58f2),_0x34972d=new Cc();_0x34972d['update'](_0x3f7c35);const _0x2186b3=_0x34972d['digest']();return Li['encodeByteArray'](_0x2186b3);},Vt=function(..._0x1343e7){let _0x2e2748='';for(let _0x170045=0x0;_0x170045<_0x1343e7['length'];_0x170045++){const _0x46bba1=_0x1343e7[_0x170045];Array['isArray'](_0x46bba1)||_0x46bba1&&typeof _0x46bba1=='object'&&typeof _0x46bba1['length']=='number'?_0x2e2748+=Vt['apply'](null,_0x46bba1):typeof _0x46bba1=='object'?_0x2e2748+=O(_0x46bba1):_0x2e2748+=_0x46bba1,_0x2e2748+='\x20';}return _0x2e2748;};let wt=null,Gs=!0x0;const Hl=function(_0x14896f,_0x112b7e){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x8debe){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x4df58b=Vt['apply'](null,_0x8debe);wt(_0x4df58b);}},Ht=function(_0x187045){return function(..._0x3b49cb){L(_0x187045,..._0x3b49cb);};},yi=function(..._0x151f1c){const _0x173d02='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x151f1c);Ye['error'](_0x173d02);},ae=function(..._0x548014){const _0x37ade6='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x548014);throw Ye['error'](_0x37ade6),new Error(_0x37ade6);},U=function(..._0x3df8cb){const _0x542b56='FIREBASE\x20WARNING:\x20'+Vt(..._0x3df8cb);Ye['warn'](_0x542b56);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x2aa1a4){return typeof _0x2aa1a4=='number'&&(_0x2aa1a4!==_0x2aa1a4||_0x2aa1a4===Number['POSITIVE_INFINITY']||_0x2aa1a4===Number['NEGATIVE_INFINITY']);},Gl=function(_0x5e8496){if(document['readyState']==='complete')_0x5e8496();else{let _0x16859a=!0x1;const _0x167825=function(){if(!document['body']){setTimeout(_0x167825,Math['floor'](0xa));return;}_0x16859a||(_0x16859a=!0x0,_0x5e8496());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x167825,!0x1),window['addEventListener']('load',_0x167825,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x167825();}),window['attachEvent']('onload',_0x167825));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0xaca6e6,_0x4a3c79){if(_0xaca6e6===_0x4a3c79)return 0x0;if(_0xaca6e6===Fe||_0x4a3c79===Ie)return-0x1;if(_0x4a3c79===Fe||_0xaca6e6===Ie)return 0x1;{const _0x16f336=qs(_0xaca6e6),_0x1a8398=qs(_0x4a3c79);return _0x16f336!==null?_0x1a8398!==null?_0x16f336-_0x1a8398===0x0?_0xaca6e6['length']-_0x4a3c79['length']:_0x16f336-_0x1a8398:-0x1:_0x1a8398!==null?0x1:_0xaca6e6<_0x4a3c79?-0x1:0x1;}},ql=function(_0x2e636e,_0xd2322c){return _0x2e636e===_0xd2322c?0x0:_0x2e636e<_0xd2322c?-0x1:0x1;},_t=function(_0x3f58a3,_0x388eb5){if(_0x388eb5&&_0x3f58a3 in _0x388eb5)return _0x388eb5[_0x3f58a3];throw new Error('Missing\x20required\x20key\x20('+_0x3f58a3+')\x20in\x20object:\x20'+O(_0x388eb5));},Hi=function(_0x978c68){if(typeof _0x978c68!='object'||_0x978c68===null)return O(_0x978c68);const _0x536dd5=[];for(const _0x31d7d6 in _0x978c68)_0x536dd5['push'](_0x31d7d6);_0x536dd5['sort']();let _0x977e34='{';for(let _0x40304e=0x0;_0x40304e<_0x536dd5['length'];_0x40304e++)_0x40304e!==0x0&&(_0x977e34+=','),_0x977e34+=O(_0x536dd5[_0x40304e]),_0x977e34+=':',_0x977e34+=Hi(_0x978c68[_0x536dd5[_0x40304e]]);return _0x977e34+='}',_0x977e34;},oo=function(_0x2a1d6e,_0x15ebd6){const _0x23af4d=_0x2a1d6e['length'];if(_0x23af4d<=_0x15ebd6)return[_0x2a1d6e];const _0x57fd36=[];for(let _0x3004c7=0x0;_0x3004c7<_0x23af4d;_0x3004c7+=_0x15ebd6)_0x3004c7+_0x15ebd6>_0x23af4d?_0x57fd36['push'](_0x2a1d6e['substring'](_0x3004c7,_0x23af4d)):_0x57fd36['push'](_0x2a1d6e['substring'](_0x3004c7,_0x3004c7+_0x15ebd6));return _0x57fd36;};function x(_0x3bc842,_0x1c3924){for(const _0x18d220 in _0x3bc842)_0x3bc842['hasOwnProperty'](_0x18d220)&&_0x1c3924(_0x18d220,_0x3bc842[_0x18d220]);}const ao=function(_0x5386aa){f(!Vi(_0x5386aa),'Invalid\x20JSON\x20number');const _0x3cde4c=0xb,_0x38860f=0x34,_0x157e8e=(0x1<<_0x3cde4c-0x1)-0x1;let _0xeb519,_0x46e3d4,_0x230def,_0x3c8a2a,_0x295a76;_0x5386aa===0x0?(_0x46e3d4=0x0,_0x230def=0x0,_0xeb519=0x1/_0x5386aa===-0x1/0x0?0x1:0x0):(_0xeb519=_0x5386aa<0x0,_0x5386aa=Math['abs'](_0x5386aa),_0x5386aa>=Math['pow'](0x2,0x1-_0x157e8e)?(_0x3c8a2a=Math['min'](Math['floor'](Math['log'](_0x5386aa)/Math['LN2']),_0x157e8e),_0x46e3d4=_0x3c8a2a+_0x157e8e,_0x230def=Math['round'](_0x5386aa*Math['pow'](0x2,_0x38860f-_0x3c8a2a)-Math['pow'](0x2,_0x38860f))):(_0x46e3d4=0x0,_0x230def=Math['round'](_0x5386aa/Math['pow'](0x2,0x1-_0x157e8e-_0x38860f))));const _0x2503a7=[];for(_0x295a76=_0x38860f;_0x295a76;_0x295a76-=0x1)_0x2503a7['push'](_0x230def%0x2?0x1:0x0),_0x230def=Math['floor'](_0x230def/0x2);for(_0x295a76=_0x3cde4c;_0x295a76;_0x295a76-=0x1)_0x2503a7['push'](_0x46e3d4%0x2?0x1:0x0),_0x46e3d4=Math['floor'](_0x46e3d4/0x2);_0x2503a7['push'](_0xeb519?0x1:0x0),_0x2503a7['reverse']();const _0x490e63=_0x2503a7['join']('');let _0xdddeaf='';for(_0x295a76=0x0;_0x295a76<0x40;_0x295a76+=0x8){let _0x5a7a3a=parseInt(_0x490e63['substr'](_0x295a76,0x8),0x2)['toString'](0x10);_0x5a7a3a['length']===0x1&&(_0x5a7a3a='0'+_0x5a7a3a),_0xdddeaf=_0xdddeaf+_0x5a7a3a;}return _0xdddeaf['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x3046f3,_0x206c93){let _0x3b2b6e='Unknown\x20Error';_0x3046f3==='too_big'?_0x3b2b6e='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x3046f3==='permission_denied'?_0x3b2b6e='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x3046f3==='unavailable'&&(_0x3b2b6e='The\x20service\x20is\x20unavailable');const _0x2b625f=new Error(_0x3046f3+'\x20at\x20'+_0x206c93['_path']['toString']()+':\x20'+_0x3b2b6e);return _0x2b625f['code']=_0x3046f3['toUpperCase'](),_0x2b625f;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x1f202f){if(Yl['test'](_0x1f202f)){const _0x5836a3=Number(_0x1f202f);if(_0x5836a3>=Ql&&_0x5836a3<=Jl)return _0x5836a3;}return null;},ht=function(_0x4534b8){try{_0x4534b8();}catch(_0x247e3f){setTimeout(()=>{const _0xa33f0b=_0x247e3f['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0xa33f0b),_0x247e3f;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x2f847b,_0x4287a3){const _0x10e076=setTimeout(_0x2f847b,_0x4287a3);return typeof _0x10e076=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x10e076):typeof _0x10e076=='object'&&_0x10e076['unref']&&_0x10e076['unref'](),_0x10e076;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x9c0e50,_0x4f26a0){this['appCheckProvider']=_0x4f26a0,this['appName']=_0x9c0e50['name'],$(_0x9c0e50)&&_0x9c0e50['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x9c0e50['settings']['appCheckToken']),this['appCheck']=_0x4f26a0==null?void 0x0:_0x4f26a0['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4f26a0==null||_0x4f26a0['get']()['then'](_0x350c9b=>this['appCheck']=_0x350c9b);}['getToken'](_0x307402){if(this['serverAppAppCheckToken']){if(_0x307402)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x307402):new Promise((_0x2cef61,_0x4b9ec5)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x307402)['then'](_0x2cef61,_0x4b9ec5):_0x2cef61(null);},0x0);});}['addTokenChangeListener'](_0x2aa529){var _0x1a6976;(_0x1a6976=this['appCheckProvider'])==null||_0x1a6976['get']()['then'](_0xb63fa4=>_0xb63fa4['addTokenListener'](_0x2aa529));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x447c90,_0x492557,_0x5eb104){this['appName_']=_0x447c90,this['firebaseOptions_']=_0x492557,this['authProvider_']=_0x5eb104,this['auth_']=null,this['auth_']=_0x5eb104['getImmediate']({'optional':!0x0}),this['auth_']||_0x5eb104['onInit'](_0x2c7eba=>this['auth_']=_0x2c7eba);}['getToken'](_0xfce27a){return this['auth_']?this['auth_']['getToken'](_0xfce27a)['catch'](_0x2a6629=>_0x2a6629&&_0x2a6629['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x2a6629)):new Promise((_0x1ee76e,_0x14c089)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0xfce27a)['then'](_0x1ee76e,_0x14c089):_0x1ee76e(null);},0x0);});}['addTokenChangeListener'](_0x3dd3d9){this['auth_']?this['auth_']['addAuthTokenListener'](_0x3dd3d9):this['authProvider_']['get']()['then'](_0x58f00a=>_0x58f00a['addAuthTokenListener'](_0x3dd3d9));}['removeTokenChangeListener'](_0x1997e3){this['authProvider_']['get']()['then'](_0x4a8023=>_0x4a8023['removeAuthTokenListener'](_0x1997e3));}['notifyForInvalidToken'](){let _0x343ddc='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x343ddc+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x343ddc+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x343ddc+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x343ddc);}}class nn{constructor(_0x240031){this['accessToken']=_0x240031;}['getToken'](_0x2351ac){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x354d8c){_0x354d8c(this['accessToken']);}['removeTokenChangeListener'](_0x460021){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x157093,_0x2485a3,_0x44e14e,_0x122ad4,_0x1e6756=!0x1,_0x405f63='',_0x5e0bb7=!0x1,_0x52eb4d=!0x1,_0x4c5e2d=null){this['secure']=_0x2485a3,this['namespace']=_0x44e14e,this['webSocketOnly']=_0x122ad4,this['nodeAdmin']=_0x1e6756,this['persistenceKey']=_0x405f63,this['includeNamespaceInQueryParams']=_0x5e0bb7,this['isUsingEmulator']=_0x52eb4d,this['emulatorOptions']=_0x4c5e2d,this['_host']=_0x157093['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x157093)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x2ed737){_0x2ed737!==this['internalHost']&&(this['internalHost']=_0x2ed737,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x45405d=this['toURLString']();return this['persistenceKey']&&(_0x45405d+='<'+this['persistenceKey']+'>'),_0x45405d;}['toURLString'](){const _0x3cd66c=this['secure']?'https://':'http://',_0x28527a=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x3cd66c+this['host']+'/'+_0x28527a;}}function th(_0x3e49ac){return _0x3e49ac['host']!==_0x3e49ac['internalHost']||_0x3e49ac['isCustomHost']()||_0x3e49ac['includeNamespaceInQueryParams'];}function vo(_0x4dc288,_0x3c033c,_0x47f397){f(typeof _0x3c033c=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x47f397=='object','typeof\x20params\x20must\x20==\x20object');let _0xce1afc;if(_0x3c033c===go)_0xce1afc=(_0x4dc288['secure']?'wss://':'ws://')+_0x4dc288['internalHost']+'/.ws?';else{if(_0x3c033c===mo)_0xce1afc=(_0x4dc288['secure']?'https://':'http://')+_0x4dc288['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x3c033c);}th(_0x4dc288)&&(_0x47f397['ns']=_0x4dc288['namespace']);const _0x1d9413=[];return x(_0x47f397,(_0x47ad4d,_0x18a82b)=>{_0x1d9413['push'](_0x47ad4d+'='+_0x18a82b);}),_0xce1afc+_0x1d9413['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x369373,_0x82ee45=0x1){J(this['counters_'],_0x369373)||(this['counters_'][_0x369373]=0x0),this['counters_'][_0x369373]+=_0x82ee45;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x2fedca){const _0x8c0f0a=_0x2fedca['toString']();return ni[_0x8c0f0a]||(ni[_0x8c0f0a]=new nh()),ni[_0x8c0f0a];}function ih(_0x4da5d3,_0x5b8454){const _0x24e60b=_0x4da5d3['toString']();return ii[_0x24e60b]||(ii[_0x24e60b]=_0x5b8454()),ii[_0x24e60b];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x2305c1){this['onMessage_']=_0x2305c1,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x14112f,_0x3d577e){this['closeAfterResponse']=_0x14112f,this['onClose']=_0x3d577e,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x22cbe7,_0x3533f3){for(this['pendingResponses'][_0x22cbe7]=_0x3533f3;this['pendingResponses'][this['currentResponseNum']];){const _0x57635d=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x1f78af=0x0;_0x1f78af<_0x57635d['length'];++_0x1f78af)_0x57635d[_0x1f78af]&&ht(()=>{this['onMessage_'](_0x57635d[_0x1f78af]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x17b2f3,_0x44c7b0,_0xdcaf78,_0xb1c2ff,_0x312c7a,_0x1f6964,_0x197798){this['connId']=_0x17b2f3,this['repoInfo']=_0x44c7b0,this['applicationId']=_0xdcaf78,this['appCheckToken']=_0xb1c2ff,this['authToken']=_0x312c7a,this['transportSessionId']=_0x1f6964,this['lastSessionId']=_0x197798,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x17b2f3),this['stats_']=Gi(_0x44c7b0),this['urlFn']=_0x48879d=>(this['appCheckToken']&&(_0x48879d[vi]=this['appCheckToken']),vo(_0x44c7b0,mo,_0x48879d));}['open'](_0x123a12,_0x5388d1){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x5388d1,this['myPacketOrderer']=new sh(_0x123a12),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x22fda3)=>{const [_0x56ecfc,_0x405676,_0xd81710,_0x3e9fed,_0x55c89c]=_0x22fda3;if(this['incrementIncomingBytes_'](_0x22fda3),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x56ecfc===zs)this['id']=_0x405676,this['password']=_0xd81710;else{if(_0x56ecfc===rh)_0x405676?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x405676,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x56ecfc);}}},(..._0x3d622e)=>{const [_0x47f33c,_0x259055]=_0x3d622e;this['incrementIncomingBytes_'](_0x3d622e),this['myPacketOrderer']['handleResponse'](_0x47f33c,_0x259055);},()=>{this['onClosed_']();},this['urlFn']);const _0x56acd8={};_0x56acd8[zs]='t',_0x56acd8[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x56acd8[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x56acd8[co]=$i,this['transportSessionId']&&(_0x56acd8[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x56acd8[po]=this['lastSessionId']),this['applicationId']&&(_0x56acd8[_o]=this['applicationId']),this['appCheckToken']&&(_0x56acd8[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x56acd8[ho]=uo);const _0x221180=this['urlFn'](_0x56acd8);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x221180),this['scriptTagHolder']['addTag'](_0x221180,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x41af46){const _0x2ed22a=O(_0x41af46);this['bytesSent']+=_0x2ed22a['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2ed22a['length']);const _0x271910=Hr(_0x2ed22a),_0xdc1a42=oo(_0x271910,fh);for(let _0x1991ac=0x0;_0x1991ac<_0xdc1a42['length'];_0x1991ac++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0xdc1a42['length'],_0xdc1a42[_0x1991ac]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x14278c,_0x3d3157){this['myDisconnFrame']=document['createElement']('iframe');const _0x3df205={};_0x3df205[dh]='t',_0x3df205[Eo]=_0x14278c,_0x3df205[Io]=_0x3d3157,this['myDisconnFrame']['src']=this['urlFn'](_0x3df205),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x4633a7){const _0x2c7ff5=O(_0x4633a7)['length'];this['bytesReceived']+=_0x2c7ff5,this['stats_']['incrementCounter']('bytes_received',_0x2c7ff5);}}class qi{constructor(_0x37f3ca,_0x428497,_0x4ff1a9,_0x4f34cd){this['onDisconnect']=_0x4ff1a9,this['urlFn']=_0x4f34cd,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x37f3ca,window[ah+this['uniqueCallbackIdentifier']]=_0x428497,this['myIFrame']=qi['createIFrame_']();let _0x8993b6='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x8993b6='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x140c26='<html><body>'+_0x8993b6+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x140c26),this['myIFrame']['doc']['close']();}catch(_0x3f6c4b){L('frame\x20writing\x20exception'),_0x3f6c4b['stack']&&L(_0x3f6c4b['stack']),L(_0x3f6c4b);}}}static['createIFrame_'](){const _0x3fd46a=document['createElement']('iframe');if(_0x3fd46a['style']['display']='none',document['body']){document['body']['appendChild'](_0x3fd46a);try{_0x3fd46a['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x3bd3ee=document['domain'];_0x3fd46a['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x3bd3ee+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x3fd46a['contentDocument']?_0x3fd46a['doc']=_0x3fd46a['contentDocument']:_0x3fd46a['contentWindow']?_0x3fd46a['doc']=_0x3fd46a['contentWindow']['document']:_0x3fd46a['document']&&(_0x3fd46a['doc']=_0x3fd46a['document']),_0x3fd46a;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x961563=this['onDisconnect'];_0x961563&&(this['onDisconnect']=null,_0x961563());}['startLongPoll'](_0x43bf94,_0x9924c1){for(this['myID']=_0x43bf94,this['myPW']=_0x9924c1,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x4c2f7e={};_0x4c2f7e[Eo]=this['myID'],_0x4c2f7e[Io]=this['myPW'],_0x4c2f7e[wo]=this['currentSerial'];let _0xf0c905=this['urlFn'](_0x4c2f7e),_0x1c8111='',_0x939b19=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x1c8111['length']<=Co;){const _0x5a2246=this['pendingSegs']['shift']();_0x1c8111=_0x1c8111+'&'+lh+_0x939b19+'='+_0x5a2246['seg']+'&'+hh+_0x939b19+'='+_0x5a2246['ts']+'&'+uh+_0x939b19+'='+_0x5a2246['d'],_0x939b19++;}return _0xf0c905=_0xf0c905+_0x1c8111,this['addLongPollTag_'](_0xf0c905,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x24c567,_0x236476,_0xb55fbc){this['pendingSegs']['push']({'seg':_0x24c567,'ts':_0x236476,'d':_0xb55fbc}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x3e01cc,_0x3e1daf){this['outstandingRequests']['add'](_0x3e1daf);const _0x3988a8=()=>{this['outstandingRequests']['delete'](_0x3e1daf),this['newRequest_']();},_0x3bb852=setTimeout(_0x3988a8,Math['floor'](ph)),_0x2c6d09=()=>{clearTimeout(_0x3bb852),_0x3988a8();};this['addTag'](_0x3e01cc,_0x2c6d09);}['addTag'](_0x3ef653,_0x45c5a9){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x70d1a8=this['myIFrame']['doc']['createElement']('script');_0x70d1a8['type']='text/javascript',_0x70d1a8['async']=!0x0,_0x70d1a8['src']=_0x3ef653,_0x70d1a8['onload']=_0x70d1a8['onreadystatechange']=function(){const _0x1a386b=_0x70d1a8['readyState'];(!_0x1a386b||_0x1a386b==='loaded'||_0x1a386b==='complete')&&(_0x70d1a8['onload']=_0x70d1a8['onreadystatechange']=null,_0x70d1a8['parentNode']&&_0x70d1a8['parentNode']['removeChild'](_0x70d1a8),_0x45c5a9());},_0x70d1a8['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x3ef653),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x70d1a8);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x14b75e,_0x2aece3,_0x7a66d2,_0x23427c,_0x2d3434,_0xf35f52,_0x12daf4){this['connId']=_0x14b75e,this['applicationId']=_0x7a66d2,this['appCheckToken']=_0x23427c,this['authToken']=_0x2d3434,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x2aece3),this['connURL']=z['connectionURL_'](_0x2aece3,_0xf35f52,_0x12daf4,_0x23427c,_0x7a66d2),this['nodeAdmin']=_0x2aece3['nodeAdmin'];}static['connectionURL_'](_0x5ee24f,_0x38ef1d,_0x147551,_0x24f86d,_0x3c2f82){const _0x268f27={};return _0x268f27[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x268f27[ho]=uo),_0x38ef1d&&(_0x268f27[lo]=_0x38ef1d),_0x147551&&(_0x268f27[po]=_0x147551),_0x24f86d&&(_0x268f27[vi]=_0x24f86d),_0x3c2f82&&(_0x268f27[_o]=_0x3c2f82),vo(_0x5ee24f,go,_0x268f27);}['open'](_0x12a2c1,_0x9c24f2){this['onDisconnect']=_0x9c24f2,this['onMessage']=_0x12a2c1,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x23c674;_c(),this['mySock']=new un(this['connURL'],[],_0x23c674);}catch(_0x5f28a6){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x577603=_0x5f28a6['message']||_0x5f28a6['data'];_0x577603&&this['log_'](_0x577603),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x2594dd=>{this['handleIncomingFrame'](_0x2594dd);},this['mySock']['onerror']=_0x29391f=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x1306dc=_0x29391f['message']||_0x29391f['data'];_0x1306dc&&this['log_'](_0x1306dc),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x270062=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x1c26ad=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x35b495=navigator['userAgent']['match'](_0x1c26ad);_0x35b495&&_0x35b495['length']>0x1&&parseFloat(_0x35b495[0x1])<4.4&&(_0x270062=!0x0);}return!_0x270062&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x3b77a7){if(this['frames']['push'](_0x3b77a7),this['frames']['length']===this['totalFrames']){const _0x574b39=this['frames']['join']('');this['frames']=null;const _0x3feee7=At(_0x574b39);this['onMessage'](_0x3feee7);}}['handleNewFrameCount_'](_0x169d49){this['totalFrames']=_0x169d49,this['frames']=[];}['extractFrameCount_'](_0x52e1ba){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x52e1ba['length']<=0x6){const _0x2ffb57=Number(_0x52e1ba);if(!isNaN(_0x2ffb57))return this['handleNewFrameCount_'](_0x2ffb57),null;}return this['handleNewFrameCount_'](0x1),_0x52e1ba;}['handleIncomingFrame'](_0xbabdcb){if(this['mySock']===null)return;const _0x2041ce=_0xbabdcb['data'];if(this['bytesReceived']+=_0x2041ce['length'],this['stats_']['incrementCounter']('bytes_received',_0x2041ce['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x2041ce);else{const _0x3c41f1=this['extractFrameCount_'](_0x2041ce);_0x3c41f1!==null&&this['appendFrame_'](_0x3c41f1);}}['send'](_0x7b177b){this['resetKeepAlive']();const _0x1315d7=O(_0x7b177b);this['bytesSent']+=_0x1315d7['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1315d7['length']);const _0x5aaca1=oo(_0x1315d7,gh);_0x5aaca1['length']>0x1&&this['sendString_'](String(_0x5aaca1['length']));for(let _0x292b5a=0x0;_0x292b5a<_0x5aaca1['length'];_0x292b5a++)this['sendString_'](_0x5aaca1[_0x292b5a]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x3888a9){try{this['mySock']['send'](_0x3888a9);}catch(_0x3e144d){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x3e144d['message']||_0x3e144d['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x417d38){this['initTransports_'](_0x417d38);}['initTransports_'](_0x4b4f14){const _0x1e2252=z&&z['isAvailable']();let _0x3290a5=_0x1e2252&&!z['previouslyFailed']();if(_0x4b4f14['webSocketOnly']&&(_0x1e2252||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x3290a5=!0x0),_0x3290a5)this['transports_']=[z];else{const _0x59f0e7=this['transports_']=[];for(const _0x5e22fe of Nt['ALL_TRANSPORTS'])_0x5e22fe&&_0x5e22fe['isAvailable']()&&_0x59f0e7['push'](_0x5e22fe);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x4e39cf,_0xdd7224,_0x57e171,_0x5d81d6,_0xc84cb3,_0x1563ef,_0x5721e0,_0x487d32,_0x1dce00,_0x32b721){this['id']=_0x4e39cf,this['repoInfo_']=_0xdd7224,this['applicationId_']=_0x57e171,this['appCheckToken_']=_0x5d81d6,this['authToken_']=_0xc84cb3,this['onMessage_']=_0x1563ef,this['onReady_']=_0x5721e0,this['onDisconnect_']=_0x487d32,this['onKill_']=_0x1dce00,this['lastSessionId']=_0x32b721,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0xdd7224),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x365668=this['transportManager_']['initialTransport']();this['conn_']=new _0x365668(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x365668['responsesRequiredToBeHealthy']||0x0;const _0x18a855=this['connReceiver_'](this['conn_']),_0xbe48e9=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x18a855,_0xbe48e9);},Math['floor'](0x0));const _0x469436=_0x365668['healthyTimeout']||0x0;_0x469436>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x469436)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x29a48a){return _0xe195=>{_0x29a48a===this['conn_']?this['onConnectionLost_'](_0xe195):_0x29a48a===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x2077c4){return _0x2c0f53=>{this['state_']!==0x2&&(_0x2077c4===this['rx_']?this['onPrimaryMessageReceived_'](_0x2c0f53):_0x2077c4===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x2c0f53):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x2208ed){const _0x649187={'t':'d','d':_0x2208ed};this['sendData_'](_0x649187);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x4a65c3){if(si in _0x4a65c3){const _0x585830=_0x4a65c3[si];_0x585830===Qs?this['upgradeIfSecondaryHealthy_']():_0x585830===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x585830===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x35baa6){const _0x6ce015=_t('t',_0x35baa6),_0x500b01=_t('d',_0x35baa6);if(_0x6ce015==='c')this['onSecondaryControl_'](_0x500b01);else{if(_0x6ce015==='d')this['pendingDataMessages']['push'](_0x500b01);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x6ce015);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x303dec){const _0x1da4eb=_t('t',_0x303dec),_0x5a068c=_t('d',_0x303dec);_0x1da4eb==='c'?this['onControl_'](_0x5a068c):_0x1da4eb==='d'&&this['onDataMessage_'](_0x5a068c);}['onDataMessage_'](_0x261488){this['onPrimaryResponse_'](),this['onMessage_'](_0x261488);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x3cc88d){const _0x538b01=_t(si,_0x3cc88d);if(js in _0x3cc88d){const _0x18e2c8=_0x3cc88d[js];if(_0x538b01===Th){const _0x5bdc56={..._0x18e2c8};this['repoInfo_']['isUsingEmulator']&&(_0x5bdc56['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x5bdc56);}else{if(_0x538b01===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x528b2c=0x0;_0x528b2c<this['pendingDataMessages']['length'];++_0x528b2c)this['onDataMessage_'](this['pendingDataMessages'][_0x528b2c]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x538b01===wh?this['onConnectionShutdown_'](_0x18e2c8):_0x538b01===Ks?this['onReset_'](_0x18e2c8):_0x538b01===Ch?yi('Server\x20Error:\x20'+_0x18e2c8):_0x538b01===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x538b01);}}}['onHandshake_'](_0xd41160){const _0x3b084b=_0xd41160['ts'],_0x23cdac=_0xd41160['v'],_0x42aa5a=_0xd41160['h'];this['sessionId']=_0xd41160['s'],this['repoInfo_']['host']=_0x42aa5a,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x3b084b),$i!==_0x23cdac&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x2079be=this['transportManager_']['upgradeTransport']();_0x2079be&&this['startUpgrade_'](_0x2079be);}['startUpgrade_'](_0x52d672){this['secondaryConn_']=new _0x52d672(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x52d672['responsesRequiredToBeHealthy']||0x0;const _0x39f3ae=this['connReceiver_'](this['secondaryConn_']),_0x662f29=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x39f3ae,_0x662f29),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x39ee2e){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x39ee2e),this['repoInfo_']['host']=_0x39ee2e,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x21f257,_0x19814c){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x21f257,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x19814c,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x222322=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x222322||this['rx_']===_0x222322)&&this['close']();}['onConnectionLost_'](_0x3f85ca){this['conn_']=null,!_0x3f85ca&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x25e93d){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x25e93d),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0xe462c9){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0xe462c9);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x4adee8,_0x51dd17,_0x7d0b6d,_0x5419e1){}['merge'](_0x19a1dc,_0xa064da,_0x40c65e,_0x4732da){}['refreshAuthToken'](_0xfbb0a9){}['refreshAppCheckToken'](_0x550653){}['onDisconnectPut'](_0x134705,_0x430918,_0x376724){}['onDisconnectMerge'](_0x3d1fd,_0x482ada,_0x46b293){}['onDisconnectCancel'](_0x5415e1,_0x483808){}['reportStats'](_0x4a7636){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x10d00c){this['allowedEvents_']=_0x10d00c,this['listeners_']={},f(Array['isArray'](_0x10d00c)&&_0x10d00c['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x13acbb,..._0x40db40){if(Array['isArray'](this['listeners_'][_0x13acbb])){const _0x33c320=[...this['listeners_'][_0x13acbb]];for(let _0x442d26=0x0;_0x442d26<_0x33c320['length'];_0x442d26++)_0x33c320[_0x442d26]['callback']['apply'](_0x33c320[_0x442d26]['context'],_0x40db40);}}['on'](_0x435449,_0x35873b,_0x3f6275){this['validateEventType_'](_0x435449),this['listeners_'][_0x435449]=this['listeners_'][_0x435449]||[],this['listeners_'][_0x435449]['push']({'callback':_0x35873b,'context':_0x3f6275});const _0x152e22=this['getInitialEvent'](_0x435449);_0x152e22&&_0x35873b['apply'](_0x3f6275,_0x152e22);}['off'](_0x463e61,_0x250d9f,_0x4f589c){this['validateEventType_'](_0x463e61);const _0x1db75c=this['listeners_'][_0x463e61]||[];for(let _0x547862=0x0;_0x547862<_0x1db75c['length'];_0x547862++)if(_0x1db75c[_0x547862]['callback']===_0x250d9f&&(!_0x4f589c||_0x4f589c===_0x1db75c[_0x547862]['context'])){_0x1db75c['splice'](_0x547862,0x1);return;}}['validateEventType_'](_0x4d0b94){f(this['allowedEvents_']['find'](_0x9afe96=>_0x9afe96===_0x4d0b94),'Unknown\x20event:\x20'+_0x4d0b94);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x1580de){return f(_0x1580de==='online','Unknown\x20event\x20type:\x20'+_0x1580de),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x571ba6,_0x572f95){if(_0x572f95===void 0x0){this['pieces_']=_0x571ba6['split']('/');let _0x2ca9f9=0x0;for(let _0x387e9d=0x0;_0x387e9d<this['pieces_']['length'];_0x387e9d++)this['pieces_'][_0x387e9d]['length']>0x0&&(this['pieces_'][_0x2ca9f9]=this['pieces_'][_0x387e9d],_0x2ca9f9++);this['pieces_']['length']=_0x2ca9f9,this['pieceNum_']=0x0;}else this['pieces_']=_0x571ba6,this['pieceNum_']=_0x572f95;}['toString'](){let _0x1fa09c='';for(let _0x4509df=this['pieceNum_'];_0x4509df<this['pieces_']['length'];_0x4509df++)this['pieces_'][_0x4509df]!==''&&(_0x1fa09c+='/'+this['pieces_'][_0x4509df]);return _0x1fa09c||'/';}}function w(){return new C('');}function y(_0xc31160){return _0xc31160['pieceNum_']>=_0xc31160['pieces_']['length']?null:_0xc31160['pieces_'][_0xc31160['pieceNum_']];}function we(_0x4ba213){return _0x4ba213['pieces_']['length']-_0x4ba213['pieceNum_'];}function b(_0xf5c14){let _0x55b913=_0xf5c14['pieceNum_'];return _0x55b913<_0xf5c14['pieces_']['length']&&_0x55b913++,new C(_0xf5c14['pieces_'],_0x55b913);}function zi(_0x58e321){return _0x58e321['pieceNum_']<_0x58e321['pieces_']['length']?_0x58e321['pieces_'][_0x58e321['pieces_']['length']-0x1]:null;}function bh(_0xab42){let _0x329901='';for(let _0x4055fc=_0xab42['pieceNum_'];_0x4055fc<_0xab42['pieces_']['length'];_0x4055fc++)_0xab42['pieces_'][_0x4055fc]!==''&&(_0x329901+='/'+encodeURIComponent(String(_0xab42['pieces_'][_0x4055fc])));return _0x329901||'/';}function Pt(_0x12d742,_0x1138f9=0x0){return _0x12d742['pieces_']['slice'](_0x12d742['pieceNum_']+_0x1138f9);}function Ro(_0x365446){if(_0x365446['pieceNum_']>=_0x365446['pieces_']['length'])return null;const _0x355047=[];for(let _0x48a805=_0x365446['pieceNum_'];_0x48a805<_0x365446['pieces_']['length']-0x1;_0x48a805++)_0x355047['push'](_0x365446['pieces_'][_0x48a805]);return new C(_0x355047,0x0);}function k(_0x58667d,_0x500b68){const _0x50f159=[];for(let _0x59e2b7=_0x58667d['pieceNum_'];_0x59e2b7<_0x58667d['pieces_']['length'];_0x59e2b7++)_0x50f159['push'](_0x58667d['pieces_'][_0x59e2b7]);if(_0x500b68 instanceof C){for(let _0x5a6170=_0x500b68['pieceNum_'];_0x5a6170<_0x500b68['pieces_']['length'];_0x5a6170++)_0x50f159['push'](_0x500b68['pieces_'][_0x5a6170]);}else{const _0x3b525b=_0x500b68['split']('/');for(let _0x442a00=0x0;_0x442a00<_0x3b525b['length'];_0x442a00++)_0x3b525b[_0x442a00]['length']>0x0&&_0x50f159['push'](_0x3b525b[_0x442a00]);}return new C(_0x50f159,0x0);}function v(_0x2ae57c){return _0x2ae57c['pieceNum_']>=_0x2ae57c['pieces_']['length'];}function F(_0x1e4641,_0x49ce67){const _0x5d906d=y(_0x1e4641),_0x5ecddc=y(_0x49ce67);if(_0x5d906d===null)return _0x49ce67;if(_0x5d906d===_0x5ecddc)return F(b(_0x1e4641),b(_0x49ce67));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x49ce67+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1e4641+')');}function Rh(_0x347b8d,_0x3a9e6a){const _0x5bc9c8=Pt(_0x347b8d,0x0),_0x31dbf8=Pt(_0x3a9e6a,0x0);for(let _0x3be1e6=0x0;_0x3be1e6<_0x5bc9c8['length']&&_0x3be1e6<_0x31dbf8['length'];_0x3be1e6++){const _0x3acb83=He(_0x5bc9c8[_0x3be1e6],_0x31dbf8[_0x3be1e6]);if(_0x3acb83!==0x0)return _0x3acb83;}return _0x5bc9c8['length']===_0x31dbf8['length']?0x0:_0x5bc9c8['length']<_0x31dbf8['length']?-0x1:0x1;}function ji(_0x3f5ecc,_0x35f865){if(we(_0x3f5ecc)!==we(_0x35f865))return!0x1;for(let _0x3ef5a4=_0x3f5ecc['pieceNum_'],_0xe7bbf8=_0x35f865['pieceNum_'];_0x3ef5a4<=_0x3f5ecc['pieces_']['length'];_0x3ef5a4++,_0xe7bbf8++)if(_0x3f5ecc['pieces_'][_0x3ef5a4]!==_0x35f865['pieces_'][_0xe7bbf8])return!0x1;return!0x0;}function G(_0x2c00c4,_0x51da12){let _0x4a68d0=_0x2c00c4['pieceNum_'],_0x5b09ba=_0x51da12['pieceNum_'];if(we(_0x2c00c4)>we(_0x51da12))return!0x1;for(;_0x4a68d0<_0x2c00c4['pieces_']['length'];){if(_0x2c00c4['pieces_'][_0x4a68d0]!==_0x51da12['pieces_'][_0x5b09ba])return!0x1;++_0x4a68d0,++_0x5b09ba;}return!0x0;}class Ah{constructor(_0x3ce05e,_0x4232c9){this['errorPrefix_']=_0x4232c9,this['parts_']=Pt(_0x3ce05e,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x2ca555=0x0;_0x2ca555<this['parts_']['length'];_0x2ca555++)this['byteLength_']+=On(this['parts_'][_0x2ca555]);Ao(this);}}function kh(_0x144756,_0x4fe810){_0x144756['parts_']['length']>0x0&&(_0x144756['byteLength_']+=0x1),_0x144756['parts_']['push'](_0x4fe810),_0x144756['byteLength_']+=On(_0x4fe810),Ao(_0x144756);}function Nh(_0x4bb8a2){const _0x386eca=_0x4bb8a2['parts_']['pop']();_0x4bb8a2['byteLength_']-=On(_0x386eca),_0x4bb8a2['parts_']['length']>0x0&&(_0x4bb8a2['byteLength_']-=0x1);}function Ao(_0x119ad1){if(_0x119ad1['byteLength_']>er)throw new Error(_0x119ad1['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x119ad1['byteLength_']+').');if(_0x119ad1['parts_']['length']>Zs)throw new Error(_0x119ad1['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x119ad1));}function Pe(_0x1519da){return _0x1519da['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x1519da['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0xbf6fe3,_0x3f00fe;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x3f00fe='visibilitychange',_0xbf6fe3='hidden'):typeof document['mozHidden']<'u'?(_0x3f00fe='mozvisibilitychange',_0xbf6fe3='mozHidden'):typeof document['msHidden']<'u'?(_0x3f00fe='msvisibilitychange',_0xbf6fe3='msHidden'):typeof document['webkitHidden']<'u'&&(_0x3f00fe='webkitvisibilitychange',_0xbf6fe3='webkitHidden')),this['visible_']=!0x0,_0x3f00fe&&document['addEventListener'](_0x3f00fe,()=>{const _0x457378=!document[_0xbf6fe3];_0x457378!==this['visible_']&&(this['visible_']=_0x457378,this['trigger']('visible',_0x457378));},!0x1);}['getInitialEvent'](_0x4aaa0b){return f(_0x4aaa0b==='visible','Unknown\x20event\x20type:\x20'+_0x4aaa0b),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x4d42f2,_0x3f39a2,_0x20bd8a,_0x17852a,_0x59fd4c,_0x27e5ee,_0x1ba505,_0x217fc6){if(super(),this['repoInfo_']=_0x4d42f2,this['applicationId_']=_0x3f39a2,this['onDataUpdate_']=_0x20bd8a,this['onConnectStatus_']=_0x17852a,this['onServerInfoUpdate_']=_0x59fd4c,this['authTokenProvider_']=_0x27e5ee,this['appCheckTokenProvider_']=_0x1ba505,this['authOverride_']=_0x217fc6,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x217fc6)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x4d42f2['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x150769,_0xb5719c,_0x4b8d20){const _0x4c7e53=++this['requestNumber_'],_0x46126d={'r':_0x4c7e53,'a':_0x150769,'b':_0xb5719c};this['log_'](O(_0x46126d)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x46126d),_0x4b8d20&&(this['requestCBHash_'][_0x4c7e53]=_0x4b8d20);}['get'](_0x2bcd27){this['initConnection_']();const _0x350b31=new ot(),_0x366927={'action':'g','request':{'p':_0x2bcd27['_path']['toString'](),'q':_0x2bcd27['_queryObject']},'onComplete':_0x22b888=>{const _0x3c3d6a=_0x22b888['d'];_0x22b888['s']==='ok'?_0x350b31['resolve'](_0x3c3d6a):_0x350b31['reject'](_0x3c3d6a);}};this['outstandingGets_']['push'](_0x366927),this['outstandingGetCount_']++;const _0x494456=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x494456),_0x350b31['promise'];}['listen'](_0x146c6e,_0x2af68d,_0x6c2b27,_0x506c28){this['initConnection_']();const _0xbe459e=_0x146c6e['_queryIdentifier'],_0x531f65=_0x146c6e['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x531f65+'\x20'+_0xbe459e),this['listens']['has'](_0x531f65)||this['listens']['set'](_0x531f65,new Map()),f(_0x146c6e['_queryParams']['isDefault']()||!_0x146c6e['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x531f65)['has'](_0xbe459e),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0xf8790f={'onComplete':_0x506c28,'hashFn':_0x2af68d,'query':_0x146c6e,'tag':_0x6c2b27};this['listens']['get'](_0x531f65)['set'](_0xbe459e,_0xf8790f),this['connected_']&&this['sendListen_'](_0xf8790f);}['sendGet_'](_0xb48ac6){const _0x5d161e=this['outstandingGets_'][_0xb48ac6];this['sendRequest']('g',_0x5d161e['request'],_0x52be50=>{delete this['outstandingGets_'][_0xb48ac6],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x5d161e['onComplete']&&_0x5d161e['onComplete'](_0x52be50);});}['sendListen_'](_0x5e882c){const _0x3c0944=_0x5e882c['query'],_0x5e17a7=_0x3c0944['_path']['toString'](),_0x7984d7=_0x3c0944['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x5e17a7+'\x20for\x20'+_0x7984d7);const _0x1dac3f={'p':_0x5e17a7},_0x4bcb67='q';_0x5e882c['tag']&&(_0x1dac3f['q']=_0x3c0944['_queryObject'],_0x1dac3f['t']=_0x5e882c['tag']),_0x1dac3f['h']=_0x5e882c['hashFn'](),this['sendRequest'](_0x4bcb67,_0x1dac3f,_0x368356=>{const _0x1ccb88=_0x368356['d'],_0x3ba8c1=_0x368356['s'];se['warnOnListenWarnings_'](_0x1ccb88,_0x3c0944),(this['listens']['get'](_0x5e17a7)&&this['listens']['get'](_0x5e17a7)['get'](_0x7984d7))===_0x5e882c&&(this['log_']('listen\x20response',_0x368356),_0x3ba8c1!=='ok'&&this['removeListen_'](_0x5e17a7,_0x7984d7),_0x5e882c['onComplete']&&_0x5e882c['onComplete'](_0x3ba8c1,_0x1ccb88));});}static['warnOnListenWarnings_'](_0x3fcf05,_0xcf0487){if(_0x3fcf05&&typeof _0x3fcf05=='object'&&J(_0x3fcf05,'w')){const _0x467230=De(_0x3fcf05,'w');if(Array['isArray'](_0x467230)&&~_0x467230['indexOf']('no_index')){const _0x126d47='\x22.indexOn\x22:\x20\x22'+_0xcf0487['_queryParams']['getIndex']()['toString']()+'\x22',_0x25a3ef=_0xcf0487['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x126d47+'\x20at\x20'+_0x25a3ef+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x39e5ee){this['authToken_']=_0x39e5ee,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x39e5ee);}['reduceReconnectDelayIfAdminCredential_'](_0x596df6){(_0x596df6&&_0x596df6['length']===0x28||wc(_0x596df6))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x54fe1c){this['appCheckToken_']=_0x54fe1c,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x4a8d81=this['authToken_'],_0x3803c3=Ic(_0x4a8d81)?'auth':'gauth',_0xd572ed={'cred':_0x4a8d81};this['authOverride_']===null?_0xd572ed['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0xd572ed['authvar']=this['authOverride_']),this['sendRequest'](_0x3803c3,_0xd572ed,_0x5aeb08=>{const _0x16fbb3=_0x5aeb08['s'],_0x2fc3c4=_0x5aeb08['d']||'error';this['authToken_']===_0x4a8d81&&(_0x16fbb3==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x16fbb3,_0x2fc3c4));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x5b3a6b=>{const _0x55d4fa=_0x5b3a6b['s'],_0x1b4a8f=_0x5b3a6b['d']||'error';_0x55d4fa==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x55d4fa,_0x1b4a8f);});}['unlisten'](_0x98f6,_0x4eb471){const _0x3c52a1=_0x98f6['_path']['toString'](),_0x7f0327=_0x98f6['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x3c52a1+'\x20'+_0x7f0327),f(_0x98f6['_queryParams']['isDefault']()||!_0x98f6['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x3c52a1,_0x7f0327)&&this['connected_']&&this['sendUnlisten_'](_0x3c52a1,_0x7f0327,_0x98f6['_queryObject'],_0x4eb471);}['sendUnlisten_'](_0x2e2922,_0x1e4df6,_0x27de73,_0x513590){this['log_']('Unlisten\x20on\x20'+_0x2e2922+'\x20for\x20'+_0x1e4df6);const _0x24851e={'p':_0x2e2922},_0x5a9b51='n';_0x513590&&(_0x24851e['q']=_0x27de73,_0x24851e['t']=_0x513590),this['sendRequest'](_0x5a9b51,_0x24851e);}['onDisconnectPut'](_0x332d11,_0x16ff75,_0x2883f3){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x332d11,_0x16ff75,_0x2883f3):this['onDisconnectRequestQueue_']['push']({'pathString':_0x332d11,'action':'o','data':_0x16ff75,'onComplete':_0x2883f3});}['onDisconnectMerge'](_0x4f15c9,_0x95800f,_0x3b5130){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x4f15c9,_0x95800f,_0x3b5130):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4f15c9,'action':'om','data':_0x95800f,'onComplete':_0x3b5130});}['onDisconnectCancel'](_0xaa1ce2,_0x2a19e6){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0xaa1ce2,null,_0x2a19e6):this['onDisconnectRequestQueue_']['push']({'pathString':_0xaa1ce2,'action':'oc','data':null,'onComplete':_0x2a19e6});}['sendOnDisconnect_'](_0x72f0fb,_0x42ac6d,_0x40d585,_0x5043f9){const _0x38ac7b={'p':_0x42ac6d,'d':_0x40d585};this['log_']('onDisconnect\x20'+_0x72f0fb,_0x38ac7b),this['sendRequest'](_0x72f0fb,_0x38ac7b,_0x4096a9=>{_0x5043f9&&setTimeout(()=>{_0x5043f9(_0x4096a9['s'],_0x4096a9['d']);},Math['floor'](0x0));});}['put'](_0x36a9b7,_0x278128,_0x27770e,_0x532ed9){this['putInternal']('p',_0x36a9b7,_0x278128,_0x27770e,_0x532ed9);}['merge'](_0x118584,_0x173c91,_0x1061f7,_0x4d09a8){this['putInternal']('m',_0x118584,_0x173c91,_0x1061f7,_0x4d09a8);}['putInternal'](_0x1b5e5f,_0x5b57b7,_0x1667b8,_0x1a06d5,_0xf95814){this['initConnection_']();const _0x4a2f2f={'p':_0x5b57b7,'d':_0x1667b8};_0xf95814!==void 0x0&&(_0x4a2f2f['h']=_0xf95814),this['outstandingPuts_']['push']({'action':_0x1b5e5f,'request':_0x4a2f2f,'onComplete':_0x1a06d5}),this['outstandingPutCount_']++;const _0x444b93=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x444b93):this['log_']('Buffering\x20put:\x20'+_0x5b57b7);}['sendPut_'](_0x55d699){const _0x378b28=this['outstandingPuts_'][_0x55d699]['action'],_0x3d2b88=this['outstandingPuts_'][_0x55d699]['request'],_0x45baf0=this['outstandingPuts_'][_0x55d699]['onComplete'];this['outstandingPuts_'][_0x55d699]['queued']=this['connected_'],this['sendRequest'](_0x378b28,_0x3d2b88,_0x93e27c=>{this['log_'](_0x378b28+'\x20response',_0x93e27c),delete this['outstandingPuts_'][_0x55d699],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x45baf0&&_0x45baf0(_0x93e27c['s'],_0x93e27c['d']);});}['reportStats'](_0x190b04){if(this['connected_']){const _0x14b5f3={'c':_0x190b04};this['log_']('reportStats',_0x14b5f3),this['sendRequest']('s',_0x14b5f3,_0x21c50c=>{if(_0x21c50c['s']!=='ok'){const _0x63fc1d=_0x21c50c['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x63fc1d);}});}}['onDataMessage_'](_0x1a1c56){if('r'in _0x1a1c56){this['log_']('from\x20server:\x20'+O(_0x1a1c56));const _0x1b2de5=_0x1a1c56['r'],_0x48ec24=this['requestCBHash_'][_0x1b2de5];_0x48ec24&&(delete this['requestCBHash_'][_0x1b2de5],_0x48ec24(_0x1a1c56['b']));}else{if('error'in _0x1a1c56)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x1a1c56['error'];'a'in _0x1a1c56&&this['onDataPush_'](_0x1a1c56['a'],_0x1a1c56['b']);}}['onDataPush_'](_0xac55e3,_0x35c7f8){this['log_']('handleServerMessage',_0xac55e3,_0x35c7f8),_0xac55e3==='d'?this['onDataUpdate_'](_0x35c7f8['p'],_0x35c7f8['d'],!0x1,_0x35c7f8['t']):_0xac55e3==='m'?this['onDataUpdate_'](_0x35c7f8['p'],_0x35c7f8['d'],!0x0,_0x35c7f8['t']):_0xac55e3==='c'?this['onListenRevoked_'](_0x35c7f8['p'],_0x35c7f8['q']):_0xac55e3==='ac'?this['onAuthRevoked_'](_0x35c7f8['s'],_0x35c7f8['d']):_0xac55e3==='apc'?this['onAppCheckRevoked_'](_0x35c7f8['s'],_0x35c7f8['d']):_0xac55e3==='sd'?this['onSecurityDebugPacket_'](_0x35c7f8):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0xac55e3)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x24432e,_0x5b99eb){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x24432e),this['lastSessionId']=_0x5b99eb,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x297d26){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x297d26));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x30a64f){_0x30a64f&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x30a64f;}['onOnline_'](_0x4a2d0a){_0x4a2d0a?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x2a81a6=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x5b07e=Math['max'](0x0,this['reconnectDelay_']-_0x2a81a6);_0x5b07e=Math['random']()*_0x5b07e,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x5b07e+'ms'),this['scheduleConnect_'](_0x5b07e),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x2864fd=this['onDataMessage_']['bind'](this),_0x3bd131=this['onReady_']['bind'](this),_0xbf0459=this['onRealtimeDisconnect_']['bind'](this),_0x257abb=this['id']+':'+se['nextConnectionId_']++,_0xe8ef04=this['lastSessionId'];let _0x44372f=!0x1,_0x4f5bc2=null;const _0x3d7291=function(){_0x4f5bc2?_0x4f5bc2['close']():(_0x44372f=!0x0,_0xbf0459());},_0x58d2b7=function(_0x29f268){f(_0x4f5bc2,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x4f5bc2['sendRequest'](_0x29f268);};this['realtime_']={'close':_0x3d7291,'sendRequest':_0x58d2b7};const _0x4acf83=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x18c453,_0x2d7854]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x4acf83),this['appCheckTokenProvider_']['getToken'](_0x4acf83)]);_0x44372f?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x18c453&&_0x18c453['accessToken'],this['appCheckToken_']=_0x2d7854&&_0x2d7854['token'],_0x4f5bc2=new Sh(_0x257abb,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x2864fd,_0x3bd131,_0xbf0459,_0x18aab=>{U(_0x18aab+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0xe8ef04));}catch(_0x113e52){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x113e52),_0x44372f||(this['repoInfo_']['nodeAdmin']&&U(_0x113e52),_0x3d7291());}}}['interrupt'](_0x2ef6b4){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x2ef6b4),this['interruptReasons_'][_0x2ef6b4]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x2961bf){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x2961bf),delete this['interruptReasons_'][_0x2961bf],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x98dd62){const _0x4aa4f6=_0x98dd62-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x4aa4f6});}['cancelSentTransactions_'](){for(let _0x47182b=0x0;_0x47182b<this['outstandingPuts_']['length'];_0x47182b++){const _0x14901c=this['outstandingPuts_'][_0x47182b];_0x14901c&&'h'in _0x14901c['request']&&_0x14901c['queued']&&(_0x14901c['onComplete']&&_0x14901c['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x47182b],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x3bed45,_0xf62409){let _0x12a7c1;_0xf62409?_0x12a7c1=_0xf62409['map'](_0x27bd4f=>Hi(_0x27bd4f))['join']('$'):_0x12a7c1='default';const _0xd2232e=this['removeListen_'](_0x3bed45,_0x12a7c1);_0xd2232e&&_0xd2232e['onComplete']&&_0xd2232e['onComplete']('permission_denied');}['removeListen_'](_0x2b67aa,_0x3b79b0){const _0x4e6bf0=new C(_0x2b67aa)['toString']();let _0x435379;if(this['listens']['has'](_0x4e6bf0)){const _0x2fd5e7=this['listens']['get'](_0x4e6bf0);_0x435379=_0x2fd5e7['get'](_0x3b79b0),_0x2fd5e7['delete'](_0x3b79b0),_0x2fd5e7['size']===0x0&&this['listens']['delete'](_0x4e6bf0);}else _0x435379=void 0x0;return _0x435379;}['onAuthRevoked_'](_0x42f635,_0x5e24c8){L('Auth\x20token\x20revoked:\x20'+_0x42f635+'/'+_0x5e24c8),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x42f635==='invalid_token'||_0x42f635==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x353cab,_0x12b22e){L('App\x20check\x20token\x20revoked:\x20'+_0x353cab+'/'+_0x12b22e),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x353cab==='invalid_token'||_0x353cab==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x4e0d8c){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x4e0d8c):'msg'in _0x4e0d8c&&console['log']('FIREBASE:\x20'+_0x4e0d8c['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x21b346 of this['listens']['values']())for(const _0x44ee5d of _0x21b346['values']())this['sendListen_'](_0x44ee5d);for(let _0x14b329=0x0;_0x14b329<this['outstandingPuts_']['length'];_0x14b329++)this['outstandingPuts_'][_0x14b329]&&this['sendPut_'](_0x14b329);for(;this['onDisconnectRequestQueue_']['length'];){const _0x348731=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x348731['action'],_0x348731['pathString'],_0x348731['data'],_0x348731['onComplete']);}for(let _0x359ef0=0x0;_0x359ef0<this['outstandingGets_']['length'];_0x359ef0++)this['outstandingGets_'][_0x359ef0]&&this['sendGet_'](_0x359ef0);}['sendConnectStats_'](){const _0x4beeeb={};let _0x32c839='js';_0x4beeeb['sdk.'+_0x32c839+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x4beeeb['framework.cordova']=0x1:Yr()&&(_0x4beeeb['framework.reactnative']=0x1),this['reportStats'](_0x4beeeb);}['shouldReconnect_'](){const _0xac8f70=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0xac8f70;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x12f1a3,_0x1e18cb){this['name']=_0x12f1a3,this['node']=_0x1e18cb;}static['Wrap'](_0x85a415,_0x3ded26){return new E(_0x85a415,_0x3ded26);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x16ebdf,_0x504568){const _0x1b1203=new E(Fe,_0x16ebdf),_0x2c378e=new E(Fe,_0x504568);return this['compare'](_0x1b1203,_0x2c378e)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x529194){Zt=_0x529194;}['compare'](_0x22cdc4,_0x38e5a6){return He(_0x22cdc4['name'],_0x38e5a6['name']);}['isDefinedOn'](_0x19e2e){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x152065,_0x1fc5b8){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0xbbadcf,_0x2cf636){return f(typeof _0xbbadcf=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0xbbadcf,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x2c1506,_0x31c207,_0x495176,_0x1188ab,_0x3c1b53=null){this['isReverse_']=_0x1188ab,this['resultGenerator_']=_0x3c1b53,this['nodeStack_']=[];let _0x1f158e=0x1;for(;!_0x2c1506['isEmpty']();)if(_0x2c1506=_0x2c1506,_0x1f158e=_0x31c207?_0x495176(_0x2c1506['key'],_0x31c207):0x1,_0x1188ab&&(_0x1f158e*=-0x1),_0x1f158e<0x0)this['isReverse_']?_0x2c1506=_0x2c1506['left']:_0x2c1506=_0x2c1506['right'];else{if(_0x1f158e===0x0){this['nodeStack_']['push'](_0x2c1506);break;}else this['nodeStack_']['push'](_0x2c1506),this['isReverse_']?_0x2c1506=_0x2c1506['right']:_0x2c1506=_0x2c1506['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x445e6f=this['nodeStack_']['pop'](),_0x58bc53;if(this['resultGenerator_']?_0x58bc53=this['resultGenerator_'](_0x445e6f['key'],_0x445e6f['value']):_0x58bc53={'key':_0x445e6f['key'],'value':_0x445e6f['value']},this['isReverse_']){for(_0x445e6f=_0x445e6f['left'];!_0x445e6f['isEmpty']();)this['nodeStack_']['push'](_0x445e6f),_0x445e6f=_0x445e6f['right'];}else{for(_0x445e6f=_0x445e6f['right'];!_0x445e6f['isEmpty']();)this['nodeStack_']['push'](_0x445e6f),_0x445e6f=_0x445e6f['left'];}return _0x58bc53;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x58bbcd=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x58bbcd['key'],_0x58bbcd['value']):{'key':_0x58bbcd['key'],'value':_0x58bbcd['value']};}}class M{constructor(_0x37cfb8,_0x2b99fd,_0x48a371,_0x1873b1,_0x27be3d){this['key']=_0x37cfb8,this['value']=_0x2b99fd,this['color']=_0x48a371??M['RED'],this['left']=_0x1873b1??B['EMPTY_NODE'],this['right']=_0x27be3d??B['EMPTY_NODE'];}['copy'](_0xa21125,_0x45d213,_0x9d12a9,_0x192735,_0x19f89f){return new M(_0xa21125??this['key'],_0x45d213??this['value'],_0x9d12a9??this['color'],_0x192735??this['left'],_0x19f89f??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x41c2e5){return this['left']['inorderTraversal'](_0x41c2e5)||!!_0x41c2e5(this['key'],this['value'])||this['right']['inorderTraversal'](_0x41c2e5);}['reverseTraversal'](_0x54ca38){return this['right']['reverseTraversal'](_0x54ca38)||_0x54ca38(this['key'],this['value'])||this['left']['reverseTraversal'](_0x54ca38);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x58c2d8,_0x51f2c9,_0x43d922){let _0x228b02=this;const _0x38ecb8=_0x43d922(_0x58c2d8,_0x228b02['key']);return _0x38ecb8<0x0?_0x228b02=_0x228b02['copy'](null,null,null,_0x228b02['left']['insert'](_0x58c2d8,_0x51f2c9,_0x43d922),null):_0x38ecb8===0x0?_0x228b02=_0x228b02['copy'](null,_0x51f2c9,null,null,null):_0x228b02=_0x228b02['copy'](null,null,null,null,_0x228b02['right']['insert'](_0x58c2d8,_0x51f2c9,_0x43d922)),_0x228b02['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x5de135=this;return!_0x5de135['left']['isRed_']()&&!_0x5de135['left']['left']['isRed_']()&&(_0x5de135=_0x5de135['moveRedLeft_']()),_0x5de135=_0x5de135['copy'](null,null,null,_0x5de135['left']['removeMin_'](),null),_0x5de135['fixUp_']();}['remove'](_0x1c5da9,_0x41b4f0){let _0x1e71da,_0x2a6145;if(_0x1e71da=this,_0x41b4f0(_0x1c5da9,_0x1e71da['key'])<0x0)!_0x1e71da['left']['isEmpty']()&&!_0x1e71da['left']['isRed_']()&&!_0x1e71da['left']['left']['isRed_']()&&(_0x1e71da=_0x1e71da['moveRedLeft_']()),_0x1e71da=_0x1e71da['copy'](null,null,null,_0x1e71da['left']['remove'](_0x1c5da9,_0x41b4f0),null);else{if(_0x1e71da['left']['isRed_']()&&(_0x1e71da=_0x1e71da['rotateRight_']()),!_0x1e71da['right']['isEmpty']()&&!_0x1e71da['right']['isRed_']()&&!_0x1e71da['right']['left']['isRed_']()&&(_0x1e71da=_0x1e71da['moveRedRight_']()),_0x41b4f0(_0x1c5da9,_0x1e71da['key'])===0x0){if(_0x1e71da['right']['isEmpty']())return B['EMPTY_NODE'];_0x2a6145=_0x1e71da['right']['min_'](),_0x1e71da=_0x1e71da['copy'](_0x2a6145['key'],_0x2a6145['value'],null,null,_0x1e71da['right']['removeMin_']());}_0x1e71da=_0x1e71da['copy'](null,null,null,null,_0x1e71da['right']['remove'](_0x1c5da9,_0x41b4f0));}return _0x1e71da['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0xb6b283=this;return _0xb6b283['right']['isRed_']()&&!_0xb6b283['left']['isRed_']()&&(_0xb6b283=_0xb6b283['rotateLeft_']()),_0xb6b283['left']['isRed_']()&&_0xb6b283['left']['left']['isRed_']()&&(_0xb6b283=_0xb6b283['rotateRight_']()),_0xb6b283['left']['isRed_']()&&_0xb6b283['right']['isRed_']()&&(_0xb6b283=_0xb6b283['colorFlip_']()),_0xb6b283;}['moveRedLeft_'](){let _0x3cc3a9=this['colorFlip_']();return _0x3cc3a9['right']['left']['isRed_']()&&(_0x3cc3a9=_0x3cc3a9['copy'](null,null,null,null,_0x3cc3a9['right']['rotateRight_']()),_0x3cc3a9=_0x3cc3a9['rotateLeft_'](),_0x3cc3a9=_0x3cc3a9['colorFlip_']()),_0x3cc3a9;}['moveRedRight_'](){let _0x377d7d=this['colorFlip_']();return _0x377d7d['left']['left']['isRed_']()&&(_0x377d7d=_0x377d7d['rotateRight_'](),_0x377d7d=_0x377d7d['colorFlip_']()),_0x377d7d;}['rotateLeft_'](){const _0x599afa=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x599afa,null);}['rotateRight_'](){const _0x1984a3=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x1984a3);}['colorFlip_'](){const _0x42a432=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x436d84=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x42a432,_0x436d84);}['checkMaxDepth_'](){const _0x6de08a=this['check_']();return Math['pow'](0x2,_0x6de08a)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x8503e5=this['left']['check_']();if(_0x8503e5!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x8503e5+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x8846bd,_0x424514,_0x544cec,_0x115c78,_0x413a0a){return this;}['insert'](_0x263a4d,_0x25c4e4,_0x53daea){return new M(_0x263a4d,_0x25c4e4,null);}['remove'](_0x3f7847,_0x204eb7){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x456493){return!0x1;}['reverseTraversal'](_0x49c116){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x1912a3,_0x58fcf2=B['EMPTY_NODE']){this['comparator_']=_0x1912a3,this['root_']=_0x58fcf2;}['insert'](_0x4a4453,_0x2fc47b){return new B(this['comparator_'],this['root_']['insert'](_0x4a4453,_0x2fc47b,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x5d1c8f){return new B(this['comparator_'],this['root_']['remove'](_0x5d1c8f,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x204a80){let _0x2f236e,_0x5b631a=this['root_'];for(;!_0x5b631a['isEmpty']();){if(_0x2f236e=this['comparator_'](_0x204a80,_0x5b631a['key']),_0x2f236e===0x0)return _0x5b631a['value'];_0x2f236e<0x0?_0x5b631a=_0x5b631a['left']:_0x2f236e>0x0&&(_0x5b631a=_0x5b631a['right']);}return null;}['getPredecessorKey'](_0x17e668){let _0x2677e4,_0x1a7eb4=this['root_'],_0x1e8948=null;for(;!_0x1a7eb4['isEmpty']();)if(_0x2677e4=this['comparator_'](_0x17e668,_0x1a7eb4['key']),_0x2677e4===0x0){if(_0x1a7eb4['left']['isEmpty']())return _0x1e8948?_0x1e8948['key']:null;for(_0x1a7eb4=_0x1a7eb4['left'];!_0x1a7eb4['right']['isEmpty']();)_0x1a7eb4=_0x1a7eb4['right'];return _0x1a7eb4['key'];}else _0x2677e4<0x0?_0x1a7eb4=_0x1a7eb4['left']:_0x2677e4>0x0&&(_0x1e8948=_0x1a7eb4,_0x1a7eb4=_0x1a7eb4['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x5700b8){return this['root_']['inorderTraversal'](_0x5700b8);}['reverseTraversal'](_0x200310){return this['root_']['reverseTraversal'](_0x200310);}['getIterator'](_0x6a9580){return new en(this['root_'],null,this['comparator_'],!0x1,_0x6a9580);}['getIteratorFrom'](_0x459d06,_0x34c281){return new en(this['root_'],_0x459d06,this['comparator_'],!0x1,_0x34c281);}['getReverseIteratorFrom'](_0x2f0d48,_0x14cb36){return new en(this['root_'],_0x2f0d48,this['comparator_'],!0x0,_0x14cb36);}['getReverseIterator'](_0x1662d5){return new en(this['root_'],null,this['comparator_'],!0x0,_0x1662d5);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x2872a8,_0x2d178b){return He(_0x2872a8['name'],_0x2d178b['name']);}function Yi(_0xbd1dcc,_0x3b5faf){return He(_0xbd1dcc,_0x3b5faf);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x2ae04f){Ei=_0x2ae04f;}const No=function(_0x10e248){return typeof _0x10e248=='number'?'number:'+ao(_0x10e248):'string:'+_0x10e248;},Po=function(_0x159226){if(_0x159226['isLeafNode']()){const _0x144a2e=_0x159226['val']();f(typeof _0x144a2e=='string'||typeof _0x144a2e=='number'||typeof _0x144a2e=='object'&&J(_0x144a2e,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x159226===Ei||_0x159226['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x159226===Ei||_0x159226['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x448d5e){ir=_0x448d5e;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x27939c,_0x10492a=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x27939c,this['priorityNode_']=_0x10492a,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x2ea931){return new D(this['value_'],_0x2ea931);}['getImmediateChild'](_0xc3d8d0){return _0xc3d8d0==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x376422){return v(_0x376422)?this:y(_0x376422)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x3ed127,_0x5056e8){return null;}['updateImmediateChild'](_0x12260d,_0x38f8f4){return _0x12260d==='.priority'?this['updatePriority'](_0x38f8f4):_0x38f8f4['isEmpty']()&&_0x12260d!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x12260d,_0x38f8f4)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x299dbb,_0x1fd543){const _0x1f307a=y(_0x299dbb);return _0x1f307a===null?_0x1fd543:_0x1fd543['isEmpty']()&&_0x1f307a!=='.priority'?this:(f(_0x1f307a!=='.priority'||we(_0x299dbb)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x1f307a,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x299dbb),_0x1fd543)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x2db18d,_0x5f287f){return!0x1;}['val'](_0x579a0f){return _0x579a0f&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x510e03='';this['priorityNode_']['isEmpty']()||(_0x510e03+='priority:'+No(this['priorityNode_']['val']())+':');const _0x1ea317=typeof this['value_'];_0x510e03+=_0x1ea317+':',_0x1ea317==='number'?_0x510e03+=ao(this['value_']):_0x510e03+=this['value_'],this['lazyHash_']=ro(_0x510e03);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x3e898f){return _0x3e898f===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x3e898f instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x3e898f['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x3e898f));}['compareToLeafNode_'](_0x48bdcd){const _0x4d5ce2=typeof _0x48bdcd['value_'],_0x236ccf=typeof this['value_'],_0x797128=D['VALUE_TYPE_ORDER']['indexOf'](_0x4d5ce2),_0x3727bb=D['VALUE_TYPE_ORDER']['indexOf'](_0x236ccf);return f(_0x797128>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4d5ce2),f(_0x3727bb>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x236ccf),_0x797128===_0x3727bb?_0x236ccf==='object'?0x0:this['value_']<_0x48bdcd['value_']?-0x1:this['value_']===_0x48bdcd['value_']?0x0:0x1:_0x3727bb-_0x797128;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x1a5cf7){if(_0x1a5cf7===this)return!0x0;if(_0x1a5cf7['isLeafNode']()){const _0x36dc81=_0x1a5cf7;return this['value_']===_0x36dc81['value_']&&this['priorityNode_']['equals'](_0x36dc81['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x350a5d){Oo=_0x350a5d;}function Wh(_0x5af534){Do=_0x5af534;}class Bh extends Dn{['compare'](_0x25e611,_0x27ec72){const _0x5488ef=_0x25e611['node']['getPriority'](),_0x21e29b=_0x27ec72['node']['getPriority'](),_0x117509=_0x5488ef['compareTo'](_0x21e29b);return _0x117509===0x0?He(_0x25e611['name'],_0x27ec72['name']):_0x117509;}['isDefinedOn'](_0x382897){return!_0x382897['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x558fd3,_0x389a65){return!_0x558fd3['getPriority']()['equals'](_0x389a65['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x22a504,_0x5dda6f){const _0x124101=Oo(_0x22a504);return new E(_0x5dda6f,new D('[PRIORITY-POST]',_0x124101));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x394de4){const _0x107366=_0x3fb6ff=>parseInt(Math['log'](_0x3fb6ff)/Vh,0xa),_0x166a92=_0xf19a63=>parseInt(Array(_0xf19a63+0x1)['join']('1'),0x2);this['count']=_0x107366(_0x394de4+0x1),this['current_']=this['count']-0x1;const _0x3e3f8e=_0x166a92(this['count']);this['bits_']=_0x394de4+0x1&_0x3e3f8e;}['nextBitIsOne'](){const _0x5f3d1c=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x5f3d1c;}}const fn=function(_0x1b761b,_0x4a03ef,_0x2da36a,_0x1db9d9){_0x1b761b['sort'](_0x4a03ef);const _0x52b624=function(_0x28c4c2,_0x178e1b){const _0x3ebe6d=_0x178e1b-_0x28c4c2;let _0x379afb,_0x3e3226;if(_0x3ebe6d===0x0)return null;if(_0x3ebe6d===0x1)return _0x379afb=_0x1b761b[_0x28c4c2],_0x3e3226=_0x2da36a?_0x2da36a(_0x379afb):_0x379afb,new M(_0x3e3226,_0x379afb['node'],M['BLACK'],null,null);{const _0x5c3c2e=parseInt(_0x3ebe6d/0x2,0xa)+_0x28c4c2,_0xa12afa=_0x52b624(_0x28c4c2,_0x5c3c2e),_0x48bf41=_0x52b624(_0x5c3c2e+0x1,_0x178e1b);return _0x379afb=_0x1b761b[_0x5c3c2e],_0x3e3226=_0x2da36a?_0x2da36a(_0x379afb):_0x379afb,new M(_0x3e3226,_0x379afb['node'],M['BLACK'],_0xa12afa,_0x48bf41);}},_0x1c748e=function(_0x12b29c){let _0xe281bc=null,_0x25c242=null,_0x47c807=_0x1b761b['length'];const _0x199b9d=function(_0x49f7bc,_0x25b8d1){const _0x1921b0=_0x47c807-_0x49f7bc,_0x26b9c1=_0x47c807;_0x47c807-=_0x49f7bc;const _0x517f2f=_0x52b624(_0x1921b0+0x1,_0x26b9c1),_0x21fe45=_0x1b761b[_0x1921b0],_0xa0bfa4=_0x2da36a?_0x2da36a(_0x21fe45):_0x21fe45;_0x48a97c(new M(_0xa0bfa4,_0x21fe45['node'],_0x25b8d1,null,_0x517f2f));},_0x48a97c=function(_0x5e2dde){_0xe281bc?(_0xe281bc['left']=_0x5e2dde,_0xe281bc=_0x5e2dde):(_0x25c242=_0x5e2dde,_0xe281bc=_0x5e2dde);};for(let _0x202aaf=0x0;_0x202aaf<_0x12b29c['count'];++_0x202aaf){const _0x5a1ff1=_0x12b29c['nextBitIsOne'](),_0x5cd859=Math['pow'](0x2,_0x12b29c['count']-(_0x202aaf+0x1));_0x5a1ff1?_0x199b9d(_0x5cd859,M['BLACK']):(_0x199b9d(_0x5cd859,M['BLACK']),_0x199b9d(_0x5cd859,M['RED']));}return _0x25c242;},_0x2d835c=new Hh(_0x1b761b['length']),_0x1a57a3=_0x1c748e(_0x2d835c);return new B(_0x1db9d9||_0x4a03ef,_0x1a57a3);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x2225c3,_0xcb4ca3){this['indexes_']=_0x2225c3,this['indexSet_']=_0xcb4ca3;}['get'](_0x59efb2){const _0x1c2212=De(this['indexes_'],_0x59efb2);if(!_0x1c2212)throw new Error('No\x20index\x20defined\x20for\x20'+_0x59efb2);return _0x1c2212 instanceof B?_0x1c2212:null;}['hasIndex'](_0x50e388){return J(this['indexSet_'],_0x50e388['toString']());}['addIndex'](_0x284f91,_0x4c2f85){f(_0x284f91!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x326f81=[];let _0x30d1c9=!0x1;const _0x161beb=_0x4c2f85['getIterator'](E['Wrap']);let _0x507e4b=_0x161beb['getNext']();for(;_0x507e4b;)_0x30d1c9=_0x30d1c9||_0x284f91['isDefinedOn'](_0x507e4b['node']),_0x326f81['push'](_0x507e4b),_0x507e4b=_0x161beb['getNext']();let _0x22f3a3;_0x30d1c9?_0x22f3a3=fn(_0x326f81,_0x284f91['getCompare']()):_0x22f3a3=ze;const _0x58da27=_0x284f91['toString'](),_0x1c3f33={...this['indexSet_']};_0x1c3f33[_0x58da27]=_0x284f91;const _0x2a5791={...this['indexes_']};return _0x2a5791[_0x58da27]=_0x22f3a3,new te(_0x2a5791,_0x1c3f33);}['addToIndexes'](_0x2a8101,_0x32fd22){const _0x3f62c5=hn(this['indexes_'],(_0x126e50,_0x33d029)=>{const _0x375d93=De(this['indexSet_'],_0x33d029);if(f(_0x375d93,'Missing\x20index\x20implementation\x20for\x20'+_0x33d029),_0x126e50===ze){if(_0x375d93['isDefinedOn'](_0x2a8101['node'])){const _0x4e3800=[],_0x17ab56=_0x32fd22['getIterator'](E['Wrap']);let _0x543bea=_0x17ab56['getNext']();for(;_0x543bea;)_0x543bea['name']!==_0x2a8101['name']&&_0x4e3800['push'](_0x543bea),_0x543bea=_0x17ab56['getNext']();return _0x4e3800['push'](_0x2a8101),fn(_0x4e3800,_0x375d93['getCompare']());}else return ze;}else{const _0xa69d5a=_0x32fd22['get'](_0x2a8101['name']);let _0x97f156=_0x126e50;return _0xa69d5a&&(_0x97f156=_0x97f156['remove'](new E(_0x2a8101['name'],_0xa69d5a))),_0x97f156['insert'](_0x2a8101,_0x2a8101['node']);}});return new te(_0x3f62c5,this['indexSet_']);}['removeFromIndexes'](_0x5706b8,_0x77ddc0){const _0x16ea7a=hn(this['indexes_'],_0x3978b8=>{if(_0x3978b8===ze)return _0x3978b8;{const _0x5dee23=_0x77ddc0['get'](_0x5706b8['name']);return _0x5dee23?_0x3978b8['remove'](new E(_0x5706b8['name'],_0x5dee23)):_0x3978b8;}});return new te(_0x16ea7a,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x370004,_0x12d4b5,_0x1b82dd){this['children_']=_0x370004,this['priorityNode_']=_0x12d4b5,this['indexMap_']=_0x1b82dd,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0xbdc38e){return this['children_']['isEmpty']()?this:new g(this['children_'],_0xbdc38e,this['indexMap_']);}['getImmediateChild'](_0x42f0b4){if(_0x42f0b4==='.priority')return this['getPriority']();{const _0x53e387=this['children_']['get'](_0x42f0b4);return _0x53e387===null?mt:_0x53e387;}}['getChild'](_0x47c0d3){const _0x4d2bfd=y(_0x47c0d3);return _0x4d2bfd===null?this:this['getImmediateChild'](_0x4d2bfd)['getChild'](b(_0x47c0d3));}['hasChild'](_0x195c81){return this['children_']['get'](_0x195c81)!==null;}['updateImmediateChild'](_0x1b7ca0,_0xef0552){if(f(_0xef0552,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x1b7ca0==='.priority')return this['updatePriority'](_0xef0552);{const _0x276a4c=new E(_0x1b7ca0,_0xef0552);let _0x3d7c66,_0x519a09;_0xef0552['isEmpty']()?(_0x3d7c66=this['children_']['remove'](_0x1b7ca0),_0x519a09=this['indexMap_']['removeFromIndexes'](_0x276a4c,this['children_'])):(_0x3d7c66=this['children_']['insert'](_0x1b7ca0,_0xef0552),_0x519a09=this['indexMap_']['addToIndexes'](_0x276a4c,this['children_']));const _0x12ae2a=_0x3d7c66['isEmpty']()?mt:this['priorityNode_'];return new g(_0x3d7c66,_0x12ae2a,_0x519a09);}}['updateChild'](_0x3add56,_0x475701){const _0x424e4a=y(_0x3add56);if(_0x424e4a===null)return _0x475701;{f(y(_0x3add56)!=='.priority'||we(_0x3add56)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x388ff6=this['getImmediateChild'](_0x424e4a)['updateChild'](b(_0x3add56),_0x475701);return this['updateImmediateChild'](_0x424e4a,_0x388ff6);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x59cfa1){if(this['isEmpty']())return null;const _0x56425b={};let _0x25eec2=0x0,_0x1bd6ec=0x0,_0x5abcf3=!0x0;if(this['forEachChild'](R,(_0x20deb9,_0x59cd45)=>{_0x56425b[_0x20deb9]=_0x59cd45['val'](_0x59cfa1),_0x25eec2++,_0x5abcf3&&g['INTEGER_REGEXP_']['test'](_0x20deb9)?_0x1bd6ec=Math['max'](_0x1bd6ec,Number(_0x20deb9)):_0x5abcf3=!0x1;}),!_0x59cfa1&&_0x5abcf3&&_0x1bd6ec<0x2*_0x25eec2){const _0x1fa3a6=[];for(const _0x4132d0 in _0x56425b)_0x1fa3a6[_0x4132d0]=_0x56425b[_0x4132d0];return _0x1fa3a6;}else return _0x59cfa1&&!this['getPriority']()['isEmpty']()&&(_0x56425b['.priority']=this['getPriority']()['val']()),_0x56425b;}['hash'](){if(this['lazyHash_']===null){let _0x19c02b='';this['getPriority']()['isEmpty']()||(_0x19c02b+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x425634,_0xd1b02f)=>{const _0x119ece=_0xd1b02f['hash']();_0x119ece!==''&&(_0x19c02b+=':'+_0x425634+':'+_0x119ece);}),this['lazyHash_']=_0x19c02b===''?'':ro(_0x19c02b);}return this['lazyHash_'];}['getPredecessorChildName'](_0x7ad711,_0x588ba8,_0x4c9b6c){const _0x2e837d=this['resolveIndex_'](_0x4c9b6c);if(_0x2e837d){const _0x3d0ee9=_0x2e837d['getPredecessorKey'](new E(_0x7ad711,_0x588ba8));return _0x3d0ee9?_0x3d0ee9['name']:null;}else return this['children_']['getPredecessorKey'](_0x7ad711);}['getFirstChildName'](_0x5f6a05){const _0x35a0b5=this['resolveIndex_'](_0x5f6a05);if(_0x35a0b5){const _0x340243=_0x35a0b5['minKey']();return _0x340243&&_0x340243['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x38c06e){const _0x2a1380=this['getFirstChildName'](_0x38c06e);return _0x2a1380?new E(_0x2a1380,this['children_']['get'](_0x2a1380)):null;}['getLastChildName'](_0x1d5f99){const _0x20b55e=this['resolveIndex_'](_0x1d5f99);if(_0x20b55e){const _0x5e2783=_0x20b55e['maxKey']();return _0x5e2783&&_0x5e2783['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x287385){const _0x2f40fd=this['getLastChildName'](_0x287385);return _0x2f40fd?new E(_0x2f40fd,this['children_']['get'](_0x2f40fd)):null;}['forEachChild'](_0x191b0d,_0x2364c2){const _0x2985bc=this['resolveIndex_'](_0x191b0d);return _0x2985bc?_0x2985bc['inorderTraversal'](_0x19e3a8=>_0x2364c2(_0x19e3a8['name'],_0x19e3a8['node'])):this['children_']['inorderTraversal'](_0x2364c2);}['getIterator'](_0x3b86f1){return this['getIteratorFrom'](_0x3b86f1['minPost'](),_0x3b86f1);}['getIteratorFrom'](_0x476b8d,_0x2bb8e1){const _0xdd3e68=this['resolveIndex_'](_0x2bb8e1);if(_0xdd3e68)return _0xdd3e68['getIteratorFrom'](_0x476b8d,_0x14307f=>_0x14307f);{const _0x3396dc=this['children_']['getIteratorFrom'](_0x476b8d['name'],E['Wrap']);let _0x5e922f=_0x3396dc['peek']();for(;_0x5e922f!=null&&_0x2bb8e1['compare'](_0x5e922f,_0x476b8d)<0x0;)_0x3396dc['getNext'](),_0x5e922f=_0x3396dc['peek']();return _0x3396dc;}}['getReverseIterator'](_0x396a55){return this['getReverseIteratorFrom'](_0x396a55['maxPost'](),_0x396a55);}['getReverseIteratorFrom'](_0x2aff8f,_0x46e1c9){const _0x5e8341=this['resolveIndex_'](_0x46e1c9);if(_0x5e8341)return _0x5e8341['getReverseIteratorFrom'](_0x2aff8f,_0x1f6708=>_0x1f6708);{const _0x45c836=this['children_']['getReverseIteratorFrom'](_0x2aff8f['name'],E['Wrap']);let _0x12cc91=_0x45c836['peek']();for(;_0x12cc91!=null&&_0x46e1c9['compare'](_0x12cc91,_0x2aff8f)>0x0;)_0x45c836['getNext'](),_0x12cc91=_0x45c836['peek']();return _0x45c836;}}['compareTo'](_0x343668){return this['isEmpty']()?_0x343668['isEmpty']()?0x0:-0x1:_0x343668['isLeafNode']()||_0x343668['isEmpty']()?0x1:_0x343668===$t?-0x1:0x0;}['withIndex'](_0x1be7ad){if(_0x1be7ad===ye||this['indexMap_']['hasIndex'](_0x1be7ad))return this;{const _0x590968=this['indexMap_']['addIndex'](_0x1be7ad,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x590968);}}['isIndexed'](_0x148a95){return _0x148a95===ye||this['indexMap_']['hasIndex'](_0x148a95);}['equals'](_0x5edace){if(_0x5edace===this)return!0x0;if(_0x5edace['isLeafNode']())return!0x1;{const _0x58652e=_0x5edace;if(this['getPriority']()['equals'](_0x58652e['getPriority']())){if(this['children_']['count']()===_0x58652e['children_']['count']()){const _0x11daeb=this['getIterator'](R),_0x346e11=_0x58652e['getIterator'](R);let _0x91ac4e=_0x11daeb['getNext'](),_0x57220f=_0x346e11['getNext']();for(;_0x91ac4e&&_0x57220f;){if(_0x91ac4e['name']!==_0x57220f['name']||!_0x91ac4e['node']['equals'](_0x57220f['node']))return!0x1;_0x91ac4e=_0x11daeb['getNext'](),_0x57220f=_0x346e11['getNext']();}return _0x91ac4e===null&&_0x57220f===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0xe79bf8){return _0xe79bf8===ye?null:this['indexMap_']['get'](_0xe79bf8['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x14f096){return _0x14f096===this?0x0:0x1;}['equals'](_0x156fe5){return _0x156fe5===this;}['getPriority'](){return this;}['getImmediateChild'](_0x178cb5){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x57a6bc,_0x1407a2=null){if(_0x57a6bc===null)return g['EMPTY_NODE'];if(typeof _0x57a6bc=='object'&&'.priority'in _0x57a6bc&&(_0x1407a2=_0x57a6bc['.priority']),f(_0x1407a2===null||typeof _0x1407a2=='string'||typeof _0x1407a2=='number'||typeof _0x1407a2=='object'&&'.sv'in _0x1407a2,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x1407a2),typeof _0x57a6bc=='object'&&'.value'in _0x57a6bc&&_0x57a6bc['.value']!==null&&(_0x57a6bc=_0x57a6bc['.value']),typeof _0x57a6bc!='object'||'.sv'in _0x57a6bc){const _0x3aafa3=_0x57a6bc;return new D(_0x3aafa3,P(_0x1407a2));}if(!(_0x57a6bc instanceof Array)&&Gh){const _0x19c9eb=[];let _0x3bd49e=!0x1;if(x(_0x57a6bc,(_0x447e88,_0x2b02cc)=>{if(_0x447e88['substring'](0x0,0x1)!=='.'){const _0x1b44c6=P(_0x2b02cc);_0x1b44c6['isEmpty']()||(_0x3bd49e=_0x3bd49e||!_0x1b44c6['getPriority']()['isEmpty'](),_0x19c9eb['push'](new E(_0x447e88,_0x1b44c6)));}}),_0x19c9eb['length']===0x0)return g['EMPTY_NODE'];const _0x230642=fn(_0x19c9eb,xh,_0x161489=>_0x161489['name'],Yi);if(_0x3bd49e){const _0x374fcc=fn(_0x19c9eb,R['getCompare']());return new g(_0x230642,P(_0x1407a2),new te({'.priority':_0x374fcc},{'.priority':R}));}else return new g(_0x230642,P(_0x1407a2),te['Default']);}else{let _0x180ed4=g['EMPTY_NODE'];return x(_0x57a6bc,(_0x4c489d,_0x4caa91)=>{if(J(_0x57a6bc,_0x4c489d)&&_0x4c489d['substring'](0x0,0x1)!=='.'){const _0x543277=P(_0x4caa91);(_0x543277['isLeafNode']()||!_0x543277['isEmpty']())&&(_0x180ed4=_0x180ed4['updateImmediateChild'](_0x4c489d,_0x543277));}}),_0x180ed4['updatePriority'](P(_0x1407a2));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x6bfc87){super(),this['indexPath_']=_0x6bfc87,f(!v(_0x6bfc87)&&y(_0x6bfc87)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x20e89c){return _0x20e89c['getChild'](this['indexPath_']);}['isDefinedOn'](_0xdbfaa2){return!_0xdbfaa2['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x4d8c51,_0x6097c2){const _0x15dad5=this['extractChild'](_0x4d8c51['node']),_0xdc92af=this['extractChild'](_0x6097c2['node']),_0x343dd6=_0x15dad5['compareTo'](_0xdc92af);return _0x343dd6===0x0?He(_0x4d8c51['name'],_0x6097c2['name']):_0x343dd6;}['makePost'](_0x409896,_0x218302){const _0x31fbc0=P(_0x409896),_0x253478=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x31fbc0);return new E(_0x218302,_0x253478);}['maxPost'](){const _0x237934=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x237934);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x3a6e3d,_0x369b5e){const _0x244329=_0x3a6e3d['node']['compareTo'](_0x369b5e['node']);return _0x244329===0x0?He(_0x3a6e3d['name'],_0x369b5e['name']):_0x244329;}['isDefinedOn'](_0x5588a8){return!0x0;}['indexedValueChanged'](_0x3e8486,_0x8003a1){return!_0x3e8486['equals'](_0x8003a1);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x5406ed,_0x4c7f75){const _0x3214ce=P(_0x5406ed);return new E(_0x4c7f75,_0x3214ce);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x198df9){return{'type':'value','snapshotNode':_0x198df9};}function et(_0x39a0cf,_0x572498){return{'type':'child_added','snapshotNode':_0x572498,'childName':_0x39a0cf};}function Ot(_0x1411ac,_0xb67716){return{'type':'child_removed','snapshotNode':_0xb67716,'childName':_0x1411ac};}function Dt(_0x15153f,_0x15865e,_0x4b278a){return{'type':'child_changed','snapshotNode':_0x15865e,'childName':_0x15153f,'oldSnap':_0x4b278a};}function zh(_0xe6813a,_0x2fe071){return{'type':'child_moved','snapshotNode':_0x2fe071,'childName':_0xe6813a};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x2768c2){this['index_']=_0x2768c2;}['updateChild'](_0x1b9c4b,_0x2327f2,_0x287628,_0x3edf8a,_0x499526,_0x3dc74a){f(_0x1b9c4b['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x1df7bb=_0x1b9c4b['getImmediateChild'](_0x2327f2);return _0x1df7bb['getChild'](_0x3edf8a)['equals'](_0x287628['getChild'](_0x3edf8a))&&_0x1df7bb['isEmpty']()===_0x287628['isEmpty']()||(_0x3dc74a!=null&&(_0x287628['isEmpty']()?_0x1b9c4b['hasChild'](_0x2327f2)?_0x3dc74a['trackChildChange'](Ot(_0x2327f2,_0x1df7bb)):f(_0x1b9c4b['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x1df7bb['isEmpty']()?_0x3dc74a['trackChildChange'](et(_0x2327f2,_0x287628)):_0x3dc74a['trackChildChange'](Dt(_0x2327f2,_0x287628,_0x1df7bb))),_0x1b9c4b['isLeafNode']()&&_0x287628['isEmpty']())?_0x1b9c4b:_0x1b9c4b['updateImmediateChild'](_0x2327f2,_0x287628)['withIndex'](this['index_']);}['updateFullNode'](_0x2f69c,_0x341eba,_0x12a9c1){return _0x12a9c1!=null&&(_0x2f69c['isLeafNode']()||_0x2f69c['forEachChild'](R,(_0x4ef60a,_0x537659)=>{_0x341eba['hasChild'](_0x4ef60a)||_0x12a9c1['trackChildChange'](Ot(_0x4ef60a,_0x537659));}),_0x341eba['isLeafNode']()||_0x341eba['forEachChild'](R,(_0xb25297,_0x5216cb)=>{if(_0x2f69c['hasChild'](_0xb25297)){const _0x37dcf4=_0x2f69c['getImmediateChild'](_0xb25297);_0x37dcf4['equals'](_0x5216cb)||_0x12a9c1['trackChildChange'](Dt(_0xb25297,_0x5216cb,_0x37dcf4));}else _0x12a9c1['trackChildChange'](et(_0xb25297,_0x5216cb));})),_0x341eba['withIndex'](this['index_']);}['updatePriority'](_0x5cda29,_0xa6e78){return _0x5cda29['isEmpty']()?g['EMPTY_NODE']:_0x5cda29['updatePriority'](_0xa6e78);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x39d4df){this['indexedFilter_']=new Ji(_0x39d4df['getIndex']()),this['index_']=_0x39d4df['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x39d4df),this['endPost_']=Mt['getEndPost_'](_0x39d4df),this['startIsInclusive_']=!_0x39d4df['startAfterSet_'],this['endIsInclusive_']=!_0x39d4df['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x4ae980){const _0x22b5b4=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x4ae980)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x4ae980)<0x0,_0xef7b70=this['endIsInclusive_']?this['index_']['compare'](_0x4ae980,this['getEndPost']())<=0x0:this['index_']['compare'](_0x4ae980,this['getEndPost']())<0x0;return _0x22b5b4&&_0xef7b70;}['updateChild'](_0x2626ff,_0x721a3f,_0x1bab0a,_0x2225b3,_0x4563e8,_0x3f0750){return this['matches'](new E(_0x721a3f,_0x1bab0a))||(_0x1bab0a=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x2626ff,_0x721a3f,_0x1bab0a,_0x2225b3,_0x4563e8,_0x3f0750);}['updateFullNode'](_0x5cc581,_0x34d47a,_0xfda52f){_0x34d47a['isLeafNode']()&&(_0x34d47a=g['EMPTY_NODE']);let _0x3bea8e=_0x34d47a['withIndex'](this['index_']);_0x3bea8e=_0x3bea8e['updatePriority'](g['EMPTY_NODE']);const _0x5debbf=this;return _0x34d47a['forEachChild'](R,(_0x5d620c,_0x3dec22)=>{_0x5debbf['matches'](new E(_0x5d620c,_0x3dec22))||(_0x3bea8e=_0x3bea8e['updateImmediateChild'](_0x5d620c,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x5cc581,_0x3bea8e,_0xfda52f);}['updatePriority'](_0x2e2744,_0x3fadbc){return _0x2e2744;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x274bc5){if(_0x274bc5['hasStart']()){const _0x46a57d=_0x274bc5['getIndexStartName']();return _0x274bc5['getIndex']()['makePost'](_0x274bc5['getIndexStartValue'](),_0x46a57d);}else return _0x274bc5['getIndex']()['minPost']();}static['getEndPost_'](_0x2cc030){if(_0x2cc030['hasEnd']()){const _0x428998=_0x2cc030['getIndexEndName']();return _0x2cc030['getIndex']()['makePost'](_0x2cc030['getIndexEndValue'](),_0x428998);}else return _0x2cc030['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x36239f){this['withinDirectionalStart']=_0x49f56c=>this['reverse_']?this['withinEndPost'](_0x49f56c):this['withinStartPost'](_0x49f56c),this['withinDirectionalEnd']=_0x9105b7=>this['reverse_']?this['withinStartPost'](_0x9105b7):this['withinEndPost'](_0x9105b7),this['withinStartPost']=_0x335c07=>{const _0x22b308=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x335c07);return this['startIsInclusive_']?_0x22b308<=0x0:_0x22b308<0x0;},this['withinEndPost']=_0x3f5570=>{const _0x2a5ec1=this['index_']['compare'](_0x3f5570,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x2a5ec1<=0x0:_0x2a5ec1<0x0;},this['rangedFilter_']=new Mt(_0x36239f),this['index_']=_0x36239f['getIndex'](),this['limit_']=_0x36239f['getLimit'](),this['reverse_']=!_0x36239f['isViewFromLeft'](),this['startIsInclusive_']=!_0x36239f['startAfterSet_'],this['endIsInclusive_']=!_0x36239f['endBeforeSet_'];}['updateChild'](_0x13087f,_0x325c52,_0x4578dc,_0x4d3d87,_0x332172,_0x2366d7){return this['rangedFilter_']['matches'](new E(_0x325c52,_0x4578dc))||(_0x4578dc=g['EMPTY_NODE']),_0x13087f['getImmediateChild'](_0x325c52)['equals'](_0x4578dc)?_0x13087f:_0x13087f['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x13087f,_0x325c52,_0x4578dc,_0x4d3d87,_0x332172,_0x2366d7):this['fullLimitUpdateChild_'](_0x13087f,_0x325c52,_0x4578dc,_0x332172,_0x2366d7);}['updateFullNode'](_0x49432a,_0x1efb3c,_0x53d37b){let _0x434491;if(_0x1efb3c['isLeafNode']()||_0x1efb3c['isEmpty']())_0x434491=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x1efb3c['numChildren']()&&_0x1efb3c['isIndexed'](this['index_'])){_0x434491=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x5496ba;this['reverse_']?_0x5496ba=_0x1efb3c['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x5496ba=_0x1efb3c['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x4ca209=0x0;for(;_0x5496ba['hasNext']()&&_0x4ca209<this['limit_'];){const _0x43c2a5=_0x5496ba['getNext']();if(this['withinDirectionalStart'](_0x43c2a5)){if(this['withinDirectionalEnd'](_0x43c2a5))_0x434491=_0x434491['updateImmediateChild'](_0x43c2a5['name'],_0x43c2a5['node']),_0x4ca209++;else break;}else continue;}}else{_0x434491=_0x1efb3c['withIndex'](this['index_']),_0x434491=_0x434491['updatePriority'](g['EMPTY_NODE']);let _0x15d115;this['reverse_']?_0x15d115=_0x434491['getReverseIterator'](this['index_']):_0x15d115=_0x434491['getIterator'](this['index_']);let _0x21e13a=0x0;for(;_0x15d115['hasNext']();){const _0x44bebb=_0x15d115['getNext']();_0x21e13a<this['limit_']&&this['withinDirectionalStart'](_0x44bebb)&&this['withinDirectionalEnd'](_0x44bebb)?_0x21e13a++:_0x434491=_0x434491['updateImmediateChild'](_0x44bebb['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x49432a,_0x434491,_0x53d37b);}['updatePriority'](_0x8f9adb,_0x272094){return _0x8f9adb;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x3c57c9,_0x49a92e,_0x3e435f,_0x2ea1fa,_0x8daac){let _0x156fc9;if(this['reverse_']){const _0xafb1d6=this['index_']['getCompare']();_0x156fc9=(_0xc775b9,_0x1f9903)=>_0xafb1d6(_0x1f9903,_0xc775b9);}else _0x156fc9=this['index_']['getCompare']();const _0x48818d=_0x3c57c9;f(_0x48818d['numChildren']()===this['limit_'],'');const _0x15765f=new E(_0x49a92e,_0x3e435f),_0x189777=this['reverse_']?_0x48818d['getFirstChild'](this['index_']):_0x48818d['getLastChild'](this['index_']),_0x4df126=this['rangedFilter_']['matches'](_0x15765f);if(_0x48818d['hasChild'](_0x49a92e)){const _0x383c93=_0x48818d['getImmediateChild'](_0x49a92e);let _0x191ce8=_0x2ea1fa['getChildAfterChild'](this['index_'],_0x189777,this['reverse_']);for(;_0x191ce8!=null&&(_0x191ce8['name']===_0x49a92e||_0x48818d['hasChild'](_0x191ce8['name']));)_0x191ce8=_0x2ea1fa['getChildAfterChild'](this['index_'],_0x191ce8,this['reverse_']);const _0x37acc0=_0x191ce8==null?0x1:_0x156fc9(_0x191ce8,_0x15765f);if(_0x4df126&&!_0x3e435f['isEmpty']()&&_0x37acc0>=0x0)return _0x8daac!=null&&_0x8daac['trackChildChange'](Dt(_0x49a92e,_0x3e435f,_0x383c93)),_0x48818d['updateImmediateChild'](_0x49a92e,_0x3e435f);{_0x8daac!=null&&_0x8daac['trackChildChange'](Ot(_0x49a92e,_0x383c93));const _0xc821d7=_0x48818d['updateImmediateChild'](_0x49a92e,g['EMPTY_NODE']);return _0x191ce8!=null&&this['rangedFilter_']['matches'](_0x191ce8)?(_0x8daac!=null&&_0x8daac['trackChildChange'](et(_0x191ce8['name'],_0x191ce8['node'])),_0xc821d7['updateImmediateChild'](_0x191ce8['name'],_0x191ce8['node'])):_0xc821d7;}}else return _0x3e435f['isEmpty']()?_0x3c57c9:_0x4df126&&_0x156fc9(_0x189777,_0x15765f)>=0x0?(_0x8daac!=null&&(_0x8daac['trackChildChange'](Ot(_0x189777['name'],_0x189777['node'])),_0x8daac['trackChildChange'](et(_0x49a92e,_0x3e435f))),_0x48818d['updateImmediateChild'](_0x49a92e,_0x3e435f)['updateImmediateChild'](_0x189777['name'],g['EMPTY_NODE'])):_0x3c57c9;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x4f324c=new Xi();return _0x4f324c['limitSet_']=this['limitSet_'],_0x4f324c['limit_']=this['limit_'],_0x4f324c['startSet_']=this['startSet_'],_0x4f324c['startAfterSet_']=this['startAfterSet_'],_0x4f324c['indexStartValue_']=this['indexStartValue_'],_0x4f324c['startNameSet_']=this['startNameSet_'],_0x4f324c['indexStartName_']=this['indexStartName_'],_0x4f324c['endSet_']=this['endSet_'],_0x4f324c['endBeforeSet_']=this['endBeforeSet_'],_0x4f324c['indexEndValue_']=this['indexEndValue_'],_0x4f324c['endNameSet_']=this['endNameSet_'],_0x4f324c['indexEndName_']=this['indexEndName_'],_0x4f324c['index_']=this['index_'],_0x4f324c['viewFrom_']=this['viewFrom_'],_0x4f324c;}}function Kh(_0x3ff3b6){return _0x3ff3b6['loadsAllData']()?new Ji(_0x3ff3b6['getIndex']()):_0x3ff3b6['hasLimit']()?new jh(_0x3ff3b6):new Mt(_0x3ff3b6);}function Yh(_0x5b4ca4,_0x3712e6){const _0x4a3d6a=_0x5b4ca4['copy']();return _0x4a3d6a['limitSet_']=!0x0,_0x4a3d6a['limit_']=_0x3712e6,_0x4a3d6a['viewFrom_']='l',_0x4a3d6a;}function Qh(_0x3eb103,_0x136644,_0x439210){const _0x24caca=_0x3eb103['copy']();return _0x24caca['startSet_']=!0x0,_0x136644===void 0x0&&(_0x136644=null),_0x24caca['indexStartValue_']=_0x136644,_0x439210!=null?(_0x24caca['startNameSet_']=!0x0,_0x24caca['indexStartName_']=_0x439210):(_0x24caca['startNameSet_']=!0x1,_0x24caca['indexStartName_']=''),_0x24caca;}function Jh(_0x442e1a,_0x113a6f,_0x115b1d){const _0x5f0974=_0x442e1a['copy']();return _0x5f0974['endSet_']=!0x0,_0x113a6f===void 0x0&&(_0x113a6f=null),_0x5f0974['indexEndValue_']=_0x113a6f,_0x115b1d!==void 0x0?(_0x5f0974['endNameSet_']=!0x0,_0x5f0974['indexEndName_']=_0x115b1d):(_0x5f0974['endNameSet_']=!0x1,_0x5f0974['indexEndName_']=''),_0x5f0974;}function xo(_0x5374f0,_0x3de08d){const _0x28b87b=_0x5374f0['copy']();return _0x28b87b['index_']=_0x3de08d,_0x28b87b;}function sr(_0xe44c5b){const _0x925ed3={};if(_0xe44c5b['isDefault']())return _0x925ed3;let _0x1a9dc4;if(_0xe44c5b['index_']===R?_0x1a9dc4='$priority':_0xe44c5b['index_']===Mo?_0x1a9dc4='$value':_0xe44c5b['index_']===ye?_0x1a9dc4='$key':(f(_0xe44c5b['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x1a9dc4=_0xe44c5b['index_']['toString']()),_0x925ed3['orderBy']=O(_0x1a9dc4),_0xe44c5b['startSet_']){const _0x7fdad0=_0xe44c5b['startAfterSet_']?'startAfter':'startAt';_0x925ed3[_0x7fdad0]=O(_0xe44c5b['indexStartValue_']),_0xe44c5b['startNameSet_']&&(_0x925ed3[_0x7fdad0]+=','+O(_0xe44c5b['indexStartName_']));}if(_0xe44c5b['endSet_']){const _0x1e6734=_0xe44c5b['endBeforeSet_']?'endBefore':'endAt';_0x925ed3[_0x1e6734]=O(_0xe44c5b['indexEndValue_']),_0xe44c5b['endNameSet_']&&(_0x925ed3[_0x1e6734]+=','+O(_0xe44c5b['indexEndName_']));}return _0xe44c5b['limitSet_']&&(_0xe44c5b['isViewFromLeft']()?_0x925ed3['limitToFirst']=_0xe44c5b['limit_']:_0x925ed3['limitToLast']=_0xe44c5b['limit_']),_0x925ed3;}function rr(_0x2c762f){const _0x3b2704={};if(_0x2c762f['startSet_']&&(_0x3b2704['sp']=_0x2c762f['indexStartValue_'],_0x2c762f['startNameSet_']&&(_0x3b2704['sn']=_0x2c762f['indexStartName_']),_0x3b2704['sin']=!_0x2c762f['startAfterSet_']),_0x2c762f['endSet_']&&(_0x3b2704['ep']=_0x2c762f['indexEndValue_'],_0x2c762f['endNameSet_']&&(_0x3b2704['en']=_0x2c762f['indexEndName_']),_0x3b2704['ein']=!_0x2c762f['endBeforeSet_']),_0x2c762f['limitSet_']){_0x3b2704['l']=_0x2c762f['limit_'];let _0x40f424=_0x2c762f['viewFrom_'];_0x40f424===''&&(_0x2c762f['isViewFromLeft']()?_0x40f424='l':_0x40f424='r'),_0x3b2704['vf']=_0x40f424;}return _0x2c762f['index_']!==R&&(_0x3b2704['i']=_0x2c762f['index_']['toString']()),_0x3b2704;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x54296b){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x541a31,_0x5bf6ab){return _0x5bf6ab!==void 0x0?'tag$'+_0x5bf6ab:(f(_0x541a31['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x541a31['_path']['toString']());}constructor(_0x309063,_0x964f2e,_0x1bcf2d,_0x344488){super(),this['repoInfo_']=_0x309063,this['onDataUpdate_']=_0x964f2e,this['authTokenProvider_']=_0x1bcf2d,this['appCheckTokenProvider_']=_0x344488,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x2dc17a,_0x42c1ab,_0x51f6b2,_0x58ecf2){const _0x2f5a78=_0x2dc17a['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2f5a78+'\x20'+_0x2dc17a['_queryIdentifier']);const _0x231bfc=pn['getListenId_'](_0x2dc17a,_0x51f6b2),_0x4877a4={};this['listens_'][_0x231bfc]=_0x4877a4;const _0x366332=sr(_0x2dc17a['_queryParams']);this['restRequest_'](_0x2f5a78+'.json',_0x366332,(_0x9a80ef,_0x1b343f)=>{let _0x3140f5=_0x1b343f;if(_0x9a80ef===0x194&&(_0x3140f5=null,_0x9a80ef=null),_0x9a80ef===null&&this['onDataUpdate_'](_0x2f5a78,_0x3140f5,!0x1,_0x51f6b2),De(this['listens_'],_0x231bfc)===_0x4877a4){let _0x1413a7;_0x9a80ef?_0x9a80ef===0x191?_0x1413a7='permission_denied':_0x1413a7='rest_error:'+_0x9a80ef:_0x1413a7='ok',_0x58ecf2(_0x1413a7,null);}});}['unlisten'](_0x16129b,_0x248391){const _0x2b7350=pn['getListenId_'](_0x16129b,_0x248391);delete this['listens_'][_0x2b7350];}['get'](_0x27b3c4){const _0x310063=sr(_0x27b3c4['_queryParams']),_0x2209a3=_0x27b3c4['_path']['toString'](),_0x5a7495=new ot();return this['restRequest_'](_0x2209a3+'.json',_0x310063,(_0x59a5f8,_0x24fa66)=>{let _0x3cf1f3=_0x24fa66;_0x59a5f8===0x194&&(_0x3cf1f3=null,_0x59a5f8=null),_0x59a5f8===null?(this['onDataUpdate_'](_0x2209a3,_0x3cf1f3,!0x1,null),_0x5a7495['resolve'](_0x3cf1f3)):_0x5a7495['reject'](new Error(_0x3cf1f3));}),_0x5a7495['promise'];}['refreshAuthToken'](_0x17fdcc){}['restRequest_'](_0x662c4c,_0x3257c9={},_0x2f0d76){return _0x3257c9['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x47f057,_0x1d6706])=>{_0x47f057&&_0x47f057['accessToken']&&(_0x3257c9['auth']=_0x47f057['accessToken']),_0x1d6706&&_0x1d6706['token']&&(_0x3257c9['ac']=_0x1d6706['token']);const _0x9073bb=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x662c4c+'?ns='+this['repoInfo_']['namespace']+ct(_0x3257c9);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x9073bb);const _0x4a7567=new XMLHttpRequest();_0x4a7567['onreadystatechange']=()=>{if(_0x2f0d76&&_0x4a7567['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x9073bb+'\x20received.\x20status:',_0x4a7567['status'],'response:',_0x4a7567['responseText']);let _0x1bcd53=null;if(_0x4a7567['status']>=0xc8&&_0x4a7567['status']<0x12c){try{_0x1bcd53=At(_0x4a7567['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x9073bb+':\x20'+_0x4a7567['responseText']);}_0x2f0d76(null,_0x1bcd53);}else _0x4a7567['status']!==0x191&&_0x4a7567['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x9073bb+'\x20Status:\x20'+_0x4a7567['status']),_0x2f0d76(_0x4a7567['status']);_0x2f0d76=null;}},_0x4a7567['open']('GET',_0x9073bb,!0x0),_0x4a7567['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x17e9aa){return this['rootNode_']['getChild'](_0x17e9aa);}['updateSnapshot'](_0x354070,_0x547ecf){this['rootNode_']=this['rootNode_']['updateChild'](_0x354070,_0x547ecf);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x2dee7f,_0x20ce72,_0x475eea){if(v(_0x20ce72))_0x2dee7f['value']=_0x475eea,_0x2dee7f['children']['clear']();else{if(_0x2dee7f['value']!==null)_0x2dee7f['value']=_0x2dee7f['value']['updateChild'](_0x20ce72,_0x475eea);else{const _0x47a6bb=y(_0x20ce72);_0x2dee7f['children']['has'](_0x47a6bb)||_0x2dee7f['children']['set'](_0x47a6bb,_n());const _0x2826ab=_0x2dee7f['children']['get'](_0x47a6bb);_0x20ce72=b(_0x20ce72),Fo(_0x2826ab,_0x20ce72,_0x475eea);}}}function Ii(_0x343cd3,_0x1898c5,_0x1192ad){_0x343cd3['value']!==null?_0x1192ad(_0x1898c5,_0x343cd3['value']):Zh(_0x343cd3,(_0x21519a,_0x521c42)=>{const _0x59c5b6=new C(_0x1898c5['toString']()+'/'+_0x21519a);Ii(_0x521c42,_0x59c5b6,_0x1192ad);});}function Zh(_0x2fbabc,_0x90ba80){_0x2fbabc['children']['forEach']((_0x9cd6eb,_0x5185c8)=>{_0x90ba80(_0x5185c8,_0x9cd6eb);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x110c3b){this['collection_']=_0x110c3b,this['last_']=null;}['get'](){const _0x180363=this['collection_']['get'](),_0x130354={..._0x180363};return this['last_']&&x(this['last_'],(_0x1d3be9,_0x5cd292)=>{_0x130354[_0x1d3be9]=_0x130354[_0x1d3be9]-_0x5cd292;}),this['last_']=_0x180363,_0x130354;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x2e5bb6,_0x696deb){this['server_']=_0x696deb,this['statsToReport_']={},this['statsListener_']=new eu(_0x2e5bb6);const _0x3904be=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x3904be));}['reportStats_'](){const _0x1d7720=this['statsListener_']['get'](),_0xf58660={};let _0x739c75=!0x1;x(_0x1d7720,(_0x4ff3fb,_0x2391c2)=>{_0x2391c2>0x0&&J(this['statsToReport_'],_0x4ff3fb)&&(_0xf58660[_0x4ff3fb]=_0x2391c2,_0x739c75=!0x0);}),_0x739c75&&this['server_']['reportStats'](_0xf58660),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x3ee7ab){_0x3ee7ab[_0x3ee7ab['OVERWRITE']=0x0]='OVERWRITE',_0x3ee7ab[_0x3ee7ab['MERGE']=0x1]='MERGE',_0x3ee7ab[_0x3ee7ab['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x3ee7ab[_0x3ee7ab['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x543d54){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x543d54,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0xff667c,_0x2e6780,_0x163114){this['path']=_0xff667c,this['affectedTree']=_0x2e6780,this['revert']=_0x163114,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x2af5c8){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x5388fe=this['affectedTree']['subtree'](new C(_0x2af5c8));return new gn(w(),_0x5388fe,this['revert']);}}else return f(y(this['path'])===_0x2af5c8,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x131477,_0xf8b695){this['source']=_0x131477,this['path']=_0xf8b695,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0xc68b50){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x4b3386,_0x2d52f2,_0x564790){this['source']=_0x4b3386,this['path']=_0x2d52f2,this['snap']=_0x564790,this['type']=j['OVERWRITE'];}['operationForChild'](_0x498728){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x498728)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x322ee4,_0x3f5778,_0x759f98){this['source']=_0x322ee4,this['path']=_0x3f5778,this['children']=_0x759f98,this['type']=j['MERGE'];}['operationForChild'](_0x9b930e){if(v(this['path'])){const _0x4113b4=this['children']['subtree'](new C(_0x9b930e));return _0x4113b4['isEmpty']()?null:_0x4113b4['value']?new Ue(this['source'],w(),_0x4113b4['value']):new tt(this['source'],w(),_0x4113b4);}else return f(y(this['path'])===_0x9b930e,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x50d06a,_0x50dfe9,_0x18e7c2){this['node_']=_0x50d06a,this['fullyInitialized_']=_0x50dfe9,this['filtered_']=_0x18e7c2;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x315bd4){if(v(_0x315bd4))return this['isFullyInitialized']()&&!this['filtered_'];const _0x4eebcb=y(_0x315bd4);return this['isCompleteForChild'](_0x4eebcb);}['isCompleteForChild'](_0x1418ab){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x1418ab);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x16f40d){this['query_']=_0x16f40d,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x5f5b22,_0x407e72,_0x876aa6,_0x1b90fe){const _0x2b042a=[],_0x570855=[];return _0x407e72['forEach'](_0x2818c6=>{_0x2818c6['type']==='child_changed'&&_0x5f5b22['index_']['indexedValueChanged'](_0x2818c6['oldSnap'],_0x2818c6['snapshotNode'])&&_0x570855['push'](zh(_0x2818c6['childName'],_0x2818c6['snapshotNode']));}),yt(_0x5f5b22,_0x2b042a,'child_removed',_0x407e72,_0x1b90fe,_0x876aa6),yt(_0x5f5b22,_0x2b042a,'child_added',_0x407e72,_0x1b90fe,_0x876aa6),yt(_0x5f5b22,_0x2b042a,'child_moved',_0x570855,_0x1b90fe,_0x876aa6),yt(_0x5f5b22,_0x2b042a,'child_changed',_0x407e72,_0x1b90fe,_0x876aa6),yt(_0x5f5b22,_0x2b042a,'value',_0x407e72,_0x1b90fe,_0x876aa6),_0x2b042a;}function yt(_0x5745fa,_0x353259,_0x22f0fb,_0x32b67e,_0x2f9044,_0x2e2dbf){const _0x9dacb4=_0x32b67e['filter'](_0x503a18=>_0x503a18['type']===_0x22f0fb);_0x9dacb4['sort']((_0x5c90bc,_0x2c6e56)=>au(_0x5745fa,_0x5c90bc,_0x2c6e56)),_0x9dacb4['forEach'](_0xaf7733=>{const _0x5df800=ou(_0x5745fa,_0xaf7733,_0x2e2dbf);_0x2f9044['forEach'](_0x4a55e0=>{_0x4a55e0['respondsTo'](_0xaf7733['type'])&&_0x353259['push'](_0x4a55e0['createEvent'](_0x5df800,_0x5745fa['query_']));});});}function ou(_0x12c86c,_0x1322d1,_0x1cd1b6){return _0x1322d1['type']==='value'||_0x1322d1['type']==='child_removed'||(_0x1322d1['prevName']=_0x1cd1b6['getPredecessorChildName'](_0x1322d1['childName'],_0x1322d1['snapshotNode'],_0x12c86c['index_'])),_0x1322d1;}function au(_0xc6ecd2,_0x541a1e,_0x8a30c8){if(_0x541a1e['childName']==null||_0x8a30c8['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0xee0488=new E(_0x541a1e['childName'],_0x541a1e['snapshotNode']),_0x17a4e1=new E(_0x8a30c8['childName'],_0x8a30c8['snapshotNode']);return _0xc6ecd2['index_']['compare'](_0xee0488,_0x17a4e1);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x32ca7b,_0x38dc82){return{'eventCache':_0x32ca7b,'serverCache':_0x38dc82};}function Tt(_0x1b5350,_0x3156e5,_0xc9161e,_0x5bc731){return Mn(new Ce(_0x3156e5,_0xc9161e,_0x5bc731),_0x1b5350['serverCache']);}function Uo(_0x50b0a1,_0x508bd0,_0x52e800,_0x5c8763){return Mn(_0x50b0a1['eventCache'],new Ce(_0x508bd0,_0x52e800,_0x5c8763));}function mn(_0x1591df){return _0x1591df['eventCache']['isFullyInitialized']()?_0x1591df['eventCache']['getNode']():null;}function We(_0x957767){return _0x957767['serverCache']['isFullyInitialized']()?_0x957767['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x26b62c){let _0x585c2d=new S(null);return x(_0x26b62c,(_0x1bf87c,_0x32201c)=>{_0x585c2d=_0x585c2d['set'](new C(_0x1bf87c),_0x32201c);}),_0x585c2d;}constructor(_0x469920,_0x495a37=cu()){this['value']=_0x469920,this['children']=_0x495a37;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x3b9c3e,_0x5607c9){if(this['value']!=null&&_0x5607c9(this['value']))return{'path':w(),'value':this['value']};if(v(_0x3b9c3e))return null;{const _0x2f8886=y(_0x3b9c3e),_0x35c6bc=this['children']['get'](_0x2f8886);if(_0x35c6bc!==null){const _0x1f12ee=_0x35c6bc['findRootMostMatchingPathAndValue'](b(_0x3b9c3e),_0x5607c9);return _0x1f12ee!=null?{'path':k(new C(_0x2f8886),_0x1f12ee['path']),'value':_0x1f12ee['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x8d8fbf){return this['findRootMostMatchingPathAndValue'](_0x8d8fbf,()=>!0x0);}['subtree'](_0x4be2c1){if(v(_0x4be2c1))return this;{const _0x4db218=y(_0x4be2c1),_0x549e8a=this['children']['get'](_0x4db218);return _0x549e8a!==null?_0x549e8a['subtree'](b(_0x4be2c1)):new S(null);}}['set'](_0x256f4b,_0x53af54){if(v(_0x256f4b))return new S(_0x53af54,this['children']);{const _0x3b0a0b=y(_0x256f4b),_0x39405b=(this['children']['get'](_0x3b0a0b)||new S(null))['set'](b(_0x256f4b),_0x53af54),_0x9877cc=this['children']['insert'](_0x3b0a0b,_0x39405b);return new S(this['value'],_0x9877cc);}}['remove'](_0x16e735){if(v(_0x16e735))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x5be272=y(_0x16e735),_0x1f81d2=this['children']['get'](_0x5be272);if(_0x1f81d2){const _0x25cccd=_0x1f81d2['remove'](b(_0x16e735));let _0x18a413;return _0x25cccd['isEmpty']()?_0x18a413=this['children']['remove'](_0x5be272):_0x18a413=this['children']['insert'](_0x5be272,_0x25cccd),this['value']===null&&_0x18a413['isEmpty']()?new S(null):new S(this['value'],_0x18a413);}else return this;}}['get'](_0x4c24f4){if(v(_0x4c24f4))return this['value'];{const _0x366c02=y(_0x4c24f4),_0xa9cd75=this['children']['get'](_0x366c02);return _0xa9cd75?_0xa9cd75['get'](b(_0x4c24f4)):null;}}['setTree'](_0x361524,_0x54b63f){if(v(_0x361524))return _0x54b63f;{const _0x5a2d8d=y(_0x361524),_0x34d5bd=(this['children']['get'](_0x5a2d8d)||new S(null))['setTree'](b(_0x361524),_0x54b63f);let _0x4f3e3e;return _0x34d5bd['isEmpty']()?_0x4f3e3e=this['children']['remove'](_0x5a2d8d):_0x4f3e3e=this['children']['insert'](_0x5a2d8d,_0x34d5bd),new S(this['value'],_0x4f3e3e);}}['fold'](_0xb25232){return this['fold_'](w(),_0xb25232);}['fold_'](_0x1df540,_0x1e1f56){const _0x1d5076={};return this['children']['inorderTraversal']((_0xd8266c,_0x5731cb)=>{_0x1d5076[_0xd8266c]=_0x5731cb['fold_'](k(_0x1df540,_0xd8266c),_0x1e1f56);}),_0x1e1f56(_0x1df540,this['value'],_0x1d5076);}['findOnPath'](_0x43f155,_0x565294){return this['findOnPath_'](_0x43f155,w(),_0x565294);}['findOnPath_'](_0x54cd95,_0x5b0c22,_0x406798){const _0x5a15d8=this['value']?_0x406798(_0x5b0c22,this['value']):!0x1;if(_0x5a15d8)return _0x5a15d8;if(v(_0x54cd95))return null;{const _0x3a1011=y(_0x54cd95),_0x3d3f44=this['children']['get'](_0x3a1011);return _0x3d3f44?_0x3d3f44['findOnPath_'](b(_0x54cd95),k(_0x5b0c22,_0x3a1011),_0x406798):null;}}['foreachOnPath'](_0x3dc6ce,_0x4b7a70){return this['foreachOnPath_'](_0x3dc6ce,w(),_0x4b7a70);}['foreachOnPath_'](_0x1a2d91,_0x1574b0,_0x4a674b){if(v(_0x1a2d91))return this;{this['value']&&_0x4a674b(_0x1574b0,this['value']);const _0x1d3822=y(_0x1a2d91),_0x8f0e9a=this['children']['get'](_0x1d3822);return _0x8f0e9a?_0x8f0e9a['foreachOnPath_'](b(_0x1a2d91),k(_0x1574b0,_0x1d3822),_0x4a674b):new S(null);}}['foreach'](_0x2d15d9){this['foreach_'](w(),_0x2d15d9);}['foreach_'](_0x43aac0,_0x22c9f8){this['children']['inorderTraversal']((_0x3bb651,_0x115ec6)=>{_0x115ec6['foreach_'](k(_0x43aac0,_0x3bb651),_0x22c9f8);}),this['value']&&_0x22c9f8(_0x43aac0,this['value']);}['foreachChild'](_0x1cfedd){this['children']['inorderTraversal']((_0x3f6766,_0x8d2f19)=>{_0x8d2f19['value']&&_0x1cfedd(_0x3f6766,_0x8d2f19['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x217ffb){this['writeTree_']=_0x217ffb;}static['empty'](){return new Y(new S(null));}}function St(_0x47587a,_0x5a661a,_0x4d0723){if(v(_0x5a661a))return new Y(new S(_0x4d0723));{const _0x385d42=_0x47587a['writeTree_']['findRootMostValueAndPath'](_0x5a661a);if(_0x385d42!=null){const _0xcbb646=_0x385d42['path'];let _0x553dcc=_0x385d42['value'];const _0xcacef=F(_0xcbb646,_0x5a661a);return _0x553dcc=_0x553dcc['updateChild'](_0xcacef,_0x4d0723),new Y(_0x47587a['writeTree_']['set'](_0xcbb646,_0x553dcc));}else{const _0x58887e=new S(_0x4d0723),_0x45857f=_0x47587a['writeTree_']['setTree'](_0x5a661a,_0x58887e);return new Y(_0x45857f);}}}function wi(_0x2a4e59,_0x2c4d97,_0x3655af){let _0x4ed694=_0x2a4e59;return x(_0x3655af,(_0x3fcad5,_0x15e6f3)=>{_0x4ed694=St(_0x4ed694,k(_0x2c4d97,_0x3fcad5),_0x15e6f3);}),_0x4ed694;}function ar(_0x5d0cc5,_0x39b5df){if(v(_0x39b5df))return Y['empty']();{const _0x418052=_0x5d0cc5['writeTree_']['setTree'](_0x39b5df,new S(null));return new Y(_0x418052);}}function Ci(_0x1402b0,_0x1b32a1){return $e(_0x1402b0,_0x1b32a1)!=null;}function $e(_0x2ef926,_0x2a24f0){const _0x3cc140=_0x2ef926['writeTree_']['findRootMostValueAndPath'](_0x2a24f0);return _0x3cc140!=null?_0x2ef926['writeTree_']['get'](_0x3cc140['path'])['getChild'](F(_0x3cc140['path'],_0x2a24f0)):null;}function cr(_0x239b3a){const _0x4ada35=[],_0x2218f5=_0x239b3a['writeTree_']['value'];return _0x2218f5!=null?_0x2218f5['isLeafNode']()||_0x2218f5['forEachChild'](R,(_0x27e105,_0x10e8ff)=>{_0x4ada35['push'](new E(_0x27e105,_0x10e8ff));}):_0x239b3a['writeTree_']['children']['inorderTraversal']((_0x191555,_0x29a3a6)=>{_0x29a3a6['value']!=null&&_0x4ada35['push'](new E(_0x191555,_0x29a3a6['value']));}),_0x4ada35;}function ve(_0x363bf7,_0x29d446){if(v(_0x29d446))return _0x363bf7;{const _0x1de286=$e(_0x363bf7,_0x29d446);return _0x1de286!=null?new Y(new S(_0x1de286)):new Y(_0x363bf7['writeTree_']['subtree'](_0x29d446));}}function Ti(_0x2fcd19){return _0x2fcd19['writeTree_']['isEmpty']();}function nt(_0x25cc2b,_0x2095b9){return Wo(w(),_0x25cc2b['writeTree_'],_0x2095b9);}function Wo(_0x478b02,_0x4b4edd,_0x14e5d1){if(_0x4b4edd['value']!=null)return _0x14e5d1['updateChild'](_0x478b02,_0x4b4edd['value']);{let _0x133adb=null;return _0x4b4edd['children']['inorderTraversal']((_0x5440ff,_0x1f0a37)=>{_0x5440ff==='.priority'?(f(_0x1f0a37['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x133adb=_0x1f0a37['value']):_0x14e5d1=Wo(k(_0x478b02,_0x5440ff),_0x1f0a37,_0x14e5d1);}),!_0x14e5d1['getChild'](_0x478b02)['isEmpty']()&&_0x133adb!==null&&(_0x14e5d1=_0x14e5d1['updateChild'](k(_0x478b02,'.priority'),_0x133adb)),_0x14e5d1;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x3f0dde,_0x5b23e0){return $o(_0x5b23e0,_0x3f0dde);}function lu(_0xe17234,_0x5d8394,_0x237970,_0x3e44c5,_0x180964){f(_0x3e44c5>_0xe17234['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x180964===void 0x0&&(_0x180964=!0x0),_0xe17234['allWrites']['push']({'path':_0x5d8394,'snap':_0x237970,'writeId':_0x3e44c5,'visible':_0x180964}),_0x180964&&(_0xe17234['visibleWrites']=St(_0xe17234['visibleWrites'],_0x5d8394,_0x237970)),_0xe17234['lastWriteId']=_0x3e44c5;}function hu(_0x1161e0,_0x5e44e3,_0x8fce1c,_0x22c546){f(_0x22c546>_0x1161e0['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x1161e0['allWrites']['push']({'path':_0x5e44e3,'children':_0x8fce1c,'writeId':_0x22c546,'visible':!0x0}),_0x1161e0['visibleWrites']=wi(_0x1161e0['visibleWrites'],_0x5e44e3,_0x8fce1c),_0x1161e0['lastWriteId']=_0x22c546;}function uu(_0x4f532f,_0xf4999){for(let _0x2a0eb0=0x0;_0x2a0eb0<_0x4f532f['allWrites']['length'];_0x2a0eb0++){const _0x3c1313=_0x4f532f['allWrites'][_0x2a0eb0];if(_0x3c1313['writeId']===_0xf4999)return _0x3c1313;}return null;}function du(_0x4d66f4,_0x5d31d5){const _0x12c5a7=_0x4d66f4['allWrites']['findIndex'](_0xad035=>_0xad035['writeId']===_0x5d31d5);f(_0x12c5a7>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x3ff406=_0x4d66f4['allWrites'][_0x12c5a7];_0x4d66f4['allWrites']['splice'](_0x12c5a7,0x1);let _0xf057ae=_0x3ff406['visible'],_0x3c67f6=!0x1,_0x4df3af=_0x4d66f4['allWrites']['length']-0x1;for(;_0xf057ae&&_0x4df3af>=0x0;){const _0x192368=_0x4d66f4['allWrites'][_0x4df3af];_0x192368['visible']&&(_0x4df3af>=_0x12c5a7&&fu(_0x192368,_0x3ff406['path'])?_0xf057ae=!0x1:G(_0x3ff406['path'],_0x192368['path'])&&(_0x3c67f6=!0x0)),_0x4df3af--;}if(_0xf057ae){if(_0x3c67f6)return pu(_0x4d66f4),!0x0;if(_0x3ff406['snap'])_0x4d66f4['visibleWrites']=ar(_0x4d66f4['visibleWrites'],_0x3ff406['path']);else{const _0x2cae79=_0x3ff406['children'];x(_0x2cae79,_0x15d135=>{_0x4d66f4['visibleWrites']=ar(_0x4d66f4['visibleWrites'],k(_0x3ff406['path'],_0x15d135));});}return!0x0;}else return!0x1;}function fu(_0x1b2724,_0x1d9db6){if(_0x1b2724['snap'])return G(_0x1b2724['path'],_0x1d9db6);for(const _0x4668bb in _0x1b2724['children'])if(_0x1b2724['children']['hasOwnProperty'](_0x4668bb)&&G(k(_0x1b2724['path'],_0x4668bb),_0x1d9db6))return!0x0;return!0x1;}function pu(_0x4ee720){_0x4ee720['visibleWrites']=Bo(_0x4ee720['allWrites'],_u,w()),_0x4ee720['allWrites']['length']>0x0?_0x4ee720['lastWriteId']=_0x4ee720['allWrites'][_0x4ee720['allWrites']['length']-0x1]['writeId']:_0x4ee720['lastWriteId']=-0x1;}function _u(_0x28029a){return _0x28029a['visible'];}function Bo(_0x17709f,_0x1945dd,_0x22c126){let _0x53b369=Y['empty']();for(let _0x5e9b54=0x0;_0x5e9b54<_0x17709f['length'];++_0x5e9b54){const _0x188aaf=_0x17709f[_0x5e9b54];if(_0x1945dd(_0x188aaf)){const _0x2ded70=_0x188aaf['path'];let _0xe18ca2;if(_0x188aaf['snap'])G(_0x22c126,_0x2ded70)?(_0xe18ca2=F(_0x22c126,_0x2ded70),_0x53b369=St(_0x53b369,_0xe18ca2,_0x188aaf['snap'])):G(_0x2ded70,_0x22c126)&&(_0xe18ca2=F(_0x2ded70,_0x22c126),_0x53b369=St(_0x53b369,w(),_0x188aaf['snap']['getChild'](_0xe18ca2)));else{if(_0x188aaf['children']){if(G(_0x22c126,_0x2ded70))_0xe18ca2=F(_0x22c126,_0x2ded70),_0x53b369=wi(_0x53b369,_0xe18ca2,_0x188aaf['children']);else{if(G(_0x2ded70,_0x22c126)){if(_0xe18ca2=F(_0x2ded70,_0x22c126),v(_0xe18ca2))_0x53b369=wi(_0x53b369,w(),_0x188aaf['children']);else{const _0x5ba814=De(_0x188aaf['children'],y(_0xe18ca2));if(_0x5ba814){const _0x7efc2e=_0x5ba814['getChild'](b(_0xe18ca2));_0x53b369=St(_0x53b369,w(),_0x7efc2e);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x53b369;}function Vo(_0x39702d,_0x4d6f0d,_0x7c641a,_0x2b062c,_0x192c17){if(!_0x2b062c&&!_0x192c17){const _0x39fb30=$e(_0x39702d['visibleWrites'],_0x4d6f0d);if(_0x39fb30!=null)return _0x39fb30;{const _0x3cf9d0=ve(_0x39702d['visibleWrites'],_0x4d6f0d);if(Ti(_0x3cf9d0))return _0x7c641a;if(_0x7c641a==null&&!Ci(_0x3cf9d0,w()))return null;{const _0x48d578=_0x7c641a||g['EMPTY_NODE'];return nt(_0x3cf9d0,_0x48d578);}}}else{const _0x45fd1c=ve(_0x39702d['visibleWrites'],_0x4d6f0d);if(!_0x192c17&&Ti(_0x45fd1c))return _0x7c641a;if(!_0x192c17&&_0x7c641a==null&&!Ci(_0x45fd1c,w()))return null;{const _0x3591c2=function(_0x29e091){return(_0x29e091['visible']||_0x192c17)&&(!_0x2b062c||!~_0x2b062c['indexOf'](_0x29e091['writeId']))&&(G(_0x29e091['path'],_0x4d6f0d)||G(_0x4d6f0d,_0x29e091['path']));},_0x1d8f69=Bo(_0x39702d['allWrites'],_0x3591c2,_0x4d6f0d),_0x3bf263=_0x7c641a||g['EMPTY_NODE'];return nt(_0x1d8f69,_0x3bf263);}}}function gu(_0xb3d0d5,_0x1ef3f0,_0xb3f07f){let _0x316716=g['EMPTY_NODE'];const _0x4c121e=$e(_0xb3d0d5['visibleWrites'],_0x1ef3f0);if(_0x4c121e)return _0x4c121e['isLeafNode']()||_0x4c121e['forEachChild'](R,(_0x798cd9,_0x22cf2d)=>{_0x316716=_0x316716['updateImmediateChild'](_0x798cd9,_0x22cf2d);}),_0x316716;if(_0xb3f07f){const _0x464807=ve(_0xb3d0d5['visibleWrites'],_0x1ef3f0);return _0xb3f07f['forEachChild'](R,(_0x475cb1,_0xa7da97)=>{const _0x3861ae=nt(ve(_0x464807,new C(_0x475cb1)),_0xa7da97);_0x316716=_0x316716['updateImmediateChild'](_0x475cb1,_0x3861ae);}),cr(_0x464807)['forEach'](_0x4778cf=>{_0x316716=_0x316716['updateImmediateChild'](_0x4778cf['name'],_0x4778cf['node']);}),_0x316716;}else{const _0x5cb312=ve(_0xb3d0d5['visibleWrites'],_0x1ef3f0);return cr(_0x5cb312)['forEach'](_0x450bf1=>{_0x316716=_0x316716['updateImmediateChild'](_0x450bf1['name'],_0x450bf1['node']);}),_0x316716;}}function mu(_0x4015e2,_0x453a12,_0x180339,_0x50cb7e,_0xd3735d){f(_0x50cb7e||_0xd3735d,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x2471df=k(_0x453a12,_0x180339);if(Ci(_0x4015e2['visibleWrites'],_0x2471df))return null;{const _0x10b157=ve(_0x4015e2['visibleWrites'],_0x2471df);return Ti(_0x10b157)?_0xd3735d['getChild'](_0x180339):nt(_0x10b157,_0xd3735d['getChild'](_0x180339));}}function yu(_0x5a4bc2,_0x52d449,_0x2f6c05,_0x14c8d2){const _0x45b95a=k(_0x52d449,_0x2f6c05),_0x3e3f85=$e(_0x5a4bc2['visibleWrites'],_0x45b95a);if(_0x3e3f85!=null)return _0x3e3f85;if(_0x14c8d2['isCompleteForChild'](_0x2f6c05)){const _0x5192d9=ve(_0x5a4bc2['visibleWrites'],_0x45b95a);return nt(_0x5192d9,_0x14c8d2['getNode']()['getImmediateChild'](_0x2f6c05));}else return null;}function vu(_0x3ca7f6,_0x346f61){return $e(_0x3ca7f6['visibleWrites'],_0x346f61);}function Eu(_0x3b732e,_0x20d6f3,_0x30ff2c,_0x4ec2bc,_0x266d14,_0x305616,_0x38ce3f){let _0x51301c;const _0x2f9db0=ve(_0x3b732e['visibleWrites'],_0x20d6f3),_0x27d8c6=$e(_0x2f9db0,w());if(_0x27d8c6!=null)_0x51301c=_0x27d8c6;else{if(_0x30ff2c!=null)_0x51301c=nt(_0x2f9db0,_0x30ff2c);else return[];}if(_0x51301c=_0x51301c['withIndex'](_0x38ce3f),!_0x51301c['isEmpty']()&&!_0x51301c['isLeafNode']()){const _0xcbb306=[],_0x2cab4b=_0x38ce3f['getCompare'](),_0x93d03d=_0x305616?_0x51301c['getReverseIteratorFrom'](_0x4ec2bc,_0x38ce3f):_0x51301c['getIteratorFrom'](_0x4ec2bc,_0x38ce3f);let _0x420d88=_0x93d03d['getNext']();for(;_0x420d88&&_0xcbb306['length']<_0x266d14;)_0x2cab4b(_0x420d88,_0x4ec2bc)!==0x0&&_0xcbb306['push'](_0x420d88),_0x420d88=_0x93d03d['getNext']();return _0xcbb306;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x22965e,_0x534655,_0x2d17bc,_0x588cff){return Vo(_0x22965e['writeTree'],_0x22965e['treePath'],_0x534655,_0x2d17bc,_0x588cff);}function ns(_0x36dd05,_0x220870){return gu(_0x36dd05['writeTree'],_0x36dd05['treePath'],_0x220870);}function lr(_0x2e0c58,_0x251c63,_0x2c3f57,_0x224a2a){return mu(_0x2e0c58['writeTree'],_0x2e0c58['treePath'],_0x251c63,_0x2c3f57,_0x224a2a);}function vn(_0x11f8c3,_0x43c2a9){return vu(_0x11f8c3['writeTree'],k(_0x11f8c3['treePath'],_0x43c2a9));}function wu(_0x29f426,_0x27f3be,_0x2c5f60,_0x25770d,_0x4e9154,_0xa5feaf){return Eu(_0x29f426['writeTree'],_0x29f426['treePath'],_0x27f3be,_0x2c5f60,_0x25770d,_0x4e9154,_0xa5feaf);}function is(_0x3e456a,_0x23c834,_0x41f934){return yu(_0x3e456a['writeTree'],_0x3e456a['treePath'],_0x23c834,_0x41f934);}function Ho(_0x1114b6,_0x50c0d1){return $o(k(_0x1114b6['treePath'],_0x50c0d1),_0x1114b6['writeTree']);}function $o(_0x171244,_0x295d5b){return{'treePath':_0x171244,'writeTree':_0x295d5b};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x24f246){const _0x48fe83=_0x24f246['type'],_0x4e2256=_0x24f246['childName'];f(_0x48fe83==='child_added'||_0x48fe83==='child_changed'||_0x48fe83==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x4e2256!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x25a883=this['changeMap']['get'](_0x4e2256);if(_0x25a883){const _0x4826dd=_0x25a883['type'];if(_0x48fe83==='child_added'&&_0x4826dd==='child_removed')this['changeMap']['set'](_0x4e2256,Dt(_0x4e2256,_0x24f246['snapshotNode'],_0x25a883['snapshotNode']));else{if(_0x48fe83==='child_removed'&&_0x4826dd==='child_added')this['changeMap']['delete'](_0x4e2256);else{if(_0x48fe83==='child_removed'&&_0x4826dd==='child_changed')this['changeMap']['set'](_0x4e2256,Ot(_0x4e2256,_0x25a883['oldSnap']));else{if(_0x48fe83==='child_changed'&&_0x4826dd==='child_added')this['changeMap']['set'](_0x4e2256,et(_0x4e2256,_0x24f246['snapshotNode']));else{if(_0x48fe83==='child_changed'&&_0x4826dd==='child_changed')this['changeMap']['set'](_0x4e2256,Dt(_0x4e2256,_0x24f246['snapshotNode'],_0x25a883['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x24f246+'\x20occurred\x20after\x20'+_0x25a883);}}}}}else this['changeMap']['set'](_0x4e2256,_0x24f246);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x5aab9a){return null;}['getChildAfterChild'](_0x20232e,_0x4eb445,_0x550984){return null;}}const Go=new Tu();class ss{constructor(_0x735e86,_0x4d0db7,_0x244a90=null){this['writes_']=_0x735e86,this['viewCache_']=_0x4d0db7,this['optCompleteServerCache_']=_0x244a90;}['getCompleteChild'](_0x4d7a40){const _0x1876d8=this['viewCache_']['eventCache'];if(_0x1876d8['isCompleteForChild'](_0x4d7a40))return _0x1876d8['getNode']()['getImmediateChild'](_0x4d7a40);{const _0x17db3a=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x4d7a40,_0x17db3a);}}['getChildAfterChild'](_0x37602b,_0x4a1c7a,_0xf51ad7){const _0x13010c=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x5a5b3c=wu(this['writes_'],_0x13010c,_0x4a1c7a,0x1,_0xf51ad7,_0x37602b);return _0x5a5b3c['length']===0x0?null:_0x5a5b3c[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x39c4b2){return{'filter':_0x39c4b2};}function bu(_0x47fe7e,_0xf7d1ba){f(_0xf7d1ba['eventCache']['getNode']()['isIndexed'](_0x47fe7e['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0xf7d1ba['serverCache']['getNode']()['isIndexed'](_0x47fe7e['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x46a0bc,_0x28106f,_0x31a177,_0x3181d4,_0x147e1e){const _0x3b1dd0=new Cu();let _0x3389b6,_0x138166;if(_0x31a177['type']===j['OVERWRITE']){const _0x502596=_0x31a177;_0x502596['source']['fromUser']?_0x3389b6=Si(_0x46a0bc,_0x28106f,_0x502596['path'],_0x502596['snap'],_0x3181d4,_0x147e1e,_0x3b1dd0):(f(_0x502596['source']['fromServer'],'Unknown\x20source.'),_0x138166=_0x502596['source']['tagged']||_0x28106f['serverCache']['isFiltered']()&&!v(_0x502596['path']),_0x3389b6=En(_0x46a0bc,_0x28106f,_0x502596['path'],_0x502596['snap'],_0x3181d4,_0x147e1e,_0x138166,_0x3b1dd0));}else{if(_0x31a177['type']===j['MERGE']){const _0x5ebdb6=_0x31a177;_0x5ebdb6['source']['fromUser']?_0x3389b6=ku(_0x46a0bc,_0x28106f,_0x5ebdb6['path'],_0x5ebdb6['children'],_0x3181d4,_0x147e1e,_0x3b1dd0):(f(_0x5ebdb6['source']['fromServer'],'Unknown\x20source.'),_0x138166=_0x5ebdb6['source']['tagged']||_0x28106f['serverCache']['isFiltered'](),_0x3389b6=bi(_0x46a0bc,_0x28106f,_0x5ebdb6['path'],_0x5ebdb6['children'],_0x3181d4,_0x147e1e,_0x138166,_0x3b1dd0));}else{if(_0x31a177['type']===j['ACK_USER_WRITE']){const _0x116af6=_0x31a177;_0x116af6['revert']?_0x3389b6=Ou(_0x46a0bc,_0x28106f,_0x116af6['path'],_0x3181d4,_0x147e1e,_0x3b1dd0):_0x3389b6=Nu(_0x46a0bc,_0x28106f,_0x116af6['path'],_0x116af6['affectedTree'],_0x3181d4,_0x147e1e,_0x3b1dd0);}else{if(_0x31a177['type']===j['LISTEN_COMPLETE'])_0x3389b6=Pu(_0x46a0bc,_0x28106f,_0x31a177['path'],_0x3181d4,_0x3b1dd0);else throw rt('Unknown\x20operation\x20type:\x20'+_0x31a177['type']);}}}const _0x8a54d2=_0x3b1dd0['getChanges']();return Au(_0x28106f,_0x3389b6,_0x8a54d2),{'viewCache':_0x3389b6,'changes':_0x8a54d2};}function Au(_0x3c54eb,_0x51c9f6,_0x549471){const _0x59db4e=_0x51c9f6['eventCache'];if(_0x59db4e['isFullyInitialized']()){const _0x408ccb=_0x59db4e['getNode']()['isLeafNode']()||_0x59db4e['getNode']()['isEmpty'](),_0x11bc60=mn(_0x3c54eb);(_0x549471['length']>0x0||!_0x3c54eb['eventCache']['isFullyInitialized']()||_0x408ccb&&!_0x59db4e['getNode']()['equals'](_0x11bc60)||!_0x59db4e['getNode']()['getPriority']()['equals'](_0x11bc60['getPriority']()))&&_0x549471['push'](Lo(mn(_0x51c9f6)));}}function qo(_0x3bba33,_0xe277c6,_0x574ed5,_0x5a3f81,_0x56646e,_0x1eefa0){const _0x11b025=_0xe277c6['eventCache'];if(vn(_0x5a3f81,_0x574ed5)!=null)return _0xe277c6;{let _0xb9734c,_0x329270;if(v(_0x574ed5)){if(f(_0xe277c6['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0xe277c6['serverCache']['isFiltered']()){const _0x30053c=We(_0xe277c6),_0x96793c=_0x30053c instanceof g?_0x30053c:g['EMPTY_NODE'],_0x4a831a=ns(_0x5a3f81,_0x96793c);_0xb9734c=_0x3bba33['filter']['updateFullNode'](_0xe277c6['eventCache']['getNode'](),_0x4a831a,_0x1eefa0);}else{const _0x21aa9b=yn(_0x5a3f81,We(_0xe277c6));_0xb9734c=_0x3bba33['filter']['updateFullNode'](_0xe277c6['eventCache']['getNode'](),_0x21aa9b,_0x1eefa0);}}else{const _0xa33098=y(_0x574ed5);if(_0xa33098==='.priority'){f(we(_0x574ed5)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x1ef10e=_0x11b025['getNode']();_0x329270=_0xe277c6['serverCache']['getNode']();const _0x35b3d2=lr(_0x5a3f81,_0x574ed5,_0x1ef10e,_0x329270);_0x35b3d2!=null?_0xb9734c=_0x3bba33['filter']['updatePriority'](_0x1ef10e,_0x35b3d2):_0xb9734c=_0x11b025['getNode']();}else{const _0x53b29e=b(_0x574ed5);let _0x1a46eb;if(_0x11b025['isCompleteForChild'](_0xa33098)){_0x329270=_0xe277c6['serverCache']['getNode']();const _0x57c70d=lr(_0x5a3f81,_0x574ed5,_0x11b025['getNode'](),_0x329270);_0x57c70d!=null?_0x1a46eb=_0x11b025['getNode']()['getImmediateChild'](_0xa33098)['updateChild'](_0x53b29e,_0x57c70d):_0x1a46eb=_0x11b025['getNode']()['getImmediateChild'](_0xa33098);}else _0x1a46eb=is(_0x5a3f81,_0xa33098,_0xe277c6['serverCache']);_0x1a46eb!=null?_0xb9734c=_0x3bba33['filter']['updateChild'](_0x11b025['getNode'](),_0xa33098,_0x1a46eb,_0x53b29e,_0x56646e,_0x1eefa0):_0xb9734c=_0x11b025['getNode']();}}return Tt(_0xe277c6,_0xb9734c,_0x11b025['isFullyInitialized']()||v(_0x574ed5),_0x3bba33['filter']['filtersNodes']());}}function En(_0x2fc2d2,_0x7253bb,_0x12167d,_0x24fb75,_0x21a16f,_0x21ded6,_0x827037,_0x1be428){const _0x13a829=_0x7253bb['serverCache'];let _0x2acef6;const _0x3f7eb7=_0x827037?_0x2fc2d2['filter']:_0x2fc2d2['filter']['getIndexedFilter']();if(v(_0x12167d))_0x2acef6=_0x3f7eb7['updateFullNode'](_0x13a829['getNode'](),_0x24fb75,null);else{if(_0x3f7eb7['filtersNodes']()&&!_0x13a829['isFiltered']()){const _0x5472f6=_0x13a829['getNode']()['updateChild'](_0x12167d,_0x24fb75);_0x2acef6=_0x3f7eb7['updateFullNode'](_0x13a829['getNode'](),_0x5472f6,null);}else{const _0x1d6883=y(_0x12167d);if(!_0x13a829['isCompleteForPath'](_0x12167d)&&we(_0x12167d)>0x1)return _0x7253bb;const _0x183d2f=b(_0x12167d),_0x26c310=_0x13a829['getNode']()['getImmediateChild'](_0x1d6883)['updateChild'](_0x183d2f,_0x24fb75);_0x1d6883==='.priority'?_0x2acef6=_0x3f7eb7['updatePriority'](_0x13a829['getNode'](),_0x26c310):_0x2acef6=_0x3f7eb7['updateChild'](_0x13a829['getNode'](),_0x1d6883,_0x26c310,_0x183d2f,Go,null);}}const _0x492962=Uo(_0x7253bb,_0x2acef6,_0x13a829['isFullyInitialized']()||v(_0x12167d),_0x3f7eb7['filtersNodes']()),_0x1c86df=new ss(_0x21a16f,_0x492962,_0x21ded6);return qo(_0x2fc2d2,_0x492962,_0x12167d,_0x21a16f,_0x1c86df,_0x1be428);}function Si(_0x1211bd,_0xf0f08c,_0x19e930,_0x181839,_0xeff435,_0x560d38,_0x267184){const _0x4f5ed5=_0xf0f08c['eventCache'];let _0x5b1e7d,_0x163e21;const _0x503a92=new ss(_0xeff435,_0xf0f08c,_0x560d38);if(v(_0x19e930))_0x163e21=_0x1211bd['filter']['updateFullNode'](_0xf0f08c['eventCache']['getNode'](),_0x181839,_0x267184),_0x5b1e7d=Tt(_0xf0f08c,_0x163e21,!0x0,_0x1211bd['filter']['filtersNodes']());else{const _0x6387b0=y(_0x19e930);if(_0x6387b0==='.priority')_0x163e21=_0x1211bd['filter']['updatePriority'](_0xf0f08c['eventCache']['getNode'](),_0x181839),_0x5b1e7d=Tt(_0xf0f08c,_0x163e21,_0x4f5ed5['isFullyInitialized'](),_0x4f5ed5['isFiltered']());else{const _0x22bcc8=b(_0x19e930),_0x22dd36=_0x4f5ed5['getNode']()['getImmediateChild'](_0x6387b0);let _0x3adff2;if(v(_0x22bcc8))_0x3adff2=_0x181839;else{const _0x5324f4=_0x503a92['getCompleteChild'](_0x6387b0);_0x5324f4!=null?zi(_0x22bcc8)==='.priority'&&_0x5324f4['getChild'](Ro(_0x22bcc8))['isEmpty']()?_0x3adff2=_0x5324f4:_0x3adff2=_0x5324f4['updateChild'](_0x22bcc8,_0x181839):_0x3adff2=g['EMPTY_NODE'];}if(_0x22dd36['equals'](_0x3adff2))_0x5b1e7d=_0xf0f08c;else{const _0x27f124=_0x1211bd['filter']['updateChild'](_0x4f5ed5['getNode'](),_0x6387b0,_0x3adff2,_0x22bcc8,_0x503a92,_0x267184);_0x5b1e7d=Tt(_0xf0f08c,_0x27f124,_0x4f5ed5['isFullyInitialized'](),_0x1211bd['filter']['filtersNodes']());}}}return _0x5b1e7d;}function hr(_0x43892,_0x598530){return _0x43892['eventCache']['isCompleteForChild'](_0x598530);}function ku(_0x23b986,_0xd55533,_0x230389,_0x49edcf,_0x17d29a,_0x32c595,_0x44f842){let _0x3e4e5c=_0xd55533;return _0x49edcf['foreach']((_0x5e8d6e,_0x2473b1)=>{const _0x49eb9d=k(_0x230389,_0x5e8d6e);hr(_0xd55533,y(_0x49eb9d))&&(_0x3e4e5c=Si(_0x23b986,_0x3e4e5c,_0x49eb9d,_0x2473b1,_0x17d29a,_0x32c595,_0x44f842));}),_0x49edcf['foreach']((_0x544d1a,_0x43aec4)=>{const _0x53aff3=k(_0x230389,_0x544d1a);hr(_0xd55533,y(_0x53aff3))||(_0x3e4e5c=Si(_0x23b986,_0x3e4e5c,_0x53aff3,_0x43aec4,_0x17d29a,_0x32c595,_0x44f842));}),_0x3e4e5c;}function ur(_0xe33e0c,_0x25e9d8,_0x1b7958){return _0x1b7958['foreach']((_0x1e1a8d,_0x454b76)=>{_0x25e9d8=_0x25e9d8['updateChild'](_0x1e1a8d,_0x454b76);}),_0x25e9d8;}function bi(_0x8251de,_0x3a6bca,_0x494cc0,_0x57c52a,_0x5f3375,_0x1c7364,_0x4655c1,_0x23e73e){if(_0x3a6bca['serverCache']['getNode']()['isEmpty']()&&!_0x3a6bca['serverCache']['isFullyInitialized']())return _0x3a6bca;let _0x4d336c=_0x3a6bca,_0x3efe57;v(_0x494cc0)?_0x3efe57=_0x57c52a:_0x3efe57=new S(null)['setTree'](_0x494cc0,_0x57c52a);const _0x1b97f3=_0x3a6bca['serverCache']['getNode']();return _0x3efe57['children']['inorderTraversal']((_0x150031,_0x331688)=>{if(_0x1b97f3['hasChild'](_0x150031)){const _0xd1b615=_0x3a6bca['serverCache']['getNode']()['getImmediateChild'](_0x150031),_0x3c80c1=ur(_0x8251de,_0xd1b615,_0x331688);_0x4d336c=En(_0x8251de,_0x4d336c,new C(_0x150031),_0x3c80c1,_0x5f3375,_0x1c7364,_0x4655c1,_0x23e73e);}}),_0x3efe57['children']['inorderTraversal']((_0x5b8017,_0x30d244)=>{const _0x17ddde=!_0x3a6bca['serverCache']['isCompleteForChild'](_0x5b8017)&&_0x30d244['value']===null;if(!_0x1b97f3['hasChild'](_0x5b8017)&&!_0x17ddde){const _0x5ddac9=_0x3a6bca['serverCache']['getNode']()['getImmediateChild'](_0x5b8017),_0x2c34ae=ur(_0x8251de,_0x5ddac9,_0x30d244);_0x4d336c=En(_0x8251de,_0x4d336c,new C(_0x5b8017),_0x2c34ae,_0x5f3375,_0x1c7364,_0x4655c1,_0x23e73e);}}),_0x4d336c;}function Nu(_0x761aaa,_0x43ff82,_0x36f7f6,_0x267988,_0x2d5eca,_0x92ce5e,_0x10011d){if(vn(_0x2d5eca,_0x36f7f6)!=null)return _0x43ff82;const _0x1077ae=_0x43ff82['serverCache']['isFiltered'](),_0x293728=_0x43ff82['serverCache'];if(_0x267988['value']!=null){if(v(_0x36f7f6)&&_0x293728['isFullyInitialized']()||_0x293728['isCompleteForPath'](_0x36f7f6))return En(_0x761aaa,_0x43ff82,_0x36f7f6,_0x293728['getNode']()['getChild'](_0x36f7f6),_0x2d5eca,_0x92ce5e,_0x1077ae,_0x10011d);if(v(_0x36f7f6)){let _0x2c7e86=new S(null);return _0x293728['getNode']()['forEachChild'](ye,(_0x36972f,_0x5c943c)=>{_0x2c7e86=_0x2c7e86['set'](new C(_0x36972f),_0x5c943c);}),bi(_0x761aaa,_0x43ff82,_0x36f7f6,_0x2c7e86,_0x2d5eca,_0x92ce5e,_0x1077ae,_0x10011d);}else return _0x43ff82;}else{let _0x1dbd0a=new S(null);return _0x267988['foreach']((_0x1fb88b,_0x3bc2ca)=>{const _0x4c2c5b=k(_0x36f7f6,_0x1fb88b);_0x293728['isCompleteForPath'](_0x4c2c5b)&&(_0x1dbd0a=_0x1dbd0a['set'](_0x1fb88b,_0x293728['getNode']()['getChild'](_0x4c2c5b)));}),bi(_0x761aaa,_0x43ff82,_0x36f7f6,_0x1dbd0a,_0x2d5eca,_0x92ce5e,_0x1077ae,_0x10011d);}}function Pu(_0x37a560,_0x557193,_0x3bb7dc,_0x3ae2e3,_0x4e69c0){const _0x1548ee=_0x557193['serverCache'],_0x2aebbc=Uo(_0x557193,_0x1548ee['getNode'](),_0x1548ee['isFullyInitialized']()||v(_0x3bb7dc),_0x1548ee['isFiltered']());return qo(_0x37a560,_0x2aebbc,_0x3bb7dc,_0x3ae2e3,Go,_0x4e69c0);}function Ou(_0x15f5f0,_0xe03ac7,_0x5d3911,_0x37a91e,_0x4d3341,_0x43088d){let _0x295e9d;if(vn(_0x37a91e,_0x5d3911)!=null)return _0xe03ac7;{const _0x375fbb=new ss(_0x37a91e,_0xe03ac7,_0x4d3341),_0x16b734=_0xe03ac7['eventCache']['getNode']();let _0x52ef83;if(v(_0x5d3911)||y(_0x5d3911)==='.priority'){let _0x385af8;if(_0xe03ac7['serverCache']['isFullyInitialized']())_0x385af8=yn(_0x37a91e,We(_0xe03ac7));else{const _0x444241=_0xe03ac7['serverCache']['getNode']();f(_0x444241 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x385af8=ns(_0x37a91e,_0x444241);}_0x385af8=_0x385af8,_0x52ef83=_0x15f5f0['filter']['updateFullNode'](_0x16b734,_0x385af8,_0x43088d);}else{const _0x963d3b=y(_0x5d3911);let _0x52962b=is(_0x37a91e,_0x963d3b,_0xe03ac7['serverCache']);_0x52962b==null&&_0xe03ac7['serverCache']['isCompleteForChild'](_0x963d3b)&&(_0x52962b=_0x16b734['getImmediateChild'](_0x963d3b)),_0x52962b!=null?_0x52ef83=_0x15f5f0['filter']['updateChild'](_0x16b734,_0x963d3b,_0x52962b,b(_0x5d3911),_0x375fbb,_0x43088d):_0xe03ac7['eventCache']['getNode']()['hasChild'](_0x963d3b)?_0x52ef83=_0x15f5f0['filter']['updateChild'](_0x16b734,_0x963d3b,g['EMPTY_NODE'],b(_0x5d3911),_0x375fbb,_0x43088d):_0x52ef83=_0x16b734,_0x52ef83['isEmpty']()&&_0xe03ac7['serverCache']['isFullyInitialized']()&&(_0x295e9d=yn(_0x37a91e,We(_0xe03ac7)),_0x295e9d['isLeafNode']()&&(_0x52ef83=_0x15f5f0['filter']['updateFullNode'](_0x52ef83,_0x295e9d,_0x43088d)));}return _0x295e9d=_0xe03ac7['serverCache']['isFullyInitialized']()||vn(_0x37a91e,w())!=null,Tt(_0xe03ac7,_0x52ef83,_0x295e9d,_0x15f5f0['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x1a84ff,_0x2d50d1){this['query_']=_0x1a84ff,this['eventRegistrations_']=[];const _0x239d4f=this['query_']['_queryParams'],_0x23da5c=new Ji(_0x239d4f['getIndex']()),_0x14304c=Kh(_0x239d4f);this['processor_']=Su(_0x14304c);const _0x2d03df=_0x2d50d1['serverCache'],_0x10057f=_0x2d50d1['eventCache'],_0x239176=_0x23da5c['updateFullNode'](g['EMPTY_NODE'],_0x2d03df['getNode'](),null),_0x55bf72=_0x14304c['updateFullNode'](g['EMPTY_NODE'],_0x10057f['getNode'](),null),_0x29d054=new Ce(_0x239176,_0x2d03df['isFullyInitialized'](),_0x23da5c['filtersNodes']()),_0x320c90=new Ce(_0x55bf72,_0x10057f['isFullyInitialized'](),_0x14304c['filtersNodes']());this['viewCache_']=Mn(_0x320c90,_0x29d054),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x18dbb6){return _0x18dbb6['viewCache_']['serverCache']['getNode']();}function Lu(_0x1d2379){return mn(_0x1d2379['viewCache_']);}function xu(_0x146856,_0x59b29d){const _0x1ea95c=We(_0x146856['viewCache_']);return _0x1ea95c&&(_0x146856['query']['_queryParams']['loadsAllData']()||!v(_0x59b29d)&&!_0x1ea95c['getImmediateChild'](y(_0x59b29d))['isEmpty']())?_0x1ea95c['getChild'](_0x59b29d):null;}function dr(_0x1f94a5){return _0x1f94a5['eventRegistrations_']['length']===0x0;}function Fu(_0x5d3088,_0x1b6061){_0x5d3088['eventRegistrations_']['push'](_0x1b6061);}function fr(_0x11130e,_0x288130,_0x139c41){const _0x54e9be=[];if(_0x139c41){f(_0x288130==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x53e7c8=_0x11130e['query']['_path'];_0x11130e['eventRegistrations_']['forEach'](_0x2b23c2=>{const _0x364243=_0x2b23c2['createCancelEvent'](_0x139c41,_0x53e7c8);_0x364243&&_0x54e9be['push'](_0x364243);});}if(_0x288130){let _0x117a22=[];for(let _0x9b0d25=0x0;_0x9b0d25<_0x11130e['eventRegistrations_']['length'];++_0x9b0d25){const _0x277ad1=_0x11130e['eventRegistrations_'][_0x9b0d25];if(!_0x277ad1['matches'](_0x288130))_0x117a22['push'](_0x277ad1);else{if(_0x288130['hasAnyCallback']()){_0x117a22=_0x117a22['concat'](_0x11130e['eventRegistrations_']['slice'](_0x9b0d25+0x1));break;}}}_0x11130e['eventRegistrations_']=_0x117a22;}else _0x11130e['eventRegistrations_']=[];return _0x54e9be;}function pr(_0xd94b5c,_0x5ed195,_0x2a4681,_0x111f98){_0x5ed195['type']===j['MERGE']&&_0x5ed195['source']['queryId']!==null&&(f(We(_0xd94b5c['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0xd94b5c['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x3a1a11=_0xd94b5c['viewCache_'],_0x25dbda=Ru(_0xd94b5c['processor_'],_0x3a1a11,_0x5ed195,_0x2a4681,_0x111f98);return bu(_0xd94b5c['processor_'],_0x25dbda['viewCache']),f(_0x25dbda['viewCache']['serverCache']['isFullyInitialized']()||!_0x3a1a11['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0xd94b5c['viewCache_']=_0x25dbda['viewCache'],zo(_0xd94b5c,_0x25dbda['changes'],_0x25dbda['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x44e913,_0x5d640a){const _0x1ed0c1=_0x44e913['viewCache_']['eventCache'],_0xac69aa=[];return _0x1ed0c1['getNode']()['isLeafNode']()||_0x1ed0c1['getNode']()['forEachChild'](R,(_0x29a69c,_0x225415)=>{_0xac69aa['push'](et(_0x29a69c,_0x225415));}),_0x1ed0c1['isFullyInitialized']()&&_0xac69aa['push'](Lo(_0x1ed0c1['getNode']())),zo(_0x44e913,_0xac69aa,_0x1ed0c1['getNode'](),_0x5d640a);}function zo(_0x1e548d,_0x5f3c61,_0x45487c,_0x240163){const _0xf3586b=_0x240163?[_0x240163]:_0x1e548d['eventRegistrations_'];return ru(_0x1e548d['eventGenerator_'],_0x5f3c61,_0x45487c,_0xf3586b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x4abafd){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x4abafd;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x24251e){return _0x24251e['views']['size']===0x0;}function rs(_0x36d727,_0x19e871,_0x158786,_0x1a0bb0){const _0x1a5842=_0x19e871['source']['queryId'];if(_0x1a5842!==null){const _0x429390=_0x36d727['views']['get'](_0x1a5842);return f(_0x429390!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x429390,_0x19e871,_0x158786,_0x1a0bb0);}else{let _0x4c53a5=[];for(const _0x1a1dd1 of _0x36d727['views']['values']())_0x4c53a5=_0x4c53a5['concat'](pr(_0x1a1dd1,_0x19e871,_0x158786,_0x1a0bb0));return _0x4c53a5;}}function Ko(_0x59c635,_0x3466f8,_0xded275,_0x5479b4,_0x1e50cf){const _0x1da0a8=_0x3466f8['_queryIdentifier'],_0x29d3f4=_0x59c635['views']['get'](_0x1da0a8);if(!_0x29d3f4){let _0x195eb4=yn(_0xded275,_0x1e50cf?_0x5479b4:null),_0x1e87ef=!0x1;_0x195eb4?_0x1e87ef=!0x0:_0x5479b4 instanceof g?(_0x195eb4=ns(_0xded275,_0x5479b4),_0x1e87ef=!0x1):(_0x195eb4=g['EMPTY_NODE'],_0x1e87ef=!0x1);const _0x21cc77=Mn(new Ce(_0x195eb4,_0x1e87ef,!0x1),new Ce(_0x5479b4,_0x1e50cf,!0x1));return new Du(_0x3466f8,_0x21cc77);}return _0x29d3f4;}function Hu(_0x143ca7,_0x45b0fd,_0x2293d7,_0x48037f,_0x15719,_0x1a7a9f){const _0x319f81=Ko(_0x143ca7,_0x45b0fd,_0x48037f,_0x15719,_0x1a7a9f);return _0x143ca7['views']['has'](_0x45b0fd['_queryIdentifier'])||_0x143ca7['views']['set'](_0x45b0fd['_queryIdentifier'],_0x319f81),Fu(_0x319f81,_0x2293d7),Uu(_0x319f81,_0x2293d7);}function $u(_0x10670a,_0x50cfe4,_0x26853f,_0x3374eb){const _0x43b656=_0x50cfe4['_queryIdentifier'],_0x4d669c=[];let _0xdecb61=[];const _0x4a5682=Te(_0x10670a);if(_0x43b656==='default'){for(const [_0x53521b,_0x48269b]of _0x10670a['views']['entries']())_0xdecb61=_0xdecb61['concat'](fr(_0x48269b,_0x26853f,_0x3374eb)),dr(_0x48269b)&&(_0x10670a['views']['delete'](_0x53521b),_0x48269b['query']['_queryParams']['loadsAllData']()||_0x4d669c['push'](_0x48269b['query']));}else{const _0x1dc0eb=_0x10670a['views']['get'](_0x43b656);_0x1dc0eb&&(_0xdecb61=_0xdecb61['concat'](fr(_0x1dc0eb,_0x26853f,_0x3374eb)),dr(_0x1dc0eb)&&(_0x10670a['views']['delete'](_0x43b656),_0x1dc0eb['query']['_queryParams']['loadsAllData']()||_0x4d669c['push'](_0x1dc0eb['query'])));}return _0x4a5682&&!Te(_0x10670a)&&_0x4d669c['push'](new(Bu())(_0x50cfe4['_repo'],_0x50cfe4['_path'])),{'removed':_0x4d669c,'events':_0xdecb61};}function Yo(_0x59057b){const _0x2261c9=[];for(const _0x33c2f0 of _0x59057b['views']['values']())_0x33c2f0['query']['_queryParams']['loadsAllData']()||_0x2261c9['push'](_0x33c2f0);return _0x2261c9;}function Ee(_0x47cc22,_0x3c55f5){let _0x289268=null;for(const _0x418e88 of _0x47cc22['views']['values']())_0x289268=_0x289268||xu(_0x418e88,_0x3c55f5);return _0x289268;}function Qo(_0x290ab3,_0x32384a){if(_0x32384a['_queryParams']['loadsAllData']())return xn(_0x290ab3);{const _0x31145a=_0x32384a['_queryIdentifier'];return _0x290ab3['views']['get'](_0x31145a);}}function Jo(_0xb5123b,_0x4018ec){return Qo(_0xb5123b,_0x4018ec)!=null;}function Te(_0x8a18db){return xn(_0x8a18db)!=null;}function xn(_0x1282e9){for(const _0x44f026 of _0x1282e9['views']['values']())if(_0x44f026['query']['_queryParams']['loadsAllData']())return _0x44f026;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x36903e){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x36903e;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x425660){this['listenProvider_']=_0x425660,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x240710,_0xc0393b,_0x3cb65a,_0x442252,_0x5db5dd){return lu(_0x240710['pendingWriteTree_'],_0xc0393b,_0x3cb65a,_0x442252,_0x5db5dd),_0x5db5dd?ut(_0x240710,new Ue(Zi(),_0xc0393b,_0x3cb65a)):[];}function ju(_0x14344e,_0xc1218f,_0x11a841,_0x458d09){hu(_0x14344e['pendingWriteTree_'],_0xc1218f,_0x11a841,_0x458d09);const _0x23afcd=S['fromObject'](_0x11a841);return ut(_0x14344e,new tt(Zi(),_0xc1218f,_0x23afcd));}function pe(_0x105eeb,_0x51d99d,_0x13e5b0=!0x1){const _0x35bb07=uu(_0x105eeb['pendingWriteTree_'],_0x51d99d);if(du(_0x105eeb['pendingWriteTree_'],_0x51d99d)){let _0x5aaf7c=new S(null);return _0x35bb07['snap']!=null?_0x5aaf7c=_0x5aaf7c['set'](w(),!0x0):x(_0x35bb07['children'],_0x3ece43=>{_0x5aaf7c=_0x5aaf7c['set'](new C(_0x3ece43),!0x0);}),ut(_0x105eeb,new gn(_0x35bb07['path'],_0x5aaf7c,_0x13e5b0));}else return[];}function Gt(_0x5a57de,_0x43f9ea,_0x485a67){return ut(_0x5a57de,new Ue(es(),_0x43f9ea,_0x485a67));}function Ku(_0x150c61,_0x474597,_0xadd173){const _0x18dca7=S['fromObject'](_0xadd173);return ut(_0x150c61,new tt(es(),_0x474597,_0x18dca7));}function Yu(_0x1828b3,_0x38de41){return ut(_0x1828b3,new Lt(es(),_0x38de41));}function Qu(_0x1c7819,_0x838864,_0x3ccbf1){const _0x1a3c1b=as(_0x1c7819,_0x3ccbf1);if(_0x1a3c1b){const _0x572bb3=cs(_0x1a3c1b),_0x486af4=_0x572bb3['path'],_0x35f0e1=_0x572bb3['queryId'],_0x4da351=F(_0x486af4,_0x838864),_0x2fe32d=new Lt(ts(_0x35f0e1),_0x4da351);return ls(_0x1c7819,_0x486af4,_0x2fe32d);}else return[];}function Cn(_0x3de3a8,_0x26f9ab,_0x161e5e,_0x26ee03,_0x1cb4e4=!0x1){const _0x5b984d=_0x26f9ab['_path'],_0x248a42=_0x3de3a8['syncPointTree_']['get'](_0x5b984d);let _0x214735=[];if(_0x248a42&&(_0x26f9ab['_queryIdentifier']==='default'||Jo(_0x248a42,_0x26f9ab))){const _0x244afe=$u(_0x248a42,_0x26f9ab,_0x161e5e,_0x26ee03);Vu(_0x248a42)&&(_0x3de3a8['syncPointTree_']=_0x3de3a8['syncPointTree_']['remove'](_0x5b984d));const _0x1205e7=_0x244afe['removed'];if(_0x214735=_0x244afe['events'],!_0x1cb4e4){const _0x3e577e=_0x1205e7['findIndex'](_0x45bc3a=>_0x45bc3a['_queryParams']['loadsAllData']())!==-0x1,_0x408faa=_0x3de3a8['syncPointTree_']['findOnPath'](_0x5b984d,(_0x14f36f,_0x3bc665)=>Te(_0x3bc665));if(_0x3e577e&&!_0x408faa){const _0x1c3a07=_0x3de3a8['syncPointTree_']['subtree'](_0x5b984d);if(!_0x1c3a07['isEmpty']()){const _0x4da19a=Zu(_0x1c3a07);for(let _0x39c7b5=0x0;_0x39c7b5<_0x4da19a['length'];++_0x39c7b5){const _0x4e4508=_0x4da19a[_0x39c7b5],_0x57952a=_0x4e4508['query'],_0x2066a5=ta(_0x3de3a8,_0x4e4508);_0x3de3a8['listenProvider_']['startListening'](bt(_0x57952a),xt(_0x3de3a8,_0x57952a),_0x2066a5['hashFn'],_0x2066a5['onComplete']);}}}!_0x408faa&&_0x1205e7['length']>0x0&&!_0x26ee03&&(_0x3e577e?_0x3de3a8['listenProvider_']['stopListening'](bt(_0x26f9ab),null):_0x1205e7['forEach'](_0x2cdcf8=>{const _0x1c5807=_0x3de3a8['queryToTagMap']['get'](Un(_0x2cdcf8));_0x3de3a8['listenProvider_']['stopListening'](bt(_0x2cdcf8),_0x1c5807);}));}ed(_0x3de3a8,_0x1205e7);}return _0x214735;}function Xo(_0x5e2d48,_0x25e41d,_0xdf2160,_0x5422b7){const _0x17a4bd=as(_0x5e2d48,_0x5422b7);if(_0x17a4bd!=null){const _0x3db1eb=cs(_0x17a4bd),_0x549a09=_0x3db1eb['path'],_0x4708e9=_0x3db1eb['queryId'],_0x483aad=F(_0x549a09,_0x25e41d),_0x19b261=new Ue(ts(_0x4708e9),_0x483aad,_0xdf2160);return ls(_0x5e2d48,_0x549a09,_0x19b261);}else return[];}function Ju(_0xdf2b2a,_0x17db3b,_0x2756e6,_0x58485d){const _0x4c43b8=as(_0xdf2b2a,_0x58485d);if(_0x4c43b8){const _0x4694c8=cs(_0x4c43b8),_0x48d994=_0x4694c8['path'],_0x3f931e=_0x4694c8['queryId'],_0x16a35b=F(_0x48d994,_0x17db3b),_0x299566=S['fromObject'](_0x2756e6),_0x1a413f=new tt(ts(_0x3f931e),_0x16a35b,_0x299566);return ls(_0xdf2b2a,_0x48d994,_0x1a413f);}else return[];}function Ri(_0x51ea02,_0x21e3bf,_0x5ccba7,_0x5a7614=!0x1){const _0xfd1649=_0x21e3bf['_path'];let _0x9efb79=null,_0x3cc205=!0x1;_0x51ea02['syncPointTree_']['foreachOnPath'](_0xfd1649,(_0xf5a8a3,_0x55793c)=>{const _0x27f4bd=F(_0xf5a8a3,_0xfd1649);_0x9efb79=_0x9efb79||Ee(_0x55793c,_0x27f4bd),_0x3cc205=_0x3cc205||Te(_0x55793c);});let _0xf418fe=_0x51ea02['syncPointTree_']['get'](_0xfd1649);_0xf418fe?(_0x3cc205=_0x3cc205||Te(_0xf418fe),_0x9efb79=_0x9efb79||Ee(_0xf418fe,w())):(_0xf418fe=new jo(),_0x51ea02['syncPointTree_']=_0x51ea02['syncPointTree_']['set'](_0xfd1649,_0xf418fe));let _0x1b7403;_0x9efb79!=null?_0x1b7403=!0x0:(_0x1b7403=!0x1,_0x9efb79=g['EMPTY_NODE'],_0x51ea02['syncPointTree_']['subtree'](_0xfd1649)['foreachChild']((_0x2e0f54,_0x37394b)=>{const _0x38fc3a=Ee(_0x37394b,w());_0x38fc3a&&(_0x9efb79=_0x9efb79['updateImmediateChild'](_0x2e0f54,_0x38fc3a));}));const _0xcffaba=Jo(_0xf418fe,_0x21e3bf);if(!_0xcffaba&&!_0x21e3bf['_queryParams']['loadsAllData']()){const _0x41e76a=Un(_0x21e3bf);f(!_0x51ea02['queryToTagMap']['has'](_0x41e76a),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x1e51fb=td();_0x51ea02['queryToTagMap']['set'](_0x41e76a,_0x1e51fb),_0x51ea02['tagToQueryMap']['set'](_0x1e51fb,_0x41e76a);}const _0x43d807=Ln(_0x51ea02['pendingWriteTree_'],_0xfd1649);let _0x4f40f7=Hu(_0xf418fe,_0x21e3bf,_0x5ccba7,_0x43d807,_0x9efb79,_0x1b7403);if(!_0xcffaba&&!_0x3cc205&&!_0x5a7614){const _0x21241b=Qo(_0xf418fe,_0x21e3bf);_0x4f40f7=_0x4f40f7['concat'](nd(_0x51ea02,_0x21e3bf,_0x21241b));}return _0x4f40f7;}function Fn(_0x49d59f,_0x437949,_0x37da41){const _0x117a60=_0x49d59f['pendingWriteTree_'],_0x353278=_0x49d59f['syncPointTree_']['findOnPath'](_0x437949,(_0x2b7bb0,_0x421e7b)=>{const _0x89c190=F(_0x2b7bb0,_0x437949),_0x36d045=Ee(_0x421e7b,_0x89c190);if(_0x36d045)return _0x36d045;});return Vo(_0x117a60,_0x437949,_0x353278,_0x37da41,!0x0);}function Xu(_0x441822,_0x368f9d){const _0x1dd18f=_0x368f9d['_path'];let _0x91d27e=null;_0x441822['syncPointTree_']['foreachOnPath'](_0x1dd18f,(_0xb6b759,_0x1e709b)=>{const _0x2edeaf=F(_0xb6b759,_0x1dd18f);_0x91d27e=_0x91d27e||Ee(_0x1e709b,_0x2edeaf);});let _0x36170b=_0x441822['syncPointTree_']['get'](_0x1dd18f);_0x36170b?_0x91d27e=_0x91d27e||Ee(_0x36170b,w()):(_0x36170b=new jo(),_0x441822['syncPointTree_']=_0x441822['syncPointTree_']['set'](_0x1dd18f,_0x36170b));const _0x5d8d14=_0x91d27e!=null,_0x3e091c=_0x5d8d14?new Ce(_0x91d27e,!0x0,!0x1):null,_0x5b0413=Ln(_0x441822['pendingWriteTree_'],_0x368f9d['_path']),_0x1b8da1=Ko(_0x36170b,_0x368f9d,_0x5b0413,_0x5d8d14?_0x3e091c['getNode']():g['EMPTY_NODE'],_0x5d8d14);return Lu(_0x1b8da1);}function ut(_0x46f2d0,_0x5c6de3){return Zo(_0x5c6de3,_0x46f2d0['syncPointTree_'],null,Ln(_0x46f2d0['pendingWriteTree_'],w()));}function Zo(_0x2b7543,_0x57f2c3,_0x47a0fb,_0x3aa4db){if(v(_0x2b7543['path']))return ea(_0x2b7543,_0x57f2c3,_0x47a0fb,_0x3aa4db);{const _0x2570b8=_0x57f2c3['get'](w());_0x47a0fb==null&&_0x2570b8!=null&&(_0x47a0fb=Ee(_0x2570b8,w()));let _0x1427be=[];const _0xae25ea=y(_0x2b7543['path']),_0x29faa5=_0x2b7543['operationForChild'](_0xae25ea),_0x337dac=_0x57f2c3['children']['get'](_0xae25ea);if(_0x337dac&&_0x29faa5){const _0x4d0e20=_0x47a0fb?_0x47a0fb['getImmediateChild'](_0xae25ea):null,_0x120cd4=Ho(_0x3aa4db,_0xae25ea);_0x1427be=_0x1427be['concat'](Zo(_0x29faa5,_0x337dac,_0x4d0e20,_0x120cd4));}return _0x2570b8&&(_0x1427be=_0x1427be['concat'](rs(_0x2570b8,_0x2b7543,_0x3aa4db,_0x47a0fb))),_0x1427be;}}function ea(_0x446053,_0x1afd0a,_0x531b57,_0x400f1f){const _0x8d1538=_0x1afd0a['get'](w());_0x531b57==null&&_0x8d1538!=null&&(_0x531b57=Ee(_0x8d1538,w()));let _0x3d8fc3=[];return _0x1afd0a['children']['inorderTraversal']((_0x24691d,_0x21436b)=>{const _0x1278cf=_0x531b57?_0x531b57['getImmediateChild'](_0x24691d):null,_0xabdf09=Ho(_0x400f1f,_0x24691d),_0x3e4793=_0x446053['operationForChild'](_0x24691d);_0x3e4793&&(_0x3d8fc3=_0x3d8fc3['concat'](ea(_0x3e4793,_0x21436b,_0x1278cf,_0xabdf09)));}),_0x8d1538&&(_0x3d8fc3=_0x3d8fc3['concat'](rs(_0x8d1538,_0x446053,_0x400f1f,_0x531b57))),_0x3d8fc3;}function ta(_0x526aeb,_0x19db6d){const _0x72bf15=_0x19db6d['query'],_0x147921=xt(_0x526aeb,_0x72bf15);return{'hashFn':()=>(Mu(_0x19db6d)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x3fd0dd=>{if(_0x3fd0dd==='ok')return _0x147921?Qu(_0x526aeb,_0x72bf15['_path'],_0x147921):Yu(_0x526aeb,_0x72bf15['_path']);{const _0x57e563=Kl(_0x3fd0dd,_0x72bf15);return Cn(_0x526aeb,_0x72bf15,null,_0x57e563);}}};}function xt(_0x385a80,_0x2938a2){const _0x437a57=Un(_0x2938a2);return _0x385a80['queryToTagMap']['get'](_0x437a57);}function Un(_0x37721f){return _0x37721f['_path']['toString']()+'$'+_0x37721f['_queryIdentifier'];}function as(_0x47d24d,_0x1b9a86){return _0x47d24d['tagToQueryMap']['get'](_0x1b9a86);}function cs(_0x509c96){const _0x342ac4=_0x509c96['indexOf']('$');return f(_0x342ac4!==-0x1&&_0x342ac4<_0x509c96['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x509c96['substr'](_0x342ac4+0x1),'path':new C(_0x509c96['substr'](0x0,_0x342ac4))};}function ls(_0x3ea23f,_0x40d6ab,_0x1c2014){const _0x2bfe13=_0x3ea23f['syncPointTree_']['get'](_0x40d6ab);f(_0x2bfe13,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x2f7f51=Ln(_0x3ea23f['pendingWriteTree_'],_0x40d6ab);return rs(_0x2bfe13,_0x1c2014,_0x2f7f51,null);}function Zu(_0x5b4002){return _0x5b4002['fold']((_0xf7dca,_0x52d6a2,_0x3b4bae)=>{if(_0x52d6a2&&Te(_0x52d6a2))return[xn(_0x52d6a2)];{let _0x298a9c=[];return _0x52d6a2&&(_0x298a9c=Yo(_0x52d6a2)),x(_0x3b4bae,(_0x541512,_0x495ae9)=>{_0x298a9c=_0x298a9c['concat'](_0x495ae9);}),_0x298a9c;}});}function bt(_0x323461){return _0x323461['_queryParams']['loadsAllData']()&&!_0x323461['_queryParams']['isDefault']()?new(qu())(_0x323461['_repo'],_0x323461['_path']):_0x323461;}function ed(_0x3e34fc,_0x100fac){for(let _0x4e8590=0x0;_0x4e8590<_0x100fac['length'];++_0x4e8590){const _0x311eee=_0x100fac[_0x4e8590];if(!_0x311eee['_queryParams']['loadsAllData']()){const _0x185727=Un(_0x311eee),_0x28c3be=_0x3e34fc['queryToTagMap']['get'](_0x185727);_0x3e34fc['queryToTagMap']['delete'](_0x185727),_0x3e34fc['tagToQueryMap']['delete'](_0x28c3be);}}}function td(){return zu++;}function nd(_0x31ee5e,_0x33d1f0,_0x3b631a){const _0xdc555a=_0x33d1f0['_path'],_0x16dcfa=xt(_0x31ee5e,_0x33d1f0),_0x52138f=ta(_0x31ee5e,_0x3b631a),_0x9d2af4=_0x31ee5e['listenProvider_']['startListening'](bt(_0x33d1f0),_0x16dcfa,_0x52138f['hashFn'],_0x52138f['onComplete']),_0x1164ce=_0x31ee5e['syncPointTree_']['subtree'](_0xdc555a);if(_0x16dcfa)f(!Te(_0x1164ce['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x27f102=_0x1164ce['fold']((_0x53977b,_0x46fcae,_0x3ffc0c)=>{if(!v(_0x53977b)&&_0x46fcae&&Te(_0x46fcae))return[xn(_0x46fcae)['query']];{let _0x3ca30b=[];return _0x46fcae&&(_0x3ca30b=_0x3ca30b['concat'](Yo(_0x46fcae)['map'](_0x628c2a=>_0x628c2a['query']))),x(_0x3ffc0c,(_0x4c36e9,_0x252163)=>{_0x3ca30b=_0x3ca30b['concat'](_0x252163);}),_0x3ca30b;}});for(let _0x281f45=0x0;_0x281f45<_0x27f102['length'];++_0x281f45){const _0xd07ba0=_0x27f102[_0x281f45];_0x31ee5e['listenProvider_']['stopListening'](bt(_0xd07ba0),xt(_0x31ee5e,_0xd07ba0));}}return _0x9d2af4;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x4d1cbe){this['node_']=_0x4d1cbe;}['getImmediateChild'](_0x4a02c8){const _0x1fb3df=this['node_']['getImmediateChild'](_0x4a02c8);return new hs(_0x1fb3df);}['node'](){return this['node_'];}}class us{constructor(_0x23ac31,_0x290cc6){this['syncTree_']=_0x23ac31,this['path_']=_0x290cc6;}['getImmediateChild'](_0x2ff5ac){const _0x250d18=k(this['path_'],_0x2ff5ac);return new us(this['syncTree_'],_0x250d18);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x54cad8){return _0x54cad8=_0x54cad8||{},_0x54cad8['timestamp']=_0x54cad8['timestamp']||new Date()['getTime'](),_0x54cad8;},gr=function(_0x2913c3,_0x2a4163,_0x5498f3){if(!_0x2913c3||typeof _0x2913c3!='object')return _0x2913c3;if(f('.sv'in _0x2913c3,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x2913c3['.sv']=='string')return sd(_0x2913c3['.sv'],_0x2a4163,_0x5498f3);if(typeof _0x2913c3['.sv']=='object')return rd(_0x2913c3['.sv'],_0x2a4163);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x2913c3,null,0x2));},sd=function(_0x3d7ab1,_0x40415f,_0x1c9748){switch(_0x3d7ab1){case'timestamp':return _0x1c9748['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x3d7ab1);}},rd=function(_0x3f2625,_0x29fca2,_0x5e3445){_0x3f2625['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3f2625,null,0x2));const _0x56be3a=_0x3f2625['increment'];typeof _0x56be3a!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x56be3a);const _0x4b59cf=_0x29fca2['node']();if(f(_0x4b59cf!==null&&typeof _0x4b59cf<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x4b59cf['isLeafNode']())return _0x56be3a;const _0x401347=_0x4b59cf['getValue']();return typeof _0x401347!='number'?_0x56be3a:_0x401347+_0x56be3a;},na=function(_0x557ccd,_0x3cad17,_0x422cc8,_0x3cbb33){return fs(_0x3cad17,new us(_0x422cc8,_0x557ccd),_0x3cbb33);},ds=function(_0xc42876,_0x5775b7,_0x19efd8){return fs(_0xc42876,new hs(_0x5775b7),_0x19efd8);};function fs(_0x25289b,_0x372839,_0x3348fb){const _0x5d9529=_0x25289b['getPriority']()['val'](),_0x94f1df=gr(_0x5d9529,_0x372839['getImmediateChild']('.priority'),_0x3348fb);let _0x11b327;if(_0x25289b['isLeafNode']()){const _0x44b46c=_0x25289b,_0x9b2e5b=gr(_0x44b46c['getValue'](),_0x372839,_0x3348fb);return _0x9b2e5b!==_0x44b46c['getValue']()||_0x94f1df!==_0x44b46c['getPriority']()['val']()?new D(_0x9b2e5b,P(_0x94f1df)):_0x25289b;}else{const _0x5b6ab4=_0x25289b;return _0x11b327=_0x5b6ab4,_0x94f1df!==_0x5b6ab4['getPriority']()['val']()&&(_0x11b327=_0x11b327['updatePriority'](new D(_0x94f1df))),_0x5b6ab4['forEachChild'](R,(_0x1a1dfb,_0x36ee49)=>{const _0x200f17=fs(_0x36ee49,_0x372839['getImmediateChild'](_0x1a1dfb),_0x3348fb);_0x200f17!==_0x36ee49&&(_0x11b327=_0x11b327['updateImmediateChild'](_0x1a1dfb,_0x200f17));}),_0x11b327;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x3d098e='',_0x39888f=null,_0x45fb4b={'children':{},'childCount':0x0}){this['name']=_0x3d098e,this['parent']=_0x39888f,this['node']=_0x45fb4b;}}function Wn(_0x373956,_0x4d48a8){let _0x2ef13b=_0x4d48a8 instanceof C?_0x4d48a8:new C(_0x4d48a8),_0x4fd803=_0x373956,_0x41f9ac=y(_0x2ef13b);for(;_0x41f9ac!==null;){const _0x1ff401=De(_0x4fd803['node']['children'],_0x41f9ac)||{'children':{},'childCount':0x0};_0x4fd803=new ps(_0x41f9ac,_0x4fd803,_0x1ff401),_0x2ef13b=b(_0x2ef13b),_0x41f9ac=y(_0x2ef13b);}return _0x4fd803;}function Ge(_0x77fcf3){return _0x77fcf3['node']['value'];}function _s(_0x53ea79,_0xea3fc9){_0x53ea79['node']['value']=_0xea3fc9,Ai(_0x53ea79);}function ia(_0x4729ec){return _0x4729ec['node']['childCount']>0x0;}function od(_0x21211a){return Ge(_0x21211a)===void 0x0&&!ia(_0x21211a);}function Bn(_0x1bf577,_0x3576c6){x(_0x1bf577['node']['children'],(_0x5d2821,_0x209038)=>{_0x3576c6(new ps(_0x5d2821,_0x1bf577,_0x209038));});}function sa(_0x2ca30a,_0x59d382,_0x121d99,_0x58720a){_0x121d99&&_0x59d382(_0x2ca30a),Bn(_0x2ca30a,_0x1c3266=>{sa(_0x1c3266,_0x59d382,!0x0);});}function ad(_0x3a3592,_0x597afe,_0x434b87){let _0xba7f4b=_0x3a3592['parent'];for(;_0xba7f4b!==null;){if(_0x597afe(_0xba7f4b))return!0x0;_0xba7f4b=_0xba7f4b['parent'];}return!0x1;}function qt(_0x1e24b4){return new C(_0x1e24b4['parent']===null?_0x1e24b4['name']:qt(_0x1e24b4['parent'])+'/'+_0x1e24b4['name']);}function Ai(_0x5cfdae){_0x5cfdae['parent']!==null&&cd(_0x5cfdae['parent'],_0x5cfdae['name'],_0x5cfdae);}function cd(_0x260213,_0x215015,_0x3ccd43){const _0x6fef92=od(_0x3ccd43),_0x30c985=J(_0x260213['node']['children'],_0x215015);_0x6fef92&&_0x30c985?(delete _0x260213['node']['children'][_0x215015],_0x260213['node']['childCount']--,Ai(_0x260213)):!_0x6fef92&&!_0x30c985&&(_0x260213['node']['children'][_0x215015]=_0x3ccd43['node'],_0x260213['node']['childCount']++,Ai(_0x260213));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x1cd3b8){return typeof _0x1cd3b8=='string'&&_0x1cd3b8['length']!==0x0&&!ld['test'](_0x1cd3b8);},ra=function(_0x5c245d){return typeof _0x5c245d=='string'&&_0x5c245d['length']!==0x0&&!hd['test'](_0x5c245d);},ud=function(_0x3e3310){return _0x3e3310&&(_0x3e3310=_0x3e3310['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x3e3310);},Tn=function(_0x45be00){return _0x45be00===null||typeof _0x45be00=='string'||typeof _0x45be00=='number'&&!Vi(_0x45be00)||_0x45be00&&typeof _0x45be00=='object'&&J(_0x45be00,'.sv');},zt=function(_0x5bd2c7,_0x5c586b,_0x334243,_0x54a7a8){_0x54a7a8&&_0x5c586b===void 0x0||jt(Pn(_0x5bd2c7,'value'),_0x5c586b,_0x334243);},jt=function(_0x544be7,_0x2bbf03,_0x1a169a){const _0x76bbf6=_0x1a169a instanceof C?new Ah(_0x1a169a,_0x544be7):_0x1a169a;if(_0x2bbf03===void 0x0)throw new Error(_0x544be7+'contains\x20undefined\x20'+Pe(_0x76bbf6));if(typeof _0x2bbf03=='function')throw new Error(_0x544be7+'contains\x20a\x20function\x20'+Pe(_0x76bbf6)+'\x20with\x20contents\x20=\x20'+_0x2bbf03['toString']());if(Vi(_0x2bbf03))throw new Error(_0x544be7+'contains\x20'+_0x2bbf03['toString']()+'\x20'+Pe(_0x76bbf6));if(typeof _0x2bbf03=='string'&&_0x2bbf03['length']>ai/0x3&&On(_0x2bbf03)>ai)throw new Error(_0x544be7+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x76bbf6)+'\x20(\x27'+_0x2bbf03['substring'](0x0,0x32)+'...\x27)');if(_0x2bbf03&&typeof _0x2bbf03=='object'){let _0x248924=!0x1,_0x2d9438=!0x1;if(x(_0x2bbf03,(_0x39d3f4,_0x5591d0)=>{if(_0x39d3f4==='.value')_0x248924=!0x0;else{if(_0x39d3f4!=='.priority'&&_0x39d3f4!=='.sv'&&(_0x2d9438=!0x0,!gs(_0x39d3f4)))throw new Error(_0x544be7+'\x20contains\x20an\x20invalid\x20key\x20('+_0x39d3f4+')\x20'+Pe(_0x76bbf6)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x76bbf6,_0x39d3f4),jt(_0x544be7,_0x5591d0,_0x76bbf6),Nh(_0x76bbf6);}),_0x248924&&_0x2d9438)throw new Error(_0x544be7+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x76bbf6)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x142a1c,_0x5f5900){let _0x507334,_0x55f792;for(_0x507334=0x0;_0x507334<_0x5f5900['length'];_0x507334++){_0x55f792=_0x5f5900[_0x507334];const _0x8b81d5=Pt(_0x55f792);for(let _0x560501=0x0;_0x560501<_0x8b81d5['length'];_0x560501++)if(!(_0x8b81d5[_0x560501]==='.priority'&&_0x560501===_0x8b81d5['length']-0x1)){if(!gs(_0x8b81d5[_0x560501]))throw new Error(_0x142a1c+'contains\x20an\x20invalid\x20key\x20('+_0x8b81d5[_0x560501]+')\x20in\x20path\x20'+_0x55f792['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x5f5900['sort'](Rh);let _0x252ba4=null;for(_0x507334=0x0;_0x507334<_0x5f5900['length'];_0x507334++){if(_0x55f792=_0x5f5900[_0x507334],_0x252ba4!==null&&G(_0x252ba4,_0x55f792))throw new Error(_0x142a1c+'contains\x20a\x20path\x20'+_0x252ba4['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x55f792['toString']());_0x252ba4=_0x55f792;}},fd=function(_0xfaaa3b,_0x325839,_0x4b1b8c,_0x2321d4){const _0x1078ce=Pn(_0xfaaa3b,'values');if(!(_0x325839&&typeof _0x325839=='object')||Array['isArray'](_0x325839))throw new Error(_0x1078ce+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0xbfa0f7=[];x(_0x325839,(_0x63b8b9,_0x3e38f7)=>{const _0x1680bd=new C(_0x63b8b9);if(jt(_0x1078ce,_0x3e38f7,k(_0x4b1b8c,_0x1680bd)),zi(_0x1680bd)==='.priority'&&!Tn(_0x3e38f7))throw new Error(_0x1078ce+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x1680bd['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0xbfa0f7['push'](_0x1680bd);}),dd(_0x1078ce,_0xbfa0f7);},ms=function(_0x3f4b03,_0x285046,_0x1278b7,_0x494958){if(!ra(_0x1278b7))throw new Error(Pn(_0x3f4b03,_0x285046)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x1278b7+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x35574e,_0x333b0b,_0x9b54b6,_0x53fdbb){_0x9b54b6&&(_0x9b54b6=_0x9b54b6['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x35574e,_0x333b0b,_0x9b54b6);},ys=function(_0x116b1c,_0x15c2ae){if(y(_0x15c2ae)==='.info')throw new Error(_0x116b1c+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x9fb104,_0x1f0779){const _0x339165=_0x1f0779['path']['toString']();if(typeof _0x1f0779['repoInfo']['host']!='string'||_0x1f0779['repoInfo']['host']['length']===0x0||!gs(_0x1f0779['repoInfo']['namespace'])&&_0x1f0779['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x339165['length']!==0x0&&!ud(_0x339165))throw new Error(Pn(_0x9fb104,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x18795b,_0x2db5f3){let _0x268a87=null;for(let _0x4fed5f=0x0;_0x4fed5f<_0x2db5f3['length'];_0x4fed5f++){const _0x3e47d0=_0x2db5f3[_0x4fed5f],_0x565955=_0x3e47d0['getPath']();_0x268a87!==null&&!ji(_0x565955,_0x268a87['path'])&&(_0x18795b['eventLists_']['push'](_0x268a87),_0x268a87=null),_0x268a87===null&&(_0x268a87={'events':[],'path':_0x565955}),_0x268a87['events']['push'](_0x3e47d0);}_0x268a87&&_0x18795b['eventLists_']['push'](_0x268a87);}function oa(_0x3ab070,_0x4ad6b1,_0x207ca6){Vn(_0x3ab070,_0x207ca6),aa(_0x3ab070,_0xec3644=>ji(_0xec3644,_0x4ad6b1));}function H(_0x2e938b,_0x4e7968,_0x216807){Vn(_0x2e938b,_0x216807),aa(_0x2e938b,_0x59dab9=>G(_0x59dab9,_0x4e7968)||G(_0x4e7968,_0x59dab9));}function aa(_0x50f3da,_0x541461){_0x50f3da['recursionDepth_']++;let _0x1b8865=!0x0;for(let _0x2a4791=0x0;_0x2a4791<_0x50f3da['eventLists_']['length'];_0x2a4791++){const _0x5ee767=_0x50f3da['eventLists_'][_0x2a4791];if(_0x5ee767){const _0x47137a=_0x5ee767['path'];_0x541461(_0x47137a)?(md(_0x50f3da['eventLists_'][_0x2a4791]),_0x50f3da['eventLists_'][_0x2a4791]=null):_0x1b8865=!0x1;}}_0x1b8865&&(_0x50f3da['eventLists_']=[]),_0x50f3da['recursionDepth_']--;}function md(_0x47b4e7){for(let _0x204044=0x0;_0x204044<_0x47b4e7['events']['length'];_0x204044++){const _0x18e946=_0x47b4e7['events'][_0x204044];if(_0x18e946!==null){_0x47b4e7['events'][_0x204044]=null;const _0x25af48=_0x18e946['getEventRunner']();wt&&L('event:\x20'+_0x18e946['toString']()),ht(_0x25af48);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x412df6,_0x16663f,_0x2b0824,_0x27be4b){this['repoInfo_']=_0x412df6,this['forceRestClient_']=_0x16663f,this['authTokenProvider_']=_0x2b0824,this['appCheckProvider_']=_0x27be4b,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x597839,_0x21b016,_0xa577e1){if(_0x597839['stats_']=Gi(_0x597839['repoInfo_']),_0x597839['forceRestClient_']||Xl())_0x597839['server_']=new pn(_0x597839['repoInfo_'],(_0x3d83a4,_0x5b0d8a,_0x442d54,_0x2aec9d)=>{mr(_0x597839,_0x3d83a4,_0x5b0d8a,_0x442d54,_0x2aec9d);},_0x597839['authTokenProvider_'],_0x597839['appCheckProvider_']),setTimeout(()=>yr(_0x597839,!0x0),0x0);else{if(typeof _0xa577e1<'u'&&_0xa577e1!==null){if(typeof _0xa577e1!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0xa577e1);}catch(_0x5d72da){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x5d72da);}}_0x597839['persistentConnection_']=new se(_0x597839['repoInfo_'],_0x21b016,(_0x3f4704,_0x25b46a,_0x82be6d,_0x18489e)=>{mr(_0x597839,_0x3f4704,_0x25b46a,_0x82be6d,_0x18489e);},_0x42cce1=>{yr(_0x597839,_0x42cce1);},_0x86e110=>{Id(_0x597839,_0x86e110);},_0x597839['authTokenProvider_'],_0x597839['appCheckProvider_'],_0xa577e1),_0x597839['server_']=_0x597839['persistentConnection_'];}_0x597839['authTokenProvider_']['addTokenChangeListener'](_0x400198=>{_0x597839['server_']['refreshAuthToken'](_0x400198);}),_0x597839['appCheckProvider_']['addTokenChangeListener'](_0x33e3ea=>{_0x597839['server_']['refreshAppCheckToken'](_0x33e3ea['token']);}),_0x597839['statsReporter_']=ih(_0x597839['repoInfo_'],()=>new iu(_0x597839['stats_'],_0x597839['server_'])),_0x597839['infoData_']=new Xh(),_0x597839['infoSyncTree_']=new _r({'startListening':(_0x4745d0,_0x46aa7c,_0x11971e,_0x406b4a)=>{let _0x105ad4=[];const _0x3d38f9=_0x597839['infoData_']['getNode'](_0x4745d0['_path']);return _0x3d38f9['isEmpty']()||(_0x105ad4=Gt(_0x597839['infoSyncTree_'],_0x4745d0['_path'],_0x3d38f9),setTimeout(()=>{_0x406b4a('ok');},0x0)),_0x105ad4;},'stopListening':()=>{}}),vs(_0x597839,'connected',!0x1),_0x597839['serverSyncTree_']=new _r({'startListening':(_0x583141,_0x3b4543,_0x2e83ff,_0x2a264f)=>(_0x597839['server_']['listen'](_0x583141,_0x2e83ff,_0x3b4543,(_0x12689f,_0x21799a)=>{const _0xb0f032=_0x2a264f(_0x12689f,_0x21799a);H(_0x597839['eventQueue_'],_0x583141['_path'],_0xb0f032);}),[]),'stopListening':(_0xa1d7f7,_0x255ec6)=>{_0x597839['server_']['unlisten'](_0xa1d7f7,_0x255ec6);}});}function la(_0x1ae37b){const _0x1ea9d4=_0x1ae37b['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x1ea9d4;}function Kt(_0x2b2df1){return id({'timestamp':la(_0x2b2df1)});}function mr(_0x490668,_0x47ea46,_0x577f61,_0xc60be0,_0x15840f){_0x490668['dataUpdateCount']++;const _0x4739cf=new C(_0x47ea46);_0x577f61=_0x490668['interceptServerDataCallback_']?_0x490668['interceptServerDataCallback_'](_0x47ea46,_0x577f61):_0x577f61;let _0x2f48c5=[];if(_0x15840f){if(_0xc60be0){const _0x5e0952=hn(_0x577f61,_0x4039d6=>P(_0x4039d6));_0x2f48c5=Ju(_0x490668['serverSyncTree_'],_0x4739cf,_0x5e0952,_0x15840f);}else{const _0x4a89d8=P(_0x577f61);_0x2f48c5=Xo(_0x490668['serverSyncTree_'],_0x4739cf,_0x4a89d8,_0x15840f);}}else{if(_0xc60be0){const _0x1e0325=hn(_0x577f61,_0x2ac4a5=>P(_0x2ac4a5));_0x2f48c5=Ku(_0x490668['serverSyncTree_'],_0x4739cf,_0x1e0325);}else{const _0x13ef1c=P(_0x577f61);_0x2f48c5=Gt(_0x490668['serverSyncTree_'],_0x4739cf,_0x13ef1c);}}let _0x50b669=_0x4739cf;_0x2f48c5['length']>0x0&&(_0x50b669=it(_0x490668,_0x4739cf)),H(_0x490668['eventQueue_'],_0x50b669,_0x2f48c5);}function yr(_0x5b28ad,_0x52362c){vs(_0x5b28ad,'connected',_0x52362c),_0x52362c===!0x1&&Sd(_0x5b28ad);}function Id(_0x2c81f5,_0x4cf23a){x(_0x4cf23a,(_0x3272dd,_0x597083)=>{vs(_0x2c81f5,_0x3272dd,_0x597083);});}function vs(_0x254cae,_0x562202,_0x45aec2){const _0x4fb0ce=new C('/.info/'+_0x562202),_0x2731fa=P(_0x45aec2);_0x254cae['infoData_']['updateSnapshot'](_0x4fb0ce,_0x2731fa);const _0x9fc78e=Gt(_0x254cae['infoSyncTree_'],_0x4fb0ce,_0x2731fa);H(_0x254cae['eventQueue_'],_0x4fb0ce,_0x9fc78e);}function Hn(_0x246b3b){return _0x246b3b['nextWriteId_']++;}function wd(_0x5a847e,_0x221aa2,_0x1179d5){const _0x2c5df2=Xu(_0x5a847e['serverSyncTree_'],_0x221aa2);return _0x2c5df2!=null?Promise['resolve'](_0x2c5df2):_0x5a847e['server_']['get'](_0x221aa2)['then'](_0x4909b2=>{const _0x266598=P(_0x4909b2)['withIndex'](_0x221aa2['_queryParams']['getIndex']());Ri(_0x5a847e['serverSyncTree_'],_0x221aa2,_0x1179d5,!0x0);let _0x4ac78c;if(_0x221aa2['_queryParams']['loadsAllData']())_0x4ac78c=Gt(_0x5a847e['serverSyncTree_'],_0x221aa2['_path'],_0x266598);else{const _0x30b487=xt(_0x5a847e['serverSyncTree_'],_0x221aa2);_0x4ac78c=Xo(_0x5a847e['serverSyncTree_'],_0x221aa2['_path'],_0x266598,_0x30b487);}return H(_0x5a847e['eventQueue_'],_0x221aa2['_path'],_0x4ac78c),Cn(_0x5a847e['serverSyncTree_'],_0x221aa2,_0x1179d5,null,!0x0),_0x266598;},_0x49fe6=>(dt(_0x5a847e,'get\x20for\x20query\x20'+O(_0x221aa2)+'\x20failed:\x20'+_0x49fe6),Promise['reject'](new Error(_0x49fe6))));}function Cd(_0x513b9b,_0x226263,_0x54e6c5,_0x4ae6c6,_0x1d783f){dt(_0x513b9b,'set',{'path':_0x226263['toString'](),'value':_0x54e6c5,'priority':_0x4ae6c6});const _0x2b1bc5=Kt(_0x513b9b),_0x2557f3=P(_0x54e6c5,_0x4ae6c6),_0x45b1bb=Fn(_0x513b9b['serverSyncTree_'],_0x226263),_0x2e0e05=ds(_0x2557f3,_0x45b1bb,_0x2b1bc5),_0x53ebd5=Hn(_0x513b9b),_0x144f3e=os(_0x513b9b['serverSyncTree_'],_0x226263,_0x2e0e05,_0x53ebd5,!0x0);Vn(_0x513b9b['eventQueue_'],_0x144f3e),_0x513b9b['server_']['put'](_0x226263['toString'](),_0x2557f3['val'](!0x0),(_0xc16122,_0x2ba793)=>{const _0xe46d7=_0xc16122==='ok';_0xe46d7||U('set\x20at\x20'+_0x226263+'\x20failed:\x20'+_0xc16122);const _0x593724=pe(_0x513b9b['serverSyncTree_'],_0x53ebd5,!_0xe46d7);H(_0x513b9b['eventQueue_'],_0x226263,_0x593724),ki(_0x513b9b,_0x1d783f,_0xc16122,_0x2ba793);});const _0x69c1c6=Is(_0x513b9b,_0x226263);it(_0x513b9b,_0x69c1c6),H(_0x513b9b['eventQueue_'],_0x69c1c6,[]);}function Td(_0x39ce6d,_0x17d84e,_0x4d5996,_0x1e8103){dt(_0x39ce6d,'update',{'path':_0x17d84e['toString'](),'value':_0x4d5996});let _0x503ca0=!0x0;const _0x5850cb=Kt(_0x39ce6d),_0x16b91e={};if(x(_0x4d5996,(_0xa4a2b1,_0xef1155)=>{_0x503ca0=!0x1,_0x16b91e[_0xa4a2b1]=na(k(_0x17d84e,_0xa4a2b1),P(_0xef1155),_0x39ce6d['serverSyncTree_'],_0x5850cb);}),_0x503ca0)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x39ce6d,_0x1e8103,'ok',void 0x0);else{const _0xe016c8=Hn(_0x39ce6d),_0x36636a=ju(_0x39ce6d['serverSyncTree_'],_0x17d84e,_0x16b91e,_0xe016c8);Vn(_0x39ce6d['eventQueue_'],_0x36636a),_0x39ce6d['server_']['merge'](_0x17d84e['toString'](),_0x4d5996,(_0x5eb2e4,_0x25f483)=>{const _0x286c21=_0x5eb2e4==='ok';_0x286c21||U('update\x20at\x20'+_0x17d84e+'\x20failed:\x20'+_0x5eb2e4);const _0x376444=pe(_0x39ce6d['serverSyncTree_'],_0xe016c8,!_0x286c21),_0x47d617=_0x376444['length']>0x0?it(_0x39ce6d,_0x17d84e):_0x17d84e;H(_0x39ce6d['eventQueue_'],_0x47d617,_0x376444),ki(_0x39ce6d,_0x1e8103,_0x5eb2e4,_0x25f483);}),x(_0x4d5996,_0x564243=>{const _0xb8762=Is(_0x39ce6d,k(_0x17d84e,_0x564243));it(_0x39ce6d,_0xb8762);}),H(_0x39ce6d['eventQueue_'],_0x17d84e,[]);}}function Sd(_0xc34295){dt(_0xc34295,'onDisconnectEvents');const _0x413b98=Kt(_0xc34295),_0x571966=_n();Ii(_0xc34295['onDisconnect_'],w(),(_0x6136d4,_0x44c9b1)=>{const _0x4dd0a6=na(_0x6136d4,_0x44c9b1,_0xc34295['serverSyncTree_'],_0x413b98);Fo(_0x571966,_0x6136d4,_0x4dd0a6);});let _0x543e8d=[];Ii(_0x571966,w(),(_0x2ba4ca,_0x3af38e)=>{_0x543e8d=_0x543e8d['concat'](Gt(_0xc34295['serverSyncTree_'],_0x2ba4ca,_0x3af38e));const _0x1fde6c=Is(_0xc34295,_0x2ba4ca);it(_0xc34295,_0x1fde6c);}),_0xc34295['onDisconnect_']=_n(),H(_0xc34295['eventQueue_'],w(),_0x543e8d);}function bd(_0x30204d,_0x8ea01d,_0x2b1fe6){let _0x14435a;y(_0x8ea01d['_path'])==='.info'?_0x14435a=Ri(_0x30204d['infoSyncTree_'],_0x8ea01d,_0x2b1fe6):_0x14435a=Ri(_0x30204d['serverSyncTree_'],_0x8ea01d,_0x2b1fe6),oa(_0x30204d['eventQueue_'],_0x8ea01d['_path'],_0x14435a);}function Rd(_0x477106,_0x3e916d,_0x28ecdf){let _0x4a0b53;y(_0x3e916d['_path'])==='.info'?_0x4a0b53=Cn(_0x477106['infoSyncTree_'],_0x3e916d,_0x28ecdf):_0x4a0b53=Cn(_0x477106['serverSyncTree_'],_0x3e916d,_0x28ecdf),oa(_0x477106['eventQueue_'],_0x3e916d['_path'],_0x4a0b53);}function ha(_0x37b363){_0x37b363['persistentConnection_']&&_0x37b363['persistentConnection_']['interrupt'](ca);}function Ad(_0x524a07){_0x524a07['persistentConnection_']&&_0x524a07['persistentConnection_']['resume'](ca);}function dt(_0x3f01e4,..._0x91360c){let _0x5b57b4='';_0x3f01e4['persistentConnection_']&&(_0x5b57b4=_0x3f01e4['persistentConnection_']['id']+':'),L(_0x5b57b4,..._0x91360c);}function ki(_0x13b746,_0x294db6,_0x4ffc94,_0x144371){_0x294db6&&ht(()=>{if(_0x4ffc94==='ok')_0x294db6(null);else{const _0x4d1f21=(_0x4ffc94||'error')['toUpperCase']();let _0x36a65c=_0x4d1f21;_0x144371&&(_0x36a65c+=':\x20'+_0x144371);const _0x4fdba7=new Error(_0x36a65c);_0x4fdba7['code']=_0x4d1f21,_0x294db6(_0x4fdba7);}});}function kd(_0x15f61f,_0x308a8a,_0x13199c,_0x1307d4,_0x16aaa4,_0xc167ec){dt(_0x15f61f,'transaction\x20on\x20'+_0x308a8a);const _0x483670={'path':_0x308a8a,'update':_0x13199c,'onComplete':_0x1307d4,'status':null,'order':so(),'applyLocally':_0xc167ec,'retryCount':0x0,'unwatcher':_0x16aaa4,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x5c1640=Es(_0x15f61f,_0x308a8a,void 0x0);_0x483670['currentInputSnapshot']=_0x5c1640;const _0x94c25=_0x483670['update'](_0x5c1640['val']());if(_0x94c25===void 0x0)_0x483670['unwatcher'](),_0x483670['currentOutputSnapshotRaw']=null,_0x483670['currentOutputSnapshotResolved']=null,_0x483670['onComplete']&&_0x483670['onComplete'](null,!0x1,_0x483670['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x94c25,_0x483670['path']),_0x483670['status']=0x0;const _0x4f23b7=Wn(_0x15f61f['transactionQueueTree_'],_0x308a8a),_0x2c6de4=Ge(_0x4f23b7)||[];_0x2c6de4['push'](_0x483670),_s(_0x4f23b7,_0x2c6de4);let _0x33fcaa;typeof _0x94c25=='object'&&_0x94c25!==null&&J(_0x94c25,'.priority')?(_0x33fcaa=De(_0x94c25,'.priority'),f(Tn(_0x33fcaa),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x33fcaa=(Fn(_0x15f61f['serverSyncTree_'],_0x308a8a)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x467ae3=Kt(_0x15f61f),_0xa32f8b=P(_0x94c25,_0x33fcaa),_0x29117a=ds(_0xa32f8b,_0x5c1640,_0x467ae3);_0x483670['currentOutputSnapshotRaw']=_0xa32f8b,_0x483670['currentOutputSnapshotResolved']=_0x29117a,_0x483670['currentWriteId']=Hn(_0x15f61f);const _0x2d5df3=os(_0x15f61f['serverSyncTree_'],_0x308a8a,_0x29117a,_0x483670['currentWriteId'],_0x483670['applyLocally']);H(_0x15f61f['eventQueue_'],_0x308a8a,_0x2d5df3),$n(_0x15f61f,_0x15f61f['transactionQueueTree_']);}}function Es(_0x2033f2,_0x40f9d9,_0x34d551){return Fn(_0x2033f2['serverSyncTree_'],_0x40f9d9,_0x34d551)||g['EMPTY_NODE'];}function $n(_0x512acb,_0x3a42e8=_0x512acb['transactionQueueTree_']){if(_0x3a42e8||Gn(_0x512acb,_0x3a42e8),Ge(_0x3a42e8)){const _0x4d7311=da(_0x512acb,_0x3a42e8);f(_0x4d7311['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x4d7311['every'](_0x339ec9=>_0x339ec9['status']===0x0)&&Nd(_0x512acb,qt(_0x3a42e8),_0x4d7311);}else ia(_0x3a42e8)&&Bn(_0x3a42e8,_0x3c5247=>{$n(_0x512acb,_0x3c5247);});}function Nd(_0x109bee,_0x2b4e24,_0x173f26){const _0x1d2a9d=_0x173f26['map'](_0x208e53=>_0x208e53['currentWriteId']),_0x4425b2=Es(_0x109bee,_0x2b4e24,_0x1d2a9d);let _0x45a601=_0x4425b2;const _0x410ac=_0x4425b2['hash']();for(let _0x504cf3=0x0;_0x504cf3<_0x173f26['length'];_0x504cf3++){const _0x53e772=_0x173f26[_0x504cf3];f(_0x53e772['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x53e772['status']=0x1,_0x53e772['retryCount']++;const _0x21a12d=F(_0x2b4e24,_0x53e772['path']);_0x45a601=_0x45a601['updateChild'](_0x21a12d,_0x53e772['currentOutputSnapshotRaw']);}const _0x1f4207=_0x45a601['val'](!0x0),_0x308e85=_0x2b4e24;_0x109bee['server_']['put'](_0x308e85['toString'](),_0x1f4207,_0x55ab10=>{dt(_0x109bee,'transaction\x20put\x20response',{'path':_0x308e85['toString'](),'status':_0x55ab10});let _0x340784=[];if(_0x55ab10==='ok'){const _0x226bc9=[];for(let _0xf7058b=0x0;_0xf7058b<_0x173f26['length'];_0xf7058b++)_0x173f26[_0xf7058b]['status']=0x2,_0x340784=_0x340784['concat'](pe(_0x109bee['serverSyncTree_'],_0x173f26[_0xf7058b]['currentWriteId'])),_0x173f26[_0xf7058b]['onComplete']&&_0x226bc9['push'](()=>_0x173f26[_0xf7058b]['onComplete'](null,!0x0,_0x173f26[_0xf7058b]['currentOutputSnapshotResolved'])),_0x173f26[_0xf7058b]['unwatcher']();Gn(_0x109bee,Wn(_0x109bee['transactionQueueTree_'],_0x2b4e24)),$n(_0x109bee,_0x109bee['transactionQueueTree_']),H(_0x109bee['eventQueue_'],_0x2b4e24,_0x340784);for(let _0x1dda02=0x0;_0x1dda02<_0x226bc9['length'];_0x1dda02++)ht(_0x226bc9[_0x1dda02]);}else{if(_0x55ab10==='datastale'){for(let _0x468f37=0x0;_0x468f37<_0x173f26['length'];_0x468f37++)_0x173f26[_0x468f37]['status']===0x3?_0x173f26[_0x468f37]['status']=0x4:_0x173f26[_0x468f37]['status']=0x0;}else{U('transaction\x20at\x20'+_0x308e85['toString']()+'\x20failed:\x20'+_0x55ab10);for(let _0x5ad41d=0x0;_0x5ad41d<_0x173f26['length'];_0x5ad41d++)_0x173f26[_0x5ad41d]['status']=0x4,_0x173f26[_0x5ad41d]['abortReason']=_0x55ab10;}it(_0x109bee,_0x2b4e24);}},_0x410ac);}function it(_0x59ad27,_0x1307de){const _0x4d253b=ua(_0x59ad27,_0x1307de),_0x421a25=qt(_0x4d253b),_0x55f188=da(_0x59ad27,_0x4d253b);return Pd(_0x59ad27,_0x55f188,_0x421a25),_0x421a25;}function Pd(_0xc3540b,_0x5b9eb8,_0x225a37){if(_0x5b9eb8['length']===0x0)return;const _0x30de65=[];let _0x454e17=[];const _0x4ba2a2=_0x5b9eb8['filter'](_0x8f9740=>_0x8f9740['status']===0x0)['map'](_0x1a8d75=>_0x1a8d75['currentWriteId']);for(let _0x542309=0x0;_0x542309<_0x5b9eb8['length'];_0x542309++){const _0x14ec6c=_0x5b9eb8[_0x542309],_0x5012c0=F(_0x225a37,_0x14ec6c['path']);let _0x47de3d=!0x1,_0x3f648c;if(f(_0x5012c0!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x14ec6c['status']===0x4)_0x47de3d=!0x0,_0x3f648c=_0x14ec6c['abortReason'],_0x454e17=_0x454e17['concat'](pe(_0xc3540b['serverSyncTree_'],_0x14ec6c['currentWriteId'],!0x0));else{if(_0x14ec6c['status']===0x0){if(_0x14ec6c['retryCount']>=yd)_0x47de3d=!0x0,_0x3f648c='maxretry',_0x454e17=_0x454e17['concat'](pe(_0xc3540b['serverSyncTree_'],_0x14ec6c['currentWriteId'],!0x0));else{const _0x1525b9=Es(_0xc3540b,_0x14ec6c['path'],_0x4ba2a2);_0x14ec6c['currentInputSnapshot']=_0x1525b9;const _0x5603aa=_0x5b9eb8[_0x542309]['update'](_0x1525b9['val']());if(_0x5603aa!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x5603aa,_0x14ec6c['path']);let _0x2cc0a7=P(_0x5603aa);typeof _0x5603aa=='object'&&_0x5603aa!=null&&J(_0x5603aa,'.priority')||(_0x2cc0a7=_0x2cc0a7['updatePriority'](_0x1525b9['getPriority']()));const _0x2aaa71=_0x14ec6c['currentWriteId'],_0x4bd73c=Kt(_0xc3540b),_0x343b10=ds(_0x2cc0a7,_0x1525b9,_0x4bd73c);_0x14ec6c['currentOutputSnapshotRaw']=_0x2cc0a7,_0x14ec6c['currentOutputSnapshotResolved']=_0x343b10,_0x14ec6c['currentWriteId']=Hn(_0xc3540b),_0x4ba2a2['splice'](_0x4ba2a2['indexOf'](_0x2aaa71),0x1),_0x454e17=_0x454e17['concat'](os(_0xc3540b['serverSyncTree_'],_0x14ec6c['path'],_0x343b10,_0x14ec6c['currentWriteId'],_0x14ec6c['applyLocally'])),_0x454e17=_0x454e17['concat'](pe(_0xc3540b['serverSyncTree_'],_0x2aaa71,!0x0));}else _0x47de3d=!0x0,_0x3f648c='nodata',_0x454e17=_0x454e17['concat'](pe(_0xc3540b['serverSyncTree_'],_0x14ec6c['currentWriteId'],!0x0));}}}H(_0xc3540b['eventQueue_'],_0x225a37,_0x454e17),_0x454e17=[],_0x47de3d&&(_0x5b9eb8[_0x542309]['status']=0x2,function(_0x97f055){setTimeout(_0x97f055,Math['floor'](0x0));}(_0x5b9eb8[_0x542309]['unwatcher']),_0x5b9eb8[_0x542309]['onComplete']&&(_0x3f648c==='nodata'?_0x30de65['push'](()=>_0x5b9eb8[_0x542309]['onComplete'](null,!0x1,_0x5b9eb8[_0x542309]['currentInputSnapshot'])):_0x30de65['push'](()=>_0x5b9eb8[_0x542309]['onComplete'](new Error(_0x3f648c),!0x1,null))));}Gn(_0xc3540b,_0xc3540b['transactionQueueTree_']);for(let _0x3008be=0x0;_0x3008be<_0x30de65['length'];_0x3008be++)ht(_0x30de65[_0x3008be]);$n(_0xc3540b,_0xc3540b['transactionQueueTree_']);}function ua(_0x3e850d,_0x53415e){let _0x4780b3,_0x4af340=_0x3e850d['transactionQueueTree_'];for(_0x4780b3=y(_0x53415e);_0x4780b3!==null&&Ge(_0x4af340)===void 0x0;)_0x4af340=Wn(_0x4af340,_0x4780b3),_0x53415e=b(_0x53415e),_0x4780b3=y(_0x53415e);return _0x4af340;}function da(_0x487df5,_0x39c2e8){const _0x42b226=[];return fa(_0x487df5,_0x39c2e8,_0x42b226),_0x42b226['sort']((_0x508319,_0x12deb9)=>_0x508319['order']-_0x12deb9['order']),_0x42b226;}function fa(_0x9e6a39,_0x27e82f,_0x1ded89){const _0x16784e=Ge(_0x27e82f);if(_0x16784e){for(let _0x3fa7e7=0x0;_0x3fa7e7<_0x16784e['length'];_0x3fa7e7++)_0x1ded89['push'](_0x16784e[_0x3fa7e7]);}Bn(_0x27e82f,_0x424525=>{fa(_0x9e6a39,_0x424525,_0x1ded89);});}function Gn(_0x1fafe3,_0x143246){const _0x36ebb0=Ge(_0x143246);if(_0x36ebb0){let _0x53774b=0x0;for(let _0x852907=0x0;_0x852907<_0x36ebb0['length'];_0x852907++)_0x36ebb0[_0x852907]['status']!==0x2&&(_0x36ebb0[_0x53774b]=_0x36ebb0[_0x852907],_0x53774b++);_0x36ebb0['length']=_0x53774b,_s(_0x143246,_0x36ebb0['length']>0x0?_0x36ebb0:void 0x0);}Bn(_0x143246,_0x16dace=>{Gn(_0x1fafe3,_0x16dace);});}function Is(_0x22fba6,_0x5cf0f5){const _0x16f2c7=qt(ua(_0x22fba6,_0x5cf0f5)),_0x1708c3=Wn(_0x22fba6['transactionQueueTree_'],_0x5cf0f5);return ad(_0x1708c3,_0x295ee8=>{ci(_0x22fba6,_0x295ee8);}),ci(_0x22fba6,_0x1708c3),sa(_0x1708c3,_0x3145a0=>{ci(_0x22fba6,_0x3145a0);}),_0x16f2c7;}function ci(_0x21b730,_0x7f6f35){const _0x220966=Ge(_0x7f6f35);if(_0x220966){const _0x3f4434=[];let _0x40ec8d=[],_0x219209=-0x1;for(let _0x2179d5=0x0;_0x2179d5<_0x220966['length'];_0x2179d5++)_0x220966[_0x2179d5]['status']===0x3||(_0x220966[_0x2179d5]['status']===0x1?(f(_0x219209===_0x2179d5-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x219209=_0x2179d5,_0x220966[_0x2179d5]['status']=0x3,_0x220966[_0x2179d5]['abortReason']='set'):(f(_0x220966[_0x2179d5]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x220966[_0x2179d5]['unwatcher'](),_0x40ec8d=_0x40ec8d['concat'](pe(_0x21b730['serverSyncTree_'],_0x220966[_0x2179d5]['currentWriteId'],!0x0)),_0x220966[_0x2179d5]['onComplete']&&_0x3f4434['push'](_0x220966[_0x2179d5]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x219209===-0x1?_s(_0x7f6f35,void 0x0):_0x220966['length']=_0x219209+0x1,H(_0x21b730['eventQueue_'],qt(_0x7f6f35),_0x40ec8d);for(let _0x5c00e5=0x0;_0x5c00e5<_0x3f4434['length'];_0x5c00e5++)ht(_0x3f4434[_0x5c00e5]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0xa4be19){let _0x2dd67f='';const _0x2faf4d=_0xa4be19['split']('/');for(let _0x26f87a=0x0;_0x26f87a<_0x2faf4d['length'];_0x26f87a++)if(_0x2faf4d[_0x26f87a]['length']>0x0){let _0x5aeaf1=_0x2faf4d[_0x26f87a];try{_0x5aeaf1=decodeURIComponent(_0x5aeaf1['replace'](/\+/g,'\x20'));}catch{}_0x2dd67f+='/'+_0x5aeaf1;}return _0x2dd67f;}function Dd(_0x4d7691){const _0x40e6f6={};_0x4d7691['charAt'](0x0)==='?'&&(_0x4d7691=_0x4d7691['substring'](0x1));for(const _0x20fad6 of _0x4d7691['split']('&')){if(_0x20fad6['length']===0x0)continue;const _0x3de000=_0x20fad6['split']('=');_0x3de000['length']===0x2?_0x40e6f6[decodeURIComponent(_0x3de000[0x0])]=decodeURIComponent(_0x3de000[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x20fad6+'\x27\x20in\x20query\x20\x27'+_0x4d7691+'\x27');}return _0x40e6f6;}const vr=function(_0x15502b,_0x256bd8){const _0x4bdc8c=Md(_0x15502b),_0x134031=_0x4bdc8c['namespace'];_0x4bdc8c['domain']==='firebase.com'&&ae(_0x4bdc8c['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x134031||_0x134031==='undefined')&&_0x4bdc8c['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x4bdc8c['secure']||$l();const _0x311b2a=_0x4bdc8c['scheme']==='ws'||_0x4bdc8c['scheme']==='wss';return{'repoInfo':new yo(_0x4bdc8c['host'],_0x4bdc8c['secure'],_0x134031,_0x311b2a,_0x256bd8,'',_0x134031!==_0x4bdc8c['subdomain']),'path':new C(_0x4bdc8c['pathString'])};},Md=function(_0x574dd0){let _0x5428a1='',_0x59b56d='',_0x472c90='',_0x18a1c3='',_0xcb7d07='',_0x38cd08=!0x0,_0x344eaa='https',_0x1b7736=0x1bb;if(typeof _0x574dd0=='string'){let _0xbeeff9=_0x574dd0['indexOf']('//');_0xbeeff9>=0x0&&(_0x344eaa=_0x574dd0['substring'](0x0,_0xbeeff9-0x1),_0x574dd0=_0x574dd0['substring'](_0xbeeff9+0x2));let _0x362e10=_0x574dd0['indexOf']('/');_0x362e10===-0x1&&(_0x362e10=_0x574dd0['length']);let _0x571559=_0x574dd0['indexOf']('?');_0x571559===-0x1&&(_0x571559=_0x574dd0['length']),_0x5428a1=_0x574dd0['substring'](0x0,Math['min'](_0x362e10,_0x571559)),_0x362e10<_0x571559&&(_0x18a1c3=Od(_0x574dd0['substring'](_0x362e10,_0x571559)));const _0x3999b5=Dd(_0x574dd0['substring'](Math['min'](_0x574dd0['length'],_0x571559)));_0xbeeff9=_0x5428a1['indexOf'](':'),_0xbeeff9>=0x0?(_0x38cd08=_0x344eaa==='https'||_0x344eaa==='wss',_0x1b7736=parseInt(_0x5428a1['substring'](_0xbeeff9+0x1),0xa)):_0xbeeff9=_0x5428a1['length'];const _0x1fad39=_0x5428a1['slice'](0x0,_0xbeeff9);if(_0x1fad39['toLowerCase']()==='localhost')_0x59b56d='localhost';else{if(_0x1fad39['split']('.')['length']<=0x2)_0x59b56d=_0x1fad39;else{const _0x31118a=_0x5428a1['indexOf']('.');_0x472c90=_0x5428a1['substring'](0x0,_0x31118a)['toLowerCase'](),_0x59b56d=_0x5428a1['substring'](_0x31118a+0x1),_0xcb7d07=_0x472c90;}}'ns'in _0x3999b5&&(_0xcb7d07=_0x3999b5['ns']);}return{'host':_0x5428a1,'port':_0x1b7736,'domain':_0x59b56d,'subdomain':_0x472c90,'secure':_0x38cd08,'scheme':_0x344eaa,'pathString':_0x18a1c3,'namespace':_0xcb7d07};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x573a0b=0x0;const _0x1745b7=[];return function(_0x4a03f9){const _0x2b85f1=_0x4a03f9===_0x573a0b;_0x573a0b=_0x4a03f9;let _0x3a53e2;const _0x48fe67=new Array(0x8);for(_0x3a53e2=0x7;_0x3a53e2>=0x0;_0x3a53e2--)_0x48fe67[_0x3a53e2]=Er['charAt'](_0x4a03f9%0x40),_0x4a03f9=Math['floor'](_0x4a03f9/0x40);f(_0x4a03f9===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0xb1ad0f=_0x48fe67['join']('');if(_0x2b85f1){for(_0x3a53e2=0xb;_0x3a53e2>=0x0&&_0x1745b7[_0x3a53e2]===0x3f;_0x3a53e2--)_0x1745b7[_0x3a53e2]=0x0;_0x1745b7[_0x3a53e2]++;}else{for(_0x3a53e2=0x0;_0x3a53e2<0xc;_0x3a53e2++)_0x1745b7[_0x3a53e2]=Math['floor'](Math['random']()*0x40);}for(_0x3a53e2=0x0;_0x3a53e2<0xc;_0x3a53e2++)_0xb1ad0f+=Er['charAt'](_0x1745b7[_0x3a53e2]);return f(_0xb1ad0f['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0xb1ad0f;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x508b3c,_0x4ecdf3,_0x97fbba,_0x29bc61){this['eventType']=_0x508b3c,this['eventRegistration']=_0x4ecdf3,this['snapshot']=_0x97fbba,this['prevName']=_0x29bc61;}['getPath'](){const _0x4726e8=this['snapshot']['ref'];return this['eventType']==='value'?_0x4726e8['_path']:_0x4726e8['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x380513,_0x2a091a,_0x304cbd){this['eventRegistration']=_0x380513,this['error']=_0x2a091a,this['path']=_0x304cbd;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x229b66,_0x5b0685){this['snapshotCallback']=_0x229b66,this['cancelCallback']=_0x5b0685;}['onValue'](_0x41b80e,_0x496656){this['snapshotCallback']['call'](null,_0x41b80e,_0x496656);}['onCancel'](_0x406f9c){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x406f9c);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x35f1f8){return this['snapshotCallback']===_0x35f1f8['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x35f1f8['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x35f1f8['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x20eb24,_0x43cc06,_0x11d830,_0x65f09c){this['_repo']=_0x20eb24,this['_path']=_0x43cc06,this['_queryParams']=_0x11d830,this['_orderByCalled']=_0x65f09c;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x12268d=rr(this['_queryParams']),_0x400b89=Hi(_0x12268d);return _0x400b89==='{}'?'default':_0x400b89;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x49ea8b){if(_0x49ea8b=N(_0x49ea8b),!(_0x49ea8b instanceof be))return!0x1;const _0xa0737d=this['_repo']===_0x49ea8b['_repo'],_0xbd474d=ji(this['_path'],_0x49ea8b['_path']),_0x20be7b=this['_queryIdentifier']===_0x49ea8b['_queryIdentifier'];return _0xa0737d&&_0xbd474d&&_0x20be7b;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x1f7090,_0x165c65){if(_0x1f7090['_orderByCalled']===!0x0)throw new Error(_0x165c65+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x40c72f){let _0x3b8c63=null,_0xda66c=null;if(_0x40c72f['hasStart']()&&(_0x3b8c63=_0x40c72f['getIndexStartValue']()),_0x40c72f['hasEnd']()&&(_0xda66c=_0x40c72f['getIndexEndValue']()),_0x40c72f['getIndex']()===ye){const _0x20a7c4='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x58541c='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x40c72f['hasStart']()){if(_0x40c72f['getIndexStartName']()!==Fe)throw new Error(_0x20a7c4);if(typeof _0x3b8c63!='string')throw new Error(_0x58541c);}if(_0x40c72f['hasEnd']()){if(_0x40c72f['getIndexEndName']()!==Ie)throw new Error(_0x20a7c4);if(typeof _0xda66c!='string')throw new Error(_0x58541c);}}else{if(_0x40c72f['getIndex']()===R){if(_0x3b8c63!=null&&!Tn(_0x3b8c63)||_0xda66c!=null&&!Tn(_0xda66c))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x40c72f['getIndex']()instanceof Qi||_0x40c72f['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x3b8c63!=null&&typeof _0x3b8c63=='object'||_0xda66c!=null&&typeof _0xda66c=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x3c7ba5){if(_0x3c7ba5['hasStart']()&&_0x3c7ba5['hasEnd']()&&_0x3c7ba5['hasLimit']()&&!_0x3c7ba5['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x4864fe,_0x25b7e6){super(_0x4864fe,_0x25b7e6,new Xi(),!0x1);}get['parent'](){const _0x8792d2=Ro(this['_path']);return _0x8792d2===null?null:new ee(this['_repo'],_0x8792d2);}get['root'](){let _0x14f64c=this;for(;_0x14f64c['parent']!==null;)_0x14f64c=_0x14f64c['parent'];return _0x14f64c;}}class st{constructor(_0x116ab3,_0x388aaf,_0x59a26c){this['_node']=_0x116ab3,this['ref']=_0x388aaf,this['_index']=_0x59a26c;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x5b6da6){const _0x288505=new C(_0x5b6da6),_0x23a697=Ft(this['ref'],_0x5b6da6);return new st(this['_node']['getChild'](_0x288505),_0x23a697,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x224045){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x28a9ce,_0x4c4e1c)=>_0x224045(new st(_0x4c4e1c,Ft(this['ref'],_0x28a9ce),R)));}['hasChild'](_0xb6de52){const _0x4b9cdd=new C(_0xb6de52);return!this['_node']['getChild'](_0x4b9cdd)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x32830f,_0x512aa5){return _0x32830f=N(_0x32830f),_0x32830f['_checkNotDeleted']('ref'),_0x512aa5!==void 0x0?Ft(_0x32830f['_root'],_0x512aa5):_0x32830f['_root'];}function Ft(_0x43911e,_0x2e5c36){return _0x43911e=N(_0x43911e),y(_0x43911e['_path'])===null?pd('child','path',_0x2e5c36):ms('child','path',_0x2e5c36),new ee(_0x43911e['_repo'],k(_0x43911e['_path'],_0x2e5c36));}function g_(_0x5e63c7,_0x5cdb43){_0x5e63c7=N(_0x5e63c7),ys('push',_0x5e63c7['_path']),zt('push',_0x5cdb43,_0x5e63c7['_path'],!0x0);const _0x1eec2d=la(_0x5e63c7['_repo']),_0x1bd682=Ld(_0x1eec2d),_0x5c6848=Ft(_0x5e63c7,_0x1bd682),_0x28a368=Ft(_0x5e63c7,_0x1bd682);let _0x22d635;return _0x5cdb43!=null?_0x22d635=Ud(_0x28a368,_0x5cdb43)['then'](()=>_0x28a368):_0x22d635=Promise['resolve'](_0x28a368),_0x5c6848['then']=_0x22d635['then']['bind'](_0x22d635),_0x5c6848['catch']=_0x22d635['then']['bind'](_0x22d635,void 0x0),_0x5c6848;}function Ud(_0x445993,_0x594b32){_0x445993=N(_0x445993),ys('set',_0x445993['_path']),zt('set',_0x594b32,_0x445993['_path'],!0x1);const _0x523392=new ot();return Cd(_0x445993['_repo'],_0x445993['_path'],_0x594b32,null,_0x523392['wrapCallback'](()=>{})),_0x523392['promise'];}function m_(_0x20e066,_0x110148){fd('update',_0x110148,_0x20e066['_path']);const _0x553e61=new ot();return Td(_0x20e066['_repo'],_0x20e066['_path'],_0x110148,_0x553e61['wrapCallback'](()=>{})),_0x553e61['promise'];}function y_(_0x4e442d){_0x4e442d=N(_0x4e442d);const _0x14339b=new pa(()=>{}),_0x3059ca=new zn(_0x14339b);return wd(_0x4e442d['_repo'],_0x4e442d,_0x3059ca)['then'](_0x3215b5=>new st(_0x3215b5,new ee(_0x4e442d['_repo'],_0x4e442d['_path']),_0x4e442d['_queryParams']['getIndex']()));}class zn{constructor(_0x4f0da1){this['callbackContext']=_0x4f0da1;}['respondsTo'](_0x8ccce8){return _0x8ccce8==='value';}['createEvent'](_0x3d6f27,_0x7722d){const _0x27749b=_0x7722d['_queryParams']['getIndex']();return new xd('value',this,new st(_0x3d6f27['snapshotNode'],new ee(_0x7722d['_repo'],_0x7722d['_path']),_0x27749b));}['getEventRunner'](_0x3a5c18){return _0x3a5c18['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x3a5c18['error']):()=>this['callbackContext']['onValue'](_0x3a5c18['snapshot'],null);}['createCancelEvent'](_0x37b015,_0xe1259a){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x37b015,_0xe1259a):null;}['matches'](_0x34ef39){return _0x34ef39 instanceof zn?!_0x34ef39['callbackContext']||!this['callbackContext']?!0x0:_0x34ef39['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x4546c1,_0x4b3ba5,_0x3e9b09,_0x1eee1f,_0x2ae371){const _0x1d47a8=new pa(_0x3e9b09,void 0x0),_0x65b71a=new zn(_0x1d47a8);return bd(_0x4546c1['_repo'],_0x4546c1,_0x65b71a),()=>Rd(_0x4546c1['_repo'],_0x4546c1,_0x65b71a);}function Bd(_0x5783a7,_0x209944,_0x11f8e4,_0x3b99fd){return Wd(_0x5783a7,'value',_0x209944);}class ft{}class ma extends ft{constructor(_0x2445d0,_0x25d02a){super(),this['_value']=_0x2445d0,this['_key']=_0x25d02a,this['type']='endAt';}['_apply'](_0x4ae413){zt('endAt',this['_value'],_0x4ae413['_path'],!0x0);const _0x3a079b=Jh(_0x4ae413['_queryParams'],this['_value'],this['_key']);if(ga(_0x3a079b),qn(_0x3a079b),_0x4ae413['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x4ae413['_repo'],_0x4ae413['_path'],_0x3a079b,_0x4ae413['_orderByCalled']);}}function v_(_0x58fdf5,_0x40965a){return new ma(_0x58fdf5,_0x40965a);}class ya extends ft{constructor(_0x54dd2a,_0x2deec1){super(),this['_value']=_0x54dd2a,this['_key']=_0x2deec1,this['type']='startAt';}['_apply'](_0x36e81c){zt('startAt',this['_value'],_0x36e81c['_path'],!0x0);const _0xafb3eb=Qh(_0x36e81c['_queryParams'],this['_value'],this['_key']);if(ga(_0xafb3eb),qn(_0xafb3eb),_0x36e81c['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x36e81c['_repo'],_0x36e81c['_path'],_0xafb3eb,_0x36e81c['_orderByCalled']);}}function E_(_0x21a5df=null,_0x432874){return new ya(_0x21a5df,_0x432874);}class Vd extends ft{constructor(_0x59b8d7){super(),this['_limit']=_0x59b8d7,this['type']='limitToFirst';}['_apply'](_0x20fca2){if(_0x20fca2['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x20fca2['_repo'],_0x20fca2['_path'],Yh(_0x20fca2['_queryParams'],this['_limit']),_0x20fca2['_orderByCalled']);}}function I_(_0xc8654c){if(Math['floor'](_0xc8654c)!==_0xc8654c||_0xc8654c<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0xc8654c);}class Hd extends ft{constructor(_0x11ad98){super(),this['_path']=_0x11ad98,this['type']='orderByChild';}['_apply'](_0x414f75){_a(_0x414f75,'orderByChild');const _0x5372cc=new C(this['_path']);if(v(_0x5372cc))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x5bd686=new Qi(_0x5372cc),_0x50d41a=xo(_0x414f75['_queryParams'],_0x5bd686);return qn(_0x50d41a),new be(_0x414f75['_repo'],_0x414f75['_path'],_0x50d41a,!0x0);}}function w_(_0x595081){if(_0x595081==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x595081==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x595081==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x595081),new Hd(_0x595081);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x880475){_a(_0x880475,'orderByKey');const _0xaf1ea7=xo(_0x880475['_queryParams'],ye);return qn(_0xaf1ea7),new be(_0x880475['_repo'],_0x880475['_path'],_0xaf1ea7,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x1e4784,_0x5ec750){super(),this['_value']=_0x1e4784,this['_key']=_0x5ec750,this['type']='equalTo';}['_apply'](_0x2e798e){if(zt('equalTo',this['_value'],_0x2e798e['_path'],!0x1),_0x2e798e['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x2e798e['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x2e798e));}}function T_(_0x279d46,_0x2114d2){return new Gd(_0x279d46,_0x2114d2);}function S_(_0x424f28,..._0xad7389){let _0x15d5c3=N(_0x424f28);for(const _0x354138 of _0xad7389)_0x15d5c3=_0x354138['_apply'](_0x15d5c3);return _0x15d5c3;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x4634aa,_0x1094f6,_0x244ce2,_0x5e246e){const _0x471285=_0x1094f6['lastIndexOf'](':'),_0x1e177a=_0x1094f6['substring'](0x0,_0x471285),_0x2b6707=at(_0x1e177a);_0x4634aa['repoInfo_']=new yo(_0x1094f6,_0x2b6707,_0x4634aa['repoInfo_']['namespace'],_0x4634aa['repoInfo_']['webSocketOnly'],_0x4634aa['repoInfo_']['nodeAdmin'],_0x4634aa['repoInfo_']['persistenceKey'],_0x4634aa['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x244ce2),_0x5e246e&&(_0x4634aa['authTokenProvider_']=_0x5e246e);}function Kd(_0x11fb73,_0xb41ce1,_0x527f1f,_0xc47da2,_0x520bf4){let _0x201f26=_0xc47da2||_0x11fb73['options']['databaseURL'];_0x201f26===void 0x0&&(_0x11fb73['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x11fb73['options']['projectId']),_0x201f26=_0x11fb73['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x37678d=vr(_0x201f26,_0x520bf4),_0x1f7c68=_0x37678d['repoInfo'],_0x25d5b7;typeof process<'u'&&Vs&&(_0x25d5b7=Vs[qd]),_0x25d5b7?(_0x201f26='http://'+_0x25d5b7+'?ns='+_0x1f7c68['namespace'],_0x37678d=vr(_0x201f26,_0x520bf4),_0x1f7c68=_0x37678d['repoInfo']):_0x37678d['repoInfo']['secure'];const _0x242002=new eh(_0x11fb73['name'],_0x11fb73['options'],_0xb41ce1);_d('Invalid\x20Firebase\x20Database\x20URL',_0x37678d),v(_0x37678d['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x478424=Qd(_0x1f7c68,_0x11fb73,_0x242002,new Zl(_0x11fb73,_0x527f1f));return new Jd(_0x478424,_0x11fb73);}function Yd(_0x403c8a,_0xf43b92){const _0x28ffd5=Ni[_0xf43b92];(!_0x28ffd5||_0x28ffd5[_0x403c8a['key']]!==_0x403c8a)&&ae('Database\x20'+_0xf43b92+'('+_0x403c8a['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x403c8a),delete _0x28ffd5[_0x403c8a['key']];}function Qd(_0x50ad10,_0x5789e9,_0x265808,_0x4bee40){let _0x16a34a=Ni[_0x5789e9['name']];_0x16a34a||(_0x16a34a={},Ni[_0x5789e9['name']]=_0x16a34a);let _0x149ae6=_0x16a34a[_0x50ad10['toURLString']()];return _0x149ae6&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x149ae6=new vd(_0x50ad10,zd,_0x265808,_0x4bee40),_0x16a34a[_0x50ad10['toURLString']()]=_0x149ae6,_0x149ae6;}class Jd{constructor(_0x1aa127,_0x1bf2d0){this['_repoInternal']=_0x1aa127,this['app']=_0x1bf2d0,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x388544){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x388544+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x150c3a=Zr(),_0x315e5f){const _0x10bc14=Bi(_0x150c3a,'database')['getImmediate']({'identifier':_0x315e5f});if(!_0x10bc14['_instanceStarted']){const _0x24e23d=cc('database');_0x24e23d&&Xd(_0x10bc14,..._0x24e23d);}return _0x10bc14;}function Xd(_0x54288b,_0x2936b0,_0x50ba6a,_0x265cc5={}){_0x54288b=N(_0x54288b),_0x54288b['_checkNotDeleted']('useEmulator');const _0x54261b=_0x2936b0+':'+_0x50ba6a,_0x1b1717=_0x54288b['_repoInternal'];if(_0x54288b['_instanceStarted']){if(_0x54261b===_0x54288b['_repoInternal']['repoInfo_']['host']&&Me(_0x265cc5,_0x1b1717['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x5ae085;if(_0x1b1717['repoInfo_']['nodeAdmin'])_0x265cc5['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x5ae085=new nn(nn['OWNER']);else{if(_0x265cc5['mockUserToken']){const _0x12e5b7=typeof _0x265cc5['mockUserToken']=='string'?_0x265cc5['mockUserToken']:lc(_0x265cc5['mockUserToken'],_0x54288b['app']['options']['projectId']);_0x5ae085=new nn(_0x12e5b7);}}at(_0x2936b0)&&(jr(_0x2936b0),Kr('Database',!0x0)),jd(_0x1b1717,_0x54261b,_0x265cc5,_0x5ae085);}function R_(_0x4e3099){_0x4e3099=N(_0x4e3099),_0x4e3099['_checkNotDeleted']('goOffline'),ha(_0x4e3099['_repo']);}function A_(_0x2d851d){_0x2d851d=N(_0x2d851d),_0x2d851d['_checkNotDeleted']('goOnline'),Ad(_0x2d851d['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x43b193){Ul(lt),Ze(new Le('database',(_0x43ef2a,{instanceIdentifier:_0x9f3552})=>{const _0x49afaa=_0x43ef2a['getProvider']('app')['getImmediate'](),_0x673f8c=_0x43ef2a['getProvider']('auth-internal'),_0x3ec44b=_0x43ef2a['getProvider']('app-check-internal');return Kd(_0x49afaa,_0x673f8c,_0x3ec44b,_0x9f3552);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x43b193),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x36b1c4,_0x15c652){this['committed']=_0x36b1c4,this['snapshot']=_0x15c652;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x85644b,_0x5b3ae7,_0x4a8bb8){if(_0x85644b=N(_0x85644b),ys('Reference.transaction',_0x85644b['_path']),_0x85644b['key']==='.length'||_0x85644b['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x85644b['key']+'\x20is\x20a\x20read-only\x20object.';const _0x388394=!0x0,_0x555dce=new ot(),_0x1da1ab=(_0x2c918d,_0x393395,_0x14c85c)=>{let _0x2e5813=null;_0x2c918d?_0x555dce['reject'](_0x2c918d):(_0x2e5813=new st(_0x14c85c,new ee(_0x85644b['_repo'],_0x85644b['_path']),R),_0x555dce['resolve'](new tf(_0x393395,_0x2e5813)));},_0x52e79b=Bd(_0x85644b,()=>{});return kd(_0x85644b['_repo'],_0x85644b['_path'],_0x5b3ae7,_0x1da1ab,_0x52e79b,_0x388394),_0x555dce['promise'];}se['prototype']['simpleListen']=function(_0x15fdfc,_0x7a1d66){this['sendRequest']('q',{'p':_0x15fdfc},_0x7a1d66);},se['prototype']['echo']=function(_0xe89511,_0x5d0b64){this['sendRequest']('echo',{'d':_0xe89511},_0x5d0b64);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x1a71ff,..._0x366432){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x1a71ff,..._0x366432);}function sn(_0xf1c1cb,..._0x47c881){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0xf1c1cb,..._0x47c881);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x2a33af,..._0x273421){throw ws(_0x2a33af,..._0x273421);}function X(_0x420d9a,..._0x53d96e){return ws(_0x420d9a,..._0x53d96e);}function Ia(_0x559c5d,_0x168a23,_0x5edd5d){const _0x54ed18={...nf(),[_0x168a23]:_0x5edd5d};return new Bt('auth','Firebase',_0x54ed18)['create'](_0x168a23,{'appName':_0x559c5d['name']});}function re(_0x2a7dd4){return Ia(_0x2a7dd4,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x3afedd,..._0x39bf31){if(typeof _0x3afedd!='string'){const _0xc00fc9=_0x39bf31[0x0],_0x44aabb=[..._0x39bf31['slice'](0x1)];return _0x44aabb[0x0]&&(_0x44aabb[0x0]['appName']=_0x3afedd['name']),_0x3afedd['_errorFactory']['create'](_0xc00fc9,..._0x44aabb);}return Ea['create'](_0x3afedd,..._0x39bf31);}function m(_0x43c2dc,_0x2a229a,..._0x338c64){if(!_0x43c2dc)throw ws(_0x2a229a,..._0x338c64);}function ne(_0x22989f){const _0x31d393='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x22989f;throw sn(_0x31d393),new Error(_0x31d393);}function ce(_0x22f107,_0x29a00e){_0x22f107||ne(_0x29a00e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x58f8a4;return typeof self<'u'&&((_0x58f8a4=self['location'])==null?void 0x0:_0x58f8a4['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x3c0545;return typeof self<'u'&&((_0x3c0545=self['location'])==null?void 0x0:_0x3c0545['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x1a7178=navigator;return _0x1a7178['languages']&&_0x1a7178['languages'][0x0]||_0x1a7178['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x243bad,_0x1366e5){this['shortDelay']=_0x243bad,this['longDelay']=_0x1366e5,ce(_0x1366e5>_0x243bad,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x9fa576,_0x29cd33){ce(_0x9fa576['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x280289}=_0x9fa576['emulator'];return _0x29cd33?''+_0x280289+(_0x29cd33['startsWith']('/')?_0x29cd33['slice'](0x1):_0x29cd33):_0x280289;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x3fe3c7,_0x34734c,_0x3c0ccd){this['fetchImpl']=_0x3fe3c7,_0x34734c&&(this['headersImpl']=_0x34734c),_0x3c0ccd&&(this['responseImpl']=_0x3c0ccd);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x289d4e,_0x28e8af){return _0x289d4e['tenantId']&&!_0x28e8af['tenantId']?{..._0x28e8af,'tenantId':_0x289d4e['tenantId']}:_0x28e8af;}async function Ae(_0x16cf6b,_0x4445a3,_0x548b20,_0x279b5e,_0xa7f020={}){return Ca(_0x16cf6b,_0xa7f020,async()=>{let _0x4fd93f={},_0x2b7452={};_0x279b5e&&(_0x4445a3==='GET'?_0x2b7452=_0x279b5e:_0x4fd93f={'body':JSON['stringify'](_0x279b5e)});const _0x5eb9c3=ct({'key':_0x16cf6b['config']['apiKey'],..._0x2b7452})['slice'](0x1),_0x54acfa=await _0x16cf6b['_getAdditionalHeaders']();_0x54acfa['Content-Type']='application/json',_0x16cf6b['languageCode']&&(_0x54acfa['X-Firebase-Locale']=_0x16cf6b['languageCode']);const _0x366c99={'method':_0x4445a3,'headers':_0x54acfa,..._0x4fd93f};return dc()||(_0x366c99['referrerPolicy']='no-referrer'),_0x16cf6b['emulatorConfig']&&at(_0x16cf6b['emulatorConfig']['host'])&&(_0x366c99['credentials']='include'),wa['fetch']()(await Ta(_0x16cf6b,_0x16cf6b['config']['apiHost'],_0x548b20,_0x5eb9c3),_0x366c99);});}async function Ca(_0x4e648a,_0x35eef5,_0x2a093d){_0x4e648a['_canInitEmulator']=!0x1;const _0x5a5ff5={...cf,..._0x35eef5};try{const _0x56f5a9=new df(_0x4e648a),_0x3ef7ed=await Promise['race']([_0x2a093d(),_0x56f5a9['promise']]);_0x56f5a9['clearNetworkTimeout']();const _0x3de0dd=await _0x3ef7ed['json']();if('needConfirmation'in _0x3de0dd)throw tn(_0x4e648a,'account-exists-with-different-credential',_0x3de0dd);if(_0x3ef7ed['ok']&&!('errorMessage'in _0x3de0dd))return _0x3de0dd;{const _0x5e1b13=_0x3ef7ed['ok']?_0x3de0dd['errorMessage']:_0x3de0dd['error']['message'],[_0x5eb30d,_0x5c458b]=_0x5e1b13['split']('\x20:\x20');if(_0x5eb30d==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x4e648a,'credential-already-in-use',_0x3de0dd);if(_0x5eb30d==='EMAIL_EXISTS')throw tn(_0x4e648a,'email-already-in-use',_0x3de0dd);if(_0x5eb30d==='USER_DISABLED')throw tn(_0x4e648a,'user-disabled',_0x3de0dd);const _0x3d331d=_0x5a5ff5[_0x5eb30d]||_0x5eb30d['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x5c458b)throw Ia(_0x4e648a,_0x3d331d,_0x5c458b);Q(_0x4e648a,_0x3d331d);}}catch(_0x3f63b7){if(_0x3f63b7 instanceof Se)throw _0x3f63b7;Q(_0x4e648a,'network-request-failed',{'message':String(_0x3f63b7)});}}async function Qt(_0x9746a6,_0x13ab8b,_0x59b8c1,_0x2a9910,_0x1884de={}){const _0x28efea=await Ae(_0x9746a6,_0x13ab8b,_0x59b8c1,_0x2a9910,_0x1884de);return'mfaPendingCredential'in _0x28efea&&Q(_0x9746a6,'multi-factor-auth-required',{'_serverResponse':_0x28efea}),_0x28efea;}async function Ta(_0x1177b3,_0x37065b,_0x1b262b,_0x20a38c){const _0x4cf697=''+_0x37065b+_0x1b262b+'?'+_0x20a38c,_0x3c5d83=_0x1177b3,_0x2ee7c7=_0x3c5d83['config']['emulator']?Cs(_0x1177b3['config'],_0x4cf697):_0x1177b3['config']['apiScheme']+'://'+_0x4cf697;return lf['includes'](_0x1b262b)&&(await _0x3c5d83['_persistenceManagerAvailable'],_0x3c5d83['_getPersistenceType']()==='COOKIE')?_0x3c5d83['_getPersistence']()['_getFinalTarget'](_0x2ee7c7)['toString']():_0x2ee7c7;}function uf(_0x2279b4){switch(_0x2279b4){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x466e7b){this['auth']=_0x466e7b,this['timer']=null,this['promise']=new Promise((_0x443d0d,_0x458b3b)=>{this['timer']=setTimeout(()=>_0x458b3b(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x4edcd0,_0x3ac77c,_0x45754e){const _0x1f97b0={'appName':_0x4edcd0['name']};_0x45754e['email']&&(_0x1f97b0['email']=_0x45754e['email']),_0x45754e['phoneNumber']&&(_0x1f97b0['phoneNumber']=_0x45754e['phoneNumber']);const _0x2f9dde=X(_0x4edcd0,_0x3ac77c,_0x1f97b0);return _0x2f9dde['customData']['_tokenResponse']=_0x45754e,_0x2f9dde;}function wr(_0xa93c74){return _0xa93c74!==void 0x0&&_0xa93c74['enterprise']!==void 0x0;}class ff{constructor(_0x5bfbdc){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x5bfbdc['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x5bfbdc['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x5bfbdc['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x1bcd95){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x37b8c5 of this['recaptchaEnforcementState'])if(_0x37b8c5['provider']&&_0x37b8c5['provider']===_0x1bcd95)return uf(_0x37b8c5['enforcementState']);return null;}['isProviderEnabled'](_0x4e061f){return this['getProviderEnforcementState'](_0x4e061f)==='ENFORCE'||this['getProviderEnforcementState'](_0x4e061f)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x388814,_0xfa9e74){return Ae(_0x388814,'GET','/v2/recaptchaConfig',Re(_0x388814,_0xfa9e74));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x1e45bf,_0x164054){return Ae(_0x1e45bf,'POST','/v1/accounts:delete',_0x164054);}async function bn(_0x2b366c,_0x686301){return Ae(_0x2b366c,'POST','/v1/accounts:lookup',_0x686301);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x22c68a){if(_0x22c68a)try{const _0x19160a=new Date(Number(_0x22c68a));if(!isNaN(_0x19160a['getTime']()))return _0x19160a['toUTCString']();}catch{}}async function gf(_0x4dc137,_0x38ef9c=!0x1){const _0x152097=N(_0x4dc137),_0x188eb0=await _0x152097['getIdToken'](_0x38ef9c),_0x16ea2f=Ts(_0x188eb0);m(_0x16ea2f&&_0x16ea2f['exp']&&_0x16ea2f['auth_time']&&_0x16ea2f['iat'],_0x152097['auth'],'internal-error');const _0x174d1e=typeof _0x16ea2f['firebase']=='object'?_0x16ea2f['firebase']:void 0x0,_0x1cd845=_0x174d1e==null?void 0x0:_0x174d1e['sign_in_provider'];return{'claims':_0x16ea2f,'token':_0x188eb0,'authTime':Rt(li(_0x16ea2f['auth_time'])),'issuedAtTime':Rt(li(_0x16ea2f['iat'])),'expirationTime':Rt(li(_0x16ea2f['exp'])),'signInProvider':_0x1cd845||null,'signInSecondFactor':(_0x174d1e==null?void 0x0:_0x174d1e['sign_in_second_factor'])||null};}function li(_0x3d397a){return Number(_0x3d397a)*0x3e8;}function Ts(_0x44c414){const [_0x57c6d9,_0x4c963d,_0x47c844]=_0x44c414['split']('.');if(_0x57c6d9===void 0x0||_0x4c963d===void 0x0||_0x47c844===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x7d79b9=ln(_0x4c963d);return _0x7d79b9?JSON['parse'](_0x7d79b9):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0xea60b9){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0xea60b9==null?void 0x0:_0xea60b9['toString']()),null;}}function Cr(_0x15cc4e){const _0x495042=Ts(_0x15cc4e);return m(_0x495042,'internal-error'),m(typeof _0x495042['exp']<'u','internal-error'),m(typeof _0x495042['iat']<'u','internal-error'),Number(_0x495042['exp'])-Number(_0x495042['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x415776,_0x2d69f8,_0x27e2ba=!0x1){if(_0x27e2ba)return _0x2d69f8;try{return await _0x2d69f8;}catch(_0x30757e){throw _0x30757e instanceof Se&&mf(_0x30757e)&&_0x415776['auth']['currentUser']===_0x415776&&await _0x415776['auth']['signOut'](),_0x30757e;}}function mf({code:_0xadf30e}){return _0xadf30e==='auth/user-disabled'||_0xadf30e==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x13859d){this['user']=_0x13859d,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x4824ec){if(_0x4824ec){const _0x282c45=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x282c45;}else{this['errorBackoff']=0x7530;const _0x4b2c1a=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x4b2c1a);}}['schedule'](_0x1fd61b=!0x1){if(!this['isRunning'])return;const _0x3d5c84=this['getInterval'](_0x1fd61b);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x3d5c84);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x475745){(_0x475745==null?void 0x0:_0x475745['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x16123b,_0x47f1f3){this['createdAt']=_0x16123b,this['lastLoginAt']=_0x47f1f3,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x58e3ca){this['createdAt']=_0x58e3ca['createdAt'],this['lastLoginAt']=_0x58e3ca['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x4e0e8b){var _0x38fe5d;const _0x4597d6=_0x4e0e8b['auth'],_0xfc8ce6=await _0x4e0e8b['getIdToken'](),_0x4ff597=await Ut(_0x4e0e8b,bn(_0x4597d6,{'idToken':_0xfc8ce6}));m(_0x4ff597==null?void 0x0:_0x4ff597['users']['length'],_0x4597d6,'internal-error');const _0x374bca=_0x4ff597['users'][0x0];_0x4e0e8b['_notifyReloadListener'](_0x374bca);const _0x262572=(_0x38fe5d=_0x374bca['providerUserInfo'])!=null&&_0x38fe5d['length']?Sa(_0x374bca['providerUserInfo']):[],_0x4b8cf8=Ef(_0x4e0e8b['providerData'],_0x262572),_0x4738e2=_0x4e0e8b['isAnonymous'],_0x4d77b4=!(_0x4e0e8b['email']&&_0x374bca['passwordHash'])&&!(_0x4b8cf8!=null&&_0x4b8cf8['length']),_0x13b097=_0x4738e2?_0x4d77b4:!0x1,_0x24cf81={'uid':_0x374bca['localId'],'displayName':_0x374bca['displayName']||null,'photoURL':_0x374bca['photoUrl']||null,'email':_0x374bca['email']||null,'emailVerified':_0x374bca['emailVerified']||!0x1,'phoneNumber':_0x374bca['phoneNumber']||null,'tenantId':_0x374bca['tenantId']||null,'providerData':_0x4b8cf8,'metadata':new Oi(_0x374bca['createdAt'],_0x374bca['lastLoginAt']),'isAnonymous':_0x13b097};Object['assign'](_0x4e0e8b,_0x24cf81);}async function vf(_0x135fd0){const _0x278bd0=N(_0x135fd0);await Rn(_0x278bd0),await _0x278bd0['auth']['_persistUserIfCurrent'](_0x278bd0),_0x278bd0['auth']['_notifyListenersIfCurrent'](_0x278bd0);}function Ef(_0x1ee969,_0x1d2bc4){return[..._0x1ee969['filter'](_0x2f7ab4=>!_0x1d2bc4['some'](_0x15a055=>_0x15a055['providerId']===_0x2f7ab4['providerId'])),..._0x1d2bc4];}function Sa(_0x509f65){return _0x509f65['map'](({providerId:_0xf2f259,..._0x427b7f})=>({'providerId':_0xf2f259,'uid':_0x427b7f['rawId']||'','displayName':_0x427b7f['displayName']||null,'email':_0x427b7f['email']||null,'phoneNumber':_0x427b7f['phoneNumber']||null,'photoURL':_0x427b7f['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x3cab16,_0x514dfd){const _0x5658c8=await Ca(_0x3cab16,{},async()=>{const _0x4cd5f7=ct({'grant_type':'refresh_token','refresh_token':_0x514dfd})['slice'](0x1),{tokenApiHost:_0xd9438f,apiKey:_0x327a13}=_0x3cab16['config'],_0x469681=await Ta(_0x3cab16,_0xd9438f,'/v1/token','key='+_0x327a13),_0x598f66=await _0x3cab16['_getAdditionalHeaders']();_0x598f66['Content-Type']='application/x-www-form-urlencoded';const _0x9db97a={'method':'POST','headers':_0x598f66,'body':_0x4cd5f7};return _0x3cab16['emulatorConfig']&&at(_0x3cab16['emulatorConfig']['host'])&&(_0x9db97a['credentials']='include'),wa['fetch']()(_0x469681,_0x9db97a);});return{'accessToken':_0x5658c8['access_token'],'expiresIn':_0x5658c8['expires_in'],'refreshToken':_0x5658c8['refresh_token']};}async function wf(_0x2534ac,_0x180d51){return Ae(_0x2534ac,'POST','/v2/accounts:revokeToken',Re(_0x2534ac,_0x180d51));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x40310a){m(_0x40310a['idToken'],'internal-error'),m(typeof _0x40310a['idToken']<'u','internal-error'),m(typeof _0x40310a['refreshToken']<'u','internal-error');const _0x586171='expiresIn'in _0x40310a&&typeof _0x40310a['expiresIn']<'u'?Number(_0x40310a['expiresIn']):Cr(_0x40310a['idToken']);this['updateTokensAndExpiration'](_0x40310a['idToken'],_0x40310a['refreshToken'],_0x586171);}['updateFromIdToken'](_0xec8212){m(_0xec8212['length']!==0x0,'internal-error');const _0x2b7b4c=Cr(_0xec8212);this['updateTokensAndExpiration'](_0xec8212,null,_0x2b7b4c);}async['getToken'](_0x5eaf65,_0x3cd65c=!0x1){return!_0x3cd65c&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x5eaf65,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x5eaf65,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x40d2a1,_0x354e8a){const {accessToken:_0x2dfbb3,refreshToken:_0x4c664c,expiresIn:_0x956b7d}=await If(_0x40d2a1,_0x354e8a);this['updateTokensAndExpiration'](_0x2dfbb3,_0x4c664c,Number(_0x956b7d));}['updateTokensAndExpiration'](_0x21b662,_0x450c33,_0x74b0b0){this['refreshToken']=_0x450c33||null,this['accessToken']=_0x21b662||null,this['expirationTime']=Date['now']()+_0x74b0b0*0x3e8;}static['fromJSON'](_0x3d16d2,_0x28733d){const {refreshToken:_0x41c7d0,accessToken:_0x1d08c1,expirationTime:_0x3e6951}=_0x28733d,_0xcc277d=new Qe();return _0x41c7d0&&(m(typeof _0x41c7d0=='string','internal-error',{'appName':_0x3d16d2}),_0xcc277d['refreshToken']=_0x41c7d0),_0x1d08c1&&(m(typeof _0x1d08c1=='string','internal-error',{'appName':_0x3d16d2}),_0xcc277d['accessToken']=_0x1d08c1),_0x3e6951&&(m(typeof _0x3e6951=='number','internal-error',{'appName':_0x3d16d2}),_0xcc277d['expirationTime']=_0x3e6951),_0xcc277d;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x5e7ad8){this['accessToken']=_0x5e7ad8['accessToken'],this['refreshToken']=_0x5e7ad8['refreshToken'],this['expirationTime']=_0x5e7ad8['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x403caa,_0x5ab36d){m(typeof _0x403caa=='string'||typeof _0x403caa>'u','internal-error',{'appName':_0x5ab36d});}class K{constructor({uid:_0xe551f7,auth:_0x2bf368,stsTokenManager:_0x4f65ce,..._0x4afe0d}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0xe551f7,this['auth']=_0x2bf368,this['stsTokenManager']=_0x4f65ce,this['accessToken']=_0x4f65ce['accessToken'],this['displayName']=_0x4afe0d['displayName']||null,this['email']=_0x4afe0d['email']||null,this['emailVerified']=_0x4afe0d['emailVerified']||!0x1,this['phoneNumber']=_0x4afe0d['phoneNumber']||null,this['photoURL']=_0x4afe0d['photoURL']||null,this['isAnonymous']=_0x4afe0d['isAnonymous']||!0x1,this['tenantId']=_0x4afe0d['tenantId']||null,this['providerData']=_0x4afe0d['providerData']?[..._0x4afe0d['providerData']]:[],this['metadata']=new Oi(_0x4afe0d['createdAt']||void 0x0,_0x4afe0d['lastLoginAt']||void 0x0);}async['getIdToken'](_0x52c2a7){const _0x373599=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x52c2a7));return m(_0x373599,this['auth'],'internal-error'),this['accessToken']!==_0x373599&&(this['accessToken']=_0x373599,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x373599;}['getIdTokenResult'](_0xedf996){return gf(this,_0xedf996);}['reload'](){return vf(this);}['_assign'](_0x28b0d1){this!==_0x28b0d1&&(m(this['uid']===_0x28b0d1['uid'],this['auth'],'internal-error'),this['displayName']=_0x28b0d1['displayName'],this['photoURL']=_0x28b0d1['photoURL'],this['email']=_0x28b0d1['email'],this['emailVerified']=_0x28b0d1['emailVerified'],this['phoneNumber']=_0x28b0d1['phoneNumber'],this['isAnonymous']=_0x28b0d1['isAnonymous'],this['tenantId']=_0x28b0d1['tenantId'],this['providerData']=_0x28b0d1['providerData']['map'](_0x3c887d=>({..._0x3c887d})),this['metadata']['_copy'](_0x28b0d1['metadata']),this['stsTokenManager']['_assign'](_0x28b0d1['stsTokenManager']));}['_clone'](_0x1c7863){const _0x4095fb=new K({...this,'auth':_0x1c7863,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x4095fb['metadata']['_copy'](this['metadata']),_0x4095fb;}['_onReload'](_0xc36d80){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0xc36d80,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x5b5c29){this['reloadListener']?this['reloadListener'](_0x5b5c29):this['reloadUserInfo']=_0x5b5c29;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x570b17,_0x3ed714=!0x1){let _0x5b0370=!0x1;_0x570b17['idToken']&&_0x570b17['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x570b17),_0x5b0370=!0x0),_0x3ed714&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x5b0370&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x55c592=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x55c592})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x5d3dfb=>({..._0x5d3dfb})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x5baf9e,_0x18f70a){const _0x4b3eed=_0x18f70a['displayName']??void 0x0,_0x4aca15=_0x18f70a['email']??void 0x0,_0x27fcb3=_0x18f70a['phoneNumber']??void 0x0,_0x229cee=_0x18f70a['photoURL']??void 0x0,_0x284e74=_0x18f70a['tenantId']??void 0x0,_0x2f4c36=_0x18f70a['_redirectEventId']??void 0x0,_0x175247=_0x18f70a['createdAt']??void 0x0,_0x36383d=_0x18f70a['lastLoginAt']??void 0x0,{uid:_0x5c150e,emailVerified:_0x2ff116,isAnonymous:_0x222bd5,providerData:_0x1f9f19,stsTokenManager:_0x13271b}=_0x18f70a;m(_0x5c150e&&_0x13271b,_0x5baf9e,'internal-error');const _0x2f035e=Qe['fromJSON'](this['name'],_0x13271b);m(typeof _0x5c150e=='string',_0x5baf9e,'internal-error'),le(_0x4b3eed,_0x5baf9e['name']),le(_0x4aca15,_0x5baf9e['name']),m(typeof _0x2ff116=='boolean',_0x5baf9e,'internal-error'),m(typeof _0x222bd5=='boolean',_0x5baf9e,'internal-error'),le(_0x27fcb3,_0x5baf9e['name']),le(_0x229cee,_0x5baf9e['name']),le(_0x284e74,_0x5baf9e['name']),le(_0x2f4c36,_0x5baf9e['name']),le(_0x175247,_0x5baf9e['name']),le(_0x36383d,_0x5baf9e['name']);const _0xfbac8=new K({'uid':_0x5c150e,'auth':_0x5baf9e,'email':_0x4aca15,'emailVerified':_0x2ff116,'displayName':_0x4b3eed,'isAnonymous':_0x222bd5,'photoURL':_0x229cee,'phoneNumber':_0x27fcb3,'tenantId':_0x284e74,'stsTokenManager':_0x2f035e,'createdAt':_0x175247,'lastLoginAt':_0x36383d});return _0x1f9f19&&Array['isArray'](_0x1f9f19)&&(_0xfbac8['providerData']=_0x1f9f19['map'](_0x358bf7=>({..._0x358bf7}))),_0x2f4c36&&(_0xfbac8['_redirectEventId']=_0x2f4c36),_0xfbac8;}static async['_fromIdTokenResponse'](_0x47ec5b,_0x5325a6,_0x442253=!0x1){const _0x77ae71=new Qe();_0x77ae71['updateFromServerResponse'](_0x5325a6);const _0x88a93a=new K({'uid':_0x5325a6['localId'],'auth':_0x47ec5b,'stsTokenManager':_0x77ae71,'isAnonymous':_0x442253});return await Rn(_0x88a93a),_0x88a93a;}static async['_fromGetAccountInfoResponse'](_0x14202c,_0x522df6,_0x167cda){const _0x2cd302=_0x522df6['users'][0x0];m(_0x2cd302['localId']!==void 0x0,'internal-error');const _0x41088c=_0x2cd302['providerUserInfo']!==void 0x0?Sa(_0x2cd302['providerUserInfo']):[],_0x15e400=!(_0x2cd302['email']&&_0x2cd302['passwordHash'])&&!(_0x41088c!=null&&_0x41088c['length']),_0x249377=new Qe();_0x249377['updateFromIdToken'](_0x167cda);const _0x5f45a1=new K({'uid':_0x2cd302['localId'],'auth':_0x14202c,'stsTokenManager':_0x249377,'isAnonymous':_0x15e400}),_0x176e77={'uid':_0x2cd302['localId'],'displayName':_0x2cd302['displayName']||null,'photoURL':_0x2cd302['photoUrl']||null,'email':_0x2cd302['email']||null,'emailVerified':_0x2cd302['emailVerified']||!0x1,'phoneNumber':_0x2cd302['phoneNumber']||null,'tenantId':_0x2cd302['tenantId']||null,'providerData':_0x41088c,'metadata':new Oi(_0x2cd302['createdAt'],_0x2cd302['lastLoginAt']),'isAnonymous':!(_0x2cd302['email']&&_0x2cd302['passwordHash'])&&!(_0x41088c!=null&&_0x41088c['length'])};return Object['assign'](_0x5f45a1,_0x176e77),_0x5f45a1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x4866fd){ce(_0x4866fd instanceof Function,'Expected\x20a\x20class\x20definition');let _0x1a9d4b=Tr['get'](_0x4866fd);return _0x1a9d4b?(ce(_0x1a9d4b instanceof _0x4866fd,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x1a9d4b):(_0x1a9d4b=new _0x4866fd(),Tr['set'](_0x4866fd,_0x1a9d4b),_0x1a9d4b);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x5cb3bc,_0x50c43a){this['storage'][_0x5cb3bc]=_0x50c43a;}async['_get'](_0x5de897){const _0x1662fe=this['storage'][_0x5de897];return _0x1662fe===void 0x0?null:_0x1662fe;}async['_remove'](_0x46cc75){delete this['storage'][_0x46cc75];}['_addListener'](_0x48a96d,_0x1059de){}['_removeListener'](_0x5c6cf6,_0x52e5d2){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x33efbb,_0x57e1c1,_0x110d90){return'firebase:'+_0x33efbb+':'+_0x57e1c1+':'+_0x110d90;}class Je{constructor(_0x3345f1,_0x30f7fd,_0x5955b4){this['persistence']=_0x3345f1,this['auth']=_0x30f7fd,this['userKey']=_0x5955b4;const {config:_0x12c779,name:_0x1ebeb5}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x12c779['apiKey'],_0x1ebeb5),this['fullPersistenceKey']=rn('persistence',_0x12c779['apiKey'],_0x1ebeb5),this['boundEventHandler']=_0x30f7fd['_onStorageEvent']['bind'](_0x30f7fd),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0xa14a60){return this['persistence']['_set'](this['fullUserKey'],_0xa14a60['toJSON']());}async['getCurrentUser'](){const _0x5919e1=await this['persistence']['_get'](this['fullUserKey']);if(!_0x5919e1)return null;if(typeof _0x5919e1=='string'){const _0x3c325b=await bn(this['auth'],{'idToken':_0x5919e1})['catch'](()=>{});return _0x3c325b?K['_fromGetAccountInfoResponse'](this['auth'],_0x3c325b,_0x5919e1):null;}return K['_fromJSON'](this['auth'],_0x5919e1);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x57c59d){if(this['persistence']===_0x57c59d)return;const _0x5a4e61=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x57c59d,_0x5a4e61)return this['setCurrentUser'](_0x5a4e61);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x457949,_0x30921a,_0x53f6a0='authUser'){if(!_0x30921a['length'])return new Je(ie(Sr),_0x457949,_0x53f6a0);const _0x281fc6=(await Promise['all'](_0x30921a['map'](async _0x238639=>{if(await _0x238639['_isAvailable']())return _0x238639;})))['filter'](_0x40410d=>_0x40410d);let _0x370567=_0x281fc6[0x0]||ie(Sr);const _0x2f4a44=rn(_0x53f6a0,_0x457949['config']['apiKey'],_0x457949['name']);let _0xaa578c=null;for(const _0x36568c of _0x30921a)try{const _0x10d3b3=await _0x36568c['_get'](_0x2f4a44);if(_0x10d3b3){let _0x2db4b2;if(typeof _0x10d3b3=='string'){const _0x6d4e6e=await bn(_0x457949,{'idToken':_0x10d3b3})['catch'](()=>{});if(!_0x6d4e6e)break;_0x2db4b2=await K['_fromGetAccountInfoResponse'](_0x457949,_0x6d4e6e,_0x10d3b3);}else _0x2db4b2=K['_fromJSON'](_0x457949,_0x10d3b3);_0x36568c!==_0x370567&&(_0xaa578c=_0x2db4b2),_0x370567=_0x36568c;break;}}catch{}const _0xca31f5=_0x281fc6['filter'](_0x1e4a01=>_0x1e4a01['_shouldAllowMigration']);return!_0x370567['_shouldAllowMigration']||!_0xca31f5['length']?new Je(_0x370567,_0x457949,_0x53f6a0):(_0x370567=_0xca31f5[0x0],_0xaa578c&&await _0x370567['_set'](_0x2f4a44,_0xaa578c['toJSON']()),await Promise['all'](_0x30921a['map'](async _0x46685b=>{if(_0x46685b!==_0x370567)try{await _0x46685b['_remove'](_0x2f4a44);}catch{}})),new Je(_0x370567,_0x457949,_0x53f6a0));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x4e8c66){const _0x4b1a65=_0x4e8c66['toLowerCase']();if(_0x4b1a65['includes']('opera/')||_0x4b1a65['includes']('opr/')||_0x4b1a65['includes']('opios/'))return'Opera';if(Na(_0x4b1a65))return'IEMobile';if(_0x4b1a65['includes']('msie')||_0x4b1a65['includes']('trident/'))return'IE';if(_0x4b1a65['includes']('edge/'))return'Edge';if(Ra(_0x4b1a65))return'Firefox';if(_0x4b1a65['includes']('silk/'))return'Silk';if(Oa(_0x4b1a65))return'Blackberry';if(Da(_0x4b1a65))return'Webos';if(Aa(_0x4b1a65))return'Safari';if((_0x4b1a65['includes']('chrome/')||ka(_0x4b1a65))&&!_0x4b1a65['includes']('edge/'))return'Chrome';if(Pa(_0x4b1a65))return'Android';{const _0x4d1b47=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x122bc1=_0x4e8c66['match'](_0x4d1b47);if((_0x122bc1==null?void 0x0:_0x122bc1['length'])===0x2)return _0x122bc1[0x1];}return'Other';}function Ra(_0x141dbb=W()){return/firefox\//i['test'](_0x141dbb);}function Aa(_0x2244d0=W()){const _0x3b1e2a=_0x2244d0['toLowerCase']();return _0x3b1e2a['includes']('safari/')&&!_0x3b1e2a['includes']('chrome/')&&!_0x3b1e2a['includes']('crios/')&&!_0x3b1e2a['includes']('android');}function ka(_0x44cd3c=W()){return/crios\//i['test'](_0x44cd3c);}function Na(_0x252847=W()){return/iemobile/i['test'](_0x252847);}function Pa(_0x2f5243=W()){return/android/i['test'](_0x2f5243);}function Oa(_0x465db9=W()){return/blackberry/i['test'](_0x465db9);}function Da(_0x45b04e=W()){return/webos/i['test'](_0x45b04e);}function Ss(_0x2eaad4=W()){return/iphone|ipad|ipod/i['test'](_0x2eaad4)||/macintosh/i['test'](_0x2eaad4)&&/mobile/i['test'](_0x2eaad4);}function Cf(_0x307a70=W()){var _0x2beeef;return Ss(_0x307a70)&&!!((_0x2beeef=window['navigator'])!=null&&_0x2beeef['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x443886=W()){return Ss(_0x443886)||Pa(_0x443886)||Da(_0x443886)||Oa(_0x443886)||/windows phone/i['test'](_0x443886)||Na(_0x443886);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x2a910b,_0x4cbb11=[]){let _0x30dbcc;switch(_0x2a910b){case'Browser':_0x30dbcc=br(W());break;case'Worker':_0x30dbcc=br(W())+'-'+_0x2a910b;break;default:_0x30dbcc=_0x2a910b;}const _0x2ee6aa=_0x4cbb11['length']?_0x4cbb11['join'](','):'FirebaseCore-web';return _0x30dbcc+'/JsCore/'+lt+'/'+_0x2ee6aa;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0xcc7fc8){this['auth']=_0xcc7fc8,this['queue']=[];}['pushCallback'](_0x36539d,_0xaeff75){const _0x50a0fa=_0x26eeea=>new Promise((_0x91c265,_0x3d910e)=>{try{const _0x524677=_0x36539d(_0x26eeea);_0x91c265(_0x524677);}catch(_0x269196){_0x3d910e(_0x269196);}});_0x50a0fa['onAbort']=_0xaeff75,this['queue']['push'](_0x50a0fa);const _0x5bae18=this['queue']['length']-0x1;return()=>{this['queue'][_0x5bae18]=()=>Promise['resolve']();};}async['runMiddleware'](_0x40b7c0){if(this['auth']['currentUser']===_0x40b7c0)return;const _0x31679b=[];try{for(const _0x346dc2 of this['queue'])await _0x346dc2(_0x40b7c0),_0x346dc2['onAbort']&&_0x31679b['push'](_0x346dc2['onAbort']);}catch(_0x1e5aa1){_0x31679b['reverse']();for(const _0x3ca2c7 of _0x31679b)try{_0x3ca2c7();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x1e5aa1==null?void 0x0:_0x1e5aa1['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x52e1d7,_0x9dae43={}){return Ae(_0x52e1d7,'GET','/v2/passwordPolicy',Re(_0x52e1d7,_0x9dae43));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x477ebc){var _0x37054b;const _0x5ee2e8=_0x477ebc['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x5ee2e8['minPasswordLength']??Rf,_0x5ee2e8['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x5ee2e8['maxPasswordLength']),_0x5ee2e8['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x5ee2e8['containsLowercaseCharacter']),_0x5ee2e8['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x5ee2e8['containsUppercaseCharacter']),_0x5ee2e8['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x5ee2e8['containsNumericCharacter']),_0x5ee2e8['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x5ee2e8['containsNonAlphanumericCharacter']),this['enforcementState']=_0x477ebc['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x37054b=_0x477ebc['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x37054b['join'](''))??'',this['forceUpgradeOnSignin']=_0x477ebc['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x477ebc['schemaVersion'];}['validatePassword'](_0x17e4a3){const _0x3319f4={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x17e4a3,_0x3319f4),this['validatePasswordCharacterOptions'](_0x17e4a3,_0x3319f4),_0x3319f4['isValid']&&(_0x3319f4['isValid']=_0x3319f4['meetsMinPasswordLength']??!0x0),_0x3319f4['isValid']&&(_0x3319f4['isValid']=_0x3319f4['meetsMaxPasswordLength']??!0x0),_0x3319f4['isValid']&&(_0x3319f4['isValid']=_0x3319f4['containsLowercaseLetter']??!0x0),_0x3319f4['isValid']&&(_0x3319f4['isValid']=_0x3319f4['containsUppercaseLetter']??!0x0),_0x3319f4['isValid']&&(_0x3319f4['isValid']=_0x3319f4['containsNumericCharacter']??!0x0),_0x3319f4['isValid']&&(_0x3319f4['isValid']=_0x3319f4['containsNonAlphanumericCharacter']??!0x0),_0x3319f4;}['validatePasswordLengthOptions'](_0x4f1870,_0x2532aa){const _0x2ea4da=this['customStrengthOptions']['minPasswordLength'],_0x426769=this['customStrengthOptions']['maxPasswordLength'];_0x2ea4da&&(_0x2532aa['meetsMinPasswordLength']=_0x4f1870['length']>=_0x2ea4da),_0x426769&&(_0x2532aa['meetsMaxPasswordLength']=_0x4f1870['length']<=_0x426769);}['validatePasswordCharacterOptions'](_0x29a958,_0x1d507f){this['updatePasswordCharacterOptionsStatuses'](_0x1d507f,!0x1,!0x1,!0x1,!0x1);let _0x51b06c;for(let _0x247bd3=0x0;_0x247bd3<_0x29a958['length'];_0x247bd3++)_0x51b06c=_0x29a958['charAt'](_0x247bd3),this['updatePasswordCharacterOptionsStatuses'](_0x1d507f,_0x51b06c>='a'&&_0x51b06c<='z',_0x51b06c>='A'&&_0x51b06c<='Z',_0x51b06c>='0'&&_0x51b06c<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x51b06c));}['updatePasswordCharacterOptionsStatuses'](_0x397c49,_0x56a838,_0x142f91,_0x123dcc,_0x1530a2){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x397c49['containsLowercaseLetter']||(_0x397c49['containsLowercaseLetter']=_0x56a838)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x397c49['containsUppercaseLetter']||(_0x397c49['containsUppercaseLetter']=_0x142f91)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x397c49['containsNumericCharacter']||(_0x397c49['containsNumericCharacter']=_0x123dcc)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x397c49['containsNonAlphanumericCharacter']||(_0x397c49['containsNonAlphanumericCharacter']=_0x1530a2));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x3d54b7,_0x823a81,_0xaa6bf0,_0x52791b){this['app']=_0x3d54b7,this['heartbeatServiceProvider']=_0x823a81,this['appCheckServiceProvider']=_0xaa6bf0,this['config']=_0x52791b,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x3d54b7['name'],this['clientVersion']=_0x52791b['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x273d26=>this['_resolvePersistenceManagerAvailable']=_0x273d26);}['_initializeWithPersistence'](_0x12168e,_0xc7c670){return _0xc7c670&&(this['_popupRedirectResolver']=ie(_0xc7c670)),this['_initializationPromise']=this['queue'](async()=>{var _0x7370d3,_0x393528,_0x4348f8;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x12168e),(_0x7370d3=this['_resolvePersistenceManagerAvailable'])==null||_0x7370d3['call'](this),!this['_deleted'])){if((_0x393528=this['_popupRedirectResolver'])!=null&&_0x393528['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0xc7c670),this['lastNotifiedUid']=((_0x4348f8=this['currentUser'])==null?void 0x0:_0x4348f8['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x5ec6cc=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x5ec6cc)){if(this['currentUser']&&_0x5ec6cc&&this['currentUser']['uid']===_0x5ec6cc['uid']){this['_currentUser']['_assign'](_0x5ec6cc),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x5ec6cc,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x1a797c){try{const _0x394677=await bn(this,{'idToken':_0x1a797c}),_0x53cd44=await K['_fromGetAccountInfoResponse'](this,_0x394677,_0x1a797c);await this['directlySetCurrentUser'](_0x53cd44);}catch(_0x4b3ec7){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x4b3ec7),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x2262be){var _0x1fc39d;if($(this['app'])){const _0x17bc6d=this['app']['settings']['authIdToken'];return _0x17bc6d?new Promise(_0x3f9b03=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x17bc6d)['then'](_0x3f9b03,_0x3f9b03));}):this['directlySetCurrentUser'](null);}const _0x47b92f=await this['assertedPersistence']['getCurrentUser']();let _0x59afba=_0x47b92f,_0x354161=!0x1;if(_0x2262be&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x2e5809=(_0x1fc39d=this['redirectUser'])==null?void 0x0:_0x1fc39d['_redirectEventId'],_0x2cdf9b=_0x59afba==null?void 0x0:_0x59afba['_redirectEventId'],_0x122f7b=await this['tryRedirectSignIn'](_0x2262be);(!_0x2e5809||_0x2e5809===_0x2cdf9b)&&(_0x122f7b!=null&&_0x122f7b['user'])&&(_0x59afba=_0x122f7b['user'],_0x354161=!0x0);}if(!_0x59afba)return this['directlySetCurrentUser'](null);if(!_0x59afba['_redirectEventId']){if(_0x354161)try{await this['beforeStateQueue']['runMiddleware'](_0x59afba);}catch(_0x4513fd){_0x59afba=_0x47b92f,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x4513fd));}return _0x59afba?this['reloadAndSetCurrentUserOrClear'](_0x59afba):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x59afba['_redirectEventId']?this['directlySetCurrentUser'](_0x59afba):this['reloadAndSetCurrentUserOrClear'](_0x59afba);}async['tryRedirectSignIn'](_0x4ef828){let _0xa70b3b=null;try{_0xa70b3b=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x4ef828,!0x0);}catch{await this['_setRedirectUser'](null);}return _0xa70b3b;}async['reloadAndSetCurrentUserOrClear'](_0x26778f){try{await Rn(_0x26778f);}catch(_0x1272c4){if((_0x1272c4==null?void 0x0:_0x1272c4['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x26778f);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x2e0e17){if($(this['app']))return Promise['reject'](re(this));const _0x5a7170=_0x2e0e17?N(_0x2e0e17):null;return _0x5a7170&&m(_0x5a7170['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x5a7170&&_0x5a7170['_clone'](this));}async['_updateCurrentUser'](_0x47d851,_0x472cf5=!0x1){if(!this['_deleted'])return _0x47d851&&m(this['tenantId']===_0x47d851['tenantId'],this,'tenant-id-mismatch'),_0x472cf5||await this['beforeStateQueue']['runMiddleware'](_0x47d851),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x47d851),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x1f07e3){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x1f07e3));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x5ec1e2){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x1b6518=this['_getPasswordPolicyInternal']();return _0x1b6518['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x1b6518['validatePassword'](_0x5ec1e2);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x180117=await bf(this),_0x54ca6a=new Af(_0x180117);this['tenantId']===null?this['_projectPasswordPolicy']=_0x54ca6a:this['_tenantPasswordPolicies'][this['tenantId']]=_0x54ca6a;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x47e4b9){this['_errorFactory']=new Bt('auth','Firebase',_0x47e4b9());}['onAuthStateChanged'](_0x14d608,_0xeb35ff,_0x29b377){return this['registerStateListener'](this['authStateSubscription'],_0x14d608,_0xeb35ff,_0x29b377);}['beforeAuthStateChanged'](_0x5b27f,_0x1cbd85){return this['beforeStateQueue']['pushCallback'](_0x5b27f,_0x1cbd85);}['onIdTokenChanged'](_0x5d1456,_0x3b5c43,_0x434672){return this['registerStateListener'](this['idTokenSubscription'],_0x5d1456,_0x3b5c43,_0x434672);}['authStateReady'](){return new Promise((_0x602e57,_0x1ab86f)=>{if(this['currentUser'])_0x602e57();else{const _0x278e65=this['onAuthStateChanged'](()=>{_0x278e65(),_0x602e57();},_0x1ab86f);}});}async['revokeAccessToken'](_0xc26c9e){if(this['currentUser']){const _0x4eea58=await this['currentUser']['getIdToken'](),_0x56b8c1={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0xc26c9e,'idToken':_0x4eea58};this['tenantId']!=null&&(_0x56b8c1['tenantId']=this['tenantId']),await wf(this,_0x56b8c1);}}['toJSON'](){var _0x32ace1;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x32ace1=this['_currentUser'])==null?void 0x0:_0x32ace1['toJSON']()};}async['_setRedirectUser'](_0x8a3f4b,_0x1a1286){const _0x386f19=await this['getOrInitRedirectPersistenceManager'](_0x1a1286);return _0x8a3f4b===null?_0x386f19['removeCurrentUser']():_0x386f19['setCurrentUser'](_0x8a3f4b);}async['getOrInitRedirectPersistenceManager'](_0x251b76){if(!this['redirectPersistenceManager']){const _0x561729=_0x251b76&&ie(_0x251b76)||this['_popupRedirectResolver'];m(_0x561729,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x561729['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x2c3088){var _0x5f47b2,_0x150f73;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x5f47b2=this['_currentUser'])==null?void 0x0:_0x5f47b2['_redirectEventId'])===_0x2c3088?this['_currentUser']:((_0x150f73=this['redirectUser'])==null?void 0x0:_0x150f73['_redirectEventId'])===_0x2c3088?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x225e3d){if(_0x225e3d===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x225e3d));}['_notifyListenersIfCurrent'](_0x3ce39b){_0x3ce39b===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x3a0d25;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x3bea31=((_0x3a0d25=this['currentUser'])==null?void 0x0:_0x3a0d25['uid'])??null;this['lastNotifiedUid']!==_0x3bea31&&(this['lastNotifiedUid']=_0x3bea31,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x33472a,_0x24f818,_0x376a37,_0x18e6d4){if(this['_deleted'])return()=>{};const _0x504034=typeof _0x24f818=='function'?_0x24f818:_0x24f818['next']['bind'](_0x24f818);let _0x4bdd40=!0x1;const _0x4933d0=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x4933d0,this,'internal-error'),_0x4933d0['then'](()=>{_0x4bdd40||_0x504034(this['currentUser']);}),typeof _0x24f818=='function'){const _0x27223c=_0x33472a['addObserver'](_0x24f818,_0x376a37,_0x18e6d4);return()=>{_0x4bdd40=!0x0,_0x27223c();};}else{const _0x3ecf08=_0x33472a['addObserver'](_0x24f818);return()=>{_0x4bdd40=!0x0,_0x3ecf08();};}}async['directlySetCurrentUser'](_0x44dfd1){this['currentUser']&&this['currentUser']!==_0x44dfd1&&this['_currentUser']['_stopProactiveRefresh'](),_0x44dfd1&&this['isProactiveRefreshEnabled']&&_0x44dfd1['_startProactiveRefresh'](),this['currentUser']=_0x44dfd1,_0x44dfd1?await this['assertedPersistence']['setCurrentUser'](_0x44dfd1):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x1995f7){return this['operations']=this['operations']['then'](_0x1995f7,_0x1995f7),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x5a83e4){!_0x5a83e4||this['frameworks']['includes'](_0x5a83e4)||(this['frameworks']['push'](_0x5a83e4),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x37ecbb;const _0x24775f={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x24775f['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x119ac9=await((_0x37ecbb=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x37ecbb['getHeartbeatsHeader']());_0x119ac9&&(_0x24775f['X-Firebase-Client']=_0x119ac9);const _0x41b3ae=await this['_getAppCheckToken']();return _0x41b3ae&&(_0x24775f['X-Firebase-AppCheck']=_0x41b3ae),_0x24775f;}async['_getAppCheckToken'](){var _0x594bf0;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x48bec1=await((_0x594bf0=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x594bf0['getToken']());return _0x48bec1!=null&&_0x48bec1['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x48bec1['error']),_0x48bec1==null?void 0x0:_0x48bec1['token'];}}function qe(_0x9e973b){return N(_0x9e973b);}class Rr{constructor(_0x465090){this['auth']=_0x465090,this['observer']=null,this['addObserver']=Tc(_0x5ccae4=>this['observer']=_0x5ccae4);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x1774e4){jn=_0x1774e4;}function xa(_0x3a0891){return jn['loadJS'](_0x3a0891);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x1d0ff3){return'__'+_0x1d0ff3+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0xe19d17){_0xe19d17();}['execute'](_0x285556,_0x3e9d18){return Promise['resolve']('token');}['render'](_0x491f12,_0x1ca78b){return'';}}class Lf{['ready'](_0x126dd0){_0x126dd0();}['execute'](_0x4853fd,_0x4c4f4a){return Promise['resolve']('token');}['render'](_0x2a2234,_0x4a96c5){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x5ce657){this['type']=xf,this['auth']=qe(_0x5ce657);}async['verify'](_0x2558bb='verify',_0x454d43=!0x1){async function _0x45cc9d(_0x136dcd){if(!_0x454d43){if(_0x136dcd['tenantId']==null&&_0x136dcd['_agentRecaptchaConfig']!=null)return _0x136dcd['_agentRecaptchaConfig']['siteKey'];if(_0x136dcd['tenantId']!=null&&_0x136dcd['_tenantRecaptchaConfigs'][_0x136dcd['tenantId']]!==void 0x0)return _0x136dcd['_tenantRecaptchaConfigs'][_0x136dcd['tenantId']]['siteKey'];}return new Promise(async(_0x21f2ee,_0x249a82)=>{pf(_0x136dcd,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x175d55=>{if(_0x175d55['recaptchaKey']===void 0x0)_0x249a82(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x5028e0=new ff(_0x175d55);return _0x136dcd['tenantId']==null?_0x136dcd['_agentRecaptchaConfig']=_0x5028e0:_0x136dcd['_tenantRecaptchaConfigs'][_0x136dcd['tenantId']]=_0x5028e0,_0x21f2ee(_0x5028e0['siteKey']);}})['catch'](_0x24f147=>{_0x249a82(_0x24f147);});});}function _0x6a3195(_0x1d9679,_0x1728da,_0x1aa12d){const _0x35011a=window['grecaptcha'];wr(_0x35011a)?_0x35011a['enterprise']['ready'](()=>{_0x35011a['enterprise']['execute'](_0x1d9679,{'action':_0x2558bb})['then'](_0x38e4ff=>{_0x1728da(_0x38e4ff);})['catch'](()=>{_0x1728da(Fa);});}):_0x1aa12d(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x11f18c,_0x395492)=>{_0x45cc9d(this['auth'])['then'](_0x543fb9=>{if(!_0x454d43&&wr(window['grecaptcha']))_0x6a3195(_0x543fb9,_0x11f18c,_0x395492);else{if(typeof window>'u'){_0x395492(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x2454c4=Pf();_0x2454c4['length']!==0x0&&(_0x2454c4+=_0x543fb9),xa(_0x2454c4)['then'](()=>{_0x6a3195(_0x543fb9,_0x11f18c,_0x395492);})['catch'](_0x2d6398=>{_0x395492(_0x2d6398);});}})['catch'](_0x2537a0=>{_0x395492(_0x2537a0);});});}}async function Ar(_0x287e68,_0x2afe71,_0x27527d,_0x27f91c=!0x1,_0x4db331=!0x1){const _0x4e6034=new Ff(_0x287e68);let _0x1588c6;if(_0x4db331)_0x1588c6=Fa;else try{_0x1588c6=await _0x4e6034['verify'](_0x27527d);}catch{_0x1588c6=await _0x4e6034['verify'](_0x27527d,!0x0);}const _0x5e2f04={..._0x2afe71};if(_0x27527d==='mfaSmsEnrollment'||_0x27527d==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x5e2f04){const _0x5d0ff5=_0x5e2f04['phoneEnrollmentInfo']['phoneNumber'],_0x4550ae=_0x5e2f04['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x5e2f04,{'phoneEnrollmentInfo':{'phoneNumber':_0x5d0ff5,'recaptchaToken':_0x4550ae,'captchaResponse':_0x1588c6,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x5e2f04){const _0x42a012=_0x5e2f04['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x5e2f04,{'phoneSignInInfo':{'recaptchaToken':_0x42a012,'captchaResponse':_0x1588c6,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x5e2f04;}return _0x27f91c?Object['assign'](_0x5e2f04,{'captchaResp':_0x1588c6}):Object['assign'](_0x5e2f04,{'captchaResponse':_0x1588c6}),Object['assign'](_0x5e2f04,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x5e2f04,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x5e2f04;}async function Di(_0x5e89d6,_0x578c1d,_0x5cba77,_0x4de552,_0x57fa03){var _0x16faee;if((_0x16faee=_0x5e89d6['_getRecaptchaConfig']())!=null&&_0x16faee['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x192fd9=await Ar(_0x5e89d6,_0x578c1d,_0x5cba77,_0x5cba77==='getOobCode');return _0x4de552(_0x5e89d6,_0x192fd9);}else return _0x4de552(_0x5e89d6,_0x578c1d)['catch'](async _0x3fe002=>{if(_0x3fe002['code']==='auth/missing-recaptcha-token'){console['log'](_0x5cba77+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x5a1ecb=await Ar(_0x5e89d6,_0x578c1d,_0x5cba77,_0x5cba77==='getOobCode');return _0x4de552(_0x5e89d6,_0x5a1ecb);}else return Promise['reject'](_0x3fe002);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x18b578,_0x36041f){const _0x2fdda2=Bi(_0x18b578,'auth');if(_0x2fdda2['isInitialized']()){const _0x3ae66c=_0x2fdda2['getImmediate'](),_0x5e545e=_0x2fdda2['getOptions']();if(Me(_0x5e545e,_0x36041f??{}))return _0x3ae66c;Q(_0x3ae66c,'already-initialized');}return _0x2fdda2['initialize']({'options':_0x36041f});}function Wf(_0x104157,_0xb561c){const _0x31ec58=(_0xb561c==null?void 0x0:_0xb561c['persistence'])||[],_0x705cb6=(Array['isArray'](_0x31ec58)?_0x31ec58:[_0x31ec58])['map'](ie);_0xb561c!=null&&_0xb561c['errorMap']&&_0x104157['_updateErrorMap'](_0xb561c['errorMap']),_0x104157['_initializeWithPersistence'](_0x705cb6,_0xb561c==null?void 0x0:_0xb561c['popupRedirectResolver']);}function Bf(_0x2e1f66,_0x58e9fc,_0xac1bf6){const _0x13412b=qe(_0x2e1f66);m(/^https?:\/\//['test'](_0x58e9fc),_0x13412b,'invalid-emulator-scheme');const _0x5cbcd6=!0x1,_0x151355=Ua(_0x58e9fc),{host:_0x1fc6ee,port:_0x30331e}=Vf(_0x58e9fc),_0x1b991=_0x30331e===null?'':':'+_0x30331e,_0x930f30={'url':_0x151355+'//'+_0x1fc6ee+_0x1b991+'/'},_0x28f872=Object['freeze']({'host':_0x1fc6ee,'port':_0x30331e,'protocol':_0x151355['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x5cbcd6})});if(!_0x13412b['_canInitEmulator']){m(_0x13412b['config']['emulator']&&_0x13412b['emulatorConfig'],_0x13412b,'emulator-config-failed'),m(Me(_0x930f30,_0x13412b['config']['emulator'])&&Me(_0x28f872,_0x13412b['emulatorConfig']),_0x13412b,'emulator-config-failed');return;}_0x13412b['config']['emulator']=_0x930f30,_0x13412b['emulatorConfig']=_0x28f872,_0x13412b['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x1fc6ee)?(jr(_0x151355+'//'+_0x1fc6ee+_0x1b991),Kr('Auth',!0x0)):Hf();}function Ua(_0x5a74cf){const _0x54893d=_0x5a74cf['indexOf'](':');return _0x54893d<0x0?'':_0x5a74cf['substr'](0x0,_0x54893d+0x1);}function Vf(_0x3e1762){const _0x34435f=Ua(_0x3e1762),_0x430fae=/(\/\/)?([^?#/]+)/['exec'](_0x3e1762['substr'](_0x34435f['length']));if(!_0x430fae)return{'host':'','port':null};const _0x40cbdf=_0x430fae[0x2]['split']('@')['pop']()||'',_0x4d9064=/^(\[[^\]]+\])(:|$)/['exec'](_0x40cbdf);if(_0x4d9064){const _0x37c7f2=_0x4d9064[0x1];return{'host':_0x37c7f2,'port':kr(_0x40cbdf['substr'](_0x37c7f2['length']+0x1))};}else{const [_0x1dd267,_0x3c2e11]=_0x40cbdf['split'](':');return{'host':_0x1dd267,'port':kr(_0x3c2e11)};}}function kr(_0x27fd86){if(!_0x27fd86)return null;const _0x2f50b4=Number(_0x27fd86);return isNaN(_0x2f50b4)?null:_0x2f50b4;}function Hf(){function _0x2d1045(){const _0x2d16e1=document['createElement']('p'),_0x344cb7=_0x2d16e1['style'];_0x2d16e1['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x344cb7['position']='fixed',_0x344cb7['width']='100%',_0x344cb7['backgroundColor']='#ffffff',_0x344cb7['border']='.1em\x20solid\x20#000000',_0x344cb7['color']='#b50000',_0x344cb7['bottom']='0px',_0x344cb7['left']='0px',_0x344cb7['margin']='0px',_0x344cb7['zIndex']='10000',_0x344cb7['textAlign']='center',_0x2d16e1['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x2d16e1);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x2d1045):_0x2d1045());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x571c4e,_0xa6252e){this['providerId']=_0x571c4e,this['signInMethod']=_0xa6252e;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x43dc69){return ne('not\x20implemented');}['_linkToIdToken'](_0x2d95bb,_0x94fb34){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x501038){return ne('not\x20implemented');}}async function $f(_0x4876ab,_0x3cbe3a){return Ae(_0x4876ab,'POST','/v1/accounts:signUp',_0x3cbe3a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x14f4de,_0x2b60c3){return Qt(_0x14f4de,'POST','/v1/accounts:signInWithPassword',Re(_0x14f4de,_0x2b60c3));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0xa6a7e3,_0x2a1ecb){return Qt(_0xa6a7e3,'POST','/v1/accounts:signInWithEmailLink',Re(_0xa6a7e3,_0x2a1ecb));}async function zf(_0x113a8c,_0x4e06cc){return Qt(_0x113a8c,'POST','/v1/accounts:signInWithEmailLink',Re(_0x113a8c,_0x4e06cc));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x15883d,_0x2694e7,_0x2a921f,_0x23cb47=null){super('password',_0x2a921f),this['_email']=_0x15883d,this['_password']=_0x2694e7,this['_tenantId']=_0x23cb47;}static['_fromEmailAndPassword'](_0x4cacd3,_0x3f6f86){return new Wt(_0x4cacd3,_0x3f6f86,'password');}static['_fromEmailAndCode'](_0x69e09e,_0x3a53a4,_0x219fb9=null){return new Wt(_0x69e09e,_0x3a53a4,'emailLink',_0x219fb9);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x31c5f8){const _0x1703ea=typeof _0x31c5f8=='string'?JSON['parse'](_0x31c5f8):_0x31c5f8;if(_0x1703ea!=null&&_0x1703ea['email']&&(_0x1703ea!=null&&_0x1703ea['password'])){if(_0x1703ea['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x1703ea['email'],_0x1703ea['password']);if(_0x1703ea['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x1703ea['email'],_0x1703ea['password'],_0x1703ea['tenantId']);}return null;}async['_getIdTokenResponse'](_0x5321b4){switch(this['signInMethod']){case'password':const _0x5d9056={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x5321b4,_0x5d9056,'signInWithPassword',Gf);case'emailLink':return qf(_0x5321b4,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x5321b4,'internal-error');}}async['_linkToIdToken'](_0x2a7289,_0x27db93){switch(this['signInMethod']){case'password':const _0x1ee5cc={'idToken':_0x27db93,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x2a7289,_0x1ee5cc,'signUpPassword',$f);case'emailLink':return zf(_0x2a7289,{'idToken':_0x27db93,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x2a7289,'internal-error');}}['_getReauthenticationResolver'](_0x11c172){return this['_getIdTokenResponse'](_0x11c172);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x4a0b84,_0x567e76){return Qt(_0x4a0b84,'POST','/v1/accounts:signInWithIdp',Re(_0x4a0b84,_0x567e76));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x4a08ba){const _0x4f6840=new Be(_0x4a08ba['providerId'],_0x4a08ba['signInMethod']);return _0x4a08ba['idToken']||_0x4a08ba['accessToken']?(_0x4a08ba['idToken']&&(_0x4f6840['idToken']=_0x4a08ba['idToken']),_0x4a08ba['accessToken']&&(_0x4f6840['accessToken']=_0x4a08ba['accessToken']),_0x4a08ba['nonce']&&!_0x4a08ba['pendingToken']&&(_0x4f6840['nonce']=_0x4a08ba['nonce']),_0x4a08ba['pendingToken']&&(_0x4f6840['pendingToken']=_0x4a08ba['pendingToken'])):_0x4a08ba['oauthToken']&&_0x4a08ba['oauthTokenSecret']?(_0x4f6840['accessToken']=_0x4a08ba['oauthToken'],_0x4f6840['secret']=_0x4a08ba['oauthTokenSecret']):Q('argument-error'),_0x4f6840;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x567bf5){const _0x9ea110=typeof _0x567bf5=='string'?JSON['parse'](_0x567bf5):_0x567bf5,{providerId:_0x58abc8,signInMethod:_0xa7c854,..._0x519864}=_0x9ea110;if(!_0x58abc8||!_0xa7c854)return null;const _0x51223d=new Be(_0x58abc8,_0xa7c854);return _0x51223d['idToken']=_0x519864['idToken']||void 0x0,_0x51223d['accessToken']=_0x519864['accessToken']||void 0x0,_0x51223d['secret']=_0x519864['secret'],_0x51223d['nonce']=_0x519864['nonce'],_0x51223d['pendingToken']=_0x519864['pendingToken']||null,_0x51223d;}['_getIdTokenResponse'](_0x57850a){const _0x32b35e=this['buildRequest']();return Xe(_0x57850a,_0x32b35e);}['_linkToIdToken'](_0x2cdf01,_0x941003){const _0xec9709=this['buildRequest']();return _0xec9709['idToken']=_0x941003,Xe(_0x2cdf01,_0xec9709);}['_getReauthenticationResolver'](_0x4d4897){const _0x76c9c7=this['buildRequest']();return _0x76c9c7['autoCreate']=!0x1,Xe(_0x4d4897,_0x76c9c7);}['buildRequest'](){const _0x1c40cf={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x1c40cf['pendingToken']=this['pendingToken'];else{const _0x9e746e={};this['idToken']&&(_0x9e746e['id_token']=this['idToken']),this['accessToken']&&(_0x9e746e['access_token']=this['accessToken']),this['secret']&&(_0x9e746e['oauth_token_secret']=this['secret']),_0x9e746e['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x9e746e['nonce']=this['nonce']),_0x1c40cf['postBody']=ct(_0x9e746e);}return _0x1c40cf;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x37390d){switch(_0x37390d){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x3f3336){const _0x47047d=vt(Et(_0x3f3336))['link'],_0x46f11b=_0x47047d?vt(Et(_0x47047d))['deep_link_id']:null,_0x2de963=vt(Et(_0x3f3336))['deep_link_id'];return(_0x2de963?vt(Et(_0x2de963))['link']:null)||_0x2de963||_0x46f11b||_0x47047d||_0x3f3336;}class Rs{constructor(_0x5594cb){const _0x20e8c3=vt(Et(_0x5594cb)),_0x5c8dac=_0x20e8c3['apiKey']??null,_0x16291c=_0x20e8c3['oobCode']??null,_0x11ee1e=Kf(_0x20e8c3['mode']??null);m(_0x5c8dac&&_0x16291c&&_0x11ee1e,'argument-error'),this['apiKey']=_0x5c8dac,this['operation']=_0x11ee1e,this['code']=_0x16291c,this['continueUrl']=_0x20e8c3['continueUrl']??null,this['languageCode']=_0x20e8c3['lang']??null,this['tenantId']=_0x20e8c3['tenantId']??null;}static['parseLink'](_0x3f1255){const _0x4f7db2=Yf(_0x3f1255);try{return new Rs(_0x4f7db2);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x5b02a9,_0x27fb6d){return Wt['_fromEmailAndPassword'](_0x5b02a9,_0x27fb6d);}static['credentialWithLink'](_0x102ff7,_0x5257aa){const _0x3c9dcc=Rs['parseLink'](_0x5257aa);return m(_0x3c9dcc,'argument-error'),Wt['_fromEmailAndCode'](_0x102ff7,_0x3c9dcc['code'],_0x3c9dcc['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0xf3fd27){this['providerId']=_0xf3fd27,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x29704e){this['defaultLanguageCode']=_0x29704e;}['setCustomParameters'](_0x4389b5){return this['customParameters']=_0x4389b5,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x41d704){return this['scopes']['includes'](_0x41d704)||this['scopes']['push'](_0x41d704),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x32f798){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x32f798});}static['credentialFromResult'](_0x171445){return he['credentialFromTaggedObject'](_0x171445);}static['credentialFromError'](_0x5395e5){return he['credentialFromTaggedObject'](_0x5395e5['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x41678d}){if(!_0x41678d||!('oauthAccessToken'in _0x41678d)||!_0x41678d['oauthAccessToken'])return null;try{return he['credential'](_0x41678d['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x62524,_0x3e962d){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x62524,'accessToken':_0x3e962d});}static['credentialFromResult'](_0x25bb1f){return ue['credentialFromTaggedObject'](_0x25bb1f);}static['credentialFromError'](_0x478310){return ue['credentialFromTaggedObject'](_0x478310['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xa4c7ad}){if(!_0xa4c7ad)return null;const {oauthIdToken:_0x3068ef,oauthAccessToken:_0x1ff224}=_0xa4c7ad;if(!_0x3068ef&&!_0x1ff224)return null;try{return ue['credential'](_0x3068ef,_0x1ff224);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x586af0){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x586af0});}static['credentialFromResult'](_0x4af641){return de['credentialFromTaggedObject'](_0x4af641);}static['credentialFromError'](_0x47b37d){return de['credentialFromTaggedObject'](_0x47b37d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x225b62}){if(!_0x225b62||!('oauthAccessToken'in _0x225b62)||!_0x225b62['oauthAccessToken'])return null;try{return de['credential'](_0x225b62['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x43f876,_0xf8846a){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x43f876,'oauthTokenSecret':_0xf8846a});}static['credentialFromResult'](_0x30c738){return fe['credentialFromTaggedObject'](_0x30c738);}static['credentialFromError'](_0x21b7f6){return fe['credentialFromTaggedObject'](_0x21b7f6['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x10beb8}){if(!_0x10beb8)return null;const {oauthAccessToken:_0x1819eb,oauthTokenSecret:_0x104538}=_0x10beb8;if(!_0x1819eb||!_0x104538)return null;try{return fe['credential'](_0x1819eb,_0x104538);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x53a1dc,_0x331aec){return Qt(_0x53a1dc,'POST','/v1/accounts:signUp',Re(_0x53a1dc,_0x331aec));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x5283e1){this['user']=_0x5283e1['user'],this['providerId']=_0x5283e1['providerId'],this['_tokenResponse']=_0x5283e1['_tokenResponse'],this['operationType']=_0x5283e1['operationType'];}static async['_fromIdTokenResponse'](_0x9c0cf8,_0x3ef3d5,_0x2cdc23,_0x892e80=!0x1){const _0xb1f35c=await K['_fromIdTokenResponse'](_0x9c0cf8,_0x2cdc23,_0x892e80),_0x408bb3=Nr(_0x2cdc23);return new Ve({'user':_0xb1f35c,'providerId':_0x408bb3,'_tokenResponse':_0x2cdc23,'operationType':_0x3ef3d5});}static async['_forOperation'](_0x34ad38,_0x59e64d,_0x448350){await _0x34ad38['_updateTokensIfNecessary'](_0x448350,!0x0);const _0x1a62a5=Nr(_0x448350);return new Ve({'user':_0x34ad38,'providerId':_0x1a62a5,'_tokenResponse':_0x448350,'operationType':_0x59e64d});}}function Nr(_0x1f8392){return _0x1f8392['providerId']?_0x1f8392['providerId']:'phoneNumber'in _0x1f8392?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x5ce696,_0x3b12e7,_0xc3a59,_0x27a10d){super(_0x3b12e7['code'],_0x3b12e7['message']),this['operationType']=_0xc3a59,this['user']=_0x27a10d,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x5ce696['name'],'tenantId':_0x5ce696['tenantId']??void 0x0,'_serverResponse':_0x3b12e7['customData']['_serverResponse'],'operationType':_0xc3a59};}static['_fromErrorAndOperation'](_0x349f6f,_0x137d38,_0x465657,_0x2b16b4){return new An(_0x349f6f,_0x137d38,_0x465657,_0x2b16b4);}}function Ba(_0x30c83b,_0x3e245c,_0x55a6c3,_0x35c7da){return(_0x3e245c==='reauthenticate'?_0x55a6c3['_getReauthenticationResolver'](_0x30c83b):_0x55a6c3['_getIdTokenResponse'](_0x30c83b))['catch'](_0x36bc94=>{throw _0x36bc94['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x30c83b,_0x36bc94,_0x3e245c,_0x35c7da):_0x36bc94;});}async function Jf(_0x58887f,_0x32240a,_0x53bb3f=!0x1){const _0x46348b=await Ut(_0x58887f,_0x32240a['_linkToIdToken'](_0x58887f['auth'],await _0x58887f['getIdToken']()),_0x53bb3f);return Ve['_forOperation'](_0x58887f,'link',_0x46348b);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0xced0a1,_0x92ba4b,_0x17b8e0=!0x1){const {auth:_0x40aca6}=_0xced0a1;if($(_0x40aca6['app']))return Promise['reject'](re(_0x40aca6));const _0x37ecb8='reauthenticate';try{const _0x44a11a=await Ut(_0xced0a1,Ba(_0x40aca6,_0x37ecb8,_0x92ba4b,_0xced0a1),_0x17b8e0);m(_0x44a11a['idToken'],_0x40aca6,'internal-error');const _0x54b324=Ts(_0x44a11a['idToken']);m(_0x54b324,_0x40aca6,'internal-error');const {sub:_0x3f27b7}=_0x54b324;return m(_0xced0a1['uid']===_0x3f27b7,_0x40aca6,'user-mismatch'),Ve['_forOperation'](_0xced0a1,_0x37ecb8,_0x44a11a);}catch(_0x57ae46){throw(_0x57ae46==null?void 0x0:_0x57ae46['code'])==='auth/user-not-found'&&Q(_0x40aca6,'user-mismatch'),_0x57ae46;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x337b25,_0x20b3b7,_0x4cdad7=!0x1){if($(_0x337b25['app']))return Promise['reject'](re(_0x337b25));const _0x14c362='signIn',_0x11a405=await Ba(_0x337b25,_0x14c362,_0x20b3b7),_0x34ed8c=await Ve['_fromIdTokenResponse'](_0x337b25,_0x14c362,_0x11a405);return _0x4cdad7||await _0x337b25['_updateCurrentUser'](_0x34ed8c['user']),_0x34ed8c;}async function Zf(_0x13d431,_0xb566a6){return Va(qe(_0x13d431),_0xb566a6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x1a144c){const _0x2d8c6b=qe(_0x1a144c);_0x2d8c6b['_getPasswordPolicyInternal']()&&await _0x2d8c6b['_updatePasswordPolicy']();}async function P_(_0x98cf2f,_0x500dea,_0x3b5075){if($(_0x98cf2f['app']))return Promise['reject'](re(_0x98cf2f));const _0x1c490f=qe(_0x98cf2f),_0x2fa26b=await Di(_0x1c490f,{'returnSecureToken':!0x0,'email':_0x500dea,'password':_0x3b5075,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x3ef2d9=>{throw _0x3ef2d9['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x98cf2f),_0x3ef2d9;}),_0x232bd2=await Ve['_fromIdTokenResponse'](_0x1c490f,'signIn',_0x2fa26b);return await _0x1c490f['_updateCurrentUser'](_0x232bd2['user']),_0x232bd2;}function O_(_0x43959e,_0x3e99a6,_0x13581a){return $(_0x43959e['app'])?Promise['reject'](re(_0x43959e)):Zf(N(_0x43959e),pt['credential'](_0x3e99a6,_0x13581a))['catch'](async _0x57f484=>{throw _0x57f484['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x43959e),_0x57f484;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x47012f,_0x2160af){return N(_0x47012f)['setPersistence'](_0x2160af);}function ep(_0x24c517,_0x49c2f,_0x581f18,_0x328477){return N(_0x24c517)['onIdTokenChanged'](_0x49c2f,_0x581f18,_0x328477);}function tp(_0x298b8b,_0x33237d,_0x522093){return N(_0x298b8b)['beforeAuthStateChanged'](_0x33237d,_0x522093);}function M_(_0x88a790,_0x1c9121,_0x7fd19e,_0x3f77e5){return N(_0x88a790)['onAuthStateChanged'](_0x1c9121,_0x7fd19e,_0x3f77e5);}function L_(_0x57993f){return N(_0x57993f)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x4db707,_0x1029a2){this['storageRetriever']=_0x4db707,this['type']=_0x1029a2;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x4ceca8,_0x3c0a5d){return this['storage']['setItem'](_0x4ceca8,JSON['stringify'](_0x3c0a5d)),Promise['resolve']();}['_get'](_0x3c80c6){const _0x4c97f4=this['storage']['getItem'](_0x3c80c6);return Promise['resolve'](_0x4c97f4?JSON['parse'](_0x4c97f4):null);}['_remove'](_0x14b11e){return this['storage']['removeItem'](_0x14b11e),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x198d60,_0x955468)=>this['onStorageEvent'](_0x198d60,_0x955468),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x518814){for(const _0x3a277f of Object['keys'](this['listeners'])){const _0x592f86=this['storage']['getItem'](_0x3a277f),_0x39ab83=this['localCache'][_0x3a277f];_0x592f86!==_0x39ab83&&_0x518814(_0x3a277f,_0x39ab83,_0x592f86);}}['onStorageEvent'](_0x26f94d,_0x3a1485=!0x1){if(!_0x26f94d['key']){this['forAllChangedKeys']((_0x11b9cd,_0x5e44bf,_0x520869)=>{this['notifyListeners'](_0x11b9cd,_0x520869);});return;}const _0x526bc9=_0x26f94d['key'];_0x3a1485?this['detachListener']():this['stopPolling']();const _0x14f07d=()=>{const _0x15c095=this['storage']['getItem'](_0x526bc9);!_0x3a1485&&this['localCache'][_0x526bc9]===_0x15c095||this['notifyListeners'](_0x526bc9,_0x15c095);},_0xc31a74=this['storage']['getItem'](_0x526bc9);Tf()&&_0xc31a74!==_0x26f94d['newValue']&&_0x26f94d['newValue']!==_0x26f94d['oldValue']?setTimeout(_0x14f07d,ip):_0x14f07d();}['notifyListeners'](_0x3ea413,_0x1eaf61){this['localCache'][_0x3ea413]=_0x1eaf61;const _0x1a9fed=this['listeners'][_0x3ea413];if(_0x1a9fed){for(const _0x2a71c6 of Array['from'](_0x1a9fed))_0x2a71c6(_0x1eaf61&&JSON['parse'](_0x1eaf61));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0xbfc7be,_0x42346f,_0x7914f9)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0xbfc7be,'oldValue':_0x42346f,'newValue':_0x7914f9}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x3cdc47,_0x3f6f78){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x3cdc47]||(this['listeners'][_0x3cdc47]=new Set(),this['localCache'][_0x3cdc47]=this['storage']['getItem'](_0x3cdc47)),this['listeners'][_0x3cdc47]['add'](_0x3f6f78);}['_removeListener'](_0x4f4c07,_0x387b8c){this['listeners'][_0x4f4c07]&&(this['listeners'][_0x4f4c07]['delete'](_0x387b8c),this['listeners'][_0x4f4c07]['size']===0x0&&delete this['listeners'][_0x4f4c07]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x1d0cd6,_0x3575c2){await super['_set'](_0x1d0cd6,_0x3575c2),this['localCache'][_0x1d0cd6]=JSON['stringify'](_0x3575c2);}async['_get'](_0x31a20f){const _0xc6708e=await super['_get'](_0x31a20f);return this['localCache'][_0x31a20f]=JSON['stringify'](_0xc6708e),_0xc6708e;}async['_remove'](_0x4dc23f){await super['_remove'](_0x4dc23f),delete this['localCache'][_0x4dc23f];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x4dcf90,_0x395160){}['_removeListener'](_0x292824,_0x618c6){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x2ac407){return Promise['all'](_0x2ac407['map'](async _0x158ae3=>{try{return{'fulfilled':!0x0,'value':await _0x158ae3};}catch(_0x5145e1){return{'fulfilled':!0x1,'reason':_0x5145e1};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x484175){this['eventTarget']=_0x484175,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x12c7b5){const _0x207c1c=this['receivers']['find'](_0x3b1532=>_0x3b1532['isListeningto'](_0x12c7b5));if(_0x207c1c)return _0x207c1c;const _0x4480cf=new Kn(_0x12c7b5);return this['receivers']['push'](_0x4480cf),_0x4480cf;}['isListeningto'](_0x4e8d67){return this['eventTarget']===_0x4e8d67;}async['handleEvent'](_0x9e7bf7){const _0x55dd91=_0x9e7bf7,{eventId:_0x4065a6,eventType:_0x5d4370,data:_0x3fad0f}=_0x55dd91['data'],_0x55f0d9=this['handlersMap'][_0x5d4370];if(!(_0x55f0d9!=null&&_0x55f0d9['size']))return;_0x55dd91['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x4065a6,'eventType':_0x5d4370});const _0x4aa0be=Array['from'](_0x55f0d9)['map'](async _0xcd4e1a=>_0xcd4e1a(_0x55dd91['origin'],_0x3fad0f)),_0x21934d=await rp(_0x4aa0be);_0x55dd91['ports'][0x0]['postMessage']({'status':'done','eventId':_0x4065a6,'eventType':_0x5d4370,'response':_0x21934d});}['_subscribe'](_0x579fc4,_0x41af73){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x579fc4]||(this['handlersMap'][_0x579fc4]=new Set()),this['handlersMap'][_0x579fc4]['add'](_0x41af73);}['_unsubscribe'](_0x240084,_0x4193ea){this['handlersMap'][_0x240084]&&_0x4193ea&&this['handlersMap'][_0x240084]['delete'](_0x4193ea),(!_0x4193ea||this['handlersMap'][_0x240084]['size']===0x0)&&delete this['handlersMap'][_0x240084],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0xf3f946='',_0x45db5e=0xa){let _0x293d23='';for(let _0x486938=0x0;_0x486938<_0x45db5e;_0x486938++)_0x293d23+=Math['floor'](Math['random']()*0xa);return _0xf3f946+_0x293d23;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x3c303a){this['target']=_0x3c303a,this['handlers']=new Set();}['removeMessageHandler'](_0x13fb18){_0x13fb18['messageChannel']&&(_0x13fb18['messageChannel']['port1']['removeEventListener']('message',_0x13fb18['onMessage']),_0x13fb18['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x13fb18);}async['_send'](_0x399d83,_0xe61e85,_0x19650f=0x32){const _0x273780=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x273780)throw new Error('connection_unavailable');let _0x2aad0a,_0x4c5138;return new Promise((_0x3022b9,_0x39555a)=>{const _0x43057b=As('',0x14);_0x273780['port1']['start']();const _0x18558a=setTimeout(()=>{_0x39555a(new Error('unsupported_event'));},_0x19650f);_0x4c5138={'messageChannel':_0x273780,'onMessage'(_0x4676ec){const _0x358466=_0x4676ec;if(_0x358466['data']['eventId']===_0x43057b)switch(_0x358466['data']['status']){case'ack':clearTimeout(_0x18558a),_0x2aad0a=setTimeout(()=>{_0x39555a(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x2aad0a),_0x3022b9(_0x358466['data']['response']);break;default:clearTimeout(_0x18558a),clearTimeout(_0x2aad0a),_0x39555a(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x4c5138),_0x273780['port1']['addEventListener']('message',_0x4c5138['onMessage']),this['target']['postMessage']({'eventType':_0x399d83,'eventId':_0x43057b,'data':_0xe61e85},[_0x273780['port2']]);})['finally'](()=>{_0x4c5138&&this['removeMessageHandler'](_0x4c5138);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x45d838){Z()['location']['href']=_0x45d838;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x3ad81c;return((_0x3ad81c=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x3ad81c['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x573de4){this['request']=_0x573de4;}['toPromise'](){return new Promise((_0x326717,_0x142190)=>{this['request']['addEventListener']('success',()=>{_0x326717(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x142190(this['request']['error']);});});}}function Yn(_0x32aee0,_0x402ce1){return _0x32aee0['transaction']([Nn],_0x402ce1?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x3d4c08=indexedDB['deleteDatabase'](Ka);return new Xt(_0x3d4c08)['toPromise']();}function Mi(){const _0x8a53ab=indexedDB['open'](Ka,up);return new Promise((_0x266c44,_0x55d70c)=>{_0x8a53ab['addEventListener']('error',()=>{_0x55d70c(_0x8a53ab['error']);}),_0x8a53ab['addEventListener']('upgradeneeded',()=>{const _0x21c5e3=_0x8a53ab['result'];try{_0x21c5e3['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x53595a){_0x55d70c(_0x53595a);}}),_0x8a53ab['addEventListener']('success',async()=>{const _0x402bed=_0x8a53ab['result'];_0x402bed['objectStoreNames']['contains'](Nn)?_0x266c44(_0x402bed):(_0x402bed['close'](),await dp(),_0x266c44(await Mi()));});});}async function Pr(_0x28c129,_0x42d528,_0x372957){const _0x2a7c4c=Yn(_0x28c129,!0x0)['put']({[Ya]:_0x42d528,'value':_0x372957});return new Xt(_0x2a7c4c)['toPromise']();}async function fp(_0x40fdd4,_0x36ab52){const _0x4df32a=Yn(_0x40fdd4,!0x1)['get'](_0x36ab52),_0x10f37f=await new Xt(_0x4df32a)['toPromise']();return _0x10f37f===void 0x0?null:_0x10f37f['value'];}function Or(_0x204482,_0x382a15){const _0x50097d=Yn(_0x204482,!0x0)['delete'](_0x382a15);return new Xt(_0x50097d)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x67b4d5){let _0xe47413=0x0;for(;;)try{const _0x5419e0=await this['_openDb']();return await _0x67b4d5(_0x5419e0);}catch(_0x492e5b){if(_0xe47413++>_p)throw _0x492e5b;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x17f632,_0x39b4d8)=>({'keyProcessed':(await this['_poll']())['includes'](_0x39b4d8['key'])})),this['receiver']['_subscribe']('ping',async(_0x1375bb,_0x3f5846)=>['keyChanged']);}async['initializeSender'](){var _0x433aee,_0x183b1f;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x48a59d=await this['sender']['_send']('ping',{},0x320);_0x48a59d&&(_0x433aee=_0x48a59d[0x0])!=null&&_0x433aee['fulfilled']&&(_0x183b1f=_0x48a59d[0x0])!=null&&_0x183b1f['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x30501f){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x30501f},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x49f299=await Mi();return await Pr(_0x49f299,kn,'1'),await Or(_0x49f299,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x493c56){this['pendingWrites']++;try{await _0x493c56();}finally{this['pendingWrites']--;}}async['_set'](_0x32f9a0,_0x2b5a9c){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1344a1=>Pr(_0x1344a1,_0x32f9a0,_0x2b5a9c)),this['localCache'][_0x32f9a0]=_0x2b5a9c,this['notifyServiceWorker'](_0x32f9a0)));}async['_get'](_0x3da6fa){const _0x1c6373=await this['_withRetries'](_0x4fffb3=>fp(_0x4fffb3,_0x3da6fa));return this['localCache'][_0x3da6fa]=_0x1c6373,_0x1c6373;}async['_remove'](_0x10b195){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2c2c92=>Or(_0x2c2c92,_0x10b195)),delete this['localCache'][_0x10b195],this['notifyServiceWorker'](_0x10b195)));}async['_poll'](){const _0x2d2235=await this['_withRetries'](_0x56df6c=>{const _0x42dfb8=Yn(_0x56df6c,!0x1)['getAll']();return new Xt(_0x42dfb8)['toPromise']();});if(!_0x2d2235)return[];if(this['pendingWrites']!==0x0)return[];const _0x3183b4=[],_0x3c722c=new Set();if(_0x2d2235['length']!==0x0){for(const {fbase_key:_0x284404,value:_0x3dcd7e}of _0x2d2235)_0x3c722c['add'](_0x284404),JSON['stringify'](this['localCache'][_0x284404])!==JSON['stringify'](_0x3dcd7e)&&(this['notifyListeners'](_0x284404,_0x3dcd7e),_0x3183b4['push'](_0x284404));}for(const _0x3f5944 of Object['keys'](this['localCache']))this['localCache'][_0x3f5944]&&!_0x3c722c['has'](_0x3f5944)&&(this['notifyListeners'](_0x3f5944,null),_0x3183b4['push'](_0x3f5944));return _0x3183b4;}['notifyListeners'](_0x374580,_0x5d56a7){this['localCache'][_0x374580]=_0x5d56a7;const _0xbf975a=this['listeners'][_0x374580];if(_0xbf975a){for(const _0x59da04 of Array['from'](_0xbf975a))_0x59da04(_0x5d56a7);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x4f3180,_0x36a548){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x4f3180]||(this['listeners'][_0x4f3180]=new Set(),this['_get'](_0x4f3180)),this['listeners'][_0x4f3180]['add'](_0x36a548);}['_removeListener'](_0x52b643,_0x45971f){this['listeners'][_0x52b643]&&(this['listeners'][_0x52b643]['delete'](_0x45971f),this['listeners'][_0x52b643]['size']===0x0&&delete this['listeners'][_0x52b643]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x414500,_0x139fd3){return _0x139fd3?ie(_0x139fd3):(m(_0x414500['_popupRedirectResolver'],_0x414500,'argument-error'),_0x414500['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x587c65){super('custom','custom'),this['params']=_0x587c65;}['_getIdTokenResponse'](_0x8b9f5c){return Xe(_0x8b9f5c,this['_buildIdpRequest']());}['_linkToIdToken'](_0x89714f,_0x428c63){return Xe(_0x89714f,this['_buildIdpRequest'](_0x428c63));}['_getReauthenticationResolver'](_0x3c248e){return Xe(_0x3c248e,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x23263a){const _0x58ead8={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x23263a&&(_0x58ead8['idToken']=_0x23263a),_0x58ead8;}}function yp(_0xab4be3){return Va(_0xab4be3['auth'],new ks(_0xab4be3),_0xab4be3['bypassAuthState']);}function vp(_0x491670){const {auth:_0x5208e5,user:_0xc7b3da}=_0x491670;return m(_0xc7b3da,_0x5208e5,'internal-error'),Xf(_0xc7b3da,new ks(_0x491670),_0x491670['bypassAuthState']);}async function Ep(_0x436a24){const {auth:_0x4092af,user:_0x436fca}=_0x436a24;return m(_0x436fca,_0x4092af,'internal-error'),Jf(_0x436fca,new ks(_0x436a24),_0x436a24['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x47a4d6,_0x2621bf,_0x151379,_0x30b4d6,_0x1fda32=!0x1){this['auth']=_0x47a4d6,this['resolver']=_0x151379,this['user']=_0x30b4d6,this['bypassAuthState']=_0x1fda32,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x2621bf)?_0x2621bf:[_0x2621bf];}['execute'](){return new Promise(async(_0x51856b,_0x277aff)=>{this['pendingPromise']={'resolve':_0x51856b,'reject':_0x277aff};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x4bb2c5){this['reject'](_0x4bb2c5);}});}async['onAuthEvent'](_0x5f5756){const {urlResponse:_0x38d25d,sessionId:_0x426512,postBody:_0x17c6ac,tenantId:_0x8e6221,error:_0x2360f2,type:_0x466a7e}=_0x5f5756;if(_0x2360f2){this['reject'](_0x2360f2);return;}const _0x2776a={'auth':this['auth'],'requestUri':_0x38d25d,'sessionId':_0x426512,'tenantId':_0x8e6221||void 0x0,'postBody':_0x17c6ac||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x466a7e)(_0x2776a));}catch(_0x544201){this['reject'](_0x544201);}}['onError'](_0xf7cacc){this['reject'](_0xf7cacc);}['getIdpTask'](_0xc91425){switch(_0xc91425){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x3e1039){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x3e1039),this['unregisterAndCleanUp']();}['reject'](_0x7373aa){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x7373aa),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x9d5c4b,_0x2a4385,_0x1828f0,_0x3a454c,_0x3ffed5){super(_0x9d5c4b,_0x2a4385,_0x3a454c,_0x3ffed5),this['provider']=_0x1828f0,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x5d634b=await this['execute']();return m(_0x5d634b,this['auth'],'internal-error'),_0x5d634b;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x3c5f4e=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x3c5f4e),this['authWindow']['associatedEvent']=_0x3c5f4e,this['resolver']['_originValidation'](this['auth'])['catch'](_0x38fa0d=>{this['reject'](_0x38fa0d);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x5c133a=>{_0x5c133a||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x1587c2;return((_0x1587c2=this['authWindow'])==null?void 0x0:_0x1587c2['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x1e08de=()=>{var _0x1fa31b,_0x2a0313;if((_0x2a0313=(_0x1fa31b=this['authWindow'])==null?void 0x0:_0x1fa31b['window'])!=null&&_0x2a0313['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x1e08de,Ip['get']());};_0x1e08de();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x4ac1d9,_0x11b9f6,_0x144e1f=!0x1){super(_0x4ac1d9,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x11b9f6,void 0x0,_0x144e1f),this['eventId']=null;}async['execute'](){let _0x23c9c3=on['get'](this['auth']['_key']());if(!_0x23c9c3){try{const _0x323cc1=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x23c9c3=()=>Promise['resolve'](_0x323cc1);}catch(_0x74a381){_0x23c9c3=()=>Promise['reject'](_0x74a381);}on['set'](this['auth']['_key'](),_0x23c9c3);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x23c9c3();}async['onAuthEvent'](_0xc14560){if(_0xc14560['type']==='signInViaRedirect')return super['onAuthEvent'](_0xc14560);if(_0xc14560['type']==='unknown'){this['resolve'](null);return;}if(_0xc14560['eventId']){const _0x58e06d=await this['auth']['_redirectUserForId'](_0xc14560['eventId']);if(_0x58e06d)return this['user']=_0x58e06d,super['onAuthEvent'](_0xc14560);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x44f8ee,_0xb7411e){const _0x5b7215=Rp(_0xb7411e),_0x111540=bp(_0x44f8ee);if(!await _0x111540['_isAvailable']())return!0x1;const _0x3125ab=await _0x111540['_get'](_0x5b7215)==='true';return await _0x111540['_remove'](_0x5b7215),_0x3125ab;}function Sp(_0x2eba8f,_0x32f44b){on['set'](_0x2eba8f['_key'](),_0x32f44b);}function bp(_0x2c4c23){return ie(_0x2c4c23['_redirectPersistence']);}function Rp(_0x1ca235){return rn(wp,_0x1ca235['config']['apiKey'],_0x1ca235['name']);}async function Ap(_0x560cdf,_0x21f74e,_0x4469a9=!0x1){if($(_0x560cdf['app']))return Promise['reject'](re(_0x560cdf));const _0x1f6bfe=qe(_0x560cdf),_0x3eead4=mp(_0x1f6bfe,_0x21f74e),_0x4cc3af=await new Cp(_0x1f6bfe,_0x3eead4,_0x4469a9)['execute']();return _0x4cc3af&&!_0x4469a9&&(delete _0x4cc3af['user']['_redirectEventId'],await _0x1f6bfe['_persistUserIfCurrent'](_0x4cc3af['user']),await _0x1f6bfe['_setRedirectUser'](null,_0x21f74e)),_0x4cc3af;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x3473c6){this['auth']=_0x3473c6,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0xbced15){this['consumers']['add'](_0xbced15),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0xbced15)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0xbced15),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x14f429){this['consumers']['delete'](_0x14f429);}['onEvent'](_0x2aef7b){if(this['hasEventBeenHandled'](_0x2aef7b))return!0x1;let _0x48bb2c=!0x1;return this['consumers']['forEach'](_0x2d5079=>{this['isEventForConsumer'](_0x2aef7b,_0x2d5079)&&(_0x48bb2c=!0x0,this['sendToConsumer'](_0x2aef7b,_0x2d5079),this['saveEventToCache'](_0x2aef7b));}),this['hasHandledPotentialRedirect']||!Pp(_0x2aef7b)||(this['hasHandledPotentialRedirect']=!0x0,_0x48bb2c||(this['queuedRedirectEvent']=_0x2aef7b,_0x48bb2c=!0x0)),_0x48bb2c;}['sendToConsumer'](_0x42da08,_0x2c89a7){var _0x4bc78e;if(_0x42da08['error']&&!Xa(_0x42da08)){const _0x52af2b=((_0x4bc78e=_0x42da08['error']['code'])==null?void 0x0:_0x4bc78e['split']('auth/')[0x1])||'internal-error';_0x2c89a7['onError'](X(this['auth'],_0x52af2b));}else _0x2c89a7['onAuthEvent'](_0x42da08);}['isEventForConsumer'](_0x5adaa4,_0x14177b){const _0x29c5db=_0x14177b['eventId']===null||!!_0x5adaa4['eventId']&&_0x5adaa4['eventId']===_0x14177b['eventId'];return _0x14177b['filter']['includes'](_0x5adaa4['type'])&&_0x29c5db;}['hasEventBeenHandled'](_0xc38bc0){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0xc38bc0));}['saveEventToCache'](_0x3f9de1){this['cachedEventUids']['add'](Dr(_0x3f9de1)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x31f8be){return[_0x31f8be['type'],_0x31f8be['eventId'],_0x31f8be['sessionId'],_0x31f8be['tenantId']]['filter'](_0x1d058b=>_0x1d058b)['join']('-');}function Xa({type:_0x34ff48,error:_0x577c23}){return _0x34ff48==='unknown'&&(_0x577c23==null?void 0x0:_0x577c23['code'])==='auth/no-auth-event';}function Pp(_0x3aaa13){switch(_0x3aaa13['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x3aaa13);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x56f823,_0x5e25fe={}){return Ae(_0x56f823,'GET','/v1/projects',_0x5e25fe);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x47557c){if(_0x47557c['config']['emulator'])return;const {authorizedDomains:_0x535720}=await Op(_0x47557c);for(const _0x5a01d6 of _0x535720)try{if(xp(_0x5a01d6))return;}catch{}Q(_0x47557c,'unauthorized-domain');}function xp(_0x42266a){const _0x3fc167=Pi(),{protocol:_0x10724e,hostname:_0x2c8155}=new URL(_0x3fc167);if(_0x42266a['startsWith']('chrome-extension://')){const _0x353077=new URL(_0x42266a);return _0x353077['hostname']===''&&_0x2c8155===''?_0x10724e==='chrome-extension:'&&_0x42266a['replace']('chrome-extension://','')===_0x3fc167['replace']('chrome-extension://',''):_0x10724e==='chrome-extension:'&&_0x353077['hostname']===_0x2c8155;}if(!Mp['test'](_0x10724e))return!0x1;if(Dp['test'](_0x42266a))return _0x2c8155===_0x42266a;const _0x54d11e=_0x42266a['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x54d11e+'|'+_0x54d11e+')$','i')['test'](_0x2c8155);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x1f47f2=Z()['___jsl'];if(_0x1f47f2!=null&&_0x1f47f2['H']){for(const _0x5bf37a of Object['keys'](_0x1f47f2['H']))if(_0x1f47f2['H'][_0x5bf37a]['r']=_0x1f47f2['H'][_0x5bf37a]['r']||[],_0x1f47f2['H'][_0x5bf37a]['L']=_0x1f47f2['H'][_0x5bf37a]['L']||[],_0x1f47f2['H'][_0x5bf37a]['r']=[..._0x1f47f2['H'][_0x5bf37a]['L']],_0x1f47f2['CP']){for(let _0x253860=0x0;_0x253860<_0x1f47f2['CP']['length'];_0x253860++)_0x1f47f2['CP'][_0x253860]=null;}}}function Up(_0x3946bb){return new Promise((_0x3a1e59,_0x1eeb71)=>{var _0x297d24,_0x1e0bb3,_0x5c73a0;function _0x297672(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x3a1e59(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x1eeb71(X(_0x3946bb,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x1e0bb3=(_0x297d24=Z()['gapi'])==null?void 0x0:_0x297d24['iframes'])!=null&&_0x1e0bb3['Iframe'])_0x3a1e59(gapi['iframes']['getContext']());else{if((_0x5c73a0=Z()['gapi'])!=null&&_0x5c73a0['load'])_0x297672();else{const _0x50455d=Df('iframefcb');return Z()[_0x50455d]=()=>{gapi['load']?_0x297672():_0x1eeb71(X(_0x3946bb,'network-request-failed'));},xa(Of()+'?onload='+_0x50455d)['catch'](_0x15b993=>_0x1eeb71(_0x15b993));}}})['catch'](_0x5c20f1=>{throw an=null,_0x5c20f1;});}let an=null;function Wp(_0x390251){return an=an||Up(_0x390251),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x3425c5){const _0x1340d0=_0x3425c5['config'];m(_0x1340d0['authDomain'],_0x3425c5,'auth-domain-config-required');const _0x1229f0=_0x1340d0['emulator']?Cs(_0x1340d0,Hp):'https://'+_0x3425c5['config']['authDomain']+'/'+Vp,_0x166260={'apiKey':_0x1340d0['apiKey'],'appName':_0x3425c5['name'],'v':lt},_0x91b98e=Gp['get'](_0x3425c5['config']['apiHost']);_0x91b98e&&(_0x166260['eid']=_0x91b98e);const _0x4fc719=_0x3425c5['_getFrameworks']();return _0x4fc719['length']&&(_0x166260['fw']=_0x4fc719['join'](',')),_0x1229f0+'?'+ct(_0x166260)['slice'](0x1);}async function zp(_0x59968c){const _0x1a4c66=await Wp(_0x59968c),_0x2502d6=Z()['gapi'];return m(_0x2502d6,_0x59968c,'internal-error'),_0x1a4c66['open']({'where':document['body'],'url':qp(_0x59968c),'messageHandlersFilter':_0x2502d6['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x2ddfdd=>new Promise(async(_0x5558a1,_0x4b11d8)=>{await _0x2ddfdd['restyle']({'setHideOnLeave':!0x1});const _0x5b4435=X(_0x59968c,'network-request-failed'),_0x1f132b=Z()['setTimeout'](()=>{_0x4b11d8(_0x5b4435);},Bp['get']());function _0x29d094(){Z()['clearTimeout'](_0x1f132b),_0x5558a1(_0x2ddfdd);}_0x2ddfdd['ping'](_0x29d094)['then'](_0x29d094,()=>{_0x4b11d8(_0x5b4435);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x1ee754){this['window']=_0x1ee754,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x486065,_0x2625c8,_0x45f892,_0xd0c1cb=Kp,_0x41d905=Yp){const _0x25eb6c=Math['max']((window['screen']['availHeight']-_0x41d905)/0x2,0x0)['toString'](),_0x40f729=Math['max']((window['screen']['availWidth']-_0xd0c1cb)/0x2,0x0)['toString']();let _0xad6906='';const _0x51e065={...jp,'width':_0xd0c1cb['toString'](),'height':_0x41d905['toString'](),'top':_0x25eb6c,'left':_0x40f729},_0x315650=W()['toLowerCase']();_0x45f892&&(_0xad6906=ka(_0x315650)?Qp:_0x45f892),Ra(_0x315650)&&(_0x2625c8=_0x2625c8||Jp,_0x51e065['scrollbars']='yes');const _0x7eb105=Object['entries'](_0x51e065)['reduce']((_0xce7775,[_0x3bee2c,_0x1267aa])=>''+_0xce7775+_0x3bee2c+'='+_0x1267aa+',','');if(Cf(_0x315650)&&_0xad6906!=='_self')return Zp(_0x2625c8||'',_0xad6906),new Lr(null);const _0x5ee33b=window['open'](_0x2625c8||'',_0xad6906,_0x7eb105);m(_0x5ee33b,_0x486065,'popup-blocked');try{_0x5ee33b['focus']();}catch{}return new Lr(_0x5ee33b);}function Zp(_0x11ffbb,_0x59f658){const _0x5736f6=document['createElement']('a');_0x5736f6['href']=_0x11ffbb,_0x5736f6['target']=_0x59f658;const _0x1d72fd=document['createEvent']('MouseEvent');_0x1d72fd['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x5736f6['dispatchEvent'](_0x1d72fd);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x1582b8,_0x3c4e07,_0x20b5b8,_0x5359b8,_0x51c656,_0x323a15){m(_0x1582b8['config']['authDomain'],_0x1582b8,'auth-domain-config-required'),m(_0x1582b8['config']['apiKey'],_0x1582b8,'invalid-api-key');const _0x4185b7={'apiKey':_0x1582b8['config']['apiKey'],'appName':_0x1582b8['name'],'authType':_0x20b5b8,'redirectUrl':_0x5359b8,'v':lt,'eventId':_0x51c656};if(_0x3c4e07 instanceof Wa){_0x3c4e07['setDefaultLanguage'](_0x1582b8['languageCode']),_0x4185b7['providerId']=_0x3c4e07['providerId']||'',ui(_0x3c4e07['getCustomParameters']())||(_0x4185b7['customParameters']=JSON['stringify'](_0x3c4e07['getCustomParameters']()));for(const [_0x407ebf,_0x415136]of Object['entries']({}))_0x4185b7[_0x407ebf]=_0x415136;}if(_0x3c4e07 instanceof Jt){const _0x31b546=_0x3c4e07['getScopes']()['filter'](_0x10b861=>_0x10b861!=='');_0x31b546['length']>0x0&&(_0x4185b7['scopes']=_0x31b546['join'](','));}_0x1582b8['tenantId']&&(_0x4185b7['tid']=_0x1582b8['tenantId']);const _0x481b01=_0x4185b7;for(const _0x11e0d6 of Object['keys'](_0x481b01))_0x481b01[_0x11e0d6]===void 0x0&&delete _0x481b01[_0x11e0d6];const _0xc631bc=await _0x1582b8['_getAppCheckToken'](),_0x5edb4a=_0xc631bc?'#'+n_+'='+encodeURIComponent(_0xc631bc):'';return i_(_0x1582b8)+'?'+ct(_0x481b01)['slice'](0x1)+_0x5edb4a;}function i_({config:_0x5df5a9}){return _0x5df5a9['emulator']?Cs(_0x5df5a9,t_):'https://'+_0x5df5a9['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x3bdcac,_0x104179,_0x34a43d,_0x5d7731){var _0x363bc6;ce((_0x363bc6=this['eventManagers'][_0x3bdcac['_key']()])==null?void 0x0:_0x363bc6['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x4ef3cf=await xr(_0x3bdcac,_0x104179,_0x34a43d,Pi(),_0x5d7731);return Xp(_0x3bdcac,_0x4ef3cf,As());}async['_openRedirect'](_0x33e780,_0x1382ed,_0x3616d3,_0x29bcb9){await this['_originValidation'](_0x33e780);const _0x1c3d44=await xr(_0x33e780,_0x1382ed,_0x3616d3,Pi(),_0x29bcb9);return ap(_0x1c3d44),new Promise(()=>{});}['_initialize'](_0x53fba4){const _0x28c4e5=_0x53fba4['_key']();if(this['eventManagers'][_0x28c4e5]){const {manager:_0x2faaef,promise:_0x476912}=this['eventManagers'][_0x28c4e5];return _0x2faaef?Promise['resolve'](_0x2faaef):(ce(_0x476912,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x476912);}const _0x340076=this['initAndGetManager'](_0x53fba4);return this['eventManagers'][_0x28c4e5]={'promise':_0x340076},_0x340076['catch'](()=>{delete this['eventManagers'][_0x28c4e5];}),_0x340076;}async['initAndGetManager'](_0x1f8ae3){const _0x3a5a6e=await zp(_0x1f8ae3),_0x2eec28=new Np(_0x1f8ae3);return _0x3a5a6e['register']('authEvent',_0x41b4b9=>(m(_0x41b4b9==null?void 0x0:_0x41b4b9['authEvent'],_0x1f8ae3,'invalid-auth-event'),{'status':_0x2eec28['onEvent'](_0x41b4b9['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x1f8ae3['_key']()]={'manager':_0x2eec28},this['iframes'][_0x1f8ae3['_key']()]=_0x3a5a6e,_0x2eec28;}['_isIframeWebStorageSupported'](_0x4ea0fc,_0x5d2835){this['iframes'][_0x4ea0fc['_key']()]['send'](hi,{'type':hi},_0x500a6d=>{var _0x11c845;const _0x31088e=(_0x11c845=_0x500a6d==null?void 0x0:_0x500a6d[0x0])==null?void 0x0:_0x11c845[hi];_0x31088e!==void 0x0&&_0x5d2835(!!_0x31088e),Q(_0x4ea0fc,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x5bec34){const _0xd5c5c2=_0x5bec34['_key']();return this['originValidationPromises'][_0xd5c5c2]||(this['originValidationPromises'][_0xd5c5c2]=Lp(_0x5bec34)),this['originValidationPromises'][_0xd5c5c2];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0xb2adee){this['auth']=_0xb2adee,this['internalListeners']=new Map();}['getUid'](){var _0x242680;return this['assertAuthConfigured'](),((_0x242680=this['auth']['currentUser'])==null?void 0x0:_0x242680['uid'])||null;}async['getToken'](_0x271b09){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x271b09)}:null;}['addAuthTokenListener'](_0x451621){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x451621))return;const _0x57a500=this['auth']['onIdTokenChanged'](_0x512372=>{_0x451621((_0x512372==null?void 0x0:_0x512372['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x451621,_0x57a500),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x438df5){this['assertAuthConfigured']();const _0x8f5214=this['internalListeners']['get'](_0x438df5);_0x8f5214&&(this['internalListeners']['delete'](_0x438df5),_0x8f5214(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x5e155b){switch(_0x5e155b){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x4bbd19){Ze(new Le('auth',(_0x8dc80f,{options:_0x318cb3})=>{const _0x1db1e7=_0x8dc80f['getProvider']('app')['getImmediate'](),_0x1c6e84=_0x8dc80f['getProvider']('heartbeat'),_0x2fe776=_0x8dc80f['getProvider']('app-check-internal'),{apiKey:_0x180b8a,authDomain:_0x18dee9}=_0x1db1e7['options'];m(_0x180b8a&&!_0x180b8a['includes'](':'),'invalid-api-key',{'appName':_0x1db1e7['name']});const _0xa407db={'apiKey':_0x180b8a,'authDomain':_0x18dee9,'clientPlatform':_0x4bbd19,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x4bbd19)},_0xfcbcac=new kf(_0x1db1e7,_0x1c6e84,_0x2fe776,_0xa407db);return Wf(_0xfcbcac,_0x318cb3),_0xfcbcac;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x5d0538,_0x4d1544,_0x2d5b19)=>{_0x5d0538['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x3f516f=>{const _0x2636f7=qe(_0x3f516f['getProvider']('auth')['getImmediate']());return(_0x128319=>new o_(_0x128319))(_0x2636f7);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x4bbd19)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x4f10ac=>async _0x1e07bd=>{const _0x11a88d=_0x1e07bd&&await _0x1e07bd['getIdTokenResult'](),_0x3fd6f9=_0x11a88d&&(new Date()['getTime']()-Date['parse'](_0x11a88d['issuedAtTime']))/0x3e8;if(_0x3fd6f9&&_0x3fd6f9>h_)return;const _0x2ef38c=_0x11a88d==null?void 0x0:_0x11a88d['token'];Wr!==_0x2ef38c&&(Wr=_0x2ef38c,await fetch(_0x4f10ac,{'method':_0x2ef38c?'POST':'DELETE','headers':_0x2ef38c?{'Authorization':'Bearer\x20'+_0x2ef38c}:{}}));};function x_(_0x5f0065=Zr()){const _0x351847=Bi(_0x5f0065,'auth');if(_0x351847['isInitialized']())return _0x351847['getImmediate']();const _0x3797f2=Uf(_0x5f0065,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0xcbb6a7=zr('authTokenSyncURL');if(_0xcbb6a7&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x10efc7=new URL(_0xcbb6a7,location['origin']);if(location['origin']===_0x10efc7['origin']){const _0x53c048=u_(_0x10efc7['toString']());tp(_0x3797f2,_0x53c048,()=>_0x53c048(_0x3797f2['currentUser'])),ep(_0x3797f2,_0x19c978=>_0x53c048(_0x19c978));}}const _0x342ad3=Gr('auth');return _0x342ad3&&Bf(_0x3797f2,'http://'+_0x342ad3),_0x3797f2;}function d_(){var _0x3caad8;return((_0x3caad8=document['getElementsByTagName']('head'))==null?void 0x0:_0x3caad8[0x0])??document;}Nf({'loadJS'(_0x1164d1){return new Promise((_0xf9dc47,_0x1ea872)=>{const _0x3a8cf1=document['createElement']('script');_0x3a8cf1['setAttribute']('src',_0x1164d1),_0x3a8cf1['onload']=_0xf9dc47,_0x3a8cf1['onerror']=_0x64f419=>{const _0x338dc2=X('internal-error');_0x338dc2['customData']=_0x64f419,_0x1ea872(_0x338dc2);},_0x3a8cf1['type']='text/javascript',_0x3a8cf1['charset']='UTF-8',d_()['appendChild'](_0x3a8cf1);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};