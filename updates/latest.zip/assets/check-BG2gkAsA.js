import{c}from'./index-Bjr25Z02.js';/**
 * @license lucide-react v0.556.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const e=[['path',{'d':'M20\x206\x209\x2017l-5-5','key':'1gmf2c'}]],t=c('check',e);export{t as C};