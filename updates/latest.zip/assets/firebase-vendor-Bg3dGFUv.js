const ic=()=>{};var xs={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0xe8d0ab,_0xb59cd1){if(!_0xe8d0ab)throw ht(_0xb59cd1);},ht=function(_0x2b659d){return new Error('Firebase\x20Database\x20('+jr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x2b659d);},Kr=function(_0x1dcb9b){const _0x36a915=[];let _0x42bf84=0x0;for(let _0x230ba0=0x0;_0x230ba0<_0x1dcb9b['length'];_0x230ba0++){let _0x5ca27d=_0x1dcb9b['charCodeAt'](_0x230ba0);_0x5ca27d<0x80?_0x36a915[_0x42bf84++]=_0x5ca27d:_0x5ca27d<0x800?(_0x36a915[_0x42bf84++]=_0x5ca27d>>0x6|0xc0,_0x36a915[_0x42bf84++]=_0x5ca27d&0x3f|0x80):(_0x5ca27d&0xfc00)===0xd800&&_0x230ba0+0x1<_0x1dcb9b['length']&&(_0x1dcb9b['charCodeAt'](_0x230ba0+0x1)&0xfc00)===0xdc00?(_0x5ca27d=0x10000+((_0x5ca27d&0x3ff)<<0xa)+(_0x1dcb9b['charCodeAt'](++_0x230ba0)&0x3ff),_0x36a915[_0x42bf84++]=_0x5ca27d>>0x12|0xf0,_0x36a915[_0x42bf84++]=_0x5ca27d>>0xc&0x3f|0x80,_0x36a915[_0x42bf84++]=_0x5ca27d>>0x6&0x3f|0x80,_0x36a915[_0x42bf84++]=_0x5ca27d&0x3f|0x80):(_0x36a915[_0x42bf84++]=_0x5ca27d>>0xc|0xe0,_0x36a915[_0x42bf84++]=_0x5ca27d>>0x6&0x3f|0x80,_0x36a915[_0x42bf84++]=_0x5ca27d&0x3f|0x80);}return _0x36a915;},sc=function(_0x39d311){const _0x150edb=[];let _0x3cdac2=0x0,_0x4eddd1=0x0;for(;_0x3cdac2<_0x39d311['length'];){const _0x213439=_0x39d311[_0x3cdac2++];if(_0x213439<0x80)_0x150edb[_0x4eddd1++]=String['fromCharCode'](_0x213439);else{if(_0x213439>0xbf&&_0x213439<0xe0){const _0x5568b8=_0x39d311[_0x3cdac2++];_0x150edb[_0x4eddd1++]=String['fromCharCode']((_0x213439&0x1f)<<0x6|_0x5568b8&0x3f);}else{if(_0x213439>0xef&&_0x213439<0x16d){const _0x2bab1b=_0x39d311[_0x3cdac2++],_0x43f661=_0x39d311[_0x3cdac2++],_0x2043bc=_0x39d311[_0x3cdac2++],_0xddf8ad=((_0x213439&0x7)<<0x12|(_0x2bab1b&0x3f)<<0xc|(_0x43f661&0x3f)<<0x6|_0x2043bc&0x3f)-0x10000;_0x150edb[_0x4eddd1++]=String['fromCharCode'](0xd800+(_0xddf8ad>>0xa)),_0x150edb[_0x4eddd1++]=String['fromCharCode'](0xdc00+(_0xddf8ad&0x3ff));}else{const _0x52bb0f=_0x39d311[_0x3cdac2++],_0x1a0ea5=_0x39d311[_0x3cdac2++];_0x150edb[_0x4eddd1++]=String['fromCharCode']((_0x213439&0xf)<<0xc|(_0x52bb0f&0x3f)<<0x6|_0x1a0ea5&0x3f);}}}}return _0x150edb['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x3229e0,_0x14c9f7){if(!Array['isArray'](_0x3229e0))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x1249a1=_0x14c9f7?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x4a8d24=[];for(let _0x59e541=0x0;_0x59e541<_0x3229e0['length'];_0x59e541+=0x3){const _0x2b8c5e=_0x3229e0[_0x59e541],_0xe9c0b6=_0x59e541+0x1<_0x3229e0['length'],_0x27fc4c=_0xe9c0b6?_0x3229e0[_0x59e541+0x1]:0x0,_0x45bcae=_0x59e541+0x2<_0x3229e0['length'],_0x41a6ac=_0x45bcae?_0x3229e0[_0x59e541+0x2]:0x0,_0x14ccfa=_0x2b8c5e>>0x2,_0x3f3d8f=(_0x2b8c5e&0x3)<<0x4|_0x27fc4c>>0x4;let _0x9c13a3=(_0x27fc4c&0xf)<<0x2|_0x41a6ac>>0x6,_0x26c838=_0x41a6ac&0x3f;_0x45bcae||(_0x26c838=0x40,_0xe9c0b6||(_0x9c13a3=0x40)),_0x4a8d24['push'](_0x1249a1[_0x14ccfa],_0x1249a1[_0x3f3d8f],_0x1249a1[_0x9c13a3],_0x1249a1[_0x26c838]);}return _0x4a8d24['join']('');},'encodeString'(_0x4adb7c,_0x149c8b){return this['HAS_NATIVE_SUPPORT']&&!_0x149c8b?btoa(_0x4adb7c):this['encodeByteArray'](Kr(_0x4adb7c),_0x149c8b);},'decodeString'(_0xc45c70,_0x12bcda){return this['HAS_NATIVE_SUPPORT']&&!_0x12bcda?atob(_0xc45c70):sc(this['decodeStringToByteArray'](_0xc45c70,_0x12bcda));},'decodeStringToByteArray'(_0x1e7939,_0x404938){this['init_']();const _0x3a750c=_0x404938?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x3df20b=[];for(let _0x55aabb=0x0;_0x55aabb<_0x1e7939['length'];){const _0x4ba635=_0x3a750c[_0x1e7939['charAt'](_0x55aabb++)],_0x384830=_0x55aabb<_0x1e7939['length']?_0x3a750c[_0x1e7939['charAt'](_0x55aabb)]:0x0;++_0x55aabb;const _0x2ceee6=_0x55aabb<_0x1e7939['length']?_0x3a750c[_0x1e7939['charAt'](_0x55aabb)]:0x40;++_0x55aabb;const _0x188b3d=_0x55aabb<_0x1e7939['length']?_0x3a750c[_0x1e7939['charAt'](_0x55aabb)]:0x40;if(++_0x55aabb,_0x4ba635==null||_0x384830==null||_0x2ceee6==null||_0x188b3d==null)throw new rc();const _0x5b5b35=_0x4ba635<<0x2|_0x384830>>0x4;if(_0x3df20b['push'](_0x5b5b35),_0x2ceee6!==0x40){const _0x372a89=_0x384830<<0x4&0xf0|_0x2ceee6>>0x2;if(_0x3df20b['push'](_0x372a89),_0x188b3d!==0x40){const _0x933961=_0x2ceee6<<0x6&0xc0|_0x188b3d;_0x3df20b['push'](_0x933961);}}}return _0x3df20b;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x3fb381=0x0;_0x3fb381<this['ENCODED_VALS']['length'];_0x3fb381++)this['byteToCharMap_'][_0x3fb381]=this['ENCODED_VALS']['charAt'](_0x3fb381),this['charToByteMap_'][this['byteToCharMap_'][_0x3fb381]]=_0x3fb381,this['byteToCharMapWebSafe_'][_0x3fb381]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3fb381),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x3fb381]]=_0x3fb381,_0x3fb381>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3fb381)]=_0x3fb381,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x3fb381)]=_0x3fb381);}}};class rc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Yr=function(_0x7c1829){const _0x4b7c02=Kr(_0x7c1829);return Fi['encodeByteArray'](_0x4b7c02,!0x0);},fn=function(_0x24334a){return Yr(_0x24334a)['replace'](/\./g,'');},pn=function(_0x28da26){try{return Fi['decodeString'](_0x28da26,!0x0);}catch(_0x6d71bf){console['error']('base64Decode\x20failed:\x20',_0x6d71bf);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(_0x5adf10){return Qr(void 0x0,_0x5adf10);}function Qr(_0xfe60a9,_0x5dd312){if(!(_0x5dd312 instanceof Object))return _0x5dd312;switch(_0x5dd312['constructor']){case Date:const _0x590618=_0x5dd312;return new Date(_0x590618['getTime']());case Object:_0xfe60a9===void 0x0&&(_0xfe60a9={});break;case Array:_0xfe60a9=[];break;default:return _0x5dd312;}for(const _0x362d54 in _0x5dd312)!_0x5dd312['hasOwnProperty'](_0x362d54)||!ac(_0x362d54)||(_0xfe60a9[_0x362d54]=Qr(_0xfe60a9[_0x362d54],_0x5dd312[_0x362d54]));return _0xfe60a9;}function ac(_0x3da291){return _0x3da291!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lc=()=>cc()['__FIREBASE_DEFAULTS__'],hc=()=>{if(typeof process>'u'||typeof xs>'u')return;const _0x189bc9=xs['__FIREBASE_DEFAULTS__'];if(_0x189bc9)return JSON['parse'](_0x189bc9);},uc=()=>{if(typeof document>'u')return;let _0x563775;try{_0x563775=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x5ceffb=_0x563775&&pn(_0x563775[0x1]);return _0x5ceffb&&JSON['parse'](_0x5ceffb);},Ui=()=>{try{return ic()||lc()||hc()||uc();}catch(_0x5401f5){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x5401f5);return;}},Jr=_0x2ebde5=>{var _0x55a504,_0x139b85;return(_0x139b85=(_0x55a504=Ui())==null?void 0x0:_0x55a504['emulatorHosts'])==null?void 0x0:_0x139b85[_0x2ebde5];},dc=_0x2b2a33=>{const _0x47f920=Jr(_0x2b2a33);if(!_0x47f920)return;const _0x49591a=_0x47f920['lastIndexOf'](':');if(_0x49591a<=0x0||_0x49591a+0x1===_0x47f920['length'])throw new Error('Invalid\x20host\x20'+_0x47f920+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x2fe02e=parseInt(_0x47f920['substring'](_0x49591a+0x1),0xa);return _0x47f920[0x0]==='['?[_0x47f920['substring'](0x1,_0x49591a-0x1),_0x2fe02e]:[_0x47f920['substring'](0x0,_0x49591a),_0x2fe02e];},Xr=()=>{var _0x1450d3;return(_0x1450d3=Ui())==null?void 0x0:_0x1450d3['config'];},Zr=_0x1efd07=>{var _0x1327a4;return(_0x1327a4=Ui())==null?void 0x0:_0x1327a4['_'+_0x1efd07];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x826aed,_0x35b8c6)=>{this['resolve']=_0x826aed,this['reject']=_0x35b8c6;});}['wrapCallback'](_0x2f8b9f){return(_0x4e6a4f,_0x39fa36)=>{_0x4e6a4f?this['reject'](_0x4e6a4f):this['resolve'](_0x39fa36),typeof _0x2f8b9f=='function'&&(this['promise']['catch'](()=>{}),_0x2f8b9f['length']===0x1?_0x2f8b9f(_0x4e6a4f):_0x2f8b9f(_0x4e6a4f,_0x39fa36));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fc(_0x336324,_0x308176){if(_0x336324['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x34aaa6={'alg':'none','type':'JWT'},_0x195e7f=_0x308176||'demo-project',_0x1d8a0d=_0x336324['iat']||0x0,_0x45d015=_0x336324['sub']||_0x336324['user_id'];if(!_0x45d015)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x37d356={'iss':'https://securetoken.google.com/'+_0x195e7f,'aud':_0x195e7f,'iat':_0x1d8a0d,'exp':_0x1d8a0d+0xe10,'auth_time':_0x1d8a0d,'sub':_0x45d015,'user_id':_0x45d015,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x336324};return[fn(JSON['stringify'](_0x34aaa6)),fn(JSON['stringify'](_0x37d356)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function pc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function _c(){const _0x2eb76d=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x2eb76d=='object'&&_0x2eb76d['id']!==void 0x0;}function eo(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function gc(){const _0x55d84d=W();return _0x55d84d['indexOf']('MSIE\x20')>=0x0||_0x55d84d['indexOf']('Trident/')>=0x0;}function mc(){return jr['NODE_ADMIN']===!0x0;}function yc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function vc(){return new Promise((_0x3ad735,_0x570bbf)=>{try{let _0x36a519=!0x0;const _0x2e06bd='validate-browser-context-for-indexeddb-analytics-module',_0x3698bc=self['indexedDB']['open'](_0x2e06bd);_0x3698bc['onsuccess']=()=>{_0x3698bc['result']['close'](),_0x36a519||self['indexedDB']['deleteDatabase'](_0x2e06bd),_0x3ad735(!0x0);},_0x3698bc['onupgradeneeded']=()=>{_0x36a519=!0x1;},_0x3698bc['onerror']=()=>{var _0x9421e6;_0x570bbf(((_0x9421e6=_0x3698bc['error'])==null?void 0x0:_0x9421e6['message'])||'');};}catch(_0x474c62){_0x570bbf(_0x474c62);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ec='FirebaseError';class be extends Error{constructor(_0x37026d,_0x1cf2ba,_0x1f38d3){super(_0x1cf2ba),this['code']=_0x37026d,this['customData']=_0x1f38d3,this['name']=Ec,Object['setPrototypeOf'](this,be['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x4fcd35,_0xa8c8c0,_0x50297f){this['service']=_0x4fcd35,this['serviceName']=_0xa8c8c0,this['errors']=_0x50297f;}['create'](_0x2e7c21,..._0x25fa71){const _0x20c47b=_0x25fa71[0x0]||{},_0x1a2f2f=this['service']+'/'+_0x2e7c21,_0x3f6d6c=this['errors'][_0x2e7c21],_0x5f00af=_0x3f6d6c?Ic(_0x3f6d6c,_0x20c47b):'Error',_0x72f367=this['serviceName']+':\x20'+_0x5f00af+'\x20('+_0x1a2f2f+').';return new be(_0x1a2f2f,_0x72f367,_0x20c47b);}}function Ic(_0x3df027,_0x24492a){return _0x3df027['replace'](wc,(_0x274410,_0x1de5b1)=>{const _0x49e459=_0x24492a[_0x1de5b1];return _0x49e459!=null?String(_0x49e459):'<'+_0x1de5b1+'?>';});}const wc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x55e761){return JSON['parse'](_0x55e761);}function O(_0x292c6b){return JSON['stringify'](_0x292c6b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const to=function(_0x1d86a5){let _0x1ace87={},_0x48a098={},_0x5eac63={},_0x56f76='';try{const _0x1c4b77=_0x1d86a5['split']('.');_0x1ace87=Pt(pn(_0x1c4b77[0x0])||''),_0x48a098=Pt(pn(_0x1c4b77[0x1])||''),_0x56f76=_0x1c4b77[0x2],_0x5eac63=_0x48a098['d']||{},delete _0x48a098['d'];}catch{}return{'header':_0x1ace87,'claims':_0x48a098,'data':_0x5eac63,'signature':_0x56f76};},Cc=function(_0x2e35f8){const _0x31a29c=to(_0x2e35f8),_0x366707=_0x31a29c['claims'];return!!_0x366707&&typeof _0x366707=='object'&&_0x366707['hasOwnProperty']('iat');},Tc=function(_0x20119e){const _0x2be7bd=to(_0x20119e)['claims'];return typeof _0x2be7bd=='object'&&_0x2be7bd['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x16e397,_0x2f2b62){return Object['prototype']['hasOwnProperty']['call'](_0x16e397,_0x2f2b62);}function Le(_0x314236,_0x32cb16){if(Object['prototype']['hasOwnProperty']['call'](_0x314236,_0x32cb16))return _0x314236[_0x32cb16];}function _n(_0xfc757a){for(const _0x2c18ca in _0xfc757a)if(Object['prototype']['hasOwnProperty']['call'](_0xfc757a,_0x2c18ca))return!0x1;return!0x0;}function gn(_0xbf196b,_0x34da29,_0x61102c){const _0x2da34f={};for(const _0x1a8650 in _0xbf196b)Object['prototype']['hasOwnProperty']['call'](_0xbf196b,_0x1a8650)&&(_0x2da34f[_0x1a8650]=_0x34da29['call'](_0x61102c,_0xbf196b[_0x1a8650],_0x1a8650,_0xbf196b));return _0x2da34f;}function xe(_0xa16e3a,_0x20394d){if(_0xa16e3a===_0x20394d)return!0x0;const _0x5f0643=Object['keys'](_0xa16e3a),_0x1fafdd=Object['keys'](_0x20394d);for(const _0x24f0ac of _0x5f0643){if(!_0x1fafdd['includes'](_0x24f0ac))return!0x1;const _0x4e72b3=_0xa16e3a[_0x24f0ac],_0xa287b9=_0x20394d[_0x24f0ac];if(Fs(_0x4e72b3)&&Fs(_0xa287b9)){if(!xe(_0x4e72b3,_0xa287b9))return!0x1;}else{if(_0x4e72b3!==_0xa287b9)return!0x1;}}for(const _0x3adfc8 of _0x1fafdd)if(!_0x5f0643['includes'](_0x3adfc8))return!0x1;return!0x0;}function Fs(_0xa34b4d){return _0xa34b4d!==null&&typeof _0xa34b4d=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x3523ca){const _0x41ec53=[];for(const [_0xb5ccb1,_0x5019e7]of Object['entries'](_0x3523ca))Array['isArray'](_0x5019e7)?_0x5019e7['forEach'](_0x9009a4=>{_0x41ec53['push'](encodeURIComponent(_0xb5ccb1)+'='+encodeURIComponent(_0x9009a4));}):_0x41ec53['push'](encodeURIComponent(_0xb5ccb1)+'='+encodeURIComponent(_0x5019e7));return _0x41ec53['length']?'&'+_0x41ec53['join']('&'):'';}function Ct(_0x2501c8){const _0x454c01={};return _0x2501c8['replace'](/^\?/,'')['split']('&')['forEach'](_0x5dde3d=>{if(_0x5dde3d){const [_0x1d342f,_0x37f3e6]=_0x5dde3d['split']('=');_0x454c01[decodeURIComponent(_0x1d342f)]=decodeURIComponent(_0x37f3e6);}}),_0x454c01;}function Tt(_0x3e229b){const _0x3714ee=_0x3e229b['indexOf']('?');if(!_0x3714ee)return'';const _0xbc314b=_0x3e229b['indexOf']('#',_0x3714ee);return _0x3e229b['substring'](_0x3714ee,_0xbc314b>0x0?_0xbc314b:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x499945=0x1;_0x499945<this['blockSize'];++_0x499945)this['pad_'][_0x499945]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x4484c1,_0x3b2e01){_0x3b2e01||(_0x3b2e01=0x0);const _0x1e140a=this['W_'];if(typeof _0x4484c1=='string'){for(let _0x175142=0x0;_0x175142<0x10;_0x175142++)_0x1e140a[_0x175142]=_0x4484c1['charCodeAt'](_0x3b2e01)<<0x18|_0x4484c1['charCodeAt'](_0x3b2e01+0x1)<<0x10|_0x4484c1['charCodeAt'](_0x3b2e01+0x2)<<0x8|_0x4484c1['charCodeAt'](_0x3b2e01+0x3),_0x3b2e01+=0x4;}else{for(let _0x471749=0x0;_0x471749<0x10;_0x471749++)_0x1e140a[_0x471749]=_0x4484c1[_0x3b2e01]<<0x18|_0x4484c1[_0x3b2e01+0x1]<<0x10|_0x4484c1[_0x3b2e01+0x2]<<0x8|_0x4484c1[_0x3b2e01+0x3],_0x3b2e01+=0x4;}for(let _0x5e52ea=0x10;_0x5e52ea<0x50;_0x5e52ea++){const _0x2c1746=_0x1e140a[_0x5e52ea-0x3]^_0x1e140a[_0x5e52ea-0x8]^_0x1e140a[_0x5e52ea-0xe]^_0x1e140a[_0x5e52ea-0x10];_0x1e140a[_0x5e52ea]=(_0x2c1746<<0x1|_0x2c1746>>>0x1f)&0xffffffff;}let _0x2648ca=this['chain_'][0x0],_0x5c9806=this['chain_'][0x1],_0x3cac25=this['chain_'][0x2],_0x4b36f0=this['chain_'][0x3],_0x2e3257=this['chain_'][0x4],_0x4cb50f,_0x19467e;for(let _0x8e5a2d=0x0;_0x8e5a2d<0x50;_0x8e5a2d++){_0x8e5a2d<0x28?_0x8e5a2d<0x14?(_0x4cb50f=_0x4b36f0^_0x5c9806&(_0x3cac25^_0x4b36f0),_0x19467e=0x5a827999):(_0x4cb50f=_0x5c9806^_0x3cac25^_0x4b36f0,_0x19467e=0x6ed9eba1):_0x8e5a2d<0x3c?(_0x4cb50f=_0x5c9806&_0x3cac25|_0x4b36f0&(_0x5c9806|_0x3cac25),_0x19467e=0x8f1bbcdc):(_0x4cb50f=_0x5c9806^_0x3cac25^_0x4b36f0,_0x19467e=0xca62c1d6);const _0x14970d=(_0x2648ca<<0x5|_0x2648ca>>>0x1b)+_0x4cb50f+_0x2e3257+_0x19467e+_0x1e140a[_0x8e5a2d]&0xffffffff;_0x2e3257=_0x4b36f0,_0x4b36f0=_0x3cac25,_0x3cac25=(_0x5c9806<<0x1e|_0x5c9806>>>0x2)&0xffffffff,_0x5c9806=_0x2648ca,_0x2648ca=_0x14970d;}this['chain_'][0x0]=this['chain_'][0x0]+_0x2648ca&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5c9806&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x3cac25&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x4b36f0&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x2e3257&0xffffffff;}['update'](_0x392d4f,_0x156cb8){if(_0x392d4f==null)return;_0x156cb8===void 0x0&&(_0x156cb8=_0x392d4f['length']);const _0x1ac5e2=_0x156cb8-this['blockSize'];let _0x5664c3=0x0;const _0x54ab9b=this['buf_'];let _0x62999f=this['inbuf_'];for(;_0x5664c3<_0x156cb8;){if(_0x62999f===0x0){for(;_0x5664c3<=_0x1ac5e2;)this['compress_'](_0x392d4f,_0x5664c3),_0x5664c3+=this['blockSize'];}if(typeof _0x392d4f=='string'){for(;_0x5664c3<_0x156cb8;)if(_0x54ab9b[_0x62999f]=_0x392d4f['charCodeAt'](_0x5664c3),++_0x62999f,++_0x5664c3,_0x62999f===this['blockSize']){this['compress_'](_0x54ab9b),_0x62999f=0x0;break;}}else{for(;_0x5664c3<_0x156cb8;)if(_0x54ab9b[_0x62999f]=_0x392d4f[_0x5664c3],++_0x62999f,++_0x5664c3,_0x62999f===this['blockSize']){this['compress_'](_0x54ab9b),_0x62999f=0x0;break;}}}this['inbuf_']=_0x62999f,this['total_']+=_0x156cb8;}['digest'](){const _0x344b6f=[];let _0x1e8a6c=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x452b4e=this['blockSize']-0x1;_0x452b4e>=0x38;_0x452b4e--)this['buf_'][_0x452b4e]=_0x1e8a6c&0xff,_0x1e8a6c/=0x100;this['compress_'](this['buf_']);let _0x336823=0x0;for(let _0x2c7a32=0x0;_0x2c7a32<0x5;_0x2c7a32++)for(let _0x3c39c2=0x18;_0x3c39c2>=0x0;_0x3c39c2-=0x8)_0x344b6f[_0x336823]=this['chain_'][_0x2c7a32]>>_0x3c39c2&0xff,++_0x336823;return _0x344b6f;}}function bc(_0x25cf07,_0x29b8f0){const _0x5d3a2d=new Rc(_0x25cf07,_0x29b8f0);return _0x5d3a2d['subscribe']['bind'](_0x5d3a2d);}class Rc{constructor(_0x13cc0e,_0x4c68ed){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x4c68ed,this['task']['then'](()=>{_0x13cc0e(this);})['catch'](_0x63822d=>{this['error'](_0x63822d);});}['next'](_0x39d472){this['forEachObserver'](_0x142bef=>{_0x142bef['next'](_0x39d472);});}['error'](_0x50328a){this['forEachObserver'](_0xe7850b=>{_0xe7850b['error'](_0x50328a);}),this['close'](_0x50328a);}['complete'](){this['forEachObserver'](_0x3f1418=>{_0x3f1418['complete']();}),this['close']();}['subscribe'](_0x544b56,_0x31f964,_0x32d05e){let _0x4dcc0e;if(_0x544b56===void 0x0&&_0x31f964===void 0x0&&_0x32d05e===void 0x0)throw new Error('Missing\x20Observer.');Ac(_0x544b56,['next','error','complete'])?_0x4dcc0e=_0x544b56:_0x4dcc0e={'next':_0x544b56,'error':_0x31f964,'complete':_0x32d05e},_0x4dcc0e['next']===void 0x0&&(_0x4dcc0e['next']=ti),_0x4dcc0e['error']===void 0x0&&(_0x4dcc0e['error']=ti),_0x4dcc0e['complete']===void 0x0&&(_0x4dcc0e['complete']=ti);const _0x5d77a9=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x4dcc0e['error'](this['finalError']):_0x4dcc0e['complete']();}catch{}}),this['observers']['push'](_0x4dcc0e),_0x5d77a9;}['unsubscribeOne'](_0x246774){this['observers']===void 0x0||this['observers'][_0x246774]===void 0x0||(delete this['observers'][_0x246774],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x11bba2){if(!this['finalized']){for(let _0x367eee=0x0;_0x367eee<this['observers']['length'];_0x367eee++)this['sendOne'](_0x367eee,_0x11bba2);}}['sendOne'](_0x47db52,_0x3818d6){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x47db52]!==void 0x0)try{_0x3818d6(this['observers'][_0x47db52]);}catch(_0x316fa4){typeof console<'u'&&console['error']&&console['error'](_0x316fa4);}});}['close'](_0x3d9d18){this['finalized']||(this['finalized']=!0x0,_0x3d9d18!==void 0x0&&(this['finalError']=_0x3d9d18),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Ac(_0x9bffcb,_0x1021d5){if(typeof _0x9bffcb!='object'||_0x9bffcb===null)return!0x1;for(const _0x6295c0 of _0x1021d5)if(_0x6295c0 in _0x9bffcb&&typeof _0x9bffcb[_0x6295c0]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x44b1e3,_0x1e53f8){return _0x44b1e3+'\x20failed:\x20'+_0x1e53f8+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kc=function(_0xd1832a){const _0x13ee10=[];let _0x1e909e=0x0;for(let _0x520445=0x0;_0x520445<_0xd1832a['length'];_0x520445++){let _0x4ebe22=_0xd1832a['charCodeAt'](_0x520445);if(_0x4ebe22>=0xd800&&_0x4ebe22<=0xdbff){const _0x4cb11e=_0x4ebe22-0xd800;_0x520445++,f(_0x520445<_0xd1832a['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x52cec1=_0xd1832a['charCodeAt'](_0x520445)-0xdc00;_0x4ebe22=0x10000+(_0x4cb11e<<0xa)+_0x52cec1;}_0x4ebe22<0x80?_0x13ee10[_0x1e909e++]=_0x4ebe22:_0x4ebe22<0x800?(_0x13ee10[_0x1e909e++]=_0x4ebe22>>0x6|0xc0,_0x13ee10[_0x1e909e++]=_0x4ebe22&0x3f|0x80):_0x4ebe22<0x10000?(_0x13ee10[_0x1e909e++]=_0x4ebe22>>0xc|0xe0,_0x13ee10[_0x1e909e++]=_0x4ebe22>>0x6&0x3f|0x80,_0x13ee10[_0x1e909e++]=_0x4ebe22&0x3f|0x80):(_0x13ee10[_0x1e909e++]=_0x4ebe22>>0x12|0xf0,_0x13ee10[_0x1e909e++]=_0x4ebe22>>0xc&0x3f|0x80,_0x13ee10[_0x1e909e++]=_0x4ebe22>>0x6&0x3f|0x80,_0x13ee10[_0x1e909e++]=_0x4ebe22&0x3f|0x80);}return _0x13ee10;},xn=function(_0x125729){let _0x19255c=0x0;for(let _0x3192c5=0x0;_0x3192c5<_0x125729['length'];_0x3192c5++){const _0x29af47=_0x125729['charCodeAt'](_0x3192c5);_0x29af47<0x80?_0x19255c++:_0x29af47<0x800?_0x19255c+=0x2:_0x29af47>=0xd800&&_0x29af47<=0xdbff?(_0x19255c+=0x4,_0x3192c5++):_0x19255c+=0x3;}return _0x19255c;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x49a215){return _0x49a215&&_0x49a215['_delegate']?_0x49a215['_delegate']:_0x49a215;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x40997c){try{return(_0x40997c['startsWith']('http://')||_0x40997c['startsWith']('https://')?new URL(_0x40997c)['hostname']:_0x40997c)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function no(_0x162455){return(await fetch(_0x162455,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x398264,_0x22a8cc,_0x47b538){this['name']=_0x398264,this['instanceFactory']=_0x22a8cc,this['type']=_0x47b538,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x5dfd5c){return this['instantiationMode']=_0x5dfd5c,this;}['setMultipleInstances'](_0x39e591){return this['multipleInstances']=_0x39e591,this;}['setServiceProps'](_0x55dc9c){return this['serviceProps']=_0x55dc9c,this;}['setInstanceCreatedCallback'](_0x12b251){return this['onInstanceCreated']=_0x12b251,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x392f3d,_0x4bb264){this['name']=_0x392f3d,this['container']=_0x4bb264,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x2b1397){const _0x358077=this['normalizeInstanceIdentifier'](_0x2b1397);if(!this['instancesDeferred']['has'](_0x358077)){const _0x249220=new H();if(this['instancesDeferred']['set'](_0x358077,_0x249220),this['isInitialized'](_0x358077)||this['shouldAutoInitialize']())try{const _0x3c4aaa=this['getOrInitializeService']({'instanceIdentifier':_0x358077});_0x3c4aaa&&_0x249220['resolve'](_0x3c4aaa);}catch{}}return this['instancesDeferred']['get'](_0x358077)['promise'];}['getImmediate'](_0x5bf848){var _0xc1e80e;const _0x8ef1e2=this['normalizeInstanceIdentifier'](_0x5bf848==null?void 0x0:_0x5bf848['identifier']),_0x49463d=(_0xc1e80e=_0x5bf848==null?void 0x0:_0x5bf848['optional'])!=null?_0xc1e80e:!0x1;if(this['isInitialized'](_0x8ef1e2)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x8ef1e2});}catch(_0x2d8cb8){if(_0x49463d)return null;throw _0x2d8cb8;}else{if(_0x49463d)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x43d575){if(_0x43d575['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x43d575['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x43d575,!!this['shouldAutoInitialize']()){if(Oc(_0x43d575))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x5566d1,_0x350217]of this['instancesDeferred']['entries']()){const _0x4a9b2e=this['normalizeInstanceIdentifier'](_0x5566d1);try{const _0x82a89d=this['getOrInitializeService']({'instanceIdentifier':_0x4a9b2e});_0x350217['resolve'](_0x82a89d);}catch{}}}}['clearInstance'](_0x54aa08=Ne){this['instancesDeferred']['delete'](_0x54aa08),this['instancesOptions']['delete'](_0x54aa08),this['instances']['delete'](_0x54aa08);}async['delete'](){const _0x4229c2=Array['from'](this['instances']['values']());await Promise['all']([..._0x4229c2['filter'](_0x44c7c6=>'INTERNAL'in _0x44c7c6)['map'](_0x2d1e80=>_0x2d1e80['INTERNAL']['delete']()),..._0x4229c2['filter'](_0x35faa4=>'_delete'in _0x35faa4)['map'](_0x467c24=>_0x467c24['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x163db3=Ne){return this['instances']['has'](_0x163db3);}['getOptions'](_0x3cda4=Ne){return this['instancesOptions']['get'](_0x3cda4)||{};}['initialize'](_0x184f59={}){const {options:_0x2f4edb={}}=_0x184f59,_0xc67fb1=this['normalizeInstanceIdentifier'](_0x184f59['instanceIdentifier']);if(this['isInitialized'](_0xc67fb1))throw Error(this['name']+'('+_0xc67fb1+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0xec46fa=this['getOrInitializeService']({'instanceIdentifier':_0xc67fb1,'options':_0x2f4edb});for(const [_0x4d2a5a,_0x52d218]of this['instancesDeferred']['entries']()){const _0x580239=this['normalizeInstanceIdentifier'](_0x4d2a5a);_0xc67fb1===_0x580239&&_0x52d218['resolve'](_0xec46fa);}return _0xec46fa;}['onInit'](_0x5f1d4c,_0x4f7b35){var _0x5cf24b;const _0x3ef776=this['normalizeInstanceIdentifier'](_0x4f7b35),_0x5395d6=(_0x5cf24b=this['onInitCallbacks']['get'](_0x3ef776))!=null?_0x5cf24b:new Set();_0x5395d6['add'](_0x5f1d4c),this['onInitCallbacks']['set'](_0x3ef776,_0x5395d6);const _0x52b4c6=this['instances']['get'](_0x3ef776);return _0x52b4c6&&_0x5f1d4c(_0x52b4c6,_0x3ef776),()=>{_0x5395d6['delete'](_0x5f1d4c);};}['invokeOnInitCallbacks'](_0x3fa159,_0x7dab2d){const _0x35719f=this['onInitCallbacks']['get'](_0x7dab2d);if(_0x35719f){for(const _0x4fe42e of _0x35719f)try{_0x4fe42e(_0x3fa159,_0x7dab2d);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x36d119,options:_0x1c0efd={}}){let _0x16e0e4=this['instances']['get'](_0x36d119);if(!_0x16e0e4&&this['component']&&(_0x16e0e4=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':Pc(_0x36d119),'options':_0x1c0efd}),this['instances']['set'](_0x36d119,_0x16e0e4),this['instancesOptions']['set'](_0x36d119,_0x1c0efd),this['invokeOnInitCallbacks'](_0x16e0e4,_0x36d119),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x36d119,_0x16e0e4);}catch{}return _0x16e0e4||null;}['normalizeInstanceIdentifier'](_0x455f53=Ne){return this['component']?this['component']['multipleInstances']?_0x455f53:Ne:_0x455f53;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function Pc(_0x21a0e9){return _0x21a0e9===Ne?void 0x0:_0x21a0e9;}function Oc(_0x363954){return _0x363954['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dc{constructor(_0x41e8e8){this['name']=_0x41e8e8,this['providers']=new Map();}['addComponent'](_0x33713d){const _0x232cb0=this['getProvider'](_0x33713d['name']);if(_0x232cb0['isComponentSet']())throw new Error('Component\x20'+_0x33713d['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x232cb0['setComponent'](_0x33713d);}['addOrOverwriteComponent'](_0x57c0b5){this['getProvider'](_0x57c0b5['name'])['isComponentSet']()&&this['providers']['delete'](_0x57c0b5['name']),this['addComponent'](_0x57c0b5);}['getProvider'](_0x4dfe74){if(this['providers']['has'](_0x4dfe74))return this['providers']['get'](_0x4dfe74);const _0x39b22e=new Nc(_0x4dfe74,this);return this['providers']['set'](_0x4dfe74,_0x39b22e),_0x39b22e;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x2d13bc){_0x2d13bc[_0x2d13bc['DEBUG']=0x0]='DEBUG',_0x2d13bc[_0x2d13bc['VERBOSE']=0x1]='VERBOSE',_0x2d13bc[_0x2d13bc['INFO']=0x2]='INFO',_0x2d13bc[_0x2d13bc['WARN']=0x3]='WARN',_0x2d13bc[_0x2d13bc['ERROR']=0x4]='ERROR',_0x2d13bc[_0x2d13bc['SILENT']=0x5]='SILENT';}(T||(T={})));const Mc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Lc=T['INFO'],xc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Fc=(_0x18c9b2,_0x11b4ab,..._0x2fa855)=>{if(_0x11b4ab<_0x18c9b2['logLevel'])return;const _0x1caa09=new Date()['toISOString'](),_0x42e0a7=xc[_0x11b4ab];if(_0x42e0a7)console[_0x42e0a7]('['+_0x1caa09+']\x20\x20'+_0x18c9b2['name']+':',..._0x2fa855);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x11b4ab+')');};class Bi{constructor(_0x1d31c7){this['name']=_0x1d31c7,this['_logLevel']=Lc,this['_logHandler']=Fc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x48ebe5){if(!(_0x48ebe5 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x48ebe5+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x48ebe5;}['setLogLevel'](_0x2f2acb){this['_logLevel']=typeof _0x2f2acb=='string'?Mc[_0x2f2acb]:_0x2f2acb;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x2452ed){if(typeof _0x2452ed!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x2452ed;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x4dcca6){this['_userLogHandler']=_0x4dcca6;}['debug'](..._0x20b35a){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x20b35a),this['_logHandler'](this,T['DEBUG'],..._0x20b35a);}['log'](..._0x4716e8){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x4716e8),this['_logHandler'](this,T['VERBOSE'],..._0x4716e8);}['info'](..._0x5e5b46){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x5e5b46),this['_logHandler'](this,T['INFO'],..._0x5e5b46);}['warn'](..._0x1dbd31){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x1dbd31),this['_logHandler'](this,T['WARN'],..._0x1dbd31);}['error'](..._0x4e16bd){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x4e16bd),this['_logHandler'](this,T['ERROR'],..._0x4e16bd);}}const Uc=(_0x143ee7,_0x409555)=>_0x409555['some'](_0x355620=>_0x143ee7 instanceof _0x355620);let Us,Ws;function Wc(){return Us||(Us=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Bc(){return Ws||(Ws=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const io=new WeakMap(),_i=new WeakMap(),so=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Vc(_0x4b7b0d){const _0x19ca3f=new Promise((_0x55f680,_0x3f4265)=>{const _0x3162e6=()=>{_0x4b7b0d['removeEventListener']('success',_0x15fb16),_0x4b7b0d['removeEventListener']('error',_0x18f139);},_0x15fb16=()=>{_0x55f680(ge(_0x4b7b0d['result'])),_0x3162e6();},_0x18f139=()=>{_0x3f4265(_0x4b7b0d['error']),_0x3162e6();};_0x4b7b0d['addEventListener']('success',_0x15fb16),_0x4b7b0d['addEventListener']('error',_0x18f139);});return _0x19ca3f['then'](_0x5f0530=>{_0x5f0530 instanceof IDBCursor&&io['set'](_0x5f0530,_0x4b7b0d);})['catch'](()=>{}),Vi['set'](_0x19ca3f,_0x4b7b0d),_0x19ca3f;}function Hc(_0x331f3b){if(_i['has'](_0x331f3b))return;const _0x267eee=new Promise((_0x464369,_0x3143b9)=>{const _0x15c0b4=()=>{_0x331f3b['removeEventListener']('complete',_0xbe582a),_0x331f3b['removeEventListener']('error',_0x86ff69),_0x331f3b['removeEventListener']('abort',_0x86ff69);},_0xbe582a=()=>{_0x464369(),_0x15c0b4();},_0x86ff69=()=>{_0x3143b9(_0x331f3b['error']||new DOMException('AbortError','AbortError')),_0x15c0b4();};_0x331f3b['addEventListener']('complete',_0xbe582a),_0x331f3b['addEventListener']('error',_0x86ff69),_0x331f3b['addEventListener']('abort',_0x86ff69);});_i['set'](_0x331f3b,_0x267eee);}let gi={'get'(_0x367476,_0x360377,_0x3ec0f2){if(_0x367476 instanceof IDBTransaction){if(_0x360377==='done')return _i['get'](_0x367476);if(_0x360377==='objectStoreNames')return _0x367476['objectStoreNames']||so['get'](_0x367476);if(_0x360377==='store')return _0x3ec0f2['objectStoreNames'][0x1]?void 0x0:_0x3ec0f2['objectStore'](_0x3ec0f2['objectStoreNames'][0x0]);}return ge(_0x367476[_0x360377]);},'set'(_0x3fa727,_0x248b0f,_0xe14e12){return _0x3fa727[_0x248b0f]=_0xe14e12,!0x0;},'has'(_0x385219,_0x59f22b){return _0x385219 instanceof IDBTransaction&&(_0x59f22b==='done'||_0x59f22b==='store')?!0x0:_0x59f22b in _0x385219;}};function $c(_0x19904e){gi=_0x19904e(gi);}function Gc(_0x333344){return _0x333344===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x57124d,..._0xc7f51a){const _0x318ded=_0x333344['call'](ii(this),_0x57124d,..._0xc7f51a);return so['set'](_0x318ded,_0x57124d['sort']?_0x57124d['sort']():[_0x57124d]),ge(_0x318ded);}:Bc()['includes'](_0x333344)?function(..._0x38eed9){return _0x333344['apply'](ii(this),_0x38eed9),ge(io['get'](this));}:function(..._0x1b9674){return ge(_0x333344['apply'](ii(this),_0x1b9674));};}function qc(_0x36a8cc){return typeof _0x36a8cc=='function'?Gc(_0x36a8cc):(_0x36a8cc instanceof IDBTransaction&&Hc(_0x36a8cc),Uc(_0x36a8cc,Wc())?new Proxy(_0x36a8cc,gi):_0x36a8cc);}function ge(_0x9de0f){if(_0x9de0f instanceof IDBRequest)return Vc(_0x9de0f);if(ni['has'](_0x9de0f))return ni['get'](_0x9de0f);const _0x46349f=qc(_0x9de0f);return _0x46349f!==_0x9de0f&&(ni['set'](_0x9de0f,_0x46349f),Vi['set'](_0x46349f,_0x9de0f)),_0x46349f;}const ii=_0x4e03a2=>Vi['get'](_0x4e03a2);function zc(_0x2f0338,_0x1f94ee,{blocked:_0x2bd198,upgrade:_0x3b0df9,blocking:_0x583234,terminated:_0x25f7e0}={}){const _0x20e6ea=indexedDB['open'](_0x2f0338,_0x1f94ee),_0x2b61f4=ge(_0x20e6ea);return _0x3b0df9&&_0x20e6ea['addEventListener']('upgradeneeded',_0x21adba=>{_0x3b0df9(ge(_0x20e6ea['result']),_0x21adba['oldVersion'],_0x21adba['newVersion'],ge(_0x20e6ea['transaction']),_0x21adba);}),_0x2bd198&&_0x20e6ea['addEventListener']('blocked',_0x2fa84c=>_0x2bd198(_0x2fa84c['oldVersion'],_0x2fa84c['newVersion'],_0x2fa84c)),_0x2b61f4['then'](_0x163012=>{_0x25f7e0&&_0x163012['addEventListener']('close',()=>_0x25f7e0()),_0x583234&&_0x163012['addEventListener']('versionchange',_0x318326=>_0x583234(_0x318326['oldVersion'],_0x318326['newVersion'],_0x318326));})['catch'](()=>{}),_0x2b61f4;}const jc=['get','getKey','getAll','getAllKeys','count'],Kc=['put','add','delete','clear'],si=new Map();function Bs(_0x20362f,_0x4892bf){if(!(_0x20362f instanceof IDBDatabase&&!(_0x4892bf in _0x20362f)&&typeof _0x4892bf=='string'))return;if(si['get'](_0x4892bf))return si['get'](_0x4892bf);const _0x45bf6c=_0x4892bf['replace'](/FromIndex$/,''),_0x2634ff=_0x4892bf!==_0x45bf6c,_0x4b639e=Kc['includes'](_0x45bf6c);if(!(_0x45bf6c in(_0x2634ff?IDBIndex:IDBObjectStore)['prototype'])||!(_0x4b639e||jc['includes'](_0x45bf6c)))return;const _0x35bcb0=async function(_0x599ac2,..._0x5d2b23){const _0x321aeb=this['transaction'](_0x599ac2,_0x4b639e?'readwrite':'readonly');let _0x2cc577=_0x321aeb['store'];return _0x2634ff&&(_0x2cc577=_0x2cc577['index'](_0x5d2b23['shift']())),(await Promise['all']([_0x2cc577[_0x45bf6c](..._0x5d2b23),_0x4b639e&&_0x321aeb['done']]))[0x0];};return si['set'](_0x4892bf,_0x35bcb0),_0x35bcb0;}$c(_0x1dd27a=>({..._0x1dd27a,'get':(_0x537de4,_0x174dd1,_0x3e6bd2)=>Bs(_0x537de4,_0x174dd1)||_0x1dd27a['get'](_0x537de4,_0x174dd1,_0x3e6bd2),'has':(_0x3cdbe4,_0x21b253)=>!!Bs(_0x3cdbe4,_0x21b253)||_0x1dd27a['has'](_0x3cdbe4,_0x21b253)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yc{constructor(_0x418e37){this['container']=_0x418e37;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0xf6d9a4=>{if(Qc(_0xf6d9a4)){const _0x57681e=_0xf6d9a4['getImmediate']();return _0x57681e['library']+'/'+_0x57681e['version'];}else return null;})['filter'](_0x573208=>_0x573208)['join']('\x20');}}function Qc(_0x46285a){const _0x153176=_0x46285a['getComponent']();return(_0x153176==null?void 0x0:_0x153176['type'])==='VERSION';}const mi='@firebase/app',Vs='0.15.1',oe=new Bi('@firebase/app'),Jc='@firebase/app-compat',Xc='@firebase/analytics-compat',Zc='@firebase/analytics',el='@firebase/app-check-compat',tl='@firebase/app-check',nl='@firebase/auth',il='@firebase/auth-compat',sl='@firebase/database',rl='@firebase/data-connect',ol='@firebase/database-compat',al='@firebase/functions',cl='@firebase/functions-compat',ll='@firebase/installations',hl='@firebase/installations-compat',ul='@firebase/messaging',dl='@firebase/messaging-compat',fl='@firebase/performance',pl='@firebase/performance-compat',_l='@firebase/remote-config',gl='@firebase/remote-config-compat',ml='@firebase/storage',yl='@firebase/storage-compat',vl='@firebase/firestore',El='@firebase/ai',Il='@firebase/firestore-compat',wl='firebase',Cl='12.16.0',yi='[DEFAULT]',Tl={[mi]:'fire-core',[Jc]:'fire-core-compat',[Zc]:'fire-analytics',[Xc]:'fire-analytics-compat',[tl]:'fire-app-check',[el]:'fire-app-check-compat',[nl]:'fire-auth',[il]:'fire-auth-compat',[sl]:'fire-rtdb',[rl]:'fire-data-connect',[ol]:'fire-rtdb-compat',[al]:'fire-fn',[cl]:'fire-fn-compat',[ll]:'fire-iid',[hl]:'fire-iid-compat',[ul]:'fire-fcm',[dl]:'fire-fcm-compat',[fl]:'fire-perf',[pl]:'fire-perf-compat',[_l]:'fire-rc',[gl]:'fire-rc-compat',[ml]:'fire-gcs',[yl]:'fire-gcs-compat',[vl]:'fire-fst',[Il]:'fire-fst-compat',[El]:'fire-vertex','fire-js':'fire-js',[wl]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function Hs(_0x7fb704,_0x45398a){try{_0x7fb704['container']['addComponent'](_0x45398a);}catch(_0x5b35ad){oe['debug']('Component\x20'+_0x45398a['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x7fb704['name'],_0x5b35ad);}}function st(_0x1c5dda){const _0x32c9f5=_0x1c5dda['name'];if(Ei['has'](_0x32c9f5))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x32c9f5+'.'),!0x1;Ei['set'](_0x32c9f5,_0x1c5dda);for(const _0x382079 of Ue['values']())Hs(_0x382079,_0x1c5dda);for(const _0x3840a3 of vi['values']())Hs(_0x3840a3,_0x1c5dda);return!0x0;}function Hi(_0x1b7ef4,_0x4243f4){const _0x4d5e8d=_0x1b7ef4['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x4d5e8d&&_0x4d5e8d['triggerHeartbeat'](),_0x1b7ef4['container']['getProvider'](_0x4243f4);}function $(_0x123b4d){return _0x123b4d==null?!0x1:_0x123b4d['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Sl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bl{constructor(_0x4e0ece,_0xb5fc9b,_0x3b16f2){this['_isDeleted']=!0x1,this['_options']={..._0x4e0ece},this['_config']={..._0xb5fc9b},this['_name']=_0xb5fc9b['name'],this['_automaticDataCollectionEnabled']=_0xb5fc9b['automaticDataCollectionEnabled'],this['_container']=_0x3b16f2,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x3e711a){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x3e711a;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x3fc156){this['_isDeleted']=_0x3fc156;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Cl;function Rl(_0x181fb3,_0x5e7e99={}){let _0x3913ef=_0x181fb3;typeof _0x5e7e99!='object'&&(_0x5e7e99={'name':_0x5e7e99});const _0x2aa675={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x5e7e99},_0xcccd97=_0x2aa675['name'];if(typeof _0xcccd97!='string'||!_0xcccd97)throw me['create']('bad-app-name',{'appName':String(_0xcccd97)});if(_0x3913ef||(_0x3913ef=Xr()),!_0x3913ef)throw me['create']('no-options');const _0x4db089=Ue['get'](_0xcccd97);if(_0x4db089){if(xe(_0x3913ef,_0x4db089['options'])&&xe(_0x2aa675,_0x4db089['config']))return _0x4db089;throw me['create']('duplicate-app',{'appName':_0xcccd97});}const _0x1fe61e=new Dc(_0xcccd97);for(const _0x205b16 of Ei['values']())_0x1fe61e['addComponent'](_0x205b16);const _0x10b871=new bl(_0x3913ef,_0x2aa675,_0x1fe61e);return Ue['set'](_0xcccd97,_0x10b871),_0x10b871;}function ro(_0x100b2c=yi){const _0x10248e=Ue['get'](_0x100b2c);if(!_0x10248e&&_0x100b2c===yi&&Xr())return Rl();if(!_0x10248e)throw me['create']('no-app',{'appName':_0x100b2c});return _0x10248e;}function v_(){return Array['from'](Ue['values']());}async function E_(_0x21caf6){let _0x5d4ff5=!0x1;const _0x38ea35=_0x21caf6['name'];Ue['has'](_0x38ea35)?(_0x5d4ff5=!0x0,Ue['delete'](_0x38ea35)):vi['has'](_0x38ea35)&&_0x21caf6['decRefCount']()<=0x0&&(vi['delete'](_0x38ea35),_0x5d4ff5=!0x0),_0x5d4ff5&&(await Promise['all'](_0x21caf6['container']['getProviders']()['map'](_0x17a01c=>_0x17a01c['delete']())),_0x21caf6['isDeleted']=!0x0);}function ye(_0x204b3d,_0x3ec05f,_0x445d72){var _0x5d0ff9;let _0x1988db=(_0x5d0ff9=Tl[_0x204b3d])!=null?_0x5d0ff9:_0x204b3d;_0x445d72&&(_0x1988db+='-'+_0x445d72);const _0x3f1afd=_0x1988db['match'](/\s|\//),_0x65af2a=_0x3ec05f['match'](/\s|\//);if(_0x3f1afd||_0x65af2a){const _0x386fde=['Unable\x20to\x20register\x20library\x20\x22'+_0x1988db+'\x22\x20with\x20version\x20\x22'+_0x3ec05f+'\x22:'];_0x3f1afd&&_0x386fde['push']('library\x20name\x20\x22'+_0x1988db+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x3f1afd&&_0x65af2a&&_0x386fde['push']('and'),_0x65af2a&&_0x386fde['push']('version\x20name\x20\x22'+_0x3ec05f+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x386fde['join']('\x20'));return;}st(new Fe(_0x1988db+'-version',()=>({'library':_0x1988db,'version':_0x3ec05f}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Al='firebase-heartbeat-database',kl=0x1,Ot='firebase-heartbeat-store';let ri=null;function oo(){return ri||(ri=zc(Al,kl,{'upgrade':(_0x4f7dee,_0x2a6c67)=>{switch(_0x2a6c67){case 0x0:try{_0x4f7dee['createObjectStore'](Ot);}catch(_0x2bc046){console['warn'](_0x2bc046);}}}})['catch'](_0x3c098f=>{throw me['create']('idb-open',{'originalErrorMessage':_0x3c098f['message']});})),ri;}async function Nl(_0x57a600){try{const _0x382864=(await oo())['transaction'](Ot),_0x25a07e=await _0x382864['objectStore'](Ot)['get'](ao(_0x57a600));return await _0x382864['done'],_0x25a07e;}catch(_0x399078){if(_0x399078 instanceof be)oe['warn'](_0x399078['message']);else{const _0x115f46=me['create']('idb-get',{'originalErrorMessage':_0x399078==null?void 0x0:_0x399078['message']});oe['warn'](_0x115f46['message']);}}}async function $s(_0x2bf7ac,_0x48d492){try{const _0xbb3d45=(await oo())['transaction'](Ot,'readwrite');await _0xbb3d45['objectStore'](Ot)['put'](_0x48d492,ao(_0x2bf7ac)),await _0xbb3d45['done'];}catch(_0x288305){if(_0x288305 instanceof be)oe['warn'](_0x288305['message']);else{const _0x2466a1=me['create']('idb-set',{'originalErrorMessage':_0x288305==null?void 0x0:_0x288305['message']});oe['warn'](_0x2466a1['message']);}}}function ao(_0x48d9d4){return _0x48d9d4['name']+'!'+_0x48d9d4['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Pl=0x400,Ol=0x1e;class Dl{constructor(_0x540e5d){this['container']=_0x540e5d,this['_heartbeatsCache']=null;const _0xd57613=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Ll(_0xd57613),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x15710e=>(this['_heartbeatsCache']=_0x15710e,_0x15710e));}async['triggerHeartbeat'](){var _0x38000c,_0x37a9be;try{const _0x4b8d3d=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x1afff9=Gs();if(((_0x38000c=this['_heartbeatsCache'])==null?void 0x0:_0x38000c['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x37a9be=this['_heartbeatsCache'])==null?void 0x0:_0x37a9be['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x1afff9||this['_heartbeatsCache']['heartbeats']['some'](_0x3797ab=>_0x3797ab['date']===_0x1afff9))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x1afff9,'agent':_0x4b8d3d}),this['_heartbeatsCache']['heartbeats']['length']>Ol){const _0x118047=xl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x118047,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x24f93d){oe['warn'](_0x24f93d);}}async['getHeartbeatsHeader'](){var _0x38e7b5;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x38e7b5=this['_heartbeatsCache'])==null?void 0x0:_0x38e7b5['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x4bf54c=Gs(),{heartbeatsToSend:_0x15dca7,unsentEntries:_0x2feeb5}=Ml(this['_heartbeatsCache']['heartbeats']),_0x5ddd54=fn(JSON['stringify']({'version':0x2,'heartbeats':_0x15dca7}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x4bf54c,_0x2feeb5['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x2feeb5,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x5ddd54;}catch(_0x501b73){return oe['warn'](_0x501b73),'';}}}function Gs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ml(_0x4f5c38,_0xa14deb=Pl){const _0x2a2019=[];let _0x38e624=_0x4f5c38['slice']();for(const _0x41586a of _0x4f5c38){const _0x5314a9=_0x2a2019['find'](_0x48068=>_0x48068['agent']===_0x41586a['agent']);if(_0x5314a9){if(_0x5314a9['dates']['push'](_0x41586a['date']),qs(_0x2a2019)>_0xa14deb){_0x5314a9['dates']['pop']();break;}}else{if(_0x2a2019['push']({'agent':_0x41586a['agent'],'dates':[_0x41586a['date']]}),qs(_0x2a2019)>_0xa14deb){_0x2a2019['pop']();break;}}_0x38e624=_0x38e624['slice'](0x1);}return{'heartbeatsToSend':_0x2a2019,'unsentEntries':_0x38e624};}class Ll{constructor(_0x41886f){this['app']=_0x41886f,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return yc()?vc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x23c4ae=await Nl(this['app']);return _0x23c4ae!=null&&_0x23c4ae['heartbeats']?_0x23c4ae:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x33539e){var _0x676a98;if(await this['_canUseIndexedDBPromise']){const _0xc944f2=await this['read']();return $s(this['app'],{'lastSentHeartbeatDate':(_0x676a98=_0x33539e['lastSentHeartbeatDate'])!=null?_0x676a98:_0xc944f2['lastSentHeartbeatDate'],'heartbeats':_0x33539e['heartbeats']});}else return;}async['add'](_0x2fed75){var _0x397796;if(await this['_canUseIndexedDBPromise']){const _0x25fb80=await this['read']();return $s(this['app'],{'lastSentHeartbeatDate':(_0x397796=_0x2fed75['lastSentHeartbeatDate'])!=null?_0x397796:_0x25fb80['lastSentHeartbeatDate'],'heartbeats':[..._0x25fb80['heartbeats'],..._0x2fed75['heartbeats']]});}else return;}}function qs(_0x328081){return fn(JSON['stringify']({'version':0x2,'heartbeats':_0x328081}))['length'];}function xl(_0x4f31a6){if(_0x4f31a6['length']===0x0)return-0x1;let _0x1626d1=0x0,_0x736169=_0x4f31a6[0x0]['date'];for(let _0xb594d0=0x1;_0xb594d0<_0x4f31a6['length'];_0xb594d0++)_0x4f31a6[_0xb594d0]['date']<_0x736169&&(_0x736169=_0x4f31a6[_0xb594d0]['date'],_0x1626d1=_0xb594d0);return _0x1626d1;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Fl(_0xc0a7f8){st(new Fe('platform-logger',_0x292c0=>new Yc(_0x292c0),'PRIVATE')),st(new Fe('heartbeat',_0x483cc7=>new Dl(_0x483cc7),'PRIVATE')),ye(mi,Vs,_0xc0a7f8),ye(mi,Vs,'esm2020'),ye('fire-js','');}Fl('');var Ul='firebase',Wl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(Ul,Wl,'app');var zs={};const js='@firebase/database',Ks='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let co='';function Bl(_0x226a2e){co=_0x226a2e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vl{constructor(_0x221584){this['domStorage_']=_0x221584,this['prefix_']='firebase:';}['set'](_0x3117a9,_0xcffce2){_0xcffce2==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x3117a9)):this['domStorage_']['setItem'](this['prefixedName_'](_0x3117a9),O(_0xcffce2));}['get'](_0x2ee863){const _0x276749=this['domStorage_']['getItem'](this['prefixedName_'](_0x2ee863));return _0x276749==null?null:Pt(_0x276749);}['remove'](_0xf6b9c3){this['domStorage_']['removeItem'](this['prefixedName_'](_0xf6b9c3));}['prefixedName_'](_0x17a529){return this['prefix_']+_0x17a529;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x20f2a8,_0x1fe28b){_0x1fe28b==null?delete this['cache_'][_0x20f2a8]:this['cache_'][_0x20f2a8]=_0x1fe28b;}['get'](_0x5b2de5){return Q(this['cache_'],_0x5b2de5)?this['cache_'][_0x5b2de5]:null;}['remove'](_0x327749){delete this['cache_'][_0x327749];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lo=function(_0x132baa){try{if(typeof window<'u'&&typeof window[_0x132baa]<'u'){const _0xa0f483=window[_0x132baa];return _0xa0f483['setItem']('firebase:sentinel','cache'),_0xa0f483['removeItem']('firebase:sentinel'),new Vl(_0xa0f483);}}catch{}return new Hl();},Oe=lo('localStorage'),$l=lo('sessionStorage'),Ze=new Bi('@firebase/database'),ho=(function(){let _0xd11e68=0x1;return function(){return _0xd11e68++;};}()),uo=function(_0xadab68){const _0x5d1e99=kc(_0xadab68),_0x1fa23e=new Sc();_0x1fa23e['update'](_0x5d1e99);const _0x1633c6=_0x1fa23e['digest']();return Fi['encodeByteArray'](_0x1633c6);},zt=function(..._0xaec311){let _0x2842b0='';for(let _0x3370a6=0x0;_0x3370a6<_0xaec311['length'];_0x3370a6++){const _0x26a726=_0xaec311[_0x3370a6];Array['isArray'](_0x26a726)||_0x26a726&&typeof _0x26a726=='object'&&typeof _0x26a726['length']=='number'?_0x2842b0+=zt['apply'](null,_0x26a726):typeof _0x26a726=='object'?_0x2842b0+=O(_0x26a726):_0x2842b0+=_0x26a726,_0x2842b0+='\x20';}return _0x2842b0;};let St=null,Ys=!0x0;const Gl=function(_0x560010,_0xb7ca67){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x43f409){if(Ys===!0x0&&(Ys=!0x1,St===null&&$l['get']('logging_enabled')===!0x0&&Gl()),St){const _0x475179=zt['apply'](null,_0x43f409);St(_0x475179);}},jt=function(_0x3d217f){return function(..._0x2d7df8){L(_0x3d217f,..._0x2d7df8);};},Ii=function(..._0x36f077){const _0x5bbcbe='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x36f077);Ze['error'](_0x5bbcbe);},ae=function(..._0x430072){const _0x2084da='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x430072);throw Ze['error'](_0x2084da),new Error(_0x2084da);},U=function(..._0x32f630){const _0x5740d6='FIREBASE\x20WARNING:\x20'+zt(..._0x32f630);Ze['warn'](_0x5740d6);},ql=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Fn=function(_0x2f2384){return typeof _0x2f2384=='number'&&(_0x2f2384!==_0x2f2384||_0x2f2384===Number['POSITIVE_INFINITY']||_0x2f2384===Number['NEGATIVE_INFINITY']);},zl=function(_0x5c64f6){if(document['readyState']==='complete')_0x5c64f6();else{let _0x24cff6=!0x1;const _0x8f7115=function(){if(!document['body']){setTimeout(_0x8f7115,Math['floor'](0xa));return;}_0x24cff6||(_0x24cff6=!0x0,_0x5c64f6());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x8f7115,!0x1),window['addEventListener']('load',_0x8f7115,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x8f7115();}),window['attachEvent']('onload',_0x8f7115));}},We='[MIN_NAME]',Ie='[MAX_NAME]',qe=function(_0x2b5d03,_0x1f6b99){if(_0x2b5d03===_0x1f6b99)return 0x0;if(_0x2b5d03===We||_0x1f6b99===Ie)return-0x1;if(_0x1f6b99===We||_0x2b5d03===Ie)return 0x1;{const _0x1d9875=Qs(_0x2b5d03),_0x27b21c=Qs(_0x1f6b99);return _0x1d9875!==null?_0x27b21c!==null?_0x1d9875-_0x27b21c===0x0?_0x2b5d03['length']-_0x1f6b99['length']:_0x1d9875-_0x27b21c:-0x1:_0x27b21c!==null?0x1:_0x2b5d03<_0x1f6b99?-0x1:0x1;}},jl=function(_0x2757d0,_0x377fcf){return _0x2757d0===_0x377fcf?0x0:_0x2757d0<_0x377fcf?-0x1:0x1;},vt=function(_0x426d3f,_0x4643bd){if(_0x4643bd&&_0x426d3f in _0x4643bd)return _0x4643bd[_0x426d3f];throw new Error('Missing\x20required\x20key\x20('+_0x426d3f+')\x20in\x20object:\x20'+O(_0x4643bd));},$i=function(_0x30a8c2){if(typeof _0x30a8c2!='object'||_0x30a8c2===null)return O(_0x30a8c2);const _0x2d5319=[];for(const _0x328279 in _0x30a8c2)_0x2d5319['push'](_0x328279);_0x2d5319['sort']();let _0x2826dc='{';for(let _0x3e6baf=0x0;_0x3e6baf<_0x2d5319['length'];_0x3e6baf++)_0x3e6baf!==0x0&&(_0x2826dc+=','),_0x2826dc+=O(_0x2d5319[_0x3e6baf]),_0x2826dc+=':',_0x2826dc+=$i(_0x30a8c2[_0x2d5319[_0x3e6baf]]);return _0x2826dc+='}',_0x2826dc;},fo=function(_0x194ab4,_0x5e77f2){const _0x20012e=_0x194ab4['length'];if(_0x20012e<=_0x5e77f2)return[_0x194ab4];const _0x4d2326=[];for(let _0x31236b=0x0;_0x31236b<_0x20012e;_0x31236b+=_0x5e77f2)_0x31236b+_0x5e77f2>_0x20012e?_0x4d2326['push'](_0x194ab4['substring'](_0x31236b,_0x20012e)):_0x4d2326['push'](_0x194ab4['substring'](_0x31236b,_0x31236b+_0x5e77f2));return _0x4d2326;};function x(_0x32f4ad,_0x465a9e){for(const _0x3cc3f5 in _0x32f4ad)_0x32f4ad['hasOwnProperty'](_0x3cc3f5)&&_0x465a9e(_0x3cc3f5,_0x32f4ad[_0x3cc3f5]);}const po=function(_0x34aa35){f(!Fn(_0x34aa35),'Invalid\x20JSON\x20number');const _0x2a7432=0xb,_0x1d2bf4=0x34,_0x340ee1=(0x1<<_0x2a7432-0x1)-0x1;let _0x12a88e,_0x577f8b,_0x59e976,_0x276712,_0x2bd0a3;_0x34aa35===0x0?(_0x577f8b=0x0,_0x59e976=0x0,_0x12a88e=0x1/_0x34aa35===-0x1/0x0?0x1:0x0):(_0x12a88e=_0x34aa35<0x0,_0x34aa35=Math['abs'](_0x34aa35),_0x34aa35>=Math['pow'](0x2,0x1-_0x340ee1)?(_0x276712=Math['min'](Math['floor'](Math['log'](_0x34aa35)/Math['LN2']),_0x340ee1),_0x577f8b=_0x276712+_0x340ee1,_0x59e976=Math['round'](_0x34aa35*Math['pow'](0x2,_0x1d2bf4-_0x276712)-Math['pow'](0x2,_0x1d2bf4))):(_0x577f8b=0x0,_0x59e976=Math['round'](_0x34aa35/Math['pow'](0x2,0x1-_0x340ee1-_0x1d2bf4))));const _0x1cfaff=[];for(_0x2bd0a3=_0x1d2bf4;_0x2bd0a3;_0x2bd0a3-=0x1)_0x1cfaff['push'](_0x59e976%0x2?0x1:0x0),_0x59e976=Math['floor'](_0x59e976/0x2);for(_0x2bd0a3=_0x2a7432;_0x2bd0a3;_0x2bd0a3-=0x1)_0x1cfaff['push'](_0x577f8b%0x2?0x1:0x0),_0x577f8b=Math['floor'](_0x577f8b/0x2);_0x1cfaff['push'](_0x12a88e?0x1:0x0),_0x1cfaff['reverse']();const _0x4be9bc=_0x1cfaff['join']('');let _0xb84502='';for(_0x2bd0a3=0x0;_0x2bd0a3<0x40;_0x2bd0a3+=0x8){let _0x17a074=parseInt(_0x4be9bc['substr'](_0x2bd0a3,0x8),0x2)['toString'](0x10);_0x17a074['length']===0x1&&(_0x17a074='0'+_0x17a074),_0xb84502=_0xb84502+_0x17a074;}return _0xb84502['toLowerCase']();},Kl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Yl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Ql(_0x2ded6f,_0x4c9306){let _0x368cf7='Unknown\x20Error';_0x2ded6f==='too_big'?_0x368cf7='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x2ded6f==='permission_denied'?_0x368cf7='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x2ded6f==='unavailable'&&(_0x368cf7='The\x20service\x20is\x20unavailable');const _0x4fd4e8=new Error(_0x2ded6f+'\x20at\x20'+_0x4c9306['_path']['toString']()+':\x20'+_0x368cf7);return _0x4fd4e8['code']=_0x2ded6f['toUpperCase'](),_0x4fd4e8;}const Jl=new RegExp('^-?(0*)\x5cd{1,10}$'),Xl=-0x80000000,Zl=0x7fffffff,Qs=function(_0x5eb5ce){if(Jl['test'](_0x5eb5ce)){const _0x5da135=Number(_0x5eb5ce);if(_0x5da135>=Xl&&_0x5da135<=Zl)return _0x5da135;}return null;},ft=function(_0x5ae43f){try{_0x5ae43f();}catch(_0x2e3620){setTimeout(()=>{const _0xd8751a=_0x2e3620['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0xd8751a),_0x2e3620;},Math['floor'](0x0));}},eh=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x5e50e3,_0x52cc1e){const _0x2fbb7c=setTimeout(_0x5e50e3,_0x52cc1e);return typeof _0x2fbb7c=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x2fbb7c):typeof _0x2fbb7c=='object'&&_0x2fbb7c['unref']&&_0x2fbb7c['unref'](),_0x2fbb7c;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x157203,_0x490fab){this['appCheckProvider']=_0x490fab,this['appName']=_0x157203['name'],$(_0x157203)&&_0x157203['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x157203['settings']['appCheckToken']),this['appCheck']=_0x490fab==null?void 0x0:_0x490fab['getImmediate']({'optional':!0x0}),this['appCheck']||_0x490fab==null||_0x490fab['get']()['then'](_0x58fdef=>this['appCheck']=_0x58fdef);}['getToken'](_0x205076){if(this['serverAppAppCheckToken']){if(_0x205076)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x205076):new Promise((_0x5f5ad4,_0x5c2e9a)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x205076)['then'](_0x5f5ad4,_0x5c2e9a):_0x5f5ad4(null);},0x0);});}['addTokenChangeListener'](_0x11b943){var _0x14f3bb;(_0x14f3bb=this['appCheckProvider'])==null||_0x14f3bb['get']()['then'](_0x31399e=>_0x31399e['addTokenListener'](_0x11b943));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(_0xb7dfee,_0x2c9cc9,_0x109d54){this['appName_']=_0xb7dfee,this['firebaseOptions_']=_0x2c9cc9,this['authProvider_']=_0x109d54,this['auth_']=null,this['auth_']=_0x109d54['getImmediate']({'optional':!0x0}),this['auth_']||_0x109d54['onInit'](_0x39ec65=>this['auth_']=_0x39ec65);}['getToken'](_0x3978e4){return this['auth_']?this['auth_']['getToken'](_0x3978e4)['catch'](_0x12e5ef=>_0x12e5ef&&_0x12e5ef['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x12e5ef)):new Promise((_0x4bb08e,_0x74637e)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x3978e4)['then'](_0x4bb08e,_0x74637e):_0x4bb08e(null);},0x0);});}['addTokenChangeListener'](_0x25ea98){this['auth_']?this['auth_']['addAuthTokenListener'](_0x25ea98):this['authProvider_']['get']()['then'](_0x3e79be=>_0x3e79be['addAuthTokenListener'](_0x25ea98));}['removeTokenChangeListener'](_0xa0ed6b){this['authProvider_']['get']()['then'](_0x43eec4=>_0x43eec4['removeAuthTokenListener'](_0xa0ed6b));}['notifyForInvalidToken'](){let _0x11cfcb='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x11cfcb+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x11cfcb+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x11cfcb+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x11cfcb);}}class cn{constructor(_0x247b3e){this['accessToken']=_0x247b3e;}['getToken'](_0x5ec60a){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x549f62){_0x549f62(this['accessToken']);}['removeTokenChangeListener'](_0x4a472e){}['notifyForInvalidToken'](){}}cn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',_o='v',go='s',mo='r',yo='f',vo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,Eo='ls',Io='p',wi='ac',wo='websocket',Co='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class To{constructor(_0x52d63f,_0x245e83,_0x2265ad,_0x15f10a,_0x5d8f76=!0x1,_0x5b47a7='',_0x32a24c=!0x1,_0x45715a=!0x1,_0x5e6889=null){this['secure']=_0x245e83,this['namespace']=_0x2265ad,this['webSocketOnly']=_0x15f10a,this['nodeAdmin']=_0x5d8f76,this['persistenceKey']=_0x5b47a7,this['includeNamespaceInQueryParams']=_0x32a24c,this['isUsingEmulator']=_0x45715a,this['emulatorOptions']=_0x5e6889,this['_host']=_0x52d63f['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x52d63f)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x1e808f){_0x1e808f!==this['internalHost']&&(this['internalHost']=_0x1e808f,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x11a2ad=this['toURLString']();return this['persistenceKey']&&(_0x11a2ad+='<'+this['persistenceKey']+'>'),_0x11a2ad;}['toURLString'](){const _0x4e0846=this['secure']?'https://':'http://',_0x49c015=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x4e0846+this['host']+'/'+_0x49c015;}}function ih(_0x414b32){return _0x414b32['host']!==_0x414b32['internalHost']||_0x414b32['isCustomHost']()||_0x414b32['includeNamespaceInQueryParams'];}function So(_0x5720c1,_0x14b606,_0x5871f4){f(typeof _0x14b606=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x5871f4=='object','typeof\x20params\x20must\x20==\x20object');let _0x22a63f;if(_0x14b606===wo)_0x22a63f=(_0x5720c1['secure']?'wss://':'ws://')+_0x5720c1['internalHost']+'/.ws?';else{if(_0x14b606===Co)_0x22a63f=(_0x5720c1['secure']?'https://':'http://')+_0x5720c1['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x14b606);}ih(_0x5720c1)&&(_0x5871f4['ns']=_0x5720c1['namespace']);const _0x53ae1b=[];return x(_0x5871f4,(_0x550d00,_0x5d6c16)=>{_0x53ae1b['push'](_0x550d00+'='+_0x5d6c16);}),_0x22a63f+_0x53ae1b['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(){this['counters_']={};}['incrementCounter'](_0x4b4863,_0x149bf7=0x1){Q(this['counters_'],_0x4b4863)||(this['counters_'][_0x4b4863]=0x0),this['counters_'][_0x4b4863]+=_0x149bf7;}['get'](){return oc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x597fe8){const _0x21383b=_0x597fe8['toString']();return oi[_0x21383b]||(oi[_0x21383b]=new sh()),oi[_0x21383b];}function rh(_0x17edb1,_0x1265bb){const _0x53e1c0=_0x17edb1['toString']();return ai[_0x53e1c0]||(ai[_0x53e1c0]=_0x1265bb()),ai[_0x53e1c0];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class oh{constructor(_0xf40912){this['onMessage_']=_0xf40912,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x5ec6f5,_0x3b3ea9){this['closeAfterResponse']=_0x5ec6f5,this['onClose']=_0x3b3ea9,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x32b8b0,_0x5f8781){for(this['pendingResponses'][_0x32b8b0]=_0x5f8781;this['pendingResponses'][this['currentResponseNum']];){const _0x36c62a=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x5ecad5=0x0;_0x5ecad5<_0x36c62a['length'];++_0x5ecad5)_0x36c62a[_0x5ecad5]&&ft(()=>{this['onMessage_'](_0x36c62a[_0x5ecad5]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Js='start',ah='close',ch='pLPCommand',lh='pRTLPCB',bo='id',Ro='pw',Ao='ser',hh='cb',uh='seg',dh='ts',fh='d',ph='dframe',ko=0x74e,No=0x1e,_h=ko-No,gh=0x61a8,mh=0x7530;class Je{constructor(_0x408c36,_0x3e986a,_0x374083,_0x2c5ee0,_0x2c0541,_0x507058,_0x59de7a){this['connId']=_0x408c36,this['repoInfo']=_0x3e986a,this['applicationId']=_0x374083,this['appCheckToken']=_0x2c5ee0,this['authToken']=_0x2c0541,this['transportSessionId']=_0x507058,this['lastSessionId']=_0x59de7a,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x408c36),this['stats_']=qi(_0x3e986a),this['urlFn']=_0x34a1c6=>(this['appCheckToken']&&(_0x34a1c6[wi]=this['appCheckToken']),So(_0x3e986a,Co,_0x34a1c6));}['open'](_0x1ca4cf,_0x207c42){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x207c42,this['myPacketOrderer']=new oh(_0x1ca4cf),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](mh)),zl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0xdf6543)=>{const [_0x174c40,_0x5c833c,_0x3aeb47,_0x5ae5e3,_0x5c9dac]=_0xdf6543;if(this['incrementIncomingBytes_'](_0xdf6543),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x174c40===Js)this['id']=_0x5c833c,this['password']=_0x3aeb47;else{if(_0x174c40===ah)_0x5c833c?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x5c833c,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x174c40);}}},(..._0x1d596e)=>{const [_0x3d4b09,_0x13a31a]=_0x1d596e;this['incrementIncomingBytes_'](_0x1d596e),this['myPacketOrderer']['handleResponse'](_0x3d4b09,_0x13a31a);},()=>{this['onClosed_']();},this['urlFn']);const _0x1cdc14={};_0x1cdc14[Js]='t',_0x1cdc14[Ao]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x1cdc14[hh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x1cdc14[_o]=Gi,this['transportSessionId']&&(_0x1cdc14[go]=this['transportSessionId']),this['lastSessionId']&&(_0x1cdc14[Eo]=this['lastSessionId']),this['applicationId']&&(_0x1cdc14[Io]=this['applicationId']),this['appCheckToken']&&(_0x1cdc14[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&vo['test'](location['hostname'])&&(_0x1cdc14[mo]=yo);const _0x120b76=this['urlFn'](_0x1cdc14);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x120b76),this['scriptTagHolder']['addTag'](_0x120b76,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!Kl()&&!Yl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0xcd55){const _0x43655a=O(_0xcd55);this['bytesSent']+=_0x43655a['length'],this['stats_']['incrementCounter']('bytes_sent',_0x43655a['length']);const _0x114656=Yr(_0x43655a),_0x366e01=fo(_0x114656,_h);for(let _0x1f8acc=0x0;_0x1f8acc<_0x366e01['length'];_0x1f8acc++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x366e01['length'],_0x366e01[_0x1f8acc]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x33dc5b,_0x45dbe6){this['myDisconnFrame']=document['createElement']('iframe');const _0x3448de={};_0x3448de[ph]='t',_0x3448de[bo]=_0x33dc5b,_0x3448de[Ro]=_0x45dbe6,this['myDisconnFrame']['src']=this['urlFn'](_0x3448de),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x2461d0){const _0x17af98=O(_0x2461d0)['length'];this['bytesReceived']+=_0x17af98,this['stats_']['incrementCounter']('bytes_received',_0x17af98);}}class zi{constructor(_0x2e7495,_0x214e43,_0x2112bc,_0x5b9da9){this['onDisconnect']=_0x2112bc,this['urlFn']=_0x5b9da9,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=ho(),window[ch+this['uniqueCallbackIdentifier']]=_0x2e7495,window[lh+this['uniqueCallbackIdentifier']]=_0x214e43,this['myIFrame']=zi['createIFrame_']();let _0xfd4f75='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0xfd4f75='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x148e67='<html><body>'+_0xfd4f75+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x148e67),this['myIFrame']['doc']['close']();}catch(_0x1bda40){L('frame\x20writing\x20exception'),_0x1bda40['stack']&&L(_0x1bda40['stack']),L(_0x1bda40);}}}static['createIFrame_'](){const _0x88712c=document['createElement']('iframe');if(_0x88712c['style']['display']='none',document['body']){document['body']['appendChild'](_0x88712c);try{_0x88712c['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x1b96b1=document['domain'];_0x88712c['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x1b96b1+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x88712c['contentDocument']?_0x88712c['doc']=_0x88712c['contentDocument']:_0x88712c['contentWindow']?_0x88712c['doc']=_0x88712c['contentWindow']['document']:_0x88712c['document']&&(_0x88712c['doc']=_0x88712c['document']),_0x88712c;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x58f900=this['onDisconnect'];_0x58f900&&(this['onDisconnect']=null,_0x58f900());}['startLongPoll'](_0x16f44a,_0x3a068e){for(this['myID']=_0x16f44a,this['myPW']=_0x3a068e,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x2dc5a4={};_0x2dc5a4[bo]=this['myID'],_0x2dc5a4[Ro]=this['myPW'],_0x2dc5a4[Ao]=this['currentSerial'];let _0x2a1716=this['urlFn'](_0x2dc5a4),_0x4e352b='',_0x1a64bd=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+No+_0x4e352b['length']<=ko;){const _0x39bd15=this['pendingSegs']['shift']();_0x4e352b=_0x4e352b+'&'+uh+_0x1a64bd+'='+_0x39bd15['seg']+'&'+dh+_0x1a64bd+'='+_0x39bd15['ts']+'&'+fh+_0x1a64bd+'='+_0x39bd15['d'],_0x1a64bd++;}return _0x2a1716=_0x2a1716+_0x4e352b,this['addLongPollTag_'](_0x2a1716,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x4b3001,_0x1add92,_0x3a61a4){this['pendingSegs']['push']({'seg':_0x4b3001,'ts':_0x1add92,'d':_0x3a61a4}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x430f51,_0x171ec8){this['outstandingRequests']['add'](_0x171ec8);const _0x17d183=()=>{this['outstandingRequests']['delete'](_0x171ec8),this['newRequest_']();},_0x409851=setTimeout(_0x17d183,Math['floor'](gh)),_0xba85c2=()=>{clearTimeout(_0x409851),_0x17d183();};this['addTag'](_0x430f51,_0xba85c2);}['addTag'](_0x63f0d,_0x929648){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x45ccd5=this['myIFrame']['doc']['createElement']('script');_0x45ccd5['type']='text/javascript',_0x45ccd5['async']=!0x0,_0x45ccd5['src']=_0x63f0d,_0x45ccd5['onload']=_0x45ccd5['onreadystatechange']=function(){const _0x4afca1=_0x45ccd5['readyState'];(!_0x4afca1||_0x4afca1==='loaded'||_0x4afca1==='complete')&&(_0x45ccd5['onload']=_0x45ccd5['onreadystatechange']=null,_0x45ccd5['parentNode']&&_0x45ccd5['parentNode']['removeChild'](_0x45ccd5),_0x929648());},_0x45ccd5['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x63f0d),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x45ccd5);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0x4000,vh=0xafc8;let mn=null;typeof MozWebSocket<'u'?mn=MozWebSocket:typeof WebSocket<'u'&&(mn=WebSocket);class q{constructor(_0x4c9454,_0x42f7c9,_0x3ebeaf,_0x421149,_0x20f648,_0x1cbf6c,_0x88e9e6){this['connId']=_0x4c9454,this['applicationId']=_0x3ebeaf,this['appCheckToken']=_0x421149,this['authToken']=_0x20f648,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x42f7c9),this['connURL']=q['connectionURL_'](_0x42f7c9,_0x1cbf6c,_0x88e9e6,_0x421149,_0x3ebeaf),this['nodeAdmin']=_0x42f7c9['nodeAdmin'];}static['connectionURL_'](_0x3211cc,_0x5cca9b,_0x3a54e4,_0x342cc0,_0x3a6908){const _0x3bdbf1={};return _0x3bdbf1[_o]=Gi,typeof location<'u'&&location['hostname']&&vo['test'](location['hostname'])&&(_0x3bdbf1[mo]=yo),_0x5cca9b&&(_0x3bdbf1[go]=_0x5cca9b),_0x3a54e4&&(_0x3bdbf1[Eo]=_0x3a54e4),_0x342cc0&&(_0x3bdbf1[wi]=_0x342cc0),_0x3a6908&&(_0x3bdbf1[Io]=_0x3a6908),So(_0x3211cc,wo,_0x3bdbf1);}['open'](_0x926f82,_0x9a33b){this['onDisconnect']=_0x9a33b,this['onMessage']=_0x926f82,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x48145d;mc(),this['mySock']=new mn(this['connURL'],[],_0x48145d);}catch(_0x901db7){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x56f157=_0x901db7['message']||_0x901db7['data'];_0x56f157&&this['log_'](_0x56f157),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x20d035=>{this['handleIncomingFrame'](_0x20d035);},this['mySock']['onerror']=_0x342440=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x2a4cc6=_0x342440['message']||_0x342440['data'];_0x2a4cc6&&this['log_'](_0x2a4cc6),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x36d936=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x2b120e=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x4c562f=navigator['userAgent']['match'](_0x2b120e);_0x4c562f&&_0x4c562f['length']>0x1&&parseFloat(_0x4c562f[0x1])<4.4&&(_0x36d936=!0x0);}return!_0x36d936&&mn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x596001){if(this['frames']['push'](_0x596001),this['frames']['length']===this['totalFrames']){const _0x292f2d=this['frames']['join']('');this['frames']=null;const _0x410e04=Pt(_0x292f2d);this['onMessage'](_0x410e04);}}['handleNewFrameCount_'](_0xc147c8){this['totalFrames']=_0xc147c8,this['frames']=[];}['extractFrameCount_'](_0x2ff235){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x2ff235['length']<=0x6){const _0x1e2137=Number(_0x2ff235);if(!isNaN(_0x1e2137))return this['handleNewFrameCount_'](_0x1e2137),null;}return this['handleNewFrameCount_'](0x1),_0x2ff235;}['handleIncomingFrame'](_0x29a7ce){if(this['mySock']===null)return;const _0x2d8e70=_0x29a7ce['data'];if(this['bytesReceived']+=_0x2d8e70['length'],this['stats_']['incrementCounter']('bytes_received',_0x2d8e70['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x2d8e70);else{const _0x11cd1d=this['extractFrameCount_'](_0x2d8e70);_0x11cd1d!==null&&this['appendFrame_'](_0x11cd1d);}}['send'](_0x24fbee){this['resetKeepAlive']();const _0x41cccf=O(_0x24fbee);this['bytesSent']+=_0x41cccf['length'],this['stats_']['incrementCounter']('bytes_sent',_0x41cccf['length']);const _0xfc3922=fo(_0x41cccf,yh);_0xfc3922['length']>0x1&&this['sendString_'](String(_0xfc3922['length']));for(let _0x2dd6b9=0x0;_0x2dd6b9<_0xfc3922['length'];_0x2dd6b9++)this['sendString_'](_0xfc3922[_0x2dd6b9]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](vh));}['sendString_'](_0x325848){try{this['mySock']['send'](_0x325848);}catch(_0x12b3cf){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x12b3cf['message']||_0x12b3cf['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5c9038){this['initTransports_'](_0x5c9038);}['initTransports_'](_0x514620){const _0x11121d=q&&q['isAvailable']();let _0x2015f5=_0x11121d&&!q['previouslyFailed']();if(_0x514620['webSocketOnly']&&(_0x11121d||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x2015f5=!0x0),_0x2015f5)this['transports_']=[q];else{const _0x5e564f=this['transports_']=[];for(const _0x59404e of Dt['ALL_TRANSPORTS'])_0x59404e&&_0x59404e['isAvailable']()&&_0x5e564f['push'](_0x59404e);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Eh=0xea60,Ih=0x1388,wh=0xa*0x400,Ch=0x64*0x400,ci='t',Xs='d',Th='s',Zs='r',Sh='e',er='o',tr='a',nr='n',ir='p',bh='h';class Rh{constructor(_0x192094,_0x318d85,_0x17bcca,_0x4b1c6b,_0x29fea8,_0x4f5a54,_0x22630f,_0x16e09d,_0x443c65,_0x1c5f3f){this['id']=_0x192094,this['repoInfo_']=_0x318d85,this['applicationId_']=_0x17bcca,this['appCheckToken_']=_0x4b1c6b,this['authToken_']=_0x29fea8,this['onMessage_']=_0x4f5a54,this['onReady_']=_0x22630f,this['onDisconnect_']=_0x16e09d,this['onKill_']=_0x443c65,this['lastSessionId']=_0x1c5f3f,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x318d85),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x45d108=this['transportManager_']['initialTransport']();this['conn_']=new _0x45d108(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x45d108['responsesRequiredToBeHealthy']||0x0;const _0x51ab1d=this['connReceiver_'](this['conn_']),_0x18609f=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x51ab1d,_0x18609f);},Math['floor'](0x0));const _0xce83c4=_0x45d108['healthyTimeout']||0x0;_0xce83c4>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ch?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>wh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0xce83c4)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x4755d6){return _0x372e5a=>{_0x4755d6===this['conn_']?this['onConnectionLost_'](_0x372e5a):_0x4755d6===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x342d3d){return _0x34c371=>{this['state_']!==0x2&&(_0x342d3d===this['rx_']?this['onPrimaryMessageReceived_'](_0x34c371):_0x342d3d===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x34c371):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x513e12){const _0x34509a={'t':'d','d':_0x513e12};this['sendData_'](_0x34509a);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x4c8b20){if(ci in _0x4c8b20){const _0x21b241=_0x4c8b20[ci];_0x21b241===tr?this['upgradeIfSecondaryHealthy_']():_0x21b241===Zs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x21b241===er&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x4ebc02){const _0x3db30c=vt('t',_0x4ebc02),_0x5c12a0=vt('d',_0x4ebc02);if(_0x3db30c==='c')this['onSecondaryControl_'](_0x5c12a0);else{if(_0x3db30c==='d')this['pendingDataMessages']['push'](_0x5c12a0);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x3db30c);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':ir,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':tr,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':nr,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x81899b){const _0x4d2c51=vt('t',_0x81899b),_0x30796a=vt('d',_0x81899b);_0x4d2c51==='c'?this['onControl_'](_0x30796a):_0x4d2c51==='d'&&this['onDataMessage_'](_0x30796a);}['onDataMessage_'](_0x35995f){this['onPrimaryResponse_'](),this['onMessage_'](_0x35995f);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x3b7b62){const _0x1aec51=vt(ci,_0x3b7b62);if(Xs in _0x3b7b62){const _0x29781b=_0x3b7b62[Xs];if(_0x1aec51===bh){const _0x312bae={..._0x29781b};this['repoInfo_']['isUsingEmulator']&&(_0x312bae['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x312bae);}else{if(_0x1aec51===nr){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0xa9f985=0x0;_0xa9f985<this['pendingDataMessages']['length'];++_0xa9f985)this['onDataMessage_'](this['pendingDataMessages'][_0xa9f985]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x1aec51===Th?this['onConnectionShutdown_'](_0x29781b):_0x1aec51===Zs?this['onReset_'](_0x29781b):_0x1aec51===Sh?Ii('Server\x20Error:\x20'+_0x29781b):_0x1aec51===er?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x1aec51);}}}['onHandshake_'](_0x25c92d){const _0x4c8b1f=_0x25c92d['ts'],_0x917dd8=_0x25c92d['v'],_0x433d9b=_0x25c92d['h'];this['sessionId']=_0x25c92d['s'],this['repoInfo_']['host']=_0x433d9b,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x4c8b1f),Gi!==_0x917dd8&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x2bbd14=this['transportManager_']['upgradeTransport']();_0x2bbd14&&this['startUpgrade_'](_0x2bbd14);}['startUpgrade_'](_0x29946b){this['secondaryConn_']=new _0x29946b(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x29946b['responsesRequiredToBeHealthy']||0x0;const _0x5c580f=this['connReceiver_'](this['secondaryConn_']),_0x42fca4=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x5c580f,_0x42fca4),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](Eh));}['onReset_'](_0x16ed9b){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x16ed9b),this['repoInfo_']['host']=_0x16ed9b,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x4d6b8a,_0x18700b){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x4d6b8a,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x18700b,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](Ih));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':ir,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x1e8228=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x1e8228||this['rx_']===_0x1e8228)&&this['close']();}['onConnectionLost_'](_0x51bc37){this['conn_']=null,!_0x51bc37&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x55939c){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x55939c),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x55aa6e){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x55aa6e);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Po{['put'](_0x5ae28d,_0x2a117a,_0xc71975,_0x506602){}['merge'](_0x4ffe34,_0x336601,_0x20ef91,_0x1a287b){}['refreshAuthToken'](_0x11f192){}['refreshAppCheckToken'](_0x5a13ec){}['onDisconnectPut'](_0x4382d3,_0x59c390,_0x59d6b5){}['onDisconnectMerge'](_0x3c9237,_0x3ec34e,_0x992e8b){}['onDisconnectCancel'](_0x546e92,_0xc8627f){}['reportStats'](_0x1492dd){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oo{constructor(_0x300b14){this['allowedEvents_']=_0x300b14,this['listeners_']={},f(Array['isArray'](_0x300b14)&&_0x300b14['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x51f512,..._0x1eed68){if(Array['isArray'](this['listeners_'][_0x51f512])){const _0x185cc9=[...this['listeners_'][_0x51f512]];for(let _0x48ec9b=0x0;_0x48ec9b<_0x185cc9['length'];_0x48ec9b++)_0x185cc9[_0x48ec9b]['callback']['apply'](_0x185cc9[_0x48ec9b]['context'],_0x1eed68);}}['on'](_0x218bcc,_0x4a7fae,_0x326b9e){this['validateEventType_'](_0x218bcc),this['listeners_'][_0x218bcc]=this['listeners_'][_0x218bcc]||[],this['listeners_'][_0x218bcc]['push']({'callback':_0x4a7fae,'context':_0x326b9e});const _0x3a45fb=this['getInitialEvent'](_0x218bcc);_0x3a45fb&&_0x4a7fae['apply'](_0x326b9e,_0x3a45fb);}['off'](_0x29cca6,_0xc0d594,_0x4d8ab0){this['validateEventType_'](_0x29cca6);const _0x1b2203=this['listeners_'][_0x29cca6]||[];for(let _0x27ef54=0x0;_0x27ef54<_0x1b2203['length'];_0x27ef54++)if(_0x1b2203[_0x27ef54]['callback']===_0xc0d594&&(!_0x4d8ab0||_0x4d8ab0===_0x1b2203[_0x27ef54]['context'])){_0x1b2203['splice'](_0x27ef54,0x1);return;}}['validateEventType_'](_0x4f1156){f(this['allowedEvents_']['find'](_0x3e4322=>_0x3e4322===_0x4f1156),'Unknown\x20event:\x20'+_0x4f1156);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yn extends Oo{static['getInstance'](){return new yn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0xbff09a){return f(_0xbff09a==='online','Unknown\x20event\x20type:\x20'+_0xbff09a),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sr=0x20,rr=0x300;class C{constructor(_0x472638,_0x1d782b){if(_0x1d782b===void 0x0){this['pieces_']=_0x472638['split']('/');let _0x4d204a=0x0;for(let _0x382501=0x0;_0x382501<this['pieces_']['length'];_0x382501++)this['pieces_'][_0x382501]['length']>0x0&&(this['pieces_'][_0x4d204a]=this['pieces_'][_0x382501],_0x4d204a++);this['pieces_']['length']=_0x4d204a,this['pieceNum_']=0x0;}else this['pieces_']=_0x472638,this['pieceNum_']=_0x1d782b;}['toString'](){let _0x56047c='';for(let _0x372d10=this['pieceNum_'];_0x372d10<this['pieces_']['length'];_0x372d10++)this['pieces_'][_0x372d10]!==''&&(_0x56047c+='/'+this['pieces_'][_0x372d10]);return _0x56047c||'/';}}function w(){return new C('');}function y(_0xce694){return _0xce694['pieceNum_']>=_0xce694['pieces_']['length']?null:_0xce694['pieces_'][_0xce694['pieceNum_']];}function we(_0x1e52be){return _0x1e52be['pieces_']['length']-_0x1e52be['pieceNum_'];}function S(_0x2de37b){let _0x56eaa9=_0x2de37b['pieceNum_'];return _0x56eaa9<_0x2de37b['pieces_']['length']&&_0x56eaa9++,new C(_0x2de37b['pieces_'],_0x56eaa9);}function ji(_0x3ddce4){return _0x3ddce4['pieceNum_']<_0x3ddce4['pieces_']['length']?_0x3ddce4['pieces_'][_0x3ddce4['pieces_']['length']-0x1]:null;}function Ah(_0x449050){let _0x56ab75='';for(let _0x5e8d5b=_0x449050['pieceNum_'];_0x5e8d5b<_0x449050['pieces_']['length'];_0x5e8d5b++)_0x449050['pieces_'][_0x5e8d5b]!==''&&(_0x56ab75+='/'+encodeURIComponent(String(_0x449050['pieces_'][_0x5e8d5b])));return _0x56ab75||'/';}function Mt(_0xb2036d,_0x8df679=0x0){return _0xb2036d['pieces_']['slice'](_0xb2036d['pieceNum_']+_0x8df679);}function Do(_0x5aee74){if(_0x5aee74['pieceNum_']>=_0x5aee74['pieces_']['length'])return null;const _0x4e0564=[];for(let _0x30948b=_0x5aee74['pieceNum_'];_0x30948b<_0x5aee74['pieces_']['length']-0x1;_0x30948b++)_0x4e0564['push'](_0x5aee74['pieces_'][_0x30948b]);return new C(_0x4e0564,0x0);}function k(_0x57f5de,_0x3ea6e9){const _0x37088e=[];for(let _0x1642e9=_0x57f5de['pieceNum_'];_0x1642e9<_0x57f5de['pieces_']['length'];_0x1642e9++)_0x37088e['push'](_0x57f5de['pieces_'][_0x1642e9]);if(_0x3ea6e9 instanceof C){for(let _0x2b44c4=_0x3ea6e9['pieceNum_'];_0x2b44c4<_0x3ea6e9['pieces_']['length'];_0x2b44c4++)_0x37088e['push'](_0x3ea6e9['pieces_'][_0x2b44c4]);}else{const _0x2a16a7=_0x3ea6e9['split']('/');for(let _0x46ca86=0x0;_0x46ca86<_0x2a16a7['length'];_0x46ca86++)_0x2a16a7[_0x46ca86]['length']>0x0&&_0x37088e['push'](_0x2a16a7[_0x46ca86]);}return new C(_0x37088e,0x0);}function v(_0x420603){return _0x420603['pieceNum_']>=_0x420603['pieces_']['length'];}function F(_0x4813d1,_0x17e516){const _0x3f344=y(_0x4813d1),_0x51850d=y(_0x17e516);if(_0x3f344===null)return _0x17e516;if(_0x3f344===_0x51850d)return F(S(_0x4813d1),S(_0x17e516));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x17e516+')\x20is\x20not\x20within\x20outerPath\x20('+_0x4813d1+')');}function kh(_0x395c2f,_0x34a059){const _0x309d5c=Mt(_0x395c2f,0x0),_0xe58294=Mt(_0x34a059,0x0);for(let _0x37429a=0x0;_0x37429a<_0x309d5c['length']&&_0x37429a<_0xe58294['length'];_0x37429a++){const _0x8d5032=qe(_0x309d5c[_0x37429a],_0xe58294[_0x37429a]);if(_0x8d5032!==0x0)return _0x8d5032;}return _0x309d5c['length']===_0xe58294['length']?0x0:_0x309d5c['length']<_0xe58294['length']?-0x1:0x1;}function Ki(_0x4d07f2,_0x1ce319){if(we(_0x4d07f2)!==we(_0x1ce319))return!0x1;for(let _0x1ac070=_0x4d07f2['pieceNum_'],_0x45bf1a=_0x1ce319['pieceNum_'];_0x1ac070<=_0x4d07f2['pieces_']['length'];_0x1ac070++,_0x45bf1a++)if(_0x4d07f2['pieces_'][_0x1ac070]!==_0x1ce319['pieces_'][_0x45bf1a])return!0x1;return!0x0;}function G(_0x33fee1,_0x1cd232){let _0x5433f2=_0x33fee1['pieceNum_'],_0x2c42c9=_0x1cd232['pieceNum_'];if(we(_0x33fee1)>we(_0x1cd232))return!0x1;for(;_0x5433f2<_0x33fee1['pieces_']['length'];){if(_0x33fee1['pieces_'][_0x5433f2]!==_0x1cd232['pieces_'][_0x2c42c9])return!0x1;++_0x5433f2,++_0x2c42c9;}return!0x0;}class Nh{constructor(_0x3642f4,_0x8b5a4e){this['errorPrefix_']=_0x8b5a4e,this['parts_']=Mt(_0x3642f4,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x9fa567=0x0;_0x9fa567<this['parts_']['length'];_0x9fa567++)this['byteLength_']+=xn(this['parts_'][_0x9fa567]);Mo(this);}}function Ph(_0x6fed6e,_0x1678a3){_0x6fed6e['parts_']['length']>0x0&&(_0x6fed6e['byteLength_']+=0x1),_0x6fed6e['parts_']['push'](_0x1678a3),_0x6fed6e['byteLength_']+=xn(_0x1678a3),Mo(_0x6fed6e);}function Oh(_0xfd08d6){const _0x3bcc4e=_0xfd08d6['parts_']['pop']();_0xfd08d6['byteLength_']-=xn(_0x3bcc4e),_0xfd08d6['parts_']['length']>0x0&&(_0xfd08d6['byteLength_']-=0x1);}function Mo(_0x54d0ba){if(_0x54d0ba['byteLength_']>rr)throw new Error(_0x54d0ba['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+rr+'\x20bytes\x20('+_0x54d0ba['byteLength_']+').');if(_0x54d0ba['parts_']['length']>sr)throw new Error(_0x54d0ba['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+sr+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x54d0ba));}function Pe(_0x26eb18){return _0x26eb18['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x26eb18['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends Oo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x314239,_0x58afc7;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x58afc7='visibilitychange',_0x314239='hidden'):typeof document['mozHidden']<'u'?(_0x58afc7='mozvisibilitychange',_0x314239='mozHidden'):typeof document['msHidden']<'u'?(_0x58afc7='msvisibilitychange',_0x314239='msHidden'):typeof document['webkitHidden']<'u'&&(_0x58afc7='webkitvisibilitychange',_0x314239='webkitHidden')),this['visible_']=!0x0,_0x58afc7&&document['addEventListener'](_0x58afc7,()=>{const _0x404a98=!document[_0x314239];_0x404a98!==this['visible_']&&(this['visible_']=_0x404a98,this['trigger']('visible',_0x404a98));},!0x1);}['getInitialEvent'](_0x4c2043){return f(_0x4c2043==='visible','Unknown\x20event\x20type:\x20'+_0x4c2043),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Dh=0x12c*0x3e8,or=0x1e*0x3e8,Mh=1.3,Lh=0x7530,xh='server_kill',ar=0x3;class se extends Po{constructor(_0x183157,_0x5f48f2,_0x21016d,_0x1cc9b4,_0x177b08,_0x23a852,_0x423d2f,_0xebc4c6){if(super(),this['repoInfo_']=_0x183157,this['applicationId_']=_0x5f48f2,this['onDataUpdate_']=_0x21016d,this['onConnectStatus_']=_0x1cc9b4,this['onServerInfoUpdate_']=_0x177b08,this['authTokenProvider_']=_0x23a852,this['appCheckTokenProvider_']=_0x423d2f,this['authOverride_']=_0xebc4c6,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Dh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0xebc4c6)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x183157['host']['indexOf']('fblocal')===-0x1&&yn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x43cf84,_0x30c960,_0xa927a5){const _0x23840f=++this['requestNumber_'],_0x3e3545={'r':_0x23840f,'a':_0x43cf84,'b':_0x30c960};this['log_'](O(_0x3e3545)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x3e3545),_0xa927a5&&(this['requestCBHash_'][_0x23840f]=_0xa927a5);}['get'](_0x210dce){this['initConnection_']();const _0x3fbbe3=new H(),_0xd20423={'action':'g','request':{'p':_0x210dce['_path']['toString'](),'q':_0x210dce['_queryObject']},'onComplete':_0x1b679b=>{const _0x6bf8df=_0x1b679b['d'];_0x1b679b['s']==='ok'?_0x3fbbe3['resolve'](_0x6bf8df):_0x3fbbe3['reject'](_0x6bf8df);}};this['outstandingGets_']['push'](_0xd20423),this['outstandingGetCount_']++;const _0x3f3b9b=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x3f3b9b),_0x3fbbe3['promise'];}['listen'](_0x5c8518,_0x16ed09,_0x38ba55,_0x102f54){this['initConnection_']();const _0x44673f=_0x5c8518['_queryIdentifier'],_0x17e09a=_0x5c8518['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x17e09a+'\x20'+_0x44673f),this['listens']['has'](_0x17e09a)||this['listens']['set'](_0x17e09a,new Map()),f(_0x5c8518['_queryParams']['isDefault']()||!_0x5c8518['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x17e09a)['has'](_0x44673f),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x32f5c1={'onComplete':_0x102f54,'hashFn':_0x16ed09,'query':_0x5c8518,'tag':_0x38ba55};this['listens']['get'](_0x17e09a)['set'](_0x44673f,_0x32f5c1),this['connected_']&&this['sendListen_'](_0x32f5c1);}['sendGet_'](_0x23c4fa){const _0x2c30db=this['outstandingGets_'][_0x23c4fa];this['sendRequest']('g',_0x2c30db['request'],_0x4fe6f3=>{delete this['outstandingGets_'][_0x23c4fa],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x2c30db['onComplete']&&_0x2c30db['onComplete'](_0x4fe6f3);});}['sendListen_'](_0x161dab){const _0x442ea8=_0x161dab['query'],_0x566afd=_0x442ea8['_path']['toString'](),_0x21e1d0=_0x442ea8['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x566afd+'\x20for\x20'+_0x21e1d0);const _0x4a6622={'p':_0x566afd},_0x390e4f='q';_0x161dab['tag']&&(_0x4a6622['q']=_0x442ea8['_queryObject'],_0x4a6622['t']=_0x161dab['tag']),_0x4a6622['h']=_0x161dab['hashFn'](),this['sendRequest'](_0x390e4f,_0x4a6622,_0x3167b1=>{const _0xe76fcc=_0x3167b1['d'],_0x41a9a5=_0x3167b1['s'];se['warnOnListenWarnings_'](_0xe76fcc,_0x442ea8),(this['listens']['get'](_0x566afd)&&this['listens']['get'](_0x566afd)['get'](_0x21e1d0))===_0x161dab&&(this['log_']('listen\x20response',_0x3167b1),_0x41a9a5!=='ok'&&this['removeListen_'](_0x566afd,_0x21e1d0),_0x161dab['onComplete']&&_0x161dab['onComplete'](_0x41a9a5,_0xe76fcc));});}static['warnOnListenWarnings_'](_0x398fbf,_0x54816b){if(_0x398fbf&&typeof _0x398fbf=='object'&&Q(_0x398fbf,'w')){const _0x5c811e=Le(_0x398fbf,'w');if(Array['isArray'](_0x5c811e)&&~_0x5c811e['indexOf']('no_index')){const _0x36ce22='\x22.indexOn\x22:\x20\x22'+_0x54816b['_queryParams']['getIndex']()['toString']()+'\x22',_0x21b7c9=_0x54816b['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x36ce22+'\x20at\x20'+_0x21b7c9+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x5590fa){this['authToken_']=_0x5590fa,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x5590fa);}['reduceReconnectDelayIfAdminCredential_'](_0x4ca327){(_0x4ca327&&_0x4ca327['length']===0x28||Tc(_0x4ca327))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=or);}['refreshAppCheckToken'](_0x38e51a){this['appCheckToken_']=_0x38e51a,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0xd405d3=this['authToken_'],_0x1ecb9e=Cc(_0xd405d3)?'auth':'gauth',_0x1d0add={'cred':_0xd405d3};this['authOverride_']===null?_0x1d0add['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x1d0add['authvar']=this['authOverride_']),this['sendRequest'](_0x1ecb9e,_0x1d0add,_0x5ab071=>{const _0x1195c0=_0x5ab071['s'],_0x36287a=_0x5ab071['d']||'error';this['authToken_']===_0xd405d3&&(_0x1195c0==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x1195c0,_0x36287a));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x418b2f=>{const _0x473ef0=_0x418b2f['s'],_0x3f5ec9=_0x418b2f['d']||'error';_0x473ef0==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x473ef0,_0x3f5ec9);});}['unlisten'](_0x49110a,_0x4121e7){const _0x197ecf=_0x49110a['_path']['toString'](),_0x2f0b70=_0x49110a['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x197ecf+'\x20'+_0x2f0b70),f(_0x49110a['_queryParams']['isDefault']()||!_0x49110a['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x197ecf,_0x2f0b70)&&this['connected_']&&this['sendUnlisten_'](_0x197ecf,_0x2f0b70,_0x49110a['_queryObject'],_0x4121e7);}['sendUnlisten_'](_0x12c12b,_0x589a58,_0x2ed697,_0x3c4c2f){this['log_']('Unlisten\x20on\x20'+_0x12c12b+'\x20for\x20'+_0x589a58);const _0x52bb54={'p':_0x12c12b},_0x5c8d5f='n';_0x3c4c2f&&(_0x52bb54['q']=_0x2ed697,_0x52bb54['t']=_0x3c4c2f),this['sendRequest'](_0x5c8d5f,_0x52bb54);}['onDisconnectPut'](_0x4ec47d,_0x781a2b,_0x3ff10d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x4ec47d,_0x781a2b,_0x3ff10d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4ec47d,'action':'o','data':_0x781a2b,'onComplete':_0x3ff10d});}['onDisconnectMerge'](_0x5a8761,_0x21c0d8,_0x31a186){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x5a8761,_0x21c0d8,_0x31a186):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5a8761,'action':'om','data':_0x21c0d8,'onComplete':_0x31a186});}['onDisconnectCancel'](_0x82207e,_0x1f2b18){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x82207e,null,_0x1f2b18):this['onDisconnectRequestQueue_']['push']({'pathString':_0x82207e,'action':'oc','data':null,'onComplete':_0x1f2b18});}['sendOnDisconnect_'](_0x1320ed,_0x3e8bac,_0x3b893b,_0x2be324){const _0x551dbe={'p':_0x3e8bac,'d':_0x3b893b};this['log_']('onDisconnect\x20'+_0x1320ed,_0x551dbe),this['sendRequest'](_0x1320ed,_0x551dbe,_0x352337=>{_0x2be324&&setTimeout(()=>{_0x2be324(_0x352337['s'],_0x352337['d']);},Math['floor'](0x0));});}['put'](_0xcf6478,_0x323203,_0x6d9d89,_0x40f833){this['putInternal']('p',_0xcf6478,_0x323203,_0x6d9d89,_0x40f833);}['merge'](_0xb76188,_0x562455,_0x41cea1,_0x48b899){this['putInternal']('m',_0xb76188,_0x562455,_0x41cea1,_0x48b899);}['putInternal'](_0xd2253d,_0x1f846e,_0x4db921,_0x25df5d,_0x490d62){this['initConnection_']();const _0x28f11d={'p':_0x1f846e,'d':_0x4db921};_0x490d62!==void 0x0&&(_0x28f11d['h']=_0x490d62),this['outstandingPuts_']['push']({'action':_0xd2253d,'request':_0x28f11d,'onComplete':_0x25df5d}),this['outstandingPutCount_']++;const _0x30fe6c=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x30fe6c):this['log_']('Buffering\x20put:\x20'+_0x1f846e);}['sendPut_'](_0x24669e){const _0x1e6aff=this['outstandingPuts_'][_0x24669e]['action'],_0x58f07d=this['outstandingPuts_'][_0x24669e]['request'],_0x38f6c2=this['outstandingPuts_'][_0x24669e]['onComplete'];this['outstandingPuts_'][_0x24669e]['queued']=this['connected_'],this['sendRequest'](_0x1e6aff,_0x58f07d,_0x418459=>{this['log_'](_0x1e6aff+'\x20response',_0x418459),delete this['outstandingPuts_'][_0x24669e],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x38f6c2&&_0x38f6c2(_0x418459['s'],_0x418459['d']);});}['reportStats'](_0x167556){if(this['connected_']){const _0x41c1a6={'c':_0x167556};this['log_']('reportStats',_0x41c1a6),this['sendRequest']('s',_0x41c1a6,_0x451323=>{if(_0x451323['s']!=='ok'){const _0x539553=_0x451323['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x539553);}});}}['onDataMessage_'](_0x4c7367){if('r'in _0x4c7367){this['log_']('from\x20server:\x20'+O(_0x4c7367));const _0xdebfbc=_0x4c7367['r'],_0x3c12f9=this['requestCBHash_'][_0xdebfbc];_0x3c12f9&&(delete this['requestCBHash_'][_0xdebfbc],_0x3c12f9(_0x4c7367['b']));}else{if('error'in _0x4c7367)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x4c7367['error'];'a'in _0x4c7367&&this['onDataPush_'](_0x4c7367['a'],_0x4c7367['b']);}}['onDataPush_'](_0x8b54c8,_0x3d8530){this['log_']('handleServerMessage',_0x8b54c8,_0x3d8530),_0x8b54c8==='d'?this['onDataUpdate_'](_0x3d8530['p'],_0x3d8530['d'],!0x1,_0x3d8530['t']):_0x8b54c8==='m'?this['onDataUpdate_'](_0x3d8530['p'],_0x3d8530['d'],!0x0,_0x3d8530['t']):_0x8b54c8==='c'?this['onListenRevoked_'](_0x3d8530['p'],_0x3d8530['q']):_0x8b54c8==='ac'?this['onAuthRevoked_'](_0x3d8530['s'],_0x3d8530['d']):_0x8b54c8==='apc'?this['onAppCheckRevoked_'](_0x3d8530['s'],_0x3d8530['d']):_0x8b54c8==='sd'?this['onSecurityDebugPacket_'](_0x3d8530):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x8b54c8)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x344792,_0x2a38ec){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x344792),this['lastSessionId']=_0x2a38ec,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x3d4f4e){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x3d4f4e));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x5dcb04){_0x5dcb04&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x5dcb04;}['onOnline_'](_0x11b7d7){_0x11b7d7?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Lh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x4e8ef0=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x496b01=Math['max'](0x0,this['reconnectDelay_']-_0x4e8ef0);_0x496b01=Math['random']()*_0x496b01,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x496b01+'ms'),this['scheduleConnect_'](_0x496b01),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Mh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x31ce72=this['onDataMessage_']['bind'](this),_0xe7ccbe=this['onReady_']['bind'](this),_0x1d26fa=this['onRealtimeDisconnect_']['bind'](this),_0x26a730=this['id']+':'+se['nextConnectionId_']++,_0x47d210=this['lastSessionId'];let _0x3769e0=!0x1,_0x9c246=null;const _0x1a0fd5=function(){_0x9c246?_0x9c246['close']():(_0x3769e0=!0x0,_0x1d26fa());},_0x367fe7=function(_0x2c321){f(_0x9c246,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x9c246['sendRequest'](_0x2c321);};this['realtime_']={'close':_0x1a0fd5,'sendRequest':_0x367fe7};const _0x366bcb=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0xee727e,_0xd46220]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x366bcb),this['appCheckTokenProvider_']['getToken'](_0x366bcb)]);_0x3769e0?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0xee727e&&_0xee727e['accessToken'],this['appCheckToken_']=_0xd46220&&_0xd46220['token'],_0x9c246=new Rh(_0x26a730,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x31ce72,_0xe7ccbe,_0x1d26fa,_0x250cde=>{U(_0x250cde+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](xh);},_0x47d210));}catch(_0x5f513b){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x5f513b),_0x3769e0||(this['repoInfo_']['nodeAdmin']&&U(_0x5f513b),_0x1a0fd5());}}}['interrupt'](_0x3374d5){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x3374d5),this['interruptReasons_'][_0x3374d5]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x55e0a6){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x55e0a6),delete this['interruptReasons_'][_0x55e0a6],_n(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x38450f){const _0x118040=_0x38450f-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x118040});}['cancelSentTransactions_'](){for(let _0x1b6048=0x0;_0x1b6048<this['outstandingPuts_']['length'];_0x1b6048++){const _0x154681=this['outstandingPuts_'][_0x1b6048];_0x154681&&'h'in _0x154681['request']&&_0x154681['queued']&&(_0x154681['onComplete']&&_0x154681['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x1b6048],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0xf7fe0f,_0x1439a3){let _0x9cbb0;_0x1439a3?_0x9cbb0=_0x1439a3['map'](_0x4cb6f6=>$i(_0x4cb6f6))['join']('$'):_0x9cbb0='default';const _0x5f4559=this['removeListen_'](_0xf7fe0f,_0x9cbb0);_0x5f4559&&_0x5f4559['onComplete']&&_0x5f4559['onComplete']('permission_denied');}['removeListen_'](_0x3c63b7,_0x351ff5){const _0x1e3728=new C(_0x3c63b7)['toString']();let _0xaca57e;if(this['listens']['has'](_0x1e3728)){const _0x28d6e0=this['listens']['get'](_0x1e3728);_0xaca57e=_0x28d6e0['get'](_0x351ff5),_0x28d6e0['delete'](_0x351ff5),_0x28d6e0['size']===0x0&&this['listens']['delete'](_0x1e3728);}else _0xaca57e=void 0x0;return _0xaca57e;}['onAuthRevoked_'](_0x4c7dcd,_0x16e40f){L('Auth\x20token\x20revoked:\x20'+_0x4c7dcd+'/'+_0x16e40f),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x4c7dcd==='invalid_token'||_0x4c7dcd==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=ar&&(this['reconnectDelay_']=or,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x1905a0,_0x255ec5){L('App\x20check\x20token\x20revoked:\x20'+_0x1905a0+'/'+_0x255ec5),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x1905a0==='invalid_token'||_0x1905a0==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=ar&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x1420cd){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x1420cd):'msg'in _0x1420cd&&console['log']('FIREBASE:\x20'+_0x1420cd['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x15bf02 of this['listens']['values']())for(const _0x38f085 of _0x15bf02['values']())this['sendListen_'](_0x38f085);for(let _0x5f218b=0x0;_0x5f218b<this['outstandingPuts_']['length'];_0x5f218b++)this['outstandingPuts_'][_0x5f218b]&&this['sendPut_'](_0x5f218b);for(;this['onDisconnectRequestQueue_']['length'];){const _0xdb0805=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0xdb0805['action'],_0xdb0805['pathString'],_0xdb0805['data'],_0xdb0805['onComplete']);}for(let _0x4d9756=0x0;_0x4d9756<this['outstandingGets_']['length'];_0x4d9756++)this['outstandingGets_'][_0x4d9756]&&this['sendGet_'](_0x4d9756);}['sendConnectStats_'](){const _0x1b7ef7={};let _0x4b7bbd='js';_0x1b7ef7['sdk.'+_0x4b7bbd+'.'+co['replace'](/\./g,'-')]=0x1,Wi()?_0x1b7ef7['framework.cordova']=0x1:eo()&&(_0x1b7ef7['framework.reactnative']=0x1),this['reportStats'](_0x1b7ef7);}['shouldReconnect_'](){const _0x3f31f4=yn['getInstance']()['currentlyOnline']();return _n(this['interruptReasons_'])&&_0x3f31f4;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x15921b,_0x1f6361){this['name']=_0x15921b,this['node']=_0x1f6361;}static['Wrap'](_0x1a59dc,_0x46cfb6){return new E(_0x1a59dc,_0x46cfb6);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Un{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x3e11fd,_0x5e0a5c){const _0x518ddf=new E(We,_0x3e11fd),_0x26b541=new E(We,_0x5e0a5c);return this['compare'](_0x518ddf,_0x26b541)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let rn;class Lo extends Un{static get['__EMPTY_NODE'](){return rn;}static set['__EMPTY_NODE'](_0x482c77){rn=_0x482c77;}['compare'](_0xa44159,_0x45f8e8){return qe(_0xa44159['name'],_0x45f8e8['name']);}['isDefinedOn'](_0x2084af){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x484a1b,_0x3ebeb1){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,rn);}['makePost'](_0x61b22e,_0x56be68){return f(typeof _0x61b22e=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x61b22e,rn);}['toString'](){return'.key';}}const Me=new Lo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class on{constructor(_0x2068d8,_0x513ceb,_0x3a89b5,_0x4d56bc,_0x1cc170=null){this['isReverse_']=_0x4d56bc,this['resultGenerator_']=_0x1cc170,this['nodeStack_']=[];let _0x16f4ab=0x1;for(;!_0x2068d8['isEmpty']();)if(_0x2068d8=_0x2068d8,_0x16f4ab=_0x513ceb?_0x3a89b5(_0x2068d8['key'],_0x513ceb):0x1,_0x4d56bc&&(_0x16f4ab*=-0x1),_0x16f4ab<0x0)this['isReverse_']?_0x2068d8=_0x2068d8['left']:_0x2068d8=_0x2068d8['right'];else{if(_0x16f4ab===0x0){this['nodeStack_']['push'](_0x2068d8);break;}else this['nodeStack_']['push'](_0x2068d8),this['isReverse_']?_0x2068d8=_0x2068d8['right']:_0x2068d8=_0x2068d8['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x1a9af8=this['nodeStack_']['pop'](),_0x4a9b81;if(this['resultGenerator_']?_0x4a9b81=this['resultGenerator_'](_0x1a9af8['key'],_0x1a9af8['value']):_0x4a9b81={'key':_0x1a9af8['key'],'value':_0x1a9af8['value']},this['isReverse_']){for(_0x1a9af8=_0x1a9af8['left'];!_0x1a9af8['isEmpty']();)this['nodeStack_']['push'](_0x1a9af8),_0x1a9af8=_0x1a9af8['right'];}else{for(_0x1a9af8=_0x1a9af8['right'];!_0x1a9af8['isEmpty']();)this['nodeStack_']['push'](_0x1a9af8),_0x1a9af8=_0x1a9af8['left'];}return _0x4a9b81;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x8bbe6f=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x8bbe6f['key'],_0x8bbe6f['value']):{'key':_0x8bbe6f['key'],'value':_0x8bbe6f['value']};}}class M{constructor(_0x30e4cd,_0x4b6882,_0x532d70,_0x2c02ba,_0x39e395){this['key']=_0x30e4cd,this['value']=_0x4b6882,this['color']=_0x532d70!=null?_0x532d70:M['RED'],this['left']=_0x2c02ba!=null?_0x2c02ba:B['EMPTY_NODE'],this['right']=_0x39e395!=null?_0x39e395:B['EMPTY_NODE'];}['copy'](_0x4cfd4a,_0x2e19cc,_0x2f515d,_0x395f73,_0x4d03e7){return new M(_0x4cfd4a!=null?_0x4cfd4a:this['key'],_0x2e19cc!=null?_0x2e19cc:this['value'],_0x2f515d!=null?_0x2f515d:this['color'],_0x395f73!=null?_0x395f73:this['left'],_0x4d03e7!=null?_0x4d03e7:this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x4c3263){return this['left']['inorderTraversal'](_0x4c3263)||!!_0x4c3263(this['key'],this['value'])||this['right']['inorderTraversal'](_0x4c3263);}['reverseTraversal'](_0x21331a){return this['right']['reverseTraversal'](_0x21331a)||_0x21331a(this['key'],this['value'])||this['left']['reverseTraversal'](_0x21331a);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x46f6b4,_0x8fd1ea,_0x247fc9){let _0x119e42=this;const _0xb4d507=_0x247fc9(_0x46f6b4,_0x119e42['key']);return _0xb4d507<0x0?_0x119e42=_0x119e42['copy'](null,null,null,_0x119e42['left']['insert'](_0x46f6b4,_0x8fd1ea,_0x247fc9),null):_0xb4d507===0x0?_0x119e42=_0x119e42['copy'](null,_0x8fd1ea,null,null,null):_0x119e42=_0x119e42['copy'](null,null,null,null,_0x119e42['right']['insert'](_0x46f6b4,_0x8fd1ea,_0x247fc9)),_0x119e42['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x28a7cb=this;return!_0x28a7cb['left']['isRed_']()&&!_0x28a7cb['left']['left']['isRed_']()&&(_0x28a7cb=_0x28a7cb['moveRedLeft_']()),_0x28a7cb=_0x28a7cb['copy'](null,null,null,_0x28a7cb['left']['removeMin_'](),null),_0x28a7cb['fixUp_']();}['remove'](_0x1d4417,_0x42f235){let _0x21f7c0,_0x114626;if(_0x21f7c0=this,_0x42f235(_0x1d4417,_0x21f7c0['key'])<0x0)!_0x21f7c0['left']['isEmpty']()&&!_0x21f7c0['left']['isRed_']()&&!_0x21f7c0['left']['left']['isRed_']()&&(_0x21f7c0=_0x21f7c0['moveRedLeft_']()),_0x21f7c0=_0x21f7c0['copy'](null,null,null,_0x21f7c0['left']['remove'](_0x1d4417,_0x42f235),null);else{if(_0x21f7c0['left']['isRed_']()&&(_0x21f7c0=_0x21f7c0['rotateRight_']()),!_0x21f7c0['right']['isEmpty']()&&!_0x21f7c0['right']['isRed_']()&&!_0x21f7c0['right']['left']['isRed_']()&&(_0x21f7c0=_0x21f7c0['moveRedRight_']()),_0x42f235(_0x1d4417,_0x21f7c0['key'])===0x0){if(_0x21f7c0['right']['isEmpty']())return B['EMPTY_NODE'];_0x114626=_0x21f7c0['right']['min_'](),_0x21f7c0=_0x21f7c0['copy'](_0x114626['key'],_0x114626['value'],null,null,_0x21f7c0['right']['removeMin_']());}_0x21f7c0=_0x21f7c0['copy'](null,null,null,null,_0x21f7c0['right']['remove'](_0x1d4417,_0x42f235));}return _0x21f7c0['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x375113=this;return _0x375113['right']['isRed_']()&&!_0x375113['left']['isRed_']()&&(_0x375113=_0x375113['rotateLeft_']()),_0x375113['left']['isRed_']()&&_0x375113['left']['left']['isRed_']()&&(_0x375113=_0x375113['rotateRight_']()),_0x375113['left']['isRed_']()&&_0x375113['right']['isRed_']()&&(_0x375113=_0x375113['colorFlip_']()),_0x375113;}['moveRedLeft_'](){let _0x52d464=this['colorFlip_']();return _0x52d464['right']['left']['isRed_']()&&(_0x52d464=_0x52d464['copy'](null,null,null,null,_0x52d464['right']['rotateRight_']()),_0x52d464=_0x52d464['rotateLeft_'](),_0x52d464=_0x52d464['colorFlip_']()),_0x52d464;}['moveRedRight_'](){let _0x30ea8e=this['colorFlip_']();return _0x30ea8e['left']['left']['isRed_']()&&(_0x30ea8e=_0x30ea8e['rotateRight_'](),_0x30ea8e=_0x30ea8e['colorFlip_']()),_0x30ea8e;}['rotateLeft_'](){const _0x30facc=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x30facc,null);}['rotateRight_'](){const _0x36d769=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x36d769);}['colorFlip_'](){const _0x40498=this['left']['copy'](null,null,!this['left']['color'],null,null),_0xce7444=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x40498,_0xce7444);}['checkMaxDepth_'](){const _0x282217=this['check_']();return Math['pow'](0x2,_0x282217)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x363169=this['left']['check_']();if(_0x363169!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x363169+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Fh{['copy'](_0x177361,_0x28b028,_0x2cd5fc,_0x316b1a,_0x2445b2){return this;}['insert'](_0x3d7bb1,_0x99d624,_0x33a9b3){return new M(_0x3d7bb1,_0x99d624,null);}['remove'](_0x1b9e23,_0x867188){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x4fd780){return!0x1;}['reverseTraversal'](_0x4d481f){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x1d983b,_0x3953e4=B['EMPTY_NODE']){this['comparator_']=_0x1d983b,this['root_']=_0x3953e4;}['insert'](_0x208f90,_0x28f9e9){return new B(this['comparator_'],this['root_']['insert'](_0x208f90,_0x28f9e9,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x4652fb){return new B(this['comparator_'],this['root_']['remove'](_0x4652fb,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x48a512){let _0x37926e,_0x362985=this['root_'];for(;!_0x362985['isEmpty']();){if(_0x37926e=this['comparator_'](_0x48a512,_0x362985['key']),_0x37926e===0x0)return _0x362985['value'];_0x37926e<0x0?_0x362985=_0x362985['left']:_0x37926e>0x0&&(_0x362985=_0x362985['right']);}return null;}['getPredecessorKey'](_0x24a837){let _0xdb86ed,_0x44e81c=this['root_'],_0x5e4ae3=null;for(;!_0x44e81c['isEmpty']();)if(_0xdb86ed=this['comparator_'](_0x24a837,_0x44e81c['key']),_0xdb86ed===0x0){if(_0x44e81c['left']['isEmpty']())return _0x5e4ae3?_0x5e4ae3['key']:null;for(_0x44e81c=_0x44e81c['left'];!_0x44e81c['right']['isEmpty']();)_0x44e81c=_0x44e81c['right'];return _0x44e81c['key'];}else _0xdb86ed<0x0?_0x44e81c=_0x44e81c['left']:_0xdb86ed>0x0&&(_0x5e4ae3=_0x44e81c,_0x44e81c=_0x44e81c['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x743e8b){return this['root_']['inorderTraversal'](_0x743e8b);}['reverseTraversal'](_0x5e70ff){return this['root_']['reverseTraversal'](_0x5e70ff);}['getIterator'](_0x58d39a){return new on(this['root_'],null,this['comparator_'],!0x1,_0x58d39a);}['getIteratorFrom'](_0x18ebc7,_0x37c1f6){return new on(this['root_'],_0x18ebc7,this['comparator_'],!0x1,_0x37c1f6);}['getReverseIteratorFrom'](_0x2178df,_0xdf3b1){return new on(this['root_'],_0x2178df,this['comparator_'],!0x0,_0xdf3b1);}['getReverseIterator'](_0x7a82bd){return new on(this['root_'],null,this['comparator_'],!0x0,_0x7a82bd);}}B['EMPTY_NODE']=new Fh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uh(_0x5f2854,_0x1b987a){return qe(_0x5f2854['name'],_0x1b987a['name']);}function Qi(_0x5b424f,_0x3efe56){return qe(_0x5b424f,_0x3efe56);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Wh(_0xdf9b8a){Ci=_0xdf9b8a;}const xo=function(_0x576f98){return typeof _0x576f98=='number'?'number:'+po(_0x576f98):'string:'+_0x576f98;},Fo=function(_0x257b0b){if(_0x257b0b['isLeafNode']()){const _0x1e41b7=_0x257b0b['val']();f(typeof _0x1e41b7=='string'||typeof _0x1e41b7=='number'||typeof _0x1e41b7=='object'&&Q(_0x1e41b7,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x257b0b===Ci||_0x257b0b['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x257b0b===Ci||_0x257b0b['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let cr;class D{static set['__childrenNodeConstructor'](_0x5130e2){cr=_0x5130e2;}static get['__childrenNodeConstructor'](){return cr;}constructor(_0x401e34,_0x38303b=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x401e34,this['priorityNode_']=_0x38303b,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Fo(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x25a44b){return new D(this['value_'],_0x25a44b);}['getImmediateChild'](_0x19d0ad){return _0x19d0ad==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x43b39e){return v(_0x43b39e)?this:y(_0x43b39e)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x4c9134,_0x108557){return null;}['updateImmediateChild'](_0x4f27d3,_0x2ee865){return _0x4f27d3==='.priority'?this['updatePriority'](_0x2ee865):_0x2ee865['isEmpty']()&&_0x4f27d3!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x4f27d3,_0x2ee865)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x1277f1,_0x49bc76){const _0x412ab1=y(_0x1277f1);return _0x412ab1===null?_0x49bc76:_0x49bc76['isEmpty']()&&_0x412ab1!=='.priority'?this:(f(_0x412ab1!=='.priority'||we(_0x1277f1)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x412ab1,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x1277f1),_0x49bc76)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x1e770b,_0x81e850){return!0x1;}['val'](_0x31e26b){return _0x31e26b&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x550de8='';this['priorityNode_']['isEmpty']()||(_0x550de8+='priority:'+xo(this['priorityNode_']['val']())+':');const _0x465848=typeof this['value_'];_0x550de8+=_0x465848+':',_0x465848==='number'?_0x550de8+=po(this['value_']):_0x550de8+=this['value_'],this['lazyHash_']=uo(_0x550de8);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x33db96){return _0x33db96===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x33db96 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x33db96['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x33db96));}['compareToLeafNode_'](_0x250f05){const _0x2e514b=typeof _0x250f05['value_'],_0x25b960=typeof this['value_'],_0x492f8a=D['VALUE_TYPE_ORDER']['indexOf'](_0x2e514b),_0x26cfda=D['VALUE_TYPE_ORDER']['indexOf'](_0x25b960);return f(_0x492f8a>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x2e514b),f(_0x26cfda>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x25b960),_0x492f8a===_0x26cfda?_0x25b960==='object'?0x0:this['value_']<_0x250f05['value_']?-0x1:this['value_']===_0x250f05['value_']?0x0:0x1:_0x26cfda-_0x492f8a;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0xd69405){if(_0xd69405===this)return!0x0;if(_0xd69405['isLeafNode']()){const _0xa03d49=_0xd69405;return this['value_']===_0xa03d49['value_']&&this['priorityNode_']['equals'](_0xa03d49['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Uo,Wo;function Bh(_0x37e4e8){Uo=_0x37e4e8;}function Vh(_0x18d8c2){Wo=_0x18d8c2;}class Hh extends Un{['compare'](_0x227b5b,_0x2b1d4f){const _0x3adb7c=_0x227b5b['node']['getPriority'](),_0xd50ce1=_0x2b1d4f['node']['getPriority'](),_0x1a8cec=_0x3adb7c['compareTo'](_0xd50ce1);return _0x1a8cec===0x0?qe(_0x227b5b['name'],_0x2b1d4f['name']):_0x1a8cec;}['isDefinedOn'](_0x39681d){return!_0x39681d['getPriority']()['isEmpty']();}['indexedValueChanged'](_0xcf37c1,_0xd476b){return!_0xcf37c1['getPriority']()['equals'](_0xd476b['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Wo));}['makePost'](_0x4f9722,_0x6df824){const _0xae5809=Uo(_0x4f9722);return new E(_0x6df824,new D('[PRIORITY-POST]',_0xae5809));}['toString'](){return'.priority';}}const R=new Hh(),$h=Math['log'](0x2);class Gh{constructor(_0x576a6d){const _0x1c0555=_0x103788=>parseInt(Math['log'](_0x103788)/$h,0xa),_0x11d275=_0x11eb58=>parseInt(Array(_0x11eb58+0x1)['join']('1'),0x2);this['count']=_0x1c0555(_0x576a6d+0x1),this['current_']=this['count']-0x1;const _0xb4ff36=_0x11d275(this['count']);this['bits_']=_0x576a6d+0x1&_0xb4ff36;}['nextBitIsOne'](){const _0x54704c=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x54704c;}}const vn=function(_0x4f1ece,_0x858c9,_0x2fee7a,_0x2cbad3){_0x4f1ece['sort'](_0x858c9);const _0x4fd60a=function(_0x41641e,_0x2068d1){const _0x21ff4e=_0x2068d1-_0x41641e;let _0x163983,_0x29efaf;if(_0x21ff4e===0x0)return null;if(_0x21ff4e===0x1)return _0x163983=_0x4f1ece[_0x41641e],_0x29efaf=_0x2fee7a?_0x2fee7a(_0x163983):_0x163983,new M(_0x29efaf,_0x163983['node'],M['BLACK'],null,null);{const _0x575682=parseInt(_0x21ff4e/0x2,0xa)+_0x41641e,_0x4fa34e=_0x4fd60a(_0x41641e,_0x575682),_0x277998=_0x4fd60a(_0x575682+0x1,_0x2068d1);return _0x163983=_0x4f1ece[_0x575682],_0x29efaf=_0x2fee7a?_0x2fee7a(_0x163983):_0x163983,new M(_0x29efaf,_0x163983['node'],M['BLACK'],_0x4fa34e,_0x277998);}},_0x36dd8d=function(_0x4d383d){let _0xd750b8=null,_0x551b8d=null,_0x20c828=_0x4f1ece['length'];const _0x3daab2=function(_0x367d01,_0x154985){const _0x22b667=_0x20c828-_0x367d01,_0x6b2ba4=_0x20c828;_0x20c828-=_0x367d01;const _0x51e766=_0x4fd60a(_0x22b667+0x1,_0x6b2ba4),_0x2fc86f=_0x4f1ece[_0x22b667],_0x252b24=_0x2fee7a?_0x2fee7a(_0x2fc86f):_0x2fc86f;_0x59e24d(new M(_0x252b24,_0x2fc86f['node'],_0x154985,null,_0x51e766));},_0x59e24d=function(_0x26e1df){_0xd750b8?(_0xd750b8['left']=_0x26e1df,_0xd750b8=_0x26e1df):(_0x551b8d=_0x26e1df,_0xd750b8=_0x26e1df);};for(let _0x17d73a=0x0;_0x17d73a<_0x4d383d['count'];++_0x17d73a){const _0x50a333=_0x4d383d['nextBitIsOne'](),_0x51feb7=Math['pow'](0x2,_0x4d383d['count']-(_0x17d73a+0x1));_0x50a333?_0x3daab2(_0x51feb7,M['BLACK']):(_0x3daab2(_0x51feb7,M['BLACK']),_0x3daab2(_0x51feb7,M['RED']));}return _0x551b8d;},_0xa7512f=new Gh(_0x4f1ece['length']),_0x24e348=_0x36dd8d(_0xa7512f);return new B(_0x2cbad3||_0x858c9,_0x24e348);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x38d811,_0x36699c){this['indexes_']=_0x38d811,this['indexSet_']=_0x36699c;}['get'](_0x2bec2c){const _0x2c99eb=Le(this['indexes_'],_0x2bec2c);if(!_0x2c99eb)throw new Error('No\x20index\x20defined\x20for\x20'+_0x2bec2c);return _0x2c99eb instanceof B?_0x2c99eb:null;}['hasIndex'](_0x4f8d2d){return Q(this['indexSet_'],_0x4f8d2d['toString']());}['addIndex'](_0x539ed3,_0x427a43){f(_0x539ed3!==Me,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x4bd90f=[];let _0x5b095f=!0x1;const _0x26fbe7=_0x427a43['getIterator'](E['Wrap']);let _0x182fe6=_0x26fbe7['getNext']();for(;_0x182fe6;)_0x5b095f=_0x5b095f||_0x539ed3['isDefinedOn'](_0x182fe6['node']),_0x4bd90f['push'](_0x182fe6),_0x182fe6=_0x26fbe7['getNext']();let _0x41f659;_0x5b095f?_0x41f659=vn(_0x4bd90f,_0x539ed3['getCompare']()):_0x41f659=Qe;const _0x26f952=_0x539ed3['toString'](),_0x5248ec={...this['indexSet_']};_0x5248ec[_0x26f952]=_0x539ed3;const _0x44dfe4={...this['indexes_']};return _0x44dfe4[_0x26f952]=_0x41f659,new te(_0x44dfe4,_0x5248ec);}['addToIndexes'](_0x3f7245,_0x5a1507){const _0x15a62d=gn(this['indexes_'],(_0x2f06a7,_0x3d582a)=>{const _0x2b80b7=Le(this['indexSet_'],_0x3d582a);if(f(_0x2b80b7,'Missing\x20index\x20implementation\x20for\x20'+_0x3d582a),_0x2f06a7===Qe){if(_0x2b80b7['isDefinedOn'](_0x3f7245['node'])){const _0x4b6a9a=[],_0x3193da=_0x5a1507['getIterator'](E['Wrap']);let _0x4c074b=_0x3193da['getNext']();for(;_0x4c074b;)_0x4c074b['name']!==_0x3f7245['name']&&_0x4b6a9a['push'](_0x4c074b),_0x4c074b=_0x3193da['getNext']();return _0x4b6a9a['push'](_0x3f7245),vn(_0x4b6a9a,_0x2b80b7['getCompare']());}else return Qe;}else{const _0x37cf51=_0x5a1507['get'](_0x3f7245['name']);let _0x4f0154=_0x2f06a7;return _0x37cf51&&(_0x4f0154=_0x4f0154['remove'](new E(_0x3f7245['name'],_0x37cf51))),_0x4f0154['insert'](_0x3f7245,_0x3f7245['node']);}});return new te(_0x15a62d,this['indexSet_']);}['removeFromIndexes'](_0x4b998f,_0xc195a){const _0x59a1af=gn(this['indexes_'],_0x4eaf7f=>{if(_0x4eaf7f===Qe)return _0x4eaf7f;{const _0x3a6a12=_0xc195a['get'](_0x4b998f['name']);return _0x3a6a12?_0x4eaf7f['remove'](new E(_0x4b998f['name'],_0x3a6a12)):_0x4eaf7f;}});return new te(_0x59a1af,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x4e425b,_0x4e1f8b,_0x31f0a6){this['children_']=_0x4e425b,this['priorityNode_']=_0x4e1f8b,this['indexMap_']=_0x31f0a6,this['lazyHash_']=null,this['priorityNode_']&&Fo(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x45a4c9){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x45a4c9,this['indexMap_']);}['getImmediateChild'](_0xe23f90){if(_0xe23f90==='.priority')return this['getPriority']();{const _0x55d8e5=this['children_']['get'](_0xe23f90);return _0x55d8e5===null?It:_0x55d8e5;}}['getChild'](_0x3b1673){const _0x383e78=y(_0x3b1673);return _0x383e78===null?this:this['getImmediateChild'](_0x383e78)['getChild'](S(_0x3b1673));}['hasChild'](_0x5a4e8){return this['children_']['get'](_0x5a4e8)!==null;}['updateImmediateChild'](_0x48a82a,_0x282e77){if(f(_0x282e77,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x48a82a==='.priority')return this['updatePriority'](_0x282e77);{const _0x19203e=new E(_0x48a82a,_0x282e77);let _0x2d3fb3,_0x44eb39;_0x282e77['isEmpty']()?(_0x2d3fb3=this['children_']['remove'](_0x48a82a),_0x44eb39=this['indexMap_']['removeFromIndexes'](_0x19203e,this['children_'])):(_0x2d3fb3=this['children_']['insert'](_0x48a82a,_0x282e77),_0x44eb39=this['indexMap_']['addToIndexes'](_0x19203e,this['children_']));const _0xf45143=_0x2d3fb3['isEmpty']()?It:this['priorityNode_'];return new g(_0x2d3fb3,_0xf45143,_0x44eb39);}}['updateChild'](_0x1de27e,_0x4fdd91){const _0x43222b=y(_0x1de27e);if(_0x43222b===null)return _0x4fdd91;{f(y(_0x1de27e)!=='.priority'||we(_0x1de27e)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x1155d2=this['getImmediateChild'](_0x43222b)['updateChild'](S(_0x1de27e),_0x4fdd91);return this['updateImmediateChild'](_0x43222b,_0x1155d2);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x52a18c){if(this['isEmpty']())return null;const _0x33f4e0={};let _0x40fb77=0x0,_0x51e8ba=0x0,_0x223c42=!0x0;if(this['forEachChild'](R,(_0x5deb35,_0x44e29b)=>{_0x33f4e0[_0x5deb35]=_0x44e29b['val'](_0x52a18c),_0x40fb77++,_0x223c42&&g['INTEGER_REGEXP_']['test'](_0x5deb35)?_0x51e8ba=Math['max'](_0x51e8ba,Number(_0x5deb35)):_0x223c42=!0x1;}),!_0x52a18c&&_0x223c42&&_0x51e8ba<0x2*_0x40fb77){const _0x1b324d=[];for(const _0x41e40f in _0x33f4e0)_0x1b324d[_0x41e40f]=_0x33f4e0[_0x41e40f];return _0x1b324d;}else return _0x52a18c&&!this['getPriority']()['isEmpty']()&&(_0x33f4e0['.priority']=this['getPriority']()['val']()),_0x33f4e0;}['hash'](){if(this['lazyHash_']===null){let _0x20b39d='';this['getPriority']()['isEmpty']()||(_0x20b39d+='priority:'+xo(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0xba75f9,_0x3d3a21)=>{const _0x3c09a8=_0x3d3a21['hash']();_0x3c09a8!==''&&(_0x20b39d+=':'+_0xba75f9+':'+_0x3c09a8);}),this['lazyHash_']=_0x20b39d===''?'':uo(_0x20b39d);}return this['lazyHash_'];}['getPredecessorChildName'](_0x66ccc5,_0x3a14f3,_0x3ea5ce){const _0x5933e5=this['resolveIndex_'](_0x3ea5ce);if(_0x5933e5){const _0x1746c1=_0x5933e5['getPredecessorKey'](new E(_0x66ccc5,_0x3a14f3));return _0x1746c1?_0x1746c1['name']:null;}else return this['children_']['getPredecessorKey'](_0x66ccc5);}['getFirstChildName'](_0x12a75c){const _0x1adf3d=this['resolveIndex_'](_0x12a75c);if(_0x1adf3d){const _0x264b86=_0x1adf3d['minKey']();return _0x264b86&&_0x264b86['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x3b0df8){const _0x1f5282=this['getFirstChildName'](_0x3b0df8);return _0x1f5282?new E(_0x1f5282,this['children_']['get'](_0x1f5282)):null;}['getLastChildName'](_0xdd724a){const _0xf742ae=this['resolveIndex_'](_0xdd724a);if(_0xf742ae){const _0x10577d=_0xf742ae['maxKey']();return _0x10577d&&_0x10577d['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x2bce35){const _0x1e8dbd=this['getLastChildName'](_0x2bce35);return _0x1e8dbd?new E(_0x1e8dbd,this['children_']['get'](_0x1e8dbd)):null;}['forEachChild'](_0x47f906,_0x104635){const _0x3d4c20=this['resolveIndex_'](_0x47f906);return _0x3d4c20?_0x3d4c20['inorderTraversal'](_0x1e3687=>_0x104635(_0x1e3687['name'],_0x1e3687['node'])):this['children_']['inorderTraversal'](_0x104635);}['getIterator'](_0xab31c5){return this['getIteratorFrom'](_0xab31c5['minPost'](),_0xab31c5);}['getIteratorFrom'](_0xf8d808,_0x4665d5){const _0x228803=this['resolveIndex_'](_0x4665d5);if(_0x228803)return _0x228803['getIteratorFrom'](_0xf8d808,_0x96ef6e=>_0x96ef6e);{const _0x2fb582=this['children_']['getIteratorFrom'](_0xf8d808['name'],E['Wrap']);let _0x586999=_0x2fb582['peek']();for(;_0x586999!=null&&_0x4665d5['compare'](_0x586999,_0xf8d808)<0x0;)_0x2fb582['getNext'](),_0x586999=_0x2fb582['peek']();return _0x2fb582;}}['getReverseIterator'](_0x4014ac){return this['getReverseIteratorFrom'](_0x4014ac['maxPost'](),_0x4014ac);}['getReverseIteratorFrom'](_0x4f6538,_0x2d5c89){const _0x36bc6b=this['resolveIndex_'](_0x2d5c89);if(_0x36bc6b)return _0x36bc6b['getReverseIteratorFrom'](_0x4f6538,_0x440a2=>_0x440a2);{const _0x2bb583=this['children_']['getReverseIteratorFrom'](_0x4f6538['name'],E['Wrap']);let _0x50ced4=_0x2bb583['peek']();for(;_0x50ced4!=null&&_0x2d5c89['compare'](_0x50ced4,_0x4f6538)>0x0;)_0x2bb583['getNext'](),_0x50ced4=_0x2bb583['peek']();return _0x2bb583;}}['compareTo'](_0x17980f){return this['isEmpty']()?_0x17980f['isEmpty']()?0x0:-0x1:_0x17980f['isLeafNode']()||_0x17980f['isEmpty']()?0x1:_0x17980f===Kt?-0x1:0x0;}['withIndex'](_0x25a014){if(_0x25a014===Me||this['indexMap_']['hasIndex'](_0x25a014))return this;{const _0x544e3c=this['indexMap_']['addIndex'](_0x25a014,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x544e3c);}}['isIndexed'](_0x5eaa35){return _0x5eaa35===Me||this['indexMap_']['hasIndex'](_0x5eaa35);}['equals'](_0x52c702){if(_0x52c702===this)return!0x0;if(_0x52c702['isLeafNode']())return!0x1;{const _0x285018=_0x52c702;if(this['getPriority']()['equals'](_0x285018['getPriority']())){if(this['children_']['count']()===_0x285018['children_']['count']()){const _0x9fceb1=this['getIterator'](R),_0x2e4f1e=_0x285018['getIterator'](R);let _0x4a5a59=_0x9fceb1['getNext'](),_0x11a139=_0x2e4f1e['getNext']();for(;_0x4a5a59&&_0x11a139;){if(_0x4a5a59['name']!==_0x11a139['name']||!_0x4a5a59['node']['equals'](_0x11a139['node']))return!0x1;_0x4a5a59=_0x9fceb1['getNext'](),_0x11a139=_0x2e4f1e['getNext']();}return _0x4a5a59===null&&_0x11a139===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x5e3afb){return _0x5e3afb===Me?null:this['indexMap_']['get'](_0x5e3afb['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class qh extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x385642){return _0x385642===this?0x0:0x1;}['equals'](_0x2c45c0){return _0x2c45c0===this;}['getPriority'](){return this;}['getImmediateChild'](_0x5bceea){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new qh();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Kt)}}),Lo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Wh(Kt),Vh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zh=!0x0;function A(_0x2a0198,_0x140a08=null){if(_0x2a0198===null)return g['EMPTY_NODE'];if(typeof _0x2a0198=='object'&&'.priority'in _0x2a0198&&(_0x140a08=_0x2a0198['.priority']),f(_0x140a08===null||typeof _0x140a08=='string'||typeof _0x140a08=='number'||typeof _0x140a08=='object'&&'.sv'in _0x140a08,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x140a08),typeof _0x2a0198=='object'&&'.value'in _0x2a0198&&_0x2a0198['.value']!==null&&(_0x2a0198=_0x2a0198['.value']),typeof _0x2a0198!='object'||'.sv'in _0x2a0198){const _0x5bf9c4=_0x2a0198;return new D(_0x5bf9c4,A(_0x140a08));}if(!(_0x2a0198 instanceof Array)&&zh){const _0x11f743=[];let _0x529dac=!0x1;if(x(_0x2a0198,(_0x23e6ef,_0x16044f)=>{if(_0x23e6ef['substring'](0x0,0x1)!=='.'){const _0x64492d=A(_0x16044f);_0x64492d['isEmpty']()||(_0x529dac=_0x529dac||!_0x64492d['getPriority']()['isEmpty'](),_0x11f743['push'](new E(_0x23e6ef,_0x64492d)));}}),_0x11f743['length']===0x0)return g['EMPTY_NODE'];const _0x40bf3f=vn(_0x11f743,Uh,_0x581273=>_0x581273['name'],Qi);if(_0x529dac){const _0x589d92=vn(_0x11f743,R['getCompare']());return new g(_0x40bf3f,A(_0x140a08),new te({'.priority':_0x589d92},{'.priority':R}));}else return new g(_0x40bf3f,A(_0x140a08),te['Default']);}else{let _0x16a984=g['EMPTY_NODE'];return x(_0x2a0198,(_0x9bd2ef,_0x2b078b)=>{if(Q(_0x2a0198,_0x9bd2ef)&&_0x9bd2ef['substring'](0x0,0x1)!=='.'){const _0xe805c5=A(_0x2b078b);(_0xe805c5['isLeafNode']()||!_0xe805c5['isEmpty']())&&(_0x16a984=_0x16a984['updateImmediateChild'](_0x9bd2ef,_0xe805c5));}}),_0x16a984['updatePriority'](A(_0x140a08));}}Bh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Un{constructor(_0x811dff){super(),this['indexPath_']=_0x811dff,f(!v(_0x811dff)&&y(_0x811dff)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x5a89b3){return _0x5a89b3['getChild'](this['indexPath_']);}['isDefinedOn'](_0x11c62f){return!_0x11c62f['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x316cab,_0x87748a){const _0x3cb274=this['extractChild'](_0x316cab['node']),_0x364e38=this['extractChild'](_0x87748a['node']),_0x4eb92c=_0x3cb274['compareTo'](_0x364e38);return _0x4eb92c===0x0?qe(_0x316cab['name'],_0x87748a['name']):_0x4eb92c;}['makePost'](_0x12137b,_0x523406){const _0x513ebb=A(_0x12137b),_0x14cab7=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x513ebb);return new E(_0x523406,_0x14cab7);}['maxPost'](){const _0x4d63a4=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(Ie,_0x4d63a4);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh extends Un{['compare'](_0x2da5ba,_0x59aec6){const _0x269603=_0x2da5ba['node']['compareTo'](_0x59aec6['node']);return _0x269603===0x0?qe(_0x2da5ba['name'],_0x59aec6['name']):_0x269603;}['isDefinedOn'](_0x51eb05){return!0x0;}['indexedValueChanged'](_0x37323b,_0x93fe92){return!_0x37323b['equals'](_0x93fe92);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x241eab,_0x3c6dc4){const _0x35a406=A(_0x241eab);return new E(_0x3c6dc4,_0x35a406);}['toString'](){return'.value';}}const Bo=new jh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vo(_0x12c6d2){return{'type':'value','snapshotNode':_0x12c6d2};}function rt(_0x414121,_0x545e8d){return{'type':'child_added','snapshotNode':_0x545e8d,'childName':_0x414121};}function Lt(_0x4b5938,_0x31429a){return{'type':'child_removed','snapshotNode':_0x31429a,'childName':_0x4b5938};}function xt(_0x1f001b,_0x135c94,_0x2428eb){return{'type':'child_changed','snapshotNode':_0x135c94,'childName':_0x1f001b,'oldSnap':_0x2428eb};}function Kh(_0x46a5dd,_0x1c17d4){return{'type':'child_moved','snapshotNode':_0x1c17d4,'childName':_0x46a5dd};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x418ac2){this['index_']=_0x418ac2;}['updateChild'](_0x39e750,_0x58b8b2,_0x195967,_0x27961b,_0x435390,_0x126d1b){f(_0x39e750['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x346401=_0x39e750['getImmediateChild'](_0x58b8b2);return _0x346401['getChild'](_0x27961b)['equals'](_0x195967['getChild'](_0x27961b))&&_0x346401['isEmpty']()===_0x195967['isEmpty']()||(_0x126d1b!=null&&(_0x195967['isEmpty']()?_0x39e750['hasChild'](_0x58b8b2)?_0x126d1b['trackChildChange'](Lt(_0x58b8b2,_0x346401)):f(_0x39e750['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x346401['isEmpty']()?_0x126d1b['trackChildChange'](rt(_0x58b8b2,_0x195967)):_0x126d1b['trackChildChange'](xt(_0x58b8b2,_0x195967,_0x346401))),_0x39e750['isLeafNode']()&&_0x195967['isEmpty']())?_0x39e750:_0x39e750['updateImmediateChild'](_0x58b8b2,_0x195967)['withIndex'](this['index_']);}['updateFullNode'](_0x5b0b11,_0x501ed5,_0x569b87){return _0x569b87!=null&&(_0x5b0b11['isLeafNode']()||_0x5b0b11['forEachChild'](R,(_0x2f4bf8,_0x5a7e57)=>{_0x501ed5['hasChild'](_0x2f4bf8)||_0x569b87['trackChildChange'](Lt(_0x2f4bf8,_0x5a7e57));}),_0x501ed5['isLeafNode']()||_0x501ed5['forEachChild'](R,(_0x7f548b,_0xbe77e2)=>{if(_0x5b0b11['hasChild'](_0x7f548b)){const _0x1d7ddf=_0x5b0b11['getImmediateChild'](_0x7f548b);_0x1d7ddf['equals'](_0xbe77e2)||_0x569b87['trackChildChange'](xt(_0x7f548b,_0xbe77e2,_0x1d7ddf));}else _0x569b87['trackChildChange'](rt(_0x7f548b,_0xbe77e2));})),_0x501ed5['withIndex'](this['index_']);}['updatePriority'](_0x555246,_0x56b551){return _0x555246['isEmpty']()?g['EMPTY_NODE']:_0x555246['updatePriority'](_0x56b551);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x33f0b9){this['indexedFilter_']=new Xi(_0x33f0b9['getIndex']()),this['index_']=_0x33f0b9['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x33f0b9),this['endPost_']=Ft['getEndPost_'](_0x33f0b9),this['startIsInclusive_']=!_0x33f0b9['startAfterSet_'],this['endIsInclusive_']=!_0x33f0b9['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0xd788a2){const _0x271ec3=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0xd788a2)<=0x0:this['index_']['compare'](this['getStartPost'](),_0xd788a2)<0x0,_0x362a38=this['endIsInclusive_']?this['index_']['compare'](_0xd788a2,this['getEndPost']())<=0x0:this['index_']['compare'](_0xd788a2,this['getEndPost']())<0x0;return _0x271ec3&&_0x362a38;}['updateChild'](_0x5a70d3,_0x4662c,_0x3c6b6f,_0x4563a8,_0x99271f,_0x48fc88){return this['matches'](new E(_0x4662c,_0x3c6b6f))||(_0x3c6b6f=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x5a70d3,_0x4662c,_0x3c6b6f,_0x4563a8,_0x99271f,_0x48fc88);}['updateFullNode'](_0xfbccfe,_0x9a4823,_0x2c11e7){_0x9a4823['isLeafNode']()&&(_0x9a4823=g['EMPTY_NODE']);let _0xc93e0=_0x9a4823['withIndex'](this['index_']);_0xc93e0=_0xc93e0['updatePriority'](g['EMPTY_NODE']);const _0x1af934=this;return _0x9a4823['forEachChild'](R,(_0x2a1908,_0xa4b53a)=>{_0x1af934['matches'](new E(_0x2a1908,_0xa4b53a))||(_0xc93e0=_0xc93e0['updateImmediateChild'](_0x2a1908,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0xfbccfe,_0xc93e0,_0x2c11e7);}['updatePriority'](_0x2d9321,_0x55430e){return _0x2d9321;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x2b3dad){if(_0x2b3dad['hasStart']()){const _0x1fdc7f=_0x2b3dad['getIndexStartName']();return _0x2b3dad['getIndex']()['makePost'](_0x2b3dad['getIndexStartValue'](),_0x1fdc7f);}else return _0x2b3dad['getIndex']()['minPost']();}static['getEndPost_'](_0x467ce1){if(_0x467ce1['hasEnd']()){const _0x3b027c=_0x467ce1['getIndexEndName']();return _0x467ce1['getIndex']()['makePost'](_0x467ce1['getIndexEndValue'](),_0x3b027c);}else return _0x467ce1['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(_0x210737){this['withinDirectionalStart']=_0x56d366=>this['reverse_']?this['withinEndPost'](_0x56d366):this['withinStartPost'](_0x56d366),this['withinDirectionalEnd']=_0x32e5c8=>this['reverse_']?this['withinStartPost'](_0x32e5c8):this['withinEndPost'](_0x32e5c8),this['withinStartPost']=_0xcae17b=>{const _0x37afdb=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0xcae17b);return this['startIsInclusive_']?_0x37afdb<=0x0:_0x37afdb<0x0;},this['withinEndPost']=_0x19e741=>{const _0x51b406=this['index_']['compare'](_0x19e741,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x51b406<=0x0:_0x51b406<0x0;},this['rangedFilter_']=new Ft(_0x210737),this['index_']=_0x210737['getIndex'](),this['limit_']=_0x210737['getLimit'](),this['reverse_']=!_0x210737['isViewFromLeft'](),this['startIsInclusive_']=!_0x210737['startAfterSet_'],this['endIsInclusive_']=!_0x210737['endBeforeSet_'];}['updateChild'](_0x4b93e9,_0x2c77ed,_0x2b8a39,_0x1d3c3e,_0x343f96,_0x4c965f){return this['rangedFilter_']['matches'](new E(_0x2c77ed,_0x2b8a39))||(_0x2b8a39=g['EMPTY_NODE']),_0x4b93e9['getImmediateChild'](_0x2c77ed)['equals'](_0x2b8a39)?_0x4b93e9:_0x4b93e9['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x4b93e9,_0x2c77ed,_0x2b8a39,_0x1d3c3e,_0x343f96,_0x4c965f):this['fullLimitUpdateChild_'](_0x4b93e9,_0x2c77ed,_0x2b8a39,_0x343f96,_0x4c965f);}['updateFullNode'](_0x5361bb,_0x3ee6dc,_0x1f5708){let _0x3dd57d;if(_0x3ee6dc['isLeafNode']()||_0x3ee6dc['isEmpty']())_0x3dd57d=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x3ee6dc['numChildren']()&&_0x3ee6dc['isIndexed'](this['index_'])){_0x3dd57d=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x3c4196;this['reverse_']?_0x3c4196=_0x3ee6dc['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x3c4196=_0x3ee6dc['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x33d36d=0x0;for(;_0x3c4196['hasNext']()&&_0x33d36d<this['limit_'];){const _0x185a76=_0x3c4196['getNext']();if(this['withinDirectionalStart'](_0x185a76)){if(this['withinDirectionalEnd'](_0x185a76))_0x3dd57d=_0x3dd57d['updateImmediateChild'](_0x185a76['name'],_0x185a76['node']),_0x33d36d++;else break;}else continue;}}else{_0x3dd57d=_0x3ee6dc['withIndex'](this['index_']),_0x3dd57d=_0x3dd57d['updatePriority'](g['EMPTY_NODE']);let _0x8f87d8;this['reverse_']?_0x8f87d8=_0x3dd57d['getReverseIterator'](this['index_']):_0x8f87d8=_0x3dd57d['getIterator'](this['index_']);let _0x497ff7=0x0;for(;_0x8f87d8['hasNext']();){const _0x18d9b5=_0x8f87d8['getNext']();_0x497ff7<this['limit_']&&this['withinDirectionalStart'](_0x18d9b5)&&this['withinDirectionalEnd'](_0x18d9b5)?_0x497ff7++:_0x3dd57d=_0x3dd57d['updateImmediateChild'](_0x18d9b5['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x5361bb,_0x3dd57d,_0x1f5708);}['updatePriority'](_0x2ac0e2,_0x33a369){return _0x2ac0e2;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x55d158,_0x3a14fb,_0x41c32e,_0xa69746,_0x151341){let _0x28cdcc;if(this['reverse_']){const _0x57b770=this['index_']['getCompare']();_0x28cdcc=(_0x5f4515,_0x222912)=>_0x57b770(_0x222912,_0x5f4515);}else _0x28cdcc=this['index_']['getCompare']();const _0xf55e28=_0x55d158;f(_0xf55e28['numChildren']()===this['limit_'],'');const _0x55dc4f=new E(_0x3a14fb,_0x41c32e),_0x46fbfb=this['reverse_']?_0xf55e28['getFirstChild'](this['index_']):_0xf55e28['getLastChild'](this['index_']),_0x2b29e3=this['rangedFilter_']['matches'](_0x55dc4f);if(_0xf55e28['hasChild'](_0x3a14fb)){const _0x4fc715=_0xf55e28['getImmediateChild'](_0x3a14fb);let _0x4bc001=_0xa69746['getChildAfterChild'](this['index_'],_0x46fbfb,this['reverse_']);for(;_0x4bc001!=null&&(_0x4bc001['name']===_0x3a14fb||_0xf55e28['hasChild'](_0x4bc001['name']));)_0x4bc001=_0xa69746['getChildAfterChild'](this['index_'],_0x4bc001,this['reverse_']);const _0x35c3c2=_0x4bc001==null?0x1:_0x28cdcc(_0x4bc001,_0x55dc4f);if(_0x2b29e3&&!_0x41c32e['isEmpty']()&&_0x35c3c2>=0x0)return _0x151341!=null&&_0x151341['trackChildChange'](xt(_0x3a14fb,_0x41c32e,_0x4fc715)),_0xf55e28['updateImmediateChild'](_0x3a14fb,_0x41c32e);{_0x151341!=null&&_0x151341['trackChildChange'](Lt(_0x3a14fb,_0x4fc715));const _0x4dcdce=_0xf55e28['updateImmediateChild'](_0x3a14fb,g['EMPTY_NODE']);return _0x4bc001!=null&&this['rangedFilter_']['matches'](_0x4bc001)?(_0x151341!=null&&_0x151341['trackChildChange'](rt(_0x4bc001['name'],_0x4bc001['node'])),_0x4dcdce['updateImmediateChild'](_0x4bc001['name'],_0x4bc001['node'])):_0x4dcdce;}}else return _0x41c32e['isEmpty']()?_0x55d158:_0x2b29e3&&_0x28cdcc(_0x46fbfb,_0x55dc4f)>=0x0?(_0x151341!=null&&(_0x151341['trackChildChange'](Lt(_0x46fbfb['name'],_0x46fbfb['node'])),_0x151341['trackChildChange'](rt(_0x3a14fb,_0x41c32e))),_0xf55e28['updateImmediateChild'](_0x3a14fb,_0x41c32e)['updateImmediateChild'](_0x46fbfb['name'],g['EMPTY_NODE'])):_0x55d158;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x217e41=new Zi();return _0x217e41['limitSet_']=this['limitSet_'],_0x217e41['limit_']=this['limit_'],_0x217e41['startSet_']=this['startSet_'],_0x217e41['startAfterSet_']=this['startAfterSet_'],_0x217e41['indexStartValue_']=this['indexStartValue_'],_0x217e41['startNameSet_']=this['startNameSet_'],_0x217e41['indexStartName_']=this['indexStartName_'],_0x217e41['endSet_']=this['endSet_'],_0x217e41['endBeforeSet_']=this['endBeforeSet_'],_0x217e41['indexEndValue_']=this['indexEndValue_'],_0x217e41['endNameSet_']=this['endNameSet_'],_0x217e41['indexEndName_']=this['indexEndName_'],_0x217e41['index_']=this['index_'],_0x217e41['viewFrom_']=this['viewFrom_'],_0x217e41;}}function Qh(_0x4d9d0f){return _0x4d9d0f['loadsAllData']()?new Xi(_0x4d9d0f['getIndex']()):_0x4d9d0f['hasLimit']()?new Yh(_0x4d9d0f):new Ft(_0x4d9d0f);}function Jh(_0x2c6918,_0x2d75e1,_0x25dc7d){const _0xb20df5=_0x2c6918['copy']();return _0xb20df5['startSet_']=!0x0,_0x2d75e1===void 0x0&&(_0x2d75e1=null),_0xb20df5['indexStartValue_']=_0x2d75e1,_0x25dc7d!=null?(_0xb20df5['startNameSet_']=!0x0,_0xb20df5['indexStartName_']=_0x25dc7d):(_0xb20df5['startNameSet_']=!0x1,_0xb20df5['indexStartName_']=''),_0xb20df5;}function Xh(_0x3a8543,_0x1dd496,_0x901c96){const _0x5a4fc5=_0x3a8543['copy']();return _0x5a4fc5['endSet_']=!0x0,_0x1dd496===void 0x0&&(_0x1dd496=null),_0x5a4fc5['indexEndValue_']=_0x1dd496,_0x901c96!==void 0x0?(_0x5a4fc5['endNameSet_']=!0x0,_0x5a4fc5['indexEndName_']=_0x901c96):(_0x5a4fc5['endNameSet_']=!0x1,_0x5a4fc5['indexEndName_']=''),_0x5a4fc5;}function Zh(_0x85df67,_0x13f63e){const _0x3330d1=_0x85df67['copy']();return _0x3330d1['index_']=_0x13f63e,_0x3330d1;}function lr(_0x23b0e2){const _0x2f116c={};if(_0x23b0e2['isDefault']())return _0x2f116c;let _0x585e0a;if(_0x23b0e2['index_']===R?_0x585e0a='$priority':_0x23b0e2['index_']===Bo?_0x585e0a='$value':_0x23b0e2['index_']===Me?_0x585e0a='$key':(f(_0x23b0e2['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x585e0a=_0x23b0e2['index_']['toString']()),_0x2f116c['orderBy']=O(_0x585e0a),_0x23b0e2['startSet_']){const _0x5d3764=_0x23b0e2['startAfterSet_']?'startAfter':'startAt';_0x2f116c[_0x5d3764]=O(_0x23b0e2['indexStartValue_']),_0x23b0e2['startNameSet_']&&(_0x2f116c[_0x5d3764]+=','+O(_0x23b0e2['indexStartName_']));}if(_0x23b0e2['endSet_']){const _0x1fd248=_0x23b0e2['endBeforeSet_']?'endBefore':'endAt';_0x2f116c[_0x1fd248]=O(_0x23b0e2['indexEndValue_']),_0x23b0e2['endNameSet_']&&(_0x2f116c[_0x1fd248]+=','+O(_0x23b0e2['indexEndName_']));}return _0x23b0e2['limitSet_']&&(_0x23b0e2['isViewFromLeft']()?_0x2f116c['limitToFirst']=_0x23b0e2['limit_']:_0x2f116c['limitToLast']=_0x23b0e2['limit_']),_0x2f116c;}function hr(_0x718906){const _0x52ac9c={};if(_0x718906['startSet_']&&(_0x52ac9c['sp']=_0x718906['indexStartValue_'],_0x718906['startNameSet_']&&(_0x52ac9c['sn']=_0x718906['indexStartName_']),_0x52ac9c['sin']=!_0x718906['startAfterSet_']),_0x718906['endSet_']&&(_0x52ac9c['ep']=_0x718906['indexEndValue_'],_0x718906['endNameSet_']&&(_0x52ac9c['en']=_0x718906['indexEndName_']),_0x52ac9c['ein']=!_0x718906['endBeforeSet_']),_0x718906['limitSet_']){_0x52ac9c['l']=_0x718906['limit_'];let _0x32fa10=_0x718906['viewFrom_'];_0x32fa10===''&&(_0x718906['isViewFromLeft']()?_0x32fa10='l':_0x32fa10='r'),_0x52ac9c['vf']=_0x32fa10;}return _0x718906['index_']!==R&&(_0x52ac9c['i']=_0x718906['index_']['toString']()),_0x52ac9c;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class En extends Po{['reportStats'](_0x4cd9e4){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x26a296,_0x2cf147){return _0x2cf147!==void 0x0?'tag$'+_0x2cf147:(f(_0x26a296['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x26a296['_path']['toString']());}constructor(_0x210838,_0x56249a,_0x538a8d,_0x30e46e){super(),this['repoInfo_']=_0x210838,this['onDataUpdate_']=_0x56249a,this['authTokenProvider_']=_0x538a8d,this['appCheckTokenProvider_']=_0x30e46e,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0xba2ad,_0x55ebf9,_0x3db70d,_0x5de61e){const _0x34581c=_0xba2ad['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x34581c+'\x20'+_0xba2ad['_queryIdentifier']);const _0x16b828=En['getListenId_'](_0xba2ad,_0x3db70d),_0x31aa9e={};this['listens_'][_0x16b828]=_0x31aa9e;const _0x531b0e=lr(_0xba2ad['_queryParams']);this['restRequest_'](_0x34581c+'.json',_0x531b0e,(_0x3f8fe0,_0x1f9b31)=>{let _0x441b89=_0x1f9b31;if(_0x3f8fe0===0x194&&(_0x441b89=null,_0x3f8fe0=null),_0x3f8fe0===null&&this['onDataUpdate_'](_0x34581c,_0x441b89,!0x1,_0x3db70d),Le(this['listens_'],_0x16b828)===_0x31aa9e){let _0x45686d;_0x3f8fe0?_0x3f8fe0===0x191?_0x45686d='permission_denied':_0x45686d='rest_error:'+_0x3f8fe0:_0x45686d='ok',_0x5de61e(_0x45686d,null);}});}['unlisten'](_0x3f02dd,_0x1006c5){const _0x2a408f=En['getListenId_'](_0x3f02dd,_0x1006c5);delete this['listens_'][_0x2a408f];}['get'](_0x3aab61){const _0x2b6640=lr(_0x3aab61['_queryParams']),_0x3f40c0=_0x3aab61['_path']['toString'](),_0x6e8708=new H();return this['restRequest_'](_0x3f40c0+'.json',_0x2b6640,(_0x179123,_0x44fcbd)=>{let _0x198cb0=_0x44fcbd;_0x179123===0x194&&(_0x198cb0=null,_0x179123=null),_0x179123===null?(this['onDataUpdate_'](_0x3f40c0,_0x198cb0,!0x1,null),_0x6e8708['resolve'](_0x198cb0)):_0x6e8708['reject'](new Error(_0x198cb0));}),_0x6e8708['promise'];}['refreshAuthToken'](_0x344233){}['restRequest_'](_0x42f40c,_0x17f356={},_0x4720c1){return _0x17f356['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x57db64,_0x42528a])=>{_0x57db64&&_0x57db64['accessToken']&&(_0x17f356['auth']=_0x57db64['accessToken']),_0x42528a&&_0x42528a['token']&&(_0x17f356['ac']=_0x42528a['token']);const _0x1d45fe=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x42f40c+'?ns='+this['repoInfo_']['namespace']+ut(_0x17f356);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x1d45fe);const _0x37d6e6=new XMLHttpRequest();_0x37d6e6['onreadystatechange']=()=>{if(_0x4720c1&&_0x37d6e6['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x1d45fe+'\x20received.\x20status:',_0x37d6e6['status'],'response:',_0x37d6e6['responseText']);let _0x5b0c41=null;if(_0x37d6e6['status']>=0xc8&&_0x37d6e6['status']<0x12c){try{_0x5b0c41=Pt(_0x37d6e6['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x1d45fe+':\x20'+_0x37d6e6['responseText']);}_0x4720c1(null,_0x5b0c41);}else _0x37d6e6['status']!==0x191&&_0x37d6e6['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x1d45fe+'\x20Status:\x20'+_0x37d6e6['status']),_0x4720c1(_0x37d6e6['status']);_0x4720c1=null;}},_0x37d6e6['open']('GET',_0x1d45fe,!0x0),_0x37d6e6['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x2bb956){return this['rootNode_']['getChild'](_0x2bb956);}['updateSnapshot'](_0x1b0b4c,_0x1596e1){this['rootNode_']=this['rootNode_']['updateChild'](_0x1b0b4c,_0x1596e1);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function In(){return{'value':null,'children':new Map()};}function pt(_0x125863,_0x29cf2f,_0x11bba9){if(v(_0x29cf2f))_0x125863['value']=_0x11bba9,_0x125863['children']['clear']();else{if(_0x125863['value']!==null)_0x125863['value']=_0x125863['value']['updateChild'](_0x29cf2f,_0x11bba9);else{const _0x31ad78=y(_0x29cf2f);_0x125863['children']['has'](_0x31ad78)||_0x125863['children']['set'](_0x31ad78,In());const _0x20bf7b=_0x125863['children']['get'](_0x31ad78);_0x29cf2f=S(_0x29cf2f),pt(_0x20bf7b,_0x29cf2f,_0x11bba9);}}}function Ti(_0x4605f4,_0x187075){if(v(_0x187075))return _0x4605f4['value']=null,_0x4605f4['children']['clear'](),!0x0;if(_0x4605f4['value']!==null){if(_0x4605f4['value']['isLeafNode']())return!0x1;{const _0x5900b2=_0x4605f4['value'];return _0x4605f4['value']=null,_0x5900b2['forEachChild'](R,(_0x49d15c,_0x33058a)=>{pt(_0x4605f4,new C(_0x49d15c),_0x33058a);}),Ti(_0x4605f4,_0x187075);}}else{if(_0x4605f4['children']['size']>0x0){const _0x2e590b=y(_0x187075);return _0x187075=S(_0x187075),_0x4605f4['children']['has'](_0x2e590b)&&Ti(_0x4605f4['children']['get'](_0x2e590b),_0x187075)&&_0x4605f4['children']['delete'](_0x2e590b),_0x4605f4['children']['size']===0x0;}else return!0x0;}}function Si(_0x1dd260,_0x32d8c9,_0x4bb853){_0x1dd260['value']!==null?_0x4bb853(_0x32d8c9,_0x1dd260['value']):tu(_0x1dd260,(_0x18c50d,_0x42a956)=>{const _0x1514ac=new C(_0x32d8c9['toString']()+'/'+_0x18c50d);Si(_0x42a956,_0x1514ac,_0x4bb853);});}function tu(_0x1e17ce,_0x31c632){_0x1e17ce['children']['forEach']((_0x4befa9,_0x5c8dc5)=>{_0x31c632(_0x5c8dc5,_0x4befa9);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nu{constructor(_0x556efc){this['collection_']=_0x556efc,this['last_']=null;}['get'](){const _0x27f5f3=this['collection_']['get'](),_0x6375ef={..._0x27f5f3};return this['last_']&&x(this['last_'],(_0x4242c6,_0x4a9a80)=>{_0x6375ef[_0x4242c6]=_0x6375ef[_0x4242c6]-_0x4a9a80;}),this['last_']=_0x27f5f3,_0x6375ef;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ur=0xa*0x3e8,iu=0x1e*0x3e8,su=0x12c*0x3e8;class ru{constructor(_0x122694,_0x3f51dd){this['server_']=_0x3f51dd,this['statsToReport_']={},this['statsListener_']=new nu(_0x122694);const _0xf787c5=ur+(iu-ur)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0xf787c5));}['reportStats_'](){const _0x59c862=this['statsListener_']['get'](),_0x403314={};let _0x370dd2=!0x1;x(_0x59c862,(_0xe0fa2e,_0x357e07)=>{_0x357e07>0x0&&Q(this['statsToReport_'],_0xe0fa2e)&&(_0x403314[_0xe0fa2e]=_0x357e07,_0x370dd2=!0x0);}),_0x370dd2&&this['server_']['reportStats'](_0x403314),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*su));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x255f0d){_0x255f0d[_0x255f0d['OVERWRITE']=0x0]='OVERWRITE',_0x255f0d[_0x255f0d['MERGE']=0x1]='MERGE',_0x255f0d[_0x255f0d['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x255f0d[_0x255f0d['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0xd40654){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0xd40654,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wn{constructor(_0x18964c,_0x312812,_0x2d83e3){this['path']=_0x18964c,this['affectedTree']=_0x312812,this['revert']=_0x2d83e3,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x3c683b){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x419a25=this['affectedTree']['subtree'](new C(_0x3c683b));return new wn(w(),_0x419a25,this['revert']);}}else return f(y(this['path'])===_0x3c683b,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new wn(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x3302d9,_0x5b797d){this['source']=_0x3302d9,this['path']=_0x5b797d,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x33aa0f){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x50d964,_0x317730,_0x2a439c){this['source']=_0x50d964,this['path']=_0x317730,this['snap']=_0x2a439c,this['type']=z['OVERWRITE'];}['operationForChild'](_0x1db3e5){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x1db3e5)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x41d8ff,_0x259951,_0xb8fec4){this['source']=_0x41d8ff,this['path']=_0x259951,this['children']=_0xb8fec4,this['type']=z['MERGE'];}['operationForChild'](_0x376c5b){if(v(this['path'])){const _0x23f059=this['children']['subtree'](new C(_0x376c5b));return _0x23f059['isEmpty']()?null:_0x23f059['value']?new Be(this['source'],w(),_0x23f059['value']):new ot(this['source'],w(),_0x23f059);}else return f(y(this['path'])===_0x376c5b,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x45ff78,_0x1acdb,_0x1b310a){this['node_']=_0x45ff78,this['fullyInitialized_']=_0x1acdb,this['filtered_']=_0x1b310a;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x2612be){if(v(_0x2612be))return this['isFullyInitialized']()&&!this['filtered_'];const _0x137ad1=y(_0x2612be);return this['isCompleteForChild'](_0x137ad1);}['isCompleteForChild'](_0x22ba11){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x22ba11);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ou{constructor(_0x237caf){this['query_']=_0x237caf,this['index_']=this['query_']['_queryParams']['getIndex']();}}function au(_0x41e1e9,_0x2c4222,_0xa4ea4b,_0x1c54b8){const _0xc1c951=[],_0x4d4d09=[];return _0x2c4222['forEach'](_0x3652f3=>{_0x3652f3['type']==='child_changed'&&_0x41e1e9['index_']['indexedValueChanged'](_0x3652f3['oldSnap'],_0x3652f3['snapshotNode'])&&_0x4d4d09['push'](Kh(_0x3652f3['childName'],_0x3652f3['snapshotNode']));}),wt(_0x41e1e9,_0xc1c951,'child_removed',_0x2c4222,_0x1c54b8,_0xa4ea4b),wt(_0x41e1e9,_0xc1c951,'child_added',_0x2c4222,_0x1c54b8,_0xa4ea4b),wt(_0x41e1e9,_0xc1c951,'child_moved',_0x4d4d09,_0x1c54b8,_0xa4ea4b),wt(_0x41e1e9,_0xc1c951,'child_changed',_0x2c4222,_0x1c54b8,_0xa4ea4b),wt(_0x41e1e9,_0xc1c951,'value',_0x2c4222,_0x1c54b8,_0xa4ea4b),_0xc1c951;}function wt(_0x12251b,_0x4139a4,_0x11f9e7,_0x213003,_0x3d2010,_0x271bba){const _0x2c1a57=_0x213003['filter'](_0x29c5fe=>_0x29c5fe['type']===_0x11f9e7);_0x2c1a57['sort']((_0x2c95f3,_0x3fd677)=>lu(_0x12251b,_0x2c95f3,_0x3fd677)),_0x2c1a57['forEach'](_0x320e9c=>{const _0x5e20e0=cu(_0x12251b,_0x320e9c,_0x271bba);_0x3d2010['forEach'](_0x380de1=>{_0x380de1['respondsTo'](_0x320e9c['type'])&&_0x4139a4['push'](_0x380de1['createEvent'](_0x5e20e0,_0x12251b['query_']));});});}function cu(_0x40ee83,_0x311825,_0x26e76a){return _0x311825['type']==='value'||_0x311825['type']==='child_removed'||(_0x311825['prevName']=_0x26e76a['getPredecessorChildName'](_0x311825['childName'],_0x311825['snapshotNode'],_0x40ee83['index_'])),_0x311825;}function lu(_0x3bc12e,_0x4b2f63,_0x74ccb7){if(_0x4b2f63['childName']==null||_0x74ccb7['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0xbafc3=new E(_0x4b2f63['childName'],_0x4b2f63['snapshotNode']),_0x2ae037=new E(_0x74ccb7['childName'],_0x74ccb7['snapshotNode']);return _0x3bc12e['index_']['compare'](_0xbafc3,_0x2ae037);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x559bf9,_0x31f137){return{'eventCache':_0x559bf9,'serverCache':_0x31f137};}function Rt(_0x3a3c51,_0x3a537f,_0x7d2394,_0x1cd3bb){return Wn(new Ce(_0x3a537f,_0x7d2394,_0x1cd3bb),_0x3a3c51['serverCache']);}function Ho(_0x1a763b,_0x5c7f5f,_0x343d47,_0x47d92d){return Wn(_0x1a763b['eventCache'],new Ce(_0x5c7f5f,_0x343d47,_0x47d92d));}function Cn(_0x509cf0){return _0x509cf0['eventCache']['isFullyInitialized']()?_0x509cf0['eventCache']['getNode']():null;}function Ve(_0x3cad04){return _0x3cad04['serverCache']['isFullyInitialized']()?_0x3cad04['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const hu=()=>(hi||(hi=new B(jl)),hi);class b{static['fromObject'](_0x313b78){let _0x13c79c=new b(null);return x(_0x313b78,(_0x46c995,_0x31956d)=>{_0x13c79c=_0x13c79c['set'](new C(_0x46c995),_0x31956d);}),_0x13c79c;}constructor(_0x2ad8d9,_0x33ec6a=hu()){this['value']=_0x2ad8d9,this['children']=_0x33ec6a;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x4a0ce6,_0x1880b7){if(this['value']!=null&&_0x1880b7(this['value']))return{'path':w(),'value':this['value']};if(v(_0x4a0ce6))return null;{const _0x2039a2=y(_0x4a0ce6),_0x1378e5=this['children']['get'](_0x2039a2);if(_0x1378e5!==null){const _0x42d338=_0x1378e5['findRootMostMatchingPathAndValue'](S(_0x4a0ce6),_0x1880b7);return _0x42d338!=null?{'path':k(new C(_0x2039a2),_0x42d338['path']),'value':_0x42d338['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x1c08fe){return this['findRootMostMatchingPathAndValue'](_0x1c08fe,()=>!0x0);}['subtree'](_0x3a7979){if(v(_0x3a7979))return this;{const _0x20d6c9=y(_0x3a7979),_0x2065e5=this['children']['get'](_0x20d6c9);return _0x2065e5!==null?_0x2065e5['subtree'](S(_0x3a7979)):new b(null);}}['set'](_0x254bc1,_0x3ad13d){if(v(_0x254bc1))return new b(_0x3ad13d,this['children']);{const _0x243d01=y(_0x254bc1),_0x6e0cde=(this['children']['get'](_0x243d01)||new b(null))['set'](S(_0x254bc1),_0x3ad13d),_0x3dafd6=this['children']['insert'](_0x243d01,_0x6e0cde);return new b(this['value'],_0x3dafd6);}}['remove'](_0x336452){if(v(_0x336452))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x155a7c=y(_0x336452),_0x258248=this['children']['get'](_0x155a7c);if(_0x258248){const _0x44df43=_0x258248['remove'](S(_0x336452));let _0x4c3e05;return _0x44df43['isEmpty']()?_0x4c3e05=this['children']['remove'](_0x155a7c):_0x4c3e05=this['children']['insert'](_0x155a7c,_0x44df43),this['value']===null&&_0x4c3e05['isEmpty']()?new b(null):new b(this['value'],_0x4c3e05);}else return this;}}['get'](_0x392285){if(v(_0x392285))return this['value'];{const _0x4e4890=y(_0x392285),_0xeee489=this['children']['get'](_0x4e4890);return _0xeee489?_0xeee489['get'](S(_0x392285)):null;}}['setTree'](_0x34db9f,_0x5ea8c7){if(v(_0x34db9f))return _0x5ea8c7;{const _0x3773b4=y(_0x34db9f),_0x393a1e=(this['children']['get'](_0x3773b4)||new b(null))['setTree'](S(_0x34db9f),_0x5ea8c7);let _0x16096c;return _0x393a1e['isEmpty']()?_0x16096c=this['children']['remove'](_0x3773b4):_0x16096c=this['children']['insert'](_0x3773b4,_0x393a1e),new b(this['value'],_0x16096c);}}['fold'](_0x9a8426){return this['fold_'](w(),_0x9a8426);}['fold_'](_0x314804,_0x1699c7){const _0x2da89e={};return this['children']['inorderTraversal']((_0x1d22dd,_0x13a265)=>{_0x2da89e[_0x1d22dd]=_0x13a265['fold_'](k(_0x314804,_0x1d22dd),_0x1699c7);}),_0x1699c7(_0x314804,this['value'],_0x2da89e);}['findOnPath'](_0x3cbf5b,_0x10d700){return this['findOnPath_'](_0x3cbf5b,w(),_0x10d700);}['findOnPath_'](_0x4ca12b,_0x5d9bfb,_0x56cc7d){const _0x50ff9e=this['value']?_0x56cc7d(_0x5d9bfb,this['value']):!0x1;if(_0x50ff9e)return _0x50ff9e;if(v(_0x4ca12b))return null;{const _0x443dfe=y(_0x4ca12b),_0x10f8bb=this['children']['get'](_0x443dfe);return _0x10f8bb?_0x10f8bb['findOnPath_'](S(_0x4ca12b),k(_0x5d9bfb,_0x443dfe),_0x56cc7d):null;}}['foreachOnPath'](_0x19bae5,_0xd8bb58){return this['foreachOnPath_'](_0x19bae5,w(),_0xd8bb58);}['foreachOnPath_'](_0x506837,_0x1bcd5b,_0x4f6be9){if(v(_0x506837))return this;{this['value']&&_0x4f6be9(_0x1bcd5b,this['value']);const _0x335928=y(_0x506837),_0x452bfc=this['children']['get'](_0x335928);return _0x452bfc?_0x452bfc['foreachOnPath_'](S(_0x506837),k(_0x1bcd5b,_0x335928),_0x4f6be9):new b(null);}}['foreach'](_0x28b0b7){this['foreach_'](w(),_0x28b0b7);}['foreach_'](_0x32b704,_0x15d9fb){this['children']['inorderTraversal']((_0x549336,_0x4ffb41)=>{_0x4ffb41['foreach_'](k(_0x32b704,_0x549336),_0x15d9fb);}),this['value']&&_0x15d9fb(_0x32b704,this['value']);}['foreachChild'](_0x4a4509){this['children']['inorderTraversal']((_0x1b7d1c,_0x19b3d8)=>{_0x19b3d8['value']&&_0x4a4509(_0x1b7d1c,_0x19b3d8['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x473bca){this['writeTree_']=_0x473bca;}static['empty'](){return new K(new b(null));}}function At(_0x1dfcfb,_0x225904,_0x143967){if(v(_0x225904))return new K(new b(_0x143967));{const _0x1f98e2=_0x1dfcfb['writeTree_']['findRootMostValueAndPath'](_0x225904);if(_0x1f98e2!=null){const _0x1bb8a5=_0x1f98e2['path'];let _0x2a6be8=_0x1f98e2['value'];const _0x18eca2=F(_0x1bb8a5,_0x225904);return _0x2a6be8=_0x2a6be8['updateChild'](_0x18eca2,_0x143967),new K(_0x1dfcfb['writeTree_']['set'](_0x1bb8a5,_0x2a6be8));}else{const _0x30bf81=new b(_0x143967),_0x14f756=_0x1dfcfb['writeTree_']['setTree'](_0x225904,_0x30bf81);return new K(_0x14f756);}}}function bi(_0x1f7475,_0x2e7763,_0x24d819){let _0x69b1e0=_0x1f7475;return x(_0x24d819,(_0x5766c7,_0x1c163e)=>{_0x69b1e0=At(_0x69b1e0,k(_0x2e7763,_0x5766c7),_0x1c163e);}),_0x69b1e0;}function dr(_0x598514,_0x1ea3d9){if(v(_0x1ea3d9))return K['empty']();{const _0x3a2e58=_0x598514['writeTree_']['setTree'](_0x1ea3d9,new b(null));return new K(_0x3a2e58);}}function Ri(_0x17207f,_0x445000){return ze(_0x17207f,_0x445000)!=null;}function ze(_0x32a8c2,_0x48a3a4){const _0x278da6=_0x32a8c2['writeTree_']['findRootMostValueAndPath'](_0x48a3a4);return _0x278da6!=null?_0x32a8c2['writeTree_']['get'](_0x278da6['path'])['getChild'](F(_0x278da6['path'],_0x48a3a4)):null;}function fr(_0xb583e1){const _0x170a7d=[],_0x34d324=_0xb583e1['writeTree_']['value'];return _0x34d324!=null?_0x34d324['isLeafNode']()||_0x34d324['forEachChild'](R,(_0x5db0c1,_0x1837a5)=>{_0x170a7d['push'](new E(_0x5db0c1,_0x1837a5));}):_0xb583e1['writeTree_']['children']['inorderTraversal']((_0x33b266,_0x3be3fd)=>{_0x3be3fd['value']!=null&&_0x170a7d['push'](new E(_0x33b266,_0x3be3fd['value']));}),_0x170a7d;}function ve(_0x113028,_0x1e24d7){if(v(_0x1e24d7))return _0x113028;{const _0x424148=ze(_0x113028,_0x1e24d7);return _0x424148!=null?new K(new b(_0x424148)):new K(_0x113028['writeTree_']['subtree'](_0x1e24d7));}}function Ai(_0xfa45f4){return _0xfa45f4['writeTree_']['isEmpty']();}function at(_0x2d6932,_0x2c0e57){return $o(w(),_0x2d6932['writeTree_'],_0x2c0e57);}function $o(_0x453b73,_0x5153e2,_0x4c3d4d){if(_0x5153e2['value']!=null)return _0x4c3d4d['updateChild'](_0x453b73,_0x5153e2['value']);{let _0x2c172f=null;return _0x5153e2['children']['inorderTraversal']((_0x461ce6,_0x43dd27)=>{_0x461ce6==='.priority'?(f(_0x43dd27['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2c172f=_0x43dd27['value']):_0x4c3d4d=$o(k(_0x453b73,_0x461ce6),_0x43dd27,_0x4c3d4d);}),!_0x4c3d4d['getChild'](_0x453b73)['isEmpty']()&&_0x2c172f!==null&&(_0x4c3d4d=_0x4c3d4d['updateChild'](k(_0x453b73,'.priority'),_0x2c172f)),_0x4c3d4d;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Bn(_0x43c40e,_0x3fc39d){return jo(_0x3fc39d,_0x43c40e);}function uu(_0x3e6518,_0x2acadf,_0x1a15ef,_0x21b734,_0x5f08be){f(_0x21b734>_0x3e6518['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x5f08be===void 0x0&&(_0x5f08be=!0x0),_0x3e6518['allWrites']['push']({'path':_0x2acadf,'snap':_0x1a15ef,'writeId':_0x21b734,'visible':_0x5f08be}),_0x5f08be&&(_0x3e6518['visibleWrites']=At(_0x3e6518['visibleWrites'],_0x2acadf,_0x1a15ef)),_0x3e6518['lastWriteId']=_0x21b734;}function du(_0x5d56d2,_0x3e804a,_0x48a98e,_0x1999b1){f(_0x1999b1>_0x5d56d2['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x5d56d2['allWrites']['push']({'path':_0x3e804a,'children':_0x48a98e,'writeId':_0x1999b1,'visible':!0x0}),_0x5d56d2['visibleWrites']=bi(_0x5d56d2['visibleWrites'],_0x3e804a,_0x48a98e),_0x5d56d2['lastWriteId']=_0x1999b1;}function fu(_0x17cbf7,_0x4990fb){for(let _0x4673cc=0x0;_0x4673cc<_0x17cbf7['allWrites']['length'];_0x4673cc++){const _0x377df3=_0x17cbf7['allWrites'][_0x4673cc];if(_0x377df3['writeId']===_0x4990fb)return _0x377df3;}return null;}function pu(_0x2d77a1,_0x5eac14){const _0xcfe022=_0x2d77a1['allWrites']['findIndex'](_0x358ba7=>_0x358ba7['writeId']===_0x5eac14);f(_0xcfe022>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x2c2a72=_0x2d77a1['allWrites'][_0xcfe022];_0x2d77a1['allWrites']['splice'](_0xcfe022,0x1);let _0x2337a9=_0x2c2a72['visible'],_0x5db920=!0x1,_0x2aa473=_0x2d77a1['allWrites']['length']-0x1;for(;_0x2337a9&&_0x2aa473>=0x0;){const _0xdccb44=_0x2d77a1['allWrites'][_0x2aa473];_0xdccb44['visible']&&(_0x2aa473>=_0xcfe022&&_u(_0xdccb44,_0x2c2a72['path'])?_0x2337a9=!0x1:G(_0x2c2a72['path'],_0xdccb44['path'])&&(_0x5db920=!0x0)),_0x2aa473--;}if(_0x2337a9){if(_0x5db920)return gu(_0x2d77a1),!0x0;if(_0x2c2a72['snap'])_0x2d77a1['visibleWrites']=dr(_0x2d77a1['visibleWrites'],_0x2c2a72['path']);else{const _0x2975fd=_0x2c2a72['children'];x(_0x2975fd,_0x9de3a6=>{_0x2d77a1['visibleWrites']=dr(_0x2d77a1['visibleWrites'],k(_0x2c2a72['path'],_0x9de3a6));});}return!0x0;}else return!0x1;}function _u(_0x49579b,_0x565405){if(_0x49579b['snap'])return G(_0x49579b['path'],_0x565405);for(const _0x4d743a in _0x49579b['children'])if(_0x49579b['children']['hasOwnProperty'](_0x4d743a)&&G(k(_0x49579b['path'],_0x4d743a),_0x565405))return!0x0;return!0x1;}function gu(_0x494ad5){_0x494ad5['visibleWrites']=Go(_0x494ad5['allWrites'],mu,w()),_0x494ad5['allWrites']['length']>0x0?_0x494ad5['lastWriteId']=_0x494ad5['allWrites'][_0x494ad5['allWrites']['length']-0x1]['writeId']:_0x494ad5['lastWriteId']=-0x1;}function mu(_0x55a62a){return _0x55a62a['visible'];}function Go(_0x1f1c2a,_0x283872,_0x2868e){let _0x4442a9=K['empty']();for(let _0x5e923c=0x0;_0x5e923c<_0x1f1c2a['length'];++_0x5e923c){const _0x509a7f=_0x1f1c2a[_0x5e923c];if(_0x283872(_0x509a7f)){const _0x4ec025=_0x509a7f['path'];let _0x4496a7;if(_0x509a7f['snap'])G(_0x2868e,_0x4ec025)?(_0x4496a7=F(_0x2868e,_0x4ec025),_0x4442a9=At(_0x4442a9,_0x4496a7,_0x509a7f['snap'])):G(_0x4ec025,_0x2868e)&&(_0x4496a7=F(_0x4ec025,_0x2868e),_0x4442a9=At(_0x4442a9,w(),_0x509a7f['snap']['getChild'](_0x4496a7)));else{if(_0x509a7f['children']){if(G(_0x2868e,_0x4ec025))_0x4496a7=F(_0x2868e,_0x4ec025),_0x4442a9=bi(_0x4442a9,_0x4496a7,_0x509a7f['children']);else{if(G(_0x4ec025,_0x2868e)){if(_0x4496a7=F(_0x4ec025,_0x2868e),v(_0x4496a7))_0x4442a9=bi(_0x4442a9,w(),_0x509a7f['children']);else{const _0x40e15d=Le(_0x509a7f['children'],y(_0x4496a7));if(_0x40e15d){const _0x188b37=_0x40e15d['getChild'](S(_0x4496a7));_0x4442a9=At(_0x4442a9,w(),_0x188b37);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x4442a9;}function qo(_0x21ac58,_0x38ee86,_0x5ee4e4,_0x3590a4,_0x3870b8){if(!_0x3590a4&&!_0x3870b8){const _0x369f0b=ze(_0x21ac58['visibleWrites'],_0x38ee86);if(_0x369f0b!=null)return _0x369f0b;{const _0x977eb8=ve(_0x21ac58['visibleWrites'],_0x38ee86);if(Ai(_0x977eb8))return _0x5ee4e4;if(_0x5ee4e4==null&&!Ri(_0x977eb8,w()))return null;{const _0x388583=_0x5ee4e4||g['EMPTY_NODE'];return at(_0x977eb8,_0x388583);}}}else{const _0x347464=ve(_0x21ac58['visibleWrites'],_0x38ee86);if(!_0x3870b8&&Ai(_0x347464))return _0x5ee4e4;if(!_0x3870b8&&_0x5ee4e4==null&&!Ri(_0x347464,w()))return null;{const _0x37856a=function(_0x263a58){return(_0x263a58['visible']||_0x3870b8)&&(!_0x3590a4||!~_0x3590a4['indexOf'](_0x263a58['writeId']))&&(G(_0x263a58['path'],_0x38ee86)||G(_0x38ee86,_0x263a58['path']));},_0x5a47be=Go(_0x21ac58['allWrites'],_0x37856a,_0x38ee86),_0x383d33=_0x5ee4e4||g['EMPTY_NODE'];return at(_0x5a47be,_0x383d33);}}}function yu(_0x54918e,_0x38491a,_0x1bfd19){let _0x1c5cc5=g['EMPTY_NODE'];const _0x394203=ze(_0x54918e['visibleWrites'],_0x38491a);if(_0x394203)return _0x394203['isLeafNode']()||_0x394203['forEachChild'](R,(_0x2f7888,_0x5e5e90)=>{_0x1c5cc5=_0x1c5cc5['updateImmediateChild'](_0x2f7888,_0x5e5e90);}),_0x1c5cc5;if(_0x1bfd19){const _0x4efa48=ve(_0x54918e['visibleWrites'],_0x38491a);return _0x1bfd19['forEachChild'](R,(_0x4ae228,_0x17e137)=>{const _0x386179=at(ve(_0x4efa48,new C(_0x4ae228)),_0x17e137);_0x1c5cc5=_0x1c5cc5['updateImmediateChild'](_0x4ae228,_0x386179);}),fr(_0x4efa48)['forEach'](_0x1d8ca=>{_0x1c5cc5=_0x1c5cc5['updateImmediateChild'](_0x1d8ca['name'],_0x1d8ca['node']);}),_0x1c5cc5;}else{const _0x647414=ve(_0x54918e['visibleWrites'],_0x38491a);return fr(_0x647414)['forEach'](_0x2efb51=>{_0x1c5cc5=_0x1c5cc5['updateImmediateChild'](_0x2efb51['name'],_0x2efb51['node']);}),_0x1c5cc5;}}function vu(_0x2e5f18,_0x2e3d9d,_0x1e2491,_0x17d922,_0x34ddc1){f(_0x17d922||_0x34ddc1,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x2d7c11=k(_0x2e3d9d,_0x1e2491);if(Ri(_0x2e5f18['visibleWrites'],_0x2d7c11))return null;{const _0xa0fe27=ve(_0x2e5f18['visibleWrites'],_0x2d7c11);return Ai(_0xa0fe27)?_0x34ddc1['getChild'](_0x1e2491):at(_0xa0fe27,_0x34ddc1['getChild'](_0x1e2491));}}function Eu(_0x1464cf,_0x485e7e,_0x592203,_0x1d591f){const _0x28fb00=k(_0x485e7e,_0x592203),_0x578a35=ze(_0x1464cf['visibleWrites'],_0x28fb00);if(_0x578a35!=null)return _0x578a35;if(_0x1d591f['isCompleteForChild'](_0x592203)){const _0x41bea1=ve(_0x1464cf['visibleWrites'],_0x28fb00);return at(_0x41bea1,_0x1d591f['getNode']()['getImmediateChild'](_0x592203));}else return null;}function Iu(_0x586115,_0x18baac){return ze(_0x586115['visibleWrites'],_0x18baac);}function wu(_0x5941d6,_0xb34e33,_0x18ff20,_0x4429f3,_0x1cf5d4,_0x36f1f4,_0x112ba6){let _0x4392ab;const _0xac3fe=ve(_0x5941d6['visibleWrites'],_0xb34e33),_0xc3ec9b=ze(_0xac3fe,w());if(_0xc3ec9b!=null)_0x4392ab=_0xc3ec9b;else{if(_0x18ff20!=null)_0x4392ab=at(_0xac3fe,_0x18ff20);else return[];}if(_0x4392ab=_0x4392ab['withIndex'](_0x112ba6),!_0x4392ab['isEmpty']()&&!_0x4392ab['isLeafNode']()){const _0x31ad7b=[],_0x33e414=_0x112ba6['getCompare'](),_0x406528=_0x36f1f4?_0x4392ab['getReverseIteratorFrom'](_0x4429f3,_0x112ba6):_0x4392ab['getIteratorFrom'](_0x4429f3,_0x112ba6);let _0x56e4ee=_0x406528['getNext']();for(;_0x56e4ee&&_0x31ad7b['length']<_0x1cf5d4;)_0x33e414(_0x56e4ee,_0x4429f3)!==0x0&&_0x31ad7b['push'](_0x56e4ee),_0x56e4ee=_0x406528['getNext']();return _0x31ad7b;}else return[];}function Cu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Tn(_0x160522,_0x5797ec,_0x4782c9,_0x5e7d4f){return qo(_0x160522['writeTree'],_0x160522['treePath'],_0x5797ec,_0x4782c9,_0x5e7d4f);}function is(_0x4bc0ec,_0x36529a){return yu(_0x4bc0ec['writeTree'],_0x4bc0ec['treePath'],_0x36529a);}function pr(_0x251abd,_0x55cb08,_0x434b6d,_0x336bf4){return vu(_0x251abd['writeTree'],_0x251abd['treePath'],_0x55cb08,_0x434b6d,_0x336bf4);}function Sn(_0x2d378d,_0x460bd7){return Iu(_0x2d378d['writeTree'],k(_0x2d378d['treePath'],_0x460bd7));}function Tu(_0x589d4a,_0x26312e,_0x4bb5e8,_0x609c8f,_0xb1c6a9,_0x446d1a){return wu(_0x589d4a['writeTree'],_0x589d4a['treePath'],_0x26312e,_0x4bb5e8,_0x609c8f,_0xb1c6a9,_0x446d1a);}function ss(_0x5ee69e,_0x5a686e,_0x1adc16){return Eu(_0x5ee69e['writeTree'],_0x5ee69e['treePath'],_0x5a686e,_0x1adc16);}function zo(_0x8b836,_0x320120){return jo(k(_0x8b836['treePath'],_0x320120),_0x8b836['writeTree']);}function jo(_0x4c589b,_0x24de80){return{'treePath':_0x4c589b,'writeTree':_0x24de80};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Su{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x26bea5){const _0x497f4c=_0x26bea5['type'],_0x2255f2=_0x26bea5['childName'];f(_0x497f4c==='child_added'||_0x497f4c==='child_changed'||_0x497f4c==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2255f2!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x570d08=this['changeMap']['get'](_0x2255f2);if(_0x570d08){const _0x42cc15=_0x570d08['type'];if(_0x497f4c==='child_added'&&_0x42cc15==='child_removed')this['changeMap']['set'](_0x2255f2,xt(_0x2255f2,_0x26bea5['snapshotNode'],_0x570d08['snapshotNode']));else{if(_0x497f4c==='child_removed'&&_0x42cc15==='child_added')this['changeMap']['delete'](_0x2255f2);else{if(_0x497f4c==='child_removed'&&_0x42cc15==='child_changed')this['changeMap']['set'](_0x2255f2,Lt(_0x2255f2,_0x570d08['oldSnap']));else{if(_0x497f4c==='child_changed'&&_0x42cc15==='child_added')this['changeMap']['set'](_0x2255f2,rt(_0x2255f2,_0x26bea5['snapshotNode']));else{if(_0x497f4c==='child_changed'&&_0x42cc15==='child_changed')this['changeMap']['set'](_0x2255f2,xt(_0x2255f2,_0x26bea5['snapshotNode'],_0x570d08['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x26bea5+'\x20occurred\x20after\x20'+_0x570d08);}}}}}else this['changeMap']['set'](_0x2255f2,_0x26bea5);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bu{['getCompleteChild'](_0x58001c){return null;}['getChildAfterChild'](_0x95970a,_0x44e992,_0x1cd0e7){return null;}}const Ko=new bu();class rs{constructor(_0x350fe0,_0x297936,_0x357d59=null){this['writes_']=_0x350fe0,this['viewCache_']=_0x297936,this['optCompleteServerCache_']=_0x357d59;}['getCompleteChild'](_0x506e29){const _0x2b954b=this['viewCache_']['eventCache'];if(_0x2b954b['isCompleteForChild'](_0x506e29))return _0x2b954b['getNode']()['getImmediateChild'](_0x506e29);{const _0x5ca41f=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x506e29,_0x5ca41f);}}['getChildAfterChild'](_0x283db5,_0x211806,_0x3cd35f){const _0x5baaa5=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x9d6636=Tu(this['writes_'],_0x5baaa5,_0x211806,0x1,_0x3cd35f,_0x283db5);return _0x9d6636['length']===0x0?null:_0x9d6636[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ru(_0x1f0983){return{'filter':_0x1f0983};}function Au(_0x442e0a,_0x43a16b){f(_0x43a16b['eventCache']['getNode']()['isIndexed'](_0x442e0a['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x43a16b['serverCache']['getNode']()['isIndexed'](_0x442e0a['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function ku(_0x5f5202,_0x1cf485,_0x5e4d68,_0x1fb6a1,_0x617b72){const _0x4490f8=new Su();let _0x1d2299,_0x469ade;if(_0x5e4d68['type']===z['OVERWRITE']){const _0x5d5828=_0x5e4d68;_0x5d5828['source']['fromUser']?_0x1d2299=ki(_0x5f5202,_0x1cf485,_0x5d5828['path'],_0x5d5828['snap'],_0x1fb6a1,_0x617b72,_0x4490f8):(f(_0x5d5828['source']['fromServer'],'Unknown\x20source.'),_0x469ade=_0x5d5828['source']['tagged']||_0x1cf485['serverCache']['isFiltered']()&&!v(_0x5d5828['path']),_0x1d2299=bn(_0x5f5202,_0x1cf485,_0x5d5828['path'],_0x5d5828['snap'],_0x1fb6a1,_0x617b72,_0x469ade,_0x4490f8));}else{if(_0x5e4d68['type']===z['MERGE']){const _0x237401=_0x5e4d68;_0x237401['source']['fromUser']?_0x1d2299=Pu(_0x5f5202,_0x1cf485,_0x237401['path'],_0x237401['children'],_0x1fb6a1,_0x617b72,_0x4490f8):(f(_0x237401['source']['fromServer'],'Unknown\x20source.'),_0x469ade=_0x237401['source']['tagged']||_0x1cf485['serverCache']['isFiltered'](),_0x1d2299=Ni(_0x5f5202,_0x1cf485,_0x237401['path'],_0x237401['children'],_0x1fb6a1,_0x617b72,_0x469ade,_0x4490f8));}else{if(_0x5e4d68['type']===z['ACK_USER_WRITE']){const _0x504476=_0x5e4d68;_0x504476['revert']?_0x1d2299=Mu(_0x5f5202,_0x1cf485,_0x504476['path'],_0x1fb6a1,_0x617b72,_0x4490f8):_0x1d2299=Ou(_0x5f5202,_0x1cf485,_0x504476['path'],_0x504476['affectedTree'],_0x1fb6a1,_0x617b72,_0x4490f8);}else{if(_0x5e4d68['type']===z['LISTEN_COMPLETE'])_0x1d2299=Du(_0x5f5202,_0x1cf485,_0x5e4d68['path'],_0x1fb6a1,_0x4490f8);else throw ht('Unknown\x20operation\x20type:\x20'+_0x5e4d68['type']);}}}const _0x290afb=_0x4490f8['getChanges']();return Nu(_0x1cf485,_0x1d2299,_0x290afb),{'viewCache':_0x1d2299,'changes':_0x290afb};}function Nu(_0x2a2f46,_0x3f1ff4,_0x9cfb1c){const _0x3b2f15=_0x3f1ff4['eventCache'];if(_0x3b2f15['isFullyInitialized']()){const _0x5647de=_0x3b2f15['getNode']()['isLeafNode']()||_0x3b2f15['getNode']()['isEmpty'](),_0x35ecbe=Cn(_0x2a2f46);(_0x9cfb1c['length']>0x0||!_0x2a2f46['eventCache']['isFullyInitialized']()||_0x5647de&&!_0x3b2f15['getNode']()['equals'](_0x35ecbe)||!_0x3b2f15['getNode']()['getPriority']()['equals'](_0x35ecbe['getPriority']()))&&_0x9cfb1c['push'](Vo(Cn(_0x3f1ff4)));}}function Yo(_0xc9f4dd,_0x4e5a0d,_0xc8110c,_0x2350f7,_0x49fa41,_0x5da764){const _0x248898=_0x4e5a0d['eventCache'];if(Sn(_0x2350f7,_0xc8110c)!=null)return _0x4e5a0d;{let _0xaa74a6,_0x1e76f7;if(v(_0xc8110c)){if(f(_0x4e5a0d['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x4e5a0d['serverCache']['isFiltered']()){const _0x5c580e=Ve(_0x4e5a0d),_0x39e5cc=_0x5c580e instanceof g?_0x5c580e:g['EMPTY_NODE'],_0x50448c=is(_0x2350f7,_0x39e5cc);_0xaa74a6=_0xc9f4dd['filter']['updateFullNode'](_0x4e5a0d['eventCache']['getNode'](),_0x50448c,_0x5da764);}else{const _0x3541bd=Tn(_0x2350f7,Ve(_0x4e5a0d));_0xaa74a6=_0xc9f4dd['filter']['updateFullNode'](_0x4e5a0d['eventCache']['getNode'](),_0x3541bd,_0x5da764);}}else{const _0x3ad05c=y(_0xc8110c);if(_0x3ad05c==='.priority'){f(we(_0xc8110c)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x5a536d=_0x248898['getNode']();_0x1e76f7=_0x4e5a0d['serverCache']['getNode']();const _0xe38891=pr(_0x2350f7,_0xc8110c,_0x5a536d,_0x1e76f7);_0xe38891!=null?_0xaa74a6=_0xc9f4dd['filter']['updatePriority'](_0x5a536d,_0xe38891):_0xaa74a6=_0x248898['getNode']();}else{const _0x24d2ce=S(_0xc8110c);let _0x39bb64;if(_0x248898['isCompleteForChild'](_0x3ad05c)){_0x1e76f7=_0x4e5a0d['serverCache']['getNode']();const _0x54c8c3=pr(_0x2350f7,_0xc8110c,_0x248898['getNode'](),_0x1e76f7);_0x54c8c3!=null?_0x39bb64=_0x248898['getNode']()['getImmediateChild'](_0x3ad05c)['updateChild'](_0x24d2ce,_0x54c8c3):_0x39bb64=_0x248898['getNode']()['getImmediateChild'](_0x3ad05c);}else _0x39bb64=ss(_0x2350f7,_0x3ad05c,_0x4e5a0d['serverCache']);_0x39bb64!=null?_0xaa74a6=_0xc9f4dd['filter']['updateChild'](_0x248898['getNode'](),_0x3ad05c,_0x39bb64,_0x24d2ce,_0x49fa41,_0x5da764):_0xaa74a6=_0x248898['getNode']();}}return Rt(_0x4e5a0d,_0xaa74a6,_0x248898['isFullyInitialized']()||v(_0xc8110c),_0xc9f4dd['filter']['filtersNodes']());}}function bn(_0x416d5b,_0x28fff4,_0x4890c4,_0xe0bdf4,_0x2433ca,_0xcc86dd,_0x2c6cd5,_0x1ec68b){const _0x27cf0d=_0x28fff4['serverCache'];let _0x4aefaf;const _0x5a8913=_0x2c6cd5?_0x416d5b['filter']:_0x416d5b['filter']['getIndexedFilter']();if(v(_0x4890c4))_0x4aefaf=_0x5a8913['updateFullNode'](_0x27cf0d['getNode'](),_0xe0bdf4,null);else{if(_0x5a8913['filtersNodes']()&&!_0x27cf0d['isFiltered']()){const _0x72117=_0x27cf0d['getNode']()['updateChild'](_0x4890c4,_0xe0bdf4);_0x4aefaf=_0x5a8913['updateFullNode'](_0x27cf0d['getNode'](),_0x72117,null);}else{const _0xa759c8=y(_0x4890c4);if(!_0x27cf0d['isCompleteForPath'](_0x4890c4)&&we(_0x4890c4)>0x1)return _0x28fff4;const _0x16eca4=S(_0x4890c4),_0xd96753=_0x27cf0d['getNode']()['getImmediateChild'](_0xa759c8)['updateChild'](_0x16eca4,_0xe0bdf4);_0xa759c8==='.priority'?_0x4aefaf=_0x5a8913['updatePriority'](_0x27cf0d['getNode'](),_0xd96753):_0x4aefaf=_0x5a8913['updateChild'](_0x27cf0d['getNode'](),_0xa759c8,_0xd96753,_0x16eca4,Ko,null);}}const _0x57e5f4=Ho(_0x28fff4,_0x4aefaf,_0x27cf0d['isFullyInitialized']()||v(_0x4890c4),_0x5a8913['filtersNodes']()),_0x207fb9=new rs(_0x2433ca,_0x57e5f4,_0xcc86dd);return Yo(_0x416d5b,_0x57e5f4,_0x4890c4,_0x2433ca,_0x207fb9,_0x1ec68b);}function ki(_0x134af4,_0x279153,_0x52695f,_0x231999,_0x5332bb,_0x3d13b0,_0x4aeabc){const _0x56b3e7=_0x279153['eventCache'];let _0x435c3c,_0x35f966;const _0x304102=new rs(_0x5332bb,_0x279153,_0x3d13b0);if(v(_0x52695f))_0x35f966=_0x134af4['filter']['updateFullNode'](_0x279153['eventCache']['getNode'](),_0x231999,_0x4aeabc),_0x435c3c=Rt(_0x279153,_0x35f966,!0x0,_0x134af4['filter']['filtersNodes']());else{const _0x3bb9cb=y(_0x52695f);if(_0x3bb9cb==='.priority')_0x35f966=_0x134af4['filter']['updatePriority'](_0x279153['eventCache']['getNode'](),_0x231999),_0x435c3c=Rt(_0x279153,_0x35f966,_0x56b3e7['isFullyInitialized'](),_0x56b3e7['isFiltered']());else{const _0x332eb9=S(_0x52695f),_0x4e5517=_0x56b3e7['getNode']()['getImmediateChild'](_0x3bb9cb);let _0x5b2c0d;if(v(_0x332eb9))_0x5b2c0d=_0x231999;else{const _0x2146f1=_0x304102['getCompleteChild'](_0x3bb9cb);_0x2146f1!=null?ji(_0x332eb9)==='.priority'&&_0x2146f1['getChild'](Do(_0x332eb9))['isEmpty']()?_0x5b2c0d=_0x2146f1:_0x5b2c0d=_0x2146f1['updateChild'](_0x332eb9,_0x231999):_0x5b2c0d=g['EMPTY_NODE'];}if(_0x4e5517['equals'](_0x5b2c0d))_0x435c3c=_0x279153;else{const _0x1a3d40=_0x134af4['filter']['updateChild'](_0x56b3e7['getNode'](),_0x3bb9cb,_0x5b2c0d,_0x332eb9,_0x304102,_0x4aeabc);_0x435c3c=Rt(_0x279153,_0x1a3d40,_0x56b3e7['isFullyInitialized'](),_0x134af4['filter']['filtersNodes']());}}}return _0x435c3c;}function _r(_0x536e7e,_0xd627f1){return _0x536e7e['eventCache']['isCompleteForChild'](_0xd627f1);}function Pu(_0x34b101,_0x47a959,_0x3057eb,_0x237ce2,_0x14a3b8,_0x26b0a8,_0x5c1d23){let _0x45b7e8=_0x47a959;return _0x237ce2['foreach']((_0x1562ec,_0x2b7746)=>{const _0x51af9c=k(_0x3057eb,_0x1562ec);_r(_0x47a959,y(_0x51af9c))&&(_0x45b7e8=ki(_0x34b101,_0x45b7e8,_0x51af9c,_0x2b7746,_0x14a3b8,_0x26b0a8,_0x5c1d23));}),_0x237ce2['foreach']((_0xa21b1,_0x17e114)=>{const _0x3c26eb=k(_0x3057eb,_0xa21b1);_r(_0x47a959,y(_0x3c26eb))||(_0x45b7e8=ki(_0x34b101,_0x45b7e8,_0x3c26eb,_0x17e114,_0x14a3b8,_0x26b0a8,_0x5c1d23));}),_0x45b7e8;}function gr(_0x3a8830,_0x5ee7d3,_0x5a529b){return _0x5a529b['foreach']((_0x106a74,_0x31c8e2)=>{_0x5ee7d3=_0x5ee7d3['updateChild'](_0x106a74,_0x31c8e2);}),_0x5ee7d3;}function Ni(_0x379856,_0x4f3481,_0x488b4d,_0x3e1e1f,_0x4ab5d1,_0xe8158c,_0x148a7f,_0x5da3f6){if(_0x4f3481['serverCache']['getNode']()['isEmpty']()&&!_0x4f3481['serverCache']['isFullyInitialized']())return _0x4f3481;let _0x2dc0a2=_0x4f3481,_0xb0820;v(_0x488b4d)?_0xb0820=_0x3e1e1f:_0xb0820=new b(null)['setTree'](_0x488b4d,_0x3e1e1f);const _0x10ffb6=_0x4f3481['serverCache']['getNode']();return _0xb0820['children']['inorderTraversal']((_0x2da3d4,_0x20e82e)=>{if(_0x10ffb6['hasChild'](_0x2da3d4)){const _0x22a9f8=_0x4f3481['serverCache']['getNode']()['getImmediateChild'](_0x2da3d4),_0x166448=gr(_0x379856,_0x22a9f8,_0x20e82e);_0x2dc0a2=bn(_0x379856,_0x2dc0a2,new C(_0x2da3d4),_0x166448,_0x4ab5d1,_0xe8158c,_0x148a7f,_0x5da3f6);}}),_0xb0820['children']['inorderTraversal']((_0xcce6e4,_0x4482b4)=>{const _0x40dd52=!_0x4f3481['serverCache']['isCompleteForChild'](_0xcce6e4)&&_0x4482b4['value']===null;if(!_0x10ffb6['hasChild'](_0xcce6e4)&&!_0x40dd52){const _0x50b05c=_0x4f3481['serverCache']['getNode']()['getImmediateChild'](_0xcce6e4),_0x331288=gr(_0x379856,_0x50b05c,_0x4482b4);_0x2dc0a2=bn(_0x379856,_0x2dc0a2,new C(_0xcce6e4),_0x331288,_0x4ab5d1,_0xe8158c,_0x148a7f,_0x5da3f6);}}),_0x2dc0a2;}function Ou(_0x51af52,_0x24df20,_0x357b5b,_0x5bd7b3,_0x4b44fc,_0x3bd6b4,_0x400204){if(Sn(_0x4b44fc,_0x357b5b)!=null)return _0x24df20;const _0x3e8370=_0x24df20['serverCache']['isFiltered'](),_0x495d55=_0x24df20['serverCache'];if(_0x5bd7b3['value']!=null){if(v(_0x357b5b)&&_0x495d55['isFullyInitialized']()||_0x495d55['isCompleteForPath'](_0x357b5b))return bn(_0x51af52,_0x24df20,_0x357b5b,_0x495d55['getNode']()['getChild'](_0x357b5b),_0x4b44fc,_0x3bd6b4,_0x3e8370,_0x400204);if(v(_0x357b5b)){let _0x1ff1c1=new b(null);return _0x495d55['getNode']()['forEachChild'](Me,(_0x34ff0a,_0x1592da)=>{_0x1ff1c1=_0x1ff1c1['set'](new C(_0x34ff0a),_0x1592da);}),Ni(_0x51af52,_0x24df20,_0x357b5b,_0x1ff1c1,_0x4b44fc,_0x3bd6b4,_0x3e8370,_0x400204);}else return _0x24df20;}else{let _0x246e49=new b(null);return _0x5bd7b3['foreach']((_0x381088,_0x26b392)=>{const _0x2590cf=k(_0x357b5b,_0x381088);_0x495d55['isCompleteForPath'](_0x2590cf)&&(_0x246e49=_0x246e49['set'](_0x381088,_0x495d55['getNode']()['getChild'](_0x2590cf)));}),Ni(_0x51af52,_0x24df20,_0x357b5b,_0x246e49,_0x4b44fc,_0x3bd6b4,_0x3e8370,_0x400204);}}function Du(_0xfb2cb8,_0x274d39,_0x439a39,_0x2e7fdc,_0x4e92d9){const _0x5f41b0=_0x274d39['serverCache'],_0x42542a=Ho(_0x274d39,_0x5f41b0['getNode'](),_0x5f41b0['isFullyInitialized']()||v(_0x439a39),_0x5f41b0['isFiltered']());return Yo(_0xfb2cb8,_0x42542a,_0x439a39,_0x2e7fdc,Ko,_0x4e92d9);}function Mu(_0x4fc332,_0xb8c851,_0x596a56,_0x605538,_0x4578d2,_0xba71a){let _0x5137f6;if(Sn(_0x605538,_0x596a56)!=null)return _0xb8c851;{const _0x4a0f88=new rs(_0x605538,_0xb8c851,_0x4578d2),_0x1d0894=_0xb8c851['eventCache']['getNode']();let _0x12d8c8;if(v(_0x596a56)||y(_0x596a56)==='.priority'){let _0x38abf6;if(_0xb8c851['serverCache']['isFullyInitialized']())_0x38abf6=Tn(_0x605538,Ve(_0xb8c851));else{const _0x3a5d5a=_0xb8c851['serverCache']['getNode']();f(_0x3a5d5a instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x38abf6=is(_0x605538,_0x3a5d5a);}_0x38abf6=_0x38abf6,_0x12d8c8=_0x4fc332['filter']['updateFullNode'](_0x1d0894,_0x38abf6,_0xba71a);}else{const _0x3d4d6a=y(_0x596a56);let _0x5356bf=ss(_0x605538,_0x3d4d6a,_0xb8c851['serverCache']);_0x5356bf==null&&_0xb8c851['serverCache']['isCompleteForChild'](_0x3d4d6a)&&(_0x5356bf=_0x1d0894['getImmediateChild'](_0x3d4d6a)),_0x5356bf!=null?_0x12d8c8=_0x4fc332['filter']['updateChild'](_0x1d0894,_0x3d4d6a,_0x5356bf,S(_0x596a56),_0x4a0f88,_0xba71a):_0xb8c851['eventCache']['getNode']()['hasChild'](_0x3d4d6a)?_0x12d8c8=_0x4fc332['filter']['updateChild'](_0x1d0894,_0x3d4d6a,g['EMPTY_NODE'],S(_0x596a56),_0x4a0f88,_0xba71a):_0x12d8c8=_0x1d0894,_0x12d8c8['isEmpty']()&&_0xb8c851['serverCache']['isFullyInitialized']()&&(_0x5137f6=Tn(_0x605538,Ve(_0xb8c851)),_0x5137f6['isLeafNode']()&&(_0x12d8c8=_0x4fc332['filter']['updateFullNode'](_0x12d8c8,_0x5137f6,_0xba71a)));}return _0x5137f6=_0xb8c851['serverCache']['isFullyInitialized']()||Sn(_0x605538,w())!=null,Rt(_0xb8c851,_0x12d8c8,_0x5137f6,_0x4fc332['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lu{constructor(_0x294fdf,_0x256058){this['query_']=_0x294fdf,this['eventRegistrations_']=[];const _0x4d8325=this['query_']['_queryParams'],_0x506c6c=new Xi(_0x4d8325['getIndex']()),_0xc8d4f5=Qh(_0x4d8325);this['processor_']=Ru(_0xc8d4f5);const _0x20596d=_0x256058['serverCache'],_0x2f95e9=_0x256058['eventCache'],_0x216f94=_0x506c6c['updateFullNode'](g['EMPTY_NODE'],_0x20596d['getNode'](),null),_0x552a89=_0xc8d4f5['updateFullNode'](g['EMPTY_NODE'],_0x2f95e9['getNode'](),null),_0x9efa24=new Ce(_0x216f94,_0x20596d['isFullyInitialized'](),_0x506c6c['filtersNodes']()),_0x1d9dc1=new Ce(_0x552a89,_0x2f95e9['isFullyInitialized'](),_0xc8d4f5['filtersNodes']());this['viewCache_']=Wn(_0x1d9dc1,_0x9efa24),this['eventGenerator_']=new ou(this['query_']);}get['query'](){return this['query_'];}}function xu(_0x2cc790){return _0x2cc790['viewCache_']['serverCache']['getNode']();}function Fu(_0x40f405){return Cn(_0x40f405['viewCache_']);}function Uu(_0x50be71,_0x15392a){const _0x9ef9d2=Ve(_0x50be71['viewCache_']);return _0x9ef9d2&&(_0x50be71['query']['_queryParams']['loadsAllData']()||!v(_0x15392a)&&!_0x9ef9d2['getImmediateChild'](y(_0x15392a))['isEmpty']())?_0x9ef9d2['getChild'](_0x15392a):null;}function mr(_0x27852c){return _0x27852c['eventRegistrations_']['length']===0x0;}function Wu(_0x41f559,_0x307e8c){_0x41f559['eventRegistrations_']['push'](_0x307e8c);}function yr(_0x4f205a,_0x4cf308,_0x50ba8b){const _0x504d83=[];if(_0x50ba8b){f(_0x4cf308==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x2c50fe=_0x4f205a['query']['_path'];_0x4f205a['eventRegistrations_']['forEach'](_0x5117b8=>{const _0xe2a595=_0x5117b8['createCancelEvent'](_0x50ba8b,_0x2c50fe);_0xe2a595&&_0x504d83['push'](_0xe2a595);});}if(_0x4cf308){let _0x46d5da=[];for(let _0xc7d632=0x0;_0xc7d632<_0x4f205a['eventRegistrations_']['length'];++_0xc7d632){const _0x401e8b=_0x4f205a['eventRegistrations_'][_0xc7d632];if(!_0x401e8b['matches'](_0x4cf308))_0x46d5da['push'](_0x401e8b);else{if(_0x4cf308['hasAnyCallback']()){_0x46d5da=_0x46d5da['concat'](_0x4f205a['eventRegistrations_']['slice'](_0xc7d632+0x1));break;}}}_0x4f205a['eventRegistrations_']=_0x46d5da;}else _0x4f205a['eventRegistrations_']=[];return _0x504d83;}function vr(_0x4472a2,_0xb26a9a,_0x4e156c,_0x8bbc6c){_0xb26a9a['type']===z['MERGE']&&_0xb26a9a['source']['queryId']!==null&&(f(Ve(_0x4472a2['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(Cn(_0x4472a2['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x3952b6=_0x4472a2['viewCache_'],_0x4f12fe=ku(_0x4472a2['processor_'],_0x3952b6,_0xb26a9a,_0x4e156c,_0x8bbc6c);return Au(_0x4472a2['processor_'],_0x4f12fe['viewCache']),f(_0x4f12fe['viewCache']['serverCache']['isFullyInitialized']()||!_0x3952b6['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x4472a2['viewCache_']=_0x4f12fe['viewCache'],Qo(_0x4472a2,_0x4f12fe['changes'],_0x4f12fe['viewCache']['eventCache']['getNode'](),null);}function Bu(_0x5aea2d,_0x987834){const _0x719a04=_0x5aea2d['viewCache_']['eventCache'],_0x2b8136=[];return _0x719a04['getNode']()['isLeafNode']()||_0x719a04['getNode']()['forEachChild'](R,(_0x59f3b4,_0x21f3eb)=>{_0x2b8136['push'](rt(_0x59f3b4,_0x21f3eb));}),_0x719a04['isFullyInitialized']()&&_0x2b8136['push'](Vo(_0x719a04['getNode']())),Qo(_0x5aea2d,_0x2b8136,_0x719a04['getNode'](),_0x987834);}function Qo(_0x39fa92,_0x4d7e24,_0x249160,_0x5b57ac){const _0x54e7e4=_0x5b57ac?[_0x5b57ac]:_0x39fa92['eventRegistrations_'];return au(_0x39fa92['eventGenerator_'],_0x4d7e24,_0x249160,_0x54e7e4);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;class Jo{constructor(){this['views']=new Map();}}function Vu(_0xcb509f){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0xcb509f;}function Hu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}function $u(_0x44dc88){return _0x44dc88['views']['size']===0x0;}function os(_0x1f3d05,_0x42e52d,_0x5143d3,_0x4aa1c1){const _0xe46d7e=_0x42e52d['source']['queryId'];if(_0xe46d7e!==null){const _0x18abb2=_0x1f3d05['views']['get'](_0xe46d7e);return f(_0x18abb2!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),vr(_0x18abb2,_0x42e52d,_0x5143d3,_0x4aa1c1);}else{let _0xa9ee46=[];for(const _0x4b2266 of _0x1f3d05['views']['values']())_0xa9ee46=_0xa9ee46['concat'](vr(_0x4b2266,_0x42e52d,_0x5143d3,_0x4aa1c1));return _0xa9ee46;}}function Xo(_0x19da13,_0x9b312c,_0x26553c,_0x4392a5,_0x3d1603){const _0x225528=_0x9b312c['_queryIdentifier'],_0xcdad05=_0x19da13['views']['get'](_0x225528);if(!_0xcdad05){let _0x2d8f01=Tn(_0x26553c,_0x3d1603?_0x4392a5:null),_0x2b0e2c=!0x1;_0x2d8f01?_0x2b0e2c=!0x0:_0x4392a5 instanceof g?(_0x2d8f01=is(_0x26553c,_0x4392a5),_0x2b0e2c=!0x1):(_0x2d8f01=g['EMPTY_NODE'],_0x2b0e2c=!0x1);const _0x2e4df1=Wn(new Ce(_0x2d8f01,_0x2b0e2c,!0x1),new Ce(_0x4392a5,_0x3d1603,!0x1));return new Lu(_0x9b312c,_0x2e4df1);}return _0xcdad05;}function Gu(_0x16dc2b,_0x3b4030,_0x37e5e0,_0x404829,_0x38d2f2,_0x188745){const _0x3b23fb=Xo(_0x16dc2b,_0x3b4030,_0x404829,_0x38d2f2,_0x188745);return _0x16dc2b['views']['has'](_0x3b4030['_queryIdentifier'])||_0x16dc2b['views']['set'](_0x3b4030['_queryIdentifier'],_0x3b23fb),Wu(_0x3b23fb,_0x37e5e0),Bu(_0x3b23fb,_0x37e5e0);}function qu(_0x56b01f,_0x57c107,_0x46d69e,_0x384b7c){const _0x55120e=_0x57c107['_queryIdentifier'],_0x407255=[];let _0x8c3853=[];const _0x4b8553=Te(_0x56b01f);if(_0x55120e==='default'){for(const [_0x507c8b,_0x50d918]of _0x56b01f['views']['entries']())_0x8c3853=_0x8c3853['concat'](yr(_0x50d918,_0x46d69e,_0x384b7c)),mr(_0x50d918)&&(_0x56b01f['views']['delete'](_0x507c8b),_0x50d918['query']['_queryParams']['loadsAllData']()||_0x407255['push'](_0x50d918['query']));}else{const _0x10f0f3=_0x56b01f['views']['get'](_0x55120e);_0x10f0f3&&(_0x8c3853=_0x8c3853['concat'](yr(_0x10f0f3,_0x46d69e,_0x384b7c)),mr(_0x10f0f3)&&(_0x56b01f['views']['delete'](_0x55120e),_0x10f0f3['query']['_queryParams']['loadsAllData']()||_0x407255['push'](_0x10f0f3['query'])));}return _0x4b8553&&!Te(_0x56b01f)&&_0x407255['push'](new(Hu())(_0x57c107['_repo'],_0x57c107['_path'])),{'removed':_0x407255,'events':_0x8c3853};}function Zo(_0x421ac2){const _0x1dbeeb=[];for(const _0x3b61f9 of _0x421ac2['views']['values']())_0x3b61f9['query']['_queryParams']['loadsAllData']()||_0x1dbeeb['push'](_0x3b61f9);return _0x1dbeeb;}function Ee(_0x52bfd7,_0x3a8732){let _0x462380=null;for(const _0x1fbe99 of _0x52bfd7['views']['values']())_0x462380=_0x462380||Uu(_0x1fbe99,_0x3a8732);return _0x462380;}function ea(_0x4456a4,_0x309017){if(_0x309017['_queryParams']['loadsAllData']())return Vn(_0x4456a4);{const _0x394f37=_0x309017['_queryIdentifier'];return _0x4456a4['views']['get'](_0x394f37);}}function ta(_0x2ec4f4,_0x560a70){return ea(_0x2ec4f4,_0x560a70)!=null;}function Te(_0x51baba){return Vn(_0x51baba)!=null;}function Vn(_0x42ebb4){for(const _0x5ee934 of _0x42ebb4['views']['values']())if(_0x5ee934['query']['_queryParams']['loadsAllData']())return _0x5ee934;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let An;function zu(_0xdaa964){f(!An,'__referenceConstructor\x20has\x20already\x20been\x20defined'),An=_0xdaa964;}function ju(){return f(An,'Reference.ts\x20has\x20not\x20been\x20loaded'),An;}let Ku=0x1;class Er{constructor(_0x1fcd02){this['listenProvider_']=_0x1fcd02,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Cu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x2b8a1b,_0x3f998c,_0x4ef5f7,_0x41cb05,_0xc59e55){return uu(_0x2b8a1b['pendingWriteTree_'],_0x3f998c,_0x4ef5f7,_0x41cb05,_0xc59e55),_0xc59e55?_t(_0x2b8a1b,new Be(es(),_0x3f998c,_0x4ef5f7)):[];}function Yu(_0x178c89,_0x2c3eef,_0x47fa6e,_0xca2365){du(_0x178c89['pendingWriteTree_'],_0x2c3eef,_0x47fa6e,_0xca2365);const _0x14f95c=b['fromObject'](_0x47fa6e);return _t(_0x178c89,new ot(es(),_0x2c3eef,_0x14f95c));}function _e(_0x4f9e59,_0x4e5c31,_0x48f792=!0x1){const _0x361371=fu(_0x4f9e59['pendingWriteTree_'],_0x4e5c31);if(pu(_0x4f9e59['pendingWriteTree_'],_0x4e5c31)){let _0x2a20ed=new b(null);return _0x361371['snap']!=null?_0x2a20ed=_0x2a20ed['set'](w(),!0x0):x(_0x361371['children'],_0x12e867=>{_0x2a20ed=_0x2a20ed['set'](new C(_0x12e867),!0x0);}),_t(_0x4f9e59,new wn(_0x361371['path'],_0x2a20ed,_0x48f792));}else return[];}function Yt(_0x62899c,_0x158fc9,_0x31a94d){return _t(_0x62899c,new Be(ts(),_0x158fc9,_0x31a94d));}function Qu(_0x1d1acf,_0x2d5564,_0x408848){const _0x288489=b['fromObject'](_0x408848);return _t(_0x1d1acf,new ot(ts(),_0x2d5564,_0x288489));}function Ju(_0x589166,_0x5b0a8e){return _t(_0x589166,new Ut(ts(),_0x5b0a8e));}function Xu(_0x53b555,_0x22bcd8,_0x2513af){const _0xb392b0=cs(_0x53b555,_0x2513af);if(_0xb392b0){const _0x10d621=ls(_0xb392b0),_0x14590d=_0x10d621['path'],_0x546034=_0x10d621['queryId'],_0x39741e=F(_0x14590d,_0x22bcd8),_0x1fc100=new Ut(ns(_0x546034),_0x39741e);return hs(_0x53b555,_0x14590d,_0x1fc100);}else return[];}function kn(_0x1a3fdb,_0x34ef12,_0xa1b78b,_0x2636e8,_0x2ba8e5=!0x1){const _0x4ea932=_0x34ef12['_path'],_0x3b62cf=_0x1a3fdb['syncPointTree_']['get'](_0x4ea932);let _0x29a6b9=[];if(_0x3b62cf&&(_0x34ef12['_queryIdentifier']==='default'||ta(_0x3b62cf,_0x34ef12))){const _0x49e9d1=qu(_0x3b62cf,_0x34ef12,_0xa1b78b,_0x2636e8);$u(_0x3b62cf)&&(_0x1a3fdb['syncPointTree_']=_0x1a3fdb['syncPointTree_']['remove'](_0x4ea932));const _0x4d4f94=_0x49e9d1['removed'];if(_0x29a6b9=_0x49e9d1['events'],!_0x2ba8e5){const _0x4c4b4f=_0x4d4f94['findIndex'](_0x2c5366=>_0x2c5366['_queryParams']['loadsAllData']())!==-0x1,_0x562dc2=_0x1a3fdb['syncPointTree_']['findOnPath'](_0x4ea932,(_0x513491,_0x1e5647)=>Te(_0x1e5647));if(_0x4c4b4f&&!_0x562dc2){const _0x2cf108=_0x1a3fdb['syncPointTree_']['subtree'](_0x4ea932);if(!_0x2cf108['isEmpty']()){const _0x372ae1=td(_0x2cf108);for(let _0x46d792=0x0;_0x46d792<_0x372ae1['length'];++_0x46d792){const _0x387ae5=_0x372ae1[_0x46d792],_0x4779cc=_0x387ae5['query'],_0x751d2d=ra(_0x1a3fdb,_0x387ae5);_0x1a3fdb['listenProvider_']['startListening'](kt(_0x4779cc),Wt(_0x1a3fdb,_0x4779cc),_0x751d2d['hashFn'],_0x751d2d['onComplete']);}}}!_0x562dc2&&_0x4d4f94['length']>0x0&&!_0x2636e8&&(_0x4c4b4f?_0x1a3fdb['listenProvider_']['stopListening'](kt(_0x34ef12),null):_0x4d4f94['forEach'](_0x2b0ab0=>{const _0x2cf1b3=_0x1a3fdb['queryToTagMap']['get']($n(_0x2b0ab0));_0x1a3fdb['listenProvider_']['stopListening'](kt(_0x2b0ab0),_0x2cf1b3);}));}nd(_0x1a3fdb,_0x4d4f94);}return _0x29a6b9;}function na(_0x482ee6,_0x43511b,_0x43e917,_0xb0481d){const _0x2fd671=cs(_0x482ee6,_0xb0481d);if(_0x2fd671!=null){const _0x40636d=ls(_0x2fd671),_0x3957cd=_0x40636d['path'],_0x4f2e9b=_0x40636d['queryId'],_0x409e9f=F(_0x3957cd,_0x43511b),_0x5b3e4d=new Be(ns(_0x4f2e9b),_0x409e9f,_0x43e917);return hs(_0x482ee6,_0x3957cd,_0x5b3e4d);}else return[];}function Zu(_0x234271,_0x219bf4,_0x2d9fd7,_0x5cc1d1){const _0x341525=cs(_0x234271,_0x5cc1d1);if(_0x341525){const _0x5ca422=ls(_0x341525),_0x4e63c0=_0x5ca422['path'],_0x42ab83=_0x5ca422['queryId'],_0x287be4=F(_0x4e63c0,_0x219bf4),_0x4f25d3=b['fromObject'](_0x2d9fd7),_0x1b6f7c=new ot(ns(_0x42ab83),_0x287be4,_0x4f25d3);return hs(_0x234271,_0x4e63c0,_0x1b6f7c);}else return[];}function Pi(_0x41ce87,_0x2ce8fe,_0x59505f,_0x39af37=!0x1){const _0x169279=_0x2ce8fe['_path'];let _0x301696=null,_0x5812b1=!0x1;_0x41ce87['syncPointTree_']['foreachOnPath'](_0x169279,(_0x5623a7,_0x4629c4)=>{const _0x5b736f=F(_0x5623a7,_0x169279);_0x301696=_0x301696||Ee(_0x4629c4,_0x5b736f),_0x5812b1=_0x5812b1||Te(_0x4629c4);});let _0x5df78b=_0x41ce87['syncPointTree_']['get'](_0x169279);_0x5df78b?(_0x5812b1=_0x5812b1||Te(_0x5df78b),_0x301696=_0x301696||Ee(_0x5df78b,w())):(_0x5df78b=new Jo(),_0x41ce87['syncPointTree_']=_0x41ce87['syncPointTree_']['set'](_0x169279,_0x5df78b));let _0x59669f;_0x301696!=null?_0x59669f=!0x0:(_0x59669f=!0x1,_0x301696=g['EMPTY_NODE'],_0x41ce87['syncPointTree_']['subtree'](_0x169279)['foreachChild']((_0x2ed199,_0x4e5cb3)=>{const _0x15f6cb=Ee(_0x4e5cb3,w());_0x15f6cb&&(_0x301696=_0x301696['updateImmediateChild'](_0x2ed199,_0x15f6cb));}));const _0x339c46=ta(_0x5df78b,_0x2ce8fe);if(!_0x339c46&&!_0x2ce8fe['_queryParams']['loadsAllData']()){const _0x77e269=$n(_0x2ce8fe);f(!_0x41ce87['queryToTagMap']['has'](_0x77e269),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x242d40=id();_0x41ce87['queryToTagMap']['set'](_0x77e269,_0x242d40),_0x41ce87['tagToQueryMap']['set'](_0x242d40,_0x77e269);}const _0x3eeb6e=Bn(_0x41ce87['pendingWriteTree_'],_0x169279);let _0x1b5936=Gu(_0x5df78b,_0x2ce8fe,_0x59505f,_0x3eeb6e,_0x301696,_0x59669f);if(!_0x339c46&&!_0x5812b1&&!_0x39af37){const _0x5b938d=ea(_0x5df78b,_0x2ce8fe);_0x1b5936=_0x1b5936['concat'](sd(_0x41ce87,_0x2ce8fe,_0x5b938d));}return _0x1b5936;}function Hn(_0x5e64c7,_0x3d2089,_0xecf9e3){const _0x2c7554=_0x5e64c7['pendingWriteTree_'],_0x591c64=_0x5e64c7['syncPointTree_']['findOnPath'](_0x3d2089,(_0x43bf26,_0x114493)=>{const _0x3b93ba=F(_0x43bf26,_0x3d2089),_0x76cfbf=Ee(_0x114493,_0x3b93ba);if(_0x76cfbf)return _0x76cfbf;});return qo(_0x2c7554,_0x3d2089,_0x591c64,_0xecf9e3,!0x0);}function ed(_0x17577e,_0x134e54){const _0xb41db6=_0x134e54['_path'];let _0x2ef5de=null;_0x17577e['syncPointTree_']['foreachOnPath'](_0xb41db6,(_0x511663,_0x96ffbc)=>{const _0x4b6c1c=F(_0x511663,_0xb41db6);_0x2ef5de=_0x2ef5de||Ee(_0x96ffbc,_0x4b6c1c);});let _0x39ea29=_0x17577e['syncPointTree_']['get'](_0xb41db6);_0x39ea29?_0x2ef5de=_0x2ef5de||Ee(_0x39ea29,w()):(_0x39ea29=new Jo(),_0x17577e['syncPointTree_']=_0x17577e['syncPointTree_']['set'](_0xb41db6,_0x39ea29));const _0x3e1446=_0x2ef5de!=null,_0x58ccac=_0x3e1446?new Ce(_0x2ef5de,!0x0,!0x1):null,_0x1a8252=Bn(_0x17577e['pendingWriteTree_'],_0x134e54['_path']),_0x204ee6=Xo(_0x39ea29,_0x134e54,_0x1a8252,_0x3e1446?_0x58ccac['getNode']():g['EMPTY_NODE'],_0x3e1446);return Fu(_0x204ee6);}function _t(_0x30bc24,_0x5b327d){return ia(_0x5b327d,_0x30bc24['syncPointTree_'],null,Bn(_0x30bc24['pendingWriteTree_'],w()));}function ia(_0x1b4064,_0x5056e0,_0xe03d3d,_0x3d15db){if(v(_0x1b4064['path']))return sa(_0x1b4064,_0x5056e0,_0xe03d3d,_0x3d15db);{const _0x13da62=_0x5056e0['get'](w());_0xe03d3d==null&&_0x13da62!=null&&(_0xe03d3d=Ee(_0x13da62,w()));let _0x480e4e=[];const _0x209405=y(_0x1b4064['path']),_0x1ef04e=_0x1b4064['operationForChild'](_0x209405),_0x44c103=_0x5056e0['children']['get'](_0x209405);if(_0x44c103&&_0x1ef04e){const _0x4b0fbf=_0xe03d3d?_0xe03d3d['getImmediateChild'](_0x209405):null,_0x36af7e=zo(_0x3d15db,_0x209405);_0x480e4e=_0x480e4e['concat'](ia(_0x1ef04e,_0x44c103,_0x4b0fbf,_0x36af7e));}return _0x13da62&&(_0x480e4e=_0x480e4e['concat'](os(_0x13da62,_0x1b4064,_0x3d15db,_0xe03d3d))),_0x480e4e;}}function sa(_0x168f71,_0x2c9706,_0x397f56,_0x3559fa){const _0x4016bd=_0x2c9706['get'](w());_0x397f56==null&&_0x4016bd!=null&&(_0x397f56=Ee(_0x4016bd,w()));let _0x407942=[];return _0x2c9706['children']['inorderTraversal']((_0x5c09e1,_0x39cee4)=>{const _0x3bf737=_0x397f56?_0x397f56['getImmediateChild'](_0x5c09e1):null,_0x583ae3=zo(_0x3559fa,_0x5c09e1),_0x562294=_0x168f71['operationForChild'](_0x5c09e1);_0x562294&&(_0x407942=_0x407942['concat'](sa(_0x562294,_0x39cee4,_0x3bf737,_0x583ae3)));}),_0x4016bd&&(_0x407942=_0x407942['concat'](os(_0x4016bd,_0x168f71,_0x3559fa,_0x397f56))),_0x407942;}function ra(_0x1bccd7,_0x5eaabe){const _0x207c97=_0x5eaabe['query'],_0x58c182=Wt(_0x1bccd7,_0x207c97);return{'hashFn':()=>(xu(_0x5eaabe)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x5aaecc=>{if(_0x5aaecc==='ok')return _0x58c182?Xu(_0x1bccd7,_0x207c97['_path'],_0x58c182):Ju(_0x1bccd7,_0x207c97['_path']);{const _0x4c4d47=Ql(_0x5aaecc,_0x207c97);return kn(_0x1bccd7,_0x207c97,null,_0x4c4d47);}}};}function Wt(_0x23ff9d,_0x2f3c49){const _0x3e3da3=$n(_0x2f3c49);return _0x23ff9d['queryToTagMap']['get'](_0x3e3da3);}function $n(_0x173ecb){return _0x173ecb['_path']['toString']()+'$'+_0x173ecb['_queryIdentifier'];}function cs(_0xb6d15f,_0x25a8a5){return _0xb6d15f['tagToQueryMap']['get'](_0x25a8a5);}function ls(_0x423410){const _0x4eaef8=_0x423410['indexOf']('$');return f(_0x4eaef8!==-0x1&&_0x4eaef8<_0x423410['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x423410['substr'](_0x4eaef8+0x1),'path':new C(_0x423410['substr'](0x0,_0x4eaef8))};}function hs(_0x539e28,_0x11bc40,_0x5c7459){const _0x15d704=_0x539e28['syncPointTree_']['get'](_0x11bc40);f(_0x15d704,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x2c5b45=Bn(_0x539e28['pendingWriteTree_'],_0x11bc40);return os(_0x15d704,_0x5c7459,_0x2c5b45,null);}function td(_0x38a1ae){return _0x38a1ae['fold']((_0x128de5,_0x4d5ef9,_0x4f8b86)=>{if(_0x4d5ef9&&Te(_0x4d5ef9))return[Vn(_0x4d5ef9)];{let _0x37014a=[];return _0x4d5ef9&&(_0x37014a=Zo(_0x4d5ef9)),x(_0x4f8b86,(_0x44571d,_0x2bca70)=>{_0x37014a=_0x37014a['concat'](_0x2bca70);}),_0x37014a;}});}function kt(_0x1b9ddc){return _0x1b9ddc['_queryParams']['loadsAllData']()&&!_0x1b9ddc['_queryParams']['isDefault']()?new(ju())(_0x1b9ddc['_repo'],_0x1b9ddc['_path']):_0x1b9ddc;}function nd(_0x2532bf,_0x56d41a){for(let _0x6779f0=0x0;_0x6779f0<_0x56d41a['length'];++_0x6779f0){const _0x39ec82=_0x56d41a[_0x6779f0];if(!_0x39ec82['_queryParams']['loadsAllData']()){const _0x3e2ad8=$n(_0x39ec82),_0x5280bd=_0x2532bf['queryToTagMap']['get'](_0x3e2ad8);_0x2532bf['queryToTagMap']['delete'](_0x3e2ad8),_0x2532bf['tagToQueryMap']['delete'](_0x5280bd);}}}function id(){return Ku++;}function sd(_0x26876e,_0x3c7476,_0x2ce894){const _0x414e21=_0x3c7476['_path'],_0x5844ad=Wt(_0x26876e,_0x3c7476),_0x440d91=ra(_0x26876e,_0x2ce894),_0x4d7e60=_0x26876e['listenProvider_']['startListening'](kt(_0x3c7476),_0x5844ad,_0x440d91['hashFn'],_0x440d91['onComplete']),_0x42f4cb=_0x26876e['syncPointTree_']['subtree'](_0x414e21);if(_0x5844ad)f(!Te(_0x42f4cb['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x52d26e=_0x42f4cb['fold']((_0xa9c12f,_0x52898f,_0x23259a)=>{if(!v(_0xa9c12f)&&_0x52898f&&Te(_0x52898f))return[Vn(_0x52898f)['query']];{let _0x23cbd8=[];return _0x52898f&&(_0x23cbd8=_0x23cbd8['concat'](Zo(_0x52898f)['map'](_0x47577f=>_0x47577f['query']))),x(_0x23259a,(_0x34f200,_0x2ddda0)=>{_0x23cbd8=_0x23cbd8['concat'](_0x2ddda0);}),_0x23cbd8;}});for(let _0x27e411=0x0;_0x27e411<_0x52d26e['length'];++_0x27e411){const _0x222f1b=_0x52d26e[_0x27e411];_0x26876e['listenProvider_']['stopListening'](kt(_0x222f1b),Wt(_0x26876e,_0x222f1b));}}return _0x4d7e60;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x52c180){this['node_']=_0x52c180;}['getImmediateChild'](_0x2fd40e){const _0x3f4435=this['node_']['getImmediateChild'](_0x2fd40e);return new us(_0x3f4435);}['node'](){return this['node_'];}}class ds{constructor(_0x139e24,_0x43efa9){this['syncTree_']=_0x139e24,this['path_']=_0x43efa9;}['getImmediateChild'](_0x23586c){const _0x391505=k(this['path_'],_0x23586c);return new ds(this['syncTree_'],_0x391505);}['node'](){return Hn(this['syncTree_'],this['path_']);}}const rd=function(_0xe2f142){return _0xe2f142=_0xe2f142||{},_0xe2f142['timestamp']=_0xe2f142['timestamp']||new Date()['getTime'](),_0xe2f142;},Ir=function(_0x404b51,_0x226917,_0x1a71e3){if(!_0x404b51||typeof _0x404b51!='object')return _0x404b51;if(f('.sv'in _0x404b51,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x404b51['.sv']=='string')return od(_0x404b51['.sv'],_0x226917,_0x1a71e3);if(typeof _0x404b51['.sv']=='object')return ad(_0x404b51['.sv'],_0x226917);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x404b51,null,0x2));},od=function(_0x9fcb1b,_0x534686,_0x455f62){switch(_0x9fcb1b){case'timestamp':return _0x455f62['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x9fcb1b);}},ad=function(_0x107e84,_0x4587dc,_0x2ece9c){_0x107e84['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x107e84,null,0x2));const _0x278618=_0x107e84['increment'];typeof _0x278618!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x278618);const _0x1abe04=_0x4587dc['node']();if(f(_0x1abe04!==null&&typeof _0x1abe04<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x1abe04['isLeafNode']())return _0x278618;const _0x224558=_0x1abe04['getValue']();return typeof _0x224558!='number'?_0x278618:_0x224558+_0x278618;},oa=function(_0x4de3b0,_0x3f5acf,_0x15b291,_0xb5cb48){return ps(_0x3f5acf,new ds(_0x15b291,_0x4de3b0),_0xb5cb48);},fs=function(_0xde6361,_0x42f48c,_0x36213d){return ps(_0xde6361,new us(_0x42f48c),_0x36213d);};function ps(_0x2ba706,_0x1ca7c5,_0x351950){const _0x549e99=_0x2ba706['getPriority']()['val'](),_0x5b8ed6=Ir(_0x549e99,_0x1ca7c5['getImmediateChild']('.priority'),_0x351950);let _0x2d5d36;if(_0x2ba706['isLeafNode']()){const _0x3c9d0b=_0x2ba706,_0xd2d713=Ir(_0x3c9d0b['getValue'](),_0x1ca7c5,_0x351950);return _0xd2d713!==_0x3c9d0b['getValue']()||_0x5b8ed6!==_0x3c9d0b['getPriority']()['val']()?new D(_0xd2d713,A(_0x5b8ed6)):_0x2ba706;}else{const _0x5d4f17=_0x2ba706;return _0x2d5d36=_0x5d4f17,_0x5b8ed6!==_0x5d4f17['getPriority']()['val']()&&(_0x2d5d36=_0x2d5d36['updatePriority'](new D(_0x5b8ed6))),_0x5d4f17['forEachChild'](R,(_0x34c0ce,_0x4a7ce2)=>{const _0x5231be=ps(_0x4a7ce2,_0x1ca7c5['getImmediateChild'](_0x34c0ce),_0x351950);_0x5231be!==_0x4a7ce2&&(_0x2d5d36=_0x2d5d36['updateImmediateChild'](_0x34c0ce,_0x5231be));}),_0x2d5d36;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x56fa37='',_0x31852b=null,_0x70489b={'children':{},'childCount':0x0}){this['name']=_0x56fa37,this['parent']=_0x31852b,this['node']=_0x70489b;}}function Gn(_0x245799,_0x27164f){let _0x3361e1=_0x27164f instanceof C?_0x27164f:new C(_0x27164f),_0x548576=_0x245799,_0x4095f1=y(_0x3361e1);for(;_0x4095f1!==null;){const _0x4bd4ce=Le(_0x548576['node']['children'],_0x4095f1)||{'children':{},'childCount':0x0};_0x548576=new _s(_0x4095f1,_0x548576,_0x4bd4ce),_0x3361e1=S(_0x3361e1),_0x4095f1=y(_0x3361e1);}return _0x548576;}function je(_0x17c817){return _0x17c817['node']['value'];}function gs(_0x256e14,_0x1210c2){_0x256e14['node']['value']=_0x1210c2,Oi(_0x256e14);}function aa(_0x414a82){return _0x414a82['node']['childCount']>0x0;}function cd(_0x2ffbcf){return je(_0x2ffbcf)===void 0x0&&!aa(_0x2ffbcf);}function qn(_0x38bce5,_0x1ba083){x(_0x38bce5['node']['children'],(_0x775ac3,_0x582893)=>{_0x1ba083(new _s(_0x775ac3,_0x38bce5,_0x582893));});}function ca(_0x160f73,_0x460bd0,_0x5d65fc,_0x4a9e70){_0x5d65fc&&_0x460bd0(_0x160f73),qn(_0x160f73,_0x91def6=>{ca(_0x91def6,_0x460bd0,!0x0);});}function ld(_0x597fbd,_0xa8d1e8,_0x2e06a7){let _0x3d5d4a=_0x597fbd['parent'];for(;_0x3d5d4a!==null;){if(_0xa8d1e8(_0x3d5d4a))return!0x0;_0x3d5d4a=_0x3d5d4a['parent'];}return!0x1;}function Qt(_0x1b1ec1){return new C(_0x1b1ec1['parent']===null?_0x1b1ec1['name']:Qt(_0x1b1ec1['parent'])+'/'+_0x1b1ec1['name']);}function Oi(_0x3e1ee2){_0x3e1ee2['parent']!==null&&hd(_0x3e1ee2['parent'],_0x3e1ee2['name'],_0x3e1ee2);}function hd(_0x4a61d9,_0x84d88a,_0xb62174){const _0x4c2da8=cd(_0xb62174),_0x522b8b=Q(_0x4a61d9['node']['children'],_0x84d88a);_0x4c2da8&&_0x522b8b?(delete _0x4a61d9['node']['children'][_0x84d88a],_0x4a61d9['node']['childCount']--,Oi(_0x4a61d9)):!_0x4c2da8&&!_0x522b8b&&(_0x4a61d9['node']['children'][_0x84d88a]=_0xb62174['node'],_0x4a61d9['node']['childCount']++,Oi(_0x4a61d9));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ud=/[\[\].#$\/\u0000-\u001F\u007F]/,dd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x7bf99d){return typeof _0x7bf99d=='string'&&_0x7bf99d['length']!==0x0&&!ud['test'](_0x7bf99d);},la=function(_0x4feb89){return typeof _0x4feb89=='string'&&_0x4feb89['length']!==0x0&&!dd['test'](_0x4feb89);},fd=function(_0xa95dc0){return _0xa95dc0&&(_0xa95dc0=_0xa95dc0['replace'](/^\/*\.info(\/|$)/,'/')),la(_0xa95dc0);},Bt=function(_0x47e44b){return _0x47e44b===null||typeof _0x47e44b=='string'||typeof _0x47e44b=='number'&&!Fn(_0x47e44b)||_0x47e44b&&typeof _0x47e44b=='object'&&Q(_0x47e44b,'.sv');},He=function(_0x58631e,_0x4812a6,_0x3b87f6,_0x15f8f2){_0x15f8f2&&_0x4812a6===void 0x0||Jt(it(_0x58631e,'value'),_0x4812a6,_0x3b87f6);},Jt=function(_0x21c91a,_0x218d58,_0x187521){const _0x34b2b4=_0x187521 instanceof C?new Nh(_0x187521,_0x21c91a):_0x187521;if(_0x218d58===void 0x0)throw new Error(_0x21c91a+'contains\x20undefined\x20'+Pe(_0x34b2b4));if(typeof _0x218d58=='function')throw new Error(_0x21c91a+'contains\x20a\x20function\x20'+Pe(_0x34b2b4)+'\x20with\x20contents\x20=\x20'+_0x218d58['toString']());if(Fn(_0x218d58))throw new Error(_0x21c91a+'contains\x20'+_0x218d58['toString']()+'\x20'+Pe(_0x34b2b4));if(typeof _0x218d58=='string'&&_0x218d58['length']>ui/0x3&&xn(_0x218d58)>ui)throw new Error(_0x21c91a+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Pe(_0x34b2b4)+'\x20(\x27'+_0x218d58['substring'](0x0,0x32)+'...\x27)');if(_0x218d58&&typeof _0x218d58=='object'){let _0x39ce94=!0x1,_0x2da657=!0x1;if(x(_0x218d58,(_0x4a69a4,_0x4f92db)=>{if(_0x4a69a4==='.value')_0x39ce94=!0x0;else{if(_0x4a69a4!=='.priority'&&_0x4a69a4!=='.sv'&&(_0x2da657=!0x0,!ms(_0x4a69a4)))throw new Error(_0x21c91a+'\x20contains\x20an\x20invalid\x20key\x20('+_0x4a69a4+')\x20'+Pe(_0x34b2b4)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}Ph(_0x34b2b4,_0x4a69a4),Jt(_0x21c91a,_0x4f92db,_0x34b2b4),Oh(_0x34b2b4);}),_0x39ce94&&_0x2da657)throw new Error(_0x21c91a+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x34b2b4)+'\x20in\x20addition\x20to\x20actual\x20children.');}},pd=function(_0x4d0d7c,_0xe7f6da){let _0x615c56,_0x4fd11e;for(_0x615c56=0x0;_0x615c56<_0xe7f6da['length'];_0x615c56++){_0x4fd11e=_0xe7f6da[_0x615c56];const _0x53c4bc=Mt(_0x4fd11e);for(let _0x2af6c9=0x0;_0x2af6c9<_0x53c4bc['length'];_0x2af6c9++)if(!(_0x53c4bc[_0x2af6c9]==='.priority'&&_0x2af6c9===_0x53c4bc['length']-0x1)){if(!ms(_0x53c4bc[_0x2af6c9]))throw new Error(_0x4d0d7c+'contains\x20an\x20invalid\x20key\x20('+_0x53c4bc[_0x2af6c9]+')\x20in\x20path\x20'+_0x4fd11e['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0xe7f6da['sort'](kh);let _0x2dcb43=null;for(_0x615c56=0x0;_0x615c56<_0xe7f6da['length'];_0x615c56++){if(_0x4fd11e=_0xe7f6da[_0x615c56],_0x2dcb43!==null&&G(_0x2dcb43,_0x4fd11e))throw new Error(_0x4d0d7c+'contains\x20a\x20path\x20'+_0x2dcb43['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x4fd11e['toString']());_0x2dcb43=_0x4fd11e;}},ha=function(_0x4d973a,_0x54bde7,_0x138841,_0x473426){const _0x408bfc=it(_0x4d973a,'values');if(!(_0x54bde7&&typeof _0x54bde7=='object')||Array['isArray'](_0x54bde7))throw new Error(_0x408bfc+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0xed6f03=[];x(_0x54bde7,(_0x3d215c,_0x1b0a55)=>{const _0x4d3a10=new C(_0x3d215c);if(Jt(_0x408bfc,_0x1b0a55,k(_0x138841,_0x4d3a10)),ji(_0x4d3a10)==='.priority'&&!Bt(_0x1b0a55))throw new Error(_0x408bfc+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x4d3a10['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0xed6f03['push'](_0x4d3a10);}),pd(_0x408bfc,_0xed6f03);},_d=function(_0x56868a,_0x1759df,_0x284105){if(Fn(_0x1759df))throw new Error(it(_0x56868a,'priority')+'is\x20'+_0x1759df['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x1759df))throw new Error(it(_0x56868a,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x37c5a9,_0x57fbfa,_0x216f5f,_0x18d8d1){if(!la(_0x216f5f))throw new Error(it(_0x37c5a9,_0x57fbfa)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x216f5f+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},gd=function(_0x46a027,_0x5324c0,_0x5632d9,_0x19943e){_0x5632d9&&(_0x5632d9=_0x5632d9['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x46a027,_0x5324c0,_0x5632d9);},De=function(_0x2fd054,_0x4e4ca7){if(y(_0x4e4ca7)==='.info')throw new Error(_0x2fd054+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},md=function(_0x43be38,_0x2f38d8){const _0x5ea0da=_0x2f38d8['path']['toString']();if(typeof _0x2f38d8['repoInfo']['host']!='string'||_0x2f38d8['repoInfo']['host']['length']===0x0||!ms(_0x2f38d8['repoInfo']['namespace'])&&_0x2f38d8['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x5ea0da['length']!==0x0&&!fd(_0x5ea0da))throw new Error(it(_0x43be38,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function zn(_0x48756b,_0xbd3575){let _0x5b3aa0=null;for(let _0xca2f8d=0x0;_0xca2f8d<_0xbd3575['length'];_0xca2f8d++){const _0x328ea1=_0xbd3575[_0xca2f8d],_0x123a48=_0x328ea1['getPath']();_0x5b3aa0!==null&&!Ki(_0x123a48,_0x5b3aa0['path'])&&(_0x48756b['eventLists_']['push'](_0x5b3aa0),_0x5b3aa0=null),_0x5b3aa0===null&&(_0x5b3aa0={'events':[],'path':_0x123a48}),_0x5b3aa0['events']['push'](_0x328ea1);}_0x5b3aa0&&_0x48756b['eventLists_']['push'](_0x5b3aa0);}function ua(_0x4de9ef,_0x5c98c7,_0x1c542f){zn(_0x4de9ef,_0x1c542f),da(_0x4de9ef,_0x6ba339=>Ki(_0x6ba339,_0x5c98c7));}function V(_0x34aae7,_0x45fa8d,_0x109767){zn(_0x34aae7,_0x109767),da(_0x34aae7,_0x11657e=>G(_0x11657e,_0x45fa8d)||G(_0x45fa8d,_0x11657e));}function da(_0x118d89,_0x4239e9){_0x118d89['recursionDepth_']++;let _0x3f9775=!0x0;for(let _0x20ee5f=0x0;_0x20ee5f<_0x118d89['eventLists_']['length'];_0x20ee5f++){const _0xabc163=_0x118d89['eventLists_'][_0x20ee5f];if(_0xabc163){const _0x4db77e=_0xabc163['path'];_0x4239e9(_0x4db77e)?(vd(_0x118d89['eventLists_'][_0x20ee5f]),_0x118d89['eventLists_'][_0x20ee5f]=null):_0x3f9775=!0x1;}}_0x3f9775&&(_0x118d89['eventLists_']=[]),_0x118d89['recursionDepth_']--;}function vd(_0x3cd4f2){for(let _0x2c2dc5=0x0;_0x2c2dc5<_0x3cd4f2['events']['length'];_0x2c2dc5++){const _0x1405a5=_0x3cd4f2['events'][_0x2c2dc5];if(_0x1405a5!==null){_0x3cd4f2['events'][_0x2c2dc5]=null;const _0x19e842=_0x1405a5['getEventRunner']();St&&L('event:\x20'+_0x1405a5['toString']()),ft(_0x19e842);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fa='repo_interrupt',Ed=0x19;class Id{constructor(_0x47aae8,_0x247968,_0x3b2c5c,_0x26b4b0){this['repoInfo_']=_0x47aae8,this['forceRestClient_']=_0x247968,this['authTokenProvider_']=_0x3b2c5c,this['appCheckProvider_']=_0x26b4b0,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new yd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=In(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function wd(_0x2b771d,_0x76a6f4,_0x3c4b50){if(_0x2b771d['stats_']=qi(_0x2b771d['repoInfo_']),_0x2b771d['forceRestClient_']||eh())_0x2b771d['server_']=new En(_0x2b771d['repoInfo_'],(_0x26148b,_0x2c2a4b,_0x1b1ef4,_0x20ee7c)=>{wr(_0x2b771d,_0x26148b,_0x2c2a4b,_0x1b1ef4,_0x20ee7c);},_0x2b771d['authTokenProvider_'],_0x2b771d['appCheckProvider_']),setTimeout(()=>Cr(_0x2b771d,!0x0),0x0);else{if(typeof _0x3c4b50<'u'&&_0x3c4b50!==null){if(typeof _0x3c4b50!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x3c4b50);}catch(_0x567f3b){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x567f3b);}}_0x2b771d['persistentConnection_']=new se(_0x2b771d['repoInfo_'],_0x76a6f4,(_0x3411de,_0x1505bf,_0x2deb1a,_0x500ead)=>{wr(_0x2b771d,_0x3411de,_0x1505bf,_0x2deb1a,_0x500ead);},_0x5a6656=>{Cr(_0x2b771d,_0x5a6656);},_0x4990f7=>{Cd(_0x2b771d,_0x4990f7);},_0x2b771d['authTokenProvider_'],_0x2b771d['appCheckProvider_'],_0x3c4b50),_0x2b771d['server_']=_0x2b771d['persistentConnection_'];}_0x2b771d['authTokenProvider_']['addTokenChangeListener'](_0x4efdd2=>{_0x2b771d['server_']['refreshAuthToken'](_0x4efdd2);}),_0x2b771d['appCheckProvider_']['addTokenChangeListener'](_0x265d60=>{_0x2b771d['server_']['refreshAppCheckToken'](_0x265d60['token']);}),_0x2b771d['statsReporter_']=rh(_0x2b771d['repoInfo_'],()=>new ru(_0x2b771d['stats_'],_0x2b771d['server_'])),_0x2b771d['infoData_']=new eu(),_0x2b771d['infoSyncTree_']=new Er({'startListening':(_0x296fd0,_0x12ef8a,_0x1312fe,_0xb473ee)=>{let _0x3c45a2=[];const _0x5dab25=_0x2b771d['infoData_']['getNode'](_0x296fd0['_path']);return _0x5dab25['isEmpty']()||(_0x3c45a2=Yt(_0x2b771d['infoSyncTree_'],_0x296fd0['_path'],_0x5dab25),setTimeout(()=>{_0xb473ee('ok');},0x0)),_0x3c45a2;},'stopListening':()=>{}}),vs(_0x2b771d,'connected',!0x1),_0x2b771d['serverSyncTree_']=new Er({'startListening':(_0x3263e9,_0x3cef06,_0x36550a,_0x2eb1b6)=>(_0x2b771d['server_']['listen'](_0x3263e9,_0x36550a,_0x3cef06,(_0x319150,_0x2edde4)=>{const _0x3f4fb9=_0x2eb1b6(_0x319150,_0x2edde4);V(_0x2b771d['eventQueue_'],_0x3263e9['_path'],_0x3f4fb9);}),[]),'stopListening':(_0x29d172,_0x1ed94b)=>{_0x2b771d['server_']['unlisten'](_0x29d172,_0x1ed94b);}});}function pa(_0x2d0efc){const _0x2aee2e=_0x2d0efc['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x2aee2e;}function Xt(_0x48876a){return rd({'timestamp':pa(_0x48876a)});}function wr(_0x5cf52a,_0x144942,_0x3f8e34,_0x352227,_0x2b26bf){_0x5cf52a['dataUpdateCount']++;const _0x5adffb=new C(_0x144942);_0x3f8e34=_0x5cf52a['interceptServerDataCallback_']?_0x5cf52a['interceptServerDataCallback_'](_0x144942,_0x3f8e34):_0x3f8e34;let _0x5519a0=[];if(_0x2b26bf){if(_0x352227){const _0x735854=gn(_0x3f8e34,_0x26ef8e=>A(_0x26ef8e));_0x5519a0=Zu(_0x5cf52a['serverSyncTree_'],_0x5adffb,_0x735854,_0x2b26bf);}else{const _0x25568b=A(_0x3f8e34);_0x5519a0=na(_0x5cf52a['serverSyncTree_'],_0x5adffb,_0x25568b,_0x2b26bf);}}else{if(_0x352227){const _0x168238=gn(_0x3f8e34,_0x5d1f76=>A(_0x5d1f76));_0x5519a0=Qu(_0x5cf52a['serverSyncTree_'],_0x5adffb,_0x168238);}else{const _0x190aec=A(_0x3f8e34);_0x5519a0=Yt(_0x5cf52a['serverSyncTree_'],_0x5adffb,_0x190aec);}}let _0x392c85=_0x5adffb;_0x5519a0['length']>0x0&&(_0x392c85=ct(_0x5cf52a,_0x5adffb)),V(_0x5cf52a['eventQueue_'],_0x392c85,_0x5519a0);}function Cr(_0x5acf36,_0x48563d){vs(_0x5acf36,'connected',_0x48563d),_0x48563d===!0x1&&Rd(_0x5acf36);}function Cd(_0x16b0c1,_0x1399e7){x(_0x1399e7,(_0x5ad16c,_0x50e6b2)=>{vs(_0x16b0c1,_0x5ad16c,_0x50e6b2);});}function vs(_0x4db70f,_0x281783,_0x4f7d8a){const _0x428518=new C('/.info/'+_0x281783),_0x4d226f=A(_0x4f7d8a);_0x4db70f['infoData_']['updateSnapshot'](_0x428518,_0x4d226f);const _0xb478fb=Yt(_0x4db70f['infoSyncTree_'],_0x428518,_0x4d226f);V(_0x4db70f['eventQueue_'],_0x428518,_0xb478fb);}function jn(_0x5761a9){return _0x5761a9['nextWriteId_']++;}function Td(_0x21f709,_0x99a471,_0x1e85d0){const _0x18d49a=ed(_0x21f709['serverSyncTree_'],_0x99a471);return _0x18d49a!=null?Promise['resolve'](_0x18d49a):_0x21f709['server_']['get'](_0x99a471)['then'](_0x53a2f9=>{const _0x494517=A(_0x53a2f9)['withIndex'](_0x99a471['_queryParams']['getIndex']());Pi(_0x21f709['serverSyncTree_'],_0x99a471,_0x1e85d0,!0x0);let _0x5210a0;if(_0x99a471['_queryParams']['loadsAllData']())_0x5210a0=Yt(_0x21f709['serverSyncTree_'],_0x99a471['_path'],_0x494517);else{const _0x37795a=Wt(_0x21f709['serverSyncTree_'],_0x99a471);_0x5210a0=na(_0x21f709['serverSyncTree_'],_0x99a471['_path'],_0x494517,_0x37795a);}return V(_0x21f709['eventQueue_'],_0x99a471['_path'],_0x5210a0),kn(_0x21f709['serverSyncTree_'],_0x99a471,_0x1e85d0,null,!0x0),_0x494517;},_0x202b26=>(gt(_0x21f709,'get\x20for\x20query\x20'+O(_0x99a471)+'\x20failed:\x20'+_0x202b26),Promise['reject'](new Error(_0x202b26))));}function Sd(_0x12fbf3,_0x219571,_0x28a5ff,_0x561e8c,_0x27ffdf){gt(_0x12fbf3,'set',{'path':_0x219571['toString'](),'value':_0x28a5ff,'priority':_0x561e8c});const _0x30541b=Xt(_0x12fbf3),_0x4c4a66=A(_0x28a5ff,_0x561e8c),_0xcbac6d=Hn(_0x12fbf3['serverSyncTree_'],_0x219571),_0x36dd0a=fs(_0x4c4a66,_0xcbac6d,_0x30541b),_0x225148=jn(_0x12fbf3),_0x56ffac=as(_0x12fbf3['serverSyncTree_'],_0x219571,_0x36dd0a,_0x225148,!0x0);zn(_0x12fbf3['eventQueue_'],_0x56ffac),_0x12fbf3['server_']['put'](_0x219571['toString'](),_0x4c4a66['val'](!0x0),(_0xd3c9b5,_0x6cfa23)=>{const _0x33d12a=_0xd3c9b5==='ok';_0x33d12a||U('set\x20at\x20'+_0x219571+'\x20failed:\x20'+_0xd3c9b5);const _0x1918af=_e(_0x12fbf3['serverSyncTree_'],_0x225148,!_0x33d12a);V(_0x12fbf3['eventQueue_'],_0x219571,_0x1918af),Se(_0x12fbf3,_0x27ffdf,_0xd3c9b5,_0x6cfa23);});const _0x4a3b4c=Is(_0x12fbf3,_0x219571);ct(_0x12fbf3,_0x4a3b4c),V(_0x12fbf3['eventQueue_'],_0x4a3b4c,[]);}function bd(_0x36d7d0,_0xbcc3d3,_0x375135,_0x34af64){gt(_0x36d7d0,'update',{'path':_0xbcc3d3['toString'](),'value':_0x375135});let _0x246c1f=!0x0;const _0xf108ad=Xt(_0x36d7d0),_0x364506={};if(x(_0x375135,(_0x1d9c26,_0x89fd2c)=>{_0x246c1f=!0x1,_0x364506[_0x1d9c26]=oa(k(_0xbcc3d3,_0x1d9c26),A(_0x89fd2c),_0x36d7d0['serverSyncTree_'],_0xf108ad);}),_0x246c1f)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Se(_0x36d7d0,_0x34af64,'ok',void 0x0);else{const _0x440bf6=jn(_0x36d7d0),_0x48a75c=Yu(_0x36d7d0['serverSyncTree_'],_0xbcc3d3,_0x364506,_0x440bf6);zn(_0x36d7d0['eventQueue_'],_0x48a75c),_0x36d7d0['server_']['merge'](_0xbcc3d3['toString'](),_0x375135,(_0x5318d8,_0x3af142)=>{const _0x5b5b49=_0x5318d8==='ok';_0x5b5b49||U('update\x20at\x20'+_0xbcc3d3+'\x20failed:\x20'+_0x5318d8);const _0x32e506=_e(_0x36d7d0['serverSyncTree_'],_0x440bf6,!_0x5b5b49),_0xf1b368=_0x32e506['length']>0x0?ct(_0x36d7d0,_0xbcc3d3):_0xbcc3d3;V(_0x36d7d0['eventQueue_'],_0xf1b368,_0x32e506),Se(_0x36d7d0,_0x34af64,_0x5318d8,_0x3af142);}),x(_0x375135,_0x459f4f=>{const _0x2e1e22=Is(_0x36d7d0,k(_0xbcc3d3,_0x459f4f));ct(_0x36d7d0,_0x2e1e22);}),V(_0x36d7d0['eventQueue_'],_0xbcc3d3,[]);}}function Rd(_0x1c0a17){gt(_0x1c0a17,'onDisconnectEvents');const _0x56c71b=Xt(_0x1c0a17),_0x5c5b8d=In();Si(_0x1c0a17['onDisconnect_'],w(),(_0x5f0fc7,_0xd3d3fc)=>{const _0x2a046d=oa(_0x5f0fc7,_0xd3d3fc,_0x1c0a17['serverSyncTree_'],_0x56c71b);pt(_0x5c5b8d,_0x5f0fc7,_0x2a046d);});let _0x7f1cdf=[];Si(_0x5c5b8d,w(),(_0x4a87e0,_0x3e0f68)=>{_0x7f1cdf=_0x7f1cdf['concat'](Yt(_0x1c0a17['serverSyncTree_'],_0x4a87e0,_0x3e0f68));const _0x1bd3e2=Is(_0x1c0a17,_0x4a87e0);ct(_0x1c0a17,_0x1bd3e2);}),_0x1c0a17['onDisconnect_']=In(),V(_0x1c0a17['eventQueue_'],w(),_0x7f1cdf);}function Ad(_0x2cf66c,_0x852710,_0x2167e4){_0x2cf66c['server_']['onDisconnectCancel'](_0x852710['toString'](),(_0x12584e,_0x343977)=>{_0x12584e==='ok'&&Ti(_0x2cf66c['onDisconnect_'],_0x852710),Se(_0x2cf66c,_0x2167e4,_0x12584e,_0x343977);});}function Tr(_0xf23402,_0x20279e,_0x138010,_0x340c2c){const _0x4ae38e=A(_0x138010);_0xf23402['server_']['onDisconnectPut'](_0x20279e['toString'](),_0x4ae38e['val'](!0x0),(_0x2aef8c,_0x58a851)=>{_0x2aef8c==='ok'&&pt(_0xf23402['onDisconnect_'],_0x20279e,_0x4ae38e),Se(_0xf23402,_0x340c2c,_0x2aef8c,_0x58a851);});}function kd(_0x37e123,_0x18e060,_0x2a4f10,_0x5498a7,_0x492842){const _0x1a26f3=A(_0x2a4f10,_0x5498a7);_0x37e123['server_']['onDisconnectPut'](_0x18e060['toString'](),_0x1a26f3['val'](!0x0),(_0x150f95,_0x404a6d)=>{_0x150f95==='ok'&&pt(_0x37e123['onDisconnect_'],_0x18e060,_0x1a26f3),Se(_0x37e123,_0x492842,_0x150f95,_0x404a6d);});}function Nd(_0x1df4ac,_0x228d01,_0x109493,_0x1a4137){if(_n(_0x109493)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Se(_0x1df4ac,_0x1a4137,'ok',void 0x0);return;}_0x1df4ac['server_']['onDisconnectMerge'](_0x228d01['toString'](),_0x109493,(_0x943da4,_0x58193f)=>{_0x943da4==='ok'&&x(_0x109493,(_0x482832,_0xae80f9)=>{const _0x36a3e1=A(_0xae80f9);pt(_0x1df4ac['onDisconnect_'],k(_0x228d01,_0x482832),_0x36a3e1);}),Se(_0x1df4ac,_0x1a4137,_0x943da4,_0x58193f);});}function Pd(_0x5853a6,_0x5c6b2b,_0xb0aeae){let _0x34cee;y(_0x5c6b2b['_path'])==='.info'?_0x34cee=Pi(_0x5853a6['infoSyncTree_'],_0x5c6b2b,_0xb0aeae):_0x34cee=Pi(_0x5853a6['serverSyncTree_'],_0x5c6b2b,_0xb0aeae),ua(_0x5853a6['eventQueue_'],_0x5c6b2b['_path'],_0x34cee);}function Od(_0x2984ec,_0x11a844,_0xfca8ea){let _0x5753df;y(_0x11a844['_path'])==='.info'?_0x5753df=kn(_0x2984ec['infoSyncTree_'],_0x11a844,_0xfca8ea):_0x5753df=kn(_0x2984ec['serverSyncTree_'],_0x11a844,_0xfca8ea),ua(_0x2984ec['eventQueue_'],_0x11a844['_path'],_0x5753df);}function _a(_0x5e7e67){_0x5e7e67['persistentConnection_']&&_0x5e7e67['persistentConnection_']['interrupt'](fa);}function Dd(_0x22dc15){_0x22dc15['persistentConnection_']&&_0x22dc15['persistentConnection_']['resume'](fa);}function gt(_0x2aba2b,..._0x2a1f32){let _0x4804cc='';_0x2aba2b['persistentConnection_']&&(_0x4804cc=_0x2aba2b['persistentConnection_']['id']+':'),L(_0x4804cc,..._0x2a1f32);}function Se(_0x3e7398,_0x3cc86c,_0x53ff0d,_0x551238){_0x3cc86c&&ft(()=>{if(_0x53ff0d==='ok')_0x3cc86c(null);else{const _0x11b3b4=(_0x53ff0d||'error')['toUpperCase']();let _0x14d463=_0x11b3b4;_0x551238&&(_0x14d463+=':\x20'+_0x551238);const _0x54363f=new Error(_0x14d463);_0x54363f['code']=_0x11b3b4,_0x3cc86c(_0x54363f);}});}function Md(_0x37b31c,_0x41dbc4,_0x21786b,_0x26ff00,_0x4a7318,_0x53f7e5){gt(_0x37b31c,'transaction\x20on\x20'+_0x41dbc4);const _0x382f1d={'path':_0x41dbc4,'update':_0x21786b,'onComplete':_0x26ff00,'status':null,'order':ho(),'applyLocally':_0x53f7e5,'retryCount':0x0,'unwatcher':_0x4a7318,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x2e4b9a=Es(_0x37b31c,_0x41dbc4,void 0x0);_0x382f1d['currentInputSnapshot']=_0x2e4b9a;const _0x4bc263=_0x382f1d['update'](_0x2e4b9a['val']());if(_0x4bc263===void 0x0)_0x382f1d['unwatcher'](),_0x382f1d['currentOutputSnapshotRaw']=null,_0x382f1d['currentOutputSnapshotResolved']=null,_0x382f1d['onComplete']&&_0x382f1d['onComplete'](null,!0x1,_0x382f1d['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4bc263,_0x382f1d['path']),_0x382f1d['status']=0x0;const _0x39d742=Gn(_0x37b31c['transactionQueueTree_'],_0x41dbc4),_0x130a80=je(_0x39d742)||[];_0x130a80['push'](_0x382f1d),gs(_0x39d742,_0x130a80);let _0x36e145;typeof _0x4bc263=='object'&&_0x4bc263!==null&&Q(_0x4bc263,'.priority')?(_0x36e145=Le(_0x4bc263,'.priority'),f(Bt(_0x36e145),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x36e145=(Hn(_0x37b31c['serverSyncTree_'],_0x41dbc4)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x567307=Xt(_0x37b31c),_0x132c91=A(_0x4bc263,_0x36e145),_0x5ac911=fs(_0x132c91,_0x2e4b9a,_0x567307);_0x382f1d['currentOutputSnapshotRaw']=_0x132c91,_0x382f1d['currentOutputSnapshotResolved']=_0x5ac911,_0x382f1d['currentWriteId']=jn(_0x37b31c);const _0x97a8ff=as(_0x37b31c['serverSyncTree_'],_0x41dbc4,_0x5ac911,_0x382f1d['currentWriteId'],_0x382f1d['applyLocally']);V(_0x37b31c['eventQueue_'],_0x41dbc4,_0x97a8ff),Kn(_0x37b31c,_0x37b31c['transactionQueueTree_']);}}function Es(_0x4b85c1,_0x35dcb2,_0x23e9df){return Hn(_0x4b85c1['serverSyncTree_'],_0x35dcb2,_0x23e9df)||g['EMPTY_NODE'];}function Kn(_0x8f7f95,_0x1a185a=_0x8f7f95['transactionQueueTree_']){if(_0x1a185a||Yn(_0x8f7f95,_0x1a185a),je(_0x1a185a)){const _0x29f88a=ma(_0x8f7f95,_0x1a185a);f(_0x29f88a['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x29f88a['every'](_0x414588=>_0x414588['status']===0x0)&&Ld(_0x8f7f95,Qt(_0x1a185a),_0x29f88a);}else aa(_0x1a185a)&&qn(_0x1a185a,_0x2ecc60=>{Kn(_0x8f7f95,_0x2ecc60);});}function Ld(_0x3d7808,_0x2fee4a,_0x5b3b46){const _0x364b36=_0x5b3b46['map'](_0x5e56e6=>_0x5e56e6['currentWriteId']),_0x32a6f0=Es(_0x3d7808,_0x2fee4a,_0x364b36);let _0x39f09b=_0x32a6f0;const _0x5d89fc=_0x32a6f0['hash']();for(let _0x15c51f=0x0;_0x15c51f<_0x5b3b46['length'];_0x15c51f++){const _0x5ddebe=_0x5b3b46[_0x15c51f];f(_0x5ddebe['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x5ddebe['status']=0x1,_0x5ddebe['retryCount']++;const _0x6574f4=F(_0x2fee4a,_0x5ddebe['path']);_0x39f09b=_0x39f09b['updateChild'](_0x6574f4,_0x5ddebe['currentOutputSnapshotRaw']);}const _0x4df16f=_0x39f09b['val'](!0x0),_0x10466e=_0x2fee4a;_0x3d7808['server_']['put'](_0x10466e['toString'](),_0x4df16f,_0x27c43f=>{gt(_0x3d7808,'transaction\x20put\x20response',{'path':_0x10466e['toString'](),'status':_0x27c43f});let _0x5ecee1=[];if(_0x27c43f==='ok'){const _0x3f58f7=[];for(let _0x54a7de=0x0;_0x54a7de<_0x5b3b46['length'];_0x54a7de++)_0x5b3b46[_0x54a7de]['status']=0x2,_0x5ecee1=_0x5ecee1['concat'](_e(_0x3d7808['serverSyncTree_'],_0x5b3b46[_0x54a7de]['currentWriteId'])),_0x5b3b46[_0x54a7de]['onComplete']&&_0x3f58f7['push'](()=>_0x5b3b46[_0x54a7de]['onComplete'](null,!0x0,_0x5b3b46[_0x54a7de]['currentOutputSnapshotResolved'])),_0x5b3b46[_0x54a7de]['unwatcher']();Yn(_0x3d7808,Gn(_0x3d7808['transactionQueueTree_'],_0x2fee4a)),Kn(_0x3d7808,_0x3d7808['transactionQueueTree_']),V(_0x3d7808['eventQueue_'],_0x2fee4a,_0x5ecee1);for(let _0x354ad5=0x0;_0x354ad5<_0x3f58f7['length'];_0x354ad5++)ft(_0x3f58f7[_0x354ad5]);}else{if(_0x27c43f==='datastale'){for(let _0x1d2e1b=0x0;_0x1d2e1b<_0x5b3b46['length'];_0x1d2e1b++)_0x5b3b46[_0x1d2e1b]['status']===0x3?_0x5b3b46[_0x1d2e1b]['status']=0x4:_0x5b3b46[_0x1d2e1b]['status']=0x0;}else{U('transaction\x20at\x20'+_0x10466e['toString']()+'\x20failed:\x20'+_0x27c43f);for(let _0x35b56b=0x0;_0x35b56b<_0x5b3b46['length'];_0x35b56b++)_0x5b3b46[_0x35b56b]['status']=0x4,_0x5b3b46[_0x35b56b]['abortReason']=_0x27c43f;}ct(_0x3d7808,_0x2fee4a);}},_0x5d89fc);}function ct(_0x47f94d,_0x3b27a2){const _0x41a73f=ga(_0x47f94d,_0x3b27a2),_0x55e380=Qt(_0x41a73f),_0x359481=ma(_0x47f94d,_0x41a73f);return xd(_0x47f94d,_0x359481,_0x55e380),_0x55e380;}function xd(_0x1c49bd,_0x229497,_0x4b6d01){if(_0x229497['length']===0x0)return;const _0x2ddcc9=[];let _0x4ed41d=[];const _0x172433=_0x229497['filter'](_0x13b343=>_0x13b343['status']===0x0)['map'](_0x285162=>_0x285162['currentWriteId']);for(let _0x3e88f9=0x0;_0x3e88f9<_0x229497['length'];_0x3e88f9++){const _0x181ce4=_0x229497[_0x3e88f9],_0x22e2e8=F(_0x4b6d01,_0x181ce4['path']);let _0x2b9c77=!0x1,_0x13a53d;if(f(_0x22e2e8!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x181ce4['status']===0x4)_0x2b9c77=!0x0,_0x13a53d=_0x181ce4['abortReason'],_0x4ed41d=_0x4ed41d['concat'](_e(_0x1c49bd['serverSyncTree_'],_0x181ce4['currentWriteId'],!0x0));else{if(_0x181ce4['status']===0x0){if(_0x181ce4['retryCount']>=Ed)_0x2b9c77=!0x0,_0x13a53d='maxretry',_0x4ed41d=_0x4ed41d['concat'](_e(_0x1c49bd['serverSyncTree_'],_0x181ce4['currentWriteId'],!0x0));else{const _0x26d481=Es(_0x1c49bd,_0x181ce4['path'],_0x172433);_0x181ce4['currentInputSnapshot']=_0x26d481;const _0x1a2c40=_0x229497[_0x3e88f9]['update'](_0x26d481['val']());if(_0x1a2c40!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x1a2c40,_0x181ce4['path']);let _0x389451=A(_0x1a2c40);typeof _0x1a2c40=='object'&&_0x1a2c40!=null&&Q(_0x1a2c40,'.priority')||(_0x389451=_0x389451['updatePriority'](_0x26d481['getPriority']()));const _0x1ec074=_0x181ce4['currentWriteId'],_0x44a54f=Xt(_0x1c49bd),_0x3f9f4d=fs(_0x389451,_0x26d481,_0x44a54f);_0x181ce4['currentOutputSnapshotRaw']=_0x389451,_0x181ce4['currentOutputSnapshotResolved']=_0x3f9f4d,_0x181ce4['currentWriteId']=jn(_0x1c49bd),_0x172433['splice'](_0x172433['indexOf'](_0x1ec074),0x1),_0x4ed41d=_0x4ed41d['concat'](as(_0x1c49bd['serverSyncTree_'],_0x181ce4['path'],_0x3f9f4d,_0x181ce4['currentWriteId'],_0x181ce4['applyLocally'])),_0x4ed41d=_0x4ed41d['concat'](_e(_0x1c49bd['serverSyncTree_'],_0x1ec074,!0x0));}else _0x2b9c77=!0x0,_0x13a53d='nodata',_0x4ed41d=_0x4ed41d['concat'](_e(_0x1c49bd['serverSyncTree_'],_0x181ce4['currentWriteId'],!0x0));}}}V(_0x1c49bd['eventQueue_'],_0x4b6d01,_0x4ed41d),_0x4ed41d=[],_0x2b9c77&&(_0x229497[_0x3e88f9]['status']=0x2,function(_0xe185d5){setTimeout(_0xe185d5,Math['floor'](0x0));}(_0x229497[_0x3e88f9]['unwatcher']),_0x229497[_0x3e88f9]['onComplete']&&(_0x13a53d==='nodata'?_0x2ddcc9['push'](()=>_0x229497[_0x3e88f9]['onComplete'](null,!0x1,_0x229497[_0x3e88f9]['currentInputSnapshot'])):_0x2ddcc9['push'](()=>_0x229497[_0x3e88f9]['onComplete'](new Error(_0x13a53d),!0x1,null))));}Yn(_0x1c49bd,_0x1c49bd['transactionQueueTree_']);for(let _0x20b49d=0x0;_0x20b49d<_0x2ddcc9['length'];_0x20b49d++)ft(_0x2ddcc9[_0x20b49d]);Kn(_0x1c49bd,_0x1c49bd['transactionQueueTree_']);}function ga(_0x4c91bc,_0x224cfa){let _0x389ebe,_0x16644c=_0x4c91bc['transactionQueueTree_'];for(_0x389ebe=y(_0x224cfa);_0x389ebe!==null&&je(_0x16644c)===void 0x0;)_0x16644c=Gn(_0x16644c,_0x389ebe),_0x224cfa=S(_0x224cfa),_0x389ebe=y(_0x224cfa);return _0x16644c;}function ma(_0x53d269,_0x4dde57){const _0x2cc010=[];return ya(_0x53d269,_0x4dde57,_0x2cc010),_0x2cc010['sort']((_0xe0dcbf,_0x1ccb72)=>_0xe0dcbf['order']-_0x1ccb72['order']),_0x2cc010;}function ya(_0x2a9acb,_0x44db9b,_0x4bc348){const _0x26f5a5=je(_0x44db9b);if(_0x26f5a5){for(let _0x544bde=0x0;_0x544bde<_0x26f5a5['length'];_0x544bde++)_0x4bc348['push'](_0x26f5a5[_0x544bde]);}qn(_0x44db9b,_0x4cfab1=>{ya(_0x2a9acb,_0x4cfab1,_0x4bc348);});}function Yn(_0x5341c2,_0x3c5480){const _0xb8afad=je(_0x3c5480);if(_0xb8afad){let _0x51e1f1=0x0;for(let _0x129a61=0x0;_0x129a61<_0xb8afad['length'];_0x129a61++)_0xb8afad[_0x129a61]['status']!==0x2&&(_0xb8afad[_0x51e1f1]=_0xb8afad[_0x129a61],_0x51e1f1++);_0xb8afad['length']=_0x51e1f1,gs(_0x3c5480,_0xb8afad['length']>0x0?_0xb8afad:void 0x0);}qn(_0x3c5480,_0x31fb9a=>{Yn(_0x5341c2,_0x31fb9a);});}function Is(_0x22d070,_0x472c41){const _0x495f0f=Qt(ga(_0x22d070,_0x472c41)),_0x326c6e=Gn(_0x22d070['transactionQueueTree_'],_0x472c41);return ld(_0x326c6e,_0x70ae75=>{di(_0x22d070,_0x70ae75);}),di(_0x22d070,_0x326c6e),ca(_0x326c6e,_0x13f045=>{di(_0x22d070,_0x13f045);}),_0x495f0f;}function di(_0x3515aa,_0x51dc03){const _0x5b8184=je(_0x51dc03);if(_0x5b8184){const _0x284e89=[];let _0x1c3626=[],_0x25bf18=-0x1;for(let _0x2dee2b=0x0;_0x2dee2b<_0x5b8184['length'];_0x2dee2b++)_0x5b8184[_0x2dee2b]['status']===0x3||(_0x5b8184[_0x2dee2b]['status']===0x1?(f(_0x25bf18===_0x2dee2b-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x25bf18=_0x2dee2b,_0x5b8184[_0x2dee2b]['status']=0x3,_0x5b8184[_0x2dee2b]['abortReason']='set'):(f(_0x5b8184[_0x2dee2b]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x5b8184[_0x2dee2b]['unwatcher'](),_0x1c3626=_0x1c3626['concat'](_e(_0x3515aa['serverSyncTree_'],_0x5b8184[_0x2dee2b]['currentWriteId'],!0x0)),_0x5b8184[_0x2dee2b]['onComplete']&&_0x284e89['push'](_0x5b8184[_0x2dee2b]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x25bf18===-0x1?gs(_0x51dc03,void 0x0):_0x5b8184['length']=_0x25bf18+0x1,V(_0x3515aa['eventQueue_'],Qt(_0x51dc03),_0x1c3626);for(let _0x53f2b1=0x0;_0x53f2b1<_0x284e89['length'];_0x53f2b1++)ft(_0x284e89[_0x53f2b1]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Fd(_0x442d4e){let _0x26a6af='';const _0x396770=_0x442d4e['split']('/');for(let _0x2c06b8=0x0;_0x2c06b8<_0x396770['length'];_0x2c06b8++)if(_0x396770[_0x2c06b8]['length']>0x0){let _0x48993d=_0x396770[_0x2c06b8];try{_0x48993d=decodeURIComponent(_0x48993d['replace'](/\+/g,'\x20'));}catch{}_0x26a6af+='/'+_0x48993d;}return _0x26a6af;}function Ud(_0x345dc0){const _0x46e754={};_0x345dc0['charAt'](0x0)==='?'&&(_0x345dc0=_0x345dc0['substring'](0x1));for(const _0x5d2d5d of _0x345dc0['split']('&')){if(_0x5d2d5d['length']===0x0)continue;const _0x40d0c7=_0x5d2d5d['split']('=');_0x40d0c7['length']===0x2?_0x46e754[decodeURIComponent(_0x40d0c7[0x0])]=decodeURIComponent(_0x40d0c7[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x5d2d5d+'\x27\x20in\x20query\x20\x27'+_0x345dc0+'\x27');}return _0x46e754;}const Sr=function(_0x5b204e,_0x4795ff){const _0x7fcd4=Wd(_0x5b204e),_0xec3968=_0x7fcd4['namespace'];_0x7fcd4['domain']==='firebase.com'&&ae(_0x7fcd4['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0xec3968||_0xec3968==='undefined')&&_0x7fcd4['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x7fcd4['secure']||ql();const _0x124823=_0x7fcd4['scheme']==='ws'||_0x7fcd4['scheme']==='wss';return{'repoInfo':new To(_0x7fcd4['host'],_0x7fcd4['secure'],_0xec3968,_0x124823,_0x4795ff,'',_0xec3968!==_0x7fcd4['subdomain']),'path':new C(_0x7fcd4['pathString'])};},Wd=function(_0x2212d9){let _0x29a12f='',_0x16829e='',_0x17b6de='',_0x18043a='',_0x2499c1='',_0x3ee68c=!0x0,_0x4a09c2='https',_0x52d690=0x1bb;if(typeof _0x2212d9=='string'){let _0x543fe6=_0x2212d9['indexOf']('//');_0x543fe6>=0x0&&(_0x4a09c2=_0x2212d9['substring'](0x0,_0x543fe6-0x1),_0x2212d9=_0x2212d9['substring'](_0x543fe6+0x2));let _0x39a75c=_0x2212d9['indexOf']('/');_0x39a75c===-0x1&&(_0x39a75c=_0x2212d9['length']);let _0xec4092=_0x2212d9['indexOf']('?');_0xec4092===-0x1&&(_0xec4092=_0x2212d9['length']),_0x29a12f=_0x2212d9['substring'](0x0,Math['min'](_0x39a75c,_0xec4092)),_0x39a75c<_0xec4092&&(_0x18043a=Fd(_0x2212d9['substring'](_0x39a75c,_0xec4092)));const _0x1cab21=Ud(_0x2212d9['substring'](Math['min'](_0x2212d9['length'],_0xec4092)));_0x543fe6=_0x29a12f['indexOf'](':'),_0x543fe6>=0x0?(_0x3ee68c=_0x4a09c2==='https'||_0x4a09c2==='wss',_0x52d690=parseInt(_0x29a12f['substring'](_0x543fe6+0x1),0xa)):_0x543fe6=_0x29a12f['length'];const _0xc2b80e=_0x29a12f['slice'](0x0,_0x543fe6);if(_0xc2b80e['toLowerCase']()==='localhost')_0x16829e='localhost';else{if(_0xc2b80e['split']('.')['length']<=0x2)_0x16829e=_0xc2b80e;else{const _0x1cbbfb=_0x29a12f['indexOf']('.');_0x17b6de=_0x29a12f['substring'](0x0,_0x1cbbfb)['toLowerCase'](),_0x16829e=_0x29a12f['substring'](_0x1cbbfb+0x1),_0x2499c1=_0x17b6de;}}'ns'in _0x1cab21&&(_0x2499c1=_0x1cab21['ns']);}return{'host':_0x29a12f,'port':_0x52d690,'domain':_0x16829e,'subdomain':_0x17b6de,'secure':_0x3ee68c,'scheme':_0x4a09c2,'pathString':_0x18043a,'namespace':_0x2499c1};},br='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Bd=(function(){let _0x108f16=0x0;const _0x21f752=[];return function(_0x4c0bbd){const _0x3ec59f=_0x4c0bbd===_0x108f16;_0x108f16=_0x4c0bbd;let _0x40d8d0;const _0x3d9004=new Array(0x8);for(_0x40d8d0=0x7;_0x40d8d0>=0x0;_0x40d8d0--)_0x3d9004[_0x40d8d0]=br['charAt'](_0x4c0bbd%0x40),_0x4c0bbd=Math['floor'](_0x4c0bbd/0x40);f(_0x4c0bbd===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x2943ff=_0x3d9004['join']('');if(_0x3ec59f){for(_0x40d8d0=0xb;_0x40d8d0>=0x0&&_0x21f752[_0x40d8d0]===0x3f;_0x40d8d0--)_0x21f752[_0x40d8d0]=0x0;_0x21f752[_0x40d8d0]++;}else{for(_0x40d8d0=0x0;_0x40d8d0<0xc;_0x40d8d0++)_0x21f752[_0x40d8d0]=Math['floor'](Math['random']()*0x40);}for(_0x40d8d0=0x0;_0x40d8d0<0xc;_0x40d8d0++)_0x2943ff+=br['charAt'](_0x21f752[_0x40d8d0]);return f(_0x2943ff['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x2943ff;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x26e834,_0x4ae6ee,_0x39f656,_0x340d59){this['eventType']=_0x26e834,this['eventRegistration']=_0x4ae6ee,this['snapshot']=_0x39f656,this['prevName']=_0x340d59;}['getPath'](){const _0x1d40f5=this['snapshot']['ref'];return this['eventType']==='value'?_0x1d40f5['_path']:_0x1d40f5['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Hd{constructor(_0x5ad999,_0x5eb470,_0x593136){this['eventRegistration']=_0x5ad999,this['error']=_0x5eb470,this['path']=_0x593136;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{constructor(_0x3b3860,_0x26a7f1){this['snapshotCallback']=_0x3b3860,this['cancelCallback']=_0x26a7f1;}['onValue'](_0x27b9d1,_0x354ac3){this['snapshotCallback']['call'](null,_0x27b9d1,_0x354ac3);}['onCancel'](_0x5c1297){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x5c1297);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x504d24){return this['snapshotCallback']===_0x504d24['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x504d24['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x504d24['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $d{constructor(_0x42a6fe,_0x440343){this['_repo']=_0x42a6fe,this['_path']=_0x440343;}['cancel'](){const _0x572143=new H();return Ad(this['_repo'],this['_path'],_0x572143['wrapCallback'](()=>{})),_0x572143['promise'];}['remove'](){De('OnDisconnect.remove',this['_path']);const _0x5c8f01=new H();return Tr(this['_repo'],this['_path'],null,_0x5c8f01['wrapCallback'](()=>{})),_0x5c8f01['promise'];}['set'](_0x149555){De('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x149555,this['_path'],!0x1);const _0x441e23=new H();return Tr(this['_repo'],this['_path'],_0x149555,_0x441e23['wrapCallback'](()=>{})),_0x441e23['promise'];}['setWithPriority'](_0x4b6aa6,_0xf8212e){De('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x4b6aa6,this['_path'],!0x1),_d('OnDisconnect.setWithPriority',_0xf8212e);const _0x3e1a81=new H();return kd(this['_repo'],this['_path'],_0x4b6aa6,_0xf8212e,_0x3e1a81['wrapCallback'](()=>{})),_0x3e1a81['promise'];}['update'](_0x44e361){De('OnDisconnect.update',this['_path']),ha('OnDisconnect.update',_0x44e361,this['_path']);const _0x39913f=new H();return Nd(this['_repo'],this['_path'],_0x44e361,_0x39913f['wrapCallback'](()=>{})),_0x39913f['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mt{constructor(_0x48216d,_0x354f2c,_0x42ab1e,_0x3f5015){this['_repo']=_0x48216d,this['_path']=_0x354f2c,this['_queryParams']=_0x42ab1e,this['_orderByCalled']=_0x3f5015;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x282d58=hr(this['_queryParams']),_0x4edcbc=$i(_0x282d58);return _0x4edcbc==='{}'?'default':_0x4edcbc;}get['_queryObject'](){return hr(this['_queryParams']);}['isEqual'](_0x4135cd){if(_0x4135cd=N(_0x4135cd),!(_0x4135cd instanceof mt))return!0x1;const _0x40774e=this['_repo']===_0x4135cd['_repo'],_0x51779f=Ki(this['_path'],_0x4135cd['_path']),_0x10d29b=this['_queryIdentifier']===_0x4135cd['_queryIdentifier'];return _0x40774e&&_0x51779f&&_0x10d29b;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ah(this['_path']);}}function Gd(_0x88cb8c,_0x1528f7){if(_0x88cb8c['_orderByCalled']===!0x0)throw new Error(_0x1528f7+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function ws(_0x14ccaf){let _0x214509=null,_0x2e5e9f=null;if(_0x14ccaf['hasStart']()&&(_0x214509=_0x14ccaf['getIndexStartValue']()),_0x14ccaf['hasEnd']()&&(_0x2e5e9f=_0x14ccaf['getIndexEndValue']()),_0x14ccaf['getIndex']()===Me){const _0x191046='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x158217='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x14ccaf['hasStart']()){if(_0x14ccaf['getIndexStartName']()!==We)throw new Error(_0x191046);if(typeof _0x214509!='string')throw new Error(_0x158217);}if(_0x14ccaf['hasEnd']()){if(_0x14ccaf['getIndexEndName']()!==Ie)throw new Error(_0x191046);if(typeof _0x2e5e9f!='string')throw new Error(_0x158217);}}else{if(_0x14ccaf['getIndex']()===R){if(_0x214509!=null&&!Bt(_0x214509)||_0x2e5e9f!=null&&!Bt(_0x2e5e9f))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x14ccaf['getIndex']()instanceof Ji||_0x14ccaf['getIndex']()===Bo,'unknown\x20index\x20type.'),_0x214509!=null&&typeof _0x214509=='object'||_0x2e5e9f!=null&&typeof _0x2e5e9f=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function Ea(_0x4f70ce){if(_0x4f70ce['hasStart']()&&_0x4f70ce['hasEnd']()&&_0x4f70ce['hasLimit']()&&!_0x4f70ce['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends mt{constructor(_0x57cadd,_0x567b27){super(_0x57cadd,_0x567b27,new Zi(),!0x1);}get['parent'](){const _0x160e06=Do(this['_path']);return _0x160e06===null?null:new ee(this['_repo'],_0x160e06);}get['root'](){let _0x62ff24=this;for(;_0x62ff24['parent']!==null;)_0x62ff24=_0x62ff24['parent'];return _0x62ff24;}}class lt{constructor(_0x8737d0,_0x372ec4,_0x4a92f1){this['_node']=_0x8737d0,this['ref']=_0x372ec4,this['_index']=_0x4a92f1;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x2add07){const _0x287cbe=new C(_0x2add07),_0x16bef4=Vt(this['ref'],_0x2add07);return new lt(this['_node']['getChild'](_0x287cbe),_0x16bef4,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x2b0daa){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x5b0986,_0x199b58)=>_0x2b0daa(new lt(_0x199b58,Vt(this['ref'],_0x5b0986),R)));}['hasChild'](_0x31b3ce){const _0x4c760a=new C(_0x31b3ce);return!this['_node']['getChild'](_0x4c760a)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function I_(_0x21bbe8,_0x347017){return _0x21bbe8=N(_0x21bbe8),_0x21bbe8['_checkNotDeleted']('ref'),_0x347017!==void 0x0?Vt(_0x21bbe8['_root'],_0x347017):_0x21bbe8['_root'];}function Vt(_0x4c5253,_0x2f083c){return _0x4c5253=N(_0x4c5253),y(_0x4c5253['_path'])===null?gd('child','path',_0x2f083c):ys('child','path',_0x2f083c),new ee(_0x4c5253['_repo'],k(_0x4c5253['_path'],_0x2f083c));}function w_(_0x3b1f2f){return _0x3b1f2f=N(_0x3b1f2f),new $d(_0x3b1f2f['_repo'],_0x3b1f2f['_path']);}function C_(_0x31e96b,_0xbc5f7b){_0x31e96b=N(_0x31e96b),De('push',_0x31e96b['_path']),He('push',_0xbc5f7b,_0x31e96b['_path'],!0x0);const _0x589983=pa(_0x31e96b['_repo']),_0x16ea77=Bd(_0x589983),_0x439d6e=Vt(_0x31e96b,_0x16ea77),_0x1f3682=Vt(_0x31e96b,_0x16ea77);let _0x7b72e4;return _0xbc5f7b!=null?_0x7b72e4=qd(_0x1f3682,_0xbc5f7b)['then'](()=>_0x1f3682):_0x7b72e4=Promise['resolve'](_0x1f3682),_0x439d6e['then']=_0x7b72e4['then']['bind'](_0x7b72e4),_0x439d6e['catch']=_0x7b72e4['then']['bind'](_0x7b72e4,void 0x0),_0x439d6e;}function qd(_0x328441,_0x5e7890){_0x328441=N(_0x328441),De('set',_0x328441['_path']),He('set',_0x5e7890,_0x328441['_path'],!0x1);const _0x21064c=new H();return Sd(_0x328441['_repo'],_0x328441['_path'],_0x5e7890,null,_0x21064c['wrapCallback'](()=>{})),_0x21064c['promise'];}function T_(_0x364884,_0x80670e){ha('update',_0x80670e,_0x364884['_path']);const _0x6ba15e=new H();return bd(_0x364884['_repo'],_0x364884['_path'],_0x80670e,_0x6ba15e['wrapCallback'](()=>{})),_0x6ba15e['promise'];}function S_(_0x348bb9){_0x348bb9=N(_0x348bb9);const _0x440cf7=new va(()=>{}),_0x3b63b4=new Qn(_0x440cf7);return Td(_0x348bb9['_repo'],_0x348bb9,_0x3b63b4)['then'](_0x1e88bd=>new lt(_0x1e88bd,new ee(_0x348bb9['_repo'],_0x348bb9['_path']),_0x348bb9['_queryParams']['getIndex']()));}class Qn{constructor(_0x1e6298){this['callbackContext']=_0x1e6298;}['respondsTo'](_0x39d0de){return _0x39d0de==='value';}['createEvent'](_0x389e32,_0x463e97){const _0x988bed=_0x463e97['_queryParams']['getIndex']();return new Vd('value',this,new lt(_0x389e32['snapshotNode'],new ee(_0x463e97['_repo'],_0x463e97['_path']),_0x988bed));}['getEventRunner'](_0x48d2f8){return _0x48d2f8['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x48d2f8['error']):()=>this['callbackContext']['onValue'](_0x48d2f8['snapshot'],null);}['createCancelEvent'](_0x3ad4f2,_0x29dace){return this['callbackContext']['hasCancelCallback']?new Hd(this,_0x3ad4f2,_0x29dace):null;}['matches'](_0x8a9609){return _0x8a9609 instanceof Qn?!_0x8a9609['callbackContext']||!this['callbackContext']?!0x0:_0x8a9609['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function zd(_0x31ea6a,_0x45f7fc,_0x182557,_0x405c42,_0xe07aaf){const _0x57b074=new va(_0x182557,void 0x0),_0x5d0da0=new Qn(_0x57b074);return Pd(_0x31ea6a['_repo'],_0x31ea6a,_0x5d0da0),()=>Od(_0x31ea6a['_repo'],_0x31ea6a,_0x5d0da0);}function jd(_0x3fbf76,_0x461f1c,_0x74a3e8,_0x4cf35f){return zd(_0x3fbf76,'value',_0x461f1c);}class Jn{}class Kd extends Jn{constructor(_0xfc2a4f,_0x1ba626){super(),this['_value']=_0xfc2a4f,this['_key']=_0x1ba626,this['type']='endAt';}['_apply'](_0x225631){He('endAt',this['_value'],_0x225631['_path'],!0x0);const _0x176e8c=Xh(_0x225631['_queryParams'],this['_value'],this['_key']);if(Ea(_0x176e8c),ws(_0x176e8c),_0x225631['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new mt(_0x225631['_repo'],_0x225631['_path'],_0x176e8c,_0x225631['_orderByCalled']);}}class Yd extends Jn{constructor(_0x635d4f,_0x1c00a5){super(),this['_value']=_0x635d4f,this['_key']=_0x1c00a5,this['type']='startAt';}['_apply'](_0x3ddc5a){He('startAt',this['_value'],_0x3ddc5a['_path'],!0x0);const _0x325d1c=Jh(_0x3ddc5a['_queryParams'],this['_value'],this['_key']);if(Ea(_0x325d1c),ws(_0x325d1c),_0x3ddc5a['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new mt(_0x3ddc5a['_repo'],_0x3ddc5a['_path'],_0x325d1c,_0x3ddc5a['_orderByCalled']);}}class Qd extends Jn{constructor(_0x4cef8e){super(),this['_path']=_0x4cef8e,this['type']='orderByChild';}['_apply'](_0x41e14a){Gd(_0x41e14a,'orderByChild');const _0xe79912=new C(this['_path']);if(v(_0xe79912))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0xd6d709=new Ji(_0xe79912),_0x17a491=Zh(_0x41e14a['_queryParams'],_0xd6d709);return ws(_0x17a491),new mt(_0x41e14a['_repo'],_0x41e14a['_path'],_0x17a491,!0x0);}}function b_(_0x460815){if(_0x460815==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x460815==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x460815==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x460815),new Qd(_0x460815);}class Jd extends Jn{constructor(_0x1a5128,_0x30d0cf){super(),this['_value']=_0x1a5128,this['_key']=_0x30d0cf,this['type']='equalTo';}['_apply'](_0x4a37d4){if(He('equalTo',this['_value'],_0x4a37d4['_path'],!0x1),_0x4a37d4['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x4a37d4['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new Kd(this['_value'],this['_key'])['_apply'](new Yd(this['_value'],this['_key'])['_apply'](_0x4a37d4));}}function R_(_0x44e027,_0x2cb1fd){return new Jd(_0x44e027,_0x2cb1fd);}function A_(_0x5e6a0e,..._0x4ebeaf){let _0x20aa0e=N(_0x5e6a0e);for(const _0x185bef of _0x4ebeaf)_0x20aa0e=_0x185bef['_apply'](_0x20aa0e);return _0x20aa0e;}Vu(ee),zu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Zd=!0x1;function ef(_0x34ef6e,_0x4d35b8,_0x55bc53,_0xddbe70){const _0x3de615=_0x4d35b8['lastIndexOf'](':'),_0x952034=_0x4d35b8['substring'](0x0,_0x3de615),_0xd659b=qt(_0x952034);_0x34ef6e['repoInfo_']=new To(_0x4d35b8,_0xd659b,_0x34ef6e['repoInfo_']['namespace'],_0x34ef6e['repoInfo_']['webSocketOnly'],_0x34ef6e['repoInfo_']['nodeAdmin'],_0x34ef6e['repoInfo_']['persistenceKey'],_0x34ef6e['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x55bc53),_0xddbe70&&(_0x34ef6e['authTokenProvider_']=_0xddbe70);}function tf(_0x2ff2da,_0x114fde,_0x3c59be,_0x275b31,_0x17d149){let _0x3b72be=_0x275b31||_0x2ff2da['options']['databaseURL'];_0x3b72be===void 0x0&&(_0x2ff2da['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x2ff2da['options']['projectId']),_0x3b72be=_0x2ff2da['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x390eb5=Sr(_0x3b72be,_0x17d149),_0x390ea1=_0x390eb5['repoInfo'],_0x53e0bd;typeof process<'u'&&zs&&(_0x53e0bd=zs[Xd]),_0x53e0bd?(_0x3b72be='http://'+_0x53e0bd+'?ns='+_0x390ea1['namespace'],_0x390eb5=Sr(_0x3b72be,_0x17d149),_0x390ea1=_0x390eb5['repoInfo']):_0x390eb5['repoInfo']['secure'];const _0x5f2bb2=new nh(_0x2ff2da['name'],_0x2ff2da['options'],_0x114fde);md('Invalid\x20Firebase\x20Database\x20URL',_0x390eb5),v(_0x390eb5['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x59f803=sf(_0x390ea1,_0x2ff2da,_0x5f2bb2,new th(_0x2ff2da,_0x3c59be));return new rf(_0x59f803,_0x2ff2da);}function nf(_0x4bc51c,_0x3081c9){const _0x1fb608=Di[_0x3081c9];(!_0x1fb608||_0x1fb608[_0x4bc51c['key']]!==_0x4bc51c)&&ae('Database\x20'+_0x3081c9+'('+_0x4bc51c['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),_a(_0x4bc51c),delete _0x1fb608[_0x4bc51c['key']];}function sf(_0x53923a,_0x21f685,_0x53a973,_0x5c400a){let _0x359904=Di[_0x21f685['name']];_0x359904||(_0x359904={},Di[_0x21f685['name']]=_0x359904);let _0x11efa9=_0x359904[_0x53923a['toURLString']()];return _0x11efa9&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x11efa9=new Id(_0x53923a,Zd,_0x53a973,_0x5c400a),_0x359904[_0x53923a['toURLString']()]=_0x11efa9,_0x11efa9;}class rf{constructor(_0x5b572b,_0x559e88){this['_repoInternal']=_0x5b572b,this['app']=_0x559e88,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(wd(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(nf(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x4d6600){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x4d6600+'\x20on\x20a\x20deleted\x20database.');}}function k_(_0x2d045f=ro(),_0x1d9f7b){const _0xe4b4=Hi(_0x2d045f,'database')['getImmediate']({'identifier':_0x1d9f7b});if(!_0xe4b4['_instanceStarted']){const _0x48424d=dc('database');_0x48424d&&of(_0xe4b4,..._0x48424d);}return _0xe4b4;}function of(_0x4b4e53,_0x538a6e,_0x469f8f,_0x2789d2={}){_0x4b4e53=N(_0x4b4e53),_0x4b4e53['_checkNotDeleted']('useEmulator');const _0x4a272=_0x538a6e+':'+_0x469f8f,_0x47b471=_0x4b4e53['_repoInternal'];if(_0x4b4e53['_instanceStarted']){if(_0x4a272===_0x4b4e53['_repoInternal']['repoInfo_']['host']&&xe(_0x2789d2,_0x47b471['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x1f4712;if(_0x47b471['repoInfo_']['nodeAdmin'])_0x2789d2['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x1f4712=new cn(cn['OWNER']);else{if(_0x2789d2['mockUserToken']){const _0x303dd5=typeof _0x2789d2['mockUserToken']=='string'?_0x2789d2['mockUserToken']:fc(_0x2789d2['mockUserToken'],_0x4b4e53['app']['options']['projectId']);_0x1f4712=new cn(_0x303dd5);}}qt(_0x538a6e)&&no(_0x538a6e),ef(_0x47b471,_0x4a272,_0x2789d2,_0x1f4712);}function N_(_0x10937f){_0x10937f=N(_0x10937f),_0x10937f['_checkNotDeleted']('goOffline'),_a(_0x10937f['_repo']);}function P_(_0x25804e){_0x25804e=N(_0x25804e),_0x25804e['_checkNotDeleted']('goOnline'),Dd(_0x25804e['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function af(_0x7c1fb4){Bl(dt),st(new Fe('database',(_0x2f5428,{instanceIdentifier:_0x37489b})=>{const _0x43c98c=_0x2f5428['getProvider']('app')['getImmediate'](),_0x301724=_0x2f5428['getProvider']('auth-internal'),_0xb35938=_0x2f5428['getProvider']('app-check-internal');return tf(_0x43c98c,_0x301724,_0xb35938,_0x37489b);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(js,Ks,_0x7c1fb4),ye(js,Ks,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'.sv':'timestamp'};function O_(){return cf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lf{constructor(_0x375b74,_0x9b5180){this['committed']=_0x375b74,this['snapshot']=_0x9b5180;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function D_(_0x471e39,_0x11fe2c,_0x490cd6){if(_0x471e39=N(_0x471e39),De('Reference.transaction',_0x471e39['_path']),_0x471e39['key']==='.length'||_0x471e39['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x471e39['key']+'\x20is\x20a\x20read-only\x20object.';const _0x53ad2c=!0x0,_0x1b3ccd=new H(),_0x313165=(_0x73d971,_0x12bf37,_0x19c6fe)=>{let _0x4a18c7=null;_0x73d971?_0x1b3ccd['reject'](_0x73d971):(_0x4a18c7=new lt(_0x19c6fe,new ee(_0x471e39['_repo'],_0x471e39['_path']),R),_0x1b3ccd['resolve'](new lf(_0x12bf37,_0x4a18c7)));},_0x1da571=jd(_0x471e39,()=>{});return Md(_0x471e39['_repo'],_0x471e39['_path'],_0x11fe2c,_0x313165,_0x1da571,_0x53ad2c),_0x1b3ccd['promise'];}se['prototype']['simpleListen']=function(_0x183465,_0x4776e1){this['sendRequest']('q',{'p':_0x183465},_0x4776e1);},se['prototype']['echo']=function(_0x4f24a1,_0x324cd5){this['sendRequest']('echo',{'d':_0x4f24a1},_0x324cd5);},af();function Ia(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const hf=Ia,wa=new Gt('auth','Firebase',Ia()),Nn=new Bi('@firebase/auth');function uf(_0x4afc8f,..._0x47d07f){Nn['logLevel']<=T['WARN']&&Nn['warn']('Auth\x20('+dt+'):\x20'+_0x4afc8f,..._0x47d07f);}function ln(_0x22bcfa,..._0xc0612c){Nn['logLevel']<=T['ERROR']&&Nn['error']('Auth\x20('+dt+'):\x20'+_0x22bcfa,..._0xc0612c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x216229,..._0x4ac5b9){throw Cs(_0x216229,..._0x4ac5b9);}function X(_0x2c3a01,..._0x532272){return Cs(_0x2c3a01,..._0x532272);}function Ca(_0x1a0db0,_0x330b19,_0x409e41){const _0x161c78={...hf(),[_0x330b19]:_0x409e41};return new Gt('auth','Firebase',_0x161c78)['create'](_0x330b19,{'appName':_0x1a0db0['name']});}function re(_0x3ff59a){return Ca(_0x3ff59a,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Cs(_0x5e8419,..._0x28b148){if(typeof _0x5e8419!='string'){const _0x560dca=_0x28b148[0x0],_0x55ded0=[..._0x28b148['slice'](0x1)];return _0x55ded0[0x0]&&(_0x55ded0[0x0]['appName']=_0x5e8419['name']),_0x5e8419['_errorFactory']['create'](_0x560dca,..._0x55ded0);}return wa['create'](_0x5e8419,..._0x28b148);}function m(_0x1e7974,_0x5d7d28,..._0x1a58ce){if(!_0x1e7974)throw Cs(_0x5d7d28,..._0x1a58ce);}function ne(_0x568c7d){const _0x22911a='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x568c7d;throw ln(_0x22911a),new Error(_0x22911a);}function ce(_0x1cef89,_0xf3c263){_0x1cef89||ne(_0xf3c263);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x25a2d9;return typeof self<'u'&&((_0x25a2d9=self['location'])==null?void 0x0:_0x25a2d9['href'])||'';}function df(){return Rr()==='http:'||Rr()==='https:';}function Rr(){var _0x51ed87;return typeof self<'u'&&((_0x51ed87=self['location'])==null?void 0x0:_0x51ed87['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ff(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(df()||_c()||'connection'in navigator)?navigator['onLine']:!0x0;}function pf(){if(typeof navigator>'u')return null;const _0x935483=navigator;return _0x935483['languages']&&_0x935483['languages'][0x0]||_0x935483['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x281fcc,_0xde142a){this['shortDelay']=_0x281fcc,this['longDelay']=_0xde142a,ce(_0xde142a>_0x281fcc,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||eo();}['get'](){return ff()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ts(_0x1a6cc1,_0x491c77){ce(_0x1a6cc1['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x321a62}=_0x1a6cc1['emulator'];return _0x491c77?''+_0x321a62+(_0x491c77['startsWith']('/')?_0x491c77['slice'](0x1):_0x491c77):_0x321a62;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ta{static['initialize'](_0x2fbac1,_0x1d49fd,_0x2af382){this['fetchImpl']=_0x2fbac1,_0x1d49fd&&(this['headersImpl']=_0x1d49fd),_0x2af382&&(this['responseImpl']=_0x2af382);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _f={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},gf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],mf=new Zt(0x7530,0xea60);function Re(_0x1c1ebf,_0x3e6086){return _0x1c1ebf['tenantId']&&!_0x3e6086['tenantId']?{..._0x3e6086,'tenantId':_0x1c1ebf['tenantId']}:_0x3e6086;}async function Ae(_0x462d29,_0x1386cf,_0x408396,_0x3ee104,_0x4c69e8={}){return Sa(_0x462d29,_0x4c69e8,async()=>{let _0x2783c2={},_0x447847={};_0x3ee104&&(_0x1386cf==='GET'?_0x447847=_0x3ee104:_0x2783c2={'body':JSON['stringify'](_0x3ee104)});const _0x58eee5=ut({..._0x447847,'key':_0x462d29['config']['apiKey']})['slice'](0x1),_0x9cd066=await _0x462d29['_getAdditionalHeaders']();_0x9cd066['Content-Type']='application/json',_0x462d29['languageCode']&&(_0x9cd066['X-Firebase-Locale']=_0x462d29['languageCode']);const _0x1ed5b7={'method':_0x1386cf,'headers':_0x9cd066,..._0x2783c2};return pc()||(_0x1ed5b7['referrerPolicy']='strict-origin-when-cross-origin'),_0x462d29['emulatorConfig']&&qt(_0x462d29['emulatorConfig']['host'])&&(_0x1ed5b7['credentials']='include'),Ta['fetch']()(await ba(_0x462d29,_0x462d29['config']['apiHost'],_0x408396,_0x58eee5),_0x1ed5b7);});}async function Sa(_0xb21c95,_0x4ec7bb,_0x57885e){_0xb21c95['_canInitEmulator']=!0x1;const _0x71fa73={..._f,..._0x4ec7bb};try{const _0x1b828b=new vf(_0xb21c95),_0x506211=await Promise['race']([_0x57885e(),_0x1b828b['promise']]);_0x1b828b['clearNetworkTimeout']();const _0x2b2046=await _0x506211['json']();if('needConfirmation'in _0x2b2046)throw an(_0xb21c95,'account-exists-with-different-credential',_0x2b2046);if(_0x506211['ok']&&!('errorMessage'in _0x2b2046))return _0x2b2046;{const _0x3ab89d=_0x506211['ok']?_0x2b2046['errorMessage']:_0x2b2046['error']['message'],[_0x23446e,_0x2d11bc]=_0x3ab89d['split']('\x20:\x20');if(_0x23446e==='FEDERATED_USER_ID_ALREADY_LINKED')throw an(_0xb21c95,'credential-already-in-use',_0x2b2046);if(_0x23446e==='EMAIL_EXISTS')throw an(_0xb21c95,'email-already-in-use',_0x2b2046);if(_0x23446e==='USER_DISABLED')throw an(_0xb21c95,'user-disabled',_0x2b2046);const _0x23217a=_0x71fa73[_0x23446e]||_0x23446e['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x2d11bc)throw Ca(_0xb21c95,_0x23217a,_0x2d11bc);Y(_0xb21c95,_0x23217a);}}catch(_0x2f2a55){if(_0x2f2a55 instanceof be)throw _0x2f2a55;Y(_0xb21c95,'network-request-failed',{'message':String(_0x2f2a55)});}}async function en(_0xf87fb8,_0x54502d,_0x3d173a,_0x5346aa,_0x5f43c5={}){const _0x24b7c3=await Ae(_0xf87fb8,_0x54502d,_0x3d173a,_0x5346aa,_0x5f43c5);return'mfaPendingCredential'in _0x24b7c3&&Y(_0xf87fb8,'multi-factor-auth-required',{'_serverResponse':_0x24b7c3}),_0x24b7c3;}async function ba(_0x1e8083,_0x33f2e7,_0x9c7d0a,_0x410ef6){const _0x2daea4=''+_0x33f2e7+_0x9c7d0a+'?'+_0x410ef6,_0x130e8c=_0x1e8083,_0x323e47=_0x130e8c['config']['emulator']?Ts(_0x1e8083['config'],_0x2daea4):_0x1e8083['config']['apiScheme']+'://'+_0x2daea4;return gf['includes'](_0x9c7d0a)&&(await _0x130e8c['_persistenceManagerAvailable'],_0x130e8c['_getPersistenceType']()==='COOKIE')?_0x130e8c['_getPersistence']()['_getFinalTarget'](_0x323e47)['toString']():_0x323e47;}function yf(_0x494416){switch(_0x494416){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class vf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x23db70){this['auth']=_0x23db70,this['timer']=null,this['promise']=new Promise((_0x3d2153,_0x24aee4)=>{this['timer']=setTimeout(()=>_0x24aee4(X(this['auth'],'network-request-failed')),mf['get']());});}}function an(_0x308dfe,_0x4b0b06,_0x1fe5e1){const _0x4cd613={'appName':_0x308dfe['name']};_0x1fe5e1['email']&&(_0x4cd613['email']=_0x1fe5e1['email']),_0x1fe5e1['phoneNumber']&&(_0x4cd613['phoneNumber']=_0x1fe5e1['phoneNumber']);const _0x2b9e7f=X(_0x308dfe,_0x4b0b06,_0x4cd613);return _0x2b9e7f['customData']['_tokenResponse']=_0x1fe5e1,_0x2b9e7f;}function Ar(_0xed724d){return _0xed724d!==void 0x0&&_0xed724d['enterprise']!==void 0x0;}class Ef{constructor(_0x2e0a27){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x2e0a27['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x2e0a27['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x2e0a27['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x1c422b){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x1af891 of this['recaptchaEnforcementState'])if(_0x1af891['provider']&&_0x1af891['provider']===_0x1c422b)return yf(_0x1af891['enforcementState']);return null;}['isProviderEnabled'](_0x562d82){return this['getProviderEnforcementState'](_0x562d82)==='ENFORCE'||this['getProviderEnforcementState'](_0x562d82)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function If(_0x12e625,_0x9ff1b2){return Ae(_0x12e625,'GET','/v2/recaptchaConfig',Re(_0x12e625,_0x9ff1b2));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function wf(_0x40fe8c,_0xf8ab79){return Ae(_0x40fe8c,'POST','/v1/accounts:delete',_0xf8ab79);}async function Pn(_0x28b594,_0x13d708){return Ae(_0x28b594,'POST','/v1/accounts:lookup',_0x13d708);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x12a4f8){if(_0x12a4f8)try{const _0x303e2e=new Date(Number(_0x12a4f8));if(!isNaN(_0x303e2e['getTime']()))return _0x303e2e['toUTCString']();}catch{}}async function Cf(_0x63a77f,_0xa036b2=!0x1){const _0x4d5d7a=N(_0x63a77f),_0x518f71=await _0x4d5d7a['getIdToken'](_0xa036b2),_0x5573c3=Ss(_0x518f71);m(_0x5573c3&&_0x5573c3['exp']&&_0x5573c3['auth_time']&&_0x5573c3['iat'],_0x4d5d7a['auth'],'internal-error');const _0x3e58c3=typeof _0x5573c3['firebase']=='object'?_0x5573c3['firebase']:void 0x0,_0x25a7da=_0x3e58c3==null?void 0x0:_0x3e58c3['sign_in_provider'];return{'claims':_0x5573c3,'token':_0x518f71,'authTime':Nt(fi(_0x5573c3['auth_time'])),'issuedAtTime':Nt(fi(_0x5573c3['iat'])),'expirationTime':Nt(fi(_0x5573c3['exp'])),'signInProvider':_0x25a7da||null,'signInSecondFactor':(_0x3e58c3==null?void 0x0:_0x3e58c3['sign_in_second_factor'])||null};}function fi(_0x44493){return Number(_0x44493)*0x3e8;}function Ss(_0x1c3da4){const [_0x7e9cd1,_0x47d044,_0x147ace]=_0x1c3da4['split']('.');if(_0x7e9cd1===void 0x0||_0x47d044===void 0x0||_0x147ace===void 0x0)return ln('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x4df639=pn(_0x47d044);return _0x4df639?JSON['parse'](_0x4df639):(ln('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x4526a8){return ln('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x4526a8==null?void 0x0:_0x4526a8['toString']()),null;}}function kr(_0x4d24af){const _0x35a2e3=Ss(_0x4d24af);return m(_0x35a2e3,'internal-error'),m(typeof _0x35a2e3['exp']<'u','internal-error'),m(typeof _0x35a2e3['iat']<'u','internal-error'),Number(_0x35a2e3['exp'])-Number(_0x35a2e3['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x38e7a7,_0x3d4920,_0x155f2d=!0x1){if(_0x155f2d)return _0x3d4920;try{return await _0x3d4920;}catch(_0x24b2d3){throw _0x24b2d3 instanceof be&&Tf(_0x24b2d3)&&_0x38e7a7['auth']['currentUser']===_0x38e7a7&&await _0x38e7a7['auth']['signOut'](),_0x24b2d3;}}function Tf({code:_0x5e24a8}){return _0x5e24a8==='auth/user-disabled'||_0x5e24a8==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x57e159){this['user']=_0x57e159,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x139aa4){var _0x2f0076;if(_0x139aa4){const _0xbee34c=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0xbee34c;}else{this['errorBackoff']=0x7530;const _0x56ae8b=((_0x2f0076=this['user']['stsTokenManager']['expirationTime'])!=null?_0x2f0076:0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x56ae8b);}}['schedule'](_0x4164d3=!0x1){if(!this['isRunning'])return;const _0x810370=this['getInterval'](_0x4164d3);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x810370);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x38a151){(_0x38a151==null?void 0x0:_0x38a151['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x4e97a3,_0x11c813){this['createdAt']=_0x4e97a3,this['lastLoginAt']=_0x11c813,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Nt(this['lastLoginAt']),this['creationTime']=Nt(this['createdAt']);}['_copy'](_0x18697d){this['createdAt']=_0x18697d['createdAt'],this['lastLoginAt']=_0x18697d['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function On(_0x4b99c6){var _0x445434;const _0x3f4204=_0x4b99c6['auth'],_0x9f2470=await _0x4b99c6['getIdToken'](),_0x2f8302=await Ht(_0x4b99c6,Pn(_0x3f4204,{'idToken':_0x9f2470}));m(_0x2f8302==null?void 0x0:_0x2f8302['users']['length'],_0x3f4204,'internal-error');const _0x2d9757=_0x2f8302['users'][0x0];_0x4b99c6['_notifyReloadListener'](_0x2d9757);const _0x543938=(_0x445434=_0x2d9757['providerUserInfo'])!=null&&_0x445434['length']?Ra(_0x2d9757['providerUserInfo']):[],_0xfd0563=Rf(_0x4b99c6['providerData'],_0x543938),_0x4f7d20=_0x4b99c6['isAnonymous'],_0x37232a=!(_0x4b99c6['email']&&_0x2d9757['passwordHash'])&&!(_0xfd0563!=null&&_0xfd0563['length']),_0x494799=_0x4f7d20?_0x37232a:!0x1,_0x5cf76a={'uid':_0x2d9757['localId'],'displayName':_0x2d9757['displayName']||null,'photoURL':_0x2d9757['photoUrl']||null,'email':_0x2d9757['email']||null,'emailVerified':_0x2d9757['emailVerified']||!0x1,'phoneNumber':_0x2d9757['phoneNumber']||null,'tenantId':_0x2d9757['tenantId']||null,'providerData':_0xfd0563,'metadata':new Li(_0x2d9757['createdAt'],_0x2d9757['lastLoginAt']),'isAnonymous':_0x494799};Object['assign'](_0x4b99c6,_0x5cf76a);}async function bf(_0x222ddd){const _0x21bb26=N(_0x222ddd);await On(_0x21bb26),await _0x21bb26['auth']['_persistUserIfCurrent'](_0x21bb26),_0x21bb26['auth']['_notifyListenersIfCurrent'](_0x21bb26);}function Rf(_0x2b7565,_0x3de87b){return[..._0x2b7565['filter'](_0x1a32f4=>!_0x3de87b['some'](_0x3c8a9d=>_0x3c8a9d['providerId']===_0x1a32f4['providerId'])),..._0x3de87b];}function Ra(_0x3f9750){return _0x3f9750['map'](({providerId:_0x2026bf,..._0x4f473a})=>({'providerId':_0x2026bf,'uid':_0x4f473a['rawId']||'','displayName':_0x4f473a['displayName']||null,'email':_0x4f473a['email']||null,'phoneNumber':_0x4f473a['phoneNumber']||null,'photoURL':_0x4f473a['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Af(_0x335500,_0x53a2d2){const _0x373838=await Sa(_0x335500,{},async()=>{const _0xf6285e=ut({'grant_type':'refresh_token','refresh_token':_0x53a2d2})['slice'](0x1),{tokenApiHost:_0x245080,apiKey:_0x70bf8c}=_0x335500['config'],_0x1125fd=await ba(_0x335500,_0x245080,'/v1/token','key='+_0x70bf8c),_0x2c699f=await _0x335500['_getAdditionalHeaders']();_0x2c699f['Content-Type']='application/x-www-form-urlencoded';const _0x48e9e2={'method':'POST','headers':_0x2c699f,'body':_0xf6285e};return _0x335500['emulatorConfig']&&qt(_0x335500['emulatorConfig']['host'])&&(_0x48e9e2['credentials']='include'),Ta['fetch']()(_0x1125fd,_0x48e9e2);});return{'accessToken':_0x373838['access_token'],'expiresIn':_0x373838['expires_in'],'refreshToken':_0x373838['refresh_token']};}async function kf(_0xab8a74,_0x4d4cbe){return Ae(_0xab8a74,'POST','/v2/accounts:revokeToken',Re(_0xab8a74,_0x4d4cbe));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x2a178d){m(_0x2a178d['idToken'],'internal-error'),m(typeof _0x2a178d['idToken']<'u','internal-error'),m(typeof _0x2a178d['refreshToken']<'u','internal-error');const _0x4d5b96='expiresIn'in _0x2a178d&&typeof _0x2a178d['expiresIn']<'u'?Number(_0x2a178d['expiresIn']):kr(_0x2a178d['idToken']);this['updateTokensAndExpiration'](_0x2a178d['idToken'],_0x2a178d['refreshToken'],_0x4d5b96);}['updateFromIdToken'](_0x19568b){m(_0x19568b['length']!==0x0,'internal-error');const _0x100501=kr(_0x19568b);this['updateTokensAndExpiration'](_0x19568b,null,_0x100501);}async['getToken'](_0x287a2e,_0x29b9d4=!0x1){return!_0x29b9d4&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x287a2e,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x287a2e,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x45b83c,_0x3c17d8){const {accessToken:_0x34e825,refreshToken:_0x4d3c91,expiresIn:_0xcb686a}=await Af(_0x45b83c,_0x3c17d8);this['updateTokensAndExpiration'](_0x34e825,_0x4d3c91,Number(_0xcb686a));}['updateTokensAndExpiration'](_0x52a873,_0x1d0512,_0x2cbf19){this['refreshToken']=_0x1d0512||null,this['accessToken']=_0x52a873||null,this['expirationTime']=Date['now']()+_0x2cbf19*0x3e8;}static['fromJSON'](_0x1b298d,_0x4276dd){const {refreshToken:_0x38d604,accessToken:_0xa9ad03,expirationTime:_0x5b77c0}=_0x4276dd,_0x16d1ec=new et();return _0x38d604&&(m(typeof _0x38d604=='string','internal-error',{'appName':_0x1b298d}),_0x16d1ec['refreshToken']=_0x38d604),_0xa9ad03&&(m(typeof _0xa9ad03=='string','internal-error',{'appName':_0x1b298d}),_0x16d1ec['accessToken']=_0xa9ad03),_0x5b77c0&&(m(typeof _0x5b77c0=='number','internal-error',{'appName':_0x1b298d}),_0x16d1ec['expirationTime']=_0x5b77c0),_0x16d1ec;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x375897){this['accessToken']=_0x375897['accessToken'],this['refreshToken']=_0x375897['refreshToken'],this['expirationTime']=_0x375897['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x298a61,_0x17ef5b){m(typeof _0x298a61=='string'||typeof _0x298a61>'u','internal-error',{'appName':_0x17ef5b});}class j{constructor({uid:_0x137ded,auth:_0x3b7e09,stsTokenManager:_0x550123,..._0x56c57d}){this['providerId']='firebase',this['proactiveRefresh']=new Sf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x137ded,this['auth']=_0x3b7e09,this['stsTokenManager']=_0x550123,this['accessToken']=_0x550123['accessToken'],this['displayName']=_0x56c57d['displayName']||null,this['email']=_0x56c57d['email']||null,this['emailVerified']=_0x56c57d['emailVerified']||!0x1,this['phoneNumber']=_0x56c57d['phoneNumber']||null,this['photoURL']=_0x56c57d['photoURL']||null,this['isAnonymous']=_0x56c57d['isAnonymous']||!0x1,this['tenantId']=_0x56c57d['tenantId']||null,this['providerData']=_0x56c57d['providerData']?[..._0x56c57d['providerData']]:[],this['metadata']=new Li(_0x56c57d['createdAt']||void 0x0,_0x56c57d['lastLoginAt']||void 0x0);}async['getIdToken'](_0x18c30b){const _0x3df837=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x18c30b));return m(_0x3df837,this['auth'],'internal-error'),this['accessToken']!==_0x3df837&&(this['accessToken']=_0x3df837,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x3df837;}['getIdTokenResult'](_0x1bf2a0){return Cf(this,_0x1bf2a0);}['reload'](){return bf(this);}['_assign'](_0x2271ea){this!==_0x2271ea&&(m(this['uid']===_0x2271ea['uid'],this['auth'],'internal-error'),this['displayName']=_0x2271ea['displayName'],this['photoURL']=_0x2271ea['photoURL'],this['email']=_0x2271ea['email'],this['emailVerified']=_0x2271ea['emailVerified'],this['phoneNumber']=_0x2271ea['phoneNumber'],this['isAnonymous']=_0x2271ea['isAnonymous'],this['tenantId']=_0x2271ea['tenantId'],this['providerData']=_0x2271ea['providerData']['map'](_0x3ff450=>({..._0x3ff450})),this['metadata']['_copy'](_0x2271ea['metadata']),this['stsTokenManager']['_assign'](_0x2271ea['stsTokenManager']));}['_clone'](_0x217999){const _0x27c1ad=new j({...this,'auth':_0x217999,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x27c1ad['metadata']['_copy'](this['metadata']),_0x27c1ad;}['_onReload'](_0x2b5c1f){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x2b5c1f,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x17c518){this['reloadListener']?this['reloadListener'](_0x17c518):this['reloadUserInfo']=_0x17c518;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x87bff3,_0x3339e7=!0x1){let _0x1e2d98=!0x1;_0x87bff3['idToken']&&_0x87bff3['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x87bff3),_0x1e2d98=!0x0),_0x3339e7&&await On(this),await this['auth']['_persistUserIfCurrent'](this),_0x1e2d98&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x4ec049=await this['getIdToken']();return await Ht(this,wf(this['auth'],{'idToken':_0x4ec049})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x1ff1ac=>({..._0x1ff1ac})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x3a145d,_0x28b16c){var _0x4eb48d,_0xf3d6d7,_0x4b9751,_0x17db57,_0x1d2441,_0x322ec0,_0x1ce2e4,_0x7d326;const _0x4b992f=(_0x4eb48d=_0x28b16c['displayName'])!=null?_0x4eb48d:void 0x0,_0x2313b6=(_0xf3d6d7=_0x28b16c['email'])!=null?_0xf3d6d7:void 0x0,_0xefd8ca=(_0x4b9751=_0x28b16c['phoneNumber'])!=null?_0x4b9751:void 0x0,_0x411f12=(_0x17db57=_0x28b16c['photoURL'])!=null?_0x17db57:void 0x0,_0x56b97a=(_0x1d2441=_0x28b16c['tenantId'])!=null?_0x1d2441:void 0x0,_0x27e35b=(_0x322ec0=_0x28b16c['_redirectEventId'])!=null?_0x322ec0:void 0x0,_0x5bf43e=(_0x1ce2e4=_0x28b16c['createdAt'])!=null?_0x1ce2e4:void 0x0,_0x554e41=(_0x7d326=_0x28b16c['lastLoginAt'])!=null?_0x7d326:void 0x0,{uid:_0x2b59a8,emailVerified:_0xd63408,isAnonymous:_0x5e110f,providerData:_0x171678,stsTokenManager:_0x4ad18d}=_0x28b16c;m(_0x2b59a8&&_0x4ad18d,_0x3a145d,'internal-error');const _0x4422cc=et['fromJSON'](this['name'],_0x4ad18d);m(typeof _0x2b59a8=='string',_0x3a145d,'internal-error'),le(_0x4b992f,_0x3a145d['name']),le(_0x2313b6,_0x3a145d['name']),m(typeof _0xd63408=='boolean',_0x3a145d,'internal-error'),m(typeof _0x5e110f=='boolean',_0x3a145d,'internal-error'),le(_0xefd8ca,_0x3a145d['name']),le(_0x411f12,_0x3a145d['name']),le(_0x56b97a,_0x3a145d['name']),le(_0x27e35b,_0x3a145d['name']),le(_0x5bf43e,_0x3a145d['name']),le(_0x554e41,_0x3a145d['name']);const _0x21c1eb=new j({'uid':_0x2b59a8,'auth':_0x3a145d,'email':_0x2313b6,'emailVerified':_0xd63408,'displayName':_0x4b992f,'isAnonymous':_0x5e110f,'photoURL':_0x411f12,'phoneNumber':_0xefd8ca,'tenantId':_0x56b97a,'stsTokenManager':_0x4422cc,'createdAt':_0x5bf43e,'lastLoginAt':_0x554e41});return _0x171678&&Array['isArray'](_0x171678)&&(_0x21c1eb['providerData']=_0x171678['map'](_0x4aafb7=>({..._0x4aafb7}))),_0x27e35b&&(_0x21c1eb['_redirectEventId']=_0x27e35b),_0x21c1eb;}static async['_fromIdTokenResponse'](_0x669451,_0x5372c3,_0x248aab=!0x1){const _0x2ad1b4=new et();_0x2ad1b4['updateFromServerResponse'](_0x5372c3);const _0x1e81a2=new j({'uid':_0x5372c3['localId'],'auth':_0x669451,'stsTokenManager':_0x2ad1b4,'isAnonymous':_0x248aab});return await On(_0x1e81a2),_0x1e81a2;}static async['_fromGetAccountInfoResponse'](_0x513a6f,_0x32be5e,_0x186f1a){const _0x1d7d02=_0x32be5e['users'][0x0];m(_0x1d7d02['localId']!==void 0x0,'internal-error');const _0x22bb8e=_0x1d7d02['providerUserInfo']!==void 0x0?Ra(_0x1d7d02['providerUserInfo']):[],_0x3e3537=!(_0x1d7d02['email']&&_0x1d7d02['passwordHash'])&&!(_0x22bb8e!=null&&_0x22bb8e['length']),_0x21d5c2=new et();_0x21d5c2['updateFromIdToken'](_0x186f1a);const _0xe13190=new j({'uid':_0x1d7d02['localId'],'auth':_0x513a6f,'stsTokenManager':_0x21d5c2,'isAnonymous':_0x3e3537}),_0x15ae06={'uid':_0x1d7d02['localId'],'displayName':_0x1d7d02['displayName']||null,'photoURL':_0x1d7d02['photoUrl']||null,'email':_0x1d7d02['email']||null,'emailVerified':_0x1d7d02['emailVerified']||!0x1,'phoneNumber':_0x1d7d02['phoneNumber']||null,'tenantId':_0x1d7d02['tenantId']||null,'providerData':_0x22bb8e,'metadata':new Li(_0x1d7d02['createdAt'],_0x1d7d02['lastLoginAt']),'isAnonymous':!(_0x1d7d02['email']&&_0x1d7d02['passwordHash'])&&!(_0x22bb8e!=null&&_0x22bb8e['length'])};return Object['assign'](_0xe13190,_0x15ae06),_0xe13190;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nr=new Map();function ie(_0x4026a7){ce(_0x4026a7 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x222739=Nr['get'](_0x4026a7);return _0x222739?(ce(_0x222739 instanceof _0x4026a7,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x222739):(_0x222739=new _0x4026a7(),Nr['set'](_0x4026a7,_0x222739),_0x222739);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Aa{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x568f14,_0x5cef61){this['storage'][_0x568f14]=_0x5cef61;}async['_get'](_0x4260f9){const _0x31f060=this['storage'][_0x4260f9];return _0x31f060===void 0x0?null:_0x31f060;}async['_remove'](_0x59f25f){delete this['storage'][_0x59f25f];}['_addListener'](_0x1b90f6,_0xb35076){}['_removeListener'](_0x44ed65,_0x2571e6){}}Aa['type']='NONE';const Pr=Aa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hn(_0x2c1a91,_0x79acc8,_0x4d1515){return'firebase:'+_0x2c1a91+':'+_0x79acc8+':'+_0x4d1515;}class tt{constructor(_0x36e918,_0x133ec4,_0x1e7208){this['persistence']=_0x36e918,this['auth']=_0x133ec4,this['userKey']=_0x1e7208;const {config:_0x2c38e5,name:_0x500ef3}=this['auth'];this['fullUserKey']=hn(this['userKey'],_0x2c38e5['apiKey'],_0x500ef3),this['fullPersistenceKey']=hn('persistence',_0x2c38e5['apiKey'],_0x500ef3),this['boundEventHandler']=_0x133ec4['_onStorageEvent']['bind'](_0x133ec4),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x3b7652){return this['persistence']['_set'](this['fullUserKey'],_0x3b7652['toJSON']());}async['getCurrentUser'](){const _0x4e1ec9=await this['persistence']['_get'](this['fullUserKey']);if(!_0x4e1ec9)return null;if(typeof _0x4e1ec9=='string'){const _0x3323a1=await Pn(this['auth'],{'idToken':_0x4e1ec9})['catch'](()=>{});return _0x3323a1?j['_fromGetAccountInfoResponse'](this['auth'],_0x3323a1,_0x4e1ec9):null;}return j['_fromJSON'](this['auth'],_0x4e1ec9);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x46c086){if(this['persistence']===_0x46c086)return;const _0x245c0a=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x46c086,_0x245c0a)return this['setCurrentUser'](_0x245c0a);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x53c5c5,_0x246809,_0x4bb721='authUser'){if(!_0x246809['length'])return new tt(ie(Pr),_0x53c5c5,_0x4bb721);const _0x463e8f=(await Promise['all'](_0x246809['map'](async _0x141856=>{if(await _0x141856['_isAvailable']())return _0x141856;})))['filter'](_0x513371=>_0x513371);let _0x4ffde7=_0x463e8f[0x0]||ie(Pr);const _0x1589f6=hn(_0x4bb721,_0x53c5c5['config']['apiKey'],_0x53c5c5['name']);let _0x46fa69=null;for(const _0x2cb76c of _0x246809)try{const _0x51d8a5=await _0x2cb76c['_get'](_0x1589f6);if(_0x51d8a5){let _0x4af520;if(typeof _0x51d8a5=='string'){const _0x4407f4=await Pn(_0x53c5c5,{'idToken':_0x51d8a5})['catch'](()=>{});if(!_0x4407f4)break;_0x4af520=await j['_fromGetAccountInfoResponse'](_0x53c5c5,_0x4407f4,_0x51d8a5);}else _0x4af520=j['_fromJSON'](_0x53c5c5,_0x51d8a5);_0x2cb76c!==_0x4ffde7&&(_0x46fa69=_0x4af520),_0x4ffde7=_0x2cb76c;break;}}catch{}const _0x33437a=_0x463e8f['filter'](_0x6a8094=>_0x6a8094['_shouldAllowMigration']);return!_0x4ffde7['_shouldAllowMigration']||!_0x33437a['length']?new tt(_0x4ffde7,_0x53c5c5,_0x4bb721):(_0x4ffde7=_0x33437a[0x0],_0x46fa69&&await _0x4ffde7['_set'](_0x1589f6,_0x46fa69['toJSON']()),await Promise['all'](_0x246809['map'](async _0x577dae=>{if(_0x577dae!==_0x4ffde7)try{await _0x577dae['_remove'](_0x1589f6);}catch{}})),new tt(_0x4ffde7,_0x53c5c5,_0x4bb721));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Or(_0x3f8a2f){const _0x2e1faa=_0x3f8a2f['toLowerCase']();if(_0x2e1faa['includes']('opera/')||_0x2e1faa['includes']('opr/')||_0x2e1faa['includes']('opios/'))return'Opera';if(Oa(_0x2e1faa))return'IEMobile';if(_0x2e1faa['includes']('msie')||_0x2e1faa['includes']('trident/'))return'IE';if(_0x2e1faa['includes']('edge/'))return'Edge';if(ka(_0x2e1faa))return'Firefox';if(_0x2e1faa['includes']('silk/'))return'Silk';if(Ma(_0x2e1faa))return'Blackberry';if(La(_0x2e1faa))return'Webos';if(Na(_0x2e1faa))return'Safari';if((_0x2e1faa['includes']('chrome/')||Pa(_0x2e1faa))&&!_0x2e1faa['includes']('edge/'))return'Chrome';if(Da(_0x2e1faa))return'Android';{const _0x566f19=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x7ef693=_0x3f8a2f['match'](_0x566f19);if((_0x7ef693==null?void 0x0:_0x7ef693['length'])===0x2)return _0x7ef693[0x1];}return'Other';}function ka(_0xd1e424=W()){return/firefox\//i['test'](_0xd1e424);}function Na(_0x1a4104=W()){const _0x501649=_0x1a4104['toLowerCase']();return _0x501649['includes']('safari/')&&!_0x501649['includes']('chrome/')&&!_0x501649['includes']('crios/')&&!_0x501649['includes']('android');}function Pa(_0x1c5919=W()){return/crios\//i['test'](_0x1c5919);}function Oa(_0x1144d5=W()){return/iemobile/i['test'](_0x1144d5);}function Da(_0x24dcd9=W()){return/android/i['test'](_0x24dcd9);}function Ma(_0x57e53b=W()){return/blackberry/i['test'](_0x57e53b);}function La(_0x2d6f7e=W()){return/webos/i['test'](_0x2d6f7e);}function bs(_0x27dc82=W()){return/iphone|ipad|ipod/i['test'](_0x27dc82)||/macintosh/i['test'](_0x27dc82)&&/mobile/i['test'](_0x27dc82);}function Nf(_0x5384da=W()){var _0x5e791b;return bs(_0x5384da)&&!!((_0x5e791b=window['navigator'])!=null&&_0x5e791b['standalone']);}function Pf(){return gc()&&document['documentMode']===0xa;}function xa(_0x22d926=W()){return bs(_0x22d926)||Da(_0x22d926)||La(_0x22d926)||Ma(_0x22d926)||/windows phone/i['test'](_0x22d926)||Oa(_0x22d926);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Fa(_0x1627c3,_0x50fd34=[]){let _0x3449a4;switch(_0x1627c3){case'Browser':_0x3449a4=Or(W());break;case'Worker':_0x3449a4=Or(W())+'-'+_0x1627c3;break;default:_0x3449a4=_0x1627c3;}const _0xb7011d=_0x50fd34['length']?_0x50fd34['join'](','):'FirebaseCore-web';return _0x3449a4+'/JsCore/'+dt+'/'+_0xb7011d;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Of{constructor(_0x5d7eed){this['auth']=_0x5d7eed,this['queue']=[];}['pushCallback'](_0x50e32f,_0x5ee992){const _0x442347=_0x38ab03=>new Promise((_0x31c506,_0xc243cd)=>{try{const _0x4b6b20=_0x50e32f(_0x38ab03);_0x31c506(_0x4b6b20);}catch(_0xd62311){_0xc243cd(_0xd62311);}});_0x442347['onAbort']=_0x5ee992,this['queue']['push'](_0x442347);const _0x533605=this['queue']['length']-0x1;return()=>{this['queue'][_0x533605]=()=>Promise['resolve']();};}async['runMiddleware'](_0x2f301f){if(this['auth']['currentUser']===_0x2f301f)return;const _0x25c054=[];try{for(const _0x5a992c of this['queue'])await _0x5a992c(_0x2f301f),_0x5a992c['onAbort']&&_0x25c054['push'](_0x5a992c['onAbort']);}catch(_0x53d98a){_0x25c054['reverse']();for(const _0x3fb1a2 of _0x25c054)try{_0x3fb1a2();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x53d98a==null?void 0x0:_0x53d98a['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Df(_0x473a04,_0x1033b5={}){return Ae(_0x473a04,'GET','/v2/passwordPolicy',Re(_0x473a04,_0x1033b5));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Mf=0x6;class Lf{constructor(_0x68435a){var _0xbb59bd,_0x29e97d,_0x42f04c,_0x211adc;const _0x8559ba=_0x68435a['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=(_0xbb59bd=_0x8559ba['minPasswordLength'])!=null?_0xbb59bd:Mf,_0x8559ba['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x8559ba['maxPasswordLength']),_0x8559ba['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x8559ba['containsLowercaseCharacter']),_0x8559ba['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x8559ba['containsUppercaseCharacter']),_0x8559ba['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x8559ba['containsNumericCharacter']),_0x8559ba['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x8559ba['containsNonAlphanumericCharacter']),this['enforcementState']=_0x68435a['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=(_0x42f04c=(_0x29e97d=_0x68435a['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x29e97d['join'](''))!=null?_0x42f04c:'',this['forceUpgradeOnSignin']=(_0x211adc=_0x68435a['forceUpgradeOnSignin'])!=null?_0x211adc:!0x1,this['schemaVersion']=_0x68435a['schemaVersion'];}['validatePassword'](_0x5b1ce1){var _0x2686a4,_0x1fa8bd,_0x25bac5,_0x5d58ea,_0x4b09de,_0x358c3f;const _0x5d719f={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x5b1ce1,_0x5d719f),this['validatePasswordCharacterOptions'](_0x5b1ce1,_0x5d719f),_0x5d719f['isValid']&&(_0x5d719f['isValid']=(_0x2686a4=_0x5d719f['meetsMinPasswordLength'])!=null?_0x2686a4:!0x0),_0x5d719f['isValid']&&(_0x5d719f['isValid']=(_0x1fa8bd=_0x5d719f['meetsMaxPasswordLength'])!=null?_0x1fa8bd:!0x0),_0x5d719f['isValid']&&(_0x5d719f['isValid']=(_0x25bac5=_0x5d719f['containsLowercaseLetter'])!=null?_0x25bac5:!0x0),_0x5d719f['isValid']&&(_0x5d719f['isValid']=(_0x5d58ea=_0x5d719f['containsUppercaseLetter'])!=null?_0x5d58ea:!0x0),_0x5d719f['isValid']&&(_0x5d719f['isValid']=(_0x4b09de=_0x5d719f['containsNumericCharacter'])!=null?_0x4b09de:!0x0),_0x5d719f['isValid']&&(_0x5d719f['isValid']=(_0x358c3f=_0x5d719f['containsNonAlphanumericCharacter'])!=null?_0x358c3f:!0x0),_0x5d719f;}['validatePasswordLengthOptions'](_0x3e63be,_0x4bb861){const _0x52612c=this['customStrengthOptions']['minPasswordLength'],_0x370c4f=this['customStrengthOptions']['maxPasswordLength'];_0x52612c&&(_0x4bb861['meetsMinPasswordLength']=_0x3e63be['length']>=_0x52612c),_0x370c4f&&(_0x4bb861['meetsMaxPasswordLength']=_0x3e63be['length']<=_0x370c4f);}['validatePasswordCharacterOptions'](_0xebc8c2,_0x3f0a59){this['updatePasswordCharacterOptionsStatuses'](_0x3f0a59,!0x1,!0x1,!0x1,!0x1);let _0x280bf1;for(let _0x17db73=0x0;_0x17db73<_0xebc8c2['length'];_0x17db73++)_0x280bf1=_0xebc8c2['charAt'](_0x17db73),this['updatePasswordCharacterOptionsStatuses'](_0x3f0a59,_0x280bf1>='a'&&_0x280bf1<='z',_0x280bf1>='A'&&_0x280bf1<='Z',_0x280bf1>='0'&&_0x280bf1<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x280bf1));}['updatePasswordCharacterOptionsStatuses'](_0x209bed,_0x1d3e0b,_0x19faf5,_0x5815cd,_0x2a9ebf){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x209bed['containsLowercaseLetter']||(_0x209bed['containsLowercaseLetter']=_0x1d3e0b)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x209bed['containsUppercaseLetter']||(_0x209bed['containsUppercaseLetter']=_0x19faf5)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x209bed['containsNumericCharacter']||(_0x209bed['containsNumericCharacter']=_0x5815cd)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x209bed['containsNonAlphanumericCharacter']||(_0x209bed['containsNonAlphanumericCharacter']=_0x2a9ebf));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xf{constructor(_0x36a96a,_0x38cc24,_0x102db8,_0x22bce7){this['app']=_0x36a96a,this['heartbeatServiceProvider']=_0x38cc24,this['appCheckServiceProvider']=_0x102db8,this['config']=_0x22bce7,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Dr(this),this['idTokenSubscription']=new Dr(this),this['beforeStateQueue']=new Of(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=wa,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x36a96a['name'],this['clientVersion']=_0x22bce7['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x4d2aca=>this['_resolvePersistenceManagerAvailable']=_0x4d2aca);}['_initializeWithPersistence'](_0x1b0174,_0x45c33b){return _0x45c33b&&(this['_popupRedirectResolver']=ie(_0x45c33b)),this['_initializationPromise']=this['queue'](async()=>{var _0x2f4115,_0x492200,_0x3178e7;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x1b0174),(_0x2f4115=this['_resolvePersistenceManagerAvailable'])==null||_0x2f4115['call'](this),!this['_deleted'])){if((_0x492200=this['_popupRedirectResolver'])!=null&&_0x492200['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x45c33b),this['lastNotifiedUid']=((_0x3178e7=this['currentUser'])==null?void 0x0:_0x3178e7['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0xae66c4=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0xae66c4)){if(this['currentUser']&&_0xae66c4&&this['currentUser']['uid']===_0xae66c4['uid']){this['_currentUser']['_assign'](_0xae66c4),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0xae66c4,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x3dd593){try{const _0x430692=await Pn(this,{'idToken':_0x3dd593}),_0x4e4ac0=await j['_fromGetAccountInfoResponse'](this,_0x430692,_0x3dd593);await this['directlySetCurrentUser'](_0x4e4ac0);}catch(_0x310dec){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x310dec),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x1773be){var _0x409e7f;if($(this['app'])){const _0x2d31f6=this['app']['settings']['authIdToken'];return _0x2d31f6?new Promise(_0x3ea422=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2d31f6)['then'](_0x3ea422,_0x3ea422));}):this['directlySetCurrentUser'](null);}const _0x4176f6=await this['assertedPersistence']['getCurrentUser']();let _0x2e17f5=_0x4176f6,_0xdb432a=!0x1;if(_0x1773be&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x4d1225=(_0x409e7f=this['redirectUser'])==null?void 0x0:_0x409e7f['_redirectEventId'],_0x291a10=_0x2e17f5==null?void 0x0:_0x2e17f5['_redirectEventId'],_0x19637d=await this['tryRedirectSignIn'](_0x1773be);(!_0x4d1225||_0x4d1225===_0x291a10)&&(_0x19637d!=null&&_0x19637d['user'])&&(_0x2e17f5=_0x19637d['user'],_0xdb432a=!0x0);}if(!_0x2e17f5)return this['directlySetCurrentUser'](null);if(!_0x2e17f5['_redirectEventId']){if(_0xdb432a)try{await this['beforeStateQueue']['runMiddleware'](_0x2e17f5);}catch(_0x33c4ca){_0x2e17f5=_0x4176f6,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x33c4ca));}return _0x2e17f5?this['reloadAndSetCurrentUserOrClear'](_0x2e17f5):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x2e17f5['_redirectEventId']?this['directlySetCurrentUser'](_0x2e17f5):this['reloadAndSetCurrentUserOrClear'](_0x2e17f5);}async['tryRedirectSignIn'](_0x5db771){let _0x382517=null;try{_0x382517=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x5db771,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x382517;}async['reloadAndSetCurrentUserOrClear'](_0x57959b){try{await On(_0x57959b);}catch(_0x495b17){if((_0x495b17==null?void 0x0:_0x495b17['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x57959b);}['useDeviceLanguage'](){this['languageCode']=pf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x180c67){if($(this['app']))return Promise['reject'](re(this));const _0x3e430e=_0x180c67?N(_0x180c67):null;return _0x3e430e&&m(_0x3e430e['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x3e430e&&_0x3e430e['_clone'](this));}async['_updateCurrentUser'](_0x5f2d1e,_0x542a8c=!0x1){if(!this['_deleted'])return _0x5f2d1e&&m(this['tenantId']===_0x5f2d1e['tenantId'],this,'tenant-id-mismatch'),_0x542a8c||await this['beforeStateQueue']['runMiddleware'](_0x5f2d1e),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x5f2d1e),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x41e8ed){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x41e8ed));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x2d9697){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x95abef=this['_getPasswordPolicyInternal']();return _0x95abef['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x95abef['validatePassword'](_0x2d9697);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x29e631=await Df(this),_0x4394ef=new Lf(_0x29e631);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4394ef:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4394ef;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x4dcc50){this['_errorFactory']=new Gt('auth','Firebase',_0x4dcc50());}['onAuthStateChanged'](_0x5b18d8,_0x594c04,_0x3d616d){return this['registerStateListener'](this['authStateSubscription'],_0x5b18d8,_0x594c04,_0x3d616d);}['beforeAuthStateChanged'](_0x5ba00f,_0x4247ee){return this['beforeStateQueue']['pushCallback'](_0x5ba00f,_0x4247ee);}['onIdTokenChanged'](_0x30bfd3,_0x424868,_0x260b79){return this['registerStateListener'](this['idTokenSubscription'],_0x30bfd3,_0x424868,_0x260b79);}['authStateReady'](){return new Promise((_0x4bae48,_0x46218e)=>{if(this['currentUser'])_0x4bae48();else{const _0x267fc4=this['onAuthStateChanged'](()=>{_0x267fc4(),_0x4bae48();},_0x46218e);}});}async['revokeAccessToken'](_0x5bab79){if(this['currentUser']){const _0x3b8d7d=await this['currentUser']['getIdToken'](),_0x38396f={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x5bab79,'idToken':_0x3b8d7d};this['tenantId']!=null&&(_0x38396f['tenantId']=this['tenantId']),await kf(this,_0x38396f);}}['toJSON'](){var _0x5045d0;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x5045d0=this['_currentUser'])==null?void 0x0:_0x5045d0['toJSON']()};}async['_setRedirectUser'](_0x545547,_0x2f8050){const _0x8f6678=await this['getOrInitRedirectPersistenceManager'](_0x2f8050);return _0x545547===null?_0x8f6678['removeCurrentUser']():_0x8f6678['setCurrentUser'](_0x545547);}async['getOrInitRedirectPersistenceManager'](_0x39ca3d){if(!this['redirectPersistenceManager']){const _0x58979e=_0x39ca3d&&ie(_0x39ca3d)||this['_popupRedirectResolver'];m(_0x58979e,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x58979e['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x1268f6){var _0x2b3ff4,_0x230c10;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x2b3ff4=this['_currentUser'])==null?void 0x0:_0x2b3ff4['_redirectEventId'])===_0x1268f6?this['_currentUser']:((_0x230c10=this['redirectUser'])==null?void 0x0:_0x230c10['_redirectEventId'])===_0x1268f6?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x4f6b40){if(_0x4f6b40===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x4f6b40));}['_notifyListenersIfCurrent'](_0x381ccd){_0x381ccd===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0xe37fb6,_0x3d6198;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x372e30=(_0x3d6198=(_0xe37fb6=this['currentUser'])==null?void 0x0:_0xe37fb6['uid'])!=null?_0x3d6198:null;this['lastNotifiedUid']!==_0x372e30&&(this['lastNotifiedUid']=_0x372e30,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x1c8def,_0x82419a,_0x42e8e4,_0x51616c){if(this['_deleted'])return()=>{};const _0x2369a9=typeof _0x82419a=='function'?_0x82419a:_0x82419a['next']['bind'](_0x82419a);let _0x19649c=!0x1;const _0x5d762f=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x5d762f,this,'internal-error'),_0x5d762f['then'](()=>{_0x19649c||_0x2369a9(this['currentUser']);}),typeof _0x82419a=='function'){const _0x3b0f51=_0x1c8def['addObserver'](_0x82419a,_0x42e8e4,_0x51616c);return()=>{_0x19649c=!0x0,_0x3b0f51();};}else{const _0x5716e3=_0x1c8def['addObserver'](_0x82419a);return()=>{_0x19649c=!0x0,_0x5716e3();};}}async['directlySetCurrentUser'](_0x2d38a5){this['currentUser']&&this['currentUser']!==_0x2d38a5&&this['_currentUser']['_stopProactiveRefresh'](),_0x2d38a5&&this['isProactiveRefreshEnabled']&&_0x2d38a5['_startProactiveRefresh'](),this['currentUser']=_0x2d38a5,_0x2d38a5?await this['assertedPersistence']['setCurrentUser'](_0x2d38a5):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x26ffe2){return this['operations']=this['operations']['then'](_0x26ffe2,_0x26ffe2),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x1df41d){!_0x1df41d||this['frameworks']['includes'](_0x1df41d)||(this['frameworks']['push'](_0x1df41d),this['frameworks']['sort'](),this['clientVersion']=Fa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x2dcb92;const _0x518691={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x518691['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x555b23=await((_0x2dcb92=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x2dcb92['getHeartbeatsHeader']());_0x555b23&&(_0x518691['X-Firebase-Client']=_0x555b23);const _0x4eecc5=await this['_getAppCheckToken']();return _0x4eecc5&&(_0x518691['X-Firebase-AppCheck']=_0x4eecc5),_0x518691;}async['_getAppCheckToken'](){var _0x50526b;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x4a5bad=await((_0x50526b=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x50526b['getToken']());return _0x4a5bad!=null&&_0x4a5bad['error']&&uf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x4a5bad['error']),_0x4a5bad==null?void 0x0:_0x4a5bad['token'];}}function Ke(_0x172061){return N(_0x172061);}class Dr{constructor(_0x1b9013){this['auth']=_0x1b9013,this['observer']=null,this['addObserver']=bc(_0x4b4d51=>this['observer']=_0x4b4d51);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Ff(_0x3f5ece){Xn=_0x3f5ece;}function Ua(_0x35c0c5){return Xn['loadJS'](_0x35c0c5);}function Uf(){return Xn['recaptchaEnterpriseScript'];}function Wf(){return Xn['gapiScript'];}function Bf(_0x3f7e4e){return'__'+_0x3f7e4e+Math['floor'](Math['random']()*0xf4240);}class Vf{constructor(){this['enterprise']=new Hf();}['ready'](_0x500ccd){_0x500ccd();}['execute'](_0x594f8f,_0x249bc9){return Promise['resolve']('token');}['render'](_0xd56afa,_0x1dc1e2){return'';}}class Hf{['ready'](_0x2e3e90){_0x2e3e90();}['execute'](_0x4b062b,_0x1af80c){return Promise['resolve']('token');}['render'](_0x107aa2,_0x5a0782){return'';}}const $f='recaptcha-enterprise',Wa='NO_RECAPTCHA',Mr='onFirebaseAuthREInstanceReady';class he{constructor(_0x3dd419){this['type']=$f,this['auth']=Ke(_0x3dd419);}async['verify'](_0x1d1414='verify',_0x1a6a12=!0x1){async function _0x19afa3(_0x490ca4){if(!_0x1a6a12){if(_0x490ca4['tenantId']==null&&_0x490ca4['_agentRecaptchaConfig']!=null)return _0x490ca4['_agentRecaptchaConfig']['siteKey'];if(_0x490ca4['tenantId']!=null&&_0x490ca4['_tenantRecaptchaConfigs'][_0x490ca4['tenantId']]!==void 0x0)return _0x490ca4['_tenantRecaptchaConfigs'][_0x490ca4['tenantId']]['siteKey'];}return new Promise(async(_0x2d0f84,_0x3799c3)=>{If(_0x490ca4,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x1cbedf=>{if(_0x1cbedf['recaptchaKey']===void 0x0)_0x3799c3(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x38b829=new Ef(_0x1cbedf);return _0x490ca4['tenantId']==null?_0x490ca4['_agentRecaptchaConfig']=_0x38b829:_0x490ca4['_tenantRecaptchaConfigs'][_0x490ca4['tenantId']]=_0x38b829,_0x2d0f84(_0x38b829['siteKey']);}})['catch'](_0x2d3359=>{_0x3799c3(_0x2d3359);});});}function _0x2dedb0(_0x55d5ad,_0x5b146e,_0x46afdf){const _0x5d8722=window['grecaptcha'];Ar(_0x5d8722)?_0x5d8722['enterprise']['ready'](()=>{_0x5d8722['enterprise']['execute'](_0x55d5ad,{'action':_0x1d1414})['then'](_0x455a47=>{_0x5b146e(_0x455a47);})['catch'](()=>{_0x5b146e(Wa);});}):_0x46afdf(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Vf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x4b2ef5,_0x22e8fd)=>{_0x19afa3(this['auth'])['then'](async _0x4a8aad=>{if(!_0x1a6a12&&Ar(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x2dedb0(_0x4a8aad,_0x4b2ef5,_0x22e8fd);else{if(typeof window>'u'){_0x22e8fd(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x3f789d=Uf();_0x3f789d['length']!==0x0&&(_0x3f789d+=_0x4a8aad+('&onload='+Mr)),he['scriptInjectionDeferred']=new H(),window[Mr]=()=>{var _0x23c6d2;(_0x23c6d2=he['scriptInjectionDeferred'])==null||_0x23c6d2['resolve']();},Ua(_0x3f789d)['then'](()=>{var _0x2b6cea;return(_0x2b6cea=he['scriptInjectionDeferred'])==null?void 0x0:_0x2b6cea['promise'];})['then'](()=>{_0x2dedb0(_0x4a8aad,_0x4b2ef5,_0x22e8fd);})['catch'](_0xfe44a3=>{_0x22e8fd(_0xfe44a3);});}})['catch'](_0x485700=>{_0x22e8fd(_0x485700);});});}}he['scriptInjectionDeferred']=null;async function Lr(_0x301966,_0x6f12d8,_0x44944f,_0x1e5ec5=!0x1,_0x305d50=!0x1){const _0x205b20=new he(_0x301966);let _0x368d86;if(_0x305d50)_0x368d86=Wa;else try{_0x368d86=await _0x205b20['verify'](_0x44944f);}catch{_0x368d86=await _0x205b20['verify'](_0x44944f,!0x0);}const _0x47fb99={..._0x6f12d8};if(_0x44944f==='mfaSmsEnrollment'||_0x44944f==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x47fb99){const _0x3877b0=_0x47fb99['phoneEnrollmentInfo']['phoneNumber'],_0x2b3528=_0x47fb99['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x47fb99,{'phoneEnrollmentInfo':{'phoneNumber':_0x3877b0,'recaptchaToken':_0x2b3528,'captchaResponse':_0x368d86,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x47fb99){const _0x23da91=_0x47fb99['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x47fb99,{'phoneSignInInfo':{'recaptchaToken':_0x23da91,'captchaResponse':_0x368d86,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x47fb99;}return _0x1e5ec5?Object['assign'](_0x47fb99,{'captchaResp':_0x368d86}):Object['assign'](_0x47fb99,{'captchaResponse':_0x368d86}),Object['assign'](_0x47fb99,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x47fb99,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x47fb99;}async function xi(_0x32dbfd,_0x4312e0,_0x2a26ae,_0x23ce18,_0x4c296e){var _0x2525ce;if((_0x2525ce=_0x32dbfd['_getRecaptchaConfig']())!=null&&_0x2525ce['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x1c209b=await Lr(_0x32dbfd,_0x4312e0,_0x2a26ae,_0x2a26ae==='getOobCode');return _0x23ce18(_0x32dbfd,_0x1c209b);}else return _0x23ce18(_0x32dbfd,_0x4312e0)['catch'](async _0x44146b=>{if(_0x44146b['code']==='auth/missing-recaptcha-token'){console['log'](_0x2a26ae+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x4211a8=await Lr(_0x32dbfd,_0x4312e0,_0x2a26ae,_0x2a26ae==='getOobCode');return _0x23ce18(_0x32dbfd,_0x4211a8);}else return Promise['reject'](_0x44146b);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x1c127e,_0x57444e){const _0x1f653d=Hi(_0x1c127e,'auth');if(_0x1f653d['isInitialized']()){const _0x4047cb=_0x1f653d['getImmediate'](),_0x23944c=_0x1f653d['getOptions']();if(xe(_0x23944c,_0x57444e!=null?_0x57444e:{}))return _0x4047cb;Y(_0x4047cb,'already-initialized');}return _0x1f653d['initialize']({'options':_0x57444e});}function qf(_0x5e786e,_0x5756ad){const _0x309f02=(_0x5756ad==null?void 0x0:_0x5756ad['persistence'])||[],_0x6447f0=(Array['isArray'](_0x309f02)?_0x309f02:[_0x309f02])['map'](ie);_0x5756ad!=null&&_0x5756ad['errorMap']&&_0x5e786e['_updateErrorMap'](_0x5756ad['errorMap']),_0x5e786e['_initializeWithPersistence'](_0x6447f0,_0x5756ad==null?void 0x0:_0x5756ad['popupRedirectResolver']);}function zf(_0x65da2a,_0x29bc88,_0x4c8ec9){const _0x56189a=Ke(_0x65da2a);m(/^https?:\/\//['test'](_0x29bc88),_0x56189a,'invalid-emulator-scheme');const _0x3c35d9=!0x1,_0x5d02c2=Ba(_0x29bc88),{host:_0xe18e4b,port:_0xc53cdd}=jf(_0x29bc88),_0x4f9bf7=_0xc53cdd===null?'':':'+_0xc53cdd,_0x110a14={'url':_0x5d02c2+'//'+_0xe18e4b+_0x4f9bf7+'/'},_0x52ae3b=Object['freeze']({'host':_0xe18e4b,'port':_0xc53cdd,'protocol':_0x5d02c2['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x3c35d9})});if(!_0x56189a['_canInitEmulator']){m(_0x56189a['config']['emulator']&&_0x56189a['emulatorConfig'],_0x56189a,'emulator-config-failed'),m(xe(_0x110a14,_0x56189a['config']['emulator'])&&xe(_0x52ae3b,_0x56189a['emulatorConfig']),_0x56189a,'emulator-config-failed');return;}_0x56189a['config']['emulator']=_0x110a14,_0x56189a['emulatorConfig']=_0x52ae3b,_0x56189a['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0xe18e4b)?no(_0x5d02c2+'//'+_0xe18e4b+_0x4f9bf7):Kf();}function Ba(_0x3a0fa6){const _0x4550d3=_0x3a0fa6['indexOf'](':');return _0x4550d3<0x0?'':_0x3a0fa6['substr'](0x0,_0x4550d3+0x1);}function jf(_0x811581){const _0x215cc6=Ba(_0x811581),_0x4e8f23=/(\/\/)?([^?#/]+)/['exec'](_0x811581['substr'](_0x215cc6['length']));if(!_0x4e8f23)return{'host':'','port':null};const _0x226071=_0x4e8f23[0x2]['split']('@')['pop']()||'',_0x2064c5=/^(\[[^\]]+\])(:|$)/['exec'](_0x226071);if(_0x2064c5){const _0x12a475=_0x2064c5[0x1];return{'host':_0x12a475,'port':xr(_0x226071['substr'](_0x12a475['length']+0x1))};}else{const [_0x14bab2,_0x1d6fa9]=_0x226071['split'](':');return{'host':_0x14bab2,'port':xr(_0x1d6fa9)};}}function xr(_0x59105f){if(!_0x59105f)return null;const _0x4bc4a5=Number(_0x59105f);return isNaN(_0x4bc4a5)?null:_0x4bc4a5;}function Kf(){function _0xfd977a(){const _0x2642c4=document['createElement']('p'),_0x2d7e6b=_0x2642c4['style'];_0x2642c4['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x2d7e6b['position']='fixed',_0x2d7e6b['width']='100%',_0x2d7e6b['backgroundColor']='#ffffff',_0x2d7e6b['border']='.1em\x20solid\x20#000000',_0x2d7e6b['color']='#b50000',_0x2d7e6b['bottom']='0px',_0x2d7e6b['left']='0px',_0x2d7e6b['margin']='0px',_0x2d7e6b['zIndex']='10000',_0x2d7e6b['textAlign']='center',_0x2642c4['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x2642c4);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0xfd977a):_0xfd977a());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs{constructor(_0x42e125,_0x402ee5){this['providerId']=_0x42e125,this['signInMethod']=_0x402ee5;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x31bd2d){return ne('not\x20implemented');}['_linkToIdToken'](_0x3ce792,_0x31a16b){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x55f88e){return ne('not\x20implemented');}}async function Yf(_0x1723bc,_0x5f2330){return Ae(_0x1723bc,'POST','/v1/accounts:signUp',_0x5f2330);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x4fc69d,_0x6ec131){return en(_0x4fc69d,'POST','/v1/accounts:signInWithPassword',Re(_0x4fc69d,_0x6ec131));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Jf(_0x292a40,_0x42327f){return en(_0x292a40,'POST','/v1/accounts:signInWithEmailLink',Re(_0x292a40,_0x42327f));}async function Xf(_0xb11ae5,_0x21ef25){return en(_0xb11ae5,'POST','/v1/accounts:signInWithEmailLink',Re(_0xb11ae5,_0x21ef25));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends Rs{constructor(_0x22ea64,_0xe7b38e,_0x532483,_0x38e267=null){super('password',_0x532483),this['_email']=_0x22ea64,this['_password']=_0xe7b38e,this['_tenantId']=_0x38e267;}static['_fromEmailAndPassword'](_0x346435,_0x3b8ae8){return new $t(_0x346435,_0x3b8ae8,'password');}static['_fromEmailAndCode'](_0x16a716,_0xbe97ec,_0x14a200=null){return new $t(_0x16a716,_0xbe97ec,'emailLink',_0x14a200);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x2e0b7a){const _0x45b6d8=typeof _0x2e0b7a=='string'?JSON['parse'](_0x2e0b7a):_0x2e0b7a;if(_0x45b6d8!=null&&_0x45b6d8['email']&&(_0x45b6d8!=null&&_0x45b6d8['password'])){if(_0x45b6d8['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x45b6d8['email'],_0x45b6d8['password']);if(_0x45b6d8['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x45b6d8['email'],_0x45b6d8['password'],_0x45b6d8['tenantId']);}return null;}async['_getIdTokenResponse'](_0x3d8ec5){switch(this['signInMethod']){case'password':const _0x3273c0={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x3d8ec5,_0x3273c0,'signInWithPassword',Qf);case'emailLink':return Jf(_0x3d8ec5,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x3d8ec5,'internal-error');}}async['_linkToIdToken'](_0x386787,_0x39fa1b){switch(this['signInMethod']){case'password':const _0x5a7157={'idToken':_0x39fa1b,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x386787,_0x5a7157,'signUpPassword',Yf);case'emailLink':return Xf(_0x386787,{'idToken':_0x39fa1b,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x386787,'internal-error');}}['_getReauthenticationResolver'](_0x3df822){return this['_getIdTokenResponse'](_0x3df822);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x149b18,_0x1960cf){return en(_0x149b18,'POST','/v1/accounts:signInWithIdp',Re(_0x149b18,_0x1960cf));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zf='http://localhost';class $e extends Rs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x556ec6){const _0x1160b1=new $e(_0x556ec6['providerId'],_0x556ec6['signInMethod']);return _0x556ec6['idToken']||_0x556ec6['accessToken']?(_0x556ec6['idToken']&&(_0x1160b1['idToken']=_0x556ec6['idToken']),_0x556ec6['accessToken']&&(_0x1160b1['accessToken']=_0x556ec6['accessToken']),_0x556ec6['nonce']&&!_0x556ec6['pendingToken']&&(_0x1160b1['nonce']=_0x556ec6['nonce']),_0x556ec6['pendingToken']&&(_0x1160b1['pendingToken']=_0x556ec6['pendingToken'])):_0x556ec6['oauthToken']&&_0x556ec6['oauthTokenSecret']?(_0x1160b1['accessToken']=_0x556ec6['oauthToken'],_0x1160b1['secret']=_0x556ec6['oauthTokenSecret']):Y('argument-error'),_0x1160b1;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x27aa88){const _0x4afb62=typeof _0x27aa88=='string'?JSON['parse'](_0x27aa88):_0x27aa88,{providerId:_0x3facb4,signInMethod:_0x1b00d5,..._0x1c553c}=_0x4afb62;if(!_0x3facb4||!_0x1b00d5)return null;const _0x2108ea=new $e(_0x3facb4,_0x1b00d5);return _0x2108ea['idToken']=_0x1c553c['idToken']||void 0x0,_0x2108ea['accessToken']=_0x1c553c['accessToken']||void 0x0,_0x2108ea['secret']=_0x1c553c['secret'],_0x2108ea['nonce']=_0x1c553c['nonce'],_0x2108ea['pendingToken']=_0x1c553c['pendingToken']||null,_0x2108ea;}['_getIdTokenResponse'](_0x25ed3b){const _0x5e0699=this['buildRequest']();return nt(_0x25ed3b,_0x5e0699);}['_linkToIdToken'](_0x3d11ec,_0x593e81){const _0x2fef3d=this['buildRequest']();return _0x2fef3d['idToken']=_0x593e81,nt(_0x3d11ec,_0x2fef3d);}['_getReauthenticationResolver'](_0x44ba19){const _0x5596b7=this['buildRequest']();return _0x5596b7['autoCreate']=!0x1,nt(_0x44ba19,_0x5596b7);}['buildRequest'](){const _0x1647d4={'requestUri':Zf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x1647d4['pendingToken']=this['pendingToken'];else{const _0x4ace0a={};this['idToken']&&(_0x4ace0a['id_token']=this['idToken']),this['accessToken']&&(_0x4ace0a['access_token']=this['accessToken']),this['secret']&&(_0x4ace0a['oauth_token_secret']=this['secret']),_0x4ace0a['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x4ace0a['nonce']=this['nonce']),_0x1647d4['postBody']=ut(_0x4ace0a);}return _0x1647d4;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ep(_0x496c3f){switch(_0x496c3f){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function tp(_0x5eb847){const _0x54aa0a=Ct(Tt(_0x5eb847))['link'],_0x70b0ae=_0x54aa0a?Ct(Tt(_0x54aa0a))['deep_link_id']:null,_0x3c4fb1=Ct(Tt(_0x5eb847))['deep_link_id'];return(_0x3c4fb1?Ct(Tt(_0x3c4fb1))['link']:null)||_0x3c4fb1||_0x70b0ae||_0x54aa0a||_0x5eb847;}class As{constructor(_0x3fa12e){var _0x19c4e0,_0x251756,_0x268e90,_0x51dbcd,_0x1f0f60,_0x11b652;const _0x3ef629=Ct(Tt(_0x3fa12e)),_0x19dcda=(_0x19c4e0=_0x3ef629['apiKey'])!=null?_0x19c4e0:null,_0x1fd31c=(_0x251756=_0x3ef629['oobCode'])!=null?_0x251756:null,_0x215d45=ep((_0x268e90=_0x3ef629['mode'])!=null?_0x268e90:null);m(_0x19dcda&&_0x1fd31c&&_0x215d45,'argument-error'),this['apiKey']=_0x19dcda,this['operation']=_0x215d45,this['code']=_0x1fd31c,this['continueUrl']=(_0x51dbcd=_0x3ef629['continueUrl'])!=null?_0x51dbcd:null,this['languageCode']=(_0x1f0f60=_0x3ef629['lang'])!=null?_0x1f0f60:null,this['tenantId']=(_0x11b652=_0x3ef629['tenantId'])!=null?_0x11b652:null;}static['parseLink'](_0x3a4db2){const _0x11059b=tp(_0x3a4db2);try{return new As(_0x11059b);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x4beb1e,_0x548468){return $t['_fromEmailAndPassword'](_0x4beb1e,_0x548468);}static['credentialWithLink'](_0x2f4420,_0x46e8a7){const _0xfb168d=As['parseLink'](_0x46e8a7);return m(_0xfb168d,'argument-error'),$t['_fromEmailAndCode'](_0x2f4420,_0xfb168d['code'],_0xfb168d['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Va{constructor(_0x5d8fb7){this['providerId']=_0x5d8fb7,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x4ddb82){this['defaultLanguageCode']=_0x4ddb82;}['setCustomParameters'](_0xe72979){return this['customParameters']=_0xe72979,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Va{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0xf94c60){return this['scopes']['includes'](_0xf94c60)||this['scopes']['push'](_0xf94c60),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x213bf6){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x213bf6});}static['credentialFromResult'](_0x1525df){return ue['credentialFromTaggedObject'](_0x1525df);}static['credentialFromError'](_0x52dd4a){return ue['credentialFromTaggedObject'](_0x52dd4a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4f9260}){if(!_0x4f9260||!('oauthAccessToken'in _0x4f9260)||!_0x4f9260['oauthAccessToken'])return null;try{return ue['credential'](_0x4f9260['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x579837,_0x5cdeaf){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x579837,'accessToken':_0x5cdeaf});}static['credentialFromResult'](_0x5f11d6){return de['credentialFromTaggedObject'](_0x5f11d6);}static['credentialFromError'](_0x24b979){return de['credentialFromTaggedObject'](_0x24b979['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3dec54}){if(!_0x3dec54)return null;const {oauthIdToken:_0x254f6e,oauthAccessToken:_0x31df87}=_0x3dec54;if(!_0x254f6e&&!_0x31df87)return null;try{return de['credential'](_0x254f6e,_0x31df87);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x2f09c4){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x2f09c4});}static['credentialFromResult'](_0xcc380e){return fe['credentialFromTaggedObject'](_0xcc380e);}static['credentialFromError'](_0x1a5b9f){return fe['credentialFromTaggedObject'](_0x1a5b9f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xcd55d5}){if(!_0xcd55d5||!('oauthAccessToken'in _0xcd55d5)||!_0xcd55d5['oauthAccessToken'])return null;try{return fe['credential'](_0xcd55d5['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x3b47f8,_0x4348d2){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x3b47f8,'oauthTokenSecret':_0x4348d2});}static['credentialFromResult'](_0x198c3e){return pe['credentialFromTaggedObject'](_0x198c3e);}static['credentialFromError'](_0x2f3266){return pe['credentialFromTaggedObject'](_0x2f3266['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x449712}){if(!_0x449712)return null;const {oauthAccessToken:_0x2ae4b3,oauthTokenSecret:_0x397116}=_0x449712;if(!_0x2ae4b3||!_0x397116)return null;try{return pe['credential'](_0x2ae4b3,_0x397116);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function np(_0x30c970,_0x27fe55){return en(_0x30c970,'POST','/v1/accounts:signUp',Re(_0x30c970,_0x27fe55));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x27975a){this['user']=_0x27975a['user'],this['providerId']=_0x27975a['providerId'],this['_tokenResponse']=_0x27975a['_tokenResponse'],this['operationType']=_0x27975a['operationType'];}static async['_fromIdTokenResponse'](_0x36cae8,_0x5e86df,_0x45c85e,_0x528ea0=!0x1){const _0x194bbd=await j['_fromIdTokenResponse'](_0x36cae8,_0x45c85e,_0x528ea0),_0x14d5ec=Fr(_0x45c85e);return new Ge({'user':_0x194bbd,'providerId':_0x14d5ec,'_tokenResponse':_0x45c85e,'operationType':_0x5e86df});}static async['_forOperation'](_0x305b24,_0x3a5097,_0x5c5777){await _0x305b24['_updateTokensIfNecessary'](_0x5c5777,!0x0);const _0xc5fa8d=Fr(_0x5c5777);return new Ge({'user':_0x305b24,'providerId':_0xc5fa8d,'_tokenResponse':_0x5c5777,'operationType':_0x3a5097});}}function Fr(_0x39ef4e){return _0x39ef4e['providerId']?_0x39ef4e['providerId']:'phoneNumber'in _0x39ef4e?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn extends be{constructor(_0x22caa3,_0xb7f21d,_0x1c86be,_0x508445){var _0x5b63bd;super(_0xb7f21d['code'],_0xb7f21d['message']),this['operationType']=_0x1c86be,this['user']=_0x508445,Object['setPrototypeOf'](this,Dn['prototype']),this['customData']={'appName':_0x22caa3['name'],'tenantId':(_0x5b63bd=_0x22caa3['tenantId'])!=null?_0x5b63bd:void 0x0,'_serverResponse':_0xb7f21d['customData']['_serverResponse'],'operationType':_0x1c86be};}static['_fromErrorAndOperation'](_0x3a5ca1,_0x1e9d4e,_0x3c2fd1,_0x5561f7){return new Dn(_0x3a5ca1,_0x1e9d4e,_0x3c2fd1,_0x5561f7);}}function Ha(_0x2d7cb6,_0x213942,_0xc05685,_0x139aec){return(_0x213942==='reauthenticate'?_0xc05685['_getReauthenticationResolver'](_0x2d7cb6):_0xc05685['_getIdTokenResponse'](_0x2d7cb6))['catch'](_0x5da74e=>{throw _0x5da74e['code']==='auth/multi-factor-auth-required'?Dn['_fromErrorAndOperation'](_0x2d7cb6,_0x5da74e,_0x213942,_0x139aec):_0x5da74e;});}async function ip(_0xf0ff49,_0x13f5aa,_0x40b704=!0x1){const _0x4b5ccb=await Ht(_0xf0ff49,_0x13f5aa['_linkToIdToken'](_0xf0ff49['auth'],await _0xf0ff49['getIdToken']()),_0x40b704);return Ge['_forOperation'](_0xf0ff49,'link',_0x4b5ccb);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function sp(_0x2ef0f4,_0x501756,_0x336b5b=!0x1){const {auth:_0x4dea18}=_0x2ef0f4;if($(_0x4dea18['app']))return Promise['reject'](re(_0x4dea18));const _0x4d0a36='reauthenticate';try{const _0x42afba=await Ht(_0x2ef0f4,Ha(_0x4dea18,_0x4d0a36,_0x501756,_0x2ef0f4),_0x336b5b);m(_0x42afba['idToken'],_0x4dea18,'internal-error');const _0xa936cc=Ss(_0x42afba['idToken']);m(_0xa936cc,_0x4dea18,'internal-error');const {sub:_0x52330b}=_0xa936cc;return m(_0x2ef0f4['uid']===_0x52330b,_0x4dea18,'user-mismatch'),Ge['_forOperation'](_0x2ef0f4,_0x4d0a36,_0x42afba);}catch(_0x379a39){throw(_0x379a39==null?void 0x0:_0x379a39['code'])==='auth/user-not-found'&&Y(_0x4dea18,'user-mismatch'),_0x379a39;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function $a(_0xbaa960,_0x5dce23,_0x347401=!0x1){if($(_0xbaa960['app']))return Promise['reject'](re(_0xbaa960));const _0x58eec7='signIn',_0x2431fd=await Ha(_0xbaa960,_0x58eec7,_0x5dce23),_0x4e4e5f=await Ge['_fromIdTokenResponse'](_0xbaa960,_0x58eec7,_0x2431fd);return _0x347401||await _0xbaa960['_updateCurrentUser'](_0x4e4e5f['user']),_0x4e4e5f;}async function rp(_0xef3525,_0xb58a14){return $a(Ke(_0xef3525),_0xb58a14);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ga(_0x2f0f65){const _0x1ab68a=Ke(_0x2f0f65);_0x1ab68a['_getPasswordPolicyInternal']()&&await _0x1ab68a['_updatePasswordPolicy']();}async function M_(_0x21ccc1,_0x27b4af,_0xea3556){if($(_0x21ccc1['app']))return Promise['reject'](re(_0x21ccc1));const _0x1dbe56=Ke(_0x21ccc1),_0x4327f7=await xi(_0x1dbe56,{'returnSecureToken':!0x0,'email':_0x27b4af,'password':_0xea3556,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',np)['catch'](_0x45b75a=>{throw _0x45b75a['code']==='auth/password-does-not-meet-requirements'&&Ga(_0x21ccc1),_0x45b75a;}),_0x5509ad=await Ge['_fromIdTokenResponse'](_0x1dbe56,'signIn',_0x4327f7);return await _0x1dbe56['_updateCurrentUser'](_0x5509ad['user']),_0x5509ad;}function L_(_0x5d83fa,_0x29e4e,_0x51d882){return $(_0x5d83fa['app'])?Promise['reject'](re(_0x5d83fa)):rp(N(_0x5d83fa),yt['credential'](_0x29e4e,_0x51d882))['catch'](async _0x432efa=>{throw _0x432efa['code']==='auth/password-does-not-meet-requirements'&&Ga(_0x5d83fa),_0x432efa;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function x_(_0x56a5d0,_0x5d0ccb){return N(_0x56a5d0)['setPersistence'](_0x5d0ccb);}function op(_0x2f18da,_0x26ad60,_0x150239,_0x317b59){return N(_0x2f18da)['onIdTokenChanged'](_0x26ad60,_0x150239,_0x317b59);}function ap(_0x73335b,_0x24b1ec,_0x3be880){return N(_0x73335b)['beforeAuthStateChanged'](_0x24b1ec,_0x3be880);}function F_(_0x50b3da,_0x2794e1,_0xce3ede,_0x16b240){return N(_0x50b3da)['onAuthStateChanged'](_0x2794e1,_0xce3ede,_0x16b240);}function U_(_0x25cbf9){return N(_0x25cbf9)['signOut']();}const Mn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa{constructor(_0x3bf8bb,_0x3c2ab0){this['storageRetriever']=_0x3bf8bb,this['type']=_0x3c2ab0;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Mn,'1'),this['storage']['removeItem'](Mn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x43a1ba,_0x5c7afe){return this['storage']['setItem'](_0x43a1ba,JSON['stringify'](_0x5c7afe)),Promise['resolve']();}['_get'](_0x8d1dbc){const _0x1ba176=this['storage']['getItem'](_0x8d1dbc);return Promise['resolve'](_0x1ba176?JSON['parse'](_0x1ba176):null);}['_remove'](_0x12ccbe){return this['storage']['removeItem'](_0x12ccbe),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cp=0x3e8,lp=0xa;class za extends qa{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x479216,_0x349024)=>this['onStorageEvent'](_0x479216,_0x349024),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=xa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x469ad5){for(const _0x2a2cda of Object['keys'](this['listeners'])){const _0x1048d4=this['storage']['getItem'](_0x2a2cda),_0x4a8b4e=this['localCache'][_0x2a2cda];_0x1048d4!==_0x4a8b4e&&_0x469ad5(_0x2a2cda,_0x4a8b4e,_0x1048d4);}}['onStorageEvent'](_0x13e159,_0x286d48=!0x1){if(!_0x13e159['key']){this['forAllChangedKeys']((_0x2da086,_0x4b71d0,_0x43961a)=>{this['notifyListeners'](_0x2da086,_0x43961a);});return;}const _0x39e439=_0x13e159['key'];_0x286d48?this['detachListener']():this['stopPolling']();const _0x2bb4c6=()=>{const _0x570200=this['storage']['getItem'](_0x39e439);!_0x286d48&&this['localCache'][_0x39e439]===_0x570200||this['notifyListeners'](_0x39e439,_0x570200);},_0x3d2bc9=this['storage']['getItem'](_0x39e439);Pf()&&_0x3d2bc9!==_0x13e159['newValue']&&_0x13e159['newValue']!==_0x13e159['oldValue']?setTimeout(_0x2bb4c6,lp):_0x2bb4c6();}['notifyListeners'](_0x3726e0,_0x5cf934){this['localCache'][_0x3726e0]=_0x5cf934;const _0x20e4b1=this['listeners'][_0x3726e0];if(_0x20e4b1){for(const _0x68ac0b of Array['from'](_0x20e4b1))_0x68ac0b(_0x5cf934&&JSON['parse'](_0x5cf934));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x5c782a,_0x52325f,_0x20553f)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x5c782a,'oldValue':_0x52325f,'newValue':_0x20553f}),!0x0);});},cp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x3eb641,_0x12941a){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x3eb641]||(this['listeners'][_0x3eb641]=new Set(),this['localCache'][_0x3eb641]=this['storage']['getItem'](_0x3eb641)),this['listeners'][_0x3eb641]['add'](_0x12941a);}['_removeListener'](_0x1f5731,_0x26a892){this['listeners'][_0x1f5731]&&(this['listeners'][_0x1f5731]['delete'](_0x26a892),this['listeners'][_0x1f5731]['size']===0x0&&delete this['listeners'][_0x1f5731]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x2f36c0,_0x5c3a49){await super['_set'](_0x2f36c0,_0x5c3a49),this['localCache'][_0x2f36c0]=JSON['stringify'](_0x5c3a49);}async['_get'](_0x47e33a){const _0x15b3f9=await super['_get'](_0x47e33a);return this['localCache'][_0x47e33a]=JSON['stringify'](_0x15b3f9),_0x15b3f9;}async['_remove'](_0x3489f3){await super['_remove'](_0x3489f3),delete this['localCache'][_0x3489f3];}}za['type']='LOCAL';const hp=za;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ja extends qa{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x18d98c,_0xce71f5){}['_removeListener'](_0x49d491,_0x5f0ae9){}}ja['type']='SESSION';const Ka=ja;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function up(_0x368a63){return Promise['all'](_0x368a63['map'](async _0x10291d=>{try{return{'fulfilled':!0x0,'value':await _0x10291d};}catch(_0x3cee25){return{'fulfilled':!0x1,'reason':_0x3cee25};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zn{constructor(_0x3e7a61){this['eventTarget']=_0x3e7a61,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x450dc2){const _0x1cc8cc=this['receivers']['find'](_0x339e7c=>_0x339e7c['isListeningto'](_0x450dc2));if(_0x1cc8cc)return _0x1cc8cc;const _0xf070fa=new Zn(_0x450dc2);return this['receivers']['push'](_0xf070fa),_0xf070fa;}['isListeningto'](_0x433e20){return this['eventTarget']===_0x433e20;}async['handleEvent'](_0xfe8bcc){const _0xea0380=_0xfe8bcc,{eventId:_0x4c1c70,eventType:_0x252e3b,data:_0x4f070e}=_0xea0380['data'],_0x30c61d=this['handlersMap'][_0x252e3b];if(!(_0x30c61d!=null&&_0x30c61d['size']))return;_0xea0380['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x4c1c70,'eventType':_0x252e3b});const _0x41f069=Array['from'](_0x30c61d)['map'](async _0x440b13=>_0x440b13(_0xea0380['origin'],_0x4f070e)),_0x409eb6=await up(_0x41f069);_0xea0380['ports'][0x0]['postMessage']({'status':'done','eventId':_0x4c1c70,'eventType':_0x252e3b,'response':_0x409eb6});}['_subscribe'](_0x673317,_0x5287e2){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x673317]||(this['handlersMap'][_0x673317]=new Set()),this['handlersMap'][_0x673317]['add'](_0x5287e2);}['_unsubscribe'](_0x37d26d,_0x2c38c3){this['handlersMap'][_0x37d26d]&&_0x2c38c3&&this['handlersMap'][_0x37d26d]['delete'](_0x2c38c3),(!_0x2c38c3||this['handlersMap'][_0x37d26d]['size']===0x0)&&delete this['handlersMap'][_0x37d26d],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Zn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ks(_0x3eb3a5='',_0x1a558d=0xa){let _0x1186e9='';for(let _0x542225=0x0;_0x542225<_0x1a558d;_0x542225++)_0x1186e9+=Math['floor'](Math['random']()*0xa);return _0x3eb3a5+_0x1186e9;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dp{constructor(_0x363c43){this['target']=_0x363c43,this['handlers']=new Set();}['removeMessageHandler'](_0x2b092b){_0x2b092b['messageChannel']&&(_0x2b092b['messageChannel']['port1']['removeEventListener']('message',_0x2b092b['onMessage']),_0x2b092b['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x2b092b);}async['_send'](_0x45254b,_0x4448b8,_0x686c71=0x32){const _0x700c69=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x700c69)throw new Error('connection_unavailable');let _0x32abc4,_0x1bc204;return new Promise((_0x1e6e53,_0x4aaa58)=>{const _0x433ce9=ks('',0x14);_0x700c69['port1']['start']();const _0x3d682c=setTimeout(()=>{_0x4aaa58(new Error('unsupported_event'));},_0x686c71);_0x1bc204={'messageChannel':_0x700c69,'onMessage'(_0x3327cb){const _0x2aaf00=_0x3327cb;if(_0x2aaf00['data']['eventId']===_0x433ce9)switch(_0x2aaf00['data']['status']){case'ack':clearTimeout(_0x3d682c),_0x32abc4=setTimeout(()=>{_0x4aaa58(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x32abc4),_0x1e6e53(_0x2aaf00['data']['response']);break;default:clearTimeout(_0x3d682c),clearTimeout(_0x32abc4),_0x4aaa58(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x1bc204),_0x700c69['port1']['addEventListener']('message',_0x1bc204['onMessage']),this['target']['postMessage']({'eventType':_0x45254b,'eventId':_0x433ce9,'data':_0x4448b8},[_0x700c69['port2']]);})['finally'](()=>{_0x1bc204&&this['removeMessageHandler'](_0x1bc204);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function fp(_0x278a03){Z()['location']['href']=_0x278a03;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ya(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function pp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function _p(){var _0x4d8e1e;return((_0x4d8e1e=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x4d8e1e['controller'])||null;}function gp(){return Ya()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qa='firebaseLocalStorageDb',mp=0x1,Ln='firebaseLocalStorage',Ja='fbase_key';class nn{constructor(_0x56015b){this['request']=_0x56015b;}['toPromise'](){return new Promise((_0x3eb590,_0x2ea306)=>{this['request']['addEventListener']('success',()=>{_0x3eb590(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x2ea306(this['request']['error']);});});}}function ei(_0x128b02,_0x59da33){return _0x128b02['transaction']([Ln],_0x59da33?'readwrite':'readonly')['objectStore'](Ln);}function yp(){const _0x5988c5=indexedDB['deleteDatabase'](Qa);return new nn(_0x5988c5)['toPromise']();}function Xa(){const _0x17859d=indexedDB['open'](Qa,mp);return new Promise((_0xba6e9e,_0x49b9eb)=>{_0x17859d['addEventListener']('error',()=>{_0x49b9eb(_0x17859d['error']);}),_0x17859d['addEventListener']('upgradeneeded',()=>{const _0x24b024=_0x17859d['result'];try{_0x24b024['createObjectStore'](Ln,{'keyPath':Ja});}catch(_0x31f1da){_0x49b9eb(_0x31f1da);}}),_0x17859d['addEventListener']('success',async()=>{const _0x4a44c0=_0x17859d['result'];_0x4a44c0['objectStoreNames']['contains'](Ln)?_0xba6e9e(_0x4a44c0):(_0x4a44c0['close'](),await yp(),_0xba6e9e(await Xa()));});});}async function Ur(_0x54a5d6,_0x2a0d24,_0x14bdf7){const _0x3d2f92=ei(_0x54a5d6,!0x0)['put']({[Ja]:_0x2a0d24,'value':_0x14bdf7});return new nn(_0x3d2f92)['toPromise']();}async function vp(_0x135d36,_0x224894){const _0x2e28db=ei(_0x135d36,!0x1)['get'](_0x224894),_0x1d5a87=await new nn(_0x2e28db)['toPromise']();return _0x1d5a87===void 0x0?null:_0x1d5a87['value'];}function Wr(_0x11b352,_0x586f1e){const _0x15d6d2=ei(_0x11b352,!0x0)['delete'](_0x586f1e);return new nn(_0x15d6d2)['toPromise']();}const Ep=0x320,Ip=0x3;class Za{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Xa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x3f77e3){let _0x30461a=0x0;for(;;)try{const _0x4ea2f4=await this['_openDb']();return await _0x3f77e3(_0x4ea2f4);}catch(_0x1b7f93){if(_0x30461a++>Ip)throw _0x1b7f93;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ya()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Zn['_getInstance'](gp()),this['receiver']['_subscribe']('keyChanged',async(_0x2942a3,_0x722ec4)=>({'keyProcessed':(await this['_poll']())['includes'](_0x722ec4['key'])})),this['receiver']['_subscribe']('ping',async(_0x445502,_0x3511d8)=>['keyChanged']);}async['initializeSender'](){var _0x569762,_0x457516;if(this['activeServiceWorker']=await pp(),!this['activeServiceWorker'])return;this['sender']=new dp(this['activeServiceWorker']);const _0x25b0e1=await this['sender']['_send']('ping',{},0x320);_0x25b0e1&&(_0x569762=_0x25b0e1[0x0])!=null&&_0x569762['fulfilled']&&(_0x457516=_0x25b0e1[0x0])!=null&&_0x457516['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x236146){if(!(!this['sender']||!this['activeServiceWorker']||_p()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x236146},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x1c8fe1=>{await Ur(_0x1c8fe1,Mn,'1'),await Wr(_0x1c8fe1,Mn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x2c5deb){this['pendingWrites']++;try{await _0x2c5deb();}finally{this['pendingWrites']--;}}async['_set'](_0x140b33,_0x433803){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x50f197=>Ur(_0x50f197,_0x140b33,_0x433803)),this['localCache'][_0x140b33]=_0x433803,this['notifyServiceWorker'](_0x140b33)));}async['_get'](_0x571b6b){const _0x51d54e=await this['_withRetries'](_0x2ddd72=>vp(_0x2ddd72,_0x571b6b));return this['localCache'][_0x571b6b]=_0x51d54e,_0x51d54e;}async['_remove'](_0x21b951){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x199332=>Wr(_0x199332,_0x21b951)),delete this['localCache'][_0x21b951],this['notifyServiceWorker'](_0x21b951)));}async['_poll'](){const _0xf30578=await this['_withRetries'](_0x528f1e=>{const _0x5a5df8=ei(_0x528f1e,!0x1)['getAll']();return new nn(_0x5a5df8)['toPromise']();});if(!_0xf30578)return[];if(this['pendingWrites']!==0x0)return[];const _0x238a4c=[],_0x2d599e=new Set();if(_0xf30578['length']!==0x0){for(const {fbase_key:_0x233206,value:_0x42d6b4}of _0xf30578)_0x2d599e['add'](_0x233206),JSON['stringify'](this['localCache'][_0x233206])!==JSON['stringify'](_0x42d6b4)&&(this['notifyListeners'](_0x233206,_0x42d6b4),_0x238a4c['push'](_0x233206));}for(const _0x34e446 of Object['keys'](this['localCache']))this['localCache'][_0x34e446]&&!_0x2d599e['has'](_0x34e446)&&(this['notifyListeners'](_0x34e446,null),_0x238a4c['push'](_0x34e446));return _0x238a4c;}['notifyListeners'](_0x397c64,_0x2763fa){this['localCache'][_0x397c64]=_0x2763fa;const _0x50dd7e=this['listeners'][_0x397c64];if(_0x50dd7e){for(const _0x57a4d4 of Array['from'](_0x50dd7e))_0x57a4d4(_0x2763fa);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),Ep);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x1278ae,_0x2153b3){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x1278ae]||(this['listeners'][_0x1278ae]=new Set(),this['_get'](_0x1278ae)),this['listeners'][_0x1278ae]['add'](_0x2153b3);}['_removeListener'](_0x57fe81,_0x3767b3){this['listeners'][_0x57fe81]&&(this['listeners'][_0x57fe81]['delete'](_0x3767b3),this['listeners'][_0x57fe81]['size']===0x0&&delete this['listeners'][_0x57fe81]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Za['type']='LOCAL';const wp=Za;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cp(_0x34ad12,_0x38e24){return _0x38e24?ie(_0x38e24):(m(_0x34ad12['_popupRedirectResolver'],_0x34ad12,'argument-error'),_0x34ad12['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ns extends Rs{constructor(_0x2cc877){super('custom','custom'),this['params']=_0x2cc877;}['_getIdTokenResponse'](_0x2c1c91){return nt(_0x2c1c91,this['_buildIdpRequest']());}['_linkToIdToken'](_0x3c4a1e,_0x4b2518){return nt(_0x3c4a1e,this['_buildIdpRequest'](_0x4b2518));}['_getReauthenticationResolver'](_0x1f1faa){return nt(_0x1f1faa,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x556c3d){const _0x185ca9={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x556c3d&&(_0x185ca9['idToken']=_0x556c3d),_0x185ca9;}}function Tp(_0x17979e){return $a(_0x17979e['auth'],new Ns(_0x17979e),_0x17979e['bypassAuthState']);}function Sp(_0x3514b0){const {auth:_0x212d9d,user:_0x442d39}=_0x3514b0;return m(_0x442d39,_0x212d9d,'internal-error'),sp(_0x442d39,new Ns(_0x3514b0),_0x3514b0['bypassAuthState']);}async function bp(_0x278a9f){const {auth:_0x92dc50,user:_0x2f7c9b}=_0x278a9f;return m(_0x2f7c9b,_0x92dc50,'internal-error'),ip(_0x2f7c9b,new Ns(_0x278a9f),_0x278a9f['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ec{constructor(_0x3e3fb3,_0x407009,_0x3d8e02,_0x2319ec,_0x415715=!0x1){this['auth']=_0x3e3fb3,this['resolver']=_0x3d8e02,this['user']=_0x2319ec,this['bypassAuthState']=_0x415715,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x407009)?_0x407009:[_0x407009];}['execute'](){return new Promise(async(_0xc17d23,_0x3a10f2)=>{this['pendingPromise']={'resolve':_0xc17d23,'reject':_0x3a10f2};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x260f6e){this['reject'](_0x260f6e);}});}async['onAuthEvent'](_0x4ff609){const {urlResponse:_0x4d611d,sessionId:_0x3f3b88,postBody:_0x1217e0,tenantId:_0x28887c,error:_0x43ad74,type:_0x1ce537}=_0x4ff609;if(_0x43ad74){this['reject'](_0x43ad74);return;}const _0x1506a2={'auth':this['auth'],'requestUri':_0x4d611d,'sessionId':_0x3f3b88,'tenantId':_0x28887c||void 0x0,'postBody':_0x1217e0||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x1ce537)(_0x1506a2));}catch(_0x5e7cad){this['reject'](_0x5e7cad);}}['onError'](_0x58bc26){this['reject'](_0x58bc26);}['getIdpTask'](_0x5e3ab7){switch(_0x5e3ab7){case'signInViaPopup':case'signInViaRedirect':return Tp;case'linkViaPopup':case'linkViaRedirect':return bp;case'reauthViaPopup':case'reauthViaRedirect':return Sp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x29823b){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x29823b),this['unregisterAndCleanUp']();}['reject'](_0x5b75f4){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x5b75f4),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rp=new Zt(0x7d0,0x2710);class Xe extends ec{constructor(_0x125dc2,_0x34ec5a,_0x560984,_0x3958c7,_0x5c4924){super(_0x125dc2,_0x34ec5a,_0x3958c7,_0x5c4924),this['provider']=_0x560984,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x1bef09=await this['execute']();return m(_0x1bef09,this['auth'],'internal-error'),_0x1bef09;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x2785d3=ks();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x2785d3),this['authWindow']['associatedEvent']=_0x2785d3,this['resolver']['_originValidation'](this['auth'])['catch'](_0x4a9e3e=>{this['reject'](_0x4a9e3e);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x368d14=>{_0x368d14||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x51c272;return((_0x51c272=this['authWindow'])==null?void 0x0:_0x51c272['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0xfab771=()=>{var _0x413c4e,_0xf0a0b0;if((_0xf0a0b0=(_0x413c4e=this['authWindow'])==null?void 0x0:_0x413c4e['window'])!=null&&_0xf0a0b0['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0xfab771,Rp['get']());};_0xfab771();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ap='pendingRedirect',un=new Map();class kp extends ec{constructor(_0xfc93da,_0x1ae78b,_0x2296c3=!0x1){super(_0xfc93da,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x1ae78b,void 0x0,_0x2296c3),this['eventId']=null;}async['execute'](){let _0x4c96da=un['get'](this['auth']['_key']());if(!_0x4c96da){try{const _0x575b9f=await Np(this['resolver'],this['auth'])?await super['execute']():null;_0x4c96da=()=>Promise['resolve'](_0x575b9f);}catch(_0x294998){_0x4c96da=()=>Promise['reject'](_0x294998);}un['set'](this['auth']['_key'](),_0x4c96da);}return this['bypassAuthState']||un['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x4c96da();}async['onAuthEvent'](_0x3cef50){if(_0x3cef50['type']==='signInViaRedirect')return super['onAuthEvent'](_0x3cef50);if(_0x3cef50['type']==='unknown'){this['resolve'](null);return;}if(_0x3cef50['eventId']){const _0x1381ab=await this['auth']['_redirectUserForId'](_0x3cef50['eventId']);if(_0x1381ab)return this['user']=_0x1381ab,super['onAuthEvent'](_0x3cef50);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Np(_0x3f0523,_0x21f0cd){const _0xf30529=Dp(_0x21f0cd),_0x3ee84c=Op(_0x3f0523);if(!await _0x3ee84c['_isAvailable']())return!0x1;const _0x332ca1=await _0x3ee84c['_get'](_0xf30529)==='true';return await _0x3ee84c['_remove'](_0xf30529),_0x332ca1;}function Pp(_0x5bb9a6,_0x236b61){un['set'](_0x5bb9a6['_key'](),_0x236b61);}function Op(_0x3a3bec){return ie(_0x3a3bec['_redirectPersistence']);}function Dp(_0x2e89d1){return hn(Ap,_0x2e89d1['config']['apiKey'],_0x2e89d1['name']);}async function Mp(_0x331dff,_0x8f2857,_0x13867c=!0x1){if($(_0x331dff['app']))return Promise['reject'](re(_0x331dff));const _0x2377fb=Ke(_0x331dff),_0x12d310=Cp(_0x2377fb,_0x8f2857),_0x25497f=await new kp(_0x2377fb,_0x12d310,_0x13867c)['execute']();return _0x25497f&&!_0x13867c&&(delete _0x25497f['user']['_redirectEventId'],await _0x2377fb['_persistUserIfCurrent'](_0x25497f['user']),await _0x2377fb['_setRedirectUser'](null,_0x8f2857)),_0x25497f;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Lp=0x258*0x3e8;class xp{constructor(_0x11a362){this['auth']=_0x11a362,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x306a57){this['consumers']['add'](_0x306a57),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x306a57)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x306a57),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x2ec90e){this['consumers']['delete'](_0x2ec90e);}['onEvent'](_0x51e121){if(this['hasEventBeenHandled'](_0x51e121))return!0x1;let _0x302e42=!0x1;return this['consumers']['forEach'](_0x5bf691=>{this['isEventForConsumer'](_0x51e121,_0x5bf691)&&(_0x302e42=!0x0,this['sendToConsumer'](_0x51e121,_0x5bf691),this['saveEventToCache'](_0x51e121));}),this['hasHandledPotentialRedirect']||!Fp(_0x51e121)||(this['hasHandledPotentialRedirect']=!0x0,_0x302e42||(this['queuedRedirectEvent']=_0x51e121,_0x302e42=!0x0)),_0x302e42;}['sendToConsumer'](_0x854405,_0x5b1221){var _0x15f2cf;if(_0x854405['error']&&!tc(_0x854405)){const _0x592aa7=((_0x15f2cf=_0x854405['error']['code'])==null?void 0x0:_0x15f2cf['split']('auth/')[0x1])||'internal-error';_0x5b1221['onError'](X(this['auth'],_0x592aa7));}else _0x5b1221['onAuthEvent'](_0x854405);}['isEventForConsumer'](_0x2bed7d,_0x3cdf5e){const _0x1d7ae9=_0x3cdf5e['eventId']===null||!!_0x2bed7d['eventId']&&_0x2bed7d['eventId']===_0x3cdf5e['eventId'];return _0x3cdf5e['filter']['includes'](_0x2bed7d['type'])&&_0x1d7ae9;}['hasEventBeenHandled'](_0x2e8ac2){return Date['now']()-this['lastProcessedEventTime']>=Lp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Br(_0x2e8ac2));}['saveEventToCache'](_0x57b24b){this['cachedEventUids']['add'](Br(_0x57b24b)),this['lastProcessedEventTime']=Date['now']();}}function Br(_0x25f390){return[_0x25f390['type'],_0x25f390['eventId'],_0x25f390['sessionId'],_0x25f390['tenantId']]['filter'](_0x1e3d0b=>_0x1e3d0b)['join']('-');}function tc({type:_0x3c1a10,error:_0x442679}){return _0x3c1a10==='unknown'&&(_0x442679==null?void 0x0:_0x442679['code'])==='auth/no-auth-event';}function Fp(_0x5e6524){switch(_0x5e6524['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return tc(_0x5e6524);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Up(_0x3bf920,_0x17a14d={}){return Ae(_0x3bf920,'GET','/v1/projects',_0x17a14d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Wp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Bp=/^https?/;async function Vp(_0x59bc36){if(_0x59bc36['config']['emulator'])return;const {authorizedDomains:_0x358b1c}=await Up(_0x59bc36);for(const _0x3491e7 of _0x358b1c)try{if(Hp(_0x3491e7))return;}catch{}Y(_0x59bc36,'unauthorized-domain');}function Hp(_0x771cb){const _0x1cf707=Mi(),{protocol:_0x1f53c6,hostname:_0x567b47}=new URL(_0x1cf707);if(_0x771cb['startsWith']('chrome-extension://')){const _0x26508e=new URL(_0x771cb);return _0x26508e['hostname']===''&&_0x567b47===''?_0x1f53c6==='chrome-extension:'&&_0x771cb['replace']('chrome-extension://','')===_0x1cf707['replace']('chrome-extension://',''):_0x1f53c6==='chrome-extension:'&&_0x26508e['hostname']===_0x567b47;}if(!Bp['test'](_0x1f53c6))return!0x1;if(Wp['test'](_0x771cb))return _0x567b47===_0x771cb;const _0x5469d2=_0x771cb['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x5469d2+'|'+_0x5469d2+')$','i')['test'](_0x567b47);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x7530,0xea60);function Vr(){const _0x2bb9cc=Z()['___jsl'];if(_0x2bb9cc!=null&&_0x2bb9cc['H']){for(const _0x45aac6 of Object['keys'](_0x2bb9cc['H']))if(_0x2bb9cc['H'][_0x45aac6]['r']=_0x2bb9cc['H'][_0x45aac6]['r']||[],_0x2bb9cc['H'][_0x45aac6]['L']=_0x2bb9cc['H'][_0x45aac6]['L']||[],_0x2bb9cc['H'][_0x45aac6]['r']=[..._0x2bb9cc['H'][_0x45aac6]['L']],_0x2bb9cc['CP']){for(let _0x177324=0x0;_0x177324<_0x2bb9cc['CP']['length'];_0x177324++)_0x2bb9cc['CP'][_0x177324]=null;}}}function Gp(_0x28baad){return new Promise((_0x1f486a,_0x3b1c94)=>{var _0x280b91,_0x896c74,_0x4a0e46;function _0x4fe306(){Vr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x1f486a(gapi['iframes']['getContext']());},'ontimeout':()=>{Vr(),_0x3b1c94(X(_0x28baad,'network-request-failed'));},'timeout':$p['get']()});}if((_0x896c74=(_0x280b91=Z()['gapi'])==null?void 0x0:_0x280b91['iframes'])!=null&&_0x896c74['Iframe'])_0x1f486a(gapi['iframes']['getContext']());else{if((_0x4a0e46=Z()['gapi'])!=null&&_0x4a0e46['load'])_0x4fe306();else{const _0x24e92b=Bf('iframefcb');return Z()[_0x24e92b]=()=>{gapi['load']?_0x4fe306():_0x3b1c94(X(_0x28baad,'network-request-failed'));},Ua(Wf()+'?onload='+_0x24e92b)['catch'](_0x48df7d=>_0x3b1c94(_0x48df7d));}}})['catch'](_0xe350f7=>{throw dn=null,_0xe350f7;});}let dn=null;function qp(_0x5907ad){return dn=dn||Gp(_0x5907ad),dn;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zp=new Zt(0x1388,0x3a98),jp='__/auth/iframe',Kp='emulator/auth/iframe',Yp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Qp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Jp(_0x49a8a0){const _0x3c24a7=_0x49a8a0['config'];m(_0x3c24a7['authDomain'],_0x49a8a0,'auth-domain-config-required');const _0x3b0cec=_0x3c24a7['emulator']?Ts(_0x3c24a7,Kp):'https://'+_0x49a8a0['config']['authDomain']+'/'+jp,_0x2694da={'apiKey':_0x3c24a7['apiKey'],'appName':_0x49a8a0['name'],'v':dt},_0x42e687=Qp['get'](_0x49a8a0['config']['apiHost']);_0x42e687&&(_0x2694da['eid']=_0x42e687);const _0x1961d4=_0x49a8a0['_getFrameworks']();return _0x1961d4['length']&&(_0x2694da['fw']=_0x1961d4['join'](',')),_0x3b0cec+'?'+ut(_0x2694da)['slice'](0x1);}async function Xp(_0x1b678e){const _0x5d0429=await qp(_0x1b678e),_0x3a69ac=Z()['gapi'];return m(_0x3a69ac,_0x1b678e,'internal-error'),_0x5d0429['open']({'where':document['body'],'url':Jp(_0x1b678e),'messageHandlersFilter':_0x3a69ac['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Yp,'dontclear':!0x0},_0x20aafe=>new Promise(async(_0x44d981,_0x499802)=>{await _0x20aafe['restyle']({'setHideOnLeave':!0x1});const _0xcc1d16=X(_0x1b678e,'network-request-failed'),_0x35a726=Z()['setTimeout'](()=>{_0x499802(_0xcc1d16);},zp['get']());function _0x54d330(){Z()['clearTimeout'](_0x35a726),_0x44d981(_0x20aafe);}_0x20aafe['ping'](_0x54d330)['then'](_0x54d330,()=>{_0x499802(_0xcc1d16);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},e_=0x1f4,t_=0x258,n_='_blank',i_='http://localhost';class Hr{constructor(_0x1d126a){this['window']=_0x1d126a,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function s_(_0x211ac3,_0x57b348,_0x36d46a,_0x555343=e_,_0x23f6dc=t_){const _0xb867e2=Math['max']((window['screen']['availHeight']-_0x23f6dc)/0x2,0x0)['toString'](),_0x20da87=Math['max']((window['screen']['availWidth']-_0x555343)/0x2,0x0)['toString']();let _0x360a40='';const _0x2c6df7={...Zp,'width':_0x555343['toString'](),'height':_0x23f6dc['toString'](),'top':_0xb867e2,'left':_0x20da87},_0xe68160=W()['toLowerCase']();_0x36d46a&&(_0x360a40=Pa(_0xe68160)?n_:_0x36d46a),ka(_0xe68160)&&(_0x57b348=_0x57b348||i_,_0x2c6df7['scrollbars']='yes');const _0x356cdd=Object['entries'](_0x2c6df7)['reduce']((_0x294c09,[_0x346661,_0x8ee17b])=>''+_0x294c09+_0x346661+'='+_0x8ee17b+',','');if(Nf(_0xe68160)&&_0x360a40!=='_self')return r_(_0x57b348||'',_0x360a40),new Hr(null);const _0x580d3e=window['open'](_0x57b348||'',_0x360a40,_0x356cdd);m(_0x580d3e,_0x211ac3,'popup-blocked');try{_0x580d3e['focus']();}catch{}return new Hr(_0x580d3e);}function r_(_0x48eb63,_0x2735fe){const _0x15b512=document['createElement']('a');_0x15b512['href']=_0x48eb63,_0x15b512['target']=_0x2735fe;const _0x5bde03=document['createEvent']('MouseEvent');_0x5bde03['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x15b512['dispatchEvent'](_0x5bde03);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const o_='__/auth/handler',a_='emulator/auth/handler',c_=encodeURIComponent('fac');async function $r(_0x3d5bbf,_0x46703c,_0x465c6f,_0x2cc2d7,_0x24fa65,_0x44bd13){m(_0x3d5bbf['config']['authDomain'],_0x3d5bbf,'auth-domain-config-required'),m(_0x3d5bbf['config']['apiKey'],_0x3d5bbf,'invalid-api-key');const _0x4d5c82={'apiKey':_0x3d5bbf['config']['apiKey'],'appName':_0x3d5bbf['name'],'authType':_0x465c6f,'redirectUrl':_0x2cc2d7,'v':dt,'eventId':_0x24fa65};if(_0x46703c instanceof Va){_0x46703c['setDefaultLanguage'](_0x3d5bbf['languageCode']),_0x4d5c82['providerId']=_0x46703c['providerId']||'',_n(_0x46703c['getCustomParameters']())||(_0x4d5c82['customParameters']=JSON['stringify'](_0x46703c['getCustomParameters']()));for(const [_0xe1a5da,_0x58ecde]of Object['entries']({}))_0x4d5c82[_0xe1a5da]=_0x58ecde;}if(_0x46703c instanceof tn){const _0x1696ee=_0x46703c['getScopes']()['filter'](_0x3e4b5f=>_0x3e4b5f!=='');_0x1696ee['length']>0x0&&(_0x4d5c82['scopes']=_0x1696ee['join'](','));}_0x3d5bbf['tenantId']&&(_0x4d5c82['tid']=_0x3d5bbf['tenantId']);const _0xcff410=_0x4d5c82;for(const _0x13342b of Object['keys'](_0xcff410))_0xcff410[_0x13342b]===void 0x0&&delete _0xcff410[_0x13342b];const _0x5e2706=await _0x3d5bbf['_getAppCheckToken'](),_0x365a92=_0x5e2706?'#'+c_+'='+encodeURIComponent(_0x5e2706):'';return l_(_0x3d5bbf)+'?'+ut(_0xcff410)['slice'](0x1)+_0x365a92;}function l_({config:_0x23458c}){return _0x23458c['emulator']?Ts(_0x23458c,a_):'https://'+_0x23458c['authDomain']+'/'+o_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class h_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=Ka,this['_completeRedirectFn']=Mp,this['_overrideRedirectResult']=Pp;}async['_openPopup'](_0x5029e2,_0x51635b,_0x2f10a1,_0x3311d1){var _0x41d245;ce((_0x41d245=this['eventManagers'][_0x5029e2['_key']()])==null?void 0x0:_0x41d245['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x4effef=await $r(_0x5029e2,_0x51635b,_0x2f10a1,Mi(),_0x3311d1);return s_(_0x5029e2,_0x4effef,ks());}async['_openRedirect'](_0x2b1542,_0x349e73,_0x16c786,_0x5ca482){await this['_originValidation'](_0x2b1542);const _0x295381=await $r(_0x2b1542,_0x349e73,_0x16c786,Mi(),_0x5ca482);return fp(_0x295381),new Promise(()=>{});}['_initialize'](_0x2b2062){const _0x3438d9=_0x2b2062['_key']();if(this['eventManagers'][_0x3438d9]){const {manager:_0x17bde1,promise:_0x27a850}=this['eventManagers'][_0x3438d9];return _0x17bde1?Promise['resolve'](_0x17bde1):(ce(_0x27a850,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x27a850);}const _0x581fc5=this['initAndGetManager'](_0x2b2062);return this['eventManagers'][_0x3438d9]={'promise':_0x581fc5},_0x581fc5['catch'](()=>{delete this['eventManagers'][_0x3438d9];}),_0x581fc5;}async['initAndGetManager'](_0x33a330){const _0xf0a1da=await Xp(_0x33a330),_0x41ce24=new xp(_0x33a330);return _0xf0a1da['register']('authEvent',_0x4ee1d0=>(m(_0x4ee1d0==null?void 0x0:_0x4ee1d0['authEvent'],_0x33a330,'invalid-auth-event'),{'status':_0x41ce24['onEvent'](_0x4ee1d0['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x33a330['_key']()]={'manager':_0x41ce24},this['iframes'][_0x33a330['_key']()]=_0xf0a1da,_0x41ce24;}['_isIframeWebStorageSupported'](_0x28bad2,_0x1f4d5d){this['iframes'][_0x28bad2['_key']()]['send'](pi,{'type':pi},_0x1756ab=>{var _0x297dc3;const _0xf24d37=(_0x297dc3=_0x1756ab==null?void 0x0:_0x1756ab[0x0])==null?void 0x0:_0x297dc3[pi];_0xf24d37!==void 0x0&&_0x1f4d5d(!!_0xf24d37),Y(_0x28bad2,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x5020e1){const _0x33f3c=_0x5020e1['_key']();return this['originValidationPromises'][_0x33f3c]||(this['originValidationPromises'][_0x33f3c]=Vp(_0x5020e1)),this['originValidationPromises'][_0x33f3c];}get['_shouldInitProactively'](){return xa()||Na()||bs();}}const u_=h_;var Gr='@firebase/auth',qr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class d_{constructor(_0x173925){this['auth']=_0x173925,this['internalListeners']=new Map();}['getUid'](){var _0x437b7d;return this['assertAuthConfigured'](),((_0x437b7d=this['auth']['currentUser'])==null?void 0x0:_0x437b7d['uid'])||null;}async['getToken'](_0x54c442){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x54c442)}:null;}['addAuthTokenListener'](_0x5e9216){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x5e9216))return;const _0x11b110=this['auth']['onIdTokenChanged'](_0x348f57=>{_0x5e9216((_0x348f57==null?void 0x0:_0x348f57['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x5e9216,_0x11b110),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x43b390){this['assertAuthConfigured']();const _0x2713c6=this['internalListeners']['get'](_0x43b390);_0x2713c6&&(this['internalListeners']['delete'](_0x43b390),_0x2713c6(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function f_(_0x46dcd9){switch(_0x46dcd9){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function p_(_0x483ff1){st(new Fe('auth',(_0x3fc794,{options:_0x12642b})=>{const _0x36f83c=_0x3fc794['getProvider']('app')['getImmediate'](),_0x43386a=_0x3fc794['getProvider']('heartbeat'),_0x4f089d=_0x3fc794['getProvider']('app-check-internal'),{apiKey:_0x24f546,authDomain:_0x4c5116}=_0x36f83c['options'];m(_0x24f546&&!_0x24f546['includes'](':'),'invalid-api-key',{'appName':_0x36f83c['name']});const _0x1b57f2={'apiKey':_0x24f546,'authDomain':_0x4c5116,'clientPlatform':_0x483ff1,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Fa(_0x483ff1)},_0x5d66a5=new xf(_0x36f83c,_0x43386a,_0x4f089d,_0x1b57f2);return qf(_0x5d66a5,_0x12642b),_0x5d66a5;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x2b373d,_0x216a62,_0x2d1996)=>{_0x2b373d['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x2ceb73=>{const _0x5c7ab6=Ke(_0x2ceb73['getProvider']('auth')['getImmediate']());return(_0x4e8698=>new d_(_0x4e8698))(_0x5c7ab6);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Gr,qr,f_(_0x483ff1)),ye(Gr,qr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const __=0x12c,g_=Zr('authIdTokenMaxAge')||__;let zr=null;const m_=_0x222f6f=>async _0x567371=>{const _0x44be7f=_0x567371&&await _0x567371['getIdTokenResult'](),_0x5a3819=_0x44be7f&&(new Date()['getTime']()-Date['parse'](_0x44be7f['issuedAtTime']))/0x3e8;if(_0x5a3819&&_0x5a3819>g_)return;const _0x53121c=_0x44be7f==null?void 0x0:_0x44be7f['token'];zr!==_0x53121c&&(zr=_0x53121c,await fetch(_0x222f6f,{'method':_0x53121c?'POST':'DELETE','headers':_0x53121c?{'Authorization':'Bearer\x20'+_0x53121c}:{}}));};function W_(_0x52e479=ro()){const _0x171a82=Hi(_0x52e479,'auth');if(_0x171a82['isInitialized']())return _0x171a82['getImmediate']();const _0x47c042=Gf(_0x52e479,{'popupRedirectResolver':u_,'persistence':[wp,hp,Ka]}),_0x19c790=Zr('authTokenSyncURL');if(_0x19c790&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x2ae1e3=new URL(_0x19c790,location['origin']);if(location['origin']===_0x2ae1e3['origin']){const _0x303965=m_(_0x2ae1e3['toString']());ap(_0x47c042,_0x303965,()=>_0x303965(_0x47c042['currentUser'])),op(_0x47c042,_0x3d33ce=>_0x303965(_0x3d33ce));}}const _0x406ca7=Jr('auth');return _0x406ca7&&zf(_0x47c042,'http://'+_0x406ca7),_0x47c042;}function y_(){var _0x23a5db,_0x234d07;return(_0x234d07=(_0x23a5db=document['getElementsByTagName']('head'))==null?void 0x0:_0x23a5db[0x0])!=null?_0x234d07:document;}Ff({'loadJS'(_0x153593){return new Promise((_0x2a4e73,_0x32740d)=>{const _0x379310=document['createElement']('script');_0x379310['setAttribute']('src',_0x153593),_0x379310['onload']=_0x2a4e73,_0x379310['onerror']=_0x2455e6=>{const _0x448764=X('internal-error');_0x448764['customData']=_0x2455e6,_0x32740d(_0x448764);},_0x379310['type']='text/javascript',_0x379310['charset']='UTF-8',y_()['appendChild'](_0x379310);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),p_('Browser');export{M_ as A,k_ as a,W_ as b,hp as c,ro as d,S_ as e,L_ as f,v_ as g,U_ as h,Rl as i,E_ as j,qd as k,O_ as l,jd as m,N_ as n,w_ as o,F_ as p,P_ as q,I_ as r,x_ as s,C_ as t,T_ as u,A_ as v,b_ as w,R_ as x,Vt as y,D_ as z};