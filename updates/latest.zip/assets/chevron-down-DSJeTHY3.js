import{c as a8_0x47e55b}from'./index-BFeeJ58k.js';/**
 * @license lucide-react v0.556.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const n=[['path',{'d':'m6\x209\x206\x206\x206-6','key':'qrunsl'}]],e=a8_0x47e55b('chevron-down',n);export{e as C};