import{c as a9_0x35d3d9}from'./index-HwRwxoun.js';/**
 * @license lucide-react v0.556.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const n=[['path',{'d':'m6\x209\x206\x206\x206-6','key':'qrunsl'}]],e=a9_0x35d3d9('chevron-down',n);export{e as C};