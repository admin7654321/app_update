const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x5197c0,_0x593b7f){if(!_0x5197c0)throw ht(_0x593b7f);},ht=function(_0x24165d){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x24165d);},Hr=function(_0x110578){const _0x20bc42=[];let _0x3a01cc=0x0;for(let _0xa19f37=0x0;_0xa19f37<_0x110578['length'];_0xa19f37++){let _0x1fece5=_0x110578['charCodeAt'](_0xa19f37);_0x1fece5<0x80?_0x20bc42[_0x3a01cc++]=_0x1fece5:_0x1fece5<0x800?(_0x20bc42[_0x3a01cc++]=_0x1fece5>>0x6|0xc0,_0x20bc42[_0x3a01cc++]=_0x1fece5&0x3f|0x80):(_0x1fece5&0xfc00)===0xd800&&_0xa19f37+0x1<_0x110578['length']&&(_0x110578['charCodeAt'](_0xa19f37+0x1)&0xfc00)===0xdc00?(_0x1fece5=0x10000+((_0x1fece5&0x3ff)<<0xa)+(_0x110578['charCodeAt'](++_0xa19f37)&0x3ff),_0x20bc42[_0x3a01cc++]=_0x1fece5>>0x12|0xf0,_0x20bc42[_0x3a01cc++]=_0x1fece5>>0xc&0x3f|0x80,_0x20bc42[_0x3a01cc++]=_0x1fece5>>0x6&0x3f|0x80,_0x20bc42[_0x3a01cc++]=_0x1fece5&0x3f|0x80):(_0x20bc42[_0x3a01cc++]=_0x1fece5>>0xc|0xe0,_0x20bc42[_0x3a01cc++]=_0x1fece5>>0x6&0x3f|0x80,_0x20bc42[_0x3a01cc++]=_0x1fece5&0x3f|0x80);}return _0x20bc42;},nc=function(_0x17ff05){const _0x2977a0=[];let _0x279f6f=0x0,_0x73855d=0x0;for(;_0x279f6f<_0x17ff05['length'];){const _0x5aa4f4=_0x17ff05[_0x279f6f++];if(_0x5aa4f4<0x80)_0x2977a0[_0x73855d++]=String['fromCharCode'](_0x5aa4f4);else{if(_0x5aa4f4>0xbf&&_0x5aa4f4<0xe0){const _0x2dad6a=_0x17ff05[_0x279f6f++];_0x2977a0[_0x73855d++]=String['fromCharCode']((_0x5aa4f4&0x1f)<<0x6|_0x2dad6a&0x3f);}else{if(_0x5aa4f4>0xef&&_0x5aa4f4<0x16d){const _0x180ec2=_0x17ff05[_0x279f6f++],_0x1db88a=_0x17ff05[_0x279f6f++],_0x869205=_0x17ff05[_0x279f6f++],_0x425ca8=((_0x5aa4f4&0x7)<<0x12|(_0x180ec2&0x3f)<<0xc|(_0x1db88a&0x3f)<<0x6|_0x869205&0x3f)-0x10000;_0x2977a0[_0x73855d++]=String['fromCharCode'](0xd800+(_0x425ca8>>0xa)),_0x2977a0[_0x73855d++]=String['fromCharCode'](0xdc00+(_0x425ca8&0x3ff));}else{const _0x541d87=_0x17ff05[_0x279f6f++],_0x2c32c6=_0x17ff05[_0x279f6f++];_0x2977a0[_0x73855d++]=String['fromCharCode']((_0x5aa4f4&0xf)<<0xc|(_0x541d87&0x3f)<<0x6|_0x2c32c6&0x3f);}}}}return _0x2977a0['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x14ecad,_0x124e44){if(!Array['isArray'](_0x14ecad))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x1a278a=_0x124e44?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0xd413af=[];for(let _0x587de8=0x0;_0x587de8<_0x14ecad['length'];_0x587de8+=0x3){const _0x47c17a=_0x14ecad[_0x587de8],_0x568c3c=_0x587de8+0x1<_0x14ecad['length'],_0x674ac1=_0x568c3c?_0x14ecad[_0x587de8+0x1]:0x0,_0x4b126a=_0x587de8+0x2<_0x14ecad['length'],_0x477734=_0x4b126a?_0x14ecad[_0x587de8+0x2]:0x0,_0x1ae37d=_0x47c17a>>0x2,_0x4e113a=(_0x47c17a&0x3)<<0x4|_0x674ac1>>0x4;let _0x2fb0f1=(_0x674ac1&0xf)<<0x2|_0x477734>>0x6,_0x232bdc=_0x477734&0x3f;_0x4b126a||(_0x232bdc=0x40,_0x568c3c||(_0x2fb0f1=0x40)),_0xd413af['push'](_0x1a278a[_0x1ae37d],_0x1a278a[_0x4e113a],_0x1a278a[_0x2fb0f1],_0x1a278a[_0x232bdc]);}return _0xd413af['join']('');},'encodeString'(_0x3f6aa5,_0x43519d){return this['HAS_NATIVE_SUPPORT']&&!_0x43519d?btoa(_0x3f6aa5):this['encodeByteArray'](Hr(_0x3f6aa5),_0x43519d);},'decodeString'(_0x3ba2b1,_0x12e1ac){return this['HAS_NATIVE_SUPPORT']&&!_0x12e1ac?atob(_0x3ba2b1):nc(this['decodeStringToByteArray'](_0x3ba2b1,_0x12e1ac));},'decodeStringToByteArray'(_0x3667a9,_0x36fea8){this['init_']();const _0x560baa=_0x36fea8?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x220be4=[];for(let _0x38079d=0x0;_0x38079d<_0x3667a9['length'];){const _0x35f098=_0x560baa[_0x3667a9['charAt'](_0x38079d++)],_0x32a857=_0x38079d<_0x3667a9['length']?_0x560baa[_0x3667a9['charAt'](_0x38079d)]:0x0;++_0x38079d;const _0x513180=_0x38079d<_0x3667a9['length']?_0x560baa[_0x3667a9['charAt'](_0x38079d)]:0x40;++_0x38079d;const _0x4a79f2=_0x38079d<_0x3667a9['length']?_0x560baa[_0x3667a9['charAt'](_0x38079d)]:0x40;if(++_0x38079d,_0x35f098==null||_0x32a857==null||_0x513180==null||_0x4a79f2==null)throw new ic();const _0xc66027=_0x35f098<<0x2|_0x32a857>>0x4;if(_0x220be4['push'](_0xc66027),_0x513180!==0x40){const _0x342d2d=_0x32a857<<0x4&0xf0|_0x513180>>0x2;if(_0x220be4['push'](_0x342d2d),_0x4a79f2!==0x40){const _0x50d6dd=_0x513180<<0x6&0xc0|_0x4a79f2;_0x220be4['push'](_0x50d6dd);}}}return _0x220be4;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x10bd40=0x0;_0x10bd40<this['ENCODED_VALS']['length'];_0x10bd40++)this['byteToCharMap_'][_0x10bd40]=this['ENCODED_VALS']['charAt'](_0x10bd40),this['charToByteMap_'][this['byteToCharMap_'][_0x10bd40]]=_0x10bd40,this['byteToCharMapWebSafe_'][_0x10bd40]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x10bd40),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x10bd40]]=_0x10bd40,_0x10bd40>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x10bd40)]=_0x10bd40,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x10bd40)]=_0x10bd40);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x5db245){const _0x3d640b=Hr(_0x5db245);return Fi['encodeByteArray'](_0x3d640b,!0x0);},dn=function(_0x58319a){return $r(_0x58319a)['replace'](/\./g,'');},fn=function(_0x405f3c){try{return Fi['decodeString'](_0x405f3c,!0x0);}catch(_0x9c21e7){console['error']('base64Decode\x20failed:\x20',_0x9c21e7);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x2a7582){return Gr(void 0x0,_0x2a7582);}function Gr(_0x1590e3,_0x5a8155){if(!(_0x5a8155 instanceof Object))return _0x5a8155;switch(_0x5a8155['constructor']){case Date:const _0x26bc8a=_0x5a8155;return new Date(_0x26bc8a['getTime']());case Object:_0x1590e3===void 0x0&&(_0x1590e3={});break;case Array:_0x1590e3=[];break;default:return _0x5a8155;}for(const _0x30701e in _0x5a8155)!_0x5a8155['hasOwnProperty'](_0x30701e)||!rc(_0x30701e)||(_0x1590e3[_0x30701e]=Gr(_0x1590e3[_0x30701e],_0x5a8155[_0x30701e]));return _0x1590e3;}function rc(_0x522792){return _0x522792!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x29ada1=Ps['__FIREBASE_DEFAULTS__'];if(_0x29ada1)return JSON['parse'](_0x29ada1);},lc=()=>{if(typeof document>'u')return;let _0x400b96;try{_0x400b96=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x5dc9ae=_0x400b96&&fn(_0x400b96[0x1]);return _0x5dc9ae&&JSON['parse'](_0x5dc9ae);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0xa6cca5){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0xa6cca5);return;}},qr=_0x50cefd=>{var _0x1c1e30,_0x5c334b;return(_0x5c334b=(_0x1c1e30=Ui())==null?void 0x0:_0x1c1e30['emulatorHosts'])==null?void 0x0:_0x5c334b[_0x50cefd];},hc=_0x30f658=>{const _0x2bddbe=qr(_0x30f658);if(!_0x2bddbe)return;const _0x1cc378=_0x2bddbe['lastIndexOf'](':');if(_0x1cc378<=0x0||_0x1cc378+0x1===_0x2bddbe['length'])throw new Error('Invalid\x20host\x20'+_0x2bddbe+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x138295=parseInt(_0x2bddbe['substring'](_0x1cc378+0x1),0xa);return _0x2bddbe[0x0]==='['?[_0x2bddbe['substring'](0x1,_0x1cc378-0x1),_0x138295]:[_0x2bddbe['substring'](0x0,_0x1cc378),_0x138295];},zr=()=>{var _0x450238;return(_0x450238=Ui())==null?void 0x0:_0x450238['config'];},jr=_0x45ee6f=>{var _0x5d48d6;return(_0x5d48d6=Ui())==null?void 0x0:_0x5d48d6['_'+_0x45ee6f];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x2ade14,_0x570926)=>{this['resolve']=_0x2ade14,this['reject']=_0x570926;});}['wrapCallback'](_0x54af72){return(_0x3860bb,_0x16792)=>{_0x3860bb?this['reject'](_0x3860bb):this['resolve'](_0x16792),typeof _0x54af72=='function'&&(this['promise']['catch'](()=>{}),_0x54af72['length']===0x1?_0x54af72(_0x3860bb):_0x54af72(_0x3860bb,_0x16792));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0xce4409,_0x16f3b2){if(_0xce4409['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x1a5d79={'alg':'none','type':'JWT'},_0x10002d=_0x16f3b2||'demo-project',_0x245e31=_0xce4409['iat']||0x0,_0x428c1d=_0xce4409['sub']||_0xce4409['user_id'];if(!_0x428c1d)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x4c7d38={'iss':'https://securetoken.google.com/'+_0x10002d,'aud':_0x10002d,'iat':_0x245e31,'exp':_0x245e31+0xe10,'auth_time':_0x245e31,'sub':_0x428c1d,'user_id':_0x428c1d,'firebase':{'sign_in_provider':'custom','identities':{}},..._0xce4409};return[dn(JSON['stringify'](_0x1a5d79)),dn(JSON['stringify'](_0x4c7d38)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x45c9d5=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x45c9d5=='object'&&_0x45c9d5['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x4d8c0b=W();return _0x4d8c0b['indexOf']('MSIE\x20')>=0x0||_0x4d8c0b['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x69640d,_0x15e4a2)=>{try{let _0x3db2f7=!0x0;const _0x125d76='validate-browser-context-for-indexeddb-analytics-module',_0x1069e0=self['indexedDB']['open'](_0x125d76);_0x1069e0['onsuccess']=()=>{_0x1069e0['result']['close'](),_0x3db2f7||self['indexedDB']['deleteDatabase'](_0x125d76),_0x69640d(!0x0);},_0x1069e0['onupgradeneeded']=()=>{_0x3db2f7=!0x1;},_0x1069e0['onerror']=()=>{var _0x4bdd4a;_0x15e4a2(((_0x4bdd4a=_0x1069e0['error'])==null?void 0x0:_0x4bdd4a['message'])||'');};}catch(_0x4fd513){_0x15e4a2(_0x4fd513);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x440351,_0x40c2e0,_0x24ddb0){super(_0x40c2e0),this['code']=_0x440351,this['customData']=_0x24ddb0,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x2242ff,_0xe9330b,_0x113af3){this['service']=_0x2242ff,this['serviceName']=_0xe9330b,this['errors']=_0x113af3;}['create'](_0x3919ab,..._0x28b6f9){const _0x162931=_0x28b6f9[0x0]||{},_0x5dc467=this['service']+'/'+_0x3919ab,_0x46772=this['errors'][_0x3919ab],_0xe7d992=_0x46772?vc(_0x46772,_0x162931):'Error',_0x4298ec=this['serviceName']+':\x20'+_0xe7d992+'\x20('+_0x5dc467+').';return new Re(_0x5dc467,_0x4298ec,_0x162931);}}function vc(_0x359e74,_0x12db22){return _0x359e74['replace'](Ec,(_0x575e85,_0x53d1bf)=>{const _0x3cf709=_0x12db22[_0x53d1bf];return _0x3cf709!=null?String(_0x3cf709):'<'+_0x53d1bf+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x29c00f){return JSON['parse'](_0x29c00f);}function O(_0x1f8459){return JSON['stringify'](_0x1f8459);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x35a60d){let _0x531d44={},_0x2d19f6={},_0x4c3cc8={},_0x1fafb6='';try{const _0x9975f1=_0x35a60d['split']('.');_0x531d44=Nt(fn(_0x9975f1[0x0])||''),_0x2d19f6=Nt(fn(_0x9975f1[0x1])||''),_0x1fafb6=_0x9975f1[0x2],_0x4c3cc8=_0x2d19f6['d']||{},delete _0x2d19f6['d'];}catch{}return{'header':_0x531d44,'claims':_0x2d19f6,'data':_0x4c3cc8,'signature':_0x1fafb6};},Ic=function(_0x43544d){const _0xdd4c0=Yr(_0x43544d),_0x1e19e4=_0xdd4c0['claims'];return!!_0x1e19e4&&typeof _0x1e19e4=='object'&&_0x1e19e4['hasOwnProperty']('iat');},wc=function(_0xdce05){const _0x14e028=Yr(_0xdce05)['claims'];return typeof _0x14e028=='object'&&_0x14e028['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x560fab,_0xbaf596){return Object['prototype']['hasOwnProperty']['call'](_0x560fab,_0xbaf596);}function Le(_0x27a0cf,_0x437b5d){if(Object['prototype']['hasOwnProperty']['call'](_0x27a0cf,_0x437b5d))return _0x27a0cf[_0x437b5d];}function pn(_0x4badff){for(const _0x2e399c in _0x4badff)if(Object['prototype']['hasOwnProperty']['call'](_0x4badff,_0x2e399c))return!0x1;return!0x0;}function _n(_0x3b6b2e,_0x1ffcd9,_0xf7ddd4){const _0x5cf280={};for(const _0x322cb3 in _0x3b6b2e)Object['prototype']['hasOwnProperty']['call'](_0x3b6b2e,_0x322cb3)&&(_0x5cf280[_0x322cb3]=_0x1ffcd9['call'](_0xf7ddd4,_0x3b6b2e[_0x322cb3],_0x322cb3,_0x3b6b2e));return _0x5cf280;}function xe(_0x11a7ed,_0x1e9fcb){if(_0x11a7ed===_0x1e9fcb)return!0x0;const _0x50155a=Object['keys'](_0x11a7ed),_0x81b578=Object['keys'](_0x1e9fcb);for(const _0x5196e6 of _0x50155a){if(!_0x81b578['includes'](_0x5196e6))return!0x1;const _0x34bad1=_0x11a7ed[_0x5196e6],_0x1961c2=_0x1e9fcb[_0x5196e6];if(Ns(_0x34bad1)&&Ns(_0x1961c2)){if(!xe(_0x34bad1,_0x1961c2))return!0x1;}else{if(_0x34bad1!==_0x1961c2)return!0x1;}}for(const _0x5ddeaf of _0x81b578)if(!_0x50155a['includes'](_0x5ddeaf))return!0x1;return!0x0;}function Ns(_0x3da4b8){return _0x3da4b8!==null&&typeof _0x3da4b8=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x488092){const _0x350bb1=[];for(const [_0x2b7655,_0x582164]of Object['entries'](_0x488092))Array['isArray'](_0x582164)?_0x582164['forEach'](_0x5e2376=>{_0x350bb1['push'](encodeURIComponent(_0x2b7655)+'='+encodeURIComponent(_0x5e2376));}):_0x350bb1['push'](encodeURIComponent(_0x2b7655)+'='+encodeURIComponent(_0x582164));return _0x350bb1['length']?'&'+_0x350bb1['join']('&'):'';}function Ct(_0x17d8df){const _0x1be810={};return _0x17d8df['replace'](/^\?/,'')['split']('&')['forEach'](_0x1cb45e=>{if(_0x1cb45e){const [_0xd1b4c9,_0x2fe179]=_0x1cb45e['split']('=');_0x1be810[decodeURIComponent(_0xd1b4c9)]=decodeURIComponent(_0x2fe179);}}),_0x1be810;}function Tt(_0x217383){const _0x7c3757=_0x217383['indexOf']('?');if(!_0x7c3757)return'';const _0x15c09b=_0x217383['indexOf']('#',_0x7c3757);return _0x217383['substring'](_0x7c3757,_0x15c09b>0x0?_0x15c09b:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x29790c=0x1;_0x29790c<this['blockSize'];++_0x29790c)this['pad_'][_0x29790c]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x5a789c,_0x5b9eb3){_0x5b9eb3||(_0x5b9eb3=0x0);const _0x52d76c=this['W_'];if(typeof _0x5a789c=='string'){for(let _0x19eee8=0x0;_0x19eee8<0x10;_0x19eee8++)_0x52d76c[_0x19eee8]=_0x5a789c['charCodeAt'](_0x5b9eb3)<<0x18|_0x5a789c['charCodeAt'](_0x5b9eb3+0x1)<<0x10|_0x5a789c['charCodeAt'](_0x5b9eb3+0x2)<<0x8|_0x5a789c['charCodeAt'](_0x5b9eb3+0x3),_0x5b9eb3+=0x4;}else{for(let _0x5c302c=0x0;_0x5c302c<0x10;_0x5c302c++)_0x52d76c[_0x5c302c]=_0x5a789c[_0x5b9eb3]<<0x18|_0x5a789c[_0x5b9eb3+0x1]<<0x10|_0x5a789c[_0x5b9eb3+0x2]<<0x8|_0x5a789c[_0x5b9eb3+0x3],_0x5b9eb3+=0x4;}for(let _0x5e712e=0x10;_0x5e712e<0x50;_0x5e712e++){const _0x5bcbdb=_0x52d76c[_0x5e712e-0x3]^_0x52d76c[_0x5e712e-0x8]^_0x52d76c[_0x5e712e-0xe]^_0x52d76c[_0x5e712e-0x10];_0x52d76c[_0x5e712e]=(_0x5bcbdb<<0x1|_0x5bcbdb>>>0x1f)&0xffffffff;}let _0x3bc6e6=this['chain_'][0x0],_0x210f56=this['chain_'][0x1],_0x132764=this['chain_'][0x2],_0x3575bb=this['chain_'][0x3],_0x58e9f6=this['chain_'][0x4],_0x512bd2,_0x3ffcb5;for(let _0x189038=0x0;_0x189038<0x50;_0x189038++){_0x189038<0x28?_0x189038<0x14?(_0x512bd2=_0x3575bb^_0x210f56&(_0x132764^_0x3575bb),_0x3ffcb5=0x5a827999):(_0x512bd2=_0x210f56^_0x132764^_0x3575bb,_0x3ffcb5=0x6ed9eba1):_0x189038<0x3c?(_0x512bd2=_0x210f56&_0x132764|_0x3575bb&(_0x210f56|_0x132764),_0x3ffcb5=0x8f1bbcdc):(_0x512bd2=_0x210f56^_0x132764^_0x3575bb,_0x3ffcb5=0xca62c1d6);const _0x467036=(_0x3bc6e6<<0x5|_0x3bc6e6>>>0x1b)+_0x512bd2+_0x58e9f6+_0x3ffcb5+_0x52d76c[_0x189038]&0xffffffff;_0x58e9f6=_0x3575bb,_0x3575bb=_0x132764,_0x132764=(_0x210f56<<0x1e|_0x210f56>>>0x2)&0xffffffff,_0x210f56=_0x3bc6e6,_0x3bc6e6=_0x467036;}this['chain_'][0x0]=this['chain_'][0x0]+_0x3bc6e6&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x210f56&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x132764&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x3575bb&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x58e9f6&0xffffffff;}['update'](_0x36b93e,_0x316926){if(_0x36b93e==null)return;_0x316926===void 0x0&&(_0x316926=_0x36b93e['length']);const _0x3da836=_0x316926-this['blockSize'];let _0xe97781=0x0;const _0x5ed3df=this['buf_'];let _0x4915cd=this['inbuf_'];for(;_0xe97781<_0x316926;){if(_0x4915cd===0x0){for(;_0xe97781<=_0x3da836;)this['compress_'](_0x36b93e,_0xe97781),_0xe97781+=this['blockSize'];}if(typeof _0x36b93e=='string'){for(;_0xe97781<_0x316926;)if(_0x5ed3df[_0x4915cd]=_0x36b93e['charCodeAt'](_0xe97781),++_0x4915cd,++_0xe97781,_0x4915cd===this['blockSize']){this['compress_'](_0x5ed3df),_0x4915cd=0x0;break;}}else{for(;_0xe97781<_0x316926;)if(_0x5ed3df[_0x4915cd]=_0x36b93e[_0xe97781],++_0x4915cd,++_0xe97781,_0x4915cd===this['blockSize']){this['compress_'](_0x5ed3df),_0x4915cd=0x0;break;}}}this['inbuf_']=_0x4915cd,this['total_']+=_0x316926;}['digest'](){const _0x3f6446=[];let _0x4f3f16=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x2d10af=this['blockSize']-0x1;_0x2d10af>=0x38;_0x2d10af--)this['buf_'][_0x2d10af]=_0x4f3f16&0xff,_0x4f3f16/=0x100;this['compress_'](this['buf_']);let _0x239d34=0x0;for(let _0x1ae265=0x0;_0x1ae265<0x5;_0x1ae265++)for(let _0x190c00=0x18;_0x190c00>=0x0;_0x190c00-=0x8)_0x3f6446[_0x239d34]=this['chain_'][_0x1ae265]>>_0x190c00&0xff,++_0x239d34;return _0x3f6446;}}function Tc(_0x184868,_0x2edb6e){const _0x183536=new Sc(_0x184868,_0x2edb6e);return _0x183536['subscribe']['bind'](_0x183536);}class Sc{constructor(_0x1c6399,_0x4beac9){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x4beac9,this['task']['then'](()=>{_0x1c6399(this);})['catch'](_0x163f74=>{this['error'](_0x163f74);});}['next'](_0x191bdf){this['forEachObserver'](_0x4ad11c=>{_0x4ad11c['next'](_0x191bdf);});}['error'](_0x39d71e){this['forEachObserver'](_0x4ee48b=>{_0x4ee48b['error'](_0x39d71e);}),this['close'](_0x39d71e);}['complete'](){this['forEachObserver'](_0x3063bf=>{_0x3063bf['complete']();}),this['close']();}['subscribe'](_0x1b3a88,_0x4cbbd7,_0x353124){let _0x41bb89;if(_0x1b3a88===void 0x0&&_0x4cbbd7===void 0x0&&_0x353124===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x1b3a88,['next','error','complete'])?_0x41bb89=_0x1b3a88:_0x41bb89={'next':_0x1b3a88,'error':_0x4cbbd7,'complete':_0x353124},_0x41bb89['next']===void 0x0&&(_0x41bb89['next']=ti),_0x41bb89['error']===void 0x0&&(_0x41bb89['error']=ti),_0x41bb89['complete']===void 0x0&&(_0x41bb89['complete']=ti);const _0x36f9b9=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x41bb89['error'](this['finalError']):_0x41bb89['complete']();}catch{}}),this['observers']['push'](_0x41bb89),_0x36f9b9;}['unsubscribeOne'](_0xc46dee){this['observers']===void 0x0||this['observers'][_0xc46dee]===void 0x0||(delete this['observers'][_0xc46dee],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x1fc600){if(!this['finalized']){for(let _0x580b42=0x0;_0x580b42<this['observers']['length'];_0x580b42++)this['sendOne'](_0x580b42,_0x1fc600);}}['sendOne'](_0xc25f71,_0x219dcd){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0xc25f71]!==void 0x0)try{_0x219dcd(this['observers'][_0xc25f71]);}catch(_0x9d03df){typeof console<'u'&&console['error']&&console['error'](_0x9d03df);}});}['close'](_0x7740b6){this['finalized']||(this['finalized']=!0x0,_0x7740b6!==void 0x0&&(this['finalError']=_0x7740b6),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x5d8f66,_0x3a4b7d){if(typeof _0x5d8f66!='object'||_0x5d8f66===null)return!0x1;for(const _0x39f94c of _0x3a4b7d)if(_0x39f94c in _0x5d8f66&&typeof _0x5d8f66[_0x39f94c]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x494725,_0x3cb9b5){return _0x494725+'\x20failed:\x20'+_0x3cb9b5+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x2aade6){const _0x37cc7d=[];let _0x502a54=0x0;for(let _0x377366=0x0;_0x377366<_0x2aade6['length'];_0x377366++){let _0x1412bc=_0x2aade6['charCodeAt'](_0x377366);if(_0x1412bc>=0xd800&&_0x1412bc<=0xdbff){const _0x3fea23=_0x1412bc-0xd800;_0x377366++,f(_0x377366<_0x2aade6['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x53a601=_0x2aade6['charCodeAt'](_0x377366)-0xdc00;_0x1412bc=0x10000+(_0x3fea23<<0xa)+_0x53a601;}_0x1412bc<0x80?_0x37cc7d[_0x502a54++]=_0x1412bc:_0x1412bc<0x800?(_0x37cc7d[_0x502a54++]=_0x1412bc>>0x6|0xc0,_0x37cc7d[_0x502a54++]=_0x1412bc&0x3f|0x80):_0x1412bc<0x10000?(_0x37cc7d[_0x502a54++]=_0x1412bc>>0xc|0xe0,_0x37cc7d[_0x502a54++]=_0x1412bc>>0x6&0x3f|0x80,_0x37cc7d[_0x502a54++]=_0x1412bc&0x3f|0x80):(_0x37cc7d[_0x502a54++]=_0x1412bc>>0x12|0xf0,_0x37cc7d[_0x502a54++]=_0x1412bc>>0xc&0x3f|0x80,_0x37cc7d[_0x502a54++]=_0x1412bc>>0x6&0x3f|0x80,_0x37cc7d[_0x502a54++]=_0x1412bc&0x3f|0x80);}return _0x37cc7d;},Ln=function(_0x13c29b){let _0x384571=0x0;for(let _0x162d2a=0x0;_0x162d2a<_0x13c29b['length'];_0x162d2a++){const _0x328d89=_0x13c29b['charCodeAt'](_0x162d2a);_0x328d89<0x80?_0x384571++:_0x328d89<0x800?_0x384571+=0x2:_0x328d89>=0xd800&&_0x328d89<=0xdbff?(_0x384571+=0x4,_0x162d2a++):_0x384571+=0x3;}return _0x384571;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x76109d){return _0x76109d&&_0x76109d['_delegate']?_0x76109d['_delegate']:_0x76109d;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x5dcadd){try{return(_0x5dcadd['startsWith']('http://')||_0x5dcadd['startsWith']('https://')?new URL(_0x5dcadd)['hostname']:_0x5dcadd)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x23fdf1){return(await fetch(_0x23fdf1,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x57be17,_0x136257,_0xa0b34d){this['name']=_0x57be17,this['instanceFactory']=_0x136257,this['type']=_0xa0b34d,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x41e53f){return this['instantiationMode']=_0x41e53f,this;}['setMultipleInstances'](_0x5a82b7){return this['multipleInstances']=_0x5a82b7,this;}['setServiceProps'](_0x56eb7e){return this['serviceProps']=_0x56eb7e,this;}['setInstanceCreatedCallback'](_0x173784){return this['onInstanceCreated']=_0x173784,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x4831cd,_0x581598){this['name']=_0x4831cd,this['container']=_0x581598,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x3b8bdc){const _0x2bc0af=this['normalizeInstanceIdentifier'](_0x3b8bdc);if(!this['instancesDeferred']['has'](_0x2bc0af)){const _0xca0b6b=new H();if(this['instancesDeferred']['set'](_0x2bc0af,_0xca0b6b),this['isInitialized'](_0x2bc0af)||this['shouldAutoInitialize']())try{const _0x40b4ec=this['getOrInitializeService']({'instanceIdentifier':_0x2bc0af});_0x40b4ec&&_0xca0b6b['resolve'](_0x40b4ec);}catch{}}return this['instancesDeferred']['get'](_0x2bc0af)['promise'];}['getImmediate'](_0x2e2753){const _0x50974e=this['normalizeInstanceIdentifier'](_0x2e2753==null?void 0x0:_0x2e2753['identifier']),_0x24b0c8=(_0x2e2753==null?void 0x0:_0x2e2753['optional'])??!0x1;if(this['isInitialized'](_0x50974e)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x50974e});}catch(_0x5b152d){if(_0x24b0c8)return null;throw _0x5b152d;}else{if(_0x24b0c8)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x503350){if(_0x503350['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x503350['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x503350,!!this['shouldAutoInitialize']()){if(Pc(_0x503350))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x439b06,_0x318c38]of this['instancesDeferred']['entries']()){const _0x552acb=this['normalizeInstanceIdentifier'](_0x439b06);try{const _0x119b53=this['getOrInitializeService']({'instanceIdentifier':_0x552acb});_0x318c38['resolve'](_0x119b53);}catch{}}}}['clearInstance'](_0x1ed1f8=Ne){this['instancesDeferred']['delete'](_0x1ed1f8),this['instancesOptions']['delete'](_0x1ed1f8),this['instances']['delete'](_0x1ed1f8);}async['delete'](){const _0x1d72e5=Array['from'](this['instances']['values']());await Promise['all']([..._0x1d72e5['filter'](_0x38ee77=>'INTERNAL'in _0x38ee77)['map'](_0x45acd4=>_0x45acd4['INTERNAL']['delete']()),..._0x1d72e5['filter'](_0x4b76f9=>'_delete'in _0x4b76f9)['map'](_0x2ff892=>_0x2ff892['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x2557eb=Ne){return this['instances']['has'](_0x2557eb);}['getOptions'](_0x3fbc27=Ne){return this['instancesOptions']['get'](_0x3fbc27)||{};}['initialize'](_0x2843e1={}){const {options:_0x2cd010={}}=_0x2843e1,_0x5c793c=this['normalizeInstanceIdentifier'](_0x2843e1['instanceIdentifier']);if(this['isInitialized'](_0x5c793c))throw Error(this['name']+'('+_0x5c793c+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x3f87b7=this['getOrInitializeService']({'instanceIdentifier':_0x5c793c,'options':_0x2cd010});for(const [_0x1d98c2,_0x5798b0]of this['instancesDeferred']['entries']()){const _0xa4ec38=this['normalizeInstanceIdentifier'](_0x1d98c2);_0x5c793c===_0xa4ec38&&_0x5798b0['resolve'](_0x3f87b7);}return _0x3f87b7;}['onInit'](_0x149028,_0x56b8b0){const _0x56ebae=this['normalizeInstanceIdentifier'](_0x56b8b0),_0xcf1a14=this['onInitCallbacks']['get'](_0x56ebae)??new Set();_0xcf1a14['add'](_0x149028),this['onInitCallbacks']['set'](_0x56ebae,_0xcf1a14);const _0x4486df=this['instances']['get'](_0x56ebae);return _0x4486df&&_0x149028(_0x4486df,_0x56ebae),()=>{_0xcf1a14['delete'](_0x149028);};}['invokeOnInitCallbacks'](_0x59e391,_0x242935){const _0x18a360=this['onInitCallbacks']['get'](_0x242935);if(_0x18a360){for(const _0x1ed064 of _0x18a360)try{_0x1ed064(_0x59e391,_0x242935);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x5072ff,options:_0x3b14ee={}}){let _0x3d7357=this['instances']['get'](_0x5072ff);if(!_0x3d7357&&this['component']&&(_0x3d7357=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x5072ff),'options':_0x3b14ee}),this['instances']['set'](_0x5072ff,_0x3d7357),this['instancesOptions']['set'](_0x5072ff,_0x3b14ee),this['invokeOnInitCallbacks'](_0x3d7357,_0x5072ff),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x5072ff,_0x3d7357);}catch{}return _0x3d7357||null;}['normalizeInstanceIdentifier'](_0x3399c0=Ne){return this['component']?this['component']['multipleInstances']?_0x3399c0:Ne:_0x3399c0;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x380161){return _0x380161===Ne?void 0x0:_0x380161;}function Pc(_0x1d65ef){return _0x1d65ef['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x4af2b1){this['name']=_0x4af2b1,this['providers']=new Map();}['addComponent'](_0x4ea509){const _0x49b61e=this['getProvider'](_0x4ea509['name']);if(_0x49b61e['isComponentSet']())throw new Error('Component\x20'+_0x4ea509['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x49b61e['setComponent'](_0x4ea509);}['addOrOverwriteComponent'](_0x5778e2){this['getProvider'](_0x5778e2['name'])['isComponentSet']()&&this['providers']['delete'](_0x5778e2['name']),this['addComponent'](_0x5778e2);}['getProvider'](_0x5107ec){if(this['providers']['has'](_0x5107ec))return this['providers']['get'](_0x5107ec);const _0x22f167=new Ac(_0x5107ec,this);return this['providers']['set'](_0x5107ec,_0x22f167),_0x22f167;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x5e2937){_0x5e2937[_0x5e2937['DEBUG']=0x0]='DEBUG',_0x5e2937[_0x5e2937['VERBOSE']=0x1]='VERBOSE',_0x5e2937[_0x5e2937['INFO']=0x2]='INFO',_0x5e2937[_0x5e2937['WARN']=0x3]='WARN',_0x5e2937[_0x5e2937['ERROR']=0x4]='ERROR',_0x5e2937[_0x5e2937['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x4b1e3d,_0x3d98bb,..._0x5dc7d1)=>{if(_0x3d98bb<_0x4b1e3d['logLevel'])return;const _0x5c9d92=new Date()['toISOString'](),_0x3d0d17=Mc[_0x3d98bb];if(_0x3d0d17)console[_0x3d0d17]('['+_0x5c9d92+']\x20\x20'+_0x4b1e3d['name']+':',..._0x5dc7d1);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x3d98bb+')');};class Bi{constructor(_0x1a1a2a){this['name']=_0x1a1a2a,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0xa8a1ad){if(!(_0xa8a1ad in T))throw new TypeError('Invalid\x20value\x20\x22'+_0xa8a1ad+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0xa8a1ad;}['setLogLevel'](_0xf117ec){this['_logLevel']=typeof _0xf117ec=='string'?Oc[_0xf117ec]:_0xf117ec;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x530aa6){if(typeof _0x530aa6!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x530aa6;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x43b9cd){this['_userLogHandler']=_0x43b9cd;}['debug'](..._0x46c3bf){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x46c3bf),this['_logHandler'](this,T['DEBUG'],..._0x46c3bf);}['log'](..._0x2b86af){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x2b86af),this['_logHandler'](this,T['VERBOSE'],..._0x2b86af);}['info'](..._0x250fab){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x250fab),this['_logHandler'](this,T['INFO'],..._0x250fab);}['warn'](..._0x5e1f21){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x5e1f21),this['_logHandler'](this,T['WARN'],..._0x5e1f21);}['error'](..._0x2051e4){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x2051e4),this['_logHandler'](this,T['ERROR'],..._0x2051e4);}}const xc=(_0x12320c,_0x410f57)=>_0x410f57['some'](_0x491b91=>_0x12320c instanceof _0x491b91);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x4a01b9){const _0x1f7b50=new Promise((_0x3d0001,_0x43e91a)=>{const _0x4f8e4b=()=>{_0x4a01b9['removeEventListener']('success',_0x14e2c6),_0x4a01b9['removeEventListener']('error',_0x253f00);},_0x14e2c6=()=>{_0x3d0001(ge(_0x4a01b9['result'])),_0x4f8e4b();},_0x253f00=()=>{_0x43e91a(_0x4a01b9['error']),_0x4f8e4b();};_0x4a01b9['addEventListener']('success',_0x14e2c6),_0x4a01b9['addEventListener']('error',_0x253f00);});return _0x1f7b50['then'](_0x51146d=>{_0x51146d instanceof IDBCursor&&Jr['set'](_0x51146d,_0x4a01b9);})['catch'](()=>{}),Vi['set'](_0x1f7b50,_0x4a01b9),_0x1f7b50;}function Bc(_0x2ecb91){if(_i['has'](_0x2ecb91))return;const _0x4b6022=new Promise((_0x4c7cb2,_0x5e2af3)=>{const _0x49c3af=()=>{_0x2ecb91['removeEventListener']('complete',_0x41c09d),_0x2ecb91['removeEventListener']('error',_0xa89e2f),_0x2ecb91['removeEventListener']('abort',_0xa89e2f);},_0x41c09d=()=>{_0x4c7cb2(),_0x49c3af();},_0xa89e2f=()=>{_0x5e2af3(_0x2ecb91['error']||new DOMException('AbortError','AbortError')),_0x49c3af();};_0x2ecb91['addEventListener']('complete',_0x41c09d),_0x2ecb91['addEventListener']('error',_0xa89e2f),_0x2ecb91['addEventListener']('abort',_0xa89e2f);});_i['set'](_0x2ecb91,_0x4b6022);}let gi={'get'(_0xf628d4,_0x35aeda,_0x5b28ac){if(_0xf628d4 instanceof IDBTransaction){if(_0x35aeda==='done')return _i['get'](_0xf628d4);if(_0x35aeda==='objectStoreNames')return _0xf628d4['objectStoreNames']||Xr['get'](_0xf628d4);if(_0x35aeda==='store')return _0x5b28ac['objectStoreNames'][0x1]?void 0x0:_0x5b28ac['objectStore'](_0x5b28ac['objectStoreNames'][0x0]);}return ge(_0xf628d4[_0x35aeda]);},'set'(_0x239f7f,_0x3d3999,_0x246940){return _0x239f7f[_0x3d3999]=_0x246940,!0x0;},'has'(_0x5b5fad,_0x407b00){return _0x5b5fad instanceof IDBTransaction&&(_0x407b00==='done'||_0x407b00==='store')?!0x0:_0x407b00 in _0x5b5fad;}};function Vc(_0x537cd3){gi=_0x537cd3(gi);}function Hc(_0x161fc6){return _0x161fc6===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x55870c,..._0x5eba42){const _0x379e4f=_0x161fc6['call'](ii(this),_0x55870c,..._0x5eba42);return Xr['set'](_0x379e4f,_0x55870c['sort']?_0x55870c['sort']():[_0x55870c]),ge(_0x379e4f);}:Uc()['includes'](_0x161fc6)?function(..._0x2b2100){return _0x161fc6['apply'](ii(this),_0x2b2100),ge(Jr['get'](this));}:function(..._0x3c44a1){return ge(_0x161fc6['apply'](ii(this),_0x3c44a1));};}function $c(_0x392e42){return typeof _0x392e42=='function'?Hc(_0x392e42):(_0x392e42 instanceof IDBTransaction&&Bc(_0x392e42),xc(_0x392e42,Fc())?new Proxy(_0x392e42,gi):_0x392e42);}function ge(_0x15a15a){if(_0x15a15a instanceof IDBRequest)return Wc(_0x15a15a);if(ni['has'](_0x15a15a))return ni['get'](_0x15a15a);const _0xb92899=$c(_0x15a15a);return _0xb92899!==_0x15a15a&&(ni['set'](_0x15a15a,_0xb92899),Vi['set'](_0xb92899,_0x15a15a)),_0xb92899;}const ii=_0x5c9ebd=>Vi['get'](_0x5c9ebd);function Gc(_0xbc863d,_0x79e87d,{blocked:_0x4e6f12,upgrade:_0x448636,blocking:_0x6b3e1a,terminated:_0x3c5e8b}={}){const _0x11676a=indexedDB['open'](_0xbc863d,_0x79e87d),_0x297005=ge(_0x11676a);return _0x448636&&_0x11676a['addEventListener']('upgradeneeded',_0xbe77c=>{_0x448636(ge(_0x11676a['result']),_0xbe77c['oldVersion'],_0xbe77c['newVersion'],ge(_0x11676a['transaction']),_0xbe77c);}),_0x4e6f12&&_0x11676a['addEventListener']('blocked',_0x1f8dca=>_0x4e6f12(_0x1f8dca['oldVersion'],_0x1f8dca['newVersion'],_0x1f8dca)),_0x297005['then'](_0x566262=>{_0x3c5e8b&&_0x566262['addEventListener']('close',()=>_0x3c5e8b()),_0x6b3e1a&&_0x566262['addEventListener']('versionchange',_0xaf2e7c=>_0x6b3e1a(_0xaf2e7c['oldVersion'],_0xaf2e7c['newVersion'],_0xaf2e7c));})['catch'](()=>{}),_0x297005;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x7ae29f,_0x5d7ee2){if(!(_0x7ae29f instanceof IDBDatabase&&!(_0x5d7ee2 in _0x7ae29f)&&typeof _0x5d7ee2=='string'))return;if(si['get'](_0x5d7ee2))return si['get'](_0x5d7ee2);const _0x20e04d=_0x5d7ee2['replace'](/FromIndex$/,''),_0x472d2b=_0x5d7ee2!==_0x20e04d,_0x3117cc=zc['includes'](_0x20e04d);if(!(_0x20e04d in(_0x472d2b?IDBIndex:IDBObjectStore)['prototype'])||!(_0x3117cc||qc['includes'](_0x20e04d)))return;const _0x171cbd=async function(_0xb02587,..._0x52a55b){const _0x1bc0cb=this['transaction'](_0xb02587,_0x3117cc?'readwrite':'readonly');let _0x520885=_0x1bc0cb['store'];return _0x472d2b&&(_0x520885=_0x520885['index'](_0x52a55b['shift']())),(await Promise['all']([_0x520885[_0x20e04d](..._0x52a55b),_0x3117cc&&_0x1bc0cb['done']]))[0x0];};return si['set'](_0x5d7ee2,_0x171cbd),_0x171cbd;}Vc(_0x2652fc=>({..._0x2652fc,'get':(_0x3d17d3,_0x540a51,_0x2fd0b9)=>Ms(_0x3d17d3,_0x540a51)||_0x2652fc['get'](_0x3d17d3,_0x540a51,_0x2fd0b9),'has':(_0x5ac796,_0x2df85b)=>!!Ms(_0x5ac796,_0x2df85b)||_0x2652fc['has'](_0x5ac796,_0x2df85b)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x8b81a2){this['container']=_0x8b81a2;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x41a984=>{if(Kc(_0x41a984)){const _0x33893a=_0x41a984['getImmediate']();return _0x33893a['library']+'/'+_0x33893a['version'];}else return null;})['filter'](_0x38bbe1=>_0x38bbe1)['join']('\x20');}}function Kc(_0x2091ed){const _0x4a910f=_0x2091ed['getComponent']();return(_0x4a910f==null?void 0x0:_0x4a910f['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x277158,_0x28c711){try{_0x277158['container']['addComponent'](_0x28c711);}catch(_0x3d0389){oe['debug']('Component\x20'+_0x28c711['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x277158['name'],_0x3d0389);}}function st(_0x29875c){const _0x146c1f=_0x29875c['name'];if(Ei['has'](_0x146c1f))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x146c1f+'.'),!0x1;Ei['set'](_0x146c1f,_0x29875c);for(const _0x2a3e43 of Ue['values']())xs(_0x2a3e43,_0x29875c);for(const _0x3b2e18 of vi['values']())xs(_0x3b2e18,_0x29875c);return!0x0;}function Hi(_0x151b89,_0x44792e){const _0x4a9798=_0x151b89['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x4a9798&&_0x4a9798['triggerHeartbeat'](),_0x151b89['container']['getProvider'](_0x44792e);}function $(_0x2ec1a8){return _0x2ec1a8==null?!0x1:_0x2ec1a8['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x4e462b,_0xe4dcae,_0x495b7a){this['_isDeleted']=!0x1,this['_options']={..._0x4e462b},this['_config']={..._0xe4dcae},this['_name']=_0xe4dcae['name'],this['_automaticDataCollectionEnabled']=_0xe4dcae['automaticDataCollectionEnabled'],this['_container']=_0x495b7a,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x58ca2c){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x58ca2c;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x3039c1){this['_isDeleted']=_0x3039c1;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x1309cf,_0x4dbdfe={}){let _0x26a606=_0x1309cf;typeof _0x4dbdfe!='object'&&(_0x4dbdfe={'name':_0x4dbdfe});const _0x2680a4={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x4dbdfe},_0x334c32=_0x2680a4['name'];if(typeof _0x334c32!='string'||!_0x334c32)throw me['create']('bad-app-name',{'appName':String(_0x334c32)});if(_0x26a606||(_0x26a606=zr()),!_0x26a606)throw me['create']('no-options');const _0x2bdc17=Ue['get'](_0x334c32);if(_0x2bdc17){if(xe(_0x26a606,_0x2bdc17['options'])&&xe(_0x2680a4,_0x2bdc17['config']))return _0x2bdc17;throw me['create']('duplicate-app',{'appName':_0x334c32});}const _0x3d4e7c=new Nc(_0x334c32);for(const _0x40b903 of Ei['values']())_0x3d4e7c['addComponent'](_0x40b903);const _0x27f5b7=new Tl(_0x26a606,_0x2680a4,_0x3d4e7c);return Ue['set'](_0x334c32,_0x27f5b7),_0x27f5b7;}function Zr(_0xe36067=yi){const _0x51b2ee=Ue['get'](_0xe36067);if(!_0x51b2ee&&_0xe36067===yi&&zr())return Sl();if(!_0x51b2ee)throw me['create']('no-app',{'appName':_0xe36067});return _0x51b2ee;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x3ce046){let _0x56f6a0=!0x1;const _0x257fd2=_0x3ce046['name'];Ue['has'](_0x257fd2)?(_0x56f6a0=!0x0,Ue['delete'](_0x257fd2)):vi['has'](_0x257fd2)&&_0x3ce046['decRefCount']()<=0x0&&(vi['delete'](_0x257fd2),_0x56f6a0=!0x0),_0x56f6a0&&(await Promise['all'](_0x3ce046['container']['getProviders']()['map'](_0x112eda=>_0x112eda['delete']())),_0x3ce046['isDeleted']=!0x0);}function ye(_0x18f80e,_0x2c57d1,_0x3a611b){let _0x334db9=wl[_0x18f80e]??_0x18f80e;_0x3a611b&&(_0x334db9+='-'+_0x3a611b);const _0x27db09=_0x334db9['match'](/\s|\//),_0x51d066=_0x2c57d1['match'](/\s|\//);if(_0x27db09||_0x51d066){const _0x49c360=['Unable\x20to\x20register\x20library\x20\x22'+_0x334db9+'\x22\x20with\x20version\x20\x22'+_0x2c57d1+'\x22:'];_0x27db09&&_0x49c360['push']('library\x20name\x20\x22'+_0x334db9+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x27db09&&_0x51d066&&_0x49c360['push']('and'),_0x51d066&&_0x49c360['push']('version\x20name\x20\x22'+_0x2c57d1+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x49c360['join']('\x20'));return;}st(new Fe(_0x334db9+'-version',()=>({'library':_0x334db9,'version':_0x2c57d1}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x589f98,_0x34276e)=>{switch(_0x34276e){case 0x0:try{_0x589f98['createObjectStore'](Ot);}catch(_0x4c461e){console['warn'](_0x4c461e);}}}})['catch'](_0x2ada4e=>{throw me['create']('idb-open',{'originalErrorMessage':_0x2ada4e['message']});})),ri;}async function Al(_0x2a4680){try{const _0x108313=(await eo())['transaction'](Ot),_0x55579b=await _0x108313['objectStore'](Ot)['get'](to(_0x2a4680));return await _0x108313['done'],_0x55579b;}catch(_0x32acb2){if(_0x32acb2 instanceof Re)oe['warn'](_0x32acb2['message']);else{const _0x1d259c=me['create']('idb-get',{'originalErrorMessage':_0x32acb2==null?void 0x0:_0x32acb2['message']});oe['warn'](_0x1d259c['message']);}}}async function Fs(_0x1d7255,_0x6a66a7){try{const _0x19c759=(await eo())['transaction'](Ot,'readwrite');await _0x19c759['objectStore'](Ot)['put'](_0x6a66a7,to(_0x1d7255)),await _0x19c759['done'];}catch(_0x332645){if(_0x332645 instanceof Re)oe['warn'](_0x332645['message']);else{const _0x54fb69=me['create']('idb-set',{'originalErrorMessage':_0x332645==null?void 0x0:_0x332645['message']});oe['warn'](_0x54fb69['message']);}}}function to(_0x45ba92){return _0x45ba92['name']+'!'+_0x45ba92['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x50716d){this['container']=_0x50716d,this['_heartbeatsCache']=null;const _0x3f92f6=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x3f92f6),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x158b2f=>(this['_heartbeatsCache']=_0x158b2f,_0x158b2f));}async['triggerHeartbeat'](){var _0x501e83,_0x68a66e;try{const _0x46b50d=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x18cb59=Us();if(((_0x501e83=this['_heartbeatsCache'])==null?void 0x0:_0x501e83['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x68a66e=this['_heartbeatsCache'])==null?void 0x0:_0x68a66e['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x18cb59||this['_heartbeatsCache']['heartbeats']['some'](_0x4e02d4=>_0x4e02d4['date']===_0x18cb59))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x18cb59,'agent':_0x46b50d}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x4189bf=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x4189bf,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x4b9970){oe['warn'](_0x4b9970);}}async['getHeartbeatsHeader'](){var _0x40a9fa;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x40a9fa=this['_heartbeatsCache'])==null?void 0x0:_0x40a9fa['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x52a758=Us(),{heartbeatsToSend:_0x193232,unsentEntries:_0x159e17}=Ol(this['_heartbeatsCache']['heartbeats']),_0x59572f=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x193232}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x52a758,_0x159e17['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x159e17,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x59572f;}catch(_0x2bff39){return oe['warn'](_0x2bff39),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x1fadf5,_0x7391f=kl){const _0x195c1a=[];let _0x4d7b47=_0x1fadf5['slice']();for(const _0xc498d7 of _0x1fadf5){const _0x9c7a3d=_0x195c1a['find'](_0x209e55=>_0x209e55['agent']===_0xc498d7['agent']);if(_0x9c7a3d){if(_0x9c7a3d['dates']['push'](_0xc498d7['date']),Ws(_0x195c1a)>_0x7391f){_0x9c7a3d['dates']['pop']();break;}}else{if(_0x195c1a['push']({'agent':_0xc498d7['agent'],'dates':[_0xc498d7['date']]}),Ws(_0x195c1a)>_0x7391f){_0x195c1a['pop']();break;}}_0x4d7b47=_0x4d7b47['slice'](0x1);}return{'heartbeatsToSend':_0x195c1a,'unsentEntries':_0x4d7b47};}class Dl{constructor(_0x3722f2){this['app']=_0x3722f2,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0xf6fcd7=await Al(this['app']);return _0xf6fcd7!=null&&_0xf6fcd7['heartbeats']?_0xf6fcd7:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x59a0d6){if(await this['_canUseIndexedDBPromise']){const _0x49b6d2=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x59a0d6['lastSentHeartbeatDate']??_0x49b6d2['lastSentHeartbeatDate'],'heartbeats':_0x59a0d6['heartbeats']});}else return;}async['add'](_0x54424b){if(await this['_canUseIndexedDBPromise']){const _0x10fb1e=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x54424b['lastSentHeartbeatDate']??_0x10fb1e['lastSentHeartbeatDate'],'heartbeats':[..._0x10fb1e['heartbeats'],..._0x54424b['heartbeats']]});}else return;}}function Ws(_0x236a22){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x236a22}))['length'];}function Ml(_0x3febc8){if(_0x3febc8['length']===0x0)return-0x1;let _0x551bfa=0x0,_0x102d6f=_0x3febc8[0x0]['date'];for(let _0x206e3a=0x1;_0x206e3a<_0x3febc8['length'];_0x206e3a++)_0x3febc8[_0x206e3a]['date']<_0x102d6f&&(_0x102d6f=_0x3febc8[_0x206e3a]['date'],_0x551bfa=_0x206e3a);return _0x551bfa;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x9e3473){st(new Fe('platform-logger',_0x4823a0=>new jc(_0x4823a0),'PRIVATE')),st(new Fe('heartbeat',_0x126136=>new Nl(_0x126136),'PRIVATE')),ye(mi,Ls,_0x9e3473),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x1fbc97){no=_0x1fbc97;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x328aa9){this['domStorage_']=_0x328aa9,this['prefix_']='firebase:';}['set'](_0x1df1cc,_0x3bb37a){_0x3bb37a==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x1df1cc)):this['domStorage_']['setItem'](this['prefixedName_'](_0x1df1cc),O(_0x3bb37a));}['get'](_0x5f7127){const _0x5eca86=this['domStorage_']['getItem'](this['prefixedName_'](_0x5f7127));return _0x5eca86==null?null:Nt(_0x5eca86);}['remove'](_0x42aa1c){this['domStorage_']['removeItem'](this['prefixedName_'](_0x42aa1c));}['prefixedName_'](_0x2f71fa){return this['prefix_']+_0x2f71fa;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x47a3f5,_0x31fd5f){_0x31fd5f==null?delete this['cache_'][_0x47a3f5]:this['cache_'][_0x47a3f5]=_0x31fd5f;}['get'](_0x5f0450){return Q(this['cache_'],_0x5f0450)?this['cache_'][_0x5f0450]:null;}['remove'](_0x99b739){delete this['cache_'][_0x99b739];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x144edc){try{if(typeof window<'u'&&typeof window[_0x144edc]<'u'){const _0x5de28b=window[_0x144edc];return _0x5de28b['setItem']('firebase:sentinel','cache'),_0x5de28b['removeItem']('firebase:sentinel'),new Wl(_0x5de28b);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x368075=0x1;return function(){return _0x368075++;};}()),ro=function(_0x40b3db){const _0x565bdf=Rc(_0x40b3db),_0x599dc6=new Cc();_0x599dc6['update'](_0x565bdf);const _0x23970c=_0x599dc6['digest']();return Fi['encodeByteArray'](_0x23970c);},zt=function(..._0x3adc18){let _0x32aedf='';for(let _0x620938=0x0;_0x620938<_0x3adc18['length'];_0x620938++){const _0x482353=_0x3adc18[_0x620938];Array['isArray'](_0x482353)||_0x482353&&typeof _0x482353=='object'&&typeof _0x482353['length']=='number'?_0x32aedf+=zt['apply'](null,_0x482353):typeof _0x482353=='object'?_0x32aedf+=O(_0x482353):_0x32aedf+=_0x482353,_0x32aedf+='\x20';}return _0x32aedf;};let St=null,$s=!0x0;const Hl=function(_0x89df2a,_0x268973){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x4432ca){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x276c4d=zt['apply'](null,_0x4432ca);St(_0x276c4d);}},jt=function(_0x5d3e54){return function(..._0x47082f){L(_0x5d3e54,..._0x47082f);};},Ii=function(..._0x51e820){const _0x4dc91f='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x51e820);Ze['error'](_0x4dc91f);},ae=function(..._0x1328eb){const _0x5a4a82='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x1328eb);throw Ze['error'](_0x5a4a82),new Error(_0x5a4a82);},U=function(..._0x37d4f3){const _0x3d4113='FIREBASE\x20WARNING:\x20'+zt(..._0x37d4f3);Ze['warn'](_0x3d4113);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x18f4d5){return typeof _0x18f4d5=='number'&&(_0x18f4d5!==_0x18f4d5||_0x18f4d5===Number['POSITIVE_INFINITY']||_0x18f4d5===Number['NEGATIVE_INFINITY']);},Gl=function(_0xbfe2ce){if(document['readyState']==='complete')_0xbfe2ce();else{let _0x34ff87=!0x1;const _0x202336=function(){if(!document['body']){setTimeout(_0x202336,Math['floor'](0xa));return;}_0x34ff87||(_0x34ff87=!0x0,_0xbfe2ce());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x202336,!0x1),window['addEventListener']('load',_0x202336,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x202336();}),window['attachEvent']('onload',_0x202336));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x14d011,_0x1d9c9a){if(_0x14d011===_0x1d9c9a)return 0x0;if(_0x14d011===We||_0x1d9c9a===we)return-0x1;if(_0x1d9c9a===We||_0x14d011===we)return 0x1;{const _0x507549=Gs(_0x14d011),_0x317a4e=Gs(_0x1d9c9a);return _0x507549!==null?_0x317a4e!==null?_0x507549-_0x317a4e===0x0?_0x14d011['length']-_0x1d9c9a['length']:_0x507549-_0x317a4e:-0x1:_0x317a4e!==null?0x1:_0x14d011<_0x1d9c9a?-0x1:0x1;}},ql=function(_0x368d89,_0x197fca){return _0x368d89===_0x197fca?0x0:_0x368d89<_0x197fca?-0x1:0x1;},vt=function(_0x19a242,_0xe94f3a){if(_0xe94f3a&&_0x19a242 in _0xe94f3a)return _0xe94f3a[_0x19a242];throw new Error('Missing\x20required\x20key\x20('+_0x19a242+')\x20in\x20object:\x20'+O(_0xe94f3a));},$i=function(_0x4118ac){if(typeof _0x4118ac!='object'||_0x4118ac===null)return O(_0x4118ac);const _0x382e79=[];for(const _0x3cb6b4 in _0x4118ac)_0x382e79['push'](_0x3cb6b4);_0x382e79['sort']();let _0x55a2b9='{';for(let _0x4e6fce=0x0;_0x4e6fce<_0x382e79['length'];_0x4e6fce++)_0x4e6fce!==0x0&&(_0x55a2b9+=','),_0x55a2b9+=O(_0x382e79[_0x4e6fce]),_0x55a2b9+=':',_0x55a2b9+=$i(_0x4118ac[_0x382e79[_0x4e6fce]]);return _0x55a2b9+='}',_0x55a2b9;},oo=function(_0x2e9a02,_0x3dbe1f){const _0x1f84ec=_0x2e9a02['length'];if(_0x1f84ec<=_0x3dbe1f)return[_0x2e9a02];const _0x42c011=[];for(let _0x36bc26=0x0;_0x36bc26<_0x1f84ec;_0x36bc26+=_0x3dbe1f)_0x36bc26+_0x3dbe1f>_0x1f84ec?_0x42c011['push'](_0x2e9a02['substring'](_0x36bc26,_0x1f84ec)):_0x42c011['push'](_0x2e9a02['substring'](_0x36bc26,_0x36bc26+_0x3dbe1f));return _0x42c011;};function x(_0x1cb0bf,_0xef6716){for(const _0xd63b11 in _0x1cb0bf)_0x1cb0bf['hasOwnProperty'](_0xd63b11)&&_0xef6716(_0xd63b11,_0x1cb0bf[_0xd63b11]);}const ao=function(_0x33b73a){f(!xn(_0x33b73a),'Invalid\x20JSON\x20number');const _0x28bdb2=0xb,_0x56a23b=0x34,_0x195635=(0x1<<_0x28bdb2-0x1)-0x1;let _0x73f721,_0x376369,_0x452254,_0x18c285,_0x20bcab;_0x33b73a===0x0?(_0x376369=0x0,_0x452254=0x0,_0x73f721=0x1/_0x33b73a===-0x1/0x0?0x1:0x0):(_0x73f721=_0x33b73a<0x0,_0x33b73a=Math['abs'](_0x33b73a),_0x33b73a>=Math['pow'](0x2,0x1-_0x195635)?(_0x18c285=Math['min'](Math['floor'](Math['log'](_0x33b73a)/Math['LN2']),_0x195635),_0x376369=_0x18c285+_0x195635,_0x452254=Math['round'](_0x33b73a*Math['pow'](0x2,_0x56a23b-_0x18c285)-Math['pow'](0x2,_0x56a23b))):(_0x376369=0x0,_0x452254=Math['round'](_0x33b73a/Math['pow'](0x2,0x1-_0x195635-_0x56a23b))));const _0x3fd30d=[];for(_0x20bcab=_0x56a23b;_0x20bcab;_0x20bcab-=0x1)_0x3fd30d['push'](_0x452254%0x2?0x1:0x0),_0x452254=Math['floor'](_0x452254/0x2);for(_0x20bcab=_0x28bdb2;_0x20bcab;_0x20bcab-=0x1)_0x3fd30d['push'](_0x376369%0x2?0x1:0x0),_0x376369=Math['floor'](_0x376369/0x2);_0x3fd30d['push'](_0x73f721?0x1:0x0),_0x3fd30d['reverse']();const _0x549db1=_0x3fd30d['join']('');let _0x39d258='';for(_0x20bcab=0x0;_0x20bcab<0x40;_0x20bcab+=0x8){let _0x26cf47=parseInt(_0x549db1['substr'](_0x20bcab,0x8),0x2)['toString'](0x10);_0x26cf47['length']===0x1&&(_0x26cf47='0'+_0x26cf47),_0x39d258=_0x39d258+_0x26cf47;}return _0x39d258['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x30fd9a,_0x2b6e4c){let _0x20de35='Unknown\x20Error';_0x30fd9a==='too_big'?_0x20de35='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x30fd9a==='permission_denied'?_0x20de35='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x30fd9a==='unavailable'&&(_0x20de35='The\x20service\x20is\x20unavailable');const _0x1605df=new Error(_0x30fd9a+'\x20at\x20'+_0x2b6e4c['_path']['toString']()+':\x20'+_0x20de35);return _0x1605df['code']=_0x30fd9a['toUpperCase'](),_0x1605df;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x59200e){if(Yl['test'](_0x59200e)){const _0x213a21=Number(_0x59200e);if(_0x213a21>=Ql&&_0x213a21<=Jl)return _0x213a21;}return null;},ft=function(_0x1b5070){try{_0x1b5070();}catch(_0x4bfc41){setTimeout(()=>{const _0x1cda2a=_0x4bfc41['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x1cda2a),_0x4bfc41;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x195d38,_0x36da51){const _0x33e96c=setTimeout(_0x195d38,_0x36da51);return typeof _0x33e96c=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x33e96c):typeof _0x33e96c=='object'&&_0x33e96c['unref']&&_0x33e96c['unref'](),_0x33e96c;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x348a90,_0x1dfa00){this['appCheckProvider']=_0x1dfa00,this['appName']=_0x348a90['name'],$(_0x348a90)&&_0x348a90['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x348a90['settings']['appCheckToken']),this['appCheck']=_0x1dfa00==null?void 0x0:_0x1dfa00['getImmediate']({'optional':!0x0}),this['appCheck']||_0x1dfa00==null||_0x1dfa00['get']()['then'](_0x57e7b3=>this['appCheck']=_0x57e7b3);}['getToken'](_0x47d770){if(this['serverAppAppCheckToken']){if(_0x47d770)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x47d770):new Promise((_0x1c669c,_0x588ba7)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x47d770)['then'](_0x1c669c,_0x588ba7):_0x1c669c(null);},0x0);});}['addTokenChangeListener'](_0xb710ba){var _0x14a742;(_0x14a742=this['appCheckProvider'])==null||_0x14a742['get']()['then'](_0x4c6772=>_0x4c6772['addTokenListener'](_0xb710ba));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x34da71,_0x17e4de,_0x4af8d9){this['appName_']=_0x34da71,this['firebaseOptions_']=_0x17e4de,this['authProvider_']=_0x4af8d9,this['auth_']=null,this['auth_']=_0x4af8d9['getImmediate']({'optional':!0x0}),this['auth_']||_0x4af8d9['onInit'](_0x2ae561=>this['auth_']=_0x2ae561);}['getToken'](_0x3711c1){return this['auth_']?this['auth_']['getToken'](_0x3711c1)['catch'](_0x31ff28=>_0x31ff28&&_0x31ff28['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x31ff28)):new Promise((_0x310ada,_0x4226db)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x3711c1)['then'](_0x310ada,_0x4226db):_0x310ada(null);},0x0);});}['addTokenChangeListener'](_0x5d95fe){this['auth_']?this['auth_']['addAuthTokenListener'](_0x5d95fe):this['authProvider_']['get']()['then'](_0x3c93ba=>_0x3c93ba['addAuthTokenListener'](_0x5d95fe));}['removeTokenChangeListener'](_0x1c4c3d){this['authProvider_']['get']()['then'](_0x434c7c=>_0x434c7c['removeAuthTokenListener'](_0x1c4c3d));}['notifyForInvalidToken'](){let _0x58d401='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x58d401+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x58d401+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x58d401+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x58d401);}}class an{constructor(_0x419085){this['accessToken']=_0x419085;}['getToken'](_0x5ec9c2){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x4c6b91){_0x4c6b91(this['accessToken']);}['removeTokenChangeListener'](_0x5debe6){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x51f468,_0x360ac9,_0x501171,_0x5c9118,_0x48f888=!0x1,_0x4e82ea='',_0x40117a=!0x1,_0x2620d6=!0x1,_0x371821=null){this['secure']=_0x360ac9,this['namespace']=_0x501171,this['webSocketOnly']=_0x5c9118,this['nodeAdmin']=_0x48f888,this['persistenceKey']=_0x4e82ea,this['includeNamespaceInQueryParams']=_0x40117a,this['isUsingEmulator']=_0x2620d6,this['emulatorOptions']=_0x371821,this['_host']=_0x51f468['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x51f468)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x182052){_0x182052!==this['internalHost']&&(this['internalHost']=_0x182052,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x1cbd14=this['toURLString']();return this['persistenceKey']&&(_0x1cbd14+='<'+this['persistenceKey']+'>'),_0x1cbd14;}['toURLString'](){const _0x4c373f=this['secure']?'https://':'http://',_0x1a5242=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x4c373f+this['host']+'/'+_0x1a5242;}}function th(_0x37a883){return _0x37a883['host']!==_0x37a883['internalHost']||_0x37a883['isCustomHost']()||_0x37a883['includeNamespaceInQueryParams'];}function vo(_0x2015ca,_0x4e1102,_0x31cd25){f(typeof _0x4e1102=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x31cd25=='object','typeof\x20params\x20must\x20==\x20object');let _0x5aed4f;if(_0x4e1102===go)_0x5aed4f=(_0x2015ca['secure']?'wss://':'ws://')+_0x2015ca['internalHost']+'/.ws?';else{if(_0x4e1102===mo)_0x5aed4f=(_0x2015ca['secure']?'https://':'http://')+_0x2015ca['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x4e1102);}th(_0x2015ca)&&(_0x31cd25['ns']=_0x2015ca['namespace']);const _0x3952a5=[];return x(_0x31cd25,(_0xf2f0f6,_0x4d4a64)=>{_0x3952a5['push'](_0xf2f0f6+'='+_0x4d4a64);}),_0x5aed4f+_0x3952a5['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x222e0e,_0x4995ab=0x1){Q(this['counters_'],_0x222e0e)||(this['counters_'][_0x222e0e]=0x0),this['counters_'][_0x222e0e]+=_0x4995ab;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x4975f9){const _0x28087b=_0x4975f9['toString']();return oi[_0x28087b]||(oi[_0x28087b]=new nh()),oi[_0x28087b];}function ih(_0x2f496a,_0x386b8b){const _0x4f6299=_0x2f496a['toString']();return ai[_0x4f6299]||(ai[_0x4f6299]=_0x386b8b()),ai[_0x4f6299];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x361cb1){this['onMessage_']=_0x361cb1,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x366642,_0x2a0807){this['closeAfterResponse']=_0x366642,this['onClose']=_0x2a0807,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x4fd9ec,_0xfd8abc){for(this['pendingResponses'][_0x4fd9ec]=_0xfd8abc;this['pendingResponses'][this['currentResponseNum']];){const _0x3f4ca2=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x161c68=0x0;_0x161c68<_0x3f4ca2['length'];++_0x161c68)_0x3f4ca2[_0x161c68]&&ft(()=>{this['onMessage_'](_0x3f4ca2[_0x161c68]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x345951,_0x1a0dc4,_0x23526e,_0x14799c,_0x4959b2,_0x5200a7,_0x4c7326){this['connId']=_0x345951,this['repoInfo']=_0x1a0dc4,this['applicationId']=_0x23526e,this['appCheckToken']=_0x14799c,this['authToken']=_0x4959b2,this['transportSessionId']=_0x5200a7,this['lastSessionId']=_0x4c7326,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x345951),this['stats_']=qi(_0x1a0dc4),this['urlFn']=_0x110d48=>(this['appCheckToken']&&(_0x110d48[wi]=this['appCheckToken']),vo(_0x1a0dc4,mo,_0x110d48));}['open'](_0x400adf,_0x5b39fd){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x5b39fd,this['myPacketOrderer']=new sh(_0x400adf),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x264f73)=>{const [_0x480f06,_0x2f109a,_0x1692d1,_0x35de10,_0xaeb4b2]=_0x264f73;if(this['incrementIncomingBytes_'](_0x264f73),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x480f06===qs)this['id']=_0x2f109a,this['password']=_0x1692d1;else{if(_0x480f06===rh)_0x2f109a?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x2f109a,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x480f06);}}},(..._0x5cd110)=>{const [_0x309119,_0x2af7c9]=_0x5cd110;this['incrementIncomingBytes_'](_0x5cd110),this['myPacketOrderer']['handleResponse'](_0x309119,_0x2af7c9);},()=>{this['onClosed_']();},this['urlFn']);const _0x555393={};_0x555393[qs]='t',_0x555393[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x555393[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x555393[co]=Gi,this['transportSessionId']&&(_0x555393[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x555393[po]=this['lastSessionId']),this['applicationId']&&(_0x555393[_o]=this['applicationId']),this['appCheckToken']&&(_0x555393[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x555393[ho]=uo);const _0x270d1f=this['urlFn'](_0x555393);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x270d1f),this['scriptTagHolder']['addTag'](_0x270d1f,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0xab9876){const _0x1d19bc=O(_0xab9876);this['bytesSent']+=_0x1d19bc['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1d19bc['length']);const _0x5ca430=$r(_0x1d19bc),_0x5519ae=oo(_0x5ca430,fh);for(let _0x51443d=0x0;_0x51443d<_0x5519ae['length'];_0x51443d++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x5519ae['length'],_0x5519ae[_0x51443d]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x583209,_0x2a3532){this['myDisconnFrame']=document['createElement']('iframe');const _0x36f8d1={};_0x36f8d1[dh]='t',_0x36f8d1[Eo]=_0x583209,_0x36f8d1[Io]=_0x2a3532,this['myDisconnFrame']['src']=this['urlFn'](_0x36f8d1),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x3e2b9f){const _0x4d12eb=O(_0x3e2b9f)['length'];this['bytesReceived']+=_0x4d12eb,this['stats_']['incrementCounter']('bytes_received',_0x4d12eb);}}class zi{constructor(_0x1218fc,_0x288741,_0x2179e0,_0x39be83){this['onDisconnect']=_0x2179e0,this['urlFn']=_0x39be83,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x1218fc,window[ah+this['uniqueCallbackIdentifier']]=_0x288741,this['myIFrame']=zi['createIFrame_']();let _0x1db7ff='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x1db7ff='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x15bff5='<html><body>'+_0x1db7ff+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x15bff5),this['myIFrame']['doc']['close']();}catch(_0x5e2032){L('frame\x20writing\x20exception'),_0x5e2032['stack']&&L(_0x5e2032['stack']),L(_0x5e2032);}}}static['createIFrame_'](){const _0x4d2103=document['createElement']('iframe');if(_0x4d2103['style']['display']='none',document['body']){document['body']['appendChild'](_0x4d2103);try{_0x4d2103['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x13cc36=document['domain'];_0x4d2103['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x13cc36+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x4d2103['contentDocument']?_0x4d2103['doc']=_0x4d2103['contentDocument']:_0x4d2103['contentWindow']?_0x4d2103['doc']=_0x4d2103['contentWindow']['document']:_0x4d2103['document']&&(_0x4d2103['doc']=_0x4d2103['document']),_0x4d2103;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x53c14b=this['onDisconnect'];_0x53c14b&&(this['onDisconnect']=null,_0x53c14b());}['startLongPoll'](_0x4152f4,_0x1e0c6b){for(this['myID']=_0x4152f4,this['myPW']=_0x1e0c6b,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x57845b={};_0x57845b[Eo]=this['myID'],_0x57845b[Io]=this['myPW'],_0x57845b[wo]=this['currentSerial'];let _0x206432=this['urlFn'](_0x57845b),_0x2b0dfa='',_0x494dbf=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x2b0dfa['length']<=Co;){const _0xdfb5cb=this['pendingSegs']['shift']();_0x2b0dfa=_0x2b0dfa+'&'+lh+_0x494dbf+'='+_0xdfb5cb['seg']+'&'+hh+_0x494dbf+'='+_0xdfb5cb['ts']+'&'+uh+_0x494dbf+'='+_0xdfb5cb['d'],_0x494dbf++;}return _0x206432=_0x206432+_0x2b0dfa,this['addLongPollTag_'](_0x206432,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x2fb7bb,_0x6b2f28,_0x373577){this['pendingSegs']['push']({'seg':_0x2fb7bb,'ts':_0x6b2f28,'d':_0x373577}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x58b800,_0x991b7f){this['outstandingRequests']['add'](_0x991b7f);const _0x3e5b52=()=>{this['outstandingRequests']['delete'](_0x991b7f),this['newRequest_']();},_0x5a1b28=setTimeout(_0x3e5b52,Math['floor'](ph)),_0x396e16=()=>{clearTimeout(_0x5a1b28),_0x3e5b52();};this['addTag'](_0x58b800,_0x396e16);}['addTag'](_0x5a82fb,_0x1b3c35){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x4d1109=this['myIFrame']['doc']['createElement']('script');_0x4d1109['type']='text/javascript',_0x4d1109['async']=!0x0,_0x4d1109['src']=_0x5a82fb,_0x4d1109['onload']=_0x4d1109['onreadystatechange']=function(){const _0x57bc30=_0x4d1109['readyState'];(!_0x57bc30||_0x57bc30==='loaded'||_0x57bc30==='complete')&&(_0x4d1109['onload']=_0x4d1109['onreadystatechange']=null,_0x4d1109['parentNode']&&_0x4d1109['parentNode']['removeChild'](_0x4d1109),_0x1b3c35());},_0x4d1109['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x5a82fb),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x4d1109);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x3adf42,_0x37c4e2,_0x41b350,_0x24f4e7,_0x5503c5,_0x5e624f,_0x1c4b86){this['connId']=_0x3adf42,this['applicationId']=_0x41b350,this['appCheckToken']=_0x24f4e7,this['authToken']=_0x5503c5,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x37c4e2),this['connURL']=q['connectionURL_'](_0x37c4e2,_0x5e624f,_0x1c4b86,_0x24f4e7,_0x41b350),this['nodeAdmin']=_0x37c4e2['nodeAdmin'];}static['connectionURL_'](_0x125437,_0x5c92c5,_0x788e32,_0x202463,_0x55738f){const _0xf54007={};return _0xf54007[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0xf54007[ho]=uo),_0x5c92c5&&(_0xf54007[lo]=_0x5c92c5),_0x788e32&&(_0xf54007[po]=_0x788e32),_0x202463&&(_0xf54007[wi]=_0x202463),_0x55738f&&(_0xf54007[_o]=_0x55738f),vo(_0x125437,go,_0xf54007);}['open'](_0xe9ff5,_0xb2c92d){this['onDisconnect']=_0xb2c92d,this['onMessage']=_0xe9ff5,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x1e1e4c;_c(),this['mySock']=new gn(this['connURL'],[],_0x1e1e4c);}catch(_0x595df3){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x5bb170=_0x595df3['message']||_0x595df3['data'];_0x5bb170&&this['log_'](_0x5bb170),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x448701=>{this['handleIncomingFrame'](_0x448701);},this['mySock']['onerror']=_0x3a414b=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x3cfe5a=_0x3a414b['message']||_0x3a414b['data'];_0x3cfe5a&&this['log_'](_0x3cfe5a),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x2df88e=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x3dbd1d=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x11b990=navigator['userAgent']['match'](_0x3dbd1d);_0x11b990&&_0x11b990['length']>0x1&&parseFloat(_0x11b990[0x1])<4.4&&(_0x2df88e=!0x0);}return!_0x2df88e&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x54ab57){if(this['frames']['push'](_0x54ab57),this['frames']['length']===this['totalFrames']){const _0x493f2b=this['frames']['join']('');this['frames']=null;const _0x4295a0=Nt(_0x493f2b);this['onMessage'](_0x4295a0);}}['handleNewFrameCount_'](_0x56bfeb){this['totalFrames']=_0x56bfeb,this['frames']=[];}['extractFrameCount_'](_0x9fedc8){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x9fedc8['length']<=0x6){const _0x5cda86=Number(_0x9fedc8);if(!isNaN(_0x5cda86))return this['handleNewFrameCount_'](_0x5cda86),null;}return this['handleNewFrameCount_'](0x1),_0x9fedc8;}['handleIncomingFrame'](_0x2e76d5){if(this['mySock']===null)return;const _0x3f1556=_0x2e76d5['data'];if(this['bytesReceived']+=_0x3f1556['length'],this['stats_']['incrementCounter']('bytes_received',_0x3f1556['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x3f1556);else{const _0x1c72c2=this['extractFrameCount_'](_0x3f1556);_0x1c72c2!==null&&this['appendFrame_'](_0x1c72c2);}}['send'](_0x50809d){this['resetKeepAlive']();const _0xbc5ec6=O(_0x50809d);this['bytesSent']+=_0xbc5ec6['length'],this['stats_']['incrementCounter']('bytes_sent',_0xbc5ec6['length']);const _0x244c53=oo(_0xbc5ec6,gh);_0x244c53['length']>0x1&&this['sendString_'](String(_0x244c53['length']));for(let _0x4e1c49=0x0;_0x4e1c49<_0x244c53['length'];_0x4e1c49++)this['sendString_'](_0x244c53[_0x4e1c49]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x47f5d7){try{this['mySock']['send'](_0x47f5d7);}catch(_0x2e3cd1){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x2e3cd1['message']||_0x2e3cd1['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5c4997){this['initTransports_'](_0x5c4997);}['initTransports_'](_0x3ab923){const _0xb80622=q&&q['isAvailable']();let _0x540adb=_0xb80622&&!q['previouslyFailed']();if(_0x3ab923['webSocketOnly']&&(_0xb80622||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x540adb=!0x0),_0x540adb)this['transports_']=[q];else{const _0x17c9f2=this['transports_']=[];for(const _0x5c04c0 of Dt['ALL_TRANSPORTS'])_0x5c04c0&&_0x5c04c0['isAvailable']()&&_0x17c9f2['push'](_0x5c04c0);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x467616,_0x4c4759,_0x420153,_0x5016ba,_0x2595da,_0x428975,_0x45d02a,_0x27b7ff,_0x4d5353,_0x28a25e){this['id']=_0x467616,this['repoInfo_']=_0x4c4759,this['applicationId_']=_0x420153,this['appCheckToken_']=_0x5016ba,this['authToken_']=_0x2595da,this['onMessage_']=_0x428975,this['onReady_']=_0x45d02a,this['onDisconnect_']=_0x27b7ff,this['onKill_']=_0x4d5353,this['lastSessionId']=_0x28a25e,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x4c4759),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x8a0d1d=this['transportManager_']['initialTransport']();this['conn_']=new _0x8a0d1d(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x8a0d1d['responsesRequiredToBeHealthy']||0x0;const _0x7ee5c9=this['connReceiver_'](this['conn_']),_0x2152ba=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x7ee5c9,_0x2152ba);},Math['floor'](0x0));const _0x35eade=_0x8a0d1d['healthyTimeout']||0x0;_0x35eade>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x35eade)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x2669a5){return _0x2129ef=>{_0x2669a5===this['conn_']?this['onConnectionLost_'](_0x2129ef):_0x2669a5===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x508214){return _0x1db1f2=>{this['state_']!==0x2&&(_0x508214===this['rx_']?this['onPrimaryMessageReceived_'](_0x1db1f2):_0x508214===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x1db1f2):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x16fea0){const _0x4b6d53={'t':'d','d':_0x16fea0};this['sendData_'](_0x4b6d53);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x305cb8){if(ci in _0x305cb8){const _0x27d987=_0x305cb8[ci];_0x27d987===Ys?this['upgradeIfSecondaryHealthy_']():_0x27d987===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x27d987===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x41d06a){const _0x1720b1=vt('t',_0x41d06a),_0x4a85dc=vt('d',_0x41d06a);if(_0x1720b1==='c')this['onSecondaryControl_'](_0x4a85dc);else{if(_0x1720b1==='d')this['pendingDataMessages']['push'](_0x4a85dc);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x1720b1);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x4a56a8){const _0x1486de=vt('t',_0x4a56a8),_0x318911=vt('d',_0x4a56a8);_0x1486de==='c'?this['onControl_'](_0x318911):_0x1486de==='d'&&this['onDataMessage_'](_0x318911);}['onDataMessage_'](_0x441f58){this['onPrimaryResponse_'](),this['onMessage_'](_0x441f58);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x2be0b7){const _0xe70fb4=vt(ci,_0x2be0b7);if(zs in _0x2be0b7){const _0x204eee=_0x2be0b7[zs];if(_0xe70fb4===Th){const _0x46f548={..._0x204eee};this['repoInfo_']['isUsingEmulator']&&(_0x46f548['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x46f548);}else{if(_0xe70fb4===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x247f9b=0x0;_0x247f9b<this['pendingDataMessages']['length'];++_0x247f9b)this['onDataMessage_'](this['pendingDataMessages'][_0x247f9b]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0xe70fb4===wh?this['onConnectionShutdown_'](_0x204eee):_0xe70fb4===js?this['onReset_'](_0x204eee):_0xe70fb4===Ch?Ii('Server\x20Error:\x20'+_0x204eee):_0xe70fb4===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0xe70fb4);}}}['onHandshake_'](_0x51c2f5){const _0x102cb9=_0x51c2f5['ts'],_0x105ab5=_0x51c2f5['v'],_0x17d02e=_0x51c2f5['h'];this['sessionId']=_0x51c2f5['s'],this['repoInfo_']['host']=_0x17d02e,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x102cb9),Gi!==_0x105ab5&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x53237d=this['transportManager_']['upgradeTransport']();_0x53237d&&this['startUpgrade_'](_0x53237d);}['startUpgrade_'](_0x16291d){this['secondaryConn_']=new _0x16291d(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x16291d['responsesRequiredToBeHealthy']||0x0;const _0x5379f0=this['connReceiver_'](this['secondaryConn_']),_0x92a5c=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x5379f0,_0x92a5c),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x55f387){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x55f387),this['repoInfo_']['host']=_0x55f387,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x5e5385,_0x53472){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x5e5385,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x53472,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x4273c4=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x4273c4||this['rx_']===_0x4273c4)&&this['close']();}['onConnectionLost_'](_0x220041){this['conn_']=null,!_0x220041&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x168157){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x168157),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x5a864c){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x5a864c);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x225bdf,_0x383fdc,_0x4c20aa,_0x1b686e){}['merge'](_0x37a1cd,_0xc289c3,_0x5b4d65,_0x57fef8){}['refreshAuthToken'](_0x151c54){}['refreshAppCheckToken'](_0x15bec9){}['onDisconnectPut'](_0x4cf0e3,_0x1108aa,_0x250979){}['onDisconnectMerge'](_0x453aaf,_0x688365,_0x3101ed){}['onDisconnectCancel'](_0x48bc2b,_0xdf2247){}['reportStats'](_0x44d624){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x2c403c){this['allowedEvents_']=_0x2c403c,this['listeners_']={},f(Array['isArray'](_0x2c403c)&&_0x2c403c['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x5104bc,..._0x288d43){if(Array['isArray'](this['listeners_'][_0x5104bc])){const _0x2df7d3=[...this['listeners_'][_0x5104bc]];for(let _0x208212=0x0;_0x208212<_0x2df7d3['length'];_0x208212++)_0x2df7d3[_0x208212]['callback']['apply'](_0x2df7d3[_0x208212]['context'],_0x288d43);}}['on'](_0x6849db,_0x2f8c8a,_0x156a8e){this['validateEventType_'](_0x6849db),this['listeners_'][_0x6849db]=this['listeners_'][_0x6849db]||[],this['listeners_'][_0x6849db]['push']({'callback':_0x2f8c8a,'context':_0x156a8e});const _0x3e8bb7=this['getInitialEvent'](_0x6849db);_0x3e8bb7&&_0x2f8c8a['apply'](_0x156a8e,_0x3e8bb7);}['off'](_0x2dd93b,_0x784e59,_0x72fd50){this['validateEventType_'](_0x2dd93b);const _0x18ed96=this['listeners_'][_0x2dd93b]||[];for(let _0x23e313=0x0;_0x23e313<_0x18ed96['length'];_0x23e313++)if(_0x18ed96[_0x23e313]['callback']===_0x784e59&&(!_0x72fd50||_0x72fd50===_0x18ed96[_0x23e313]['context'])){_0x18ed96['splice'](_0x23e313,0x1);return;}}['validateEventType_'](_0x1254ed){f(this['allowedEvents_']['find'](_0x44068f=>_0x44068f===_0x1254ed),'Unknown\x20event:\x20'+_0x1254ed);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x33a9b1){return f(_0x33a9b1==='online','Unknown\x20event\x20type:\x20'+_0x33a9b1),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x15a821,_0x5da6e6){if(_0x5da6e6===void 0x0){this['pieces_']=_0x15a821['split']('/');let _0x435af2=0x0;for(let _0x5bd8c0=0x0;_0x5bd8c0<this['pieces_']['length'];_0x5bd8c0++)this['pieces_'][_0x5bd8c0]['length']>0x0&&(this['pieces_'][_0x435af2]=this['pieces_'][_0x5bd8c0],_0x435af2++);this['pieces_']['length']=_0x435af2,this['pieceNum_']=0x0;}else this['pieces_']=_0x15a821,this['pieceNum_']=_0x5da6e6;}['toString'](){let _0x50ea15='';for(let _0x56b0c3=this['pieceNum_'];_0x56b0c3<this['pieces_']['length'];_0x56b0c3++)this['pieces_'][_0x56b0c3]!==''&&(_0x50ea15+='/'+this['pieces_'][_0x56b0c3]);return _0x50ea15||'/';}}function w(){return new C('');}function y(_0x24e61c){return _0x24e61c['pieceNum_']>=_0x24e61c['pieces_']['length']?null:_0x24e61c['pieces_'][_0x24e61c['pieceNum_']];}function Ce(_0x6de031){return _0x6de031['pieces_']['length']-_0x6de031['pieceNum_'];}function S(_0x26742a){let _0x53653f=_0x26742a['pieceNum_'];return _0x53653f<_0x26742a['pieces_']['length']&&_0x53653f++,new C(_0x26742a['pieces_'],_0x53653f);}function ji(_0x2d8053){return _0x2d8053['pieceNum_']<_0x2d8053['pieces_']['length']?_0x2d8053['pieces_'][_0x2d8053['pieces_']['length']-0x1]:null;}function bh(_0x29e790){let _0x5ccb9a='';for(let _0x577655=_0x29e790['pieceNum_'];_0x577655<_0x29e790['pieces_']['length'];_0x577655++)_0x29e790['pieces_'][_0x577655]!==''&&(_0x5ccb9a+='/'+encodeURIComponent(String(_0x29e790['pieces_'][_0x577655])));return _0x5ccb9a||'/';}function Mt(_0x98afc3,_0x42901e=0x0){return _0x98afc3['pieces_']['slice'](_0x98afc3['pieceNum_']+_0x42901e);}function Ro(_0x4df1db){if(_0x4df1db['pieceNum_']>=_0x4df1db['pieces_']['length'])return null;const _0x56e008=[];for(let _0x22794b=_0x4df1db['pieceNum_'];_0x22794b<_0x4df1db['pieces_']['length']-0x1;_0x22794b++)_0x56e008['push'](_0x4df1db['pieces_'][_0x22794b]);return new C(_0x56e008,0x0);}function k(_0x26b8e4,_0x2f6fa1){const _0x1942fd=[];for(let _0x141864=_0x26b8e4['pieceNum_'];_0x141864<_0x26b8e4['pieces_']['length'];_0x141864++)_0x1942fd['push'](_0x26b8e4['pieces_'][_0x141864]);if(_0x2f6fa1 instanceof C){for(let _0x4f6dd7=_0x2f6fa1['pieceNum_'];_0x4f6dd7<_0x2f6fa1['pieces_']['length'];_0x4f6dd7++)_0x1942fd['push'](_0x2f6fa1['pieces_'][_0x4f6dd7]);}else{const _0x265f04=_0x2f6fa1['split']('/');for(let _0x222760=0x0;_0x222760<_0x265f04['length'];_0x222760++)_0x265f04[_0x222760]['length']>0x0&&_0x1942fd['push'](_0x265f04[_0x222760]);}return new C(_0x1942fd,0x0);}function v(_0x2f34a9){return _0x2f34a9['pieceNum_']>=_0x2f34a9['pieces_']['length'];}function F(_0x2a3390,_0x321d72){const _0x41d78b=y(_0x2a3390),_0x53293c=y(_0x321d72);if(_0x41d78b===null)return _0x321d72;if(_0x41d78b===_0x53293c)return F(S(_0x2a3390),S(_0x321d72));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x321d72+')\x20is\x20not\x20within\x20outerPath\x20('+_0x2a3390+')');}function Rh(_0x4dc0cf,_0x12b895){const _0x2f1a61=Mt(_0x4dc0cf,0x0),_0x32bede=Mt(_0x12b895,0x0);for(let _0x31c47e=0x0;_0x31c47e<_0x2f1a61['length']&&_0x31c47e<_0x32bede['length'];_0x31c47e++){const _0x1f0ede=qe(_0x2f1a61[_0x31c47e],_0x32bede[_0x31c47e]);if(_0x1f0ede!==0x0)return _0x1f0ede;}return _0x2f1a61['length']===_0x32bede['length']?0x0:_0x2f1a61['length']<_0x32bede['length']?-0x1:0x1;}function Ki(_0x49fdbb,_0x1dd788){if(Ce(_0x49fdbb)!==Ce(_0x1dd788))return!0x1;for(let _0x290a40=_0x49fdbb['pieceNum_'],_0x2a74b6=_0x1dd788['pieceNum_'];_0x290a40<=_0x49fdbb['pieces_']['length'];_0x290a40++,_0x2a74b6++)if(_0x49fdbb['pieces_'][_0x290a40]!==_0x1dd788['pieces_'][_0x2a74b6])return!0x1;return!0x0;}function G(_0x48bf47,_0x43d81d){let _0x5af410=_0x48bf47['pieceNum_'],_0x192b11=_0x43d81d['pieceNum_'];if(Ce(_0x48bf47)>Ce(_0x43d81d))return!0x1;for(;_0x5af410<_0x48bf47['pieces_']['length'];){if(_0x48bf47['pieces_'][_0x5af410]!==_0x43d81d['pieces_'][_0x192b11])return!0x1;++_0x5af410,++_0x192b11;}return!0x0;}class Ah{constructor(_0x1dbb34,_0x11995c){this['errorPrefix_']=_0x11995c,this['parts_']=Mt(_0x1dbb34,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x295a87=0x0;_0x295a87<this['parts_']['length'];_0x295a87++)this['byteLength_']+=Ln(this['parts_'][_0x295a87]);Ao(this);}}function kh(_0xc911a3,_0xd65b33){_0xc911a3['parts_']['length']>0x0&&(_0xc911a3['byteLength_']+=0x1),_0xc911a3['parts_']['push'](_0xd65b33),_0xc911a3['byteLength_']+=Ln(_0xd65b33),Ao(_0xc911a3);}function Ph(_0xcc374f){const _0x1c9c32=_0xcc374f['parts_']['pop']();_0xcc374f['byteLength_']-=Ln(_0x1c9c32),_0xcc374f['parts_']['length']>0x0&&(_0xcc374f['byteLength_']-=0x1);}function Ao(_0x1f8f34){if(_0x1f8f34['byteLength_']>Zs)throw new Error(_0x1f8f34['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x1f8f34['byteLength_']+').');if(_0x1f8f34['parts_']['length']>Xs)throw new Error(_0x1f8f34['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x1f8f34));}function Oe(_0x3b6c3c){return _0x3b6c3c['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x3b6c3c['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x32ed5a,_0xdeb87a;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0xdeb87a='visibilitychange',_0x32ed5a='hidden'):typeof document['mozHidden']<'u'?(_0xdeb87a='mozvisibilitychange',_0x32ed5a='mozHidden'):typeof document['msHidden']<'u'?(_0xdeb87a='msvisibilitychange',_0x32ed5a='msHidden'):typeof document['webkitHidden']<'u'&&(_0xdeb87a='webkitvisibilitychange',_0x32ed5a='webkitHidden')),this['visible_']=!0x0,_0xdeb87a&&document['addEventListener'](_0xdeb87a,()=>{const _0x6a4bc1=!document[_0x32ed5a];_0x6a4bc1!==this['visible_']&&(this['visible_']=_0x6a4bc1,this['trigger']('visible',_0x6a4bc1));},!0x1);}['getInitialEvent'](_0x28d2d7){return f(_0x28d2d7==='visible','Unknown\x20event\x20type:\x20'+_0x28d2d7),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0xb7aef2,_0x409fa0,_0x5c685e,_0x5cb3e7,_0x227e72,_0xa898f,_0xe61056,_0x3b1bcd){if(super(),this['repoInfo_']=_0xb7aef2,this['applicationId_']=_0x409fa0,this['onDataUpdate_']=_0x5c685e,this['onConnectStatus_']=_0x5cb3e7,this['onServerInfoUpdate_']=_0x227e72,this['authTokenProvider_']=_0xa898f,this['appCheckTokenProvider_']=_0xe61056,this['authOverride_']=_0x3b1bcd,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x3b1bcd)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0xb7aef2['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x2ff29c,_0x974c94,_0x490aa9){const _0x52771d=++this['requestNumber_'],_0xe91b8b={'r':_0x52771d,'a':_0x2ff29c,'b':_0x974c94};this['log_'](O(_0xe91b8b)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0xe91b8b),_0x490aa9&&(this['requestCBHash_'][_0x52771d]=_0x490aa9);}['get'](_0x3c25c0){this['initConnection_']();const _0xc16c04=new H(),_0x1d1eee={'action':'g','request':{'p':_0x3c25c0['_path']['toString'](),'q':_0x3c25c0['_queryObject']},'onComplete':_0x3787b9=>{const _0x1368df=_0x3787b9['d'];_0x3787b9['s']==='ok'?_0xc16c04['resolve'](_0x1368df):_0xc16c04['reject'](_0x1368df);}};this['outstandingGets_']['push'](_0x1d1eee),this['outstandingGetCount_']++;const _0x1716ef=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x1716ef),_0xc16c04['promise'];}['listen'](_0x50e3eb,_0x5cc875,_0xd425be,_0x3eea63){this['initConnection_']();const _0x59ea44=_0x50e3eb['_queryIdentifier'],_0x1ca03f=_0x50e3eb['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1ca03f+'\x20'+_0x59ea44),this['listens']['has'](_0x1ca03f)||this['listens']['set'](_0x1ca03f,new Map()),f(_0x50e3eb['_queryParams']['isDefault']()||!_0x50e3eb['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x1ca03f)['has'](_0x59ea44),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x268d53={'onComplete':_0x3eea63,'hashFn':_0x5cc875,'query':_0x50e3eb,'tag':_0xd425be};this['listens']['get'](_0x1ca03f)['set'](_0x59ea44,_0x268d53),this['connected_']&&this['sendListen_'](_0x268d53);}['sendGet_'](_0x3f5968){const _0x402bd9=this['outstandingGets_'][_0x3f5968];this['sendRequest']('g',_0x402bd9['request'],_0x341329=>{delete this['outstandingGets_'][_0x3f5968],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x402bd9['onComplete']&&_0x402bd9['onComplete'](_0x341329);});}['sendListen_'](_0x17901a){const _0x2b88f6=_0x17901a['query'],_0x44770f=_0x2b88f6['_path']['toString'](),_0x4d7b77=_0x2b88f6['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x44770f+'\x20for\x20'+_0x4d7b77);const _0x186a2f={'p':_0x44770f},_0x5b3e6a='q';_0x17901a['tag']&&(_0x186a2f['q']=_0x2b88f6['_queryObject'],_0x186a2f['t']=_0x17901a['tag']),_0x186a2f['h']=_0x17901a['hashFn'](),this['sendRequest'](_0x5b3e6a,_0x186a2f,_0x45594d=>{const _0x553fae=_0x45594d['d'],_0x22e647=_0x45594d['s'];se['warnOnListenWarnings_'](_0x553fae,_0x2b88f6),(this['listens']['get'](_0x44770f)&&this['listens']['get'](_0x44770f)['get'](_0x4d7b77))===_0x17901a&&(this['log_']('listen\x20response',_0x45594d),_0x22e647!=='ok'&&this['removeListen_'](_0x44770f,_0x4d7b77),_0x17901a['onComplete']&&_0x17901a['onComplete'](_0x22e647,_0x553fae));});}static['warnOnListenWarnings_'](_0x241efa,_0x333c9c){if(_0x241efa&&typeof _0x241efa=='object'&&Q(_0x241efa,'w')){const _0x4ba1ad=Le(_0x241efa,'w');if(Array['isArray'](_0x4ba1ad)&&~_0x4ba1ad['indexOf']('no_index')){const _0x23d727='\x22.indexOn\x22:\x20\x22'+_0x333c9c['_queryParams']['getIndex']()['toString']()+'\x22',_0x6004c3=_0x333c9c['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x23d727+'\x20at\x20'+_0x6004c3+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x4b5725){this['authToken_']=_0x4b5725,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x4b5725);}['reduceReconnectDelayIfAdminCredential_'](_0x394b94){(_0x394b94&&_0x394b94['length']===0x28||wc(_0x394b94))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x50ba67){this['appCheckToken_']=_0x50ba67,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x17a74b=this['authToken_'],_0x42fe5e=Ic(_0x17a74b)?'auth':'gauth',_0x46a7f0={'cred':_0x17a74b};this['authOverride_']===null?_0x46a7f0['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x46a7f0['authvar']=this['authOverride_']),this['sendRequest'](_0x42fe5e,_0x46a7f0,_0x936013=>{const _0x15a859=_0x936013['s'],_0x12340b=_0x936013['d']||'error';this['authToken_']===_0x17a74b&&(_0x15a859==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x15a859,_0x12340b));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x341f8b=>{const _0xd19f6a=_0x341f8b['s'],_0x4bd13d=_0x341f8b['d']||'error';_0xd19f6a==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0xd19f6a,_0x4bd13d);});}['unlisten'](_0x3422c4,_0x34ef39){const _0x257fa1=_0x3422c4['_path']['toString'](),_0x4f01e7=_0x3422c4['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x257fa1+'\x20'+_0x4f01e7),f(_0x3422c4['_queryParams']['isDefault']()||!_0x3422c4['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x257fa1,_0x4f01e7)&&this['connected_']&&this['sendUnlisten_'](_0x257fa1,_0x4f01e7,_0x3422c4['_queryObject'],_0x34ef39);}['sendUnlisten_'](_0x1cf0b0,_0x45357c,_0x3ca86f,_0x1a22a0){this['log_']('Unlisten\x20on\x20'+_0x1cf0b0+'\x20for\x20'+_0x45357c);const _0x355443={'p':_0x1cf0b0},_0x170ee6='n';_0x1a22a0&&(_0x355443['q']=_0x3ca86f,_0x355443['t']=_0x1a22a0),this['sendRequest'](_0x170ee6,_0x355443);}['onDisconnectPut'](_0x148994,_0x2bf2a3,_0x1b0d7d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x148994,_0x2bf2a3,_0x1b0d7d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x148994,'action':'o','data':_0x2bf2a3,'onComplete':_0x1b0d7d});}['onDisconnectMerge'](_0x2afbf1,_0x1e0a25,_0xcedc07){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x2afbf1,_0x1e0a25,_0xcedc07):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2afbf1,'action':'om','data':_0x1e0a25,'onComplete':_0xcedc07});}['onDisconnectCancel'](_0x2688f9,_0x590e5a){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x2688f9,null,_0x590e5a):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2688f9,'action':'oc','data':null,'onComplete':_0x590e5a});}['sendOnDisconnect_'](_0x50dc54,_0x49b4df,_0x543ee9,_0x3c8045){const _0x518d1e={'p':_0x49b4df,'d':_0x543ee9};this['log_']('onDisconnect\x20'+_0x50dc54,_0x518d1e),this['sendRequest'](_0x50dc54,_0x518d1e,_0x1eb99=>{_0x3c8045&&setTimeout(()=>{_0x3c8045(_0x1eb99['s'],_0x1eb99['d']);},Math['floor'](0x0));});}['put'](_0x391ce4,_0xda25a2,_0x4c69b6,_0xee82e9){this['putInternal']('p',_0x391ce4,_0xda25a2,_0x4c69b6,_0xee82e9);}['merge'](_0xfe37f0,_0x4b16a5,_0x18b038,_0x33f48a){this['putInternal']('m',_0xfe37f0,_0x4b16a5,_0x18b038,_0x33f48a);}['putInternal'](_0x266139,_0xc47486,_0x550f6d,_0x177ca4,_0x377c84){this['initConnection_']();const _0xc05e0e={'p':_0xc47486,'d':_0x550f6d};_0x377c84!==void 0x0&&(_0xc05e0e['h']=_0x377c84),this['outstandingPuts_']['push']({'action':_0x266139,'request':_0xc05e0e,'onComplete':_0x177ca4}),this['outstandingPutCount_']++;const _0x33f514=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x33f514):this['log_']('Buffering\x20put:\x20'+_0xc47486);}['sendPut_'](_0x43c1a3){const _0x52c0bc=this['outstandingPuts_'][_0x43c1a3]['action'],_0x5b71e7=this['outstandingPuts_'][_0x43c1a3]['request'],_0x530728=this['outstandingPuts_'][_0x43c1a3]['onComplete'];this['outstandingPuts_'][_0x43c1a3]['queued']=this['connected_'],this['sendRequest'](_0x52c0bc,_0x5b71e7,_0x647f3=>{this['log_'](_0x52c0bc+'\x20response',_0x647f3),delete this['outstandingPuts_'][_0x43c1a3],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x530728&&_0x530728(_0x647f3['s'],_0x647f3['d']);});}['reportStats'](_0x4a0082){if(this['connected_']){const _0x125729={'c':_0x4a0082};this['log_']('reportStats',_0x125729),this['sendRequest']('s',_0x125729,_0x1b5118=>{if(_0x1b5118['s']!=='ok'){const _0x191437=_0x1b5118['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x191437);}});}}['onDataMessage_'](_0x3be4cf){if('r'in _0x3be4cf){this['log_']('from\x20server:\x20'+O(_0x3be4cf));const _0x2e0ba7=_0x3be4cf['r'],_0x394cf8=this['requestCBHash_'][_0x2e0ba7];_0x394cf8&&(delete this['requestCBHash_'][_0x2e0ba7],_0x394cf8(_0x3be4cf['b']));}else{if('error'in _0x3be4cf)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x3be4cf['error'];'a'in _0x3be4cf&&this['onDataPush_'](_0x3be4cf['a'],_0x3be4cf['b']);}}['onDataPush_'](_0x32061c,_0x1607ff){this['log_']('handleServerMessage',_0x32061c,_0x1607ff),_0x32061c==='d'?this['onDataUpdate_'](_0x1607ff['p'],_0x1607ff['d'],!0x1,_0x1607ff['t']):_0x32061c==='m'?this['onDataUpdate_'](_0x1607ff['p'],_0x1607ff['d'],!0x0,_0x1607ff['t']):_0x32061c==='c'?this['onListenRevoked_'](_0x1607ff['p'],_0x1607ff['q']):_0x32061c==='ac'?this['onAuthRevoked_'](_0x1607ff['s'],_0x1607ff['d']):_0x32061c==='apc'?this['onAppCheckRevoked_'](_0x1607ff['s'],_0x1607ff['d']):_0x32061c==='sd'?this['onSecurityDebugPacket_'](_0x1607ff):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x32061c)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x2644d6,_0x164293){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x2644d6),this['lastSessionId']=_0x164293,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x475820){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x475820));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x4e5eb5){_0x4e5eb5&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x4e5eb5;}['onOnline_'](_0x3379b3){_0x3379b3?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x3ac53a=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x2d110e=Math['max'](0x0,this['reconnectDelay_']-_0x3ac53a);_0x2d110e=Math['random']()*_0x2d110e,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x2d110e+'ms'),this['scheduleConnect_'](_0x2d110e),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x2d0e4a=this['onDataMessage_']['bind'](this),_0x2554ed=this['onReady_']['bind'](this),_0x3fcd11=this['onRealtimeDisconnect_']['bind'](this),_0x5d5b8a=this['id']+':'+se['nextConnectionId_']++,_0xc64f34=this['lastSessionId'];let _0x1d009f=!0x1,_0x569384=null;const _0x43d26e=function(){_0x569384?_0x569384['close']():(_0x1d009f=!0x0,_0x3fcd11());},_0x281224=function(_0x3076a4){f(_0x569384,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x569384['sendRequest'](_0x3076a4);};this['realtime_']={'close':_0x43d26e,'sendRequest':_0x281224};const _0x3e03ce=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x52aa6d,_0x3dc2c9]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x3e03ce),this['appCheckTokenProvider_']['getToken'](_0x3e03ce)]);_0x1d009f?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x52aa6d&&_0x52aa6d['accessToken'],this['appCheckToken_']=_0x3dc2c9&&_0x3dc2c9['token'],_0x569384=new Sh(_0x5d5b8a,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x2d0e4a,_0x2554ed,_0x3fcd11,_0x46880a=>{U(_0x46880a+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0xc64f34));}catch(_0x4aa319){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x4aa319),_0x1d009f||(this['repoInfo_']['nodeAdmin']&&U(_0x4aa319),_0x43d26e());}}}['interrupt'](_0x44e3b3){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x44e3b3),this['interruptReasons_'][_0x44e3b3]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x1964d9){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x1964d9),delete this['interruptReasons_'][_0x1964d9],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x589163){const _0x354014=_0x589163-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x354014});}['cancelSentTransactions_'](){for(let _0x781e79=0x0;_0x781e79<this['outstandingPuts_']['length'];_0x781e79++){const _0x561be6=this['outstandingPuts_'][_0x781e79];_0x561be6&&'h'in _0x561be6['request']&&_0x561be6['queued']&&(_0x561be6['onComplete']&&_0x561be6['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x781e79],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x114c07,_0x16edd8){let _0x177990;_0x16edd8?_0x177990=_0x16edd8['map'](_0x4df14c=>$i(_0x4df14c))['join']('$'):_0x177990='default';const _0x50cfd9=this['removeListen_'](_0x114c07,_0x177990);_0x50cfd9&&_0x50cfd9['onComplete']&&_0x50cfd9['onComplete']('permission_denied');}['removeListen_'](_0x430d17,_0x55d008){const _0x56674d=new C(_0x430d17)['toString']();let _0x4c8894;if(this['listens']['has'](_0x56674d)){const _0x411ffc=this['listens']['get'](_0x56674d);_0x4c8894=_0x411ffc['get'](_0x55d008),_0x411ffc['delete'](_0x55d008),_0x411ffc['size']===0x0&&this['listens']['delete'](_0x56674d);}else _0x4c8894=void 0x0;return _0x4c8894;}['onAuthRevoked_'](_0x12602d,_0x44c506){L('Auth\x20token\x20revoked:\x20'+_0x12602d+'/'+_0x44c506),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x12602d==='invalid_token'||_0x12602d==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0xd3fc76,_0x37b145){L('App\x20check\x20token\x20revoked:\x20'+_0xd3fc76+'/'+_0x37b145),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0xd3fc76==='invalid_token'||_0xd3fc76==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x5dfd8e){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x5dfd8e):'msg'in _0x5dfd8e&&console['log']('FIREBASE:\x20'+_0x5dfd8e['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x30629b of this['listens']['values']())for(const _0x317eff of _0x30629b['values']())this['sendListen_'](_0x317eff);for(let _0x40a1fb=0x0;_0x40a1fb<this['outstandingPuts_']['length'];_0x40a1fb++)this['outstandingPuts_'][_0x40a1fb]&&this['sendPut_'](_0x40a1fb);for(;this['onDisconnectRequestQueue_']['length'];){const _0x512b4d=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x512b4d['action'],_0x512b4d['pathString'],_0x512b4d['data'],_0x512b4d['onComplete']);}for(let _0x37c4ab=0x0;_0x37c4ab<this['outstandingGets_']['length'];_0x37c4ab++)this['outstandingGets_'][_0x37c4ab]&&this['sendGet_'](_0x37c4ab);}['sendConnectStats_'](){const _0xa15828={};let _0x3f6b0d='js';_0xa15828['sdk.'+_0x3f6b0d+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0xa15828['framework.cordova']=0x1:Kr()&&(_0xa15828['framework.reactnative']=0x1),this['reportStats'](_0xa15828);}['shouldReconnect_'](){const _0x1abd7c=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x1abd7c;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x180837,_0x4d2206){this['name']=_0x180837,this['node']=_0x4d2206;}static['Wrap'](_0x37ba72,_0x37275b){return new E(_0x37ba72,_0x37275b);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0xbef59,_0x2e610b){const _0x431dbd=new E(We,_0xbef59),_0x28f24f=new E(We,_0x2e610b);return this['compare'](_0x431dbd,_0x28f24f)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x2882d6){sn=_0x2882d6;}['compare'](_0x5dc743,_0x180f96){return qe(_0x5dc743['name'],_0x180f96['name']);}['isDefinedOn'](_0x4d0107){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x33066d,_0x1df4d1){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x20acfc,_0x57c95f){return f(typeof _0x20acfc=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x20acfc,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x310c3a,_0x1ea390,_0x3ff91d,_0x5c7b81,_0x41f7a8=null){this['isReverse_']=_0x5c7b81,this['resultGenerator_']=_0x41f7a8,this['nodeStack_']=[];let _0x59a8c3=0x1;for(;!_0x310c3a['isEmpty']();)if(_0x310c3a=_0x310c3a,_0x59a8c3=_0x1ea390?_0x3ff91d(_0x310c3a['key'],_0x1ea390):0x1,_0x5c7b81&&(_0x59a8c3*=-0x1),_0x59a8c3<0x0)this['isReverse_']?_0x310c3a=_0x310c3a['left']:_0x310c3a=_0x310c3a['right'];else{if(_0x59a8c3===0x0){this['nodeStack_']['push'](_0x310c3a);break;}else this['nodeStack_']['push'](_0x310c3a),this['isReverse_']?_0x310c3a=_0x310c3a['right']:_0x310c3a=_0x310c3a['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x230a19=this['nodeStack_']['pop'](),_0x2b613f;if(this['resultGenerator_']?_0x2b613f=this['resultGenerator_'](_0x230a19['key'],_0x230a19['value']):_0x2b613f={'key':_0x230a19['key'],'value':_0x230a19['value']},this['isReverse_']){for(_0x230a19=_0x230a19['left'];!_0x230a19['isEmpty']();)this['nodeStack_']['push'](_0x230a19),_0x230a19=_0x230a19['right'];}else{for(_0x230a19=_0x230a19['right'];!_0x230a19['isEmpty']();)this['nodeStack_']['push'](_0x230a19),_0x230a19=_0x230a19['left'];}return _0x2b613f;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x152878=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x152878['key'],_0x152878['value']):{'key':_0x152878['key'],'value':_0x152878['value']};}}class M{constructor(_0x3a9d20,_0x522c60,_0x394137,_0xf2ab8c,_0x303a3a){this['key']=_0x3a9d20,this['value']=_0x522c60,this['color']=_0x394137??M['RED'],this['left']=_0xf2ab8c??B['EMPTY_NODE'],this['right']=_0x303a3a??B['EMPTY_NODE'];}['copy'](_0x4c5ef7,_0x13d94f,_0x27f7ef,_0x17bea1,_0x346bae){return new M(_0x4c5ef7??this['key'],_0x13d94f??this['value'],_0x27f7ef??this['color'],_0x17bea1??this['left'],_0x346bae??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0xc9de5d){return this['left']['inorderTraversal'](_0xc9de5d)||!!_0xc9de5d(this['key'],this['value'])||this['right']['inorderTraversal'](_0xc9de5d);}['reverseTraversal'](_0x77d18d){return this['right']['reverseTraversal'](_0x77d18d)||_0x77d18d(this['key'],this['value'])||this['left']['reverseTraversal'](_0x77d18d);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x15d376,_0x40d6ca,_0x1516ff){let _0x19bba1=this;const _0x14cdae=_0x1516ff(_0x15d376,_0x19bba1['key']);return _0x14cdae<0x0?_0x19bba1=_0x19bba1['copy'](null,null,null,_0x19bba1['left']['insert'](_0x15d376,_0x40d6ca,_0x1516ff),null):_0x14cdae===0x0?_0x19bba1=_0x19bba1['copy'](null,_0x40d6ca,null,null,null):_0x19bba1=_0x19bba1['copy'](null,null,null,null,_0x19bba1['right']['insert'](_0x15d376,_0x40d6ca,_0x1516ff)),_0x19bba1['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x540e6a=this;return!_0x540e6a['left']['isRed_']()&&!_0x540e6a['left']['left']['isRed_']()&&(_0x540e6a=_0x540e6a['moveRedLeft_']()),_0x540e6a=_0x540e6a['copy'](null,null,null,_0x540e6a['left']['removeMin_'](),null),_0x540e6a['fixUp_']();}['remove'](_0x579a64,_0x592c2a){let _0x5d369b,_0x27484d;if(_0x5d369b=this,_0x592c2a(_0x579a64,_0x5d369b['key'])<0x0)!_0x5d369b['left']['isEmpty']()&&!_0x5d369b['left']['isRed_']()&&!_0x5d369b['left']['left']['isRed_']()&&(_0x5d369b=_0x5d369b['moveRedLeft_']()),_0x5d369b=_0x5d369b['copy'](null,null,null,_0x5d369b['left']['remove'](_0x579a64,_0x592c2a),null);else{if(_0x5d369b['left']['isRed_']()&&(_0x5d369b=_0x5d369b['rotateRight_']()),!_0x5d369b['right']['isEmpty']()&&!_0x5d369b['right']['isRed_']()&&!_0x5d369b['right']['left']['isRed_']()&&(_0x5d369b=_0x5d369b['moveRedRight_']()),_0x592c2a(_0x579a64,_0x5d369b['key'])===0x0){if(_0x5d369b['right']['isEmpty']())return B['EMPTY_NODE'];_0x27484d=_0x5d369b['right']['min_'](),_0x5d369b=_0x5d369b['copy'](_0x27484d['key'],_0x27484d['value'],null,null,_0x5d369b['right']['removeMin_']());}_0x5d369b=_0x5d369b['copy'](null,null,null,null,_0x5d369b['right']['remove'](_0x579a64,_0x592c2a));}return _0x5d369b['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x1dc288=this;return _0x1dc288['right']['isRed_']()&&!_0x1dc288['left']['isRed_']()&&(_0x1dc288=_0x1dc288['rotateLeft_']()),_0x1dc288['left']['isRed_']()&&_0x1dc288['left']['left']['isRed_']()&&(_0x1dc288=_0x1dc288['rotateRight_']()),_0x1dc288['left']['isRed_']()&&_0x1dc288['right']['isRed_']()&&(_0x1dc288=_0x1dc288['colorFlip_']()),_0x1dc288;}['moveRedLeft_'](){let _0x43323c=this['colorFlip_']();return _0x43323c['right']['left']['isRed_']()&&(_0x43323c=_0x43323c['copy'](null,null,null,null,_0x43323c['right']['rotateRight_']()),_0x43323c=_0x43323c['rotateLeft_'](),_0x43323c=_0x43323c['colorFlip_']()),_0x43323c;}['moveRedRight_'](){let _0x45fbcb=this['colorFlip_']();return _0x45fbcb['left']['left']['isRed_']()&&(_0x45fbcb=_0x45fbcb['rotateRight_'](),_0x45fbcb=_0x45fbcb['colorFlip_']()),_0x45fbcb;}['rotateLeft_'](){const _0x676bbb=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x676bbb,null);}['rotateRight_'](){const _0x2c1071=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x2c1071);}['colorFlip_'](){const _0x5d86d5=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x10b004=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x5d86d5,_0x10b004);}['checkMaxDepth_'](){const _0x1f4903=this['check_']();return Math['pow'](0x2,_0x1f4903)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x373dd1=this['left']['check_']();if(_0x373dd1!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x373dd1+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x39e051,_0x4bdb58,_0x2752e4,_0x13a97a,_0x550f91){return this;}['insert'](_0x41fbc1,_0x2b3317,_0x3e6b85){return new M(_0x41fbc1,_0x2b3317,null);}['remove'](_0x5b0b02,_0x4085aa){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x2c40e4){return!0x1;}['reverseTraversal'](_0x3443d3){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x4d5f8f,_0x23120a=B['EMPTY_NODE']){this['comparator_']=_0x4d5f8f,this['root_']=_0x23120a;}['insert'](_0x47e771,_0x5f29d9){return new B(this['comparator_'],this['root_']['insert'](_0x47e771,_0x5f29d9,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x26c0e5){return new B(this['comparator_'],this['root_']['remove'](_0x26c0e5,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x48c11d){let _0x3ec972,_0x5f5ac1=this['root_'];for(;!_0x5f5ac1['isEmpty']();){if(_0x3ec972=this['comparator_'](_0x48c11d,_0x5f5ac1['key']),_0x3ec972===0x0)return _0x5f5ac1['value'];_0x3ec972<0x0?_0x5f5ac1=_0x5f5ac1['left']:_0x3ec972>0x0&&(_0x5f5ac1=_0x5f5ac1['right']);}return null;}['getPredecessorKey'](_0x2a4123){let _0x24c6bd,_0x11ceda=this['root_'],_0x10ab0d=null;for(;!_0x11ceda['isEmpty']();)if(_0x24c6bd=this['comparator_'](_0x2a4123,_0x11ceda['key']),_0x24c6bd===0x0){if(_0x11ceda['left']['isEmpty']())return _0x10ab0d?_0x10ab0d['key']:null;for(_0x11ceda=_0x11ceda['left'];!_0x11ceda['right']['isEmpty']();)_0x11ceda=_0x11ceda['right'];return _0x11ceda['key'];}else _0x24c6bd<0x0?_0x11ceda=_0x11ceda['left']:_0x24c6bd>0x0&&(_0x10ab0d=_0x11ceda,_0x11ceda=_0x11ceda['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x7cd8ed){return this['root_']['inorderTraversal'](_0x7cd8ed);}['reverseTraversal'](_0x5f2819){return this['root_']['reverseTraversal'](_0x5f2819);}['getIterator'](_0xfca387){return new rn(this['root_'],null,this['comparator_'],!0x1,_0xfca387);}['getIteratorFrom'](_0x35e1b1,_0x1cd688){return new rn(this['root_'],_0x35e1b1,this['comparator_'],!0x1,_0x1cd688);}['getReverseIteratorFrom'](_0x5734f2,_0x36d760){return new rn(this['root_'],_0x5734f2,this['comparator_'],!0x0,_0x36d760);}['getReverseIterator'](_0x3f4949){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x3f4949);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x2498fa,_0x4db102){return qe(_0x2498fa['name'],_0x4db102['name']);}function Qi(_0x5d3ab2,_0x64897c){return qe(_0x5d3ab2,_0x64897c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x4266e4){Ci=_0x4266e4;}const Po=function(_0x472fd9){return typeof _0x472fd9=='number'?'number:'+ao(_0x472fd9):'string:'+_0x472fd9;},No=function(_0x35d52b){if(_0x35d52b['isLeafNode']()){const _0x53dcce=_0x35d52b['val']();f(typeof _0x53dcce=='string'||typeof _0x53dcce=='number'||typeof _0x53dcce=='object'&&Q(_0x53dcce,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x35d52b===Ci||_0x35d52b['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x35d52b===Ci||_0x35d52b['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x40a071){nr=_0x40a071;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x225be3,_0x36c336=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x225be3,this['priorityNode_']=_0x36c336,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1dbd02){return new D(this['value_'],_0x1dbd02);}['getImmediateChild'](_0x14dece){return _0x14dece==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x5b489f){return v(_0x5b489f)?this:y(_0x5b489f)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x89e19f,_0x37f108){return null;}['updateImmediateChild'](_0x33d5cf,_0x443d59){return _0x33d5cf==='.priority'?this['updatePriority'](_0x443d59):_0x443d59['isEmpty']()&&_0x33d5cf!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x33d5cf,_0x443d59)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x506156,_0x3bff53){const _0x51755a=y(_0x506156);return _0x51755a===null?_0x3bff53:_0x3bff53['isEmpty']()&&_0x51755a!=='.priority'?this:(f(_0x51755a!=='.priority'||Ce(_0x506156)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x51755a,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x506156),_0x3bff53)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x54a87e,_0x8e720b){return!0x1;}['val'](_0x552eb3){return _0x552eb3&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x3b59cb='';this['priorityNode_']['isEmpty']()||(_0x3b59cb+='priority:'+Po(this['priorityNode_']['val']())+':');const _0xb5b20=typeof this['value_'];_0x3b59cb+=_0xb5b20+':',_0xb5b20==='number'?_0x3b59cb+=ao(this['value_']):_0x3b59cb+=this['value_'],this['lazyHash_']=ro(_0x3b59cb);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x19cf3f){return _0x19cf3f===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x19cf3f instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x19cf3f['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x19cf3f));}['compareToLeafNode_'](_0x276938){const _0x4d09a6=typeof _0x276938['value_'],_0x3ade8d=typeof this['value_'],_0x426e13=D['VALUE_TYPE_ORDER']['indexOf'](_0x4d09a6),_0x337be5=D['VALUE_TYPE_ORDER']['indexOf'](_0x3ade8d);return f(_0x426e13>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4d09a6),f(_0x337be5>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x3ade8d),_0x426e13===_0x337be5?_0x3ade8d==='object'?0x0:this['value_']<_0x276938['value_']?-0x1:this['value_']===_0x276938['value_']?0x0:0x1:_0x337be5-_0x426e13;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x29195d){if(_0x29195d===this)return!0x0;if(_0x29195d['isLeafNode']()){const _0x345fb7=_0x29195d;return this['value_']===_0x345fb7['value_']&&this['priorityNode_']['equals'](_0x345fb7['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x355e87){Oo=_0x355e87;}function Wh(_0x12c90d){Do=_0x12c90d;}class Bh extends Fn{['compare'](_0x39bff9,_0x4e7933){const _0x27eb9e=_0x39bff9['node']['getPriority'](),_0x1f78d6=_0x4e7933['node']['getPriority'](),_0x2786b8=_0x27eb9e['compareTo'](_0x1f78d6);return _0x2786b8===0x0?qe(_0x39bff9['name'],_0x4e7933['name']):_0x2786b8;}['isDefinedOn'](_0x4c3eef){return!_0x4c3eef['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x8a8303,_0x652e5d){return!_0x8a8303['getPriority']()['equals'](_0x652e5d['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x5e662a,_0x1cf0f1){const _0x4948ca=Oo(_0x5e662a);return new E(_0x1cf0f1,new D('[PRIORITY-POST]',_0x4948ca));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x491d9a){const _0xeefe20=_0x397000=>parseInt(Math['log'](_0x397000)/Vh,0xa),_0x2b8428=_0x42a56a=>parseInt(Array(_0x42a56a+0x1)['join']('1'),0x2);this['count']=_0xeefe20(_0x491d9a+0x1),this['current_']=this['count']-0x1;const _0x590c8a=_0x2b8428(this['count']);this['bits_']=_0x491d9a+0x1&_0x590c8a;}['nextBitIsOne'](){const _0x47585d=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x47585d;}}const yn=function(_0xc6be2e,_0x40b937,_0x54f42b,_0x9707bf){_0xc6be2e['sort'](_0x40b937);const _0x24aecc=function(_0x1dd696,_0x955b50){const _0x4b5cd3=_0x955b50-_0x1dd696;let _0x5e5081,_0x58fb09;if(_0x4b5cd3===0x0)return null;if(_0x4b5cd3===0x1)return _0x5e5081=_0xc6be2e[_0x1dd696],_0x58fb09=_0x54f42b?_0x54f42b(_0x5e5081):_0x5e5081,new M(_0x58fb09,_0x5e5081['node'],M['BLACK'],null,null);{const _0x5d37d1=parseInt(_0x4b5cd3/0x2,0xa)+_0x1dd696,_0x153ab7=_0x24aecc(_0x1dd696,_0x5d37d1),_0x100505=_0x24aecc(_0x5d37d1+0x1,_0x955b50);return _0x5e5081=_0xc6be2e[_0x5d37d1],_0x58fb09=_0x54f42b?_0x54f42b(_0x5e5081):_0x5e5081,new M(_0x58fb09,_0x5e5081['node'],M['BLACK'],_0x153ab7,_0x100505);}},_0x212692=function(_0xf9a523){let _0x20dd4d=null,_0x4b0498=null,_0x2186e0=_0xc6be2e['length'];const _0x5e305c=function(_0x47dd6c,_0xa0a7d0){const _0x3ab782=_0x2186e0-_0x47dd6c,_0xcf3e54=_0x2186e0;_0x2186e0-=_0x47dd6c;const _0x5b10ef=_0x24aecc(_0x3ab782+0x1,_0xcf3e54),_0x12ba0e=_0xc6be2e[_0x3ab782],_0x481596=_0x54f42b?_0x54f42b(_0x12ba0e):_0x12ba0e;_0x59adfc(new M(_0x481596,_0x12ba0e['node'],_0xa0a7d0,null,_0x5b10ef));},_0x59adfc=function(_0x37dc33){_0x20dd4d?(_0x20dd4d['left']=_0x37dc33,_0x20dd4d=_0x37dc33):(_0x4b0498=_0x37dc33,_0x20dd4d=_0x37dc33);};for(let _0x5596aa=0x0;_0x5596aa<_0xf9a523['count'];++_0x5596aa){const _0x29896a=_0xf9a523['nextBitIsOne'](),_0x4f2353=Math['pow'](0x2,_0xf9a523['count']-(_0x5596aa+0x1));_0x29896a?_0x5e305c(_0x4f2353,M['BLACK']):(_0x5e305c(_0x4f2353,M['BLACK']),_0x5e305c(_0x4f2353,M['RED']));}return _0x4b0498;},_0x56c6d3=new Hh(_0xc6be2e['length']),_0x3b6515=_0x212692(_0x56c6d3);return new B(_0x9707bf||_0x40b937,_0x3b6515);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x5cc0eb,_0x2b8fc9){this['indexes_']=_0x5cc0eb,this['indexSet_']=_0x2b8fc9;}['get'](_0x3a54f8){const _0x4fbe77=Le(this['indexes_'],_0x3a54f8);if(!_0x4fbe77)throw new Error('No\x20index\x20defined\x20for\x20'+_0x3a54f8);return _0x4fbe77 instanceof B?_0x4fbe77:null;}['hasIndex'](_0x3bbbeb){return Q(this['indexSet_'],_0x3bbbeb['toString']());}['addIndex'](_0x2ce792,_0x6f7b97){f(_0x2ce792!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0xe90cea=[];let _0x520629=!0x1;const _0x1ce0f3=_0x6f7b97['getIterator'](E['Wrap']);let _0x5d8808=_0x1ce0f3['getNext']();for(;_0x5d8808;)_0x520629=_0x520629||_0x2ce792['isDefinedOn'](_0x5d8808['node']),_0xe90cea['push'](_0x5d8808),_0x5d8808=_0x1ce0f3['getNext']();let _0x3b187a;_0x520629?_0x3b187a=yn(_0xe90cea,_0x2ce792['getCompare']()):_0x3b187a=Qe;const _0x321679=_0x2ce792['toString'](),_0x2a9626={...this['indexSet_']};_0x2a9626[_0x321679]=_0x2ce792;const _0x14d935={...this['indexes_']};return _0x14d935[_0x321679]=_0x3b187a,new te(_0x14d935,_0x2a9626);}['addToIndexes'](_0x4e9c61,_0x2d7b8a){const _0x2208d0=_n(this['indexes_'],(_0x5270d3,_0x217ae2)=>{const _0x105d5f=Le(this['indexSet_'],_0x217ae2);if(f(_0x105d5f,'Missing\x20index\x20implementation\x20for\x20'+_0x217ae2),_0x5270d3===Qe){if(_0x105d5f['isDefinedOn'](_0x4e9c61['node'])){const _0x48b143=[],_0x404b62=_0x2d7b8a['getIterator'](E['Wrap']);let _0xd87699=_0x404b62['getNext']();for(;_0xd87699;)_0xd87699['name']!==_0x4e9c61['name']&&_0x48b143['push'](_0xd87699),_0xd87699=_0x404b62['getNext']();return _0x48b143['push'](_0x4e9c61),yn(_0x48b143,_0x105d5f['getCompare']());}else return Qe;}else{const _0x5baed0=_0x2d7b8a['get'](_0x4e9c61['name']);let _0x520552=_0x5270d3;return _0x5baed0&&(_0x520552=_0x520552['remove'](new E(_0x4e9c61['name'],_0x5baed0))),_0x520552['insert'](_0x4e9c61,_0x4e9c61['node']);}});return new te(_0x2208d0,this['indexSet_']);}['removeFromIndexes'](_0x152fd4,_0x3f424d){const _0x485710=_n(this['indexes_'],_0x280f17=>{if(_0x280f17===Qe)return _0x280f17;{const _0x4819bc=_0x3f424d['get'](_0x152fd4['name']);return _0x4819bc?_0x280f17['remove'](new E(_0x152fd4['name'],_0x4819bc)):_0x280f17;}});return new te(_0x485710,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x13dafd,_0xfab635,_0x5caf79){this['children_']=_0x13dafd,this['priorityNode_']=_0xfab635,this['indexMap_']=_0x5caf79,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0xc6750e){return this['children_']['isEmpty']()?this:new g(this['children_'],_0xc6750e,this['indexMap_']);}['getImmediateChild'](_0x284574){if(_0x284574==='.priority')return this['getPriority']();{const _0x30b6a5=this['children_']['get'](_0x284574);return _0x30b6a5===null?It:_0x30b6a5;}}['getChild'](_0x4b7e91){const _0x589003=y(_0x4b7e91);return _0x589003===null?this:this['getImmediateChild'](_0x589003)['getChild'](S(_0x4b7e91));}['hasChild'](_0x4f8911){return this['children_']['get'](_0x4f8911)!==null;}['updateImmediateChild'](_0x245af4,_0x4479e5){if(f(_0x4479e5,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x245af4==='.priority')return this['updatePriority'](_0x4479e5);{const _0x450691=new E(_0x245af4,_0x4479e5);let _0x52ac94,_0x5dcbc7;_0x4479e5['isEmpty']()?(_0x52ac94=this['children_']['remove'](_0x245af4),_0x5dcbc7=this['indexMap_']['removeFromIndexes'](_0x450691,this['children_'])):(_0x52ac94=this['children_']['insert'](_0x245af4,_0x4479e5),_0x5dcbc7=this['indexMap_']['addToIndexes'](_0x450691,this['children_']));const _0x3cb98f=_0x52ac94['isEmpty']()?It:this['priorityNode_'];return new g(_0x52ac94,_0x3cb98f,_0x5dcbc7);}}['updateChild'](_0x8cde10,_0x19ae56){const _0x2c2171=y(_0x8cde10);if(_0x2c2171===null)return _0x19ae56;{f(y(_0x8cde10)!=='.priority'||Ce(_0x8cde10)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x547f7e=this['getImmediateChild'](_0x2c2171)['updateChild'](S(_0x8cde10),_0x19ae56);return this['updateImmediateChild'](_0x2c2171,_0x547f7e);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0xd7d6ab){if(this['isEmpty']())return null;const _0x1bd4de={};let _0x25141c=0x0,_0x5e1a4=0x0,_0x33b679=!0x0;if(this['forEachChild'](R,(_0x3181f8,_0x56fa40)=>{_0x1bd4de[_0x3181f8]=_0x56fa40['val'](_0xd7d6ab),_0x25141c++,_0x33b679&&g['INTEGER_REGEXP_']['test'](_0x3181f8)?_0x5e1a4=Math['max'](_0x5e1a4,Number(_0x3181f8)):_0x33b679=!0x1;}),!_0xd7d6ab&&_0x33b679&&_0x5e1a4<0x2*_0x25141c){const _0x15afd2=[];for(const _0x15926b in _0x1bd4de)_0x15afd2[_0x15926b]=_0x1bd4de[_0x15926b];return _0x15afd2;}else return _0xd7d6ab&&!this['getPriority']()['isEmpty']()&&(_0x1bd4de['.priority']=this['getPriority']()['val']()),_0x1bd4de;}['hash'](){if(this['lazyHash_']===null){let _0x41228c='';this['getPriority']()['isEmpty']()||(_0x41228c+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x1d776e,_0x3ea569)=>{const _0x1ce688=_0x3ea569['hash']();_0x1ce688!==''&&(_0x41228c+=':'+_0x1d776e+':'+_0x1ce688);}),this['lazyHash_']=_0x41228c===''?'':ro(_0x41228c);}return this['lazyHash_'];}['getPredecessorChildName'](_0x1e3b1c,_0x46d3a4,_0x216056){const _0x419616=this['resolveIndex_'](_0x216056);if(_0x419616){const _0x554bc8=_0x419616['getPredecessorKey'](new E(_0x1e3b1c,_0x46d3a4));return _0x554bc8?_0x554bc8['name']:null;}else return this['children_']['getPredecessorKey'](_0x1e3b1c);}['getFirstChildName'](_0x3827f3){const _0x4b3633=this['resolveIndex_'](_0x3827f3);if(_0x4b3633){const _0x3ee7ad=_0x4b3633['minKey']();return _0x3ee7ad&&_0x3ee7ad['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x57bd6e){const _0x5ad7f9=this['getFirstChildName'](_0x57bd6e);return _0x5ad7f9?new E(_0x5ad7f9,this['children_']['get'](_0x5ad7f9)):null;}['getLastChildName'](_0x394784){const _0x234425=this['resolveIndex_'](_0x394784);if(_0x234425){const _0x3f1e98=_0x234425['maxKey']();return _0x3f1e98&&_0x3f1e98['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x1b147c){const _0x5b0240=this['getLastChildName'](_0x1b147c);return _0x5b0240?new E(_0x5b0240,this['children_']['get'](_0x5b0240)):null;}['forEachChild'](_0x831e72,_0x3e04b5){const _0x32a925=this['resolveIndex_'](_0x831e72);return _0x32a925?_0x32a925['inorderTraversal'](_0x37fede=>_0x3e04b5(_0x37fede['name'],_0x37fede['node'])):this['children_']['inorderTraversal'](_0x3e04b5);}['getIterator'](_0x50d4f8){return this['getIteratorFrom'](_0x50d4f8['minPost'](),_0x50d4f8);}['getIteratorFrom'](_0x5f10e9,_0x3a0e15){const _0x1f32c0=this['resolveIndex_'](_0x3a0e15);if(_0x1f32c0)return _0x1f32c0['getIteratorFrom'](_0x5f10e9,_0x3d6de9=>_0x3d6de9);{const _0x22e226=this['children_']['getIteratorFrom'](_0x5f10e9['name'],E['Wrap']);let _0x169ed1=_0x22e226['peek']();for(;_0x169ed1!=null&&_0x3a0e15['compare'](_0x169ed1,_0x5f10e9)<0x0;)_0x22e226['getNext'](),_0x169ed1=_0x22e226['peek']();return _0x22e226;}}['getReverseIterator'](_0x3f551e){return this['getReverseIteratorFrom'](_0x3f551e['maxPost'](),_0x3f551e);}['getReverseIteratorFrom'](_0x19d186,_0x154016){const _0xf760c7=this['resolveIndex_'](_0x154016);if(_0xf760c7)return _0xf760c7['getReverseIteratorFrom'](_0x19d186,_0x2da95e=>_0x2da95e);{const _0x4b5a9d=this['children_']['getReverseIteratorFrom'](_0x19d186['name'],E['Wrap']);let _0x437678=_0x4b5a9d['peek']();for(;_0x437678!=null&&_0x154016['compare'](_0x437678,_0x19d186)>0x0;)_0x4b5a9d['getNext'](),_0x437678=_0x4b5a9d['peek']();return _0x4b5a9d;}}['compareTo'](_0x3d4239){return this['isEmpty']()?_0x3d4239['isEmpty']()?0x0:-0x1:_0x3d4239['isLeafNode']()||_0x3d4239['isEmpty']()?0x1:_0x3d4239===Kt?-0x1:0x0;}['withIndex'](_0x2b848f){if(_0x2b848f===ve||this['indexMap_']['hasIndex'](_0x2b848f))return this;{const _0x1bb6d2=this['indexMap_']['addIndex'](_0x2b848f,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x1bb6d2);}}['isIndexed'](_0x22ac62){return _0x22ac62===ve||this['indexMap_']['hasIndex'](_0x22ac62);}['equals'](_0x14d847){if(_0x14d847===this)return!0x0;if(_0x14d847['isLeafNode']())return!0x1;{const _0x47b9e9=_0x14d847;if(this['getPriority']()['equals'](_0x47b9e9['getPriority']())){if(this['children_']['count']()===_0x47b9e9['children_']['count']()){const _0x7b1b43=this['getIterator'](R),_0x57bbb2=_0x47b9e9['getIterator'](R);let _0x183a53=_0x7b1b43['getNext'](),_0x5af304=_0x57bbb2['getNext']();for(;_0x183a53&&_0x5af304;){if(_0x183a53['name']!==_0x5af304['name']||!_0x183a53['node']['equals'](_0x5af304['node']))return!0x1;_0x183a53=_0x7b1b43['getNext'](),_0x5af304=_0x57bbb2['getNext']();}return _0x183a53===null&&_0x5af304===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x1d5f7d){return _0x1d5f7d===ve?null:this['indexMap_']['get'](_0x1d5f7d['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x5982af){return _0x5982af===this?0x0:0x1;}['equals'](_0x5edda8){return _0x5edda8===this;}['getPriority'](){return this;}['getImmediateChild'](_0x4d21d4){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x3eb255,_0x1acfce=null){if(_0x3eb255===null)return g['EMPTY_NODE'];if(typeof _0x3eb255=='object'&&'.priority'in _0x3eb255&&(_0x1acfce=_0x3eb255['.priority']),f(_0x1acfce===null||typeof _0x1acfce=='string'||typeof _0x1acfce=='number'||typeof _0x1acfce=='object'&&'.sv'in _0x1acfce,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x1acfce),typeof _0x3eb255=='object'&&'.value'in _0x3eb255&&_0x3eb255['.value']!==null&&(_0x3eb255=_0x3eb255['.value']),typeof _0x3eb255!='object'||'.sv'in _0x3eb255){const _0x3aec73=_0x3eb255;return new D(_0x3aec73,A(_0x1acfce));}if(!(_0x3eb255 instanceof Array)&&Gh){const _0x8ba063=[];let _0x44c6d9=!0x1;if(x(_0x3eb255,(_0x2eb0b6,_0x492eec)=>{if(_0x2eb0b6['substring'](0x0,0x1)!=='.'){const _0x37f46f=A(_0x492eec);_0x37f46f['isEmpty']()||(_0x44c6d9=_0x44c6d9||!_0x37f46f['getPriority']()['isEmpty'](),_0x8ba063['push'](new E(_0x2eb0b6,_0x37f46f)));}}),_0x8ba063['length']===0x0)return g['EMPTY_NODE'];const _0x5744b9=yn(_0x8ba063,xh,_0x21611d=>_0x21611d['name'],Qi);if(_0x44c6d9){const _0x541b8a=yn(_0x8ba063,R['getCompare']());return new g(_0x5744b9,A(_0x1acfce),new te({'.priority':_0x541b8a},{'.priority':R}));}else return new g(_0x5744b9,A(_0x1acfce),te['Default']);}else{let _0xbc60ab=g['EMPTY_NODE'];return x(_0x3eb255,(_0x2ce24d,_0x1d664e)=>{if(Q(_0x3eb255,_0x2ce24d)&&_0x2ce24d['substring'](0x0,0x1)!=='.'){const _0x472194=A(_0x1d664e);(_0x472194['isLeafNode']()||!_0x472194['isEmpty']())&&(_0xbc60ab=_0xbc60ab['updateImmediateChild'](_0x2ce24d,_0x472194));}}),_0xbc60ab['updatePriority'](A(_0x1acfce));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x485594){super(),this['indexPath_']=_0x485594,f(!v(_0x485594)&&y(_0x485594)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x438a40){return _0x438a40['getChild'](this['indexPath_']);}['isDefinedOn'](_0x284397){return!_0x284397['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x22e1c0,_0x4e78b1){const _0x3c9c11=this['extractChild'](_0x22e1c0['node']),_0xee3250=this['extractChild'](_0x4e78b1['node']),_0x5d509f=_0x3c9c11['compareTo'](_0xee3250);return _0x5d509f===0x0?qe(_0x22e1c0['name'],_0x4e78b1['name']):_0x5d509f;}['makePost'](_0x14abe1,_0x481101){const _0x55fb19=A(_0x14abe1),_0x4c199e=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x55fb19);return new E(_0x481101,_0x4c199e);}['maxPost'](){const _0x2f0493=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x2f0493);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x498c64,_0x20daa6){const _0x40bfa0=_0x498c64['node']['compareTo'](_0x20daa6['node']);return _0x40bfa0===0x0?qe(_0x498c64['name'],_0x20daa6['name']):_0x40bfa0;}['isDefinedOn'](_0x22f4aa){return!0x0;}['indexedValueChanged'](_0x5e781f,_0x2df598){return!_0x5e781f['equals'](_0x2df598);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0xa4287e,_0x49b652){const _0x219742=A(_0xa4287e);return new E(_0x49b652,_0x219742);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x211826){return{'type':'value','snapshotNode':_0x211826};}function rt(_0x4f2bfc,_0xbc2e84){return{'type':'child_added','snapshotNode':_0xbc2e84,'childName':_0x4f2bfc};}function Lt(_0x3497a6,_0x2c250f){return{'type':'child_removed','snapshotNode':_0x2c250f,'childName':_0x3497a6};}function xt(_0x1edd80,_0x54cfcb,_0x4799d8){return{'type':'child_changed','snapshotNode':_0x54cfcb,'childName':_0x1edd80,'oldSnap':_0x4799d8};}function zh(_0x32988b,_0x5c9c63){return{'type':'child_moved','snapshotNode':_0x5c9c63,'childName':_0x32988b};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x47b18e){this['index_']=_0x47b18e;}['updateChild'](_0x279cde,_0x429c36,_0x3623f6,_0x5035b5,_0x210d06,_0x2ca464){f(_0x279cde['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x1c4402=_0x279cde['getImmediateChild'](_0x429c36);return _0x1c4402['getChild'](_0x5035b5)['equals'](_0x3623f6['getChild'](_0x5035b5))&&_0x1c4402['isEmpty']()===_0x3623f6['isEmpty']()||(_0x2ca464!=null&&(_0x3623f6['isEmpty']()?_0x279cde['hasChild'](_0x429c36)?_0x2ca464['trackChildChange'](Lt(_0x429c36,_0x1c4402)):f(_0x279cde['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x1c4402['isEmpty']()?_0x2ca464['trackChildChange'](rt(_0x429c36,_0x3623f6)):_0x2ca464['trackChildChange'](xt(_0x429c36,_0x3623f6,_0x1c4402))),_0x279cde['isLeafNode']()&&_0x3623f6['isEmpty']())?_0x279cde:_0x279cde['updateImmediateChild'](_0x429c36,_0x3623f6)['withIndex'](this['index_']);}['updateFullNode'](_0xb17c76,_0x1d765b,_0x65f4a8){return _0x65f4a8!=null&&(_0xb17c76['isLeafNode']()||_0xb17c76['forEachChild'](R,(_0x2b05a4,_0x37d6cd)=>{_0x1d765b['hasChild'](_0x2b05a4)||_0x65f4a8['trackChildChange'](Lt(_0x2b05a4,_0x37d6cd));}),_0x1d765b['isLeafNode']()||_0x1d765b['forEachChild'](R,(_0x27acc8,_0x14ba66)=>{if(_0xb17c76['hasChild'](_0x27acc8)){const _0x2b7104=_0xb17c76['getImmediateChild'](_0x27acc8);_0x2b7104['equals'](_0x14ba66)||_0x65f4a8['trackChildChange'](xt(_0x27acc8,_0x14ba66,_0x2b7104));}else _0x65f4a8['trackChildChange'](rt(_0x27acc8,_0x14ba66));})),_0x1d765b['withIndex'](this['index_']);}['updatePriority'](_0x5d922d,_0x3f7a8e){return _0x5d922d['isEmpty']()?g['EMPTY_NODE']:_0x5d922d['updatePriority'](_0x3f7a8e);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x40373b){this['indexedFilter_']=new Xi(_0x40373b['getIndex']()),this['index_']=_0x40373b['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x40373b),this['endPost_']=Ft['getEndPost_'](_0x40373b),this['startIsInclusive_']=!_0x40373b['startAfterSet_'],this['endIsInclusive_']=!_0x40373b['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x33d12f){const _0x4155eb=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x33d12f)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x33d12f)<0x0,_0x5a27e5=this['endIsInclusive_']?this['index_']['compare'](_0x33d12f,this['getEndPost']())<=0x0:this['index_']['compare'](_0x33d12f,this['getEndPost']())<0x0;return _0x4155eb&&_0x5a27e5;}['updateChild'](_0x331963,_0x432905,_0x4a5389,_0x54d92f,_0xb355b2,_0x5d3a09){return this['matches'](new E(_0x432905,_0x4a5389))||(_0x4a5389=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x331963,_0x432905,_0x4a5389,_0x54d92f,_0xb355b2,_0x5d3a09);}['updateFullNode'](_0xa455cb,_0x59205d,_0x57818e){_0x59205d['isLeafNode']()&&(_0x59205d=g['EMPTY_NODE']);let _0x562f50=_0x59205d['withIndex'](this['index_']);_0x562f50=_0x562f50['updatePriority'](g['EMPTY_NODE']);const _0x1c40f5=this;return _0x59205d['forEachChild'](R,(_0x45f926,_0xd558d3)=>{_0x1c40f5['matches'](new E(_0x45f926,_0xd558d3))||(_0x562f50=_0x562f50['updateImmediateChild'](_0x45f926,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0xa455cb,_0x562f50,_0x57818e);}['updatePriority'](_0x29f427,_0x2ca81b){return _0x29f427;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x4ccf12){if(_0x4ccf12['hasStart']()){const _0x2710d2=_0x4ccf12['getIndexStartName']();return _0x4ccf12['getIndex']()['makePost'](_0x4ccf12['getIndexStartValue'](),_0x2710d2);}else return _0x4ccf12['getIndex']()['minPost']();}static['getEndPost_'](_0x45de1b){if(_0x45de1b['hasEnd']()){const _0x530f5f=_0x45de1b['getIndexEndName']();return _0x45de1b['getIndex']()['makePost'](_0x45de1b['getIndexEndValue'](),_0x530f5f);}else return _0x45de1b['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x50a732){this['withinDirectionalStart']=_0x1857d9=>this['reverse_']?this['withinEndPost'](_0x1857d9):this['withinStartPost'](_0x1857d9),this['withinDirectionalEnd']=_0x51cfa9=>this['reverse_']?this['withinStartPost'](_0x51cfa9):this['withinEndPost'](_0x51cfa9),this['withinStartPost']=_0x12411c=>{const _0x5966f7=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x12411c);return this['startIsInclusive_']?_0x5966f7<=0x0:_0x5966f7<0x0;},this['withinEndPost']=_0x5b3cd3=>{const _0x5c3248=this['index_']['compare'](_0x5b3cd3,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x5c3248<=0x0:_0x5c3248<0x0;},this['rangedFilter_']=new Ft(_0x50a732),this['index_']=_0x50a732['getIndex'](),this['limit_']=_0x50a732['getLimit'](),this['reverse_']=!_0x50a732['isViewFromLeft'](),this['startIsInclusive_']=!_0x50a732['startAfterSet_'],this['endIsInclusive_']=!_0x50a732['endBeforeSet_'];}['updateChild'](_0x3eb58a,_0x94bc78,_0x3149a4,_0x53f76c,_0x122ae8,_0x469593){return this['rangedFilter_']['matches'](new E(_0x94bc78,_0x3149a4))||(_0x3149a4=g['EMPTY_NODE']),_0x3eb58a['getImmediateChild'](_0x94bc78)['equals'](_0x3149a4)?_0x3eb58a:_0x3eb58a['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x3eb58a,_0x94bc78,_0x3149a4,_0x53f76c,_0x122ae8,_0x469593):this['fullLimitUpdateChild_'](_0x3eb58a,_0x94bc78,_0x3149a4,_0x122ae8,_0x469593);}['updateFullNode'](_0x402cd3,_0x35b417,_0x2d44c1){let _0xdfbf8;if(_0x35b417['isLeafNode']()||_0x35b417['isEmpty']())_0xdfbf8=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x35b417['numChildren']()&&_0x35b417['isIndexed'](this['index_'])){_0xdfbf8=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x7f2b7b;this['reverse_']?_0x7f2b7b=_0x35b417['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x7f2b7b=_0x35b417['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x1a23c7=0x0;for(;_0x7f2b7b['hasNext']()&&_0x1a23c7<this['limit_'];){const _0x5dcd62=_0x7f2b7b['getNext']();if(this['withinDirectionalStart'](_0x5dcd62)){if(this['withinDirectionalEnd'](_0x5dcd62))_0xdfbf8=_0xdfbf8['updateImmediateChild'](_0x5dcd62['name'],_0x5dcd62['node']),_0x1a23c7++;else break;}else continue;}}else{_0xdfbf8=_0x35b417['withIndex'](this['index_']),_0xdfbf8=_0xdfbf8['updatePriority'](g['EMPTY_NODE']);let _0x19cece;this['reverse_']?_0x19cece=_0xdfbf8['getReverseIterator'](this['index_']):_0x19cece=_0xdfbf8['getIterator'](this['index_']);let _0x577916=0x0;for(;_0x19cece['hasNext']();){const _0x542ef2=_0x19cece['getNext']();_0x577916<this['limit_']&&this['withinDirectionalStart'](_0x542ef2)&&this['withinDirectionalEnd'](_0x542ef2)?_0x577916++:_0xdfbf8=_0xdfbf8['updateImmediateChild'](_0x542ef2['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x402cd3,_0xdfbf8,_0x2d44c1);}['updatePriority'](_0x34cf65,_0x41ff1d){return _0x34cf65;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x2ef195,_0x220f27,_0x102f66,_0xfe036e,_0x1e8b9a){let _0x5eb957;if(this['reverse_']){const _0x4f62e2=this['index_']['getCompare']();_0x5eb957=(_0x5386fd,_0x16cc57)=>_0x4f62e2(_0x16cc57,_0x5386fd);}else _0x5eb957=this['index_']['getCompare']();const _0x5a7d0f=_0x2ef195;f(_0x5a7d0f['numChildren']()===this['limit_'],'');const _0x440eeb=new E(_0x220f27,_0x102f66),_0x4ce1ce=this['reverse_']?_0x5a7d0f['getFirstChild'](this['index_']):_0x5a7d0f['getLastChild'](this['index_']),_0x2c8f57=this['rangedFilter_']['matches'](_0x440eeb);if(_0x5a7d0f['hasChild'](_0x220f27)){const _0x26f47f=_0x5a7d0f['getImmediateChild'](_0x220f27);let _0x203f89=_0xfe036e['getChildAfterChild'](this['index_'],_0x4ce1ce,this['reverse_']);for(;_0x203f89!=null&&(_0x203f89['name']===_0x220f27||_0x5a7d0f['hasChild'](_0x203f89['name']));)_0x203f89=_0xfe036e['getChildAfterChild'](this['index_'],_0x203f89,this['reverse_']);const _0x54cfc8=_0x203f89==null?0x1:_0x5eb957(_0x203f89,_0x440eeb);if(_0x2c8f57&&!_0x102f66['isEmpty']()&&_0x54cfc8>=0x0)return _0x1e8b9a!=null&&_0x1e8b9a['trackChildChange'](xt(_0x220f27,_0x102f66,_0x26f47f)),_0x5a7d0f['updateImmediateChild'](_0x220f27,_0x102f66);{_0x1e8b9a!=null&&_0x1e8b9a['trackChildChange'](Lt(_0x220f27,_0x26f47f));const _0x1ca69d=_0x5a7d0f['updateImmediateChild'](_0x220f27,g['EMPTY_NODE']);return _0x203f89!=null&&this['rangedFilter_']['matches'](_0x203f89)?(_0x1e8b9a!=null&&_0x1e8b9a['trackChildChange'](rt(_0x203f89['name'],_0x203f89['node'])),_0x1ca69d['updateImmediateChild'](_0x203f89['name'],_0x203f89['node'])):_0x1ca69d;}}else return _0x102f66['isEmpty']()?_0x2ef195:_0x2c8f57&&_0x5eb957(_0x4ce1ce,_0x440eeb)>=0x0?(_0x1e8b9a!=null&&(_0x1e8b9a['trackChildChange'](Lt(_0x4ce1ce['name'],_0x4ce1ce['node'])),_0x1e8b9a['trackChildChange'](rt(_0x220f27,_0x102f66))),_0x5a7d0f['updateImmediateChild'](_0x220f27,_0x102f66)['updateImmediateChild'](_0x4ce1ce['name'],g['EMPTY_NODE'])):_0x2ef195;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x1c7155=new Zi();return _0x1c7155['limitSet_']=this['limitSet_'],_0x1c7155['limit_']=this['limit_'],_0x1c7155['startSet_']=this['startSet_'],_0x1c7155['startAfterSet_']=this['startAfterSet_'],_0x1c7155['indexStartValue_']=this['indexStartValue_'],_0x1c7155['startNameSet_']=this['startNameSet_'],_0x1c7155['indexStartName_']=this['indexStartName_'],_0x1c7155['endSet_']=this['endSet_'],_0x1c7155['endBeforeSet_']=this['endBeforeSet_'],_0x1c7155['indexEndValue_']=this['indexEndValue_'],_0x1c7155['endNameSet_']=this['endNameSet_'],_0x1c7155['indexEndName_']=this['indexEndName_'],_0x1c7155['index_']=this['index_'],_0x1c7155['viewFrom_']=this['viewFrom_'],_0x1c7155;}}function Kh(_0x5f5151){return _0x5f5151['loadsAllData']()?new Xi(_0x5f5151['getIndex']()):_0x5f5151['hasLimit']()?new jh(_0x5f5151):new Ft(_0x5f5151);}function Yh(_0x3a02f9,_0x3e96fb){const _0x333d0a=_0x3a02f9['copy']();return _0x333d0a['limitSet_']=!0x0,_0x333d0a['limit_']=_0x3e96fb,_0x333d0a['viewFrom_']='l',_0x333d0a;}function Qh(_0x57da1b,_0x3f5aef,_0x55c80e){const _0x9f5a4a=_0x57da1b['copy']();return _0x9f5a4a['startSet_']=!0x0,_0x3f5aef===void 0x0&&(_0x3f5aef=null),_0x9f5a4a['indexStartValue_']=_0x3f5aef,_0x55c80e!=null?(_0x9f5a4a['startNameSet_']=!0x0,_0x9f5a4a['indexStartName_']=_0x55c80e):(_0x9f5a4a['startNameSet_']=!0x1,_0x9f5a4a['indexStartName_']=''),_0x9f5a4a;}function Jh(_0xe6afa9,_0x3a4568,_0x452df8){const _0x10c50a=_0xe6afa9['copy']();return _0x10c50a['endSet_']=!0x0,_0x3a4568===void 0x0&&(_0x3a4568=null),_0x10c50a['indexEndValue_']=_0x3a4568,_0x452df8!==void 0x0?(_0x10c50a['endNameSet_']=!0x0,_0x10c50a['indexEndName_']=_0x452df8):(_0x10c50a['endNameSet_']=!0x1,_0x10c50a['indexEndName_']=''),_0x10c50a;}function xo(_0x27d279,_0x59737e){const _0x3e4817=_0x27d279['copy']();return _0x3e4817['index_']=_0x59737e,_0x3e4817;}function ir(_0x379ddf){const _0x52e3a3={};if(_0x379ddf['isDefault']())return _0x52e3a3;let _0x3224a8;if(_0x379ddf['index_']===R?_0x3224a8='$priority':_0x379ddf['index_']===Mo?_0x3224a8='$value':_0x379ddf['index_']===ve?_0x3224a8='$key':(f(_0x379ddf['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x3224a8=_0x379ddf['index_']['toString']()),_0x52e3a3['orderBy']=O(_0x3224a8),_0x379ddf['startSet_']){const _0x137dc2=_0x379ddf['startAfterSet_']?'startAfter':'startAt';_0x52e3a3[_0x137dc2]=O(_0x379ddf['indexStartValue_']),_0x379ddf['startNameSet_']&&(_0x52e3a3[_0x137dc2]+=','+O(_0x379ddf['indexStartName_']));}if(_0x379ddf['endSet_']){const _0x47b447=_0x379ddf['endBeforeSet_']?'endBefore':'endAt';_0x52e3a3[_0x47b447]=O(_0x379ddf['indexEndValue_']),_0x379ddf['endNameSet_']&&(_0x52e3a3[_0x47b447]+=','+O(_0x379ddf['indexEndName_']));}return _0x379ddf['limitSet_']&&(_0x379ddf['isViewFromLeft']()?_0x52e3a3['limitToFirst']=_0x379ddf['limit_']:_0x52e3a3['limitToLast']=_0x379ddf['limit_']),_0x52e3a3;}function sr(_0x486549){const _0x1185fa={};if(_0x486549['startSet_']&&(_0x1185fa['sp']=_0x486549['indexStartValue_'],_0x486549['startNameSet_']&&(_0x1185fa['sn']=_0x486549['indexStartName_']),_0x1185fa['sin']=!_0x486549['startAfterSet_']),_0x486549['endSet_']&&(_0x1185fa['ep']=_0x486549['indexEndValue_'],_0x486549['endNameSet_']&&(_0x1185fa['en']=_0x486549['indexEndName_']),_0x1185fa['ein']=!_0x486549['endBeforeSet_']),_0x486549['limitSet_']){_0x1185fa['l']=_0x486549['limit_'];let _0xd6b232=_0x486549['viewFrom_'];_0xd6b232===''&&(_0x486549['isViewFromLeft']()?_0xd6b232='l':_0xd6b232='r'),_0x1185fa['vf']=_0xd6b232;}return _0x486549['index_']!==R&&(_0x1185fa['i']=_0x486549['index_']['toString']()),_0x1185fa;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x29423b){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x51e201,_0x4002f2){return _0x4002f2!==void 0x0?'tag$'+_0x4002f2:(f(_0x51e201['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x51e201['_path']['toString']());}constructor(_0x9da425,_0x21f58c,_0x356f1f,_0x54c750){super(),this['repoInfo_']=_0x9da425,this['onDataUpdate_']=_0x21f58c,this['authTokenProvider_']=_0x356f1f,this['appCheckTokenProvider_']=_0x54c750,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x471fd6,_0x37fb4a,_0x15d226,_0x569862){const _0xd9146b=_0x471fd6['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0xd9146b+'\x20'+_0x471fd6['_queryIdentifier']);const _0x258545=vn['getListenId_'](_0x471fd6,_0x15d226),_0x3bbe84={};this['listens_'][_0x258545]=_0x3bbe84;const _0x19dac2=ir(_0x471fd6['_queryParams']);this['restRequest_'](_0xd9146b+'.json',_0x19dac2,(_0x27fb67,_0x1dca2a)=>{let _0xb527b7=_0x1dca2a;if(_0x27fb67===0x194&&(_0xb527b7=null,_0x27fb67=null),_0x27fb67===null&&this['onDataUpdate_'](_0xd9146b,_0xb527b7,!0x1,_0x15d226),Le(this['listens_'],_0x258545)===_0x3bbe84){let _0xeeea92;_0x27fb67?_0x27fb67===0x191?_0xeeea92='permission_denied':_0xeeea92='rest_error:'+_0x27fb67:_0xeeea92='ok',_0x569862(_0xeeea92,null);}});}['unlisten'](_0x19aab4,_0x3f18fe){const _0x573cb8=vn['getListenId_'](_0x19aab4,_0x3f18fe);delete this['listens_'][_0x573cb8];}['get'](_0x5b39e6){const _0x374254=ir(_0x5b39e6['_queryParams']),_0x183407=_0x5b39e6['_path']['toString'](),_0x351a2e=new H();return this['restRequest_'](_0x183407+'.json',_0x374254,(_0x42adda,_0x4d7a71)=>{let _0x5da875=_0x4d7a71;_0x42adda===0x194&&(_0x5da875=null,_0x42adda=null),_0x42adda===null?(this['onDataUpdate_'](_0x183407,_0x5da875,!0x1,null),_0x351a2e['resolve'](_0x5da875)):_0x351a2e['reject'](new Error(_0x5da875));}),_0x351a2e['promise'];}['refreshAuthToken'](_0x54330c){}['restRequest_'](_0x2c1ed4,_0x141237={},_0x329f26){return _0x141237['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x32aff2,_0x4f5604])=>{_0x32aff2&&_0x32aff2['accessToken']&&(_0x141237['auth']=_0x32aff2['accessToken']),_0x4f5604&&_0x4f5604['token']&&(_0x141237['ac']=_0x4f5604['token']);const _0x53a8e4=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x2c1ed4+'?ns='+this['repoInfo_']['namespace']+ut(_0x141237);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x53a8e4);const _0x5eb596=new XMLHttpRequest();_0x5eb596['onreadystatechange']=()=>{if(_0x329f26&&_0x5eb596['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x53a8e4+'\x20received.\x20status:',_0x5eb596['status'],'response:',_0x5eb596['responseText']);let _0x1191d4=null;if(_0x5eb596['status']>=0xc8&&_0x5eb596['status']<0x12c){try{_0x1191d4=Nt(_0x5eb596['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x53a8e4+':\x20'+_0x5eb596['responseText']);}_0x329f26(null,_0x1191d4);}else _0x5eb596['status']!==0x191&&_0x5eb596['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x53a8e4+'\x20Status:\x20'+_0x5eb596['status']),_0x329f26(_0x5eb596['status']);_0x329f26=null;}},_0x5eb596['open']('GET',_0x53a8e4,!0x0),_0x5eb596['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x28c0bf){return this['rootNode_']['getChild'](_0x28c0bf);}['updateSnapshot'](_0x423a8c,_0x278761){this['rootNode_']=this['rootNode_']['updateChild'](_0x423a8c,_0x278761);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x36ed70,_0x4ab37d,_0x21c4f5){if(v(_0x4ab37d))_0x36ed70['value']=_0x21c4f5,_0x36ed70['children']['clear']();else{if(_0x36ed70['value']!==null)_0x36ed70['value']=_0x36ed70['value']['updateChild'](_0x4ab37d,_0x21c4f5);else{const _0xa1eab8=y(_0x4ab37d);_0x36ed70['children']['has'](_0xa1eab8)||_0x36ed70['children']['set'](_0xa1eab8,En());const _0x43fbda=_0x36ed70['children']['get'](_0xa1eab8);_0x4ab37d=S(_0x4ab37d),pt(_0x43fbda,_0x4ab37d,_0x21c4f5);}}}function Ti(_0xf30c7f,_0x2c11c8){if(v(_0x2c11c8))return _0xf30c7f['value']=null,_0xf30c7f['children']['clear'](),!0x0;if(_0xf30c7f['value']!==null){if(_0xf30c7f['value']['isLeafNode']())return!0x1;{const _0x5a7f04=_0xf30c7f['value'];return _0xf30c7f['value']=null,_0x5a7f04['forEachChild'](R,(_0x25d970,_0x2a420b)=>{pt(_0xf30c7f,new C(_0x25d970),_0x2a420b);}),Ti(_0xf30c7f,_0x2c11c8);}}else{if(_0xf30c7f['children']['size']>0x0){const _0x35be4b=y(_0x2c11c8);return _0x2c11c8=S(_0x2c11c8),_0xf30c7f['children']['has'](_0x35be4b)&&Ti(_0xf30c7f['children']['get'](_0x35be4b),_0x2c11c8)&&_0xf30c7f['children']['delete'](_0x35be4b),_0xf30c7f['children']['size']===0x0;}else return!0x0;}}function Si(_0x5aa19b,_0x26f5b7,_0x5be49f){_0x5aa19b['value']!==null?_0x5be49f(_0x26f5b7,_0x5aa19b['value']):Zh(_0x5aa19b,(_0x2cf520,_0x1f07ba)=>{const _0x338f52=new C(_0x26f5b7['toString']()+'/'+_0x2cf520);Si(_0x1f07ba,_0x338f52,_0x5be49f);});}function Zh(_0x5ab7fe,_0x240910){_0x5ab7fe['children']['forEach']((_0x2dedbe,_0x5a583b)=>{_0x240910(_0x5a583b,_0x2dedbe);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x2a4122){this['collection_']=_0x2a4122,this['last_']=null;}['get'](){const _0x38bc82=this['collection_']['get'](),_0x2d5bc7={..._0x38bc82};return this['last_']&&x(this['last_'],(_0x505d89,_0x43b530)=>{_0x2d5bc7[_0x505d89]=_0x2d5bc7[_0x505d89]-_0x43b530;}),this['last_']=_0x38bc82,_0x2d5bc7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x43fb53,_0x4698e1){this['server_']=_0x4698e1,this['statsToReport_']={},this['statsListener_']=new eu(_0x43fb53);const _0x2ebaa5=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x2ebaa5));}['reportStats_'](){const _0x357ffa=this['statsListener_']['get'](),_0x2d677a={};let _0x286021=!0x1;x(_0x357ffa,(_0x3fa6cf,_0x191557)=>{_0x191557>0x0&&Q(this['statsToReport_'],_0x3fa6cf)&&(_0x2d677a[_0x3fa6cf]=_0x191557,_0x286021=!0x0);}),_0x286021&&this['server_']['reportStats'](_0x2d677a),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x2ba167){_0x2ba167[_0x2ba167['OVERWRITE']=0x0]='OVERWRITE',_0x2ba167[_0x2ba167['MERGE']=0x1]='MERGE',_0x2ba167[_0x2ba167['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x2ba167[_0x2ba167['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x32b1a9){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x32b1a9,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x354b7f,_0x33edf9,_0x2260be){this['path']=_0x354b7f,this['affectedTree']=_0x33edf9,this['revert']=_0x2260be,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x3107ea){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x4038d0=this['affectedTree']['subtree'](new C(_0x3107ea));return new In(w(),_0x4038d0,this['revert']);}}else return f(y(this['path'])===_0x3107ea,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x101805,_0x59770b){this['source']=_0x101805,this['path']=_0x59770b,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x19f579){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x43e958,_0x3325e9,_0x3c822f){this['source']=_0x43e958,this['path']=_0x3325e9,this['snap']=_0x3c822f,this['type']=z['OVERWRITE'];}['operationForChild'](_0x3b9643){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x3b9643)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x4761eb,_0x1024a1,_0x3f5b9a){this['source']=_0x4761eb,this['path']=_0x1024a1,this['children']=_0x3f5b9a,this['type']=z['MERGE'];}['operationForChild'](_0x1da890){if(v(this['path'])){const _0x546406=this['children']['subtree'](new C(_0x1da890));return _0x546406['isEmpty']()?null:_0x546406['value']?new Be(this['source'],w(),_0x546406['value']):new ot(this['source'],w(),_0x546406);}else return f(y(this['path'])===_0x1da890,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x114545,_0x364d02,_0x484c3d){this['node_']=_0x114545,this['fullyInitialized_']=_0x364d02,this['filtered_']=_0x484c3d;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x4ca8d8){if(v(_0x4ca8d8))return this['isFullyInitialized']()&&!this['filtered_'];const _0x3b9961=y(_0x4ca8d8);return this['isCompleteForChild'](_0x3b9961);}['isCompleteForChild'](_0x2374bb){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x2374bb);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x7a0f24){this['query_']=_0x7a0f24,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x55d653,_0x178e06,_0xf0bc63,_0xbfcb76){const _0x30604a=[],_0x2cd2c8=[];return _0x178e06['forEach'](_0x21f4bb=>{_0x21f4bb['type']==='child_changed'&&_0x55d653['index_']['indexedValueChanged'](_0x21f4bb['oldSnap'],_0x21f4bb['snapshotNode'])&&_0x2cd2c8['push'](zh(_0x21f4bb['childName'],_0x21f4bb['snapshotNode']));}),wt(_0x55d653,_0x30604a,'child_removed',_0x178e06,_0xbfcb76,_0xf0bc63),wt(_0x55d653,_0x30604a,'child_added',_0x178e06,_0xbfcb76,_0xf0bc63),wt(_0x55d653,_0x30604a,'child_moved',_0x2cd2c8,_0xbfcb76,_0xf0bc63),wt(_0x55d653,_0x30604a,'child_changed',_0x178e06,_0xbfcb76,_0xf0bc63),wt(_0x55d653,_0x30604a,'value',_0x178e06,_0xbfcb76,_0xf0bc63),_0x30604a;}function wt(_0x47a979,_0x3d7fb,_0x4e6e3a,_0x111f8a,_0x54ebcd,_0xc9fee0){const _0x31ce4c=_0x111f8a['filter'](_0xbeb81e=>_0xbeb81e['type']===_0x4e6e3a);_0x31ce4c['sort']((_0x2436bb,_0x36bc1e)=>au(_0x47a979,_0x2436bb,_0x36bc1e)),_0x31ce4c['forEach'](_0x810572=>{const _0x1f0ad3=ou(_0x47a979,_0x810572,_0xc9fee0);_0x54ebcd['forEach'](_0x417b02=>{_0x417b02['respondsTo'](_0x810572['type'])&&_0x3d7fb['push'](_0x417b02['createEvent'](_0x1f0ad3,_0x47a979['query_']));});});}function ou(_0x4a869a,_0x1daf92,_0x385aa9){return _0x1daf92['type']==='value'||_0x1daf92['type']==='child_removed'||(_0x1daf92['prevName']=_0x385aa9['getPredecessorChildName'](_0x1daf92['childName'],_0x1daf92['snapshotNode'],_0x4a869a['index_'])),_0x1daf92;}function au(_0x352d6d,_0x5aadd4,_0x329e0b){if(_0x5aadd4['childName']==null||_0x329e0b['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x1cda8d=new E(_0x5aadd4['childName'],_0x5aadd4['snapshotNode']),_0x547606=new E(_0x329e0b['childName'],_0x329e0b['snapshotNode']);return _0x352d6d['index_']['compare'](_0x1cda8d,_0x547606);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x303469,_0x8b6990){return{'eventCache':_0x303469,'serverCache':_0x8b6990};}function Rt(_0xa97f47,_0x39e08f,_0x59496a,_0x81ad5a){return Un(new Te(_0x39e08f,_0x59496a,_0x81ad5a),_0xa97f47['serverCache']);}function Fo(_0x279518,_0x255ec9,_0x90b23b,_0x4a31a8){return Un(_0x279518['eventCache'],new Te(_0x255ec9,_0x90b23b,_0x4a31a8));}function wn(_0x49ddf5){return _0x49ddf5['eventCache']['isFullyInitialized']()?_0x49ddf5['eventCache']['getNode']():null;}function Ve(_0x3c5c8a){return _0x3c5c8a['serverCache']['isFullyInitialized']()?_0x3c5c8a['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0xfb4c38){let _0x500194=new b(null);return x(_0xfb4c38,(_0x46b875,_0x5cbcd6)=>{_0x500194=_0x500194['set'](new C(_0x46b875),_0x5cbcd6);}),_0x500194;}constructor(_0x3b61c1,_0x1482e9=cu()){this['value']=_0x3b61c1,this['children']=_0x1482e9;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x2bd102,_0x5c4ad9){if(this['value']!=null&&_0x5c4ad9(this['value']))return{'path':w(),'value':this['value']};if(v(_0x2bd102))return null;{const _0x2cc4b6=y(_0x2bd102),_0x5de790=this['children']['get'](_0x2cc4b6);if(_0x5de790!==null){const _0x325ed9=_0x5de790['findRootMostMatchingPathAndValue'](S(_0x2bd102),_0x5c4ad9);return _0x325ed9!=null?{'path':k(new C(_0x2cc4b6),_0x325ed9['path']),'value':_0x325ed9['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x5d1895){return this['findRootMostMatchingPathAndValue'](_0x5d1895,()=>!0x0);}['subtree'](_0x2a3555){if(v(_0x2a3555))return this;{const _0x192146=y(_0x2a3555),_0x30bc7a=this['children']['get'](_0x192146);return _0x30bc7a!==null?_0x30bc7a['subtree'](S(_0x2a3555)):new b(null);}}['set'](_0x3b514a,_0x12d089){if(v(_0x3b514a))return new b(_0x12d089,this['children']);{const _0x403895=y(_0x3b514a),_0x433f02=(this['children']['get'](_0x403895)||new b(null))['set'](S(_0x3b514a),_0x12d089),_0x2faeab=this['children']['insert'](_0x403895,_0x433f02);return new b(this['value'],_0x2faeab);}}['remove'](_0x54cae2){if(v(_0x54cae2))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x2361b2=y(_0x54cae2),_0x75f18a=this['children']['get'](_0x2361b2);if(_0x75f18a){const _0x5eb56a=_0x75f18a['remove'](S(_0x54cae2));let _0x2d4f33;return _0x5eb56a['isEmpty']()?_0x2d4f33=this['children']['remove'](_0x2361b2):_0x2d4f33=this['children']['insert'](_0x2361b2,_0x5eb56a),this['value']===null&&_0x2d4f33['isEmpty']()?new b(null):new b(this['value'],_0x2d4f33);}else return this;}}['get'](_0x72395c){if(v(_0x72395c))return this['value'];{const _0x1f5e10=y(_0x72395c),_0xd6d20a=this['children']['get'](_0x1f5e10);return _0xd6d20a?_0xd6d20a['get'](S(_0x72395c)):null;}}['setTree'](_0xedea6b,_0x7bcf41){if(v(_0xedea6b))return _0x7bcf41;{const _0x54681e=y(_0xedea6b),_0x3116ad=(this['children']['get'](_0x54681e)||new b(null))['setTree'](S(_0xedea6b),_0x7bcf41);let _0x356c75;return _0x3116ad['isEmpty']()?_0x356c75=this['children']['remove'](_0x54681e):_0x356c75=this['children']['insert'](_0x54681e,_0x3116ad),new b(this['value'],_0x356c75);}}['fold'](_0x49accd){return this['fold_'](w(),_0x49accd);}['fold_'](_0x265de4,_0x4a7a80){const _0x4b7e3b={};return this['children']['inorderTraversal']((_0xf1878b,_0x51bd61)=>{_0x4b7e3b[_0xf1878b]=_0x51bd61['fold_'](k(_0x265de4,_0xf1878b),_0x4a7a80);}),_0x4a7a80(_0x265de4,this['value'],_0x4b7e3b);}['findOnPath'](_0x3e7192,_0x5b10d6){return this['findOnPath_'](_0x3e7192,w(),_0x5b10d6);}['findOnPath_'](_0x179070,_0x1c92be,_0x37b5f7){const _0x3d623b=this['value']?_0x37b5f7(_0x1c92be,this['value']):!0x1;if(_0x3d623b)return _0x3d623b;if(v(_0x179070))return null;{const _0x4f9591=y(_0x179070),_0x299f07=this['children']['get'](_0x4f9591);return _0x299f07?_0x299f07['findOnPath_'](S(_0x179070),k(_0x1c92be,_0x4f9591),_0x37b5f7):null;}}['foreachOnPath'](_0x31b818,_0xfa4305){return this['foreachOnPath_'](_0x31b818,w(),_0xfa4305);}['foreachOnPath_'](_0x44ef99,_0x3cef7b,_0x430df7){if(v(_0x44ef99))return this;{this['value']&&_0x430df7(_0x3cef7b,this['value']);const _0x24ca37=y(_0x44ef99),_0x1b42e7=this['children']['get'](_0x24ca37);return _0x1b42e7?_0x1b42e7['foreachOnPath_'](S(_0x44ef99),k(_0x3cef7b,_0x24ca37),_0x430df7):new b(null);}}['foreach'](_0xcc7137){this['foreach_'](w(),_0xcc7137);}['foreach_'](_0x1dbf43,_0x56ff17){this['children']['inorderTraversal']((_0x28b129,_0x4a9214)=>{_0x4a9214['foreach_'](k(_0x1dbf43,_0x28b129),_0x56ff17);}),this['value']&&_0x56ff17(_0x1dbf43,this['value']);}['foreachChild'](_0x14b34b){this['children']['inorderTraversal']((_0x1c33c2,_0x505aa9)=>{_0x505aa9['value']&&_0x14b34b(_0x1c33c2,_0x505aa9['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x25a299){this['writeTree_']=_0x25a299;}static['empty'](){return new K(new b(null));}}function At(_0x534e53,_0x1d59da,_0x18d2a8){if(v(_0x1d59da))return new K(new b(_0x18d2a8));{const _0x5a85c0=_0x534e53['writeTree_']['findRootMostValueAndPath'](_0x1d59da);if(_0x5a85c0!=null){const _0x57c977=_0x5a85c0['path'];let _0x1caa4c=_0x5a85c0['value'];const _0x239adb=F(_0x57c977,_0x1d59da);return _0x1caa4c=_0x1caa4c['updateChild'](_0x239adb,_0x18d2a8),new K(_0x534e53['writeTree_']['set'](_0x57c977,_0x1caa4c));}else{const _0x481491=new b(_0x18d2a8),_0x378515=_0x534e53['writeTree_']['setTree'](_0x1d59da,_0x481491);return new K(_0x378515);}}}function bi(_0x2fd828,_0x218f10,_0x103409){let _0x4c0ac9=_0x2fd828;return x(_0x103409,(_0x5f079c,_0x57d47c)=>{_0x4c0ac9=At(_0x4c0ac9,k(_0x218f10,_0x5f079c),_0x57d47c);}),_0x4c0ac9;}function or(_0x15e631,_0x41da55){if(v(_0x41da55))return K['empty']();{const _0x18e87c=_0x15e631['writeTree_']['setTree'](_0x41da55,new b(null));return new K(_0x18e87c);}}function Ri(_0x5d81f7,_0x2c46fb){return ze(_0x5d81f7,_0x2c46fb)!=null;}function ze(_0x32f70d,_0x32c265){const _0x445b59=_0x32f70d['writeTree_']['findRootMostValueAndPath'](_0x32c265);return _0x445b59!=null?_0x32f70d['writeTree_']['get'](_0x445b59['path'])['getChild'](F(_0x445b59['path'],_0x32c265)):null;}function ar(_0x23f1e8){const _0x352da6=[],_0x48a5ef=_0x23f1e8['writeTree_']['value'];return _0x48a5ef!=null?_0x48a5ef['isLeafNode']()||_0x48a5ef['forEachChild'](R,(_0x14973a,_0x114b01)=>{_0x352da6['push'](new E(_0x14973a,_0x114b01));}):_0x23f1e8['writeTree_']['children']['inorderTraversal']((_0x196b5e,_0x3a80b1)=>{_0x3a80b1['value']!=null&&_0x352da6['push'](new E(_0x196b5e,_0x3a80b1['value']));}),_0x352da6;}function Ee(_0x2d2ec8,_0x4948ac){if(v(_0x4948ac))return _0x2d2ec8;{const _0x3abf60=ze(_0x2d2ec8,_0x4948ac);return _0x3abf60!=null?new K(new b(_0x3abf60)):new K(_0x2d2ec8['writeTree_']['subtree'](_0x4948ac));}}function Ai(_0x57ba56){return _0x57ba56['writeTree_']['isEmpty']();}function at(_0x5c17e0,_0x40e349){return Uo(w(),_0x5c17e0['writeTree_'],_0x40e349);}function Uo(_0x3fbaa0,_0x518aa9,_0xcb199e){if(_0x518aa9['value']!=null)return _0xcb199e['updateChild'](_0x3fbaa0,_0x518aa9['value']);{let _0xb2dddc=null;return _0x518aa9['children']['inorderTraversal']((_0x3afed8,_0x37d8e3)=>{_0x3afed8==='.priority'?(f(_0x37d8e3['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0xb2dddc=_0x37d8e3['value']):_0xcb199e=Uo(k(_0x3fbaa0,_0x3afed8),_0x37d8e3,_0xcb199e);}),!_0xcb199e['getChild'](_0x3fbaa0)['isEmpty']()&&_0xb2dddc!==null&&(_0xcb199e=_0xcb199e['updateChild'](k(_0x3fbaa0,'.priority'),_0xb2dddc)),_0xcb199e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x1c19ad,_0x224a49){return Ho(_0x224a49,_0x1c19ad);}function lu(_0x355c9e,_0x1dec88,_0x68b40b,_0x369f78,_0x3c234d){f(_0x369f78>_0x355c9e['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x3c234d===void 0x0&&(_0x3c234d=!0x0),_0x355c9e['allWrites']['push']({'path':_0x1dec88,'snap':_0x68b40b,'writeId':_0x369f78,'visible':_0x3c234d}),_0x3c234d&&(_0x355c9e['visibleWrites']=At(_0x355c9e['visibleWrites'],_0x1dec88,_0x68b40b)),_0x355c9e['lastWriteId']=_0x369f78;}function hu(_0x4a548f,_0x58854a,_0x55f9b6,_0x50f5e9){f(_0x50f5e9>_0x4a548f['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x4a548f['allWrites']['push']({'path':_0x58854a,'children':_0x55f9b6,'writeId':_0x50f5e9,'visible':!0x0}),_0x4a548f['visibleWrites']=bi(_0x4a548f['visibleWrites'],_0x58854a,_0x55f9b6),_0x4a548f['lastWriteId']=_0x50f5e9;}function uu(_0x3fd8a5,_0x40ce40){for(let _0xbefc11=0x0;_0xbefc11<_0x3fd8a5['allWrites']['length'];_0xbefc11++){const _0x4c4b19=_0x3fd8a5['allWrites'][_0xbefc11];if(_0x4c4b19['writeId']===_0x40ce40)return _0x4c4b19;}return null;}function du(_0x49d81e,_0x437aa7){const _0x1241fe=_0x49d81e['allWrites']['findIndex'](_0x3b4528=>_0x3b4528['writeId']===_0x437aa7);f(_0x1241fe>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x4ce5b5=_0x49d81e['allWrites'][_0x1241fe];_0x49d81e['allWrites']['splice'](_0x1241fe,0x1);let _0x346b04=_0x4ce5b5['visible'],_0x4f6860=!0x1,_0x4b64a9=_0x49d81e['allWrites']['length']-0x1;for(;_0x346b04&&_0x4b64a9>=0x0;){const _0x3643da=_0x49d81e['allWrites'][_0x4b64a9];_0x3643da['visible']&&(_0x4b64a9>=_0x1241fe&&fu(_0x3643da,_0x4ce5b5['path'])?_0x346b04=!0x1:G(_0x4ce5b5['path'],_0x3643da['path'])&&(_0x4f6860=!0x0)),_0x4b64a9--;}if(_0x346b04){if(_0x4f6860)return pu(_0x49d81e),!0x0;if(_0x4ce5b5['snap'])_0x49d81e['visibleWrites']=or(_0x49d81e['visibleWrites'],_0x4ce5b5['path']);else{const _0x387d29=_0x4ce5b5['children'];x(_0x387d29,_0x4a0b40=>{_0x49d81e['visibleWrites']=or(_0x49d81e['visibleWrites'],k(_0x4ce5b5['path'],_0x4a0b40));});}return!0x0;}else return!0x1;}function fu(_0x148d22,_0x2e85a3){if(_0x148d22['snap'])return G(_0x148d22['path'],_0x2e85a3);for(const _0x20ffd2 in _0x148d22['children'])if(_0x148d22['children']['hasOwnProperty'](_0x20ffd2)&&G(k(_0x148d22['path'],_0x20ffd2),_0x2e85a3))return!0x0;return!0x1;}function pu(_0x252848){_0x252848['visibleWrites']=Wo(_0x252848['allWrites'],_u,w()),_0x252848['allWrites']['length']>0x0?_0x252848['lastWriteId']=_0x252848['allWrites'][_0x252848['allWrites']['length']-0x1]['writeId']:_0x252848['lastWriteId']=-0x1;}function _u(_0x334f19){return _0x334f19['visible'];}function Wo(_0x228611,_0x119263,_0x55dd6b){let _0xec32c5=K['empty']();for(let _0x488421=0x0;_0x488421<_0x228611['length'];++_0x488421){const _0x4ae7b6=_0x228611[_0x488421];if(_0x119263(_0x4ae7b6)){const _0x253e8c=_0x4ae7b6['path'];let _0x233fef;if(_0x4ae7b6['snap'])G(_0x55dd6b,_0x253e8c)?(_0x233fef=F(_0x55dd6b,_0x253e8c),_0xec32c5=At(_0xec32c5,_0x233fef,_0x4ae7b6['snap'])):G(_0x253e8c,_0x55dd6b)&&(_0x233fef=F(_0x253e8c,_0x55dd6b),_0xec32c5=At(_0xec32c5,w(),_0x4ae7b6['snap']['getChild'](_0x233fef)));else{if(_0x4ae7b6['children']){if(G(_0x55dd6b,_0x253e8c))_0x233fef=F(_0x55dd6b,_0x253e8c),_0xec32c5=bi(_0xec32c5,_0x233fef,_0x4ae7b6['children']);else{if(G(_0x253e8c,_0x55dd6b)){if(_0x233fef=F(_0x253e8c,_0x55dd6b),v(_0x233fef))_0xec32c5=bi(_0xec32c5,w(),_0x4ae7b6['children']);else{const _0x8286f1=Le(_0x4ae7b6['children'],y(_0x233fef));if(_0x8286f1){const _0x28e2ae=_0x8286f1['getChild'](S(_0x233fef));_0xec32c5=At(_0xec32c5,w(),_0x28e2ae);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0xec32c5;}function Bo(_0xd59e74,_0x1bb6e6,_0x54963b,_0x12e0ef,_0x119c12){if(!_0x12e0ef&&!_0x119c12){const _0x268fbc=ze(_0xd59e74['visibleWrites'],_0x1bb6e6);if(_0x268fbc!=null)return _0x268fbc;{const _0x48a3e9=Ee(_0xd59e74['visibleWrites'],_0x1bb6e6);if(Ai(_0x48a3e9))return _0x54963b;if(_0x54963b==null&&!Ri(_0x48a3e9,w()))return null;{const _0x18ced1=_0x54963b||g['EMPTY_NODE'];return at(_0x48a3e9,_0x18ced1);}}}else{const _0x525b93=Ee(_0xd59e74['visibleWrites'],_0x1bb6e6);if(!_0x119c12&&Ai(_0x525b93))return _0x54963b;if(!_0x119c12&&_0x54963b==null&&!Ri(_0x525b93,w()))return null;{const _0x55ecd4=function(_0x530db4){return(_0x530db4['visible']||_0x119c12)&&(!_0x12e0ef||!~_0x12e0ef['indexOf'](_0x530db4['writeId']))&&(G(_0x530db4['path'],_0x1bb6e6)||G(_0x1bb6e6,_0x530db4['path']));},_0x490a5a=Wo(_0xd59e74['allWrites'],_0x55ecd4,_0x1bb6e6),_0xb3466f=_0x54963b||g['EMPTY_NODE'];return at(_0x490a5a,_0xb3466f);}}}function gu(_0xd907f1,_0x32df09,_0x15466c){let _0x581e17=g['EMPTY_NODE'];const _0x3d88f1=ze(_0xd907f1['visibleWrites'],_0x32df09);if(_0x3d88f1)return _0x3d88f1['isLeafNode']()||_0x3d88f1['forEachChild'](R,(_0x2e316b,_0x11dd04)=>{_0x581e17=_0x581e17['updateImmediateChild'](_0x2e316b,_0x11dd04);}),_0x581e17;if(_0x15466c){const _0x544702=Ee(_0xd907f1['visibleWrites'],_0x32df09);return _0x15466c['forEachChild'](R,(_0x13a247,_0x5b2e87)=>{const _0x5e47d3=at(Ee(_0x544702,new C(_0x13a247)),_0x5b2e87);_0x581e17=_0x581e17['updateImmediateChild'](_0x13a247,_0x5e47d3);}),ar(_0x544702)['forEach'](_0x3a36cb=>{_0x581e17=_0x581e17['updateImmediateChild'](_0x3a36cb['name'],_0x3a36cb['node']);}),_0x581e17;}else{const _0x110718=Ee(_0xd907f1['visibleWrites'],_0x32df09);return ar(_0x110718)['forEach'](_0x133ba5=>{_0x581e17=_0x581e17['updateImmediateChild'](_0x133ba5['name'],_0x133ba5['node']);}),_0x581e17;}}function mu(_0x3ac1bf,_0x5b055f,_0x2c8b76,_0x307aef,_0x1d85f9){f(_0x307aef||_0x1d85f9,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x5cb035=k(_0x5b055f,_0x2c8b76);if(Ri(_0x3ac1bf['visibleWrites'],_0x5cb035))return null;{const _0xa77dcf=Ee(_0x3ac1bf['visibleWrites'],_0x5cb035);return Ai(_0xa77dcf)?_0x1d85f9['getChild'](_0x2c8b76):at(_0xa77dcf,_0x1d85f9['getChild'](_0x2c8b76));}}function yu(_0x12330e,_0x2faec7,_0x1acbd5,_0x4e1305){const _0x1b4a07=k(_0x2faec7,_0x1acbd5),_0x3a0652=ze(_0x12330e['visibleWrites'],_0x1b4a07);if(_0x3a0652!=null)return _0x3a0652;if(_0x4e1305['isCompleteForChild'](_0x1acbd5)){const _0x866af8=Ee(_0x12330e['visibleWrites'],_0x1b4a07);return at(_0x866af8,_0x4e1305['getNode']()['getImmediateChild'](_0x1acbd5));}else return null;}function vu(_0x4f7a29,_0x34d0d9){return ze(_0x4f7a29['visibleWrites'],_0x34d0d9);}function Eu(_0x3b9176,_0x21d4ad,_0x450c95,_0x24b5ea,_0x1ab83d,_0x5aa945,_0x50b339){let _0x3ae5cf;const _0x234c44=Ee(_0x3b9176['visibleWrites'],_0x21d4ad),_0x78ac41=ze(_0x234c44,w());if(_0x78ac41!=null)_0x3ae5cf=_0x78ac41;else{if(_0x450c95!=null)_0x3ae5cf=at(_0x234c44,_0x450c95);else return[];}if(_0x3ae5cf=_0x3ae5cf['withIndex'](_0x50b339),!_0x3ae5cf['isEmpty']()&&!_0x3ae5cf['isLeafNode']()){const _0xe0f786=[],_0x10e6fc=_0x50b339['getCompare'](),_0x285e46=_0x5aa945?_0x3ae5cf['getReverseIteratorFrom'](_0x24b5ea,_0x50b339):_0x3ae5cf['getIteratorFrom'](_0x24b5ea,_0x50b339);let _0x5a579f=_0x285e46['getNext']();for(;_0x5a579f&&_0xe0f786['length']<_0x1ab83d;)_0x10e6fc(_0x5a579f,_0x24b5ea)!==0x0&&_0xe0f786['push'](_0x5a579f),_0x5a579f=_0x285e46['getNext']();return _0xe0f786;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x132601,_0x25f73a,_0x36a992,_0x2c522d){return Bo(_0x132601['writeTree'],_0x132601['treePath'],_0x25f73a,_0x36a992,_0x2c522d);}function is(_0x277a84,_0x101c7d){return gu(_0x277a84['writeTree'],_0x277a84['treePath'],_0x101c7d);}function cr(_0x18414e,_0x5954a7,_0x30d06b,_0x46303f){return mu(_0x18414e['writeTree'],_0x18414e['treePath'],_0x5954a7,_0x30d06b,_0x46303f);}function Tn(_0x3bbd3a,_0xfbb64e){return vu(_0x3bbd3a['writeTree'],k(_0x3bbd3a['treePath'],_0xfbb64e));}function wu(_0x5c0c2b,_0x175ec7,_0x4a7589,_0x438200,_0x1c6e1e,_0xe08259){return Eu(_0x5c0c2b['writeTree'],_0x5c0c2b['treePath'],_0x175ec7,_0x4a7589,_0x438200,_0x1c6e1e,_0xe08259);}function ss(_0x419c03,_0x1c7762,_0x25f7f8){return yu(_0x419c03['writeTree'],_0x419c03['treePath'],_0x1c7762,_0x25f7f8);}function Vo(_0x14f274,_0x4f5cc0){return Ho(k(_0x14f274['treePath'],_0x4f5cc0),_0x14f274['writeTree']);}function Ho(_0x45e87a,_0x133aff){return{'treePath':_0x45e87a,'writeTree':_0x133aff};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x4880a1){const _0x16967f=_0x4880a1['type'],_0x51d1ab=_0x4880a1['childName'];f(_0x16967f==='child_added'||_0x16967f==='child_changed'||_0x16967f==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x51d1ab!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x433e5e=this['changeMap']['get'](_0x51d1ab);if(_0x433e5e){const _0x3843bf=_0x433e5e['type'];if(_0x16967f==='child_added'&&_0x3843bf==='child_removed')this['changeMap']['set'](_0x51d1ab,xt(_0x51d1ab,_0x4880a1['snapshotNode'],_0x433e5e['snapshotNode']));else{if(_0x16967f==='child_removed'&&_0x3843bf==='child_added')this['changeMap']['delete'](_0x51d1ab);else{if(_0x16967f==='child_removed'&&_0x3843bf==='child_changed')this['changeMap']['set'](_0x51d1ab,Lt(_0x51d1ab,_0x433e5e['oldSnap']));else{if(_0x16967f==='child_changed'&&_0x3843bf==='child_added')this['changeMap']['set'](_0x51d1ab,rt(_0x51d1ab,_0x4880a1['snapshotNode']));else{if(_0x16967f==='child_changed'&&_0x3843bf==='child_changed')this['changeMap']['set'](_0x51d1ab,xt(_0x51d1ab,_0x4880a1['snapshotNode'],_0x433e5e['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x4880a1+'\x20occurred\x20after\x20'+_0x433e5e);}}}}}else this['changeMap']['set'](_0x51d1ab,_0x4880a1);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x412a6f){return null;}['getChildAfterChild'](_0x1a89d6,_0x165ae4,_0x7944bd){return null;}}const $o=new Tu();class rs{constructor(_0x21b055,_0x5b1b52,_0x5ebd4d=null){this['writes_']=_0x21b055,this['viewCache_']=_0x5b1b52,this['optCompleteServerCache_']=_0x5ebd4d;}['getCompleteChild'](_0x5463f8){const _0x3e8f9e=this['viewCache_']['eventCache'];if(_0x3e8f9e['isCompleteForChild'](_0x5463f8))return _0x3e8f9e['getNode']()['getImmediateChild'](_0x5463f8);{const _0x2bd929=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x5463f8,_0x2bd929);}}['getChildAfterChild'](_0x4d1c9f,_0x2dacce,_0x1f1c4e){const _0x4e0034=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x500547=wu(this['writes_'],_0x4e0034,_0x2dacce,0x1,_0x1f1c4e,_0x4d1c9f);return _0x500547['length']===0x0?null:_0x500547[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x1723fe){return{'filter':_0x1723fe};}function bu(_0x1dc4a7,_0x569d37){f(_0x569d37['eventCache']['getNode']()['isIndexed'](_0x1dc4a7['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x569d37['serverCache']['getNode']()['isIndexed'](_0x1dc4a7['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x327f0d,_0xcaf920,_0x4c0eb4,_0x3648d8,_0x80d998){const _0x409814=new Cu();let _0x1eca63,_0x1f8030;if(_0x4c0eb4['type']===z['OVERWRITE']){const _0x53d9be=_0x4c0eb4;_0x53d9be['source']['fromUser']?_0x1eca63=ki(_0x327f0d,_0xcaf920,_0x53d9be['path'],_0x53d9be['snap'],_0x3648d8,_0x80d998,_0x409814):(f(_0x53d9be['source']['fromServer'],'Unknown\x20source.'),_0x1f8030=_0x53d9be['source']['tagged']||_0xcaf920['serverCache']['isFiltered']()&&!v(_0x53d9be['path']),_0x1eca63=Sn(_0x327f0d,_0xcaf920,_0x53d9be['path'],_0x53d9be['snap'],_0x3648d8,_0x80d998,_0x1f8030,_0x409814));}else{if(_0x4c0eb4['type']===z['MERGE']){const _0x49aa87=_0x4c0eb4;_0x49aa87['source']['fromUser']?_0x1eca63=ku(_0x327f0d,_0xcaf920,_0x49aa87['path'],_0x49aa87['children'],_0x3648d8,_0x80d998,_0x409814):(f(_0x49aa87['source']['fromServer'],'Unknown\x20source.'),_0x1f8030=_0x49aa87['source']['tagged']||_0xcaf920['serverCache']['isFiltered'](),_0x1eca63=Pi(_0x327f0d,_0xcaf920,_0x49aa87['path'],_0x49aa87['children'],_0x3648d8,_0x80d998,_0x1f8030,_0x409814));}else{if(_0x4c0eb4['type']===z['ACK_USER_WRITE']){const _0x148bc8=_0x4c0eb4;_0x148bc8['revert']?_0x1eca63=Ou(_0x327f0d,_0xcaf920,_0x148bc8['path'],_0x3648d8,_0x80d998,_0x409814):_0x1eca63=Pu(_0x327f0d,_0xcaf920,_0x148bc8['path'],_0x148bc8['affectedTree'],_0x3648d8,_0x80d998,_0x409814);}else{if(_0x4c0eb4['type']===z['LISTEN_COMPLETE'])_0x1eca63=Nu(_0x327f0d,_0xcaf920,_0x4c0eb4['path'],_0x3648d8,_0x409814);else throw ht('Unknown\x20operation\x20type:\x20'+_0x4c0eb4['type']);}}}const _0x9bbb76=_0x409814['getChanges']();return Au(_0xcaf920,_0x1eca63,_0x9bbb76),{'viewCache':_0x1eca63,'changes':_0x9bbb76};}function Au(_0x7ba8dc,_0x104121,_0x217fb5){const _0x1b0d56=_0x104121['eventCache'];if(_0x1b0d56['isFullyInitialized']()){const _0x24fa57=_0x1b0d56['getNode']()['isLeafNode']()||_0x1b0d56['getNode']()['isEmpty'](),_0x217b8f=wn(_0x7ba8dc);(_0x217fb5['length']>0x0||!_0x7ba8dc['eventCache']['isFullyInitialized']()||_0x24fa57&&!_0x1b0d56['getNode']()['equals'](_0x217b8f)||!_0x1b0d56['getNode']()['getPriority']()['equals'](_0x217b8f['getPriority']()))&&_0x217fb5['push'](Lo(wn(_0x104121)));}}function Go(_0x45d4c7,_0x5a5559,_0x396dd2,_0x34af44,_0x2418d2,_0x48794a){const _0x11b29f=_0x5a5559['eventCache'];if(Tn(_0x34af44,_0x396dd2)!=null)return _0x5a5559;{let _0x1f84aa,_0x1818fb;if(v(_0x396dd2)){if(f(_0x5a5559['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x5a5559['serverCache']['isFiltered']()){const _0x284ff9=Ve(_0x5a5559),_0x2d644c=_0x284ff9 instanceof g?_0x284ff9:g['EMPTY_NODE'],_0x38cad1=is(_0x34af44,_0x2d644c);_0x1f84aa=_0x45d4c7['filter']['updateFullNode'](_0x5a5559['eventCache']['getNode'](),_0x38cad1,_0x48794a);}else{const _0x52a068=Cn(_0x34af44,Ve(_0x5a5559));_0x1f84aa=_0x45d4c7['filter']['updateFullNode'](_0x5a5559['eventCache']['getNode'](),_0x52a068,_0x48794a);}}else{const _0x5bfbcb=y(_0x396dd2);if(_0x5bfbcb==='.priority'){f(Ce(_0x396dd2)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x41ebb2=_0x11b29f['getNode']();_0x1818fb=_0x5a5559['serverCache']['getNode']();const _0xfb4827=cr(_0x34af44,_0x396dd2,_0x41ebb2,_0x1818fb);_0xfb4827!=null?_0x1f84aa=_0x45d4c7['filter']['updatePriority'](_0x41ebb2,_0xfb4827):_0x1f84aa=_0x11b29f['getNode']();}else{const _0x5247a2=S(_0x396dd2);let _0x4cbffb;if(_0x11b29f['isCompleteForChild'](_0x5bfbcb)){_0x1818fb=_0x5a5559['serverCache']['getNode']();const _0x1ba645=cr(_0x34af44,_0x396dd2,_0x11b29f['getNode'](),_0x1818fb);_0x1ba645!=null?_0x4cbffb=_0x11b29f['getNode']()['getImmediateChild'](_0x5bfbcb)['updateChild'](_0x5247a2,_0x1ba645):_0x4cbffb=_0x11b29f['getNode']()['getImmediateChild'](_0x5bfbcb);}else _0x4cbffb=ss(_0x34af44,_0x5bfbcb,_0x5a5559['serverCache']);_0x4cbffb!=null?_0x1f84aa=_0x45d4c7['filter']['updateChild'](_0x11b29f['getNode'](),_0x5bfbcb,_0x4cbffb,_0x5247a2,_0x2418d2,_0x48794a):_0x1f84aa=_0x11b29f['getNode']();}}return Rt(_0x5a5559,_0x1f84aa,_0x11b29f['isFullyInitialized']()||v(_0x396dd2),_0x45d4c7['filter']['filtersNodes']());}}function Sn(_0x495098,_0x3a4c09,_0x24d6f3,_0x3d72ac,_0x4d9e28,_0x2b9699,_0x313ecf,_0x1b3cd1){const _0x9857c6=_0x3a4c09['serverCache'];let _0x561d8f;const _0x494a88=_0x313ecf?_0x495098['filter']:_0x495098['filter']['getIndexedFilter']();if(v(_0x24d6f3))_0x561d8f=_0x494a88['updateFullNode'](_0x9857c6['getNode'](),_0x3d72ac,null);else{if(_0x494a88['filtersNodes']()&&!_0x9857c6['isFiltered']()){const _0x2acf66=_0x9857c6['getNode']()['updateChild'](_0x24d6f3,_0x3d72ac);_0x561d8f=_0x494a88['updateFullNode'](_0x9857c6['getNode'](),_0x2acf66,null);}else{const _0x1b54fb=y(_0x24d6f3);if(!_0x9857c6['isCompleteForPath'](_0x24d6f3)&&Ce(_0x24d6f3)>0x1)return _0x3a4c09;const _0x276ad0=S(_0x24d6f3),_0x11c197=_0x9857c6['getNode']()['getImmediateChild'](_0x1b54fb)['updateChild'](_0x276ad0,_0x3d72ac);_0x1b54fb==='.priority'?_0x561d8f=_0x494a88['updatePriority'](_0x9857c6['getNode'](),_0x11c197):_0x561d8f=_0x494a88['updateChild'](_0x9857c6['getNode'](),_0x1b54fb,_0x11c197,_0x276ad0,$o,null);}}const _0xc80133=Fo(_0x3a4c09,_0x561d8f,_0x9857c6['isFullyInitialized']()||v(_0x24d6f3),_0x494a88['filtersNodes']()),_0x512da1=new rs(_0x4d9e28,_0xc80133,_0x2b9699);return Go(_0x495098,_0xc80133,_0x24d6f3,_0x4d9e28,_0x512da1,_0x1b3cd1);}function ki(_0x33de9b,_0x3b97d6,_0x42b9e2,_0x44e755,_0x4083cc,_0x321c97,_0x52aa12){const _0x7ecd34=_0x3b97d6['eventCache'];let _0x3523f0,_0x224013;const _0x164515=new rs(_0x4083cc,_0x3b97d6,_0x321c97);if(v(_0x42b9e2))_0x224013=_0x33de9b['filter']['updateFullNode'](_0x3b97d6['eventCache']['getNode'](),_0x44e755,_0x52aa12),_0x3523f0=Rt(_0x3b97d6,_0x224013,!0x0,_0x33de9b['filter']['filtersNodes']());else{const _0x413681=y(_0x42b9e2);if(_0x413681==='.priority')_0x224013=_0x33de9b['filter']['updatePriority'](_0x3b97d6['eventCache']['getNode'](),_0x44e755),_0x3523f0=Rt(_0x3b97d6,_0x224013,_0x7ecd34['isFullyInitialized'](),_0x7ecd34['isFiltered']());else{const _0x102cab=S(_0x42b9e2),_0x1e8626=_0x7ecd34['getNode']()['getImmediateChild'](_0x413681);let _0x1c74eb;if(v(_0x102cab))_0x1c74eb=_0x44e755;else{const _0x49a91a=_0x164515['getCompleteChild'](_0x413681);_0x49a91a!=null?ji(_0x102cab)==='.priority'&&_0x49a91a['getChild'](Ro(_0x102cab))['isEmpty']()?_0x1c74eb=_0x49a91a:_0x1c74eb=_0x49a91a['updateChild'](_0x102cab,_0x44e755):_0x1c74eb=g['EMPTY_NODE'];}if(_0x1e8626['equals'](_0x1c74eb))_0x3523f0=_0x3b97d6;else{const _0xc3c6df=_0x33de9b['filter']['updateChild'](_0x7ecd34['getNode'](),_0x413681,_0x1c74eb,_0x102cab,_0x164515,_0x52aa12);_0x3523f0=Rt(_0x3b97d6,_0xc3c6df,_0x7ecd34['isFullyInitialized'](),_0x33de9b['filter']['filtersNodes']());}}}return _0x3523f0;}function lr(_0x1be342,_0x55b4f1){return _0x1be342['eventCache']['isCompleteForChild'](_0x55b4f1);}function ku(_0x1f5861,_0x1a04c6,_0x470e12,_0x439a49,_0x435079,_0x1f7234,_0xb588f3){let _0x5f0599=_0x1a04c6;return _0x439a49['foreach']((_0x2904d5,_0x3c7491)=>{const _0x382799=k(_0x470e12,_0x2904d5);lr(_0x1a04c6,y(_0x382799))&&(_0x5f0599=ki(_0x1f5861,_0x5f0599,_0x382799,_0x3c7491,_0x435079,_0x1f7234,_0xb588f3));}),_0x439a49['foreach']((_0x1bf7bc,_0x3205b3)=>{const _0xab60a2=k(_0x470e12,_0x1bf7bc);lr(_0x1a04c6,y(_0xab60a2))||(_0x5f0599=ki(_0x1f5861,_0x5f0599,_0xab60a2,_0x3205b3,_0x435079,_0x1f7234,_0xb588f3));}),_0x5f0599;}function hr(_0x2d2468,_0x235849,_0x3b3d4d){return _0x3b3d4d['foreach']((_0x58d3c4,_0x1856b8)=>{_0x235849=_0x235849['updateChild'](_0x58d3c4,_0x1856b8);}),_0x235849;}function Pi(_0x511558,_0x225370,_0x2afd27,_0x5e3184,_0x50f288,_0x368681,_0x19da5e,_0x14849a){if(_0x225370['serverCache']['getNode']()['isEmpty']()&&!_0x225370['serverCache']['isFullyInitialized']())return _0x225370;let _0x1d107a=_0x225370,_0x1816aa;v(_0x2afd27)?_0x1816aa=_0x5e3184:_0x1816aa=new b(null)['setTree'](_0x2afd27,_0x5e3184);const _0x4dc5d8=_0x225370['serverCache']['getNode']();return _0x1816aa['children']['inorderTraversal']((_0x41d699,_0x5841ae)=>{if(_0x4dc5d8['hasChild'](_0x41d699)){const _0xfb7445=_0x225370['serverCache']['getNode']()['getImmediateChild'](_0x41d699),_0x5878e5=hr(_0x511558,_0xfb7445,_0x5841ae);_0x1d107a=Sn(_0x511558,_0x1d107a,new C(_0x41d699),_0x5878e5,_0x50f288,_0x368681,_0x19da5e,_0x14849a);}}),_0x1816aa['children']['inorderTraversal']((_0x3fd359,_0x257bab)=>{const _0x54e8ef=!_0x225370['serverCache']['isCompleteForChild'](_0x3fd359)&&_0x257bab['value']===null;if(!_0x4dc5d8['hasChild'](_0x3fd359)&&!_0x54e8ef){const _0x537cc7=_0x225370['serverCache']['getNode']()['getImmediateChild'](_0x3fd359),_0x3430e3=hr(_0x511558,_0x537cc7,_0x257bab);_0x1d107a=Sn(_0x511558,_0x1d107a,new C(_0x3fd359),_0x3430e3,_0x50f288,_0x368681,_0x19da5e,_0x14849a);}}),_0x1d107a;}function Pu(_0x4a04e9,_0x5d840d,_0x35f96d,_0x560b20,_0x574b20,_0x575611,_0x30b580){if(Tn(_0x574b20,_0x35f96d)!=null)return _0x5d840d;const _0x1e6b58=_0x5d840d['serverCache']['isFiltered'](),_0x233821=_0x5d840d['serverCache'];if(_0x560b20['value']!=null){if(v(_0x35f96d)&&_0x233821['isFullyInitialized']()||_0x233821['isCompleteForPath'](_0x35f96d))return Sn(_0x4a04e9,_0x5d840d,_0x35f96d,_0x233821['getNode']()['getChild'](_0x35f96d),_0x574b20,_0x575611,_0x1e6b58,_0x30b580);if(v(_0x35f96d)){let _0x20ac8a=new b(null);return _0x233821['getNode']()['forEachChild'](ve,(_0x35a943,_0x559979)=>{_0x20ac8a=_0x20ac8a['set'](new C(_0x35a943),_0x559979);}),Pi(_0x4a04e9,_0x5d840d,_0x35f96d,_0x20ac8a,_0x574b20,_0x575611,_0x1e6b58,_0x30b580);}else return _0x5d840d;}else{let _0x3fd357=new b(null);return _0x560b20['foreach']((_0x5f0e5e,_0x1cf58c)=>{const _0x129899=k(_0x35f96d,_0x5f0e5e);_0x233821['isCompleteForPath'](_0x129899)&&(_0x3fd357=_0x3fd357['set'](_0x5f0e5e,_0x233821['getNode']()['getChild'](_0x129899)));}),Pi(_0x4a04e9,_0x5d840d,_0x35f96d,_0x3fd357,_0x574b20,_0x575611,_0x1e6b58,_0x30b580);}}function Nu(_0x955aa1,_0x5307ae,_0xc0254c,_0x2d1bc1,_0x1e30ce){const _0xeeed0e=_0x5307ae['serverCache'],_0x201da5=Fo(_0x5307ae,_0xeeed0e['getNode'](),_0xeeed0e['isFullyInitialized']()||v(_0xc0254c),_0xeeed0e['isFiltered']());return Go(_0x955aa1,_0x201da5,_0xc0254c,_0x2d1bc1,$o,_0x1e30ce);}function Ou(_0x303cb7,_0x13bbb7,_0x11926d,_0xf5365e,_0x22f43a,_0x3f5a71){let _0x587745;if(Tn(_0xf5365e,_0x11926d)!=null)return _0x13bbb7;{const _0x2e4689=new rs(_0xf5365e,_0x13bbb7,_0x22f43a),_0x2cf4bc=_0x13bbb7['eventCache']['getNode']();let _0x5f27d5;if(v(_0x11926d)||y(_0x11926d)==='.priority'){let _0x2a45c4;if(_0x13bbb7['serverCache']['isFullyInitialized']())_0x2a45c4=Cn(_0xf5365e,Ve(_0x13bbb7));else{const _0x4a827d=_0x13bbb7['serverCache']['getNode']();f(_0x4a827d instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x2a45c4=is(_0xf5365e,_0x4a827d);}_0x2a45c4=_0x2a45c4,_0x5f27d5=_0x303cb7['filter']['updateFullNode'](_0x2cf4bc,_0x2a45c4,_0x3f5a71);}else{const _0x4526fa=y(_0x11926d);let _0x22d412=ss(_0xf5365e,_0x4526fa,_0x13bbb7['serverCache']);_0x22d412==null&&_0x13bbb7['serverCache']['isCompleteForChild'](_0x4526fa)&&(_0x22d412=_0x2cf4bc['getImmediateChild'](_0x4526fa)),_0x22d412!=null?_0x5f27d5=_0x303cb7['filter']['updateChild'](_0x2cf4bc,_0x4526fa,_0x22d412,S(_0x11926d),_0x2e4689,_0x3f5a71):_0x13bbb7['eventCache']['getNode']()['hasChild'](_0x4526fa)?_0x5f27d5=_0x303cb7['filter']['updateChild'](_0x2cf4bc,_0x4526fa,g['EMPTY_NODE'],S(_0x11926d),_0x2e4689,_0x3f5a71):_0x5f27d5=_0x2cf4bc,_0x5f27d5['isEmpty']()&&_0x13bbb7['serverCache']['isFullyInitialized']()&&(_0x587745=Cn(_0xf5365e,Ve(_0x13bbb7)),_0x587745['isLeafNode']()&&(_0x5f27d5=_0x303cb7['filter']['updateFullNode'](_0x5f27d5,_0x587745,_0x3f5a71)));}return _0x587745=_0x13bbb7['serverCache']['isFullyInitialized']()||Tn(_0xf5365e,w())!=null,Rt(_0x13bbb7,_0x5f27d5,_0x587745,_0x303cb7['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x5941c9,_0x11fe47){this['query_']=_0x5941c9,this['eventRegistrations_']=[];const _0x56be1a=this['query_']['_queryParams'],_0x500c86=new Xi(_0x56be1a['getIndex']()),_0x85e5f9=Kh(_0x56be1a);this['processor_']=Su(_0x85e5f9);const _0x124bf7=_0x11fe47['serverCache'],_0x1b87e1=_0x11fe47['eventCache'],_0xabbb09=_0x500c86['updateFullNode'](g['EMPTY_NODE'],_0x124bf7['getNode'](),null),_0xf3a417=_0x85e5f9['updateFullNode'](g['EMPTY_NODE'],_0x1b87e1['getNode'](),null),_0x4b340e=new Te(_0xabbb09,_0x124bf7['isFullyInitialized'](),_0x500c86['filtersNodes']()),_0x2cbb45=new Te(_0xf3a417,_0x1b87e1['isFullyInitialized'](),_0x85e5f9['filtersNodes']());this['viewCache_']=Un(_0x2cbb45,_0x4b340e),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x418a14){return _0x418a14['viewCache_']['serverCache']['getNode']();}function Lu(_0x29b501){return wn(_0x29b501['viewCache_']);}function xu(_0x135bc9,_0x4c450b){const _0x265640=Ve(_0x135bc9['viewCache_']);return _0x265640&&(_0x135bc9['query']['_queryParams']['loadsAllData']()||!v(_0x4c450b)&&!_0x265640['getImmediateChild'](y(_0x4c450b))['isEmpty']())?_0x265640['getChild'](_0x4c450b):null;}function ur(_0x5e6007){return _0x5e6007['eventRegistrations_']['length']===0x0;}function Fu(_0x481ba5,_0x221321){_0x481ba5['eventRegistrations_']['push'](_0x221321);}function dr(_0x1b26de,_0x2e3978,_0x546618){const _0x53ca32=[];if(_0x546618){f(_0x2e3978==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x1d0356=_0x1b26de['query']['_path'];_0x1b26de['eventRegistrations_']['forEach'](_0x39409a=>{const _0x1c4280=_0x39409a['createCancelEvent'](_0x546618,_0x1d0356);_0x1c4280&&_0x53ca32['push'](_0x1c4280);});}if(_0x2e3978){let _0x52b283=[];for(let _0x1eab1f=0x0;_0x1eab1f<_0x1b26de['eventRegistrations_']['length'];++_0x1eab1f){const _0x574edd=_0x1b26de['eventRegistrations_'][_0x1eab1f];if(!_0x574edd['matches'](_0x2e3978))_0x52b283['push'](_0x574edd);else{if(_0x2e3978['hasAnyCallback']()){_0x52b283=_0x52b283['concat'](_0x1b26de['eventRegistrations_']['slice'](_0x1eab1f+0x1));break;}}}_0x1b26de['eventRegistrations_']=_0x52b283;}else _0x1b26de['eventRegistrations_']=[];return _0x53ca32;}function fr(_0x4acfa2,_0x15e7c9,_0x1395a2,_0x4e2b57){_0x15e7c9['type']===z['MERGE']&&_0x15e7c9['source']['queryId']!==null&&(f(Ve(_0x4acfa2['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x4acfa2['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x41d555=_0x4acfa2['viewCache_'],_0x3adc8c=Ru(_0x4acfa2['processor_'],_0x41d555,_0x15e7c9,_0x1395a2,_0x4e2b57);return bu(_0x4acfa2['processor_'],_0x3adc8c['viewCache']),f(_0x3adc8c['viewCache']['serverCache']['isFullyInitialized']()||!_0x41d555['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x4acfa2['viewCache_']=_0x3adc8c['viewCache'],qo(_0x4acfa2,_0x3adc8c['changes'],_0x3adc8c['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x5a1022,_0x5dd130){const _0x579557=_0x5a1022['viewCache_']['eventCache'],_0x48c7aa=[];return _0x579557['getNode']()['isLeafNode']()||_0x579557['getNode']()['forEachChild'](R,(_0x9c50aa,_0x27cf77)=>{_0x48c7aa['push'](rt(_0x9c50aa,_0x27cf77));}),_0x579557['isFullyInitialized']()&&_0x48c7aa['push'](Lo(_0x579557['getNode']())),qo(_0x5a1022,_0x48c7aa,_0x579557['getNode'](),_0x5dd130);}function qo(_0x18563b,_0x1745e6,_0x21e8b6,_0xeb8f2f){const _0xe0f304=_0xeb8f2f?[_0xeb8f2f]:_0x18563b['eventRegistrations_'];return ru(_0x18563b['eventGenerator_'],_0x1745e6,_0x21e8b6,_0xe0f304);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x28695a){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x28695a;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x5af688){return _0x5af688['views']['size']===0x0;}function os(_0x53632e,_0x1541ff,_0x46bb55,_0x2e63e2){const _0x430eb3=_0x1541ff['source']['queryId'];if(_0x430eb3!==null){const _0x27cdb2=_0x53632e['views']['get'](_0x430eb3);return f(_0x27cdb2!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x27cdb2,_0x1541ff,_0x46bb55,_0x2e63e2);}else{let _0xde61a9=[];for(const _0x342a90 of _0x53632e['views']['values']())_0xde61a9=_0xde61a9['concat'](fr(_0x342a90,_0x1541ff,_0x46bb55,_0x2e63e2));return _0xde61a9;}}function jo(_0xc98362,_0x5a6db7,_0x33cac1,_0x1c6327,_0x304c05){const _0xfc7588=_0x5a6db7['_queryIdentifier'],_0x54d926=_0xc98362['views']['get'](_0xfc7588);if(!_0x54d926){let _0x373155=Cn(_0x33cac1,_0x304c05?_0x1c6327:null),_0x5bd633=!0x1;_0x373155?_0x5bd633=!0x0:_0x1c6327 instanceof g?(_0x373155=is(_0x33cac1,_0x1c6327),_0x5bd633=!0x1):(_0x373155=g['EMPTY_NODE'],_0x5bd633=!0x1);const _0x1ca84a=Un(new Te(_0x373155,_0x5bd633,!0x1),new Te(_0x1c6327,_0x304c05,!0x1));return new Du(_0x5a6db7,_0x1ca84a);}return _0x54d926;}function Hu(_0x35af91,_0x2c25ec,_0x6286da,_0x566fd2,_0x46e07d,_0x32fa0d){const _0x9ad832=jo(_0x35af91,_0x2c25ec,_0x566fd2,_0x46e07d,_0x32fa0d);return _0x35af91['views']['has'](_0x2c25ec['_queryIdentifier'])||_0x35af91['views']['set'](_0x2c25ec['_queryIdentifier'],_0x9ad832),Fu(_0x9ad832,_0x6286da),Uu(_0x9ad832,_0x6286da);}function $u(_0x148a9f,_0x102ca4,_0x4f83c9,_0x36cbb4){const _0x5aab4d=_0x102ca4['_queryIdentifier'],_0x57d7f0=[];let _0xebbb5a=[];const _0x201791=Se(_0x148a9f);if(_0x5aab4d==='default'){for(const [_0x456352,_0xba804a]of _0x148a9f['views']['entries']())_0xebbb5a=_0xebbb5a['concat'](dr(_0xba804a,_0x4f83c9,_0x36cbb4)),ur(_0xba804a)&&(_0x148a9f['views']['delete'](_0x456352),_0xba804a['query']['_queryParams']['loadsAllData']()||_0x57d7f0['push'](_0xba804a['query']));}else{const _0x2744ae=_0x148a9f['views']['get'](_0x5aab4d);_0x2744ae&&(_0xebbb5a=_0xebbb5a['concat'](dr(_0x2744ae,_0x4f83c9,_0x36cbb4)),ur(_0x2744ae)&&(_0x148a9f['views']['delete'](_0x5aab4d),_0x2744ae['query']['_queryParams']['loadsAllData']()||_0x57d7f0['push'](_0x2744ae['query'])));}return _0x201791&&!Se(_0x148a9f)&&_0x57d7f0['push'](new(Bu())(_0x102ca4['_repo'],_0x102ca4['_path'])),{'removed':_0x57d7f0,'events':_0xebbb5a};}function Ko(_0x7ae121){const _0x10270c=[];for(const _0x4cac27 of _0x7ae121['views']['values']())_0x4cac27['query']['_queryParams']['loadsAllData']()||_0x10270c['push'](_0x4cac27);return _0x10270c;}function Ie(_0x12ed0e,_0x44bb2d){let _0x1ef812=null;for(const _0x37a385 of _0x12ed0e['views']['values']())_0x1ef812=_0x1ef812||xu(_0x37a385,_0x44bb2d);return _0x1ef812;}function Yo(_0x36a2af,_0x38fb99){if(_0x38fb99['_queryParams']['loadsAllData']())return Bn(_0x36a2af);{const _0x43a8a2=_0x38fb99['_queryIdentifier'];return _0x36a2af['views']['get'](_0x43a8a2);}}function Qo(_0x4e7fae,_0x4b85ab){return Yo(_0x4e7fae,_0x4b85ab)!=null;}function Se(_0x1e265c){return Bn(_0x1e265c)!=null;}function Bn(_0x221ee9){for(const _0x502cf8 of _0x221ee9['views']['values']())if(_0x502cf8['query']['_queryParams']['loadsAllData']())return _0x502cf8;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x57458a){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x57458a;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x338b63){this['listenProvider_']=_0x338b63,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x38c74f,_0x5dcfd7,_0x23536a,_0x293537,_0x22cb31){return lu(_0x38c74f['pendingWriteTree_'],_0x5dcfd7,_0x23536a,_0x293537,_0x22cb31),_0x22cb31?_t(_0x38c74f,new Be(es(),_0x5dcfd7,_0x23536a)):[];}function ju(_0xd8821f,_0x41ebf4,_0x430bb7,_0x5b8b8c){hu(_0xd8821f['pendingWriteTree_'],_0x41ebf4,_0x430bb7,_0x5b8b8c);const _0x120e2=b['fromObject'](_0x430bb7);return _t(_0xd8821f,new ot(es(),_0x41ebf4,_0x120e2));}function _e(_0x27b902,_0x4cc16d,_0xebfc69=!0x1){const _0x425697=uu(_0x27b902['pendingWriteTree_'],_0x4cc16d);if(du(_0x27b902['pendingWriteTree_'],_0x4cc16d)){let _0x4b6896=new b(null);return _0x425697['snap']!=null?_0x4b6896=_0x4b6896['set'](w(),!0x0):x(_0x425697['children'],_0x2049a8=>{_0x4b6896=_0x4b6896['set'](new C(_0x2049a8),!0x0);}),_t(_0x27b902,new In(_0x425697['path'],_0x4b6896,_0xebfc69));}else return[];}function Yt(_0x22a36e,_0x360ca1,_0x277da6){return _t(_0x22a36e,new Be(ts(),_0x360ca1,_0x277da6));}function Ku(_0x532a2d,_0x55ee7a,_0x3d4397){const _0x4b3e53=b['fromObject'](_0x3d4397);return _t(_0x532a2d,new ot(ts(),_0x55ee7a,_0x4b3e53));}function Yu(_0xc5e1d4,_0x261f62){return _t(_0xc5e1d4,new Ut(ts(),_0x261f62));}function Qu(_0x1d5ec6,_0x4ad65d,_0x34d1e7){const _0x4473d9=cs(_0x1d5ec6,_0x34d1e7);if(_0x4473d9){const _0xf64548=ls(_0x4473d9),_0xee7ea4=_0xf64548['path'],_0x423fdc=_0xf64548['queryId'],_0x2be346=F(_0xee7ea4,_0x4ad65d),_0xff6e3d=new Ut(ns(_0x423fdc),_0x2be346);return hs(_0x1d5ec6,_0xee7ea4,_0xff6e3d);}else return[];}function An(_0x6a84ab,_0x3e1604,_0x1538c5,_0x5c1833,_0xa38be4=!0x1){const _0x4c55af=_0x3e1604['_path'],_0xd89748=_0x6a84ab['syncPointTree_']['get'](_0x4c55af);let _0x42fd3f=[];if(_0xd89748&&(_0x3e1604['_queryIdentifier']==='default'||Qo(_0xd89748,_0x3e1604))){const _0x565bab=$u(_0xd89748,_0x3e1604,_0x1538c5,_0x5c1833);Vu(_0xd89748)&&(_0x6a84ab['syncPointTree_']=_0x6a84ab['syncPointTree_']['remove'](_0x4c55af));const _0x127dbe=_0x565bab['removed'];if(_0x42fd3f=_0x565bab['events'],!_0xa38be4){const _0x32981c=_0x127dbe['findIndex'](_0x104682=>_0x104682['_queryParams']['loadsAllData']())!==-0x1,_0x18a6d0=_0x6a84ab['syncPointTree_']['findOnPath'](_0x4c55af,(_0x46c3d2,_0x9f4939)=>Se(_0x9f4939));if(_0x32981c&&!_0x18a6d0){const _0x4c3805=_0x6a84ab['syncPointTree_']['subtree'](_0x4c55af);if(!_0x4c3805['isEmpty']()){const _0x35530f=Zu(_0x4c3805);for(let _0x5430fb=0x0;_0x5430fb<_0x35530f['length'];++_0x5430fb){const _0x213610=_0x35530f[_0x5430fb],_0x4b03fc=_0x213610['query'],_0xd95834=ea(_0x6a84ab,_0x213610);_0x6a84ab['listenProvider_']['startListening'](kt(_0x4b03fc),Wt(_0x6a84ab,_0x4b03fc),_0xd95834['hashFn'],_0xd95834['onComplete']);}}}!_0x18a6d0&&_0x127dbe['length']>0x0&&!_0x5c1833&&(_0x32981c?_0x6a84ab['listenProvider_']['stopListening'](kt(_0x3e1604),null):_0x127dbe['forEach'](_0x4246e2=>{const _0x386412=_0x6a84ab['queryToTagMap']['get'](Hn(_0x4246e2));_0x6a84ab['listenProvider_']['stopListening'](kt(_0x4246e2),_0x386412);}));}ed(_0x6a84ab,_0x127dbe);}return _0x42fd3f;}function Jo(_0x35b89a,_0x9b853,_0x3b14b2,_0x4cd039){const _0x327b58=cs(_0x35b89a,_0x4cd039);if(_0x327b58!=null){const _0x17f552=ls(_0x327b58),_0x2dfd38=_0x17f552['path'],_0x3be563=_0x17f552['queryId'],_0x5f33b8=F(_0x2dfd38,_0x9b853),_0x3dd643=new Be(ns(_0x3be563),_0x5f33b8,_0x3b14b2);return hs(_0x35b89a,_0x2dfd38,_0x3dd643);}else return[];}function Ju(_0x21a48e,_0x503bf1,_0x2a5d6f,_0x1c0d6b){const _0x3b54c3=cs(_0x21a48e,_0x1c0d6b);if(_0x3b54c3){const _0x5dea39=ls(_0x3b54c3),_0x1a4c24=_0x5dea39['path'],_0x1d56c5=_0x5dea39['queryId'],_0x442a17=F(_0x1a4c24,_0x503bf1),_0x1c64ca=b['fromObject'](_0x2a5d6f),_0x5672ae=new ot(ns(_0x1d56c5),_0x442a17,_0x1c64ca);return hs(_0x21a48e,_0x1a4c24,_0x5672ae);}else return[];}function Ni(_0x22944a,_0x582132,_0x352a92,_0x55d7ea=!0x1){const _0x284ca0=_0x582132['_path'];let _0x9996cf=null,_0x3f5d04=!0x1;_0x22944a['syncPointTree_']['foreachOnPath'](_0x284ca0,(_0x30c22a,_0x5f4b9a)=>{const _0x59c25d=F(_0x30c22a,_0x284ca0);_0x9996cf=_0x9996cf||Ie(_0x5f4b9a,_0x59c25d),_0x3f5d04=_0x3f5d04||Se(_0x5f4b9a);});let _0x14e93a=_0x22944a['syncPointTree_']['get'](_0x284ca0);_0x14e93a?(_0x3f5d04=_0x3f5d04||Se(_0x14e93a),_0x9996cf=_0x9996cf||Ie(_0x14e93a,w())):(_0x14e93a=new zo(),_0x22944a['syncPointTree_']=_0x22944a['syncPointTree_']['set'](_0x284ca0,_0x14e93a));let _0x231371;_0x9996cf!=null?_0x231371=!0x0:(_0x231371=!0x1,_0x9996cf=g['EMPTY_NODE'],_0x22944a['syncPointTree_']['subtree'](_0x284ca0)['foreachChild']((_0x774392,_0x2806b6)=>{const _0x5a34e5=Ie(_0x2806b6,w());_0x5a34e5&&(_0x9996cf=_0x9996cf['updateImmediateChild'](_0x774392,_0x5a34e5));}));const _0x5a3a09=Qo(_0x14e93a,_0x582132);if(!_0x5a3a09&&!_0x582132['_queryParams']['loadsAllData']()){const _0x5e1cd6=Hn(_0x582132);f(!_0x22944a['queryToTagMap']['has'](_0x5e1cd6),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x3c518d=td();_0x22944a['queryToTagMap']['set'](_0x5e1cd6,_0x3c518d),_0x22944a['tagToQueryMap']['set'](_0x3c518d,_0x5e1cd6);}const _0x1bafff=Wn(_0x22944a['pendingWriteTree_'],_0x284ca0);let _0x2c1dfc=Hu(_0x14e93a,_0x582132,_0x352a92,_0x1bafff,_0x9996cf,_0x231371);if(!_0x5a3a09&&!_0x3f5d04&&!_0x55d7ea){const _0x5a0f17=Yo(_0x14e93a,_0x582132);_0x2c1dfc=_0x2c1dfc['concat'](nd(_0x22944a,_0x582132,_0x5a0f17));}return _0x2c1dfc;}function Vn(_0x400979,_0x5c3933,_0x4497b3){const _0x5e7c4b=_0x400979['pendingWriteTree_'],_0x4f50b8=_0x400979['syncPointTree_']['findOnPath'](_0x5c3933,(_0x453400,_0x126cec)=>{const _0x103896=F(_0x453400,_0x5c3933),_0x1fd313=Ie(_0x126cec,_0x103896);if(_0x1fd313)return _0x1fd313;});return Bo(_0x5e7c4b,_0x5c3933,_0x4f50b8,_0x4497b3,!0x0);}function Xu(_0x41b798,_0x52cfe6){const _0x3433d3=_0x52cfe6['_path'];let _0x1115fa=null;_0x41b798['syncPointTree_']['foreachOnPath'](_0x3433d3,(_0x233ec2,_0x3cdd5b)=>{const _0x1a7111=F(_0x233ec2,_0x3433d3);_0x1115fa=_0x1115fa||Ie(_0x3cdd5b,_0x1a7111);});let _0x1dca9f=_0x41b798['syncPointTree_']['get'](_0x3433d3);_0x1dca9f?_0x1115fa=_0x1115fa||Ie(_0x1dca9f,w()):(_0x1dca9f=new zo(),_0x41b798['syncPointTree_']=_0x41b798['syncPointTree_']['set'](_0x3433d3,_0x1dca9f));const _0x3b75b6=_0x1115fa!=null,_0x8f40ea=_0x3b75b6?new Te(_0x1115fa,!0x0,!0x1):null,_0x3e67aa=Wn(_0x41b798['pendingWriteTree_'],_0x52cfe6['_path']),_0x37c815=jo(_0x1dca9f,_0x52cfe6,_0x3e67aa,_0x3b75b6?_0x8f40ea['getNode']():g['EMPTY_NODE'],_0x3b75b6);return Lu(_0x37c815);}function _t(_0x5e21e3,_0x7acd7a){return Xo(_0x7acd7a,_0x5e21e3['syncPointTree_'],null,Wn(_0x5e21e3['pendingWriteTree_'],w()));}function Xo(_0x4ce2fb,_0x49d528,_0x43f4a9,_0xe2cfa8){if(v(_0x4ce2fb['path']))return Zo(_0x4ce2fb,_0x49d528,_0x43f4a9,_0xe2cfa8);{const _0x5041c9=_0x49d528['get'](w());_0x43f4a9==null&&_0x5041c9!=null&&(_0x43f4a9=Ie(_0x5041c9,w()));let _0x2328b2=[];const _0x5b592e=y(_0x4ce2fb['path']),_0x4b2be1=_0x4ce2fb['operationForChild'](_0x5b592e),_0x3e897a=_0x49d528['children']['get'](_0x5b592e);if(_0x3e897a&&_0x4b2be1){const _0x58d091=_0x43f4a9?_0x43f4a9['getImmediateChild'](_0x5b592e):null,_0x2837d9=Vo(_0xe2cfa8,_0x5b592e);_0x2328b2=_0x2328b2['concat'](Xo(_0x4b2be1,_0x3e897a,_0x58d091,_0x2837d9));}return _0x5041c9&&(_0x2328b2=_0x2328b2['concat'](os(_0x5041c9,_0x4ce2fb,_0xe2cfa8,_0x43f4a9))),_0x2328b2;}}function Zo(_0x4dd287,_0x260be3,_0x331f26,_0x600f9c){const _0x54c527=_0x260be3['get'](w());_0x331f26==null&&_0x54c527!=null&&(_0x331f26=Ie(_0x54c527,w()));let _0x3579c1=[];return _0x260be3['children']['inorderTraversal']((_0x25c95f,_0x2b4acb)=>{const _0xa0b55=_0x331f26?_0x331f26['getImmediateChild'](_0x25c95f):null,_0x995e50=Vo(_0x600f9c,_0x25c95f),_0x2efa73=_0x4dd287['operationForChild'](_0x25c95f);_0x2efa73&&(_0x3579c1=_0x3579c1['concat'](Zo(_0x2efa73,_0x2b4acb,_0xa0b55,_0x995e50)));}),_0x54c527&&(_0x3579c1=_0x3579c1['concat'](os(_0x54c527,_0x4dd287,_0x600f9c,_0x331f26))),_0x3579c1;}function ea(_0x1b5c9e,_0x1398c3){const _0x5eb756=_0x1398c3['query'],_0x5be50f=Wt(_0x1b5c9e,_0x5eb756);return{'hashFn':()=>(Mu(_0x1398c3)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x1b61f5=>{if(_0x1b61f5==='ok')return _0x5be50f?Qu(_0x1b5c9e,_0x5eb756['_path'],_0x5be50f):Yu(_0x1b5c9e,_0x5eb756['_path']);{const _0x26a4e2=Kl(_0x1b61f5,_0x5eb756);return An(_0x1b5c9e,_0x5eb756,null,_0x26a4e2);}}};}function Wt(_0x536e2c,_0x46aad2){const _0x3fcbaf=Hn(_0x46aad2);return _0x536e2c['queryToTagMap']['get'](_0x3fcbaf);}function Hn(_0xf7a2a9){return _0xf7a2a9['_path']['toString']()+'$'+_0xf7a2a9['_queryIdentifier'];}function cs(_0x5bb249,_0x14f3f6){return _0x5bb249['tagToQueryMap']['get'](_0x14f3f6);}function ls(_0xd8a9f7){const _0x33093f=_0xd8a9f7['indexOf']('$');return f(_0x33093f!==-0x1&&_0x33093f<_0xd8a9f7['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0xd8a9f7['substr'](_0x33093f+0x1),'path':new C(_0xd8a9f7['substr'](0x0,_0x33093f))};}function hs(_0x43022c,_0x418f55,_0x343f45){const _0x78f65e=_0x43022c['syncPointTree_']['get'](_0x418f55);f(_0x78f65e,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x166072=Wn(_0x43022c['pendingWriteTree_'],_0x418f55);return os(_0x78f65e,_0x343f45,_0x166072,null);}function Zu(_0x11fbc8){return _0x11fbc8['fold']((_0x9d9cb,_0x353eec,_0x2134d1)=>{if(_0x353eec&&Se(_0x353eec))return[Bn(_0x353eec)];{let _0x2df41e=[];return _0x353eec&&(_0x2df41e=Ko(_0x353eec)),x(_0x2134d1,(_0x176fd6,_0x30aedd)=>{_0x2df41e=_0x2df41e['concat'](_0x30aedd);}),_0x2df41e;}});}function kt(_0x2e44b6){return _0x2e44b6['_queryParams']['loadsAllData']()&&!_0x2e44b6['_queryParams']['isDefault']()?new(qu())(_0x2e44b6['_repo'],_0x2e44b6['_path']):_0x2e44b6;}function ed(_0x4a0237,_0x573fb0){for(let _0x40bdd5=0x0;_0x40bdd5<_0x573fb0['length'];++_0x40bdd5){const _0x3575c0=_0x573fb0[_0x40bdd5];if(!_0x3575c0['_queryParams']['loadsAllData']()){const _0x29756b=Hn(_0x3575c0),_0x2be28d=_0x4a0237['queryToTagMap']['get'](_0x29756b);_0x4a0237['queryToTagMap']['delete'](_0x29756b),_0x4a0237['tagToQueryMap']['delete'](_0x2be28d);}}}function td(){return zu++;}function nd(_0xee1e56,_0x73e451,_0x403b74){const _0x55d634=_0x73e451['_path'],_0x3a66b8=Wt(_0xee1e56,_0x73e451),_0x53a4c4=ea(_0xee1e56,_0x403b74),_0x3169f6=_0xee1e56['listenProvider_']['startListening'](kt(_0x73e451),_0x3a66b8,_0x53a4c4['hashFn'],_0x53a4c4['onComplete']),_0x29667c=_0xee1e56['syncPointTree_']['subtree'](_0x55d634);if(_0x3a66b8)f(!Se(_0x29667c['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x1b702b=_0x29667c['fold']((_0x2eecf2,_0x441327,_0x393e10)=>{if(!v(_0x2eecf2)&&_0x441327&&Se(_0x441327))return[Bn(_0x441327)['query']];{let _0x298917=[];return _0x441327&&(_0x298917=_0x298917['concat'](Ko(_0x441327)['map'](_0x237e2b=>_0x237e2b['query']))),x(_0x393e10,(_0x470f40,_0x271a73)=>{_0x298917=_0x298917['concat'](_0x271a73);}),_0x298917;}});for(let _0x43e033=0x0;_0x43e033<_0x1b702b['length'];++_0x43e033){const _0x243519=_0x1b702b[_0x43e033];_0xee1e56['listenProvider_']['stopListening'](kt(_0x243519),Wt(_0xee1e56,_0x243519));}}return _0x3169f6;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x41103b){this['node_']=_0x41103b;}['getImmediateChild'](_0x2b6596){const _0xd42251=this['node_']['getImmediateChild'](_0x2b6596);return new us(_0xd42251);}['node'](){return this['node_'];}}class ds{constructor(_0x1c331b,_0x48be91){this['syncTree_']=_0x1c331b,this['path_']=_0x48be91;}['getImmediateChild'](_0x542230){const _0x3d89a5=k(this['path_'],_0x542230);return new ds(this['syncTree_'],_0x3d89a5);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x1267d1){return _0x1267d1=_0x1267d1||{},_0x1267d1['timestamp']=_0x1267d1['timestamp']||new Date()['getTime'](),_0x1267d1;},_r=function(_0x1bfa42,_0xdae6e9,_0x594cf0){if(!_0x1bfa42||typeof _0x1bfa42!='object')return _0x1bfa42;if(f('.sv'in _0x1bfa42,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x1bfa42['.sv']=='string')return sd(_0x1bfa42['.sv'],_0xdae6e9,_0x594cf0);if(typeof _0x1bfa42['.sv']=='object')return rd(_0x1bfa42['.sv'],_0xdae6e9);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1bfa42,null,0x2));},sd=function(_0x1d0bb2,_0x3cfb03,_0x205684){switch(_0x1d0bb2){case'timestamp':return _0x205684['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1d0bb2);}},rd=function(_0x897dcb,_0x2887e8,_0x2fff56){_0x897dcb['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x897dcb,null,0x2));const _0x45798f=_0x897dcb['increment'];typeof _0x45798f!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x45798f);const _0x5125eb=_0x2887e8['node']();if(f(_0x5125eb!==null&&typeof _0x5125eb<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x5125eb['isLeafNode']())return _0x45798f;const _0x1b678f=_0x5125eb['getValue']();return typeof _0x1b678f!='number'?_0x45798f:_0x1b678f+_0x45798f;},ta=function(_0x1366ac,_0x52e002,_0x5421df,_0x37c02a){return ps(_0x52e002,new ds(_0x5421df,_0x1366ac),_0x37c02a);},fs=function(_0x5245d7,_0x42f157,_0x11df65){return ps(_0x5245d7,new us(_0x42f157),_0x11df65);};function ps(_0x21c3c5,_0x10cc07,_0x4c05b4){const _0xe125ef=_0x21c3c5['getPriority']()['val'](),_0x5c160c=_r(_0xe125ef,_0x10cc07['getImmediateChild']('.priority'),_0x4c05b4);let _0x29d8b4;if(_0x21c3c5['isLeafNode']()){const _0x586e26=_0x21c3c5,_0x495987=_r(_0x586e26['getValue'](),_0x10cc07,_0x4c05b4);return _0x495987!==_0x586e26['getValue']()||_0x5c160c!==_0x586e26['getPriority']()['val']()?new D(_0x495987,A(_0x5c160c)):_0x21c3c5;}else{const _0x5783e0=_0x21c3c5;return _0x29d8b4=_0x5783e0,_0x5c160c!==_0x5783e0['getPriority']()['val']()&&(_0x29d8b4=_0x29d8b4['updatePriority'](new D(_0x5c160c))),_0x5783e0['forEachChild'](R,(_0x1d88f1,_0x2a9d96)=>{const _0x376255=ps(_0x2a9d96,_0x10cc07['getImmediateChild'](_0x1d88f1),_0x4c05b4);_0x376255!==_0x2a9d96&&(_0x29d8b4=_0x29d8b4['updateImmediateChild'](_0x1d88f1,_0x376255));}),_0x29d8b4;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x457d5e='',_0x43c46f=null,_0x391702={'children':{},'childCount':0x0}){this['name']=_0x457d5e,this['parent']=_0x43c46f,this['node']=_0x391702;}}function $n(_0x1be5da,_0x2cac33){let _0xabf70=_0x2cac33 instanceof C?_0x2cac33:new C(_0x2cac33),_0x517e90=_0x1be5da,_0x441f49=y(_0xabf70);for(;_0x441f49!==null;){const _0x4050ff=Le(_0x517e90['node']['children'],_0x441f49)||{'children':{},'childCount':0x0};_0x517e90=new _s(_0x441f49,_0x517e90,_0x4050ff),_0xabf70=S(_0xabf70),_0x441f49=y(_0xabf70);}return _0x517e90;}function je(_0x404afb){return _0x404afb['node']['value'];}function gs(_0x379df6,_0x7f8090){_0x379df6['node']['value']=_0x7f8090,Oi(_0x379df6);}function na(_0x39af28){return _0x39af28['node']['childCount']>0x0;}function od(_0xc78f63){return je(_0xc78f63)===void 0x0&&!na(_0xc78f63);}function Gn(_0xcc7a88,_0xc1b313){x(_0xcc7a88['node']['children'],(_0x4aee3d,_0x3960d0)=>{_0xc1b313(new _s(_0x4aee3d,_0xcc7a88,_0x3960d0));});}function ia(_0x22ab7f,_0x1d26e9,_0x34efc5,_0x5b3156){_0x34efc5&&_0x1d26e9(_0x22ab7f),Gn(_0x22ab7f,_0x1ee0e3=>{ia(_0x1ee0e3,_0x1d26e9,!0x0);});}function ad(_0x1597ad,_0x13a74d,_0xf6a384){let _0x59aa43=_0x1597ad['parent'];for(;_0x59aa43!==null;){if(_0x13a74d(_0x59aa43))return!0x0;_0x59aa43=_0x59aa43['parent'];}return!0x1;}function Qt(_0x47bcf3){return new C(_0x47bcf3['parent']===null?_0x47bcf3['name']:Qt(_0x47bcf3['parent'])+'/'+_0x47bcf3['name']);}function Oi(_0x2a9a0f){_0x2a9a0f['parent']!==null&&cd(_0x2a9a0f['parent'],_0x2a9a0f['name'],_0x2a9a0f);}function cd(_0x39d3b3,_0x3da580,_0x174f83){const _0x5d28f8=od(_0x174f83),_0x39d8b1=Q(_0x39d3b3['node']['children'],_0x3da580);_0x5d28f8&&_0x39d8b1?(delete _0x39d3b3['node']['children'][_0x3da580],_0x39d3b3['node']['childCount']--,Oi(_0x39d3b3)):!_0x5d28f8&&!_0x39d8b1&&(_0x39d3b3['node']['children'][_0x3da580]=_0x174f83['node'],_0x39d3b3['node']['childCount']++,Oi(_0x39d3b3));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x27816d){return typeof _0x27816d=='string'&&_0x27816d['length']!==0x0&&!ld['test'](_0x27816d);},sa=function(_0x8854e4){return typeof _0x8854e4=='string'&&_0x8854e4['length']!==0x0&&!hd['test'](_0x8854e4);},ud=function(_0x21e6ef){return _0x21e6ef&&(_0x21e6ef=_0x21e6ef['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x21e6ef);},Bt=function(_0x27c19e){return _0x27c19e===null||typeof _0x27c19e=='string'||typeof _0x27c19e=='number'&&!xn(_0x27c19e)||_0x27c19e&&typeof _0x27c19e=='object'&&Q(_0x27c19e,'.sv');},He=function(_0x19e136,_0x4d1fae,_0x269c41,_0xbe0423){_0xbe0423&&_0x4d1fae===void 0x0||Jt(it(_0x19e136,'value'),_0x4d1fae,_0x269c41);},Jt=function(_0x254e39,_0x524a94,_0x7acbcc){const _0x25ec79=_0x7acbcc instanceof C?new Ah(_0x7acbcc,_0x254e39):_0x7acbcc;if(_0x524a94===void 0x0)throw new Error(_0x254e39+'contains\x20undefined\x20'+Oe(_0x25ec79));if(typeof _0x524a94=='function')throw new Error(_0x254e39+'contains\x20a\x20function\x20'+Oe(_0x25ec79)+'\x20with\x20contents\x20=\x20'+_0x524a94['toString']());if(xn(_0x524a94))throw new Error(_0x254e39+'contains\x20'+_0x524a94['toString']()+'\x20'+Oe(_0x25ec79));if(typeof _0x524a94=='string'&&_0x524a94['length']>ui/0x3&&Ln(_0x524a94)>ui)throw new Error(_0x254e39+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x25ec79)+'\x20(\x27'+_0x524a94['substring'](0x0,0x32)+'...\x27)');if(_0x524a94&&typeof _0x524a94=='object'){let _0x3e2ef6=!0x1,_0x5813e3=!0x1;if(x(_0x524a94,(_0x5d89ac,_0x418d96)=>{if(_0x5d89ac==='.value')_0x3e2ef6=!0x0;else{if(_0x5d89ac!=='.priority'&&_0x5d89ac!=='.sv'&&(_0x5813e3=!0x0,!ms(_0x5d89ac)))throw new Error(_0x254e39+'\x20contains\x20an\x20invalid\x20key\x20('+_0x5d89ac+')\x20'+Oe(_0x25ec79)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x25ec79,_0x5d89ac),Jt(_0x254e39,_0x418d96,_0x25ec79),Ph(_0x25ec79);}),_0x3e2ef6&&_0x5813e3)throw new Error(_0x254e39+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x25ec79)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x3c3b86,_0x1af855){let _0x344a6f,_0x8b2042;for(_0x344a6f=0x0;_0x344a6f<_0x1af855['length'];_0x344a6f++){_0x8b2042=_0x1af855[_0x344a6f];const _0x586aca=Mt(_0x8b2042);for(let _0x379e03=0x0;_0x379e03<_0x586aca['length'];_0x379e03++)if(!(_0x586aca[_0x379e03]==='.priority'&&_0x379e03===_0x586aca['length']-0x1)){if(!ms(_0x586aca[_0x379e03]))throw new Error(_0x3c3b86+'contains\x20an\x20invalid\x20key\x20('+_0x586aca[_0x379e03]+')\x20in\x20path\x20'+_0x8b2042['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x1af855['sort'](Rh);let _0x16c338=null;for(_0x344a6f=0x0;_0x344a6f<_0x1af855['length'];_0x344a6f++){if(_0x8b2042=_0x1af855[_0x344a6f],_0x16c338!==null&&G(_0x16c338,_0x8b2042))throw new Error(_0x3c3b86+'contains\x20a\x20path\x20'+_0x16c338['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x8b2042['toString']());_0x16c338=_0x8b2042;}},ra=function(_0x5a1e5f,_0x42611e,_0x2dcf2a,_0x36809f){const _0x1541a9=it(_0x5a1e5f,'values');if(!(_0x42611e&&typeof _0x42611e=='object')||Array['isArray'](_0x42611e))throw new Error(_0x1541a9+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x435f1d=[];x(_0x42611e,(_0x1336ea,_0x519526)=>{const _0x5e4794=new C(_0x1336ea);if(Jt(_0x1541a9,_0x519526,k(_0x2dcf2a,_0x5e4794)),ji(_0x5e4794)==='.priority'&&!Bt(_0x519526))throw new Error(_0x1541a9+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x5e4794['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x435f1d['push'](_0x5e4794);}),dd(_0x1541a9,_0x435f1d);},fd=function(_0x3aa203,_0x339f93,_0x591799){if(xn(_0x339f93))throw new Error(it(_0x3aa203,'priority')+'is\x20'+_0x339f93['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x339f93))throw new Error(it(_0x3aa203,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x36be8c,_0x578ca5,_0x5a154d,_0x2dcd22){if(!sa(_0x5a154d))throw new Error(it(_0x36be8c,_0x578ca5)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x5a154d+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x82b22a,_0x3fb42d,_0x4f736b,_0x109e82){_0x4f736b&&(_0x4f736b=_0x4f736b['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x82b22a,_0x3fb42d,_0x4f736b);},Me=function(_0x5ad961,_0x4813ed){if(y(_0x4813ed)==='.info')throw new Error(_0x5ad961+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x436b72,_0x2284fb){const _0xbd2bbd=_0x2284fb['path']['toString']();if(typeof _0x2284fb['repoInfo']['host']!='string'||_0x2284fb['repoInfo']['host']['length']===0x0||!ms(_0x2284fb['repoInfo']['namespace'])&&_0x2284fb['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0xbd2bbd['length']!==0x0&&!ud(_0xbd2bbd))throw new Error(it(_0x436b72,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x212ed7,_0x4caa52){let _0x5ed146=null;for(let _0x122d27=0x0;_0x122d27<_0x4caa52['length'];_0x122d27++){const _0x5988b2=_0x4caa52[_0x122d27],_0x444275=_0x5988b2['getPath']();_0x5ed146!==null&&!Ki(_0x444275,_0x5ed146['path'])&&(_0x212ed7['eventLists_']['push'](_0x5ed146),_0x5ed146=null),_0x5ed146===null&&(_0x5ed146={'events':[],'path':_0x444275}),_0x5ed146['events']['push'](_0x5988b2);}_0x5ed146&&_0x212ed7['eventLists_']['push'](_0x5ed146);}function oa(_0xaabecc,_0x559e39,_0x577460){qn(_0xaabecc,_0x577460),aa(_0xaabecc,_0x3f8599=>Ki(_0x3f8599,_0x559e39));}function V(_0x13c9ac,_0x43a43d,_0x36f182){qn(_0x13c9ac,_0x36f182),aa(_0x13c9ac,_0x6843de=>G(_0x6843de,_0x43a43d)||G(_0x43a43d,_0x6843de));}function aa(_0x29df0d,_0x3d5574){_0x29df0d['recursionDepth_']++;let _0x3659cc=!0x0;for(let _0x5d414c=0x0;_0x5d414c<_0x29df0d['eventLists_']['length'];_0x5d414c++){const _0x11af8c=_0x29df0d['eventLists_'][_0x5d414c];if(_0x11af8c){const _0x3779e6=_0x11af8c['path'];_0x3d5574(_0x3779e6)?(md(_0x29df0d['eventLists_'][_0x5d414c]),_0x29df0d['eventLists_'][_0x5d414c]=null):_0x3659cc=!0x1;}}_0x3659cc&&(_0x29df0d['eventLists_']=[]),_0x29df0d['recursionDepth_']--;}function md(_0x561bcf){for(let _0x5b5273=0x0;_0x5b5273<_0x561bcf['events']['length'];_0x5b5273++){const _0x3080c2=_0x561bcf['events'][_0x5b5273];if(_0x3080c2!==null){_0x561bcf['events'][_0x5b5273]=null;const _0xf31d88=_0x3080c2['getEventRunner']();St&&L('event:\x20'+_0x3080c2['toString']()),ft(_0xf31d88);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x3c9a43,_0x1d8269,_0x45b14d,_0x4a4c38){this['repoInfo_']=_0x3c9a43,this['forceRestClient_']=_0x1d8269,this['authTokenProvider_']=_0x45b14d,this['appCheckProvider_']=_0x4a4c38,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x4e907a,_0x4ab773,_0x4fdffa){if(_0x4e907a['stats_']=qi(_0x4e907a['repoInfo_']),_0x4e907a['forceRestClient_']||Xl())_0x4e907a['server_']=new vn(_0x4e907a['repoInfo_'],(_0x43b498,_0x46754b,_0x19615b,_0x3b526c)=>{gr(_0x4e907a,_0x43b498,_0x46754b,_0x19615b,_0x3b526c);},_0x4e907a['authTokenProvider_'],_0x4e907a['appCheckProvider_']),setTimeout(()=>mr(_0x4e907a,!0x0),0x0);else{if(typeof _0x4fdffa<'u'&&_0x4fdffa!==null){if(typeof _0x4fdffa!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x4fdffa);}catch(_0x3d7ba8){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x3d7ba8);}}_0x4e907a['persistentConnection_']=new se(_0x4e907a['repoInfo_'],_0x4ab773,(_0x36b153,_0x2b66d2,_0x513ddb,_0x30b6dc)=>{gr(_0x4e907a,_0x36b153,_0x2b66d2,_0x513ddb,_0x30b6dc);},_0x33530e=>{mr(_0x4e907a,_0x33530e);},_0x369b47=>{Id(_0x4e907a,_0x369b47);},_0x4e907a['authTokenProvider_'],_0x4e907a['appCheckProvider_'],_0x4fdffa),_0x4e907a['server_']=_0x4e907a['persistentConnection_'];}_0x4e907a['authTokenProvider_']['addTokenChangeListener'](_0x40a1ed=>{_0x4e907a['server_']['refreshAuthToken'](_0x40a1ed);}),_0x4e907a['appCheckProvider_']['addTokenChangeListener'](_0x1d7412=>{_0x4e907a['server_']['refreshAppCheckToken'](_0x1d7412['token']);}),_0x4e907a['statsReporter_']=ih(_0x4e907a['repoInfo_'],()=>new iu(_0x4e907a['stats_'],_0x4e907a['server_'])),_0x4e907a['infoData_']=new Xh(),_0x4e907a['infoSyncTree_']=new pr({'startListening':(_0xb0c872,_0x5e0c4b,_0x499ab8,_0xea3c60)=>{let _0x28ea6e=[];const _0x24e5e7=_0x4e907a['infoData_']['getNode'](_0xb0c872['_path']);return _0x24e5e7['isEmpty']()||(_0x28ea6e=Yt(_0x4e907a['infoSyncTree_'],_0xb0c872['_path'],_0x24e5e7),setTimeout(()=>{_0xea3c60('ok');},0x0)),_0x28ea6e;},'stopListening':()=>{}}),vs(_0x4e907a,'connected',!0x1),_0x4e907a['serverSyncTree_']=new pr({'startListening':(_0x3c739c,_0x339e75,_0x276573,_0x3a89bf)=>(_0x4e907a['server_']['listen'](_0x3c739c,_0x276573,_0x339e75,(_0x364dd3,_0x3b85df)=>{const _0x587d8e=_0x3a89bf(_0x364dd3,_0x3b85df);V(_0x4e907a['eventQueue_'],_0x3c739c['_path'],_0x587d8e);}),[]),'stopListening':(_0x114b57,_0x2f6dd3)=>{_0x4e907a['server_']['unlisten'](_0x114b57,_0x2f6dd3);}});}function la(_0x3e103f){const _0x357d85=_0x3e103f['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x357d85;}function Xt(_0x11fa20){return id({'timestamp':la(_0x11fa20)});}function gr(_0x270ae8,_0x1560a1,_0x43e34d,_0x2ee89a,_0x34112b){_0x270ae8['dataUpdateCount']++;const _0x4d2c42=new C(_0x1560a1);_0x43e34d=_0x270ae8['interceptServerDataCallback_']?_0x270ae8['interceptServerDataCallback_'](_0x1560a1,_0x43e34d):_0x43e34d;let _0x2c0a1a=[];if(_0x34112b){if(_0x2ee89a){const _0x11104f=_n(_0x43e34d,_0x3383d4=>A(_0x3383d4));_0x2c0a1a=Ju(_0x270ae8['serverSyncTree_'],_0x4d2c42,_0x11104f,_0x34112b);}else{const _0x215c05=A(_0x43e34d);_0x2c0a1a=Jo(_0x270ae8['serverSyncTree_'],_0x4d2c42,_0x215c05,_0x34112b);}}else{if(_0x2ee89a){const _0x44b35e=_n(_0x43e34d,_0x1de399=>A(_0x1de399));_0x2c0a1a=Ku(_0x270ae8['serverSyncTree_'],_0x4d2c42,_0x44b35e);}else{const _0x26be0f=A(_0x43e34d);_0x2c0a1a=Yt(_0x270ae8['serverSyncTree_'],_0x4d2c42,_0x26be0f);}}let _0x223948=_0x4d2c42;_0x2c0a1a['length']>0x0&&(_0x223948=ct(_0x270ae8,_0x4d2c42)),V(_0x270ae8['eventQueue_'],_0x223948,_0x2c0a1a);}function mr(_0x25ad10,_0x2ab8d5){vs(_0x25ad10,'connected',_0x2ab8d5),_0x2ab8d5===!0x1&&Sd(_0x25ad10);}function Id(_0x180d91,_0xb355f1){x(_0xb355f1,(_0x14e50c,_0x15463f)=>{vs(_0x180d91,_0x14e50c,_0x15463f);});}function vs(_0x232557,_0x253f59,_0x6e7517){const _0x1e5b58=new C('/.info/'+_0x253f59),_0x1cbfa2=A(_0x6e7517);_0x232557['infoData_']['updateSnapshot'](_0x1e5b58,_0x1cbfa2);const _0x8fb772=Yt(_0x232557['infoSyncTree_'],_0x1e5b58,_0x1cbfa2);V(_0x232557['eventQueue_'],_0x1e5b58,_0x8fb772);}function zn(_0x3e60da){return _0x3e60da['nextWriteId_']++;}function wd(_0x109645,_0x454daf,_0x42ffd5){const _0x3fbd9e=Xu(_0x109645['serverSyncTree_'],_0x454daf);return _0x3fbd9e!=null?Promise['resolve'](_0x3fbd9e):_0x109645['server_']['get'](_0x454daf)['then'](_0x15af74=>{const _0xc420dd=A(_0x15af74)['withIndex'](_0x454daf['_queryParams']['getIndex']());Ni(_0x109645['serverSyncTree_'],_0x454daf,_0x42ffd5,!0x0);let _0x53321d;if(_0x454daf['_queryParams']['loadsAllData']())_0x53321d=Yt(_0x109645['serverSyncTree_'],_0x454daf['_path'],_0xc420dd);else{const _0xc4d6fb=Wt(_0x109645['serverSyncTree_'],_0x454daf);_0x53321d=Jo(_0x109645['serverSyncTree_'],_0x454daf['_path'],_0xc420dd,_0xc4d6fb);}return V(_0x109645['eventQueue_'],_0x454daf['_path'],_0x53321d),An(_0x109645['serverSyncTree_'],_0x454daf,_0x42ffd5,null,!0x0),_0xc420dd;},_0x46cf2f=>(gt(_0x109645,'get\x20for\x20query\x20'+O(_0x454daf)+'\x20failed:\x20'+_0x46cf2f),Promise['reject'](new Error(_0x46cf2f))));}function Cd(_0x471887,_0x320223,_0x49ad18,_0x2e5354,_0x570c31){gt(_0x471887,'set',{'path':_0x320223['toString'](),'value':_0x49ad18,'priority':_0x2e5354});const _0x1bc6e9=Xt(_0x471887),_0x22ea7e=A(_0x49ad18,_0x2e5354),_0x1a30e7=Vn(_0x471887['serverSyncTree_'],_0x320223),_0x3fced7=fs(_0x22ea7e,_0x1a30e7,_0x1bc6e9),_0x1f8cf9=zn(_0x471887),_0x1e842b=as(_0x471887['serverSyncTree_'],_0x320223,_0x3fced7,_0x1f8cf9,!0x0);qn(_0x471887['eventQueue_'],_0x1e842b),_0x471887['server_']['put'](_0x320223['toString'](),_0x22ea7e['val'](!0x0),(_0x59e4f4,_0x27ee02)=>{const _0x3a9bda=_0x59e4f4==='ok';_0x3a9bda||U('set\x20at\x20'+_0x320223+'\x20failed:\x20'+_0x59e4f4);const _0x10f064=_e(_0x471887['serverSyncTree_'],_0x1f8cf9,!_0x3a9bda);V(_0x471887['eventQueue_'],_0x320223,_0x10f064),be(_0x471887,_0x570c31,_0x59e4f4,_0x27ee02);});const _0x193415=Is(_0x471887,_0x320223);ct(_0x471887,_0x193415),V(_0x471887['eventQueue_'],_0x193415,[]);}function Td(_0x150d0f,_0x3ad0ff,_0x57507e,_0x439a0a){gt(_0x150d0f,'update',{'path':_0x3ad0ff['toString'](),'value':_0x57507e});let _0x3c270b=!0x0;const _0x59bc58=Xt(_0x150d0f),_0x365a0a={};if(x(_0x57507e,(_0x41adc0,_0x51d02e)=>{_0x3c270b=!0x1,_0x365a0a[_0x41adc0]=ta(k(_0x3ad0ff,_0x41adc0),A(_0x51d02e),_0x150d0f['serverSyncTree_'],_0x59bc58);}),_0x3c270b)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x150d0f,_0x439a0a,'ok',void 0x0);else{const _0x417ca6=zn(_0x150d0f),_0x245b51=ju(_0x150d0f['serverSyncTree_'],_0x3ad0ff,_0x365a0a,_0x417ca6);qn(_0x150d0f['eventQueue_'],_0x245b51),_0x150d0f['server_']['merge'](_0x3ad0ff['toString'](),_0x57507e,(_0x419f40,_0x3fc5d3)=>{const _0x55b4b4=_0x419f40==='ok';_0x55b4b4||U('update\x20at\x20'+_0x3ad0ff+'\x20failed:\x20'+_0x419f40);const _0x11be92=_e(_0x150d0f['serverSyncTree_'],_0x417ca6,!_0x55b4b4),_0x37372e=_0x11be92['length']>0x0?ct(_0x150d0f,_0x3ad0ff):_0x3ad0ff;V(_0x150d0f['eventQueue_'],_0x37372e,_0x11be92),be(_0x150d0f,_0x439a0a,_0x419f40,_0x3fc5d3);}),x(_0x57507e,_0x228339=>{const _0x499136=Is(_0x150d0f,k(_0x3ad0ff,_0x228339));ct(_0x150d0f,_0x499136);}),V(_0x150d0f['eventQueue_'],_0x3ad0ff,[]);}}function Sd(_0xbc8591){gt(_0xbc8591,'onDisconnectEvents');const _0x127778=Xt(_0xbc8591),_0x3b9ad1=En();Si(_0xbc8591['onDisconnect_'],w(),(_0x154fa8,_0x1d52ef)=>{const _0x98bfcf=ta(_0x154fa8,_0x1d52ef,_0xbc8591['serverSyncTree_'],_0x127778);pt(_0x3b9ad1,_0x154fa8,_0x98bfcf);});let _0x448a9e=[];Si(_0x3b9ad1,w(),(_0x46a6a5,_0x4152e3)=>{_0x448a9e=_0x448a9e['concat'](Yt(_0xbc8591['serverSyncTree_'],_0x46a6a5,_0x4152e3));const _0x13db34=Is(_0xbc8591,_0x46a6a5);ct(_0xbc8591,_0x13db34);}),_0xbc8591['onDisconnect_']=En(),V(_0xbc8591['eventQueue_'],w(),_0x448a9e);}function bd(_0x1f56e7,_0x4bca35,_0x47629d){_0x1f56e7['server_']['onDisconnectCancel'](_0x4bca35['toString'](),(_0x43b32b,_0x246086)=>{_0x43b32b==='ok'&&Ti(_0x1f56e7['onDisconnect_'],_0x4bca35),be(_0x1f56e7,_0x47629d,_0x43b32b,_0x246086);});}function yr(_0x24f2bd,_0x1db925,_0x5f3d1f,_0x574e49){const _0x4b4ba0=A(_0x5f3d1f);_0x24f2bd['server_']['onDisconnectPut'](_0x1db925['toString'](),_0x4b4ba0['val'](!0x0),(_0x4318fb,_0x29a1e5)=>{_0x4318fb==='ok'&&pt(_0x24f2bd['onDisconnect_'],_0x1db925,_0x4b4ba0),be(_0x24f2bd,_0x574e49,_0x4318fb,_0x29a1e5);});}function Rd(_0x248eb2,_0x5ce420,_0x5e5a25,_0x5e951e,_0x29036d){const _0x53fb2a=A(_0x5e5a25,_0x5e951e);_0x248eb2['server_']['onDisconnectPut'](_0x5ce420['toString'](),_0x53fb2a['val'](!0x0),(_0x3f23e0,_0x27df82)=>{_0x3f23e0==='ok'&&pt(_0x248eb2['onDisconnect_'],_0x5ce420,_0x53fb2a),be(_0x248eb2,_0x29036d,_0x3f23e0,_0x27df82);});}function Ad(_0x375e0f,_0x4af790,_0x1b8356,_0x275fbd){if(pn(_0x1b8356)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x375e0f,_0x275fbd,'ok',void 0x0);return;}_0x375e0f['server_']['onDisconnectMerge'](_0x4af790['toString'](),_0x1b8356,(_0x4d3dfa,_0x240f55)=>{_0x4d3dfa==='ok'&&x(_0x1b8356,(_0x171cde,_0x2caa23)=>{const _0x149653=A(_0x2caa23);pt(_0x375e0f['onDisconnect_'],k(_0x4af790,_0x171cde),_0x149653);}),be(_0x375e0f,_0x275fbd,_0x4d3dfa,_0x240f55);});}function kd(_0x2d1950,_0x5870e4,_0x365958){let _0x55cafe;y(_0x5870e4['_path'])==='.info'?_0x55cafe=Ni(_0x2d1950['infoSyncTree_'],_0x5870e4,_0x365958):_0x55cafe=Ni(_0x2d1950['serverSyncTree_'],_0x5870e4,_0x365958),oa(_0x2d1950['eventQueue_'],_0x5870e4['_path'],_0x55cafe);}function Pd(_0x1269e1,_0x141ed5,_0x32e113){let _0xd13233;y(_0x141ed5['_path'])==='.info'?_0xd13233=An(_0x1269e1['infoSyncTree_'],_0x141ed5,_0x32e113):_0xd13233=An(_0x1269e1['serverSyncTree_'],_0x141ed5,_0x32e113),oa(_0x1269e1['eventQueue_'],_0x141ed5['_path'],_0xd13233);}function ha(_0xeac25a){_0xeac25a['persistentConnection_']&&_0xeac25a['persistentConnection_']['interrupt'](ca);}function Nd(_0x46e40c){_0x46e40c['persistentConnection_']&&_0x46e40c['persistentConnection_']['resume'](ca);}function gt(_0xe614a1,..._0x50f2b1){let _0x485fbc='';_0xe614a1['persistentConnection_']&&(_0x485fbc=_0xe614a1['persistentConnection_']['id']+':'),L(_0x485fbc,..._0x50f2b1);}function be(_0x3e917d,_0xcdfab8,_0x19ab7f,_0x114ddd){_0xcdfab8&&ft(()=>{if(_0x19ab7f==='ok')_0xcdfab8(null);else{const _0x2da7f9=(_0x19ab7f||'error')['toUpperCase']();let _0x44e07b=_0x2da7f9;_0x114ddd&&(_0x44e07b+=':\x20'+_0x114ddd);const _0x51b2d0=new Error(_0x44e07b);_0x51b2d0['code']=_0x2da7f9,_0xcdfab8(_0x51b2d0);}});}function Od(_0x588283,_0x148e13,_0x3c4ef5,_0x3f6b55,_0x51a85a,_0x32b1d7){gt(_0x588283,'transaction\x20on\x20'+_0x148e13);const _0x3a7e09={'path':_0x148e13,'update':_0x3c4ef5,'onComplete':_0x3f6b55,'status':null,'order':so(),'applyLocally':_0x32b1d7,'retryCount':0x0,'unwatcher':_0x51a85a,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x1e754f=Es(_0x588283,_0x148e13,void 0x0);_0x3a7e09['currentInputSnapshot']=_0x1e754f;const _0x8c18ff=_0x3a7e09['update'](_0x1e754f['val']());if(_0x8c18ff===void 0x0)_0x3a7e09['unwatcher'](),_0x3a7e09['currentOutputSnapshotRaw']=null,_0x3a7e09['currentOutputSnapshotResolved']=null,_0x3a7e09['onComplete']&&_0x3a7e09['onComplete'](null,!0x1,_0x3a7e09['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x8c18ff,_0x3a7e09['path']),_0x3a7e09['status']=0x0;const _0x4c1f02=$n(_0x588283['transactionQueueTree_'],_0x148e13),_0x3ce4b4=je(_0x4c1f02)||[];_0x3ce4b4['push'](_0x3a7e09),gs(_0x4c1f02,_0x3ce4b4);let _0x6524d7;typeof _0x8c18ff=='object'&&_0x8c18ff!==null&&Q(_0x8c18ff,'.priority')?(_0x6524d7=Le(_0x8c18ff,'.priority'),f(Bt(_0x6524d7),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x6524d7=(Vn(_0x588283['serverSyncTree_'],_0x148e13)||g['EMPTY_NODE'])['getPriority']()['val']();const _0xceabe=Xt(_0x588283),_0x33963d=A(_0x8c18ff,_0x6524d7),_0x28c89d=fs(_0x33963d,_0x1e754f,_0xceabe);_0x3a7e09['currentOutputSnapshotRaw']=_0x33963d,_0x3a7e09['currentOutputSnapshotResolved']=_0x28c89d,_0x3a7e09['currentWriteId']=zn(_0x588283);const _0x33ace1=as(_0x588283['serverSyncTree_'],_0x148e13,_0x28c89d,_0x3a7e09['currentWriteId'],_0x3a7e09['applyLocally']);V(_0x588283['eventQueue_'],_0x148e13,_0x33ace1),jn(_0x588283,_0x588283['transactionQueueTree_']);}}function Es(_0x9e26a4,_0x520964,_0x4ffd53){return Vn(_0x9e26a4['serverSyncTree_'],_0x520964,_0x4ffd53)||g['EMPTY_NODE'];}function jn(_0x4ffaeb,_0x1dba79=_0x4ffaeb['transactionQueueTree_']){if(_0x1dba79||Kn(_0x4ffaeb,_0x1dba79),je(_0x1dba79)){const _0x479a21=da(_0x4ffaeb,_0x1dba79);f(_0x479a21['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x479a21['every'](_0x28add9=>_0x28add9['status']===0x0)&&Dd(_0x4ffaeb,Qt(_0x1dba79),_0x479a21);}else na(_0x1dba79)&&Gn(_0x1dba79,_0x55798d=>{jn(_0x4ffaeb,_0x55798d);});}function Dd(_0x4df9de,_0x259632,_0x20f36f){const _0x54c37e=_0x20f36f['map'](_0x56da23=>_0x56da23['currentWriteId']),_0x5d4b45=Es(_0x4df9de,_0x259632,_0x54c37e);let _0x12d51b=_0x5d4b45;const _0x36d4e0=_0x5d4b45['hash']();for(let _0x355c5b=0x0;_0x355c5b<_0x20f36f['length'];_0x355c5b++){const _0x439701=_0x20f36f[_0x355c5b];f(_0x439701['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x439701['status']=0x1,_0x439701['retryCount']++;const _0x462198=F(_0x259632,_0x439701['path']);_0x12d51b=_0x12d51b['updateChild'](_0x462198,_0x439701['currentOutputSnapshotRaw']);}const _0x27346b=_0x12d51b['val'](!0x0),_0x2e84dc=_0x259632;_0x4df9de['server_']['put'](_0x2e84dc['toString'](),_0x27346b,_0x5080da=>{gt(_0x4df9de,'transaction\x20put\x20response',{'path':_0x2e84dc['toString'](),'status':_0x5080da});let _0x135716=[];if(_0x5080da==='ok'){const _0xf92a6f=[];for(let _0x39916f=0x0;_0x39916f<_0x20f36f['length'];_0x39916f++)_0x20f36f[_0x39916f]['status']=0x2,_0x135716=_0x135716['concat'](_e(_0x4df9de['serverSyncTree_'],_0x20f36f[_0x39916f]['currentWriteId'])),_0x20f36f[_0x39916f]['onComplete']&&_0xf92a6f['push'](()=>_0x20f36f[_0x39916f]['onComplete'](null,!0x0,_0x20f36f[_0x39916f]['currentOutputSnapshotResolved'])),_0x20f36f[_0x39916f]['unwatcher']();Kn(_0x4df9de,$n(_0x4df9de['transactionQueueTree_'],_0x259632)),jn(_0x4df9de,_0x4df9de['transactionQueueTree_']),V(_0x4df9de['eventQueue_'],_0x259632,_0x135716);for(let _0x231ac0=0x0;_0x231ac0<_0xf92a6f['length'];_0x231ac0++)ft(_0xf92a6f[_0x231ac0]);}else{if(_0x5080da==='datastale'){for(let _0x12efed=0x0;_0x12efed<_0x20f36f['length'];_0x12efed++)_0x20f36f[_0x12efed]['status']===0x3?_0x20f36f[_0x12efed]['status']=0x4:_0x20f36f[_0x12efed]['status']=0x0;}else{U('transaction\x20at\x20'+_0x2e84dc['toString']()+'\x20failed:\x20'+_0x5080da);for(let _0x194cc0=0x0;_0x194cc0<_0x20f36f['length'];_0x194cc0++)_0x20f36f[_0x194cc0]['status']=0x4,_0x20f36f[_0x194cc0]['abortReason']=_0x5080da;}ct(_0x4df9de,_0x259632);}},_0x36d4e0);}function ct(_0x5c533a,_0x59e999){const _0x137de2=ua(_0x5c533a,_0x59e999),_0x12d679=Qt(_0x137de2),_0x2d86a2=da(_0x5c533a,_0x137de2);return Md(_0x5c533a,_0x2d86a2,_0x12d679),_0x12d679;}function Md(_0x119d38,_0x154af9,_0x3c79e3){if(_0x154af9['length']===0x0)return;const _0x40e803=[];let _0x7cef8f=[];const _0x5bd82e=_0x154af9['filter'](_0x169af6=>_0x169af6['status']===0x0)['map'](_0x134de4=>_0x134de4['currentWriteId']);for(let _0x42ca12=0x0;_0x42ca12<_0x154af9['length'];_0x42ca12++){const _0xee3f27=_0x154af9[_0x42ca12],_0x479bb9=F(_0x3c79e3,_0xee3f27['path']);let _0xe74caa=!0x1,_0x2971e1;if(f(_0x479bb9!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0xee3f27['status']===0x4)_0xe74caa=!0x0,_0x2971e1=_0xee3f27['abortReason'],_0x7cef8f=_0x7cef8f['concat'](_e(_0x119d38['serverSyncTree_'],_0xee3f27['currentWriteId'],!0x0));else{if(_0xee3f27['status']===0x0){if(_0xee3f27['retryCount']>=yd)_0xe74caa=!0x0,_0x2971e1='maxretry',_0x7cef8f=_0x7cef8f['concat'](_e(_0x119d38['serverSyncTree_'],_0xee3f27['currentWriteId'],!0x0));else{const _0x7a196c=Es(_0x119d38,_0xee3f27['path'],_0x5bd82e);_0xee3f27['currentInputSnapshot']=_0x7a196c;const _0x4523a3=_0x154af9[_0x42ca12]['update'](_0x7a196c['val']());if(_0x4523a3!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4523a3,_0xee3f27['path']);let _0x420171=A(_0x4523a3);typeof _0x4523a3=='object'&&_0x4523a3!=null&&Q(_0x4523a3,'.priority')||(_0x420171=_0x420171['updatePriority'](_0x7a196c['getPriority']()));const _0x9ada6e=_0xee3f27['currentWriteId'],_0x1c24fe=Xt(_0x119d38),_0x4bd170=fs(_0x420171,_0x7a196c,_0x1c24fe);_0xee3f27['currentOutputSnapshotRaw']=_0x420171,_0xee3f27['currentOutputSnapshotResolved']=_0x4bd170,_0xee3f27['currentWriteId']=zn(_0x119d38),_0x5bd82e['splice'](_0x5bd82e['indexOf'](_0x9ada6e),0x1),_0x7cef8f=_0x7cef8f['concat'](as(_0x119d38['serverSyncTree_'],_0xee3f27['path'],_0x4bd170,_0xee3f27['currentWriteId'],_0xee3f27['applyLocally'])),_0x7cef8f=_0x7cef8f['concat'](_e(_0x119d38['serverSyncTree_'],_0x9ada6e,!0x0));}else _0xe74caa=!0x0,_0x2971e1='nodata',_0x7cef8f=_0x7cef8f['concat'](_e(_0x119d38['serverSyncTree_'],_0xee3f27['currentWriteId'],!0x0));}}}V(_0x119d38['eventQueue_'],_0x3c79e3,_0x7cef8f),_0x7cef8f=[],_0xe74caa&&(_0x154af9[_0x42ca12]['status']=0x2,function(_0x15fbf7){setTimeout(_0x15fbf7,Math['floor'](0x0));}(_0x154af9[_0x42ca12]['unwatcher']),_0x154af9[_0x42ca12]['onComplete']&&(_0x2971e1==='nodata'?_0x40e803['push'](()=>_0x154af9[_0x42ca12]['onComplete'](null,!0x1,_0x154af9[_0x42ca12]['currentInputSnapshot'])):_0x40e803['push'](()=>_0x154af9[_0x42ca12]['onComplete'](new Error(_0x2971e1),!0x1,null))));}Kn(_0x119d38,_0x119d38['transactionQueueTree_']);for(let _0x424792=0x0;_0x424792<_0x40e803['length'];_0x424792++)ft(_0x40e803[_0x424792]);jn(_0x119d38,_0x119d38['transactionQueueTree_']);}function ua(_0x152485,_0x18b16d){let _0x3003b4,_0x3f8c04=_0x152485['transactionQueueTree_'];for(_0x3003b4=y(_0x18b16d);_0x3003b4!==null&&je(_0x3f8c04)===void 0x0;)_0x3f8c04=$n(_0x3f8c04,_0x3003b4),_0x18b16d=S(_0x18b16d),_0x3003b4=y(_0x18b16d);return _0x3f8c04;}function da(_0x20f1a6,_0x47281d){const _0x1b05bd=[];return fa(_0x20f1a6,_0x47281d,_0x1b05bd),_0x1b05bd['sort']((_0x471469,_0x51065e)=>_0x471469['order']-_0x51065e['order']),_0x1b05bd;}function fa(_0x26a4bf,_0x5bdbd8,_0xf335fd){const _0xae7bbb=je(_0x5bdbd8);if(_0xae7bbb){for(let _0x4f6496=0x0;_0x4f6496<_0xae7bbb['length'];_0x4f6496++)_0xf335fd['push'](_0xae7bbb[_0x4f6496]);}Gn(_0x5bdbd8,_0x46301c=>{fa(_0x26a4bf,_0x46301c,_0xf335fd);});}function Kn(_0x568e64,_0x3884e9){const _0x1f2960=je(_0x3884e9);if(_0x1f2960){let _0x47201d=0x0;for(let _0xadb465=0x0;_0xadb465<_0x1f2960['length'];_0xadb465++)_0x1f2960[_0xadb465]['status']!==0x2&&(_0x1f2960[_0x47201d]=_0x1f2960[_0xadb465],_0x47201d++);_0x1f2960['length']=_0x47201d,gs(_0x3884e9,_0x1f2960['length']>0x0?_0x1f2960:void 0x0);}Gn(_0x3884e9,_0x2ef159=>{Kn(_0x568e64,_0x2ef159);});}function Is(_0x6e1089,_0xf83e36){const _0x3eba7f=Qt(ua(_0x6e1089,_0xf83e36)),_0x470266=$n(_0x6e1089['transactionQueueTree_'],_0xf83e36);return ad(_0x470266,_0x4ce38a=>{di(_0x6e1089,_0x4ce38a);}),di(_0x6e1089,_0x470266),ia(_0x470266,_0x13ddda=>{di(_0x6e1089,_0x13ddda);}),_0x3eba7f;}function di(_0x5805a8,_0x12fa6b){const _0x171b76=je(_0x12fa6b);if(_0x171b76){const _0x8a8fcf=[];let _0x4072d3=[],_0x176016=-0x1;for(let _0x3af0d8=0x0;_0x3af0d8<_0x171b76['length'];_0x3af0d8++)_0x171b76[_0x3af0d8]['status']===0x3||(_0x171b76[_0x3af0d8]['status']===0x1?(f(_0x176016===_0x3af0d8-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x176016=_0x3af0d8,_0x171b76[_0x3af0d8]['status']=0x3,_0x171b76[_0x3af0d8]['abortReason']='set'):(f(_0x171b76[_0x3af0d8]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x171b76[_0x3af0d8]['unwatcher'](),_0x4072d3=_0x4072d3['concat'](_e(_0x5805a8['serverSyncTree_'],_0x171b76[_0x3af0d8]['currentWriteId'],!0x0)),_0x171b76[_0x3af0d8]['onComplete']&&_0x8a8fcf['push'](_0x171b76[_0x3af0d8]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x176016===-0x1?gs(_0x12fa6b,void 0x0):_0x171b76['length']=_0x176016+0x1,V(_0x5805a8['eventQueue_'],Qt(_0x12fa6b),_0x4072d3);for(let _0x50fcbe=0x0;_0x50fcbe<_0x8a8fcf['length'];_0x50fcbe++)ft(_0x8a8fcf[_0x50fcbe]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x977d03){let _0x545e39='';const _0x5a0c9c=_0x977d03['split']('/');for(let _0x1b9379=0x0;_0x1b9379<_0x5a0c9c['length'];_0x1b9379++)if(_0x5a0c9c[_0x1b9379]['length']>0x0){let _0x7ecd0b=_0x5a0c9c[_0x1b9379];try{_0x7ecd0b=decodeURIComponent(_0x7ecd0b['replace'](/\+/g,'\x20'));}catch{}_0x545e39+='/'+_0x7ecd0b;}return _0x545e39;}function xd(_0x10d405){const _0x53b2d2={};_0x10d405['charAt'](0x0)==='?'&&(_0x10d405=_0x10d405['substring'](0x1));for(const _0x544bef of _0x10d405['split']('&')){if(_0x544bef['length']===0x0)continue;const _0x2b6ab9=_0x544bef['split']('=');_0x2b6ab9['length']===0x2?_0x53b2d2[decodeURIComponent(_0x2b6ab9[0x0])]=decodeURIComponent(_0x2b6ab9[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x544bef+'\x27\x20in\x20query\x20\x27'+_0x10d405+'\x27');}return _0x53b2d2;}const vr=function(_0x57d5fc,_0x1252cb){const _0x78e2b1=Fd(_0x57d5fc),_0x5bd3aa=_0x78e2b1['namespace'];_0x78e2b1['domain']==='firebase.com'&&ae(_0x78e2b1['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5bd3aa||_0x5bd3aa==='undefined')&&_0x78e2b1['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x78e2b1['secure']||$l();const _0x14a020=_0x78e2b1['scheme']==='ws'||_0x78e2b1['scheme']==='wss';return{'repoInfo':new yo(_0x78e2b1['host'],_0x78e2b1['secure'],_0x5bd3aa,_0x14a020,_0x1252cb,'',_0x5bd3aa!==_0x78e2b1['subdomain']),'path':new C(_0x78e2b1['pathString'])};},Fd=function(_0x2aeef4){let _0x600968='',_0x3cd62e='',_0x31c48a='',_0x557dac='',_0x5e044b='',_0x202c72=!0x0,_0x558404='https',_0xf89909=0x1bb;if(typeof _0x2aeef4=='string'){let _0x562d5b=_0x2aeef4['indexOf']('//');_0x562d5b>=0x0&&(_0x558404=_0x2aeef4['substring'](0x0,_0x562d5b-0x1),_0x2aeef4=_0x2aeef4['substring'](_0x562d5b+0x2));let _0x43f4e1=_0x2aeef4['indexOf']('/');_0x43f4e1===-0x1&&(_0x43f4e1=_0x2aeef4['length']);let _0xe3881c=_0x2aeef4['indexOf']('?');_0xe3881c===-0x1&&(_0xe3881c=_0x2aeef4['length']),_0x600968=_0x2aeef4['substring'](0x0,Math['min'](_0x43f4e1,_0xe3881c)),_0x43f4e1<_0xe3881c&&(_0x557dac=Ld(_0x2aeef4['substring'](_0x43f4e1,_0xe3881c)));const _0x16d075=xd(_0x2aeef4['substring'](Math['min'](_0x2aeef4['length'],_0xe3881c)));_0x562d5b=_0x600968['indexOf'](':'),_0x562d5b>=0x0?(_0x202c72=_0x558404==='https'||_0x558404==='wss',_0xf89909=parseInt(_0x600968['substring'](_0x562d5b+0x1),0xa)):_0x562d5b=_0x600968['length'];const _0x4eeb51=_0x600968['slice'](0x0,_0x562d5b);if(_0x4eeb51['toLowerCase']()==='localhost')_0x3cd62e='localhost';else{if(_0x4eeb51['split']('.')['length']<=0x2)_0x3cd62e=_0x4eeb51;else{const _0x692098=_0x600968['indexOf']('.');_0x31c48a=_0x600968['substring'](0x0,_0x692098)['toLowerCase'](),_0x3cd62e=_0x600968['substring'](_0x692098+0x1),_0x5e044b=_0x31c48a;}}'ns'in _0x16d075&&(_0x5e044b=_0x16d075['ns']);}return{'host':_0x600968,'port':_0xf89909,'domain':_0x3cd62e,'subdomain':_0x31c48a,'secure':_0x202c72,'scheme':_0x558404,'pathString':_0x557dac,'namespace':_0x5e044b};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x3ae5c2=0x0;const _0x449542=[];return function(_0x32bce3){const _0x5fd126=_0x32bce3===_0x3ae5c2;_0x3ae5c2=_0x32bce3;let _0x4b00fd;const _0x97cdfb=new Array(0x8);for(_0x4b00fd=0x7;_0x4b00fd>=0x0;_0x4b00fd--)_0x97cdfb[_0x4b00fd]=Er['charAt'](_0x32bce3%0x40),_0x32bce3=Math['floor'](_0x32bce3/0x40);f(_0x32bce3===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x13a88f=_0x97cdfb['join']('');if(_0x5fd126){for(_0x4b00fd=0xb;_0x4b00fd>=0x0&&_0x449542[_0x4b00fd]===0x3f;_0x4b00fd--)_0x449542[_0x4b00fd]=0x0;_0x449542[_0x4b00fd]++;}else{for(_0x4b00fd=0x0;_0x4b00fd<0xc;_0x4b00fd++)_0x449542[_0x4b00fd]=Math['floor'](Math['random']()*0x40);}for(_0x4b00fd=0x0;_0x4b00fd<0xc;_0x4b00fd++)_0x13a88f+=Er['charAt'](_0x449542[_0x4b00fd]);return f(_0x13a88f['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x13a88f;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x2d65eb,_0x455ea4,_0x1452ce,_0x5ebddb){this['eventType']=_0x2d65eb,this['eventRegistration']=_0x455ea4,this['snapshot']=_0x1452ce,this['prevName']=_0x5ebddb;}['getPath'](){const _0x225e49=this['snapshot']['ref'];return this['eventType']==='value'?_0x225e49['_path']:_0x225e49['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x412ac7,_0x95b12a,_0x2ee583){this['eventRegistration']=_0x412ac7,this['error']=_0x95b12a,this['path']=_0x2ee583;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x16597f,_0x431639){this['snapshotCallback']=_0x16597f,this['cancelCallback']=_0x431639;}['onValue'](_0x4fca62,_0x226bb1){this['snapshotCallback']['call'](null,_0x4fca62,_0x226bb1);}['onCancel'](_0x1cd400){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x1cd400);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x461681){return this['snapshotCallback']===_0x461681['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x461681['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x461681['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x17d0a8,_0x29f34f){this['_repo']=_0x17d0a8,this['_path']=_0x29f34f;}['cancel'](){const _0x1bf455=new H();return bd(this['_repo'],this['_path'],_0x1bf455['wrapCallback'](()=>{})),_0x1bf455['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x26c762=new H();return yr(this['_repo'],this['_path'],null,_0x26c762['wrapCallback'](()=>{})),_0x26c762['promise'];}['set'](_0x21bbe2){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x21bbe2,this['_path'],!0x1);const _0x561139=new H();return yr(this['_repo'],this['_path'],_0x21bbe2,_0x561139['wrapCallback'](()=>{})),_0x561139['promise'];}['setWithPriority'](_0xfe2335,_0xb6926f){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0xfe2335,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0xb6926f);const _0x350170=new H();return Rd(this['_repo'],this['_path'],_0xfe2335,_0xb6926f,_0x350170['wrapCallback'](()=>{})),_0x350170['promise'];}['update'](_0x3740fe){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x3740fe,this['_path']);const _0x3e897b=new H();return Ad(this['_repo'],this['_path'],_0x3740fe,_0x3e897b['wrapCallback'](()=>{})),_0x3e897b['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x1ab8ee,_0x4c1949,_0x32de42,_0x180fd1){this['_repo']=_0x1ab8ee,this['_path']=_0x4c1949,this['_queryParams']=_0x32de42,this['_orderByCalled']=_0x180fd1;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x4e992e=sr(this['_queryParams']),_0x2c7ed5=$i(_0x4e992e);return _0x2c7ed5==='{}'?'default':_0x2c7ed5;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x48f59d){if(_0x48f59d=P(_0x48f59d),!(_0x48f59d instanceof Ae))return!0x1;const _0x4eddd3=this['_repo']===_0x48f59d['_repo'],_0x44bcf8=Ki(this['_path'],_0x48f59d['_path']),_0x430037=this['_queryIdentifier']===_0x48f59d['_queryIdentifier'];return _0x4eddd3&&_0x44bcf8&&_0x430037;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x444a7a,_0x854824){if(_0x444a7a['_orderByCalled']===!0x0)throw new Error(_0x854824+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x4aa3d1){let _0x4a5a58=null,_0x1c1b94=null;if(_0x4aa3d1['hasStart']()&&(_0x4a5a58=_0x4aa3d1['getIndexStartValue']()),_0x4aa3d1['hasEnd']()&&(_0x1c1b94=_0x4aa3d1['getIndexEndValue']()),_0x4aa3d1['getIndex']()===ve){const _0x2eae6b='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2ec2f1='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x4aa3d1['hasStart']()){if(_0x4aa3d1['getIndexStartName']()!==We)throw new Error(_0x2eae6b);if(typeof _0x4a5a58!='string')throw new Error(_0x2ec2f1);}if(_0x4aa3d1['hasEnd']()){if(_0x4aa3d1['getIndexEndName']()!==we)throw new Error(_0x2eae6b);if(typeof _0x1c1b94!='string')throw new Error(_0x2ec2f1);}}else{if(_0x4aa3d1['getIndex']()===R){if(_0x4a5a58!=null&&!Bt(_0x4a5a58)||_0x1c1b94!=null&&!Bt(_0x1c1b94))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x4aa3d1['getIndex']()instanceof Ji||_0x4aa3d1['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x4a5a58!=null&&typeof _0x4a5a58=='object'||_0x1c1b94!=null&&typeof _0x1c1b94=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x2de967){if(_0x2de967['hasStart']()&&_0x2de967['hasEnd']()&&_0x2de967['hasLimit']()&&!_0x2de967['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x3f56d3,_0x23ef63){super(_0x3f56d3,_0x23ef63,new Zi(),!0x1);}get['parent'](){const _0xa51dd2=Ro(this['_path']);return _0xa51dd2===null?null:new ee(this['_repo'],_0xa51dd2);}get['root'](){let _0x50bf3c=this;for(;_0x50bf3c['parent']!==null;)_0x50bf3c=_0x50bf3c['parent'];return _0x50bf3c;}}class lt{constructor(_0x4aa32b,_0x4999c,_0x882274){this['_node']=_0x4aa32b,this['ref']=_0x4999c,this['_index']=_0x882274;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x278b11){const _0x857c82=new C(_0x278b11),_0x3a214b=Vt(this['ref'],_0x278b11);return new lt(this['_node']['getChild'](_0x857c82),_0x3a214b,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x5c70e5){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x1f58f8,_0x52a020)=>_0x5c70e5(new lt(_0x52a020,Vt(this['ref'],_0x1f58f8),R)));}['hasChild'](_0x19c9af){const _0x2ce0a1=new C(_0x19c9af);return!this['_node']['getChild'](_0x2ce0a1)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0xcb157b,_0x4fce3d){return _0xcb157b=P(_0xcb157b),_0xcb157b['_checkNotDeleted']('ref'),_0x4fce3d!==void 0x0?Vt(_0xcb157b['_root'],_0x4fce3d):_0xcb157b['_root'];}function Vt(_0x31a0f6,_0x358fd8){return _0x31a0f6=P(_0x31a0f6),y(_0x31a0f6['_path'])===null?pd('child','path',_0x358fd8):ys('child','path',_0x358fd8),new ee(_0x31a0f6['_repo'],k(_0x31a0f6['_path'],_0x358fd8));}function v_(_0x453064){return _0x453064=P(_0x453064),new Vd(_0x453064['_repo'],_0x453064['_path']);}function E_(_0x301034,_0x3f1dc6){_0x301034=P(_0x301034),Me('push',_0x301034['_path']),He('push',_0x3f1dc6,_0x301034['_path'],!0x0);const _0x5002fe=la(_0x301034['_repo']),_0x4f9caa=Ud(_0x5002fe),_0x577c1a=Vt(_0x301034,_0x4f9caa),_0x14d852=Vt(_0x301034,_0x4f9caa);let _0x5ae15a;return _0x3f1dc6!=null?_0x5ae15a=Hd(_0x14d852,_0x3f1dc6)['then'](()=>_0x14d852):_0x5ae15a=Promise['resolve'](_0x14d852),_0x577c1a['then']=_0x5ae15a['then']['bind'](_0x5ae15a),_0x577c1a['catch']=_0x5ae15a['then']['bind'](_0x5ae15a,void 0x0),_0x577c1a;}function Hd(_0x59d378,_0x2c559b){_0x59d378=P(_0x59d378),Me('set',_0x59d378['_path']),He('set',_0x2c559b,_0x59d378['_path'],!0x1);const _0x350f0e=new H();return Cd(_0x59d378['_repo'],_0x59d378['_path'],_0x2c559b,null,_0x350f0e['wrapCallback'](()=>{})),_0x350f0e['promise'];}function I_(_0x34a00e,_0x4f0e02){ra('update',_0x4f0e02,_0x34a00e['_path']);const _0x5b6374=new H();return Td(_0x34a00e['_repo'],_0x34a00e['_path'],_0x4f0e02,_0x5b6374['wrapCallback'](()=>{})),_0x5b6374['promise'];}function w_(_0x2e43a5){_0x2e43a5=P(_0x2e43a5);const _0xaeec73=new pa(()=>{}),_0x4fd757=new Qn(_0xaeec73);return wd(_0x2e43a5['_repo'],_0x2e43a5,_0x4fd757)['then'](_0xbcae86=>new lt(_0xbcae86,new ee(_0x2e43a5['_repo'],_0x2e43a5['_path']),_0x2e43a5['_queryParams']['getIndex']()));}class Qn{constructor(_0x7e3e91){this['callbackContext']=_0x7e3e91;}['respondsTo'](_0x268c92){return _0x268c92==='value';}['createEvent'](_0x27f56d,_0x33d606){const _0x58ccfa=_0x33d606['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x27f56d['snapshotNode'],new ee(_0x33d606['_repo'],_0x33d606['_path']),_0x58ccfa));}['getEventRunner'](_0x1ae6a3){return _0x1ae6a3['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x1ae6a3['error']):()=>this['callbackContext']['onValue'](_0x1ae6a3['snapshot'],null);}['createCancelEvent'](_0x5328e7,_0x4f9ba5){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x5328e7,_0x4f9ba5):null;}['matches'](_0x225c33){return _0x225c33 instanceof Qn?!_0x225c33['callbackContext']||!this['callbackContext']?!0x0:_0x225c33['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x21bdfd,_0x4c0b0e,_0x2be3f9,_0x2d19a9,_0x3bd749){const _0x14b487=new pa(_0x2be3f9,void 0x0),_0x14f2cf=new Qn(_0x14b487);return kd(_0x21bdfd['_repo'],_0x21bdfd,_0x14f2cf),()=>Pd(_0x21bdfd['_repo'],_0x21bdfd,_0x14f2cf);}function Gd(_0x447afb,_0x3a2ef6,_0x239b5e,_0x590221){return $d(_0x447afb,'value',_0x3a2ef6);}class mt{}class ma extends mt{constructor(_0x1e8a25,_0x3218e8){super(),this['_value']=_0x1e8a25,this['_key']=_0x3218e8,this['type']='endAt';}['_apply'](_0x5d5a1f){He('endAt',this['_value'],_0x5d5a1f['_path'],!0x0);const _0x342a30=Jh(_0x5d5a1f['_queryParams'],this['_value'],this['_key']);if(ga(_0x342a30),Yn(_0x342a30),_0x5d5a1f['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x5d5a1f['_repo'],_0x5d5a1f['_path'],_0x342a30,_0x5d5a1f['_orderByCalled']);}}function C_(_0x4cfd51,_0x30275a){return new ma(_0x4cfd51,_0x30275a);}class ya extends mt{constructor(_0x2fc1cc,_0x6595fa){super(),this['_value']=_0x2fc1cc,this['_key']=_0x6595fa,this['type']='startAt';}['_apply'](_0x539c07){He('startAt',this['_value'],_0x539c07['_path'],!0x0);const _0x486af1=Qh(_0x539c07['_queryParams'],this['_value'],this['_key']);if(ga(_0x486af1),Yn(_0x486af1),_0x539c07['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x539c07['_repo'],_0x539c07['_path'],_0x486af1,_0x539c07['_orderByCalled']);}}function T_(_0x4845d8=null,_0x3324de){return new ya(_0x4845d8,_0x3324de);}class qd extends mt{constructor(_0x1a5908){super(),this['_limit']=_0x1a5908,this['type']='limitToFirst';}['_apply'](_0x4a1198){if(_0x4a1198['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x4a1198['_repo'],_0x4a1198['_path'],Yh(_0x4a1198['_queryParams'],this['_limit']),_0x4a1198['_orderByCalled']);}}function S_(_0x47fac4){if(Math['floor'](_0x47fac4)!==_0x47fac4||_0x47fac4<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x47fac4);}class zd extends mt{constructor(_0x581105){super(),this['_path']=_0x581105,this['type']='orderByChild';}['_apply'](_0x39032a){_a(_0x39032a,'orderByChild');const _0x29587d=new C(this['_path']);if(v(_0x29587d))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x3ed3af=new Ji(_0x29587d),_0xb24605=xo(_0x39032a['_queryParams'],_0x3ed3af);return Yn(_0xb24605),new Ae(_0x39032a['_repo'],_0x39032a['_path'],_0xb24605,!0x0);}}function b_(_0x2bd65b){if(_0x2bd65b==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x2bd65b==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x2bd65b==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x2bd65b),new zd(_0x2bd65b);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x60b4fb){_a(_0x60b4fb,'orderByKey');const _0x333291=xo(_0x60b4fb['_queryParams'],ve);return Yn(_0x333291),new Ae(_0x60b4fb['_repo'],_0x60b4fb['_path'],_0x333291,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0xaae0a3,_0x4aac43){super(),this['_value']=_0xaae0a3,this['_key']=_0x4aac43,this['type']='equalTo';}['_apply'](_0x289430){if(He('equalTo',this['_value'],_0x289430['_path'],!0x1),_0x289430['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x289430['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x289430));}}function A_(_0x34959e,_0x469526){return new Kd(_0x34959e,_0x469526);}function k_(_0x2ac683,..._0x231def){let _0x4b5dde=P(_0x2ac683);for(const _0x22de8c of _0x231def)_0x4b5dde=_0x22de8c['_apply'](_0x4b5dde);return _0x4b5dde;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x2a88ea,_0x56e68e,_0x1c53dd,_0x261f52){const _0x4544ce=_0x56e68e['lastIndexOf'](':'),_0x134693=_0x56e68e['substring'](0x0,_0x4544ce),_0x1f0208=qt(_0x134693);_0x2a88ea['repoInfo_']=new yo(_0x56e68e,_0x1f0208,_0x2a88ea['repoInfo_']['namespace'],_0x2a88ea['repoInfo_']['webSocketOnly'],_0x2a88ea['repoInfo_']['nodeAdmin'],_0x2a88ea['repoInfo_']['persistenceKey'],_0x2a88ea['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x1c53dd),_0x261f52&&(_0x2a88ea['authTokenProvider_']=_0x261f52);}function Xd(_0x33feea,_0x39d18f,_0x1fb507,_0xfc75ae,_0x1a1ad3){let _0x17cccb=_0xfc75ae||_0x33feea['options']['databaseURL'];_0x17cccb===void 0x0&&(_0x33feea['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x33feea['options']['projectId']),_0x17cccb=_0x33feea['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x297a8a=vr(_0x17cccb,_0x1a1ad3),_0x46ce10=_0x297a8a['repoInfo'],_0x559e5f;typeof process<'u'&&Bs&&(_0x559e5f=Bs[Yd]),_0x559e5f?(_0x17cccb='http://'+_0x559e5f+'?ns='+_0x46ce10['namespace'],_0x297a8a=vr(_0x17cccb,_0x1a1ad3),_0x46ce10=_0x297a8a['repoInfo']):_0x297a8a['repoInfo']['secure'];const _0x3f9eb6=new eh(_0x33feea['name'],_0x33feea['options'],_0x39d18f);_d('Invalid\x20Firebase\x20Database\x20URL',_0x297a8a),v(_0x297a8a['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x3ca7f9=ef(_0x46ce10,_0x33feea,_0x3f9eb6,new Zl(_0x33feea,_0x1fb507));return new tf(_0x3ca7f9,_0x33feea);}function Zd(_0x241863,_0x1d9cfd){const _0x227dda=Di[_0x1d9cfd];(!_0x227dda||_0x227dda[_0x241863['key']]!==_0x241863)&&ae('Database\x20'+_0x1d9cfd+'('+_0x241863['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x241863),delete _0x227dda[_0x241863['key']];}function ef(_0x1084ce,_0x124f4b,_0x475b4f,_0x507a72){let _0x127fdf=Di[_0x124f4b['name']];_0x127fdf||(_0x127fdf={},Di[_0x124f4b['name']]=_0x127fdf);let _0x54339a=_0x127fdf[_0x1084ce['toURLString']()];return _0x54339a&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x54339a=new vd(_0x1084ce,Qd,_0x475b4f,_0x507a72),_0x127fdf[_0x1084ce['toURLString']()]=_0x54339a,_0x54339a;}class tf{constructor(_0x1c044e,_0x5e476c){this['_repoInternal']=_0x1c044e,this['app']=_0x5e476c,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x31c0aa){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x31c0aa+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x46a541=Zr(),_0x3af17c){const _0xaa4e3a=Hi(_0x46a541,'database')['getImmediate']({'identifier':_0x3af17c});if(!_0xaa4e3a['_instanceStarted']){const _0x1ee88c=hc('database');_0x1ee88c&&nf(_0xaa4e3a,..._0x1ee88c);}return _0xaa4e3a;}function nf(_0x173fc2,_0x36e9e0,_0x45df45,_0x3b8fa5={}){_0x173fc2=P(_0x173fc2),_0x173fc2['_checkNotDeleted']('useEmulator');const _0x437115=_0x36e9e0+':'+_0x45df45,_0x5694e7=_0x173fc2['_repoInternal'];if(_0x173fc2['_instanceStarted']){if(_0x437115===_0x173fc2['_repoInternal']['repoInfo_']['host']&&xe(_0x3b8fa5,_0x5694e7['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x44dcf0;if(_0x5694e7['repoInfo_']['nodeAdmin'])_0x3b8fa5['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x44dcf0=new an(an['OWNER']);else{if(_0x3b8fa5['mockUserToken']){const _0x5da09d=typeof _0x3b8fa5['mockUserToken']=='string'?_0x3b8fa5['mockUserToken']:uc(_0x3b8fa5['mockUserToken'],_0x173fc2['app']['options']['projectId']);_0x44dcf0=new an(_0x5da09d);}}qt(_0x36e9e0)&&Qr(_0x36e9e0),Jd(_0x5694e7,_0x437115,_0x3b8fa5,_0x44dcf0);}function N_(_0x3c5a41){_0x3c5a41=P(_0x3c5a41),_0x3c5a41['_checkNotDeleted']('goOffline'),ha(_0x3c5a41['_repo']);}function O_(_0x56e062){_0x56e062=P(_0x56e062),_0x56e062['_checkNotDeleted']('goOnline'),Nd(_0x56e062['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x3f7eec){Ul(dt),st(new Fe('database',(_0x30c139,{instanceIdentifier:_0x6dcd80})=>{const _0x8088e7=_0x30c139['getProvider']('app')['getImmediate'](),_0x4bff80=_0x30c139['getProvider']('auth-internal'),_0x2f80c0=_0x30c139['getProvider']('app-check-internal');return Xd(_0x8088e7,_0x4bff80,_0x2f80c0,_0x6dcd80);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x3f7eec),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x1bb053,_0xfbaeb7){this['committed']=_0x1bb053,this['snapshot']=_0xfbaeb7;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x54e16c,_0x47de4e,_0x528245){if(_0x54e16c=P(_0x54e16c),Me('Reference.transaction',_0x54e16c['_path']),_0x54e16c['key']==='.length'||_0x54e16c['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x54e16c['key']+'\x20is\x20a\x20read-only\x20object.';const _0x29bd3b=!0x0,_0x28303b=new H(),_0x374483=(_0x1452ee,_0x1f5745,_0x631d8f)=>{let _0x43c1e6=null;_0x1452ee?_0x28303b['reject'](_0x1452ee):(_0x43c1e6=new lt(_0x631d8f,new ee(_0x54e16c['_repo'],_0x54e16c['_path']),R),_0x28303b['resolve'](new of(_0x1f5745,_0x43c1e6)));},_0x39ada4=Gd(_0x54e16c,()=>{});return Od(_0x54e16c['_repo'],_0x54e16c['_path'],_0x47de4e,_0x374483,_0x39ada4,_0x29bd3b),_0x28303b['promise'];}se['prototype']['simpleListen']=function(_0x158eaf,_0x2484a9){this['sendRequest']('q',{'p':_0x158eaf},_0x2484a9);},se['prototype']['echo']=function(_0x33039f,_0x5d286d){this['sendRequest']('echo',{'d':_0x33039f},_0x5d286d);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x3c003a,..._0x1aa772){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x3c003a,..._0x1aa772);}function cn(_0x28f8fd,..._0x5b0edd){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x28f8fd,..._0x5b0edd);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x136493,..._0x70f9b7){throw ws(_0x136493,..._0x70f9b7);}function X(_0xb6e533,..._0x1124de){return ws(_0xb6e533,..._0x1124de);}function Ia(_0x4eca76,_0x2fe3e7,_0x540357){const _0x3d8b22={...af(),[_0x2fe3e7]:_0x540357};return new Gt('auth','Firebase',_0x3d8b22)['create'](_0x2fe3e7,{'appName':_0x4eca76['name']});}function re(_0x57cef1){return Ia(_0x57cef1,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x320097,..._0x160bcb){if(typeof _0x320097!='string'){const _0x56c792=_0x160bcb[0x0],_0x466c5e=[..._0x160bcb['slice'](0x1)];return _0x466c5e[0x0]&&(_0x466c5e[0x0]['appName']=_0x320097['name']),_0x320097['_errorFactory']['create'](_0x56c792,..._0x466c5e);}return Ea['create'](_0x320097,..._0x160bcb);}function m(_0x2b4738,_0xa6f5f9,..._0x170e45){if(!_0x2b4738)throw ws(_0xa6f5f9,..._0x170e45);}function ne(_0x531848){const _0x21aacc='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x531848;throw cn(_0x21aacc),new Error(_0x21aacc);}function ce(_0xbc0257,_0x413c71){_0xbc0257||ne(_0x413c71);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x389beb;return typeof self<'u'&&((_0x389beb=self['location'])==null?void 0x0:_0x389beb['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x120f53;return typeof self<'u'&&((_0x120f53=self['location'])==null?void 0x0:_0x120f53['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x59174d=navigator;return _0x59174d['languages']&&_0x59174d['languages'][0x0]||_0x59174d['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x3f8547,_0x2e8d74){this['shortDelay']=_0x3f8547,this['longDelay']=_0x2e8d74,ce(_0x2e8d74>_0x3f8547,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x2e1625,_0x1ae49a){ce(_0x2e1625['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x3564c7}=_0x2e1625['emulator'];return _0x1ae49a?''+_0x3564c7+(_0x1ae49a['startsWith']('/')?_0x1ae49a['slice'](0x1):_0x1ae49a):_0x3564c7;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x46818a,_0x13d180,_0x1e51e1){this['fetchImpl']=_0x46818a,_0x13d180&&(this['headersImpl']=_0x13d180),_0x1e51e1&&(this['responseImpl']=_0x1e51e1);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x414a95,_0x29fdfc){return _0x414a95['tenantId']&&!_0x29fdfc['tenantId']?{..._0x29fdfc,'tenantId':_0x414a95['tenantId']}:_0x29fdfc;}async function Pe(_0x3ca023,_0x21e414,_0x4804d6,_0x116a77,_0x36a8e7={}){return Ca(_0x3ca023,_0x36a8e7,async()=>{let _0x2e3de3={},_0x577550={};_0x116a77&&(_0x21e414==='GET'?_0x577550=_0x116a77:_0x2e3de3={'body':JSON['stringify'](_0x116a77)});const _0x77d096=ut({..._0x577550,'key':_0x3ca023['config']['apiKey']})['slice'](0x1),_0x2689b2=await _0x3ca023['_getAdditionalHeaders']();_0x2689b2['Content-Type']='application/json',_0x3ca023['languageCode']&&(_0x2689b2['X-Firebase-Locale']=_0x3ca023['languageCode']);const _0x213f3f={'method':_0x21e414,'headers':_0x2689b2,..._0x2e3de3};return dc()||(_0x213f3f['referrerPolicy']='strict-origin-when-cross-origin'),_0x3ca023['emulatorConfig']&&qt(_0x3ca023['emulatorConfig']['host'])&&(_0x213f3f['credentials']='include'),wa['fetch']()(await Ta(_0x3ca023,_0x3ca023['config']['apiHost'],_0x4804d6,_0x77d096),_0x213f3f);});}async function Ca(_0x2fb052,_0x133bd5,_0x26f59e){_0x2fb052['_canInitEmulator']=!0x1;const _0x356a59={...df,..._0x133bd5};try{const _0x43dbff=new gf(_0x2fb052),_0x317356=await Promise['race']([_0x26f59e(),_0x43dbff['promise']]);_0x43dbff['clearNetworkTimeout']();const _0x4ff693=await _0x317356['json']();if('needConfirmation'in _0x4ff693)throw on(_0x2fb052,'account-exists-with-different-credential',_0x4ff693);if(_0x317356['ok']&&!('errorMessage'in _0x4ff693))return _0x4ff693;{const _0x56cdf5=_0x317356['ok']?_0x4ff693['errorMessage']:_0x4ff693['error']['message'],[_0x5ddd68,_0x4476e3]=_0x56cdf5['split']('\x20:\x20');if(_0x5ddd68==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x2fb052,'credential-already-in-use',_0x4ff693);if(_0x5ddd68==='EMAIL_EXISTS')throw on(_0x2fb052,'email-already-in-use',_0x4ff693);if(_0x5ddd68==='USER_DISABLED')throw on(_0x2fb052,'user-disabled',_0x4ff693);const _0x39c2cf=_0x356a59[_0x5ddd68]||_0x5ddd68['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x4476e3)throw Ia(_0x2fb052,_0x39c2cf,_0x4476e3);Y(_0x2fb052,_0x39c2cf);}}catch(_0x3ed40f){if(_0x3ed40f instanceof Re)throw _0x3ed40f;Y(_0x2fb052,'network-request-failed',{'message':String(_0x3ed40f)});}}async function en(_0x1612ac,_0xa527ef,_0x2edd51,_0x555f5c,_0x5e95fc={}){const _0x8e53e7=await Pe(_0x1612ac,_0xa527ef,_0x2edd51,_0x555f5c,_0x5e95fc);return'mfaPendingCredential'in _0x8e53e7&&Y(_0x1612ac,'multi-factor-auth-required',{'_serverResponse':_0x8e53e7}),_0x8e53e7;}async function Ta(_0x5a978f,_0x2316d5,_0x5b7b07,_0x10f74c){const _0x3a2a4b=''+_0x2316d5+_0x5b7b07+'?'+_0x10f74c,_0x102e5c=_0x5a978f,_0x4f2cfe=_0x102e5c['config']['emulator']?Cs(_0x5a978f['config'],_0x3a2a4b):_0x5a978f['config']['apiScheme']+'://'+_0x3a2a4b;return ff['includes'](_0x5b7b07)&&(await _0x102e5c['_persistenceManagerAvailable'],_0x102e5c['_getPersistenceType']()==='COOKIE')?_0x102e5c['_getPersistence']()['_getFinalTarget'](_0x4f2cfe)['toString']():_0x4f2cfe;}function _f(_0x4553bc){switch(_0x4553bc){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x4078af){this['auth']=_0x4078af,this['timer']=null,this['promise']=new Promise((_0x592bef,_0x2075d3)=>{this['timer']=setTimeout(()=>_0x2075d3(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x232f00,_0x545e18,_0x5a2e18){const _0xdfb960={'appName':_0x232f00['name']};_0x5a2e18['email']&&(_0xdfb960['email']=_0x5a2e18['email']),_0x5a2e18['phoneNumber']&&(_0xdfb960['phoneNumber']=_0x5a2e18['phoneNumber']);const _0x3d6a03=X(_0x232f00,_0x545e18,_0xdfb960);return _0x3d6a03['customData']['_tokenResponse']=_0x5a2e18,_0x3d6a03;}function wr(_0x19a31b){return _0x19a31b!==void 0x0&&_0x19a31b['enterprise']!==void 0x0;}class mf{constructor(_0x216111){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x216111['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x216111['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x216111['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x3bc318){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x31635e of this['recaptchaEnforcementState'])if(_0x31635e['provider']&&_0x31635e['provider']===_0x3bc318)return _f(_0x31635e['enforcementState']);return null;}['isProviderEnabled'](_0x4f58d0){return this['getProviderEnforcementState'](_0x4f58d0)==='ENFORCE'||this['getProviderEnforcementState'](_0x4f58d0)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x1754c2,_0x18d83e){return Pe(_0x1754c2,'GET','/v2/recaptchaConfig',ke(_0x1754c2,_0x18d83e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x3e586e,_0x580f70){return Pe(_0x3e586e,'POST','/v1/accounts:delete',_0x580f70);}async function Pn(_0x331052,_0x2a98c6){return Pe(_0x331052,'POST','/v1/accounts:lookup',_0x2a98c6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x1f0d0c){if(_0x1f0d0c)try{const _0x1a86cf=new Date(Number(_0x1f0d0c));if(!isNaN(_0x1a86cf['getTime']()))return _0x1a86cf['toUTCString']();}catch{}}async function Ef(_0x3380bd,_0x29c2bf=!0x1){const _0x16db6f=P(_0x3380bd),_0x3fde59=await _0x16db6f['getIdToken'](_0x29c2bf),_0xd1f452=Ts(_0x3fde59);m(_0xd1f452&&_0xd1f452['exp']&&_0xd1f452['auth_time']&&_0xd1f452['iat'],_0x16db6f['auth'],'internal-error');const _0x3a1321=typeof _0xd1f452['firebase']=='object'?_0xd1f452['firebase']:void 0x0,_0xf06450=_0x3a1321==null?void 0x0:_0x3a1321['sign_in_provider'];return{'claims':_0xd1f452,'token':_0x3fde59,'authTime':Pt(fi(_0xd1f452['auth_time'])),'issuedAtTime':Pt(fi(_0xd1f452['iat'])),'expirationTime':Pt(fi(_0xd1f452['exp'])),'signInProvider':_0xf06450||null,'signInSecondFactor':(_0x3a1321==null?void 0x0:_0x3a1321['sign_in_second_factor'])||null};}function fi(_0x122e15){return Number(_0x122e15)*0x3e8;}function Ts(_0xc2247f){const [_0x3d9cc5,_0x524827,_0x5acfee]=_0xc2247f['split']('.');if(_0x3d9cc5===void 0x0||_0x524827===void 0x0||_0x5acfee===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x560c5d=fn(_0x524827);return _0x560c5d?JSON['parse'](_0x560c5d):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x3b48de){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x3b48de==null?void 0x0:_0x3b48de['toString']()),null;}}function Cr(_0x265317){const _0x10bc96=Ts(_0x265317);return m(_0x10bc96,'internal-error'),m(typeof _0x10bc96['exp']<'u','internal-error'),m(typeof _0x10bc96['iat']<'u','internal-error'),Number(_0x10bc96['exp'])-Number(_0x10bc96['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x4794ab,_0x3e5244,_0x5c1044=!0x1){if(_0x5c1044)return _0x3e5244;try{return await _0x3e5244;}catch(_0x29cb87){throw _0x29cb87 instanceof Re&&If(_0x29cb87)&&_0x4794ab['auth']['currentUser']===_0x4794ab&&await _0x4794ab['auth']['signOut'](),_0x29cb87;}}function If({code:_0x5af166}){return _0x5af166==='auth/user-disabled'||_0x5af166==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x46b9a8){this['user']=_0x46b9a8,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x1b683e){if(_0x1b683e){const _0x50b19e=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x50b19e;}else{this['errorBackoff']=0x7530;const _0x35dbf0=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x35dbf0);}}['schedule'](_0x2889ff=!0x1){if(!this['isRunning'])return;const _0x1c6b1f=this['getInterval'](_0x2889ff);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x1c6b1f);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x7e1fdb){(_0x7e1fdb==null?void 0x0:_0x7e1fdb['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x56a69d,_0x2ce475){this['createdAt']=_0x56a69d,this['lastLoginAt']=_0x2ce475,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x4ac45d){this['createdAt']=_0x4ac45d['createdAt'],this['lastLoginAt']=_0x4ac45d['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x31c493){var _0x32e0db;const _0x1803bd=_0x31c493['auth'],_0x4a0abd=await _0x31c493['getIdToken'](),_0x2fc4ab=await Ht(_0x31c493,Pn(_0x1803bd,{'idToken':_0x4a0abd}));m(_0x2fc4ab==null?void 0x0:_0x2fc4ab['users']['length'],_0x1803bd,'internal-error');const _0x47c234=_0x2fc4ab['users'][0x0];_0x31c493['_notifyReloadListener'](_0x47c234);const _0x3c049a=(_0x32e0db=_0x47c234['providerUserInfo'])!=null&&_0x32e0db['length']?Sa(_0x47c234['providerUserInfo']):[],_0x2564f7=Tf(_0x31c493['providerData'],_0x3c049a),_0x1de948=_0x31c493['isAnonymous'],_0x2d4f7a=!(_0x31c493['email']&&_0x47c234['passwordHash'])&&!(_0x2564f7!=null&&_0x2564f7['length']),_0x5e4d6c=_0x1de948?_0x2d4f7a:!0x1,_0x3a3f1f={'uid':_0x47c234['localId'],'displayName':_0x47c234['displayName']||null,'photoURL':_0x47c234['photoUrl']||null,'email':_0x47c234['email']||null,'emailVerified':_0x47c234['emailVerified']||!0x1,'phoneNumber':_0x47c234['phoneNumber']||null,'tenantId':_0x47c234['tenantId']||null,'providerData':_0x2564f7,'metadata':new Li(_0x47c234['createdAt'],_0x47c234['lastLoginAt']),'isAnonymous':_0x5e4d6c};Object['assign'](_0x31c493,_0x3a3f1f);}async function Cf(_0x3148a7){const _0x20f1a5=P(_0x3148a7);await Nn(_0x20f1a5),await _0x20f1a5['auth']['_persistUserIfCurrent'](_0x20f1a5),_0x20f1a5['auth']['_notifyListenersIfCurrent'](_0x20f1a5);}function Tf(_0x38bd5d,_0x377bbe){return[..._0x38bd5d['filter'](_0x438973=>!_0x377bbe['some'](_0x4d6122=>_0x4d6122['providerId']===_0x438973['providerId'])),..._0x377bbe];}function Sa(_0x2544cb){return _0x2544cb['map'](({providerId:_0x4dbc9d,..._0x412dab})=>({'providerId':_0x4dbc9d,'uid':_0x412dab['rawId']||'','displayName':_0x412dab['displayName']||null,'email':_0x412dab['email']||null,'phoneNumber':_0x412dab['phoneNumber']||null,'photoURL':_0x412dab['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x5cac6f,_0x30b4d0){const _0x37bd57=await Ca(_0x5cac6f,{},async()=>{const _0x3bf074=ut({'grant_type':'refresh_token','refresh_token':_0x30b4d0})['slice'](0x1),{tokenApiHost:_0x398da3,apiKey:_0x2b80a6}=_0x5cac6f['config'],_0x506130=await Ta(_0x5cac6f,_0x398da3,'/v1/token','key='+_0x2b80a6),_0x4ba084=await _0x5cac6f['_getAdditionalHeaders']();_0x4ba084['Content-Type']='application/x-www-form-urlencoded';const _0x3dc407={'method':'POST','headers':_0x4ba084,'body':_0x3bf074};return _0x5cac6f['emulatorConfig']&&qt(_0x5cac6f['emulatorConfig']['host'])&&(_0x3dc407['credentials']='include'),wa['fetch']()(_0x506130,_0x3dc407);});return{'accessToken':_0x37bd57['access_token'],'expiresIn':_0x37bd57['expires_in'],'refreshToken':_0x37bd57['refresh_token']};}async function bf(_0x41d116,_0x2afb64){return Pe(_0x41d116,'POST','/v2/accounts:revokeToken',ke(_0x41d116,_0x2afb64));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x450a07){m(_0x450a07['idToken'],'internal-error'),m(typeof _0x450a07['idToken']<'u','internal-error'),m(typeof _0x450a07['refreshToken']<'u','internal-error');const _0x3c47f1='expiresIn'in _0x450a07&&typeof _0x450a07['expiresIn']<'u'?Number(_0x450a07['expiresIn']):Cr(_0x450a07['idToken']);this['updateTokensAndExpiration'](_0x450a07['idToken'],_0x450a07['refreshToken'],_0x3c47f1);}['updateFromIdToken'](_0x431a4e){m(_0x431a4e['length']!==0x0,'internal-error');const _0x7dc6f8=Cr(_0x431a4e);this['updateTokensAndExpiration'](_0x431a4e,null,_0x7dc6f8);}async['getToken'](_0x106151,_0xae7ad6=!0x1){return!_0xae7ad6&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x106151,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x106151,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x5639b5,_0x1919c8){const {accessToken:_0x15d3ca,refreshToken:_0x576684,expiresIn:_0x235ef0}=await Sf(_0x5639b5,_0x1919c8);this['updateTokensAndExpiration'](_0x15d3ca,_0x576684,Number(_0x235ef0));}['updateTokensAndExpiration'](_0x11707e,_0x16efb8,_0x217735){this['refreshToken']=_0x16efb8||null,this['accessToken']=_0x11707e||null,this['expirationTime']=Date['now']()+_0x217735*0x3e8;}static['fromJSON'](_0x15b8de,_0x35f7e2){const {refreshToken:_0x5b6c0b,accessToken:_0x5db78e,expirationTime:_0x96503c}=_0x35f7e2,_0x53b226=new et();return _0x5b6c0b&&(m(typeof _0x5b6c0b=='string','internal-error',{'appName':_0x15b8de}),_0x53b226['refreshToken']=_0x5b6c0b),_0x5db78e&&(m(typeof _0x5db78e=='string','internal-error',{'appName':_0x15b8de}),_0x53b226['accessToken']=_0x5db78e),_0x96503c&&(m(typeof _0x96503c=='number','internal-error',{'appName':_0x15b8de}),_0x53b226['expirationTime']=_0x96503c),_0x53b226;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x891bb2){this['accessToken']=_0x891bb2['accessToken'],this['refreshToken']=_0x891bb2['refreshToken'],this['expirationTime']=_0x891bb2['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x4d6eac,_0x3ec1c7){m(typeof _0x4d6eac=='string'||typeof _0x4d6eac>'u','internal-error',{'appName':_0x3ec1c7});}class j{constructor({uid:_0x36c826,auth:_0x384649,stsTokenManager:_0x57e05b,..._0x308751}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x36c826,this['auth']=_0x384649,this['stsTokenManager']=_0x57e05b,this['accessToken']=_0x57e05b['accessToken'],this['displayName']=_0x308751['displayName']||null,this['email']=_0x308751['email']||null,this['emailVerified']=_0x308751['emailVerified']||!0x1,this['phoneNumber']=_0x308751['phoneNumber']||null,this['photoURL']=_0x308751['photoURL']||null,this['isAnonymous']=_0x308751['isAnonymous']||!0x1,this['tenantId']=_0x308751['tenantId']||null,this['providerData']=_0x308751['providerData']?[..._0x308751['providerData']]:[],this['metadata']=new Li(_0x308751['createdAt']||void 0x0,_0x308751['lastLoginAt']||void 0x0);}async['getIdToken'](_0x341759){const _0x3560ba=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x341759));return m(_0x3560ba,this['auth'],'internal-error'),this['accessToken']!==_0x3560ba&&(this['accessToken']=_0x3560ba,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x3560ba;}['getIdTokenResult'](_0x3175f5){return Ef(this,_0x3175f5);}['reload'](){return Cf(this);}['_assign'](_0x370351){this!==_0x370351&&(m(this['uid']===_0x370351['uid'],this['auth'],'internal-error'),this['displayName']=_0x370351['displayName'],this['photoURL']=_0x370351['photoURL'],this['email']=_0x370351['email'],this['emailVerified']=_0x370351['emailVerified'],this['phoneNumber']=_0x370351['phoneNumber'],this['isAnonymous']=_0x370351['isAnonymous'],this['tenantId']=_0x370351['tenantId'],this['providerData']=_0x370351['providerData']['map'](_0xd60e33=>({..._0xd60e33})),this['metadata']['_copy'](_0x370351['metadata']),this['stsTokenManager']['_assign'](_0x370351['stsTokenManager']));}['_clone'](_0xeac02){const _0x5b027d=new j({...this,'auth':_0xeac02,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x5b027d['metadata']['_copy'](this['metadata']),_0x5b027d;}['_onReload'](_0x7a9d7){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x7a9d7,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x34027f){this['reloadListener']?this['reloadListener'](_0x34027f):this['reloadUserInfo']=_0x34027f;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x4076ae,_0x5b061a=!0x1){let _0x12b2a6=!0x1;_0x4076ae['idToken']&&_0x4076ae['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x4076ae),_0x12b2a6=!0x0),_0x5b061a&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x12b2a6&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x1d5861=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x1d5861})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x483226=>({..._0x483226})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x14b59f,_0x31c365){const _0xafff81=_0x31c365['displayName']??void 0x0,_0x3a7e6e=_0x31c365['email']??void 0x0,_0x269c1c=_0x31c365['phoneNumber']??void 0x0,_0x371cc0=_0x31c365['photoURL']??void 0x0,_0xaefa43=_0x31c365['tenantId']??void 0x0,_0xde737b=_0x31c365['_redirectEventId']??void 0x0,_0x2b18e9=_0x31c365['createdAt']??void 0x0,_0x13ad74=_0x31c365['lastLoginAt']??void 0x0,{uid:_0x255cf0,emailVerified:_0x7b800d,isAnonymous:_0x58a08c,providerData:_0x59d25e,stsTokenManager:_0x30c566}=_0x31c365;m(_0x255cf0&&_0x30c566,_0x14b59f,'internal-error');const _0x5adbf6=et['fromJSON'](this['name'],_0x30c566);m(typeof _0x255cf0=='string',_0x14b59f,'internal-error'),le(_0xafff81,_0x14b59f['name']),le(_0x3a7e6e,_0x14b59f['name']),m(typeof _0x7b800d=='boolean',_0x14b59f,'internal-error'),m(typeof _0x58a08c=='boolean',_0x14b59f,'internal-error'),le(_0x269c1c,_0x14b59f['name']),le(_0x371cc0,_0x14b59f['name']),le(_0xaefa43,_0x14b59f['name']),le(_0xde737b,_0x14b59f['name']),le(_0x2b18e9,_0x14b59f['name']),le(_0x13ad74,_0x14b59f['name']);const _0x203c80=new j({'uid':_0x255cf0,'auth':_0x14b59f,'email':_0x3a7e6e,'emailVerified':_0x7b800d,'displayName':_0xafff81,'isAnonymous':_0x58a08c,'photoURL':_0x371cc0,'phoneNumber':_0x269c1c,'tenantId':_0xaefa43,'stsTokenManager':_0x5adbf6,'createdAt':_0x2b18e9,'lastLoginAt':_0x13ad74});return _0x59d25e&&Array['isArray'](_0x59d25e)&&(_0x203c80['providerData']=_0x59d25e['map'](_0x274f31=>({..._0x274f31}))),_0xde737b&&(_0x203c80['_redirectEventId']=_0xde737b),_0x203c80;}static async['_fromIdTokenResponse'](_0x54b7d8,_0x4ecfd7,_0x4f7cbe=!0x1){const _0x149035=new et();_0x149035['updateFromServerResponse'](_0x4ecfd7);const _0x1974f4=new j({'uid':_0x4ecfd7['localId'],'auth':_0x54b7d8,'stsTokenManager':_0x149035,'isAnonymous':_0x4f7cbe});return await Nn(_0x1974f4),_0x1974f4;}static async['_fromGetAccountInfoResponse'](_0x13a895,_0x4403da,_0x2e840f){const _0xdbed56=_0x4403da['users'][0x0];m(_0xdbed56['localId']!==void 0x0,'internal-error');const _0x2445e3=_0xdbed56['providerUserInfo']!==void 0x0?Sa(_0xdbed56['providerUserInfo']):[],_0xff28df=!(_0xdbed56['email']&&_0xdbed56['passwordHash'])&&!(_0x2445e3!=null&&_0x2445e3['length']),_0x4ca294=new et();_0x4ca294['updateFromIdToken'](_0x2e840f);const _0x17cb4a=new j({'uid':_0xdbed56['localId'],'auth':_0x13a895,'stsTokenManager':_0x4ca294,'isAnonymous':_0xff28df}),_0x187e96={'uid':_0xdbed56['localId'],'displayName':_0xdbed56['displayName']||null,'photoURL':_0xdbed56['photoUrl']||null,'email':_0xdbed56['email']||null,'emailVerified':_0xdbed56['emailVerified']||!0x1,'phoneNumber':_0xdbed56['phoneNumber']||null,'tenantId':_0xdbed56['tenantId']||null,'providerData':_0x2445e3,'metadata':new Li(_0xdbed56['createdAt'],_0xdbed56['lastLoginAt']),'isAnonymous':!(_0xdbed56['email']&&_0xdbed56['passwordHash'])&&!(_0x2445e3!=null&&_0x2445e3['length'])};return Object['assign'](_0x17cb4a,_0x187e96),_0x17cb4a;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x165fb4){ce(_0x165fb4 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x2de810=Tr['get'](_0x165fb4);return _0x2de810?(ce(_0x2de810 instanceof _0x165fb4,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x2de810):(_0x2de810=new _0x165fb4(),Tr['set'](_0x165fb4,_0x2de810),_0x2de810);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x317b63,_0x33e453){this['storage'][_0x317b63]=_0x33e453;}async['_get'](_0x136e94){const _0x57dcd6=this['storage'][_0x136e94];return _0x57dcd6===void 0x0?null:_0x57dcd6;}async['_remove'](_0x3842c8){delete this['storage'][_0x3842c8];}['_addListener'](_0x198525,_0x211d40){}['_removeListener'](_0x5976f8,_0x2a2b08){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x5f4c1b,_0x39d9c2,_0x5a9170){return'firebase:'+_0x5f4c1b+':'+_0x39d9c2+':'+_0x5a9170;}class tt{constructor(_0xfa8e2e,_0x893dd9,_0x5435d4){this['persistence']=_0xfa8e2e,this['auth']=_0x893dd9,this['userKey']=_0x5435d4;const {config:_0x575885,name:_0x21afb1}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x575885['apiKey'],_0x21afb1),this['fullPersistenceKey']=ln('persistence',_0x575885['apiKey'],_0x21afb1),this['boundEventHandler']=_0x893dd9['_onStorageEvent']['bind'](_0x893dd9),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x252dbb){return this['persistence']['_set'](this['fullUserKey'],_0x252dbb['toJSON']());}async['getCurrentUser'](){const _0x43fa1c=await this['persistence']['_get'](this['fullUserKey']);if(!_0x43fa1c)return null;if(typeof _0x43fa1c=='string'){const _0x5dc78c=await Pn(this['auth'],{'idToken':_0x43fa1c})['catch'](()=>{});return _0x5dc78c?j['_fromGetAccountInfoResponse'](this['auth'],_0x5dc78c,_0x43fa1c):null;}return j['_fromJSON'](this['auth'],_0x43fa1c);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x3d46e8){if(this['persistence']===_0x3d46e8)return;const _0x521097=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x3d46e8,_0x521097)return this['setCurrentUser'](_0x521097);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x3971a3,_0x5bf41d,_0x4ce7c1='authUser'){if(!_0x5bf41d['length'])return new tt(ie(Sr),_0x3971a3,_0x4ce7c1);const _0x13bc3c=(await Promise['all'](_0x5bf41d['map'](async _0x9fdced=>{if(await _0x9fdced['_isAvailable']())return _0x9fdced;})))['filter'](_0x3ff11a=>_0x3ff11a);let _0x4e2daa=_0x13bc3c[0x0]||ie(Sr);const _0x205977=ln(_0x4ce7c1,_0x3971a3['config']['apiKey'],_0x3971a3['name']);let _0x1034e0=null;for(const _0x41de67 of _0x5bf41d)try{const _0x5212cf=await _0x41de67['_get'](_0x205977);if(_0x5212cf){let _0x58a8c7;if(typeof _0x5212cf=='string'){const _0x5d4001=await Pn(_0x3971a3,{'idToken':_0x5212cf})['catch'](()=>{});if(!_0x5d4001)break;_0x58a8c7=await j['_fromGetAccountInfoResponse'](_0x3971a3,_0x5d4001,_0x5212cf);}else _0x58a8c7=j['_fromJSON'](_0x3971a3,_0x5212cf);_0x41de67!==_0x4e2daa&&(_0x1034e0=_0x58a8c7),_0x4e2daa=_0x41de67;break;}}catch{}const _0x379f1f=_0x13bc3c['filter'](_0x5a11fc=>_0x5a11fc['_shouldAllowMigration']);return!_0x4e2daa['_shouldAllowMigration']||!_0x379f1f['length']?new tt(_0x4e2daa,_0x3971a3,_0x4ce7c1):(_0x4e2daa=_0x379f1f[0x0],_0x1034e0&&await _0x4e2daa['_set'](_0x205977,_0x1034e0['toJSON']()),await Promise['all'](_0x5bf41d['map'](async _0x254772=>{if(_0x254772!==_0x4e2daa)try{await _0x254772['_remove'](_0x205977);}catch{}})),new tt(_0x4e2daa,_0x3971a3,_0x4ce7c1));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x2293fe){const _0x38cc04=_0x2293fe['toLowerCase']();if(_0x38cc04['includes']('opera/')||_0x38cc04['includes']('opr/')||_0x38cc04['includes']('opios/'))return'Opera';if(Pa(_0x38cc04))return'IEMobile';if(_0x38cc04['includes']('msie')||_0x38cc04['includes']('trident/'))return'IE';if(_0x38cc04['includes']('edge/'))return'Edge';if(Ra(_0x38cc04))return'Firefox';if(_0x38cc04['includes']('silk/'))return'Silk';if(Oa(_0x38cc04))return'Blackberry';if(Da(_0x38cc04))return'Webos';if(Aa(_0x38cc04))return'Safari';if((_0x38cc04['includes']('chrome/')||ka(_0x38cc04))&&!_0x38cc04['includes']('edge/'))return'Chrome';if(Na(_0x38cc04))return'Android';{const _0x4e719b=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x3f9b5d=_0x2293fe['match'](_0x4e719b);if((_0x3f9b5d==null?void 0x0:_0x3f9b5d['length'])===0x2)return _0x3f9b5d[0x1];}return'Other';}function Ra(_0x49245a=W()){return/firefox\//i['test'](_0x49245a);}function Aa(_0x565ac3=W()){const _0x216992=_0x565ac3['toLowerCase']();return _0x216992['includes']('safari/')&&!_0x216992['includes']('chrome/')&&!_0x216992['includes']('crios/')&&!_0x216992['includes']('android');}function ka(_0x4b2a03=W()){return/crios\//i['test'](_0x4b2a03);}function Pa(_0x3f1879=W()){return/iemobile/i['test'](_0x3f1879);}function Na(_0x45514c=W()){return/android/i['test'](_0x45514c);}function Oa(_0x2a139d=W()){return/blackberry/i['test'](_0x2a139d);}function Da(_0x2bcee1=W()){return/webos/i['test'](_0x2bcee1);}function Ss(_0x237c68=W()){return/iphone|ipad|ipod/i['test'](_0x237c68)||/macintosh/i['test'](_0x237c68)&&/mobile/i['test'](_0x237c68);}function Rf(_0x1dd728=W()){var _0x454bff;return Ss(_0x1dd728)&&!!((_0x454bff=window['navigator'])!=null&&_0x454bff['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x4ab5da=W()){return Ss(_0x4ab5da)||Na(_0x4ab5da)||Da(_0x4ab5da)||Oa(_0x4ab5da)||/windows phone/i['test'](_0x4ab5da)||Pa(_0x4ab5da);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x48a7d7,_0x244043=[]){let _0x359205;switch(_0x48a7d7){case'Browser':_0x359205=br(W());break;case'Worker':_0x359205=br(W())+'-'+_0x48a7d7;break;default:_0x359205=_0x48a7d7;}const _0x5eb425=_0x244043['length']?_0x244043['join'](','):'FirebaseCore-web';return _0x359205+'/JsCore/'+dt+'/'+_0x5eb425;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x138ac5){this['auth']=_0x138ac5,this['queue']=[];}['pushCallback'](_0x176bde,_0x3a9ef1){const _0x7ee6c9=_0x2738c3=>new Promise((_0x2db76e,_0x269ee5)=>{try{const _0x277b47=_0x176bde(_0x2738c3);_0x2db76e(_0x277b47);}catch(_0x4f181a){_0x269ee5(_0x4f181a);}});_0x7ee6c9['onAbort']=_0x3a9ef1,this['queue']['push'](_0x7ee6c9);const _0x170b24=this['queue']['length']-0x1;return()=>{this['queue'][_0x170b24]=()=>Promise['resolve']();};}async['runMiddleware'](_0x627f24){if(this['auth']['currentUser']===_0x627f24)return;const _0x445684=[];try{for(const _0x5191f2 of this['queue'])await _0x5191f2(_0x627f24),_0x5191f2['onAbort']&&_0x445684['push'](_0x5191f2['onAbort']);}catch(_0x18ffb5){_0x445684['reverse']();for(const _0x5c8a87 of _0x445684)try{_0x5c8a87();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x18ffb5==null?void 0x0:_0x18ffb5['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x257005,_0x329665={}){return Pe(_0x257005,'GET','/v2/passwordPolicy',ke(_0x257005,_0x329665));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x473d6b){var _0x40a300;const _0x47e37d=_0x473d6b['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x47e37d['minPasswordLength']??Nf,_0x47e37d['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x47e37d['maxPasswordLength']),_0x47e37d['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x47e37d['containsLowercaseCharacter']),_0x47e37d['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x47e37d['containsUppercaseCharacter']),_0x47e37d['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x47e37d['containsNumericCharacter']),_0x47e37d['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x47e37d['containsNonAlphanumericCharacter']),this['enforcementState']=_0x473d6b['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x40a300=_0x473d6b['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x40a300['join'](''))??'',this['forceUpgradeOnSignin']=_0x473d6b['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x473d6b['schemaVersion'];}['validatePassword'](_0x332a92){const _0x4a2f4b={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x332a92,_0x4a2f4b),this['validatePasswordCharacterOptions'](_0x332a92,_0x4a2f4b),_0x4a2f4b['isValid']&&(_0x4a2f4b['isValid']=_0x4a2f4b['meetsMinPasswordLength']??!0x0),_0x4a2f4b['isValid']&&(_0x4a2f4b['isValid']=_0x4a2f4b['meetsMaxPasswordLength']??!0x0),_0x4a2f4b['isValid']&&(_0x4a2f4b['isValid']=_0x4a2f4b['containsLowercaseLetter']??!0x0),_0x4a2f4b['isValid']&&(_0x4a2f4b['isValid']=_0x4a2f4b['containsUppercaseLetter']??!0x0),_0x4a2f4b['isValid']&&(_0x4a2f4b['isValid']=_0x4a2f4b['containsNumericCharacter']??!0x0),_0x4a2f4b['isValid']&&(_0x4a2f4b['isValid']=_0x4a2f4b['containsNonAlphanumericCharacter']??!0x0),_0x4a2f4b;}['validatePasswordLengthOptions'](_0x21402b,_0x36cc29){const _0xa78d96=this['customStrengthOptions']['minPasswordLength'],_0x236937=this['customStrengthOptions']['maxPasswordLength'];_0xa78d96&&(_0x36cc29['meetsMinPasswordLength']=_0x21402b['length']>=_0xa78d96),_0x236937&&(_0x36cc29['meetsMaxPasswordLength']=_0x21402b['length']<=_0x236937);}['validatePasswordCharacterOptions'](_0x2ed6c7,_0x2f70d9){this['updatePasswordCharacterOptionsStatuses'](_0x2f70d9,!0x1,!0x1,!0x1,!0x1);let _0x113509;for(let _0x5e6c3c=0x0;_0x5e6c3c<_0x2ed6c7['length'];_0x5e6c3c++)_0x113509=_0x2ed6c7['charAt'](_0x5e6c3c),this['updatePasswordCharacterOptionsStatuses'](_0x2f70d9,_0x113509>='a'&&_0x113509<='z',_0x113509>='A'&&_0x113509<='Z',_0x113509>='0'&&_0x113509<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x113509));}['updatePasswordCharacterOptionsStatuses'](_0x1dc79a,_0x24eb6f,_0x5f8744,_0x1a9c4b,_0x27698e){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x1dc79a['containsLowercaseLetter']||(_0x1dc79a['containsLowercaseLetter']=_0x24eb6f)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x1dc79a['containsUppercaseLetter']||(_0x1dc79a['containsUppercaseLetter']=_0x5f8744)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x1dc79a['containsNumericCharacter']||(_0x1dc79a['containsNumericCharacter']=_0x1a9c4b)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x1dc79a['containsNonAlphanumericCharacter']||(_0x1dc79a['containsNonAlphanumericCharacter']=_0x27698e));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x132205,_0x258979,_0x648d5e,_0x3d63a8){this['app']=_0x132205,this['heartbeatServiceProvider']=_0x258979,this['appCheckServiceProvider']=_0x648d5e,this['config']=_0x3d63a8,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x132205['name'],this['clientVersion']=_0x3d63a8['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x48f636=>this['_resolvePersistenceManagerAvailable']=_0x48f636);}['_initializeWithPersistence'](_0x501f9d,_0x3c9a28){return _0x3c9a28&&(this['_popupRedirectResolver']=ie(_0x3c9a28)),this['_initializationPromise']=this['queue'](async()=>{var _0x5c1d48,_0xff54d8,_0x263e4e;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x501f9d),(_0x5c1d48=this['_resolvePersistenceManagerAvailable'])==null||_0x5c1d48['call'](this),!this['_deleted'])){if((_0xff54d8=this['_popupRedirectResolver'])!=null&&_0xff54d8['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x3c9a28),this['lastNotifiedUid']=((_0x263e4e=this['currentUser'])==null?void 0x0:_0x263e4e['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x3a2d14=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x3a2d14)){if(this['currentUser']&&_0x3a2d14&&this['currentUser']['uid']===_0x3a2d14['uid']){this['_currentUser']['_assign'](_0x3a2d14),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x3a2d14,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x45b874){try{const _0x230efc=await Pn(this,{'idToken':_0x45b874}),_0xc40fab=await j['_fromGetAccountInfoResponse'](this,_0x230efc,_0x45b874);await this['directlySetCurrentUser'](_0xc40fab);}catch(_0x36c706){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x36c706),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x5b9394){var _0x2b84c4;if($(this['app'])){const _0x1bc219=this['app']['settings']['authIdToken'];return _0x1bc219?new Promise(_0x5c053d=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x1bc219)['then'](_0x5c053d,_0x5c053d));}):this['directlySetCurrentUser'](null);}const _0x2bd5ea=await this['assertedPersistence']['getCurrentUser']();let _0x573239=_0x2bd5ea,_0x993567=!0x1;if(_0x5b9394&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x48b3b5=(_0x2b84c4=this['redirectUser'])==null?void 0x0:_0x2b84c4['_redirectEventId'],_0x283192=_0x573239==null?void 0x0:_0x573239['_redirectEventId'],_0xd2d647=await this['tryRedirectSignIn'](_0x5b9394);(!_0x48b3b5||_0x48b3b5===_0x283192)&&(_0xd2d647!=null&&_0xd2d647['user'])&&(_0x573239=_0xd2d647['user'],_0x993567=!0x0);}if(!_0x573239)return this['directlySetCurrentUser'](null);if(!_0x573239['_redirectEventId']){if(_0x993567)try{await this['beforeStateQueue']['runMiddleware'](_0x573239);}catch(_0x30b8f8){_0x573239=_0x2bd5ea,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x30b8f8));}return _0x573239?this['reloadAndSetCurrentUserOrClear'](_0x573239):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x573239['_redirectEventId']?this['directlySetCurrentUser'](_0x573239):this['reloadAndSetCurrentUserOrClear'](_0x573239);}async['tryRedirectSignIn'](_0x2a6ea6){let _0x46b821=null;try{_0x46b821=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x2a6ea6,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x46b821;}async['reloadAndSetCurrentUserOrClear'](_0x43ff59){try{await Nn(_0x43ff59);}catch(_0x1e1993){if((_0x1e1993==null?void 0x0:_0x1e1993['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x43ff59);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x36eef3){if($(this['app']))return Promise['reject'](re(this));const _0xc3b1c5=_0x36eef3?P(_0x36eef3):null;return _0xc3b1c5&&m(_0xc3b1c5['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0xc3b1c5&&_0xc3b1c5['_clone'](this));}async['_updateCurrentUser'](_0x150ff9,_0x49352f=!0x1){if(!this['_deleted'])return _0x150ff9&&m(this['tenantId']===_0x150ff9['tenantId'],this,'tenant-id-mismatch'),_0x49352f||await this['beforeStateQueue']['runMiddleware'](_0x150ff9),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x150ff9),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x340260){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x340260));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x5b993f){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x31940f=this['_getPasswordPolicyInternal']();return _0x31940f['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x31940f['validatePassword'](_0x5b993f);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x4b33e7=await Pf(this),_0x21bef4=new Of(_0x4b33e7);this['tenantId']===null?this['_projectPasswordPolicy']=_0x21bef4:this['_tenantPasswordPolicies'][this['tenantId']]=_0x21bef4;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x11011f){this['_errorFactory']=new Gt('auth','Firebase',_0x11011f());}['onAuthStateChanged'](_0x428b63,_0x24556d,_0x400445){return this['registerStateListener'](this['authStateSubscription'],_0x428b63,_0x24556d,_0x400445);}['beforeAuthStateChanged'](_0x3518ad,_0x30d7e4){return this['beforeStateQueue']['pushCallback'](_0x3518ad,_0x30d7e4);}['onIdTokenChanged'](_0x27a222,_0x39f13f,_0x277169){return this['registerStateListener'](this['idTokenSubscription'],_0x27a222,_0x39f13f,_0x277169);}['authStateReady'](){return new Promise((_0x4353b6,_0x27ec4f)=>{if(this['currentUser'])_0x4353b6();else{const _0x2fb297=this['onAuthStateChanged'](()=>{_0x2fb297(),_0x4353b6();},_0x27ec4f);}});}async['revokeAccessToken'](_0x45ed17){if(this['currentUser']){const _0x1263b0=await this['currentUser']['getIdToken'](),_0xeb8bf4={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x45ed17,'idToken':_0x1263b0};this['tenantId']!=null&&(_0xeb8bf4['tenantId']=this['tenantId']),await bf(this,_0xeb8bf4);}}['toJSON'](){var _0x4ec5e3;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x4ec5e3=this['_currentUser'])==null?void 0x0:_0x4ec5e3['toJSON']()};}async['_setRedirectUser'](_0x5da064,_0x19044b){const _0x374e9f=await this['getOrInitRedirectPersistenceManager'](_0x19044b);return _0x5da064===null?_0x374e9f['removeCurrentUser']():_0x374e9f['setCurrentUser'](_0x5da064);}async['getOrInitRedirectPersistenceManager'](_0x457368){if(!this['redirectPersistenceManager']){const _0x4d7b6b=_0x457368&&ie(_0x457368)||this['_popupRedirectResolver'];m(_0x4d7b6b,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x4d7b6b['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x287bed){var _0x43a2ff,_0x2bad9a;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x43a2ff=this['_currentUser'])==null?void 0x0:_0x43a2ff['_redirectEventId'])===_0x287bed?this['_currentUser']:((_0x2bad9a=this['redirectUser'])==null?void 0x0:_0x2bad9a['_redirectEventId'])===_0x287bed?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x5739b9){if(_0x5739b9===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x5739b9));}['_notifyListenersIfCurrent'](_0x30e511){_0x30e511===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x3b5c9d;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x360bfe=((_0x3b5c9d=this['currentUser'])==null?void 0x0:_0x3b5c9d['uid'])??null;this['lastNotifiedUid']!==_0x360bfe&&(this['lastNotifiedUid']=_0x360bfe,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x2a0ddf,_0x29ac93,_0x2a86b4,_0x2fcef0){if(this['_deleted'])return()=>{};const _0x4cf224=typeof _0x29ac93=='function'?_0x29ac93:_0x29ac93['next']['bind'](_0x29ac93);let _0x57a0ef=!0x1;const _0x512a3f=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x512a3f,this,'internal-error'),_0x512a3f['then'](()=>{_0x57a0ef||_0x4cf224(this['currentUser']);}),typeof _0x29ac93=='function'){const _0x2d19e8=_0x2a0ddf['addObserver'](_0x29ac93,_0x2a86b4,_0x2fcef0);return()=>{_0x57a0ef=!0x0,_0x2d19e8();};}else{const _0x3532f6=_0x2a0ddf['addObserver'](_0x29ac93);return()=>{_0x57a0ef=!0x0,_0x3532f6();};}}async['directlySetCurrentUser'](_0x1531a0){this['currentUser']&&this['currentUser']!==_0x1531a0&&this['_currentUser']['_stopProactiveRefresh'](),_0x1531a0&&this['isProactiveRefreshEnabled']&&_0x1531a0['_startProactiveRefresh'](),this['currentUser']=_0x1531a0,_0x1531a0?await this['assertedPersistence']['setCurrentUser'](_0x1531a0):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x41cc0b){return this['operations']=this['operations']['then'](_0x41cc0b,_0x41cc0b),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x42f711){!_0x42f711||this['frameworks']['includes'](_0x42f711)||(this['frameworks']['push'](_0x42f711),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x426552;const _0x1fb3ec={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x1fb3ec['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x3bf8d1=await((_0x426552=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x426552['getHeartbeatsHeader']());_0x3bf8d1&&(_0x1fb3ec['X-Firebase-Client']=_0x3bf8d1);const _0x341927=await this['_getAppCheckToken']();return _0x341927&&(_0x1fb3ec['X-Firebase-AppCheck']=_0x341927),_0x1fb3ec;}async['_getAppCheckToken'](){var _0x20cf2c;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x1cedba=await((_0x20cf2c=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x20cf2c['getToken']());return _0x1cedba!=null&&_0x1cedba['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x1cedba['error']),_0x1cedba==null?void 0x0:_0x1cedba['token'];}}function Ke(_0x156a01){return P(_0x156a01);}class Rr{constructor(_0x19bccf){this['auth']=_0x19bccf,this['observer']=null,this['addObserver']=Tc(_0x153cf2=>this['observer']=_0x153cf2);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x5276fd){Jn=_0x5276fd;}function xa(_0x22b430){return Jn['loadJS'](_0x22b430);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x254522){return'__'+_0x254522+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x1739b0){_0x1739b0();}['execute'](_0x1be188,_0x5a4e7a){return Promise['resolve']('token');}['render'](_0x512a6a,_0x4cfca6){return'';}}class Wf{['ready'](_0x4e8e4f){_0x4e8e4f();}['execute'](_0x7b5ad9,_0x266ae5){return Promise['resolve']('token');}['render'](_0x4733b6,_0xb3d405){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x29a4bc){this['type']=Bf,this['auth']=Ke(_0x29a4bc);}async['verify'](_0x2d3dfc='verify',_0x4be61d=!0x1){async function _0x593117(_0x1d5587){if(!_0x4be61d){if(_0x1d5587['tenantId']==null&&_0x1d5587['_agentRecaptchaConfig']!=null)return _0x1d5587['_agentRecaptchaConfig']['siteKey'];if(_0x1d5587['tenantId']!=null&&_0x1d5587['_tenantRecaptchaConfigs'][_0x1d5587['tenantId']]!==void 0x0)return _0x1d5587['_tenantRecaptchaConfigs'][_0x1d5587['tenantId']]['siteKey'];}return new Promise(async(_0x53a5a1,_0x560d3a)=>{yf(_0x1d5587,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x2b3d90=>{if(_0x2b3d90['recaptchaKey']===void 0x0)_0x560d3a(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x574a3d=new mf(_0x2b3d90);return _0x1d5587['tenantId']==null?_0x1d5587['_agentRecaptchaConfig']=_0x574a3d:_0x1d5587['_tenantRecaptchaConfigs'][_0x1d5587['tenantId']]=_0x574a3d,_0x53a5a1(_0x574a3d['siteKey']);}})['catch'](_0x321280=>{_0x560d3a(_0x321280);});});}function _0x58f302(_0x1d8ea6,_0x142d66,_0x3056e1){const _0x29afc4=window['grecaptcha'];wr(_0x29afc4)?_0x29afc4['enterprise']['ready'](()=>{_0x29afc4['enterprise']['execute'](_0x1d8ea6,{'action':_0x2d3dfc})['then'](_0x1751c1=>{_0x142d66(_0x1751c1);})['catch'](()=>{_0x142d66(Fa);});}):_0x3056e1(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x1673ae,_0x554e90)=>{_0x593117(this['auth'])['then'](async _0x41af3f=>{if(!_0x4be61d&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x58f302(_0x41af3f,_0x1673ae,_0x554e90);else{if(typeof window>'u'){_0x554e90(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x526379=Lf();_0x526379['length']!==0x0&&(_0x526379+=_0x41af3f+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x4b963e;(_0x4b963e=he['scriptInjectionDeferred'])==null||_0x4b963e['resolve']();},xa(_0x526379)['then'](()=>{var _0xa5bdd8;return(_0xa5bdd8=he['scriptInjectionDeferred'])==null?void 0x0:_0xa5bdd8['promise'];})['then'](()=>{_0x58f302(_0x41af3f,_0x1673ae,_0x554e90);})['catch'](_0x1065ae=>{_0x554e90(_0x1065ae);});}})['catch'](_0x27ecc3=>{_0x554e90(_0x27ecc3);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x5516d4,_0x58baf0,_0x788420,_0x5a4778=!0x1,_0xca641c=!0x1){const _0x2fd615=new he(_0x5516d4);let _0x2a2620;if(_0xca641c)_0x2a2620=Fa;else try{_0x2a2620=await _0x2fd615['verify'](_0x788420);}catch{_0x2a2620=await _0x2fd615['verify'](_0x788420,!0x0);}const _0x2b52fb={..._0x58baf0};if(_0x788420==='mfaSmsEnrollment'||_0x788420==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x2b52fb){const _0x109cc0=_0x2b52fb['phoneEnrollmentInfo']['phoneNumber'],_0x2c2132=_0x2b52fb['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x2b52fb,{'phoneEnrollmentInfo':{'phoneNumber':_0x109cc0,'recaptchaToken':_0x2c2132,'captchaResponse':_0x2a2620,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x2b52fb){const _0x523bf8=_0x2b52fb['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x2b52fb,{'phoneSignInInfo':{'recaptchaToken':_0x523bf8,'captchaResponse':_0x2a2620,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x2b52fb;}return _0x5a4778?Object['assign'](_0x2b52fb,{'captchaResp':_0x2a2620}):Object['assign'](_0x2b52fb,{'captchaResponse':_0x2a2620}),Object['assign'](_0x2b52fb,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x2b52fb,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x2b52fb;}async function xi(_0x2877bd,_0x4c28ef,_0x374846,_0x37d913,_0x1799d0){var _0x47bd83;if((_0x47bd83=_0x2877bd['_getRecaptchaConfig']())!=null&&_0x47bd83['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x324390=await kr(_0x2877bd,_0x4c28ef,_0x374846,_0x374846==='getOobCode');return _0x37d913(_0x2877bd,_0x324390);}else return _0x37d913(_0x2877bd,_0x4c28ef)['catch'](async _0x1bd6b5=>{if(_0x1bd6b5['code']==='auth/missing-recaptcha-token'){console['log'](_0x374846+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x3b642b=await kr(_0x2877bd,_0x4c28ef,_0x374846,_0x374846==='getOobCode');return _0x37d913(_0x2877bd,_0x3b642b);}else return Promise['reject'](_0x1bd6b5);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x1e1d51,_0x13ad31){const _0x4a6417=Hi(_0x1e1d51,'auth');if(_0x4a6417['isInitialized']()){const _0x2c65d0=_0x4a6417['getImmediate'](),_0xbd164e=_0x4a6417['getOptions']();if(xe(_0xbd164e,_0x13ad31??{}))return _0x2c65d0;Y(_0x2c65d0,'already-initialized');}return _0x4a6417['initialize']({'options':_0x13ad31});}function Hf(_0x214009,_0x564132){const _0x5cda04=(_0x564132==null?void 0x0:_0x564132['persistence'])||[],_0x2a31b7=(Array['isArray'](_0x5cda04)?_0x5cda04:[_0x5cda04])['map'](ie);_0x564132!=null&&_0x564132['errorMap']&&_0x214009['_updateErrorMap'](_0x564132['errorMap']),_0x214009['_initializeWithPersistence'](_0x2a31b7,_0x564132==null?void 0x0:_0x564132['popupRedirectResolver']);}function $f(_0x3fc8d2,_0x123831,_0x38071f){const _0x32b85b=Ke(_0x3fc8d2);m(/^https?:\/\//['test'](_0x123831),_0x32b85b,'invalid-emulator-scheme');const _0x563ed8=!0x1,_0x434127=Ua(_0x123831),{host:_0x371ac2,port:_0x36e8ae}=Gf(_0x123831),_0x354fbb=_0x36e8ae===null?'':':'+_0x36e8ae,_0x49618a={'url':_0x434127+'//'+_0x371ac2+_0x354fbb+'/'},_0x508c4f=Object['freeze']({'host':_0x371ac2,'port':_0x36e8ae,'protocol':_0x434127['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x563ed8})});if(!_0x32b85b['_canInitEmulator']){m(_0x32b85b['config']['emulator']&&_0x32b85b['emulatorConfig'],_0x32b85b,'emulator-config-failed'),m(xe(_0x49618a,_0x32b85b['config']['emulator'])&&xe(_0x508c4f,_0x32b85b['emulatorConfig']),_0x32b85b,'emulator-config-failed');return;}_0x32b85b['config']['emulator']=_0x49618a,_0x32b85b['emulatorConfig']=_0x508c4f,_0x32b85b['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x371ac2)?Qr(_0x434127+'//'+_0x371ac2+_0x354fbb):qf();}function Ua(_0x5e007d){const _0x4ff653=_0x5e007d['indexOf'](':');return _0x4ff653<0x0?'':_0x5e007d['substr'](0x0,_0x4ff653+0x1);}function Gf(_0x5c2972){const _0x5a25e5=Ua(_0x5c2972),_0x33ebe4=/(\/\/)?([^?#/]+)/['exec'](_0x5c2972['substr'](_0x5a25e5['length']));if(!_0x33ebe4)return{'host':'','port':null};const _0x4cb3b0=_0x33ebe4[0x2]['split']('@')['pop']()||'',_0x468c55=/^(\[[^\]]+\])(:|$)/['exec'](_0x4cb3b0);if(_0x468c55){const _0x11f379=_0x468c55[0x1];return{'host':_0x11f379,'port':Pr(_0x4cb3b0['substr'](_0x11f379['length']+0x1))};}else{const [_0x53a0f5,_0x1770ff]=_0x4cb3b0['split'](':');return{'host':_0x53a0f5,'port':Pr(_0x1770ff)};}}function Pr(_0x5c1b89){if(!_0x5c1b89)return null;const _0x3797e8=Number(_0x5c1b89);return isNaN(_0x3797e8)?null:_0x3797e8;}function qf(){function _0x1134c7(){const _0x48418a=document['createElement']('p'),_0x45ad42=_0x48418a['style'];_0x48418a['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x45ad42['position']='fixed',_0x45ad42['width']='100%',_0x45ad42['backgroundColor']='#ffffff',_0x45ad42['border']='.1em\x20solid\x20#000000',_0x45ad42['color']='#b50000',_0x45ad42['bottom']='0px',_0x45ad42['left']='0px',_0x45ad42['margin']='0px',_0x45ad42['zIndex']='10000',_0x45ad42['textAlign']='center',_0x48418a['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x48418a);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1134c7):_0x1134c7());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x4ce49d,_0x93bc5e){this['providerId']=_0x4ce49d,this['signInMethod']=_0x93bc5e;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x49ca1f){return ne('not\x20implemented');}['_linkToIdToken'](_0x1a3c07,_0xbe7a7e){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x172af7){return ne('not\x20implemented');}}async function zf(_0x647354,_0x3d4c5e){return Pe(_0x647354,'POST','/v1/accounts:signUp',_0x3d4c5e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x41047c,_0x116d9f){return en(_0x41047c,'POST','/v1/accounts:signInWithPassword',ke(_0x41047c,_0x116d9f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x3291,_0x289726){return en(_0x3291,'POST','/v1/accounts:signInWithEmailLink',ke(_0x3291,_0x289726));}async function Yf(_0x1c0cda,_0xc92502){return en(_0x1c0cda,'POST','/v1/accounts:signInWithEmailLink',ke(_0x1c0cda,_0xc92502));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x4ba19a,_0x595f09,_0x18d257,_0x336c5f=null){super('password',_0x18d257),this['_email']=_0x4ba19a,this['_password']=_0x595f09,this['_tenantId']=_0x336c5f;}static['_fromEmailAndPassword'](_0x528a3b,_0x35f53f){return new $t(_0x528a3b,_0x35f53f,'password');}static['_fromEmailAndCode'](_0x42af87,_0x3e1fce,_0x10fb76=null){return new $t(_0x42af87,_0x3e1fce,'emailLink',_0x10fb76);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x3ff8d8){const _0x593ff4=typeof _0x3ff8d8=='string'?JSON['parse'](_0x3ff8d8):_0x3ff8d8;if(_0x593ff4!=null&&_0x593ff4['email']&&(_0x593ff4!=null&&_0x593ff4['password'])){if(_0x593ff4['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x593ff4['email'],_0x593ff4['password']);if(_0x593ff4['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x593ff4['email'],_0x593ff4['password'],_0x593ff4['tenantId']);}return null;}async['_getIdTokenResponse'](_0x39c842){switch(this['signInMethod']){case'password':const _0x518ca2={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x39c842,_0x518ca2,'signInWithPassword',jf);case'emailLink':return Kf(_0x39c842,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x39c842,'internal-error');}}async['_linkToIdToken'](_0xbcb603,_0x442d0){switch(this['signInMethod']){case'password':const _0x2512f0={'idToken':_0x442d0,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0xbcb603,_0x2512f0,'signUpPassword',zf);case'emailLink':return Yf(_0xbcb603,{'idToken':_0x442d0,'email':this['_email'],'oobCode':this['_password']});default:Y(_0xbcb603,'internal-error');}}['_getReauthenticationResolver'](_0xcfa923){return this['_getIdTokenResponse'](_0xcfa923);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x1b0ed0,_0x52ebcc){return en(_0x1b0ed0,'POST','/v1/accounts:signInWithIdp',ke(_0x1b0ed0,_0x52ebcc));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x376bcc){const _0x2beb18=new $e(_0x376bcc['providerId'],_0x376bcc['signInMethod']);return _0x376bcc['idToken']||_0x376bcc['accessToken']?(_0x376bcc['idToken']&&(_0x2beb18['idToken']=_0x376bcc['idToken']),_0x376bcc['accessToken']&&(_0x2beb18['accessToken']=_0x376bcc['accessToken']),_0x376bcc['nonce']&&!_0x376bcc['pendingToken']&&(_0x2beb18['nonce']=_0x376bcc['nonce']),_0x376bcc['pendingToken']&&(_0x2beb18['pendingToken']=_0x376bcc['pendingToken'])):_0x376bcc['oauthToken']&&_0x376bcc['oauthTokenSecret']?(_0x2beb18['accessToken']=_0x376bcc['oauthToken'],_0x2beb18['secret']=_0x376bcc['oauthTokenSecret']):Y('argument-error'),_0x2beb18;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x5bb656){const _0x1e19d8=typeof _0x5bb656=='string'?JSON['parse'](_0x5bb656):_0x5bb656,{providerId:_0x2a5d31,signInMethod:_0xf79ab4,..._0x3cea80}=_0x1e19d8;if(!_0x2a5d31||!_0xf79ab4)return null;const _0x1ce9f6=new $e(_0x2a5d31,_0xf79ab4);return _0x1ce9f6['idToken']=_0x3cea80['idToken']||void 0x0,_0x1ce9f6['accessToken']=_0x3cea80['accessToken']||void 0x0,_0x1ce9f6['secret']=_0x3cea80['secret'],_0x1ce9f6['nonce']=_0x3cea80['nonce'],_0x1ce9f6['pendingToken']=_0x3cea80['pendingToken']||null,_0x1ce9f6;}['_getIdTokenResponse'](_0x44379e){const _0x5f18ca=this['buildRequest']();return nt(_0x44379e,_0x5f18ca);}['_linkToIdToken'](_0x451ef3,_0x4cf7a9){const _0x2fd568=this['buildRequest']();return _0x2fd568['idToken']=_0x4cf7a9,nt(_0x451ef3,_0x2fd568);}['_getReauthenticationResolver'](_0x2486af){const _0x2c20ba=this['buildRequest']();return _0x2c20ba['autoCreate']=!0x1,nt(_0x2486af,_0x2c20ba);}['buildRequest'](){const _0xeba9ce={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0xeba9ce['pendingToken']=this['pendingToken'];else{const _0x5ec646={};this['idToken']&&(_0x5ec646['id_token']=this['idToken']),this['accessToken']&&(_0x5ec646['access_token']=this['accessToken']),this['secret']&&(_0x5ec646['oauth_token_secret']=this['secret']),_0x5ec646['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x5ec646['nonce']=this['nonce']),_0xeba9ce['postBody']=ut(_0x5ec646);}return _0xeba9ce;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x21e718){switch(_0x21e718){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x52905d){const _0x5cf50f=Ct(Tt(_0x52905d))['link'],_0xf76f86=_0x5cf50f?Ct(Tt(_0x5cf50f))['deep_link_id']:null,_0x495578=Ct(Tt(_0x52905d))['deep_link_id'];return(_0x495578?Ct(Tt(_0x495578))['link']:null)||_0x495578||_0xf76f86||_0x5cf50f||_0x52905d;}class Rs{constructor(_0x3bf004){const _0x937176=Ct(Tt(_0x3bf004)),_0x409f12=_0x937176['apiKey']??null,_0x3f28fa=_0x937176['oobCode']??null,_0x51eed3=Jf(_0x937176['mode']??null);m(_0x409f12&&_0x3f28fa&&_0x51eed3,'argument-error'),this['apiKey']=_0x409f12,this['operation']=_0x51eed3,this['code']=_0x3f28fa,this['continueUrl']=_0x937176['continueUrl']??null,this['languageCode']=_0x937176['lang']??null,this['tenantId']=_0x937176['tenantId']??null;}static['parseLink'](_0x408506){const _0x16e250=Xf(_0x408506);try{return new Rs(_0x16e250);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x52fb8a,_0x5a30da){return $t['_fromEmailAndPassword'](_0x52fb8a,_0x5a30da);}static['credentialWithLink'](_0x1202da,_0x5bbbdc){const _0x482631=Rs['parseLink'](_0x5bbbdc);return m(_0x482631,'argument-error'),$t['_fromEmailAndCode'](_0x1202da,_0x482631['code'],_0x482631['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x37bc2e){this['providerId']=_0x37bc2e,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x1ecaa9){this['defaultLanguageCode']=_0x1ecaa9;}['setCustomParameters'](_0x598a22){return this['customParameters']=_0x598a22,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5caada){return this['scopes']['includes'](_0x5caada)||this['scopes']['push'](_0x5caada),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0xa85ca4){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0xa85ca4});}static['credentialFromResult'](_0x1db830){return ue['credentialFromTaggedObject'](_0x1db830);}static['credentialFromError'](_0x5cc89a){return ue['credentialFromTaggedObject'](_0x5cc89a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x267ab8}){if(!_0x267ab8||!('oauthAccessToken'in _0x267ab8)||!_0x267ab8['oauthAccessToken'])return null;try{return ue['credential'](_0x267ab8['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x1a7657,_0x4639ee){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x1a7657,'accessToken':_0x4639ee});}static['credentialFromResult'](_0x155051){return de['credentialFromTaggedObject'](_0x155051);}static['credentialFromError'](_0x405465){return de['credentialFromTaggedObject'](_0x405465['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2ff818}){if(!_0x2ff818)return null;const {oauthIdToken:_0x278863,oauthAccessToken:_0x4e0daf}=_0x2ff818;if(!_0x278863&&!_0x4e0daf)return null;try{return de['credential'](_0x278863,_0x4e0daf);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x34a86c){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x34a86c});}static['credentialFromResult'](_0x5b73e9){return fe['credentialFromTaggedObject'](_0x5b73e9);}static['credentialFromError'](_0x42c178){return fe['credentialFromTaggedObject'](_0x42c178['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x215bda}){if(!_0x215bda||!('oauthAccessToken'in _0x215bda)||!_0x215bda['oauthAccessToken'])return null;try{return fe['credential'](_0x215bda['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x35ca23,_0x118f3b){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x35ca23,'oauthTokenSecret':_0x118f3b});}static['credentialFromResult'](_0xeb4413){return pe['credentialFromTaggedObject'](_0xeb4413);}static['credentialFromError'](_0x2de070){return pe['credentialFromTaggedObject'](_0x2de070['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x51fa64}){if(!_0x51fa64)return null;const {oauthAccessToken:_0x2d884e,oauthTokenSecret:_0x536229}=_0x51fa64;if(!_0x2d884e||!_0x536229)return null;try{return pe['credential'](_0x2d884e,_0x536229);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x57f9db,_0x343d88){return en(_0x57f9db,'POST','/v1/accounts:signUp',ke(_0x57f9db,_0x343d88));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x17bfe4){this['user']=_0x17bfe4['user'],this['providerId']=_0x17bfe4['providerId'],this['_tokenResponse']=_0x17bfe4['_tokenResponse'],this['operationType']=_0x17bfe4['operationType'];}static async['_fromIdTokenResponse'](_0x517397,_0x56f5ec,_0x3e8a71,_0x4e6dd4=!0x1){const _0x2d99f2=await j['_fromIdTokenResponse'](_0x517397,_0x3e8a71,_0x4e6dd4),_0x311de6=Nr(_0x3e8a71);return new Ge({'user':_0x2d99f2,'providerId':_0x311de6,'_tokenResponse':_0x3e8a71,'operationType':_0x56f5ec});}static async['_forOperation'](_0x1481c8,_0x53c061,_0x156270){await _0x1481c8['_updateTokensIfNecessary'](_0x156270,!0x0);const _0x58dbc5=Nr(_0x156270);return new Ge({'user':_0x1481c8,'providerId':_0x58dbc5,'_tokenResponse':_0x156270,'operationType':_0x53c061});}}function Nr(_0x2327f9){return _0x2327f9['providerId']?_0x2327f9['providerId']:'phoneNumber'in _0x2327f9?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x202021,_0x1d2333,_0x5c1517,_0x228989){super(_0x1d2333['code'],_0x1d2333['message']),this['operationType']=_0x5c1517,this['user']=_0x228989,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x202021['name'],'tenantId':_0x202021['tenantId']??void 0x0,'_serverResponse':_0x1d2333['customData']['_serverResponse'],'operationType':_0x5c1517};}static['_fromErrorAndOperation'](_0x5b935b,_0x96116e,_0x201300,_0x56ab90){return new On(_0x5b935b,_0x96116e,_0x201300,_0x56ab90);}}function Ba(_0x4dabec,_0x3eda7e,_0x57e123,_0xe880f0){return(_0x3eda7e==='reauthenticate'?_0x57e123['_getReauthenticationResolver'](_0x4dabec):_0x57e123['_getIdTokenResponse'](_0x4dabec))['catch'](_0x443e45=>{throw _0x443e45['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x4dabec,_0x443e45,_0x3eda7e,_0xe880f0):_0x443e45;});}async function ep(_0x158299,_0x5e58ba,_0x3cf858=!0x1){const _0x56f2a2=await Ht(_0x158299,_0x5e58ba['_linkToIdToken'](_0x158299['auth'],await _0x158299['getIdToken']()),_0x3cf858);return Ge['_forOperation'](_0x158299,'link',_0x56f2a2);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x44305c,_0xb39639,_0x489be2=!0x1){const {auth:_0x241f45}=_0x44305c;if($(_0x241f45['app']))return Promise['reject'](re(_0x241f45));const _0x44ee5e='reauthenticate';try{const _0x13c2f7=await Ht(_0x44305c,Ba(_0x241f45,_0x44ee5e,_0xb39639,_0x44305c),_0x489be2);m(_0x13c2f7['idToken'],_0x241f45,'internal-error');const _0x17e054=Ts(_0x13c2f7['idToken']);m(_0x17e054,_0x241f45,'internal-error');const {sub:_0x1d68f4}=_0x17e054;return m(_0x44305c['uid']===_0x1d68f4,_0x241f45,'user-mismatch'),Ge['_forOperation'](_0x44305c,_0x44ee5e,_0x13c2f7);}catch(_0x154859){throw(_0x154859==null?void 0x0:_0x154859['code'])==='auth/user-not-found'&&Y(_0x241f45,'user-mismatch'),_0x154859;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x54512b,_0x37d3e7,_0x849a98=!0x1){if($(_0x54512b['app']))return Promise['reject'](re(_0x54512b));const _0x54f9fc='signIn',_0xcb289d=await Ba(_0x54512b,_0x54f9fc,_0x37d3e7),_0x3f3057=await Ge['_fromIdTokenResponse'](_0x54512b,_0x54f9fc,_0xcb289d);return _0x849a98||await _0x54512b['_updateCurrentUser'](_0x3f3057['user']),_0x3f3057;}async function np(_0x6c54b7,_0x424b23){return Va(Ke(_0x6c54b7),_0x424b23);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x2fa021){const _0xdcc780=Ke(_0x2fa021);_0xdcc780['_getPasswordPolicyInternal']()&&await _0xdcc780['_updatePasswordPolicy']();}async function L_(_0x48f986,_0x1257ac,_0x310bf4){if($(_0x48f986['app']))return Promise['reject'](re(_0x48f986));const _0x4db398=Ke(_0x48f986),_0x31e971=await xi(_0x4db398,{'returnSecureToken':!0x0,'email':_0x1257ac,'password':_0x310bf4,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x444e03=>{throw _0x444e03['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x48f986),_0x444e03;}),_0x4fcdbb=await Ge['_fromIdTokenResponse'](_0x4db398,'signIn',_0x31e971);return await _0x4db398['_updateCurrentUser'](_0x4fcdbb['user']),_0x4fcdbb;}function x_(_0x21f68d,_0x37d06c,_0xb0c317){return $(_0x21f68d['app'])?Promise['reject'](re(_0x21f68d)):np(P(_0x21f68d),yt['credential'](_0x37d06c,_0xb0c317))['catch'](async _0x5016be=>{throw _0x5016be['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x21f68d),_0x5016be;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x511cf3,_0x413eb1){return P(_0x511cf3)['setPersistence'](_0x413eb1);}function ip(_0x35e472,_0xdcf4c5,_0x34a37c,_0x926131){return P(_0x35e472)['onIdTokenChanged'](_0xdcf4c5,_0x34a37c,_0x926131);}function sp(_0x5a0de5,_0xb349a9,_0x851c4f){return P(_0x5a0de5)['beforeAuthStateChanged'](_0xb349a9,_0x851c4f);}function U_(_0x1deb25,_0x1b4ea8,_0x482fb2,_0x33c2cb){return P(_0x1deb25)['onAuthStateChanged'](_0x1b4ea8,_0x482fb2,_0x33c2cb);}function W_(_0x285877){return P(_0x285877)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x5695f6,_0x54e01){this['storageRetriever']=_0x5695f6,this['type']=_0x54e01;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x25fed9,_0x21d99a){return this['storage']['setItem'](_0x25fed9,JSON['stringify'](_0x21d99a)),Promise['resolve']();}['_get'](_0x43b160){const _0x1d3f13=this['storage']['getItem'](_0x43b160);return Promise['resolve'](_0x1d3f13?JSON['parse'](_0x1d3f13):null);}['_remove'](_0x12e019){return this['storage']['removeItem'](_0x12e019),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x13511b,_0x543bc6)=>this['onStorageEvent'](_0x13511b,_0x543bc6),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x2c7ea9){for(const _0xe59a72 of Object['keys'](this['listeners'])){const _0x13ce18=this['storage']['getItem'](_0xe59a72),_0x4d715d=this['localCache'][_0xe59a72];_0x13ce18!==_0x4d715d&&_0x2c7ea9(_0xe59a72,_0x4d715d,_0x13ce18);}}['onStorageEvent'](_0xec96d5,_0x14ca12=!0x1){if(!_0xec96d5['key']){this['forAllChangedKeys']((_0x1b2a21,_0x1ab527,_0x3fce69)=>{this['notifyListeners'](_0x1b2a21,_0x3fce69);});return;}const _0x2d7377=_0xec96d5['key'];_0x14ca12?this['detachListener']():this['stopPolling']();const _0x1fd9ab=()=>{const _0x4786e2=this['storage']['getItem'](_0x2d7377);!_0x14ca12&&this['localCache'][_0x2d7377]===_0x4786e2||this['notifyListeners'](_0x2d7377,_0x4786e2);},_0x50b6c4=this['storage']['getItem'](_0x2d7377);Af()&&_0x50b6c4!==_0xec96d5['newValue']&&_0xec96d5['newValue']!==_0xec96d5['oldValue']?setTimeout(_0x1fd9ab,op):_0x1fd9ab();}['notifyListeners'](_0x1469be,_0x396fdc){this['localCache'][_0x1469be]=_0x396fdc;const _0x271a8d=this['listeners'][_0x1469be];if(_0x271a8d){for(const _0x4276a5 of Array['from'](_0x271a8d))_0x4276a5(_0x396fdc&&JSON['parse'](_0x396fdc));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x2fe5d5,_0x1d0b26,_0x28e546)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x2fe5d5,'oldValue':_0x1d0b26,'newValue':_0x28e546}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x132262,_0x27b596){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x132262]||(this['listeners'][_0x132262]=new Set(),this['localCache'][_0x132262]=this['storage']['getItem'](_0x132262)),this['listeners'][_0x132262]['add'](_0x27b596);}['_removeListener'](_0x1cb2ad,_0x50465e){this['listeners'][_0x1cb2ad]&&(this['listeners'][_0x1cb2ad]['delete'](_0x50465e),this['listeners'][_0x1cb2ad]['size']===0x0&&delete this['listeners'][_0x1cb2ad]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x5759b7,_0x439ffe){await super['_set'](_0x5759b7,_0x439ffe),this['localCache'][_0x5759b7]=JSON['stringify'](_0x439ffe);}async['_get'](_0x438613){const _0x508e0a=await super['_get'](_0x438613);return this['localCache'][_0x438613]=JSON['stringify'](_0x508e0a),_0x508e0a;}async['_remove'](_0xa708cf){await super['_remove'](_0xa708cf),delete this['localCache'][_0xa708cf];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x176da1,_0x566fab){}['_removeListener'](_0x10bac3,_0x20b7a8){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0xf7d049){return Promise['all'](_0xf7d049['map'](async _0x5b85f4=>{try{return{'fulfilled':!0x0,'value':await _0x5b85f4};}catch(_0x1b43fc){return{'fulfilled':!0x1,'reason':_0x1b43fc};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x49cfaf){this['eventTarget']=_0x49cfaf,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x542007){const _0x81ed74=this['receivers']['find'](_0x5105d5=>_0x5105d5['isListeningto'](_0x542007));if(_0x81ed74)return _0x81ed74;const _0x3cc2d5=new Xn(_0x542007);return this['receivers']['push'](_0x3cc2d5),_0x3cc2d5;}['isListeningto'](_0x1344d9){return this['eventTarget']===_0x1344d9;}async['handleEvent'](_0x11c8ea){const _0x27fea3=_0x11c8ea,{eventId:_0x6c6002,eventType:_0x10756d,data:_0x500894}=_0x27fea3['data'],_0xcd6349=this['handlersMap'][_0x10756d];if(!(_0xcd6349!=null&&_0xcd6349['size']))return;_0x27fea3['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x6c6002,'eventType':_0x10756d});const _0x2841cf=Array['from'](_0xcd6349)['map'](async _0x4c9d02=>_0x4c9d02(_0x27fea3['origin'],_0x500894)),_0x36b473=await cp(_0x2841cf);_0x27fea3['ports'][0x0]['postMessage']({'status':'done','eventId':_0x6c6002,'eventType':_0x10756d,'response':_0x36b473});}['_subscribe'](_0x23b760,_0x4532ca){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x23b760]||(this['handlersMap'][_0x23b760]=new Set()),this['handlersMap'][_0x23b760]['add'](_0x4532ca);}['_unsubscribe'](_0x55f647,_0x3af575){this['handlersMap'][_0x55f647]&&_0x3af575&&this['handlersMap'][_0x55f647]['delete'](_0x3af575),(!_0x3af575||this['handlersMap'][_0x55f647]['size']===0x0)&&delete this['handlersMap'][_0x55f647],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x15001c='',_0x5cfae3=0xa){let _0x1a9c66='';for(let _0x2320f0=0x0;_0x2320f0<_0x5cfae3;_0x2320f0++)_0x1a9c66+=Math['floor'](Math['random']()*0xa);return _0x15001c+_0x1a9c66;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x8e5db5){this['target']=_0x8e5db5,this['handlers']=new Set();}['removeMessageHandler'](_0x1b02fa){_0x1b02fa['messageChannel']&&(_0x1b02fa['messageChannel']['port1']['removeEventListener']('message',_0x1b02fa['onMessage']),_0x1b02fa['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x1b02fa);}async['_send'](_0x5205b2,_0xeddbf6,_0x33d5f2=0x32){const _0x3f7abe=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x3f7abe)throw new Error('connection_unavailable');let _0x325af1,_0x517b13;return new Promise((_0x48f2ff,_0x3f848a)=>{const _0x29b3a5=As('',0x14);_0x3f7abe['port1']['start']();const _0x205f90=setTimeout(()=>{_0x3f848a(new Error('unsupported_event'));},_0x33d5f2);_0x517b13={'messageChannel':_0x3f7abe,'onMessage'(_0x4217dd){const _0x41a09e=_0x4217dd;if(_0x41a09e['data']['eventId']===_0x29b3a5)switch(_0x41a09e['data']['status']){case'ack':clearTimeout(_0x205f90),_0x325af1=setTimeout(()=>{_0x3f848a(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x325af1),_0x48f2ff(_0x41a09e['data']['response']);break;default:clearTimeout(_0x205f90),clearTimeout(_0x325af1),_0x3f848a(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x517b13),_0x3f7abe['port1']['addEventListener']('message',_0x517b13['onMessage']),this['target']['postMessage']({'eventType':_0x5205b2,'eventId':_0x29b3a5,'data':_0xeddbf6},[_0x3f7abe['port2']]);})['finally'](()=>{_0x517b13&&this['removeMessageHandler'](_0x517b13);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x6ec5b8){Z()['location']['href']=_0x6ec5b8;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x22714f;return((_0x22714f=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x22714f['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0xc26ee1){this['request']=_0xc26ee1;}['toPromise'](){return new Promise((_0x569298,_0x3a4f3c)=>{this['request']['addEventListener']('success',()=>{_0x569298(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x3a4f3c(this['request']['error']);});});}}function Zn(_0xe8d8f3,_0xe6c81d){return _0xe8d8f3['transaction']([Mn],_0xe6c81d?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x2755c6=indexedDB['deleteDatabase'](Ka);return new nn(_0x2755c6)['toPromise']();}function Qa(){const _0x4d0b6b=indexedDB['open'](Ka,pp);return new Promise((_0x56e55a,_0x254662)=>{_0x4d0b6b['addEventListener']('error',()=>{_0x254662(_0x4d0b6b['error']);}),_0x4d0b6b['addEventListener']('upgradeneeded',()=>{const _0x3d11e2=_0x4d0b6b['result'];try{_0x3d11e2['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x37fd87){_0x254662(_0x37fd87);}}),_0x4d0b6b['addEventListener']('success',async()=>{const _0x33e17c=_0x4d0b6b['result'];_0x33e17c['objectStoreNames']['contains'](Mn)?_0x56e55a(_0x33e17c):(_0x33e17c['close'](),await _p(),_0x56e55a(await Qa()));});});}async function Or(_0x295b72,_0x2b4068,_0x3410b3){const _0x30230e=Zn(_0x295b72,!0x0)['put']({[Ya]:_0x2b4068,'value':_0x3410b3});return new nn(_0x30230e)['toPromise']();}async function gp(_0x155c59,_0x1142ab){const _0x331854=Zn(_0x155c59,!0x1)['get'](_0x1142ab),_0x305f42=await new nn(_0x331854)['toPromise']();return _0x305f42===void 0x0?null:_0x305f42['value'];}function Dr(_0x565c95,_0x4a6e5d){const _0x5cba0e=Zn(_0x565c95,!0x0)['delete'](_0x4a6e5d);return new nn(_0x5cba0e)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x260929){let _0xdee908=0x0;for(;;)try{const _0x1c1409=await this['_openDb']();return await _0x260929(_0x1c1409);}catch(_0x53da3b){if(_0xdee908++>yp)throw _0x53da3b;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x4d4e17,_0x244c42)=>({'keyProcessed':(await this['_poll']())['includes'](_0x244c42['key'])})),this['receiver']['_subscribe']('ping',async(_0x22469b,_0x5d01c2)=>['keyChanged']);}async['initializeSender'](){var _0x5e44f1,_0x791bf9;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x4952b1=await this['sender']['_send']('ping',{},0x320);_0x4952b1&&(_0x5e44f1=_0x4952b1[0x0])!=null&&_0x5e44f1['fulfilled']&&(_0x791bf9=_0x4952b1[0x0])!=null&&_0x791bf9['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x3eada6){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x3eada6},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0xec70c5=>{await Or(_0xec70c5,Dn,'1'),await Dr(_0xec70c5,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x4542c7){this['pendingWrites']++;try{await _0x4542c7();}finally{this['pendingWrites']--;}}async['_set'](_0x299028,_0x56c4a9){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x420472=>Or(_0x420472,_0x299028,_0x56c4a9)),this['localCache'][_0x299028]=_0x56c4a9,this['notifyServiceWorker'](_0x299028)));}async['_get'](_0x56c468){const _0x3fa27b=await this['_withRetries'](_0x1583b0=>gp(_0x1583b0,_0x56c468));return this['localCache'][_0x56c468]=_0x3fa27b,_0x3fa27b;}async['_remove'](_0x1b16b0){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x255ce3=>Dr(_0x255ce3,_0x1b16b0)),delete this['localCache'][_0x1b16b0],this['notifyServiceWorker'](_0x1b16b0)));}async['_poll'](){const _0x3dd8bf=await this['_withRetries'](_0x8e38e0=>{const _0x13da55=Zn(_0x8e38e0,!0x1)['getAll']();return new nn(_0x13da55)['toPromise']();});if(!_0x3dd8bf)return[];if(this['pendingWrites']!==0x0)return[];const _0x43042c=[],_0x344cec=new Set();if(_0x3dd8bf['length']!==0x0){for(const {fbase_key:_0x1f4064,value:_0x2554a1}of _0x3dd8bf)_0x344cec['add'](_0x1f4064),JSON['stringify'](this['localCache'][_0x1f4064])!==JSON['stringify'](_0x2554a1)&&(this['notifyListeners'](_0x1f4064,_0x2554a1),_0x43042c['push'](_0x1f4064));}for(const _0xb4a9e1 of Object['keys'](this['localCache']))this['localCache'][_0xb4a9e1]&&!_0x344cec['has'](_0xb4a9e1)&&(this['notifyListeners'](_0xb4a9e1,null),_0x43042c['push'](_0xb4a9e1));return _0x43042c;}['notifyListeners'](_0x53aa29,_0x2cd4c6){this['localCache'][_0x53aa29]=_0x2cd4c6;const _0x3ed224=this['listeners'][_0x53aa29];if(_0x3ed224){for(const _0x1f6484 of Array['from'](_0x3ed224))_0x1f6484(_0x2cd4c6);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x312570,_0x39cd79){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x312570]||(this['listeners'][_0x312570]=new Set(),this['_get'](_0x312570)),this['listeners'][_0x312570]['add'](_0x39cd79);}['_removeListener'](_0x3d9978,_0x4dacde){this['listeners'][_0x3d9978]&&(this['listeners'][_0x3d9978]['delete'](_0x4dacde),this['listeners'][_0x3d9978]['size']===0x0&&delete this['listeners'][_0x3d9978]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x17bd75,_0x2022ae){return _0x2022ae?ie(_0x2022ae):(m(_0x17bd75['_popupRedirectResolver'],_0x17bd75,'argument-error'),_0x17bd75['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x1462be){super('custom','custom'),this['params']=_0x1462be;}['_getIdTokenResponse'](_0x8b1781){return nt(_0x8b1781,this['_buildIdpRequest']());}['_linkToIdToken'](_0x2b7a8e,_0x278d16){return nt(_0x2b7a8e,this['_buildIdpRequest'](_0x278d16));}['_getReauthenticationResolver'](_0x530961){return nt(_0x530961,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x3455c7){const _0x40e25e={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x3455c7&&(_0x40e25e['idToken']=_0x3455c7),_0x40e25e;}}function Ip(_0x253913){return Va(_0x253913['auth'],new ks(_0x253913),_0x253913['bypassAuthState']);}function wp(_0x548632){const {auth:_0x16d0d0,user:_0x17fc91}=_0x548632;return m(_0x17fc91,_0x16d0d0,'internal-error'),tp(_0x17fc91,new ks(_0x548632),_0x548632['bypassAuthState']);}async function Cp(_0x599b04){const {auth:_0xcbc1c0,user:_0x4776df}=_0x599b04;return m(_0x4776df,_0xcbc1c0,'internal-error'),ep(_0x4776df,new ks(_0x599b04),_0x599b04['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x3f0cb0,_0x1e5efb,_0x2120f3,_0x35efec,_0x5233c9=!0x1){this['auth']=_0x3f0cb0,this['resolver']=_0x2120f3,this['user']=_0x35efec,this['bypassAuthState']=_0x5233c9,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x1e5efb)?_0x1e5efb:[_0x1e5efb];}['execute'](){return new Promise(async(_0x4bee23,_0x103a42)=>{this['pendingPromise']={'resolve':_0x4bee23,'reject':_0x103a42};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x20198d){this['reject'](_0x20198d);}});}async['onAuthEvent'](_0x25d32a){const {urlResponse:_0xfb8231,sessionId:_0x5e1bfa,postBody:_0x236997,tenantId:_0x30be4e,error:_0x5ad69d,type:_0x51646c}=_0x25d32a;if(_0x5ad69d){this['reject'](_0x5ad69d);return;}const _0x337eb7={'auth':this['auth'],'requestUri':_0xfb8231,'sessionId':_0x5e1bfa,'tenantId':_0x30be4e||void 0x0,'postBody':_0x236997||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x51646c)(_0x337eb7));}catch(_0x1df372){this['reject'](_0x1df372);}}['onError'](_0x1f6478){this['reject'](_0x1f6478);}['getIdpTask'](_0x511ce5){switch(_0x511ce5){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x2279f4){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x2279f4),this['unregisterAndCleanUp']();}['reject'](_0x303fa7){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x303fa7),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x7ff5fd,_0x53ce4c,_0x61faf1,_0x2c36c7,_0x333926){super(_0x7ff5fd,_0x53ce4c,_0x2c36c7,_0x333926),this['provider']=_0x61faf1,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x4df48a=await this['execute']();return m(_0x4df48a,this['auth'],'internal-error'),_0x4df48a;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x58d6ed=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x58d6ed),this['authWindow']['associatedEvent']=_0x58d6ed,this['resolver']['_originValidation'](this['auth'])['catch'](_0x1050f7=>{this['reject'](_0x1050f7);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x1eede3=>{_0x1eede3||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x58af70;return((_0x58af70=this['authWindow'])==null?void 0x0:_0x58af70['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x1a644b=()=>{var _0x3f556e,_0x4f29d0;if((_0x4f29d0=(_0x3f556e=this['authWindow'])==null?void 0x0:_0x3f556e['window'])!=null&&_0x4f29d0['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x1a644b,Tp['get']());};_0x1a644b();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x19dfbf,_0x4dd7ad,_0xb2858a=!0x1){super(_0x19dfbf,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x4dd7ad,void 0x0,_0xb2858a),this['eventId']=null;}async['execute'](){let _0x5bd3e6=hn['get'](this['auth']['_key']());if(!_0x5bd3e6){try{const _0x36b500=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x5bd3e6=()=>Promise['resolve'](_0x36b500);}catch(_0x5e42cb){_0x5bd3e6=()=>Promise['reject'](_0x5e42cb);}hn['set'](this['auth']['_key'](),_0x5bd3e6);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x5bd3e6();}async['onAuthEvent'](_0x3156ce){if(_0x3156ce['type']==='signInViaRedirect')return super['onAuthEvent'](_0x3156ce);if(_0x3156ce['type']==='unknown'){this['resolve'](null);return;}if(_0x3156ce['eventId']){const _0x2c71a2=await this['auth']['_redirectUserForId'](_0x3156ce['eventId']);if(_0x2c71a2)return this['user']=_0x2c71a2,super['onAuthEvent'](_0x3156ce);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x1d48a5,_0x32c0e5){const _0x419cc1=Pp(_0x32c0e5),_0x448123=kp(_0x1d48a5);if(!await _0x448123['_isAvailable']())return!0x1;const _0x3165a5=await _0x448123['_get'](_0x419cc1)==='true';return await _0x448123['_remove'](_0x419cc1),_0x3165a5;}function Ap(_0x399815,_0x65ee6f){hn['set'](_0x399815['_key'](),_0x65ee6f);}function kp(_0x2def15){return ie(_0x2def15['_redirectPersistence']);}function Pp(_0x3a1a2f){return ln(Sp,_0x3a1a2f['config']['apiKey'],_0x3a1a2f['name']);}async function Np(_0x5c1f95,_0x54f752,_0x92eac3=!0x1){if($(_0x5c1f95['app']))return Promise['reject'](re(_0x5c1f95));const _0x5cd310=Ke(_0x5c1f95),_0x13cc13=Ep(_0x5cd310,_0x54f752),_0x15d762=await new bp(_0x5cd310,_0x13cc13,_0x92eac3)['execute']();return _0x15d762&&!_0x92eac3&&(delete _0x15d762['user']['_redirectEventId'],await _0x5cd310['_persistUserIfCurrent'](_0x15d762['user']),await _0x5cd310['_setRedirectUser'](null,_0x54f752)),_0x15d762;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x656f){this['auth']=_0x656f,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x1ae143){this['consumers']['add'](_0x1ae143),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x1ae143)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x1ae143),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x761498){this['consumers']['delete'](_0x761498);}['onEvent'](_0x3f1d38){if(this['hasEventBeenHandled'](_0x3f1d38))return!0x1;let _0x1812f6=!0x1;return this['consumers']['forEach'](_0x493619=>{this['isEventForConsumer'](_0x3f1d38,_0x493619)&&(_0x1812f6=!0x0,this['sendToConsumer'](_0x3f1d38,_0x493619),this['saveEventToCache'](_0x3f1d38));}),this['hasHandledPotentialRedirect']||!Mp(_0x3f1d38)||(this['hasHandledPotentialRedirect']=!0x0,_0x1812f6||(this['queuedRedirectEvent']=_0x3f1d38,_0x1812f6=!0x0)),_0x1812f6;}['sendToConsumer'](_0x290075,_0x4a8d23){var _0x4395ef;if(_0x290075['error']&&!Za(_0x290075)){const _0xd5a2cf=((_0x4395ef=_0x290075['error']['code'])==null?void 0x0:_0x4395ef['split']('auth/')[0x1])||'internal-error';_0x4a8d23['onError'](X(this['auth'],_0xd5a2cf));}else _0x4a8d23['onAuthEvent'](_0x290075);}['isEventForConsumer'](_0x17cd2a,_0x1f780d){const _0x573694=_0x1f780d['eventId']===null||!!_0x17cd2a['eventId']&&_0x17cd2a['eventId']===_0x1f780d['eventId'];return _0x1f780d['filter']['includes'](_0x17cd2a['type'])&&_0x573694;}['hasEventBeenHandled'](_0x65b81c){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x65b81c));}['saveEventToCache'](_0x28e2e5){this['cachedEventUids']['add'](Mr(_0x28e2e5)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x5cb123){return[_0x5cb123['type'],_0x5cb123['eventId'],_0x5cb123['sessionId'],_0x5cb123['tenantId']]['filter'](_0x3d0d03=>_0x3d0d03)['join']('-');}function Za({type:_0x5513b6,error:_0x5f3955}){return _0x5513b6==='unknown'&&(_0x5f3955==null?void 0x0:_0x5f3955['code'])==='auth/no-auth-event';}function Mp(_0x14092d){switch(_0x14092d['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x14092d);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0xa9b9bd,_0x4d0c68={}){return Pe(_0xa9b9bd,'GET','/v1/projects',_0x4d0c68);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x3bdd62){if(_0x3bdd62['config']['emulator'])return;const {authorizedDomains:_0x3a4c16}=await Lp(_0x3bdd62);for(const _0x4ce315 of _0x3a4c16)try{if(Wp(_0x4ce315))return;}catch{}Y(_0x3bdd62,'unauthorized-domain');}function Wp(_0x4a7ece){const _0x2dd264=Mi(),{protocol:_0xb5b83e,hostname:_0xabf38a}=new URL(_0x2dd264);if(_0x4a7ece['startsWith']('chrome-extension://')){const _0x85adf3=new URL(_0x4a7ece);return _0x85adf3['hostname']===''&&_0xabf38a===''?_0xb5b83e==='chrome-extension:'&&_0x4a7ece['replace']('chrome-extension://','')===_0x2dd264['replace']('chrome-extension://',''):_0xb5b83e==='chrome-extension:'&&_0x85adf3['hostname']===_0xabf38a;}if(!Fp['test'](_0xb5b83e))return!0x1;if(xp['test'](_0x4a7ece))return _0xabf38a===_0x4a7ece;const _0x2d5e27=_0x4a7ece['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x2d5e27+'|'+_0x2d5e27+')$','i')['test'](_0xabf38a);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x175eb1=Z()['___jsl'];if(_0x175eb1!=null&&_0x175eb1['H']){for(const _0x7c4c48 of Object['keys'](_0x175eb1['H']))if(_0x175eb1['H'][_0x7c4c48]['r']=_0x175eb1['H'][_0x7c4c48]['r']||[],_0x175eb1['H'][_0x7c4c48]['L']=_0x175eb1['H'][_0x7c4c48]['L']||[],_0x175eb1['H'][_0x7c4c48]['r']=[..._0x175eb1['H'][_0x7c4c48]['L']],_0x175eb1['CP']){for(let _0xad0b66=0x0;_0xad0b66<_0x175eb1['CP']['length'];_0xad0b66++)_0x175eb1['CP'][_0xad0b66]=null;}}}function Vp(_0x5c8116){return new Promise((_0x277104,_0x409098)=>{var _0x3f89d7,_0xce85fa,_0xf0529c;function _0x3de7d5(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x277104(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x409098(X(_0x5c8116,'network-request-failed'));},'timeout':Bp['get']()});}if((_0xce85fa=(_0x3f89d7=Z()['gapi'])==null?void 0x0:_0x3f89d7['iframes'])!=null&&_0xce85fa['Iframe'])_0x277104(gapi['iframes']['getContext']());else{if((_0xf0529c=Z()['gapi'])!=null&&_0xf0529c['load'])_0x3de7d5();else{const _0x163451=Ff('iframefcb');return Z()[_0x163451]=()=>{gapi['load']?_0x3de7d5():_0x409098(X(_0x5c8116,'network-request-failed'));},xa(xf()+'?onload='+_0x163451)['catch'](_0x4cff5f=>_0x409098(_0x4cff5f));}}})['catch'](_0x22313a=>{throw un=null,_0x22313a;});}let un=null;function Hp(_0xafc939){return un=un||Vp(_0xafc939),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x5371b3){const _0x11a993=_0x5371b3['config'];m(_0x11a993['authDomain'],_0x5371b3,'auth-domain-config-required');const _0x4d5e33=_0x11a993['emulator']?Cs(_0x11a993,qp):'https://'+_0x5371b3['config']['authDomain']+'/'+Gp,_0x48a8c5={'apiKey':_0x11a993['apiKey'],'appName':_0x5371b3['name'],'v':dt},_0x26cff0=jp['get'](_0x5371b3['config']['apiHost']);_0x26cff0&&(_0x48a8c5['eid']=_0x26cff0);const _0x262bd1=_0x5371b3['_getFrameworks']();return _0x262bd1['length']&&(_0x48a8c5['fw']=_0x262bd1['join'](',')),_0x4d5e33+'?'+ut(_0x48a8c5)['slice'](0x1);}async function Yp(_0x41fb43){const _0x14574b=await Hp(_0x41fb43),_0xfb999=Z()['gapi'];return m(_0xfb999,_0x41fb43,'internal-error'),_0x14574b['open']({'where':document['body'],'url':Kp(_0x41fb43),'messageHandlersFilter':_0xfb999['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x45fcab=>new Promise(async(_0x115fcb,_0x321f7e)=>{await _0x45fcab['restyle']({'setHideOnLeave':!0x1});const _0x2a9d97=X(_0x41fb43,'network-request-failed'),_0x326f86=Z()['setTimeout'](()=>{_0x321f7e(_0x2a9d97);},$p['get']());function _0x2ca75f(){Z()['clearTimeout'](_0x326f86),_0x115fcb(_0x45fcab);}_0x45fcab['ping'](_0x2ca75f)['then'](_0x2ca75f,()=>{_0x321f7e(_0x2a9d97);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x14ac03){this['window']=_0x14ac03,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x8af31d,_0x1cb85b,_0x4e70d0,_0x1b7931=Jp,_0x16ff1b=Xp){const _0x3c0a49=Math['max']((window['screen']['availHeight']-_0x16ff1b)/0x2,0x0)['toString'](),_0x353ade=Math['max']((window['screen']['availWidth']-_0x1b7931)/0x2,0x0)['toString']();let _0x1ae7b9='';const _0x5af39e={...Qp,'width':_0x1b7931['toString'](),'height':_0x16ff1b['toString'](),'top':_0x3c0a49,'left':_0x353ade},_0x11761e=W()['toLowerCase']();_0x4e70d0&&(_0x1ae7b9=ka(_0x11761e)?Zp:_0x4e70d0),Ra(_0x11761e)&&(_0x1cb85b=_0x1cb85b||e_,_0x5af39e['scrollbars']='yes');const _0x5aa829=Object['entries'](_0x5af39e)['reduce']((_0x479d21,[_0x3e5f05,_0x23cc40])=>''+_0x479d21+_0x3e5f05+'='+_0x23cc40+',','');if(Rf(_0x11761e)&&_0x1ae7b9!=='_self')return n_(_0x1cb85b||'',_0x1ae7b9),new xr(null);const _0x41e9f9=window['open'](_0x1cb85b||'',_0x1ae7b9,_0x5aa829);m(_0x41e9f9,_0x8af31d,'popup-blocked');try{_0x41e9f9['focus']();}catch{}return new xr(_0x41e9f9);}function n_(_0x35e169,_0x21c2d0){const _0x60caf8=document['createElement']('a');_0x60caf8['href']=_0x35e169,_0x60caf8['target']=_0x21c2d0;const _0x40b5ea=document['createEvent']('MouseEvent');_0x40b5ea['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x60caf8['dispatchEvent'](_0x40b5ea);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x423747,_0x4d90a2,_0x4e1871,_0x511967,_0x4f2f7e,_0x586150){m(_0x423747['config']['authDomain'],_0x423747,'auth-domain-config-required'),m(_0x423747['config']['apiKey'],_0x423747,'invalid-api-key');const _0x1dcdf8={'apiKey':_0x423747['config']['apiKey'],'appName':_0x423747['name'],'authType':_0x4e1871,'redirectUrl':_0x511967,'v':dt,'eventId':_0x4f2f7e};if(_0x4d90a2 instanceof Wa){_0x4d90a2['setDefaultLanguage'](_0x423747['languageCode']),_0x1dcdf8['providerId']=_0x4d90a2['providerId']||'',pn(_0x4d90a2['getCustomParameters']())||(_0x1dcdf8['customParameters']=JSON['stringify'](_0x4d90a2['getCustomParameters']()));for(const [_0x1b53c2,_0x28f080]of Object['entries']({}))_0x1dcdf8[_0x1b53c2]=_0x28f080;}if(_0x4d90a2 instanceof tn){const _0x574daa=_0x4d90a2['getScopes']()['filter'](_0x31db59=>_0x31db59!=='');_0x574daa['length']>0x0&&(_0x1dcdf8['scopes']=_0x574daa['join'](','));}_0x423747['tenantId']&&(_0x1dcdf8['tid']=_0x423747['tenantId']);const _0x40134d=_0x1dcdf8;for(const _0x20480e of Object['keys'](_0x40134d))_0x40134d[_0x20480e]===void 0x0&&delete _0x40134d[_0x20480e];const _0x429cf8=await _0x423747['_getAppCheckToken'](),_0x1205c8=_0x429cf8?'#'+r_+'='+encodeURIComponent(_0x429cf8):'';return o_(_0x423747)+'?'+ut(_0x40134d)['slice'](0x1)+_0x1205c8;}function o_({config:_0x122fd2}){return _0x122fd2['emulator']?Cs(_0x122fd2,s_):'https://'+_0x122fd2['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0xb35060,_0x55af96,_0x51cd1c,_0x1b9f6a){var _0x4169f7;ce((_0x4169f7=this['eventManagers'][_0xb35060['_key']()])==null?void 0x0:_0x4169f7['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x158d7b=await Fr(_0xb35060,_0x55af96,_0x51cd1c,Mi(),_0x1b9f6a);return t_(_0xb35060,_0x158d7b,As());}async['_openRedirect'](_0x5804fc,_0x2878aa,_0x4339bf,_0x714ee1){await this['_originValidation'](_0x5804fc);const _0x1c1138=await Fr(_0x5804fc,_0x2878aa,_0x4339bf,Mi(),_0x714ee1);return hp(_0x1c1138),new Promise(()=>{});}['_initialize'](_0x46f0e2){const _0x1ab6d0=_0x46f0e2['_key']();if(this['eventManagers'][_0x1ab6d0]){const {manager:_0x53a7c9,promise:_0x109c41}=this['eventManagers'][_0x1ab6d0];return _0x53a7c9?Promise['resolve'](_0x53a7c9):(ce(_0x109c41,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x109c41);}const _0x237175=this['initAndGetManager'](_0x46f0e2);return this['eventManagers'][_0x1ab6d0]={'promise':_0x237175},_0x237175['catch'](()=>{delete this['eventManagers'][_0x1ab6d0];}),_0x237175;}async['initAndGetManager'](_0x1c18ff){const _0x49833f=await Yp(_0x1c18ff),_0x4fbb85=new Dp(_0x1c18ff);return _0x49833f['register']('authEvent',_0x58bd25=>(m(_0x58bd25==null?void 0x0:_0x58bd25['authEvent'],_0x1c18ff,'invalid-auth-event'),{'status':_0x4fbb85['onEvent'](_0x58bd25['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x1c18ff['_key']()]={'manager':_0x4fbb85},this['iframes'][_0x1c18ff['_key']()]=_0x49833f,_0x4fbb85;}['_isIframeWebStorageSupported'](_0x50facd,_0x4a11bb){this['iframes'][_0x50facd['_key']()]['send'](pi,{'type':pi},_0x4c51ec=>{var _0x4768a6;const _0x3f30f4=(_0x4768a6=_0x4c51ec==null?void 0x0:_0x4c51ec[0x0])==null?void 0x0:_0x4768a6[pi];_0x3f30f4!==void 0x0&&_0x4a11bb(!!_0x3f30f4),Y(_0x50facd,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x2879d8){const _0x2cfe4e=_0x2879d8['_key']();return this['originValidationPromises'][_0x2cfe4e]||(this['originValidationPromises'][_0x2cfe4e]=Up(_0x2879d8)),this['originValidationPromises'][_0x2cfe4e];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x3fd40b){this['auth']=_0x3fd40b,this['internalListeners']=new Map();}['getUid'](){var _0x140721;return this['assertAuthConfigured'](),((_0x140721=this['auth']['currentUser'])==null?void 0x0:_0x140721['uid'])||null;}async['getToken'](_0x2afad7){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x2afad7)}:null;}['addAuthTokenListener'](_0x4f8fa2){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x4f8fa2))return;const _0x914f7d=this['auth']['onIdTokenChanged'](_0x2351b6=>{_0x4f8fa2((_0x2351b6==null?void 0x0:_0x2351b6['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x4f8fa2,_0x914f7d),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x265851){this['assertAuthConfigured']();const _0x55db23=this['internalListeners']['get'](_0x265851);_0x55db23&&(this['internalListeners']['delete'](_0x265851),_0x55db23(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x3aa932){switch(_0x3aa932){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x464f7f){st(new Fe('auth',(_0x199629,{options:_0x5cc148})=>{const _0x3f7f45=_0x199629['getProvider']('app')['getImmediate'](),_0x3a0626=_0x199629['getProvider']('heartbeat'),_0x700076=_0x199629['getProvider']('app-check-internal'),{apiKey:_0x58d8ce,authDomain:_0x1ddfc6}=_0x3f7f45['options'];m(_0x58d8ce&&!_0x58d8ce['includes'](':'),'invalid-api-key',{'appName':_0x3f7f45['name']});const _0x4ce1b6={'apiKey':_0x58d8ce,'authDomain':_0x1ddfc6,'clientPlatform':_0x464f7f,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x464f7f)},_0x1a3713=new Df(_0x3f7f45,_0x3a0626,_0x700076,_0x4ce1b6);return Hf(_0x1a3713,_0x5cc148),_0x1a3713;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x3ce8ae,_0x4e9765,_0xa0fcae)=>{_0x3ce8ae['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x23ac24=>{const _0x5af7b2=Ke(_0x23ac24['getProvider']('auth')['getImmediate']());return(_0x47f285=>new l_(_0x47f285))(_0x5af7b2);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x464f7f)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x2cc939=>async _0x36b5c6=>{const _0xa90d0e=_0x36b5c6&&await _0x36b5c6['getIdTokenResult'](),_0x27ef9a=_0xa90d0e&&(new Date()['getTime']()-Date['parse'](_0xa90d0e['issuedAtTime']))/0x3e8;if(_0x27ef9a&&_0x27ef9a>f_)return;const _0x42c6cb=_0xa90d0e==null?void 0x0:_0xa90d0e['token'];Br!==_0x42c6cb&&(Br=_0x42c6cb,await fetch(_0x2cc939,{'method':_0x42c6cb?'POST':'DELETE','headers':_0x42c6cb?{'Authorization':'Bearer\x20'+_0x42c6cb}:{}}));};function B_(_0x1ba3f2=Zr()){const _0x355461=Hi(_0x1ba3f2,'auth');if(_0x355461['isInitialized']())return _0x355461['getImmediate']();const _0x48a195=Vf(_0x1ba3f2,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x13942a=jr('authTokenSyncURL');if(_0x13942a&&typeof isSecureContext=='boolean'&&isSecureContext){const _0xa84f55=new URL(_0x13942a,location['origin']);if(location['origin']===_0xa84f55['origin']){const _0x5e9dd3=p_(_0xa84f55['toString']());sp(_0x48a195,_0x5e9dd3,()=>_0x5e9dd3(_0x48a195['currentUser'])),ip(_0x48a195,_0x4de24e=>_0x5e9dd3(_0x4de24e));}}const _0xe5ea=qr('auth');return _0xe5ea&&$f(_0x48a195,'http://'+_0xe5ea),_0x48a195;}function __(){var _0x8e518f;return((_0x8e518f=document['getElementsByTagName']('head'))==null?void 0x0:_0x8e518f[0x0])??document;}Mf({'loadJS'(_0x347f07){return new Promise((_0x1bcd4f,_0x410b50)=>{const _0x2b29bb=document['createElement']('script');_0x2b29bb['setAttribute']('src',_0x347f07),_0x2b29bb['onload']=_0x1bcd4f,_0x2b29bb['onerror']=_0xccfdc2=>{const _0x3572c6=X('internal-error');_0x3572c6['customData']=_0xccfdc2,_0x410b50(_0x3572c6);},_0x2b29bb['type']='text/javascript',_0x2b29bb['charset']='UTF-8',__()['appendChild'](_0x2b29bb);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};